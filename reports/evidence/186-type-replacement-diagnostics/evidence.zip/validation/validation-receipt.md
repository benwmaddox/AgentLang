# Type replacement diagnostic validation receipt

Repository checkout: `D:\code\AgentLang`, branch `main`.

## Failed preparation attempts retained

- `dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore` exited 1 with `The build failed. Fix the build errors and run again.`
- `dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore -v minimal` exited 1 with `Build FAILED` and 0 warnings / 0 errors. The retained detailed diagnostic attempt is `build.diag.txt`; it failed in `_GetProjectReferenceTargetFrameworkProperties` without a surfaced compiler diagnostic.
- `dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore -m:1 -p:BuildProjectReferences=false -v minimal` caught `FS0041` at `Program.fs(805,20)` because a helper parameter lacked a string annotation. The helper now has explicit parameter types.
- `dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore --no-build` exited `-532462766` when tests used the default OS temp directory. Output: `qualify the help-returned Result function as a library word: expected success, got STORAGE_ACCESS_DENIED: Access to the path is denied.` The rerun used workspace-local process `TEMP` and `TMP`.

## Passing focused validation

- Build command: `dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore -m:1 -v minimal`
- Build result: passed with 0 warnings and 0 errors. Core, CLI, and Flow Runtime test assemblies built in Release.
- Test command: with process `TEMP` and `TMP` set to `D:\code\AgentLang\.agentlang\type-diagnostic-186\tmp`, run `dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore --no-build`.
- Test result: `Flow Runtime tests passed: 42 groups, 1891 assertions.` Exit code 0. Exact output is retained in `focused-run.txt`.
- `git diff --check` passed with exit code 0.

## Source pins

- Diagnostic ordering and payload: `src/AgentLang.Core/Runtime.fs:3849` and `src/AgentLang.Core/Runtime.fs:5245`.
- Structured replacement help: `src/AgentLang.Core/AuthoringHelp.fs:46` and `src/AgentLang.Core/AuthoringHelp.fs:574`; JSON serialization is in `src/AgentLang.Core/Runtime.fs:413`.
- Focused help assertions: `tests/AgentLang.Flow.Runtime.Tests/Program.fs:267`.
- Type-only, mixed, same-name persistent record field-change, no-mutation, task abort, reload, and add-only duplicate assertions: `tests/AgentLang.Flow.Runtime.Tests/Program.fs:801` onward.
- Authoring documentation: `docs/AUTHORING.md:169`.

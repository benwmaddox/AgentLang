# Capability boundary review

## Conclusion

The filesystem provider rejects absolute paths, canonicalizes relative paths under the Engine project root, and checks each existing child for a reparse point before doing file I/O. I found no static `..`/rooted-path escape in that normalization path. One concrete gap remains if the intended guarantee is confinement against concurrent filesystem mutation: validation and use are separate path-based operations, so an actor able to replace a checked directory entry between them can redirect the later open. The source explicitly documents that this is not race-proof.

I found no source-level production bypass in Flow/2 test-file overrides. Replacement dispatch is attached to test execution, the original call's effect preflight still runs, and tests use the virtual file provider. This review does not certify the runtime as a security sandbox.

## Filesystem path enforcement

`FileSystem.resolve` rejects rooted/empty paths, combines the input with `Path.GetFullPath` of the project root, checks the canonical prefix, and walks path components for `ReparsePoint`/`LinkTarget` (`src/AgentLang.Core/FileSystem.fs:77-126`). `readText`, `fileExists`, and `writeText` then call `File.ReadAllBytes`, `File.GetAttributes`, and `File.WriteAllBytes` using the returned path (`:131-169`).

**Visible gap and condition:** another process/user that can mutate the project tree can replace a previously checked component with a symlink/junction/reparse point after `validateReparsePoints` returns but before the file API opens it. That creates a check/use window in which I/O may follow the replacement outside the project path. The module comment already says these checks reduce accidental traversal and are not a race-proof boundary (`:22-24`). Thus this is a limit of adversarial path confinement, not evidence of a static path parser escape.

**Requirement boundary:** `FileSystemMode.Real` is the default and the provider confines path strings at runtime (`src/AgentLang.Core/Runtime.fs:328-338, 1953-1983`). This is not OS process isolation: host permissions and who can modify the project tree remain part of the boundary. Virtual mode uses an in-memory map and does not resolve user paths to host files (`Runtime.fs:1957-1983`).

**Existing focused tests:** `tests/AgentLang.Cli.Tests/Program.fs:573-683` covers real reads/writes, virtual writes not reaching disk, test I/O isolation, distinct test and production grants, rejection of `../escaped.txt`, and denied effects. I found no focused symlink or deterministic check/use-race test in the audited test files.

**Bounded follow-up:** if hostile concurrent mutation is in scope, use handle-relative/no-follow traversal for the final open (or place execution under an OS sandbox with a read/write root). Add a deterministic test around an injected opener that swaps a path component after validation; avoid timing-based race tests. If the intended contract is protection from accidental traversal only, keep that host assumption explicit and require the project tree to be protected from concurrent writers.

## Test-only function overrides

`FlowLowering.compileTestFileSettings` resolves each override against the original compiler snapshot, rejects generated targets, requires an exact signature and effect subset, creates a synthetic fixture identity, and maps only the original target to that fixture (`src/AgentLang.Core/FlowLowering.fs:2741-2816, 2818-2913`). It checks the expanded program preserves original functions and has only the expected fixture additions (`:2926-2961`).

At execution, the interpreter validates the original and expanded programs, allowed target/fixture identities, signature compatibility, and effect subsets (`src/AgentLang.Core/IrInterpreter.fs:318-410, 420-440, 635-648`). Each original call runs `PreflightEffects` before replacement dispatch (`:622-634`), so a pure fake cannot grant a denied original effect. Runtime tests create the test trace in `FileSystemMode.Virtual` and pass the override map only to `executeBodyWithTestDispatch` for the test body (`src/AgentLang.Core/Runtime.fs:2556-2571`). Ordinary Flow evaluation compiles against and executes the production snapshot without that dispatch (`Runtime.fs:5373-5391`).

**Existing focused tests:** `tests/AgentLang.Flow.Runtime.Tests/Program.fs:6222-6271` verifies a real-mode Engine's test-file fake and virtual setup leave a host file unchanged across tests, publication, and reload, then confirms production evaluation reads the original host file. Lines `6273-6291` verify the override cannot bypass denied `fs.read`; `6293-6315` verify self-overridden tests do not qualify production library coverage. The CLI test at `tests/AgentLang.Cli.Tests/Program.fs:648-658` separately verifies test grants cannot authorize production writes.

**Assessment:** no concrete production leak/bypass was visible in the audited source paths. The conclusion is limited to Flow test-file dispatch through the language/runtime path; host code controls Engine setup and can call library APIs directly.

## Audit limits

This was a read-only source audit of `FileSystem.fs`, the relevant Runtime and interpreter/lowering paths, and focused CLI/Flow runtime tests. I did not run tests, builds, or probes and did not inspect unrelated repository or host files. The race analysis follows directly from the check-then-open code; no exploit was attempted.

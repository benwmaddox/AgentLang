#!/usr/bin/env python3
"""Seal report-285 evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
HERE = REPO / ".agentlang" / "lang-285"
OUT = REPO / "reports" / "evidence" / "285-equal-pages"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|secret|cookie\.txt$|\.env$|labels\.json$)")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(_: Path) -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    gates = sorted(p for p in HERE.glob("gates-*") if p.is_dir())[-1]
    for f in sorted(gates.glob("*.log")) + [gates / "summary.json"]:
        items.append((f, f"gates/{f.name}"))
    pg = REPO / ".agentlang" / "pages-285"
    for f in sorted(list(pg.glob("*.sh")) + list(pg.glob("*.py")) + list(pg.glob("*.rb")) + list(pg.glob("*.txt"))):
        items.append((f, f"pages-285/{f.name}"))
    sw = REPO / ".agentlang" / "linux-sweep-285"
    for name in ("PLAN.md", "sweep-lifetime.sh", "run-sweep.sh", "cleanup-native.sh", "aggregate.py", "aggregate-s285b.md", "aggregate-s285b.json",
                 "sweep-s285b.log", "wait-s285b.log", "contamination-screen.txt", "flowbin.txt", "wait-quiet-then-sweep.sh"):
        items.append((sw / name, f"sweep/{name}"))
    for f in sorted((sw / "runs").glob("s285b-*/*")):
        if f.is_file() and (f.name != "server.log" or f.stat().st_size < 1_000_000):
            items.append((f, f"sweep/runs/{f.parent.name}/{f.name}"))
    for name in ("Run-Gates.ps1", "seal_285.py"):
        items.append((HERE / name, f"tools/{name}"))
    items.append((REPO / ".agentlang" / "lang-281" / "secret_scan.py", "tools/secret_scan.py"))
    changed = subprocess.run(["git", "diff", "--name-only", "24945d5"], cwd=REPO, check=True, capture_output=True, text=True).stdout.split()
    for rel in sorted(set(changed)):
        path = REPO / rel
        if path.is_file() and not rel.startswith("reports/"):
            items.append((path, f"sources/{rel}"))
    return items


def main() -> int:
    gates = HERE
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries, blobs = [], {}
    for path, arc in collect(gates):
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) and path.name not in ("server-log-secret-scan.txt", "secret_scan.py"):  # holds a hit count only
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "agentlang-evidence-v1", "report": "285", "entries": entries}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "285-equal-pages-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        if set(zf.namelist()) != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

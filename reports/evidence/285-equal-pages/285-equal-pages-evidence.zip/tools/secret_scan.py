#!/usr/bin/env python3
"""Value-based secret scan of an evidence zip: reference.env values, fixture passwords and the
snapshot session cookies (>= 12 chars). Prints counts and member names only, never values."""
import json, sys, zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
H = REPO / ".agentlang" / "once-campfire-verification" / "fixtures" / "default"
M = REPO / ".agentlang" / "campfire-matched-258" / "private"

values = set()
for line in (H / "reference.env").read_text(encoding="utf-8").splitlines():
    if "=" in line and not line.lstrip().startswith("#"):
        name, value = line.split("=", 1)
        if not name.strip().endswith("PUBLIC_KEY"):  # public by design (VAPID key is in every page)
            values.add(value.strip())
labels = json.loads((H / "labels.json").read_text(encoding="utf-8"))
def walk(v, key=""):
    if isinstance(v, dict):
        for k, x in v.items(): walk(x, k)
    elif isinstance(v, str) and "pass" in key.lower():
        values.add(v)
walk(labels)
for k, v in labels.items():
    if "pass" in k.lower() and isinstance(v, str): values.add(v)
for f in M.glob("rails-cookie-*.txt"):
    values.add(f.read_text(encoding="utf-8").strip())
needles = [v.encode() for v in values if len(v) >= 12]
hits = []
with zipfile.ZipFile(sys.argv[1]) as zf:
    for name in zf.namelist():
        data = zf.read(name)
        if any(n in data for n in needles):
            hits.append(name)
print(json.dumps({"needles": len(needles), "members": len(zipfile.ZipFile(sys.argv[1]).namelist()), "hits": hits}))
sys.exit(1 if hits else 0)

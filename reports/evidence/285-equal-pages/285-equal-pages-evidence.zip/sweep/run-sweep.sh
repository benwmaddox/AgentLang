# Root orchestrator for the 284 sweep: 3 reps x 6 server/cache configs, interleaved, each lifetime
# measuring 16/32/64/128 connections in a rotated order. Pre-registered in PLAN.md.
# wsl -d Ubuntu -u root -- bash /mnt/d/code/AgentLang/.agentlang/linux-sweep-285/run-sweep.sh <tag>
set -u
D=/mnt/d/code/AgentLang/.agentlang/linux-sweep-285
TAG=$1
CONFIGS=(flow:off rust:off rails:off flow:on rust:on rails:on)
CORDERS=(16,32,64,128 128,64,32,16 32,128,16,64 64,16,128,32)
LOG=$D/sweep-$TAG.log
i=0
for rep in 1 2 3; do
  # Rotate the config order by 2 per rep, and reverse it on rep 2, so no config always runs first.
  order=()
  for k in 0 1 2 3 4 5; do order+=("${CONFIGS[$(( (k + 2*(rep-1)) % 6 ))]}"); done
  [ $rep = 2 ] && order=("${order[5]}" "${order[4]}" "${order[3]}" "${order[2]}" "${order[1]}" "${order[0]}")
  for cfg in "${order[@]}"; do
    app=${cfg%%:*}; cache=${cfg##*:}; concs=${CORDERS[$(( i % 4 ))]}; i=$((i+1))
    run=$TAG-$app-$cache-r$rep
    echo "$(date -u +%FT%TZ) start $run concs=$concs loadavg=$(cut -d' ' -f1-3 /proc/loadavg) top=$(ps -eo pcpu,comm --sort=-pcpu --no-headers | head -3 | tr -s ' ' | tr '\n' ';')" | tee -a "$LOG"
    bash $D/sweep-lifetime.sh "$app" "$run" "$cache" "$concs"; rc=$?
    echo "$(date -u +%FT%TZ) end $run exit=$rc cgroup_left=$(test -e /sys/fs/cgroup/lb273-srv && echo yes || echo no) netns=$(ip netns list | grep -c lb273) host_listeners=$(ss -ltnH | awk '{print $4}' | grep -cE ':(13774|13775|6379)$')" | tee -a "$LOG"
    [ $rc = 0 ] || bash $D/cleanup-native.sh >> "$LOG" 2>&1
  done
done
echo "$(date -u +%FT%TZ) sweep done" | tee -a "$LOG"

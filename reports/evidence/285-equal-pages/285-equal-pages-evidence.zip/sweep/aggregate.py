#!/usr/bin/env python3
"""Aggregate sweep cells: median [min-max] over reps per (app, cache, conc), plus each server's peak
(the highest-median-req/s connection count whose cells are all labeled saturated; PLAN.md)."""
import json, statistics, sys
from collections import defaultdict
from pathlib import Path

D = Path(__file__).resolve().parent
tag = sys.argv[1]
cells = [json.loads(l) for f in sorted((D / "runs").glob(f"{tag}-*/cells.jsonl")) for l in f.read_text().splitlines() if l.strip()]
groups = defaultdict(list)
for c in cells:
    groups[(c["app"], c["cache"], c["conc"])].append(c)

def mr(xs, fmt):
    return f"{fmt.format(statistics.median(xs))} [{fmt.format(min(xs))}-{fmt.format(max(xs))}]"

order = {"rails": 0, "rust": 1, "flow": 2}
out = {"cells": len(cells), "rows": [], "peaks": []}
print("| Server | Cache | Conn | n | Req/s | CPU ms/req | p50 / p99 ms | Server util | Client util | Labels | PSS MB |")
print("| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: |")
for key in sorted(groups, key=lambda k: (k[1], order[k[0]], k[2])):
    g = groups[key]
    labels = sorted({c["label"] for c in g})
    bad = sum(c["invalid"] + c["errors"] for c in g) + sum(v for c in g for s, v in c["statuses"].items() if s != "200")
    fmt_rps = "{:,.0f}" if statistics.median(c["rps"] for c in g) >= 100 else "{:.1f}"
    row = dict(app=key[0], cache=key[1], conc=key[2], reps=len(g), rps=statistics.median(c["rps"] for c in g),
               cpu=statistics.median(c["cpu_ms_per_req"] for c in g), labels=labels, bad=bad,
               server_util=statistics.median(c["server_util"] for c in g), client_util=statistics.median(c["client_util"] for c in g))
    out["rows"].append(row)
    print(f"| {key[0]} | {key[1]} | {key[2]} | {len(g)} | {mr([c['rps'] for c in g], fmt_rps)} | {mr([c['cpu_ms_per_req'] for c in g], '{:.2f}')} | "
          f"{statistics.median(c['p50_ms'] for c in g):.1f} / {statistics.median(c['p99_ms'] for c in g):.1f} | "
          f"{mr([c['server_util'] for c in g], '{:.2f}')} | {mr([c['client_util'] for c in g], '{:.2f}')} | {', '.join(labels)}{' BAD=' + str(bad) if bad else ''} | "
          f"{statistics.median(c['pss_mb'] for c in g):.1f} |")
print()
print("| Server | Cache | Peak conn | Req/s | CPU ms/req | Label |")
print("| --- | --- | ---: | ---: | ---: | --- |")
for app in ("rails", "rust", "flow"):
    for cache in ("off", "on"):
        rows = [r for r in out["rows"] if r["app"] == app and r["cache"] == cache]
        if not rows: continue
        sat = [r for r in rows if r["labels"] == ["saturated"]]
        best = max(sat or rows, key=lambda r: r["rps"])
        label = "saturated" if sat else "not saturated: " + "/".join(best["labels"])
        out["peaks"].append(dict(best, peak_label=label))
        print(f"| {app} | {cache} | {best['conc']} | {best['rps']:,.1f} | {best['cpu']:.3f} | {label} |")
(D / f"aggregate-{tag}.json").write_text(json.dumps(out, indent=2) + "\n")

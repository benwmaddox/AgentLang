# Root: recover from a crashed native lifetime (kills the server cgroup, removes netns lb273).
C=/sys/fs/cgroup/lb273-srv
if [ -e $C ]; then
  echo "procs=$(wc -l < $C/cgroup.procs)"; echo 1 > $C/cgroup.kill
  for i in $(seq 1 100); do grep -q "populated 0" $C/cgroup.events && break; sleep 0.1; done
  rmdir $C && echo "cgroup removed"
fi
ip netns del lb273 2>/dev/null && echo "netns removed"
echo "host_listeners=$(ss -ltnH | awk '{print $4}' | grep -cE ':(13774|13775|6379)$')"

P=/home/ben/linuxbench/private
D=/mnt/d/code/AgentLang/.agentlang/pages-285/private
cp $P/s284-flow-off-r1/body1.html $D/flow.html
cp $P/s284-rust-off-r1/body1.html $D/rust.html
cp $P/s284-rails-off-r1/body1.html $D/rails.html
ls -la $D

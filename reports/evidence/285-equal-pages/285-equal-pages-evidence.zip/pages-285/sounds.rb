# Campfire's built-in sounds (reference app/models/sound.rb) with their digested asset paths from
# the compiled asset manifest, as JSON rows: name, mp3 path, image path or "", width, height, text.
require "json"
# ActiveSupport's Array#index_by, which sound.rb uses.
class Array
  def index_by
    each_with_object({}) { |item, index| index[yield(item)] = item }
  end
end
load ARGV.fetch(0)
manifest = JSON.parse(File.read(ARGV.fetch(1)))
rows = Sound::INDEX.keys.sort.map do |name|
  sound = Sound.find_by_name(name)
  mp3 = manifest.fetch(sound.asset_path).fetch("digested_path")
  if sound.image
    image = manifest.fetch(sound.image.asset_path).fetch("digested_path")
    [ name, mp3, image, sound.image.width, sound.image.height, "" ]
  else
    [ name, mp3, "", 0, 0, sound.text ]
  end
end
File.write(ARGV.fetch(2), JSON.generate(rows))
puts "sounds=#{rows.size}"

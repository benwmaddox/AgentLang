for p in $(cat /sys/fs/cgroup/lb273-srv/cgroup.procs); do ps -o pid=,comm=,args= -p "$p" | cut -c1-120; done

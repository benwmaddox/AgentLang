# Oracle tests for message file attachments: Rails' output for each attachment message,
# against campfire.presentation.attachment-html of the blob row the server reads
# (SQLite metadata text) with tokens signed here like ActiveStorage.verifier does.
import base64, hashlib, hmac, json, sqlite3
R = r"D:\code\AgentLang\.agentlang"
env = {}
for line in open(R + r"\once-campfire-verification\fixtures\default\reference.env", encoding="utf-8"):
    line = line.strip()
    if "=" in line and not line.startswith("#"):
        k, v = line.split("=", 1); env[k] = v
key = hashlib.pbkdf2_hmac("sha256", env["SECRET_KEY_BASE"].encode(), b"ActiveStorage", 1000, 64)
def sign(data, purpose):
    m = base64.b64encode(json.dumps({"_rails": {"data": data, "pur": purpose}}, separators=(",", ":")).encode()).decode()
    return m + "--" + hmac.new(key, m.encode(), hashlib.sha1).hexdigest()
db = sqlite3.connect(R + r"\once-campfire-verification\fixtures\default\db\production.sqlite3")
rows = {r[0]: r[1:] for r in db.execute("""SELECT a.record_id, b.id, b.filename, b.content_type,
  CASE WHEN json_type(b.metadata, '$.width') IN ('integer', 'real') THEN CAST(json_extract(b.metadata, '$.width') AS TEXT) ELSE '' END,
  CASE WHEN json_type(b.metadata, '$.height') IN ('integer', 'real') THEN CAST(json_extract(b.metadata, '$.height') AS TEXT) ELSE '' END
  FROM active_storage_attachments a JOIN active_storage_blobs b ON b.id = a.blob_id WHERE a.record_type = 'Message' AND a.name = 'attachment'""")}
def q(s): return json.dumps(s, ensure_ascii=False)
out = []
for line in open(R + r"\pages-285\private\oracle-r2.jsonl", encoding="utf-8"):
    d = json.loads(line)
    if d["content_type"] != "attachment": continue
    blob, filename, kind, width, height = rows[d["id"]]
    variation = None
    if kind.startswith("video/"): variation = {"format": "webp", "resize_to_limit": [1200, 800]}
    elif kind == "image/jpeg": variation = {"format": "jpg", "resize_to_limit": [1200, 800]}
    preview = sign(variation, "variation") if variation else ""
    out.append(f'''test campfire.presentation.attachment-html/oracle-m{d["id"]} {{
    let attachment = messageAttachment.new(message-id = {d["id"]}, filename = {q(filename)}, content-type = {q(kind)}, width = {q(width)}, height = {q(height)}, blob-token = {q(sign(blob, "blob_id"))}, preview-token = {q(preview)})
    expect Html.value(campfire.presentation.attachment-html(attachment)) == {q(d["html"])}
}}
''')
open(R + r"\pages-285\private\attachment-oracle-tests.flow", "w", encoding="utf-8", newline="").write("\n".join(out))
print(len(out), "tests;", [rows[k][3:] for k in rows])

from pathlib import Path
R = Path(r"D:\code\AgentLang")


def rw(rel, pairs):
    p = R / rel
    s = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70], s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8", newline="")


rw("src/stdlib/rich-html.flow", [
    ('''    for step in 0..length + 1 {
        if bool.not(ok) || at >= length {''', '''    let steps = length + 1
    for step in 0..steps {
        if bool.not(ok) || at >= length {'''),
    ('''            var name-end = if closing { at + 2 } else { at + 1 }
            for k in name-end..length {''', '''            var name-end = if closing { at + 2 } else { at + 1 }
            let name-scan = name-end
            for k in name-scan..length {'''),
    ('''                    var attr-end = cursor + 1
                    for k in cursor + 1..length {''', '''                    var attr-end = cursor + 1
                    let attr-scan = cursor + 1
                    for k in attr-scan..length {'''),
    ('''                    var value-end = attr-end + 2
                    for k in attr-end + 2..length {''', '''                    var value-end = attr-end + 2
                    let value-scan = attr-end + 2
                    for k in value-scan..length {'''),
    ('''        } else if byte == 62 || byte == 34 && false {
            ok = false''', '''        } else if byte == 62 {
            ok = false'''),
])

rw("applications/campfire/message.flow", [
    ('''fn campfire.views.rails-message-boosted(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>) -> Html {
    effects none
    doc "''', '''fn campfire.views.rails-message-boosted(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>) -> Html {
    effects none
    doc "campfire.views.rails-message-presented with the body escaped as text."
    let body = match message.body {
        none => Html.new("")
        some text => Html.new(text)
    }
    campfire.views.rails-message-presented(context, message, boost-views, body)
}

fn campfire.views.rails-message-presented(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html) -> Html {
    effects none
    doc "body is the message's presentation (what Rails' message_presentation puts inside the lexxy-content layout). '''),
    ('''    let body = match message.body {
        none => Html.new("")
        some text => Html.new(text)
    }
    let boosts = boost-views.map(campfire.views.boost)''', '''    let boosts = boost-views.map(campfire.views.boost)'''),
])

rw("src/AgentLang.FlowHttp/FlowApp.fs", [
    ('let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow" ]', 'let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow"; "rich-html.flow" ]'),
])

rw("applications/campfire/server/server.flow", [
    ('''fn campfire.server.render-message(context: MessageContext, message: MessageWithCreator, boosts: List<BoostView>) -> String {
    doc "messages/_message with the message's own boosts."
    campfire.views.text(campfire.views.rails-message-boosted(context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id))))
}''', '''fn campfire.server.presentation(message: MessageWithCreator) -> Html {
    doc "The message body as Rails' message_presentation shows it: a stored body that is already safe, canonical rich text (rich-html.canonical?) is inserted as is, which is what Rails renders for it; anything else is escaped as text until the full Flow pipeline exists (docs/EQUAL-PAGES-PLAN.md)."
    match message.body {
        none => Html.new("")
        some text => if rich-html.canonical?(text) { html.raw(text) } else { Html.new(text) }
    }
}

test campfire.server.presentation/canonical-or-escaped {
    let message = messageWithCreator.new(id = MessageId.new(5), room-id = RoomId.new(1), creator-id = UserId.new(1), created-at-ms = 0, updated-at-ms = 0, client-message-id = "c5", created-at = "", creator-name = "", creator-bio = "", creator-updated-at = "", creator-avatar-token = "", body = option.some<String>("<p>hi</p>"))
    expect campfire.views.text(campfire.server.presentation(message)) == "<p>hi</p>"
    let unsafe = messageWithCreator.new(id = MessageId.new(5), room-id = RoomId.new(1), creator-id = UserId.new(1), created-at-ms = 0, updated-at-ms = 0, client-message-id = "c5", created-at = "", creator-name = "", creator-bio = "", creator-updated-at = "", creator-avatar-token = "", body = option.some<String>("<script>x</script>"))
    expect campfire.views.text(campfire.server.presentation(unsafe)) == "&lt;script&gt;x&lt;/script&gt;"
}

fn campfire.server.render-message(context: MessageContext, message: MessageWithCreator, boosts: List<BoostView>) -> String {
    doc "messages/_message with the message's own boosts and its presentation."
    campfire.views.text(campfire.views.rails-message-presented(context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message)))
}'''),
    ('''        rendered = list.append(rendered, campfire.views.rails-message-boosted(message-context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id))))''',
     '''        rendered = list.append(rendered, campfire.views.rails-message-presented(message-context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message)))'''),
])
print("ok")

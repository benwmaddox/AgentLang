from pathlib import Path
p = Path(r"D:\code\AgentLang\scripts\Test-CampfireFlowServerParity.ps1")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''    [int] $StoreMb = 32''', '''    [int] $StoreMb = 32,
    # Since report 285 the Flow server renders the room page as Rails does (docs/EQUAL-PAGES-PLAN.md),
    # which the native HTTP.sys host (scheduled for deletion) does not. Room-page bodies are then
    # compared with this Rails page (CSRF elements removed) instead of the native host's; statuses,
    # headers, cookies and every other body still compare with the native host.
    [string] $RailsRoomPage = \'\'''')
rep('''    $same = [ordered]@{ status = $native.status -eq $flow.status; headers = $native.headers -eq $flow.headers; cookies = $native.cookies -eq $flow.cookies; body = $native.body -ceq $flow.body }''',
    '''    $roomPage = $RailsRoomPage -ne '' -and $native.status -eq '200' -and $native.bodyBytes -gt 100000
    $expectedBody = if ($roomPage) { [IO.File]::ReadAllText([IO.Path]::GetFullPath($RailsRoomPage)) } else { $native.body }
    $same = [ordered]@{ status = $native.status -eq $flow.status; headers = $native.headers -eq $flow.headers; cookies = $native.cookies -eq $flow.cookies; body = $expectedBody -ceq $flow.body }''')
rep('''    "{0,-15} status {1}/{2} headers={3} set-cookie={4} body={5} ({6} bytes)" -f $name, $native.status, $flow.status, $same.headers, $same.cookies, $same.body, $flow.bodyBytes''',
    '''    "{0,-15} status {1}/{2} headers={3} set-cookie={4} body={5} ({6} bytes{7})" -f $name, $native.status, $flow.status, $same.headers, $same.cookies, $same.body, $flow.bodyBytes, $(if ($roomPage) { ', vs Rails' } else { '' })''')
a = '''$loadgenSame = [IO.File]::ReadAllText((Join-Path $out 'native/loadgen-body.html')) -ceq [IO.File]::ReadAllText((Join-Path $out 'flow/loadgen-body.html'))'''
assert a in s
s = s.replace(a, '''$loadgenExpected = if ($RailsRoomPage -ne '') { [IO.File]::ReadAllText([IO.Path]::GetFullPath($RailsRoomPage)) } else { [IO.File]::ReadAllText((Join-Path $out 'native/loadgen-body.html')) }
$loadgenSame = $loadgenExpected -ceq [IO.File]::ReadAllText((Join-Path $out 'flow/loadgen-body.html'))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

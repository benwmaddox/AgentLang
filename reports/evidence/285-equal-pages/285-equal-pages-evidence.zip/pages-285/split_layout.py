from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\layout.flow")
s = p.read_text(encoding="utf-8")

title = "    <title>{chrome.room-name}</title>\n\n"
head_end = '<script type="module">import "application"</script>\n'
a = s.index(title) + len(title)
b = s.index(head_end, a) + len(head_end)
head = s[a:b]
lb_start = s.index('    <dialog class="lightbox"')
lb_end = s.index("  </body>", lb_start)
lightbox = s[lb_start:lb_end]
assert s.count('    <dialog class="lightbox"') == 1 and s.count(head_end) == 1

holes = {"{chrome.user-id}": "{user-id}", "{chrome.user-name}": "{user-name}", "{chrome.account-version}": "{account-version}"}
for old, new in holes.items():
    head = head.replace(old, new)
assert "{chrome." not in head and "{chrome." not in lightbox, "unexpected holes"

s = s[:a] + "{head}" + s[b:lb_start] + "{lightbox}" + s[lb_end:]
s = s.replace('''    doc "The Rails room page layout (layouts/application and rooms/show chrome), generated from Campfire's markup with every request, user, room and account value as a hole."
''', '''    doc "The Rails room page layout (layouts/application and rooms/show chrome), generated from Campfire's markup with every request, user, room and account value as a hole."
    let head = campfire.views.head-assets(chrome.user-id, chrome.user-name, chrome.account-version)
    let lightbox = campfire.views.lightbox()
''', 1)

s += '''
fn campfire.views.head-assets(user-id: String, user-name: String, account-version: String) -> Html {
    effects none
    doc "layouts/application's head after the title: meta tags (no CSRF tags: forgery protection is header-only), the current user, the account logo, stylesheets and the import map."
    html"""''' + head + '''"""
}

test campfire.views.head-assets/user {
    expect string.contains(campfire.views.text(campfire.views.head-assets("7", "Ann", "1")), "<meta name=\\"current-user-id\\" content=\\"7\\" />")
}

fn campfire.views.lightbox() -> Html {
    effects none
    doc "layouts/_lightbox and the app logo that close every page."
    html"""''' + lightbox + '''"""
}

test campfire.views.lightbox/dialog {
    expect string.starts-with(campfire.views.text(campfire.views.lightbox()), "    <dialog class=\\"lightbox\\"")
}

fn campfire.views.sidebar-page(head: Html, body-class: String, frame: Html) -> Html {
    effects none
    doc "users/sidebars#show inside layouts/application: the frame in main, an empty nav and sidebar."
    let lightbox = campfire.views.lightbox()
    html"""<!DOCTYPE html>
<html>
  <head>
    <title>Campfire</title>

{head}

  </head>

  <body class="{body-class}" data-controller="local-time lightbox">
    <a href="#main-content" class="skip-navigation btn">Skip to main content</a>

    <nav id="nav">

    </nav>


    <main id="main-content">
{frame}
      <footer id="footer">

      </footer>
    </main>

    <aside id="sidebar" data-controller="toggle-class" data-toggle-class-toggle-class="open">

    </aside>

{lightbox}  </body>
</html>
"""
}

test campfire.views.sidebar-page/frame {
    let text = campfire.views.text(campfire.views.sidebar-page(html"<x></x>", "admin", html"<y></y>"))
    expect string.contains(text, "<title>Campfire</title>") && string.contains(text, "<body class=\\"admin\\"")
}
'''
p.write_text(s, encoding="utf-8", newline="")
print("ok", len(head), len(lightbox))

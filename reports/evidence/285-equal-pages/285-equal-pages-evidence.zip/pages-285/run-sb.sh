PAGE_HEADERS=1 PAGE_PATH=/users/me/sidebar bash page-lifetime.sh rails pg-rails-sb1 off 16 > /dev/null 2>&1; echo rails=$?
mkdir -p private/sb; cp /home/ben/linuxbench/private/pg-rails-sb1/curl-body.html private/sb/rails.html; cp /home/ben/linuxbench/private/pg-rails-sb1/headers.txt private/sb/rails-headers.txt

from pathlib import Path
R = Path(r"D:\code\AgentLang")
A = R / "applications/campfire/server"


def edit(path, pairs):
    s = path.read_text(encoding="utf-8")
    for a, b, *n in pairs:
        count = n[0] if n else 1
        assert s.count(a) == count, (path.name, s.count(a), a[:100])
        s = s.replace(a, b)
    path.write_text(s, encoding="utf-8", newline="")


edit(A / "server-request.flow", [
    ("    after: Option<String>\n}", "    after: Option<String>\n    // GET/HEAD /users/me/sidebar (users/sidebars#show).\n    sidebar: Bool\n}"),
    ("    match campfire.server.room-path(path) {\n        none => result.error<ServerRequest, HttpResponse>(campfire.server.status(404))",
     '    let routed = if path == "/users/me/sidebar" { option.some<RoomPath>(roomPath.new(room = "0", around = option.none<String>(), paging = false)) } else { campfire.server.room-path(path) }\n    match routed {\n        none => result.error<ServerRequest, HttpResponse>(campfire.server.status(404))'),
    ('after = if paging { campfire.server.query-param(incoming.target, "after") } else { option.none<String>() })',
     'after = if paging { campfire.server.query-param(incoming.target, "after") } else { option.none<String>() }, sidebar = http.path(incoming.target) == "/users/me/sidebar")'),
])

s = (A / "server.flow").read_text(encoding="utf-8")
s = s.replace("paging = false, before = option.none<String>(), after = option.none<String>())",
              "paging = false, before = option.none<String>(), after = option.none<String>(), sidebar = false)")
a = "        ok built => if built.paging { campfire.server.messages-read(built, request, context) } else {"
assert s.count(a) == 1
s = s.replace(a, "        ok built => if built.sidebar { campfire.server.sidebar-read(built, request, context) } else if built.paging { campfire.server.messages-read(built, request, context) } else {")
a = '''    let request = built.campfire
    match campfire.server.restore-request-session(request, context) {
        error failure => campfire.server.http-response(campfire.server.response(500, HttpView.empty(), "", option.none<SessionToken>()), built, incoming.target, context)
        ok maybe-session => match maybe-session {
            none => campfire.server.http-response(campfire.server.bot-or-redirect(request), built, incoming.target, context)
            some restored => {
                let refresh = campfire.server.refresh-token(restored)
                match campfire.server.authenticated-user(request, restored, refresh) {
                    error response => campfire.server.http-response(response, built, incoming.target, context)
                    ok user => campfire.server.messages-index(request, user, refresh, built, incoming, context)
                }
            }
        }
    }'''
assert s.count(a) == 1
s = s.replace(a, '''    match campfire.server.signed-in(built, incoming, context) {
        error response => response
        ok signed => campfire.server.messages-index(built.campfire, signed.user, signed.refresh, built, incoming, context)
    }''')
(A / "server.flow").write_text(s, encoding="utf-8", newline="")

b = R / "scripts/Build-CampfireFlowServer.ps1"
t = b.read_text(encoding="utf-8")
print([l for l in t.split("\n") if "presentation.flow" in l or "server-db.flow" in l][:4])

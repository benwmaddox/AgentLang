from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (s.count(a), a[:90])
    s = s.replace(a, b)


rep("    turbo-key: Bytes\n}", "    turbo-key: Bytes\n    storage-key: Bytes\n}")
rep('        turbo-key = campfire.server.rails-key(secret, "turbo/signed_stream_verifier_key", 64))',
    '        turbo-key = campfire.server.rails-key(secret, "turbo/signed_stream_verifier_key", 64),\n        storage-key = campfire.server.rails-key(secret, "ActiveStorage", 64))')
rep("    expect bytes.length(context.avatar-key) == 64\n}", "    expect bytes.length(context.avatar-key) == 64\n    expect bytes.length(context.storage-key) == 64\n}")
rep('''fn campfire.server.presentation(message: MessageWithCreator, users: List<MentionUser>, request-host: String) -> Html {
    doc "campfire.presentation.body-for-host of the message's stored body, the mention users loaded for its page and the request's host."
    campfire.presentation.body-for-host(message.body, users, request-host)
}''', '''record PageExtras {
    users: List<MentionUser>
    attachments: List<MessageAttachment>
    request-host: String
}

fn campfire.server.no-extras() -> PageExtras {
    doc "No mention users, no attachments, no request host (for tests)."
    pageExtras.new(users = list.empty<MentionUser>(), attachments = list.empty<MessageAttachment>(), request-host = "")
}

test campfire.server.no-extras/empty {
    expect list.count(campfire.server.no-extras().users) == 0
}

fn campfire.server.page-extras(messages: List<MessageWithCreator>, server: CampfireServerContext) -> PageExtras {
    effects db.read
    doc "What presenting these messages needs beyond their rows: the users they mention and their attached files (one query each), and the request host."
    var ids = list.empty<Int>()
    for message in messages {
        ids = list.append(ids, MessageId.value(message.id))
    }
    let attachments = match campfire.server.attachments-for(ids, server.storage-key) { error failure => list.empty<MessageAttachment>(); ok found => found }
    pageExtras.new(users = campfire.server.page-mention-users(messages, server.avatar-key), attachments = attachments, request-host = campfire.server.request-host(server))
}

test campfire.server.page-extras/none {
    expect campfire.server.test-fixture() == 0
    expect campfire.server.page-extras(list.empty<MessageWithCreator>(), campfire.server.test-context()).request-host == "127.0.0.1"
}

fn campfire.server.presentation(message: MessageWithCreator, extras: PageExtras) -> Html {
    doc "message_presentation: the attached file when the message has one, else campfire.presentation.body-for-host of its stored body with the page's mention users and the request's host."
    var attached = option.none<MessageAttachment>()
    for attachment in extras.attachments {
        if attachment.message-id == MessageId.value(message.id) {
            attached = option.some<MessageAttachment>(attachment)
        }
    }
    match attached {
        some attachment => campfire.presentation.attachment-html(attachment)
        none => campfire.presentation.body-for-host(message.body, extras.users, extras.request-host)
    }
}''')
s = s.replace('list.empty<MentionUser>(), "")', 'campfire.server.no-extras())')
rep("boosts: List<BoostView>, users: List<MentionUser>, request-host: String) -> String {", "boosts: List<BoostView>, extras: PageExtras) -> String {")
rep("campfire.server.presentation(message, users, request-host)))", "campfire.server.presentation(message, extras)))")
rep("boosts: List<BoostView>, users: List<MentionUser>, request-host: String) -> StreamedPage {", "boosts: List<BoostView>, extras: PageExtras) -> StreamedPage {")
rep("campfire.server.render-message(context, message, boosts, users, request-host)", "campfire.server.render-message(context, message, boosts, extras)")
rep("fn campfire.server.stream-room-page(chrome: PageChrome, keys: List<PageKey>, cache: WorkerCache, avatar-key: Bytes, request-host: String) -> Result<Int, DbError> {",
    "fn campfire.server.stream-room-page(chrome: PageChrome, keys: List<PageKey>, cache: WorkerCache, server: CampfireServerContext) -> Result<Int, DbError> {")
rep("    let loaded-boosts = match campfire.server.boosts-for(missing, avatar-key) {", "    let loaded-boosts = match campfire.server.boosts-for(missing, server.avatar-key) {")
rep("    match campfire.server.messages-by-id(missing, avatar-key) {", "    match campfire.server.messages-by-id(missing, server.avatar-key) {")
rep("campfire.server.write-messages(cache, context, keys, loaded, boosts, campfire.server.page-mention-users(loaded, avatar-key), request-host)",
    "campfire.server.write-messages(cache, context, keys, loaded, boosts, campfire.server.page-extras(loaded, server))")
rep("campfire.server.stream-room-page(chrome, keys, cache, context.avatar-key, campfire.server.request-host(context))", "campfire.server.stream-room-page(chrome, keys, cache, context)")
rep('campfire.server.stream-room-page(chrome, keys, cache, campfire.server.test-context().avatar-key, "")', "campfire.server.stream-room-page(chrome, keys, cache, campfire.server.test-context())", 2)
rep("    let users = campfire.server.page-mention-users(messages, context.avatar-key)\n", "    let extras = campfire.server.page-extras(messages, context)\n")
rep("campfire.server.presentation(message, users, campfire.server.request-host(context))", "campfire.server.presentation(message, extras)")
p.write_text(s, encoding="utf-8", newline="")

p = Path(r"D:\code\AgentLang\applications\campfire\server\server-db.flow")
s = p.read_text(encoding="utf-8")
anchor = "fn campfire.server.mention-users("
assert s.count(anchor) == 1
q = '\\"'  # a Flow escaped quote: backslash, quote
block = '''fn campfire.server.storage-token(storage-key: Bytes, data: String, purpose: String) -> String {
    doc "ActiveStorage.verifier.generate(data, purpose:): strict Base64 of the JSON envelope, '--', hex HMAC-SHA1 with the ActiveStorage key. data is already JSON."
    let encoded = base64.encode(bytes.from-utf8(string.join(["{@Q@_rails@Q@:{@Q@data@Q@:", data, ",@Q@pur@Q@:@Q@", purpose, "@Q@}}"])))
    string.join([encoded, "--", hex.encode(crypto.hmac-sha1(storage-key, bytes.from-utf8(encoded)))])
}

test campfire.server.storage-token/shape {
    let token = campfire.server.storage-token(bytes.from-utf8("k"), "5", "blob_id")
    expect string.starts-with(token, "eyJfcmFpbHMiOnsiZGF0YSI6NSwicHVyIjoiYmxvYl9pZCJ9fQ==--") && string.byte-length(token) == 56 + 40
}

fn campfire.server.attachments-for(ids: List<Int>, storage-key: Bytes) -> Result<List<MessageAttachment>, DbError> {
    effects db.read
    doc "The attached file of each of these messages (has_one_attached :attachment), in one query: its blob row, metadata dimensions as SQLite writes the JSON numbers, and the signed blob id and preview variation key."
    if list.count(ids) == 0 {
        result.ok<List<MessageAttachment>, DbError>(list.empty<MessageAttachment>())
    } else {
        match db.query("SELECT a.record_id, b.id, b.filename, b.content_type, CASE WHEN json_type(b.metadata, '$.width') IN ('integer', 'real') THEN CAST(json_extract(b.metadata, '$.width') AS TEXT) ELSE '' END, CASE WHEN json_type(b.metadata, '$.height') IN ('integer', 'real') THEN CAST(json_extract(b.metadata, '$.height') AS TEXT) ELSE '' END FROM active_storage_attachments AS a INNER JOIN active_storage_blobs AS b ON b.id = a.blob_id WHERE a.record_type = 'Message' AND a.name = 'attachment' AND a.record_id IN (SELECT value FROM json_each($ids))", [db.text-param(campfire.server.id-list(ids))]) {
            error failure => result.error<List<MessageAttachment>, DbError>(campfire.server.db-error(failure))
            ok rows => {
                var attachments = list.empty<MessageAttachment>()
                for row in rows {
                    let filename = campfire.server.text-or-empty(db.optional-text(row, 2))
                    let kind = campfire.server.text-or-empty(db.optional-text(row, 3))
                    let variation = campfire.presentation.preview-variation(filename, kind)
                    attachments = list.append(attachments, messageAttachment.new(
                        message-id = campfire.server.int-or-zero(db.optional-int(row, 0)),
                        filename = filename,
                        content-type = kind,
                        width = campfire.server.text-or-empty(db.optional-text(row, 4)),
                        height = campfire.server.text-or-empty(db.optional-text(row, 5)),
                        blob-token = campfire.server.storage-token(storage-key, int.to-string(campfire.server.int-or-zero(db.optional-int(row, 1))), "blob_id"),
                        preview-token = if variation == "" { "" } else { campfire.server.storage-token(storage-key, variation, "variation") }))
                }
                result.ok<List<MessageAttachment>, DbError>(attachments)
            }
        }
    }
}

'''.replace("@Q@", q)
s = s.replace(anchor, block + anchor)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

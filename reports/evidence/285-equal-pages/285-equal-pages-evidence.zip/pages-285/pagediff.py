"""Diff room pages against Rails with its CSRF elements removed (as Flow and Rust omit them).
usage: pagediff.py <dir with flow.html rust.html rails.html> [max blocks]"""
import difflib, re, sys
from collections import Counter
from pathlib import Path

D = Path(sys.argv[1])
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 12


def rails_without_csrf(text):
    text = re.sub(r'    <meta name="csrf-param" content="authenticity_token" />\n<meta name="csrf-token" content="[^"]*" />\n    \n', "", text)
    return re.sub(r'<input type="hidden" name="authenticity_token" value="[^"]*" />', "", text)


def load(name):
    return (D / f"{name}.html").read_text(encoding="utf-8")


rails = rails_without_csrf(load("rails"))
(D / "rails-nocsrf.html").write_text(rails, encoding="utf-8", newline="")
for name in ("flow", "rust"):
    mine = load(name)
    print(f"== {name}: {len(mine.encode())} bytes vs rails-nocsrf {len(rails.encode())}; identical={mine == rails}")
    a, b = mine.splitlines(), rails.splitlines()
    ops = [o for o in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes() if o[0] != "equal"]
    kinds = Counter()
    for tag, i1, i2, j1, j2 in ops:
        sample = " ".join(b[j1:j2] or a[i1:i2])
        key = re.sub(r"\d+", "N", re.sub(r'"[^"]{0,80}"', '""', sample.strip()))[:70]
        kinds[key] += 1
    print(f"   {len(ops)} differing blocks; most common shapes:")
    for k, n in kinds.most_common(limit):
        print(f"   {n:4d}  {k}")

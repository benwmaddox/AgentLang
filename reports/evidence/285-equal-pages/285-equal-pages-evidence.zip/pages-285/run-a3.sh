PAGE_ROOM=486777696/@933434570 FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server bash page-lifetime.sh flow pg-flow-a3 on 16 > /dev/null 2>&1; echo flow=$?
cp /home/ben/linuxbench/private/pg-flow-a3/body1.html private/a1/flow.html; cp private/a1/flow.html private/a1/rust.html; grep -h peak-arena runs/pg-flow-a3/server.log | cut -c1-60

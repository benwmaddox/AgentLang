A=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258/private/native-db-snap-nc/production.sqlite3
B=/mnt/d/code/AgentLang/.agentlang/once-campfire-verification/fixtures/default/db/production.sqlite3
for db in $A $B; do echo "== $db"; sqlite3 -readonly $db "select quote(body) from action_text_rich_texts where record_id=933434601 and record_type='Message';"; sqlite3 -readonly $db "select count(*), sum(length(body)) from action_text_rich_texts;"; done
ls -la $(dirname $B)

export PAGE_ROOM=654632876
FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server bash page-lifetime.sh flow pg-flow-r5 on 16 > /dev/null 2>&1; echo flow=$?
cp /home/ben/linuxbench/private/pg-flow-r5/body1.html private/r654/flow.html
bash check.sh m6

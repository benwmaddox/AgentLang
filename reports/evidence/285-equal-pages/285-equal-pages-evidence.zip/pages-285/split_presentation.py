from pathlib import Path
R = Path(r"D:\code\AgentLang")
C = R / "applications" / "campfire"
p = C / "presentation.flow"
s = p.read_text(encoding="utf-8")
start = s.index("fn campfire.views.rich-text-layout(content: Html) -> Html {")
end = s.index("fn campfire.presentation.body(stored: Option<String>) -> Html {", start)
block = s[start:end]
s = s[:start] + s[end:]
t_start = s.index("test campfire.views.rich-text-layout/wraps {")
t_end = s.index("\n}\n", t_start) + 3
test = s[t_start:t_end]
s = s[:t_start] + s[t_end:]
p.write_text(s.rstrip() + "\n", encoding="utf-8", newline="")
m = (C / "message.flow").read_text(encoding="utf-8")
marker = "fn campfire.views.rails-message-presented("
m = m.replace(marker, block + marker, 1)
(C / "message.flow").write_text(m, encoding="utf-8", newline="")
v = (C / "views-tests.flow").read_text(encoding="utf-8")
(C / "views-tests.flow").write_text(v.rstrip() + "\n\n" + test.replace("Html.value(", "campfire.views.text("), encoding="utf-8", newline="")
for rel in ("tests/AgentLang.CampfireViews.Tests/Program.fs", "applications/campfire/Http/Application.fs"):
    q = R / rel
    t = q.read_text(encoding="utf-8")
    a = '"sounds.flow"; "presentation.flow"; "message.flow";'
    assert t.count(a) == 1, rel
    q.write_text(t.replace(a, '"sounds.flow"; "message.flow";'), encoding="utf-8", newline="")
print("ok")

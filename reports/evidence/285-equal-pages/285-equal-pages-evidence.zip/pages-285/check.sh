# usage: check.sh <tag> : one flow lifetime (store on) with the campfire-285 binary, then copy its page.
export FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server
bash /mnt/d/code/AgentLang/.agentlang/linux-sweep-284/sweep-lifetime.sh flow "p285-$1" on 16 > /dev/null 2>&1; echo "exit=$?"
grep -o 'decoded_bytes=[0-9]* body_constant=[a-z]*' /mnt/d/code/AgentLang/.agentlang/linux-sweep-284/runs/p285-$1/driver.log
grep -o '"invalid":[0-9]*' /mnt/d/code/AgentLang/.agentlang/linux-sweep-284/runs/p285-$1/cells.jsonl
cp /home/ben/linuxbench/private/p285-$1/body1.html /mnt/d/code/AgentLang/.agentlang/pages-285/private/flow.html

from pathlib import Path
R = Path(r"D:\code\AgentLang")
C = R / "applications" / "campfire"

p = C / "server" / "server.flow"
s = p.read_text(encoding="utf-8")
start = s.index("fn campfire.server.presentation(message: MessageWithCreator) -> Html {")
end = s.index("test campfire.server.presentation/canonical-or-escaped {", start)
body = s[start:end]
s = s[:start] + '''fn campfire.server.presentation(message: MessageWithCreator) -> Html {
    doc "campfire.presentation.body of the message's stored body."
    campfire.presentation.body(message.body)
}

''' + s[end:]
p.write_text(s, encoding="utf-8", newline="")

# The logic moves, renamed, into a shared file with no server or host dependencies.
logic = body.replace("fn campfire.server.presentation(message: MessageWithCreator) -> Html {", "fn campfire.presentation.body(stored: Option<String>) -> Html {")
logic = logic.replace("    match message.body {", "    match stored {")
logic = logic.replace('''    doc "The message body as Rails' message_presentation shows it''', '''    doc "A stored message body as Rails' message_presentation shows it''')
(C / "presentation.flow").write_text('''// Message presentation (MessagesHelper#message_presentation) from a stored Action Text body,
// matched to Rails' output (docs/EQUAL-PAGES-PLAN.md). Pure: no database, no host operations,
// so the Rails oracle corpus can test it directly.

''' + logic.rstrip() + '''

test campfire.presentation.body/kinds {
    expect campfire.views.text(campfire.presentation.body(option.some<String>("<p>hi</p>"))) == "<div class=\\"lexxy-content\\">\\n  <p>hi</p>\\n</div>\\n"
    expect campfire.views.text(campfire.presentation.body(option.none<String>())) == "<div class=\\"lexxy-content\\">\\n  \\n</div>\\n"
    expect string.starts-with(campfire.views.text(campfire.presentation.body(option.some<String>("/play bell"))), "<div class=\\"sound\\"")
}
''', encoding="utf-8", newline="")

for rel, a, b in [
    ("scripts/Build-CampfireFlowServer.ps1", "'emoji.flow', 'sounds.flow', 'message.flow',", "'emoji.flow', 'sounds.flow', 'message.flow', 'presentation.flow',"),
]:
    q = R / rel
    t = q.read_text(encoding="utf-8")
    assert t.count(a) == 1, rel
    q.write_text(t.replace(a, b), encoding="utf-8", newline="")
print("ok")

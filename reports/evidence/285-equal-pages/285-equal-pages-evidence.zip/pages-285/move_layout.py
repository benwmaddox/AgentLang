from pathlib import Path
R = Path(r"D:\code\AgentLang")
C = R / "applications" / "campfire"
m = (C / "message.flow").read_text(encoding="utf-8")
block_start = m.index("fn campfire.views.rich-text-layout(content: Html) -> Html {")
block_end = m.index("fn campfire.views.rails-message-presented(", block_start)
block = m[block_start:block_end]
(C / "message.flow").write_text(m[:block_start] + m[block_end:], encoding="utf-8", newline="")
p = C / "presentation.flow"
s = p.read_text(encoding="utf-8")
marker = "fn campfire.presentation.body(stored: Option<String>) -> Html {"
s = s.replace(marker, block + marker, 1)
s = s.replace('campfire.views.text(campfire.presentation.body(', 'Html.value(campfire.presentation.body(')
p.write_text(s, encoding="utf-8", newline="")
v = (C / "views-tests.flow").read_text(encoding="utf-8")
a = '''
test campfire.views.rich-text-layout/wraps {
    expect campfire.views.text(campfire.views.rich-text-layout(html"<p>x</p>")) == "<div class=\\"lexxy-content\\">\\n  <p>x</p>\\n</div>\\n"
}
'''
assert a in v
(C / "views-tests.flow").write_text(v.replace(a, ""), encoding="utf-8", newline="")
s = p.read_text(encoding="utf-8")
s += '''
test campfire.views.rich-text-layout/wraps {
    expect Html.value(campfire.views.rich-text-layout(html"<p>x</p>")) == "<div class=\\"lexxy-content\\">\\n  <p>x</p>\\n</div>\\n"
}
'''
p.write_text(s, encoding="utf-8", newline="")
for rel, a, b in [
    ("tests/AgentLang.CampfireViews.Tests/Program.fs", '"emoji.flow"; "sounds.flow"; "message.flow";', '"emoji.flow"; "sounds.flow"; "presentation.flow"; "message.flow";'),
    ("applications/campfire/Http/Application.fs", '"emoji.flow"; "sounds.flow"; "message.flow";', '"emoji.flow"; "sounds.flow"; "presentation.flow"; "message.flow";'),
]:
    q = R / rel
    t = q.read_text(encoding="utf-8")
    assert t.count(a) == 1, rel
    q.write_text(t.replace(a, b), encoding="utf-8", newline="")
print("ok")

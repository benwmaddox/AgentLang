from pathlib import Path
p = Path(r"D:\code\AgentLang\docs\EQUAL-PAGES-PLAN.md")
s = p.read_text(encoding="utf-8")
a = "- Rich text is sanitized **inbound**, in Flow code, while mimicking Rails'\n  output: the stored presentation must equal what Rails renders."
assert a in s
s = s.replace(a, """- Rich text: **for now, match Rails' output with Flow-only code**, sanitizing
  at render time, which with the worker store means once per cache miss. **The
  long-term goal is inbound sanitization** (sanitize once on write, store the
  safe HTML); that is described below as the next step, not this milestone.
- An HTML5 parser in Flow, stripped down to what is known to be OK: the
  allowlisted tags and attributes. Anything else is dropped or refused, never
  recovered. Message content never carries JavaScript.""")
a = "## Inbound rich text (Flow)"
assert a in s
s = s.replace(a, """## What message content may contain (the allowlist Rails applies, mirrored)

- **Tags:**
  - `a abbr acronym address b big blockquote br cite code dd del dfn div dl dt
    em h1-h6 hr i img ins kbd li mark ol p pre samp small span strong sub sup
    time tt ul var`;
  - plus the editor's `s u mark table thead tbody tfoot tr th td`;
  - plus Action Text attachments.
- **Attributes:** `abbr alt cite class datetime height href lang src title width
  xml:lang data-language`, plus attachment attributes. No `name`, no `on*`.
- **URIs** (`href`, `src`, and the other URI attributes): allowed protocols
  only. `javascript:` is removed; `data:` is allowed only for
  `image/gif|jpeg|png`, `text/plain` and `text/css`.
- **`style`:** only Lexxy's highlight `color` / `background-color` with plain
  values; every other declaration is dropped.

## Rich text now: render-time match in Flow (this milestone)""")
a = "- **Storage:** a Flow-owned table"
assert a in s
s = s.replace(a, """- **Now:** the parser and pipeline run on the render path inside the
  message partial, only on worker-store misses. Its output is part of the
  stored fragment.
- **Later (long-term, inbound):** the same pipeline runs on write and in a
  one-time migration instead, and rendering copies the stored HTML. Storage:
  a Flow-owned table""")
a = "- **When it runs:**"
assert a in s
s = s.replace(a, "- **When the inbound version runs:**")
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
import shutil
R = Path(r"D:\code\AgentLang")
C = R / "applications" / "campfire"


def rw(rel, pairs):
    p = R / rel
    s = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:70], s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8", newline="")


shutil.copyfile(R / ".agentlang/pages-285/private/sounds.flow", C / "sounds.flow")

rw("applications/campfire/message.flow", [
    ('''    doc "campfire.views.rails-message-presented with the body escaped as text."
    let body = match message.body {
        none => Html.new("")
        some text => Html.new(text)
    }
    campfire.views.rails-message-presented(context, message, boost-views, body)''',
     '''    doc "campfire.views.rails-message-presented with the body escaped as text inside the Action Text layout."
    let body = match message.body {
        none => Html.new("")
        some text => Html.new(text)
    }
    campfire.views.rails-message-presented(context, message, boost-views, campfire.views.rich-text-layout(body))'''),
    ('''fn campfire.views.rails-message-presented(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html) -> Html {
    effects none
    doc "body is the message's presentation (what Rails' message_presentation puts inside the lexxy-content layout). ''',
     '''fn campfire.views.rich-text-layout(content: Html) -> Html {
    effects none
    doc "Action Text's layout around rendered rich text (layouts/action_text/contents/_content), as message_presentation returns it for a text message."
    html"<div class=\\"lexxy-content\\">\\n  {content}\\n</div>\\n"
}

fn campfire.views.rails-message-presented(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html) -> Html {
    effects none
    doc "body is the message's whole presentation, as Rails' message_presentation returns it (the rich-text layout for a text message, the sound markup for a sound). '''),
    ('''          <div id="presentation_message_{message.client-message-id}" dir="auto" data-reply-target="body" data-messages-target="body">
  <div class="lexxy-content">
  {body}
</div>

</div>''', '''          <div id="presentation_message_{message.client-message-id}" dir="auto" data-reply-target="body" data-messages-target="body">
  {body}
</div>'''),
])

rw("applications/campfire/server/server.flow", [
    ('''    match message.body {
        none => Html.new("")
        some text => if rich-html.canonical?(text) { html.raw(text) } else { Html.new(text) }
    }
}''', '''    match message.body {
        none => campfire.views.rich-text-layout(Html.new(""))
        some text => {
            // Message#content_type: a canonical body without markup whose text is '/play <name>' is a sound.
            let sound = if rich-html.canonical?(text) && bool.not(string.contains(text, "<")) && bool.not(string.contains(text, "&")) { campfire.sounds.command(text) } else { option.none<Sound>() }
            match sound {
                some found => campfire.views.sound(found)
                none => campfire.views.rich-text-layout(if rich-html.canonical?(text) { html.raw(text) } else { Html.new(text) })
            }
        }
    }
}'''),
    ('''    expect campfire.views.text(campfire.server.presentation(message)) == "<p>hi</p>"''',
     '''    expect campfire.views.text(campfire.server.presentation(message)) == "<div class=\\"lexxy-content\\">\\n  <p>hi</p>\\n</div>\\n"'''),
    ('''    expect campfire.views.text(campfire.server.presentation(unsafe)) == "&lt;script&gt;x&lt;/script&gt;"''',
     '''    expect campfire.views.text(campfire.server.presentation(unsafe)) == "<div class=\\"lexxy-content\\">\\n  &lt;script&gt;x&lt;/script&gt;\\n</div>\\n"
    let bell = messageWithCreator.new(id = MessageId.new(5), room-id = RoomId.new(1), creator-id = UserId.new(1), created-at-ms = 0, updated-at-ms = 0, client-message-id = "c5", created-at = "", creator-name = "", creator-bio = "", creator-updated-at = "", creator-avatar-token = "", body = option.some<String>("/play bell"))
    expect string.starts-with(campfire.views.text(campfire.server.presentation(bell)), "<div class=\\"sound\\"")'''),
])

rw("applications/campfire/views-tests.flow", [
    ('''html"<p>x</p>")), "<div class=\\"lexxy-content\\">\\n  <p>x</p>\\n</div>")''',
     '''campfire.views.rich-text-layout(html"<p>x</p>"))), "<div class=\\"lexxy-content\\">\\n  <p>x</p>\\n</div>\\n\\n</div>")'''),
])
s = (C / "views-tests.flow").read_text(encoding="utf-8")
s += '''
test campfire.views.rich-text-layout/wraps {
    expect campfire.views.text(campfire.views.rich-text-layout(html"<p>x</p>")) == "<div class=\\"lexxy-content\\">\\n  <p>x</p>\\n</div>\\n"
}
'''
(C / "views-tests.flow").write_text(s, encoding="utf-8", newline="")

# sounds.flow joins the shared views wherever message.flow loads.
rw("scripts/Build-CampfireFlowServer.ps1", [("'emoji.flow', 'message.flow',", "'emoji.flow', 'sounds.flow', 'message.flow',")])
rw("tests/AgentLang.CampfireViews.Tests/Program.fs", [('"emoji.flow"; "message.flow";', '"emoji.flow"; "sounds.flow"; "message.flow";')])
rw("applications/campfire/Http/Application.fs", [('"emoji.flow"; "message.flow";', '"emoji.flow"; "sounds.flow"; "message.flow";')])
print("ok")

from pathlib import Path
p = Path(r"D:\code\AgentLang\src\stdlib\rich-html.flow")
s = p.read_text(encoding="utf-8")
a = '''                match rich-html.link-url(match string.slice(run, at, end - at) { none => ""; some s => s }, bool.not(www)) {
                    none => {
                        refused = true
                    }
                    some linked => {
                        out = string.join([out, match string.slice(run, copied, at - copied) { none => ""; some s => s }, linked])
                        copied = end
                        at = end
                    }
                }'''
b = '''                let linked = rich-html.link-url(match string.slice(run, at, end - at) { none => ""; some s => s }, bool.not(www))
                if linked == option.none<String>() {
                    refused = true
                } else {
                    out = string.join([out, match string.slice(run, copied, at - copied) { none => ""; some s => s }, match linked { none => ""; some text => text }])
                    copied = end
                    at = end
                }'''
assert s.count(a) == 1, "run"
s = s.replace(a, b)
a = '''                match rich-html.link-text-run(run) {
                    none => {
                        refused = true
                    }
                    some linked => {
                        out = string.concat(out, linked)
                    }
                }'''
b = '''                let linked = rich-html.link-text-run(run)
                if linked == option.none<String>() {
                    refused = true
                } else {
                    out = string.concat(out, match linked { none => ""; some text => text })
                }'''
assert s.count(a) == 1, "link"
s = s.replace(a, b)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

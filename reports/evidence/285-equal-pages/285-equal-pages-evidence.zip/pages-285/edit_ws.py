from pathlib import Path
C = Path(r"D:\code\AgentLang\applications\campfire")


def rw(rel, pairs):
    p = C / rel
    s = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:60], s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8", newline="")


rw("message.flow", [
    ('    html"""<div id="message_{message.client-message-id}"', '    html"""  <div id="message_{message.client-message-id}"'),
    ('    </turbo-frame>\n</div>\n  """\n}', '    </turbo-frame>\n</div>\n"""\n}'),
])
rw("layout.flow", [
    ('data-refresh-room-url-value="{chrome.base-url}/rooms/{chrome.room-id}/refresh">{messages}</div>',
     'data-refresh-room-url-value="{chrome.base-url}/rooms/{chrome.room-id}/refresh">\n    \n    \n{messages}</div>'),
])
rw("server/server.flow", [
    ('"views/messages/_message:flow-2"', '"views/messages/_message:flow-3"'),
    ('== "views/messages/_message:flow-2/messages/3-1772465460123/presentation-v3"', '== "views/messages/_message:flow-3/messages/3-1772465460123/presentation-v3"'),
    ('expect campfire.server.fragment-key(3, 9) == "views/messages/_message:flow-2/messages/3-9/presentation-v3"', 'expect campfire.server.fragment-key(3, 9) == "views/messages/_message:flow-3/messages/3-9/presentation-v3"'),
    ('''        some at => match string.index-of(empty, "\\">", at) {
            none => -1
            some end => end + 2
        }''', '''        some at => match string.index-of(empty, "\\">", at) {
            none => -1
            some end => campfire.server.skip-whitespace(empty, end + 2)
        }'''),
    ('''fn campfire.server.page-frame(chrome: PageChrome) -> PageFrame {
    doc "campfire.views.page with no messages, split where the messages go: just after the opening tag of the messages container (the first '\\">' after its data-messages-target attribute; attribute values are escaped, so page text cannot end it early). head ++ messages ++ tail is the page. The layout stays one compile-time-checked template."''',
     '''fn campfire.server.skip-whitespace(text: String, from: Int) -> Int {
    doc "The first index at or after from that is not a space, tab, CR or LF."
    var at = from
    for index in from..string.byte-length(text) {
        let byte = string.byte-at-or(text, index, 0)
        if byte != 32 && byte != 9 && byte != 10 && byte != 13 {
            break
        }
        at = index + 1
    }
    at
}

test campfire.server.skip-whitespace/stops {
    expect campfire.server.skip-whitespace("a\\n  b", 1) == 4
    expect campfire.server.skip-whitespace("ab", 2) == 2
}

fn campfire.server.page-frame(chrome: PageChrome) -> PageFrame {
    doc "campfire.views.page with no messages, split where the messages go: after the opening tag of the messages container (the first '\\">' after its data-messages-target attribute; attribute values are escaped, so page text cannot end it early) and the whitespace the layout puts before the messages. head ++ messages ++ tail is the page. The layout stays one compile-time-checked template."'''),
    ('    expect string.ends-with(frame.head, "/rooms/1/refresh\\">")', '    expect string.ends-with(frame.head, "/rooms/1/refresh\\">\\n    \\n    \\n")'),
])
print("ok")

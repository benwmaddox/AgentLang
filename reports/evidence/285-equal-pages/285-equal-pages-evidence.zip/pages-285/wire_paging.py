from pathlib import Path
A = Path(r"D:\code\AgentLang\applications\campfire\server")
P = Path(r"D:\code\AgentLang\.agentlang\pages-285")


def edit(path, pairs):
    s = path.read_text(encoding="utf-8")
    for a, b, *n in pairs:
        count = n[0] if n else 1
        assert s.count(a) == count, (path.name, s.count(a), a[:100])
        s = s.replace(a, b)
    path.write_text(s, encoding="utf-8", newline="")


helpers = (P / "paging.txt").read_text(encoding="utf-8") + (P / "paging-handler.txt").read_text(encoding="utf-8")

edit(A / "server-request.flow", [
    ("    around: Option<Int>\n}",
     "    around: Option<Int>\n    // GET/HEAD /rooms/<id>/messages (messages#index) and its before/after parameters.\n    paging: Bool\n    before: Option<String>\n    after: Option<String>\n}"),
    ("record RoomPath {\n    room: String\n    around: Option<String>\n}", "record RoomPath {\n    room: String\n    around: Option<String>\n    paging: Bool\n}"),
    ('some room => option.some<RoomPath>(roomPath.new(room = room, around = option.none<String>()))',
     'some room => option.some<RoomPath>(roomPath.new(room = room, around = option.none<String>(), paging = false))'),
    ('''            if room == "" || message == "" || string.contains(room, "/") || string.contains(message, "/") || string.contains(message, ".") {
                option.none<RoomPath>()
            } else {
                option.some<RoomPath>(roomPath.new(room = room, around = option.some<String>(message)))
            }''',
     '''            let paging-room = if string.ends-with(rest, "/messages") { campfire.server.cut(rest, 0, string.byte-length(rest) - 9) } else { "" }
            if paging-room != "" && bool.not(string.contains(paging-room, "/")) {
                option.some<RoomPath>(roomPath.new(room = paging-room, around = option.none<String>(), paging = true))
            } else if room == "" || message == "" || string.contains(room, "/") || string.contains(message, "/") || string.contains(message, ".") {
                option.none<RoomPath>()
            } else {
                option.some<RoomPath>(roomPath.new(room = room, around = option.some<String>(message), paging = false))
            }'''),
    ('expect campfire.server.room-path("/rooms/1") == option.some<RoomPath>(roomPath.new(room = "1", around = option.none<String>()))',
     'expect campfire.server.room-path("/rooms/1") == option.some<RoomPath>(roomPath.new(room = "1", around = option.none<String>(), paging = false))'),
    ('expect campfire.server.room-path("/rooms/1/@25") == option.some<RoomPath>(roomPath.new(room = "1", around = option.some<String>("25")))',
     'expect campfire.server.room-path("/rooms/1/@25") == option.some<RoomPath>(roomPath.new(room = "1", around = option.some<String>("25"), paging = false))'),
    ('    expect campfire.server.room-path("/rooms/1/messages") == option.none<RoomPath>()\n',
     '    expect campfire.server.room-path("/rooms/1/messages") == option.some<RoomPath>(roomPath.new(room = "1", around = option.none<String>(), paging = true))\n    expect campfire.server.room-path("/rooms/1/x/messages") == option.none<RoomPath>()\n'),
    ("some room-id => campfire.server.room-request(incoming, context, room-id, is-head, around)",
     "some room-id => campfire.server.room-request(incoming, context, room-id, is-head, around, room-path.paging)"),
    ("fn campfire.server.room-request(incoming: HttpRequest, context: CampfireServerContext, room-id: Int, is-head: Bool, around: Option<Int>) -> Result<ServerRequest, HttpResponse> {",
     "fn campfire.server.room-request(incoming: HttpRequest, context: CampfireServerContext, room-id: Int, is-head: Bool, around: Option<Int>, paging: Bool) -> Result<ServerRequest, HttpResponse> {"),
    ("serverRequest.new(campfire = built, session-cookie = session-cookie, around = around)",
     'serverRequest.new(campfire = built, session-cookie = session-cookie, around = around, paging = paging, before = if paging { campfire.server.query-param(incoming.target, "before") } else { option.none<String>() }, after = if paging { campfire.server.query-param(incoming.target, "after") } else { option.none<String>() })'),
    (", option.none<Int>())", ", option.none<Int>(), false)", 2),
])

s = (A / "server.flow").read_text(encoding="utf-8")
s = s.replace("session-cookie = option.none<String>(), around = option.none<Int>())",
              "session-cookie = option.none<String>(), around = option.none<Int>(), paging = false, before = option.none<String>(), after = option.none<String>())")
a = "        ok built => campfire.server.http-response(campfire.server.room-read(built.campfire, context, built.around), built, request.target, context)"
assert s.count(a) == 1
s = s.replace(a, "        ok built => if built.paging { campfire.server.messages-read(built, request, context) } else { campfire.server.http-response(campfire.server.room-read(built.campfire, context, built.around), built, request.target, context) }")
a = "fn campfire.server.handle(request: HttpRequest, context: CampfireServerContext) -> HttpResponse {"
s = s.replace(a, helpers.lstrip("\n") + "\n" + a)
(A / "server.flow").write_text(s, encoding="utf-8", newline="")
print("ok")

import re
from pathlib import Path
A = Path(r"D:\code\AgentLang\applications\campfire\server")

# ---- server-db.flow: the around keys query
p = A / "server-db.flow"
s = p.read_text(encoding="utf-8")
anchor = "fn campfire.server.page-keys-query(room-id: RoomId) -> Result<List<PageKey>, DbError> {"
assert s.count(anchor) == 1
around = Path(r"D:\code\AgentLang\.agentlang\pages-285\around.txt").read_text(encoding="utf-8").lstrip("\n")
s = s.replace(anchor, around + "\n" + anchor)
p.write_text(s, encoding="utf-8", newline="")

t = A / "server-db-tests.flow"
s = t.read_text(encoding="utf-8")
s += '''
test campfire.server.page-keys-around/fixture {
    expect campfire.server.test-fixture() == 0
    let ids = fn-keys-ids
}
'''
# replaced below with a concrete body (no helper functions in tests)
s = s.replace('''    let ids = fn-keys-ids
}
''', '''    let first = match campfire.server.page-keys-around(RoomId.new(1), 1) { error failure => list.empty<PageKey>(); ok keys => keys }
    expect list.count(first) == 2
    expect match list.get(first, 0) { none => 0; some key => key.id } == 1
    expect match list.get(first, 1) { none => 0; some key => key.id } == 2
    let second = match campfire.server.page-keys-around(RoomId.new(1), 2) { error failure => list.empty<PageKey>(); ok keys => keys }
    expect list.count(second) == 2 && match list.get(second, 0) { none => 0; some key => key.id } == 1
    // A message of no room the user reads: the last page, as rooms#show's find_by fallback.
    expect campfire.server.page-keys-around(RoomId.new(1), 99) == campfire.server.page-keys-query(RoomId.new(1))
}
''')
t.write_text(s, encoding="utf-8", newline="")

# ---- server.flow: thread around through the room read
p = A / "server.flow"
s = p.read_text(encoding="utf-8")
def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (s.count(a), a[:100])
    s = s.replace(a, b)

# page-for-member
rep("fn campfire.server.page-for-member(user-id: UserId, room-id: RoomId, context: CampfireServerContext) -> Result<List<MessageWithCreator>, RoomMessageError> {\n    effects db.read, db.write\n    doc \"campfire.messages.page-for-member with the worker's avatar key.\"",
    "fn campfire.server.page-for-member(user-id: UserId, room-id: RoomId, context: CampfireServerContext, around: Option<Int>) -> Result<List<MessageWithCreator>, RoomMessageError> {\n    effects db.read, db.write\n    doc \"campfire.messages.page-for-member with the worker's avatar key: the last page, or the page around a message (campfire.server.page-keys-around).\"")
rep("""                match campfire.server.last-page-with-creators(room-id, context.avatar-key) {
                    ok messages => result.ok<List<MessageWithCreator>, RoomMessageError>(messages)""",
    """                let loaded = match around {
                    none => campfire.server.last-page-with-creators(room-id, context.avatar-key)
                    some message-id => campfire.server.messages-for-keys(campfire.server.page-keys-around(room-id, message-id), context.avatar-key)
                }
                match loaded {
                    ok messages => result.ok<List<MessageWithCreator>, RoomMessageError>(messages)""")
rep("campfire.server.page-for-member(UserId.new(1), RoomId.new(1), context)", "campfire.server.page-for-member(UserId.new(1), RoomId.new(1), context, option.none<Int>())")
rep("campfire.server.page-for-member(UserId.new(2), RoomId.new(1), context)", "campfire.server.page-for-member(UserId.new(2), RoomId.new(1), context, option.none<Int>())")
rep("campfire.server.page-for-member(user.id, room.id, campfire.server.test-context())", "campfire.server.page-for-member(user.id, room.id, campfire.server.test-context(), option.none<Int>())", 2)

# messages-for-keys: the rows of these keys, in key order
rep("fn campfire.server.page-for-member(", '''fn campfire.server.messages-for-keys(keys: Result<List<PageKey>, DbError>, avatar-key: Bytes) -> Result<List<MessageWithCreator>, DbError> {
    effects db.read
    doc "The page rows of these keys, in the keys' order (one query)."
    match keys {
        error failure => result.error<List<MessageWithCreator>, DbError>(failure)
        ok page => {
            var ids = list.empty<Int>()
            for key in page {
                ids = list.append(ids, key.id)
            }
            match campfire.server.messages-by-id(ids, avatar-key) {
                error failure => result.error<List<MessageWithCreator>, DbError>(failure)
                ok loaded => {
                    var ordered = list.empty<MessageWithCreator>()
                    for key in page {
                        for message in loaded {
                            if MessageId.value(message.id) == key.id {
                                ordered = list.append(ordered, message)
                            }
                        }
                    }
                    result.ok<List<MessageWithCreator>, DbError>(ordered)
                }
            }
        }
    }
}

test campfire.server.messages-for-keys/order {
    expect campfire.server.test-fixture() == 0
    let keys = result.ok<List<PageKey>, DbError>([pageKey.new(id = 2, updated-at-ms = 0), pageKey.new(id = 1, updated-at-ms = 0)])
    let loaded = match campfire.server.messages-for-keys(keys, bytes.from-utf8("k")) { error failure => list.empty<MessageWithCreator>(); ok rows => rows }
    expect list.count(loaded) == 2 && match list.get(loaded, 0) { none => 0; some message => MessageId.value(message.id) } == 2
}

fn campfire.server.page-for-member(''')

# streamed-page-for-member
rep("fn campfire.server.streamed-page-for-member(user-id: UserId, chrome: PageChrome, room-id: RoomId, cache: WorkerCache, context: CampfireServerContext) -> Result<Int, RoomMessageError> {",
    "fn campfire.server.streamed-page-for-member(user-id: UserId, chrome: PageChrome, room-id: RoomId, cache: WorkerCache, context: CampfireServerContext, around: Option<Int>) -> Result<Int, RoomMessageError> {")
rep("                        let written = match campfire.server.page-keys-query(room-id) {",
    "                        let keys = match around { none => campfire.server.page-keys-query(room-id); some message-id => campfire.server.page-keys-around(room-id, message-id) }\n                        let written = match keys {")
rep("cache, campfire.server.test-context()) == result.ok<Int, RoomMessageError>(2)", "cache, campfire.server.test-context(), option.none<Int>()) == result.ok<Int, RoomMessageError>(2)")
rep("cache, campfire.server.test-context()) == result.error<Int, RoomMessageError>(", "cache, campfire.server.test-context(), option.none<Int>()) == result.error<Int, RoomMessageError>(")

# show-room
rep("fn campfire.server.show-room(request: CampfireHttpRequest, user: AuthUser, room: RoomRow, refresh: Option<SessionToken>, context: CampfireServerContext) -> CampfireHttpResponse {",
    "fn campfire.server.show-room(request: CampfireHttpRequest, user: AuthUser, room: RoomRow, refresh: Option<SessionToken>, context: CampfireServerContext, around: Option<Int>) -> CampfireHttpResponse {")
rep("room.id, cache, context) {\n            error failure => campfire.server.response(500",
    "room.id, cache, context, around) {\n            error failure => campfire.server.response(500")
rep("        match campfire.server.page-for-member(user.id, room.id, context) {\n            error failure => campfire.server.response(500",
    "        match campfire.server.page-for-member(user.id, room.id, context, around) {\n            error failure => campfire.server.response(500")
s = s.replace("option.none<SessionToken>(), campfire.server.test-context())", "option.none<SessionToken>(), campfire.server.test-context(), option.none<Int>())")

# room-read-route and room-read
rep("fn campfire.server.room-read-route(request: CampfireHttpRequest, user: AuthUser, refresh: Option<SessionToken>, context: CampfireServerContext) -> CampfireHttpResponse {",
    "fn campfire.server.room-read-route(request: CampfireHttpRequest, user: AuthUser, refresh: Option<SessionToken>, context: CampfireServerContext, around: Option<Int>) -> CampfireHttpResponse {")
rep("some room => campfire.server.show-room(request, user, room, refresh, context)", "some room => campfire.server.show-room(request, user, room, refresh, context, around)")
rep("fn campfire.server.room-read(request: CampfireHttpRequest, context: CampfireServerContext) -> CampfireHttpResponse {",
    "fn campfire.server.room-read(request: CampfireHttpRequest, context: CampfireServerContext, around: Option<Int>) -> CampfireHttpResponse {")
rep("ok user => campfire.server.room-read-route(request, user, refresh, context)", "ok user => campfire.server.room-read-route(request, user, refresh, context, around)")
s = re.sub(r"(campfire\.server\.room-read(?:-route)?\(campfire\.server\.test-request\([^\n]*?), campfire\.server\.test-context\(\)\)",
           r"\1, campfire.server.test-context(), option.none<Int>())", s)
rep("campfire.server.room-read(built.campfire, context)", "campfire.server.room-read(built.campfire, context, built.around)")
p.write_text(s, encoding="utf-8", newline="")

# ---- server-request.flow: the @message path
p = A / "server-request.flow"
s = p.read_text(encoding="utf-8")
rep("    session-cookie: Option<String>\n}", "    session-cookie: Option<String>\n    // The message id of /rooms/<id>/@<message> (rooms#show's message_id), as ActiveRecord casts it.\n    around: Option<Int>\n}")
rep("fn campfire.server.room-id-text(path: String) -> Option<String> {", '''record RoomPath {
    room: String
    around: Option<String>
}

fn campfire.server.room-path(path: String) -> Option<RoomPath> {
    doc "/rooms/<id> (campfire.server.room-id-text), or /rooms/<id>/@<message> (the at_message route: a segment of no '/' or '.')."
    match campfire.server.room-id-text(path) {
        some room => option.some<RoomPath>(roomPath.new(room = room, around = option.none<String>()))
        none => {
            let length = string.byte-length(path)
            let rest = if length > 7 && campfire.server.equal-ignoring-case?(campfire.server.cut(path, 0, 7), "/rooms/") { campfire.server.cut(path, 7, length - 7) } else { "" }
            let slash = match string.index-of(rest, "/@", 0) { none => -1; some at => at }
            let room = if slash > 0 { campfire.server.cut(rest, 0, slash) } else { "" }
            let message = if slash > 0 { campfire.server.cut(rest, slash + 2, string.byte-length(rest) - slash - 2) } else { "" }
            if room == "" || message == "" || string.contains(room, "/") || string.contains(message, "/") || string.contains(message, ".") {
                option.none<RoomPath>()
            } else {
                option.some<RoomPath>(roomPath.new(room = room, around = option.some<String>(message)))
            }
        }
    }
}

test campfire.server.room-path/forms {
    expect campfire.server.room-path("/rooms/1") == option.some<RoomPath>(roomPath.new(room = "1", around = option.none<String>()))
    expect campfire.server.room-path("/rooms/1/@25") == option.some<RoomPath>(roomPath.new(room = "1", around = option.some<String>("25")))
    expect campfire.server.room-path("/rooms/1/@") == option.none<RoomPath>()
    expect campfire.server.room-path("/rooms/1/@2.json") == option.none<RoomPath>()
    expect campfire.server.room-path("/rooms/1/messages") == option.none<RoomPath>()
}

fn campfire.server.ruby-to-i(text: String) -> Int {
    doc "String#to_i, as ActiveModel's Integer type casts a parameter: leading whitespace, an optional sign, then digits (underscores between digits allowed); 0 when none."
    var at = 0
    let length = string.byte-length(text)
    for step in 0..length {
        let byte = string.byte-at-or(text, at, 0)
        if byte != 32 && (byte < 9 || byte > 13) {
            break
        }
        at = at + 1
    }
    let sign = string.byte-at-or(text, at, 0)
    let negative = sign == 45
    if sign == 45 || sign == 43 {
        at = at + 1
    }
    var value = 0
    var digits = 0
    var done = false
    for index in at..length {
        let byte = string.byte-at-or(text, index, 0)
        let underscore = byte == 95 && digits > 0 && string.byte-at-or(text, index + 1, 0) >= 48 && string.byte-at-or(text, index + 1, 0) <= 57
        if done || bool.not((byte >= 48 && byte <= 57) || underscore) || digits >= 18 {
            break
        }
        if bool.not(underscore) {
            value = value * 10 + byte - 48
            digits = digits + 1
        }
    }
    if negative { 0 - value } else { value }
}

test campfire.server.ruby-to-i/forms {
    expect campfire.server.ruby-to-i("25") == 25 && campfire.server.ruby-to-i("12abc") == 12 && campfire.server.ruby-to-i("abc") == 0
    expect campfire.server.ruby-to-i(" -1_0") == -10
}

fn campfire.server.room-id-text(path: String) -> Option<String> {''')
rep("    match campfire.server.room-id-text(path) {\n        none => result.error<ServerRequest, HttpResponse>(campfire.server.status(404))\n        some id-text => {",
    "    match campfire.server.room-path(path) {\n        none => result.error<ServerRequest, HttpResponse>(campfire.server.status(404))\n        some room-path => {\n            let id-text = room-path.room\n            let around = match room-path.around { none => option.none<Int>(); some text => option.some<Int>(campfire.server.ruby-to-i(text)) }")
rep("some room-id => campfire.server.room-request(incoming, context, room-id, is-head)", "some room-id => campfire.server.room-request(incoming, context, room-id, is-head, around)")
rep("fn campfire.server.room-request(incoming: HttpRequest, context: CampfireServerContext, room-id: Int, is-head: Bool) -> Result<ServerRequest, HttpResponse> {",
    "fn campfire.server.room-request(incoming: HttpRequest, context: CampfireServerContext, room-id: Int, is-head: Bool, around: Option<Int>) -> Result<ServerRequest, HttpResponse> {")
rep("serverRequest.new(campfire = built, session-cookie = session-cookie)", "serverRequest.new(campfire = built, session-cookie = session-cookie, around = around)")
s = re.sub(r"campfire\.server\.room-request\(incoming, context, (\d+), (true|false)\)", r"campfire.server.room-request(incoming, context, \1, \2, option.none<Int>())", s)
p.write_text(s, encoding="utf-8", newline="")

p = A / "server.flow"
s = p.read_text(encoding="utf-8")
s = s.replace("session-cookie = option.none<String>())", "session-cookie = option.none<String>(), around = option.none<Int>())")
p.write_text(s, encoding="utf-8", newline="")
print("ok")

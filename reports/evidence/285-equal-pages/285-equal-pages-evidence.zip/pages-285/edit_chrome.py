from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:70], s.count(a))
    s = s.replace(a, b)


rep('''    signing-key: Bytes
    avatar-key: Bytes
}''', '''    signing-key: Bytes
    avatar-key: Bytes
    turbo-key: Bytes
}''')
rep('''        avatar-key = campfire.server.rails-key(secret, "active_record/signed_id", 64))''',
    '''        avatar-key = campfire.server.rails-key(secret, "active_record/signed_id", 64),
        turbo-key = campfire.server.rails-key(secret, "turbo/signed_stream_verifier_key", 64))''')

chrome = '''
// ----------------------------------------------------------- page chrome

fn campfire.server.number-stamp(timestamp: String) -> String {
    doc "Rails Time#to_fs(:number) of a stored UTC timestamp: the digits of 'YYYY-MM-DD HH:MM:SS', any fraction dropped."
    let whole = match string.slice(timestamp, 0, 19) { none => timestamp; some text => text }
    string.replace(string.replace(string.replace(whole, "-", ""), ":", ""), " ", "")
}

test campfire.server.number-stamp/drops-fraction {
    expect campfire.server.number-stamp("2026-01-02 16:00:00.123456") == "20260102160000"
    expect campfire.server.number-stamp("2026-01-01 16:00:00") == "20260101160000"
}

fn campfire.server.room-class(room: RoomRow) -> String {
    doc "The room's Rails STI class, as its GlobalID names it."
    match room.kind {
        open => "Rooms::Open"
        closed => "Rooms::Closed"
        direct => "Rooms::Direct"
    }
}

fn campfire.server.signed-stream-name(turbo-key: Bytes, room: RoomRow) -> String {
    doc "turbo_stream_from @room, :messages: Turbo's signed stream name, a Rails MessageVerifier (strict Base64 of the JSON string '<room GlobalID param>:messages', '--', hex HMAC-SHA256 with the turbo/signed_stream_verifier_key key). The GlobalID param is the unpadded URL-safe Base64 of gid://campfire/<class>/<id>."
    let gid = string.join(["gid://campfire/", campfire.server.room-class(room), "/", int.to-string(RoomId.value(room.id))])
    let name = string.concat(base64.url-encode(bytes.from-utf8(gid)), ":messages")
    let encoded = base64.encode(bytes.from-utf8(json.quote(name)))
    string.join([encoded, "--", hex.encode(crypto.hmac-sha256(turbo-key, bytes.from-utf8(encoded)))])
}

test campfire.server.signed-stream-name/shape {
    let room = roomRow.new(id = RoomId.new(486777696), name = option.some<String>("All Talk"), kind = RoomKind.closed(), creator-id = UserId.new(1), created-at = "", updated-at = "")
    let signed = campfire.server.signed-stream-name(bytes.from-utf8("k"), room)
    expect string.starts-with(signed, "IloybGtPaTh2WTJGdGNHWnBjbVV2VW05dmJYTTZPa05zYjNObFpDODBPRFkzTnpjMk9UWTptZXNzYWdlcyI=--")
    expect string.byte-length(signed) == 84 + 2 + 64
}

fn campfire.server.chrome-stamps(user-id: UserId) -> List<String> {
    effects db.read
    doc "The user's and the account's updated_at (the avatar and logo versions), empty when missing."
    match db.query("SELECT (SELECT updated_at FROM users WHERE id = $userId), (SELECT updated_at FROM accounts ORDER BY id LIMIT 1)", [db.int-param(UserId.value(user-id))]) {
        error failure => ["", ""]
        ok rows => match db.first-row(rows) {
            none => ["", ""]
            some row => [campfire.server.text-or-empty(db.optional-text(row, 0)), campfire.server.text-or-empty(db.optional-text(row, 1))]
        }
    }
}

fn campfire.server.page-chrome(room: RoomRow, user: AuthUser, base-url: String, context: CampfireServerContext) -> PageChrome {
    effects db.read
    doc "campfire.views.room-chrome with the values the layout needs from the database and the worker keys: the account logo version, the current user's fresh avatar path, the room's signed message stream and its loaded_at (room.updated_at in epoch ms)."
    let base = campfire.views.room-chrome(room, user, base-url)
    let stamps = campfire.server.chrome-stamps(user.id)
    let user-stamp = match list.get(stamps, 0) { none => ""; some text => text }
    let account-stamp = match list.get(stamps, 1) { none => ""; some text => text }
    let avatar = if user-stamp == "" { "" } else { string.join(["/users/", campfire.server.avatar-token(context.avatar-key, UserId.value(user.id)), "/avatar?v=", campfire.server.number-stamp(user-stamp)]) }
    let loaded-at = match campfire.server.parse-timestamp(room.updated-at) { none => ""; some micros => int.to-string(micros / 1000) }
    pageChrome.new(
        room-name = base.room-name,
        room-id = base.room-id,
        room-key = base.room-key,
        room-path = base.room-path,
        user-id = base.user-id,
        user-name = base.user-name,
        body-class = base.body-class,
        base-url = base.base-url,
        account-version = if account-stamp == "" { "" } else { campfire.server.number-stamp(account-stamp) },
        user-avatar-url = avatar,
        stream-name = campfire.server.signed-stream-name(context.turbo-key, room),
        loaded-at = loaded-at)
}

fn campfire.server.show-room('''
rep('''
fn campfire.server.show-room(''', chrome)
rep('''        match campfire.server.streamed-page-for-member(user.id, campfire.views.room-chrome(room, user, request.base-url), room.id, cache, context) {''',
    '''        match campfire.server.streamed-page-for-member(user.id, campfire.server.page-chrome(room, user, request.base-url, context), room.id, cache, context) {''')
rep('''                body = campfire.views.creator-room-page(campfire.views.room-chrome(room, user, request.base-url), messages))''',
    '''                body = campfire.views.creator-room-page(campfire.server.page-chrome(room, user, request.base-url, context), messages))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

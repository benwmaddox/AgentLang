echo 1 > /sys/fs/cgroup/lb273-srv/cgroup.kill 2>/dev/null; sleep 1; rmdir /sys/fs/cgroup/lb273-srv 2>/dev/null; test -e /sys/fs/cgroup/lb273-srv && echo still-there || echo clean

from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\message.flow")
s = p.read_text(encoding="utf-8")
def rep(a, b):
    global s
    assert s.count(a) == 1, a[:80]
    s = s.replace(a, b)
rep('    let span-class = if campfire.emoji.all?(boost.content) { "txt-small txt-medium" } else { "txt-small" }\n',
    '    let span-class = if campfire.emoji.all?(boost.content) { "txt-small txt-medium" } else { "txt-small" }\n    let title = campfire.views.user-title(boost.booster-name, boost.booster-bio)\n')
rep('<a title="{boost.booster-name}" class="btn avatar"', '<a title="{title}" class="btn avatar"')
rep('''    let title = if message.creator-bio == "" {
        message.creator-name
    } else {
        string.concat(string.concat(message.creator-name, " – "), message.creator-bio)
    }
''', '''    let title = campfire.views.user-title(message.creator-name, message.creator-bio)
''')
old_head = 'fn campfire.views.rails-message-presented(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html) -> Html {\n    effects none\n'
i = s.index(old_head)
j = s.index('\n    let id = int.to-string(MessageId.value(message.id))', i)
doc = s[i + len(old_head):j]
rep(old_head + doc, '''fn campfire.views.rails-message-presented(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html) -> Html {
    effects none
    doc "campfire.views.rails-message-shown for a message that is not all emoji and has no attachment (the Reply action)."
    campfire.views.rails-message-shown(context, message, boost-views, body, messageShown.new(emoji = false, actions = campfire.views.reply-actions()))
}

fn campfire.views.rails-message-shown(context: MessageContext, message: MessageWithCreator, boost-views: List<BoostView>, body: Html, shown: MessageShown) -> Html {
    effects none
''' + doc.replace("One message as Rails renders", "shown says whether the message is all emoji (message--emoji) and holds its primary actions (campfire.views.reply-actions or attachment-actions). One message as Rails renders"))
rep('class="message " data-controller="reply"', 'class="message {emoji-class}" data-controller="reply"')
rep('    let boosts = boost-views.map(campfire.views.boost)\n', '    let boosts = boost-views.map(campfire.views.boost)\n    let emoji-class = if shown.emoji { "message--emoji" } else { "" }\n')
rep('''          <button class="btn message__action-btn center full-width" data-action="reply#reply" title="Reply" aria-label="Reply">
            <img class="colorize--black" aria-hidden="true" src="/assets/reply-edb77e33.svg" width="20" height="20" />
</button>
        <button class="btn message__action-btn center full-width" title="Copy link"''', '''{shown.actions}        <button class="btn message__action-btn center full-width" title="Copy link"''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

bash check.sh pre1
bash page-lifetime.sh flow pg-flow-off1 off 16 > /dev/null 2>&1; echo off=$?; cp /home/ben/linuxbench/private/pg-flow-off1/body1.html private/flow-off.html; grep -h "flow_args\|flowbin" runs/pg-flow-off1/cache-env.txt 2>/dev/null | cut -c1-160

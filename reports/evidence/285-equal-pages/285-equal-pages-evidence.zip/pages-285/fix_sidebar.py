from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\sidebar.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (s.count(a), a[:80])
    s = s.replace(a, b)


# Literal ERB HTML: Rails writes '->' raw in these attributes.
s = s.replace("-&gt;", "->")

rep('''fn campfire.views.sidebar-avatar(url: String) -> Html {''', '''fn campfire.views.unterminated(text: Html) -> Html {
    effects none
    doc "A template's text without its final newline (a template's closing quotes sit on their own line)."
    let value = campfire.views.text(text)
    html.raw(if string.ends-with(value, "\\n") { match string.slice(value, 0, string.byte-length(value) - 1) { none => value; some s => s } } else { value })
}

test campfire.views.unterminated/newline {
    expect campfire.views.text(campfire.views.unterminated(html.raw("a\\n"))) == "a" && campfire.views.text(campfire.views.unterminated(html.raw("a"))) == "a"
}

fn campfire.views.sidebar-avatar(url: String) -> Html {''')

rep('''    html"""
  <a class="{class}" id="list_rooms_direct_{id}"''', '''    let link = html"""  <a class="{class}" id="list_rooms_direct_{id}"''')
rep('''          {names}
      </span>
    </span>
</a>"""
}''', '''          {names}
      </span>
    </span>
</a>
"""
    html.raw(string.concat("\\n", campfire.views.text(campfire.views.unterminated(link))))
}''')
rep('''    html"""<form class="button_to"''', '''    let form = html"""<form class="button_to"''')
rep('''</button></form>"""
}''', '''</button></form>
"""
    campfire.views.unterminated(form)
}''')
rep('''    let new-room = if sidebar.can-create-rooms {
        html"""
        <a class="rooms__new-btn''', '''    let new-room = if sidebar.can-create-rooms {
        let link = html"""        <a class="rooms__new-btn''')
rep('''          <img aria-hidden="true" style="view-transition-name: new-room" src="/assets/add-f232d8a6.svg" width="20" height="20" />
</a>"""
    } else {''', '''          <img aria-hidden="true" style="view-transition-name: new-room" src="/assets/add-f232d8a6.svg" width="20" height="20" />
</a>
"""
        html.raw(string.concat("\\n", campfire.views.text(campfire.views.unterminated(link))))
    } else {''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

out = File.open(ARGV.fetch(0), "w")
out.puts "variable=#{ActiveStorage.variable_content_types.inspect}"
out.puts "previewers=#{ActiveStorage.previewers.map(&:name).inspect}"
%w[video/quicktime video/mp4 application/pdf image/bmp image/jpeg image/svg+xml image/heic].each do |type|
  blob = ActiveStorage::Blob.new(content_type: type, filename: "x")
  out.puts "#{type} variable=#{blob.variable?} previewable=#{blob.previewable?} video=#{blob.video?} image=#{blob.image?}"
end
out.puts "thumb=#{Message::THUMBNAIL_MAX_WIDTH}x#{Message::THUMBNAIL_MAX_HEIGHT}"
out.puts "verifier=#{ActiveStorage.verifier.inspect[0, 120]}"
include ActionView::Helpers::AssetUrlHelper rescue nil
out.puts "helper=#{ApplicationController.helpers.method(:broadcast_image_tag).source_location.inspect}"
%w[common-file-text.svg download.svg share.svg].each { |a| out.puts "#{a}=#{ApplicationController.helpers.asset_path(a)}" }
out.close

from pathlib import Path
p = Path(r"D:\code\AgentLang\src\stdlib\rich-html.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:70], s.count(a))
    s = s.replace(a, b)


rep('''fn rich-html.top(stack: List<String>) -> String {
    match list.get(stack, 0) { none => ""; some name => name }
}

test rich-html.top/empty {
    expect rich-html.top(list.empty<String>()) == "" && rich-html.top(["b", "a"]) == "b"
}

fn rich-html.open?(stack: List<String>, name: String) -> Bool {
    doc "True when an element of this name is open."
    var found = false
    for open in stack {
        if open == name {
            found = true
            break
        }
    }
    found
}

test rich-html.open?/inside {
    expect rich-html.open?(["b", "a"], "a") && bool.not(rich-html.open?(["b"], "a"))
}''', '''// The open-element stack is a path of names, outermost first: "/div/p".

fn rich-html.last-slash(stack: String) -> Int {
    doc "The index of the last '/' in the stack path, or -1."
    var found = -1
    for index in 0..string.byte-length(stack) {
        if string.byte-at-or(stack, index, 0) == 47 {
            found = index
        }
    }
    found
}

test rich-html.last-slash/path {
    expect rich-html.last-slash("/div/p") == 4 && rich-html.last-slash("") == -1
}

fn rich-html.top(stack: String) -> String {
    doc "The innermost open element, or empty."
    let at = rich-html.last-slash(stack)
    if at < 0 { "" } else { match string.slice(stack, at + 1, string.byte-length(stack) - at - 1) { none => ""; some name => name } }
}

test rich-html.top/empty {
    expect rich-html.top("") == "" && rich-html.top("/a/b") == "b"
}

fn rich-html.pop(stack: String) -> String {
    doc "The stack without its innermost element."
    let at = rich-html.last-slash(stack)
    if at < 0 { "" } else { match string.slice(stack, 0, at) { none => ""; some rest => rest } }
}

test rich-html.pop/one {
    expect rich-html.pop("/a/b") == "/a" && rich-html.pop("/a") == ""
}

fn rich-html.open?(stack: String, name: String) -> Bool {
    doc "True when an element of this name is open."
    string.contains(string.concat(stack, "/"), string.join(["/", name, "/"]))
}

test rich-html.open?/inside {
    expect rich-html.open?("/a/b", "a") && bool.not(rich-html.open?("/b", "a")) && bool.not(rich-html.open?("/ab", "a"))
}''')
rep('fn rich-html.child-ok?(parent: String, child: String, stack: List<String>) -> Bool {', 'fn rich-html.child-ok?(parent: String, child: String, stack: String) -> Bool {')
rep('''    expect bool.not(rich-html.child-ok?("p", "div", ["p"]))
    expect bool.not(rich-html.child-ok?("strong", "p", ["strong", "p"]))
    expect bool.not(rich-html.child-ok?("span", "a", ["span", "a"]))
    expect rich-html.child-ok?("table", "tbody", ["table"]) && rich-html.child-ok?("tr", "td", ["tr", "tbody", "table"])
    expect bool.not(rich-html.child-ok?("table", "tr", ["table"])) && bool.not(rich-html.child-ok?("div", "td", ["div"]))
    expect rich-html.child-ok?("div", "p", ["div"])''', '''    expect bool.not(rich-html.child-ok?("p", "div", "/p"))
    expect bool.not(rich-html.child-ok?("strong", "p", "/p/strong"))
    expect bool.not(rich-html.child-ok?("span", "a", "/a/span"))
    expect rich-html.child-ok?("table", "tbody", "/table") && rich-html.child-ok?("tr", "td", "/table/tbody/tr")
    expect bool.not(rich-html.child-ok?("table", "tr", "/table")) && bool.not(rich-html.child-ok?("div", "td", "/div"))
    expect rich-html.child-ok?("div", "p", "/div")''')
rep('fn rich-html.text-ok?(stack: List<String>, text: String) -> Bool {', 'fn rich-html.text-ok?(stack: String, text: String) -> Bool {')
rep('''    expect rich-html.text-ok?(["p"], "plain text")
    expect bool.not(rich-html.text-ok?(["p"], "see https://x.y")) && bool.not(rich-html.text-ok?(["p"], "mail a@b.c")) && bool.not(rich-html.text-ok?(["p"], "WWW.example.com"))
    expect rich-html.text-ok?(["tbody"], " ") && bool.not(rich-html.text-ok?(["tbody"], "x"))''', '''    expect rich-html.text-ok?("/p", "plain text")
    expect bool.not(rich-html.text-ok?("/p", "see https://x.y")) && bool.not(rich-html.text-ok?("/p", "mail a@b.c")) && bool.not(rich-html.text-ok?("/p", "WWW.example.com"))
    expect rich-html.text-ok?("/table/tbody", " ") && bool.not(rich-html.text-ok?("/table/tbody", "x"))''')
rep('''    var stack = list.empty<String>()
    var text-start = 0''', '''    var stack = ""
    var text-start = 0''')
rep('''                stack = list.tail(stack)''', '''                stack = rich-html.pop(stack)''')
rep('''                var seen = list.empty<String>()''', '''                var seen = ""''')
rep('''|| rich-html.open?(seen, attr-name) ||''', '''|| rich-html.open?(seen, attr-name) ||''')
rep('''                    seen = list.append(seen, attr-name)''', '''                    seen = string.join([seen, "/", attr-name])''')
rep('''                    stack = list.concat([name], stack)''', '''                    stack = string.join([stack, "/", name])''')
rep('''    ok && list.count(stack) == 0 && rich-html.text-ok?(stack, tail)''', '''    ok && stack == "" && rich-html.text-ok?(stack, tail)''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

out = File.open(ARGV.fetch(0), "w")
out.puts "web=#{ActiveStorage.web_image_content_types.inspect}"
[["a.jpg","image/jpeg"],["a.JPG","image/jpeg"],["a.jpeg","image/jpeg"],["a.png","image/jpeg"],["a","image/jpeg"],["a.png","image/png"],["a.gif","image/gif"],["a.webp","image/webp"],["a.tiff","image/tiff"],["a.heic","image/heic"]].each do |name, type|
  blob = ActiveStorage::Blob.new(content_type: type, filename: name)
  out.puts "#{name} #{type} format=#{blob.send(:default_variant_format).inspect}"
end
out.puts "nil-dims=#{ApplicationController.helpers.image_tag('/x.png', width: nil, height: nil, class: 'c')}"
out.close

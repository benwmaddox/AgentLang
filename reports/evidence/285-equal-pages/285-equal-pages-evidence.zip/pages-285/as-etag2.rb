out = File.open(ARGV.fetch(0), "w")
MessagesController.etaggers.each { |e| loc = e.source_location; out.puts "#{loc.inspect} #{File.readlines(loc[0])[loc[1] - 1].strip[0, 160] rescue '?'}" }
out.close

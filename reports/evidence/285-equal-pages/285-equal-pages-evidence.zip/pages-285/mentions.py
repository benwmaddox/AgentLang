from pathlib import Path
R = Path(r"D:\code\AgentLang")
p = R / "applications/campfire/presentation.flow"
s = p.read_text(encoding="utf-8")

mentions = '''
// ------------------------------------------------------------- mentions
//
// An <action-text-attachment> whose SGID names a user renders as a mention
// (Campfire's possibly-expired path reads the GlobalID out of the SGID without
// checking its signature: the `data` field, or the GID matched out of an older
// Marshal-dumped `message`). The markup is the users/_mention partial as the
// sanitizer leaves it: sgid, data-turbo-frame and aria-hidden removed, the img
// serialized without '/'. Users come from the caller (one query per page).
// Attachments of any other kind make the body unsupported for now (none).

record MentionUser {
    id: Int
    name: String
    bio: String
    avatar-url: String
}

fn campfire.presentation.gid-user-id(gid: String) -> Option<Int> {
    doc "The id of a gid://campfire/User/<id> GlobalID (any ?params ignored); none for other models."
    let prefix = "gid://campfire/User/"
    if bool.not(string.starts-with(gid, prefix)) {
        option.none<Int>()
    } else {
        let rest = match string.slice(gid, string.byte-length(prefix), string.byte-length(gid) - string.byte-length(prefix)) { none => ""; some s => s }
        var digits = 0
        for index in 0..string.byte-length(rest) {
            let byte = string.byte-at-or(rest, index, 0)
            if byte < 48 || byte > 57 {
                break
            }
            digits = index + 1
        }
        let after = string.byte-at-or(rest, digits, 63)
        if digits == 0 || (digits < string.byte-length(rest) && after != 63) {
            option.none<Int>()
        } else {
            int.parse(match string.slice(rest, 0, digits) { none => ""; some s => s })
        }
    }
}

test campfire.presentation.gid-user-id/forms {
    expect campfire.presentation.gid-user-id("gid://campfire/User/712064548?expires_in") == option.some<Int>(712064548)
    expect campfire.presentation.gid-user-id("gid://campfire/User/127326141") == option.some<Int>(127326141)
    expect campfire.presentation.gid-user-id("gid://campfire/Message/1") == option.none<Int>()
}

fn campfire.presentation.base64-text(encoded: String) -> Option<String> {
    doc "Base64.strict_decode64 rescue Base64.urlsafe_decode64, as UTF-8 text."
    let raw = match base64.decode(encoded) { some data => option.some<Bytes>(data); none => base64.url-decode(encoded) }
    match raw { none => option.none<String>(); some data => bytes.to-utf8(data) }
}

test campfire.presentation.base64-text/decodes {
    expect campfire.presentation.base64-text("aGk=") == option.some<String>("hi")
}

fn campfire.presentation.sgid-user-id(sgid: String) -> Option<Int> {
    doc "attachable_from_possibly_expired_sgid, for users: the GlobalID in the SGID's message part, unverified."
    let message = match string.index-of(sgid, "--", 0) { none => sgid; some at => match string.slice(sgid, 0, at) { none => ""; some s => s } }
    let rails = match campfire.presentation.base64-text(message) { none => option.none<Json>(); some text => match json.parse(text) { none => option.none<Json>(); some value => json.field(value, "_rails") } }
    match rails {
        none => option.none<Int>()
        some fields => match json.field(fields, "data") {
            some data => match json.text(data) { none => option.none<Int>(); some gid => campfire.presentation.gid-user-id(gid) }
            none => match json.field(fields, "message") {
                none => option.none<Int>()
                some dumped => match json.text(dumped) {
                    none => option.none<Int>()
                    some encoded => match campfire.presentation.base64-text(encoded) {
                        none => option.none<Int>()
                        some marshaled => match string.index-of(marshaled, "gid://campfire/", 0) {
                            none => option.none<Int>()
                            some at => campfire.presentation.gid-user-id(match string.slice(marshaled, at, string.byte-length(marshaled) - at) { none => ""; some s => s })
                        }
                    }
                }
            }
        }
    }
}

test campfire.presentation.sgid-user-id/both-formats {
    expect campfire.presentation.sgid-user-id("eyJfcmFpbHMiOnsiZGF0YSI6ImdpZDovL2NhbXBmaXJlL1VzZXIvNzEyMDY0NTQ4P2V4cGlyZXNfaW4iLCJwdXIiOiJhdHRhY2hhYmxlIn19--577b92d04def2489c2795713eaa553e74aefb9b8") == option.some<Int>(712064548)
    expect campfire.presentation.sgid-user-id("eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaUpuYVdRNkx5OWpZVzF3Wm1seVpTOVZjMlZ5THpFeU56TXlOakUwTVFZNkJrVlUiLCJleHAiOm51bGwsInB1ciI6ImF0dGFjaGFibGUifX0=--0123456789abcdef0123456789abcdef01234567") == option.some<Int>(127326141)
    expect campfire.presentation.sgid-user-id("not-base64!--x") == option.none<Int>()
}

fn campfire.presentation.mention-html(user: MentionUser) -> String {
    doc "users/_mention as the sanitizer leaves it. The title is the name and the bio joined by ' – ' (a blank bio is left out)."
    let title = if string.trim(user.bio) == "" { user.name } else { string.join([user.name, " – ", user.bio]) }
    string.join(["<span class=\\"mention\\"><a title=\\"", rich-html.escape-attribute(title), "\\" class=\\"btn avatar\\" href=\\"/users/", int.to-string(user.id), "\\"><img src=\\"", rich-html.escape-attribute(user.avatar-url), "\\" width=\\"48\\" height=\\"48\\"></a> ", rich-html.escape-text(user.name), "</span>"])
}

test campfire.presentation.mention-html/markup {
    expect campfire.presentation.mention-html(mentionUser.new(id = 7, name = "Kevin", bio = "Programmer", avatar-url = "/users/t/avatar?v=1")) == "<span class=\\"mention\\"><a title=\\"Kevin – Programmer\\" class=\\"btn avatar\\" href=\\"/users/7\\"><img src=\\"/users/t/avatar?v=1\\" width=\\"48\\" height=\\"48\\"></a> Kevin</span>"
}

fn campfire.presentation.find-user(users: List<MentionUser>, id: Int) -> Option<MentionUser> {
    var found = option.none<MentionUser>()
    for user in users {
        if user.id == id {
            found = option.some<MentionUser>(user)
            break
        }
    }
    found
}

test campfire.presentation.find-user/by-id {
    let user = mentionUser.new(id = 7, name = "K", bio = "", avatar-url = "")
    expect campfire.presentation.find-user([user], 7) == option.some<MentionUser>(user)
}

record AttachmentScan {
    text: String
    user-ids: List<Int>
    supported: Bool
}

fn campfire.presentation.scan-attachments(text: String, users: List<MentionUser>) -> AttachmentScan {
    doc "Replaces each empty <action-text-attachment ...></action-text-attachment> that mentions a known user with the mention markup. Collects every mentioned user id (for the caller's query). supported is false for any other attachment or shape."
    let close-tag = "</action-text-attachment>"
    var out = ""
    var ids = list.empty<Int>()
    var supported = true
    var at = 0
    let length = string.byte-length(text)
    let steps = length + 1
    for step in 0..steps {
        let next = match string.index-of(text, "<action-text-attachment", at) { none => -1; some found => found }
        if next < 0 || bool.not(supported) {
            break
        }
        let tag = rich-html.tag(text, next)
        let after = tag.stop + 1
        let closed = tag.valid && tag.name == "action-text-attachment" && match string.slice(text, after, string.byte-length(close-tag)) { none => false; some s => s == close-tag }
        let user-id = match rich-html.attribute(tag, "sgid") { none => option.none<Int>(); some sgid => campfire.presentation.sgid-user-id(sgid) }
        let opengraph = match rich-html.attribute(tag, "content-type") { none => false; some kind => string.contains(kind, "opengraph") }
        if bool.not(closed) || opengraph || user-id == option.none<Int>() {
            supported = false
        } else {
            let id = match user-id { none => 0; some value => value }
            ids = list.append(ids, id)
            let rendered = match campfire.presentation.find-user(users, id) { none => ""; some user => campfire.presentation.mention-html(user) }
            out = string.join([out, match string.slice(text, at, next - at) { none => ""; some s => s }, rendered])
            at = after + string.byte-length(close-tag)
        }
    }
    attachmentScan.new(text = string.concat(out, match string.slice(text, at, length - at) { none => ""; some s => s }), user-ids = ids, supported = supported)
}

test campfire.presentation.scan-attachments/mention {
    let user = mentionUser.new(id = 127326141, name = "David", bio = "", avatar-url = "/a")
    let scan = campfire.presentation.scan-attachments("<div>Thanks <action-text-attachment sgid=\\"eyJfcmFpbHMiOnsiZGF0YSI6ImdpZDovL2NhbXBmaXJlL1VzZXIvMTI3MzI2MTQxIiwicHVyIjoiYXR0YWNoYWJsZSJ9fQ==--x\\" content-type=\\"application/vnd.campfire.mention\\"></action-text-attachment>, ok</div>", [user])
    expect scan.supported && scan.user-ids == [127326141]
    expect scan.text == "<div>Thanks <span class=\\"mention\\"><a title=\\"David\\" class=\\"btn avatar\\" href=\\"/users/127326141\\"><img src=\\"/a\\" width=\\"48\\" height=\\"48\\"></a> David</span>, ok</div>"
    expect bool.not(campfire.presentation.scan-attachments("<action-text-attachment content-type=\\"application/vnd.actiontext.opengraph-embed\\"></action-text-attachment>", list.empty<MentionUser>()).supported)
}

fn campfire.presentation.mentioned-user-ids(stored: Option<String>) -> List<Int> {
    doc "The user ids a stored body mentions, for loading them before rendering."
    match stored { none => list.empty<Int>(); some text => campfire.presentation.scan-attachments(text, list.empty<MentionUser>()).user-ids }
}

test campfire.presentation.mentioned-user-ids/none {
    expect campfire.presentation.mentioned-user-ids(option.some<String>("<p>x</p>")) == list.empty<Int>()
}
'''

a = "fn campfire.presentation.body(stored: Option<String>) -> Html {"
assert s.count(a) == 1
s = s.replace(a, mentions + "\nfn campfire.presentation.body-with(stored: Option<String>, users: List<MentionUser>) -> Html {")
# Inside body-with: substitute attachments first.
a2 = '''                    let shown = match rich-html.without-figure(text) { none => text; some inner => inner }'''
assert s.count(a2) == 1
s = s.replace(a2, '''                    let unwrapped = match rich-html.without-figure(text) { none => text; some inner => inner }
                    let scanned = campfire.presentation.scan-attachments(unwrapped, users)
                    // A mention of a user the caller did not load renders as nothing, like Rails' missing attachable.
                    let shown = if scanned.supported { scanned.text } else { "<unsupported>" }''')
s += '''
fn campfire.presentation.body(stored: Option<String>) -> Html {
    doc "campfire.presentation.body-with no mention users."
    campfire.presentation.body-with(stored, list.empty<MentionUser>())
}
'''
p.write_text(s, encoding="utf-8", newline="")
print("ok")

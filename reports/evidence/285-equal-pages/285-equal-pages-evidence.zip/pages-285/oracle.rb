# Rails oracle for rich text: every message's `message_presentation` (MessagesHelper), rendered
# by the reference app itself. Writes JSON lines: id, content_type, body (stored), html (output).
# Run with: bin/rails runner oracle.rb OUT.jsonl  (RAILS_ENV=production, snapshot database)
require "json"
out = File.open(ARGV.fetch(0), "w")
renderer = ApplicationController.renderer.new(http_host: "127.0.0.1:13774", https: false)
count = 0
Message.includes(:rich_text_body).find_each do |message|
  body = message.body&.body&.to_html
  stored = ActiveRecord::Base.connection.select_value(ActiveRecord::Base.sanitize_sql_array(["SELECT body FROM action_text_rich_texts WHERE record_type = ? AND record_id = ? AND name = ?", "Message", message.id, "body"]))
  html = renderer.render(inline: "<%= message_presentation(@message) %>", assigns: { message: message })
  out.puts JSON.generate(id: message.id, content_type: message.content_type, stored: stored, canonical: body, html: html)
  count += 1
end
out.close
puts "oracle messages=#{count}"

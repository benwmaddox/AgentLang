from pathlib import Path
R = Path(r"D:\code\AgentLang")
p = R / "src/stdlib/rich-html.flow"
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:70], s.count(a))
    s = s.replace(a, b)


add = (R / ".agentlang/pages-285/autolink_flow.txt").read_text(encoding="utf-8")
add = add.replace('''    for step in 0..length + 1 {
        if at >= length || refused {''', '''    let steps = length + 1
    for step in 0..steps {
        if at >= length || refused {''')
add = add.replace('''            if end == body && bool.not(www) {
                at = at + 1
            } else if www && end == body {
                at = at + 1
            } else {''', '''            if end == body {
                // AUTO_LINK_RE needs at least one URL character after the prefix.
                at = at + 1
            } else {''')

# Text rule takes a links-allowed switch; the scanner becomes rich-html.scan.
rep('''fn rich-html.text-ok?(stack: String, text: String) -> Bool {''', '''fn rich-html.text-ok?(stack: String, text: String) -> Bool {
    doc "rich-html.text-ok-for? with no links allowed."
    rich-html.text-ok-for?(stack, text, false)
}

fn rich-html.text-ok-for?(stack: String, text: String, links-allowed: Bool) -> Bool {''')
rep('''        bool.not(string.contains(text, "://")) && bool.not(string.contains(string.to-lower-ascii(text), "www.")) && bool.not(rich-html.email-like?(text))''',
    '''        (links-allowed || (bool.not(string.contains(text, "://")) && bool.not(string.contains(string.to-lower-ascii(text), "www.")))) && bool.not(rich-html.email-like?(text))''')
rep('''fn rich-html.canonical?(text: String) -> Bool {
    doc "True when text is safe, canonical rich text that Rails' message pipeline returns unchanged (see the file comment). Anything uncertain is false."
''', '''fn rich-html.canonical?(text: String) -> Bool {
    doc "True when text is safe, canonical rich text that Rails' message pipeline returns unchanged (see the file comment). Anything uncertain is false."
    rich-html.scan(text, false)
}

fn rich-html.scan(text: String, links-allowed: Bool) -> Bool {
    doc "The canonical-text check. With links-allowed, text may contain URLs (rich-html.present links them); everything else is as strict."
''')
rep('''            ok = ok && rich-html.text-ok?(stack, run)''', '''            ok = ok && rich-html.text-ok-for?(stack, run, links-allowed)''')
rep('''    ok && stack == "" && rich-html.text-ok?(stack, tail)''', '''    ok && stack == "" && rich-html.text-ok-for?(stack, tail, links-allowed)''')
# Attribute values: no newline, '<' or '>' (rails_autolink treats them as tag boundaries).
rep('''                    if string.byte-at-or(text, value-end, 0) != 34 || string.contains(value, " ") {''',
    '''                    if string.byte-at-or(text, value-end, 0) != 34 || string.contains(value, " ") || string.contains(value, "\\n") || string.contains(value, "<") || string.contains(value, ">") {''')

s += add + '''
fn rich-html.link(text: String) -> Option<String> {
    doc "auto_link over canonical text: every text run outside an <a> element gets its URLs linked. Tags are copied as they are (canonical attribute values hold no '>')."
    let length = string.byte-length(text)
    var out = ""
    var at = 0
    var anchors = 0
    var refused = false
    let steps = length + 1
    for step in 0..steps {
        if at >= length || refused {
            break
        }
        if string.byte-at-or(text, at, 0) == 60 {
            let close = match string.index-of(text, ">", at) { none => length - 1; some end => end }
            let tag = match string.slice(text, at, close + 1 - at) { none => ""; some s => s }
            if string.starts-with(tag, "<a ") || tag == "<a>" {
                anchors = anchors + 1
            } else if tag == "</a>" {
                anchors = anchors - 1
            }
            out = string.concat(out, tag)
            at = close + 1
        } else {
            let next = match string.index-of(text, "<", at) { none => length; some lt => lt }
            let run = match string.slice(text, at, next - at) { none => ""; some s => s }
            if anchors > 0 {
                out = string.concat(out, run)
            } else {
                match rich-html.link-text-run(run) {
                    none => {
                        refused = true
                    }
                    some linked => {
                        out = string.concat(out, linked)
                    }
                }
            }
            at = next
        }
    }
    if refused { option.none<String>() } else { option.some<String>(out) }
}

test rich-html.link/outside-anchors {
    expect rich-html.link("<p>see https://a.b/c and <a href=\\"https://a.b/d\\">https://a.b/d</a></p>") == option.some<String>("<p>see <a target=\\"_blank\\" href=\\"https://a.b/c\\">https://a.b/c</a> and <a href=\\"https://a.b/d\\">https://a.b/d</a></p>")
}

fn rich-html.present(text: String) -> Option<String> {
    doc "Rich text as Rails' sanitize-then-auto_link leaves it, when the text is canonical apart from URL text: the text itself when nothing needs linking, else the linked text. None for anything else (the caller escapes)."
    if rich-html.canonical?(text) {
        option.some<String>(text)
    } else if rich-html.scan(text, true) {
        rich-html.link(text)
    } else {
        option.none<String>()
    }
}

test rich-html.present/links {
    expect rich-html.present("<p>hi</p>") == option.some<String>("<p>hi</p>")
    expect rich-html.present("<p>Docs at https://example.com/docs</p>") == option.some<String>("<p>Docs at <a target=\\"_blank\\" href=\\"https://example.com/docs\\">https://example.com/docs</a></p>")
    expect rich-html.present("<script>x</script>") == option.none<String>()
}

test rich-html.scan/links-allowed {
    expect rich-html.scan("<p>see https://x.y</p>", true) && bool.not(rich-html.scan("<p>see https://x.y</p>", false))
    expect bool.not(rich-html.scan("<p title=\\"a>b\\">x</p>", true))
}

test rich-html.text-ok-for?/links {
    expect rich-html.text-ok-for?("/p", "https://x.y", true) && bool.not(rich-html.text-ok-for?("/p", "https://x.y", false))
}
'''
p.write_text(s, encoding="utf-8", newline="")

q = R / "applications/campfire/presentation.flow"
t = q.read_text(encoding="utf-8")
a = '''                    let shown = match rich-html.without-figure(text) { none => text; some inner => if rich-html.canonical?(inner) { inner } else { text } }
                    campfire.views.rich-text-layout(if rich-html.canonical?(shown) { html.raw(shown) } else { Html.new(text) })'''
assert t.count(a) == 1
t = t.replace(a, '''                    let shown = match rich-html.without-figure(text) { none => text; some inner => inner }
                    campfire.views.rich-text-layout(match rich-html.present(shown) { some safe => html.raw(safe); none => Html.new(text) })''')
q.write_text(t, encoding="utf-8", newline="")
print("ok")

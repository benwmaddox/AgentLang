export PAGE_ROOM=654632876
bash -x /mnt/d/code/AgentLang/.agentlang/pages-285/page-lifetime.sh rails pg-rails-r3 off 16 > /mnt/d/code/AgentLang/.agentlang/pages-285/private/pg-rails-r3.trace 2>&1; echo rc=$?

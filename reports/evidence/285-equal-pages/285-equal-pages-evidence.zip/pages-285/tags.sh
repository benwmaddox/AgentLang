DB=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258/private/native-db-snap-nc/production.sqlite3
sqlite3 -readonly "$DB" "select count(*), sum(length(body)) from action_text_rich_texts;" 
sqlite3 -readonly "$DB" "select body from action_text_rich_texts;" | grep -o '<[a-zA-Z][a-zA-Z0-9-]*' | sort | uniq -c | sort -rn
sqlite3 -readonly "$DB" "select body from action_text_rich_texts;" | grep -o ' [a-zA-Z-]*=' | sort | uniq -c | sort -rn | head -20
sqlite3 -readonly "$DB" "select body from action_text_rich_texts;" | grep -o '&[a-z#0-9]*;' | sort | uniq -c

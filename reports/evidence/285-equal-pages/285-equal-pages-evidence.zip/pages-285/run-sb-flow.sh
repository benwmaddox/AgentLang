true
PAGE_HEADERS=1 PAGE_PATH=/users/me/sidebar FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server bash page-lifetime.sh flow pg-flow-sb2 on 16 > /dev/null 2>&1; echo flow-sb=$?
cp /home/ben/linuxbench/private/pg-flow-sb2/curl-body.html private/sb/flow.html; head -1 /home/ben/linuxbench/private/pg-flow-sb2/headers.txt

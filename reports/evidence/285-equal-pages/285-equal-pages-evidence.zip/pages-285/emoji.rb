# Code point ranges matching Rails' String#all_emoji? atom: \p{Emoji_Presentation}|\p{Extended_Pictographic}|\u{FE0F}
re = /\A(?:\p{Emoji_Presentation}|\p{Extended_Pictographic}|\u{FE0F})\z/
ranges = []
start = nil; prev = nil
(0..0x10FFFF).each do |cp|
  next if cp.between?(0xD800, 0xDFFF)
  if re.match?(cp.chr(Encoding::UTF_8))
    if start && cp == prev + 1 then prev = cp else ranges << [start, prev] if start; start = prev = cp end
  end
end
ranges << [start, prev] if start
puts "ruby=#{RUBY_VERSION} unicode=#{RbConfig::CONFIG['UNICODE_VERSION']} emoji=#{RbConfig::CONFIG['UNICODE_EMOJI_VERSION']} ranges=#{ranges.size}"
File.write(ARGV[0], ranges.map { |a, b| "#{a} #{b}" }.join("\n") + "\n")

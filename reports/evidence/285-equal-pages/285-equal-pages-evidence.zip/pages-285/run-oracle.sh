# Flow message presentation against Rails' recorded output for every snapshot message, file attachments included.
cd /d/code/AgentLang && dotnet run --project src/AgentLang.Cli -c Release -- test $(cat .agentlang/pages-285/oracle-files.txt) .agentlang/pages-285/private/presentation-oracle-tests.flow .agentlang/pages-285/private/attachment-oracle-tests.flow 2>&1 | grep -E 'FAIL|passed|error'

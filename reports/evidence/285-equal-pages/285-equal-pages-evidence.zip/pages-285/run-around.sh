F=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server
for c in "a1 486777696/@933434570" "a2 486777696/@1"; do
  set -- $c
  PAGE_ROOM=$2 bash page-lifetime.sh rails pg-rails-$1 off 16 > /dev/null 2>&1; echo rails-$1=$?
  PAGE_ROOM=$2 FLOWBIN=$F bash page-lifetime.sh flow pg-flow-$1 on 16 > /dev/null 2>&1; echo flow-$1=$?
  mkdir -p private/$1; cp /home/ben/linuxbench/private/pg-rails-$1/body1.html private/$1/rails.html; cp /home/ben/linuxbench/private/pg-flow-$1/body1.html private/$1/flow.html; cp private/$1/flow.html private/$1/rust.html
done

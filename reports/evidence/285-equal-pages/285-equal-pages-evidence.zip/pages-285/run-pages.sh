export PAGE_ROOM=654632876
bash page-lifetime.sh rails pg-rails-r4 off 16 > /dev/null 2>&1; echo rails=$?
FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server bash page-lifetime.sh flow pg-flow-r4 on 16 > /dev/null 2>&1; echo flow=$?
grep -h "page room\|decoded_bytes\|not ready\|stopped" runs/pg-*-r4/driver.log
cp /home/ben/linuxbench/private/pg-rails-r4/body1.html private/rails-654.html; cp /home/ben/linuxbench/private/pg-flow-r4/body1.html private/flow-654.html

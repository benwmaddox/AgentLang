out = File.open(ARGV.fetch(0), "w")
out.puts "etaggers=#{MessagesController.etaggers.size} with_template_digest=#{MessagesController.etag_with_template_digest rescue 'n/a'}"
finder = ApplicationController.new.lookup_context
out.puts "digest=#{ActionView::Digestor.digest(name: "messages/index", format: :html, finder: finder)}"
room = Room.find(486777696)
target = room.messages.find(933434570)
msgs = room.messages.with_creator.page_before(target)
out.puts "class=#{msgs.class} count=#{msgs.size} first_key=#{msgs.first.cache_key_with_version}"
key = ActiveSupport::Cache.expand_cache_key([msgs, ActionView::Digestor.digest(name: "messages/index", format: :html, finder: finder)])
out.puts "expanded_head=#{key[0, 120]} md5=#{Digest::MD5.hexdigest(key)}"
out.close

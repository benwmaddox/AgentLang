F=/home/ben/linuxbench/flowhttp/campfire-285/flow_http_server
for c in "pb 486777696/messages?before=933434570" "pa 486777696/messages?after=933434570" "pe 486777696/messages?before=933434510"; do
  set -- $c
  PAGE_HEADERS=1 PAGE_ROOM=$2 FLOWBIN=$F bash page-lifetime.sh flow pg-flow-$1 on 16 > /dev/null 2>&1; echo flow-$1=$?
  cp /home/ben/linuxbench/private/pg-flow-$1/curl-body.html private/$1/flow.html; cp /home/ben/linuxbench/private/pg-flow-$1/headers.txt private/$1/flow-headers.txt
done

from pathlib import Path
R = Path(r"D:\code\AgentLang")
S = R / "applications/campfire/server"

p = S / "server-db.flow"
s = p.read_text(encoding="utf-8")
anchor = "fn campfire.server.last-page-with-creators(room-id: RoomId, avatar-key: Bytes) -> Result<List<MessageWithCreator>, DbError> {"
if "fn campfire.server.mention-users(" not in s:
  s = s.replace(anchor, '''fn campfire.server.mention-users(ids: List<Int>, avatar-key: Bytes) -> List<MentionUser> {
    effects db.read
    doc "The users these ids name, as mentions render them (name, bio, fresh avatar path), in one query. Missing users are left out (Rails renders a missing attachable as nothing)."
    if list.count(ids) == 0 {
        list.empty<MentionUser>()
    } else {
        match db.query("SELECT id, name, COALESCE(bio, ''), updated_at FROM users WHERE id IN (SELECT value FROM json_each($ids))", [db.text-param(campfire.server.id-list(ids))]) {
            error failure => list.empty<MentionUser>()
            ok rows => {
                var users = list.empty<MentionUser>()
                for row in rows {
                    let id = campfire.server.int-or-zero(db.optional-int(row, 0))
                    let stamp = campfire.server.text-or-empty(db.optional-text(row, 3))
                    users = list.append(users, mentionUser.new(
                        id = id,
                        name = campfire.server.text-or-empty(db.optional-text(row, 1)),
                        bio = campfire.server.text-or-empty(db.optional-text(row, 2)),
                        avatar-url = string.join(["/users/", campfire.server.avatar-token(avatar-key, id), "/avatar?v=", string.replace(string.replace(string.replace(match string.slice(stamp, 0, 19) { none => stamp; some text => text }, "-", ""), ":", ""), " ", "")])))
                }
                users
            }
        }
    }
}

''' + anchor)
p.write_text(s, encoding="utf-8", newline="")

t = (S / "server-db-tests.flow").read_text(encoding="utf-8")
if 'test campfire.server.mention-users/fixture' not in t: t += '''
test campfire.server.mention-users/fixture {
    expect campfire.server.test-fixture() == 0
    let users = campfire.server.mention-users([1, 99], bytes.from-utf8("key"))
    expect list.count(users) == 1
    expect match list.get(users, 0) { none => ""; some user => user.name } == "Ann"
    expect list.count(campfire.server.mention-users(list.empty<Int>(), bytes.from-utf8("key"))) == 0
}
'''
(S / "server-db-tests.flow").write_text(t, encoding="utf-8", newline="")

p = S / "server.flow"
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''fn campfire.server.presentation(message: MessageWithCreator) -> Html {
    doc "campfire.presentation.body of the message's stored body."
    campfire.presentation.body(message.body)
}''', '''fn campfire.server.presentation(message: MessageWithCreator, users: List<MentionUser>) -> Html {
    doc "campfire.presentation.body-with of the message's stored body and the mention users loaded for its page."
    campfire.presentation.body-with(message.body, users)
}

fn campfire.server.page-mention-users(messages: List<MessageWithCreator>, avatar-key: Bytes) -> List<MentionUser> {
    effects db.read
    doc "Every user these messages mention, loaded in one query."
    var ids = list.empty<Int>()
    for message in messages {
        for id in campfire.presentation.mentioned-user-ids(message.body) {
            ids = list.append(ids, id)
        }
    }
    campfire.server.mention-users(ids, avatar-key)
}

test campfire.server.page-mention-users/none {
    expect campfire.server.test-fixture() == 0
    expect list.count(campfire.server.page-mention-users(list.empty<MessageWithCreator>(), bytes.from-utf8("k"))) == 0
}''')
rep('''fn campfire.server.render-message(context: MessageContext, message: MessageWithCreator, boosts: List<BoostView>) -> String {
    doc "messages/_message with the message's own boosts and its presentation."
    campfire.views.text(campfire.views.rails-message-presented(context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message)))
}''', '''fn campfire.server.render-message(context: MessageContext, message: MessageWithCreator, boosts: List<BoostView>, users: List<MentionUser>) -> String {
    doc "messages/_message with the message's own boosts and its presentation."
    campfire.views.text(campfire.views.rails-message-presented(context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message, users)))
}''')
rep('''    let text = campfire.server.render-message(context, message, [boostView.new(id = 9, message-id = 5, booster-id = 2, booster-name = "Bo", booster-avatar-url = "/users/t2/avatar?v=1", content = "👀")])''',
    '''    let text = campfire.server.render-message(context, message, [boostView.new(id = 9, message-id = 5, booster-id = 2, booster-name = "Bo", booster-avatar-url = "/users/t2/avatar?v=1", content = "👀")], list.empty<MentionUser>())''')
rep('''fn campfire.server.write-messages(cache: WorkerCache, context: MessageContext, keys: List<PageKey>, loaded: List<MessageWithCreator>, boosts: List<BoostView>) -> StreamedPage {''',
    '''fn campfire.server.write-messages(cache: WorkerCache, context: MessageContext, keys: List<PageKey>, loaded: List<MessageWithCreator>, boosts: List<BoostView>, users: List<MentionUser>) -> StreamedPage {''')
rep('''                    some message => campfire.server.render-message(context, message, boosts)''', '''                    some message => campfire.server.render-message(context, message, boosts, users)''')
rep('''            let page = campfire.server.write-messages(cache, context, keys, loaded, boosts)''', '''            let page = campfire.server.write-messages(cache, context, keys, loaded, boosts, campfire.server.page-mention-users(loaded, avatar-key))''')
s = s.replace('''[message], list.empty<BoostView>())''', '''[message], list.empty<BoostView>(), list.empty<MentionUser>())''')
s = s.replace('''list.empty<MessageWithCreator>(), list.empty<BoostView>())''', '''list.empty<MessageWithCreator>(), list.empty<BoostView>(), list.empty<MentionUser>())''')
rep('''    var rendered = list.empty<Html>()
    for message in messages {
        rendered = list.append(rendered, campfire.views.rails-message-presented(message-context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message)))''',
    '''    let users = campfire.server.page-mention-users(messages, context.avatar-key)
    var rendered = list.empty<Html>()
    for message in messages {
        rendered = list.append(rendered, campfire.views.rails-message-presented(message-context, message, campfire.server.boosts-of(boosts, MessageId.value(message.id)), campfire.server.presentation(message, users)))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

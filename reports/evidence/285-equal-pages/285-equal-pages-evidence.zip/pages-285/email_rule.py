from pathlib import Path
p = Path(r"D:\code\AgentLang\src\stdlib\rich-html.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''fn rich-html.text-ok?(stack: String, text: String) -> Bool {''', '''fn rich-html.word-byte?(byte: Int) -> Bool {
    doc "A byte auto_link's e-mail pattern may treat as a word character: ASCII letters, digits, '_' and '-', and (conservatively) any non-ASCII byte."
    (byte >= 97 && byte <= 122) || (byte >= 65 && byte <= 90) || (byte >= 48 && byte <= 57) || byte == 95 || byte == 45 || byte >= 128
}

test rich-html.word-byte?/classes {
    expect rich-html.word-byte?(97) && rich-html.word-byte?(45) && rich-html.word-byte?(200) && bool.not(rich-html.word-byte?(46))
}

fn rich-html.email-like?(text: String) -> Bool {
    doc "True when some '@' is followed by word characters, a '.', and another word character: the shape auto_link links as an e-mail address (user@host.tld). '@' without a dotted host after it is left alone, as auto_link leaves it."
    let length = string.byte-length(text)
    var found = false
    for index in 0..length {
        if string.byte-at-or(text, index, 0) == 64 {
            var at = index + 1
            let start = at
            for k in start..length {
                if bool.not(rich-html.word-byte?(string.byte-at-or(text, k, 0))) {
                    break
                }
                at = k + 1
            }
            if at > start && string.byte-at-or(text, at, 0) == 46 && rich-html.word-byte?(string.byte-at-or(text, at + 1, 0)) {
                found = true
            }
        }
    }
    found
}

test rich-html.email-like?/shapes {
    expect rich-html.email-like?("mail a@b.c") && rich-html.email-like?("x@host.example")
    expect bool.not(rich-html.email-like?("Deployed campfire@4f2c1e9 to production")) && bool.not(rich-html.email-like?("@ home")) && bool.not(rich-html.email-like?("a@b."))
}

fn rich-html.text-ok?(stack: String, text: String) -> Bool {''')
rep('''        bool.not(string.contains(text, "://")) && bool.not(string.contains(string.to-lower-ascii(text), "www.")) && bool.not(string.contains(text, "@"))''',
    '''        bool.not(string.contains(text, "://")) && bool.not(string.contains(string.to-lower-ascii(text), "www.")) && bool.not(rich-html.email-like?(text))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

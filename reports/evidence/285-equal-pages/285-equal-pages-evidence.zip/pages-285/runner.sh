# Runs a Ruby script (arg 2, in pages-285) in a fresh copy of the native Rails app against a copy of the fixture database.
# Run as root: wsl -d Ubuntu -u root -- bash .../runner.sh <run> <script.rb>
set -euo pipefail
RUN=$1
U=ben; UH=/home/$U; L=$UH/linuxbench
H=/mnt/d/code/AgentLang/.agentlang/once-campfire-verification
D=/mnt/d/code/AgentLang/.agentlang/pages-285
W=$L/runs/runner-$RUN
test ! -e "$W" || { echo "run exists"; exit 2; }
asu() { setpriv --reuid=$U --regid=$U --init-groups "$@"; }
asu mkdir -p "$W"; asu cp -a "$L/rails/app" "$W/app"; ROOT=$W/app
asu rm -rf "$ROOT/storage"; asu mkdir -p "$ROOT/storage/logs"
asu cp -r "$H/fixtures/default/db" "$ROOT/storage/db"; asu cp -r "$H/fixtures/default/storage" "$ROOT/storage/files"
asu cp "$D/$2" "$W/script.rb"
ENVV=(LANG=C.UTF-8 HOME=$UH USER=$U RAILS_ENV=production
      PATH=$L/rails/bundle/bin:$L/ruby-3.4.10/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
      GEM_HOME=$L/rails/bundle BUNDLE_APP_CONFIG=$L/rails/bundle BUNDLE_SILENCE_ROOT_WARNING=1 BUNDLE_DEPLOYMENT=1
      BUNDLE_PATH=$L/rails/bundle BUNDLE_WITHOUT=development APP_VERSION=verification
      GIT_REVISION=90b330024dec3e757c79b6a7e6568f93da8e3148 RAILS_LOG_LEVEL=warn)
while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in ''|'#'*) continue;; esac; ENVV+=("$line")
done < "$H/fixtures/default/reference.env"
mkdir -p "$D/private"
cd "$ROOT" && asu env -i "${ENVV[@]}" bin/rails runner "$W/script.rb" "$W/out.txt" 2>&1 | tail -30
cp "$W/out.txt" "$D/private/runner-$RUN.txt" 2>/dev/null || true
cat "$D/private/runner-$RUN.txt" 2>/dev/null

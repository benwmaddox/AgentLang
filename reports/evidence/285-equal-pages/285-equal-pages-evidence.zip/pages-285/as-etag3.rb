out = File.open(ARGV.fetch(0), "w")
labels = JSON.parse(File.read("/mnt/d/code/AgentLang/.agentlang/once-campfire-verification/fixtures/default/labels.json"))
s = ActionDispatch::Integration::Session.new(Rails.application)
s.host! "127.0.0.1:13774"
s.post "/session", params: { email_address: labels["emails.david"] || labels.dig("emails", "david"), password: labels["passwords.all"] || labels.dig("passwords", "all") }
out.puts "login=#{s.response.status}"
s.get "/rooms/486777696/messages?before=933434570"
out.puts "status=#{s.response.status} etag=#{s.response.headers['ETag']} lm=#{s.response.headers['Last-Modified']}"
room = Room.find(486777696); target = room.messages.find(933434570)
msgs = room.messages.with_creator.page_before(target)
finder = ApplicationController.new.lookup_context
d = ActionView::Digestor.digest(name: "messages/index", format: :html, finder: finder)
[[msgs, d], [msgs], msgs].each_with_index { |v, i| out.puts "cand#{i}=W/\"#{ActiveSupport::Digest.hexdigest(ActiveSupport::Cache.expand_cache_key(v))}\"" }
out.puts "digest_class=#{ActiveSupport::Digest.hash_digest_class}"
out.close

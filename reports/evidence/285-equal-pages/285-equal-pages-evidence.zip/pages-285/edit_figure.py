from pathlib import Path
R = Path(r"D:\code\AgentLang")

p = R / "src/stdlib/rich-html.flow"
s = p.read_text(encoding="utf-8")
s += '''
fn rich-html.without-figure(text: String) -> Option<String> {
    doc "Rails' SanitizeTags strips the disallowed <figure> Lexxy wraps a table in and keeps its children. This handles exactly that shape: the whole text is one top-level <figure ...>...</figure> with no other figure inside. Returns the children, or none for any other text."
    let length = string.byte-length(text)
    let open-end = match string.index-of(text, ">", 0) { none => -1; some at => at }
    let shaped = string.starts-with(text, "<figure") && string.ends-with(text, "</figure>") && open-end > 0
    let after-name = string.byte-at-or(text, 7, 0)
    if bool.not(shaped) || (after-name != 62 && after-name != 32) {
        option.none<String>()
    } else {
        let inner = match string.slice(text, open-end + 1, length - open-end - 1 - 9) { none => ""; some s => s }
        if string.contains(inner, "<figure") || string.contains(inner, "</figure>") {
            option.none<String>()
        } else {
            option.some<String>(inner)
        }
    }
}

test rich-html.without-figure/lexxy-table {
    expect rich-html.without-figure("<figure class=\\"lexxy-content__table-wrapper\\"><table><tbody> <tr><td><p>x</p></td></tr> </tbody></table></figure>") == option.some<String>("<table><tbody> <tr><td><p>x</p></td></tr> </tbody></table>")
    expect rich-html.without-figure("<p>x</p>") == option.none<String>()
    expect rich-html.without-figure("<figure><figure>x</figure></figure>") == option.none<String>()
    expect rich-html.without-figure("<figures>x</figures>") == option.none<String>()
}
'''
p.write_text(s, encoding="utf-8", newline="")

p = R / "applications/campfire/server/server.flow"
s = p.read_text(encoding="utf-8")
a = '''                none => campfire.views.rich-text-layout(if rich-html.canonical?(text) { html.raw(text) } else { Html.new(text) })'''
assert s.count(a) == 1
s = s.replace(a, '''                none => {
                    // SanitizeTags strips Lexxy's table <figure> wrapper and keeps the table.
                    let shown = match rich-html.without-figure(text) { none => text; some inner => if rich-html.canonical?(inner) { inner } else { text } }
                    campfire.views.rich-text-layout(if rich-html.canonical?(shown) { html.raw(shown) } else { Html.new(text) })
                }''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

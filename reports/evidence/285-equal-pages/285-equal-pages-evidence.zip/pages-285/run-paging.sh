for c in "pb 486777696/messages?before=933434570" "pa 486777696/messages?after=933434570" "pe 486777696/messages?before=933434510"; do
  set -- $c
  PAGE_HEADERS=1 PAGE_ROOM=$2 bash page-lifetime.sh rails pg-rails-$1 off 16 > /dev/null 2>&1; echo rails-$1=$?
  mkdir -p private/$1; cp /home/ben/linuxbench/private/pg-rails-$1/curl-body.html private/$1/rails.html; cp /home/ben/linuxbench/private/pg-rails-$1/headers.txt private/$1/rails-headers.txt
done

from pathlib import Path
p = Path(r"D:\code\AgentLang\.agentlang\pages-285\tag_tokenizer.txt")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''fn rich-html.lower-byte(byte: Int) -> Int {
    if byte >= 65 && byte <= 90 { byte + 32 } else { byte }
}

test rich-html.lower-byte/ascii {
    expect rich-html.lower-byte(65) == 97 && rich-html.lower-byte(97) == 97
}''', '''fn rich-html.ascii-char(code: Int) -> String {
    doc "The printable ASCII character with this code (32-126), else empty."
    let table = " !\\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
    if code < 32 || code > 126 { "" } else { match string.slice(table, code - 32, 1) { none => ""; some c => c } }
}

test rich-html.ascii-char/table {
    expect rich-html.ascii-char(39) == "'" && rich-html.ascii-char(65) == "A" && rich-html.ascii-char(126) == "~" && rich-html.ascii-char(200) == ""
}''')
rep('''        if digits > 0 && terminated && value > 0 && value < 1114112 && (value < 55296 || value > 57343) {
            found = [string.from-code-point(value), int.to-string(start + digits + 1)]''', '''        if digits > 0 && terminated && rich-html.ascii-char(value) != "" {
            // Printable ASCII only; other code points are refused (no encoder in this library).
            found = [rich-html.ascii-char(value), int.to-string(start + digits + 1)]''')
rep('''            if rich-html.space?(byte) { state = 1 } else if byte == 47 { state = 8 } else if byte == 62 { end = i } else { name = string.concat(name, string.from-code-point(rich-html.lower-byte(byte))) }''',
    '''            if rich-html.space?(byte) { state = 1 } else if byte == 47 { state = 8 } else if byte == 62 { end = i } else { name = string.concat(name, char) }''')
rep('''            if rich-html.space?(byte) || byte == 47 || byte == 62 { state = 3; advance = 0 } else if byte == 61 { state = 4 } else { attr-name = string.concat(attr-name, if byte < 128 { string.from-code-point(rich-html.lower-byte(byte)) } else { char }) }''',
    '''            if rich-html.space?(byte) || byte == 47 || byte == 62 { state = 3; advance = 0 } else if byte == 61 { state = 4 } else { attr-name = string.concat(attr-name, char) }''')
rep('''        if emit-attr {
            var seen = false''', '''        if emit-attr {
            // The tokenizer lower-cases ASCII letters in attribute names.
            attr-name = string.to-lower-ascii(attr-name)
            var seen = false''')
rep('''    htmlTag.new(name = name, attributes = attributes, end = end, ok = ok && end >= 0)''',
    '''    htmlTag.new(name = string.to-lower-ascii(name), attributes = attributes, end = end, ok = ok && end >= 0)''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

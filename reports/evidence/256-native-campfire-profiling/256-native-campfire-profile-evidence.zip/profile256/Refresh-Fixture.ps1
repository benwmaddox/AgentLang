param(
  [Parameter(Mandatory)][string]$BuildDirectory,
  [Parameter(Mandatory)][string]$OutputPath
)
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
$fixture = [IO.Path]::GetFullPath((Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'))
$build = [IO.Path]::GetFullPath($BuildDirectory)
$receiptPath = Join-Path $build 'build-receipt.json'
$sqlitePath = Join-Path $build 'e_sqlite3.dll'
if (-not (Test-Path -LiteralPath $receiptPath -PathType Leaf) -or -not (Test-Path -LiteralPath $sqlitePath -PathType Leaf)) {
  throw 'Selected build must contain its build receipt and pinned SQLite DLL.'
}
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
$actualSqlite = (Get-FileHash -LiteralPath $sqlitePath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualSqlite -cne ([string]$receipt.SqliteSha256).ToLowerInvariant()) { throw 'SQLite hash does not match the selected build receipt.' }
$databasePaths = @(
  (Join-Path $fixture 'native.sqlite'),
  (Join-Path $fixture 'reference.sqlite')
)
foreach ($databasePath in $databasePaths) {
  $full = [IO.Path]::GetFullPath($databasePath)
  if (-not [StringComparer]::OrdinalIgnoreCase.Equals([IO.Path]::GetDirectoryName($full), $fixture)) { throw 'Refusing to mutate a DB outside the disposable Campfire fixture.' }
  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw 'Both synthetic fixture DBs must already exist.' }
}
$python = Get-Command python -ErrorAction Stop
$tempOutput = Join-Path $env:TEMP ('campfire-native-profile-256-refresh-' + [Guid]::NewGuid().ToString('N') + '.json')
try {
  $helper = Join-Path $PSScriptRoot 'refresh_fixture.py'
  $args = @($helper, $sqlitePath, $actualSqlite, $tempOutput) + $databasePaths
  & $python.Source @args
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $tempOutput -PathType Leaf)) { throw 'Synthetic fixture refresh failed.' }
  $metadata = Get-Content -LiteralPath $tempOutput -Raw | ConvertFrom-Json
  if ($metadata.sqliteVersion -cne '3.53.3' -or $metadata.rows.Count -ne 2) { throw 'Fixture refresh receipt failed validation.' }
  $resolvedOutput = [IO.Path]::GetFullPath($OutputPath)
  if (Test-Path -LiteralPath $resolvedOutput) { throw 'Fixture refresh output is immutable and already exists.' }
  $parent = Split-Path -Parent $resolvedOutput
  if (-not (Test-Path -LiteralPath $parent -PathType Container)) { $null = New-Item -ItemType Directory -Path $parent }
  $metadata | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $resolvedOutput -Encoding utf8NoBOM
  Write-Output "refreshed synthetic session in native/reference fixture copies; sqlite_sha256=$actualSqlite"
} finally {
  Remove-Item -LiteralPath $tempOutput -Force -ErrorAction SilentlyContinue
}

#requires -Version 7.0
param(
  [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$')][string]$RunName,
  [Parameter(Mandatory)][ValidateSet('Off','Detailed')][string]$ExecutionProfile,
  [int]$Concurrency = 16,
  [int]$Repeats = 2,
  [int]$Seconds = 15,
  [long]$ClientAffinityMask = 4129788
)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$repo = 'D:\code\AgentLang'
$root = Join-Path $repo ".agentlang/campfire-native-profile-256/runs/$RunName"
if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'Start the host through Run-Host.ps1 first.' }
$start = Get-Content -LiteralPath (Join-Path $root 'run-start.json') -Raw | ConvertFrom-Json
$hostInfo = Get-Content -LiteralPath (Join-Path $root 'host-process.json') -Raw | ConvertFrom-Json
$receipt = Get-Content -LiteralPath (Join-Path $root 'build-receipt.json') -Raw | ConvertFrom-Json
if ($start.executionProfile -cne $ExecutionProfile.ToLowerInvariant() -or
    ([string]$receipt.ExecutionProfile).ToLowerInvariant() -cne $ExecutionProfile.ToLowerInvariant()) {
  throw 'Requested execution profile does not match the immutable run build.'
}
$server = Get-Process -Id ([int]$hostInfo.processId) -ErrorAction Stop
$expectedExe = [IO.Path]::GetFullPath((Join-Path $start.buildDirectory 'native_http_host.exe'))
if (-not [StringComparer]::OrdinalIgnoreCase.Equals($server.Path, $expectedExe)) { throw 'Server PID is not the task-owned executable recorded for this run.' }
if ($Concurrency -ne 16 -or $Repeats -ne 2 -or $Seconds -ne 15) { throw 'The matched 256 experiment pins 16 clients, two repeats, and 15 seconds per repeat.' }
if ($ClientAffinityMask -ne 4129788) { throw 'The matched experiment pins the existing fixed-affinity client mask.' }

$fixture = Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'
$templatePath = Join-Path $fixture 'native-measure.config.json'
if (-not (Test-Path -LiteralPath $templatePath -PathType Leaf)) { throw 'Private disposable benchmark template is missing.' }
$pinsPath = Join-Path $repo '.agentlang/campfire-native-profile-256/client-source-pins.json'
$pins = Get-Content -LiteralPath $pinsPath -Raw | ConvertFrom-Json
$expectedSourceSha256 = '42566cbb461ba13814c4660aaee8687f9220377e45a9226f180e7180104896f4'
$expectedBinarySha256 = '073258c828a9ad104836ee0ac4026f507686d35a0efd9ff8c95c03b6b57970c9'
$expectedBuildLogSha256 = '0157694feed0da8f80343a5db6af8a62bad037c7309a45bd99578de3c8f53064'
$expectedSourcePath = 'experiments/AgentLang.Campfire.HttpMeasure/Program.cs'
$expectedBinaryPath = '.agentlang/campfire-native-profile-256/client-artifacts/bin/HttpMeasure/release/HttpMeasure.dll'
$expectedLatencyBoundary = 'Complete body received, before status/SHA256 validation; throughput includes validation'
if ($pins.sourcePath -cne $expectedSourcePath -or $pins.binaryPath -cne $expectedBinaryPath -or
    $pins.sourceSha256.ToLowerInvariant() -cne $expectedSourceSha256 -or
    $pins.binarySha256.ToLowerInvariant() -cne $expectedBinarySha256 -or
    $pins.buildLogSha256.ToLowerInvariant() -cne $expectedBuildLogSha256 -or
    [int]$pins.buildExitCode -ne 0 -or [int]$pins.selfTestExitCode -ne 0 -or
    $pins.latencyBoundary -cne $expectedLatencyBoundary) {
  throw 'The 256 client source/build pin receipt is absent, failed, or changed.'
}
$clientSource = Join-Path $repo $expectedSourcePath
$clientDll = Join-Path $repo $expectedBinaryPath
$clientBuildLog = Join-Path $repo '.agentlang/campfire-native-profile-256/client-build.log'
$clientSourceHash = (Get-FileHash -LiteralPath $clientSource -Algorithm SHA256).Hash.ToLowerInvariant()
if ($clientSourceHash -cne $expectedSourceSha256) { throw 'HTTP client source differs from its pinned build.' }
$clientBuildLogHash = (Get-FileHash -LiteralPath $clientBuildLog -Algorithm SHA256).Hash.ToLowerInvariant()
if ($clientBuildLogHash -cne $expectedBuildLogSha256) { throw 'HTTP client build log differs from its pinned build.' }
$clientHash = (Get-FileHash -LiteralPath $clientDll -Algorithm SHA256).Hash.ToLowerInvariant()
if ($clientHash -cne $expectedBinarySha256) { throw 'HTTP client artifact differs from its source-pinned build.' }
$topologyPath = Join-Path $repo '.agentlang/campfire-native-profile-255/topology.json'
$topology = Get-Content -LiteralPath $topologyPath -Raw | ConvertFrom-Json
$expectedClientMask = [Convert]::ToInt64($topology.selection.clientMaskHex.Substring(2), 16)
if ($expectedClientMask -ne $ClientAffinityMask) { throw 'Client affinity mask differs from the pinned four-core topology.' }

$configTemplate = Get-Content -LiteralPath $templatePath -Raw | ConvertFrom-Json
if ($configTemplate.Uri -cne 'http://127.0.0.1:13773/rooms/104' -or
    $configTemplate.Method -and $configTemplate.Method -cne 'GET') { throw 'Benchmark template does not identify the pinned authenticated GET workload.' }
$baselineBodyHash = ([string]$configTemplate.ExpectedBodySha256).ToLowerInvariant()
if ($baselineBodyHash -notmatch '^[0-9a-f]{64}$') { throw 'Benchmark template has no valid expected body hash.' }
$clientRoot = Join-Path $root 'client'
$null = New-Item -ItemType Directory -Path $clientRoot
$rows = [System.Collections.Generic.List[object]]::new()
for ($repeat = 1; $repeat -le $Repeats; $repeat++) {
  $config = $configTemplate | ConvertTo-Json -Depth 5 | ConvertFrom-Json
  $config.Concurrency = $Concurrency
  $config.Seconds = $Seconds
  $config.WarmupRequests = 20
  $config.ServerPid = [int]$hostInfo.processId
  $config | Add-Member -NotePropertyName ClientAffinityMask -NotePropertyValue $ClientAffinityMask -Force
  $configPath = Join-Path ([IO.Path]::GetTempPath()) ('campfire-native-profile-256-' + [Guid]::NewGuid().ToString('N') + '.json')
  $resultPath = Join-Path $clientRoot "repeat-$repeat.result.json"
  $logPath = Join-Path $clientRoot "repeat-$repeat.client.log"
  if ((Test-Path -LiteralPath $resultPath) -or (Test-Path -LiteralPath $logPath)) { throw 'Measurement output paths are immutable.' }
  try {
    $configJson = $config | ConvertTo-Json -Depth 5
    [IO.File]::WriteAllText($configPath, $configJson, [Text.UTF8Encoding]::new($false))
    & dotnet $clientDll $configPath $resultPath 2>&1 | Set-Content -LiteralPath $logPath -Encoding utf8NoBOM
    if ($LASTEXITCODE -ne 0) { throw "Benchmark correctness failed in repeat $repeat; private config was not retained." }
    $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json
    if ([int]$result.failures -ne 0 -or [int]$result.correctResponses -le 0 -or
        [double]$result.measuredSeconds -le 0 -or [int]$result.Concurrency -ne $Concurrency -or
        [int]$result.WarmupRequests -ne 20 -or [string]$result.method -cne 'GET' -or
        ([string]$result.ExpectedBodySha256).ToLowerInvariant() -cne $baselineBodyHash -or
        [long]$result.effectiveClientAffinityMask -ne $ClientAffinityMask) {
      throw "Benchmark result failed fixed workload checks in repeat $repeat."
    }
    $rows.Add($result)
    Write-Output ("profile={0} repeat={1} ok={2} req/s={3:F2} p99<={4}ms hostCPU={5:F3} clientCPU={6:F3} failures={7}" -f
      $ExecutionProfile,$repeat,$result.correctResponses,$result.correctRequestsPerSecond,$result.p99MillisecondsUpperBound,
      $result.serverCpuEquivalentCores,$result.clientCpuEquivalentCores,$result.failures)
  } finally {
    Remove-Item -LiteralPath $configPath -Force -ErrorAction SilentlyContinue
  }
}
$summaryPath = Join-Path $root 'measurement-summary.json'
if (Test-Path -LiteralPath $summaryPath) { throw 'Immutable measurement summary already exists.' }
[ordered]@{
  runName = $RunName
  executionProfile = $ExecutionProfile.ToLowerInvariant()
  clientSourcePath = $expectedSourcePath
  clientSourceSha256 = $clientSourceHash
  clientBuildLogSha256 = $clientBuildLogHash
  clientSelfTestExitCode = [int]$pins.selfTestExitCode
  clientBinarySha256 = $clientHash
  clientLatencyBoundary = $expectedLatencyBoundary
  concurrency = $Concurrency
  repeats = $Repeats
  secondsPerRepeat = $Seconds
  warmupRequestsPerRepeat = 20
  clientAffinityMask = $ClientAffinityMask
  expectedBodySha256 = $baselineBodyHash
  results = @($rows)
} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $summaryPath -Encoding utf8NoBOM

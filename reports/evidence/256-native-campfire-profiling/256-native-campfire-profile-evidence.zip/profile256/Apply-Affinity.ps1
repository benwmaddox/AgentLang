#requires -Version 7.0
param(
  [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$')][string]$RunName,
  [Parameter(Mandatory)][int]$ServerPid,
  [switch]$After
)
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
$root = Join-Path $repo ".agentlang/campfire-native-profile-256/runs/$RunName"
$topologyPath = Join-Path $repo '.agentlang/campfire-native-profile-255/topology.json'
$topology = Get-Content -LiteralPath $topologyPath -Raw | ConvertFrom-Json
$selection = $topology.selection
if ($selection.group -ne 0 -or $selection.selectedPhysicalCoreCount -ne 4) { throw 'Expected the pinned four-physical-core topology.' }
$mask = [Convert]::ToInt64($selection.serverMaskHex.Substring(2), 16)
$siblings = [Convert]::ToInt64($selection.siblingMaskHex.Substring(2), 16)
$client = [Convert]::ToInt64($selection.clientMaskHex.Substring(2), 16)
$hostInfo = Get-Content -LiteralPath (Join-Path $root 'host-process.json') -Raw | ConvertFrom-Json
if ([int]$hostInfo.processId -ne $ServerPid) { throw 'PID differs from the task-owned host process receipt.' }
$process = Get-Process -Id $ServerPid -ErrorAction Stop
$expected = [IO.Path]::GetFullPath([string]$hostInfo.executable)
if (-not [StringComparer]::OrdinalIgnoreCase.Equals($process.Path, $expected)) { throw 'PID is not the selected profile host executable.' }
if ($After) {
  $startPath = Join-Path $root 'affinity-start.json'
  $receipt = Get-Content -LiteralPath $startPath -Raw | ConvertFrom-Json
  $process.Refresh()
  $receipt.effectiveServerMaskAfter = $process.ProcessorAffinity.ToInt64()
  if ($receipt.effectiveServerMaskAfter -ne $mask) { throw 'Server affinity changed during the sample.' }
  $path = Join-Path $root 'affinity-receipt.json'
  if (Test-Path -LiteralPath $path) { throw 'Affinity receipt is immutable and already exists.' }
  $receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding utf8NoBOM
} else {
  $process.ProcessorAffinity = [IntPtr]::new($mask)
  $process.Refresh()
  if ($process.ProcessorAffinity.ToInt64() -ne $mask) { throw 'Server affinity did not match the requested mask.' }
  $path = Join-Path $root 'affinity-start.json'
  if (Test-Path -LiteralPath $path) { throw 'Affinity start is immutable and already exists.' }
  [ordered]@{
    serverPid = $ServerPid
    requestedServerMask = $mask
    effectiveServerMaskBefore = $process.ProcessorAffinity.ToInt64()
    effectiveServerMaskAfter = $null
    clientMask = $client
    serverSiblingMask = $siblings
    serverLogicalProcessors = @($selection.selectedLogicalProcessorIndices)
    serverPhysicalCores = @($selection.physicalCoreIndices)
    topologySha256 = (Get-FileHash -LiteralPath $topologyPath -Algorithm SHA256).Hash.ToLowerInvariant()
    scope = 'Native process only; four logical processors on four distinct physical cores. Kernel HTTP.sys work is outside this process affinity.'
  } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding utf8NoBOM
}
Write-Output "serverMask=$mask clientMask=$client fourPhysicalCores=true"

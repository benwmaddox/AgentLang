#include <windows.h>
#include <stdio.h>
int main(void){
  SetThreadAffinityMask(GetCurrentThread(), 1ull<<10); /* logical 10 = one of the four server cores */
  LARGE_INTEGER f,a,b,x; QueryPerformanceFrequency(&f);
  volatile LONGLONG sink=0; const int N=20000000;
  for(int r=0;r<5;r++){
    QueryPerformanceCounter(&a);
    for(int i=0;i<N;i++){ QueryPerformanceCounter(&x); sink+=x.QuadPart; }
    QueryPerformanceCounter(&b);
    printf("rep %d: %.2f ns per QPC call\n", r, (double)(b.QuadPart-a.QuadPart)*1e9/f.QuadPart/N);
  }
  printf("freq=%lld\n", f.QuadPart); return 0;
}

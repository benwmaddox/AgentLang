from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath


REPO = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT = REPO / "reports" / "evidence" / "256-native-campfire-profiling"
BANNED_PATH = re.compile(r"(?i)(\.sqlite3?(?:-(?:wal|shm|journal))?$|\.db3?$|\.config\.json$|synthetic-secret|private-request|private-measure|\.env$)")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_archive_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or ":" in name or "\x00" in name or BANNED_PATH.search(name):
        raise ValueError(f"Unsafe archive member: {name}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the sealed native Campfire profile-256 evidence archive.")
    parser.add_argument("--directory", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--index", action="store_true", help="also compare current source snapshots with Git index bytes")
    args = parser.parse_args()
    directory = Path(os.path.abspath(args.directory))
    repo_abs = Path(os.path.abspath(REPO))
    relative_directory = directory.relative_to(repo_abs)
    cursor = repo_abs
    for part in relative_directory.parts:
        cursor = cursor / part
        if cursor.is_symlink() or getattr(cursor, "is_junction", lambda: False)():
            raise ValueError(f"Evidence directory may not contain a reparse point: {cursor}")
    manifest_path = directory / "manifest.json"
    if manifest_path.is_symlink():
        raise ValueError("Manifest may not be a symlink")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if manifest.get("format") != "campfire-native-profile-evidence-v1":
        raise ValueError("Unrecognized evidence manifest format")
    archive_name = manifest.get("archiveFile")
    if not isinstance(archive_name, str) or Path(archive_name).name != archive_name or BANNED_PATH.search(archive_name):
        raise ValueError("Unsafe archive filename in manifest")
    archive = Path(os.path.abspath(directory / archive_name))
    archive.relative_to(directory)
    if archive.is_symlink():
        raise ValueError("Archive may not be a symlink")
    archive_bytes = archive.read_bytes()
    if digest(archive_bytes) != manifest.get("archiveSha256") or len(archive_bytes) != manifest.get("archiveSizeBytes"):
        raise ValueError("Archive hash or byte count mismatch")
    rows = manifest.get("entries")
    if not isinstance(rows, list) or len(rows) != manifest.get("entryCount"):
        raise ValueError("Manifest entry count mismatch")
    expected = {}
    for row in rows:
        name = row.get("archivePath")
        if not isinstance(name, str):
            raise ValueError("Missing archive path")
        checked_archive_name(name)
        if name in expected:
            raise ValueError(f"Duplicate manifest entry: {name}")
        expected[name] = row
    with zipfile.ZipFile(archive, "r") as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise ValueError("Archive members do not exactly match the manifest")
        for name, row in expected.items():
            data = zf.read(name)
            if len(data) != row.get("sizeBytes") or digest(data) != row.get("sha256"):
                raise ValueError(f"Archive member checksum mismatch: {name}")
        embedded = json.loads(zf.read("evidence-manifest.json").decode("utf-8"))
        if embedded.get("format") != manifest["format"] or embedded.get("profile") != "256":
            raise ValueError("Embedded manifest profile mismatch")
        embedded_rows = embedded.get("entries")
        external_rows = [row for name, row in expected.items() if name != "evidence-manifest.json"]
        if embedded_rows != external_rows:
            raise ValueError("Embedded and external entry inventories disagree")
        source_rows = embedded.get("currentSourceHashes")
        if not isinstance(source_rows, list):
            raise ValueError("Missing current source hash list")
        source_entries = {row["sourcePath"]: row for row in embedded_rows if row.get("kind") == "source"}
        for source in source_rows:
            path = source.get("path")
            expected_hash = source.get("sha256")
            if path not in source_entries or source_entries[path].get("sha256") != expected_hash:
                raise ValueError(f"Current source inventory mismatch: {path}")
            current = Path(os.path.abspath(REPO / Path(path)))
            current.relative_to(repo_abs)
            if digest(current.read_bytes()) != expected_hash:
                raise ValueError(f"Current source changed since sealing: {path}")
            if args.index:
                import subprocess

                staged = subprocess.run(
                    ["git", "show", ":" + path], cwd=REPO, check=True, stdout=subprocess.PIPE
                ).stdout
                if digest(staged) != expected_hash:
                    raise ValueError(f"Git index source changed since sealing: {path}")
    print(json.dumps({"verified": True, "archive": archive.name, "sha256": manifest["archiveSha256"], "entries": len(expected), "currentSources": len(source_rows)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"archive verification failed: {exc}", file=sys.stderr)
        raise SystemExit(1)

# Campfire native execution-profile 256

O2 trusted-generated native room GET; StageProfile On in both arms; execution Off/Detailed ABBA; four workers, fixed four-core host mask, fixed affinity-disjoint client mask, concurrency 16, two 15-second repeats per host, 20 warmups per repeat. The pinned 256 client records latency after the full body arrives and before status/body-digest validation; throughput includes validation.

| Run | Profile | Host GETs | Correct req/s | Median repeat P99 upper bound (ms) | Provider ticks / API ticks |
|---|---|---:|---:|---:|---:|
| OffA | off | 197336 | 6575.71 | 3.546 | — |
| DetailedB | detailed | 203763 | 6789.87 | 3.508 | 49.082119805726 |
| DetailedC | detailed | 205127 | 6835.29 | 3.510 | 48.656659979866156 |
| OffD | off | 206137 | 6868.66 | 3.337 | — |

Combined Detailed throughput change: +1.34%.

## Detailed category means

Per-run category totals and means are in the JSON report. Runtime counters overlap, SQL counters nest inside provider callbacks, and these columns must not be summed into API time.

| Profile | Category | Calls | Failures | Mean µs/call | Calls/host GET |
|---|---|---:|---:|---:|---:|
| DetailedB | reserve_release | 9169335 | 0 | 0.0168 | 45.0000 |
| DetailedB | initialization_check | 770020377 | 0 | 0.0151 | 3779.0000 |
| DetailedB | arena_copy | 4890312 | 0 | 0.0728 | 24.0000 |
| DetailedB | value_measure | 0 | 0 | — | 0.0000 |
| DetailedB | external_measure | 1426341 | 0 | 3.1843 | 7.0000 |
| DetailedB | structural_locate | 8965572 | 0 | 3.8768 | 44.0000 |
| DetailedB | host_output_commit | 1222578 | 0 | 3.2321 | 6.0000 |
| DetailedB | frame_validation | 6724179 | 0 | 0.0170 | 33.0000 |
| DetailedB | other_runtime_validation | 10391913 | 0 | 2.0676 | 51.0000 |
| DetailedB | cookie_verify_session_token | 203763 | 0 | 6.2997 | 1.0000 |
| DetailedB | session_find_by_token | 203763 | 0 | 17.5030 | 1.0000 |
| DetailedB | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedB | user_find_by_id | 203763 | 0 | 5.5463 | 1.0000 |
| DetailedB | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedB | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedB | room_find_for_user | 203763 | 0 | 10.0106 | 1.0000 |
| DetailedB | membership_exists | 203763 | 0 | 4.2885 | 1.0000 |
| DetailedB | message_last_page | 203763 | 0 | 211.6335 | 1.0000 |
| DetailedB | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedB | sql_bind | 1833867 | 0 | 0.2553 | 9.0000 |
| DetailedB | sql_step | 18134907 | 0 | 1.0361 | 89.0000 |
| DetailedB | sql_reset | 16504803 | 0 | 0.1109 | 81.0000 |
| DetailedC | reserve_release | 9230715 | 0 | 0.0169 | 45.0000 |
| DetailedC | initialization_check | 775174933 | 0 | 0.0151 | 3779.0000 |
| DetailedC | arena_copy | 4923048 | 0 | 0.0731 | 24.0000 |
| DetailedC | value_measure | 0 | 0 | — | 0.0000 |
| DetailedC | external_measure | 1435889 | 0 | 3.1856 | 7.0000 |
| DetailedC | structural_locate | 9025588 | 0 | 3.8819 | 44.0000 |
| DetailedC | host_output_commit | 1230762 | 0 | 3.2302 | 6.0000 |
| DetailedC | frame_validation | 6769191 | 0 | 0.0170 | 33.0000 |
| DetailedC | other_runtime_validation | 10461477 | 0 | 2.0697 | 51.0000 |
| DetailedC | cookie_verify_session_token | 205127 | 0 | 6.3561 | 1.0000 |
| DetailedC | session_find_by_token | 205127 | 0 | 17.5637 | 1.0000 |
| DetailedC | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedC | user_find_by_id | 205127 | 0 | 5.5129 | 1.0000 |
| DetailedC | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedC | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedC | room_find_for_user | 205127 | 0 | 9.9853 | 1.0000 |
| DetailedC | membership_exists | 205127 | 0 | 4.2634 | 1.0000 |
| DetailedC | message_last_page | 205127 | 0 | 207.5671 | 1.0000 |
| DetailedC | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedC | sql_bind | 1846143 | 0 | 0.2579 | 9.0000 |
| DetailedC | sql_step | 18256303 | 0 | 1.0372 | 89.0000 |
| DetailedC | sql_reset | 16615287 | 0 | 0.1116 | 81.0000 |

## Interpretation limits

- Stage timing is enabled in both arms; this estimates incremental detailed runtime counter overhead, not host stage-profiler overhead.
- Worker timer sums overlap in wall time; runtime category totals also overlap; SQL intervals are nested within provider callbacks.
- Client p95/p99 values are histogram upper bounds from successful responses only and remain separate from host QPC means/maxima.
- SQLite step time is not lock-wait time. No lock-cause claim is supported by this steady-state workload.
- The pure cookie SRW lock, adapter active-state guard, and internal SQLite/HTTP.sys/CNG synchronization are outside separately timed wait counters; low operation totals do not establish absence of contention.
- This private Windows HTTP.sys workload is not apples-to-apples with the public Rails/Docker benchmark or a WebSocket-capacity test.

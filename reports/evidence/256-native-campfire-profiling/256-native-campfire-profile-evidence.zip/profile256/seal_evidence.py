from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
PRIVATE = REPO / ".agentlang" / "campfire-native-profile-256"
ROOM_TESTS = REPO / ".agentlang" / "campfire-native-room-read-252" / "test-runs"
LLVM_TESTS = REPO / ".agentlang" / "campfire-native-profile-256" / "llvm-regression-report256"
OUTPUT = REPO / "reports" / "evidence" / "256-native-campfire-profiling"
FINAL_VALIDATION_RUNS = {
    ("off", "O0"): "validate-off-o0",
    ("off", "O2"): "validate-off-o2",
    ("detailed", "O0"): "validate-detailed-o0",
    ("detailed", "O2"): "validate-detailed-o2-resumed",
}
DEFAULT_PERF_RUNS = {
    "OffA": "off-a-final",
    "DetailedB": "detailed-b",
    "DetailedC": "detailed-c",
    "OffD": "off-d",
    "OffE": "off-e",
    "DetailedF": "detailed-f",
    "DetailedG": "detailed-g",
    "OffH": "off-h",
}
PERF_PROFILES = {"OffA": "off", "DetailedB": "detailed", "DetailedC": "detailed", "OffD": "off",
                 "OffE": "off", "DetailedF": "detailed", "DetailedG": "detailed", "OffH": "off"}
REPLICATION_RUNS = ("off-e", "detailed-f", "detailed-g", "off-h")
RETAINED_FAILED_RUNS = ("off-a",)
ANALYSIS_FILES = ("profile-analysis-256.json", "profile-analysis-256.md",
                  "profile-analysis-256-set2.json", "profile-analysis-256-set2.md")
EXPECTED_IMPORTS = {"BCRYPT.DLL", "HTTPAPI.DLL", "KERNEL32.DLL", "SHELL32.DLL", "WS2_32.DLL"}
EXPECTED_BODY_SHA256 = "5720b8ab483c40515667e09502d577b4189e0f7fcdc9a4f72d0844144ac41f15"
EXPECTED_OPERATIONS = [
    (1, "campfire.cookies.verify-session-token"),
    (2, "campfire.sessions.find-by-token"),
    (3, "campfire.sessions.refresh-before"),
    (4, "campfire.users.find-by-id"),
    (5, "campfire.users.authenticate-bot-key"),
    (6, "campfire.browser.version-at-least?"),
    (7, "campfire.rooms.find-for-user"),
    (8, "campfire.membership.exists?"),
    (9, "campfire.messages.last-page"),
]
BANNED_PATH = re.compile(r"(?i)(\.sqlite3?(?:-(?:wal|shm|journal))?$|\.db3?$|\.config\.json$|synthetic-secret|private-request|private-measure|\.env$)")
RAW_SECRET = re.compile(
    r"(?im)^\s*(?:cookie|set-cookie|authorization)\s*:|"
    r'"(?:Cookie|CookieHeader|Secret|Password|Authorization)"\s*:\s*"|'
    r"(?:session_token|_campfire_session)\s*=[^\s\";]{16,}"
)


def fail(message: str) -> None:
    raise RuntimeError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return digest(path.read_bytes())


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe_file(path: Path, allowed_root: Path) -> Path:
    path = Path(os.path.abspath(path))
    allowed_root = Path(os.path.abspath(allowed_root))
    try:
        relative = path.relative_to(allowed_root)
    except (OSError, ValueError) as ex:
        fail(f"Input escapes its allowed root or is missing: {path}: {ex}")
    cursor = allowed_root
    for part in relative.parts:
        cursor = cursor / part
        is_junction = getattr(cursor, "is_junction", lambda: False)()
        if cursor.is_symlink() or is_junction:
            fail(f"Symlink input refused: {cursor}")
    if not path.is_file():
        fail(f"Expected file: {path}")
    return path


def require_hash(path: Path, expected: str, context: str) -> None:
    actual = sha_file(path)
    if actual.lower() != str(expected).lower():
        fail(f"SHA-256 mismatch for {context}: expected {expected}, got {actual}")


def check_output_path() -> None:
    cursor = REPO
    for part in OUTPUT.relative_to(REPO).parts:
        cursor = cursor / part
        if cursor.exists() and (cursor.is_symlink() or getattr(cursor, "is_junction", lambda: False)()):
            fail(f"Evidence output path contains a reparse point: {cursor}")


@dataclass
class Entry:
    archive_path: str
    source_path: str
    kind: str
    data: bytes
    sha256: str

    def manifest_row(self) -> dict:
        return {
            "archivePath": self.archive_path,
            "sourcePath": self.source_path,
            "sha256": self.sha256,
            "sizeBytes": len(self.data),
            "kind": self.kind,
        }


class Collector:
    def __init__(self) -> None:
        self.entries: dict[str, Entry] = {}
        self.source_hashes: dict[str, str] = {}

    def add(self, path: Path, archive_path: str, kind: str, allowed_root: Path, scan: bool = False) -> Entry:
        if archive_path.startswith("/") or ".." in Path(archive_path).parts or BANNED_PATH.search(archive_path):
            fail(f"Unsafe archive path refused: {archive_path}")
        if archive_path in self.entries:
            previous = self.entries[archive_path]
            candidate = safe_file(path, allowed_root)
            data = candidate.read_bytes()
            if previous.source_path == candidate.relative_to(REPO).as_posix() and previous.data == data and previous.kind == kind:
                return previous
            fail(f"Conflicting duplicate archive path: {archive_path}")
        resolved = safe_file(path, allowed_root)
        rel = resolved.relative_to(REPO).as_posix()
        if BANNED_PATH.search(rel):
            fail(f"Sensitive or database input refused: {rel}")
        data = resolved.read_bytes()
        if scan:
            text = data.decode("utf-8-sig")
            if RAW_SECRET.search(text):
                fail(f"Possible credential-bearing text refused: {rel}")
        entry = Entry(archive_path, rel, kind, data, digest(data))
        self.entries[archive_path] = entry
        if kind == "source":
            previous = self.source_hashes.setdefault(rel, entry.sha256)
            if previous != entry.sha256:
                fail(f"Source changed while collecting: {rel}")
        return entry

    def add_generated(self, archive_path: str, data: bytes, kind: str = "receipt") -> Entry:
        if archive_path.startswith("/") or ".." in Path(archive_path).parts or archive_path in self.entries:
            fail(f"Unsafe/duplicate generated archive path: {archive_path}")
        entry = Entry(archive_path, "generated:" + archive_path, kind, data, digest(data))
        self.entries[archive_path] = entry
        return entry


def profile_builds(collector: Collector) -> dict[str, dict]:
    # The final O2 validation receipts select the exact artifacts used by the gates.
    selected: dict[str, dict] = {}
    candidates = [safe_file(path, PRIVATE) for path in sorted((PRIVATE / "http-host").glob("build-trusted-generated-*/O2/build-receipt.json"))]
    for profile, run_name in (("off", "validate-off-o2"), ("detailed", "validate-detailed-o2-resumed")):
        run = PRIVATE / "runs" / run_name
        rr = load_json(safe_file(run / "run-receipt.json", PRIVATE))
        if rr.get("terminalExitCode") != 0 or rr.get("executionProfile") != profile or rr.get("optimization") != "O2":
            fail(f"Final validation run did not pass for {profile}: {run_name}")
        wanted_receipt_sha = rr.get("buildReceiptSha256", "").lower()
        matched = []
        for candidate in candidates:
            if sha_file(candidate).lower() == wanted_receipt_sha:
                matched.append(candidate.parent.parent)
        if len(matched) != 1:
            fail(f"Expected one O2 build for {profile} pinned by the final validation receipt; found {len(matched)}")
        root = matched[0]
        build_dir = root / "O2"
        receipt_path = safe_file(build_dir / "build-receipt.json", PRIVATE)
        receipt = load_json(receipt_path)
        if (receipt.get("RuntimeProfile"), receipt.get("ExecutionProfile"), receipt.get("Optimization"), receipt.get("StageProfile")) != (
            "trusted-generated", profile, "O2", "On"
        ):
            fail(f"Unexpected native build profile in {receipt_path}")
        expected_compile_profile = "CAMPFIRE_HTTP_EXECUTION_PROFILE=1" if profile == "detailed" else "CAMPFIRE_HTTP_EXECUTION_PROFILE=0"
        expected_runtime_define = "-DAL_OWNING_DETAILED_PROFILE=1" if profile == "detailed" else "-DAL_OWNING_DETAILED_PROFILE=0"
        if receipt.get("ExecutionProfileGeneratedPin") != expected_compile_profile or receipt.get("ModuleInstrumentationCompileDefine") != expected_runtime_define or receipt.get("HostLocalRuntimeInstrumentation") != "off" or receipt.get("OwningRuntimeCompileDefine") != "-DAL_OWNING_TRUSTED_GENERATED=1":
            fail(f"Unexpected native compile profile pins for {profile}")
        if receipt.get("HostRetainedCapacityBytes") != 4194304 or receipt.get("ModuleOutputLimitBytes") != 16777216:
            fail(f"Unexpected host/module capacity for {profile}")
        for filename, key in (
            ("native_http_host.exe", "HostExeSha256"),
            ("owning-stack-native-host.dll", "ModuleSha256"),
            ("owning-stack-native-host-manifest.json", "ManifestSha256"),
            ("e_sqlite3.dll", "SqliteSha256"),
        ):
            require_hash(safe_file(build_dir / filename, PRIVATE), receipt[key], f"{profile} O2 {filename}")
        require_hash(safe_file(root / "http_host_pins.h", PRIVATE), receipt["GeneratedPinsHeaderSha256"], f"{profile} generated pins")
        manifest = load_json(safe_file(build_dir / "owning-stack-native-host-manifest.json", PRIVATE))
        info = manifest["moduleInfo"]
        if (info.get("profileId"), info.get("operationId"), info.get("operationName"), info.get("adapterSymbol")) != (
            "campfire-room-read-v1", "campfire.http.room-read", "campfire.http.room-read", "al_host_campfire_room_read_v1"
        ):
            fail(f"Unexpected Campfire room-read manifest identity for {profile}")
        if (info.get("runtimeProfile"), info.get("executionProfile"), info.get("optimization")) != ("trusted-generated", profile, "O2"):
            fail(f"Unexpected manifest build profile for {profile}")
        if info.get("inputTypes") != ["CampfireHttpRequest"] or info.get("outputTypes") != ["CampfireHttpResponse"]:
            fail(f"Unexpected entry types for {profile}")
        if info.get("effects") != ["db.read", "db.write"] or info.get("fixedEffectAllowlist") != ["db.read", "db.write"]:
            fail(f"Unexpected effect allowlist for {profile}")
        if (info.get("hostAbiVersion"), info.get("layoutAbiVersion"), info.get("layoutSchemaVersion"), info.get("outputLimitBytes")) != (1, 5, 5, 16777216):
            fail(f"Unexpected ABI or output bound for {profile}")
        actual_ops = [(item.get("tag"), item.get("operationId")) for item in info.get("operations", [])]
        if actual_ops != EXPECTED_OPERATIONS:
            fail(f"Closed host-operation profile changed for {profile}: {actual_ops}")
        imports = {m.group(1).upper() for m in re.finditer(r"(?im)^\s*Name:\s*(\S+)", safe_file(build_dir / "native-imports.txt", PRIVATE).read_text(encoding="utf-8-sig"))}
        receipt_imports = {str(value).upper() for value in receipt.get("Imports", [])}
        if imports != EXPECTED_IMPORTS or receipt_imports != EXPECTED_IMPORTS:
            fail(f"Unexpected native imports for {profile}: {imports or receipt_imports}")
        if any(rr.get(field, "").lower() != receipt[key].lower() for field, key in (("hostExeSha256", "HostExeSha256"), ("moduleSha256", "ModuleSha256"), ("manifestSha256", "ManifestSha256"), ("sqliteSha256", "SqliteSha256"))):
            fail(f"Validation run artifacts disagree with selected {profile} build")
        selected[profile] = {"root": root, "buildDir": build_dir, "receipt": receipt, "manifest": manifest, "run": run}

    # Both builds must be from the same source freeze; add every pinned tracked source once.
    all_pins: dict[str, str] = {}
    for profile, build in selected.items():
        pin_path = safe_file(build["root"] / "source-pins.json", PRIVATE)
        pins = load_json(pin_path)
        for source, expected in pins.items():
            if source == "generated/http_host_pins.h":
                continue
            old = all_pins.setdefault(source, str(expected).lower())
            if old != str(expected).lower():
                fail(f"Off/Detailed source-freeze disagreement for {source}")
            path = safe_file(REPO / Path(source), REPO)
            require_hash(path, expected, f"source pin {source}")
            collector.add(path, "sources/" + Path(source).as_posix(), "source", REPO)
        collector.add(pin_path, f"build/{profile}/source-pins.json", "receipt", PRIVATE, scan=True)
        generated = safe_file(build["root"] / "http_host_pins.h", PRIVATE)
        collector.add(generated, f"build/{profile}/http_host_pins.h", "generated-source", PRIVATE)
        for name in ("build-receipt.json", "native_http_host.exe", "owning-stack-native-host.dll", "owning-stack-native-host-manifest.json", "e_sqlite3.dll", "native-imports.txt"):
            p = safe_file(build["buildDir"] / name, PRIVATE)
            collector.add(p, f"build/{profile}/O2/{name}", "artifact" if p.suffix.lower() in {".exe", ".dll"} else "receipt", PRIVATE, scan=p.suffix.lower() in {".json", ".txt"})
    return selected


def validate_room_tests(collector: Collector, builds: dict[str, dict]) -> None:
    for profile in ("off", "detailed"):
        module_hash = builds[profile]["receipt"]["ModuleSha256"].lower()
        candidates = []
        for root in ROOM_TESTS.glob("20261013T256*-final-*"):
            receipt_path = root / "test-receipt.json"
            if not receipt_path.is_file():
                continue
            receipt = load_json(receipt_path)
            if receipt.get("passed") and receipt.get("executionProfile") == profile and receipt.get("runtimeProfile") == "trusted-generated" and receipt.get("artifactsSha256", {}).get("O2/dll", "").lower() == module_hash:
                candidates.append((root, receipt))
        if len(candidates) != 1:
            fail(f"Expected one passing final room-read test receipt for {profile}; found {len(candidates)}")
        root, receipt = candidates[0]
        freeze_path = safe_file(root / "test-source-freeze.json", ROOM_TESTS)
        freeze = load_json(freeze_path)
        if not freeze.get("stable") or freeze.get("changedFiles"):
            fail(f"Room-read source freeze is unstable for {profile}")
        if str(freeze.get("runtimeProfile", "")).lower() != "trustedgenerated" or str(freeze.get("executionProfile", "")).lower() != profile:
            fail(f"Room-read source freeze profile mismatch for {profile}")
        for source, before in freeze.get("before", {}).items():
            after = freeze.get("after", {}).get(source)
            if before != after:
                fail(f"Room-read source changed during gate: {source}")
            path = safe_file(REPO / source, REPO)
            require_hash(path, before, f"room-read source freeze {source}")
            collector.add(path, "sources/" + Path(source).as_posix(), "source", REPO)
        art = receipt.get("artifactsSha256", {})
        for key, filename in (("O2/dll", "owning-stack-native-host.dll"), ("O2/manifest", "owning-stack-native-host-manifest.json"), ("O2/sqlite", "e_sqlite3.dll")):
            if art.get(key, "").lower() != builds[profile]["receipt"][{"O2/dll":"ModuleSha256","O2/manifest":"ManifestSha256","O2/sqlite":"SqliteSha256"}[key]].lower():
                fail(f"Room-read test artifact {key} does not match selected {profile} build")
        smoke = safe_file(root / "test-smoke" / "O2" / "room_read_standalone_smoke.exe", ROOM_TESTS)
        require_hash(smoke, art["O2/smoke-exe"], f"{profile} no-CLR smoke executable")
        selected_build_receipt = builds[profile]["receipt"]
        if selected_build_receipt.get("ProvenanceMode") != "fresh-validation-receipt" or selected_build_receipt.get("ValidationReceiptSha256", "").lower() != sha_file(root / "test-receipt.json").lower() or selected_build_receipt.get("ValidationSourceFreezeSha256", "").lower() != sha_file(freeze_path).lower():
            fail(f"Selected O2 compiler artifact does not cite this room-read receipt/freeze: {profile}")
        for name in ("test-receipt.json", "test-source-freeze.json", "test-build.log", "test-run.log", "test-room-read-adapter-aggregator.c"):
            path = safe_file(root / name, ROOM_TESTS)
            collector.add(path, f"room-read-tests/{profile}/{name}", "receipt" if name.endswith((".json", ".log")) else "source", ROOM_TESTS, scan=name.endswith((".json", ".log")))
        collector.add(smoke, f"room-read-tests/{profile}/O2/room_read_standalone_smoke.exe", "artifact", ROOM_TESTS)


def validate_http_receipts(collector: Collector) -> None:
    seen = set()
    for directory in sorted((PRIVATE / "http-validation").iterdir()):
        receipt_path = directory / "validation-receipt.json"
        if not receipt_path.is_file():
            continue
        receipt = load_json(safe_file(receipt_path, PRIVATE))
        profile = str(receipt.get("executionProfile", "")).lower()
        opt = str(receipt.get("optimization", ""))
        pair = (profile, opt)
        if pair not in FINAL_VALIDATION_RUNS or pair in seen:
            fail(f"Unexpected or duplicate HTTP validation tuple {pair}")
        if receipt.get("runName") != FINAL_VALIDATION_RUNS[pair] or receipt.get("corpusCases") != 20:
            fail(f"Unexpected final HTTP validation receipt {directory.name}")
        cookie = load_json(safe_file(directory / "cookie-header-redacted-receipt.json", PRIVATE))
        if cookie.get("result") != "pass" or cookie.get("requestCount") != 12 or cookie.get("assertions") != 291 or cookie.get("invalidExpiresWeekdays"):
            fail(f"Cookie parity receipt failed or changed: {directory.name}")
        corpus_path = safe_file(directory / "http-corpus.json", PRIVATE)
        corpus = load_json(corpus_path)
        if not isinstance(corpus, list) or len(corpus) != 20 or any(row.get("status") != row.get("expectedStatus") for row in corpus):
            fail(f"HTTP corpus mismatch: {directory.name}")
        cookie_path = safe_file(directory / "cookie-header-redacted-receipt.json", PRIVATE)
        if sha_file(cookie_path).lower() != receipt.get("checkerReceiptSha256", "").lower():
            fail(f"Cookie checker receipt hash mismatch: {directory.name}")
        if sha_file(corpus_path).lower() != receipt.get("corpusSha256", "").lower():
            fail(f"HTTP corpus hash mismatch: {directory.name}")
        checker_dll = PRIVATE / "http-checker-artifacts" / "bin" / "AgentLang.Campfire.NativeHttp.Tests" / "release" / "AgentLang.Campfire.NativeHttp.Tests.dll"
        if not receipt.get("checkerSha256") or receipt["checkerSha256"].lower() != sha_file(safe_file(checker_dll, PRIVATE)).lower():
            fail(f"HTTP checker binary pin mismatch: {directory.name}")
        for name in ("validation-receipt.json", "cookie-header-redacted-receipt.json", "http-corpus.json"):
            p = safe_file(directory / name, PRIVATE)
            collector.add(p, f"http-validation/{directory.name}/{name}", "receipt", PRIVATE, scan=True)
        transport = directory / "transport-limits.json"
        if transport.exists():
            transport_path = safe_file(transport, PRIVATE)
            data = load_json(transport_path)
            if data.get("passed") is not True or len(data.get("cases", [])) != 5 or any(case.get("passed") is not True for case in data["cases"]):
                fail(f"Transport-limit receipt failed: {directory.name}")
            if sha_file(transport_path).lower() != str(receipt.get("transportReceiptSha256", "")).lower():
                fail(f"Transport receipt hash mismatch: {directory.name}")
            collector.add(transport, f"http-validation/{directory.name}/transport-limits.json", "receipt", PRIVATE, scan=True)
        elif opt == "O2":
            fail(f"O2 HTTP validation lacks transport-limit receipt: {directory.name}")
        run = PRIVATE / "runs" / receipt["runName"]
        run_receipt_path = safe_file(run / "run-receipt.json", PRIVATE)
        run_receipt = load_json(run_receipt_path)
        if run_receipt.get("terminalExitCode") != 0 or run_receipt.get("fatalStatus") != 0 or run_receipt.get("executionProfile") != profile or run_receipt.get("optimization") != opt:
            fail(f"HTTP host run did not pass for {directory.name}")
        build_receipt_path = safe_file(run / "build-receipt.json", PRIVATE)
        if sha_file(build_receipt_path).lower() != run_receipt.get("buildReceiptSha256", "").lower():
            fail(f"HTTP build receipt hash mismatch: {directory.name}")
        host_log_path = safe_file(run / "native-host.log", PRIVATE)
        if sha_file(host_log_path).lower() != run_receipt.get("nativeHostLogSha256", "").lower():
            fail(f"HTTP host log hash mismatch: {directory.name}")
        for name in ("build-receipt.json", "run-receipt.json", "native-host.log", "native-host.stderr.log", "fixture-refresh.json", "fixture-postrun.json"):
            p = run / name
            if p.exists():
                collector.add(safe_file(p, PRIVATE), f"http-validation/{directory.name}/host-run/{name}", "receipt", PRIVATE, scan=True)
        seen.add(pair)
    if seen != set(FINAL_VALIDATION_RUNS):
        fail(f"Missing final HTTP validation tuples: {set(FINAL_VALIDATION_RUNS) - seen}")


def validate_client_and_probe(collector: Collector, builds: dict[str, dict]) -> None:
    client_pins_path = safe_file(PRIVATE / "client-source-pins.json", PRIVATE)
    pins = load_json(client_pins_path)
    source = safe_file(REPO / pins["sourcePath"], REPO)
    binary = safe_file(REPO / pins["binaryPath"], REPO)
    build_log = safe_file(PRIVATE / "client-build.log", PRIVATE)
    require_hash(source, pins["sourceSha256"], "HTTP measure client source")
    require_hash(binary, pins["binarySha256"], "HTTP measure client binary")
    require_hash(build_log, pins["buildLogSha256"], "HTTP measure client build log")
    if pins.get("buildExitCode") != 0 or pins.get("selfTestExitCode") != 0:
        fail("Pinned HTTP measurement client did not pass its build/self-test")
    collector.add(source, "client/Program.cs", "source", REPO)
    collector.add(client_pins_path, "client/source-pins.json", "receipt", PRIVATE, scan=True)
    collector.add(build_log, "client/build.log", "receipt", PRIVATE, scan=True)
    collector.add(binary, "client/HttpMeasure.dll", "artifact", REPO)
    pdb = binary.with_suffix(".pdb")
    pdb = safe_file(pdb, REPO)
    collector.add(pdb, "client/HttpMeasure.pdb", "artifact", REPO)
    pins_artifact = {
        "format": "campfire-native-profile-256-client-artifact-pins-v1",
        "source": {"path": pins["sourcePath"], "sha256": pins["sourceSha256"]},
        "binary": {"path": pins["binaryPath"], "sha256": pins["binarySha256"]},
        "pdb": {"path": pdb.relative_to(REPO).as_posix(), "sha256": sha_file(pdb), "sizeBytes": pdb.stat().st_size},
        "buildLogSha256": pins["buildLogSha256"],
    }
    collector.add_generated("client/artifact-pins.json", (json.dumps(pins_artifact, indent=2, sort_keys=True) + "\n").encode())
    probe = load_json(safe_file(PRIVATE / "profile-api-probe-results.json", PRIVATE))
    if probe.get("passed") is not True:
        fail("Native profiler API probe did not pass")
    for profile, entry in (("off", probe["dlls"]["off"]), ("detailed", probe["dlls"]["detailed"])):
        if entry["sha256"].lower() != builds[profile]["receipt"]["ModuleSha256"].lower():
            fail(f"Profiler API probe module pin disagrees for {profile}")
    for name in ("profile-api-probe.py", "profile-api-probe.log", "profile-api-probe-results.json"):
        collector.add(safe_file(PRIVATE / name, PRIVATE), f"profiler-api/{name}", "source" if name.endswith(".py") else "receipt", PRIVATE, scan=not name.endswith(".py"))


def validate_full_llvm(collector: Collector) -> None:
    receipt_path = safe_file(LLVM_TESTS / "full-suite-receipt.json", REPO)
    receipt = load_json(receipt_path)
    if receipt.get("status") != "pass" or receipt.get("terminalExitCode") != 0 or not isinstance(receipt.get("assertions"), int):
        fail("Full LLVM suite receipt is not a passing terminal run")
    output_path = safe_file(LLVM_TESTS / "full-suite-captured-session-output.log", REPO)
    build = LLVM_TESTS / "build" / "bin" / "AgentLang.Llvm.Tests" / "release"
    file_set = [
        (build / "AgentLang.Llvm.Tests.dll", "AgentLang.Llvm.Tests.dll"),
        (build / "AgentLang.Llvm.Tests.exe", "AgentLang.Llvm.Tests.exe"),
        (build / "AgentLang.Llvm.Tests.pdb", "AgentLang.Llvm.Tests.pdb"),
        (build / "AgentLang.Llvm.Tests.deps.json", "AgentLang.Llvm.Tests.deps.json"),
        (build / "AgentLang.Llvm.Tests.runtimeconfig.json", "AgentLang.Llvm.Tests.runtimeconfig.json"),
        (build / "AgentLang.Core.dll", "AgentLang.Core.dll"),
        (build / "AgentLang.Core.pdb", "AgentLang.Core.pdb"),
        (build / "AgentLang.Llvm.dll", "AgentLang.Llvm.dll"),
        (build / "AgentLang.Llvm.pdb", "AgentLang.Llvm.pdb"),
        (build / "FSharp.Core.dll", "FSharp.Core.dll"),
    ]
    test_dll = safe_file(file_set[0][0], REPO)
    require_hash(test_dll, receipt["testAssemblySha256"], "full LLVM test assembly")
    pins = []
    for path, name in file_set:
        f = safe_file(path, REPO)
        pins.append({"path": f.relative_to(REPO).as_posix(), "sha256": sha_file(f), "sizeBytes": f.stat().st_size})
        collector.add(f, f"llvm-full-suite/{name}", "artifact" if f.suffix.lower() in {".dll", ".exe"} else "receipt", REPO, scan=f.suffix.lower() == ".json")
    collector.add(receipt_path, "llvm-full-suite/full-suite-receipt.json", "receipt", REPO, scan=True)
    collector.add(output_path, "llvm-full-suite/full-suite-captured-session-output.log", "receipt", REPO, scan=True)
    generated = {
        "format": "campfire-native-profile-256-llvm-artifact-pins-v1",
        "suite": receipt["suite"],
        "assertions": receipt["assertions"],
        "testAssemblySha256": receipt["testAssemblySha256"],
        "artifacts": pins,
        "historicalSourcePins": receipt.get("sourceHashes", []),
        "sourcePinNote": "The embedded full-suite receipt is authoritative for its historical source hashes; current native-host sources are pinned separately by the selected O2 source freezes.",
    }
    collector.add_generated("llvm-full-suite/artifact-pins.json", (json.dumps(generated, indent=2) + "\n").encode())


def validate_private_inputs(collector: Collector) -> None:
    explicit = [
        "README.md", "analysis-plan.md", "room-workload-comparison.md", "aggregate_profiles.py",
        "Apply-Affinity.ps1", "Measure.ps1", "Run-Host.ps1", "Validate-Http.ps1", "Refresh-Fixture.ps1", "refresh_fixture.py",
        "client-build.log", "host-build-off.log", "host-build-detailed.log", "http-checker-build.log", "http-checker-build-host.log",
        "reference-build.log", "reference-build-host.log",
        "reference-validation-1.log", "reference-validation-2.log", "reference-validation-3.log", "reference-validation-4.log", "reference-validation-resumed.log",
        "seal_evidence.py", "verify_archive.py",
        "Run-Cycle.ps1", "replication-screen.md", "replication-screen-results.txt", "aggregator-revision.md",
        "qpc-cost/qpc_cost.c", "qpc-cost/qpc-cost-output.txt", "make_llvm_receipt.py",
        "llvm-regression-report256/build.log",
    ]
    for name in explicit:
        p = safe_file(PRIVATE / name, PRIVATE)
        collector.add(p, f"profile256/{name}", "source" if p.suffix.lower() in {".py", ".ps1", ".c"} else "receipt", PRIVATE, scan=p.suffix.lower() not in {".py", ".ps1", ".c"})
    for run in REPLICATION_RUNS:
        for name in ("driver.log", "processes-before.json", "processes-after.json", "run-host.out.log", "run-host.err.log"):
            p = safe_file(PRIVATE / "replication-driver" / run / name, PRIVATE)
            collector.add(p, f"replication-driver/{run}/{name}", "receipt", PRIVATE, scan=True)
    for run in RETAINED_FAILED_RUNS:
        root = PRIVATE / "runs" / run
        for p in sorted(root.iterdir()):
            if p.is_file():
                collector.add(safe_file(p, PRIVATE), f"performance-retained-failed/{run}/{p.name}", "receipt", PRIVATE, scan=True)
    topology = REPO / ".agentlang" / "campfire-native-profile-255" / "topology.json"
    if topology.exists():
        collector.add(safe_file(topology, REPO), "profile256/topology.json", "receipt", REPO, scan=True)
    for name in ANALYSIS_FILES:
        path = PRIVATE / name
        if path.exists():
            collector.add(safe_file(path, PRIVATE), f"profile256/{name}", "receipt", PRIVATE, scan=True)
    collector.add(safe_file(PRIVATE / "reference-project" / "dictionary.agent", PRIVATE), "reference/dictionary.agent", "source", PRIVATE)

    checker_source_dir = REPO / "tests" / "AgentLang.Campfire.NativeHttp.Tests"
    for name in ("AgentLang.Campfire.NativeHttp.Tests.fsproj", "Program.fs"):
        path = safe_file(checker_source_dir / name, REPO)
        collector.add(path, f"sources/tests/AgentLang.Campfire.NativeHttp.Tests/{name}", "source", REPO)
    checker = PRIVATE / "http-checker-artifacts" / "bin" / "AgentLang.Campfire.NativeHttp.Tests" / "release"
    cookie_library = PRIVATE / "http-checker-artifacts" / "bin" / "AgentLang.Campfire.Cookies" / "release"
    for name in (
        "AgentLang.Campfire.NativeHttp.Tests.dll", "AgentLang.Campfire.NativeHttp.Tests.exe",
        "AgentLang.Campfire.NativeHttp.Tests.pdb", "AgentLang.Campfire.NativeHttp.Tests.deps.json",
        "AgentLang.Campfire.NativeHttp.Tests.runtimeconfig.json", "FSharp.Core.dll",
    ):
        path = safe_file(checker / name, PRIVATE)
        collector.add(path, f"http-checker/{name}", "artifact" if path.suffix.lower() in {".dll", ".exe"} else "receipt", PRIVATE, scan=path.suffix.lower() == ".json")
    for name in ("AgentLang.Campfire.Cookies.dll", "AgentLang.Campfire.Cookies.pdb", "AgentLang.Campfire.Cookies.deps.json"):
        path = safe_file(cookie_library / name, PRIVATE)
        collector.add(path, f"http-checker/{name}", "artifact" if path.suffix.lower() == ".dll" else "receipt", PRIVATE, scan=path.suffix.lower() == ".json")
    build_log = safe_file(PRIVATE / "http-checker-build-host.log", PRIVATE)
    if "Build succeeded." not in build_log.read_text(encoding="utf-8-sig"):
        fail("Successful HTTP checker build log is missing its success marker")
    collector.add(build_log, "http-checker/build.log", "receipt", PRIVATE, scan=True)


def parse_runs(values: list[str] | None) -> dict[str, str]:
    result = dict(DEFAULT_PERF_RUNS) if not values else {}
    for value in values or []:
        if "=" not in value:
            fail(f"Run must have LABEL=FOLDER form: {value}")
        label, folder = value.split("=", 1)
        if label not in DEFAULT_PERF_RUNS or label in result:
            fail(f"Unknown or duplicate performance label: {label}")
        if Path(folder).name != folder or folder in (".", ".."):
            fail(f"Performance folder must be one directory name: {folder}")
        result[label] = folder
    if set(result) != set(DEFAULT_PERF_RUNS):
        fail("Sealing requires exactly the two OffA-OffD and OffE-OffH ABBA sets")
    return result


def validate_performance_runs(collector: Collector, builds: dict[str, dict], runs: dict[str, str]) -> None:
    profiles = PERF_PROFILES
    for label, folder in runs.items():
        root = safe_file(PRIVATE / "runs" / folder / "run-receipt.json", PRIVATE).parent
        receipt = load_json(root / "run-receipt.json")
        if receipt.get("terminalExitCode") != 0 or receipt.get("fatalStatus") != 0 or receipt.get("executionProfile") != profiles[label] or receipt.get("optimization") != "O2" or receipt.get("runtimeProfile") != "trusted-generated":
            fail(f"Performance run did not terminate cleanly with expected profile: {label}/{folder}")
        if receipt.get("workerCleanupLine") != receipt.get("workers") or receipt.get("workers") != 4:
            fail(f"Performance run worker cleanup mismatch: {label}/{folder}")
        build_receipt_path = safe_file(root / "build-receipt.json", PRIVATE)
        build_receipt = load_json(build_receipt_path)
        if sha_file(build_receipt_path).lower() != receipt.get("buildReceiptSha256", "").lower():
            fail(f"Performance build-receipt hash mismatch: {label}/{folder}")
        if sha_file(root / "native-host.log").lower() != receipt.get("nativeHostLogSha256", "").lower():
            fail(f"Performance native host log hash mismatch: {label}/{folder}")
        if receipt.get("moduleSha256", "").lower() != builds[profiles[label]]["receipt"]["ModuleSha256"].lower():
            fail(f"Performance run used an unexpected native module: {label}/{folder}")
        selected_receipt = builds[profiles[label]]["receipt"]
        if any(
            receipt.get(field, "").lower() != selected_receipt[key].lower()
            for field, key in (("hostExeSha256", "HostExeSha256"), ("manifestSha256", "ManifestSha256"), ("sqliteSha256", "SqliteSha256"))
        ):
            fail(f"Performance run artifact hashes disagree with selected build: {label}/{folder}")
        if build_receipt.get("ExecutionProfile") != profiles[label] or build_receipt.get("RuntimeProfile") != "trusted-generated":
            fail(f"Performance copied build receipt mismatch: {label}/{folder}")
        summary = load_json(safe_file(root / "measurement-summary.json", PRIVATE))
        if summary.get("runName") != folder or summary.get("executionProfile") != profiles[label] or summary.get("repeats") != 2 or summary.get("concurrency") != 16:
            fail(f"Performance summary configuration mismatch: {label}/{folder}")
        client_pins = load_json(safe_file(PRIVATE / "client-source-pins.json", PRIVATE))
        if summary.get("clientSourceSha256", "").lower() != client_pins["sourceSha256"].lower() or summary.get("clientBinarySha256", "").lower() != client_pins["binarySha256"].lower() or summary.get("clientBuildLogSha256", "").lower() != client_pins["buildLogSha256"].lower():
            fail(f"Performance client provenance mismatch: {label}/{folder}")
        if summary.get("expectedBodySha256", "").lower() != EXPECTED_BODY_SHA256:
            fail(f"Performance expected-body pin mismatch: {label}/{folder}")
        if len(summary.get("results", [])) != 2 or any(row.get("failures") != 0 or row.get("errors") or row.get("correctResponses", 0) <= 0 for row in summary["results"]):
            fail(f"Performance summary contains failures: {label}/{folder}")
        post = load_json(safe_file(root / "fixture-postrun.json", PRIVATE))
        if post.get("unchanged") is not True or any(not row.get("unchanged") for row in post.get("rows", [])):
            fail(f"Fixture changed during performance run: {label}/{folder}")
        for name in ("run-start.json", "affinity-start.json", "affinity-receipt.json", "build-receipt.json", "run-receipt.json", "host-process.json", "fixture-refresh.json", "fixture-postrun.json", "native-host.log", "native-host.stderr.log", "measurement-summary.json"):
            path = root / name
            if path.exists():
                collector.add(safe_file(path, PRIVATE), f"performance/{label}/{name}", "receipt", PRIVATE, scan=True)
        client = root / "client"
        for repeat in (1, 2):
            for suffix in ("result.json", "client.log"):
                path = safe_file(client / f"repeat-{repeat}.{suffix}", PRIVATE)
                collector.add(path, f"performance/{label}/repeat-{repeat}.{suffix}", "receipt", PRIVATE, scan=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate or seal sanitized Campfire profile-256 evidence.")
    parser.add_argument("--seal", action="store_true", help="create the immutable archive; omitted means preflight only")
    parser.add_argument("--run", action="append", help="performance root as LABEL=FOLDER (repeat 4 times when sealing)")
    args = parser.parse_args()
    if not PRIVATE.is_dir():
        fail(f"Missing evidence root: {PRIVATE}")
    collector = Collector()
    builds = profile_builds(collector)
    validate_room_tests(collector, builds)
    validate_http_receipts(collector)
    validate_client_and_probe(collector, builds)
    validate_full_llvm(collector)
    validate_private_inputs(collector)
    if args.seal:
        runs = parse_runs(args.run)
        validate_performance_runs(collector, builds, runs)
        check_output_path()
        if OUTPUT.exists():
            fail(f"Immutable evidence output already exists: {OUTPUT}")
        report_files = [PRIVATE / name for name in ANALYSIS_FILES]
        if not all(path.is_file() for path in report_files):
            fail("Final aggregated profile-analysis.json and .md must exist before sealing")
        sources_before = {}
        for path, expected in collector.source_hashes.items():
            actual = sha_file(REPO / path)
            if actual != expected:
                fail(f"Source changed after collection: {path}")
            sources_before[path] = actual
        entries = [entry.manifest_row() for entry in sorted(collector.entries.values(), key=lambda x: x.archive_path)]
        metadata = {
            "format": "campfire-native-profile-evidence-v1",
            "profile": "256",
            "selectedProfiles": {name: {"executionProfile": name, "runtimeProfile": "trusted-generated", "optimization": "O2", "moduleSha256": builds[name]["receipt"]["ModuleSha256"]} for name in ("off", "detailed")},
            "performanceRuns": runs,
            "entries": entries,
            "currentSourceHashes": [{"path": path, "sha256": value} for path, value in sorted(collector.source_hashes.items())],
            "excluded": ["SQLite fixtures and WAL/SHM files", "secrets and signed cookies", "request/measurement configs", "raw HTTP headers and response bodies"],
        }
        embedded = (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode("utf-8")
        output = OUTPUT
        output.parent.mkdir(parents=True, exist_ok=True)
        output.mkdir()
        archive = output / "256-native-campfire-profile-evidence.zip"
        try:
            with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
                for entry in sorted(collector.entries.values(), key=lambda x: x.archive_path):
                    zf.writestr(entry.archive_path, entry.data)
                zf.writestr("evidence-manifest.json", embedded)
            ext_entries = entries + [{"archivePath": "evidence-manifest.json", "sourcePath": "generated:evidence-manifest.json", "sha256": digest(embedded), "sizeBytes": len(embedded), "kind": "receipt"}]
            external = {
                "format": metadata["format"],
                "archiveFile": archive.name,
                "archiveSha256": sha_file(archive),
                "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(ext_entries),
                "entries": ext_entries,
            }
            manifest_path = output / "manifest.json"
            manifest_path.write_text(json.dumps(external, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            for path, expected in sources_before.items():
                if sha_file(REPO / path) != expected:
                    fail(f"Source changed during archive creation: {path}")
            for entry in collector.entries.values():
                if entry.kind == "source" and sha_file(REPO / entry.source_path) != entry.sha256:
                    fail(f"Source changed during archive creation: {entry.source_path}")
        except Exception:
            # Preserve any partially written output for forensic review; never overwrite it.
            raise
        print(json.dumps({"sealed": True, "archive": archive.relative_to(REPO).as_posix(), "sha256": external["archiveSha256"], "sizeBytes": external["archiveSizeBytes"], "entries": len(ext_entries), "currentSources": len(collector.source_hashes)}, sort_keys=True))
    else:
        print(json.dumps({"preflight": "pass", "profiles": sorted(builds), "httpValidationTuples": 4, "roomReadProfiles": 2, "sourcePins": len(collector.source_hashes), "selectedNativeO2Artifacts": 2, "archiveWritten": False}, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"evidence preflight/seal failed: {exc}", file=sys.stderr)
        raise SystemExit(1)

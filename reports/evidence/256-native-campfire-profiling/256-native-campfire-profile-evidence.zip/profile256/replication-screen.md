# Replication set 2: contamination screen (written before collection)

Written 2026-10-13 before any `off-e`/`detailed-f`/`detailed-g`/`off-h` host started.
Bands come from the three first-set runs that kept the server saturated
(OffA, DetailedB, OffD). DetailedC is retained in all tables; it fails this screen.

A run is flagged "environment-contaminated" (reported, never deleted) if any holds:

1. Mean server CPU-equivalent cores across its two repeats < 3.75
   (set-1 clean range 3.81-3.89; DetailedC 3.47).
2. `send_api` mean > 60 µs per host GET (set-1 clean range 39.6-46.0; DetailedC 80.3).
3. Either repeat's correct req/s differs from the other repeat by > 5%.

Observed new process starts during each host lifetime are recorded by the driver
as context only; they are not proof of cause.

Overhead estimate: use in-host `api_execute` µs/GET and throughput for each
adjacent Off/Detailed pair among unflagged runs, with the Off-vs-Off difference in
the same set reported as the drift floor. No result below that floor is claimed.

Toolchain note: set 2 runs the byte-identical helpers under PowerShell 7.6.6
(MSIX, installed 2026-10-13 because no pwsh was reachable from this session).
The first set's PowerShell version is not recorded in its receipts.

#!/usr/bin/env python3
"""Write full-suite-receipt.json for the report-256 LLVM regression run."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / ".agentlang" / "campfire-native-profile-256" / "llvm-regression-report256"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    build_log = (ROOT / "build.log").read_text(encoding="utf-8-sig")
    run_log_path = ROOT / "run.log"
    run_log = run_log_path.read_text(encoding="utf-8-sig")
    if "build-exit=0" not in build_log or not re.search(r"(?m)^\s*0 Warning\(s\)", build_log) or not re.search(r"(?m)^\s*0 Error\(s\)", build_log):
        raise SystemExit("build did not finish cleanly with zero warnings/errors")
    if "run-exit=0" not in run_log:
        raise SystemExit("suite did not exit 0")
    match = re.search(r"AgentLang\.Llvm\.Tests: (\d+) assertions passed", run_log)
    if not match:
        raise SystemExit("suite assertion summary missing")
    test_dll = ROOT / "build" / "bin" / "AgentLang.Llvm.Tests" / "release" / "AgentLang.Llvm.Tests.dll"
    tracked = subprocess.run(["git", "ls-files", "src", "tests/AgentLang.Llvm.Tests"], cwd=REPO, check=True,
                             capture_output=True, text=True).stdout.split()
    extra = ["src/AgentLang.Llvm/native/owning_stack_profile.h"]
    sources = sorted(set(tracked) | {p for p in extra if (REPO / p).is_file()})
    receipt = {
        "suite": "AgentLang.Llvm.Tests full suite",
        "status": "pass",
        "terminalExitCode": 0,
        "assertions": int(match.group(1)),
        "buildCommand": "dotnet build tests/AgentLang.Llvm.Tests/AgentLang.Llvm.Tests.fsproj --artifacts-path .agentlang/campfire-native-profile-256/llvm-regression-report256/build --configuration Release --verbosity minimal -p:NuGetAudit=false -m:1",
        "runCommand": "dotnet .agentlang/campfire-native-profile-256/llvm-regression-report256/build/bin/AgentLang.Llvm.Tests/release/AgentLang.Llvm.Tests.dll --artifacts-path .agentlang/campfire-native-profile-256/llvm-regression-report256/full-suite-artifacts",
        "testAssemblySha256": sha(test_dll),
        "buildLogSha256": sha(ROOT / "build.log"),
        "outputCapture": "redirected stdout/stderr of the run command",
        "sourceHashes": [{"path": p, "sha256": sha(REPO / p)} for p in sources if (REPO / p).is_file()],
    }
    (ROOT / "full-suite-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    shutil.copyfile(run_log_path, ROOT / "full-suite-captured-session-output.log")
    print(json.dumps({"assertions": receipt["assertions"], "sources": len(receipt["sourceHashes"])}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

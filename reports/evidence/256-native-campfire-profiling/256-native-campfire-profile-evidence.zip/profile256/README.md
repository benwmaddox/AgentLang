# Campfire execution-profile 256 helpers

These private scripts support one controlled O2 `Off, Detailed, Detailed, Off` run order. They never start an interpreter or reference listener. `Run-Host.ps1` starts only the native HTTP.sys host and writes `host-process.json` before it begins streaming the live host log; the caller owns applying affinity, driving the client, and signalling `Local\CampfireNative256Stop`.

## Pre-run checks

Build four O0/O2 combinations (`Off` and `Detailed`) from the same room-read source freeze with stage profiling enabled. Run `Validate-Http.ps1` on a disposable host lifetime for each combination before collecting performance data. Every supplied build directory must be inside this private 256 directory and its receipt, manifest and copied artifacts must match exactly. The two synthetic SQLite copies are refreshed with the build's hash-pinned SQLite 3.53.3 before each host process starts; this helper updates only `sessions.id=70,user_id=7`, closes both connections, and writes timestamp/count metadata without tokens. After a clean host shutdown, `Run-Host.ps1` opens both DBs read-only and verifies that `last_active_at` and `updated_at` still match the pre-run timestamp; the aggregator requires the post-run receipt.

## One host/sample cycle

Start each host in its own PowerShell 7 session, for example:

```powershell
pwsh -NoProfile -File .agentlang/campfire-native-profile-256/Run-Host.ps1 `
  -BuildDirectory .agentlang/campfire-native-profile-256/http-host/BUILD-ID/O2 `
  -RunName off-a -ExecutionProfile Off -Optimization O2 -Workers 4
```

Once `host-process.json` exists and the log contains `READY`, pin the recorded PID with `Apply-Affinity.ps1`. Then run `Measure.ps1` with that run name, profile, and PID's fixed workload. The helper runs two 15-second repeats with 16 clients and 20 warmups each, verifies every response through the pinned client, and writes no cookie-bearing config into the run root. Verify affinity again with `Apply-Affinity.ps1 -After`, signal the host stop event, and wait for a zero exit plus four clean workers. Repeat with labels `off-a`, `detailed-b`, `detailed-c`, `off-d`, using the corresponding receipts. Do not refresh either DB while its server is live.

After all four run receipts are terminal, aggregate without starting listeners:

```powershell
python .agentlang/campfire-native-profile-256/aggregate_profiles.py `
  --run OffA=off-a --run DetailedB=detailed-b --run DetailedC=detailed-c --run OffD=off-d
```

The aggregator fails closed on profile ABI/log shape, worker cleanup, zero-error client contracts, request accounting, body-hash consistency, fixture freshness, source/build provenance, or CPU affinity. It keeps runtime counter totals, provider callback time, SQL time, HTTP stage time, client latency and process CPU in separate views because the intervals overlap and have different scopes. It reports per-repeat P95/P99 histogram upper bounds and does not synthesize a pooled percentile from them.

`Measure.ps1` uses the separately pinned 256 client build, not the historical 255 fixed-client artifact. Its latency sample ends after the complete body arrives and before response status/body-digest validation; throughput still includes validation. The aggregator rechecks the client source, build log, binary, self-test status, and this timing-boundary label.

Run-root outputs are private. Do not publish or archive fixture DBs, WAL/SHM files, secret files, private configs, request headers, or cookie values.

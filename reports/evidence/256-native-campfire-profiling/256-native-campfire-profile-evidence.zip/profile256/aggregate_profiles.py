#!/usr/bin/env python3
"""Strictly aggregate the fixed Off/Detailed ABBA profile runs."""
from __future__ import annotations

import argparse
from collections import defaultdict
import datetime as dt
import json
import math
from pathlib import Path
import re
import statistics
import sys
from typing import Any


CATEGORIES = [
    "reserve_release",
    "initialization_check",
    "arena_copy",
    "value_measure",
    "external_measure",
    "structural_locate",
    "host_output_commit",
    "frame_validation",
    "other_runtime_validation",
    "cookie_verify_session_token",
    "session_find_by_token",
    "session_refresh_before",
    "user_find_by_id",
    "user_authenticate_bot_key",
    "browser_version_at_least",
    "room_find_for_user",
    "membership_exists",
    "message_last_page",
    "sql_prepare",
    "sql_bind",
    "sql_step",
    "sql_reset",
]
STAGES = ["receive_wait", "input_prepare", "api_execute", "renderer", "cookie_finalize", "send_api", "request_scrub"]
PROVIDER_IDS = range(9, 18)
RUNTIME_IDS = range(0, 9)
SQL_IDS = range(18, 22)
CLIENT_SOURCE_PATH = "experiments/AgentLang.Campfire.HttpMeasure/Program.cs"
CLIENT_SOURCE_SHA256 = "42566cbb461ba13814c4660aaee8687f9220377e45a9226f180e7180104896f4"
CLIENT_BINARY_PATH = ".agentlang/campfire-native-profile-256/client-artifacts/bin/HttpMeasure/release/HttpMeasure.dll"
CLIENT_BINARY_SHA256 = "073258c828a9ad104836ee0ac4026f507686d35a0efd9ff8c95c03b6b57970c9"
CLIENT_BUILD_LOG_SHA256 = "0157694feed0da8f80343a5db6af8a62bad037c7309a45bd99578de3c8f53064"
CLIENT_LATENCY_BOUNDARY = "Complete body received, before status/SHA256 validation; throughput includes validation"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def tokens(line: str) -> dict[str, str]:
    return {key: value for key, value in re.findall(r"([A-Za-z0-9_]+)=([^\s]+)", line)}


def integer(fields: dict[str, str], key: str, context: str) -> int:
    require(key in fields, f"{context}: missing {key}")
    try:
        value = int(fields[key], 10)
    except ValueError as error:
        raise ValueError(f"{context}: malformed integer {key}") from error
    require(value >= 0, f"{context}: negative {key}")
    return value


def finite_number(value: Any, context: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{context}: expected a number") from error
    require(math.isfinite(number), f"{context}: value must be finite")
    return number


def validate_client_pin() -> dict[str, str]:
    profile_root = Path(__file__).resolve().parent
    repo_root = profile_root.parents[1]
    pin = read_json(profile_root / "client-source-pins.json")
    expected = {
        "sourcePath": CLIENT_SOURCE_PATH,
        "sourceSha256": CLIENT_SOURCE_SHA256,
        "binaryPath": CLIENT_BINARY_PATH,
        "binarySha256": CLIENT_BINARY_SHA256,
        "buildLogSha256": CLIENT_BUILD_LOG_SHA256,
        "latencyBoundary": CLIENT_LATENCY_BOUNDARY,
    }
    for field, value in expected.items():
        actual = pin.get(field)
        if field.endswith("Sha256"):
            actual = str(actual).lower()
        require(actual == value, f"client source pin receipt mismatch: {field}")
    require(pin.get("buildExitCode") == 0 and pin.get("selfTestExitCode") == 0,
            "client build/self-test receipt did not pass")
    source_hash = hashlib_sha256(repo_root / CLIENT_SOURCE_PATH)
    binary_hash = hashlib_sha256(repo_root / CLIENT_BINARY_PATH)
    build_log_hash = hashlib_sha256(profile_root / "client-build.log")
    require(source_hash == CLIENT_SOURCE_SHA256, "pinned client source changed")
    require(binary_hash == CLIENT_BINARY_SHA256, "pinned client binary changed")
    require(build_log_hash == CLIENT_BUILD_LOG_SHA256, "pinned client build log changed")
    return {"sourceSha256": source_hash, "binarySha256": binary_hash,
            "buildLogSha256": build_log_hash, "latencyBoundary": CLIENT_LATENCY_BOUNDARY}


def parse_log(path: Path, expected_profile: str, expected_workers: int) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8-sig")
    metadata: dict[int, dict[str, int]] = {}
    counters: dict[tuple[int, int], dict[str, Any]] = {}
    stage_workers: dict[int, dict[str, Any]] = {}
    stage_header: dict[str, str] | None = None
    shutdown_match = re.search(r"(?m)^shutdown\.workers_cleaned=(\d+) shutdown\.fatal_status=(\d+)\s*$", text)
    require(shutdown_match is not None, f"{path}: missing terminal shutdown receipt")
    require(int(shutdown_match.group(1)) == expected_workers and int(shutdown_match.group(2)) == 0,
            f"{path}: worker cleanup or fatal status failed")
    for line in text.splitlines():
        if line.startswith("stage_profile "):
            require(stage_header is None, f"{path}: duplicate stage_profile header")
            stage_header = tokens(line)
        elif line.startswith("stage_worker "):
            fields = tokens(line)
            index = integer(fields, "index", "stage worker")
            require(index not in stage_workers, f"{path}: duplicate stage worker {index}")
            stage_workers[index] = fields
        elif line.startswith("execution_profile "):
            fields = tokens(line)
            worker = integer(fields, "worker", "execution profile")
            require(worker not in metadata, f"{path}: duplicate execution profile for worker {worker}")
            meta = {key: integer(fields, key, f"execution profile worker {worker}") for key in ("version", "size", "categories", "qpc_frequency")}
            metadata[worker] = meta
        elif line.startswith("execution_counter "):
            fields = tokens(line)
            worker = integer(fields, "worker", "execution counter")
            category = integer(fields, "id", "execution counter")
            require(category < len(CATEGORIES), f"{path}: unknown counter id {category}")
            require(fields.get("name") == CATEGORIES[category], f"{path}: counter name/id mismatch at id {category}")
            key = (worker, category)
            require(key not in counters, f"{path}: duplicate counter {key}")
            counters[key] = {
                "calls": integer(fields, "calls", f"counter {key}"),
                "ticks": integer(fields, "ticks", f"counter {key}"),
                "failures": integer(fields, "failures", f"counter {key}"),
                "name": fields["name"],
            }

    require(stage_header is not None, f"{path}: stage profile is absent")
    require(integer(stage_header, "enabled", "stage profile") == 1, f"{path}: stage profile is disabled")
    require(integer(stage_header, "workers", "stage profile") == expected_workers, f"{path}: stage worker count mismatch")
    stage_frequency = integer(stage_header, "qpc_frequency", "stage profile")
    require(stage_frequency > 0, f"{path}: invalid stage QPC frequency")
    require(set(stage_workers) == set(range(expected_workers)), f"{path}: incomplete stage workers")
    for worker, fields in stage_workers.items():
        require(integer(fields, "index", f"stage worker {worker}") == worker, f"{path}: stage worker index mismatch")
        require(integer(fields, "cpu_valid", f"stage worker {worker}") == 1, f"{path}: invalid worker CPU window")
        integer(fields, "received_requests", f"stage worker {worker}")
        integer(fields, "worker_loop_user_100ns", f"stage worker {worker}")
        integer(fields, "worker_loop_kernel_100ns", f"stage worker {worker}")
        for stage in STAGES:
            integer(fields, f"{stage}_calls", f"stage worker {worker}")
            integer(fields, f"{stage}_ticks", f"stage worker {worker}")
            integer(fields, f"{stage}_max_ticks", f"stage worker {worker}")

    if expected_profile == "off":
        require(not metadata and not counters, f"{path}: Off execution profile emitted detailed counters")
    else:
        require(set(metadata) == set(range(expected_workers)), f"{path}: detailed profile snapshot missing a worker")
        require(len(counters) == expected_workers * len(CATEGORIES), f"{path}: expected exactly 22 counters per worker")
        for worker, meta in metadata.items():
            require(meta["version"] == 1 and meta["size"] == 552 and meta["categories"] == 22,
                    f"{path}: unsupported detailed profile ABI for worker {worker}")
            require(meta["qpc_frequency"] == stage_frequency, f"{path}: stage/execution QPC frequencies differ")
        for worker in range(expected_workers):
            for category, name in enumerate(CATEGORIES):
                counter = counters.get((worker, category))
                require(counter is not None, f"{path}: missing {name} counter for worker {worker}")
                require(counter["failures"] <= counter["calls"], f"{path}: failure count exceeds calls for {name}")
                require(counter["calls"] != 0 or counter["ticks"] == 0, f"{path}: zero-call counter has elapsed ticks for {name}")
                require(counter["failures"] == 0, f"{path}: nonzero failure count in accepted profile run ({name})")

    stage_totals: dict[str, dict[str, int]] = {}
    for stage in STAGES:
        stage_totals[stage] = {
            "calls": sum(int(row[f"{stage}_calls"]) for row in stage_workers.values()),
            "ticks": sum(int(row[f"{stage}_ticks"]) for row in stage_workers.values()),
            "maxTicks": max(int(row[f"{stage}_max_ticks"]) for row in stage_workers.values()),
        }
    if expected_profile == "detailed":
        all_counters = {
            name: {
                "calls": sum(counters[(worker, category)]["calls"] for worker in range(expected_workers)),
                "ticks": sum(counters[(worker, category)]["ticks"] for worker in range(expected_workers)),
                "failures": sum(counters[(worker, category)]["failures"] for worker in range(expected_workers)),
            }
            for category, name in enumerate(CATEGORIES)
        }
        api_ticks = stage_totals["api_execute"]["ticks"]
        callback_ticks = sum(all_counters[CATEGORIES[i]]["ticks"] for i in PROVIDER_IDS)
        require(callback_ticks <= api_ticks, f"{path}: summed host callback intervals exceed inclusive api_execute")
        for category in RUNTIME_IDS:
            require(all_counters[CATEGORIES[category]]["ticks"] <= api_ticks,
                    f"{path}: runtime interval exceeds inclusive api_execute ({CATEGORIES[category]})")
        return {"qpcFrequency": stage_frequency, "stage": stage_totals, "counters": all_counters,
                "providerCallbackTicks": callback_ticks, "apiExecuteTicks": api_ticks,
                "flowRuntimeOutsideCallbacksTicks": api_ticks - callback_ticks,
                "workers": [stage_workers[index] for index in range(expected_workers)]}
    return {"qpcFrequency": stage_frequency, "stage": stage_totals,
            "workers": [stage_workers[index] for index in range(expected_workers)]}


def load_run(label: str, root: Path) -> dict[str, Any]:
    start = read_json(root / "run-start.json")
    terminal = read_json(root / "run-receipt.json")
    build = read_json(root / "build-receipt.json")
    measurement = read_json(root / "measurement-summary.json")
    fixture = read_json(root / "fixture-refresh.json")
    fixture_postrun_path = root / "fixture-postrun.json"
    fixture_postrun = read_json(fixture_postrun_path)
    affinity = read_json(root / "affinity-receipt.json")
    require(start["runName"] == root.name, f"{label}: run-name/path mismatch")
    profile = str(start["executionProfile"]).lower()
    require(profile in ("off", "detailed"), f"{label}: invalid execution profile")
    require(build["ExecutionProfile"].lower() == profile and terminal["executionProfile"] == profile,
            f"{label}: build/start/terminal profile mismatch")
    require(build["Optimization"] == "O2" and start["optimization"] == "O2", f"{label}: accepted perf runs must be O2")
    require(build["RuntimeProfile"] == "trusted-generated" and build["StageProfile"] == "On", f"{label}: profile/host-stage build mismatch")
    require(terminal["terminalExitCode"] == 0 and terminal["fatalStatus"] == 0 and terminal["workerCleanupLine"] == 4,
            f"{label}: native host did not exit cleanly with four workers")
    require(terminal["nativeHostLogSha256"] == hashlib_sha256(root / "native-host.log"), f"{label}: host log hash mismatch")
    require(terminal["buildReceiptSha256"] == hashlib_sha256(root / "build-receipt.json"), f"{label}: copied build receipt hash mismatch")
    require(terminal["fixturePostRunExitCode"] == 0 and
            terminal["fixturePostRunSha256"] == hashlib_sha256(fixture_postrun_path),
            f"{label}: fixture post-run receipt failed or changed")
    require(start["buildReceiptSha256"] == terminal["buildReceiptSha256"], f"{label}: receipt changed during run")
    require(fixture["sqliteVersion"] == "3.53.3" and len(fixture["rows"]) == 2, f"{label}: fixture refresh receipt invalid")
    require(fixture_postrun["sqliteVersion"] == fixture["sqliteVersion"] and
            fixture_postrun["sqliteSha256"] == fixture["sqliteSha256"] and
            fixture_postrun["unchanged"] is True and
            fixture_postrun["expectedSessionTimestamp"] == fixture["rows"][0]["sessionLastActiveAt"] and
            len(fixture_postrun["rows"]) == 2 and all(row["unchanged"] is True for row in fixture_postrun["rows"]),
            f"{label}: session timestamps changed during the measured host lifetime")
    refreshed = dt.datetime.fromisoformat(fixture["refreshedUtc"].replace("Z", "+00:00"))
    started = dt.datetime.fromisoformat(start["startedUtc"].replace("Z", "+00:00"))
    now = dt.datetime.now(dt.timezone.utc)
    require(dt.timedelta(0) <= started - refreshed <= dt.timedelta(minutes=2), f"{label}: session refresh was not immediately before host startup")
    require(now - refreshed <= dt.timedelta(hours=1), f"{label}: synthetic session aged into refresh-due state")
    require(affinity["effectiveServerMaskBefore"] == affinity["effectiveServerMaskAfter"] == affinity["requestedServerMask"],
            f"{label}: fixed server affinity did not remain stable")
    require(affinity["serverPhysicalCores"] == [0, 9, 10, 11], f"{label}: expected four distinct selected physical cores")
    require(affinity["clientMask"] == 4129788 and affinity["topologySha256"] == "d942c22352a0184c204e26fa07773b5c09739800f98f4368d17ad57f80c90967",
            f"{label}: fixed topology/client affinity changed")
    rows = measurement["results"]
    require(len(rows) == 2 and measurement["repeats"] == 2 and measurement["concurrency"] == 16 and
            measurement["secondsPerRepeat"] == 15 and measurement["warmupRequestsPerRepeat"] == 20,
            f"{label}: measurement matrix mismatch")
    require(measurement["executionProfile"] == profile and measurement["clientAffinityMask"] == 4129788,
            f"{label}: measurement profile or client affinity mismatch")
    require(measurement["clientSourcePath"] == CLIENT_SOURCE_PATH and
            measurement["clientSourceSha256"].lower() == CLIENT_SOURCE_SHA256 and
            measurement["clientBinarySha256"].lower() == CLIENT_BINARY_SHA256 and
            measurement["clientBuildLogSha256"].lower() == CLIENT_BUILD_LOG_SHA256 and
            measurement["clientSelfTestExitCode"] == 0 and
            measurement["clientLatencyBoundary"] == CLIENT_LATENCY_BOUNDARY,
            f"{label}: client artifact or timing boundary does not match the pinned 256 client")
    expected_body = str(measurement["expectedBodySha256"]).lower()
    for index, row in enumerate(rows, start=1):
        require(row["method"] == "GET" and row["uri"] == "http://127.0.0.1:13773/rooms/104", f"{label}: wrong request workload")
        require(row["ExpectedBodySha256"].lower() == expected_body, f"{label}: body contract changed")
        require(int(row["failures"]) == 0 and not row["errors"], f"{label}: benchmark client rejected response(s)")
        require(int(row["Concurrency"]) == 16 and int(row["WarmupRequests"]) == 20, f"{label}: client workload mismatch")
        require(int(row["effectiveClientAffinityMask"]) == 4129788, f"{label}: client affinity mismatch")
        require(finite_number(row["measuredSeconds"], f"{label} repeat {index}") >= 14.9, f"{label}: incomplete measured interval")
        require(int(row["correctResponses"]) > 0 and int(row["responseBytes"]) > 0, f"{label}: no validated response data")
    log = parse_log(root / "native-host.log", profile, 4)
    if profile == "detailed":
        require(log["counters"]["session_refresh_before"]["calls"] == 0,
                f"{label}: steady-state benchmark unexpectedly invoked session refresh")
    host_requests = sum(int(worker["received_requests"]) for worker in log["workers"])
    expected_requests = sum(int(row["correctResponses"]) + 20 for row in rows)
    require(host_requests == expected_requests, f"{label}: host GET count {host_requests} != validated responses plus warmups {expected_requests}")
    require(log["stage"]["api_execute"]["calls"] == host_requests, f"{label}: API call count differs from host GET count")
    require(log["stage"]["renderer"]["calls"] == host_requests * 2, f"{label}: expected two renderer passes per GET")
    require(log["stage"]["cookie_finalize"]["calls"] == host_requests and
            log["stage"]["send_api"]["calls"] == host_requests and
            log["stage"]["request_scrub"]["calls"] == host_requests,
            f"{label}: request stage call counts do not match accepted GETs")
    return {"label": label, "root": str(root), "profile": profile, "start": start, "terminal": terminal,
            "build": build, "measurement": measurement, "log": log, "hostRequests": host_requests}


def hashlib_sha256(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_summary(run: dict[str, Any]) -> dict[str, Any]:
    rows = run["measurement"]["results"]
    seconds = sum(finite_number(row["measuredSeconds"], "measuredSeconds") for row in rows)
    responses = sum(int(row["correctResponses"]) for row in rows)
    p95 = [finite_number(row["p95MillisecondsUpperBound"], "p95") for row in rows]
    p99 = [finite_number(row["p99MillisecondsUpperBound"], "p99") for row in rows]
    server_cpu = [finite_number(row["serverCpuEquivalentCores"], "serverCpu") for row in rows]
    client_cpu = [finite_number(row["clientCpuEquivalentCores"], "clientCpu") for row in rows]
    failures = sum(int(row["failures"]) for row in rows)
    frequency = run["log"]["qpcFrequency"]
    stage_means: dict[str, Any] = {}
    for name, stage in run["log"]["stage"].items():
        stage_means[name] = {
            "calls": stage["calls"],
            "ticks": stage["ticks"],
            "maxTicks": stage["maxTicks"],
            "meanMicrosecondsPerCall": (stage["ticks"] * 1_000_000.0 / frequency / stage["calls"]) if stage["calls"] else None,
            "maximumMicroseconds": (stage["maxTicks"] * 1_000_000.0 / frequency) if stage["calls"] else None,
        }
    summary: dict[str, Any] = {
        "name": run["label"], "profile": run["profile"], "hostRequests": run["hostRequests"],
        "correctResponses": responses, "measuredSeconds": seconds,
        "failures": failures,
        "requestsPerSecond": responses / seconds,
        "repeatP95UpperBoundsMs": p95, "medianRepeatP95UpperBoundMs": statistics.median(p95),
        "repeatP99UpperBoundsMs": p99, "medianRepeatP99UpperBoundMs": statistics.median(p99),
        "meanServerCpuEquivalentCores": statistics.mean(server_cpu),
        "meanClientCpuEquivalentCores": statistics.mean(client_cpu),
        "expectedBodySha256": rows[0]["ExpectedBodySha256"].lower(),
        "client": {
            "sourcePath": CLIENT_SOURCE_PATH,
            "sourceSha256": CLIENT_SOURCE_SHA256,
            "binaryPath": CLIENT_BINARY_PATH,
            "binarySha256": CLIENT_BINARY_SHA256,
            "latencyBoundary": CLIENT_LATENCY_BOUNDARY,
        },
        "stage": run["log"]["stage"],
        "stageMeans": stage_means,
    }
    if run["profile"] == "detailed":
        frequency = run["log"]["qpcFrequency"]
        per_category: dict[str, Any] = {}
        for name, counter in run["log"]["counters"].items():
            per_category[name] = {
                **counter,
                "meanMicrosecondsPerCall": (counter["ticks"] * 1_000_000.0 / frequency / counter["calls"]) if counter["calls"] else None,
                "callsPerHostGet": counter["calls"] / run["hostRequests"],
                "ticksPerHostGet": counter["ticks"] / run["hostRequests"],
            }
        summary["detailedProfile"] = {
            "abiVersion": 1, "sizeBytes": 552, "categoryCount": 22, "qpcFrequency": frequency,
            "counters": per_category,
            "providerCallbackTicks": run["log"]["providerCallbackTicks"],
            "apiExecuteTicks": run["log"]["apiExecuteTicks"],
            "providerCallbackPercentOfApiTicks": 100.0 * run["log"]["providerCallbackTicks"] / run["log"]["apiExecuteTicks"] if run["log"]["apiExecuteTicks"] else None,
            "flowRuntimeOutsideCallbacksTicks": run["log"]["flowRuntimeOutsideCallbacksTicks"],
            "overlapRule": "Runtime counters overlap and SQL counters are nested inside provider callbacks; category rows are not additive. Provider callback sum is valid after dispatcher non-recursion review.",
        }
    return summary


def compare(source: list[dict[str, Any]]) -> dict[str, Any]:
    require(len(source) == 4, "Exactly four runs are required for OffA, DetailedB, DetailedC, OffD")
    expected_profiles = ["off", "detailed", "detailed", "off"]
    require([run["profile"] for run in source] == expected_profiles, "Runs must follow Off, Detailed, Detailed, Off ABBA order")
    summaries = [run_summary(run) for run in source]
    expected_hash = summaries[0]["expectedBodySha256"]
    require(all(row["expectedBodySha256"] == expected_hash for row in summaries), "Response body hash differs across runs")
    qpc_frequencies = {run["log"]["qpcFrequency"] for run in source}
    require(len(qpc_frequencies) == 1, "QPC frequency changed between the matched runs")
    # Generated pins and freeze documents include the selected execution profile
    # and artifact hashes. Compare their verified source maps, not whole-document
    # hashes across deliberately different instrumentation builds.
    stable_build_fields = ["HostSourceSha256", "SqliteSha256", "RuntimeProfile", "StageProfile", "Optimization", "SdkVersion", "MsvcVersion", "Compiler", "Linker", "Imports", "HostLocalRuntimeInstrumentation"]
    reference = source[0]["build"]
    source_maps = []
    for run in source:
        freeze_path = Path(run["build"]["ValidationRunRoot"]) / "test-source-freeze.json"
        require(hashlib_sha256(freeze_path).lower() == run["build"]["ValidationSourceFreezeSha256"].lower(), "Validation source freeze hash mismatch")
        freeze = read_json(freeze_path)
        require(freeze["stable"] and not freeze["changedFiles"] and freeze["before"] == freeze["after"], "Validation sources changed")
        source_maps.append(freeze["after"])
    require(all(item == source_maps[0] for item in source_maps), "Source bytes changed between instrumentation builds")
    for run in source[1:]:
        for field in stable_build_fields:
            if field in reference and field in run["build"]:
                require(reference[field] == run["build"][field], f"Build input changed between profiles: {field}")
    def percent_change(detailed: float, off: float) -> float | None:
        return None if off == 0.0 else 100.0 * (detailed / off - 1.0)

    def paired_metrics(off_index: int, detailed_index: int, label: str) -> dict[str, Any]:
        off, detailed = summaries[off_index], summaries[detailed_index]
        return {
            "pair": label,
            "off": off["name"],
            "detailed": detailed["name"],
            "throughputChangePercent": percent_change(detailed["requestsPerSecond"], off["requestsPerSecond"]),
            "medianRepeatP95ChangePercent": percent_change(detailed["medianRepeatP95UpperBoundMs"], off["medianRepeatP95UpperBoundMs"]),
            "medianRepeatP99ChangePercent": percent_change(detailed["medianRepeatP99UpperBoundMs"], off["medianRepeatP99UpperBoundMs"]),
            "meanServerCpuChangePercent": percent_change(detailed["meanServerCpuEquivalentCores"], off["meanServerCpuEquivalentCores"]),
            "meanClientCpuChangePercent": percent_change(detailed["meanClientCpuEquivalentCores"], off["meanClientCpuEquivalentCores"]),
            "offMetrics": {
                "requestsPerSecond": off["requestsPerSecond"],
                "repeatP95UpperBoundsMs": off["repeatP95UpperBoundsMs"],
                "repeatP99UpperBoundsMs": off["repeatP99UpperBoundsMs"],
                "meanServerCpuEquivalentCores": off["meanServerCpuEquivalentCores"],
                "meanClientCpuEquivalentCores": off["meanClientCpuEquivalentCores"],
            },
            "detailedMetrics": {
                "requestsPerSecond": detailed["requestsPerSecond"],
                "repeatP95UpperBoundsMs": detailed["repeatP95UpperBoundsMs"],
                "repeatP99UpperBoundsMs": detailed["repeatP99UpperBoundsMs"],
                "meanServerCpuEquivalentCores": detailed["meanServerCpuEquivalentCores"],
                "meanClientCpuEquivalentCores": detailed["meanClientCpuEquivalentCores"],
            },
        }
    pairs = [
        paired_metrics(0, 1, "A-Off / B-Detailed"),
        paired_metrics(3, 2, "D-Off / C-Detailed"),
    ]
    detailed_repeats = [row for run in source if run["profile"] == "detailed" for row in run["measurement"]["results"]]
    off_repeats = [row for run in source if run["profile"] == "off" for row in run["measurement"]["results"]]
    detailed_rate = sum(int(row["correctResponses"]) for row in detailed_repeats) / sum(float(row["measuredSeconds"]) for row in detailed_repeats)
    off_rate = sum(int(row["correctResponses"]) for row in off_repeats) / sum(float(row["measuredSeconds"]) for row in off_repeats)
    profile_medians: dict[str, Any] = {}
    for profile in ("off", "detailed"):
        profile_run_summaries = [row for row in summaries if row["profile"] == profile]
        profile_runs = [run for run in source if run["profile"] == profile]
        repeats = [row for run in profile_runs for row in run["measurement"]["results"]]
        stage_means: dict[str, Any] = {}
        frequency = profile_runs[0]["log"]["qpcFrequency"]
        for stage_name in STAGES:
            calls = sum(run["log"]["stage"][stage_name]["calls"] for run in profile_runs)
            ticks = sum(run["log"]["stage"][stage_name]["ticks"] for run in profile_runs)
            maximum_ticks = max(run["log"]["stage"][stage_name]["maxTicks"] for run in profile_runs)
            stage_means[stage_name] = {
                "calls": calls,
                "ticks": ticks,
                "maxTicks": maximum_ticks,
                "meanMicrosecondsPerCall": ticks * 1_000_000.0 / frequency / calls if calls else None,
                "maximumMicroseconds": maximum_ticks * 1_000_000.0 / frequency if calls else None,
            }
        profile_medians[profile] = {
            "hostRequestsPerSecondMedian": statistics.median(row["requestsPerSecond"] for row in profile_run_summaries),
            "repeatP95UpperBoundMedianMs": statistics.median(float(row["p95MillisecondsUpperBound"]) for row in repeats),
            "repeatP99UpperBoundMedianMs": statistics.median(float(row["p99MillisecondsUpperBound"]) for row in repeats),
            "serverCpuEquivalentCoresMedian": statistics.median(float(row["serverCpuEquivalentCores"]) for row in repeats),
            "clientCpuEquivalentCoresMedian": statistics.median(float(row["clientCpuEquivalentCores"]) for row in repeats),
            "responseFailures": sum(int(row["failures"]) for row in repeats),
            "stageMeans": stage_means,
        }
        if profile == "detailed":
            names = CATEGORIES
            counters = {}
            for category, name in enumerate(names):
                calls = sum(run["log"]["counters"][name]["calls"] for run in profile_runs)
                ticks = sum(run["log"]["counters"][name]["ticks"] for run in profile_runs)
                failures = sum(run["log"]["counters"][name]["failures"] for run in profile_runs)
                counters[name] = {
                    "calls": calls,
                    "ticks": ticks,
                    "failures": failures,
                    "meanMicrosecondsPerCall": ticks * 1_000_000.0 / frequency / calls if calls else None,
                    "callsPerHostGet": calls / sum(run["hostRequests"] for run in profile_runs),
                }
            profile_medians[profile]["detailedCounters"] = counters
    detailed_p99 = [float(row["p99MillisecondsUpperBound"]) for row in detailed_repeats]
    off_p99 = [float(row["p99MillisecondsUpperBound"]) for row in off_repeats]
    return {
        "schemaVersion": 1,
        "method": "O2 trusted-generated native room GET; StageProfile On in both arms; execution Off/Detailed ABBA; four workers, fixed four-core host mask, fixed affinity-disjoint client mask, concurrency 16, two 15-second repeats per host, 20 warmups per repeat. The pinned 256 client records latency after the full body arrives and before status/body-digest validation; throughput includes validation.",
        "runs": summaries,
        "adjacentPairs": pairs,
        "profileMedians": profile_medians,
        "combinedThroughput": {
            "offRequestsPerSecond": off_rate,
            "detailedRequestsPerSecond": detailed_rate,
            "detailedChangePercent": 100.0 * (detailed_rate / off_rate - 1.0),
        },
        "p99": {
            "offRepeatUpperBoundsMs": off_p99,
            "detailedRepeatUpperBoundsMs": detailed_p99,
            "offMedianRepeatUpperBoundMs": statistics.median(off_p99),
            "detailedMedianRepeatUpperBoundMs": statistics.median(detailed_p99),
            "interpretation": "Median of four per-repeat client histogram upper bounds per profile; not a pooled histogram percentile.",
        },
        "interpretationLimits": [
            "Stage timing is enabled in both arms; this estimates incremental detailed runtime counter overhead, not host stage-profiler overhead.",
            "Worker timer sums overlap in wall time; runtime category totals also overlap; SQL intervals are nested within provider callbacks.",
            "Client p95/p99 values are histogram upper bounds from successful responses only and remain separate from host QPC means/maxima.",
            "SQLite step time is not lock-wait time. No lock-cause claim is supported by this steady-state workload.",
            "The pure cookie SRW lock, adapter active-state guard, and internal SQLite/HTTP.sys/CNG synchronization are outside separately timed wait counters; low operation totals do not establish absence of contention.",
            "This private Windows HTTP.sys workload is not apples-to-apples with the public Rails/Docker benchmark or a WebSocket-capacity test.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs-root", type=Path, default=Path(__file__).parent / "runs")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "profile-analysis-256.json")
    parser.add_argument("--markdown", type=Path, default=Path(__file__).parent / "profile-analysis-256.md")
    parser.add_argument("--run", action="append", required=True, metavar="LABEL=RUN_NAME", help="repeat in OffA, DetailedB, DetailedC, OffD order")
    args = parser.parse_args()
    try:
        client_pin = validate_client_pin()
        labels = ["OffA", "DetailedB", "DetailedC", "OffD"]
        require(len(args.run) == 4, "Provide exactly four --run LABEL=RUN_NAME arguments")
        runs_root = args.runs_root.resolve(strict=True)
        runs = []
        for expected, value in zip(labels, args.run):
            require("=" in value, "Each --run must be LABEL=RUN_NAME")
            label, name = value.split("=", 1)
            require(label == expected, f"Expected --run {expected}=... in ABBA order")
            require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", name) is not None,
                    f"Invalid immutable run name for {label}")
            root = (runs_root / name).resolve(strict=True)
            require(root.is_relative_to(runs_root), f"{label}: run directory escaped the selected run root")
            runs.append(load_run(label, root))
        report = compare(runs)
        report["clientPin"] = client_pin
        output_json = args.output.resolve()
        output_markdown = args.markdown.resolve()
        require(output_json != output_markdown, "JSON and Markdown outputs must be different immutable paths")
        for output in (output_json, output_markdown):
            require(not output.exists(), f"Refusing to overwrite immutable output {output}")
            output.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        detail_rows = []
        for run in report["runs"]:
            detail = run.get("detailedProfile", {})
            detail_rows.append(f"| {run['name']} | {run['profile']} | {run['hostRequests']} | {run['requestsPerSecond']:.2f} | {run['medianRepeatP99UpperBoundMs']:.3f} | {detail.get('providerCallbackPercentOfApiTicks', '—') if detail else '—'} |")
        markdown = "\n".join([
            "# Campfire native execution-profile 256",
            "",
            report["method"],
            "",
            "| Run | Profile | Host GETs | Correct req/s | Median repeat P99 upper bound (ms) | Provider ticks / API ticks |",
            "|---|---|---:|---:|---:|---:|",
            *detail_rows,
            "",
            f"Combined Detailed throughput change: {report['combinedThroughput']['detailedChangePercent']:+.2f}%.",
            "",
            "## Detailed category means",
            "",
            "Per-run category totals and means are in the JSON report. Runtime counters overlap, SQL counters nest inside provider callbacks, and these columns must not be summed into API time.",
            "",
            "| Profile | Category | Calls | Failures | Mean µs/call | Calls/host GET |",
            "|---|---|---:|---:|---:|---:|",
        ])
        for run in report["runs"]:
            detail = run.get("detailedProfile")
            if not detail:
                continue
            for name, row in detail["counters"].items():
                mean = "—" if row["meanMicrosecondsPerCall"] is None else f"{row['meanMicrosecondsPerCall']:.4f}"
                markdown += f"\n| {run['name']} | {name} | {row['calls']} | {row['failures']} | {mean} | {row['callsPerHostGet']:.4f} |"
        markdown += "\n\n## Interpretation limits\n\n" + "\n".join(f"- {item}" for item in report["interpretationLimits"]) + "\n"
        output_markdown.write_text(markdown, encoding="utf-8")
        print(f"validated 4 ABBA runs; detailed throughput delta {report['combinedThroughput']['detailedChangePercent']:+.2f}%")
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"profile aggregation failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

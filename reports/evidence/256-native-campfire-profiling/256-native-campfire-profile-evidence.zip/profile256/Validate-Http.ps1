#requires -Version 7.0
param(
  [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$')][string]$RunName,
  [Parameter(Mandatory)][ValidateSet('Off','Detailed')][string]$ExecutionProfile,
  [Parameter(Mandatory)][ValidateSet('O0','O2')][string]$Optimization
)
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
$runRoot = Join-Path $repo ".agentlang/campfire-native-profile-256/runs/$RunName"
$fixture = Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'
$hostInfo = Get-Content -LiteralPath (Join-Path $runRoot 'host-process.json') -Raw | ConvertFrom-Json
$start = Get-Content -LiteralPath (Join-Path $runRoot 'run-start.json') -Raw | ConvertFrom-Json
$buildReceipt = Get-Content -LiteralPath (Join-Path $runRoot 'build-receipt.json') -Raw | ConvertFrom-Json
if ($start.executionProfile -cne $ExecutionProfile.ToLowerInvariant() -or
    $start.optimization -cne $Optimization -or
    ([string]$buildReceipt.ExecutionProfile).ToLowerInvariant() -cne $ExecutionProfile.ToLowerInvariant()) {
  throw 'Validation tuple does not match the running host and immutable build receipt.'
}
$server = Get-Process -Id ([int]$hostInfo.processId) -ErrorAction Stop
if (-not [StringComparer]::OrdinalIgnoreCase.Equals($server.Path, [IO.Path]::GetFullPath([string]$hostInfo.executable))) {
  throw 'Validation PID is not the task-owned host process.'
}
$checker = Join-Path $repo '.agentlang/campfire-native-profile-256/http-checker-artifacts/bin/AgentLang.Campfire.NativeHttp.Tests/release/AgentLang.Campfire.NativeHttp.Tests.dll'
$requestPath = Join-Path $fixture 'private-request.json'
$secretPath = Join-Path $fixture 'synthetic-secret.txt'
$corpusScript = Join-Path $fixture 'corpus.ps1'
$transportScript = Join-Path $repo 'tests/AgentLang.Campfire.NativeHttp.Tests/transport-limits.ps1'
foreach ($path in @($checker,$requestPath,$secretPath,$corpusScript)) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing HTTP validation input: $(Split-Path -Leaf $path)." }
}
$outputRoot = Join-Path $repo '.agentlang/campfire-native-profile-256/http-validation'
$label = "$RunName-$ExecutionProfile-$Optimization".ToLowerInvariant()
$output = Join-Path $outputRoot $label
if (Test-Path -LiteralPath $output) { throw 'Validation output roots are immutable.' }
$null = New-Item -ItemType Directory -Path $output -Force
$checkerReceipt = Join-Path $output 'cookie-header-redacted-receipt.json'
& dotnet $checker $requestPath $secretPath $checkerReceipt
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $checkerReceipt -PathType Leaf)) { throw 'Cookie/header parity check failed.' }

$corpusName = 'profile256-' + [Guid]::NewGuid().ToString('N') + '.json'
$corpusFixturePath = Join-Path $fixture $corpusName
$corpusOutput = Join-Path $output 'http-corpus.json'
try {
  if (Test-Path -LiteralPath $corpusFixturePath) { throw 'Unexpected temporary corpus path collision.' }
  & $corpusScript -Port 13773 -ResultName $corpusName
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $corpusFixturePath -PathType Leaf)) { throw 'Loopback HTTP corpus failed.' }
  $corpusRows = @(Get-Content -LiteralPath $corpusFixturePath -Raw | ConvertFrom-Json)
  if ($corpusRows.Count -ne 20 -or @($corpusRows | Where-Object { $_.status -ne $_.expectedStatus }).Count -ne 0) {
    throw 'Loopback corpus did not satisfy its 20 pinned status expectations.'
  }
  Copy-Item -LiteralPath $corpusFixturePath -Destination $corpusOutput
} finally {
  Remove-Item -LiteralPath $corpusFixturePath -Force -ErrorAction SilentlyContinue
}

$transportReceipt = $null
if ($Optimization -eq 'O2') {
  if (-not (Test-Path -LiteralPath $transportScript -PathType Leaf)) { throw 'Transport-limit verifier is missing.' }
  $transportReceipt = Join-Path $output 'transport-limits.json'
  & $transportScript -ReceiptPath $transportReceipt
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $transportReceipt -PathType Leaf)) { throw 'Transport-limit check failed.' }
}
$bodyHash = ([string]((Get-Content -LiteralPath $requestPath -Raw | ConvertFrom-Json).ExpectedBodySha256)).ToLowerInvariant()
[ordered]@{
  runName = $RunName
  executionProfile = $ExecutionProfile.ToLowerInvariant()
  optimization = $Optimization
  checkerSha256 = (Get-FileHash -LiteralPath $checker -Algorithm SHA256).Hash.ToLowerInvariant()
  checkerReceiptSha256 = (Get-FileHash -LiteralPath $checkerReceipt -Algorithm SHA256).Hash.ToLowerInvariant()
  corpusSha256 = (Get-FileHash -LiteralPath $corpusOutput -Algorithm SHA256).Hash.ToLowerInvariant()
  corpusCases = 20
  expectedBodySha256 = $bodyHash
  transportReceiptSha256 = if ($transportReceipt) { (Get-FileHash -LiteralPath $transportReceipt -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null }
  verifiedUtc = [DateTime]::UtcNow.ToString('O')
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'validation-receipt.json') -Encoding utf8NoBOM
Write-Output "validation=$label checker=passed corpus=20 transport=$(if($transportReceipt){'passed'}else{'not-run'})"

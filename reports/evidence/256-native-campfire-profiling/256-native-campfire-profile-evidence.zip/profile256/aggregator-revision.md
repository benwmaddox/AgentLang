# Aggregator revision after collection

Every set-1 and set-2 `run-start.json` pins `aggregate_profiles.py` at SHA256
`47e44d6517ddbdb87a2692e11c73f84ac6599d6374a0ee3eecaa5a594e886e23`. The aggregator
was edited after set-1 collection (2026-10-12 22:17 EDT) and before any aggregation
was accepted. That revision changed analysis only; hosts, client and fixture
helpers are byte-identical across all eight accepted runs.

The original version required whole-document equality of `GeneratedPinsHeaderSha256`
and `ValidationSourceFreezeSha256` across Off and Detailed builds. Those two hashes
necessarily differ by profile. A manual diff before the revision showed:

- `http_host_pins.h`: only `CAMPFIRE_HTTP_EXECUTION_PROFILE 0|1` and the pinned
  module/manifest SHA256 byte arrays differ.
- `source-pins.json`: only the `generated/http_host_pins.h` hash differs.
- `test-source-freeze.json`: only `executionProfile` (`Off`/`Detailed`) differs.

The revised aggregator drops those two whole-document fields from the strict
equality list, adds compiler/linker/import/host-instrumentation fields to it,
verifies each run's freeze file hash against its build receipt, requires a stable
freeze (`stable`, no `changedFiles`, `before == after`), and requires the
`after` source maps to be identical across all four runs of a set.

A brief concurrent edit by a second agent session (adding a helper that was never
called) was removed within 30 seconds and is not in the sealed aggregator. The
sealed aggregator's own hash is recorded in the evidence manifest.

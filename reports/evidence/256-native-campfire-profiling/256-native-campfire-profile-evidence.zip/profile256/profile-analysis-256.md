# Campfire native execution-profile 256

O2 trusted-generated native room GET; StageProfile On in both arms; execution Off/Detailed ABBA; four workers, fixed four-core host mask, fixed affinity-disjoint client mask, concurrency 16, two 15-second repeats per host, 20 warmups per repeat. The pinned 256 client records latency after the full body arrives and before status/body-digest validation; throughput includes validation.

| Run | Profile | Host GETs | Correct req/s | Median repeat P99 upper bound (ms) | Provider ticks / API ticks |
|---|---|---:|---:|---:|---:|
| OffA | off | 196137 | 6535.66 | 3.540 | — |
| DetailedB | detailed | 190363 | 6342.93 | 3.778 | 52.68686355384532 |
| DetailedC | detailed | 167791 | 5590.88 | 6.074 | 49.511811643696355 |
| OffD | off | 189293 | 6307.53 | 3.622 | — |

Combined Detailed throughput change: -7.08%.

## Detailed category means

Per-run category totals and means are in the JSON report. Runtime counters overlap, SQL counters nest inside provider callbacks, and these columns must not be summed into API time.

| Profile | Category | Calls | Failures | Mean µs/call | Calls/host GET |
|---|---|---:|---:|---:|---:|
| DetailedB | reserve_release | 8566335 | 0 | 0.0167 | 45.0000 |
| DetailedB | initialization_check | 719381777 | 0 | 0.0151 | 3779.0000 |
| DetailedB | arena_copy | 4568712 | 0 | 0.0758 | 24.0000 |
| DetailedB | value_measure | 0 | 0 | — | 0.0000 |
| DetailedB | external_measure | 1332541 | 0 | 3.1966 | 7.0000 |
| DetailedB | structural_locate | 8375972 | 0 | 3.8766 | 44.0000 |
| DetailedB | host_output_commit | 1142178 | 0 | 3.2362 | 6.0000 |
| DetailedB | frame_validation | 6281979 | 0 | 0.0170 | 33.0000 |
| DetailedB | other_runtime_validation | 9708513 | 0 | 2.0684 | 51.0000 |
| DetailedB | cookie_verify_session_token | 190363 | 0 | 6.3693 | 1.0000 |
| DetailedB | session_find_by_token | 190363 | 0 | 19.5824 | 1.0000 |
| DetailedB | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedB | user_find_by_id | 190363 | 0 | 6.0042 | 1.0000 |
| DetailedB | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedB | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedB | room_find_for_user | 190363 | 0 | 11.4394 | 1.0000 |
| DetailedB | membership_exists | 190363 | 0 | 4.5204 | 1.0000 |
| DetailedB | message_last_page | 190363 | 0 | 247.3480 | 1.0000 |
| DetailedB | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedB | sql_bind | 1713267 | 0 | 0.2762 | 9.0000 |
| DetailedB | sql_step | 16942307 | 0 | 1.0746 | 89.0000 |
| DetailedB | sql_reset | 15419403 | 0 | 0.1218 | 81.0000 |
| DetailedC | reserve_release | 7550595 | 0 | 0.0199 | 45.0000 |
| DetailedC | initialization_check | 634082189 | 0 | 0.0169 | 3779.0000 |
| DetailedC | arena_copy | 4026984 | 0 | 0.0887 | 24.0000 |
| DetailedC | value_measure | 0 | 0 | — | 0.0000 |
| DetailedC | external_measure | 1174537 | 0 | 3.7097 | 7.0000 |
| DetailedC | structural_locate | 7382804 | 0 | 4.3732 | 44.0000 |
| DetailedC | host_output_commit | 1006746 | 0 | 3.7281 | 6.0000 |
| DetailedC | frame_validation | 5537103 | 0 | 0.0199 | 33.0000 |
| DetailedC | other_runtime_validation | 8557341 | 0 | 2.3285 | 51.0000 |
| DetailedC | cookie_verify_session_token | 167791 | 0 | 7.8303 | 1.0000 |
| DetailedC | session_find_by_token | 167791 | 0 | 22.5769 | 1.0000 |
| DetailedC | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedC | user_find_by_id | 167791 | 0 | 7.1069 | 1.0000 |
| DetailedC | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedC | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedC | room_find_for_user | 167791 | 0 | 12.9246 | 1.0000 |
| DetailedC | membership_exists | 167791 | 0 | 5.4985 | 1.0000 |
| DetailedC | message_last_page | 167791 | 0 | 238.6131 | 1.0000 |
| DetailedC | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedC | sql_bind | 1510119 | 0 | 0.3785 | 9.0000 |
| DetailedC | sql_step | 14933399 | 0 | 1.2427 | 89.0000 |
| DetailedC | sql_reset | 13591071 | 0 | 0.1393 | 81.0000 |

## Interpretation limits

- Stage timing is enabled in both arms; this estimates incremental detailed runtime counter overhead, not host stage-profiler overhead.
- Worker timer sums overlap in wall time; runtime category totals also overlap; SQL intervals are nested within provider callbacks.
- Client p95/p99 values are histogram upper bounds from successful responses only and remain separate from host QPC means/maxima.
- SQLite step time is not lock-wait time. No lock-cause claim is supported by this steady-state workload.
- The pure cookie SRW lock, adapter active-state guard, and internal SQLite/HTTP.sys/CNG synchronization are outside separately timed wait counters; low operation totals do not establish absence of contention.
- This private Windows HTTP.sys workload is not apples-to-apples with the public Rails/Docker benchmark or a WebSocket-capacity test.

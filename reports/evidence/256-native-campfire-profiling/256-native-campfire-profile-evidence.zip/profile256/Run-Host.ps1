#requires -Version 7.0
param(
  [Parameter(Mandatory)][string]$BuildDirectory,
  [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$')][string]$RunName,
  [Parameter(Mandatory)][ValidateSet('Off','Detailed')][string]$ExecutionProfile,
  [ValidateSet('O0','O2')][string]$Optimization = 'O2',
  [ValidateSet(1,2,3,4,5,6,7,8)][int]$Workers = 4,
  [ValidateSet(13773)][int]$Port = 13773
)
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
$privateRoot = [IO.Path]::GetFullPath((Join-Path $repo '.agentlang/campfire-native-profile-256'))
$runRoot = [IO.Path]::GetFullPath((Join-Path $privateRoot "runs/$RunName"))
$build = [IO.Path]::GetFullPath($BuildDirectory)
$prefix = $privateRoot + [IO.Path]::DirectorySeparatorChar
if (-not $build.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'BuildDirectory must be inside the private profile-256 root.' }
if (Test-Path -LiteralPath $runRoot) { throw 'Run roots are immutable; choose a new RunName.' }
$null = New-Item -ItemType Directory -Path (Join-Path $privateRoot 'runs') -Force
$null = New-Item -ItemType Directory -Path $runRoot

function Get-Sha256([string]$Path) {
  (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Assert-Hash([string]$Path, [string]$Expected, [string]$Label) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Missing $Label artifact." }
  $actual = Get-Sha256 $Path
  if ($actual -cne $Expected.ToLowerInvariant()) { throw "$Label does not match its selected build receipt." }
  return $actual
}

$receiptPath = Join-Path $build 'build-receipt.json'
$manifestPath = Join-Path $build 'owning-stack-native-host-manifest.json'
$hostPath = Join-Path $build 'native_http_host.exe'
$modulePath = Join-Path $build 'owning-stack-native-host.dll'
$sqlitePath = Join-Path $build 'e_sqlite3.dll'
$importsPath = Join-Path $build 'native-imports.txt'
foreach ($path in @($receiptPath, $manifestPath, $hostPath, $modulePath, $sqlitePath, $importsPath)) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Selected build is incomplete: $(Split-Path -Leaf $path) is missing." }
}
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$profile = $ExecutionProfile.ToLowerInvariant()
if ($receipt.Optimization -cne $Optimization -or $receipt.RuntimeProfile -cne 'trusted-generated' -or
    $receipt.StageProfile -cne 'On' -or ([string]$receipt.ExecutionProfile).ToLowerInvariant() -cne $profile) {
  throw "Selected build must be $Optimization trusted-generated, StageProfile On, and match ExecutionProfile exactly."
}
if ($manifest.moduleInfo.runtimeProfile -cne 'trusted-generated' -or
    $manifest.moduleInfo.executionProfile -cne $profile) {
  throw 'Manifest runtime/execution profile does not match the selected build receipt.'
}
$hostHash = Assert-Hash $hostPath ([string]$receipt.HostExeSha256) 'Native host executable'
$moduleHash = Assert-Hash $modulePath ([string]$receipt.ModuleSha256) 'Native runtime DLL'
$manifestHash = Assert-Hash $manifestPath ([string]$receipt.ManifestSha256) 'Native manifest'
$sqliteHash = Assert-Hash $sqlitePath ([string]$receipt.SqliteSha256) 'Pinned SQLite DLL'
$importNames = @($receipt.Imports | ForEach-Object { ([string]$_).ToUpperInvariant() } | Sort-Object -Unique)
$expectedImports = @('BCRYPT.DLL','HTTPAPI.DLL','KERNEL32.DLL','SHELL32.DLL','WS2_32.DLL')
if (($importNames -join ',') -cne ($expectedImports -join ',')) { throw 'Native host import allowlist changed.' }
if ((Get-Content -LiteralPath $importsPath -Raw) -match '(?i)(mscoree|hostfxr|coreclr|e_sqlite3)\.dll') { throw 'Native host import audit contains a CLR or statically imported SQLite module.' }

$copiedReceipt = Join-Path $runRoot 'build-receipt.json'
Copy-Item -LiteralPath $receiptPath -Destination $copiedReceipt
$fixture = Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'
$databasePath = Join-Path $fixture 'native.sqlite'
$secretPath = Join-Path $fixture 'synthetic-secret.txt'
if (-not (Test-Path -LiteralPath $databasePath -PathType Leaf) -or -not (Test-Path -LiteralPath $secretPath -PathType Leaf)) {
  throw 'The disposable synthetic HTTP fixture is missing.'
}
$refreshPath = Join-Path $runRoot 'fixture-refresh.json'
& (Join-Path $PSScriptRoot 'Refresh-Fixture.ps1') -BuildDirectory $build -OutputPath $refreshPath

$sourceScripts = @('Run-Host.ps1','Refresh-Fixture.ps1','refresh_fixture.py','Measure.ps1','Apply-Affinity.ps1','Validate-Http.ps1','aggregate_profiles.py')
$scriptHashes = [ordered]@{}
foreach ($name in $sourceScripts) { $scriptHashes[$name] = Get-Sha256 (Join-Path $PSScriptRoot $name) }
$startRecord = [ordered]@{
  runName = $RunName
  executionProfile = $profile
  runtimeProfile = 'trusted-generated'
  stageProfile = 'On'
  optimization = $Optimization
  workers = $Workers
  port = $Port
  buildDirectory = $build
  buildReceiptSha256 = Get-Sha256 $copiedReceipt
  hostExeSha256 = $hostHash
  moduleSha256 = $moduleHash
  manifestSha256 = $manifestHash
  sqliteSha256 = $sqliteHash
  fixtureRefreshSha256 = Get-Sha256 $refreshPath
  helperSha256 = $scriptHashes
  startedUtc = [DateTime]::UtcNow.ToString('O')
  stopEventName = 'Local\CampfireNative256Stop'
}
$startRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $runRoot 'run-start.json') -Encoding utf8NoBOM

$processInfo = [Diagnostics.ProcessStartInfo]::new()
$processInfo.FileName = $hostPath
$processInfo.UseShellExecute = $false
$processInfo.CreateNoWindow = $true
$processInfo.RedirectStandardOutput = $true
$processInfo.RedirectStandardError = $true
foreach ($argument in @(
  '--module', $modulePath,
  '--manifest', $manifestPath,
  '--db', $databasePath,
  '--secret-file', $secretPath,
  '--port', [string]$Port,
  '--workers', [string]$Workers,
  '--stop-event', 'Local\CampfireNative256Stop'
)) { [void]$processInfo.ArgumentList.Add($argument) }
$process = [Diagnostics.Process]::new()
$process.StartInfo = $processInfo
if (-not $process.Start()) { throw 'Native host process did not start.' }
$processId = $process.Id
[ordered]@{
  processId = $processId
  executable = $hostPath
  executableSha256 = $hostHash
  executionProfile = $profile
  workers = $Workers
  port = $Port
  processStartedUtc = [DateTime]::UtcNow.ToString('O')
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $runRoot 'host-process.json') -Encoding utf8NoBOM

$stdoutPath = Join-Path $runRoot 'native-host.log'
$stderrPath = Join-Path $runRoot 'native-host.stderr.log'
$stream = [IO.FileStream]::new($stdoutPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::ReadWrite)
$writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
$writer.AutoFlush = $true
$stderrTask = $process.StandardError.ReadToEndAsync()
try {
  while ($null -ne ($line = $process.StandardOutput.ReadLine())) { $writer.WriteLine($line) }
  $process.WaitForExit()
} finally {
  $writer.Dispose()
}
$stderr = $stderrTask.GetAwaiter().GetResult()
[IO.File]::WriteAllText($stderrPath, $stderr, [Text.UTF8Encoding]::new($false))
$exitCode = $process.ExitCode
$hostLogHash = Get-Sha256 $stdoutPath
$stderrHash = Get-Sha256 $stderrPath
$shutdownLine = Select-String -LiteralPath $stdoutPath -Pattern '^shutdown\.workers_cleaned=\d+ shutdown\.fatal_status=\d+$' | Select-Object -Last 1
$cleanedCount = $null
$fatalStatus = $null
if ($shutdownLine -and $shutdownLine.Line -match '^shutdown\.workers_cleaned=(\d+) shutdown\.fatal_status=(\d+)$') {
  $cleanedCount = [int]$Matches[1]
  $fatalStatus = [int]$Matches[2]
}
$terminal = [ordered]@{
  terminalExitCode = $exitCode
  workers = $Workers
  optimization = $Optimization
  executionProfile = $profile
  runtimeProfile = 'trusted-generated'
  stageProfile = 'On'
  hostPid = $processId
  buildReceiptSha256 = Get-Sha256 $copiedReceipt
  hostExeSha256 = $hostHash
  moduleSha256 = $moduleHash
  manifestSha256 = $manifestHash
  sqliteSha256 = $sqliteHash
  fixtureRefreshSha256 = Get-Sha256 $refreshPath
  fixturePostRunSha256 = $null
  fixturePostRunExitCode = $null
  nativeHostLogSha256 = $hostLogHash
  nativeHostStderrSha256 = $stderrHash
  workerCleanupLine = $cleanedCount
  fatalStatus = $fatalStatus
  endedUtc = [DateTime]::UtcNow.ToString('O')
}
if ($exitCode -ne 0 -or $cleanedCount -ne $Workers -or $fatalStatus -ne 0) {
  $terminal | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $runRoot 'run-receipt.json') -Encoding utf8NoBOM
  throw "Native host run failed or did not cleanly stop; preserved root: $runRoot"
}
$refreshMetadata = Get-Content -LiteralPath $refreshPath -Raw | ConvertFrom-Json
$verifyPath = Join-Path $runRoot 'fixture-postrun.json'
$fixtureDatabasePaths = @(
  (Join-Path $fixture 'native.sqlite'),
  (Join-Path $fixture 'reference.sqlite')
)
$python = Get-Command python -ErrorAction Stop
$fixtureHelper = Join-Path $PSScriptRoot 'refresh_fixture.py'
$verificationExitCode = 1
try {
  & $python.Source $fixtureHelper '--verify-unchanged' $sqlitePath $sqliteHash $verifyPath `
    $refreshMetadata.rows[0].sessionLastActiveAt $fixtureDatabasePaths[0] $fixtureDatabasePaths[1]
  $verificationExitCode = $LASTEXITCODE
} catch {
  $verificationExitCode = 1
}
$terminal.fixturePostRunExitCode = $verificationExitCode
if (Test-Path -LiteralPath $verifyPath -PathType Leaf) {
  $terminal.fixturePostRunSha256 = Get-Sha256 $verifyPath
}
$terminal | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $runRoot 'run-receipt.json') -Encoding utf8NoBOM
if ($verificationExitCode -ne 0 -or $null -eq $terminal.fixturePostRunSha256) {
  throw "Read-only post-run session freshness verification failed; preserved root: $runRoot"
}
Write-Output "run=$RunName pid=$processId profile=$profile workers=$Workers terminal=0 clean=verified"

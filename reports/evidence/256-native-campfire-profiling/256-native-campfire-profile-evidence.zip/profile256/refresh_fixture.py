from __future__ import annotations

import ctypes as c
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys


SQLITE_OK = 0
SQLITE_ROW = 100
SQLITE_DONE = 101
SQLITE_OPEN_READWRITE = 0x00000002
SQLITE_OPEN_READONLY = 0x00000001
SQLITE_OPEN_NOMUTEX = 0x00008000
SQLITE_TRANSIENT = c.c_void_p(-1)


def check(code: int, expected: int, operation: str) -> None:
    if code != expected:
        raise RuntimeError(f"SQLite fixture refresh failed at {operation}: code={code}")


def scalar_text(db: c.c_void_p, sqlite: c.CDLL, sql: bytes) -> str:
    statement = c.c_void_p()
    check(sqlite.sqlite3_prepare_v2(db, sql, -1, c.byref(statement), None), SQLITE_OK, "prepare")
    try:
        check(sqlite.sqlite3_step(statement), SQLITE_ROW, "query")
        value = sqlite.sqlite3_column_text(statement, 0)
        if value is None:
            raise RuntimeError("SQLite fixture query returned NULL")
        return value.decode("utf-8", "strict")
    finally:
        check(sqlite.sqlite3_finalize(statement), SQLITE_OK, "finalize")


def refresh(sqlite: c.CDLL, database: Path, now_text: str) -> dict[str, object]:
    db = c.c_void_p()
    check(sqlite.sqlite3_open_v2(str(database).encode("utf-8"), c.byref(db), SQLITE_OPEN_READWRITE | SQLITE_OPEN_NOMUTEX, None), SQLITE_OK, "open")
    try:
        check(sqlite.sqlite3_busy_timeout(db, 5000), SQLITE_OK, "busy_timeout")
        if scalar_text(db, sqlite, b"PRAGMA journal_mode").lower() != "wal":
            raise RuntimeError("Synthetic fixture is not provisioned in WAL mode")
        if scalar_text(db, sqlite, b"PRAGMA synchronous") != "2":
            raise RuntimeError("Fixture refresh connection is not using synchronous=FULL")
        check(sqlite.sqlite3_exec(db, b"PRAGMA foreign_keys=ON", None, None, None), SQLITE_OK, "foreign_keys")
        if scalar_text(db, sqlite, b"PRAGMA foreign_keys") != "1":
            raise RuntimeError("Fixture refresh connection did not enable foreign keys")

        statement = c.c_void_p()
        query = b"SELECT COUNT(*) FROM sessions WHERE id=70 AND user_id=7"
        check(sqlite.sqlite3_prepare_v2(db, query, -1, c.byref(statement), None), SQLITE_OK, "session_check_prepare")
        try:
            check(sqlite.sqlite3_step(statement), SQLITE_ROW, "session_check")
            if sqlite.sqlite3_column_int64(statement, 0) != 1:
                raise RuntimeError("Synthetic fixture session id 70 / user 7 is missing or ambiguous")
        finally:
            check(sqlite.sqlite3_finalize(statement), SQLITE_OK, "session_check_finalize")

        statement = c.c_void_p()
        update = b"UPDATE sessions SET last_active_at=?1, updated_at=?1 WHERE id=70 AND user_id=7"
        check(sqlite.sqlite3_prepare_v2(db, update, -1, c.byref(statement), None), SQLITE_OK, "update_prepare")
        encoded_now = now_text.encode("ascii")
        try:
            check(sqlite.sqlite3_bind_text(statement, 1, encoded_now, len(encoded_now), SQLITE_TRANSIENT), SQLITE_OK, "update_bind")
            check(sqlite.sqlite3_step(statement), SQLITE_DONE, "update_step")
            if sqlite.sqlite3_changes(db) != 1:
                raise RuntimeError("Fixture refresh did not update exactly one synthetic session")
        finally:
            check(sqlite.sqlite3_finalize(statement), SQLITE_OK, "update_finalize")

        observed = scalar_text(db, sqlite, b"SELECT last_active_at FROM sessions WHERE id=70 AND user_id=7")
        if observed != now_text:
            raise RuntimeError("Fixture session timestamp did not round-trip exactly")
        session_count = int(scalar_text(db, sqlite, b"SELECT COUNT(*) FROM sessions"))
        return {"database": database.name, "sessionCount": session_count, "sessionLastActiveAt": observed}
    finally:
        check(sqlite.sqlite3_close(db), SQLITE_OK, "close")


def verify_unchanged(sqlite: c.CDLL, database: Path, expected_timestamp: str) -> dict[str, object]:
    """Read-only check that the benchmark did not refresh its synthetic session."""
    db = c.c_void_p()
    flags = SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX
    check(sqlite.sqlite3_open_v2(str(database).encode("utf-8"), c.byref(db), flags, None), SQLITE_OK, "verify_open")
    try:
        check(sqlite.sqlite3_busy_timeout(db, 5000), SQLITE_OK, "verify_busy_timeout")
        if scalar_text(db, sqlite, b"PRAGMA journal_mode").lower() != "wal":
            raise RuntimeError("Synthetic fixture left WAL mode during benchmark")
        check(sqlite.sqlite3_exec(db, b"PRAGMA foreign_keys=ON", None, None, None), SQLITE_OK, "verify_foreign_keys")
        if scalar_text(db, sqlite, b"PRAGMA foreign_keys") != "1":
            raise RuntimeError("Read-only fixture verification did not enable foreign keys")
        count = int(scalar_text(db, sqlite, b"SELECT COUNT(*) FROM sessions WHERE id=70 AND user_id=7"))
        if count != 1:
            raise RuntimeError("Synthetic fixture session id 70 / user 7 is missing or ambiguous")
        last_active = scalar_text(db, sqlite, b"SELECT last_active_at FROM sessions WHERE id=70 AND user_id=7")
        updated = scalar_text(db, sqlite, b"SELECT updated_at FROM sessions WHERE id=70 AND user_id=7")
        unchanged = last_active == expected_timestamp and updated == expected_timestamp
        return {
            "database": database.name,
            "sessionCount": int(scalar_text(db, sqlite, b"SELECT COUNT(*) FROM sessions")),
            "lastActiveAtMatchesRefresh": last_active == expected_timestamp,
            "updatedAtMatchesRefresh": updated == expected_timestamp,
            "unchanged": unchanged,
        }
    finally:
        check(sqlite.sqlite3_close(db), SQLITE_OK, "verify_close")


def main() -> None:
    verify_mode = len(sys.argv) > 1 and sys.argv[1] == "--verify-unchanged"
    if verify_mode:
        if len(sys.argv) != 8:
            raise SystemExit("usage: refresh_fixture.py --verify-unchanged SQLITE_DLL EXPECTED_SHA256 OUTPUT_JSON EXPECTED_TIMESTAMP native.sqlite reference.sqlite")
        arguments = sys.argv[2:]
        expected_timestamp = arguments[3]
        database_arguments = arguments[4:6]
    else:
        if len(sys.argv) != 6:
            raise SystemExit("usage: refresh_fixture.py SQLITE_DLL EXPECTED_SHA256 OUTPUT_JSON native.sqlite reference.sqlite")
        arguments = sys.argv[1:]
        expected_timestamp = ""
        database_arguments = arguments[3:5]
    dll = Path(arguments[0]).resolve(strict=True)
    expected = arguments[1].lower()
    output = Path(arguments[2])
    databases = [Path(path).resolve(strict=True) for path in database_arguments]
    actual = hashlib.sha256(dll.read_bytes()).hexdigest()
    if actual != expected:
        raise RuntimeError("Pinned SQLite DLL hash mismatch")
    for database in databases:
        if database.parent != databases[0].parent or database.name not in {"native.sqlite", "reference.sqlite"}:
            raise RuntimeError("Refusing to mutate a database outside the two disposable fixture copies")

    sqlite = c.WinDLL(str(dll))
    sqlite.sqlite3_libversion.restype = c.c_char_p
    sqlite.sqlite3_open_v2.argtypes = [c.c_char_p, c.POINTER(c.c_void_p), c.c_int, c.c_char_p]
    sqlite.sqlite3_open_v2.restype = c.c_int
    sqlite.sqlite3_close.argtypes = [c.c_void_p]
    sqlite.sqlite3_close.restype = c.c_int
    sqlite.sqlite3_prepare_v2.argtypes = [c.c_void_p, c.c_char_p, c.c_int, c.POINTER(c.c_void_p), c.c_void_p]
    sqlite.sqlite3_prepare_v2.restype = c.c_int
    sqlite.sqlite3_step.argtypes = [c.c_void_p]
    sqlite.sqlite3_step.restype = c.c_int
    sqlite.sqlite3_finalize.argtypes = [c.c_void_p]
    sqlite.sqlite3_finalize.restype = c.c_int
    sqlite.sqlite3_column_text.argtypes = [c.c_void_p, c.c_int]
    sqlite.sqlite3_column_text.restype = c.c_char_p
    sqlite.sqlite3_column_int64.argtypes = [c.c_void_p, c.c_int]
    sqlite.sqlite3_column_int64.restype = c.c_int64
    sqlite.sqlite3_bind_text.argtypes = [c.c_void_p, c.c_int, c.c_char_p, c.c_int, c.c_void_p]
    sqlite.sqlite3_bind_text.restype = c.c_int
    sqlite.sqlite3_busy_timeout.argtypes = [c.c_void_p, c.c_int]
    sqlite.sqlite3_busy_timeout.restype = c.c_int
    sqlite.sqlite3_changes.argtypes = [c.c_void_p]
    sqlite.sqlite3_changes.restype = c.c_int
    sqlite.sqlite3_exec.argtypes = [c.c_void_p, c.c_char_p, c.c_void_p, c.c_void_p, c.POINTER(c.c_char_p)]
    sqlite.sqlite3_exec.restype = c.c_int

    version = sqlite.sqlite3_libversion().decode("ascii")
    if version != "3.53.3":
        raise RuntimeError(f"Unexpected pinned SQLite version: {version}")
    if verify_mode:
        rows = [verify_unchanged(sqlite, database, expected_timestamp) for database in databases]
        receipt = {
            "sqliteVersion": version,
            "sqliteSha256": actual,
            "expectedSessionTimestamp": expected_timestamp,
            "rows": rows,
            "unchanged": all(bool(row["unchanged"]) for row in rows),
        }
        if output.exists():
            raise RuntimeError("Fixture verification output path already exists")
        output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"sqliteVersion": version, "sqliteSha256": actual, "unchanged": receipt["unchanged"]}, separators=(",", ":")))
        if not receipt["unchanged"]:
            raise RuntimeError("Synthetic session timestamp changed during the benchmark")
        return
    now = dt.datetime.now(dt.timezone.utc)
    now_text = now.strftime("%Y-%m-%d %H:%M:%S.%f")
    rows = [refresh(sqlite, database, now_text) for database in databases]
    receipt = {"sqliteVersion": version, "sqliteSha256": actual, "refreshedUtc": now.isoformat().replace("+00:00", "Z"), "rows": rows}
    if output.exists():
        raise RuntimeError("Fixture refresh output path already exists")
    output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"sqliteVersion": version, "sqliteSha256": actual, "rows": rows}, separators=(",", ":")))


if __name__ == "__main__":
    main()

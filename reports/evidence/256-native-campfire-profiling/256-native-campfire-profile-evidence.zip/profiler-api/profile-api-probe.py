from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ABI_VERSION = 1
SNAPSHOT_BYTES = 552
CATEGORY_COUNT = 22
COUNTER_OFFSET = 24
COUNTER_BYTES = 24
STATUS_OK = 0
STATUS_INVALID_ARGUMENT = 1
STATUS_TIMER_FAILURE = 4
STATUS_CATEGORY_UNSUPPORTED = 5
U64_MAX = (1 << 64) - 1
EXPECTED = {
    "detailed": "CC9F53250B5DE83D69E8E7392268E83201B86B02725C006502480A4FD90244FA",
    "off": "F846CFCBA4C78D3E1482C56418B89EE9DF94F5A2EA5D9463C1B1F017F0B29541",
}
RUNS = {
    "detailed": "20261013T256000003Z-final-detailed",
    "off": "20261013T256000004Z-final-off",
}
EXPORTS = (
    "al_owning_profile_begin_v1",
    "al_owning_profile_end_v1",
    "al_owning_profile_reset_v1",
    "al_owning_profile_snapshot_v1",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def u32(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset:offset + 4], "little")


def u64(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset:offset + 8], "little")


def counter(data: bytes, category: int) -> dict[str, int]:
    offset = COUNTER_OFFSET + category * COUNTER_BYTES
    return {
        "calls": u64(data, offset),
        "ticks": u64(data, offset + 8),
        "failures": u64(data, offset + 16),
    }


def require(condition: bool, label: str, assertions: list[str]) -> None:
    if not condition:
        raise AssertionError(label)
    assertions.append(label)


def main() -> dict[str, object]:
    repo = Path(__file__).resolve().parents[2]
    results: dict[str, object] = {
        "probe": "profile-api-probe-v1",
        "python": sys.version.split()[0],
        "assertions": [],
        "dlls": {},
        "observedStatuses": {},
        "sentinelTest": "UINT64_MAX input sentinel only; no OS QPC failure was induced",
    }
    assertions = results["assertions"]
    assert isinstance(assertions, list)
    artifacts: dict[str, Path] = {}
    for profile, run_name in RUNS.items():
        run_root = repo / ".agentlang" / "campfire-native-room-read-252" / "test-runs" / run_name
        receipt_path = run_root / "test-receipt.json"
        dll_path = run_root / "test-artifacts" / "O2" / "owning-stack-native-host.dll"
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        actual_hash = sha256(dll_path)
        expected_profile = "detailed" if profile == "detailed" else "off"
        require(receipt.get("passed") is True, f"{profile} source gate receipt passed", assertions)
        require(receipt.get("executionProfile") == expected_profile,
                f"{profile} source gate receipt names execution profile {expected_profile}", assertions)
        require(receipt.get("artifactsSha256", {}).get("O2/dll", "").upper() == EXPECTED[profile],
                f"{profile} receipt pins expected O2 module hash", assertions)
        require(actual_hash == EXPECTED[profile], f"{profile} O2 module hash matches the pinned digest", assertions)
        results["dlls"][profile] = {
            "path": str(dll_path),
            "sha256": actual_hash,
            "receipt": str(receipt_path),
        }
        artifacts[profile] = dll_path

    if os.name != "nt":
        raise RuntimeError("This probe must run on Windows to load the pinned PE modules.")

    detailed_dir = os.add_dll_directory(str(artifacts["detailed"].parent))
    try:
        detailed = ctypes.CDLL(str(artifacts["detailed"]))
        begin = detailed.al_owning_profile_begin_v1
        begin.argtypes = []
        begin.restype = ctypes.c_uint64
        end = detailed.al_owning_profile_end_v1
        end.argtypes = [ctypes.c_uint32, ctypes.c_uint64, ctypes.c_int32]
        end.restype = ctypes.c_int32
        reset = detailed.al_owning_profile_reset_v1
        reset.argtypes = [ctypes.c_uint32]
        reset.restype = ctypes.c_int32
        snapshot = detailed.al_owning_profile_snapshot_v1
        snapshot.argtypes = [ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32]
        snapshot.restype = ctypes.c_int32
        require(True, "Detailed O2 DLL exposes all four profiler APIs", assertions)

        def read_snapshot() -> tuple[int, bytes]:
            buffer = (ctypes.c_ubyte * SNAPSHOT_BYTES)()
            status = snapshot(ABI_VERSION, ctypes.cast(buffer, ctypes.c_void_p), SNAPSHOT_BYTES)
            return status, bytes(buffer)

        require(reset(ABI_VERSION) == STATUS_OK, "ABI v1 reset succeeds before failure-counter probe", assertions)
        start = begin()
        require(start not in (0, U64_MAX), "begin returns a valid QPC start value", assertions)
        status = end(0, start, 1)
        results["observedStatuses"]["failedEnd"] = int(status)
        require(status == STATUS_OK, "end with failed=1 records successfully", assertions)
        snapshot_status, data = read_snapshot()
        require(snapshot_status == STATUS_OK, "snapshot succeeds after failed end", assertions)
        require(u32(data, 0) == ABI_VERSION and u32(data, 4) == SNAPSHOT_BYTES and
                u32(data, 8) == CATEGORY_COUNT and u32(data, 12) == 0,
                "snapshot header matches ABI v1 layout", assertions)
        observed = counter(data, 0)
        results["failureCounter"] = observed
        require(observed["calls"] == 1 and observed["failures"] == 1,
                "failed end increments exactly one call and one failure", assertions)

        before_invalid = data
        invalid_category_status = end(CATEGORY_COUNT, begin(), 0)
        zero_start_status = end(0, 0, 0)
        bad_failed_status = end(0, begin(), 2)
        results["observedStatuses"]["invalidCategory"] = int(invalid_category_status)
        results["observedStatuses"]["zeroStart"] = int(zero_start_status)
        results["observedStatuses"]["invalidFailedFlag"] = int(bad_failed_status)
        require(invalid_category_status == STATUS_CATEGORY_UNSUPPORTED,
                "end rejects categoryCount as unsupported", assertions)
        require(zero_start_status == STATUS_INVALID_ARGUMENT,
                "end rejects zero start ticks", assertions)
        require(bad_failed_status == STATUS_INVALID_ARGUMENT,
                "end rejects failed flag outside 0/1", assertions)
        after_invalid_status, after_invalid = read_snapshot()
        require(after_invalid_status == STATUS_OK and after_invalid == before_invalid,
                "invalid end arguments leave snapshot bytes and counters unchanged", assertions)

        sentinel_status = end(0, U64_MAX, 0)
        results["observedStatuses"]["uint64MaxSentinelEnd"] = int(sentinel_status)
        require(sentinel_status == STATUS_TIMER_FAILURE,
                "UINT64_MAX start sentinel returns TIMER_FAILURE", assertions)
        canary = bytes([0xA5]) * SNAPSHOT_BYTES
        output = (ctypes.c_ubyte * SNAPSHOT_BYTES).from_buffer_copy(canary)
        snapshot_after_sentinel = snapshot(
            ABI_VERSION, ctypes.cast(output, ctypes.c_void_p), SNAPSHOT_BYTES)
        results["observedStatuses"]["snapshotAfterSentinel"] = int(snapshot_after_sentinel)
        require(snapshot_after_sentinel == STATUS_TIMER_FAILURE,
                "snapshot reports sticky timer failure after sentinel input", assertions)
        require(bytes(output) == canary,
                "failed snapshot after sentinel leaves the output canary unchanged", assertions)
        require(reset(ABI_VERSION) == STATUS_OK,
                "ABI v1 reset clears sticky timer failure", assertions)
        cleared_status, cleared = read_snapshot()
        require(cleared_status == STATUS_OK,
                "snapshot succeeds after reset clears timer failure", assertions)
        require(all(counter(cleared, category) == {"calls": 0, "ticks": 0, "failures": 0}
                    for category in range(CATEGORY_COUNT)),
                "reset clears all 22 counters after timer failure", assertions)
    finally:
        detailed_dir.close()

    off_dir = os.add_dll_directory(str(artifacts["off"].parent))
    try:
        off = ctypes.CDLL(str(artifacts["off"]))
        missing: list[str] = []
        for export in EXPORTS:
            try:
                getattr(off, export)
            except AttributeError:
                missing.append(export)
        results["offMissingExports"] = missing
        require(missing == list(EXPORTS),
                "Off O2 DLL omits all four profiler exports", assertions)
    finally:
        off_dir.close()

    results["passed"] = True
    return results


def main_with_failure_capture() -> int:
    output_dir = Path(__file__).resolve().parent
    result_path = output_dir / "profile-api-probe-results.json"
    log_path = output_dir / "profile-api-probe.log"
    try:
        result = main()
        serialized = json.dumps(result, indent=2, sort_keys=True) + "\n"
        result_path.write_text(serialized, encoding="utf-8")
        log_path.write_text(
            "profile-api-probe: PASS\n" +
            "\n".join(f"assertion: {item}" for item in result["assertions"]) + "\n" +
            f"detailed_sha256: {result['dlls']['detailed']['sha256']}\n" +
            f"off_sha256: {result['dlls']['off']['sha256']}\n" +
            "sentinel_scope: UINT64_MAX input sentinel only; no OS QPC failure induced\n",
            encoding="utf-8")
        print(serialized, end="")
        return 0
    except Exception as error:
        failure = {
            "probe": "profile-api-probe-v1",
            "passed": False,
            "errorType": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
        }
        result_path.write_text(json.dumps(failure, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        log_path.write_text("profile-api-probe: FAIL\n" + failure["traceback"], encoding="utf-8")
        print(json.dumps(failure, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main_with_failure_capture())

# Authentication persistence validation

UTC run date: 2026-10-11. Final test source hashes are in `implementation-hashes.sha256`. Reference source pins are in `source-hashes.sha256`.

## Dependency restore and build

Root-coordinated trusted-host restore completed with `NuGetAudit=true`; raw output is `host-restore.log`. The sandbox's earlier ordinary build could not reach the vulnerability feed (NU1900); the failed output is retained in `build.log`. Following the trusted restore, the local serial build used the restored assets without another network attempt:

~~~powershell
dotnet build tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release -m:1 --no-restore
~~~

Exit code: 0; build succeeded with 0 warnings and 0 errors. Raw final output: `build-final.log`.

## Executable tests

~~~powershell
dotnet run --project tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release --no-build --no-restore
~~~

Exit code: 0; `PASS 8 groups, 95 assertions`. Raw final output: `test-run-final.log`. Each group creates a unique local SQLite fixture beneath the private `databases` directory.

Two earlier fixture expectation failures were corrected to match the pinned Rust implementation's first-two-segments `split('-')` behavior. Raw first failure is `test-run.log`; the second observed output is retained as `test-run-wrong-token-failure.log`. The intermediate passing 96-assertion output included one unrelated placeholder check later removed; it is kept as `test-run-with-placeholder.log`, not the final receipt.

The four new project/source files use LF line endings and one final LF. Their byte counts and SHA-256 values were checked after the final successful run.

## Scope limit

This validates the standalone SQLite adapter and its six typed operations against narrow real SQLite fixtures. It does not validate registration/invocation through the Core host-operation bridge, full Campfire HTTP authentication/session restoration, or integration with a live host provider.

## Follow-up compatibility correction: nonpositive session IDs

Removed the adapter-only `sessionId <= 0` input restriction. Added fixture rows with stored IDs `0` and `-1`; token lookup imports both IDs, refresh updates both rows, and a reopened provider observes the negative-ID refresh. The existing missing-ID `NotFound` case remains in the same group. This matches the pinned model/schema contract, which uses unrestricted SQLite integer primary keys.

Final follow-up commands, run against the trusted-host restore assets with no additional restore:

~~~powershell
dotnet build tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release -m:1 --no-restore
dotnet run --project tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release --no-build --no-restore
~~~

Build exit code: 0; 0 warnings and 0 errors (`build-nonpositive-id.log`). Test exit code: 0; `PASS 8 groups, 100 assertions` (`test-run-nonpositive-id.log`). Follow-up source hashes are in `implementation-hashes-239-nonpositive-id.sha256`; prior accepted run receipts and hashes above are retained as history.

## Follow-up precision correction: compare the full cutoff instant

The refresh predicate now compares the parsed database activity instant directly with the supplied UTC cutoff. It does not truncate the cutoff. The `Now` written to `last_active_at` and `updated_at` remains canonicalized to database microseconds. A new case leaves a 1 µs activity unchanged at an equal 1 µs cutoff, then confirms it refreshes at a cutoff of 1.1 µs.

This preserves the provider API's full `DateTimeOffset` instant. In the pinned Rust application, `Session::needs_resume` uses strict `< now.ago(ACTIVITY_REFRESH_RATE)` (`models/session.rs` lines 96–99). Its `Env::now` converts through `Timestamp::from_jiff`, and `Timestamp` explicitly normalizes/writes at microsecond precision (`database.rs` line 67; `time.rs` lines 14–20, 28–31). Thus ordinary Flow callers using the microsecond `UtcInstant` have the same threshold precision as upstream; the additional sub-microsecond test defines the host adapter's finer-grained input behavior without quantizing it.

Final precision-review commands used the restored assets:

~~~powershell
dotnet build tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release -m:1 --no-restore
dotnet run --project tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release --no-build --no-restore
~~~

Build exit code: 0; 0 warnings and 0 errors (`build-cutoff-precision.log`). Test exit code: 0; `PASS 8 groups, 102 assertions` (`test-run-cutoff-precision.log`). Implementation hashes are in `implementation-hashes-240-cutoff-precision.sha256`; reference hashes are in `reference-precision-hashes.sha256`. Earlier receipts remain unchanged.

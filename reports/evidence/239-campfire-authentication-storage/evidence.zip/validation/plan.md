# Campfire authentication/session persistence slice

## Evidence and compatibility target

The inspected sources are the pinned Campfire Rust checkout `6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad` and Rails reference `90b330024dec3e757c79b6a7e6568f93da8e3148`. Relevant local SHA-256 values are in `source-hashes.sha256`.

The Rust models define session lookup by exact token; refresh only when `last_active_at < cutoff`, updating IP, user-agent, last-active, and updated time; user restoration by ID has no status predicate; bot lookup uses the first two `-`-split parts with active status and bot role; ban check is exact IP-string membership; room lookup is `rooms` joined to `memberships` filtered by both IDs. `schema.sql` confirms the required columns and integer role/status values. The existing message provider uses prepared parameterized queries, opens existing DBs in read/write mode, maps provider errors to the existing closed `DbError`, and serializes Rails timestamps in UTC at microsecond precision.

## Implementation plan

Create `applications/campfire/Authentication.Persistence/AgentLang.Campfire.Authentication.Persistence.fsproj` and `SqliteProvider.fs`. The project targets net9.0, treats warnings as errors, pins Microsoft.Data.Sqlite 10.0.12, and references only the existing Campfire Persistence project for `UserId`, `RoomId`, `RoomRow`, `RoomKind`, and `DbError`. The separate namespace prevents collisions with the first Campfire provider.

The public adapter API will expose nominal struct wrappers `SessionId`, `SessionToken`, `BotKey`, and `RemoteIp`; closed role/status enums; `SessionRow`, `SessionRefresh`, and `AuthUser`; and these six methods only:

- `FindSessionByToken(SessionToken) -> Result<Option<SessionRow>, DbError>`
- `RefreshSessionBefore(SessionRefresh) -> Result<SessionRow, DbError>`
- `FindUserById(UserId) -> Result<Option<AuthUser>, DbError>`
- `AuthenticateBotKey(BotKey) -> Result<Option<AuthUser>, DbError>`
- `IsIpBanned(RemoteIp) -> Result<bool, DbError>`
- `FindRoomForUser(UserId, RoomId) -> Result<Option<RoomRow>, DbError>`

All SQL is fixed and prepared, all values are bound, and no connection/query API is exposed. `OpenExisting` fails closed for a missing file and does not create it. It has no clock dependency: refresh receives `now`, `cutoff`, and nullable request IP/user-agent values.

For refresh, parse the selected stored timestamp as a UTC instant rather than compare the database text lexically. If it is strictly older than the supplied cutoff, update in a write transaction using the exact observed `last_active_at` text in the `WHERE` clause as a compare-and-swap guard; reread the current row before returning. Equality is a no-op. This prevents an older concurrent request from overwriting a newer refresh and handles alternate valid stored timestamp representations without SQLite's millisecond date functions. Writes normalize to UTC, truncate to microseconds, and use the existing provider's Rails-compatible representation. Invalid request option values/cutoff ordering return `InvalidInput`; malformed persisted timestamps/enums fail closed as `Unavailable`; a missing refresh target returns `NotFound`.

`AuthenticateBotKey` binds its first ID and token segments exactly as the Rust split does and ignores later suffix segments. It performs no trim; the upstream controller's trimming is a separate boundary. User lookups deliberately do not filter status. Room lookup has no admin bypass and returns only the scoped membership join result.

Create `tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj` and `Program.fs`. The executable test project references only the new authentication persistence project and follows the existing standalone persistence-test convention. Each test group creates its own narrow SQLite fixture and opens its own production-shape provider instance; there is no default production DB path or fallback fixture.

Focused cases cover: positive/missing token and user lookups; every valid role/status plus invalid stored enum/timestamp; active bot, inactive/non-bot rejection, malformed keys, ignored suffixes, raw whitespace and explicit caller trimming; exact ban strings and injection-shaped values; room-member isolation including administrator non-members and orphan membership rows; exact cutoff and one-microsecond ordering, offset timestamps, `None` IP/UA, no-op preservation, update preservation of identity/token/created time, reopen persistence, missing target and invalid refresh input; trigger-abort rollback and typed error mapping; and concurrent newer/older refreshes when local SQLite handles it consistently.

## Owned files

- `applications/campfire/Authentication.Persistence/AgentLang.Campfire.Authentication.Persistence.fsproj`
- `applications/campfire/Authentication.Persistence/SqliteProvider.fs`
- `tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj`
- `tests/AgentLang.Campfire.Authentication.Persistence.Tests/Program.fs`
- Private implementation and validation records under `.agentlang/campfire-auth-storage-239/`

No Core, Flow, Host, existing Persistence source, public report/docs, or Git metadata will be changed.

## Validation

Run exactly:

~~~powershell
dotnet build tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release -m:1
dotnet run --project tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj -c Release --no-build --no-restore
~~~

The executable test project must print its assertion and group totals and exit zero. Preserve command output privately. Do not suppress NuGet audit or take a network bypass; report any restore/audit blocker to the parent for a trusted-host retry.
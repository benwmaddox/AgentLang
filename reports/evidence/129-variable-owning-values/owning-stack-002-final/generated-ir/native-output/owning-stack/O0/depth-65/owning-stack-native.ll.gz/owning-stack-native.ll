%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 8
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  %step.status.28 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %step.ok.29 = icmp eq i32 %step.status.28, 0
  br i1 %step.ok.29, label %step.continue.30, label %frame.failure.0
step.continue.30:
  %stack.offset.31 = add i32 %context.value.15, 8
  %reserve.status.32 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.31, i32 3)
  %reserve.ok.33 = icmp eq i32 %reserve.status.32, 0
  br i1 %reserve.ok.33, label %reserve.continue.34, label %frame.failure.0
reserve.continue.34:
  %callee.status.35 = call i32 @agentlang_word_0062(ptr %ctx, i32 %context.value.15, i32 %context.value.15, i32 4)
  %callee.ok.36 = icmp eq i32 %callee.status.35, 0
  br i1 %callee.ok.36, label %callee.returned.37, label %frame.failure.0
callee.returned.37:
  %stack.offset.38 = add i32 %context.value.15, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.38, i32 0, i32 0, i32 0)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %context.value.15, 8
  %cursor.check.44 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.43)
  %cursor.ok.45 = icmp eq i32 %cursor.check.44, 0
  br i1 %cursor.ok.45, label %cursor.continue.46, label %frame.failure.0
cursor.continue.46:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 8, i32 8, i32 1, i32 9)
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %runtime.ok.49 = icmp eq i32 %context.value.48, 0
  br i1 %runtime.ok.49, label %runtime.continue.50, label %frame.failure.0
runtime.continue.50:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %baseline.live.total.57 = add i32 %context.value.6, %context.value.8
  %current.live.total.58 = add i32 %context.value.52, %context.value.54
  %cleanup.live.delta.59 = sub i32 %baseline.live.total.57, %current.live.total.58
  %cleanup.local.delta.60 = sub i32 %context.value.8, %context.value.54
  %cleanup.reserved.delta.61 = sub i32 %context.value.56, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.59, i32 %cleanup.local.delta.60)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.61)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 5)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 8)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %local.is.active.68 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.69 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.70 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.71 = select i1 %local.is.active.68, i32 %local.clear.payload.69, i32 0
  %local.clear.live.type.72 = select i1 %local.is.active.68, i32 %local.clear.type.70, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.71, i32 %local.clear.live.type.72)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %frame.failure.0
runtime.continue.76:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %baseline.live.total.83 = add i32 %context.value.9, %context.value.11
  %current.live.total.84 = add i32 %context.value.78, %context.value.80
  %cleanup.live.delta.85 = sub i32 %baseline.live.total.83, %current.live.total.84
  %cleanup.local.delta.86 = sub i32 %context.value.11, %context.value.80
  %cleanup.reserved.delta.87 = sub i32 %context.value.82, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.85, i32 %cleanup.local.delta.86)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.87)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 9)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 12)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 14)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 15)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 16)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 19)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 21)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0065(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 22)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0003(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 23)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 26)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 28)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0002(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 29)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0004(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 30)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 33)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 35)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0003(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 36)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0005(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 37)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 38)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 40)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 41)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 42)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0004(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 43)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0006(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 44)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 45)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 46)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 47)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 48)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 49)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0005(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 50)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0007(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 51)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 52)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 53)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 54)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 55)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 56)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0006(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 57)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0008(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 58)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 59)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 60)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 61)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 62)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 63)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0007(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 64)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0009(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 65)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 66)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 67)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 68)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 69)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 70)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0008(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 71)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0010(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 72)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 73)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 75)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 77)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0009(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 78)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0011(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 79)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 80)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 81)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 82)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 83)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 84)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0010(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 85)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0012(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 86)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 87)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 88)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 89)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 90)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 91)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 92)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0013(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 93)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 94)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 95)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 96)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 97)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 98)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0011(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 99)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0014(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 100)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 101)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 102)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 103)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 104)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 105)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0013(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 106)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0015(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 107)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 108)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 109)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 110)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 111)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 112)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0014(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 113)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0016(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 114)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 115)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 116)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 117)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 118)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 119)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0015(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 120)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0017(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 121)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 122)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 123)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 124)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 125)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 126)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0016(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 127)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0018(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 128)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 129)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 130)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 131)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 132)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 133)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0017(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 134)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0019(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 135)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 136)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 137)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 138)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 139)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 140)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0018(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 141)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0020(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 142)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 143)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 144)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 145)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 146)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 147)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0019(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 148)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0021(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 149)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 150)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 151)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 152)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 153)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 154)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0020(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 155)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0022(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 156)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 157)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 158)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 159)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 160)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 161)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0021(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 162)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0023(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 163)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 164)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 165)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 166)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 167)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 168)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0012(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 169)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0024(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 170)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 171)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 172)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 173)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 174)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 175)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0022(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 176)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0025(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 177)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 178)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 179)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 180)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 181)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 182)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0024(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 183)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0026(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 184)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 185)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 186)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 187)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 188)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 189)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0025(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 190)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0027(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 191)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 192)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 193)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 194)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 195)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 196)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0026(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 197)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0028(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 198)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 199)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 200)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 201)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 202)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 203)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0027(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 204)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0029(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 205)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 206)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 207)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 208)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 209)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 210)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0028(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 211)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0030(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 212)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 213)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 214)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 215)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 216)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 217)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0029(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 218)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0031(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 219)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 220)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 221)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 222)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 223)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 224)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0030(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 225)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0032(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 226)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 227)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 228)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 229)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 230)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 231)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0031(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 232)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0033(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 233)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 234)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 235)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 236)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 237)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 238)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0032(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 239)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0034(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 240)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 241)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 242)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 243)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 244)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 245)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0023(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 246)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0035(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 247)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 248)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 249)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 250)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 251)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 252)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0033(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 253)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0036(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 254)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 255)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 256)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 257)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 258)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 259)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0035(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 260)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0037(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 261)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 262)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 263)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 264)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 265)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 266)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0036(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 267)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0038(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 268)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 269)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 270)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 271)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 272)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 273)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0037(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 274)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0039(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 275)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 276)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 277)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 278)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 279)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 280)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0038(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 281)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0040(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 282)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 283)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 284)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 285)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 286)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 287)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0039(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 288)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0041(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 289)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 290)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 291)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 292)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 293)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 294)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0040(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 295)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0042(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 296)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 297)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 298)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 299)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 300)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 301)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0041(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 302)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0043(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 303)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 304)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 305)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 306)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 307)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 308)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0042(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 309)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0044(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 310)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 311)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 312)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 313)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 314)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 315)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0043(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 316)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0045(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 317)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 318)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 319)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 320)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 321)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 322)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0034(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 323)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0046(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 324)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 325)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 326)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 327)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 328)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 329)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0044(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 330)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0047(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 331)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 332)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 333)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 334)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 335)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 336)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0046(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 337)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0048(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 338)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 339)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 340)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 341)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 342)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 343)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0047(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 344)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0049(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 345)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 346)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 347)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 348)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 349)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 350)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0048(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 351)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0050(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 352)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 353)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 354)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 355)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 356)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 357)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0049(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 358)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0051(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 359)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 360)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 361)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 362)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 363)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 364)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0050(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 365)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0052(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 366)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 367)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 368)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 369)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 370)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 371)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0051(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 372)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0053(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 373)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 374)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 375)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 376)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 377)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 378)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0052(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 379)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0054(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 380)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 381)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 382)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 383)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 384)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 385)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0053(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 386)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0055(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 387)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 388)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 389)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 390)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 391)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 392)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0054(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 393)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0056(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 394)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 395)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 396)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 397)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 398)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 399)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0045(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 400)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0057(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 401)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 402)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 403)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 404)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 405)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 406)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0055(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 407)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0058(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 408)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 409)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 410)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 411)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 412)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 413)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0057(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 414)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0059(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 415)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 416)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 417)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 418)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 419)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 420)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0058(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 421)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0060(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 422)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 423)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 424)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 425)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 426)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 427)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0059(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 428)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0061(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 429)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 430)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 431)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 432)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 433)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 434)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0060(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 435)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0062(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 436)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 437)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 438)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 439)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 440)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 441)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0061(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 442)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0063(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 443)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 444)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 445)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 446)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 447)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 448)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0056(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 449)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0064(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 450)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 451)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 452)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 453)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 454)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 455)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0063(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 456)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0065(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 457)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 458)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 1)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 1)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 459)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 460)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 1)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  %step.status.64 = call i32 @al_owning_charge_step(ptr %ctx, i32 461)
  %step.ok.65 = icmp eq i32 %step.status.64, 0
  br i1 %step.ok.65, label %step.continue.66, label %frame.failure.0
step.continue.66:
  %stack.offset.67 = add i32 %stack.offset.19, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 462)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %callee.status.71 = call i32 @agentlang_word_0064(ptr %ctx, i32 %stack.offset.19, i32 %stack.offset.19, i32 463)
  %callee.ok.72 = icmp eq i32 %callee.status.71, 0
  br i1 %callee.ok.72, label %callee.returned.73, label %frame.failure.0
callee.returned.73:
  %stack.offset.74 = add i32 %stack.offset.19, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.74, i32 0, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %stack.offset.79 = add i32 %stack.offset.19, 8
  %cursor.check.80 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.79)
  %cursor.ok.81 = icmp eq i32 %cursor.check.80, 0
  br i1 %cursor.ok.81, label %cursor.continue.82, label %frame.failure.0
cursor.continue.82:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 1, i32 9)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %local.is.active.87 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.88 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.89 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.90 = select i1 %local.is.active.87, i32 %local.clear.payload.88, i32 0
  %local.clear.live.type.91 = select i1 %local.is.active.87, i32 %local.clear.type.89, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.90, i32 %local.clear.live.type.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %baseline.live.total.102 = add i32 %context.value.9, %context.value.11
  %current.live.total.103 = add i32 %context.value.97, %context.value.99
  %cleanup.live.delta.104 = sub i32 %baseline.live.total.102, %current.live.total.103
  %cleanup.local.delta.105 = sub i32 %context.value.11, %context.value.99
  %cleanup.reserved.delta.106 = sub i32 %context.value.101, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.104, i32 %cleanup.local.delta.105)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.106)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 8
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 8, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 8, i32 464)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 8, i32 8, i32 1)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.26 = load i32, ptr %context.field.25, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.27 = add i32 %context.value.22, %context.value.24
  %entry.failure.delta.28 = sub i32 0, %entry.failure.live.27
  %entry.failure.local.delta.29 = sub i32 0, %context.value.24
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.28, i32 %entry.failure.local.delta.29)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.26)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 8, i32 1)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %entry.failure.0
runtime.continue.33:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %runtime.ok.36 = icmp eq i32 %context.value.35, 0
  br i1 %runtime.ok.36, label %runtime.continue.37, label %entry.failure.0
runtime.continue.37:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %entry.cleanup.total.live.46 = add i32 %context.value.41, %context.value.43
  %entry.cleanup.live.delta.47 = sub i32 0, %entry.cleanup.total.live.46
  %entry.cleanup.local.delta.48 = sub i32 0, %context.value.43
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.47, i32 %entry.cleanup.local.delta.48)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.45)
  br label %entry.return.status
entry.return.status:
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.50 = load i32, ptr %context.field.49, align 4
  ret i32 %context.value.50
}


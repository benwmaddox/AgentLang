%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 8
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  %step.status.28 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %step.ok.29 = icmp eq i32 %step.status.28, 0
  br i1 %step.ok.29, label %step.continue.30, label %frame.failure.0
step.continue.30:
  %stack.offset.31 = add i32 %context.value.15, 16
  %reserve.status.32 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.31, i32 3)
  %reserve.ok.33 = icmp eq i32 %reserve.status.32, 0
  br i1 %reserve.ok.33, label %reserve.continue.34, label %frame.failure.0
reserve.continue.34:
  %callee.status.35 = call i32 @agentlang_word_0001(ptr %ctx, i32 %context.value.15, i32 %context.value.15, i32 4)
  %callee.ok.36 = icmp eq i32 %callee.status.35, 0
  br i1 %callee.ok.36, label %callee.returned.37, label %frame.failure.0
callee.returned.37:
  %stack.offset.38 = add i32 %context.value.15, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.38, i32 0, i32 0, i32 0)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %context.value.15, 16
  %cursor.check.44 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.43)
  %cursor.ok.45 = icmp eq i32 %cursor.check.44, 0
  br i1 %cursor.ok.45, label %cursor.continue.46, label %frame.failure.0
cursor.continue.46:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 16, i32 16, i32 5, i32 9)
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %runtime.ok.49 = icmp eq i32 %context.value.48, 0
  br i1 %runtime.ok.49, label %runtime.continue.50, label %frame.failure.0
runtime.continue.50:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %baseline.live.total.57 = add i32 %context.value.6, %context.value.8
  %current.live.total.58 = add i32 %context.value.52, %context.value.54
  %cleanup.live.delta.59 = sub i32 %baseline.live.total.57, %current.live.total.58
  %cleanup.local.delta.60 = sub i32 %context.value.8, %context.value.54
  %cleanup.reserved.delta.61 = sub i32 %context.value.56, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.59, i32 %cleanup.local.delta.60)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.61)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %frame.entered.29 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.30 = icmp eq i32 %frame.entered.29, 0
  br i1 %frame.entered.ok.30, label %frame.entered.continue.31, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.offset.34 = add i32 %context.value.33, 40
  %stack.offset.35 = add i32 %context.value.33, 56
  %reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 5)
  %reserve.ok.37 = icmp eq i32 %reserve.status.36, 0
  br i1 %reserve.ok.37, label %reserve.continue.38, label %frame.reserve.failure.1
reserve.continue.38:
  call void @al_owning_local_reserve(ptr %ctx, i32 40)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, 8
  %stack.offset.44 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.44, i32 %stack.offset.43, i32 8, i32 8, i32 1, i32 8)
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.50 = load i32, ptr %context.field.49, align 4
  %runtime.ok.51 = icmp eq i32 %context.value.50, 0
  br i1 %runtime.ok.51, label %runtime.continue.52, label %frame.failure.0
runtime.continue.52:
  %step.status.53 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %step.ok.54 = icmp eq i32 %step.status.53, 0
  br i1 %step.ok.54, label %step.continue.55, label %frame.failure.0
step.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.57 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.58 = select i1 %local.is.active.56, i32 %local.previous.payload.57, i32 0
  %stack.offset.59 = add i32 %stack.offset.34, 8
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.33, i32 %stack.offset.59, i32 8, i32 8, i32 8, i32 %local.old.payload.58, i32 1)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  %stack.offset.64 = add i32 %stack.offset.34, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.64, i32 8, i32 8, i32 1)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %frame.failure.0
runtime.continue.68:
  %stack.offset.69 = add i32 %stack.offset.34, 8
  %cursor.check.70 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.69)
  %cursor.ok.71 = icmp eq i32 %cursor.check.70, 0
  br i1 %cursor.ok.71, label %cursor.continue.72, label %frame.failure.0
cursor.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %step.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %step.ok.74, label %step.continue.75, label %frame.failure.0
step.continue.75:
  %local.is.active.76 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.77 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.78 = select i1 %local.is.active.76, i32 %local.previous.payload.77, i32 0
  %stack.offset.79 = add i32 %context.value.33, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.79, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.78, i32 1)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  store i1 true, ptr %local.active.6, align 1
  store i32 8, ptr %local.payload.7, align 4
  store i32 1, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %cursor.check.88 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.89 = icmp eq i32 %cursor.check.88, 0
  br i1 %cursor.ok.89, label %cursor.continue.90, label %frame.failure.0
cursor.continue.90:
  %step.status.91 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %step.ok.92 = icmp eq i32 %step.status.91, 0
  br i1 %step.ok.92, label %step.continue.93, label %frame.failure.0
step.continue.93:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %step.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %step.ok.95, label %step.continue.96, label %frame.failure.0
step.continue.96:
  %stack.offset.97 = add i32 %stack.offset.34, 8
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 10)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %frame.failure.0
reserve.continue.100:
  %stack.offset.101 = add i32 %context.value.33, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.101, i32 8, i32 8, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 %stack.offset.34, 8
  %cursor.check.107 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.106)
  %cursor.ok.108 = icmp eq i32 %cursor.check.107, 0
  br i1 %cursor.ok.108, label %cursor.continue.109, label %frame.failure.0
cursor.continue.109:
  %step.status.110 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %step.ok.111 = icmp eq i32 %step.status.110, 0
  br i1 %step.ok.111, label %step.continue.112, label %frame.failure.0
step.continue.112:
  %local.is.active.113 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.114 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.115 = select i1 %local.is.active.113, i32 %local.previous.payload.114, i32 0
  %stack.offset.116 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.116, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.115, i32 1)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %runtime.ok.123 = icmp eq i32 %context.value.122, 0
  br i1 %runtime.ok.123, label %runtime.continue.124, label %frame.failure.0
runtime.continue.124:
  %cursor.check.125 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.126 = icmp eq i32 %cursor.check.125, 0
  br i1 %cursor.ok.126, label %cursor.continue.127, label %frame.failure.0
cursor.continue.127:
  %step.status.128 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %step.ok.129 = icmp eq i32 %step.status.128, 0
  br i1 %step.ok.129, label %step.continue.130, label %frame.failure.0
step.continue.130:
  %stack.offset.131 = add i32 %stack.offset.34, 8
  %reserve.status.132 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.131, i32 13)
  %reserve.ok.133 = icmp eq i32 %reserve.status.132, 0
  br i1 %reserve.ok.133, label %reserve.continue.134, label %frame.failure.0
reserve.continue.134:
  %stack.offset.135 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.135, i32 8, i32 8, i32 1)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %runtime.ok.138 = icmp eq i32 %context.value.137, 0
  br i1 %runtime.ok.138, label %runtime.continue.139, label %frame.failure.0
runtime.continue.139:
  %stack.offset.140 = add i32 %stack.offset.34, 8
  %cursor.check.141 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.140)
  %cursor.ok.142 = icmp eq i32 %cursor.check.141, 0
  br i1 %cursor.ok.142, label %cursor.continue.143, label %frame.failure.0
cursor.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %step.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %step.ok.145, label %step.continue.146, label %frame.failure.0
step.continue.146:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 1, i32 6)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  %stack.offset.151 = add i32 %stack.offset.34, 8
  %stack.offset.152 = add i32 %stack.offset.34, 8
  %record.grows.153 = icmp ugt i32 %stack.offset.151, %stack.offset.152
  br i1 %record.grows.153, label %record.reserve.154, label %record.release.155
record.reserve.154:
  %reserve.status.157 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.151, i32 15)
  %reserve.ok.158 = icmp eq i32 %reserve.status.157, 0
  br i1 %reserve.ok.158, label %reserve.continue.159, label %frame.failure.0
reserve.continue.159:
  br label %record.ready.156
record.release.155:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.151, i32 0, i32 6, i32 8)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  br label %record.ready.156
record.ready.156:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %stack.offset.34, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  %stack.offset.168 = add i32 %stack.offset.34, 8
  %cursor.check.169 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.168)
  %cursor.ok.170 = icmp eq i32 %cursor.check.169, 0
  br i1 %cursor.ok.170, label %cursor.continue.171, label %frame.failure.0
cursor.continue.171:
  %local.is.active.172 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.173 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.174 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.175 = select i1 %local.is.active.172, i32 %local.clear.payload.173, i32 0
  %local.clear.live.type.176 = select i1 %local.is.active.172, i32 %local.clear.type.174, i32 0
  %stack.offset.177 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.177, i32 8, i32 %local.clear.live.payload.175, i32 %local.clear.live.type.176)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %stack.offset.182 = add i32 %stack.offset.34, 8
  %cursor.check.183 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.182)
  %cursor.ok.184 = icmp eq i32 %cursor.check.183, 0
  br i1 %cursor.ok.184, label %cursor.continue.185, label %frame.failure.0
cursor.continue.185:
  %step.status.186 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %step.ok.187 = icmp eq i32 %step.status.186, 0
  br i1 %step.ok.187, label %step.continue.188, label %frame.failure.0
step.continue.188:
  %local.is.active.189 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.190 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.191 = select i1 %local.is.active.189, i32 %local.previous.payload.190, i32 0
  %stack.offset.192 = add i32 %context.value.33, 16
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.192, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.191, i32 6)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %frame.failure.0
runtime.continue.196:
  store i1 true, ptr %local.active.9, align 1
  store i32 8, ptr %local.payload.10, align 4
  store i32 6, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %runtime.ok.199 = icmp eq i32 %context.value.198, 0
  br i1 %runtime.ok.199, label %runtime.continue.200, label %frame.failure.0
runtime.continue.200:
  %cursor.check.201 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.202 = icmp eq i32 %cursor.check.201, 0
  br i1 %cursor.ok.202, label %cursor.continue.203, label %frame.failure.0
cursor.continue.203:
  %step.status.204 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %step.ok.205 = icmp eq i32 %step.status.204, 0
  br i1 %step.ok.205, label %step.continue.206, label %frame.failure.0
step.continue.206:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %step.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %step.ok.208, label %step.continue.209, label %frame.failure.0
step.continue.209:
  %stack.offset.210 = add i32 %stack.offset.34, 8
  %reserve.status.211 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.210, i32 19)
  %reserve.ok.212 = icmp eq i32 %reserve.status.211, 0
  br i1 %reserve.ok.212, label %reserve.continue.213, label %frame.failure.0
reserve.continue.213:
  %stack.offset.214 = add i32 %context.value.33, 16
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.214, i32 8, i32 8, i32 6)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  %stack.offset.219 = add i32 %stack.offset.34, 8
  %cursor.check.220 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.219)
  %cursor.ok.221 = icmp eq i32 %cursor.check.220, 0
  br i1 %cursor.ok.221, label %cursor.continue.222, label %frame.failure.0
cursor.continue.222:
  %step.status.223 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %step.ok.224 = icmp eq i32 %step.status.223, 0
  br i1 %step.ok.224, label %step.continue.225, label %frame.failure.0
step.continue.225:
  %local.is.active.226 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.227 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.228 = select i1 %local.is.active.226, i32 %local.previous.payload.227, i32 0
  %stack.offset.229 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.229, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.228, i32 6)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 6, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %cursor.check.238 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.239 = icmp eq i32 %cursor.check.238, 0
  br i1 %cursor.ok.239, label %cursor.continue.240, label %frame.failure.0
cursor.continue.240:
  %step.status.241 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %step.ok.242 = icmp eq i32 %step.status.241, 0
  br i1 %step.ok.242, label %step.continue.243, label %frame.failure.0
step.continue.243:
  %stack.offset.244 = add i32 %stack.offset.34, 8
  %reserve.status.245 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.244, i32 22)
  %reserve.ok.246 = icmp eq i32 %reserve.status.245, 0
  br i1 %reserve.ok.246, label %reserve.continue.247, label %frame.failure.0
reserve.continue.247:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %context.value.33, i32 8, i32 8, i32 1)
  %context.field.248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.249 = load i32, ptr %context.field.248, align 4
  %runtime.ok.250 = icmp eq i32 %context.value.249, 0
  br i1 %runtime.ok.250, label %runtime.continue.251, label %frame.failure.0
runtime.continue.251:
  %stack.offset.252 = add i32 %stack.offset.34, 8
  %cursor.check.253 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.252)
  %cursor.ok.254 = icmp eq i32 %cursor.check.253, 0
  br i1 %cursor.ok.254, label %cursor.continue.255, label %frame.failure.0
cursor.continue.255:
  %step.status.256 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %step.ok.257 = icmp eq i32 %step.status.256, 0
  br i1 %step.ok.257, label %step.continue.258, label %frame.failure.0
step.continue.258:
  %local.is.active.259 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.260 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.261 = select i1 %local.is.active.259, i32 %local.previous.payload.260, i32 0
  %stack.offset.262 = add i32 %context.value.33, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.262, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.261, i32 1)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %frame.failure.0
runtime.continue.266:
  store i1 true, ptr %local.active.18, align 1
  store i32 8, ptr %local.payload.19, align 4
  store i32 1, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %frame.failure.0
runtime.continue.270:
  %cursor.check.271 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.272 = icmp eq i32 %cursor.check.271, 0
  br i1 %cursor.ok.272, label %cursor.continue.273, label %frame.failure.0
cursor.continue.273:
  %step.status.274 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %step.ok.275 = icmp eq i32 %step.status.274, 0
  br i1 %step.ok.275, label %step.continue.276, label %frame.failure.0
step.continue.276:
  %stack.offset.277 = add i32 %stack.offset.34, 8
  %reserve.status.278 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.277, i32 25)
  %reserve.ok.279 = icmp eq i32 %reserve.status.278, 0
  br i1 %reserve.ok.279, label %reserve.continue.280, label %frame.failure.0
reserve.continue.280:
  %stack.offset.281 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.281, i32 8, i32 8, i32 6)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %stack.offset.286 = add i32 %stack.offset.34, 8
  %cursor.check.287 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.286)
  %cursor.ok.288 = icmp eq i32 %cursor.check.287, 0
  br i1 %cursor.ok.288, label %cursor.continue.289, label %frame.failure.0
cursor.continue.289:
  %step.status.290 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %step.ok.291 = icmp eq i32 %step.status.290, 0
  br i1 %step.ok.291, label %step.continue.292, label %frame.failure.0
step.continue.292:
  %stack.offset.293 = add i32 %stack.offset.34, 8
  %stack.offset.294 = add i32 %stack.offset.293, 8
  %reserve.status.295 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.294, i32 27)
  %reserve.ok.296 = icmp eq i32 %reserve.status.295, 0
  br i1 %reserve.ok.296, label %reserve.continue.297, label %frame.failure.0
reserve.continue.297:
  %stack.offset.298 = add i32 %context.value.33, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.293, i32 %stack.offset.298, i32 8, i32 8, i32 1)
  %context.field.299 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.300 = load i32, ptr %context.field.299, align 4
  %runtime.ok.301 = icmp eq i32 %context.value.300, 0
  br i1 %runtime.ok.301, label %runtime.continue.302, label %frame.failure.0
runtime.continue.302:
  %stack.offset.303 = add i32 %stack.offset.34, 16
  %cursor.check.304 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.303)
  %cursor.ok.305 = icmp eq i32 %cursor.check.304, 0
  br i1 %cursor.ok.305, label %cursor.continue.306, label %frame.failure.0
cursor.continue.306:
  %step.status.307 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %step.ok.308 = icmp eq i32 %step.status.307, 0
  br i1 %step.ok.308, label %step.continue.309, label %frame.failure.0
step.continue.309:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 6, i32 6)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %frame.failure.0
runtime.continue.313:
  %stack.offset.314 = add i32 %stack.offset.34, 8
  %stack.offset.315 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.314, i32 %stack.offset.315, i32 8, i32 8, i32 1, i32 6)
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %runtime.ok.318 = icmp eq i32 %context.value.317, 0
  br i1 %runtime.ok.318, label %runtime.continue.319, label %frame.failure.0
runtime.continue.319:
  %stack.offset.320 = add i32 %stack.offset.34, 16
  %stack.offset.321 = add i32 %stack.offset.34, 16
  %record.grows.322 = icmp ugt i32 %stack.offset.320, %stack.offset.321
  br i1 %record.grows.322, label %record.reserve.323, label %record.release.324
record.reserve.323:
  %reserve.status.326 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.320, i32 29)
  %reserve.ok.327 = icmp eq i32 %reserve.status.326, 0
  br i1 %reserve.ok.327, label %reserve.continue.328, label %frame.failure.0
reserve.continue.328:
  br label %record.ready.325
record.release.324:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.320, i32 0, i32 5, i32 16)
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %runtime.ok.331 = icmp eq i32 %context.value.330, 0
  br i1 %runtime.ok.331, label %runtime.continue.332, label %frame.failure.0
runtime.continue.332:
  br label %record.ready.325
record.ready.325:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %stack.offset.34, i32 16, i32 16, i32 0, i32 0)
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %runtime.ok.335 = icmp eq i32 %context.value.334, 0
  br i1 %runtime.ok.335, label %runtime.continue.336, label %frame.failure.0
runtime.continue.336:
  %stack.offset.337 = add i32 %stack.offset.34, 16
  %cursor.check.338 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.337)
  %cursor.ok.339 = icmp eq i32 %cursor.check.338, 0
  br i1 %cursor.ok.339, label %cursor.continue.340, label %frame.failure.0
cursor.continue.340:
  %local.is.active.341 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.342 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.343 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.344 = select i1 %local.is.active.341, i32 %local.clear.payload.342, i32 0
  %local.clear.live.type.345 = select i1 %local.is.active.341, i32 %local.clear.type.343, i32 0
  %stack.offset.346 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.346, i32 8, i32 %local.clear.live.payload.344, i32 %local.clear.live.type.345)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.is.active.351 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.352 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.353 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.354 = select i1 %local.is.active.351, i32 %local.clear.payload.352, i32 0
  %local.clear.live.type.355 = select i1 %local.is.active.351, i32 %local.clear.type.353, i32 0
  %stack.offset.356 = add i32 %context.value.33, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.356, i32 8, i32 %local.clear.live.payload.354, i32 %local.clear.live.type.355)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %stack.offset.361 = add i32 %stack.offset.34, 16
  %cursor.check.362 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.361)
  %cursor.ok.363 = icmp eq i32 %cursor.check.362, 0
  br i1 %cursor.ok.363, label %cursor.continue.364, label %frame.failure.0
cursor.continue.364:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.34, i32 16, i32 16, i32 5, i32 9)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %local.is.active.369 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.370 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.371 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.372 = select i1 %local.is.active.369, i32 %local.clear.payload.370, i32 0
  %local.clear.live.type.373 = select i1 %local.is.active.369, i32 %local.clear.type.371, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.33, i32 8, i32 %local.clear.live.payload.372, i32 %local.clear.live.type.373)
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %runtime.ok.376 = icmp eq i32 %context.value.375, 0
  br i1 %runtime.ok.376, label %runtime.continue.377, label %frame.failure.0
runtime.continue.377:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.378 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.379 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.380 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.381 = select i1 %local.is.active.378, i32 %local.clear.payload.379, i32 0
  %local.clear.live.type.382 = select i1 %local.is.active.378, i32 %local.clear.type.380, i32 0
  %stack.offset.383 = add i32 %context.value.33, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.383, i32 8, i32 %local.clear.live.payload.381, i32 %local.clear.live.type.382)
  %context.field.384 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.385 = load i32, ptr %context.field.384, align 4
  %runtime.ok.386 = icmp eq i32 %context.value.385, 0
  br i1 %runtime.ok.386, label %runtime.continue.387, label %frame.failure.0
runtime.continue.387:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.388 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.389 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.390 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.391 = select i1 %local.is.active.388, i32 %local.clear.payload.389, i32 0
  %local.clear.live.type.392 = select i1 %local.is.active.388, i32 %local.clear.type.390, i32 0
  %stack.offset.393 = add i32 %context.value.33, 16
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.393, i32 8, i32 %local.clear.live.payload.391, i32 %local.clear.live.type.392)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  call void @al_owning_local_release(ptr %ctx, i32 40)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.33, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %context.field.400 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.401 = load i32, ptr %context.field.400, align 4
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %baseline.live.total.404 = add i32 %context.value.24, %context.value.26
  %current.live.total.405 = add i32 %context.value.399, %context.value.401
  %cleanup.live.delta.406 = sub i32 %baseline.live.total.404, %current.live.total.405
  %cleanup.local.delta.407 = sub i32 %context.value.26, %context.value.401
  %cleanup.reserved.delta.408 = sub i32 %context.value.403, %context.value.28
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.406, i32 %cleanup.local.delta.407)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.408)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %local.active.21 = alloca i1, align 1
  %local.payload.22 = alloca i32, align 4
  %local.type.23 = alloca i32, align 4
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %local.active.24 = alloca i1, align 1
  %local.payload.25 = alloca i32, align 4
  %local.type.26 = alloca i32, align 4
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %local.active.27 = alloca i1, align 1
  %local.payload.28 = alloca i32, align 4
  %local.type.29 = alloca i32, align 4
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  %local.active.30 = alloca i1, align 1
  %local.payload.31 = alloca i32, align 4
  %local.type.32 = alloca i32, align 4
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %context.field.35 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.36 = load i32, ptr %context.field.35, align 4
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %frame.entered.41 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.42 = icmp eq i32 %frame.entered.41, 0
  br i1 %frame.entered.ok.42, label %frame.entered.continue.43, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.offset.46 = add i32 %context.value.45, 80
  %stack.offset.47 = add i32 %context.value.45, 88
  %reserve.status.48 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.47, i32 30)
  %reserve.ok.49 = icmp eq i32 %reserve.status.48, 0
  br i1 %reserve.ok.49, label %reserve.continue.50, label %frame.reserve.failure.1
reserve.continue.50:
  call void @al_owning_local_reserve(ptr %ctx, i32 80)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %frame.failure.0
runtime.continue.58:
  %step.status.59 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %step.ok.60 = icmp eq i32 %step.status.59, 0
  br i1 %step.ok.60, label %step.continue.61, label %frame.failure.0
step.continue.61:
  %local.is.active.62 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.63 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.64 = select i1 %local.is.active.62, i32 %local.previous.payload.63, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.45, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.64, i32 1)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %frame.failure.0
runtime.continue.68:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %frame.failure.0
runtime.continue.72:
  %cursor.check.73 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.74 = icmp eq i32 %cursor.check.73, 0
  br i1 %cursor.ok.74, label %cursor.continue.75, label %frame.failure.0
cursor.continue.75:
  %step.status.76 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %step.ok.77 = icmp eq i32 %step.status.76, 0
  br i1 %step.ok.77, label %step.continue.78, label %frame.failure.0
step.continue.78:
  %stack.offset.79 = add i32 %stack.offset.46, 8
  %reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.79, i32 33)
  %reserve.ok.81 = icmp eq i32 %reserve.status.80, 0
  br i1 %reserve.ok.81, label %reserve.continue.82, label %frame.failure.0
reserve.continue.82:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %context.value.45, i32 8, i32 8, i32 1)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %stack.offset.87 = add i32 %stack.offset.46, 8
  %cursor.check.88 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.87)
  %cursor.ok.89 = icmp eq i32 %cursor.check.88, 0
  br i1 %cursor.ok.89, label %cursor.continue.90, label %frame.failure.0
cursor.continue.90:
  %step.status.91 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %step.ok.92 = icmp eq i32 %step.status.91, 0
  br i1 %step.ok.92, label %step.continue.93, label %frame.failure.0
step.continue.93:
  %stack.offset.94 = add i32 %stack.offset.46, 8
  %stack.offset.95 = add i32 %stack.offset.94, 8
  %reserve.status.96 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.95, i32 35)
  %reserve.ok.97 = icmp eq i32 %reserve.status.96, 0
  br i1 %reserve.ok.97, label %reserve.continue.98, label %frame.failure.0
reserve.continue.98:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.94, i64 700, i32 1)
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %runtime.ok.101 = icmp eq i32 %context.value.100, 0
  br i1 %runtime.ok.101, label %runtime.continue.102, label %frame.failure.0
runtime.continue.102:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %stack.offset.107 = add i32 %stack.offset.46, 16
  %cursor.check.108 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.107)
  %cursor.ok.109 = icmp eq i32 %cursor.check.108, 0
  br i1 %cursor.ok.109, label %cursor.continue.110, label %frame.failure.0
cursor.continue.110:
  %step.status.111 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %step.ok.112 = icmp eq i32 %step.status.111, 0
  br i1 %step.ok.112, label %step.continue.113, label %frame.failure.0
step.continue.113:
  %stack.offset.114 = add i32 %stack.offset.46, 16
  %reserve.status.115 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.114, i32 37)
  %reserve.ok.116 = icmp eq i32 %reserve.status.115, 0
  br i1 %reserve.ok.116, label %reserve.continue.117, label %frame.failure.0
reserve.continue.117:
  %callee.status.118 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 38)
  %callee.ok.119 = icmp eq i32 %callee.status.118, 0
  br i1 %callee.ok.119, label %callee.returned.120, label %frame.failure.0
callee.returned.120:
  %stack.offset.121 = add i32 %stack.offset.46, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.121, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %runtime.ok.124 = icmp eq i32 %context.value.123, 0
  br i1 %runtime.ok.124, label %runtime.continue.125, label %frame.failure.0
runtime.continue.125:
  %stack.offset.126 = add i32 %stack.offset.46, 16
  %cursor.check.127 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.126)
  %cursor.ok.128 = icmp eq i32 %cursor.check.127, 0
  br i1 %cursor.ok.128, label %cursor.continue.129, label %frame.failure.0
cursor.continue.129:
  %step.status.130 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %step.ok.131 = icmp eq i32 %step.status.130, 0
  br i1 %step.ok.131, label %step.continue.132, label %frame.failure.0
step.continue.132:
  %local.is.active.133 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.134 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.135 = select i1 %local.is.active.133, i32 %local.previous.payload.134, i32 0
  %stack.offset.136 = add i32 %context.value.45, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.136, i32 %stack.offset.46, i32 16, i32 16, i32 16, i32 %local.old.payload.135, i32 5)
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %runtime.ok.139 = icmp eq i32 %context.value.138, 0
  br i1 %runtime.ok.139, label %runtime.continue.140, label %frame.failure.0
runtime.continue.140:
  store i1 true, ptr %local.active.6, align 1
  store i32 16, ptr %local.payload.7, align 4
  store i32 5, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 16, i32 16, i32 5)
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %runtime.ok.143 = icmp eq i32 %context.value.142, 0
  br i1 %runtime.ok.143, label %runtime.continue.144, label %frame.failure.0
runtime.continue.144:
  %cursor.check.145 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.146 = icmp eq i32 %cursor.check.145, 0
  br i1 %cursor.ok.146, label %cursor.continue.147, label %frame.failure.0
cursor.continue.147:
  %step.status.148 = call i32 @al_owning_charge_step(ptr %ctx, i32 40)
  %step.ok.149 = icmp eq i32 %step.status.148, 0
  br i1 %step.ok.149, label %step.continue.150, label %frame.failure.0
step.continue.150:
  %stack.offset.151 = add i32 %stack.offset.46, 8
  %reserve.status.152 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.151, i32 41)
  %reserve.ok.153 = icmp eq i32 %reserve.status.152, 0
  br i1 %reserve.ok.153, label %reserve.continue.154, label %frame.failure.0
reserve.continue.154:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %context.value.45, i32 8, i32 8, i32 1)
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %runtime.ok.157 = icmp eq i32 %context.value.156, 0
  br i1 %runtime.ok.157, label %runtime.continue.158, label %frame.failure.0
runtime.continue.158:
  %stack.offset.159 = add i32 %stack.offset.46, 8
  %cursor.check.160 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.159)
  %cursor.ok.161 = icmp eq i32 %cursor.check.160, 0
  br i1 %cursor.ok.161, label %cursor.continue.162, label %frame.failure.0
cursor.continue.162:
  %step.status.163 = call i32 @al_owning_charge_step(ptr %ctx, i32 42)
  %step.ok.164 = icmp eq i32 %step.status.163, 0
  br i1 %step.ok.164, label %step.continue.165, label %frame.failure.0
step.continue.165:
  %stack.offset.166 = add i32 %stack.offset.46, 8
  %stack.offset.167 = add i32 %stack.offset.166, 8
  %reserve.status.168 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.167, i32 43)
  %reserve.ok.169 = icmp eq i32 %reserve.status.168, 0
  br i1 %reserve.ok.169, label %reserve.continue.170, label %frame.failure.0
reserve.continue.170:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.166, i64 0, i32 1)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %runtime.ok.177 = icmp eq i32 %context.value.176, 0
  br i1 %runtime.ok.177, label %runtime.continue.178, label %frame.failure.0
runtime.continue.178:
  %stack.offset.179 = add i32 %stack.offset.46, 16
  %cursor.check.180 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.179)
  %cursor.ok.181 = icmp eq i32 %cursor.check.180, 0
  br i1 %cursor.ok.181, label %cursor.continue.182, label %frame.failure.0
cursor.continue.182:
  %step.status.183 = call i32 @al_owning_charge_step(ptr %ctx, i32 44)
  %step.ok.184 = icmp eq i32 %step.status.183, 0
  br i1 %step.ok.184, label %step.continue.185, label %frame.failure.0
step.continue.185:
  %stack.offset.186 = add i32 %stack.offset.46, 8
  %equals.result.187 = call i32 @al_owning_equal(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.186, i32 8)
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %runtime.ok.190 = icmp eq i32 %context.value.189, 0
  br i1 %runtime.ok.190, label %runtime.continue.191, label %frame.failure.0
runtime.continue.191:
  %equals.bool.192 = icmp ne i32 %equals.result.187, 0
  %equals.value.193 = zext i1 %equals.bool.192 to i64
  %stack.offset.194 = add i32 %stack.offset.46, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.194, i32 8, i32 8, i32 1)
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %runtime.ok.197 = icmp eq i32 %context.value.196, 0
  br i1 %runtime.ok.197, label %runtime.continue.198, label %frame.failure.0
runtime.continue.198:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %frame.failure.0
runtime.continue.202:
  %stack.offset.203 = add i32 %stack.offset.46, 8
  %reserve.status.204 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.203, i32 45)
  %reserve.ok.205 = icmp eq i32 %reserve.status.204, 0
  br i1 %reserve.ok.205, label %reserve.continue.206, label %frame.failure.0
reserve.continue.206:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.46, i64 %equals.value.193, i32 2)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.212 = load i32, ptr %context.field.211, align 4
  %runtime.ok.213 = icmp eq i32 %context.value.212, 0
  br i1 %runtime.ok.213, label %runtime.continue.214, label %frame.failure.0
runtime.continue.214:
  %stack.offset.215 = add i32 %stack.offset.46, 8
  %cursor.check.216 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.215)
  %cursor.ok.217 = icmp eq i32 %cursor.check.216, 0
  br i1 %cursor.ok.217, label %cursor.continue.218, label %frame.failure.0
cursor.continue.218:
  %step.status.219 = call i32 @al_owning_charge_step(ptr %ctx, i32 46)
  %step.ok.220 = icmp eq i32 %step.status.219, 0
  br i1 %step.ok.220, label %step.continue.221, label %frame.failure.0
step.continue.221:
  %if.condition.raw.222 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.46)
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %runtime.ok.225 = icmp eq i32 %context.value.224, 0
  br i1 %runtime.ok.225, label %runtime.continue.226, label %frame.failure.0
runtime.continue.226:
  %if.condition.227 = icmp ne i64 %if.condition.raw.222, 0
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 2)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %frame.failure.0
runtime.continue.231:
  br i1 %if.condition.227, label %if.then.232, label %if.else.233
if.then.232:
  %step.status.235 = call i32 @al_owning_charge_step(ptr %ctx, i32 47)
  %step.ok.236 = icmp eq i32 %step.status.235, 0
  br i1 %step.ok.236, label %step.continue.237, label %frame.failure.0
step.continue.237:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %step.status.238 = call i32 @al_owning_charge_step(ptr %ctx, i32 48)
  %step.ok.239 = icmp eq i32 %step.status.238, 0
  br i1 %step.ok.239, label %step.continue.240, label %frame.failure.0
step.continue.240:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %step.status.241 = call i32 @al_owning_charge_step(ptr %ctx, i32 49)
  %step.ok.242 = icmp eq i32 %step.status.241, 0
  br i1 %step.ok.242, label %step.continue.243, label %frame.failure.0
step.continue.243:
  %stack.offset.244 = add i32 %stack.offset.46, 8
  %reserve.status.245 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.244, i32 50)
  %reserve.ok.246 = icmp eq i32 %reserve.status.245, 0
  br i1 %reserve.ok.246, label %reserve.continue.247, label %frame.failure.0
reserve.continue.247:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %context.value.45, i32 8, i32 8, i32 1)
  %context.field.248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.249 = load i32, ptr %context.field.248, align 4
  %runtime.ok.250 = icmp eq i32 %context.value.249, 0
  br i1 %runtime.ok.250, label %runtime.continue.251, label %frame.failure.0
runtime.continue.251:
  %stack.offset.252 = add i32 %stack.offset.46, 8
  %cursor.check.253 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.252)
  %cursor.ok.254 = icmp eq i32 %cursor.check.253, 0
  br i1 %cursor.ok.254, label %cursor.continue.255, label %frame.failure.0
cursor.continue.255:
  %step.status.256 = call i32 @al_owning_charge_step(ptr %ctx, i32 51)
  %step.ok.257 = icmp eq i32 %step.status.256, 0
  br i1 %step.ok.257, label %step.continue.258, label %frame.failure.0
step.continue.258:
  %local.is.active.259 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.260 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.261 = select i1 %local.is.active.259, i32 %local.previous.payload.260, i32 0
  %stack.offset.262 = add i32 %context.value.45, 40
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.262, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.261, i32 1)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %frame.failure.0
runtime.continue.266:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %frame.failure.0
runtime.continue.270:
  %cursor.check.271 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.272 = icmp eq i32 %cursor.check.271, 0
  br i1 %cursor.ok.272, label %cursor.continue.273, label %frame.failure.0
cursor.continue.273:
  %step.status.274 = call i32 @al_owning_charge_step(ptr %ctx, i32 52)
  %step.ok.275 = icmp eq i32 %step.status.274, 0
  br i1 %step.ok.275, label %step.continue.276, label %frame.failure.0
step.continue.276:
  %stack.offset.277 = add i32 %stack.offset.46, 8
  %reserve.status.278 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.277, i32 53)
  %reserve.ok.279 = icmp eq i32 %reserve.status.278, 0
  br i1 %reserve.ok.279, label %reserve.continue.280, label %frame.failure.0
reserve.continue.280:
  %stack.offset.281 = add i32 %context.value.45, 40
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.281, i32 8, i32 8, i32 1)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %stack.offset.286 = add i32 %stack.offset.46, 8
  %cursor.check.287 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.286)
  %cursor.ok.288 = icmp eq i32 %cursor.check.287, 0
  br i1 %cursor.ok.288, label %cursor.continue.289, label %frame.failure.0
cursor.continue.289:
  %step.status.290 = call i32 @al_owning_charge_step(ptr %ctx, i32 54)
  %step.ok.291 = icmp eq i32 %step.status.290, 0
  br i1 %step.ok.291, label %step.continue.292, label %frame.failure.0
step.continue.292:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 1, i32 6)
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %runtime.ok.295 = icmp eq i32 %context.value.294, 0
  br i1 %runtime.ok.295, label %runtime.continue.296, label %frame.failure.0
runtime.continue.296:
  %stack.offset.297 = add i32 %stack.offset.46, 8
  %stack.offset.298 = add i32 %stack.offset.46, 8
  %record.grows.299 = icmp ugt i32 %stack.offset.297, %stack.offset.298
  br i1 %record.grows.299, label %record.reserve.300, label %record.release.301
record.reserve.300:
  %reserve.status.303 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.297, i32 55)
  %reserve.ok.304 = icmp eq i32 %reserve.status.303, 0
  br i1 %reserve.ok.304, label %reserve.continue.305, label %frame.failure.0
reserve.continue.305:
  br label %record.ready.302
record.release.301:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.297, i32 0, i32 6, i32 8)
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %runtime.ok.308 = icmp eq i32 %context.value.307, 0
  br i1 %runtime.ok.308, label %runtime.continue.309, label %frame.failure.0
runtime.continue.309:
  br label %record.ready.302
record.ready.302:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %stack.offset.46, i32 8, i32 8, i32 0, i32 0)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %frame.failure.0
runtime.continue.313:
  %stack.offset.314 = add i32 %stack.offset.46, 8
  %cursor.check.315 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.314)
  %cursor.ok.316 = icmp eq i32 %cursor.check.315, 0
  br i1 %cursor.ok.316, label %cursor.continue.317, label %frame.failure.0
cursor.continue.317:
  %local.is.active.318 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.319 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.320 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.321 = select i1 %local.is.active.318, i32 %local.clear.payload.319, i32 0
  %local.clear.live.type.322 = select i1 %local.is.active.318, i32 %local.clear.type.320, i32 0
  %stack.offset.323 = add i32 %context.value.45, 40
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.323, i32 8, i32 %local.clear.live.payload.321, i32 %local.clear.live.type.322)
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %runtime.ok.326 = icmp eq i32 %context.value.325, 0
  br i1 %runtime.ok.326, label %runtime.continue.327, label %frame.failure.0
runtime.continue.327:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %stack.offset.328 = add i32 %stack.offset.46, 8
  %cursor.check.329 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.328)
  %cursor.ok.330 = icmp eq i32 %cursor.check.329, 0
  br i1 %cursor.ok.330, label %cursor.continue.331, label %frame.failure.0
cursor.continue.331:
  %step.status.332 = call i32 @al_owning_charge_step(ptr %ctx, i32 56)
  %step.ok.333 = icmp eq i32 %step.status.332, 0
  br i1 %step.ok.333, label %step.continue.334, label %frame.failure.0
step.continue.334:
  %local.is.active.335 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.336 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.337 = select i1 %local.is.active.335, i32 %local.previous.payload.336, i32 0
  %stack.offset.338 = add i32 %context.value.45, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.338, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.337, i32 6)
  %context.field.339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.340 = load i32, ptr %context.field.339, align 4
  %runtime.ok.341 = icmp eq i32 %context.value.340, 0
  br i1 %runtime.ok.341, label %runtime.continue.342, label %frame.failure.0
runtime.continue.342:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 6, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 6)
  %context.field.343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.344 = load i32, ptr %context.field.343, align 4
  %runtime.ok.345 = icmp eq i32 %context.value.344, 0
  br i1 %runtime.ok.345, label %runtime.continue.346, label %frame.failure.0
runtime.continue.346:
  %cursor.check.347 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.348 = icmp eq i32 %cursor.check.347, 0
  br i1 %cursor.ok.348, label %cursor.continue.349, label %frame.failure.0
cursor.continue.349:
  %step.status.350 = call i32 @al_owning_charge_step(ptr %ctx, i32 57)
  %step.ok.351 = icmp eq i32 %step.status.350, 0
  br i1 %step.ok.351, label %step.continue.352, label %frame.failure.0
step.continue.352:
  %stack.offset.353 = add i32 %stack.offset.46, 8
  %reserve.status.354 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.353, i32 58)
  %reserve.ok.355 = icmp eq i32 %reserve.status.354, 0
  br i1 %reserve.ok.355, label %reserve.continue.356, label %frame.failure.0
reserve.continue.356:
  %stack.offset.357 = add i32 %context.value.45, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.357, i32 8, i32 8, i32 6)
  %context.field.358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.359 = load i32, ptr %context.field.358, align 4
  %runtime.ok.360 = icmp eq i32 %context.value.359, 0
  br i1 %runtime.ok.360, label %runtime.continue.361, label %frame.failure.0
runtime.continue.361:
  %stack.offset.362 = add i32 %stack.offset.46, 8
  %cursor.check.363 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.362)
  %cursor.ok.364 = icmp eq i32 %cursor.check.363, 0
  br i1 %cursor.ok.364, label %cursor.continue.365, label %frame.failure.0
cursor.continue.365:
  %step.status.366 = call i32 @al_owning_charge_step(ptr %ctx, i32 59)
  %step.ok.367 = icmp eq i32 %step.status.366, 0
  br i1 %step.ok.367, label %step.continue.368, label %frame.failure.0
step.continue.368:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 1, i32 7)
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %runtime.ok.371 = icmp eq i32 %context.value.370, 0
  br i1 %runtime.ok.371, label %runtime.continue.372, label %frame.failure.0
runtime.continue.372:
  %stack.offset.373 = add i32 %stack.offset.46, 8
  %stack.offset.374 = add i32 %stack.offset.46, 8
  %field.grows.375 = icmp ugt i32 %stack.offset.373, %stack.offset.374
  br i1 %field.grows.375, label %field.reserve.376, label %field.release.377
field.reserve.376:
  %reserve.status.379 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.373, i32 60)
  %reserve.ok.380 = icmp eq i32 %reserve.status.379, 0
  br i1 %reserve.ok.380, label %reserve.continue.381, label %frame.failure.0
reserve.continue.381:
  br label %field.ready.378
field.release.377:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.373, i32 0, i32 1, i32 8)
  %context.field.382 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.383 = load i32, ptr %context.field.382, align 4
  %runtime.ok.384 = icmp eq i32 %context.value.383, 0
  br i1 %runtime.ok.384, label %runtime.continue.385, label %frame.failure.0
runtime.continue.385:
  br label %field.ready.378
field.ready.378:
  %stack.offset.386 = add i32 %stack.offset.46, 8
  %cursor.check.387 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.386)
  %cursor.ok.388 = icmp eq i32 %cursor.check.387, 0
  br i1 %cursor.ok.388, label %cursor.continue.389, label %frame.failure.0
cursor.continue.389:
  %local.is.active.390 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.391 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.392 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.393 = select i1 %local.is.active.390, i32 %local.clear.payload.391, i32 0
  %local.clear.live.type.394 = select i1 %local.is.active.390, i32 %local.clear.type.392, i32 0
  %stack.offset.395 = add i32 %context.value.45, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.395, i32 8, i32 %local.clear.live.payload.393, i32 %local.clear.live.type.394)
  %context.field.396 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.397 = load i32, ptr %context.field.396, align 4
  %runtime.ok.398 = icmp eq i32 %context.value.397, 0
  br i1 %runtime.ok.398, label %runtime.continue.399, label %frame.failure.0
runtime.continue.399:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %stack.offset.400 = add i32 %stack.offset.46, 8
  %cursor.check.401 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.400)
  %cursor.ok.402 = icmp eq i32 %cursor.check.401, 0
  br i1 %cursor.ok.402, label %cursor.continue.403, label %frame.failure.0
cursor.continue.403:
  br label %if.join.234
if.else.233:
  %step.status.404 = call i32 @al_owning_charge_step(ptr %ctx, i32 61)
  %step.ok.405 = icmp eq i32 %step.status.404, 0
  br i1 %step.ok.405, label %step.continue.406, label %frame.failure.0
step.continue.406:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.407 = call i32 @al_owning_charge_step(ptr %ctx, i32 62)
  %step.ok.408 = icmp eq i32 %step.status.407, 0
  br i1 %step.ok.408, label %step.continue.409, label %frame.failure.0
step.continue.409:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %step.status.410 = call i32 @al_owning_charge_step(ptr %ctx, i32 63)
  %step.ok.411 = icmp eq i32 %step.status.410, 0
  br i1 %step.ok.411, label %step.continue.412, label %frame.failure.0
step.continue.412:
  %stack.offset.413 = add i32 %stack.offset.46, 8
  %reserve.status.414 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.413, i32 64)
  %reserve.ok.415 = icmp eq i32 %reserve.status.414, 0
  br i1 %reserve.ok.415, label %reserve.continue.416, label %frame.failure.0
reserve.continue.416:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %context.value.45, i32 8, i32 8, i32 1)
  %context.field.417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.418 = load i32, ptr %context.field.417, align 4
  %runtime.ok.419 = icmp eq i32 %context.value.418, 0
  br i1 %runtime.ok.419, label %runtime.continue.420, label %frame.failure.0
runtime.continue.420:
  %stack.offset.421 = add i32 %stack.offset.46, 8
  %cursor.check.422 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.421)
  %cursor.ok.423 = icmp eq i32 %cursor.check.422, 0
  br i1 %cursor.ok.423, label %cursor.continue.424, label %frame.failure.0
cursor.continue.424:
  %step.status.425 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %step.ok.426 = icmp eq i32 %step.status.425, 0
  br i1 %step.ok.426, label %step.continue.427, label %frame.failure.0
step.continue.427:
  %local.is.active.428 = load i1, ptr %local.active.21, align 1
  %local.previous.payload.429 = load i32, ptr %local.payload.22, align 4
  %local.old.payload.430 = select i1 %local.is.active.428, i32 %local.previous.payload.429, i32 0
  %stack.offset.431 = add i32 %context.value.45, 56
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.431, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.430, i32 1)
  %context.field.432 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.433 = load i32, ptr %context.field.432, align 4
  %runtime.ok.434 = icmp eq i32 %context.value.433, 0
  br i1 %runtime.ok.434, label %runtime.continue.435, label %frame.failure.0
runtime.continue.435:
  store i1 true, ptr %local.active.21, align 1
  store i32 8, ptr %local.payload.22, align 4
  store i32 1, ptr %local.type.23, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.436 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.437 = load i32, ptr %context.field.436, align 4
  %runtime.ok.438 = icmp eq i32 %context.value.437, 0
  br i1 %runtime.ok.438, label %runtime.continue.439, label %frame.failure.0
runtime.continue.439:
  %cursor.check.440 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.441 = icmp eq i32 %cursor.check.440, 0
  br i1 %cursor.ok.441, label %cursor.continue.442, label %frame.failure.0
cursor.continue.442:
  %step.status.443 = call i32 @al_owning_charge_step(ptr %ctx, i32 66)
  %step.ok.444 = icmp eq i32 %step.status.443, 0
  br i1 %step.ok.444, label %step.continue.445, label %frame.failure.0
step.continue.445:
  %stack.offset.446 = add i32 %stack.offset.46, 8
  %reserve.status.447 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.446, i32 67)
  %reserve.ok.448 = icmp eq i32 %reserve.status.447, 0
  br i1 %reserve.ok.448, label %reserve.continue.449, label %frame.failure.0
reserve.continue.449:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %context.value.45, i32 8, i32 8, i32 1)
  %context.field.450 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.451 = load i32, ptr %context.field.450, align 4
  %runtime.ok.452 = icmp eq i32 %context.value.451, 0
  br i1 %runtime.ok.452, label %runtime.continue.453, label %frame.failure.0
runtime.continue.453:
  %stack.offset.454 = add i32 %stack.offset.46, 8
  %cursor.check.455 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.454)
  %cursor.ok.456 = icmp eq i32 %cursor.check.455, 0
  br i1 %cursor.ok.456, label %cursor.continue.457, label %frame.failure.0
cursor.continue.457:
  %step.status.458 = call i32 @al_owning_charge_step(ptr %ctx, i32 68)
  %step.ok.459 = icmp eq i32 %step.status.458, 0
  br i1 %step.ok.459, label %step.continue.460, label %frame.failure.0
step.continue.460:
  %stack.offset.461 = add i32 %stack.offset.46, 8
  %stack.offset.462 = add i32 %stack.offset.461, 8
  %reserve.status.463 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.462, i32 69)
  %reserve.ok.464 = icmp eq i32 %reserve.status.463, 0
  br i1 %reserve.ok.464, label %reserve.continue.465, label %frame.failure.0
reserve.continue.465:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.461, i64 800, i32 1)
  %context.field.466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.467 = load i32, ptr %context.field.466, align 4
  %runtime.ok.468 = icmp eq i32 %context.value.467, 0
  br i1 %runtime.ok.468, label %runtime.continue.469, label %frame.failure.0
runtime.continue.469:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.471 = load i32, ptr %context.field.470, align 4
  %runtime.ok.472 = icmp eq i32 %context.value.471, 0
  br i1 %runtime.ok.472, label %runtime.continue.473, label %frame.failure.0
runtime.continue.473:
  %stack.offset.474 = add i32 %stack.offset.46, 16
  %cursor.check.475 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.474)
  %cursor.ok.476 = icmp eq i32 %cursor.check.475, 0
  br i1 %cursor.ok.476, label %cursor.continue.477, label %frame.failure.0
cursor.continue.477:
  %step.status.478 = call i32 @al_owning_charge_step(ptr %ctx, i32 70)
  %step.ok.479 = icmp eq i32 %step.status.478, 0
  br i1 %step.ok.479, label %step.continue.480, label %frame.failure.0
step.continue.480:
  %stack.offset.481 = add i32 %stack.offset.46, 16
  %reserve.status.482 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.481, i32 71)
  %reserve.ok.483 = icmp eq i32 %reserve.status.482, 0
  br i1 %reserve.ok.483, label %reserve.continue.484, label %frame.failure.0
reserve.continue.484:
  %callee.status.485 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 72)
  %callee.ok.486 = icmp eq i32 %callee.status.485, 0
  br i1 %callee.ok.486, label %callee.returned.487, label %frame.failure.0
callee.returned.487:
  %stack.offset.488 = add i32 %stack.offset.46, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.488, i32 0, i32 0, i32 0)
  %context.field.489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.490 = load i32, ptr %context.field.489, align 4
  %runtime.ok.491 = icmp eq i32 %context.value.490, 0
  br i1 %runtime.ok.491, label %runtime.continue.492, label %frame.failure.0
runtime.continue.492:
  %stack.offset.493 = add i32 %stack.offset.46, 16
  %cursor.check.494 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.493)
  %cursor.ok.495 = icmp eq i32 %cursor.check.494, 0
  br i1 %cursor.ok.495, label %cursor.continue.496, label %frame.failure.0
cursor.continue.496:
  %step.status.497 = call i32 @al_owning_charge_step(ptr %ctx, i32 73)
  %step.ok.498 = icmp eq i32 %step.status.497, 0
  br i1 %step.ok.498, label %step.continue.499, label %frame.failure.0
step.continue.499:
  %local.is.active.500 = load i1, ptr %local.active.24, align 1
  %local.previous.payload.501 = load i32, ptr %local.payload.25, align 4
  %local.old.payload.502 = select i1 %local.is.active.500, i32 %local.previous.payload.501, i32 0
  %stack.offset.503 = add i32 %context.value.45, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.503, i32 %stack.offset.46, i32 16, i32 16, i32 16, i32 %local.old.payload.502, i32 5)
  %context.field.504 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.505 = load i32, ptr %context.field.504, align 4
  %runtime.ok.506 = icmp eq i32 %context.value.505, 0
  br i1 %runtime.ok.506, label %runtime.continue.507, label %frame.failure.0
runtime.continue.507:
  store i1 true, ptr %local.active.24, align 1
  store i32 16, ptr %local.payload.25, align 4
  store i32 5, ptr %local.type.26, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 16, i32 16, i32 5)
  %context.field.508 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.509 = load i32, ptr %context.field.508, align 4
  %runtime.ok.510 = icmp eq i32 %context.value.509, 0
  br i1 %runtime.ok.510, label %runtime.continue.511, label %frame.failure.0
runtime.continue.511:
  %cursor.check.512 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.513 = icmp eq i32 %cursor.check.512, 0
  br i1 %cursor.ok.513, label %cursor.continue.514, label %frame.failure.0
cursor.continue.514:
  %step.status.515 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %step.ok.516 = icmp eq i32 %step.status.515, 0
  br i1 %step.ok.516, label %step.continue.517, label %frame.failure.0
step.continue.517:
  %stack.offset.518 = add i32 %stack.offset.46, 8
  %reserve.status.519 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.518, i32 75)
  %reserve.ok.520 = icmp eq i32 %reserve.status.519, 0
  br i1 %reserve.ok.520, label %reserve.continue.521, label %frame.failure.0
reserve.continue.521:
  %stack.offset.522 = add i32 %context.value.45, 56
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.522, i32 8, i32 8, i32 1)
  %context.field.523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.524 = load i32, ptr %context.field.523, align 4
  %runtime.ok.525 = icmp eq i32 %context.value.524, 0
  br i1 %runtime.ok.525, label %runtime.continue.526, label %frame.failure.0
runtime.continue.526:
  %stack.offset.527 = add i32 %stack.offset.46, 8
  %cursor.check.528 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.527)
  %cursor.ok.529 = icmp eq i32 %cursor.check.528, 0
  br i1 %cursor.ok.529, label %cursor.continue.530, label %frame.failure.0
cursor.continue.530:
  %step.status.531 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %step.ok.532 = icmp eq i32 %step.status.531, 0
  br i1 %step.ok.532, label %step.continue.533, label %frame.failure.0
step.continue.533:
  %stack.offset.534 = add i32 %stack.offset.46, 8
  %stack.offset.535 = add i32 %stack.offset.534, 16
  %reserve.status.536 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.535, i32 77)
  %reserve.ok.537 = icmp eq i32 %reserve.status.536, 0
  br i1 %reserve.ok.537, label %reserve.continue.538, label %frame.failure.0
reserve.continue.538:
  %stack.offset.539 = add i32 %context.value.45, 64
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.534, i32 %stack.offset.539, i32 16, i32 16, i32 5)
  %context.field.540 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.541 = load i32, ptr %context.field.540, align 4
  %runtime.ok.542 = icmp eq i32 %context.value.541, 0
  br i1 %runtime.ok.542, label %runtime.continue.543, label %frame.failure.0
runtime.continue.543:
  %stack.offset.544 = add i32 %stack.offset.46, 24
  %cursor.check.545 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.544)
  %cursor.ok.546 = icmp eq i32 %cursor.check.545, 0
  br i1 %cursor.ok.546, label %cursor.continue.547, label %frame.failure.0
cursor.continue.547:
  %step.status.548 = call i32 @al_owning_charge_step(ptr %ctx, i32 78)
  %step.ok.549 = icmp eq i32 %step.status.548, 0
  br i1 %step.ok.549, label %step.continue.550, label %frame.failure.0
step.continue.550:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 1, i32 6)
  %context.field.551 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.552 = load i32, ptr %context.field.551, align 4
  %runtime.ok.553 = icmp eq i32 %context.value.552, 0
  br i1 %runtime.ok.553, label %runtime.continue.554, label %frame.failure.0
runtime.continue.554:
  %stack.offset.555 = add i32 %stack.offset.46, 8
  %stack.offset.556 = add i32 %stack.offset.46, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.555, i32 %stack.offset.556, i32 16, i32 16, i32 5, i32 6)
  %context.field.557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.558 = load i32, ptr %context.field.557, align 4
  %runtime.ok.559 = icmp eq i32 %context.value.558, 0
  br i1 %runtime.ok.559, label %runtime.continue.560, label %frame.failure.0
runtime.continue.560:
  %stack.offset.561 = add i32 %stack.offset.46, 24
  %stack.offset.562 = add i32 %stack.offset.46, 24
  %record.grows.563 = icmp ugt i32 %stack.offset.561, %stack.offset.562
  br i1 %record.grows.563, label %record.reserve.564, label %record.release.565
record.reserve.564:
  %reserve.status.567 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.561, i32 79)
  %reserve.ok.568 = icmp eq i32 %reserve.status.567, 0
  br i1 %reserve.ok.568, label %reserve.continue.569, label %frame.failure.0
reserve.continue.569:
  br label %record.ready.566
record.release.565:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.561, i32 0, i32 7, i32 24)
  %context.field.570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.571 = load i32, ptr %context.field.570, align 4
  %runtime.ok.572 = icmp eq i32 %context.value.571, 0
  br i1 %runtime.ok.572, label %runtime.continue.573, label %frame.failure.0
runtime.continue.573:
  br label %record.ready.566
record.ready.566:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 7, i32 %stack.offset.46, i32 24, i32 24, i32 0, i32 0)
  %context.field.574 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.575 = load i32, ptr %context.field.574, align 4
  %runtime.ok.576 = icmp eq i32 %context.value.575, 0
  br i1 %runtime.ok.576, label %runtime.continue.577, label %frame.failure.0
runtime.continue.577:
  %stack.offset.578 = add i32 %stack.offset.46, 24
  %cursor.check.579 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.578)
  %cursor.ok.580 = icmp eq i32 %cursor.check.579, 0
  br i1 %cursor.ok.580, label %cursor.continue.581, label %frame.failure.0
cursor.continue.581:
  %local.is.active.582 = load i1, ptr %local.active.21, align 1
  %local.clear.payload.583 = load i32, ptr %local.payload.22, align 4
  %local.clear.type.584 = load i32, ptr %local.type.23, align 4
  %local.clear.live.payload.585 = select i1 %local.is.active.582, i32 %local.clear.payload.583, i32 0
  %local.clear.live.type.586 = select i1 %local.is.active.582, i32 %local.clear.type.584, i32 0
  %stack.offset.587 = add i32 %context.value.45, 56
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.587, i32 8, i32 %local.clear.live.payload.585, i32 %local.clear.live.type.586)
  %context.field.588 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.589 = load i32, ptr %context.field.588, align 4
  %runtime.ok.590 = icmp eq i32 %context.value.589, 0
  br i1 %runtime.ok.590, label %runtime.continue.591, label %frame.failure.0
runtime.continue.591:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %local.is.active.592 = load i1, ptr %local.active.24, align 1
  %local.clear.payload.593 = load i32, ptr %local.payload.25, align 4
  %local.clear.type.594 = load i32, ptr %local.type.26, align 4
  %local.clear.live.payload.595 = select i1 %local.is.active.592, i32 %local.clear.payload.593, i32 0
  %local.clear.live.type.596 = select i1 %local.is.active.592, i32 %local.clear.type.594, i32 0
  %stack.offset.597 = add i32 %context.value.45, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.597, i32 16, i32 %local.clear.live.payload.595, i32 %local.clear.live.type.596)
  %context.field.598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.599 = load i32, ptr %context.field.598, align 4
  %runtime.ok.600 = icmp eq i32 %context.value.599, 0
  br i1 %runtime.ok.600, label %runtime.continue.601, label %frame.failure.0
runtime.continue.601:
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %stack.offset.602 = add i32 %stack.offset.46, 24
  %cursor.check.603 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.602)
  %cursor.ok.604 = icmp eq i32 %cursor.check.603, 0
  br i1 %cursor.ok.604, label %cursor.continue.605, label %frame.failure.0
cursor.continue.605:
  %step.status.606 = call i32 @al_owning_charge_step(ptr %ctx, i32 80)
  %step.ok.607 = icmp eq i32 %step.status.606, 0
  br i1 %step.ok.607, label %step.continue.608, label %frame.failure.0
step.continue.608:
  %local.is.active.609 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.610 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.611 = select i1 %local.is.active.609, i32 %local.previous.payload.610, i32 0
  %stack.offset.612 = add i32 %context.value.45, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.612, i32 %stack.offset.46, i32 24, i32 24, i32 24, i32 %local.old.payload.611, i32 7)
  %context.field.613 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.614 = load i32, ptr %context.field.613, align 4
  %runtime.ok.615 = icmp eq i32 %context.value.614, 0
  br i1 %runtime.ok.615, label %runtime.continue.616, label %frame.failure.0
runtime.continue.616:
  store i1 true, ptr %local.active.18, align 1
  store i32 24, ptr %local.payload.19, align 4
  store i32 7, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 24, i32 24, i32 7)
  %context.field.617 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.618 = load i32, ptr %context.field.617, align 4
  %runtime.ok.619 = icmp eq i32 %context.value.618, 0
  br i1 %runtime.ok.619, label %runtime.continue.620, label %frame.failure.0
runtime.continue.620:
  %cursor.check.621 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.622 = icmp eq i32 %cursor.check.621, 0
  br i1 %cursor.ok.622, label %cursor.continue.623, label %frame.failure.0
cursor.continue.623:
  %step.status.624 = call i32 @al_owning_charge_step(ptr %ctx, i32 81)
  %step.ok.625 = icmp eq i32 %step.status.624, 0
  br i1 %step.ok.625, label %step.continue.626, label %frame.failure.0
step.continue.626:
  %stack.offset.627 = add i32 %stack.offset.46, 24
  %reserve.status.628 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.627, i32 82)
  %reserve.ok.629 = icmp eq i32 %reserve.status.628, 0
  br i1 %reserve.ok.629, label %reserve.continue.630, label %frame.failure.0
reserve.continue.630:
  %stack.offset.631 = add i32 %context.value.45, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.631, i32 24, i32 24, i32 7)
  %context.field.632 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.633 = load i32, ptr %context.field.632, align 4
  %runtime.ok.634 = icmp eq i32 %context.value.633, 0
  br i1 %runtime.ok.634, label %runtime.continue.635, label %frame.failure.0
runtime.continue.635:
  %stack.offset.636 = add i32 %stack.offset.46, 24
  %cursor.check.637 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.636)
  %cursor.ok.638 = icmp eq i32 %cursor.check.637, 0
  br i1 %cursor.ok.638, label %cursor.continue.639, label %frame.failure.0
cursor.continue.639:
  %step.status.640 = call i32 @al_owning_charge_step(ptr %ctx, i32 83)
  %step.ok.641 = icmp eq i32 %step.status.640, 0
  br i1 %step.ok.641, label %step.continue.642, label %frame.failure.0
step.continue.642:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 1, i32 7)
  %context.field.643 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.644 = load i32, ptr %context.field.643, align 4
  %runtime.ok.645 = icmp eq i32 %context.value.644, 0
  br i1 %runtime.ok.645, label %runtime.continue.646, label %frame.failure.0
runtime.continue.646:
  %stack.offset.647 = add i32 %stack.offset.46, 8
  %stack.offset.648 = add i32 %stack.offset.46, 24
  %field.grows.649 = icmp ugt i32 %stack.offset.647, %stack.offset.648
  br i1 %field.grows.649, label %field.reserve.650, label %field.release.651
field.reserve.650:
  %reserve.status.653 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.647, i32 84)
  %reserve.ok.654 = icmp eq i32 %reserve.status.653, 0
  br i1 %reserve.ok.654, label %reserve.continue.655, label %frame.failure.0
reserve.continue.655:
  br label %field.ready.652
field.release.651:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.647, i32 0, i32 1, i32 8)
  %context.field.656 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.657 = load i32, ptr %context.field.656, align 4
  %runtime.ok.658 = icmp eq i32 %context.value.657, 0
  br i1 %runtime.ok.658, label %runtime.continue.659, label %frame.failure.0
runtime.continue.659:
  br label %field.ready.652
field.ready.652:
  call void @al_owning_update_live(ptr %ctx, i32 -16, i32 0)
  %context.field.660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.661 = load i32, ptr %context.field.660, align 4
  %runtime.ok.662 = icmp eq i32 %context.value.661, 0
  br i1 %runtime.ok.662, label %runtime.continue.663, label %frame.failure.0
runtime.continue.663:
  %stack.offset.664 = add i32 %stack.offset.46, 8
  %cursor.check.665 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.664)
  %cursor.ok.666 = icmp eq i32 %cursor.check.665, 0
  br i1 %cursor.ok.666, label %cursor.continue.667, label %frame.failure.0
cursor.continue.667:
  %local.is.active.668 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.669 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.670 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.671 = select i1 %local.is.active.668, i32 %local.clear.payload.669, i32 0
  %local.clear.live.type.672 = select i1 %local.is.active.668, i32 %local.clear.type.670, i32 0
  %stack.offset.673 = add i32 %context.value.45, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.673, i32 24, i32 %local.clear.live.payload.671, i32 %local.clear.live.type.672)
  %context.field.674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.675 = load i32, ptr %context.field.674, align 4
  %runtime.ok.676 = icmp eq i32 %context.value.675, 0
  br i1 %runtime.ok.676, label %runtime.continue.677, label %frame.failure.0
runtime.continue.677:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %stack.offset.678 = add i32 %stack.offset.46, 8
  %cursor.check.679 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.678)
  %cursor.ok.680 = icmp eq i32 %cursor.check.679, 0
  br i1 %cursor.ok.680, label %cursor.continue.681, label %frame.failure.0
cursor.continue.681:
  br label %if.join.234
if.join.234:
  %stack.offset.682 = add i32 %stack.offset.46, 8
  %cursor.check.683 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.682)
  %cursor.ok.684 = icmp eq i32 %cursor.check.683, 0
  br i1 %cursor.ok.684, label %cursor.continue.685, label %frame.failure.0
cursor.continue.685:
  %step.status.686 = call i32 @al_owning_charge_step(ptr %ctx, i32 85)
  %step.ok.687 = icmp eq i32 %step.status.686, 0
  br i1 %step.ok.687, label %step.continue.688, label %frame.failure.0
step.continue.688:
  %local.is.active.689 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.690 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.691 = select i1 %local.is.active.689, i32 %local.previous.payload.690, i32 0
  %stack.offset.692 = add i32 %context.value.45, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.692, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.691, i32 1)
  %context.field.693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.694 = load i32, ptr %context.field.693, align 4
  %runtime.ok.695 = icmp eq i32 %context.value.694, 0
  br i1 %runtime.ok.695, label %runtime.continue.696, label %frame.failure.0
runtime.continue.696:
  store i1 true, ptr %local.active.9, align 1
  store i32 8, ptr %local.payload.10, align 4
  store i32 1, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.698 = load i32, ptr %context.field.697, align 4
  %runtime.ok.699 = icmp eq i32 %context.value.698, 0
  br i1 %runtime.ok.699, label %runtime.continue.700, label %frame.failure.0
runtime.continue.700:
  %cursor.check.701 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.702 = icmp eq i32 %cursor.check.701, 0
  br i1 %cursor.ok.702, label %cursor.continue.703, label %frame.failure.0
cursor.continue.703:
  %step.status.704 = call i32 @al_owning_charge_step(ptr %ctx, i32 86)
  %step.ok.705 = icmp eq i32 %step.status.704, 0
  br i1 %step.ok.705, label %step.continue.706, label %frame.failure.0
step.continue.706:
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %step.status.707 = call i32 @al_owning_charge_step(ptr %ctx, i32 87)
  %step.ok.708 = icmp eq i32 %step.status.707, 0
  br i1 %step.ok.708, label %step.continue.709, label %frame.failure.0
step.continue.709:
  %stack.offset.710 = add i32 %stack.offset.46, 16
  %reserve.status.711 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.710, i32 88)
  %reserve.ok.712 = icmp eq i32 %reserve.status.711, 0
  br i1 %reserve.ok.712, label %reserve.continue.713, label %frame.failure.0
reserve.continue.713:
  %stack.offset.714 = add i32 %context.value.45, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.714, i32 16, i32 16, i32 5)
  %context.field.715 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.716 = load i32, ptr %context.field.715, align 4
  %runtime.ok.717 = icmp eq i32 %context.value.716, 0
  br i1 %runtime.ok.717, label %runtime.continue.718, label %frame.failure.0
runtime.continue.718:
  %stack.offset.719 = add i32 %stack.offset.46, 16
  %cursor.check.720 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.719)
  %cursor.ok.721 = icmp eq i32 %cursor.check.720, 0
  br i1 %cursor.ok.721, label %cursor.continue.722, label %frame.failure.0
cursor.continue.722:
  %step.status.723 = call i32 @al_owning_charge_step(ptr %ctx, i32 89)
  %step.ok.724 = icmp eq i32 %step.status.723, 0
  br i1 %step.ok.724, label %step.continue.725, label %frame.failure.0
step.continue.725:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 6, i32 7)
  %context.field.726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.727 = load i32, ptr %context.field.726, align 4
  %runtime.ok.728 = icmp eq i32 %context.value.727, 0
  br i1 %runtime.ok.728, label %runtime.continue.729, label %frame.failure.0
runtime.continue.729:
  %stack.offset.730 = add i32 %stack.offset.46, 8
  %stack.offset.731 = add i32 %stack.offset.46, 16
  %field.grows.732 = icmp ugt i32 %stack.offset.730, %stack.offset.731
  br i1 %field.grows.732, label %field.reserve.733, label %field.release.734
field.reserve.733:
  %reserve.status.736 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.730, i32 90)
  %reserve.ok.737 = icmp eq i32 %reserve.status.736, 0
  br i1 %reserve.ok.737, label %reserve.continue.738, label %frame.failure.0
reserve.continue.738:
  br label %field.ready.735
field.release.734:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.730, i32 0, i32 6, i32 8)
  %context.field.739 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.740 = load i32, ptr %context.field.739, align 4
  %runtime.ok.741 = icmp eq i32 %context.value.740, 0
  br i1 %runtime.ok.741, label %runtime.continue.742, label %frame.failure.0
runtime.continue.742:
  br label %field.ready.735
field.ready.735:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.744 = load i32, ptr %context.field.743, align 4
  %runtime.ok.745 = icmp eq i32 %context.value.744, 0
  br i1 %runtime.ok.745, label %runtime.continue.746, label %frame.failure.0
runtime.continue.746:
  %stack.offset.747 = add i32 %stack.offset.46, 8
  %cursor.check.748 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.747)
  %cursor.ok.749 = icmp eq i32 %cursor.check.748, 0
  br i1 %cursor.ok.749, label %cursor.continue.750, label %frame.failure.0
cursor.continue.750:
  %step.status.751 = call i32 @al_owning_charge_step(ptr %ctx, i32 91)
  %step.ok.752 = icmp eq i32 %step.status.751, 0
  br i1 %step.ok.752, label %step.continue.753, label %frame.failure.0
step.continue.753:
  %local.is.active.754 = load i1, ptr %local.active.27, align 1
  %local.previous.payload.755 = load i32, ptr %local.payload.28, align 4
  %local.old.payload.756 = select i1 %local.is.active.754, i32 %local.previous.payload.755, i32 0
  %stack.offset.757 = add i32 %context.value.45, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.757, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.756, i32 6)
  %context.field.758 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.759 = load i32, ptr %context.field.758, align 4
  %runtime.ok.760 = icmp eq i32 %context.value.759, 0
  br i1 %runtime.ok.760, label %runtime.continue.761, label %frame.failure.0
runtime.continue.761:
  store i1 true, ptr %local.active.27, align 1
  store i32 8, ptr %local.payload.28, align 4
  store i32 6, ptr %local.type.29, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 6)
  %context.field.762 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.763 = load i32, ptr %context.field.762, align 4
  %runtime.ok.764 = icmp eq i32 %context.value.763, 0
  br i1 %runtime.ok.764, label %runtime.continue.765, label %frame.failure.0
runtime.continue.765:
  %cursor.check.766 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.767 = icmp eq i32 %cursor.check.766, 0
  br i1 %cursor.ok.767, label %cursor.continue.768, label %frame.failure.0
cursor.continue.768:
  %step.status.769 = call i32 @al_owning_charge_step(ptr %ctx, i32 92)
  %step.ok.770 = icmp eq i32 %step.status.769, 0
  br i1 %step.ok.770, label %step.continue.771, label %frame.failure.0
step.continue.771:
  %stack.offset.772 = add i32 %stack.offset.46, 16
  %reserve.status.773 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.772, i32 93)
  %reserve.ok.774 = icmp eq i32 %reserve.status.773, 0
  br i1 %reserve.ok.774, label %reserve.continue.775, label %frame.failure.0
reserve.continue.775:
  %stack.offset.776 = add i32 %context.value.45, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.776, i32 16, i32 16, i32 5)
  %context.field.777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.778 = load i32, ptr %context.field.777, align 4
  %runtime.ok.779 = icmp eq i32 %context.value.778, 0
  br i1 %runtime.ok.779, label %runtime.continue.780, label %frame.failure.0
runtime.continue.780:
  %stack.offset.781 = add i32 %stack.offset.46, 16
  %cursor.check.782 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.781)
  %cursor.ok.783 = icmp eq i32 %cursor.check.782, 0
  br i1 %cursor.ok.783, label %cursor.continue.784, label %frame.failure.0
cursor.continue.784:
  %step.status.785 = call i32 @al_owning_charge_step(ptr %ctx, i32 94)
  %step.ok.786 = icmp eq i32 %step.status.785, 0
  br i1 %step.ok.786, label %step.continue.787, label %frame.failure.0
step.continue.787:
  %stack.offset.788 = add i32 %stack.offset.46, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.788, i32 8, i32 8, i32 1, i32 7)
  %context.field.789 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.790 = load i32, ptr %context.field.789, align 4
  %runtime.ok.791 = icmp eq i32 %context.value.790, 0
  br i1 %runtime.ok.791, label %runtime.continue.792, label %frame.failure.0
runtime.continue.792:
  %stack.offset.793 = add i32 %stack.offset.46, 8
  %stack.offset.794 = add i32 %stack.offset.46, 16
  %field.grows.795 = icmp ugt i32 %stack.offset.793, %stack.offset.794
  br i1 %field.grows.795, label %field.reserve.796, label %field.release.797
field.reserve.796:
  %reserve.status.799 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.793, i32 95)
  %reserve.ok.800 = icmp eq i32 %reserve.status.799, 0
  br i1 %reserve.ok.800, label %reserve.continue.801, label %frame.failure.0
reserve.continue.801:
  br label %field.ready.798
field.release.797:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.793, i32 0, i32 1, i32 8)
  %context.field.802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.803 = load i32, ptr %context.field.802, align 4
  %runtime.ok.804 = icmp eq i32 %context.value.803, 0
  br i1 %runtime.ok.804, label %runtime.continue.805, label %frame.failure.0
runtime.continue.805:
  br label %field.ready.798
field.ready.798:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.806 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.807 = load i32, ptr %context.field.806, align 4
  %runtime.ok.808 = icmp eq i32 %context.value.807, 0
  br i1 %runtime.ok.808, label %runtime.continue.809, label %frame.failure.0
runtime.continue.809:
  %stack.offset.810 = add i32 %stack.offset.46, 8
  %cursor.check.811 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.810)
  %cursor.ok.812 = icmp eq i32 %cursor.check.811, 0
  br i1 %cursor.ok.812, label %cursor.continue.813, label %frame.failure.0
cursor.continue.813:
  %step.status.814 = call i32 @al_owning_charge_step(ptr %ctx, i32 96)
  %step.ok.815 = icmp eq i32 %step.status.814, 0
  br i1 %step.ok.815, label %step.continue.816, label %frame.failure.0
step.continue.816:
  %stack.offset.817 = add i32 %stack.offset.46, 8
  %stack.offset.818 = add i32 %stack.offset.817, 8
  %reserve.status.819 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.818, i32 97)
  %reserve.ok.820 = icmp eq i32 %reserve.status.819, 0
  br i1 %reserve.ok.820, label %reserve.continue.821, label %frame.failure.0
reserve.continue.821:
  %stack.offset.822 = add i32 %context.value.45, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.817, i32 %stack.offset.822, i32 8, i32 8, i32 1)
  %context.field.823 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.824 = load i32, ptr %context.field.823, align 4
  %runtime.ok.825 = icmp eq i32 %context.value.824, 0
  br i1 %runtime.ok.825, label %runtime.continue.826, label %frame.failure.0
runtime.continue.826:
  %stack.offset.827 = add i32 %stack.offset.46, 16
  %cursor.check.828 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.827)
  %cursor.ok.829 = icmp eq i32 %cursor.check.828, 0
  br i1 %cursor.ok.829, label %cursor.continue.830, label %frame.failure.0
cursor.continue.830:
  %step.status.831 = call i32 @al_owning_charge_step(ptr %ctx, i32 98)
  %step.ok.832 = icmp eq i32 %step.status.831, 0
  br i1 %step.ok.832, label %step.continue.833, label %frame.failure.0
step.continue.833:
  %stack.offset.834 = add i32 %stack.offset.46, 8
  %integer.left.835 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.46)
  %context.field.837 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.838 = load i32, ptr %context.field.837, align 4
  %runtime.ok.839 = icmp eq i32 %context.value.838, 0
  br i1 %runtime.ok.839, label %runtime.continue.840, label %frame.failure.0
runtime.continue.840:
  %integer.right.836 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.834)
  %context.field.841 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.842 = load i32, ptr %context.field.841, align 4
  %runtime.ok.843 = icmp eq i32 %context.value.842, 0
  br i1 %runtime.ok.843, label %runtime.continue.844, label %frame.failure.0
runtime.continue.844:
  %integer.checked.845 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.835, i64 %integer.right.836)
  %integer.result.846 = extractvalue { i64, i1 } %integer.checked.845, 0
  %integer.overflow.847 = extractvalue { i64, i1 } %integer.checked.845, 1
  br i1 %integer.overflow.847, label %integer.overflow.failure.849, label %integer.nooverflow.848
integer.overflow.failure.849:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 99, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.848:
  %stack.offset.850 = add i32 %stack.offset.46, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.850, i32 8, i32 8, i32 1)
  %context.field.851 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.852 = load i32, ptr %context.field.851, align 4
  %runtime.ok.853 = icmp eq i32 %context.value.852, 0
  br i1 %runtime.ok.853, label %runtime.continue.854, label %frame.failure.0
runtime.continue.854:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.855 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.856 = load i32, ptr %context.field.855, align 4
  %runtime.ok.857 = icmp eq i32 %context.value.856, 0
  br i1 %runtime.ok.857, label %runtime.continue.858, label %frame.failure.0
runtime.continue.858:
  %stack.offset.859 = add i32 %stack.offset.46, 8
  %reserve.status.860 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.859, i32 100)
  %reserve.ok.861 = icmp eq i32 %reserve.status.860, 0
  br i1 %reserve.ok.861, label %reserve.continue.862, label %frame.failure.0
reserve.continue.862:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.46, i64 %integer.result.846, i32 1)
  %context.field.863 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.864 = load i32, ptr %context.field.863, align 4
  %runtime.ok.865 = icmp eq i32 %context.value.864, 0
  br i1 %runtime.ok.865, label %runtime.continue.866, label %frame.failure.0
runtime.continue.866:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.868 = load i32, ptr %context.field.867, align 4
  %runtime.ok.869 = icmp eq i32 %context.value.868, 0
  br i1 %runtime.ok.869, label %runtime.continue.870, label %frame.failure.0
runtime.continue.870:
  %stack.offset.871 = add i32 %stack.offset.46, 8
  %cursor.check.872 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.871)
  %cursor.ok.873 = icmp eq i32 %cursor.check.872, 0
  br i1 %cursor.ok.873, label %cursor.continue.874, label %frame.failure.0
cursor.continue.874:
  %step.status.875 = call i32 @al_owning_charge_step(ptr %ctx, i32 101)
  %step.ok.876 = icmp eq i32 %step.status.875, 0
  br i1 %step.ok.876, label %step.continue.877, label %frame.failure.0
step.continue.877:
  %local.is.active.878 = load i1, ptr %local.active.30, align 1
  %local.previous.payload.879 = load i32, ptr %local.payload.31, align 4
  %local.old.payload.880 = select i1 %local.is.active.878, i32 %local.previous.payload.879, i32 0
  %stack.offset.881 = add i32 %context.value.45, 40
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.881, i32 %stack.offset.46, i32 8, i32 8, i32 8, i32 %local.old.payload.880, i32 1)
  %context.field.882 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.883 = load i32, ptr %context.field.882, align 4
  %runtime.ok.884 = icmp eq i32 %context.value.883, 0
  br i1 %runtime.ok.884, label %runtime.continue.885, label %frame.failure.0
runtime.continue.885:
  store i1 true, ptr %local.active.30, align 1
  store i32 8, ptr %local.payload.31, align 4
  store i32 1, ptr %local.type.32, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.46, i32 8, i32 8, i32 1)
  %context.field.886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.887 = load i32, ptr %context.field.886, align 4
  %runtime.ok.888 = icmp eq i32 %context.value.887, 0
  br i1 %runtime.ok.888, label %runtime.continue.889, label %frame.failure.0
runtime.continue.889:
  %cursor.check.890 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.46)
  %cursor.ok.891 = icmp eq i32 %cursor.check.890, 0
  br i1 %cursor.ok.891, label %cursor.continue.892, label %frame.failure.0
cursor.continue.892:
  %step.status.893 = call i32 @al_owning_charge_step(ptr %ctx, i32 102)
  %step.ok.894 = icmp eq i32 %step.status.893, 0
  br i1 %step.ok.894, label %step.continue.895, label %frame.failure.0
step.continue.895:
  %stack.offset.896 = add i32 %stack.offset.46, 8
  %reserve.status.897 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.896, i32 103)
  %reserve.ok.898 = icmp eq i32 %reserve.status.897, 0
  br i1 %reserve.ok.898, label %reserve.continue.899, label %frame.failure.0
reserve.continue.899:
  %stack.offset.900 = add i32 %context.value.45, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.900, i32 8, i32 8, i32 6)
  %context.field.901 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.902 = load i32, ptr %context.field.901, align 4
  %runtime.ok.903 = icmp eq i32 %context.value.902, 0
  br i1 %runtime.ok.903, label %runtime.continue.904, label %frame.failure.0
runtime.continue.904:
  %stack.offset.905 = add i32 %stack.offset.46, 8
  %cursor.check.906 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.905)
  %cursor.ok.907 = icmp eq i32 %cursor.check.906, 0
  br i1 %cursor.ok.907, label %cursor.continue.908, label %frame.failure.0
cursor.continue.908:
  %step.status.909 = call i32 @al_owning_charge_step(ptr %ctx, i32 104)
  %step.ok.910 = icmp eq i32 %step.status.909, 0
  br i1 %step.ok.910, label %step.continue.911, label %frame.failure.0
step.continue.911:
  %stack.offset.912 = add i32 %stack.offset.46, 8
  %stack.offset.913 = add i32 %stack.offset.912, 8
  %reserve.status.914 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.913, i32 105)
  %reserve.ok.915 = icmp eq i32 %reserve.status.914, 0
  br i1 %reserve.ok.915, label %reserve.continue.916, label %frame.failure.0
reserve.continue.916:
  %stack.offset.917 = add i32 %context.value.45, 40
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.912, i32 %stack.offset.917, i32 8, i32 8, i32 1)
  %context.field.918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.919 = load i32, ptr %context.field.918, align 4
  %runtime.ok.920 = icmp eq i32 %context.value.919, 0
  br i1 %runtime.ok.920, label %runtime.continue.921, label %frame.failure.0
runtime.continue.921:
  %stack.offset.922 = add i32 %stack.offset.46, 16
  %cursor.check.923 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.922)
  %cursor.ok.924 = icmp eq i32 %cursor.check.923, 0
  br i1 %cursor.ok.924, label %cursor.continue.925, label %frame.failure.0
cursor.continue.925:
  %step.status.926 = call i32 @al_owning_charge_step(ptr %ctx, i32 106)
  %step.ok.927 = icmp eq i32 %step.status.926, 0
  br i1 %step.ok.927, label %step.continue.928, label %frame.failure.0
step.continue.928:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.46, i32 %stack.offset.46, i32 8, i32 8, i32 6, i32 6)
  %context.field.929 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.930 = load i32, ptr %context.field.929, align 4
  %runtime.ok.931 = icmp eq i32 %context.value.930, 0
  br i1 %runtime.ok.931, label %runtime.continue.932, label %frame.failure.0
runtime.continue.932:
  %stack.offset.933 = add i32 %stack.offset.46, 8
  %stack.offset.934 = add i32 %stack.offset.46, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.933, i32 %stack.offset.934, i32 8, i32 8, i32 1, i32 6)
  %context.field.935 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.936 = load i32, ptr %context.field.935, align 4
  %runtime.ok.937 = icmp eq i32 %context.value.936, 0
  br i1 %runtime.ok.937, label %runtime.continue.938, label %frame.failure.0
runtime.continue.938:
  %stack.offset.939 = add i32 %stack.offset.46, 16
  %stack.offset.940 = add i32 %stack.offset.46, 16
  %record.grows.941 = icmp ugt i32 %stack.offset.939, %stack.offset.940
  br i1 %record.grows.941, label %record.reserve.942, label %record.release.943
record.reserve.942:
  %reserve.status.945 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.939, i32 107)
  %reserve.ok.946 = icmp eq i32 %reserve.status.945, 0
  br i1 %reserve.ok.946, label %reserve.continue.947, label %frame.failure.0
reserve.continue.947:
  br label %record.ready.944
record.release.943:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.939, i32 0, i32 5, i32 16)
  %context.field.948 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.949 = load i32, ptr %context.field.948, align 4
  %runtime.ok.950 = icmp eq i32 %context.value.949, 0
  br i1 %runtime.ok.950, label %runtime.continue.951, label %frame.failure.0
runtime.continue.951:
  br label %record.ready.944
record.ready.944:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %stack.offset.46, i32 16, i32 16, i32 0, i32 0)
  %context.field.952 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.953 = load i32, ptr %context.field.952, align 4
  %runtime.ok.954 = icmp eq i32 %context.value.953, 0
  br i1 %runtime.ok.954, label %runtime.continue.955, label %frame.failure.0
runtime.continue.955:
  %stack.offset.956 = add i32 %stack.offset.46, 16
  %cursor.check.957 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.956)
  %cursor.ok.958 = icmp eq i32 %cursor.check.957, 0
  br i1 %cursor.ok.958, label %cursor.continue.959, label %frame.failure.0
cursor.continue.959:
  %local.is.active.960 = load i1, ptr %local.active.27, align 1
  %local.clear.payload.961 = load i32, ptr %local.payload.28, align 4
  %local.clear.type.962 = load i32, ptr %local.type.29, align 4
  %local.clear.live.payload.963 = select i1 %local.is.active.960, i32 %local.clear.payload.961, i32 0
  %local.clear.live.type.964 = select i1 %local.is.active.960, i32 %local.clear.type.962, i32 0
  %stack.offset.965 = add i32 %context.value.45, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.965, i32 8, i32 %local.clear.live.payload.963, i32 %local.clear.live.type.964)
  %context.field.966 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.967 = load i32, ptr %context.field.966, align 4
  %runtime.ok.968 = icmp eq i32 %context.value.967, 0
  br i1 %runtime.ok.968, label %runtime.continue.969, label %frame.failure.0
runtime.continue.969:
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  %local.is.active.970 = load i1, ptr %local.active.30, align 1
  %local.clear.payload.971 = load i32, ptr %local.payload.31, align 4
  %local.clear.type.972 = load i32, ptr %local.type.32, align 4
  %local.clear.live.payload.973 = select i1 %local.is.active.970, i32 %local.clear.payload.971, i32 0
  %local.clear.live.type.974 = select i1 %local.is.active.970, i32 %local.clear.type.972, i32 0
  %stack.offset.975 = add i32 %context.value.45, 40
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.975, i32 8, i32 %local.clear.live.payload.973, i32 %local.clear.live.type.974)
  %context.field.976 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.977 = load i32, ptr %context.field.976, align 4
  %runtime.ok.978 = icmp eq i32 %context.value.977, 0
  br i1 %runtime.ok.978, label %runtime.continue.979, label %frame.failure.0
runtime.continue.979:
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %stack.offset.980 = add i32 %stack.offset.46, 16
  %cursor.check.981 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.980)
  %cursor.ok.982 = icmp eq i32 %cursor.check.981, 0
  br i1 %cursor.ok.982, label %cursor.continue.983, label %frame.failure.0
cursor.continue.983:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.46, i32 16, i32 16, i32 5, i32 9)
  %context.field.984 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.985 = load i32, ptr %context.field.984, align 4
  %runtime.ok.986 = icmp eq i32 %context.value.985, 0
  br i1 %runtime.ok.986, label %runtime.continue.987, label %frame.failure.0
runtime.continue.987:
  %local.is.active.988 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.989 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.990 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.991 = select i1 %local.is.active.988, i32 %local.clear.payload.989, i32 0
  %local.clear.live.type.992 = select i1 %local.is.active.988, i32 %local.clear.type.990, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.45, i32 8, i32 %local.clear.live.payload.991, i32 %local.clear.live.type.992)
  %context.field.993 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.994 = load i32, ptr %context.field.993, align 4
  %runtime.ok.995 = icmp eq i32 %context.value.994, 0
  br i1 %runtime.ok.995, label %runtime.continue.996, label %frame.failure.0
runtime.continue.996:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.997 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.998 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.999 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.1000 = select i1 %local.is.active.997, i32 %local.clear.payload.998, i32 0
  %local.clear.live.type.1001 = select i1 %local.is.active.997, i32 %local.clear.type.999, i32 0
  %stack.offset.1002 = add i32 %context.value.45, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1002, i32 16, i32 %local.clear.live.payload.1000, i32 %local.clear.live.type.1001)
  %context.field.1003 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1004 = load i32, ptr %context.field.1003, align 4
  %runtime.ok.1005 = icmp eq i32 %context.value.1004, 0
  br i1 %runtime.ok.1005, label %runtime.continue.1006, label %frame.failure.0
runtime.continue.1006:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.1007 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.1008 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.1009 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.1010 = select i1 %local.is.active.1007, i32 %local.clear.payload.1008, i32 0
  %local.clear.live.type.1011 = select i1 %local.is.active.1007, i32 %local.clear.type.1009, i32 0
  %stack.offset.1012 = add i32 %context.value.45, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1012, i32 8, i32 %local.clear.live.payload.1010, i32 %local.clear.live.type.1011)
  %context.field.1013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1014 = load i32, ptr %context.field.1013, align 4
  %runtime.ok.1015 = icmp eq i32 %context.value.1014, 0
  br i1 %runtime.ok.1015, label %runtime.continue.1016, label %frame.failure.0
runtime.continue.1016:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  call void @al_owning_local_release(ptr %ctx, i32 80)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.45, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  %context.field.1017 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1018 = load i32, ptr %context.field.1017, align 4
  %context.field.1019 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1020 = load i32, ptr %context.field.1019, align 4
  %context.field.1021 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1022 = load i32, ptr %context.field.1021, align 4
  %baseline.live.total.1023 = add i32 %context.value.36, %context.value.38
  %current.live.total.1024 = add i32 %context.value.1018, %context.value.1020
  %cleanup.live.delta.1025 = sub i32 %baseline.live.total.1023, %current.live.total.1024
  %cleanup.local.delta.1026 = sub i32 %context.value.38, %context.value.1020
  %cleanup.reserved.delta.1027 = sub i32 %context.value.1022, %context.value.40
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.1025, i32 %cleanup.local.delta.1026)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.1027)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 8
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 8, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 8, i32 108)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 8, i32 8, i32 1)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 16, i32 109)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %entry.failure.0
reserve.continue.19:
  %entry.body.status.20 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.21 = icmp eq i32 %entry.body.status.20, 0
  br i1 %entry.body.ok.21, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.29 = load i32, ptr %context.field.28, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.30 = add i32 %context.value.25, %context.value.27
  %entry.failure.delta.31 = sub i32 0, %entry.failure.live.30
  %entry.failure.local.delta.32 = sub i32 0, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.31, i32 %entry.failure.local.delta.32)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.29)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 16, i32 5)
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %runtime.ok.35 = icmp eq i32 %context.value.34, 0
  br i1 %runtime.ok.35, label %runtime.continue.36, label %entry.failure.0
runtime.continue.36:
  call void @al_owning_update_live(ptr %ctx, i32 -16, i32 0)
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %runtime.ok.39 = icmp eq i32 %context.value.38, 0
  br i1 %runtime.ok.39, label %runtime.continue.40, label %entry.failure.0
runtime.continue.40:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.41 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.42 = load i32, ptr %context.field.41, align 4
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %entry.cleanup.total.live.49 = add i32 %context.value.44, %context.value.46
  %entry.cleanup.live.delta.50 = sub i32 0, %entry.cleanup.total.live.49
  %entry.cleanup.local.delta.51 = sub i32 0, %context.value.46
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.50, i32 %entry.cleanup.local.delta.51)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.48)
  br label %entry.return.status
entry.return.status:
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  ret i32 %context.value.53
}


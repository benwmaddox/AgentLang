%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 8
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 8, i32 0, i32 4, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 8, i32 0, i32 4, i32 9)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %baseline.live.total.38 = add i32 %context.value.6, %context.value.8
  %current.live.total.39 = add i32 %context.value.33, %context.value.35
  %cleanup.live.delta.40 = sub i32 %baseline.live.total.38, %current.live.total.39
  %cleanup.local.delta.41 = sub i32 %context.value.8, %context.value.35
  %cleanup.reserved.delta.42 = sub i32 %context.value.37, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.40, i32 %cleanup.local.delta.41)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.42)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 8
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 8, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 8, i32 2)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 0, i32 8, i32 4)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.26 = load i32, ptr %context.field.25, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.27 = add i32 %context.value.22, %context.value.24
  %entry.failure.delta.28 = sub i32 0, %entry.failure.live.27
  %entry.failure.local.delta.29 = sub i32 0, %context.value.24
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.28, i32 %entry.failure.local.delta.29)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.26)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 8, i32 0)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %entry.failure.0
runtime.continue.33:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %entry.cleanup.total.live.42 = add i32 %context.value.37, %context.value.39
  %entry.cleanup.live.delta.43 = sub i32 0, %entry.cleanup.total.live.42
  %entry.cleanup.local.delta.44 = sub i32 0, %context.value.39
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.43, i32 %entry.cleanup.local.delta.44)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.41)
  br label %entry.return.status
entry.return.status:
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  ret i32 %context.value.46
}


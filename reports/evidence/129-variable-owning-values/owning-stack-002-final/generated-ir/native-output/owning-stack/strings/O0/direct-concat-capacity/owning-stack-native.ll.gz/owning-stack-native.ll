%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 12, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %value.size.35 = alloca %AlOwningValueSize, align 4
  %measure.status.36 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.33, i32 %stack.offset.16, i32 3, ptr %value.size.35)
  %helper.ok.37 = icmp eq i32 %measure.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %frame.failure.0
helper.continue.38:
  %value.payload.pointer.39 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 0
  %value.extent.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 1
  %value.payload.41 = load i32, ptr %value.payload.pointer.39, align 4
  %value.extent.42 = load i32, ptr %value.extent.pointer.40, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.33, i32 %value.extent.42, i32 %value.payload.41, i32 12, i32 8)
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %runtime.ok.45 = icmp eq i32 %context.value.44, 0
  br i1 %runtime.ok.45, label %runtime.continue.46, label %frame.failure.0
runtime.continue.46:
  %stack.offset.47 = add i32 %stack.offset.33, %value.extent.42
  %stack.offset.48 = add i32 %stack.offset.34, %value.extent.42
  %arguments.exact.49 = icmp eq i32 %stack.offset.47, %stack.offset.16
  br i1 %arguments.exact.49, label %arguments.continue.50, label %frame.failure.0
arguments.continue.50:
  %step.status.51 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.52 = icmp eq i32 %step.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %stack.offset.56 = add i32 0, 0
  %stack.offset.57 = add i32 %context.value.15, %stack.offset.56
  %stack.sub.58 = sub i32 %context.value.55, %value.extent.42
  %string.concat.units.59 = alloca i32, align 4
  %string.concat.payload.pointer.60 = alloca i32, align 4
  %string.concat.extent.pointer.61 = alloca i32, align 4
  %string.concat.plan.status.62 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.57, i32 %value.extent.28, i32 %stack.sub.58, i32 %value.extent.42, i32 5, ptr %string.concat.units.59, ptr %string.concat.payload.pointer.60, ptr %string.concat.extent.pointer.61)
  %helper.ok.63 = icmp eq i32 %string.concat.plan.status.62, 0
  br i1 %helper.ok.63, label %helper.continue.64, label %frame.failure.0
helper.continue.64:
  %string.concat.payload.65 = load i32, ptr %string.concat.payload.pointer.60, align 4
  %string.concat.extent.66 = load i32, ptr %string.concat.extent.pointer.61, align 4
  %stack.offset.67 = add i32 %context.value.55, %string.concat.extent.66
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 6)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %frame.failure.0
reserve.continue.70:
  %string.concat.write.status.71 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.55, i32 %string.concat.extent.66, i32 %stack.offset.57, i32 %value.extent.28, i32 %stack.sub.58, i32 %value.extent.42, i32 12, i32 5)
  %helper.ok.72 = icmp eq i32 %string.concat.write.status.71, 0
  br i1 %helper.ok.72, label %helper.continue.73, label %frame.failure.0
helper.continue.73:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.57, i32 %context.value.55, i32 %string.concat.extent.66, i32 %string.concat.payload.65, i32 12, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %frame.failure.0
runtime.continue.77:
  %stack.offset.78 = add i32 %stack.offset.57, %string.concat.extent.66
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.78, i32 0, i32 0, i32 0)
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %runtime.ok.81 = icmp eq i32 %context.value.80, 0
  br i1 %runtime.ok.81, label %runtime.continue.82, label %frame.failure.0
runtime.continue.82:
  %stack.offset.83 = add i32 %value.payload.27, %value.payload.41
  %stack.sub.84 = sub i32 %string.concat.payload.65, %stack.offset.83
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.84, i32 0)
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %runtime.ok.87 = icmp eq i32 %context.value.86, 0
  br i1 %runtime.ok.87, label %runtime.continue.88, label %frame.failure.0
runtime.continue.88:
  %stack.offset.89 = add i32 0, %string.concat.extent.66
  %stack.offset.90 = add i32 0, %stack.offset.89
  %stack.offset.91 = add i32 %context.value.15, %stack.offset.90
  %cursor.status.92 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.91)
  %cursor.ok.93 = icmp eq i32 %cursor.status.92, 0
  br i1 %cursor.ok.93, label %cursor.continue.94, label %frame.failure.0
cursor.continue.94:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %stack.offset.101 = add i32 %context.value.6, %context.value.8
  %stack.offset.102 = add i32 %context.value.96, %context.value.98
  %stack.sub.103 = sub i32 %stack.offset.101, %stack.offset.102
  %stack.sub.104 = sub i32 %context.value.8, %context.value.98
  %stack.sub.105 = sub i32 %context.value.100, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.103, i32 %stack.sub.104)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.105)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 7, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.extent.pointer.24 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.25 = load i32, ptr %input.extent.pointer.24, align 4
  %host.pointer.26 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.payload.pointer.27 = alloca i32, align 4
  %input.measured.extent.pointer.28 = alloca i32, align 4
  %input.measure.status.29 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.26, i32 %input.host.extent.25, i32 0, i32 8, ptr %input.payload.pointer.27, ptr %input.measured.extent.pointer.28)
  %helper.ok.30 = icmp eq i32 %input.measure.status.29, 0
  br i1 %helper.ok.30, label %helper.continue.31, label %entry.failure.0
helper.continue.31:
  %input.measured.payload.32 = load i32, ptr %input.payload.pointer.27, align 4
  %input.measured.extent.33 = load i32, ptr %input.measured.extent.pointer.28, align 4
  %input.extent.exact.34 = icmp eq i32 %input.measured.extent.33, %input.host.extent.25
  br i1 %input.extent.exact.34, label %input.extent.exact.35, label %input.extent.invalid.36
input.extent.invalid.36:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 8, i32 %input.measured.extent.33, i32 %input.host.extent.25)
  br label %entry.failure.0
input.extent.exact.35:
  %stack.offset.37 = add i32 %stack.offset.23, %input.host.extent.25
  %input.total.exact.38 = icmp eq i32 %stack.offset.37, %input.bytes
  br i1 %input.total.exact.38, label %input.valid.39, label %input.invalid.40
input.invalid.40:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.37, i32 %input.bytes)
  br label %entry.failure.0
input.valid.39:
  %reserve.status.41 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 9)
  %reserve.ok.42 = icmp eq i32 %reserve.status.41, 0
  br i1 %reserve.ok.42, label %reserve.continue.43, label %entry.failure.0
reserve.continue.43:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.45 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.44, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 12, i32 10)
  %helper.ok.46 = icmp eq i32 %input.copy.status.45, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %entry.failure.0
helper.continue.47:
  %host.pointer.48 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.copy.status.49 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.23, ptr %host.pointer.48, i32 %input.host.extent.25, i32 0, i32 %input.measured.payload.32, i32 %input.host.extent.25, i32 12, i32 11)
  %helper.ok.50 = icmp eq i32 %input.copy.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %entry.failure.0
helper.continue.51:
  %entry.body.status.52 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 12)
  %entry.body.ok.53 = icmp eq i32 %entry.body.status.52, 0
  br i1 %entry.body.ok.53, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.54 = add i32 0, %input.bytes
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %value.size.57 = alloca %AlOwningValueSize, align 4
  %measure.status.58 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.54, i32 %context.value.56, i32 13, ptr %value.size.57)
  %helper.ok.59 = icmp eq i32 %measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %value.payload.pointer.61 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 0
  %value.extent.pointer.62 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 1
  %value.payload.63 = load i32, ptr %value.payload.pointer.61, align 4
  %value.extent.64 = load i32, ptr %value.extent.pointer.62, align 4
  %stack.offset.65 = add i32 %stack.offset.54, %value.extent.64
  %stack.offset.66 = add i32 0, %value.payload.63
  %entry.outputs.exact.67 = icmp eq i32 %stack.offset.65, %context.value.56
  br i1 %entry.outputs.exact.67, label %entry.outputs.exact.68, label %entry.failure.0
entry.outputs.exact.68:
  %stack.sub.69 = sub i32 %context.value.56, %stack.offset.54
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.54, i32 %stack.sub.69, i32 %stack.offset.66, i32 0, i32 9)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.69, i32 0, i32 0, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.69, i32 12)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %entry.failure.0
runtime.continue.81:
  %stack.sub.82 = sub i32 0, %stack.offset.66
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.82, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %entry.failure.0
runtime.continue.86:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.offset.93 = add i32 %context.value.88, %context.value.90
  %stack.sub.94 = sub i32 0, %stack.offset.93
  %stack.sub.95 = sub i32 0, %context.value.90
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.94, i32 %stack.sub.95)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.92)
  br label %entry.return.status
entry.return.status:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  ret i32 %context.value.97
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 8, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %value.size.35 = alloca %AlOwningValueSize, align 4
  %measure.status.36 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.33, i32 %stack.offset.16, i32 3, ptr %value.size.35)
  %helper.ok.37 = icmp eq i32 %measure.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %frame.failure.0
helper.continue.38:
  %value.payload.pointer.39 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 0
  %value.extent.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 1
  %value.payload.41 = load i32, ptr %value.payload.pointer.39, align 4
  %value.extent.42 = load i32, ptr %value.extent.pointer.40, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.33, i32 %value.extent.42, i32 %value.payload.41, i32 8, i32 8)
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %runtime.ok.45 = icmp eq i32 %context.value.44, 0
  br i1 %runtime.ok.45, label %runtime.continue.46, label %frame.failure.0
runtime.continue.46:
  %stack.offset.47 = add i32 %stack.offset.33, %value.extent.42
  %stack.offset.48 = add i32 %stack.offset.34, %value.extent.42
  %value.size.49 = alloca %AlOwningValueSize, align 4
  %measure.status.50 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.47, i32 %stack.offset.16, i32 4, ptr %value.size.49)
  %helper.ok.51 = icmp eq i32 %measure.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %frame.failure.0
helper.continue.52:
  %value.payload.pointer.53 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 0
  %value.extent.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 1
  %value.payload.55 = load i32, ptr %value.payload.pointer.53, align 4
  %value.extent.56 = load i32, ptr %value.extent.pointer.54, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.48, i32 %stack.offset.47, i32 %value.extent.56, i32 %value.payload.55, i32 2, i32 8)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %stack.offset.61 = add i32 %stack.offset.47, %value.extent.56
  %stack.offset.62 = add i32 %stack.offset.48, %value.extent.56
  %arguments.exact.63 = icmp eq i32 %stack.offset.61, %stack.offset.16
  br i1 %arguments.exact.63, label %arguments.continue.64, label %frame.failure.0
arguments.continue.64:
  %step.status.65 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.66 = icmp eq i32 %step.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %frame.failure.0
helper.continue.67:
  %stack.offset.68 = add i32 0, 0
  %stack.offset.69 = add i32 %context.value.15, %stack.offset.68
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.offset.73 = add i32 0, %value.extent.28
  %stack.offset.74 = add i32 %stack.offset.73, %value.extent.42
  %stack.offset.75 = add i32 %stack.offset.74, %value.extent.56
  %callee.status.72 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.69, i32 %stack.offset.75, i32 6)
  %helper.ok.76 = icmp eq i32 %callee.status.72, 0
  br i1 %helper.ok.76, label %helper.continue.77, label %frame.failure.0
helper.continue.77:
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %value.size.80 = alloca %AlOwningValueSize, align 4
  %measure.status.81 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %context.value.71, i32 %context.value.79, i32 7, ptr %value.size.80)
  %helper.ok.82 = icmp eq i32 %measure.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %value.payload.pointer.84 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.80, i32 0, i32 0
  %value.extent.pointer.85 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.80, i32 0, i32 1
  %value.payload.86 = load i32, ptr %value.payload.pointer.84, align 4
  %value.extent.87 = load i32, ptr %value.extent.pointer.85, align 4
  %stack.offset.88 = add i32 %context.value.71, %value.extent.87
  %stack.offset.89 = add i32 0, %value.payload.86
  %value.size.90 = alloca %AlOwningValueSize, align 4
  %measure.status.91 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.88, i32 %context.value.79, i32 8, ptr %value.size.90)
  %helper.ok.92 = icmp eq i32 %measure.status.91, 0
  br i1 %helper.ok.92, label %helper.continue.93, label %frame.failure.0
helper.continue.93:
  %value.payload.pointer.94 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.90, i32 0, i32 0
  %value.extent.pointer.95 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.90, i32 0, i32 1
  %value.payload.96 = load i32, ptr %value.payload.pointer.94, align 4
  %value.extent.97 = load i32, ptr %value.extent.pointer.95, align 4
  %stack.offset.98 = add i32 %stack.offset.88, %value.extent.97
  %stack.offset.99 = add i32 %stack.offset.89, %value.payload.96
  %callee.outputs.exact.100 = icmp eq i32 %stack.offset.98, %context.value.79
  br i1 %callee.outputs.exact.100, label %callee.outputs.continue.101, label %frame.failure.0
callee.outputs.continue.101:
  %stack.sub.102 = sub i32 %context.value.79, %context.value.71
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.69, i32 %context.value.71, i32 %stack.sub.102, i32 %stack.offset.99, i32 0, i32 9)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %stack.offset.107 = add i32 %stack.offset.69, %stack.sub.102
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.107, i32 0, i32 0, i32 0)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %stack.offset.112 = add i32 0, %value.extent.87
  %stack.offset.113 = add i32 %stack.offset.112, %value.extent.97
  %stack.offset.114 = add i32 0, %stack.offset.113
  %stack.offset.115 = add i32 %context.value.15, %stack.offset.114
  %cursor.status.116 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.115)
  %cursor.ok.117 = icmp eq i32 %cursor.status.116, 0
  br i1 %cursor.ok.117, label %cursor.continue.118, label %frame.failure.0
cursor.continue.118:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.offset.125 = add i32 %context.value.6, %context.value.8
  %stack.offset.126 = add i32 %context.value.120, %context.value.122
  %stack.sub.127 = sub i32 %stack.offset.125, %stack.offset.126
  %stack.sub.128 = sub i32 %context.value.8, %context.value.122
  %stack.sub.129 = sub i32 %context.value.124, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.127, i32 %stack.sub.128)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.129)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.offset.19 = alloca i32, align 4
  %local.extent.20 = alloca i32, align 4
  %local.payload.21 = alloca i32, align 4
  %local.type.22 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  %local.active.23 = alloca i1, align 1
  %local.offset.24 = alloca i32, align 4
  %local.extent.25 = alloca i32, align 4
  %local.payload.26 = alloca i32, align 4
  %local.type.27 = alloca i32, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %frame.entered.36 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.37 = icmp eq i32 %frame.entered.36, 0
  br i1 %frame.enter.ok.37, label %frame.enter.continue.38, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.38:
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %stack.offset.41 = add i32 %argument.source, %argument.bytes
  %stack.offset.42 = add i32 %context.value.40, %argument.bytes
  %reserve.status.43 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.42, i32 9)
  %reserve.ok.44 = icmp eq i32 %reserve.status.43, 0
  br i1 %reserve.ok.44, label %reserve.continue.45, label %frame.reserve.failure.1
reserve.continue.45:
  %value.size.46 = alloca %AlOwningValueSize, align 4
  %measure.status.47 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %argument.source, i32 %stack.offset.41, i32 10, ptr %value.size.46)
  %helper.ok.48 = icmp eq i32 %measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  %value.payload.pointer.50 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.46, i32 0, i32 0
  %value.extent.pointer.51 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.46, i32 0, i32 1
  %value.payload.52 = load i32, ptr %value.payload.pointer.50, align 4
  %value.extent.53 = load i32, ptr %value.extent.pointer.51, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.40, i32 %argument.source, i32 %value.extent.53, i32 %value.payload.52, i32 8, i32 8)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %frame.failure.0
runtime.continue.57:
  %stack.offset.58 = add i32 %argument.source, %value.extent.53
  %stack.offset.59 = add i32 %context.value.40, %value.extent.53
  %value.size.60 = alloca %AlOwningValueSize, align 4
  %measure.status.61 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.58, i32 %stack.offset.41, i32 11, ptr %value.size.60)
  %helper.ok.62 = icmp eq i32 %measure.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %value.payload.pointer.64 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 0
  %value.extent.pointer.65 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 1
  %value.payload.66 = load i32, ptr %value.payload.pointer.64, align 4
  %value.extent.67 = load i32, ptr %value.extent.pointer.65, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.59, i32 %stack.offset.58, i32 %value.extent.67, i32 %value.payload.66, i32 8, i32 8)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %stack.offset.72 = add i32 %stack.offset.58, %value.extent.67
  %stack.offset.73 = add i32 %stack.offset.59, %value.extent.67
  %value.size.74 = alloca %AlOwningValueSize, align 4
  %measure.status.75 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.72, i32 %stack.offset.41, i32 12, ptr %value.size.74)
  %helper.ok.76 = icmp eq i32 %measure.status.75, 0
  br i1 %helper.ok.76, label %helper.continue.77, label %frame.failure.0
helper.continue.77:
  %value.payload.pointer.78 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.74, i32 0, i32 0
  %value.extent.pointer.79 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.74, i32 0, i32 1
  %value.payload.80 = load i32, ptr %value.payload.pointer.78, align 4
  %value.extent.81 = load i32, ptr %value.extent.pointer.79, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.73, i32 %stack.offset.72, i32 %value.extent.81, i32 %value.payload.80, i32 2, i32 8)
  %context.field.82 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.83 = load i32, ptr %context.field.82, align 4
  %runtime.ok.84 = icmp eq i32 %context.value.83, 0
  br i1 %runtime.ok.84, label %runtime.continue.85, label %frame.failure.0
runtime.continue.85:
  %stack.offset.86 = add i32 %stack.offset.72, %value.extent.81
  %stack.offset.87 = add i32 %stack.offset.73, %value.extent.81
  %arguments.exact.88 = icmp eq i32 %stack.offset.86, %stack.offset.41
  br i1 %arguments.exact.88, label %arguments.continue.89, label %frame.failure.0
arguments.continue.89:
  %step.status.90 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.91 = icmp eq i32 %step.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %local.is.active.93 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.94 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.95 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.96 = select i1 %local.is.active.93, i32 %local.previous.extent.94, i32 0
  %local.old.payload.97 = select i1 %local.is.active.93, i32 %local.previous.payload.95, i32 0
  %stack.offset.98 = add i32 %context.value.40, 0
  %stack.offset.99 = add i32 %stack.offset.98, %local.old.extent.96
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %stack.sub.102 = sub i32 %context.value.101, %stack.offset.99
  %stack.sub.103 = sub i32 %context.value.101, %local.old.extent.96
  %stack.offset.104 = add i32 %stack.sub.103, %value.extent.81
  %local.grows.105 = icmp ugt i32 %value.extent.81, %local.old.extent.96
  br i1 %local.grows.105, label %local.grow.106, label %local.fixed.107
local.grow.106:
  %reserve.status.109 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.104, i32 14)
  %reserve.ok.110 = icmp eq i32 %reserve.status.109, 0
  br i1 %reserve.ok.110, label %reserve.continue.111, label %frame.failure.0
reserve.continue.111:
  %stack.sub.112 = sub i32 %value.extent.81, %local.old.extent.96
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  br label %local.layout.ready.108
local.fixed.107:
  br label %local.layout.ready.108
local.layout.ready.108:
  %stack.offset.117 = add i32 %stack.offset.98, %value.extent.81
  %local.is.active.118 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.119 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.120 = select i1 %local.is.active.118, i32 %local.suffix.payload.119, i32 0
  %stack.offset.121 = add i32 0, %local.suffix.selected.120
  %local.is.active.122 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.123 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.124 = select i1 %local.is.active.122, i32 %local.suffix.payload.123, i32 0
  %stack.offset.125 = add i32 %stack.offset.121, %local.suffix.selected.124
  %local.is.active.126 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.127 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.128 = select i1 %local.is.active.126, i32 %local.suffix.payload.127, i32 0
  %stack.offset.129 = add i32 %stack.offset.125, %local.suffix.selected.128
  %local.is.active.130 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.131 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.132 = select i1 %local.is.active.130, i32 %local.suffix.payload.131, i32 0
  %stack.offset.133 = add i32 %stack.offset.129, %local.suffix.selected.132
  %stack.offset.134 = add i32 0, %value.payload.52
  %stack.offset.135 = add i32 %stack.offset.134, %value.payload.66
  %stack.offset.136 = add i32 %stack.offset.135, %value.payload.80
  %stack.offset.137 = add i32 %stack.offset.133, %stack.offset.136
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.117, i32 %stack.offset.99, i32 %stack.sub.102, i32 %stack.offset.137, i32 0, i32 14)
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %runtime.ok.140 = icmp eq i32 %context.value.139, 0
  br i1 %runtime.ok.140, label %runtime.continue.141, label %frame.failure.0
runtime.continue.141:
  %stack.sub.142 = sub i32 %context.value.101, %value.extent.81
  %stack.sub.143 = sub i32 %stack.sub.142, %local.old.extent.96
  %stack.offset.144 = add i32 %stack.sub.143, %value.extent.81
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.98, i32 %stack.offset.144, i32 %value.extent.81, i32 %value.payload.80, i32 2, i32 4)
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %runtime.ok.147 = icmp eq i32 %context.value.146, 0
  br i1 %runtime.ok.147, label %runtime.continue.148, label %frame.failure.0
runtime.continue.148:
  %stack.sub.149 = sub i32 %context.value.101, %local.old.extent.96
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.149, i32 0, i32 0, i32 0)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %local.shrinks.154 = icmp ult i32 %value.extent.81, %local.old.extent.96
  br i1 %local.shrinks.154, label %local.shrink.155, label %local.counts.ready.156
local.shrink.155:
  %stack.sub.157 = sub i32 %local.old.extent.96, %value.extent.81
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.157)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  br label %local.counts.ready.156
local.counts.ready.156:
  %local.payload.delta.162 = sub i32 %value.payload.80, %local.old.payload.97
  %stack.sub.163 = sub i32 0, %local.old.payload.97
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.163, i32 %local.payload.delta.162)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  %local.is.active.168 = load i1, ptr %local.active.8, align 1
  %local.later.offset.169 = load i32, ptr %local.offset.9, align 4
  %stack.sub.170 = sub i32 %local.later.offset.169, %local.old.extent.96
  %stack.offset.171 = add i32 %stack.sub.170, %value.extent.81
  %local.later.offset.selected.172 = select i1 %local.is.active.168, i32 %stack.offset.171, i32 %local.later.offset.169
  store i32 %local.later.offset.selected.172, ptr %local.offset.9, align 4
  %local.is.active.173 = load i1, ptr %local.active.13, align 1
  %local.later.offset.174 = load i32, ptr %local.offset.14, align 4
  %stack.sub.175 = sub i32 %local.later.offset.174, %local.old.extent.96
  %stack.offset.176 = add i32 %stack.sub.175, %value.extent.81
  %local.later.offset.selected.177 = select i1 %local.is.active.173, i32 %stack.offset.176, i32 %local.later.offset.174
  store i32 %local.later.offset.selected.177, ptr %local.offset.14, align 4
  %local.is.active.178 = load i1, ptr %local.active.18, align 1
  %local.later.offset.179 = load i32, ptr %local.offset.19, align 4
  %stack.sub.180 = sub i32 %local.later.offset.179, %local.old.extent.96
  %stack.offset.181 = add i32 %stack.sub.180, %value.extent.81
  %local.later.offset.selected.182 = select i1 %local.is.active.178, i32 %stack.offset.181, i32 %local.later.offset.179
  store i32 %local.later.offset.selected.182, ptr %local.offset.19, align 4
  %local.is.active.183 = load i1, ptr %local.active.23, align 1
  %local.later.offset.184 = load i32, ptr %local.offset.24, align 4
  %stack.sub.185 = sub i32 %local.later.offset.184, %local.old.extent.96
  %stack.offset.186 = add i32 %stack.sub.185, %value.extent.81
  %local.later.offset.selected.187 = select i1 %local.is.active.183, i32 %stack.offset.186, i32 %local.later.offset.184
  store i32 %local.later.offset.selected.187, ptr %local.offset.24, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.98, ptr %local.offset.4, align 4
  store i32 %value.extent.81, ptr %local.extent.5, align 4
  store i32 %value.payload.80, ptr %local.payload.6, align 4
  store i32 2, ptr %local.type.7, align 4
  %local.is.active.188 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.189 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.190 = select i1 %local.is.active.188, i32 %local.sum.extent.189, i32 0
  %stack.offset.191 = add i32 0, %local.sum.selected.190
  %local.is.active.192 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.193 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.194 = select i1 %local.is.active.192, i32 %local.sum.extent.193, i32 0
  %stack.offset.195 = add i32 %stack.offset.191, %local.sum.selected.194
  %local.is.active.196 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.197 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.198 = select i1 %local.is.active.196, i32 %local.sum.extent.197, i32 0
  %stack.offset.199 = add i32 %stack.offset.195, %local.sum.selected.198
  %local.is.active.200 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.201 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.202 = select i1 %local.is.active.200, i32 %local.sum.extent.201, i32 0
  %stack.offset.203 = add i32 %stack.offset.199, %local.sum.selected.202
  %local.is.active.204 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.205 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.206 = select i1 %local.is.active.204, i32 %local.sum.extent.205, i32 0
  %stack.offset.207 = add i32 %stack.offset.203, %local.sum.selected.206
  %stack.offset.208 = add i32 0, %value.extent.53
  %stack.offset.209 = add i32 %stack.offset.208, %value.extent.67
  %stack.offset.210 = add i32 %stack.offset.207, %stack.offset.209
  %stack.offset.211 = add i32 %context.value.40, %stack.offset.210
  %cursor.status.212 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.211)
  %cursor.ok.213 = icmp eq i32 %cursor.status.212, 0
  br i1 %cursor.ok.213, label %cursor.continue.214, label %frame.failure.0
cursor.continue.214:
  %step.status.215 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.216 = icmp eq i32 %step.status.215, 0
  br i1 %helper.ok.216, label %helper.continue.217, label %frame.failure.0
helper.continue.217:
  %local.is.active.218 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.219 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.220 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.221 = select i1 %local.is.active.218, i32 %local.previous.extent.219, i32 0
  %local.old.payload.222 = select i1 %local.is.active.218, i32 %local.previous.payload.220, i32 0
  %local.is.active.223 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.224 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.225 = select i1 %local.is.active.223, i32 %local.sum.extent.224, i32 0
  %stack.offset.226 = add i32 0, %local.sum.selected.225
  %stack.offset.227 = add i32 %context.value.40, %stack.offset.226
  %stack.offset.228 = add i32 %stack.offset.227, %local.old.extent.221
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %stack.sub.231 = sub i32 %context.value.230, %stack.offset.228
  %stack.sub.232 = sub i32 %context.value.230, %local.old.extent.221
  %stack.offset.233 = add i32 %stack.sub.232, %value.extent.67
  %local.grows.234 = icmp ugt i32 %value.extent.67, %local.old.extent.221
  br i1 %local.grows.234, label %local.grow.235, label %local.fixed.236
local.grow.235:
  %reserve.status.238 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.233, i32 16)
  %reserve.ok.239 = icmp eq i32 %reserve.status.238, 0
  br i1 %reserve.ok.239, label %reserve.continue.240, label %frame.failure.0
reserve.continue.240:
  %stack.sub.241 = sub i32 %value.extent.67, %local.old.extent.221
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.241)
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %runtime.ok.244 = icmp eq i32 %context.value.243, 0
  br i1 %runtime.ok.244, label %runtime.continue.245, label %frame.failure.0
runtime.continue.245:
  br label %local.layout.ready.237
local.fixed.236:
  br label %local.layout.ready.237
local.layout.ready.237:
  %stack.offset.246 = add i32 %stack.offset.227, %value.extent.67
  %local.is.active.247 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.248 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.249 = select i1 %local.is.active.247, i32 %local.suffix.payload.248, i32 0
  %stack.offset.250 = add i32 0, %local.suffix.selected.249
  %local.is.active.251 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.252 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.253 = select i1 %local.is.active.251, i32 %local.suffix.payload.252, i32 0
  %stack.offset.254 = add i32 %stack.offset.250, %local.suffix.selected.253
  %local.is.active.255 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.256 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.257 = select i1 %local.is.active.255, i32 %local.suffix.payload.256, i32 0
  %stack.offset.258 = add i32 %stack.offset.254, %local.suffix.selected.257
  %stack.offset.259 = add i32 0, %value.payload.52
  %stack.offset.260 = add i32 %stack.offset.259, %value.payload.66
  %stack.offset.261 = add i32 %stack.offset.258, %stack.offset.260
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.246, i32 %stack.offset.228, i32 %stack.sub.231, i32 %stack.offset.261, i32 0, i32 14)
  %context.field.262 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.263 = load i32, ptr %context.field.262, align 4
  %runtime.ok.264 = icmp eq i32 %context.value.263, 0
  br i1 %runtime.ok.264, label %runtime.continue.265, label %frame.failure.0
runtime.continue.265:
  %stack.sub.266 = sub i32 %context.value.230, %value.extent.67
  %stack.sub.267 = sub i32 %stack.sub.266, %local.old.extent.221
  %stack.offset.268 = add i32 %stack.sub.267, %value.extent.67
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.227, i32 %stack.offset.268, i32 %value.extent.67, i32 %value.payload.66, i32 8, i32 4)
  %context.field.269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.270 = load i32, ptr %context.field.269, align 4
  %runtime.ok.271 = icmp eq i32 %context.value.270, 0
  br i1 %runtime.ok.271, label %runtime.continue.272, label %frame.failure.0
runtime.continue.272:
  %stack.sub.273 = sub i32 %context.value.230, %local.old.extent.221
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.273, i32 0, i32 0, i32 0)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %local.shrinks.278 = icmp ult i32 %value.extent.67, %local.old.extent.221
  br i1 %local.shrinks.278, label %local.shrink.279, label %local.counts.ready.280
local.shrink.279:
  %stack.sub.281 = sub i32 %local.old.extent.221, %value.extent.67
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.281)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  br label %local.counts.ready.280
local.counts.ready.280:
  %local.payload.delta.286 = sub i32 %value.payload.66, %local.old.payload.222
  %stack.sub.287 = sub i32 0, %local.old.payload.222
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.287, i32 %local.payload.delta.286)
  %context.field.288 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.289 = load i32, ptr %context.field.288, align 4
  %runtime.ok.290 = icmp eq i32 %context.value.289, 0
  br i1 %runtime.ok.290, label %runtime.continue.291, label %frame.failure.0
runtime.continue.291:
  %local.is.active.292 = load i1, ptr %local.active.13, align 1
  %local.later.offset.293 = load i32, ptr %local.offset.14, align 4
  %stack.sub.294 = sub i32 %local.later.offset.293, %local.old.extent.221
  %stack.offset.295 = add i32 %stack.sub.294, %value.extent.67
  %local.later.offset.selected.296 = select i1 %local.is.active.292, i32 %stack.offset.295, i32 %local.later.offset.293
  store i32 %local.later.offset.selected.296, ptr %local.offset.14, align 4
  %local.is.active.297 = load i1, ptr %local.active.18, align 1
  %local.later.offset.298 = load i32, ptr %local.offset.19, align 4
  %stack.sub.299 = sub i32 %local.later.offset.298, %local.old.extent.221
  %stack.offset.300 = add i32 %stack.sub.299, %value.extent.67
  %local.later.offset.selected.301 = select i1 %local.is.active.297, i32 %stack.offset.300, i32 %local.later.offset.298
  store i32 %local.later.offset.selected.301, ptr %local.offset.19, align 4
  %local.is.active.302 = load i1, ptr %local.active.23, align 1
  %local.later.offset.303 = load i32, ptr %local.offset.24, align 4
  %stack.sub.304 = sub i32 %local.later.offset.303, %local.old.extent.221
  %stack.offset.305 = add i32 %stack.sub.304, %value.extent.67
  %local.later.offset.selected.306 = select i1 %local.is.active.302, i32 %stack.offset.305, i32 %local.later.offset.303
  store i32 %local.later.offset.selected.306, ptr %local.offset.24, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.227, ptr %local.offset.9, align 4
  store i32 %value.extent.67, ptr %local.extent.10, align 4
  store i32 %value.payload.66, ptr %local.payload.11, align 4
  store i32 8, ptr %local.type.12, align 4
  %local.is.active.307 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.308 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.309 = select i1 %local.is.active.307, i32 %local.sum.extent.308, i32 0
  %stack.offset.310 = add i32 0, %local.sum.selected.309
  %local.is.active.311 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.312 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.313 = select i1 %local.is.active.311, i32 %local.sum.extent.312, i32 0
  %stack.offset.314 = add i32 %stack.offset.310, %local.sum.selected.313
  %local.is.active.315 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.316 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.317 = select i1 %local.is.active.315, i32 %local.sum.extent.316, i32 0
  %stack.offset.318 = add i32 %stack.offset.314, %local.sum.selected.317
  %local.is.active.319 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.320 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.321 = select i1 %local.is.active.319, i32 %local.sum.extent.320, i32 0
  %stack.offset.322 = add i32 %stack.offset.318, %local.sum.selected.321
  %local.is.active.323 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.324 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.325 = select i1 %local.is.active.323, i32 %local.sum.extent.324, i32 0
  %stack.offset.326 = add i32 %stack.offset.322, %local.sum.selected.325
  %stack.offset.327 = add i32 0, %value.extent.53
  %stack.offset.328 = add i32 %stack.offset.326, %stack.offset.327
  %stack.offset.329 = add i32 %context.value.40, %stack.offset.328
  %cursor.status.330 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.329)
  %cursor.ok.331 = icmp eq i32 %cursor.status.330, 0
  br i1 %cursor.ok.331, label %cursor.continue.332, label %frame.failure.0
cursor.continue.332:
  %step.status.333 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.334 = icmp eq i32 %step.status.333, 0
  br i1 %helper.ok.334, label %helper.continue.335, label %frame.failure.0
helper.continue.335:
  %local.is.active.336 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.337 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.338 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.339 = select i1 %local.is.active.336, i32 %local.previous.extent.337, i32 0
  %local.old.payload.340 = select i1 %local.is.active.336, i32 %local.previous.payload.338, i32 0
  %local.is.active.341 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.342 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.343 = select i1 %local.is.active.341, i32 %local.sum.extent.342, i32 0
  %stack.offset.344 = add i32 0, %local.sum.selected.343
  %local.is.active.345 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.346 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.347 = select i1 %local.is.active.345, i32 %local.sum.extent.346, i32 0
  %stack.offset.348 = add i32 %stack.offset.344, %local.sum.selected.347
  %stack.offset.349 = add i32 %context.value.40, %stack.offset.348
  %stack.offset.350 = add i32 %stack.offset.349, %local.old.extent.339
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %stack.sub.353 = sub i32 %context.value.352, %stack.offset.350
  %stack.sub.354 = sub i32 %context.value.352, %local.old.extent.339
  %stack.offset.355 = add i32 %stack.sub.354, %value.extent.53
  %local.grows.356 = icmp ugt i32 %value.extent.53, %local.old.extent.339
  br i1 %local.grows.356, label %local.grow.357, label %local.fixed.358
local.grow.357:
  %reserve.status.360 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.355, i32 18)
  %reserve.ok.361 = icmp eq i32 %reserve.status.360, 0
  br i1 %reserve.ok.361, label %reserve.continue.362, label %frame.failure.0
reserve.continue.362:
  %stack.sub.363 = sub i32 %value.extent.53, %local.old.extent.339
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.363)
  %context.field.364 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.365 = load i32, ptr %context.field.364, align 4
  %runtime.ok.366 = icmp eq i32 %context.value.365, 0
  br i1 %runtime.ok.366, label %runtime.continue.367, label %frame.failure.0
runtime.continue.367:
  br label %local.layout.ready.359
local.fixed.358:
  br label %local.layout.ready.359
local.layout.ready.359:
  %stack.offset.368 = add i32 %stack.offset.349, %value.extent.53
  %local.is.active.369 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.370 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.371 = select i1 %local.is.active.369, i32 %local.suffix.payload.370, i32 0
  %stack.offset.372 = add i32 0, %local.suffix.selected.371
  %local.is.active.373 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.374 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.375 = select i1 %local.is.active.373, i32 %local.suffix.payload.374, i32 0
  %stack.offset.376 = add i32 %stack.offset.372, %local.suffix.selected.375
  %stack.offset.377 = add i32 0, %value.payload.52
  %stack.offset.378 = add i32 %stack.offset.376, %stack.offset.377
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.368, i32 %stack.offset.350, i32 %stack.sub.353, i32 %stack.offset.378, i32 0, i32 14)
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %runtime.ok.381 = icmp eq i32 %context.value.380, 0
  br i1 %runtime.ok.381, label %runtime.continue.382, label %frame.failure.0
runtime.continue.382:
  %stack.sub.383 = sub i32 %context.value.352, %value.extent.53
  %stack.sub.384 = sub i32 %stack.sub.383, %local.old.extent.339
  %stack.offset.385 = add i32 %stack.sub.384, %value.extent.53
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.349, i32 %stack.offset.385, i32 %value.extent.53, i32 %value.payload.52, i32 8, i32 4)
  %context.field.386 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.387 = load i32, ptr %context.field.386, align 4
  %runtime.ok.388 = icmp eq i32 %context.value.387, 0
  br i1 %runtime.ok.388, label %runtime.continue.389, label %frame.failure.0
runtime.continue.389:
  %stack.sub.390 = sub i32 %context.value.352, %local.old.extent.339
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.390, i32 0, i32 0, i32 0)
  %context.field.391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.392 = load i32, ptr %context.field.391, align 4
  %runtime.ok.393 = icmp eq i32 %context.value.392, 0
  br i1 %runtime.ok.393, label %runtime.continue.394, label %frame.failure.0
runtime.continue.394:
  %local.shrinks.395 = icmp ult i32 %value.extent.53, %local.old.extent.339
  br i1 %local.shrinks.395, label %local.shrink.396, label %local.counts.ready.397
local.shrink.396:
  %stack.sub.398 = sub i32 %local.old.extent.339, %value.extent.53
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.398)
  %context.field.399 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.400 = load i32, ptr %context.field.399, align 4
  %runtime.ok.401 = icmp eq i32 %context.value.400, 0
  br i1 %runtime.ok.401, label %runtime.continue.402, label %frame.failure.0
runtime.continue.402:
  br label %local.counts.ready.397
local.counts.ready.397:
  %local.payload.delta.403 = sub i32 %value.payload.52, %local.old.payload.340
  %stack.sub.404 = sub i32 0, %local.old.payload.340
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.404, i32 %local.payload.delta.403)
  %context.field.405 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.406 = load i32, ptr %context.field.405, align 4
  %runtime.ok.407 = icmp eq i32 %context.value.406, 0
  br i1 %runtime.ok.407, label %runtime.continue.408, label %frame.failure.0
runtime.continue.408:
  %local.is.active.409 = load i1, ptr %local.active.18, align 1
  %local.later.offset.410 = load i32, ptr %local.offset.19, align 4
  %stack.sub.411 = sub i32 %local.later.offset.410, %local.old.extent.339
  %stack.offset.412 = add i32 %stack.sub.411, %value.extent.53
  %local.later.offset.selected.413 = select i1 %local.is.active.409, i32 %stack.offset.412, i32 %local.later.offset.410
  store i32 %local.later.offset.selected.413, ptr %local.offset.19, align 4
  %local.is.active.414 = load i1, ptr %local.active.23, align 1
  %local.later.offset.415 = load i32, ptr %local.offset.24, align 4
  %stack.sub.416 = sub i32 %local.later.offset.415, %local.old.extent.339
  %stack.offset.417 = add i32 %stack.sub.416, %value.extent.53
  %local.later.offset.selected.418 = select i1 %local.is.active.414, i32 %stack.offset.417, i32 %local.later.offset.415
  store i32 %local.later.offset.selected.418, ptr %local.offset.24, align 4
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.349, ptr %local.offset.14, align 4
  store i32 %value.extent.53, ptr %local.extent.15, align 4
  store i32 %value.payload.52, ptr %local.payload.16, align 4
  store i32 8, ptr %local.type.17, align 4
  %local.is.active.419 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.420 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.421 = select i1 %local.is.active.419, i32 %local.sum.extent.420, i32 0
  %stack.offset.422 = add i32 0, %local.sum.selected.421
  %local.is.active.423 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.424 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.425 = select i1 %local.is.active.423, i32 %local.sum.extent.424, i32 0
  %stack.offset.426 = add i32 %stack.offset.422, %local.sum.selected.425
  %local.is.active.427 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.428 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.429 = select i1 %local.is.active.427, i32 %local.sum.extent.428, i32 0
  %stack.offset.430 = add i32 %stack.offset.426, %local.sum.selected.429
  %local.is.active.431 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.432 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.433 = select i1 %local.is.active.431, i32 %local.sum.extent.432, i32 0
  %stack.offset.434 = add i32 %stack.offset.430, %local.sum.selected.433
  %local.is.active.435 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.436 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.437 = select i1 %local.is.active.435, i32 %local.sum.extent.436, i32 0
  %stack.offset.438 = add i32 %stack.offset.434, %local.sum.selected.437
  %stack.offset.439 = add i32 %stack.offset.438, 0
  %stack.offset.440 = add i32 %context.value.40, %stack.offset.439
  %cursor.status.441 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.440)
  %cursor.ok.442 = icmp eq i32 %cursor.status.441, 0
  br i1 %cursor.ok.442, label %cursor.continue.443, label %frame.failure.0
cursor.continue.443:
  %step.status.444 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.445 = icmp eq i32 %step.status.444, 0
  br i1 %helper.ok.445, label %helper.continue.446, label %frame.failure.0
helper.continue.446:
  %local.source.offset.447 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.448 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.449 = load i32, ptr %local.payload.6, align 4
  %context.field.450 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.451 = load i32, ptr %context.field.450, align 4
  %stack.offset.452 = add i32 %context.value.451, %local.source.extent.448
  %reserve.status.453 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.452, i32 20)
  %reserve.ok.454 = icmp eq i32 %reserve.status.453, 0
  br i1 %reserve.ok.454, label %reserve.continue.455, label %frame.failure.0
reserve.continue.455:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.451, i32 %local.source.offset.447, i32 %local.source.extent.448, i32 %local.source.payload.449, i32 2)
  %context.field.456 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.457 = load i32, ptr %context.field.456, align 4
  %runtime.ok.458 = icmp eq i32 %context.value.457, 0
  br i1 %runtime.ok.458, label %runtime.continue.459, label %frame.failure.0
runtime.continue.459:
  %local.is.active.460 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.461 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.462 = select i1 %local.is.active.460, i32 %local.sum.extent.461, i32 0
  %stack.offset.463 = add i32 0, %local.sum.selected.462
  %local.is.active.464 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.465 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.466 = select i1 %local.is.active.464, i32 %local.sum.extent.465, i32 0
  %stack.offset.467 = add i32 %stack.offset.463, %local.sum.selected.466
  %local.is.active.468 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.469 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.470 = select i1 %local.is.active.468, i32 %local.sum.extent.469, i32 0
  %stack.offset.471 = add i32 %stack.offset.467, %local.sum.selected.470
  %local.is.active.472 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.473 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.474 = select i1 %local.is.active.472, i32 %local.sum.extent.473, i32 0
  %stack.offset.475 = add i32 %stack.offset.471, %local.sum.selected.474
  %local.is.active.476 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.477 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.478 = select i1 %local.is.active.476, i32 %local.sum.extent.477, i32 0
  %stack.offset.479 = add i32 %stack.offset.475, %local.sum.selected.478
  %stack.offset.480 = add i32 0, %local.source.extent.448
  %stack.offset.481 = add i32 %stack.offset.479, %stack.offset.480
  %stack.offset.482 = add i32 %context.value.40, %stack.offset.481
  %cursor.status.483 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.482)
  %cursor.ok.484 = icmp eq i32 %cursor.status.483, 0
  br i1 %cursor.ok.484, label %cursor.continue.485, label %frame.failure.0
cursor.continue.485:
  %step.status.486 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.487 = icmp eq i32 %step.status.486, 0
  br i1 %helper.ok.487, label %helper.continue.488, label %frame.failure.0
helper.continue.488:
  %context.field.489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.490 = load i32, ptr %context.field.489, align 4
  %stack.sub.491 = sub i32 %context.value.490, %local.source.extent.448
  %if.condition.raw.492 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.491)
  %context.field.493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.494 = load i32, ptr %context.field.493, align 4
  %runtime.ok.495 = icmp eq i32 %context.value.494, 0
  br i1 %runtime.ok.495, label %runtime.continue.496, label %frame.failure.0
runtime.continue.496:
  %if.condition.497 = icmp ne i64 %if.condition.raw.492, 0
  %context.field.498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.499 = load i32, ptr %context.field.498, align 4
  %stack.sub.500 = sub i32 %context.value.499, %local.source.extent.448
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.500, i32 %local.source.extent.448, i32 %local.source.payload.449, i32 2)
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  %runtime.ok.503 = icmp eq i32 %context.value.502, 0
  br i1 %runtime.ok.503, label %runtime.continue.504, label %frame.failure.0
runtime.continue.504:
  br i1 %if.condition.497, label %if.then.505, label %if.else.506
if.then.505:
  %step.status.508 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.509 = icmp eq i32 %step.status.508, 0
  br i1 %helper.ok.509, label %helper.continue.510, label %frame.failure.0
helper.continue.510:
  %step.status.511 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.512 = icmp eq i32 %step.status.511, 0
  br i1 %helper.ok.512, label %helper.continue.513, label %frame.failure.0
helper.continue.513:
  %local.source.offset.514 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.515 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.516 = load i32, ptr %local.payload.16, align 4
  %context.field.517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.518 = load i32, ptr %context.field.517, align 4
  %stack.offset.519 = add i32 %context.value.518, %local.source.extent.515
  %reserve.status.520 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.519, i32 24)
  %reserve.ok.521 = icmp eq i32 %reserve.status.520, 0
  br i1 %reserve.ok.521, label %reserve.continue.522, label %frame.failure.0
reserve.continue.522:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.518, i32 %local.source.offset.514, i32 %local.source.extent.515, i32 %local.source.payload.516, i32 8)
  %context.field.523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.524 = load i32, ptr %context.field.523, align 4
  %runtime.ok.525 = icmp eq i32 %context.value.524, 0
  br i1 %runtime.ok.525, label %runtime.continue.526, label %frame.failure.0
runtime.continue.526:
  %local.is.active.527 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.528 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.529 = select i1 %local.is.active.527, i32 %local.sum.extent.528, i32 0
  %stack.offset.530 = add i32 0, %local.sum.selected.529
  %local.is.active.531 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.532 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.533 = select i1 %local.is.active.531, i32 %local.sum.extent.532, i32 0
  %stack.offset.534 = add i32 %stack.offset.530, %local.sum.selected.533
  %local.is.active.535 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.536 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.537 = select i1 %local.is.active.535, i32 %local.sum.extent.536, i32 0
  %stack.offset.538 = add i32 %stack.offset.534, %local.sum.selected.537
  %local.is.active.539 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.540 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.541 = select i1 %local.is.active.539, i32 %local.sum.extent.540, i32 0
  %stack.offset.542 = add i32 %stack.offset.538, %local.sum.selected.541
  %local.is.active.543 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.544 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.545 = select i1 %local.is.active.543, i32 %local.sum.extent.544, i32 0
  %stack.offset.546 = add i32 %stack.offset.542, %local.sum.selected.545
  %stack.offset.547 = add i32 0, %local.source.extent.515
  %stack.offset.548 = add i32 %stack.offset.546, %stack.offset.547
  %stack.offset.549 = add i32 %context.value.40, %stack.offset.548
  %cursor.status.550 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.549)
  %cursor.ok.551 = icmp eq i32 %cursor.status.550, 0
  br i1 %cursor.ok.551, label %cursor.continue.552, label %frame.failure.0
cursor.continue.552:
  %local.is.active.553 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.554 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.555 = select i1 %local.is.active.553, i32 %local.sum.extent.554, i32 0
  %stack.offset.556 = add i32 0, %local.sum.selected.555
  %local.is.active.557 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.558 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.559 = select i1 %local.is.active.557, i32 %local.sum.extent.558, i32 0
  %stack.offset.560 = add i32 %stack.offset.556, %local.sum.selected.559
  %local.is.active.561 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.562 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.563 = select i1 %local.is.active.561, i32 %local.sum.extent.562, i32 0
  %stack.offset.564 = add i32 %stack.offset.560, %local.sum.selected.563
  %local.is.active.565 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.566 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.567 = select i1 %local.is.active.565, i32 %local.sum.extent.566, i32 0
  %stack.offset.568 = add i32 %stack.offset.564, %local.sum.selected.567
  %local.is.active.569 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.570 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.571 = select i1 %local.is.active.569, i32 %local.sum.extent.570, i32 0
  %stack.offset.572 = add i32 %stack.offset.568, %local.sum.selected.571
  %stack.offset.573 = add i32 0, %local.source.extent.515
  %stack.offset.574 = add i32 %stack.offset.572, %stack.offset.573
  %stack.offset.575 = add i32 %context.value.40, %stack.offset.574
  %cursor.status.576 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.575)
  %cursor.ok.577 = icmp eq i32 %cursor.status.576, 0
  br i1 %cursor.ok.577, label %cursor.continue.578, label %frame.failure.0
cursor.continue.578:
  br label %if.join.507
if.else.506:
  %step.status.579 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.580 = icmp eq i32 %step.status.579, 0
  br i1 %helper.ok.580, label %helper.continue.581, label %frame.failure.0
helper.continue.581:
  %step.status.582 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.583 = icmp eq i32 %step.status.582, 0
  br i1 %helper.ok.583, label %helper.continue.584, label %frame.failure.0
helper.continue.584:
  %local.source.offset.585 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.586 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.587 = load i32, ptr %local.payload.11, align 4
  %context.field.588 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.589 = load i32, ptr %context.field.588, align 4
  %stack.offset.590 = add i32 %context.value.589, %local.source.extent.586
  %reserve.status.591 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.590, i32 27)
  %reserve.ok.592 = icmp eq i32 %reserve.status.591, 0
  br i1 %reserve.ok.592, label %reserve.continue.593, label %frame.failure.0
reserve.continue.593:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.589, i32 %local.source.offset.585, i32 %local.source.extent.586, i32 %local.source.payload.587, i32 8)
  %context.field.594 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.595 = load i32, ptr %context.field.594, align 4
  %runtime.ok.596 = icmp eq i32 %context.value.595, 0
  br i1 %runtime.ok.596, label %runtime.continue.597, label %frame.failure.0
runtime.continue.597:
  %local.is.active.598 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.599 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.600 = select i1 %local.is.active.598, i32 %local.sum.extent.599, i32 0
  %stack.offset.601 = add i32 0, %local.sum.selected.600
  %local.is.active.602 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.603 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.604 = select i1 %local.is.active.602, i32 %local.sum.extent.603, i32 0
  %stack.offset.605 = add i32 %stack.offset.601, %local.sum.selected.604
  %local.is.active.606 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.607 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.608 = select i1 %local.is.active.606, i32 %local.sum.extent.607, i32 0
  %stack.offset.609 = add i32 %stack.offset.605, %local.sum.selected.608
  %local.is.active.610 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.611 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.612 = select i1 %local.is.active.610, i32 %local.sum.extent.611, i32 0
  %stack.offset.613 = add i32 %stack.offset.609, %local.sum.selected.612
  %local.is.active.614 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.615 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.616 = select i1 %local.is.active.614, i32 %local.sum.extent.615, i32 0
  %stack.offset.617 = add i32 %stack.offset.613, %local.sum.selected.616
  %stack.offset.618 = add i32 0, %local.source.extent.586
  %stack.offset.619 = add i32 %stack.offset.617, %stack.offset.618
  %stack.offset.620 = add i32 %context.value.40, %stack.offset.619
  %cursor.status.621 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.620)
  %cursor.ok.622 = icmp eq i32 %cursor.status.621, 0
  br i1 %cursor.ok.622, label %cursor.continue.623, label %frame.failure.0
cursor.continue.623:
  %local.is.active.624 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.625 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.626 = select i1 %local.is.active.624, i32 %local.sum.extent.625, i32 0
  %stack.offset.627 = add i32 0, %local.sum.selected.626
  %local.is.active.628 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.629 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.630 = select i1 %local.is.active.628, i32 %local.sum.extent.629, i32 0
  %stack.offset.631 = add i32 %stack.offset.627, %local.sum.selected.630
  %local.is.active.632 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.633 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.634 = select i1 %local.is.active.632, i32 %local.sum.extent.633, i32 0
  %stack.offset.635 = add i32 %stack.offset.631, %local.sum.selected.634
  %local.is.active.636 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.637 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.638 = select i1 %local.is.active.636, i32 %local.sum.extent.637, i32 0
  %stack.offset.639 = add i32 %stack.offset.635, %local.sum.selected.638
  %local.is.active.640 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.641 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.642 = select i1 %local.is.active.640, i32 %local.sum.extent.641, i32 0
  %stack.offset.643 = add i32 %stack.offset.639, %local.sum.selected.642
  %stack.offset.644 = add i32 0, %local.source.extent.586
  %stack.offset.645 = add i32 %stack.offset.643, %stack.offset.644
  %stack.offset.646 = add i32 %context.value.40, %stack.offset.645
  %cursor.status.647 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.646)
  %cursor.ok.648 = icmp eq i32 %cursor.status.647, 0
  br i1 %cursor.ok.648, label %cursor.continue.649, label %frame.failure.0
cursor.continue.649:
  br label %if.join.507
if.join.507:
  %if.value.extent.650 = phi i32 [ %local.source.extent.515, %cursor.continue.578 ], [ %local.source.extent.586, %cursor.continue.649 ]
  %if.value.payload.651 = phi i32 [ %local.source.payload.516, %cursor.continue.578 ], [ %local.source.payload.587, %cursor.continue.649 ]
  %local.is.active.652 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.653 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.654 = select i1 %local.is.active.652, i32 %local.sum.extent.653, i32 0
  %stack.offset.655 = add i32 0, %local.sum.selected.654
  %local.is.active.656 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.657 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.658 = select i1 %local.is.active.656, i32 %local.sum.extent.657, i32 0
  %stack.offset.659 = add i32 %stack.offset.655, %local.sum.selected.658
  %local.is.active.660 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.661 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.662 = select i1 %local.is.active.660, i32 %local.sum.extent.661, i32 0
  %stack.offset.663 = add i32 %stack.offset.659, %local.sum.selected.662
  %local.is.active.664 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.665 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.666 = select i1 %local.is.active.664, i32 %local.sum.extent.665, i32 0
  %stack.offset.667 = add i32 %stack.offset.663, %local.sum.selected.666
  %local.is.active.668 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.669 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.670 = select i1 %local.is.active.668, i32 %local.sum.extent.669, i32 0
  %stack.offset.671 = add i32 %stack.offset.667, %local.sum.selected.670
  %stack.offset.672 = add i32 0, %if.value.extent.650
  %stack.offset.673 = add i32 %stack.offset.671, %stack.offset.672
  %stack.offset.674 = add i32 %context.value.40, %stack.offset.673
  %cursor.status.675 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.674)
  %cursor.ok.676 = icmp eq i32 %cursor.status.675, 0
  br i1 %cursor.ok.676, label %cursor.continue.677, label %frame.failure.0
cursor.continue.677:
  %step.status.678 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.679 = icmp eq i32 %step.status.678, 0
  br i1 %helper.ok.679, label %helper.continue.680, label %frame.failure.0
helper.continue.680:
  %local.is.active.681 = load i1, ptr %local.active.18, align 1
  %local.previous.extent.682 = load i32, ptr %local.extent.20, align 4
  %local.previous.payload.683 = load i32, ptr %local.payload.21, align 4
  %local.old.extent.684 = select i1 %local.is.active.681, i32 %local.previous.extent.682, i32 0
  %local.old.payload.685 = select i1 %local.is.active.681, i32 %local.previous.payload.683, i32 0
  %local.is.active.686 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.687 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.688 = select i1 %local.is.active.686, i32 %local.sum.extent.687, i32 0
  %stack.offset.689 = add i32 0, %local.sum.selected.688
  %local.is.active.690 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.691 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.692 = select i1 %local.is.active.690, i32 %local.sum.extent.691, i32 0
  %stack.offset.693 = add i32 %stack.offset.689, %local.sum.selected.692
  %local.is.active.694 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.695 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.696 = select i1 %local.is.active.694, i32 %local.sum.extent.695, i32 0
  %stack.offset.697 = add i32 %stack.offset.693, %local.sum.selected.696
  %stack.offset.698 = add i32 %context.value.40, %stack.offset.697
  %stack.offset.699 = add i32 %stack.offset.698, %local.old.extent.684
  %context.field.700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.701 = load i32, ptr %context.field.700, align 4
  %stack.sub.702 = sub i32 %context.value.701, %stack.offset.699
  %stack.sub.703 = sub i32 %context.value.701, %local.old.extent.684
  %stack.offset.704 = add i32 %stack.sub.703, %if.value.extent.650
  %local.grows.705 = icmp ugt i32 %if.value.extent.650, %local.old.extent.684
  br i1 %local.grows.705, label %local.grow.706, label %local.fixed.707
local.grow.706:
  %reserve.status.709 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.704, i32 29)
  %reserve.ok.710 = icmp eq i32 %reserve.status.709, 0
  br i1 %reserve.ok.710, label %reserve.continue.711, label %frame.failure.0
reserve.continue.711:
  %stack.sub.712 = sub i32 %if.value.extent.650, %local.old.extent.684
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.712)
  %context.field.713 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.714 = load i32, ptr %context.field.713, align 4
  %runtime.ok.715 = icmp eq i32 %context.value.714, 0
  br i1 %runtime.ok.715, label %runtime.continue.716, label %frame.failure.0
runtime.continue.716:
  br label %local.layout.ready.708
local.fixed.707:
  br label %local.layout.ready.708
local.layout.ready.708:
  %stack.offset.717 = add i32 %stack.offset.698, %if.value.extent.650
  %local.is.active.718 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.719 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.720 = select i1 %local.is.active.718, i32 %local.suffix.payload.719, i32 0
  %stack.offset.721 = add i32 0, %local.suffix.selected.720
  %stack.offset.722 = add i32 0, %if.value.payload.651
  %stack.offset.723 = add i32 %stack.offset.721, %stack.offset.722
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.717, i32 %stack.offset.699, i32 %stack.sub.702, i32 %stack.offset.723, i32 0, i32 14)
  %context.field.724 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.725 = load i32, ptr %context.field.724, align 4
  %runtime.ok.726 = icmp eq i32 %context.value.725, 0
  br i1 %runtime.ok.726, label %runtime.continue.727, label %frame.failure.0
runtime.continue.727:
  %stack.sub.728 = sub i32 %context.value.701, %if.value.extent.650
  %stack.sub.729 = sub i32 %stack.sub.728, %local.old.extent.684
  %stack.offset.730 = add i32 %stack.sub.729, %if.value.extent.650
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.698, i32 %stack.offset.730, i32 %if.value.extent.650, i32 %if.value.payload.651, i32 8, i32 4)
  %context.field.731 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.732 = load i32, ptr %context.field.731, align 4
  %runtime.ok.733 = icmp eq i32 %context.value.732, 0
  br i1 %runtime.ok.733, label %runtime.continue.734, label %frame.failure.0
runtime.continue.734:
  %stack.sub.735 = sub i32 %context.value.701, %local.old.extent.684
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.735, i32 0, i32 0, i32 0)
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.737 = load i32, ptr %context.field.736, align 4
  %runtime.ok.738 = icmp eq i32 %context.value.737, 0
  br i1 %runtime.ok.738, label %runtime.continue.739, label %frame.failure.0
runtime.continue.739:
  %local.shrinks.740 = icmp ult i32 %if.value.extent.650, %local.old.extent.684
  br i1 %local.shrinks.740, label %local.shrink.741, label %local.counts.ready.742
local.shrink.741:
  %stack.sub.743 = sub i32 %local.old.extent.684, %if.value.extent.650
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.743)
  %context.field.744 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.745 = load i32, ptr %context.field.744, align 4
  %runtime.ok.746 = icmp eq i32 %context.value.745, 0
  br i1 %runtime.ok.746, label %runtime.continue.747, label %frame.failure.0
runtime.continue.747:
  br label %local.counts.ready.742
local.counts.ready.742:
  %local.payload.delta.748 = sub i32 %if.value.payload.651, %local.old.payload.685
  %stack.sub.749 = sub i32 0, %local.old.payload.685
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.749, i32 %local.payload.delta.748)
  %context.field.750 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.751 = load i32, ptr %context.field.750, align 4
  %runtime.ok.752 = icmp eq i32 %context.value.751, 0
  br i1 %runtime.ok.752, label %runtime.continue.753, label %frame.failure.0
runtime.continue.753:
  %local.is.active.754 = load i1, ptr %local.active.23, align 1
  %local.later.offset.755 = load i32, ptr %local.offset.24, align 4
  %stack.sub.756 = sub i32 %local.later.offset.755, %local.old.extent.684
  %stack.offset.757 = add i32 %stack.sub.756, %if.value.extent.650
  %local.later.offset.selected.758 = select i1 %local.is.active.754, i32 %stack.offset.757, i32 %local.later.offset.755
  store i32 %local.later.offset.selected.758, ptr %local.offset.24, align 4
  store i1 true, ptr %local.active.18, align 1
  store i32 %stack.offset.698, ptr %local.offset.19, align 4
  store i32 %if.value.extent.650, ptr %local.extent.20, align 4
  store i32 %if.value.payload.651, ptr %local.payload.21, align 4
  store i32 8, ptr %local.type.22, align 4
  %local.is.active.759 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.760 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.761 = select i1 %local.is.active.759, i32 %local.sum.extent.760, i32 0
  %stack.offset.762 = add i32 0, %local.sum.selected.761
  %local.is.active.763 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.764 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.765 = select i1 %local.is.active.763, i32 %local.sum.extent.764, i32 0
  %stack.offset.766 = add i32 %stack.offset.762, %local.sum.selected.765
  %local.is.active.767 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.768 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.769 = select i1 %local.is.active.767, i32 %local.sum.extent.768, i32 0
  %stack.offset.770 = add i32 %stack.offset.766, %local.sum.selected.769
  %local.is.active.771 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.772 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.773 = select i1 %local.is.active.771, i32 %local.sum.extent.772, i32 0
  %stack.offset.774 = add i32 %stack.offset.770, %local.sum.selected.773
  %local.is.active.775 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.776 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.777 = select i1 %local.is.active.775, i32 %local.sum.extent.776, i32 0
  %stack.offset.778 = add i32 %stack.offset.774, %local.sum.selected.777
  %stack.offset.779 = add i32 %stack.offset.778, 0
  %stack.offset.780 = add i32 %context.value.40, %stack.offset.779
  %cursor.status.781 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.780)
  %cursor.ok.782 = icmp eq i32 %cursor.status.781, 0
  br i1 %cursor.ok.782, label %cursor.continue.783, label %frame.failure.0
cursor.continue.783:
  %step.status.784 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.785 = icmp eq i32 %step.status.784, 0
  br i1 %helper.ok.785, label %helper.continue.786, label %frame.failure.0
helper.continue.786:
  %local.source.offset.787 = load i32, ptr %local.offset.19, align 4
  %local.source.extent.788 = load i32, ptr %local.extent.20, align 4
  %local.source.payload.789 = load i32, ptr %local.payload.21, align 4
  %context.field.790 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.791 = load i32, ptr %context.field.790, align 4
  %stack.offset.792 = add i32 %context.value.791, %local.source.extent.788
  %reserve.status.793 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.792, i32 31)
  %reserve.ok.794 = icmp eq i32 %reserve.status.793, 0
  br i1 %reserve.ok.794, label %reserve.continue.795, label %frame.failure.0
reserve.continue.795:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.791, i32 %local.source.offset.787, i32 %local.source.extent.788, i32 %local.source.payload.789, i32 8)
  %context.field.796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.797 = load i32, ptr %context.field.796, align 4
  %runtime.ok.798 = icmp eq i32 %context.value.797, 0
  br i1 %runtime.ok.798, label %runtime.continue.799, label %frame.failure.0
runtime.continue.799:
  %local.is.active.800 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.801 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.802 = select i1 %local.is.active.800, i32 %local.sum.extent.801, i32 0
  %stack.offset.803 = add i32 0, %local.sum.selected.802
  %local.is.active.804 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.805 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.806 = select i1 %local.is.active.804, i32 %local.sum.extent.805, i32 0
  %stack.offset.807 = add i32 %stack.offset.803, %local.sum.selected.806
  %local.is.active.808 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.809 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.810 = select i1 %local.is.active.808, i32 %local.sum.extent.809, i32 0
  %stack.offset.811 = add i32 %stack.offset.807, %local.sum.selected.810
  %local.is.active.812 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.813 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.814 = select i1 %local.is.active.812, i32 %local.sum.extent.813, i32 0
  %stack.offset.815 = add i32 %stack.offset.811, %local.sum.selected.814
  %local.is.active.816 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.817 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.818 = select i1 %local.is.active.816, i32 %local.sum.extent.817, i32 0
  %stack.offset.819 = add i32 %stack.offset.815, %local.sum.selected.818
  %stack.offset.820 = add i32 0, %local.source.extent.788
  %stack.offset.821 = add i32 %stack.offset.819, %stack.offset.820
  %stack.offset.822 = add i32 %context.value.40, %stack.offset.821
  %cursor.status.823 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.822)
  %cursor.ok.824 = icmp eq i32 %cursor.status.823, 0
  br i1 %cursor.ok.824, label %cursor.continue.825, label %frame.failure.0
cursor.continue.825:
  %step.status.826 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %helper.ok.827 = icmp eq i32 %step.status.826, 0
  br i1 %helper.ok.827, label %helper.continue.828, label %frame.failure.0
helper.continue.828:
  %local.is.active.829 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.830 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.831 = select i1 %local.is.active.829, i32 %local.sum.extent.830, i32 0
  %stack.offset.832 = add i32 0, %local.sum.selected.831
  %local.is.active.833 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.834 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.835 = select i1 %local.is.active.833, i32 %local.sum.extent.834, i32 0
  %stack.offset.836 = add i32 %stack.offset.832, %local.sum.selected.835
  %local.is.active.837 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.838 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.839 = select i1 %local.is.active.837, i32 %local.sum.extent.838, i32 0
  %stack.offset.840 = add i32 %stack.offset.836, %local.sum.selected.839
  %local.is.active.841 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.842 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.843 = select i1 %local.is.active.841, i32 %local.sum.extent.842, i32 0
  %stack.offset.844 = add i32 %stack.offset.840, %local.sum.selected.843
  %local.is.active.845 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.846 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.847 = select i1 %local.is.active.845, i32 %local.sum.extent.846, i32 0
  %stack.offset.848 = add i32 %stack.offset.844, %local.sum.selected.847
  %stack.offset.849 = add i32 %stack.offset.848, 0
  %stack.offset.850 = add i32 %context.value.40, %stack.offset.849
  %field.location.851 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.852 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.850, i32 %local.source.extent.788, i32 0, i32 33, ptr %field.location.851)
  %helper.ok.853 = icmp eq i32 %field.location.status.852, 0
  br i1 %helper.ok.853, label %helper.continue.854, label %frame.failure.0
helper.continue.854:
  %field.offset.pointer.855 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.851, i32 0, i32 0
  %field.offset.856 = load i32, ptr %field.offset.pointer.855, align 4
  %field.payload.pointer.857 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.851, i32 0, i32 1
  %field.payload.858 = load i32, ptr %field.payload.pointer.857, align 4
  %field.extent.pointer.859 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.851, i32 0, i32 2
  %field.extent.860 = load i32, ptr %field.extent.pointer.859, align 4
  %stack.offset.861 = add i32 %stack.offset.850, %field.extent.860
  %context.field.862 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.863 = load i32, ptr %context.field.862, align 4
  %field.result.grows.864 = icmp ugt i32 %stack.offset.861, %context.value.863
  br i1 %field.result.grows.864, label %field.result.reserve.865, label %field.result.existing.866
field.result.reserve.865:
  %reserve.status.868 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.861, i32 34)
  %reserve.ok.869 = icmp eq i32 %reserve.status.868, 0
  br i1 %reserve.ok.869, label %reserve.continue.870, label %frame.failure.0
reserve.continue.870:
  br label %field.result.ready.867
field.result.existing.866:
  br label %field.result.ready.867
field.result.ready.867:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.850, i32 %field.offset.856, i32 %field.extent.860, i32 %field.payload.858, i32 9, i32 7)
  %context.field.871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.872 = load i32, ptr %context.field.871, align 4
  %runtime.ok.873 = icmp eq i32 %context.value.872, 0
  br i1 %runtime.ok.873, label %runtime.continue.874, label %frame.failure.0
runtime.continue.874:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.861, i32 0, i32 0, i32 0)
  %context.field.875 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.876 = load i32, ptr %context.field.875, align 4
  %runtime.ok.877 = icmp eq i32 %context.value.876, 0
  br i1 %runtime.ok.877, label %runtime.continue.878, label %frame.failure.0
runtime.continue.878:
  %stack.sub.879 = sub i32 %field.payload.858, %local.source.payload.789
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.879, i32 0)
  %context.field.880 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.881 = load i32, ptr %context.field.880, align 4
  %runtime.ok.882 = icmp eq i32 %context.value.881, 0
  br i1 %runtime.ok.882, label %runtime.continue.883, label %frame.failure.0
runtime.continue.883:
  %local.is.active.884 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.885 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.886 = select i1 %local.is.active.884, i32 %local.sum.extent.885, i32 0
  %stack.offset.887 = add i32 0, %local.sum.selected.886
  %local.is.active.888 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.889 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.890 = select i1 %local.is.active.888, i32 %local.sum.extent.889, i32 0
  %stack.offset.891 = add i32 %stack.offset.887, %local.sum.selected.890
  %local.is.active.892 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.893 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.894 = select i1 %local.is.active.892, i32 %local.sum.extent.893, i32 0
  %stack.offset.895 = add i32 %stack.offset.891, %local.sum.selected.894
  %local.is.active.896 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.897 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.898 = select i1 %local.is.active.896, i32 %local.sum.extent.897, i32 0
  %stack.offset.899 = add i32 %stack.offset.895, %local.sum.selected.898
  %local.is.active.900 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.901 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.902 = select i1 %local.is.active.900, i32 %local.sum.extent.901, i32 0
  %stack.offset.903 = add i32 %stack.offset.899, %local.sum.selected.902
  %stack.offset.904 = add i32 0, %field.extent.860
  %stack.offset.905 = add i32 %stack.offset.903, %stack.offset.904
  %stack.offset.906 = add i32 %context.value.40, %stack.offset.905
  %cursor.status.907 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.906)
  %cursor.ok.908 = icmp eq i32 %cursor.status.907, 0
  br i1 %cursor.ok.908, label %cursor.continue.909, label %frame.failure.0
cursor.continue.909:
  %step.status.910 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.911 = icmp eq i32 %step.status.910, 0
  br i1 %helper.ok.911, label %helper.continue.912, label %frame.failure.0
helper.continue.912:
  %local.is.active.913 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.914 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.915 = select i1 %local.is.active.913, i32 %local.sum.extent.914, i32 0
  %stack.offset.916 = add i32 0, %local.sum.selected.915
  %local.is.active.917 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.918 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.919 = select i1 %local.is.active.917, i32 %local.sum.extent.918, i32 0
  %stack.offset.920 = add i32 %stack.offset.916, %local.sum.selected.919
  %local.is.active.921 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.922 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.923 = select i1 %local.is.active.921, i32 %local.sum.extent.922, i32 0
  %stack.offset.924 = add i32 %stack.offset.920, %local.sum.selected.923
  %local.is.active.925 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.926 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.927 = select i1 %local.is.active.925, i32 %local.sum.extent.926, i32 0
  %stack.offset.928 = add i32 %stack.offset.924, %local.sum.selected.927
  %local.is.active.929 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.930 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.931 = select i1 %local.is.active.929, i32 %local.sum.extent.930, i32 0
  %stack.offset.932 = add i32 %stack.offset.928, %local.sum.selected.931
  %stack.offset.933 = add i32 %stack.offset.932, 0
  %stack.offset.934 = add i32 %context.value.40, %stack.offset.933
  %field.location.935 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.936 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.934, i32 %field.extent.860, i32 0, i32 36, ptr %field.location.935)
  %helper.ok.937 = icmp eq i32 %field.location.status.936, 0
  br i1 %helper.ok.937, label %helper.continue.938, label %frame.failure.0
helper.continue.938:
  %field.offset.pointer.939 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.935, i32 0, i32 0
  %field.offset.940 = load i32, ptr %field.offset.pointer.939, align 4
  %field.payload.pointer.941 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.935, i32 0, i32 1
  %field.payload.942 = load i32, ptr %field.payload.pointer.941, align 4
  %field.extent.pointer.943 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.935, i32 0, i32 2
  %field.extent.944 = load i32, ptr %field.extent.pointer.943, align 4
  %stack.offset.945 = add i32 %stack.offset.934, %field.extent.944
  %context.field.946 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.947 = load i32, ptr %context.field.946, align 4
  %field.result.grows.948 = icmp ugt i32 %stack.offset.945, %context.value.947
  br i1 %field.result.grows.948, label %field.result.reserve.949, label %field.result.existing.950
field.result.reserve.949:
  %reserve.status.952 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.945, i32 37)
  %reserve.ok.953 = icmp eq i32 %reserve.status.952, 0
  br i1 %reserve.ok.953, label %reserve.continue.954, label %frame.failure.0
reserve.continue.954:
  br label %field.result.ready.951
field.result.existing.950:
  br label %field.result.ready.951
field.result.ready.951:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.934, i32 %field.offset.940, i32 %field.extent.944, i32 %field.payload.942, i32 12, i32 7)
  %context.field.955 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.956 = load i32, ptr %context.field.955, align 4
  %runtime.ok.957 = icmp eq i32 %context.value.956, 0
  br i1 %runtime.ok.957, label %runtime.continue.958, label %frame.failure.0
runtime.continue.958:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.945, i32 0, i32 0, i32 0)
  %context.field.959 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.960 = load i32, ptr %context.field.959, align 4
  %runtime.ok.961 = icmp eq i32 %context.value.960, 0
  br i1 %runtime.ok.961, label %runtime.continue.962, label %frame.failure.0
runtime.continue.962:
  %stack.sub.963 = sub i32 %field.payload.942, %field.payload.858
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.963, i32 0)
  %context.field.964 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.965 = load i32, ptr %context.field.964, align 4
  %runtime.ok.966 = icmp eq i32 %context.value.965, 0
  br i1 %runtime.ok.966, label %runtime.continue.967, label %frame.failure.0
runtime.continue.967:
  %local.is.active.968 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.969 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.970 = select i1 %local.is.active.968, i32 %local.sum.extent.969, i32 0
  %stack.offset.971 = add i32 0, %local.sum.selected.970
  %local.is.active.972 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.973 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.974 = select i1 %local.is.active.972, i32 %local.sum.extent.973, i32 0
  %stack.offset.975 = add i32 %stack.offset.971, %local.sum.selected.974
  %local.is.active.976 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.977 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.978 = select i1 %local.is.active.976, i32 %local.sum.extent.977, i32 0
  %stack.offset.979 = add i32 %stack.offset.975, %local.sum.selected.978
  %local.is.active.980 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.981 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.982 = select i1 %local.is.active.980, i32 %local.sum.extent.981, i32 0
  %stack.offset.983 = add i32 %stack.offset.979, %local.sum.selected.982
  %local.is.active.984 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.985 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.986 = select i1 %local.is.active.984, i32 %local.sum.extent.985, i32 0
  %stack.offset.987 = add i32 %stack.offset.983, %local.sum.selected.986
  %stack.offset.988 = add i32 0, %field.extent.944
  %stack.offset.989 = add i32 %stack.offset.987, %stack.offset.988
  %stack.offset.990 = add i32 %context.value.40, %stack.offset.989
  %cursor.status.991 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.990)
  %cursor.ok.992 = icmp eq i32 %cursor.status.991, 0
  br i1 %cursor.ok.992, label %cursor.continue.993, label %frame.failure.0
cursor.continue.993:
  %step.status.994 = call i32 @al_owning_charge_step(ptr %ctx, i32 38)
  %helper.ok.995 = icmp eq i32 %step.status.994, 0
  br i1 %helper.ok.995, label %helper.continue.996, label %frame.failure.0
helper.continue.996:
  %local.is.active.997 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.998 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.999 = select i1 %local.is.active.997, i32 %local.sum.extent.998, i32 0
  %stack.offset.1000 = add i32 0, %local.sum.selected.999
  %local.is.active.1001 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1002 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1003 = select i1 %local.is.active.1001, i32 %local.sum.extent.1002, i32 0
  %stack.offset.1004 = add i32 %stack.offset.1000, %local.sum.selected.1003
  %local.is.active.1005 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1006 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1007 = select i1 %local.is.active.1005, i32 %local.sum.extent.1006, i32 0
  %stack.offset.1008 = add i32 %stack.offset.1004, %local.sum.selected.1007
  %local.is.active.1009 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1010 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1011 = select i1 %local.is.active.1009, i32 %local.sum.extent.1010, i32 0
  %stack.offset.1012 = add i32 %stack.offset.1008, %local.sum.selected.1011
  %local.is.active.1013 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1014 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1015 = select i1 %local.is.active.1013, i32 %local.sum.extent.1014, i32 0
  %stack.offset.1016 = add i32 %stack.offset.1012, %local.sum.selected.1015
  %stack.offset.1017 = add i32 %stack.offset.1016, 0
  %stack.offset.1018 = add i32 %context.value.40, %stack.offset.1017
  %string.length.units.1019 = alloca i32, align 4
  %string.length.status.1020 = call i32 @al_owning_string_length(ptr %ctx, i32 %stack.offset.1018, i32 %field.extent.944, i32 39, ptr %string.length.units.1019)
  %helper.ok.1021 = icmp eq i32 %string.length.status.1020, 0
  br i1 %helper.ok.1021, label %helper.continue.1022, label %frame.failure.0
helper.continue.1022:
  %string.length.value.1023 = load i32, ptr %string.length.units.1019, align 4
  %string.length.int.1024 = zext i32 %string.length.value.1023 to i64
  %context.field.1025 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1026 = load i32, ptr %context.field.1025, align 4
  %stack.sub.1027 = sub i32 %context.value.1026, %field.extent.944
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.1027, i32 %field.extent.944, i32 %field.payload.942, i32 12)
  %context.field.1028 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1029 = load i32, ptr %context.field.1028, align 4
  %runtime.ok.1030 = icmp eq i32 %context.value.1029, 0
  br i1 %runtime.ok.1030, label %runtime.continue.1031, label %frame.failure.0
runtime.continue.1031:
  %context.field.1032 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1033 = load i32, ptr %context.field.1032, align 4
  %stack.offset.1034 = add i32 %context.value.1033, 8
  %reserve.status.1035 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1034, i32 40)
  %reserve.ok.1036 = icmp eq i32 %reserve.status.1035, 0
  br i1 %reserve.ok.1036, label %reserve.continue.1037, label %frame.failure.0
reserve.continue.1037:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1033, i64 %string.length.int.1024, i32 1)
  %context.field.1038 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1039 = load i32, ptr %context.field.1038, align 4
  %runtime.ok.1040 = icmp eq i32 %context.value.1039, 0
  br i1 %runtime.ok.1040, label %runtime.continue.1041, label %frame.failure.0
runtime.continue.1041:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1042 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1043 = load i32, ptr %context.field.1042, align 4
  %runtime.ok.1044 = icmp eq i32 %context.value.1043, 0
  br i1 %runtime.ok.1044, label %runtime.continue.1045, label %frame.failure.0
runtime.continue.1045:
  %local.is.active.1046 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1047 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1048 = select i1 %local.is.active.1046, i32 %local.sum.extent.1047, i32 0
  %stack.offset.1049 = add i32 0, %local.sum.selected.1048
  %local.is.active.1050 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1051 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1052 = select i1 %local.is.active.1050, i32 %local.sum.extent.1051, i32 0
  %stack.offset.1053 = add i32 %stack.offset.1049, %local.sum.selected.1052
  %local.is.active.1054 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1055 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1056 = select i1 %local.is.active.1054, i32 %local.sum.extent.1055, i32 0
  %stack.offset.1057 = add i32 %stack.offset.1053, %local.sum.selected.1056
  %local.is.active.1058 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1059 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1060 = select i1 %local.is.active.1058, i32 %local.sum.extent.1059, i32 0
  %stack.offset.1061 = add i32 %stack.offset.1057, %local.sum.selected.1060
  %local.is.active.1062 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1063 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1064 = select i1 %local.is.active.1062, i32 %local.sum.extent.1063, i32 0
  %stack.offset.1065 = add i32 %stack.offset.1061, %local.sum.selected.1064
  %stack.offset.1066 = add i32 0, 8
  %stack.offset.1067 = add i32 %stack.offset.1065, %stack.offset.1066
  %stack.offset.1068 = add i32 %context.value.40, %stack.offset.1067
  %cursor.status.1069 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1068)
  %cursor.ok.1070 = icmp eq i32 %cursor.status.1069, 0
  br i1 %cursor.ok.1070, label %cursor.continue.1071, label %frame.failure.0
cursor.continue.1071:
  %step.status.1072 = call i32 @al_owning_charge_step(ptr %ctx, i32 41)
  %helper.ok.1073 = icmp eq i32 %step.status.1072, 0
  br i1 %helper.ok.1073, label %helper.continue.1074, label %frame.failure.0
helper.continue.1074:
  %local.is.active.1075 = load i1, ptr %local.active.23, align 1
  %local.previous.extent.1076 = load i32, ptr %local.extent.25, align 4
  %local.previous.payload.1077 = load i32, ptr %local.payload.26, align 4
  %local.old.extent.1078 = select i1 %local.is.active.1075, i32 %local.previous.extent.1076, i32 0
  %local.old.payload.1079 = select i1 %local.is.active.1075, i32 %local.previous.payload.1077, i32 0
  %local.is.active.1080 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1081 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1082 = select i1 %local.is.active.1080, i32 %local.sum.extent.1081, i32 0
  %stack.offset.1083 = add i32 0, %local.sum.selected.1082
  %local.is.active.1084 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1085 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1086 = select i1 %local.is.active.1084, i32 %local.sum.extent.1085, i32 0
  %stack.offset.1087 = add i32 %stack.offset.1083, %local.sum.selected.1086
  %local.is.active.1088 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1089 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1090 = select i1 %local.is.active.1088, i32 %local.sum.extent.1089, i32 0
  %stack.offset.1091 = add i32 %stack.offset.1087, %local.sum.selected.1090
  %local.is.active.1092 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1093 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1094 = select i1 %local.is.active.1092, i32 %local.sum.extent.1093, i32 0
  %stack.offset.1095 = add i32 %stack.offset.1091, %local.sum.selected.1094
  %stack.offset.1096 = add i32 %context.value.40, %stack.offset.1095
  %stack.offset.1097 = add i32 %stack.offset.1096, %local.old.extent.1078
  %context.field.1098 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1099 = load i32, ptr %context.field.1098, align 4
  %stack.sub.1100 = sub i32 %context.value.1099, %stack.offset.1097
  %stack.sub.1101 = sub i32 %context.value.1099, %local.old.extent.1078
  %stack.offset.1102 = add i32 %stack.sub.1101, 8
  %local.grows.1103 = icmp ugt i32 8, %local.old.extent.1078
  br i1 %local.grows.1103, label %local.grow.1104, label %local.fixed.1105
local.grow.1104:
  %reserve.status.1107 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1102, i32 42)
  %reserve.ok.1108 = icmp eq i32 %reserve.status.1107, 0
  br i1 %reserve.ok.1108, label %reserve.continue.1109, label %frame.failure.0
reserve.continue.1109:
  %stack.sub.1110 = sub i32 8, %local.old.extent.1078
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.1110)
  %context.field.1111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1112 = load i32, ptr %context.field.1111, align 4
  %runtime.ok.1113 = icmp eq i32 %context.value.1112, 0
  br i1 %runtime.ok.1113, label %runtime.continue.1114, label %frame.failure.0
runtime.continue.1114:
  br label %local.layout.ready.1106
local.fixed.1105:
  br label %local.layout.ready.1106
local.layout.ready.1106:
  %stack.offset.1115 = add i32 %stack.offset.1096, 8
  %stack.offset.1116 = add i32 0, 8
  %stack.offset.1117 = add i32 0, %stack.offset.1116
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1115, i32 %stack.offset.1097, i32 %stack.sub.1100, i32 %stack.offset.1117, i32 0, i32 14)
  %context.field.1118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1119 = load i32, ptr %context.field.1118, align 4
  %runtime.ok.1120 = icmp eq i32 %context.value.1119, 0
  br i1 %runtime.ok.1120, label %runtime.continue.1121, label %frame.failure.0
runtime.continue.1121:
  %stack.sub.1122 = sub i32 %context.value.1099, 8
  %stack.sub.1123 = sub i32 %stack.sub.1122, %local.old.extent.1078
  %stack.offset.1124 = add i32 %stack.sub.1123, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1096, i32 %stack.offset.1124, i32 8, i32 8, i32 1, i32 4)
  %context.field.1125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1126 = load i32, ptr %context.field.1125, align 4
  %runtime.ok.1127 = icmp eq i32 %context.value.1126, 0
  br i1 %runtime.ok.1127, label %runtime.continue.1128, label %frame.failure.0
runtime.continue.1128:
  %stack.sub.1129 = sub i32 %context.value.1099, %local.old.extent.1078
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1129, i32 0, i32 0, i32 0)
  %context.field.1130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1131 = load i32, ptr %context.field.1130, align 4
  %runtime.ok.1132 = icmp eq i32 %context.value.1131, 0
  br i1 %runtime.ok.1132, label %runtime.continue.1133, label %frame.failure.0
runtime.continue.1133:
  %local.shrinks.1134 = icmp ult i32 8, %local.old.extent.1078
  br i1 %local.shrinks.1134, label %local.shrink.1135, label %local.counts.ready.1136
local.shrink.1135:
  %stack.sub.1137 = sub i32 %local.old.extent.1078, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1137)
  %context.field.1138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1139 = load i32, ptr %context.field.1138, align 4
  %runtime.ok.1140 = icmp eq i32 %context.value.1139, 0
  br i1 %runtime.ok.1140, label %runtime.continue.1141, label %frame.failure.0
runtime.continue.1141:
  br label %local.counts.ready.1136
local.counts.ready.1136:
  %local.payload.delta.1142 = sub i32 8, %local.old.payload.1079
  %stack.sub.1143 = sub i32 0, %local.old.payload.1079
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1143, i32 %local.payload.delta.1142)
  %context.field.1144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1145 = load i32, ptr %context.field.1144, align 4
  %runtime.ok.1146 = icmp eq i32 %context.value.1145, 0
  br i1 %runtime.ok.1146, label %runtime.continue.1147, label %frame.failure.0
runtime.continue.1147:
  store i1 true, ptr %local.active.23, align 1
  store i32 %stack.offset.1096, ptr %local.offset.24, align 4
  store i32 8, ptr %local.extent.25, align 4
  store i32 8, ptr %local.payload.26, align 4
  store i32 1, ptr %local.type.27, align 4
  %local.is.active.1148 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1149 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1150 = select i1 %local.is.active.1148, i32 %local.sum.extent.1149, i32 0
  %stack.offset.1151 = add i32 0, %local.sum.selected.1150
  %local.is.active.1152 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1153 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1154 = select i1 %local.is.active.1152, i32 %local.sum.extent.1153, i32 0
  %stack.offset.1155 = add i32 %stack.offset.1151, %local.sum.selected.1154
  %local.is.active.1156 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1157 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1158 = select i1 %local.is.active.1156, i32 %local.sum.extent.1157, i32 0
  %stack.offset.1159 = add i32 %stack.offset.1155, %local.sum.selected.1158
  %local.is.active.1160 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1161 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1162 = select i1 %local.is.active.1160, i32 %local.sum.extent.1161, i32 0
  %stack.offset.1163 = add i32 %stack.offset.1159, %local.sum.selected.1162
  %local.is.active.1164 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1165 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1166 = select i1 %local.is.active.1164, i32 %local.sum.extent.1165, i32 0
  %stack.offset.1167 = add i32 %stack.offset.1163, %local.sum.selected.1166
  %stack.offset.1168 = add i32 %stack.offset.1167, 0
  %stack.offset.1169 = add i32 %context.value.40, %stack.offset.1168
  %cursor.status.1170 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1169)
  %cursor.ok.1171 = icmp eq i32 %cursor.status.1170, 0
  br i1 %cursor.ok.1171, label %cursor.continue.1172, label %frame.failure.0
cursor.continue.1172:
  %step.status.1173 = call i32 @al_owning_charge_step(ptr %ctx, i32 43)
  %helper.ok.1174 = icmp eq i32 %step.status.1173, 0
  br i1 %helper.ok.1174, label %helper.continue.1175, label %frame.failure.0
helper.continue.1175:
  %local.source.offset.1176 = load i32, ptr %local.offset.19, align 4
  %local.source.extent.1177 = load i32, ptr %local.extent.20, align 4
  %local.source.payload.1178 = load i32, ptr %local.payload.21, align 4
  %context.field.1179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1180 = load i32, ptr %context.field.1179, align 4
  %stack.offset.1181 = add i32 %context.value.1180, %local.source.extent.1177
  %reserve.status.1182 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1181, i32 44)
  %reserve.ok.1183 = icmp eq i32 %reserve.status.1182, 0
  br i1 %reserve.ok.1183, label %reserve.continue.1184, label %frame.failure.0
reserve.continue.1184:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1180, i32 %local.source.offset.1176, i32 %local.source.extent.1177, i32 %local.source.payload.1178, i32 8)
  %context.field.1185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1186 = load i32, ptr %context.field.1185, align 4
  %runtime.ok.1187 = icmp eq i32 %context.value.1186, 0
  br i1 %runtime.ok.1187, label %runtime.continue.1188, label %frame.failure.0
runtime.continue.1188:
  %local.is.active.1189 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1190 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1191 = select i1 %local.is.active.1189, i32 %local.sum.extent.1190, i32 0
  %stack.offset.1192 = add i32 0, %local.sum.selected.1191
  %local.is.active.1193 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1194 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1195 = select i1 %local.is.active.1193, i32 %local.sum.extent.1194, i32 0
  %stack.offset.1196 = add i32 %stack.offset.1192, %local.sum.selected.1195
  %local.is.active.1197 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1198 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1199 = select i1 %local.is.active.1197, i32 %local.sum.extent.1198, i32 0
  %stack.offset.1200 = add i32 %stack.offset.1196, %local.sum.selected.1199
  %local.is.active.1201 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1202 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1203 = select i1 %local.is.active.1201, i32 %local.sum.extent.1202, i32 0
  %stack.offset.1204 = add i32 %stack.offset.1200, %local.sum.selected.1203
  %local.is.active.1205 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1206 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1207 = select i1 %local.is.active.1205, i32 %local.sum.extent.1206, i32 0
  %stack.offset.1208 = add i32 %stack.offset.1204, %local.sum.selected.1207
  %stack.offset.1209 = add i32 0, %local.source.extent.1177
  %stack.offset.1210 = add i32 %stack.offset.1208, %stack.offset.1209
  %stack.offset.1211 = add i32 %context.value.40, %stack.offset.1210
  %cursor.status.1212 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1211)
  %cursor.ok.1213 = icmp eq i32 %cursor.status.1212, 0
  br i1 %cursor.ok.1213, label %cursor.continue.1214, label %frame.failure.0
cursor.continue.1214:
  %step.status.1215 = call i32 @al_owning_charge_step(ptr %ctx, i32 45)
  %helper.ok.1216 = icmp eq i32 %step.status.1215, 0
  br i1 %helper.ok.1216, label %helper.continue.1217, label %frame.failure.0
helper.continue.1217:
  %local.source.offset.1218 = load i32, ptr %local.offset.24, align 4
  %local.source.extent.1219 = load i32, ptr %local.extent.25, align 4
  %local.source.payload.1220 = load i32, ptr %local.payload.26, align 4
  %context.field.1221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1222 = load i32, ptr %context.field.1221, align 4
  %stack.offset.1223 = add i32 %context.value.1222, %local.source.extent.1219
  %reserve.status.1224 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1223, i32 46)
  %reserve.ok.1225 = icmp eq i32 %reserve.status.1224, 0
  br i1 %reserve.ok.1225, label %reserve.continue.1226, label %frame.failure.0
reserve.continue.1226:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1222, i32 %local.source.offset.1218, i32 %local.source.extent.1219, i32 %local.source.payload.1220, i32 1)
  %context.field.1227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1228 = load i32, ptr %context.field.1227, align 4
  %runtime.ok.1229 = icmp eq i32 %context.value.1228, 0
  br i1 %runtime.ok.1229, label %runtime.continue.1230, label %frame.failure.0
runtime.continue.1230:
  %local.is.active.1231 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1232 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1233 = select i1 %local.is.active.1231, i32 %local.sum.extent.1232, i32 0
  %stack.offset.1234 = add i32 0, %local.sum.selected.1233
  %local.is.active.1235 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1236 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1237 = select i1 %local.is.active.1235, i32 %local.sum.extent.1236, i32 0
  %stack.offset.1238 = add i32 %stack.offset.1234, %local.sum.selected.1237
  %local.is.active.1239 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1240 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1241 = select i1 %local.is.active.1239, i32 %local.sum.extent.1240, i32 0
  %stack.offset.1242 = add i32 %stack.offset.1238, %local.sum.selected.1241
  %local.is.active.1243 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1244 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1245 = select i1 %local.is.active.1243, i32 %local.sum.extent.1244, i32 0
  %stack.offset.1246 = add i32 %stack.offset.1242, %local.sum.selected.1245
  %local.is.active.1247 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1248 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1249 = select i1 %local.is.active.1247, i32 %local.sum.extent.1248, i32 0
  %stack.offset.1250 = add i32 %stack.offset.1246, %local.sum.selected.1249
  %stack.offset.1251 = add i32 0, %local.source.extent.1177
  %stack.offset.1252 = add i32 %stack.offset.1251, %local.source.extent.1219
  %stack.offset.1253 = add i32 %stack.offset.1250, %stack.offset.1252
  %stack.offset.1254 = add i32 %context.value.40, %stack.offset.1253
  %cursor.status.1255 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1254)
  %cursor.ok.1256 = icmp eq i32 %cursor.status.1255, 0
  br i1 %cursor.ok.1256, label %cursor.continue.1257, label %frame.failure.0
cursor.continue.1257:
  %local.is.active.1258 = load i1, ptr %local.active.23, align 1
  br i1 %local.is.active.1258, label %local.remove.1259, label %local.keep.1260
local.keep.1260:
  br label %local.removed.1261
local.remove.1259:
  %local.remove.offset.1262 = load i32, ptr %local.offset.24, align 4
  %local.remove.extent.1263 = load i32, ptr %local.extent.25, align 4
  %local.remove.payload.1264 = load i32, ptr %local.payload.26, align 4
  %local.remove.type.1265 = load i32, ptr %local.type.27, align 4
  %stack.offset.1266 = add i32 %local.remove.offset.1262, %local.remove.extent.1263
  %context.field.1267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1268 = load i32, ptr %context.field.1267, align 4
  %stack.sub.1269 = sub i32 %context.value.1268, %stack.offset.1266
  %stack.offset.1270 = add i32 0, %local.source.payload.1178
  %stack.offset.1271 = add i32 %stack.offset.1270, %local.source.payload.1220
  %stack.offset.1272 = add i32 0, %stack.offset.1271
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1262, i32 %stack.offset.1266, i32 %stack.sub.1269, i32 %stack.offset.1272, i32 0, i32 14)
  %context.field.1273 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1274 = load i32, ptr %context.field.1273, align 4
  %runtime.ok.1275 = icmp eq i32 %context.value.1274, 0
  br i1 %runtime.ok.1275, label %runtime.continue.1276, label %frame.failure.0
runtime.continue.1276:
  %stack.sub.1277 = sub i32 %context.value.1268, %local.remove.extent.1263
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1277, i32 0, i32 0, i32 0)
  %context.field.1278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1279 = load i32, ptr %context.field.1278, align 4
  %runtime.ok.1280 = icmp eq i32 %context.value.1279, 0
  br i1 %runtime.ok.1280, label %runtime.continue.1281, label %frame.failure.0
runtime.continue.1281:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1265, i32 %local.remove.offset.1262, i32 %local.remove.extent.1263, i32 %local.remove.payload.1264, i32 0, i32 0)
  %context.field.1282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1283 = load i32, ptr %context.field.1282, align 4
  %runtime.ok.1284 = icmp eq i32 %context.value.1283, 0
  br i1 %runtime.ok.1284, label %runtime.continue.1285, label %frame.failure.0
runtime.continue.1285:
  %stack.sub.1286 = sub i32 0, %local.remove.payload.1264
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1286, i32 %stack.sub.1286)
  %context.field.1287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1288 = load i32, ptr %context.field.1287, align 4
  %runtime.ok.1289 = icmp eq i32 %context.value.1288, 0
  br i1 %runtime.ok.1289, label %runtime.continue.1290, label %frame.failure.0
runtime.continue.1290:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1263)
  %context.field.1291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1292 = load i32, ptr %context.field.1291, align 4
  %runtime.ok.1293 = icmp eq i32 %context.value.1292, 0
  br i1 %runtime.ok.1293, label %runtime.continue.1294, label %frame.failure.0
runtime.continue.1294:
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  br label %local.removed.1261
local.removed.1261:
  %local.is.active.1295 = load i1, ptr %local.active.18, align 1
  br i1 %local.is.active.1295, label %local.remove.1296, label %local.keep.1297
local.keep.1297:
  br label %local.removed.1298
local.remove.1296:
  %local.remove.offset.1299 = load i32, ptr %local.offset.19, align 4
  %local.remove.extent.1300 = load i32, ptr %local.extent.20, align 4
  %local.remove.payload.1301 = load i32, ptr %local.payload.21, align 4
  %local.remove.type.1302 = load i32, ptr %local.type.22, align 4
  %stack.offset.1303 = add i32 %local.remove.offset.1299, %local.remove.extent.1300
  %context.field.1304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1305 = load i32, ptr %context.field.1304, align 4
  %stack.sub.1306 = sub i32 %context.value.1305, %stack.offset.1303
  %local.is.active.1307 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1308 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1309 = select i1 %local.is.active.1307, i32 %local.suffix.payload.1308, i32 0
  %stack.offset.1310 = add i32 0, %local.suffix.selected.1309
  %stack.offset.1311 = add i32 0, %local.source.payload.1178
  %stack.offset.1312 = add i32 %stack.offset.1311, %local.source.payload.1220
  %stack.offset.1313 = add i32 %stack.offset.1310, %stack.offset.1312
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1299, i32 %stack.offset.1303, i32 %stack.sub.1306, i32 %stack.offset.1313, i32 0, i32 14)
  %context.field.1314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1315 = load i32, ptr %context.field.1314, align 4
  %runtime.ok.1316 = icmp eq i32 %context.value.1315, 0
  br i1 %runtime.ok.1316, label %runtime.continue.1317, label %frame.failure.0
runtime.continue.1317:
  %stack.sub.1318 = sub i32 %context.value.1305, %local.remove.extent.1300
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1318, i32 0, i32 0, i32 0)
  %context.field.1319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1320 = load i32, ptr %context.field.1319, align 4
  %runtime.ok.1321 = icmp eq i32 %context.value.1320, 0
  br i1 %runtime.ok.1321, label %runtime.continue.1322, label %frame.failure.0
runtime.continue.1322:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1302, i32 %local.remove.offset.1299, i32 %local.remove.extent.1300, i32 %local.remove.payload.1301, i32 0, i32 0)
  %context.field.1323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1324 = load i32, ptr %context.field.1323, align 4
  %runtime.ok.1325 = icmp eq i32 %context.value.1324, 0
  br i1 %runtime.ok.1325, label %runtime.continue.1326, label %frame.failure.0
runtime.continue.1326:
  %stack.sub.1327 = sub i32 0, %local.remove.payload.1301
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1327, i32 %stack.sub.1327)
  %context.field.1328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1329 = load i32, ptr %context.field.1328, align 4
  %runtime.ok.1330 = icmp eq i32 %context.value.1329, 0
  br i1 %runtime.ok.1330, label %runtime.continue.1331, label %frame.failure.0
runtime.continue.1331:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1300)
  %context.field.1332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1333 = load i32, ptr %context.field.1332, align 4
  %runtime.ok.1334 = icmp eq i32 %context.value.1333, 0
  br i1 %runtime.ok.1334, label %runtime.continue.1335, label %frame.failure.0
runtime.continue.1335:
  %local.is.active.1336 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1337 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1338 = sub i32 %local.later.offset.1337, %local.remove.extent.1300
  %local.later.offset.selected.1339 = select i1 %local.is.active.1336, i32 %stack.sub.1338, i32 %local.later.offset.1337
  store i32 %local.later.offset.selected.1339, ptr %local.offset.24, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  br label %local.removed.1298
local.removed.1298:
  %local.is.active.1340 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.1340, label %local.remove.1341, label %local.keep.1342
local.keep.1342:
  br label %local.removed.1343
local.remove.1341:
  %local.remove.offset.1344 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.1345 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.1346 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.1347 = load i32, ptr %local.type.17, align 4
  %stack.offset.1348 = add i32 %local.remove.offset.1344, %local.remove.extent.1345
  %context.field.1349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1350 = load i32, ptr %context.field.1349, align 4
  %stack.sub.1351 = sub i32 %context.value.1350, %stack.offset.1348
  %local.is.active.1352 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1353 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1354 = select i1 %local.is.active.1352, i32 %local.suffix.payload.1353, i32 0
  %stack.offset.1355 = add i32 0, %local.suffix.selected.1354
  %local.is.active.1356 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1357 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1358 = select i1 %local.is.active.1356, i32 %local.suffix.payload.1357, i32 0
  %stack.offset.1359 = add i32 %stack.offset.1355, %local.suffix.selected.1358
  %stack.offset.1360 = add i32 0, %local.source.payload.1178
  %stack.offset.1361 = add i32 %stack.offset.1360, %local.source.payload.1220
  %stack.offset.1362 = add i32 %stack.offset.1359, %stack.offset.1361
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1344, i32 %stack.offset.1348, i32 %stack.sub.1351, i32 %stack.offset.1362, i32 0, i32 14)
  %context.field.1363 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1364 = load i32, ptr %context.field.1363, align 4
  %runtime.ok.1365 = icmp eq i32 %context.value.1364, 0
  br i1 %runtime.ok.1365, label %runtime.continue.1366, label %frame.failure.0
runtime.continue.1366:
  %stack.sub.1367 = sub i32 %context.value.1350, %local.remove.extent.1345
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1367, i32 0, i32 0, i32 0)
  %context.field.1368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1369 = load i32, ptr %context.field.1368, align 4
  %runtime.ok.1370 = icmp eq i32 %context.value.1369, 0
  br i1 %runtime.ok.1370, label %runtime.continue.1371, label %frame.failure.0
runtime.continue.1371:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1347, i32 %local.remove.offset.1344, i32 %local.remove.extent.1345, i32 %local.remove.payload.1346, i32 0, i32 0)
  %context.field.1372 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1373 = load i32, ptr %context.field.1372, align 4
  %runtime.ok.1374 = icmp eq i32 %context.value.1373, 0
  br i1 %runtime.ok.1374, label %runtime.continue.1375, label %frame.failure.0
runtime.continue.1375:
  %stack.sub.1376 = sub i32 0, %local.remove.payload.1346
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1376, i32 %stack.sub.1376)
  %context.field.1377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1378 = load i32, ptr %context.field.1377, align 4
  %runtime.ok.1379 = icmp eq i32 %context.value.1378, 0
  br i1 %runtime.ok.1379, label %runtime.continue.1380, label %frame.failure.0
runtime.continue.1380:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1345)
  %context.field.1381 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1382 = load i32, ptr %context.field.1381, align 4
  %runtime.ok.1383 = icmp eq i32 %context.value.1382, 0
  br i1 %runtime.ok.1383, label %runtime.continue.1384, label %frame.failure.0
runtime.continue.1384:
  %local.is.active.1385 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1386 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1387 = sub i32 %local.later.offset.1386, %local.remove.extent.1345
  %local.later.offset.selected.1388 = select i1 %local.is.active.1385, i32 %stack.sub.1387, i32 %local.later.offset.1386
  store i32 %local.later.offset.selected.1388, ptr %local.offset.19, align 4
  %local.is.active.1389 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1390 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1391 = sub i32 %local.later.offset.1390, %local.remove.extent.1345
  %local.later.offset.selected.1392 = select i1 %local.is.active.1389, i32 %stack.sub.1391, i32 %local.later.offset.1390
  store i32 %local.later.offset.selected.1392, ptr %local.offset.24, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.1343
local.removed.1343:
  %local.is.active.1393 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1393, label %local.remove.1394, label %local.keep.1395
local.keep.1395:
  br label %local.removed.1396
local.remove.1394:
  %local.remove.offset.1397 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.1398 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.1399 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.1400 = load i32, ptr %local.type.12, align 4
  %stack.offset.1401 = add i32 %local.remove.offset.1397, %local.remove.extent.1398
  %context.field.1402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1403 = load i32, ptr %context.field.1402, align 4
  %stack.sub.1404 = sub i32 %context.value.1403, %stack.offset.1401
  %local.is.active.1405 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1406 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1407 = select i1 %local.is.active.1405, i32 %local.suffix.payload.1406, i32 0
  %stack.offset.1408 = add i32 0, %local.suffix.selected.1407
  %local.is.active.1409 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1410 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1411 = select i1 %local.is.active.1409, i32 %local.suffix.payload.1410, i32 0
  %stack.offset.1412 = add i32 %stack.offset.1408, %local.suffix.selected.1411
  %local.is.active.1413 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1414 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1415 = select i1 %local.is.active.1413, i32 %local.suffix.payload.1414, i32 0
  %stack.offset.1416 = add i32 %stack.offset.1412, %local.suffix.selected.1415
  %stack.offset.1417 = add i32 0, %local.source.payload.1178
  %stack.offset.1418 = add i32 %stack.offset.1417, %local.source.payload.1220
  %stack.offset.1419 = add i32 %stack.offset.1416, %stack.offset.1418
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1397, i32 %stack.offset.1401, i32 %stack.sub.1404, i32 %stack.offset.1419, i32 0, i32 14)
  %context.field.1420 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1421 = load i32, ptr %context.field.1420, align 4
  %runtime.ok.1422 = icmp eq i32 %context.value.1421, 0
  br i1 %runtime.ok.1422, label %runtime.continue.1423, label %frame.failure.0
runtime.continue.1423:
  %stack.sub.1424 = sub i32 %context.value.1403, %local.remove.extent.1398
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1424, i32 0, i32 0, i32 0)
  %context.field.1425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1426 = load i32, ptr %context.field.1425, align 4
  %runtime.ok.1427 = icmp eq i32 %context.value.1426, 0
  br i1 %runtime.ok.1427, label %runtime.continue.1428, label %frame.failure.0
runtime.continue.1428:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1400, i32 %local.remove.offset.1397, i32 %local.remove.extent.1398, i32 %local.remove.payload.1399, i32 0, i32 0)
  %context.field.1429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1430 = load i32, ptr %context.field.1429, align 4
  %runtime.ok.1431 = icmp eq i32 %context.value.1430, 0
  br i1 %runtime.ok.1431, label %runtime.continue.1432, label %frame.failure.0
runtime.continue.1432:
  %stack.sub.1433 = sub i32 0, %local.remove.payload.1399
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1433, i32 %stack.sub.1433)
  %context.field.1434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1435 = load i32, ptr %context.field.1434, align 4
  %runtime.ok.1436 = icmp eq i32 %context.value.1435, 0
  br i1 %runtime.ok.1436, label %runtime.continue.1437, label %frame.failure.0
runtime.continue.1437:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1398)
  %context.field.1438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1439 = load i32, ptr %context.field.1438, align 4
  %runtime.ok.1440 = icmp eq i32 %context.value.1439, 0
  br i1 %runtime.ok.1440, label %runtime.continue.1441, label %frame.failure.0
runtime.continue.1441:
  %local.is.active.1442 = load i1, ptr %local.active.13, align 1
  %local.later.offset.1443 = load i32, ptr %local.offset.14, align 4
  %stack.sub.1444 = sub i32 %local.later.offset.1443, %local.remove.extent.1398
  %local.later.offset.selected.1445 = select i1 %local.is.active.1442, i32 %stack.sub.1444, i32 %local.later.offset.1443
  store i32 %local.later.offset.selected.1445, ptr %local.offset.14, align 4
  %local.is.active.1446 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1447 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1448 = sub i32 %local.later.offset.1447, %local.remove.extent.1398
  %local.later.offset.selected.1449 = select i1 %local.is.active.1446, i32 %stack.sub.1448, i32 %local.later.offset.1447
  store i32 %local.later.offset.selected.1449, ptr %local.offset.19, align 4
  %local.is.active.1450 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1451 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1452 = sub i32 %local.later.offset.1451, %local.remove.extent.1398
  %local.later.offset.selected.1453 = select i1 %local.is.active.1450, i32 %stack.sub.1452, i32 %local.later.offset.1451
  store i32 %local.later.offset.selected.1453, ptr %local.offset.24, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.1396
local.removed.1396:
  %local.is.active.1454 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.1454, label %local.remove.1455, label %local.keep.1456
local.keep.1456:
  br label %local.removed.1457
local.remove.1455:
  %local.remove.offset.1458 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.1459 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.1460 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.1461 = load i32, ptr %local.type.7, align 4
  %stack.offset.1462 = add i32 %local.remove.offset.1458, %local.remove.extent.1459
  %context.field.1463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1464 = load i32, ptr %context.field.1463, align 4
  %stack.sub.1465 = sub i32 %context.value.1464, %stack.offset.1462
  %local.is.active.1466 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.1467 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.1468 = select i1 %local.is.active.1466, i32 %local.suffix.payload.1467, i32 0
  %stack.offset.1469 = add i32 0, %local.suffix.selected.1468
  %local.is.active.1470 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1471 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1472 = select i1 %local.is.active.1470, i32 %local.suffix.payload.1471, i32 0
  %stack.offset.1473 = add i32 %stack.offset.1469, %local.suffix.selected.1472
  %local.is.active.1474 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1475 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1476 = select i1 %local.is.active.1474, i32 %local.suffix.payload.1475, i32 0
  %stack.offset.1477 = add i32 %stack.offset.1473, %local.suffix.selected.1476
  %local.is.active.1478 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1479 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1480 = select i1 %local.is.active.1478, i32 %local.suffix.payload.1479, i32 0
  %stack.offset.1481 = add i32 %stack.offset.1477, %local.suffix.selected.1480
  %stack.offset.1482 = add i32 0, %local.source.payload.1178
  %stack.offset.1483 = add i32 %stack.offset.1482, %local.source.payload.1220
  %stack.offset.1484 = add i32 %stack.offset.1481, %stack.offset.1483
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1458, i32 %stack.offset.1462, i32 %stack.sub.1465, i32 %stack.offset.1484, i32 0, i32 14)
  %context.field.1485 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1486 = load i32, ptr %context.field.1485, align 4
  %runtime.ok.1487 = icmp eq i32 %context.value.1486, 0
  br i1 %runtime.ok.1487, label %runtime.continue.1488, label %frame.failure.0
runtime.continue.1488:
  %stack.sub.1489 = sub i32 %context.value.1464, %local.remove.extent.1459
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1489, i32 0, i32 0, i32 0)
  %context.field.1490 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1491 = load i32, ptr %context.field.1490, align 4
  %runtime.ok.1492 = icmp eq i32 %context.value.1491, 0
  br i1 %runtime.ok.1492, label %runtime.continue.1493, label %frame.failure.0
runtime.continue.1493:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1461, i32 %local.remove.offset.1458, i32 %local.remove.extent.1459, i32 %local.remove.payload.1460, i32 0, i32 0)
  %context.field.1494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1495 = load i32, ptr %context.field.1494, align 4
  %runtime.ok.1496 = icmp eq i32 %context.value.1495, 0
  br i1 %runtime.ok.1496, label %runtime.continue.1497, label %frame.failure.0
runtime.continue.1497:
  %stack.sub.1498 = sub i32 0, %local.remove.payload.1460
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1498, i32 %stack.sub.1498)
  %context.field.1499 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1500 = load i32, ptr %context.field.1499, align 4
  %runtime.ok.1501 = icmp eq i32 %context.value.1500, 0
  br i1 %runtime.ok.1501, label %runtime.continue.1502, label %frame.failure.0
runtime.continue.1502:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1459)
  %context.field.1503 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1504 = load i32, ptr %context.field.1503, align 4
  %runtime.ok.1505 = icmp eq i32 %context.value.1504, 0
  br i1 %runtime.ok.1505, label %runtime.continue.1506, label %frame.failure.0
runtime.continue.1506:
  %local.is.active.1507 = load i1, ptr %local.active.8, align 1
  %local.later.offset.1508 = load i32, ptr %local.offset.9, align 4
  %stack.sub.1509 = sub i32 %local.later.offset.1508, %local.remove.extent.1459
  %local.later.offset.selected.1510 = select i1 %local.is.active.1507, i32 %stack.sub.1509, i32 %local.later.offset.1508
  store i32 %local.later.offset.selected.1510, ptr %local.offset.9, align 4
  %local.is.active.1511 = load i1, ptr %local.active.13, align 1
  %local.later.offset.1512 = load i32, ptr %local.offset.14, align 4
  %stack.sub.1513 = sub i32 %local.later.offset.1512, %local.remove.extent.1459
  %local.later.offset.selected.1514 = select i1 %local.is.active.1511, i32 %stack.sub.1513, i32 %local.later.offset.1512
  store i32 %local.later.offset.selected.1514, ptr %local.offset.14, align 4
  %local.is.active.1515 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1516 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1517 = sub i32 %local.later.offset.1516, %local.remove.extent.1459
  %local.later.offset.selected.1518 = select i1 %local.is.active.1515, i32 %stack.sub.1517, i32 %local.later.offset.1516
  store i32 %local.later.offset.selected.1518, ptr %local.offset.19, align 4
  %local.is.active.1519 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1520 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1521 = sub i32 %local.later.offset.1520, %local.remove.extent.1459
  %local.later.offset.selected.1522 = select i1 %local.is.active.1519, i32 %stack.sub.1521, i32 %local.later.offset.1520
  store i32 %local.later.offset.selected.1522, ptr %local.offset.24, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.1457
local.removed.1457:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.29, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.29, i32 0, i32 0, i32 0)
  %context.field.1523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1524 = load i32, ptr %context.field.1523, align 4
  %context.field.1525 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1526 = load i32, ptr %context.field.1525, align 4
  %context.field.1527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1528 = load i32, ptr %context.field.1527, align 4
  %stack.offset.1529 = add i32 %context.value.31, %context.value.33
  %stack.offset.1530 = add i32 %context.value.1524, %context.value.1526
  %stack.sub.1531 = sub i32 %stack.offset.1529, %stack.offset.1530
  %stack.sub.1532 = sub i32 %context.value.33, %context.value.1526
  %stack.sub.1533 = sub i32 %context.value.1528, %context.value.35
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1531, i32 %stack.sub.1532)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1533)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 3
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 3, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 47, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 47, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.extent.pointer.24 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.25 = load i32, ptr %input.extent.pointer.24, align 4
  %host.pointer.26 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.payload.pointer.27 = alloca i32, align 4
  %input.measured.extent.pointer.28 = alloca i32, align 4
  %input.measure.status.29 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.26, i32 %input.host.extent.25, i32 0, i32 48, ptr %input.payload.pointer.27, ptr %input.measured.extent.pointer.28)
  %helper.ok.30 = icmp eq i32 %input.measure.status.29, 0
  br i1 %helper.ok.30, label %helper.continue.31, label %entry.failure.0
helper.continue.31:
  %input.measured.payload.32 = load i32, ptr %input.payload.pointer.27, align 4
  %input.measured.extent.33 = load i32, ptr %input.measured.extent.pointer.28, align 4
  %input.extent.exact.34 = icmp eq i32 %input.measured.extent.33, %input.host.extent.25
  br i1 %input.extent.exact.34, label %input.extent.exact.35, label %input.extent.invalid.36
input.extent.invalid.36:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 48, i32 %input.measured.extent.33, i32 %input.host.extent.25)
  br label %entry.failure.0
input.extent.exact.35:
  %stack.offset.37 = add i32 %stack.offset.23, %input.host.extent.25
  %input.extent.pointer.38 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.39 = load i32, ptr %input.extent.pointer.38, align 4
  %host.pointer.40 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.37
  %input.payload.pointer.41 = alloca i32, align 4
  %input.measured.extent.pointer.42 = alloca i32, align 4
  %input.measure.status.43 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.40, i32 %input.host.extent.39, i32 0, i32 49, ptr %input.payload.pointer.41, ptr %input.measured.extent.pointer.42)
  %helper.ok.44 = icmp eq i32 %input.measure.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %input.measured.payload.46 = load i32, ptr %input.payload.pointer.41, align 4
  %input.measured.extent.47 = load i32, ptr %input.measured.extent.pointer.42, align 4
  %input.extent.exact.48 = icmp eq i32 %input.measured.extent.47, %input.host.extent.39
  br i1 %input.extent.exact.48, label %input.extent.exact.49, label %input.extent.invalid.50
input.extent.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 49, i32 %input.measured.extent.47, i32 %input.host.extent.39)
  br label %entry.failure.0
input.extent.exact.49:
  %stack.offset.51 = add i32 %stack.offset.37, %input.host.extent.39
  %input.total.exact.52 = icmp eq i32 %stack.offset.51, %input.bytes
  br i1 %input.total.exact.52, label %input.valid.53, label %input.invalid.54
input.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.51, i32 %input.bytes)
  br label %entry.failure.0
input.valid.53:
  %reserve.status.55 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.51, i32 50)
  %reserve.ok.56 = icmp eq i32 %reserve.status.55, 0
  br i1 %reserve.ok.56, label %reserve.continue.57, label %entry.failure.0
reserve.continue.57:
  %host.pointer.58 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.59 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.58, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 8, i32 51)
  %helper.ok.60 = icmp eq i32 %input.copy.status.59, 0
  br i1 %helper.ok.60, label %helper.continue.61, label %entry.failure.0
helper.continue.61:
  %host.pointer.62 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.copy.status.63 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.23, ptr %host.pointer.62, i32 %input.host.extent.25, i32 0, i32 %input.measured.payload.32, i32 %input.host.extent.25, i32 8, i32 52)
  %helper.ok.64 = icmp eq i32 %input.copy.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %entry.failure.0
helper.continue.65:
  %host.pointer.66 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.37
  %input.copy.status.67 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.37, ptr %host.pointer.66, i32 %input.host.extent.39, i32 0, i32 %input.measured.payload.46, i32 %input.host.extent.39, i32 2, i32 53)
  %helper.ok.68 = icmp eq i32 %input.copy.status.67, 0
  br i1 %helper.ok.68, label %helper.continue.69, label %entry.failure.0
helper.continue.69:
  %entry.body.status.70 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 54)
  %entry.body.ok.71 = icmp eq i32 %entry.body.status.70, 0
  br i1 %entry.body.ok.71, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.72 = add i32 0, %input.bytes
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %value.size.75 = alloca %AlOwningValueSize, align 4
  %measure.status.76 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.72, i32 %context.value.74, i32 55, ptr %value.size.75)
  %helper.ok.77 = icmp eq i32 %measure.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %entry.failure.0
helper.continue.78:
  %value.payload.pointer.79 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.75, i32 0, i32 0
  %value.extent.pointer.80 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.75, i32 0, i32 1
  %value.payload.81 = load i32, ptr %value.payload.pointer.79, align 4
  %value.extent.82 = load i32, ptr %value.extent.pointer.80, align 4
  %stack.offset.83 = add i32 %stack.offset.72, %value.extent.82
  %stack.offset.84 = add i32 0, %value.payload.81
  %value.size.85 = alloca %AlOwningValueSize, align 4
  %measure.status.86 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.83, i32 %context.value.74, i32 56, ptr %value.size.85)
  %helper.ok.87 = icmp eq i32 %measure.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %entry.failure.0
helper.continue.88:
  %value.payload.pointer.89 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.85, i32 0, i32 0
  %value.extent.pointer.90 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.85, i32 0, i32 1
  %value.payload.91 = load i32, ptr %value.payload.pointer.89, align 4
  %value.extent.92 = load i32, ptr %value.extent.pointer.90, align 4
  %stack.offset.93 = add i32 %stack.offset.83, %value.extent.92
  %stack.offset.94 = add i32 %stack.offset.84, %value.payload.91
  %entry.outputs.exact.95 = icmp eq i32 %stack.offset.93, %context.value.74
  br i1 %entry.outputs.exact.95, label %entry.outputs.exact.96, label %entry.failure.0
entry.outputs.exact.96:
  %stack.sub.97 = sub i32 %context.value.74, %stack.offset.72
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.72, i32 %stack.sub.97, i32 %stack.offset.94, i32 0, i32 9)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %entry.failure.0
runtime.continue.101:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.97, i32 0, i32 0, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.97, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %entry.failure.0
runtime.continue.109:
  %stack.sub.110 = sub i32 0, %stack.offset.94
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.110, i32 0)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %entry.failure.0
runtime.continue.114:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.offset.121 = add i32 %context.value.116, %context.value.118
  %stack.sub.122 = sub i32 0, %stack.offset.121
  %stack.sub.123 = sub i32 0, %context.value.118
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.122, i32 %stack.sub.123)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.120)
  br label %entry.return.status
entry.return.status:
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.125 = load i32, ptr %context.field.124, align 4
  ret i32 %context.value.125
}


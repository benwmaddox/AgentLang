%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 12, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %stack.offset.40 = add i32 0, 0
  %stack.offset.41 = add i32 %context.value.15, %stack.offset.40
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %stack.offset.45 = add i32 0, %value.extent.28
  %callee.status.44 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.41, i32 %stack.offset.45, i32 4)
  %helper.ok.46 = icmp eq i32 %callee.status.44, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %frame.failure.0
helper.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %value.size.50 = alloca %AlOwningValueSize, align 4
  %measure.status.51 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %context.value.43, i32 %context.value.49, i32 5, ptr %value.size.50)
  %helper.ok.52 = icmp eq i32 %measure.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %value.payload.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 0
  %value.extent.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 1
  %value.payload.56 = load i32, ptr %value.payload.pointer.54, align 4
  %value.extent.57 = load i32, ptr %value.extent.pointer.55, align 4
  %stack.offset.58 = add i32 %context.value.43, %value.extent.57
  %stack.offset.59 = add i32 0, %value.payload.56
  %callee.outputs.exact.60 = icmp eq i32 %stack.offset.58, %context.value.49
  br i1 %callee.outputs.exact.60, label %callee.outputs.continue.61, label %frame.failure.0
callee.outputs.continue.61:
  %stack.sub.62 = sub i32 %context.value.49, %context.value.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.41, i32 %context.value.43, i32 %stack.sub.62, i32 %stack.offset.59, i32 0, i32 9)
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %runtime.ok.65 = icmp eq i32 %context.value.64, 0
  br i1 %runtime.ok.65, label %runtime.continue.66, label %frame.failure.0
runtime.continue.66:
  %stack.offset.67 = add i32 %stack.offset.41, %stack.sub.62
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.67, i32 0, i32 0, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %stack.offset.72 = add i32 0, %value.extent.57
  %stack.offset.73 = add i32 0, %stack.offset.72
  %stack.offset.74 = add i32 %context.value.15, %stack.offset.73
  %cursor.status.75 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.74)
  %cursor.ok.76 = icmp eq i32 %cursor.status.75, 0
  br i1 %cursor.ok.76, label %cursor.continue.77, label %frame.failure.0
cursor.continue.77:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %context.field.82 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.83 = load i32, ptr %context.field.82, align 4
  %stack.offset.84 = add i32 %context.value.6, %context.value.8
  %stack.offset.85 = add i32 %context.value.79, %context.value.81
  %stack.sub.86 = sub i32 %stack.offset.84, %stack.offset.85
  %stack.sub.87 = sub i32 %context.value.8, %context.value.81
  %stack.sub.88 = sub i32 %context.value.83, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.86, i32 %stack.sub.87)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.88)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.18:
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %stack.offset.21 = add i32 %argument.source, %argument.bytes
  %stack.offset.22 = add i32 %context.value.20, %argument.bytes
  %reserve.status.23 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.22, i32 6)
  %reserve.ok.24 = icmp eq i32 %reserve.status.23, 0
  br i1 %reserve.ok.24, label %reserve.continue.25, label %frame.reserve.failure.1
reserve.continue.25:
  %value.size.26 = alloca %AlOwningValueSize, align 4
  %measure.status.27 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %argument.source, i32 %stack.offset.21, i32 7, ptr %value.size.26)
  %helper.ok.28 = icmp eq i32 %measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %frame.failure.0
helper.continue.29:
  %value.payload.pointer.30 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.26, i32 0, i32 0
  %value.extent.pointer.31 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.26, i32 0, i32 1
  %value.payload.32 = load i32, ptr %value.payload.pointer.30, align 4
  %value.extent.33 = load i32, ptr %value.extent.pointer.31, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.20, i32 %argument.source, i32 %value.extent.33, i32 %value.payload.32, i32 12, i32 8)
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %runtime.ok.36 = icmp eq i32 %context.value.35, 0
  br i1 %runtime.ok.36, label %runtime.continue.37, label %frame.failure.0
runtime.continue.37:
  %stack.offset.38 = add i32 %argument.source, %value.extent.33
  %stack.offset.39 = add i32 %context.value.20, %value.extent.33
  %arguments.exact.40 = icmp eq i32 %stack.offset.38, %stack.offset.21
  br i1 %arguments.exact.40, label %arguments.continue.41, label %frame.failure.0
arguments.continue.41:
  %step.status.42 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.43 = icmp eq i32 %step.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %frame.failure.0
helper.continue.44:
  %local.is.active.45 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.46 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.47 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.48 = select i1 %local.is.active.45, i32 %local.previous.extent.46, i32 0
  %local.old.payload.49 = select i1 %local.is.active.45, i32 %local.previous.payload.47, i32 0
  %stack.offset.50 = add i32 %context.value.20, 0
  %stack.offset.51 = add i32 %stack.offset.50, %local.old.extent.48
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %stack.sub.54 = sub i32 %context.value.53, %stack.offset.51
  %stack.sub.55 = sub i32 %context.value.53, %local.old.extent.48
  %stack.offset.56 = add i32 %stack.sub.55, %value.extent.33
  %local.grows.57 = icmp ugt i32 %value.extent.33, %local.old.extent.48
  br i1 %local.grows.57, label %local.grow.58, label %local.fixed.59
local.grow.58:
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.56, i32 9)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  %stack.sub.64 = sub i32 %value.extent.33, %local.old.extent.48
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.64)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %frame.failure.0
runtime.continue.68:
  br label %local.layout.ready.60
local.fixed.59:
  br label %local.layout.ready.60
local.layout.ready.60:
  %stack.offset.69 = add i32 %stack.offset.50, %value.extent.33
  %stack.offset.70 = add i32 0, %value.payload.32
  %stack.offset.71 = add i32 0, %stack.offset.70
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.69, i32 %stack.offset.51, i32 %stack.sub.54, i32 %stack.offset.71, i32 0, i32 14)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %frame.failure.0
runtime.continue.75:
  %stack.sub.76 = sub i32 %context.value.53, %value.extent.33
  %stack.sub.77 = sub i32 %stack.sub.76, %local.old.extent.48
  %stack.offset.78 = add i32 %stack.sub.77, %value.extent.33
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.50, i32 %stack.offset.78, i32 %value.extent.33, i32 %value.payload.32, i32 12, i32 4)
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %runtime.ok.81 = icmp eq i32 %context.value.80, 0
  br i1 %runtime.ok.81, label %runtime.continue.82, label %frame.failure.0
runtime.continue.82:
  %stack.sub.83 = sub i32 %context.value.53, %local.old.extent.48
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.83, i32 0, i32 0, i32 0)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %local.shrinks.88 = icmp ult i32 %value.extent.33, %local.old.extent.48
  br i1 %local.shrinks.88, label %local.shrink.89, label %local.counts.ready.90
local.shrink.89:
  %stack.sub.91 = sub i32 %local.old.extent.48, %value.extent.33
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  br label %local.counts.ready.90
local.counts.ready.90:
  %local.payload.delta.96 = sub i32 %value.payload.32, %local.old.payload.49
  %stack.sub.97 = sub i32 0, %local.old.payload.49
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.97, i32 %local.payload.delta.96)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.50, ptr %local.offset.4, align 4
  store i32 %value.extent.33, ptr %local.extent.5, align 4
  store i32 %value.payload.32, ptr %local.payload.6, align 4
  store i32 12, ptr %local.type.7, align 4
  %local.is.active.102 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.103 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.104 = select i1 %local.is.active.102, i32 %local.sum.extent.103, i32 0
  %stack.offset.105 = add i32 0, %local.sum.selected.104
  %stack.offset.106 = add i32 %stack.offset.105, 0
  %stack.offset.107 = add i32 %context.value.20, %stack.offset.106
  %cursor.status.108 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.107)
  %cursor.ok.109 = icmp eq i32 %cursor.status.108, 0
  br i1 %cursor.ok.109, label %cursor.continue.110, label %frame.failure.0
cursor.continue.110:
  %step.status.111 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.112 = icmp eq i32 %step.status.111, 0
  br i1 %helper.ok.112, label %helper.continue.113, label %frame.failure.0
helper.continue.113:
  %local.source.offset.114 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.115 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.116 = load i32, ptr %local.payload.6, align 4
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %stack.offset.119 = add i32 %context.value.118, %local.source.extent.115
  %reserve.status.120 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.119, i32 11)
  %reserve.ok.121 = icmp eq i32 %reserve.status.120, 0
  br i1 %reserve.ok.121, label %reserve.continue.122, label %frame.failure.0
reserve.continue.122:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.118, i32 %local.source.offset.114, i32 %local.source.extent.115, i32 %local.source.payload.116, i32 12)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %local.is.active.127 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.128 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.129 = select i1 %local.is.active.127, i32 %local.sum.extent.128, i32 0
  %stack.offset.130 = add i32 0, %local.sum.selected.129
  %stack.offset.131 = add i32 0, %local.source.extent.115
  %stack.offset.132 = add i32 %stack.offset.130, %stack.offset.131
  %stack.offset.133 = add i32 %context.value.20, %stack.offset.132
  %cursor.status.134 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.133)
  %cursor.ok.135 = icmp eq i32 %cursor.status.134, 0
  br i1 %cursor.ok.135, label %cursor.continue.136, label %frame.failure.0
cursor.continue.136:
  %local.is.active.137 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.137, label %local.remove.138, label %local.keep.139
local.keep.139:
  br label %local.removed.140
local.remove.138:
  %local.remove.offset.141 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.142 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.143 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.144 = load i32, ptr %local.type.7, align 4
  %stack.offset.145 = add i32 %local.remove.offset.141, %local.remove.extent.142
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.148 = sub i32 %context.value.147, %stack.offset.145
  %stack.offset.149 = add i32 0, %local.source.payload.116
  %stack.offset.150 = add i32 0, %stack.offset.149
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.141, i32 %stack.offset.145, i32 %stack.sub.148, i32 %stack.offset.150, i32 0, i32 14)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  %stack.sub.155 = sub i32 %context.value.147, %local.remove.extent.142
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.155, i32 0, i32 0, i32 0)
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %runtime.ok.158 = icmp eq i32 %context.value.157, 0
  br i1 %runtime.ok.158, label %runtime.continue.159, label %frame.failure.0
runtime.continue.159:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.144, i32 %local.remove.offset.141, i32 %local.remove.extent.142, i32 %local.remove.payload.143, i32 0, i32 0)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  %stack.sub.164 = sub i32 0, %local.remove.payload.143
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.164, i32 %stack.sub.164)
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %runtime.ok.167 = icmp eq i32 %context.value.166, 0
  br i1 %runtime.ok.167, label %runtime.continue.168, label %frame.failure.0
runtime.continue.168:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.142)
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %runtime.ok.171 = icmp eq i32 %context.value.170, 0
  br i1 %runtime.ok.171, label %runtime.continue.172, label %frame.failure.0
runtime.continue.172:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.140
local.removed.140:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.174 = load i32, ptr %context.field.173, align 4
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %context.field.177 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.178 = load i32, ptr %context.field.177, align 4
  %stack.offset.179 = add i32 %context.value.11, %context.value.13
  %stack.offset.180 = add i32 %context.value.174, %context.value.176
  %stack.sub.181 = sub i32 %stack.offset.179, %stack.offset.180
  %stack.sub.182 = sub i32 %context.value.13, %context.value.176
  %stack.sub.183 = sub i32 %context.value.178, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.181, i32 %stack.sub.182)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.183)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 12, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 12, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 13)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 12, i32 14)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 15)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %value.size.39 = alloca %AlOwningValueSize, align 4
  %measure.status.40 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.36, i32 %context.value.38, i32 16, ptr %value.size.39)
  %helper.ok.41 = icmp eq i32 %measure.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %entry.failure.0
helper.continue.42:
  %value.payload.pointer.43 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 0
  %value.extent.pointer.44 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 1
  %value.payload.45 = load i32, ptr %value.payload.pointer.43, align 4
  %value.extent.46 = load i32, ptr %value.extent.pointer.44, align 4
  %stack.offset.47 = add i32 %stack.offset.36, %value.extent.46
  %stack.offset.48 = add i32 0, %value.payload.45
  %entry.outputs.exact.49 = icmp eq i32 %stack.offset.47, %context.value.38
  br i1 %entry.outputs.exact.49, label %entry.outputs.exact.50, label %entry.failure.0
entry.outputs.exact.50:
  %stack.sub.51 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.51, i32 %stack.offset.48, i32 0, i32 9)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %entry.failure.0
runtime.continue.55:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.51, i32 0, i32 0, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.51, i32 12)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %entry.failure.0
runtime.continue.63:
  %stack.sub.64 = sub i32 0, %stack.offset.48
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.64, i32 0)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %entry.failure.0
runtime.continue.68:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.offset.75 = add i32 %context.value.70, %context.value.72
  %stack.sub.76 = sub i32 0, %stack.offset.75
  %stack.sub.77 = sub i32 0, %context.value.72
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.76, i32 %stack.sub.77)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.74)
  br label %entry.return.status
entry.return.status:
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  ret i32 %context.value.79
}


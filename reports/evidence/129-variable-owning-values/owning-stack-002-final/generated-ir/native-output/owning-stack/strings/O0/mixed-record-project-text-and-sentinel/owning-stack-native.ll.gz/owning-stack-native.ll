%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 10, i32 0, i32 3, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 3, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [3 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 0, i32 1, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 3 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 10, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %stack.offset.40 = add i32 0, 0
  %stack.offset.41 = add i32 %context.value.15, %stack.offset.40
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %stack.offset.45 = add i32 0, %value.extent.28
  %callee.status.44 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.41, i32 %stack.offset.45, i32 4)
  %helper.ok.46 = icmp eq i32 %callee.status.44, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %frame.failure.0
helper.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %value.size.50 = alloca %AlOwningValueSize, align 4
  %measure.status.51 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %context.value.43, i32 %context.value.49, i32 5, ptr %value.size.50)
  %helper.ok.52 = icmp eq i32 %measure.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %value.payload.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 0
  %value.extent.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 1
  %value.payload.56 = load i32, ptr %value.payload.pointer.54, align 4
  %value.extent.57 = load i32, ptr %value.extent.pointer.55, align 4
  %stack.offset.58 = add i32 %context.value.43, %value.extent.57
  %stack.offset.59 = add i32 0, %value.payload.56
  %value.size.60 = alloca %AlOwningValueSize, align 4
  %measure.status.61 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.58, i32 %context.value.49, i32 6, ptr %value.size.60)
  %helper.ok.62 = icmp eq i32 %measure.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %value.payload.pointer.64 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 0
  %value.extent.pointer.65 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 1
  %value.payload.66 = load i32, ptr %value.payload.pointer.64, align 4
  %value.extent.67 = load i32, ptr %value.extent.pointer.65, align 4
  %stack.offset.68 = add i32 %stack.offset.58, %value.extent.67
  %stack.offset.69 = add i32 %stack.offset.59, %value.payload.66
  %callee.outputs.exact.70 = icmp eq i32 %stack.offset.68, %context.value.49
  br i1 %callee.outputs.exact.70, label %callee.outputs.continue.71, label %frame.failure.0
callee.outputs.continue.71:
  %stack.sub.72 = sub i32 %context.value.49, %context.value.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.41, i32 %context.value.43, i32 %stack.sub.72, i32 %stack.offset.69, i32 0, i32 9)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %frame.failure.0
runtime.continue.76:
  %stack.offset.77 = add i32 %stack.offset.41, %stack.sub.72
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.77, i32 0, i32 0, i32 0)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %frame.failure.0
runtime.continue.81:
  %stack.offset.82 = add i32 0, %value.extent.57
  %stack.offset.83 = add i32 %stack.offset.82, %value.extent.67
  %stack.offset.84 = add i32 0, %stack.offset.83
  %stack.offset.85 = add i32 %context.value.15, %stack.offset.84
  %cursor.status.86 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.85)
  %cursor.ok.87 = icmp eq i32 %cursor.status.86, 0
  br i1 %cursor.ok.87, label %cursor.continue.88, label %frame.failure.0
cursor.continue.88:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %stack.offset.95 = add i32 %context.value.6, %context.value.8
  %stack.offset.96 = add i32 %context.value.90, %context.value.92
  %stack.sub.97 = sub i32 %stack.offset.95, %stack.offset.96
  %stack.sub.98 = sub i32 %context.value.8, %context.value.92
  %stack.sub.99 = sub i32 %context.value.94, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.97, i32 %stack.sub.98)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.99)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %frame.entered.26 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.27 = icmp eq i32 %frame.entered.26, 0
  br i1 %frame.enter.ok.27, label %frame.enter.continue.28, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.28:
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %stack.offset.31 = add i32 %argument.source, %argument.bytes
  %stack.offset.32 = add i32 %context.value.30, %argument.bytes
  %reserve.status.33 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.32, i32 7)
  %reserve.ok.34 = icmp eq i32 %reserve.status.33, 0
  br i1 %reserve.ok.34, label %reserve.continue.35, label %frame.reserve.failure.1
reserve.continue.35:
  %value.size.36 = alloca %AlOwningValueSize, align 4
  %measure.status.37 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %argument.source, i32 %stack.offset.31, i32 8, ptr %value.size.36)
  %helper.ok.38 = icmp eq i32 %measure.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %value.payload.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.36, i32 0, i32 0
  %value.extent.pointer.41 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.36, i32 0, i32 1
  %value.payload.42 = load i32, ptr %value.payload.pointer.40, align 4
  %value.extent.43 = load i32, ptr %value.extent.pointer.41, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.30, i32 %argument.source, i32 %value.extent.43, i32 %value.payload.42, i32 10, i32 8)
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %runtime.ok.46 = icmp eq i32 %context.value.45, 0
  br i1 %runtime.ok.46, label %runtime.continue.47, label %frame.failure.0
runtime.continue.47:
  %stack.offset.48 = add i32 %argument.source, %value.extent.43
  %stack.offset.49 = add i32 %context.value.30, %value.extent.43
  %arguments.exact.50 = icmp eq i32 %stack.offset.48, %stack.offset.31
  br i1 %arguments.exact.50, label %arguments.continue.51, label %frame.failure.0
arguments.continue.51:
  %step.status.52 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.53 = icmp eq i32 %step.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %local.is.active.55 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.56 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.57 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.58 = select i1 %local.is.active.55, i32 %local.previous.extent.56, i32 0
  %local.old.payload.59 = select i1 %local.is.active.55, i32 %local.previous.payload.57, i32 0
  %stack.offset.60 = add i32 %context.value.30, 0
  %stack.offset.61 = add i32 %stack.offset.60, %local.old.extent.58
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.64 = sub i32 %context.value.63, %stack.offset.61
  %stack.sub.65 = sub i32 %context.value.63, %local.old.extent.58
  %stack.offset.66 = add i32 %stack.sub.65, %value.extent.43
  %local.grows.67 = icmp ugt i32 %value.extent.43, %local.old.extent.58
  br i1 %local.grows.67, label %local.grow.68, label %local.fixed.69
local.grow.68:
  %reserve.status.71 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.66, i32 10)
  %reserve.ok.72 = icmp eq i32 %reserve.status.71, 0
  br i1 %reserve.ok.72, label %reserve.continue.73, label %frame.failure.0
reserve.continue.73:
  %stack.sub.74 = sub i32 %value.extent.43, %local.old.extent.58
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.74)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  br label %local.layout.ready.70
local.fixed.69:
  br label %local.layout.ready.70
local.layout.ready.70:
  %stack.offset.79 = add i32 %stack.offset.60, %value.extent.43
  %local.is.active.80 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.81 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.82 = select i1 %local.is.active.80, i32 %local.suffix.payload.81, i32 0
  %stack.offset.83 = add i32 0, %local.suffix.selected.82
  %local.is.active.84 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.85 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.86 = select i1 %local.is.active.84, i32 %local.suffix.payload.85, i32 0
  %stack.offset.87 = add i32 %stack.offset.83, %local.suffix.selected.86
  %stack.offset.88 = add i32 0, %value.payload.42
  %stack.offset.89 = add i32 %stack.offset.87, %stack.offset.88
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.79, i32 %stack.offset.61, i32 %stack.sub.64, i32 %stack.offset.89, i32 0, i32 14)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %stack.sub.94 = sub i32 %context.value.63, %value.extent.43
  %stack.sub.95 = sub i32 %stack.sub.94, %local.old.extent.58
  %stack.offset.96 = add i32 %stack.sub.95, %value.extent.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.60, i32 %stack.offset.96, i32 %value.extent.43, i32 %value.payload.42, i32 10, i32 4)
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %runtime.ok.99 = icmp eq i32 %context.value.98, 0
  br i1 %runtime.ok.99, label %runtime.continue.100, label %frame.failure.0
runtime.continue.100:
  %stack.sub.101 = sub i32 %context.value.63, %local.old.extent.58
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.101, i32 0, i32 0, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %local.shrinks.106 = icmp ult i32 %value.extent.43, %local.old.extent.58
  br i1 %local.shrinks.106, label %local.shrink.107, label %local.counts.ready.108
local.shrink.107:
  %stack.sub.109 = sub i32 %local.old.extent.58, %value.extent.43
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.109)
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %runtime.ok.112 = icmp eq i32 %context.value.111, 0
  br i1 %runtime.ok.112, label %runtime.continue.113, label %frame.failure.0
runtime.continue.113:
  br label %local.counts.ready.108
local.counts.ready.108:
  %local.payload.delta.114 = sub i32 %value.payload.42, %local.old.payload.59
  %stack.sub.115 = sub i32 0, %local.old.payload.59
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.115, i32 %local.payload.delta.114)
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %runtime.ok.118 = icmp eq i32 %context.value.117, 0
  br i1 %runtime.ok.118, label %runtime.continue.119, label %frame.failure.0
runtime.continue.119:
  %local.is.active.120 = load i1, ptr %local.active.8, align 1
  %local.later.offset.121 = load i32, ptr %local.offset.9, align 4
  %stack.sub.122 = sub i32 %local.later.offset.121, %local.old.extent.58
  %stack.offset.123 = add i32 %stack.sub.122, %value.extent.43
  %local.later.offset.selected.124 = select i1 %local.is.active.120, i32 %stack.offset.123, i32 %local.later.offset.121
  store i32 %local.later.offset.selected.124, ptr %local.offset.9, align 4
  %local.is.active.125 = load i1, ptr %local.active.13, align 1
  %local.later.offset.126 = load i32, ptr %local.offset.14, align 4
  %stack.sub.127 = sub i32 %local.later.offset.126, %local.old.extent.58
  %stack.offset.128 = add i32 %stack.sub.127, %value.extent.43
  %local.later.offset.selected.129 = select i1 %local.is.active.125, i32 %stack.offset.128, i32 %local.later.offset.126
  store i32 %local.later.offset.selected.129, ptr %local.offset.14, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.60, ptr %local.offset.4, align 4
  store i32 %value.extent.43, ptr %local.extent.5, align 4
  store i32 %value.payload.42, ptr %local.payload.6, align 4
  store i32 10, ptr %local.type.7, align 4
  %local.is.active.130 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.131 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.132 = select i1 %local.is.active.130, i32 %local.sum.extent.131, i32 0
  %stack.offset.133 = add i32 0, %local.sum.selected.132
  %local.is.active.134 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.135 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.136 = select i1 %local.is.active.134, i32 %local.sum.extent.135, i32 0
  %stack.offset.137 = add i32 %stack.offset.133, %local.sum.selected.136
  %local.is.active.138 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.139 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.140 = select i1 %local.is.active.138, i32 %local.sum.extent.139, i32 0
  %stack.offset.141 = add i32 %stack.offset.137, %local.sum.selected.140
  %stack.offset.142 = add i32 %stack.offset.141, 0
  %stack.offset.143 = add i32 %context.value.30, %stack.offset.142
  %cursor.status.144 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.143)
  %cursor.ok.145 = icmp eq i32 %cursor.status.144, 0
  br i1 %cursor.ok.145, label %cursor.continue.146, label %frame.failure.0
cursor.continue.146:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %local.source.offset.150 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.151 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.152 = load i32, ptr %local.payload.6, align 4
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %stack.offset.155 = add i32 %context.value.154, %local.source.extent.151
  %reserve.status.156 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.155, i32 12)
  %reserve.ok.157 = icmp eq i32 %reserve.status.156, 0
  br i1 %reserve.ok.157, label %reserve.continue.158, label %frame.failure.0
reserve.continue.158:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.154, i32 %local.source.offset.150, i32 %local.source.extent.151, i32 %local.source.payload.152, i32 10)
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %runtime.ok.161 = icmp eq i32 %context.value.160, 0
  br i1 %runtime.ok.161, label %runtime.continue.162, label %frame.failure.0
runtime.continue.162:
  %local.is.active.163 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.164 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.165 = select i1 %local.is.active.163, i32 %local.sum.extent.164, i32 0
  %stack.offset.166 = add i32 0, %local.sum.selected.165
  %local.is.active.167 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.168 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.169 = select i1 %local.is.active.167, i32 %local.sum.extent.168, i32 0
  %stack.offset.170 = add i32 %stack.offset.166, %local.sum.selected.169
  %local.is.active.171 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.172 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.173 = select i1 %local.is.active.171, i32 %local.sum.extent.172, i32 0
  %stack.offset.174 = add i32 %stack.offset.170, %local.sum.selected.173
  %stack.offset.175 = add i32 0, %local.source.extent.151
  %stack.offset.176 = add i32 %stack.offset.174, %stack.offset.175
  %stack.offset.177 = add i32 %context.value.30, %stack.offset.176
  %cursor.status.178 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.177)
  %cursor.ok.179 = icmp eq i32 %cursor.status.178, 0
  br i1 %cursor.ok.179, label %cursor.continue.180, label %frame.failure.0
cursor.continue.180:
  %step.status.181 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.182 = icmp eq i32 %step.status.181, 0
  br i1 %helper.ok.182, label %helper.continue.183, label %frame.failure.0
helper.continue.183:
  %local.is.active.184 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.185 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.186 = select i1 %local.is.active.184, i32 %local.sum.extent.185, i32 0
  %stack.offset.187 = add i32 0, %local.sum.selected.186
  %local.is.active.188 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.189 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.190 = select i1 %local.is.active.188, i32 %local.sum.extent.189, i32 0
  %stack.offset.191 = add i32 %stack.offset.187, %local.sum.selected.190
  %local.is.active.192 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.193 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.194 = select i1 %local.is.active.192, i32 %local.sum.extent.193, i32 0
  %stack.offset.195 = add i32 %stack.offset.191, %local.sum.selected.194
  %stack.offset.196 = add i32 %stack.offset.195, 0
  %stack.offset.197 = add i32 %context.value.30, %stack.offset.196
  %field.location.198 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.199 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.197, i32 %local.source.extent.151, i32 1, i32 14, ptr %field.location.198)
  %helper.ok.200 = icmp eq i32 %field.location.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %frame.failure.0
helper.continue.201:
  %field.offset.pointer.202 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.198, i32 0, i32 0
  %field.offset.203 = load i32, ptr %field.offset.pointer.202, align 4
  %field.payload.pointer.204 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.198, i32 0, i32 1
  %field.payload.205 = load i32, ptr %field.payload.pointer.204, align 4
  %field.extent.pointer.206 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.198, i32 0, i32 2
  %field.extent.207 = load i32, ptr %field.extent.pointer.206, align 4
  %stack.offset.208 = add i32 %stack.offset.197, %field.extent.207
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %field.result.grows.211 = icmp ugt i32 %stack.offset.208, %context.value.210
  br i1 %field.result.grows.211, label %field.result.reserve.212, label %field.result.existing.213
field.result.reserve.212:
  %reserve.status.215 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.208, i32 15)
  %reserve.ok.216 = icmp eq i32 %reserve.status.215, 0
  br i1 %reserve.ok.216, label %reserve.continue.217, label %frame.failure.0
reserve.continue.217:
  br label %field.result.ready.214
field.result.existing.213:
  br label %field.result.ready.214
field.result.ready.214:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.197, i32 %field.offset.203, i32 %field.extent.207, i32 %field.payload.205, i32 12, i32 7)
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %runtime.ok.220 = icmp eq i32 %context.value.219, 0
  br i1 %runtime.ok.220, label %runtime.continue.221, label %frame.failure.0
runtime.continue.221:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.208, i32 0, i32 0, i32 0)
  %context.field.222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.223 = load i32, ptr %context.field.222, align 4
  %runtime.ok.224 = icmp eq i32 %context.value.223, 0
  br i1 %runtime.ok.224, label %runtime.continue.225, label %frame.failure.0
runtime.continue.225:
  %stack.sub.226 = sub i32 %field.payload.205, %local.source.payload.152
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.226, i32 0)
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %runtime.ok.229 = icmp eq i32 %context.value.228, 0
  br i1 %runtime.ok.229, label %runtime.continue.230, label %frame.failure.0
runtime.continue.230:
  %local.is.active.231 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.232 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.233 = select i1 %local.is.active.231, i32 %local.sum.extent.232, i32 0
  %stack.offset.234 = add i32 0, %local.sum.selected.233
  %local.is.active.235 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.236 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.237 = select i1 %local.is.active.235, i32 %local.sum.extent.236, i32 0
  %stack.offset.238 = add i32 %stack.offset.234, %local.sum.selected.237
  %local.is.active.239 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.240 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.241 = select i1 %local.is.active.239, i32 %local.sum.extent.240, i32 0
  %stack.offset.242 = add i32 %stack.offset.238, %local.sum.selected.241
  %stack.offset.243 = add i32 0, %field.extent.207
  %stack.offset.244 = add i32 %stack.offset.242, %stack.offset.243
  %stack.offset.245 = add i32 %context.value.30, %stack.offset.244
  %cursor.status.246 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.245)
  %cursor.ok.247 = icmp eq i32 %cursor.status.246, 0
  br i1 %cursor.ok.247, label %cursor.continue.248, label %frame.failure.0
cursor.continue.248:
  %step.status.249 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.250 = icmp eq i32 %step.status.249, 0
  br i1 %helper.ok.250, label %helper.continue.251, label %frame.failure.0
helper.continue.251:
  %local.is.active.252 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.253 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.254 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.255 = select i1 %local.is.active.252, i32 %local.previous.extent.253, i32 0
  %local.old.payload.256 = select i1 %local.is.active.252, i32 %local.previous.payload.254, i32 0
  %local.is.active.257 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.258 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.259 = select i1 %local.is.active.257, i32 %local.sum.extent.258, i32 0
  %stack.offset.260 = add i32 0, %local.sum.selected.259
  %stack.offset.261 = add i32 %context.value.30, %stack.offset.260
  %stack.offset.262 = add i32 %stack.offset.261, %local.old.extent.255
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %stack.sub.265 = sub i32 %context.value.264, %stack.offset.262
  %stack.sub.266 = sub i32 %context.value.264, %local.old.extent.255
  %stack.offset.267 = add i32 %stack.sub.266, %field.extent.207
  %local.grows.268 = icmp ugt i32 %field.extent.207, %local.old.extent.255
  br i1 %local.grows.268, label %local.grow.269, label %local.fixed.270
local.grow.269:
  %reserve.status.272 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.267, i32 17)
  %reserve.ok.273 = icmp eq i32 %reserve.status.272, 0
  br i1 %reserve.ok.273, label %reserve.continue.274, label %frame.failure.0
reserve.continue.274:
  %stack.sub.275 = sub i32 %field.extent.207, %local.old.extent.255
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.275)
  %context.field.276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.277 = load i32, ptr %context.field.276, align 4
  %runtime.ok.278 = icmp eq i32 %context.value.277, 0
  br i1 %runtime.ok.278, label %runtime.continue.279, label %frame.failure.0
runtime.continue.279:
  br label %local.layout.ready.271
local.fixed.270:
  br label %local.layout.ready.271
local.layout.ready.271:
  %stack.offset.280 = add i32 %stack.offset.261, %field.extent.207
  %local.is.active.281 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.282 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.283 = select i1 %local.is.active.281, i32 %local.suffix.payload.282, i32 0
  %stack.offset.284 = add i32 0, %local.suffix.selected.283
  %stack.offset.285 = add i32 0, %field.payload.205
  %stack.offset.286 = add i32 %stack.offset.284, %stack.offset.285
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.280, i32 %stack.offset.262, i32 %stack.sub.265, i32 %stack.offset.286, i32 0, i32 14)
  %context.field.287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.288 = load i32, ptr %context.field.287, align 4
  %runtime.ok.289 = icmp eq i32 %context.value.288, 0
  br i1 %runtime.ok.289, label %runtime.continue.290, label %frame.failure.0
runtime.continue.290:
  %stack.sub.291 = sub i32 %context.value.264, %field.extent.207
  %stack.sub.292 = sub i32 %stack.sub.291, %local.old.extent.255
  %stack.offset.293 = add i32 %stack.sub.292, %field.extent.207
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.261, i32 %stack.offset.293, i32 %field.extent.207, i32 %field.payload.205, i32 12, i32 4)
  %context.field.294 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.295 = load i32, ptr %context.field.294, align 4
  %runtime.ok.296 = icmp eq i32 %context.value.295, 0
  br i1 %runtime.ok.296, label %runtime.continue.297, label %frame.failure.0
runtime.continue.297:
  %stack.sub.298 = sub i32 %context.value.264, %local.old.extent.255
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.298, i32 0, i32 0, i32 0)
  %context.field.299 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.300 = load i32, ptr %context.field.299, align 4
  %runtime.ok.301 = icmp eq i32 %context.value.300, 0
  br i1 %runtime.ok.301, label %runtime.continue.302, label %frame.failure.0
runtime.continue.302:
  %local.shrinks.303 = icmp ult i32 %field.extent.207, %local.old.extent.255
  br i1 %local.shrinks.303, label %local.shrink.304, label %local.counts.ready.305
local.shrink.304:
  %stack.sub.306 = sub i32 %local.old.extent.255, %field.extent.207
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.306)
  %context.field.307 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.308 = load i32, ptr %context.field.307, align 4
  %runtime.ok.309 = icmp eq i32 %context.value.308, 0
  br i1 %runtime.ok.309, label %runtime.continue.310, label %frame.failure.0
runtime.continue.310:
  br label %local.counts.ready.305
local.counts.ready.305:
  %local.payload.delta.311 = sub i32 %field.payload.205, %local.old.payload.256
  %stack.sub.312 = sub i32 0, %local.old.payload.256
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.312, i32 %local.payload.delta.311)
  %context.field.313 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.314 = load i32, ptr %context.field.313, align 4
  %runtime.ok.315 = icmp eq i32 %context.value.314, 0
  br i1 %runtime.ok.315, label %runtime.continue.316, label %frame.failure.0
runtime.continue.316:
  %local.is.active.317 = load i1, ptr %local.active.13, align 1
  %local.later.offset.318 = load i32, ptr %local.offset.14, align 4
  %stack.sub.319 = sub i32 %local.later.offset.318, %local.old.extent.255
  %stack.offset.320 = add i32 %stack.sub.319, %field.extent.207
  %local.later.offset.selected.321 = select i1 %local.is.active.317, i32 %stack.offset.320, i32 %local.later.offset.318
  store i32 %local.later.offset.selected.321, ptr %local.offset.14, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.261, ptr %local.offset.9, align 4
  store i32 %field.extent.207, ptr %local.extent.10, align 4
  store i32 %field.payload.205, ptr %local.payload.11, align 4
  store i32 12, ptr %local.type.12, align 4
  %local.is.active.322 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.323 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.324 = select i1 %local.is.active.322, i32 %local.sum.extent.323, i32 0
  %stack.offset.325 = add i32 0, %local.sum.selected.324
  %local.is.active.326 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.327 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.328 = select i1 %local.is.active.326, i32 %local.sum.extent.327, i32 0
  %stack.offset.329 = add i32 %stack.offset.325, %local.sum.selected.328
  %local.is.active.330 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.331 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.332 = select i1 %local.is.active.330, i32 %local.sum.extent.331, i32 0
  %stack.offset.333 = add i32 %stack.offset.329, %local.sum.selected.332
  %stack.offset.334 = add i32 %stack.offset.333, 0
  %stack.offset.335 = add i32 %context.value.30, %stack.offset.334
  %cursor.status.336 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.335)
  %cursor.ok.337 = icmp eq i32 %cursor.status.336, 0
  br i1 %cursor.ok.337, label %cursor.continue.338, label %frame.failure.0
cursor.continue.338:
  %step.status.339 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.340 = icmp eq i32 %step.status.339, 0
  br i1 %helper.ok.340, label %helper.continue.341, label %frame.failure.0
helper.continue.341:
  %local.source.offset.342 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.343 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.344 = load i32, ptr %local.payload.6, align 4
  %context.field.345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.346 = load i32, ptr %context.field.345, align 4
  %stack.offset.347 = add i32 %context.value.346, %local.source.extent.343
  %reserve.status.348 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.347, i32 19)
  %reserve.ok.349 = icmp eq i32 %reserve.status.348, 0
  br i1 %reserve.ok.349, label %reserve.continue.350, label %frame.failure.0
reserve.continue.350:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.346, i32 %local.source.offset.342, i32 %local.source.extent.343, i32 %local.source.payload.344, i32 10)
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %runtime.ok.353 = icmp eq i32 %context.value.352, 0
  br i1 %runtime.ok.353, label %runtime.continue.354, label %frame.failure.0
runtime.continue.354:
  %local.is.active.355 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.356 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.357 = select i1 %local.is.active.355, i32 %local.sum.extent.356, i32 0
  %stack.offset.358 = add i32 0, %local.sum.selected.357
  %local.is.active.359 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.360 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.361 = select i1 %local.is.active.359, i32 %local.sum.extent.360, i32 0
  %stack.offset.362 = add i32 %stack.offset.358, %local.sum.selected.361
  %local.is.active.363 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.364 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.365 = select i1 %local.is.active.363, i32 %local.sum.extent.364, i32 0
  %stack.offset.366 = add i32 %stack.offset.362, %local.sum.selected.365
  %stack.offset.367 = add i32 0, %local.source.extent.343
  %stack.offset.368 = add i32 %stack.offset.366, %stack.offset.367
  %stack.offset.369 = add i32 %context.value.30, %stack.offset.368
  %cursor.status.370 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.369)
  %cursor.ok.371 = icmp eq i32 %cursor.status.370, 0
  br i1 %cursor.ok.371, label %cursor.continue.372, label %frame.failure.0
cursor.continue.372:
  %step.status.373 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.374 = icmp eq i32 %step.status.373, 0
  br i1 %helper.ok.374, label %helper.continue.375, label %frame.failure.0
helper.continue.375:
  %local.is.active.376 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.377 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.378 = select i1 %local.is.active.376, i32 %local.sum.extent.377, i32 0
  %stack.offset.379 = add i32 0, %local.sum.selected.378
  %local.is.active.380 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.381 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.382 = select i1 %local.is.active.380, i32 %local.sum.extent.381, i32 0
  %stack.offset.383 = add i32 %stack.offset.379, %local.sum.selected.382
  %local.is.active.384 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.385 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.386 = select i1 %local.is.active.384, i32 %local.sum.extent.385, i32 0
  %stack.offset.387 = add i32 %stack.offset.383, %local.sum.selected.386
  %stack.offset.388 = add i32 %stack.offset.387, 0
  %stack.offset.389 = add i32 %context.value.30, %stack.offset.388
  %field.location.390 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.391 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.389, i32 %local.source.extent.343, i32 2, i32 21, ptr %field.location.390)
  %helper.ok.392 = icmp eq i32 %field.location.status.391, 0
  br i1 %helper.ok.392, label %helper.continue.393, label %frame.failure.0
helper.continue.393:
  %field.offset.pointer.394 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.390, i32 0, i32 0
  %field.offset.395 = load i32, ptr %field.offset.pointer.394, align 4
  %field.payload.pointer.396 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.390, i32 0, i32 1
  %field.payload.397 = load i32, ptr %field.payload.pointer.396, align 4
  %field.extent.pointer.398 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.390, i32 0, i32 2
  %field.extent.399 = load i32, ptr %field.extent.pointer.398, align 4
  %stack.offset.400 = add i32 %stack.offset.389, %field.extent.399
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %field.result.grows.403 = icmp ugt i32 %stack.offset.400, %context.value.402
  br i1 %field.result.grows.403, label %field.result.reserve.404, label %field.result.existing.405
field.result.reserve.404:
  %reserve.status.407 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.400, i32 22)
  %reserve.ok.408 = icmp eq i32 %reserve.status.407, 0
  br i1 %reserve.ok.408, label %reserve.continue.409, label %frame.failure.0
reserve.continue.409:
  br label %field.result.ready.406
field.result.existing.405:
  br label %field.result.ready.406
field.result.ready.406:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.389, i32 %field.offset.395, i32 %field.extent.399, i32 %field.payload.397, i32 1, i32 7)
  %context.field.410 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.411 = load i32, ptr %context.field.410, align 4
  %runtime.ok.412 = icmp eq i32 %context.value.411, 0
  br i1 %runtime.ok.412, label %runtime.continue.413, label %frame.failure.0
runtime.continue.413:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.400, i32 0, i32 0, i32 0)
  %context.field.414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.415 = load i32, ptr %context.field.414, align 4
  %runtime.ok.416 = icmp eq i32 %context.value.415, 0
  br i1 %runtime.ok.416, label %runtime.continue.417, label %frame.failure.0
runtime.continue.417:
  %stack.sub.418 = sub i32 %field.payload.397, %local.source.payload.344
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.418, i32 0)
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.420 = load i32, ptr %context.field.419, align 4
  %runtime.ok.421 = icmp eq i32 %context.value.420, 0
  br i1 %runtime.ok.421, label %runtime.continue.422, label %frame.failure.0
runtime.continue.422:
  %local.is.active.423 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.424 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.425 = select i1 %local.is.active.423, i32 %local.sum.extent.424, i32 0
  %stack.offset.426 = add i32 0, %local.sum.selected.425
  %local.is.active.427 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.428 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.429 = select i1 %local.is.active.427, i32 %local.sum.extent.428, i32 0
  %stack.offset.430 = add i32 %stack.offset.426, %local.sum.selected.429
  %local.is.active.431 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.432 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.433 = select i1 %local.is.active.431, i32 %local.sum.extent.432, i32 0
  %stack.offset.434 = add i32 %stack.offset.430, %local.sum.selected.433
  %stack.offset.435 = add i32 0, %field.extent.399
  %stack.offset.436 = add i32 %stack.offset.434, %stack.offset.435
  %stack.offset.437 = add i32 %context.value.30, %stack.offset.436
  %cursor.status.438 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.437)
  %cursor.ok.439 = icmp eq i32 %cursor.status.438, 0
  br i1 %cursor.ok.439, label %cursor.continue.440, label %frame.failure.0
cursor.continue.440:
  %step.status.441 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.442 = icmp eq i32 %step.status.441, 0
  br i1 %helper.ok.442, label %helper.continue.443, label %frame.failure.0
helper.continue.443:
  %local.is.active.444 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.445 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.446 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.447 = select i1 %local.is.active.444, i32 %local.previous.extent.445, i32 0
  %local.old.payload.448 = select i1 %local.is.active.444, i32 %local.previous.payload.446, i32 0
  %local.is.active.449 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.450 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.451 = select i1 %local.is.active.449, i32 %local.sum.extent.450, i32 0
  %stack.offset.452 = add i32 0, %local.sum.selected.451
  %local.is.active.453 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.454 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.455 = select i1 %local.is.active.453, i32 %local.sum.extent.454, i32 0
  %stack.offset.456 = add i32 %stack.offset.452, %local.sum.selected.455
  %stack.offset.457 = add i32 %context.value.30, %stack.offset.456
  %stack.offset.458 = add i32 %stack.offset.457, %local.old.extent.447
  %context.field.459 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.460 = load i32, ptr %context.field.459, align 4
  %stack.sub.461 = sub i32 %context.value.460, %stack.offset.458
  %stack.sub.462 = sub i32 %context.value.460, %local.old.extent.447
  %stack.offset.463 = add i32 %stack.sub.462, %field.extent.399
  %local.grows.464 = icmp ugt i32 %field.extent.399, %local.old.extent.447
  br i1 %local.grows.464, label %local.grow.465, label %local.fixed.466
local.grow.465:
  %reserve.status.468 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.463, i32 24)
  %reserve.ok.469 = icmp eq i32 %reserve.status.468, 0
  br i1 %reserve.ok.469, label %reserve.continue.470, label %frame.failure.0
reserve.continue.470:
  %stack.sub.471 = sub i32 %field.extent.399, %local.old.extent.447
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.471)
  %context.field.472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.473 = load i32, ptr %context.field.472, align 4
  %runtime.ok.474 = icmp eq i32 %context.value.473, 0
  br i1 %runtime.ok.474, label %runtime.continue.475, label %frame.failure.0
runtime.continue.475:
  br label %local.layout.ready.467
local.fixed.466:
  br label %local.layout.ready.467
local.layout.ready.467:
  %stack.offset.476 = add i32 %stack.offset.457, %field.extent.399
  %stack.offset.477 = add i32 0, %field.payload.397
  %stack.offset.478 = add i32 0, %stack.offset.477
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.476, i32 %stack.offset.458, i32 %stack.sub.461, i32 %stack.offset.478, i32 0, i32 14)
  %context.field.479 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.480 = load i32, ptr %context.field.479, align 4
  %runtime.ok.481 = icmp eq i32 %context.value.480, 0
  br i1 %runtime.ok.481, label %runtime.continue.482, label %frame.failure.0
runtime.continue.482:
  %stack.sub.483 = sub i32 %context.value.460, %field.extent.399
  %stack.sub.484 = sub i32 %stack.sub.483, %local.old.extent.447
  %stack.offset.485 = add i32 %stack.sub.484, %field.extent.399
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.457, i32 %stack.offset.485, i32 %field.extent.399, i32 %field.payload.397, i32 1, i32 4)
  %context.field.486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.487 = load i32, ptr %context.field.486, align 4
  %runtime.ok.488 = icmp eq i32 %context.value.487, 0
  br i1 %runtime.ok.488, label %runtime.continue.489, label %frame.failure.0
runtime.continue.489:
  %stack.sub.490 = sub i32 %context.value.460, %local.old.extent.447
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.490, i32 0, i32 0, i32 0)
  %context.field.491 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.492 = load i32, ptr %context.field.491, align 4
  %runtime.ok.493 = icmp eq i32 %context.value.492, 0
  br i1 %runtime.ok.493, label %runtime.continue.494, label %frame.failure.0
runtime.continue.494:
  %local.shrinks.495 = icmp ult i32 %field.extent.399, %local.old.extent.447
  br i1 %local.shrinks.495, label %local.shrink.496, label %local.counts.ready.497
local.shrink.496:
  %stack.sub.498 = sub i32 %local.old.extent.447, %field.extent.399
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.498)
  %context.field.499 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.500 = load i32, ptr %context.field.499, align 4
  %runtime.ok.501 = icmp eq i32 %context.value.500, 0
  br i1 %runtime.ok.501, label %runtime.continue.502, label %frame.failure.0
runtime.continue.502:
  br label %local.counts.ready.497
local.counts.ready.497:
  %local.payload.delta.503 = sub i32 %field.payload.397, %local.old.payload.448
  %stack.sub.504 = sub i32 0, %local.old.payload.448
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.504, i32 %local.payload.delta.503)
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %runtime.ok.507 = icmp eq i32 %context.value.506, 0
  br i1 %runtime.ok.507, label %runtime.continue.508, label %frame.failure.0
runtime.continue.508:
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.457, ptr %local.offset.14, align 4
  store i32 %field.extent.399, ptr %local.extent.15, align 4
  store i32 %field.payload.397, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  %local.is.active.509 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.510 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.511 = select i1 %local.is.active.509, i32 %local.sum.extent.510, i32 0
  %stack.offset.512 = add i32 0, %local.sum.selected.511
  %local.is.active.513 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.514 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.515 = select i1 %local.is.active.513, i32 %local.sum.extent.514, i32 0
  %stack.offset.516 = add i32 %stack.offset.512, %local.sum.selected.515
  %local.is.active.517 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.518 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.519 = select i1 %local.is.active.517, i32 %local.sum.extent.518, i32 0
  %stack.offset.520 = add i32 %stack.offset.516, %local.sum.selected.519
  %stack.offset.521 = add i32 %stack.offset.520, 0
  %stack.offset.522 = add i32 %context.value.30, %stack.offset.521
  %cursor.status.523 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.522)
  %cursor.ok.524 = icmp eq i32 %cursor.status.523, 0
  br i1 %cursor.ok.524, label %cursor.continue.525, label %frame.failure.0
cursor.continue.525:
  %step.status.526 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.527 = icmp eq i32 %step.status.526, 0
  br i1 %helper.ok.527, label %helper.continue.528, label %frame.failure.0
helper.continue.528:
  %local.source.offset.529 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.530 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.531 = load i32, ptr %local.payload.11, align 4
  %context.field.532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.533 = load i32, ptr %context.field.532, align 4
  %stack.offset.534 = add i32 %context.value.533, %local.source.extent.530
  %reserve.status.535 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.534, i32 26)
  %reserve.ok.536 = icmp eq i32 %reserve.status.535, 0
  br i1 %reserve.ok.536, label %reserve.continue.537, label %frame.failure.0
reserve.continue.537:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.533, i32 %local.source.offset.529, i32 %local.source.extent.530, i32 %local.source.payload.531, i32 12)
  %context.field.538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.539 = load i32, ptr %context.field.538, align 4
  %runtime.ok.540 = icmp eq i32 %context.value.539, 0
  br i1 %runtime.ok.540, label %runtime.continue.541, label %frame.failure.0
runtime.continue.541:
  %local.is.active.542 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.543 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.544 = select i1 %local.is.active.542, i32 %local.sum.extent.543, i32 0
  %stack.offset.545 = add i32 0, %local.sum.selected.544
  %local.is.active.546 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.547 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.548 = select i1 %local.is.active.546, i32 %local.sum.extent.547, i32 0
  %stack.offset.549 = add i32 %stack.offset.545, %local.sum.selected.548
  %local.is.active.550 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.551 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.552 = select i1 %local.is.active.550, i32 %local.sum.extent.551, i32 0
  %stack.offset.553 = add i32 %stack.offset.549, %local.sum.selected.552
  %stack.offset.554 = add i32 0, %local.source.extent.530
  %stack.offset.555 = add i32 %stack.offset.553, %stack.offset.554
  %stack.offset.556 = add i32 %context.value.30, %stack.offset.555
  %cursor.status.557 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.556)
  %cursor.ok.558 = icmp eq i32 %cursor.status.557, 0
  br i1 %cursor.ok.558, label %cursor.continue.559, label %frame.failure.0
cursor.continue.559:
  %step.status.560 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.561 = icmp eq i32 %step.status.560, 0
  br i1 %helper.ok.561, label %helper.continue.562, label %frame.failure.0
helper.continue.562:
  %local.source.offset.563 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.564 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.565 = load i32, ptr %local.payload.16, align 4
  %context.field.566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.567 = load i32, ptr %context.field.566, align 4
  %stack.offset.568 = add i32 %context.value.567, %local.source.extent.564
  %reserve.status.569 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.568, i32 28)
  %reserve.ok.570 = icmp eq i32 %reserve.status.569, 0
  br i1 %reserve.ok.570, label %reserve.continue.571, label %frame.failure.0
reserve.continue.571:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.567, i32 %local.source.offset.563, i32 %local.source.extent.564, i32 %local.source.payload.565, i32 1)
  %context.field.572 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.573 = load i32, ptr %context.field.572, align 4
  %runtime.ok.574 = icmp eq i32 %context.value.573, 0
  br i1 %runtime.ok.574, label %runtime.continue.575, label %frame.failure.0
runtime.continue.575:
  %local.is.active.576 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.577 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.578 = select i1 %local.is.active.576, i32 %local.sum.extent.577, i32 0
  %stack.offset.579 = add i32 0, %local.sum.selected.578
  %local.is.active.580 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.581 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.582 = select i1 %local.is.active.580, i32 %local.sum.extent.581, i32 0
  %stack.offset.583 = add i32 %stack.offset.579, %local.sum.selected.582
  %local.is.active.584 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.585 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.586 = select i1 %local.is.active.584, i32 %local.sum.extent.585, i32 0
  %stack.offset.587 = add i32 %stack.offset.583, %local.sum.selected.586
  %stack.offset.588 = add i32 0, %local.source.extent.530
  %stack.offset.589 = add i32 %stack.offset.588, %local.source.extent.564
  %stack.offset.590 = add i32 %stack.offset.587, %stack.offset.589
  %stack.offset.591 = add i32 %context.value.30, %stack.offset.590
  %cursor.status.592 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.591)
  %cursor.ok.593 = icmp eq i32 %cursor.status.592, 0
  br i1 %cursor.ok.593, label %cursor.continue.594, label %frame.failure.0
cursor.continue.594:
  %local.is.active.595 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.595, label %local.remove.596, label %local.keep.597
local.keep.597:
  br label %local.removed.598
local.remove.596:
  %local.remove.offset.599 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.600 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.601 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.602 = load i32, ptr %local.type.17, align 4
  %stack.offset.603 = add i32 %local.remove.offset.599, %local.remove.extent.600
  %context.field.604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.605 = load i32, ptr %context.field.604, align 4
  %stack.sub.606 = sub i32 %context.value.605, %stack.offset.603
  %stack.offset.607 = add i32 0, %local.source.payload.531
  %stack.offset.608 = add i32 %stack.offset.607, %local.source.payload.565
  %stack.offset.609 = add i32 0, %stack.offset.608
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.599, i32 %stack.offset.603, i32 %stack.sub.606, i32 %stack.offset.609, i32 0, i32 14)
  %context.field.610 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.611 = load i32, ptr %context.field.610, align 4
  %runtime.ok.612 = icmp eq i32 %context.value.611, 0
  br i1 %runtime.ok.612, label %runtime.continue.613, label %frame.failure.0
runtime.continue.613:
  %stack.sub.614 = sub i32 %context.value.605, %local.remove.extent.600
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.614, i32 0, i32 0, i32 0)
  %context.field.615 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.616 = load i32, ptr %context.field.615, align 4
  %runtime.ok.617 = icmp eq i32 %context.value.616, 0
  br i1 %runtime.ok.617, label %runtime.continue.618, label %frame.failure.0
runtime.continue.618:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.602, i32 %local.remove.offset.599, i32 %local.remove.extent.600, i32 %local.remove.payload.601, i32 0, i32 0)
  %context.field.619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.620 = load i32, ptr %context.field.619, align 4
  %runtime.ok.621 = icmp eq i32 %context.value.620, 0
  br i1 %runtime.ok.621, label %runtime.continue.622, label %frame.failure.0
runtime.continue.622:
  %stack.sub.623 = sub i32 0, %local.remove.payload.601
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.623, i32 %stack.sub.623)
  %context.field.624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.625 = load i32, ptr %context.field.624, align 4
  %runtime.ok.626 = icmp eq i32 %context.value.625, 0
  br i1 %runtime.ok.626, label %runtime.continue.627, label %frame.failure.0
runtime.continue.627:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.600)
  %context.field.628 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.629 = load i32, ptr %context.field.628, align 4
  %runtime.ok.630 = icmp eq i32 %context.value.629, 0
  br i1 %runtime.ok.630, label %runtime.continue.631, label %frame.failure.0
runtime.continue.631:
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.598
local.removed.598:
  %local.is.active.632 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.632, label %local.remove.633, label %local.keep.634
local.keep.634:
  br label %local.removed.635
local.remove.633:
  %local.remove.offset.636 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.637 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.638 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.639 = load i32, ptr %local.type.12, align 4
  %stack.offset.640 = add i32 %local.remove.offset.636, %local.remove.extent.637
  %context.field.641 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.642 = load i32, ptr %context.field.641, align 4
  %stack.sub.643 = sub i32 %context.value.642, %stack.offset.640
  %local.is.active.644 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.645 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.646 = select i1 %local.is.active.644, i32 %local.suffix.payload.645, i32 0
  %stack.offset.647 = add i32 0, %local.suffix.selected.646
  %stack.offset.648 = add i32 0, %local.source.payload.531
  %stack.offset.649 = add i32 %stack.offset.648, %local.source.payload.565
  %stack.offset.650 = add i32 %stack.offset.647, %stack.offset.649
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.636, i32 %stack.offset.640, i32 %stack.sub.643, i32 %stack.offset.650, i32 0, i32 14)
  %context.field.651 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.652 = load i32, ptr %context.field.651, align 4
  %runtime.ok.653 = icmp eq i32 %context.value.652, 0
  br i1 %runtime.ok.653, label %runtime.continue.654, label %frame.failure.0
runtime.continue.654:
  %stack.sub.655 = sub i32 %context.value.642, %local.remove.extent.637
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.655, i32 0, i32 0, i32 0)
  %context.field.656 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.657 = load i32, ptr %context.field.656, align 4
  %runtime.ok.658 = icmp eq i32 %context.value.657, 0
  br i1 %runtime.ok.658, label %runtime.continue.659, label %frame.failure.0
runtime.continue.659:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.639, i32 %local.remove.offset.636, i32 %local.remove.extent.637, i32 %local.remove.payload.638, i32 0, i32 0)
  %context.field.660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.661 = load i32, ptr %context.field.660, align 4
  %runtime.ok.662 = icmp eq i32 %context.value.661, 0
  br i1 %runtime.ok.662, label %runtime.continue.663, label %frame.failure.0
runtime.continue.663:
  %stack.sub.664 = sub i32 0, %local.remove.payload.638
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.664, i32 %stack.sub.664)
  %context.field.665 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.666 = load i32, ptr %context.field.665, align 4
  %runtime.ok.667 = icmp eq i32 %context.value.666, 0
  br i1 %runtime.ok.667, label %runtime.continue.668, label %frame.failure.0
runtime.continue.668:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.637)
  %context.field.669 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.670 = load i32, ptr %context.field.669, align 4
  %runtime.ok.671 = icmp eq i32 %context.value.670, 0
  br i1 %runtime.ok.671, label %runtime.continue.672, label %frame.failure.0
runtime.continue.672:
  %local.is.active.673 = load i1, ptr %local.active.13, align 1
  %local.later.offset.674 = load i32, ptr %local.offset.14, align 4
  %stack.sub.675 = sub i32 %local.later.offset.674, %local.remove.extent.637
  %local.later.offset.selected.676 = select i1 %local.is.active.673, i32 %stack.sub.675, i32 %local.later.offset.674
  store i32 %local.later.offset.selected.676, ptr %local.offset.14, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.635
local.removed.635:
  %local.is.active.677 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.677, label %local.remove.678, label %local.keep.679
local.keep.679:
  br label %local.removed.680
local.remove.678:
  %local.remove.offset.681 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.682 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.683 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.684 = load i32, ptr %local.type.7, align 4
  %stack.offset.685 = add i32 %local.remove.offset.681, %local.remove.extent.682
  %context.field.686 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.687 = load i32, ptr %context.field.686, align 4
  %stack.sub.688 = sub i32 %context.value.687, %stack.offset.685
  %local.is.active.689 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.690 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.691 = select i1 %local.is.active.689, i32 %local.suffix.payload.690, i32 0
  %stack.offset.692 = add i32 0, %local.suffix.selected.691
  %local.is.active.693 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.694 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.695 = select i1 %local.is.active.693, i32 %local.suffix.payload.694, i32 0
  %stack.offset.696 = add i32 %stack.offset.692, %local.suffix.selected.695
  %stack.offset.697 = add i32 0, %local.source.payload.531
  %stack.offset.698 = add i32 %stack.offset.697, %local.source.payload.565
  %stack.offset.699 = add i32 %stack.offset.696, %stack.offset.698
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.681, i32 %stack.offset.685, i32 %stack.sub.688, i32 %stack.offset.699, i32 0, i32 14)
  %context.field.700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.701 = load i32, ptr %context.field.700, align 4
  %runtime.ok.702 = icmp eq i32 %context.value.701, 0
  br i1 %runtime.ok.702, label %runtime.continue.703, label %frame.failure.0
runtime.continue.703:
  %stack.sub.704 = sub i32 %context.value.687, %local.remove.extent.682
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.704, i32 0, i32 0, i32 0)
  %context.field.705 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.706 = load i32, ptr %context.field.705, align 4
  %runtime.ok.707 = icmp eq i32 %context.value.706, 0
  br i1 %runtime.ok.707, label %runtime.continue.708, label %frame.failure.0
runtime.continue.708:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.684, i32 %local.remove.offset.681, i32 %local.remove.extent.682, i32 %local.remove.payload.683, i32 0, i32 0)
  %context.field.709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.710 = load i32, ptr %context.field.709, align 4
  %runtime.ok.711 = icmp eq i32 %context.value.710, 0
  br i1 %runtime.ok.711, label %runtime.continue.712, label %frame.failure.0
runtime.continue.712:
  %stack.sub.713 = sub i32 0, %local.remove.payload.683
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.713, i32 %stack.sub.713)
  %context.field.714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.715 = load i32, ptr %context.field.714, align 4
  %runtime.ok.716 = icmp eq i32 %context.value.715, 0
  br i1 %runtime.ok.716, label %runtime.continue.717, label %frame.failure.0
runtime.continue.717:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.682)
  %context.field.718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.719 = load i32, ptr %context.field.718, align 4
  %runtime.ok.720 = icmp eq i32 %context.value.719, 0
  br i1 %runtime.ok.720, label %runtime.continue.721, label %frame.failure.0
runtime.continue.721:
  %local.is.active.722 = load i1, ptr %local.active.8, align 1
  %local.later.offset.723 = load i32, ptr %local.offset.9, align 4
  %stack.sub.724 = sub i32 %local.later.offset.723, %local.remove.extent.682
  %local.later.offset.selected.725 = select i1 %local.is.active.722, i32 %stack.sub.724, i32 %local.later.offset.723
  store i32 %local.later.offset.selected.725, ptr %local.offset.9, align 4
  %local.is.active.726 = load i1, ptr %local.active.13, align 1
  %local.later.offset.727 = load i32, ptr %local.offset.14, align 4
  %stack.sub.728 = sub i32 %local.later.offset.727, %local.remove.extent.682
  %local.later.offset.selected.729 = select i1 %local.is.active.726, i32 %stack.sub.728, i32 %local.later.offset.727
  store i32 %local.later.offset.selected.729, ptr %local.offset.14, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.680
local.removed.680:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  %context.field.730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.731 = load i32, ptr %context.field.730, align 4
  %context.field.732 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.733 = load i32, ptr %context.field.732, align 4
  %context.field.734 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.735 = load i32, ptr %context.field.734, align 4
  %stack.offset.736 = add i32 %context.value.21, %context.value.23
  %stack.offset.737 = add i32 %context.value.731, %context.value.733
  %stack.sub.738 = sub i32 %stack.offset.736, %stack.offset.737
  %stack.sub.739 = sub i32 %context.value.23, %context.value.733
  %stack.sub.740 = sub i32 %context.value.735, %context.value.25
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.738, i32 %stack.sub.739)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.740)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 29, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 29, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 30)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 10, i32 31)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 32)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %value.size.39 = alloca %AlOwningValueSize, align 4
  %measure.status.40 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.36, i32 %context.value.38, i32 33, ptr %value.size.39)
  %helper.ok.41 = icmp eq i32 %measure.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %entry.failure.0
helper.continue.42:
  %value.payload.pointer.43 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 0
  %value.extent.pointer.44 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 1
  %value.payload.45 = load i32, ptr %value.payload.pointer.43, align 4
  %value.extent.46 = load i32, ptr %value.extent.pointer.44, align 4
  %stack.offset.47 = add i32 %stack.offset.36, %value.extent.46
  %stack.offset.48 = add i32 0, %value.payload.45
  %value.size.49 = alloca %AlOwningValueSize, align 4
  %measure.status.50 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.47, i32 %context.value.38, i32 34, ptr %value.size.49)
  %helper.ok.51 = icmp eq i32 %measure.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %entry.failure.0
helper.continue.52:
  %value.payload.pointer.53 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 0
  %value.extent.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 1
  %value.payload.55 = load i32, ptr %value.payload.pointer.53, align 4
  %value.extent.56 = load i32, ptr %value.extent.pointer.54, align 4
  %stack.offset.57 = add i32 %stack.offset.47, %value.extent.56
  %stack.offset.58 = add i32 %stack.offset.48, %value.payload.55
  %entry.outputs.exact.59 = icmp eq i32 %stack.offset.57, %context.value.38
  br i1 %entry.outputs.exact.59, label %entry.outputs.exact.60, label %entry.failure.0
entry.outputs.exact.60:
  %stack.sub.61 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.61, i32 %stack.offset.58, i32 0, i32 9)
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %runtime.ok.64 = icmp eq i32 %context.value.63, 0
  br i1 %runtime.ok.64, label %runtime.continue.65, label %entry.failure.0
runtime.continue.65:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.61, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %entry.failure.0
runtime.continue.69:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.61, i32 0)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  %stack.sub.74 = sub i32 0, %stack.offset.58
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.74, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %entry.failure.0
runtime.continue.78:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %stack.offset.85 = add i32 %context.value.80, %context.value.82
  %stack.sub.86 = sub i32 0, %stack.offset.85
  %stack.sub.87 = sub i32 0, %context.value.82
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.86, i32 %stack.sub.87)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.84)
  br label %entry.return.status
entry.return.status:
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  ret i32 %context.value.89
}


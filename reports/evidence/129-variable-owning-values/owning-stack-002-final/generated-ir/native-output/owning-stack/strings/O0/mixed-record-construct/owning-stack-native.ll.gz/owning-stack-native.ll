%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 10, i32 0, i32 3, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 3, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [3 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 0, i32 1, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 3 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 12, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %value.size.35 = alloca %AlOwningValueSize, align 4
  %measure.status.36 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.33, i32 %stack.offset.16, i32 3, ptr %value.size.35)
  %helper.ok.37 = icmp eq i32 %measure.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %frame.failure.0
helper.continue.38:
  %value.payload.pointer.39 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 0
  %value.extent.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 1
  %value.payload.41 = load i32, ptr %value.payload.pointer.39, align 4
  %value.extent.42 = load i32, ptr %value.extent.pointer.40, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.33, i32 %value.extent.42, i32 %value.payload.41, i32 1, i32 8)
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %runtime.ok.45 = icmp eq i32 %context.value.44, 0
  br i1 %runtime.ok.45, label %runtime.continue.46, label %frame.failure.0
runtime.continue.46:
  %stack.offset.47 = add i32 %stack.offset.33, %value.extent.42
  %stack.offset.48 = add i32 %stack.offset.34, %value.extent.42
  %arguments.exact.49 = icmp eq i32 %stack.offset.47, %stack.offset.16
  br i1 %arguments.exact.49, label %arguments.continue.50, label %frame.failure.0
arguments.continue.50:
  %step.status.51 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.52 = icmp eq i32 %step.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %stack.offset.54 = add i32 0, 0
  %stack.offset.55 = add i32 %context.value.15, %stack.offset.54
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.offset.59 = add i32 0, %value.extent.28
  %stack.offset.60 = add i32 %stack.offset.59, %value.extent.42
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.55, i32 %stack.offset.60, i32 5)
  %helper.ok.61 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.61, label %helper.continue.62, label %frame.failure.0
helper.continue.62:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %value.size.65 = alloca %AlOwningValueSize, align 4
  %measure.status.66 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %context.value.57, i32 %context.value.64, i32 6, ptr %value.size.65)
  %helper.ok.67 = icmp eq i32 %measure.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %frame.failure.0
helper.continue.68:
  %value.payload.pointer.69 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 0
  %value.extent.pointer.70 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 1
  %value.payload.71 = load i32, ptr %value.payload.pointer.69, align 4
  %value.extent.72 = load i32, ptr %value.extent.pointer.70, align 4
  %stack.offset.73 = add i32 %context.value.57, %value.extent.72
  %stack.offset.74 = add i32 0, %value.payload.71
  %callee.outputs.exact.75 = icmp eq i32 %stack.offset.73, %context.value.64
  br i1 %callee.outputs.exact.75, label %callee.outputs.continue.76, label %frame.failure.0
callee.outputs.continue.76:
  %stack.sub.77 = sub i32 %context.value.64, %context.value.57
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.55, i32 %context.value.57, i32 %stack.sub.77, i32 %stack.offset.74, i32 0, i32 9)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %frame.failure.0
runtime.continue.81:
  %stack.offset.82 = add i32 %stack.offset.55, %stack.sub.77
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.82, i32 0, i32 0, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %stack.offset.87 = add i32 0, %value.extent.72
  %stack.offset.88 = add i32 0, %stack.offset.87
  %stack.offset.89 = add i32 %context.value.15, %stack.offset.88
  %cursor.status.90 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.89)
  %cursor.ok.91 = icmp eq i32 %cursor.status.90, 0
  br i1 %cursor.ok.91, label %cursor.continue.92, label %frame.failure.0
cursor.continue.92:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.offset.99 = add i32 %context.value.6, %context.value.8
  %stack.offset.100 = add i32 %context.value.94, %context.value.96
  %stack.sub.101 = sub i32 %stack.offset.99, %stack.offset.100
  %stack.sub.102 = sub i32 %context.value.8, %context.value.96
  %stack.sub.103 = sub i32 %context.value.98, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.101, i32 %stack.sub.102)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.103)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.offset.19 = alloca i32, align 4
  %local.extent.20 = alloca i32, align 4
  %local.payload.21 = alloca i32, align 4
  %local.type.22 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  %local.active.23 = alloca i1, align 1
  %local.offset.24 = alloca i32, align 4
  %local.extent.25 = alloca i32, align 4
  %local.payload.26 = alloca i32, align 4
  %local.type.27 = alloca i32, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  %local.active.28 = alloca i1, align 1
  %local.offset.29 = alloca i32, align 4
  %local.extent.30 = alloca i32, align 4
  %local.payload.31 = alloca i32, align 4
  %local.type.32 = alloca i32, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %context.field.35 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.36 = load i32, ptr %context.field.35, align 4
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %frame.entered.41 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.42 = icmp eq i32 %frame.entered.41, 0
  br i1 %frame.enter.ok.42, label %frame.enter.continue.43, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.offset.46 = add i32 %argument.source, %argument.bytes
  %stack.offset.47 = add i32 %context.value.45, %argument.bytes
  %reserve.status.48 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.47, i32 7)
  %reserve.ok.49 = icmp eq i32 %reserve.status.48, 0
  br i1 %reserve.ok.49, label %reserve.continue.50, label %frame.reserve.failure.1
reserve.continue.50:
  %value.size.51 = alloca %AlOwningValueSize, align 4
  %measure.status.52 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.46, i32 8, ptr %value.size.51)
  %helper.ok.53 = icmp eq i32 %measure.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %value.payload.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.51, i32 0, i32 0
  %value.extent.pointer.56 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.51, i32 0, i32 1
  %value.payload.57 = load i32, ptr %value.payload.pointer.55, align 4
  %value.extent.58 = load i32, ptr %value.extent.pointer.56, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.45, i32 %argument.source, i32 %value.extent.58, i32 %value.payload.57, i32 12, i32 8)
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %runtime.ok.61 = icmp eq i32 %context.value.60, 0
  br i1 %runtime.ok.61, label %runtime.continue.62, label %frame.failure.0
runtime.continue.62:
  %stack.offset.63 = add i32 %argument.source, %value.extent.58
  %stack.offset.64 = add i32 %context.value.45, %value.extent.58
  %value.size.65 = alloca %AlOwningValueSize, align 4
  %measure.status.66 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.63, i32 %stack.offset.46, i32 9, ptr %value.size.65)
  %helper.ok.67 = icmp eq i32 %measure.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %frame.failure.0
helper.continue.68:
  %value.payload.pointer.69 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 0
  %value.extent.pointer.70 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 1
  %value.payload.71 = load i32, ptr %value.payload.pointer.69, align 4
  %value.extent.72 = load i32, ptr %value.extent.pointer.70, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.64, i32 %stack.offset.63, i32 %value.extent.72, i32 %value.payload.71, i32 1, i32 8)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %frame.failure.0
runtime.continue.76:
  %stack.offset.77 = add i32 %stack.offset.63, %value.extent.72
  %stack.offset.78 = add i32 %stack.offset.64, %value.extent.72
  %arguments.exact.79 = icmp eq i32 %stack.offset.77, %stack.offset.46
  br i1 %arguments.exact.79, label %arguments.continue.80, label %frame.failure.0
arguments.continue.80:
  %step.status.81 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.82 = icmp eq i32 %step.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %local.is.active.84 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.85 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.86 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.87 = select i1 %local.is.active.84, i32 %local.previous.extent.85, i32 0
  %local.old.payload.88 = select i1 %local.is.active.84, i32 %local.previous.payload.86, i32 0
  %stack.offset.89 = add i32 %context.value.45, 0
  %stack.offset.90 = add i32 %stack.offset.89, %local.old.extent.87
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.sub.93 = sub i32 %context.value.92, %stack.offset.90
  %stack.sub.94 = sub i32 %context.value.92, %local.old.extent.87
  %stack.offset.95 = add i32 %stack.sub.94, %value.extent.72
  %local.grows.96 = icmp ugt i32 %value.extent.72, %local.old.extent.87
  br i1 %local.grows.96, label %local.grow.97, label %local.fixed.98
local.grow.97:
  %reserve.status.100 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.95, i32 11)
  %reserve.ok.101 = icmp eq i32 %reserve.status.100, 0
  br i1 %reserve.ok.101, label %reserve.continue.102, label %frame.failure.0
reserve.continue.102:
  %stack.sub.103 = sub i32 %value.extent.72, %local.old.extent.87
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.103)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  br label %local.layout.ready.99
local.fixed.98:
  br label %local.layout.ready.99
local.layout.ready.99:
  %stack.offset.108 = add i32 %stack.offset.89, %value.extent.72
  %local.is.active.109 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.110 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.111 = select i1 %local.is.active.109, i32 %local.suffix.payload.110, i32 0
  %stack.offset.112 = add i32 0, %local.suffix.selected.111
  %local.is.active.113 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.114 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.115 = select i1 %local.is.active.113, i32 %local.suffix.payload.114, i32 0
  %stack.offset.116 = add i32 %stack.offset.112, %local.suffix.selected.115
  %local.is.active.117 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.118 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.119 = select i1 %local.is.active.117, i32 %local.suffix.payload.118, i32 0
  %stack.offset.120 = add i32 %stack.offset.116, %local.suffix.selected.119
  %local.is.active.121 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.122 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.123 = select i1 %local.is.active.121, i32 %local.suffix.payload.122, i32 0
  %stack.offset.124 = add i32 %stack.offset.120, %local.suffix.selected.123
  %local.is.active.125 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.126 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.127 = select i1 %local.is.active.125, i32 %local.suffix.payload.126, i32 0
  %stack.offset.128 = add i32 %stack.offset.124, %local.suffix.selected.127
  %stack.offset.129 = add i32 0, %value.payload.57
  %stack.offset.130 = add i32 %stack.offset.129, %value.payload.71
  %stack.offset.131 = add i32 %stack.offset.128, %stack.offset.130
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.108, i32 %stack.offset.90, i32 %stack.sub.93, i32 %stack.offset.131, i32 0, i32 14)
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %runtime.ok.134 = icmp eq i32 %context.value.133, 0
  br i1 %runtime.ok.134, label %runtime.continue.135, label %frame.failure.0
runtime.continue.135:
  %stack.sub.136 = sub i32 %context.value.92, %value.extent.72
  %stack.sub.137 = sub i32 %stack.sub.136, %local.old.extent.87
  %stack.offset.138 = add i32 %stack.sub.137, %value.extent.72
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.89, i32 %stack.offset.138, i32 %value.extent.72, i32 %value.payload.71, i32 1, i32 4)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %frame.failure.0
runtime.continue.142:
  %stack.sub.143 = sub i32 %context.value.92, %local.old.extent.87
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.143, i32 0, i32 0, i32 0)
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  %runtime.ok.146 = icmp eq i32 %context.value.145, 0
  br i1 %runtime.ok.146, label %runtime.continue.147, label %frame.failure.0
runtime.continue.147:
  %local.shrinks.148 = icmp ult i32 %value.extent.72, %local.old.extent.87
  br i1 %local.shrinks.148, label %local.shrink.149, label %local.counts.ready.150
local.shrink.149:
  %stack.sub.151 = sub i32 %local.old.extent.87, %value.extent.72
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.151)
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %runtime.ok.154 = icmp eq i32 %context.value.153, 0
  br i1 %runtime.ok.154, label %runtime.continue.155, label %frame.failure.0
runtime.continue.155:
  br label %local.counts.ready.150
local.counts.ready.150:
  %local.payload.delta.156 = sub i32 %value.payload.71, %local.old.payload.88
  %stack.sub.157 = sub i32 0, %local.old.payload.88
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.157, i32 %local.payload.delta.156)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %local.is.active.162 = load i1, ptr %local.active.8, align 1
  %local.later.offset.163 = load i32, ptr %local.offset.9, align 4
  %stack.sub.164 = sub i32 %local.later.offset.163, %local.old.extent.87
  %stack.offset.165 = add i32 %stack.sub.164, %value.extent.72
  %local.later.offset.selected.166 = select i1 %local.is.active.162, i32 %stack.offset.165, i32 %local.later.offset.163
  store i32 %local.later.offset.selected.166, ptr %local.offset.9, align 4
  %local.is.active.167 = load i1, ptr %local.active.13, align 1
  %local.later.offset.168 = load i32, ptr %local.offset.14, align 4
  %stack.sub.169 = sub i32 %local.later.offset.168, %local.old.extent.87
  %stack.offset.170 = add i32 %stack.sub.169, %value.extent.72
  %local.later.offset.selected.171 = select i1 %local.is.active.167, i32 %stack.offset.170, i32 %local.later.offset.168
  store i32 %local.later.offset.selected.171, ptr %local.offset.14, align 4
  %local.is.active.172 = load i1, ptr %local.active.18, align 1
  %local.later.offset.173 = load i32, ptr %local.offset.19, align 4
  %stack.sub.174 = sub i32 %local.later.offset.173, %local.old.extent.87
  %stack.offset.175 = add i32 %stack.sub.174, %value.extent.72
  %local.later.offset.selected.176 = select i1 %local.is.active.172, i32 %stack.offset.175, i32 %local.later.offset.173
  store i32 %local.later.offset.selected.176, ptr %local.offset.19, align 4
  %local.is.active.177 = load i1, ptr %local.active.23, align 1
  %local.later.offset.178 = load i32, ptr %local.offset.24, align 4
  %stack.sub.179 = sub i32 %local.later.offset.178, %local.old.extent.87
  %stack.offset.180 = add i32 %stack.sub.179, %value.extent.72
  %local.later.offset.selected.181 = select i1 %local.is.active.177, i32 %stack.offset.180, i32 %local.later.offset.178
  store i32 %local.later.offset.selected.181, ptr %local.offset.24, align 4
  %local.is.active.182 = load i1, ptr %local.active.28, align 1
  %local.later.offset.183 = load i32, ptr %local.offset.29, align 4
  %stack.sub.184 = sub i32 %local.later.offset.183, %local.old.extent.87
  %stack.offset.185 = add i32 %stack.sub.184, %value.extent.72
  %local.later.offset.selected.186 = select i1 %local.is.active.182, i32 %stack.offset.185, i32 %local.later.offset.183
  store i32 %local.later.offset.selected.186, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.89, ptr %local.offset.4, align 4
  store i32 %value.extent.72, ptr %local.extent.5, align 4
  store i32 %value.payload.71, ptr %local.payload.6, align 4
  store i32 1, ptr %local.type.7, align 4
  %local.is.active.187 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.188 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.189 = select i1 %local.is.active.187, i32 %local.sum.extent.188, i32 0
  %stack.offset.190 = add i32 0, %local.sum.selected.189
  %local.is.active.191 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.192 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.193 = select i1 %local.is.active.191, i32 %local.sum.extent.192, i32 0
  %stack.offset.194 = add i32 %stack.offset.190, %local.sum.selected.193
  %local.is.active.195 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.196 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.197 = select i1 %local.is.active.195, i32 %local.sum.extent.196, i32 0
  %stack.offset.198 = add i32 %stack.offset.194, %local.sum.selected.197
  %local.is.active.199 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.200 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.201 = select i1 %local.is.active.199, i32 %local.sum.extent.200, i32 0
  %stack.offset.202 = add i32 %stack.offset.198, %local.sum.selected.201
  %local.is.active.203 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.204 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.205 = select i1 %local.is.active.203, i32 %local.sum.extent.204, i32 0
  %stack.offset.206 = add i32 %stack.offset.202, %local.sum.selected.205
  %local.is.active.207 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.208 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.209 = select i1 %local.is.active.207, i32 %local.sum.extent.208, i32 0
  %stack.offset.210 = add i32 %stack.offset.206, %local.sum.selected.209
  %stack.offset.211 = add i32 0, %value.extent.58
  %stack.offset.212 = add i32 %stack.offset.210, %stack.offset.211
  %stack.offset.213 = add i32 %context.value.45, %stack.offset.212
  %cursor.status.214 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.213)
  %cursor.ok.215 = icmp eq i32 %cursor.status.214, 0
  br i1 %cursor.ok.215, label %cursor.continue.216, label %frame.failure.0
cursor.continue.216:
  %step.status.217 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.218 = icmp eq i32 %step.status.217, 0
  br i1 %helper.ok.218, label %helper.continue.219, label %frame.failure.0
helper.continue.219:
  %local.is.active.220 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.221 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.222 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.223 = select i1 %local.is.active.220, i32 %local.previous.extent.221, i32 0
  %local.old.payload.224 = select i1 %local.is.active.220, i32 %local.previous.payload.222, i32 0
  %local.is.active.225 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.226 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.227 = select i1 %local.is.active.225, i32 %local.sum.extent.226, i32 0
  %stack.offset.228 = add i32 0, %local.sum.selected.227
  %stack.offset.229 = add i32 %context.value.45, %stack.offset.228
  %stack.offset.230 = add i32 %stack.offset.229, %local.old.extent.223
  %context.field.231 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.232 = load i32, ptr %context.field.231, align 4
  %stack.sub.233 = sub i32 %context.value.232, %stack.offset.230
  %stack.sub.234 = sub i32 %context.value.232, %local.old.extent.223
  %stack.offset.235 = add i32 %stack.sub.234, %value.extent.58
  %local.grows.236 = icmp ugt i32 %value.extent.58, %local.old.extent.223
  br i1 %local.grows.236, label %local.grow.237, label %local.fixed.238
local.grow.237:
  %reserve.status.240 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.235, i32 13)
  %reserve.ok.241 = icmp eq i32 %reserve.status.240, 0
  br i1 %reserve.ok.241, label %reserve.continue.242, label %frame.failure.0
reserve.continue.242:
  %stack.sub.243 = sub i32 %value.extent.58, %local.old.extent.223
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.243)
  %context.field.244 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.245 = load i32, ptr %context.field.244, align 4
  %runtime.ok.246 = icmp eq i32 %context.value.245, 0
  br i1 %runtime.ok.246, label %runtime.continue.247, label %frame.failure.0
runtime.continue.247:
  br label %local.layout.ready.239
local.fixed.238:
  br label %local.layout.ready.239
local.layout.ready.239:
  %stack.offset.248 = add i32 %stack.offset.229, %value.extent.58
  %local.is.active.249 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.250 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.251 = select i1 %local.is.active.249, i32 %local.suffix.payload.250, i32 0
  %stack.offset.252 = add i32 0, %local.suffix.selected.251
  %local.is.active.253 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.254 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.255 = select i1 %local.is.active.253, i32 %local.suffix.payload.254, i32 0
  %stack.offset.256 = add i32 %stack.offset.252, %local.suffix.selected.255
  %local.is.active.257 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.258 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.259 = select i1 %local.is.active.257, i32 %local.suffix.payload.258, i32 0
  %stack.offset.260 = add i32 %stack.offset.256, %local.suffix.selected.259
  %local.is.active.261 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.262 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.263 = select i1 %local.is.active.261, i32 %local.suffix.payload.262, i32 0
  %stack.offset.264 = add i32 %stack.offset.260, %local.suffix.selected.263
  %stack.offset.265 = add i32 0, %value.payload.57
  %stack.offset.266 = add i32 %stack.offset.264, %stack.offset.265
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.248, i32 %stack.offset.230, i32 %stack.sub.233, i32 %stack.offset.266, i32 0, i32 14)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %frame.failure.0
runtime.continue.270:
  %stack.sub.271 = sub i32 %context.value.232, %value.extent.58
  %stack.sub.272 = sub i32 %stack.sub.271, %local.old.extent.223
  %stack.offset.273 = add i32 %stack.sub.272, %value.extent.58
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.229, i32 %stack.offset.273, i32 %value.extent.58, i32 %value.payload.57, i32 12, i32 4)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %stack.sub.278 = sub i32 %context.value.232, %local.old.extent.223
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.278, i32 0, i32 0, i32 0)
  %context.field.279 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.280 = load i32, ptr %context.field.279, align 4
  %runtime.ok.281 = icmp eq i32 %context.value.280, 0
  br i1 %runtime.ok.281, label %runtime.continue.282, label %frame.failure.0
runtime.continue.282:
  %local.shrinks.283 = icmp ult i32 %value.extent.58, %local.old.extent.223
  br i1 %local.shrinks.283, label %local.shrink.284, label %local.counts.ready.285
local.shrink.284:
  %stack.sub.286 = sub i32 %local.old.extent.223, %value.extent.58
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.286)
  %context.field.287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.288 = load i32, ptr %context.field.287, align 4
  %runtime.ok.289 = icmp eq i32 %context.value.288, 0
  br i1 %runtime.ok.289, label %runtime.continue.290, label %frame.failure.0
runtime.continue.290:
  br label %local.counts.ready.285
local.counts.ready.285:
  %local.payload.delta.291 = sub i32 %value.payload.57, %local.old.payload.224
  %stack.sub.292 = sub i32 0, %local.old.payload.224
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.292, i32 %local.payload.delta.291)
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %runtime.ok.295 = icmp eq i32 %context.value.294, 0
  br i1 %runtime.ok.295, label %runtime.continue.296, label %frame.failure.0
runtime.continue.296:
  %local.is.active.297 = load i1, ptr %local.active.13, align 1
  %local.later.offset.298 = load i32, ptr %local.offset.14, align 4
  %stack.sub.299 = sub i32 %local.later.offset.298, %local.old.extent.223
  %stack.offset.300 = add i32 %stack.sub.299, %value.extent.58
  %local.later.offset.selected.301 = select i1 %local.is.active.297, i32 %stack.offset.300, i32 %local.later.offset.298
  store i32 %local.later.offset.selected.301, ptr %local.offset.14, align 4
  %local.is.active.302 = load i1, ptr %local.active.18, align 1
  %local.later.offset.303 = load i32, ptr %local.offset.19, align 4
  %stack.sub.304 = sub i32 %local.later.offset.303, %local.old.extent.223
  %stack.offset.305 = add i32 %stack.sub.304, %value.extent.58
  %local.later.offset.selected.306 = select i1 %local.is.active.302, i32 %stack.offset.305, i32 %local.later.offset.303
  store i32 %local.later.offset.selected.306, ptr %local.offset.19, align 4
  %local.is.active.307 = load i1, ptr %local.active.23, align 1
  %local.later.offset.308 = load i32, ptr %local.offset.24, align 4
  %stack.sub.309 = sub i32 %local.later.offset.308, %local.old.extent.223
  %stack.offset.310 = add i32 %stack.sub.309, %value.extent.58
  %local.later.offset.selected.311 = select i1 %local.is.active.307, i32 %stack.offset.310, i32 %local.later.offset.308
  store i32 %local.later.offset.selected.311, ptr %local.offset.24, align 4
  %local.is.active.312 = load i1, ptr %local.active.28, align 1
  %local.later.offset.313 = load i32, ptr %local.offset.29, align 4
  %stack.sub.314 = sub i32 %local.later.offset.313, %local.old.extent.223
  %stack.offset.315 = add i32 %stack.sub.314, %value.extent.58
  %local.later.offset.selected.316 = select i1 %local.is.active.312, i32 %stack.offset.315, i32 %local.later.offset.313
  store i32 %local.later.offset.selected.316, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.229, ptr %local.offset.9, align 4
  store i32 %value.extent.58, ptr %local.extent.10, align 4
  store i32 %value.payload.57, ptr %local.payload.11, align 4
  store i32 12, ptr %local.type.12, align 4
  %local.is.active.317 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.318 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.319 = select i1 %local.is.active.317, i32 %local.sum.extent.318, i32 0
  %stack.offset.320 = add i32 0, %local.sum.selected.319
  %local.is.active.321 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.322 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.323 = select i1 %local.is.active.321, i32 %local.sum.extent.322, i32 0
  %stack.offset.324 = add i32 %stack.offset.320, %local.sum.selected.323
  %local.is.active.325 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.326 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.327 = select i1 %local.is.active.325, i32 %local.sum.extent.326, i32 0
  %stack.offset.328 = add i32 %stack.offset.324, %local.sum.selected.327
  %local.is.active.329 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.330 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.331 = select i1 %local.is.active.329, i32 %local.sum.extent.330, i32 0
  %stack.offset.332 = add i32 %stack.offset.328, %local.sum.selected.331
  %local.is.active.333 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.334 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.335 = select i1 %local.is.active.333, i32 %local.sum.extent.334, i32 0
  %stack.offset.336 = add i32 %stack.offset.332, %local.sum.selected.335
  %local.is.active.337 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.338 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.339 = select i1 %local.is.active.337, i32 %local.sum.extent.338, i32 0
  %stack.offset.340 = add i32 %stack.offset.336, %local.sum.selected.339
  %stack.offset.341 = add i32 %stack.offset.340, 0
  %stack.offset.342 = add i32 %context.value.45, %stack.offset.341
  %cursor.status.343 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.342)
  %cursor.ok.344 = icmp eq i32 %cursor.status.343, 0
  br i1 %cursor.ok.344, label %cursor.continue.345, label %frame.failure.0
cursor.continue.345:
  %step.status.346 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.347 = icmp eq i32 %step.status.346, 0
  br i1 %helper.ok.347, label %helper.continue.348, label %frame.failure.0
helper.continue.348:
  %context.field.349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.350 = load i32, ptr %context.field.349, align 4
  %stack.offset.351 = add i32 %context.value.350, 8
  %reserve.status.352 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.351, i32 15)
  %reserve.ok.353 = icmp eq i32 %reserve.status.352, 0
  br i1 %reserve.ok.353, label %reserve.continue.354, label %frame.failure.0
reserve.continue.354:
  call void @al_owning_store_token(ptr %ctx, i32 %context.value.350, i32 4)
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %runtime.ok.357 = icmp eq i32 %context.value.356, 0
  br i1 %runtime.ok.357, label %runtime.continue.358, label %frame.failure.0
runtime.continue.358:
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.350, i32 %context.value.350, i32 8, i32 0, i32 4, i32 6)
  %context.field.359 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.360 = load i32, ptr %context.field.359, align 4
  %runtime.ok.361 = icmp eq i32 %context.value.360, 0
  br i1 %runtime.ok.361, label %runtime.continue.362, label %frame.failure.0
runtime.continue.362:
  %stack.offset.363 = add i32 %context.value.350, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.363, i32 0, i32 0, i32 0)
  %context.field.364 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.365 = load i32, ptr %context.field.364, align 4
  %runtime.ok.366 = icmp eq i32 %context.value.365, 0
  br i1 %runtime.ok.366, label %runtime.continue.367, label %frame.failure.0
runtime.continue.367:
  %stack.sub.368 = sub i32 0, 0
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.368, i32 0)
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %runtime.ok.371 = icmp eq i32 %context.value.370, 0
  br i1 %runtime.ok.371, label %runtime.continue.372, label %frame.failure.0
runtime.continue.372:
  %local.is.active.373 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.374 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.375 = select i1 %local.is.active.373, i32 %local.sum.extent.374, i32 0
  %stack.offset.376 = add i32 0, %local.sum.selected.375
  %local.is.active.377 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.378 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.379 = select i1 %local.is.active.377, i32 %local.sum.extent.378, i32 0
  %stack.offset.380 = add i32 %stack.offset.376, %local.sum.selected.379
  %local.is.active.381 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.382 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.383 = select i1 %local.is.active.381, i32 %local.sum.extent.382, i32 0
  %stack.offset.384 = add i32 %stack.offset.380, %local.sum.selected.383
  %local.is.active.385 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.386 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.387 = select i1 %local.is.active.385, i32 %local.sum.extent.386, i32 0
  %stack.offset.388 = add i32 %stack.offset.384, %local.sum.selected.387
  %local.is.active.389 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.390 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.391 = select i1 %local.is.active.389, i32 %local.sum.extent.390, i32 0
  %stack.offset.392 = add i32 %stack.offset.388, %local.sum.selected.391
  %local.is.active.393 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.394 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.395 = select i1 %local.is.active.393, i32 %local.sum.extent.394, i32 0
  %stack.offset.396 = add i32 %stack.offset.392, %local.sum.selected.395
  %stack.offset.397 = add i32 0, 8
  %stack.offset.398 = add i32 %stack.offset.396, %stack.offset.397
  %stack.offset.399 = add i32 %context.value.45, %stack.offset.398
  %cursor.status.400 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.399)
  %cursor.ok.401 = icmp eq i32 %cursor.status.400, 0
  br i1 %cursor.ok.401, label %cursor.continue.402, label %frame.failure.0
cursor.continue.402:
  %step.status.403 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.404 = icmp eq i32 %step.status.403, 0
  br i1 %helper.ok.404, label %helper.continue.405, label %frame.failure.0
helper.continue.405:
  %local.is.active.406 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.407 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.408 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.409 = select i1 %local.is.active.406, i32 %local.previous.extent.407, i32 0
  %local.old.payload.410 = select i1 %local.is.active.406, i32 %local.previous.payload.408, i32 0
  %local.is.active.411 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.412 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.413 = select i1 %local.is.active.411, i32 %local.sum.extent.412, i32 0
  %stack.offset.414 = add i32 0, %local.sum.selected.413
  %local.is.active.415 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.416 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.417 = select i1 %local.is.active.415, i32 %local.sum.extent.416, i32 0
  %stack.offset.418 = add i32 %stack.offset.414, %local.sum.selected.417
  %stack.offset.419 = add i32 %context.value.45, %stack.offset.418
  %stack.offset.420 = add i32 %stack.offset.419, %local.old.extent.409
  %context.field.421 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.422 = load i32, ptr %context.field.421, align 4
  %stack.sub.423 = sub i32 %context.value.422, %stack.offset.420
  %stack.sub.424 = sub i32 %context.value.422, %local.old.extent.409
  %stack.offset.425 = add i32 %stack.sub.424, 8
  %local.grows.426 = icmp ugt i32 8, %local.old.extent.409
  br i1 %local.grows.426, label %local.grow.427, label %local.fixed.428
local.grow.427:
  %reserve.status.430 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.425, i32 17)
  %reserve.ok.431 = icmp eq i32 %reserve.status.430, 0
  br i1 %reserve.ok.431, label %reserve.continue.432, label %frame.failure.0
reserve.continue.432:
  %stack.sub.433 = sub i32 8, %local.old.extent.409
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.433)
  %context.field.434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.435 = load i32, ptr %context.field.434, align 4
  %runtime.ok.436 = icmp eq i32 %context.value.435, 0
  br i1 %runtime.ok.436, label %runtime.continue.437, label %frame.failure.0
runtime.continue.437:
  br label %local.layout.ready.429
local.fixed.428:
  br label %local.layout.ready.429
local.layout.ready.429:
  %stack.offset.438 = add i32 %stack.offset.419, 8
  %local.is.active.439 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.440 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.441 = select i1 %local.is.active.439, i32 %local.suffix.payload.440, i32 0
  %stack.offset.442 = add i32 0, %local.suffix.selected.441
  %local.is.active.443 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.444 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.445 = select i1 %local.is.active.443, i32 %local.suffix.payload.444, i32 0
  %stack.offset.446 = add i32 %stack.offset.442, %local.suffix.selected.445
  %local.is.active.447 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.448 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.449 = select i1 %local.is.active.447, i32 %local.suffix.payload.448, i32 0
  %stack.offset.450 = add i32 %stack.offset.446, %local.suffix.selected.449
  %stack.offset.451 = add i32 0, 0
  %stack.offset.452 = add i32 %stack.offset.450, %stack.offset.451
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.438, i32 %stack.offset.420, i32 %stack.sub.423, i32 %stack.offset.452, i32 0, i32 14)
  %context.field.453 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.454 = load i32, ptr %context.field.453, align 4
  %runtime.ok.455 = icmp eq i32 %context.value.454, 0
  br i1 %runtime.ok.455, label %runtime.continue.456, label %frame.failure.0
runtime.continue.456:
  %stack.sub.457 = sub i32 %context.value.422, 8
  %stack.sub.458 = sub i32 %stack.sub.457, %local.old.extent.409
  %stack.offset.459 = add i32 %stack.sub.458, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.419, i32 %stack.offset.459, i32 8, i32 0, i32 4, i32 4)
  %context.field.460 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.461 = load i32, ptr %context.field.460, align 4
  %runtime.ok.462 = icmp eq i32 %context.value.461, 0
  br i1 %runtime.ok.462, label %runtime.continue.463, label %frame.failure.0
runtime.continue.463:
  %stack.sub.464 = sub i32 %context.value.422, %local.old.extent.409
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.464, i32 0, i32 0, i32 0)
  %context.field.465 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.466 = load i32, ptr %context.field.465, align 4
  %runtime.ok.467 = icmp eq i32 %context.value.466, 0
  br i1 %runtime.ok.467, label %runtime.continue.468, label %frame.failure.0
runtime.continue.468:
  %local.shrinks.469 = icmp ult i32 8, %local.old.extent.409
  br i1 %local.shrinks.469, label %local.shrink.470, label %local.counts.ready.471
local.shrink.470:
  %stack.sub.472 = sub i32 %local.old.extent.409, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.472)
  %context.field.473 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.474 = load i32, ptr %context.field.473, align 4
  %runtime.ok.475 = icmp eq i32 %context.value.474, 0
  br i1 %runtime.ok.475, label %runtime.continue.476, label %frame.failure.0
runtime.continue.476:
  br label %local.counts.ready.471
local.counts.ready.471:
  %local.payload.delta.477 = sub i32 0, %local.old.payload.410
  %stack.sub.478 = sub i32 0, %local.old.payload.410
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.478, i32 %local.payload.delta.477)
  %context.field.479 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.480 = load i32, ptr %context.field.479, align 4
  %runtime.ok.481 = icmp eq i32 %context.value.480, 0
  br i1 %runtime.ok.481, label %runtime.continue.482, label %frame.failure.0
runtime.continue.482:
  %local.is.active.483 = load i1, ptr %local.active.18, align 1
  %local.later.offset.484 = load i32, ptr %local.offset.19, align 4
  %stack.sub.485 = sub i32 %local.later.offset.484, %local.old.extent.409
  %stack.offset.486 = add i32 %stack.sub.485, 8
  %local.later.offset.selected.487 = select i1 %local.is.active.483, i32 %stack.offset.486, i32 %local.later.offset.484
  store i32 %local.later.offset.selected.487, ptr %local.offset.19, align 4
  %local.is.active.488 = load i1, ptr %local.active.23, align 1
  %local.later.offset.489 = load i32, ptr %local.offset.24, align 4
  %stack.sub.490 = sub i32 %local.later.offset.489, %local.old.extent.409
  %stack.offset.491 = add i32 %stack.sub.490, 8
  %local.later.offset.selected.492 = select i1 %local.is.active.488, i32 %stack.offset.491, i32 %local.later.offset.489
  store i32 %local.later.offset.selected.492, ptr %local.offset.24, align 4
  %local.is.active.493 = load i1, ptr %local.active.28, align 1
  %local.later.offset.494 = load i32, ptr %local.offset.29, align 4
  %stack.sub.495 = sub i32 %local.later.offset.494, %local.old.extent.409
  %stack.offset.496 = add i32 %stack.sub.495, 8
  %local.later.offset.selected.497 = select i1 %local.is.active.493, i32 %stack.offset.496, i32 %local.later.offset.494
  store i32 %local.later.offset.selected.497, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.419, ptr %local.offset.14, align 4
  store i32 8, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 4, ptr %local.type.17, align 4
  %local.is.active.498 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.499 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.500 = select i1 %local.is.active.498, i32 %local.sum.extent.499, i32 0
  %stack.offset.501 = add i32 0, %local.sum.selected.500
  %local.is.active.502 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.503 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.504 = select i1 %local.is.active.502, i32 %local.sum.extent.503, i32 0
  %stack.offset.505 = add i32 %stack.offset.501, %local.sum.selected.504
  %local.is.active.506 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.507 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.508 = select i1 %local.is.active.506, i32 %local.sum.extent.507, i32 0
  %stack.offset.509 = add i32 %stack.offset.505, %local.sum.selected.508
  %local.is.active.510 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.511 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.512 = select i1 %local.is.active.510, i32 %local.sum.extent.511, i32 0
  %stack.offset.513 = add i32 %stack.offset.509, %local.sum.selected.512
  %local.is.active.514 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.515 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.516 = select i1 %local.is.active.514, i32 %local.sum.extent.515, i32 0
  %stack.offset.517 = add i32 %stack.offset.513, %local.sum.selected.516
  %local.is.active.518 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.519 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.520 = select i1 %local.is.active.518, i32 %local.sum.extent.519, i32 0
  %stack.offset.521 = add i32 %stack.offset.517, %local.sum.selected.520
  %stack.offset.522 = add i32 %stack.offset.521, 0
  %stack.offset.523 = add i32 %context.value.45, %stack.offset.522
  %cursor.status.524 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.523)
  %cursor.ok.525 = icmp eq i32 %cursor.status.524, 0
  br i1 %cursor.ok.525, label %cursor.continue.526, label %frame.failure.0
cursor.continue.526:
  %step.status.527 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.528 = icmp eq i32 %step.status.527, 0
  br i1 %helper.ok.528, label %helper.continue.529, label %frame.failure.0
helper.continue.529:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %step.status.530 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.531 = icmp eq i32 %step.status.530, 0
  br i1 %helper.ok.531, label %helper.continue.532, label %frame.failure.0
helper.continue.532:
  %local.source.offset.533 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.534 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.535 = load i32, ptr %local.payload.16, align 4
  %context.field.536 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.537 = load i32, ptr %context.field.536, align 4
  %stack.offset.538 = add i32 %context.value.537, %local.source.extent.534
  %reserve.status.539 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.538, i32 20)
  %reserve.ok.540 = icmp eq i32 %reserve.status.539, 0
  br i1 %reserve.ok.540, label %reserve.continue.541, label %frame.failure.0
reserve.continue.541:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.537, i32 %local.source.offset.533, i32 %local.source.extent.534, i32 %local.source.payload.535, i32 4)
  %context.field.542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.543 = load i32, ptr %context.field.542, align 4
  %runtime.ok.544 = icmp eq i32 %context.value.543, 0
  br i1 %runtime.ok.544, label %runtime.continue.545, label %frame.failure.0
runtime.continue.545:
  %local.is.active.546 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.547 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.548 = select i1 %local.is.active.546, i32 %local.sum.extent.547, i32 0
  %stack.offset.549 = add i32 0, %local.sum.selected.548
  %local.is.active.550 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.551 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.552 = select i1 %local.is.active.550, i32 %local.sum.extent.551, i32 0
  %stack.offset.553 = add i32 %stack.offset.549, %local.sum.selected.552
  %local.is.active.554 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.555 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.556 = select i1 %local.is.active.554, i32 %local.sum.extent.555, i32 0
  %stack.offset.557 = add i32 %stack.offset.553, %local.sum.selected.556
  %local.is.active.558 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.559 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.560 = select i1 %local.is.active.558, i32 %local.sum.extent.559, i32 0
  %stack.offset.561 = add i32 %stack.offset.557, %local.sum.selected.560
  %local.is.active.562 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.563 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.564 = select i1 %local.is.active.562, i32 %local.sum.extent.563, i32 0
  %stack.offset.565 = add i32 %stack.offset.561, %local.sum.selected.564
  %local.is.active.566 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.567 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.568 = select i1 %local.is.active.566, i32 %local.sum.extent.567, i32 0
  %stack.offset.569 = add i32 %stack.offset.565, %local.sum.selected.568
  %stack.offset.570 = add i32 0, %local.source.extent.534
  %stack.offset.571 = add i32 %stack.offset.569, %stack.offset.570
  %stack.offset.572 = add i32 %context.value.45, %stack.offset.571
  %cursor.status.573 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.572)
  %cursor.ok.574 = icmp eq i32 %cursor.status.573, 0
  br i1 %cursor.ok.574, label %cursor.continue.575, label %frame.failure.0
cursor.continue.575:
  %step.status.576 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.577 = icmp eq i32 %step.status.576, 0
  br i1 %helper.ok.577, label %helper.continue.578, label %frame.failure.0
helper.continue.578:
  %local.is.active.579 = load i1, ptr %local.active.18, align 1
  %local.previous.extent.580 = load i32, ptr %local.extent.20, align 4
  %local.previous.payload.581 = load i32, ptr %local.payload.21, align 4
  %local.old.extent.582 = select i1 %local.is.active.579, i32 %local.previous.extent.580, i32 0
  %local.old.payload.583 = select i1 %local.is.active.579, i32 %local.previous.payload.581, i32 0
  %local.is.active.584 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.585 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.586 = select i1 %local.is.active.584, i32 %local.sum.extent.585, i32 0
  %stack.offset.587 = add i32 0, %local.sum.selected.586
  %local.is.active.588 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.589 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.590 = select i1 %local.is.active.588, i32 %local.sum.extent.589, i32 0
  %stack.offset.591 = add i32 %stack.offset.587, %local.sum.selected.590
  %local.is.active.592 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.593 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.594 = select i1 %local.is.active.592, i32 %local.sum.extent.593, i32 0
  %stack.offset.595 = add i32 %stack.offset.591, %local.sum.selected.594
  %stack.offset.596 = add i32 %context.value.45, %stack.offset.595
  %stack.offset.597 = add i32 %stack.offset.596, %local.old.extent.582
  %context.field.598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.599 = load i32, ptr %context.field.598, align 4
  %stack.sub.600 = sub i32 %context.value.599, %stack.offset.597
  %stack.sub.601 = sub i32 %context.value.599, %local.old.extent.582
  %stack.offset.602 = add i32 %stack.sub.601, %local.source.extent.534
  %local.grows.603 = icmp ugt i32 %local.source.extent.534, %local.old.extent.582
  br i1 %local.grows.603, label %local.grow.604, label %local.fixed.605
local.grow.604:
  %reserve.status.607 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.602, i32 22)
  %reserve.ok.608 = icmp eq i32 %reserve.status.607, 0
  br i1 %reserve.ok.608, label %reserve.continue.609, label %frame.failure.0
reserve.continue.609:
  %stack.sub.610 = sub i32 %local.source.extent.534, %local.old.extent.582
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.610)
  %context.field.611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.612 = load i32, ptr %context.field.611, align 4
  %runtime.ok.613 = icmp eq i32 %context.value.612, 0
  br i1 %runtime.ok.613, label %runtime.continue.614, label %frame.failure.0
runtime.continue.614:
  br label %local.layout.ready.606
local.fixed.605:
  br label %local.layout.ready.606
local.layout.ready.606:
  %stack.offset.615 = add i32 %stack.offset.596, %local.source.extent.534
  %local.is.active.616 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.617 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.618 = select i1 %local.is.active.616, i32 %local.suffix.payload.617, i32 0
  %stack.offset.619 = add i32 0, %local.suffix.selected.618
  %local.is.active.620 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.621 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.622 = select i1 %local.is.active.620, i32 %local.suffix.payload.621, i32 0
  %stack.offset.623 = add i32 %stack.offset.619, %local.suffix.selected.622
  %stack.offset.624 = add i32 0, %local.source.payload.535
  %stack.offset.625 = add i32 %stack.offset.623, %stack.offset.624
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.615, i32 %stack.offset.597, i32 %stack.sub.600, i32 %stack.offset.625, i32 0, i32 14)
  %context.field.626 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.627 = load i32, ptr %context.field.626, align 4
  %runtime.ok.628 = icmp eq i32 %context.value.627, 0
  br i1 %runtime.ok.628, label %runtime.continue.629, label %frame.failure.0
runtime.continue.629:
  %stack.sub.630 = sub i32 %context.value.599, %local.source.extent.534
  %stack.sub.631 = sub i32 %stack.sub.630, %local.old.extent.582
  %stack.offset.632 = add i32 %stack.sub.631, %local.source.extent.534
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.596, i32 %stack.offset.632, i32 %local.source.extent.534, i32 %local.source.payload.535, i32 4, i32 4)
  %context.field.633 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.634 = load i32, ptr %context.field.633, align 4
  %runtime.ok.635 = icmp eq i32 %context.value.634, 0
  br i1 %runtime.ok.635, label %runtime.continue.636, label %frame.failure.0
runtime.continue.636:
  %stack.sub.637 = sub i32 %context.value.599, %local.old.extent.582
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.637, i32 0, i32 0, i32 0)
  %context.field.638 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.639 = load i32, ptr %context.field.638, align 4
  %runtime.ok.640 = icmp eq i32 %context.value.639, 0
  br i1 %runtime.ok.640, label %runtime.continue.641, label %frame.failure.0
runtime.continue.641:
  %local.shrinks.642 = icmp ult i32 %local.source.extent.534, %local.old.extent.582
  br i1 %local.shrinks.642, label %local.shrink.643, label %local.counts.ready.644
local.shrink.643:
  %stack.sub.645 = sub i32 %local.old.extent.582, %local.source.extent.534
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.645)
  %context.field.646 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.647 = load i32, ptr %context.field.646, align 4
  %runtime.ok.648 = icmp eq i32 %context.value.647, 0
  br i1 %runtime.ok.648, label %runtime.continue.649, label %frame.failure.0
runtime.continue.649:
  br label %local.counts.ready.644
local.counts.ready.644:
  %local.payload.delta.650 = sub i32 %local.source.payload.535, %local.old.payload.583
  %stack.sub.651 = sub i32 0, %local.old.payload.583
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.651, i32 %local.payload.delta.650)
  %context.field.652 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.653 = load i32, ptr %context.field.652, align 4
  %runtime.ok.654 = icmp eq i32 %context.value.653, 0
  br i1 %runtime.ok.654, label %runtime.continue.655, label %frame.failure.0
runtime.continue.655:
  %local.is.active.656 = load i1, ptr %local.active.23, align 1
  %local.later.offset.657 = load i32, ptr %local.offset.24, align 4
  %stack.sub.658 = sub i32 %local.later.offset.657, %local.old.extent.582
  %stack.offset.659 = add i32 %stack.sub.658, %local.source.extent.534
  %local.later.offset.selected.660 = select i1 %local.is.active.656, i32 %stack.offset.659, i32 %local.later.offset.657
  store i32 %local.later.offset.selected.660, ptr %local.offset.24, align 4
  %local.is.active.661 = load i1, ptr %local.active.28, align 1
  %local.later.offset.662 = load i32, ptr %local.offset.29, align 4
  %stack.sub.663 = sub i32 %local.later.offset.662, %local.old.extent.582
  %stack.offset.664 = add i32 %stack.sub.663, %local.source.extent.534
  %local.later.offset.selected.665 = select i1 %local.is.active.661, i32 %stack.offset.664, i32 %local.later.offset.662
  store i32 %local.later.offset.selected.665, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.18, align 1
  store i32 %stack.offset.596, ptr %local.offset.19, align 4
  store i32 %local.source.extent.534, ptr %local.extent.20, align 4
  store i32 %local.source.payload.535, ptr %local.payload.21, align 4
  store i32 4, ptr %local.type.22, align 4
  %local.is.active.666 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.667 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.668 = select i1 %local.is.active.666, i32 %local.sum.extent.667, i32 0
  %stack.offset.669 = add i32 0, %local.sum.selected.668
  %local.is.active.670 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.671 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.672 = select i1 %local.is.active.670, i32 %local.sum.extent.671, i32 0
  %stack.offset.673 = add i32 %stack.offset.669, %local.sum.selected.672
  %local.is.active.674 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.675 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.676 = select i1 %local.is.active.674, i32 %local.sum.extent.675, i32 0
  %stack.offset.677 = add i32 %stack.offset.673, %local.sum.selected.676
  %local.is.active.678 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.679 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.680 = select i1 %local.is.active.678, i32 %local.sum.extent.679, i32 0
  %stack.offset.681 = add i32 %stack.offset.677, %local.sum.selected.680
  %local.is.active.682 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.683 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.684 = select i1 %local.is.active.682, i32 %local.sum.extent.683, i32 0
  %stack.offset.685 = add i32 %stack.offset.681, %local.sum.selected.684
  %local.is.active.686 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.687 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.688 = select i1 %local.is.active.686, i32 %local.sum.extent.687, i32 0
  %stack.offset.689 = add i32 %stack.offset.685, %local.sum.selected.688
  %stack.offset.690 = add i32 %stack.offset.689, 0
  %stack.offset.691 = add i32 %context.value.45, %stack.offset.690
  %cursor.status.692 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.691)
  %cursor.ok.693 = icmp eq i32 %cursor.status.692, 0
  br i1 %cursor.ok.693, label %cursor.continue.694, label %frame.failure.0
cursor.continue.694:
  %step.status.695 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.696 = icmp eq i32 %step.status.695, 0
  br i1 %helper.ok.696, label %helper.continue.697, label %frame.failure.0
helper.continue.697:
  %local.source.offset.698 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.699 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.700 = load i32, ptr %local.payload.11, align 4
  %context.field.701 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.702 = load i32, ptr %context.field.701, align 4
  %stack.offset.703 = add i32 %context.value.702, %local.source.extent.699
  %reserve.status.704 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.703, i32 24)
  %reserve.ok.705 = icmp eq i32 %reserve.status.704, 0
  br i1 %reserve.ok.705, label %reserve.continue.706, label %frame.failure.0
reserve.continue.706:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.702, i32 %local.source.offset.698, i32 %local.source.extent.699, i32 %local.source.payload.700, i32 12)
  %context.field.707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.708 = load i32, ptr %context.field.707, align 4
  %runtime.ok.709 = icmp eq i32 %context.value.708, 0
  br i1 %runtime.ok.709, label %runtime.continue.710, label %frame.failure.0
runtime.continue.710:
  %local.is.active.711 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.712 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.713 = select i1 %local.is.active.711, i32 %local.sum.extent.712, i32 0
  %stack.offset.714 = add i32 0, %local.sum.selected.713
  %local.is.active.715 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.716 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.717 = select i1 %local.is.active.715, i32 %local.sum.extent.716, i32 0
  %stack.offset.718 = add i32 %stack.offset.714, %local.sum.selected.717
  %local.is.active.719 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.720 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.721 = select i1 %local.is.active.719, i32 %local.sum.extent.720, i32 0
  %stack.offset.722 = add i32 %stack.offset.718, %local.sum.selected.721
  %local.is.active.723 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.724 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.725 = select i1 %local.is.active.723, i32 %local.sum.extent.724, i32 0
  %stack.offset.726 = add i32 %stack.offset.722, %local.sum.selected.725
  %local.is.active.727 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.728 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.729 = select i1 %local.is.active.727, i32 %local.sum.extent.728, i32 0
  %stack.offset.730 = add i32 %stack.offset.726, %local.sum.selected.729
  %local.is.active.731 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.732 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.733 = select i1 %local.is.active.731, i32 %local.sum.extent.732, i32 0
  %stack.offset.734 = add i32 %stack.offset.730, %local.sum.selected.733
  %stack.offset.735 = add i32 0, %local.source.extent.699
  %stack.offset.736 = add i32 %stack.offset.734, %stack.offset.735
  %stack.offset.737 = add i32 %context.value.45, %stack.offset.736
  %cursor.status.738 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.737)
  %cursor.ok.739 = icmp eq i32 %cursor.status.738, 0
  br i1 %cursor.ok.739, label %cursor.continue.740, label %frame.failure.0
cursor.continue.740:
  %step.status.741 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.742 = icmp eq i32 %step.status.741, 0
  br i1 %helper.ok.742, label %helper.continue.743, label %frame.failure.0
helper.continue.743:
  %local.is.active.744 = load i1, ptr %local.active.23, align 1
  %local.previous.extent.745 = load i32, ptr %local.extent.25, align 4
  %local.previous.payload.746 = load i32, ptr %local.payload.26, align 4
  %local.old.extent.747 = select i1 %local.is.active.744, i32 %local.previous.extent.745, i32 0
  %local.old.payload.748 = select i1 %local.is.active.744, i32 %local.previous.payload.746, i32 0
  %local.is.active.749 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.750 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.751 = select i1 %local.is.active.749, i32 %local.sum.extent.750, i32 0
  %stack.offset.752 = add i32 0, %local.sum.selected.751
  %local.is.active.753 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.754 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.755 = select i1 %local.is.active.753, i32 %local.sum.extent.754, i32 0
  %stack.offset.756 = add i32 %stack.offset.752, %local.sum.selected.755
  %local.is.active.757 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.758 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.759 = select i1 %local.is.active.757, i32 %local.sum.extent.758, i32 0
  %stack.offset.760 = add i32 %stack.offset.756, %local.sum.selected.759
  %local.is.active.761 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.762 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.763 = select i1 %local.is.active.761, i32 %local.sum.extent.762, i32 0
  %stack.offset.764 = add i32 %stack.offset.760, %local.sum.selected.763
  %stack.offset.765 = add i32 %context.value.45, %stack.offset.764
  %stack.offset.766 = add i32 %stack.offset.765, %local.old.extent.747
  %context.field.767 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.768 = load i32, ptr %context.field.767, align 4
  %stack.sub.769 = sub i32 %context.value.768, %stack.offset.766
  %stack.sub.770 = sub i32 %context.value.768, %local.old.extent.747
  %stack.offset.771 = add i32 %stack.sub.770, %local.source.extent.699
  %local.grows.772 = icmp ugt i32 %local.source.extent.699, %local.old.extent.747
  br i1 %local.grows.772, label %local.grow.773, label %local.fixed.774
local.grow.773:
  %reserve.status.776 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.771, i32 26)
  %reserve.ok.777 = icmp eq i32 %reserve.status.776, 0
  br i1 %reserve.ok.777, label %reserve.continue.778, label %frame.failure.0
reserve.continue.778:
  %stack.sub.779 = sub i32 %local.source.extent.699, %local.old.extent.747
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.779)
  %context.field.780 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.781 = load i32, ptr %context.field.780, align 4
  %runtime.ok.782 = icmp eq i32 %context.value.781, 0
  br i1 %runtime.ok.782, label %runtime.continue.783, label %frame.failure.0
runtime.continue.783:
  br label %local.layout.ready.775
local.fixed.774:
  br label %local.layout.ready.775
local.layout.ready.775:
  %stack.offset.784 = add i32 %stack.offset.765, %local.source.extent.699
  %local.is.active.785 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.786 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.787 = select i1 %local.is.active.785, i32 %local.suffix.payload.786, i32 0
  %stack.offset.788 = add i32 0, %local.suffix.selected.787
  %stack.offset.789 = add i32 0, %local.source.payload.700
  %stack.offset.790 = add i32 %stack.offset.788, %stack.offset.789
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.784, i32 %stack.offset.766, i32 %stack.sub.769, i32 %stack.offset.790, i32 0, i32 14)
  %context.field.791 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.792 = load i32, ptr %context.field.791, align 4
  %runtime.ok.793 = icmp eq i32 %context.value.792, 0
  br i1 %runtime.ok.793, label %runtime.continue.794, label %frame.failure.0
runtime.continue.794:
  %stack.sub.795 = sub i32 %context.value.768, %local.source.extent.699
  %stack.sub.796 = sub i32 %stack.sub.795, %local.old.extent.747
  %stack.offset.797 = add i32 %stack.sub.796, %local.source.extent.699
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.765, i32 %stack.offset.797, i32 %local.source.extent.699, i32 %local.source.payload.700, i32 12, i32 4)
  %context.field.798 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.799 = load i32, ptr %context.field.798, align 4
  %runtime.ok.800 = icmp eq i32 %context.value.799, 0
  br i1 %runtime.ok.800, label %runtime.continue.801, label %frame.failure.0
runtime.continue.801:
  %stack.sub.802 = sub i32 %context.value.768, %local.old.extent.747
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.802, i32 0, i32 0, i32 0)
  %context.field.803 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.804 = load i32, ptr %context.field.803, align 4
  %runtime.ok.805 = icmp eq i32 %context.value.804, 0
  br i1 %runtime.ok.805, label %runtime.continue.806, label %frame.failure.0
runtime.continue.806:
  %local.shrinks.807 = icmp ult i32 %local.source.extent.699, %local.old.extent.747
  br i1 %local.shrinks.807, label %local.shrink.808, label %local.counts.ready.809
local.shrink.808:
  %stack.sub.810 = sub i32 %local.old.extent.747, %local.source.extent.699
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.810)
  %context.field.811 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.812 = load i32, ptr %context.field.811, align 4
  %runtime.ok.813 = icmp eq i32 %context.value.812, 0
  br i1 %runtime.ok.813, label %runtime.continue.814, label %frame.failure.0
runtime.continue.814:
  br label %local.counts.ready.809
local.counts.ready.809:
  %local.payload.delta.815 = sub i32 %local.source.payload.700, %local.old.payload.748
  %stack.sub.816 = sub i32 0, %local.old.payload.748
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.816, i32 %local.payload.delta.815)
  %context.field.817 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.818 = load i32, ptr %context.field.817, align 4
  %runtime.ok.819 = icmp eq i32 %context.value.818, 0
  br i1 %runtime.ok.819, label %runtime.continue.820, label %frame.failure.0
runtime.continue.820:
  %local.is.active.821 = load i1, ptr %local.active.28, align 1
  %local.later.offset.822 = load i32, ptr %local.offset.29, align 4
  %stack.sub.823 = sub i32 %local.later.offset.822, %local.old.extent.747
  %stack.offset.824 = add i32 %stack.sub.823, %local.source.extent.699
  %local.later.offset.selected.825 = select i1 %local.is.active.821, i32 %stack.offset.824, i32 %local.later.offset.822
  store i32 %local.later.offset.selected.825, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.23, align 1
  store i32 %stack.offset.765, ptr %local.offset.24, align 4
  store i32 %local.source.extent.699, ptr %local.extent.25, align 4
  store i32 %local.source.payload.700, ptr %local.payload.26, align 4
  store i32 12, ptr %local.type.27, align 4
  %local.is.active.826 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.827 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.828 = select i1 %local.is.active.826, i32 %local.sum.extent.827, i32 0
  %stack.offset.829 = add i32 0, %local.sum.selected.828
  %local.is.active.830 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.831 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.832 = select i1 %local.is.active.830, i32 %local.sum.extent.831, i32 0
  %stack.offset.833 = add i32 %stack.offset.829, %local.sum.selected.832
  %local.is.active.834 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.835 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.836 = select i1 %local.is.active.834, i32 %local.sum.extent.835, i32 0
  %stack.offset.837 = add i32 %stack.offset.833, %local.sum.selected.836
  %local.is.active.838 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.839 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.840 = select i1 %local.is.active.838, i32 %local.sum.extent.839, i32 0
  %stack.offset.841 = add i32 %stack.offset.837, %local.sum.selected.840
  %local.is.active.842 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.843 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.844 = select i1 %local.is.active.842, i32 %local.sum.extent.843, i32 0
  %stack.offset.845 = add i32 %stack.offset.841, %local.sum.selected.844
  %local.is.active.846 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.847 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.848 = select i1 %local.is.active.846, i32 %local.sum.extent.847, i32 0
  %stack.offset.849 = add i32 %stack.offset.845, %local.sum.selected.848
  %stack.offset.850 = add i32 %stack.offset.849, 0
  %stack.offset.851 = add i32 %context.value.45, %stack.offset.850
  %cursor.status.852 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.851)
  %cursor.ok.853 = icmp eq i32 %cursor.status.852, 0
  br i1 %cursor.ok.853, label %cursor.continue.854, label %frame.failure.0
cursor.continue.854:
  %step.status.855 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.856 = icmp eq i32 %step.status.855, 0
  br i1 %helper.ok.856, label %helper.continue.857, label %frame.failure.0
helper.continue.857:
  %local.source.offset.858 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.859 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.860 = load i32, ptr %local.payload.6, align 4
  %context.field.861 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.862 = load i32, ptr %context.field.861, align 4
  %stack.offset.863 = add i32 %context.value.862, %local.source.extent.859
  %reserve.status.864 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.863, i32 28)
  %reserve.ok.865 = icmp eq i32 %reserve.status.864, 0
  br i1 %reserve.ok.865, label %reserve.continue.866, label %frame.failure.0
reserve.continue.866:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.862, i32 %local.source.offset.858, i32 %local.source.extent.859, i32 %local.source.payload.860, i32 1)
  %context.field.867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.868 = load i32, ptr %context.field.867, align 4
  %runtime.ok.869 = icmp eq i32 %context.value.868, 0
  br i1 %runtime.ok.869, label %runtime.continue.870, label %frame.failure.0
runtime.continue.870:
  %local.is.active.871 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.872 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.873 = select i1 %local.is.active.871, i32 %local.sum.extent.872, i32 0
  %stack.offset.874 = add i32 0, %local.sum.selected.873
  %local.is.active.875 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.876 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.877 = select i1 %local.is.active.875, i32 %local.sum.extent.876, i32 0
  %stack.offset.878 = add i32 %stack.offset.874, %local.sum.selected.877
  %local.is.active.879 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.880 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.881 = select i1 %local.is.active.879, i32 %local.sum.extent.880, i32 0
  %stack.offset.882 = add i32 %stack.offset.878, %local.sum.selected.881
  %local.is.active.883 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.884 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.885 = select i1 %local.is.active.883, i32 %local.sum.extent.884, i32 0
  %stack.offset.886 = add i32 %stack.offset.882, %local.sum.selected.885
  %local.is.active.887 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.888 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.889 = select i1 %local.is.active.887, i32 %local.sum.extent.888, i32 0
  %stack.offset.890 = add i32 %stack.offset.886, %local.sum.selected.889
  %local.is.active.891 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.892 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.893 = select i1 %local.is.active.891, i32 %local.sum.extent.892, i32 0
  %stack.offset.894 = add i32 %stack.offset.890, %local.sum.selected.893
  %stack.offset.895 = add i32 0, %local.source.extent.859
  %stack.offset.896 = add i32 %stack.offset.894, %stack.offset.895
  %stack.offset.897 = add i32 %context.value.45, %stack.offset.896
  %cursor.status.898 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.897)
  %cursor.ok.899 = icmp eq i32 %cursor.status.898, 0
  br i1 %cursor.ok.899, label %cursor.continue.900, label %frame.failure.0
cursor.continue.900:
  %step.status.901 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.902 = icmp eq i32 %step.status.901, 0
  br i1 %helper.ok.902, label %helper.continue.903, label %frame.failure.0
helper.continue.903:
  %local.is.active.904 = load i1, ptr %local.active.28, align 1
  %local.previous.extent.905 = load i32, ptr %local.extent.30, align 4
  %local.previous.payload.906 = load i32, ptr %local.payload.31, align 4
  %local.old.extent.907 = select i1 %local.is.active.904, i32 %local.previous.extent.905, i32 0
  %local.old.payload.908 = select i1 %local.is.active.904, i32 %local.previous.payload.906, i32 0
  %local.is.active.909 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.910 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.911 = select i1 %local.is.active.909, i32 %local.sum.extent.910, i32 0
  %stack.offset.912 = add i32 0, %local.sum.selected.911
  %local.is.active.913 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.914 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.915 = select i1 %local.is.active.913, i32 %local.sum.extent.914, i32 0
  %stack.offset.916 = add i32 %stack.offset.912, %local.sum.selected.915
  %local.is.active.917 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.918 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.919 = select i1 %local.is.active.917, i32 %local.sum.extent.918, i32 0
  %stack.offset.920 = add i32 %stack.offset.916, %local.sum.selected.919
  %local.is.active.921 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.922 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.923 = select i1 %local.is.active.921, i32 %local.sum.extent.922, i32 0
  %stack.offset.924 = add i32 %stack.offset.920, %local.sum.selected.923
  %local.is.active.925 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.926 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.927 = select i1 %local.is.active.925, i32 %local.sum.extent.926, i32 0
  %stack.offset.928 = add i32 %stack.offset.924, %local.sum.selected.927
  %stack.offset.929 = add i32 %context.value.45, %stack.offset.928
  %stack.offset.930 = add i32 %stack.offset.929, %local.old.extent.907
  %context.field.931 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.932 = load i32, ptr %context.field.931, align 4
  %stack.sub.933 = sub i32 %context.value.932, %stack.offset.930
  %stack.sub.934 = sub i32 %context.value.932, %local.old.extent.907
  %stack.offset.935 = add i32 %stack.sub.934, %local.source.extent.859
  %local.grows.936 = icmp ugt i32 %local.source.extent.859, %local.old.extent.907
  br i1 %local.grows.936, label %local.grow.937, label %local.fixed.938
local.grow.937:
  %reserve.status.940 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.935, i32 30)
  %reserve.ok.941 = icmp eq i32 %reserve.status.940, 0
  br i1 %reserve.ok.941, label %reserve.continue.942, label %frame.failure.0
reserve.continue.942:
  %stack.sub.943 = sub i32 %local.source.extent.859, %local.old.extent.907
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.943)
  %context.field.944 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.945 = load i32, ptr %context.field.944, align 4
  %runtime.ok.946 = icmp eq i32 %context.value.945, 0
  br i1 %runtime.ok.946, label %runtime.continue.947, label %frame.failure.0
runtime.continue.947:
  br label %local.layout.ready.939
local.fixed.938:
  br label %local.layout.ready.939
local.layout.ready.939:
  %stack.offset.948 = add i32 %stack.offset.929, %local.source.extent.859
  %stack.offset.949 = add i32 0, %local.source.payload.860
  %stack.offset.950 = add i32 0, %stack.offset.949
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.948, i32 %stack.offset.930, i32 %stack.sub.933, i32 %stack.offset.950, i32 0, i32 14)
  %context.field.951 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.952 = load i32, ptr %context.field.951, align 4
  %runtime.ok.953 = icmp eq i32 %context.value.952, 0
  br i1 %runtime.ok.953, label %runtime.continue.954, label %frame.failure.0
runtime.continue.954:
  %stack.sub.955 = sub i32 %context.value.932, %local.source.extent.859
  %stack.sub.956 = sub i32 %stack.sub.955, %local.old.extent.907
  %stack.offset.957 = add i32 %stack.sub.956, %local.source.extent.859
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.929, i32 %stack.offset.957, i32 %local.source.extent.859, i32 %local.source.payload.860, i32 1, i32 4)
  %context.field.958 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.959 = load i32, ptr %context.field.958, align 4
  %runtime.ok.960 = icmp eq i32 %context.value.959, 0
  br i1 %runtime.ok.960, label %runtime.continue.961, label %frame.failure.0
runtime.continue.961:
  %stack.sub.962 = sub i32 %context.value.932, %local.old.extent.907
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.962, i32 0, i32 0, i32 0)
  %context.field.963 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.964 = load i32, ptr %context.field.963, align 4
  %runtime.ok.965 = icmp eq i32 %context.value.964, 0
  br i1 %runtime.ok.965, label %runtime.continue.966, label %frame.failure.0
runtime.continue.966:
  %local.shrinks.967 = icmp ult i32 %local.source.extent.859, %local.old.extent.907
  br i1 %local.shrinks.967, label %local.shrink.968, label %local.counts.ready.969
local.shrink.968:
  %stack.sub.970 = sub i32 %local.old.extent.907, %local.source.extent.859
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.970)
  %context.field.971 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.972 = load i32, ptr %context.field.971, align 4
  %runtime.ok.973 = icmp eq i32 %context.value.972, 0
  br i1 %runtime.ok.973, label %runtime.continue.974, label %frame.failure.0
runtime.continue.974:
  br label %local.counts.ready.969
local.counts.ready.969:
  %local.payload.delta.975 = sub i32 %local.source.payload.860, %local.old.payload.908
  %stack.sub.976 = sub i32 0, %local.old.payload.908
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.976, i32 %local.payload.delta.975)
  %context.field.977 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.978 = load i32, ptr %context.field.977, align 4
  %runtime.ok.979 = icmp eq i32 %context.value.978, 0
  br i1 %runtime.ok.979, label %runtime.continue.980, label %frame.failure.0
runtime.continue.980:
  store i1 true, ptr %local.active.28, align 1
  store i32 %stack.offset.929, ptr %local.offset.29, align 4
  store i32 %local.source.extent.859, ptr %local.extent.30, align 4
  store i32 %local.source.payload.860, ptr %local.payload.31, align 4
  store i32 1, ptr %local.type.32, align 4
  %local.is.active.981 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.982 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.983 = select i1 %local.is.active.981, i32 %local.sum.extent.982, i32 0
  %stack.offset.984 = add i32 0, %local.sum.selected.983
  %local.is.active.985 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.986 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.987 = select i1 %local.is.active.985, i32 %local.sum.extent.986, i32 0
  %stack.offset.988 = add i32 %stack.offset.984, %local.sum.selected.987
  %local.is.active.989 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.990 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.991 = select i1 %local.is.active.989, i32 %local.sum.extent.990, i32 0
  %stack.offset.992 = add i32 %stack.offset.988, %local.sum.selected.991
  %local.is.active.993 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.994 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.995 = select i1 %local.is.active.993, i32 %local.sum.extent.994, i32 0
  %stack.offset.996 = add i32 %stack.offset.992, %local.sum.selected.995
  %local.is.active.997 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.998 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.999 = select i1 %local.is.active.997, i32 %local.sum.extent.998, i32 0
  %stack.offset.1000 = add i32 %stack.offset.996, %local.sum.selected.999
  %local.is.active.1001 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1002 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1003 = select i1 %local.is.active.1001, i32 %local.sum.extent.1002, i32 0
  %stack.offset.1004 = add i32 %stack.offset.1000, %local.sum.selected.1003
  %stack.offset.1005 = add i32 %stack.offset.1004, 0
  %stack.offset.1006 = add i32 %context.value.45, %stack.offset.1005
  %cursor.status.1007 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1006)
  %cursor.ok.1008 = icmp eq i32 %cursor.status.1007, 0
  br i1 %cursor.ok.1008, label %cursor.continue.1009, label %frame.failure.0
cursor.continue.1009:
  %step.status.1010 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %helper.ok.1011 = icmp eq i32 %step.status.1010, 0
  br i1 %helper.ok.1011, label %helper.continue.1012, label %frame.failure.0
helper.continue.1012:
  %local.source.offset.1013 = load i32, ptr %local.offset.19, align 4
  %local.source.extent.1014 = load i32, ptr %local.extent.20, align 4
  %local.source.payload.1015 = load i32, ptr %local.payload.21, align 4
  %context.field.1016 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1017 = load i32, ptr %context.field.1016, align 4
  %stack.offset.1018 = add i32 %context.value.1017, %local.source.extent.1014
  %reserve.status.1019 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1018, i32 32)
  %reserve.ok.1020 = icmp eq i32 %reserve.status.1019, 0
  br i1 %reserve.ok.1020, label %reserve.continue.1021, label %frame.failure.0
reserve.continue.1021:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1017, i32 %local.source.offset.1013, i32 %local.source.extent.1014, i32 %local.source.payload.1015, i32 4)
  %context.field.1022 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1023 = load i32, ptr %context.field.1022, align 4
  %runtime.ok.1024 = icmp eq i32 %context.value.1023, 0
  br i1 %runtime.ok.1024, label %runtime.continue.1025, label %frame.failure.0
runtime.continue.1025:
  %local.is.active.1026 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1027 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1028 = select i1 %local.is.active.1026, i32 %local.sum.extent.1027, i32 0
  %stack.offset.1029 = add i32 0, %local.sum.selected.1028
  %local.is.active.1030 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1031 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1032 = select i1 %local.is.active.1030, i32 %local.sum.extent.1031, i32 0
  %stack.offset.1033 = add i32 %stack.offset.1029, %local.sum.selected.1032
  %local.is.active.1034 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1035 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1036 = select i1 %local.is.active.1034, i32 %local.sum.extent.1035, i32 0
  %stack.offset.1037 = add i32 %stack.offset.1033, %local.sum.selected.1036
  %local.is.active.1038 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1039 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1040 = select i1 %local.is.active.1038, i32 %local.sum.extent.1039, i32 0
  %stack.offset.1041 = add i32 %stack.offset.1037, %local.sum.selected.1040
  %local.is.active.1042 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1043 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1044 = select i1 %local.is.active.1042, i32 %local.sum.extent.1043, i32 0
  %stack.offset.1045 = add i32 %stack.offset.1041, %local.sum.selected.1044
  %local.is.active.1046 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1047 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1048 = select i1 %local.is.active.1046, i32 %local.sum.extent.1047, i32 0
  %stack.offset.1049 = add i32 %stack.offset.1045, %local.sum.selected.1048
  %stack.offset.1050 = add i32 0, %local.source.extent.1014
  %stack.offset.1051 = add i32 %stack.offset.1049, %stack.offset.1050
  %stack.offset.1052 = add i32 %context.value.45, %stack.offset.1051
  %cursor.status.1053 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1052)
  %cursor.ok.1054 = icmp eq i32 %cursor.status.1053, 0
  br i1 %cursor.ok.1054, label %cursor.continue.1055, label %frame.failure.0
cursor.continue.1055:
  %step.status.1056 = call i32 @al_owning_charge_step(ptr %ctx, i32 33)
  %helper.ok.1057 = icmp eq i32 %step.status.1056, 0
  br i1 %helper.ok.1057, label %helper.continue.1058, label %frame.failure.0
helper.continue.1058:
  %local.source.offset.1059 = load i32, ptr %local.offset.24, align 4
  %local.source.extent.1060 = load i32, ptr %local.extent.25, align 4
  %local.source.payload.1061 = load i32, ptr %local.payload.26, align 4
  %context.field.1062 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1063 = load i32, ptr %context.field.1062, align 4
  %stack.offset.1064 = add i32 %context.value.1063, %local.source.extent.1060
  %reserve.status.1065 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1064, i32 34)
  %reserve.ok.1066 = icmp eq i32 %reserve.status.1065, 0
  br i1 %reserve.ok.1066, label %reserve.continue.1067, label %frame.failure.0
reserve.continue.1067:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1063, i32 %local.source.offset.1059, i32 %local.source.extent.1060, i32 %local.source.payload.1061, i32 12)
  %context.field.1068 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1069 = load i32, ptr %context.field.1068, align 4
  %runtime.ok.1070 = icmp eq i32 %context.value.1069, 0
  br i1 %runtime.ok.1070, label %runtime.continue.1071, label %frame.failure.0
runtime.continue.1071:
  %local.is.active.1072 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1073 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1074 = select i1 %local.is.active.1072, i32 %local.sum.extent.1073, i32 0
  %stack.offset.1075 = add i32 0, %local.sum.selected.1074
  %local.is.active.1076 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1077 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1078 = select i1 %local.is.active.1076, i32 %local.sum.extent.1077, i32 0
  %stack.offset.1079 = add i32 %stack.offset.1075, %local.sum.selected.1078
  %local.is.active.1080 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1081 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1082 = select i1 %local.is.active.1080, i32 %local.sum.extent.1081, i32 0
  %stack.offset.1083 = add i32 %stack.offset.1079, %local.sum.selected.1082
  %local.is.active.1084 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1085 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1086 = select i1 %local.is.active.1084, i32 %local.sum.extent.1085, i32 0
  %stack.offset.1087 = add i32 %stack.offset.1083, %local.sum.selected.1086
  %local.is.active.1088 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1089 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1090 = select i1 %local.is.active.1088, i32 %local.sum.extent.1089, i32 0
  %stack.offset.1091 = add i32 %stack.offset.1087, %local.sum.selected.1090
  %local.is.active.1092 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1093 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1094 = select i1 %local.is.active.1092, i32 %local.sum.extent.1093, i32 0
  %stack.offset.1095 = add i32 %stack.offset.1091, %local.sum.selected.1094
  %stack.offset.1096 = add i32 0, %local.source.extent.1014
  %stack.offset.1097 = add i32 %stack.offset.1096, %local.source.extent.1060
  %stack.offset.1098 = add i32 %stack.offset.1095, %stack.offset.1097
  %stack.offset.1099 = add i32 %context.value.45, %stack.offset.1098
  %cursor.status.1100 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1099)
  %cursor.ok.1101 = icmp eq i32 %cursor.status.1100, 0
  br i1 %cursor.ok.1101, label %cursor.continue.1102, label %frame.failure.0
cursor.continue.1102:
  %step.status.1103 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.1104 = icmp eq i32 %step.status.1103, 0
  br i1 %helper.ok.1104, label %helper.continue.1105, label %frame.failure.0
helper.continue.1105:
  %local.source.offset.1106 = load i32, ptr %local.offset.29, align 4
  %local.source.extent.1107 = load i32, ptr %local.extent.30, align 4
  %local.source.payload.1108 = load i32, ptr %local.payload.31, align 4
  %context.field.1109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1110 = load i32, ptr %context.field.1109, align 4
  %stack.offset.1111 = add i32 %context.value.1110, %local.source.extent.1107
  %reserve.status.1112 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1111, i32 36)
  %reserve.ok.1113 = icmp eq i32 %reserve.status.1112, 0
  br i1 %reserve.ok.1113, label %reserve.continue.1114, label %frame.failure.0
reserve.continue.1114:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1110, i32 %local.source.offset.1106, i32 %local.source.extent.1107, i32 %local.source.payload.1108, i32 1)
  %context.field.1115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1116 = load i32, ptr %context.field.1115, align 4
  %runtime.ok.1117 = icmp eq i32 %context.value.1116, 0
  br i1 %runtime.ok.1117, label %runtime.continue.1118, label %frame.failure.0
runtime.continue.1118:
  %local.is.active.1119 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1120 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1121 = select i1 %local.is.active.1119, i32 %local.sum.extent.1120, i32 0
  %stack.offset.1122 = add i32 0, %local.sum.selected.1121
  %local.is.active.1123 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1124 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1125 = select i1 %local.is.active.1123, i32 %local.sum.extent.1124, i32 0
  %stack.offset.1126 = add i32 %stack.offset.1122, %local.sum.selected.1125
  %local.is.active.1127 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1128 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1129 = select i1 %local.is.active.1127, i32 %local.sum.extent.1128, i32 0
  %stack.offset.1130 = add i32 %stack.offset.1126, %local.sum.selected.1129
  %local.is.active.1131 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1132 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1133 = select i1 %local.is.active.1131, i32 %local.sum.extent.1132, i32 0
  %stack.offset.1134 = add i32 %stack.offset.1130, %local.sum.selected.1133
  %local.is.active.1135 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1136 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1137 = select i1 %local.is.active.1135, i32 %local.sum.extent.1136, i32 0
  %stack.offset.1138 = add i32 %stack.offset.1134, %local.sum.selected.1137
  %local.is.active.1139 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1140 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1141 = select i1 %local.is.active.1139, i32 %local.sum.extent.1140, i32 0
  %stack.offset.1142 = add i32 %stack.offset.1138, %local.sum.selected.1141
  %stack.offset.1143 = add i32 0, %local.source.extent.1014
  %stack.offset.1144 = add i32 %stack.offset.1143, %local.source.extent.1060
  %stack.offset.1145 = add i32 %stack.offset.1144, %local.source.extent.1107
  %stack.offset.1146 = add i32 %stack.offset.1142, %stack.offset.1145
  %stack.offset.1147 = add i32 %context.value.45, %stack.offset.1146
  %cursor.status.1148 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1147)
  %cursor.ok.1149 = icmp eq i32 %cursor.status.1148, 0
  br i1 %cursor.ok.1149, label %cursor.continue.1150, label %frame.failure.0
cursor.continue.1150:
  %step.status.1151 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %helper.ok.1152 = icmp eq i32 %step.status.1151, 0
  br i1 %helper.ok.1152, label %helper.continue.1153, label %frame.failure.0
helper.continue.1153:
  %stack.offset.1154 = add i32 0, %local.source.payload.1015
  %stack.offset.1155 = add i32 %stack.offset.1154, %local.source.payload.1061
  %stack.offset.1156 = add i32 %stack.offset.1155, %local.source.payload.1108
  %stack.offset.1157 = add i32 0, %local.source.extent.1060
  %stack.offset.1158 = add i32 %stack.offset.1157, %local.source.extent.1107
  %context.field.1159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1160 = load i32, ptr %context.field.1159, align 4
  %local.is.active.1161 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1162 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1163 = select i1 %local.is.active.1161, i32 %local.sum.extent.1162, i32 0
  %stack.offset.1164 = add i32 0, %local.sum.selected.1163
  %local.is.active.1165 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1166 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1167 = select i1 %local.is.active.1165, i32 %local.sum.extent.1166, i32 0
  %stack.offset.1168 = add i32 %stack.offset.1164, %local.sum.selected.1167
  %local.is.active.1169 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1170 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1171 = select i1 %local.is.active.1169, i32 %local.sum.extent.1170, i32 0
  %stack.offset.1172 = add i32 %stack.offset.1168, %local.sum.selected.1171
  %local.is.active.1173 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1174 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1175 = select i1 %local.is.active.1173, i32 %local.sum.extent.1174, i32 0
  %stack.offset.1176 = add i32 %stack.offset.1172, %local.sum.selected.1175
  %local.is.active.1177 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1178 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1179 = select i1 %local.is.active.1177, i32 %local.sum.extent.1178, i32 0
  %stack.offset.1180 = add i32 %stack.offset.1176, %local.sum.selected.1179
  %local.is.active.1181 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1182 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1183 = select i1 %local.is.active.1181, i32 %local.sum.extent.1182, i32 0
  %stack.offset.1184 = add i32 %stack.offset.1180, %local.sum.selected.1183
  %stack.offset.1185 = add i32 %stack.offset.1184, 0
  %stack.offset.1186 = add i32 %context.value.45, %stack.offset.1185
  %stack.offset.1187 = add i32 %context.value.1160, %stack.offset.1158
  %reserve.status.1188 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1187, i32 38)
  %reserve.ok.1189 = icmp eq i32 %reserve.status.1188, 0
  br i1 %reserve.ok.1189, label %reserve.continue.1190, label %frame.failure.0
reserve.continue.1190:
  %local.is.active.1191 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1192 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1193 = select i1 %local.is.active.1191, i32 %local.sum.extent.1192, i32 0
  %stack.offset.1194 = add i32 0, %local.sum.selected.1193
  %local.is.active.1195 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1196 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1197 = select i1 %local.is.active.1195, i32 %local.sum.extent.1196, i32 0
  %stack.offset.1198 = add i32 %stack.offset.1194, %local.sum.selected.1197
  %local.is.active.1199 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1200 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1201 = select i1 %local.is.active.1199, i32 %local.sum.extent.1200, i32 0
  %stack.offset.1202 = add i32 %stack.offset.1198, %local.sum.selected.1201
  %local.is.active.1203 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1204 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1205 = select i1 %local.is.active.1203, i32 %local.sum.extent.1204, i32 0
  %stack.offset.1206 = add i32 %stack.offset.1202, %local.sum.selected.1205
  %local.is.active.1207 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1208 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1209 = select i1 %local.is.active.1207, i32 %local.sum.extent.1208, i32 0
  %stack.offset.1210 = add i32 %stack.offset.1206, %local.sum.selected.1209
  %local.is.active.1211 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1212 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1213 = select i1 %local.is.active.1211, i32 %local.sum.extent.1212, i32 0
  %stack.offset.1214 = add i32 %stack.offset.1210, %local.sum.selected.1213
  %stack.offset.1215 = add i32 0, %local.source.extent.1014
  %stack.offset.1216 = add i32 %stack.offset.1214, %stack.offset.1215
  %stack.offset.1217 = add i32 %context.value.45, %stack.offset.1216
  %stack.offset.1218 = add i32 %context.value.1160, 0
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1218, i32 %stack.offset.1217, i32 %local.source.extent.1060, i32 %local.source.payload.1061, i32 12, i32 6)
  %context.field.1219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1220 = load i32, ptr %context.field.1219, align 4
  %runtime.ok.1221 = icmp eq i32 %context.value.1220, 0
  br i1 %runtime.ok.1221, label %runtime.continue.1222, label %frame.failure.0
runtime.continue.1222:
  %stack.offset.1223 = add i32 0, %local.source.extent.1060
  %local.is.active.1224 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1225 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1226 = select i1 %local.is.active.1224, i32 %local.sum.extent.1225, i32 0
  %stack.offset.1227 = add i32 0, %local.sum.selected.1226
  %local.is.active.1228 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1229 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1230 = select i1 %local.is.active.1228, i32 %local.sum.extent.1229, i32 0
  %stack.offset.1231 = add i32 %stack.offset.1227, %local.sum.selected.1230
  %local.is.active.1232 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1233 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1234 = select i1 %local.is.active.1232, i32 %local.sum.extent.1233, i32 0
  %stack.offset.1235 = add i32 %stack.offset.1231, %local.sum.selected.1234
  %local.is.active.1236 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1237 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1238 = select i1 %local.is.active.1236, i32 %local.sum.extent.1237, i32 0
  %stack.offset.1239 = add i32 %stack.offset.1235, %local.sum.selected.1238
  %local.is.active.1240 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1241 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1242 = select i1 %local.is.active.1240, i32 %local.sum.extent.1241, i32 0
  %stack.offset.1243 = add i32 %stack.offset.1239, %local.sum.selected.1242
  %local.is.active.1244 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1245 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1246 = select i1 %local.is.active.1244, i32 %local.sum.extent.1245, i32 0
  %stack.offset.1247 = add i32 %stack.offset.1243, %local.sum.selected.1246
  %stack.offset.1248 = add i32 0, %local.source.extent.1014
  %stack.offset.1249 = add i32 %stack.offset.1248, %local.source.extent.1060
  %stack.offset.1250 = add i32 %stack.offset.1247, %stack.offset.1249
  %stack.offset.1251 = add i32 %context.value.45, %stack.offset.1250
  %stack.offset.1252 = add i32 %context.value.1160, %stack.offset.1223
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1252, i32 %stack.offset.1251, i32 %local.source.extent.1107, i32 %local.source.payload.1108, i32 1, i32 6)
  %context.field.1253 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1254 = load i32, ptr %context.field.1253, align 4
  %runtime.ok.1255 = icmp eq i32 %context.value.1254, 0
  br i1 %runtime.ok.1255, label %runtime.continue.1256, label %frame.failure.0
runtime.continue.1256:
  %stack.offset.1257 = add i32 %stack.offset.1223, %local.source.extent.1107
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1186, i32 %context.value.1160, i32 %stack.offset.1158, i32 %stack.offset.1156, i32 10, i32 6)
  %context.field.1258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1259 = load i32, ptr %context.field.1258, align 4
  %runtime.ok.1260 = icmp eq i32 %context.value.1259, 0
  br i1 %runtime.ok.1260, label %runtime.continue.1261, label %frame.failure.0
runtime.continue.1261:
  %stack.offset.1262 = add i32 %stack.offset.1186, %stack.offset.1158
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1262, i32 0, i32 0, i32 0)
  %context.field.1263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1264 = load i32, ptr %context.field.1263, align 4
  %runtime.ok.1265 = icmp eq i32 %context.value.1264, 0
  br i1 %runtime.ok.1265, label %runtime.continue.1266, label %frame.failure.0
runtime.continue.1266:
  %stack.offset.1267 = add i32 0, %local.source.payload.1015
  %stack.offset.1268 = add i32 %stack.offset.1267, %local.source.payload.1061
  %stack.offset.1269 = add i32 %stack.offset.1268, %local.source.payload.1108
  %stack.sub.1270 = sub i32 %stack.offset.1156, %stack.offset.1269
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1270, i32 0)
  %context.field.1271 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1272 = load i32, ptr %context.field.1271, align 4
  %runtime.ok.1273 = icmp eq i32 %context.value.1272, 0
  br i1 %runtime.ok.1273, label %runtime.continue.1274, label %frame.failure.0
runtime.continue.1274:
  %local.is.active.1275 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1276 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1277 = select i1 %local.is.active.1275, i32 %local.sum.extent.1276, i32 0
  %stack.offset.1278 = add i32 0, %local.sum.selected.1277
  %local.is.active.1279 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1280 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1281 = select i1 %local.is.active.1279, i32 %local.sum.extent.1280, i32 0
  %stack.offset.1282 = add i32 %stack.offset.1278, %local.sum.selected.1281
  %local.is.active.1283 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1284 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1285 = select i1 %local.is.active.1283, i32 %local.sum.extent.1284, i32 0
  %stack.offset.1286 = add i32 %stack.offset.1282, %local.sum.selected.1285
  %local.is.active.1287 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1288 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1289 = select i1 %local.is.active.1287, i32 %local.sum.extent.1288, i32 0
  %stack.offset.1290 = add i32 %stack.offset.1286, %local.sum.selected.1289
  %local.is.active.1291 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1292 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1293 = select i1 %local.is.active.1291, i32 %local.sum.extent.1292, i32 0
  %stack.offset.1294 = add i32 %stack.offset.1290, %local.sum.selected.1293
  %local.is.active.1295 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1296 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1297 = select i1 %local.is.active.1295, i32 %local.sum.extent.1296, i32 0
  %stack.offset.1298 = add i32 %stack.offset.1294, %local.sum.selected.1297
  %stack.offset.1299 = add i32 0, %stack.offset.1158
  %stack.offset.1300 = add i32 %stack.offset.1298, %stack.offset.1299
  %stack.offset.1301 = add i32 %context.value.45, %stack.offset.1300
  %cursor.status.1302 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1301)
  %cursor.ok.1303 = icmp eq i32 %cursor.status.1302, 0
  br i1 %cursor.ok.1303, label %cursor.continue.1304, label %frame.failure.0
cursor.continue.1304:
  %local.is.active.1305 = load i1, ptr %local.active.28, align 1
  br i1 %local.is.active.1305, label %local.remove.1306, label %local.keep.1307
local.keep.1307:
  br label %local.removed.1308
local.remove.1306:
  %local.remove.offset.1309 = load i32, ptr %local.offset.29, align 4
  %local.remove.extent.1310 = load i32, ptr %local.extent.30, align 4
  %local.remove.payload.1311 = load i32, ptr %local.payload.31, align 4
  %local.remove.type.1312 = load i32, ptr %local.type.32, align 4
  %stack.offset.1313 = add i32 %local.remove.offset.1309, %local.remove.extent.1310
  %context.field.1314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1315 = load i32, ptr %context.field.1314, align 4
  %stack.sub.1316 = sub i32 %context.value.1315, %stack.offset.1313
  %stack.offset.1317 = add i32 0, %stack.offset.1156
  %stack.offset.1318 = add i32 0, %stack.offset.1317
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1309, i32 %stack.offset.1313, i32 %stack.sub.1316, i32 %stack.offset.1318, i32 0, i32 14)
  %context.field.1319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1320 = load i32, ptr %context.field.1319, align 4
  %runtime.ok.1321 = icmp eq i32 %context.value.1320, 0
  br i1 %runtime.ok.1321, label %runtime.continue.1322, label %frame.failure.0
runtime.continue.1322:
  %stack.sub.1323 = sub i32 %context.value.1315, %local.remove.extent.1310
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1323, i32 0, i32 0, i32 0)
  %context.field.1324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1325 = load i32, ptr %context.field.1324, align 4
  %runtime.ok.1326 = icmp eq i32 %context.value.1325, 0
  br i1 %runtime.ok.1326, label %runtime.continue.1327, label %frame.failure.0
runtime.continue.1327:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1312, i32 %local.remove.offset.1309, i32 %local.remove.extent.1310, i32 %local.remove.payload.1311, i32 0, i32 0)
  %context.field.1328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1329 = load i32, ptr %context.field.1328, align 4
  %runtime.ok.1330 = icmp eq i32 %context.value.1329, 0
  br i1 %runtime.ok.1330, label %runtime.continue.1331, label %frame.failure.0
runtime.continue.1331:
  %stack.sub.1332 = sub i32 0, %local.remove.payload.1311
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1332, i32 %stack.sub.1332)
  %context.field.1333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1334 = load i32, ptr %context.field.1333, align 4
  %runtime.ok.1335 = icmp eq i32 %context.value.1334, 0
  br i1 %runtime.ok.1335, label %runtime.continue.1336, label %frame.failure.0
runtime.continue.1336:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1310)
  %context.field.1337 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1338 = load i32, ptr %context.field.1337, align 4
  %runtime.ok.1339 = icmp eq i32 %context.value.1338, 0
  br i1 %runtime.ok.1339, label %runtime.continue.1340, label %frame.failure.0
runtime.continue.1340:
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  br label %local.removed.1308
local.removed.1308:
  %local.is.active.1341 = load i1, ptr %local.active.23, align 1
  br i1 %local.is.active.1341, label %local.remove.1342, label %local.keep.1343
local.keep.1343:
  br label %local.removed.1344
local.remove.1342:
  %local.remove.offset.1345 = load i32, ptr %local.offset.24, align 4
  %local.remove.extent.1346 = load i32, ptr %local.extent.25, align 4
  %local.remove.payload.1347 = load i32, ptr %local.payload.26, align 4
  %local.remove.type.1348 = load i32, ptr %local.type.27, align 4
  %stack.offset.1349 = add i32 %local.remove.offset.1345, %local.remove.extent.1346
  %context.field.1350 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1351 = load i32, ptr %context.field.1350, align 4
  %stack.sub.1352 = sub i32 %context.value.1351, %stack.offset.1349
  %local.is.active.1353 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1354 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1355 = select i1 %local.is.active.1353, i32 %local.suffix.payload.1354, i32 0
  %stack.offset.1356 = add i32 0, %local.suffix.selected.1355
  %stack.offset.1357 = add i32 0, %stack.offset.1156
  %stack.offset.1358 = add i32 %stack.offset.1356, %stack.offset.1357
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1345, i32 %stack.offset.1349, i32 %stack.sub.1352, i32 %stack.offset.1358, i32 0, i32 14)
  %context.field.1359 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1360 = load i32, ptr %context.field.1359, align 4
  %runtime.ok.1361 = icmp eq i32 %context.value.1360, 0
  br i1 %runtime.ok.1361, label %runtime.continue.1362, label %frame.failure.0
runtime.continue.1362:
  %stack.sub.1363 = sub i32 %context.value.1351, %local.remove.extent.1346
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1363, i32 0, i32 0, i32 0)
  %context.field.1364 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1365 = load i32, ptr %context.field.1364, align 4
  %runtime.ok.1366 = icmp eq i32 %context.value.1365, 0
  br i1 %runtime.ok.1366, label %runtime.continue.1367, label %frame.failure.0
runtime.continue.1367:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1348, i32 %local.remove.offset.1345, i32 %local.remove.extent.1346, i32 %local.remove.payload.1347, i32 0, i32 0)
  %context.field.1368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1369 = load i32, ptr %context.field.1368, align 4
  %runtime.ok.1370 = icmp eq i32 %context.value.1369, 0
  br i1 %runtime.ok.1370, label %runtime.continue.1371, label %frame.failure.0
runtime.continue.1371:
  %stack.sub.1372 = sub i32 0, %local.remove.payload.1347
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1372, i32 %stack.sub.1372)
  %context.field.1373 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1374 = load i32, ptr %context.field.1373, align 4
  %runtime.ok.1375 = icmp eq i32 %context.value.1374, 0
  br i1 %runtime.ok.1375, label %runtime.continue.1376, label %frame.failure.0
runtime.continue.1376:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1346)
  %context.field.1377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1378 = load i32, ptr %context.field.1377, align 4
  %runtime.ok.1379 = icmp eq i32 %context.value.1378, 0
  br i1 %runtime.ok.1379, label %runtime.continue.1380, label %frame.failure.0
runtime.continue.1380:
  %local.is.active.1381 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1382 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1383 = sub i32 %local.later.offset.1382, %local.remove.extent.1346
  %local.later.offset.selected.1384 = select i1 %local.is.active.1381, i32 %stack.sub.1383, i32 %local.later.offset.1382
  store i32 %local.later.offset.selected.1384, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  br label %local.removed.1344
local.removed.1344:
  %local.is.active.1385 = load i1, ptr %local.active.18, align 1
  br i1 %local.is.active.1385, label %local.remove.1386, label %local.keep.1387
local.keep.1387:
  br label %local.removed.1388
local.remove.1386:
  %local.remove.offset.1389 = load i32, ptr %local.offset.19, align 4
  %local.remove.extent.1390 = load i32, ptr %local.extent.20, align 4
  %local.remove.payload.1391 = load i32, ptr %local.payload.21, align 4
  %local.remove.type.1392 = load i32, ptr %local.type.22, align 4
  %stack.offset.1393 = add i32 %local.remove.offset.1389, %local.remove.extent.1390
  %context.field.1394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1395 = load i32, ptr %context.field.1394, align 4
  %stack.sub.1396 = sub i32 %context.value.1395, %stack.offset.1393
  %local.is.active.1397 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1398 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1399 = select i1 %local.is.active.1397, i32 %local.suffix.payload.1398, i32 0
  %stack.offset.1400 = add i32 0, %local.suffix.selected.1399
  %local.is.active.1401 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1402 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1403 = select i1 %local.is.active.1401, i32 %local.suffix.payload.1402, i32 0
  %stack.offset.1404 = add i32 %stack.offset.1400, %local.suffix.selected.1403
  %stack.offset.1405 = add i32 0, %stack.offset.1156
  %stack.offset.1406 = add i32 %stack.offset.1404, %stack.offset.1405
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1389, i32 %stack.offset.1393, i32 %stack.sub.1396, i32 %stack.offset.1406, i32 0, i32 14)
  %context.field.1407 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1408 = load i32, ptr %context.field.1407, align 4
  %runtime.ok.1409 = icmp eq i32 %context.value.1408, 0
  br i1 %runtime.ok.1409, label %runtime.continue.1410, label %frame.failure.0
runtime.continue.1410:
  %stack.sub.1411 = sub i32 %context.value.1395, %local.remove.extent.1390
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1411, i32 0, i32 0, i32 0)
  %context.field.1412 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1413 = load i32, ptr %context.field.1412, align 4
  %runtime.ok.1414 = icmp eq i32 %context.value.1413, 0
  br i1 %runtime.ok.1414, label %runtime.continue.1415, label %frame.failure.0
runtime.continue.1415:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1392, i32 %local.remove.offset.1389, i32 %local.remove.extent.1390, i32 %local.remove.payload.1391, i32 0, i32 0)
  %context.field.1416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1417 = load i32, ptr %context.field.1416, align 4
  %runtime.ok.1418 = icmp eq i32 %context.value.1417, 0
  br i1 %runtime.ok.1418, label %runtime.continue.1419, label %frame.failure.0
runtime.continue.1419:
  %stack.sub.1420 = sub i32 0, %local.remove.payload.1391
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1420, i32 %stack.sub.1420)
  %context.field.1421 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1422 = load i32, ptr %context.field.1421, align 4
  %runtime.ok.1423 = icmp eq i32 %context.value.1422, 0
  br i1 %runtime.ok.1423, label %runtime.continue.1424, label %frame.failure.0
runtime.continue.1424:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1390)
  %context.field.1425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1426 = load i32, ptr %context.field.1425, align 4
  %runtime.ok.1427 = icmp eq i32 %context.value.1426, 0
  br i1 %runtime.ok.1427, label %runtime.continue.1428, label %frame.failure.0
runtime.continue.1428:
  %local.is.active.1429 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1430 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1431 = sub i32 %local.later.offset.1430, %local.remove.extent.1390
  %local.later.offset.selected.1432 = select i1 %local.is.active.1429, i32 %stack.sub.1431, i32 %local.later.offset.1430
  store i32 %local.later.offset.selected.1432, ptr %local.offset.24, align 4
  %local.is.active.1433 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1434 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1435 = sub i32 %local.later.offset.1434, %local.remove.extent.1390
  %local.later.offset.selected.1436 = select i1 %local.is.active.1433, i32 %stack.sub.1435, i32 %local.later.offset.1434
  store i32 %local.later.offset.selected.1436, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  br label %local.removed.1388
local.removed.1388:
  %local.is.active.1437 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1438 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1439 = select i1 %local.is.active.1437, i32 %local.sum.extent.1438, i32 0
  %stack.offset.1440 = add i32 0, %local.sum.selected.1439
  %local.is.active.1441 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1442 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1443 = select i1 %local.is.active.1441, i32 %local.sum.extent.1442, i32 0
  %stack.offset.1444 = add i32 %stack.offset.1440, %local.sum.selected.1443
  %local.is.active.1445 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1446 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1447 = select i1 %local.is.active.1445, i32 %local.sum.extent.1446, i32 0
  %stack.offset.1448 = add i32 %stack.offset.1444, %local.sum.selected.1447
  %local.is.active.1449 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1450 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1451 = select i1 %local.is.active.1449, i32 %local.sum.extent.1450, i32 0
  %stack.offset.1452 = add i32 %stack.offset.1448, %local.sum.selected.1451
  %local.is.active.1453 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1454 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1455 = select i1 %local.is.active.1453, i32 %local.sum.extent.1454, i32 0
  %stack.offset.1456 = add i32 %stack.offset.1452, %local.sum.selected.1455
  %local.is.active.1457 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1458 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1459 = select i1 %local.is.active.1457, i32 %local.sum.extent.1458, i32 0
  %stack.offset.1460 = add i32 %stack.offset.1456, %local.sum.selected.1459
  %stack.offset.1461 = add i32 0, %stack.offset.1158
  %stack.offset.1462 = add i32 %stack.offset.1460, %stack.offset.1461
  %stack.offset.1463 = add i32 %context.value.45, %stack.offset.1462
  %cursor.status.1464 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1463)
  %cursor.ok.1465 = icmp eq i32 %cursor.status.1464, 0
  br i1 %cursor.ok.1465, label %cursor.continue.1466, label %frame.failure.0
cursor.continue.1466:
  %local.is.active.1467 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.1467, label %local.remove.1468, label %local.keep.1469
local.keep.1469:
  br label %local.removed.1470
local.remove.1468:
  %local.remove.offset.1471 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.1472 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.1473 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.1474 = load i32, ptr %local.type.17, align 4
  %stack.offset.1475 = add i32 %local.remove.offset.1471, %local.remove.extent.1472
  %context.field.1476 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1477 = load i32, ptr %context.field.1476, align 4
  %stack.sub.1478 = sub i32 %context.value.1477, %stack.offset.1475
  %local.is.active.1479 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1480 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1481 = select i1 %local.is.active.1479, i32 %local.suffix.payload.1480, i32 0
  %stack.offset.1482 = add i32 0, %local.suffix.selected.1481
  %local.is.active.1483 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1484 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1485 = select i1 %local.is.active.1483, i32 %local.suffix.payload.1484, i32 0
  %stack.offset.1486 = add i32 %stack.offset.1482, %local.suffix.selected.1485
  %local.is.active.1487 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1488 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1489 = select i1 %local.is.active.1487, i32 %local.suffix.payload.1488, i32 0
  %stack.offset.1490 = add i32 %stack.offset.1486, %local.suffix.selected.1489
  %stack.offset.1491 = add i32 0, %stack.offset.1156
  %stack.offset.1492 = add i32 %stack.offset.1490, %stack.offset.1491
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1471, i32 %stack.offset.1475, i32 %stack.sub.1478, i32 %stack.offset.1492, i32 0, i32 14)
  %context.field.1493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1494 = load i32, ptr %context.field.1493, align 4
  %runtime.ok.1495 = icmp eq i32 %context.value.1494, 0
  br i1 %runtime.ok.1495, label %runtime.continue.1496, label %frame.failure.0
runtime.continue.1496:
  %stack.sub.1497 = sub i32 %context.value.1477, %local.remove.extent.1472
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1497, i32 0, i32 0, i32 0)
  %context.field.1498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1499 = load i32, ptr %context.field.1498, align 4
  %runtime.ok.1500 = icmp eq i32 %context.value.1499, 0
  br i1 %runtime.ok.1500, label %runtime.continue.1501, label %frame.failure.0
runtime.continue.1501:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1474, i32 %local.remove.offset.1471, i32 %local.remove.extent.1472, i32 %local.remove.payload.1473, i32 0, i32 0)
  %context.field.1502 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1503 = load i32, ptr %context.field.1502, align 4
  %runtime.ok.1504 = icmp eq i32 %context.value.1503, 0
  br i1 %runtime.ok.1504, label %runtime.continue.1505, label %frame.failure.0
runtime.continue.1505:
  %stack.sub.1506 = sub i32 0, %local.remove.payload.1473
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1506, i32 %stack.sub.1506)
  %context.field.1507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1508 = load i32, ptr %context.field.1507, align 4
  %runtime.ok.1509 = icmp eq i32 %context.value.1508, 0
  br i1 %runtime.ok.1509, label %runtime.continue.1510, label %frame.failure.0
runtime.continue.1510:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1472)
  %context.field.1511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1512 = load i32, ptr %context.field.1511, align 4
  %runtime.ok.1513 = icmp eq i32 %context.value.1512, 0
  br i1 %runtime.ok.1513, label %runtime.continue.1514, label %frame.failure.0
runtime.continue.1514:
  %local.is.active.1515 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1516 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1517 = sub i32 %local.later.offset.1516, %local.remove.extent.1472
  %local.later.offset.selected.1518 = select i1 %local.is.active.1515, i32 %stack.sub.1517, i32 %local.later.offset.1516
  store i32 %local.later.offset.selected.1518, ptr %local.offset.19, align 4
  %local.is.active.1519 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1520 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1521 = sub i32 %local.later.offset.1520, %local.remove.extent.1472
  %local.later.offset.selected.1522 = select i1 %local.is.active.1519, i32 %stack.sub.1521, i32 %local.later.offset.1520
  store i32 %local.later.offset.selected.1522, ptr %local.offset.24, align 4
  %local.is.active.1523 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1524 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1525 = sub i32 %local.later.offset.1524, %local.remove.extent.1472
  %local.later.offset.selected.1526 = select i1 %local.is.active.1523, i32 %stack.sub.1525, i32 %local.later.offset.1524
  store i32 %local.later.offset.selected.1526, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.1470
local.removed.1470:
  %local.is.active.1527 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1527, label %local.remove.1528, label %local.keep.1529
local.keep.1529:
  br label %local.removed.1530
local.remove.1528:
  %local.remove.offset.1531 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.1532 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.1533 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.1534 = load i32, ptr %local.type.12, align 4
  %stack.offset.1535 = add i32 %local.remove.offset.1531, %local.remove.extent.1532
  %context.field.1536 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1537 = load i32, ptr %context.field.1536, align 4
  %stack.sub.1538 = sub i32 %context.value.1537, %stack.offset.1535
  %local.is.active.1539 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1540 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1541 = select i1 %local.is.active.1539, i32 %local.suffix.payload.1540, i32 0
  %stack.offset.1542 = add i32 0, %local.suffix.selected.1541
  %local.is.active.1543 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1544 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1545 = select i1 %local.is.active.1543, i32 %local.suffix.payload.1544, i32 0
  %stack.offset.1546 = add i32 %stack.offset.1542, %local.suffix.selected.1545
  %local.is.active.1547 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1548 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1549 = select i1 %local.is.active.1547, i32 %local.suffix.payload.1548, i32 0
  %stack.offset.1550 = add i32 %stack.offset.1546, %local.suffix.selected.1549
  %local.is.active.1551 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1552 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1553 = select i1 %local.is.active.1551, i32 %local.suffix.payload.1552, i32 0
  %stack.offset.1554 = add i32 %stack.offset.1550, %local.suffix.selected.1553
  %stack.offset.1555 = add i32 0, %stack.offset.1156
  %stack.offset.1556 = add i32 %stack.offset.1554, %stack.offset.1555
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1531, i32 %stack.offset.1535, i32 %stack.sub.1538, i32 %stack.offset.1556, i32 0, i32 14)
  %context.field.1557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1558 = load i32, ptr %context.field.1557, align 4
  %runtime.ok.1559 = icmp eq i32 %context.value.1558, 0
  br i1 %runtime.ok.1559, label %runtime.continue.1560, label %frame.failure.0
runtime.continue.1560:
  %stack.sub.1561 = sub i32 %context.value.1537, %local.remove.extent.1532
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1561, i32 0, i32 0, i32 0)
  %context.field.1562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1563 = load i32, ptr %context.field.1562, align 4
  %runtime.ok.1564 = icmp eq i32 %context.value.1563, 0
  br i1 %runtime.ok.1564, label %runtime.continue.1565, label %frame.failure.0
runtime.continue.1565:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1534, i32 %local.remove.offset.1531, i32 %local.remove.extent.1532, i32 %local.remove.payload.1533, i32 0, i32 0)
  %context.field.1566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1567 = load i32, ptr %context.field.1566, align 4
  %runtime.ok.1568 = icmp eq i32 %context.value.1567, 0
  br i1 %runtime.ok.1568, label %runtime.continue.1569, label %frame.failure.0
runtime.continue.1569:
  %stack.sub.1570 = sub i32 0, %local.remove.payload.1533
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1570, i32 %stack.sub.1570)
  %context.field.1571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1572 = load i32, ptr %context.field.1571, align 4
  %runtime.ok.1573 = icmp eq i32 %context.value.1572, 0
  br i1 %runtime.ok.1573, label %runtime.continue.1574, label %frame.failure.0
runtime.continue.1574:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1532)
  %context.field.1575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1576 = load i32, ptr %context.field.1575, align 4
  %runtime.ok.1577 = icmp eq i32 %context.value.1576, 0
  br i1 %runtime.ok.1577, label %runtime.continue.1578, label %frame.failure.0
runtime.continue.1578:
  %local.is.active.1579 = load i1, ptr %local.active.13, align 1
  %local.later.offset.1580 = load i32, ptr %local.offset.14, align 4
  %stack.sub.1581 = sub i32 %local.later.offset.1580, %local.remove.extent.1532
  %local.later.offset.selected.1582 = select i1 %local.is.active.1579, i32 %stack.sub.1581, i32 %local.later.offset.1580
  store i32 %local.later.offset.selected.1582, ptr %local.offset.14, align 4
  %local.is.active.1583 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1584 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1585 = sub i32 %local.later.offset.1584, %local.remove.extent.1532
  %local.later.offset.selected.1586 = select i1 %local.is.active.1583, i32 %stack.sub.1585, i32 %local.later.offset.1584
  store i32 %local.later.offset.selected.1586, ptr %local.offset.19, align 4
  %local.is.active.1587 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1588 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1589 = sub i32 %local.later.offset.1588, %local.remove.extent.1532
  %local.later.offset.selected.1590 = select i1 %local.is.active.1587, i32 %stack.sub.1589, i32 %local.later.offset.1588
  store i32 %local.later.offset.selected.1590, ptr %local.offset.24, align 4
  %local.is.active.1591 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1592 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1593 = sub i32 %local.later.offset.1592, %local.remove.extent.1532
  %local.later.offset.selected.1594 = select i1 %local.is.active.1591, i32 %stack.sub.1593, i32 %local.later.offset.1592
  store i32 %local.later.offset.selected.1594, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.1530
local.removed.1530:
  %local.is.active.1595 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.1595, label %local.remove.1596, label %local.keep.1597
local.keep.1597:
  br label %local.removed.1598
local.remove.1596:
  %local.remove.offset.1599 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.1600 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.1601 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.1602 = load i32, ptr %local.type.7, align 4
  %stack.offset.1603 = add i32 %local.remove.offset.1599, %local.remove.extent.1600
  %context.field.1604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1605 = load i32, ptr %context.field.1604, align 4
  %stack.sub.1606 = sub i32 %context.value.1605, %stack.offset.1603
  %local.is.active.1607 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.1608 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.1609 = select i1 %local.is.active.1607, i32 %local.suffix.payload.1608, i32 0
  %stack.offset.1610 = add i32 0, %local.suffix.selected.1609
  %local.is.active.1611 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1612 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1613 = select i1 %local.is.active.1611, i32 %local.suffix.payload.1612, i32 0
  %stack.offset.1614 = add i32 %stack.offset.1610, %local.suffix.selected.1613
  %local.is.active.1615 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1616 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1617 = select i1 %local.is.active.1615, i32 %local.suffix.payload.1616, i32 0
  %stack.offset.1618 = add i32 %stack.offset.1614, %local.suffix.selected.1617
  %local.is.active.1619 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1620 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1621 = select i1 %local.is.active.1619, i32 %local.suffix.payload.1620, i32 0
  %stack.offset.1622 = add i32 %stack.offset.1618, %local.suffix.selected.1621
  %local.is.active.1623 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1624 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1625 = select i1 %local.is.active.1623, i32 %local.suffix.payload.1624, i32 0
  %stack.offset.1626 = add i32 %stack.offset.1622, %local.suffix.selected.1625
  %stack.offset.1627 = add i32 0, %stack.offset.1156
  %stack.offset.1628 = add i32 %stack.offset.1626, %stack.offset.1627
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1599, i32 %stack.offset.1603, i32 %stack.sub.1606, i32 %stack.offset.1628, i32 0, i32 14)
  %context.field.1629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1630 = load i32, ptr %context.field.1629, align 4
  %runtime.ok.1631 = icmp eq i32 %context.value.1630, 0
  br i1 %runtime.ok.1631, label %runtime.continue.1632, label %frame.failure.0
runtime.continue.1632:
  %stack.sub.1633 = sub i32 %context.value.1605, %local.remove.extent.1600
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1633, i32 0, i32 0, i32 0)
  %context.field.1634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1635 = load i32, ptr %context.field.1634, align 4
  %runtime.ok.1636 = icmp eq i32 %context.value.1635, 0
  br i1 %runtime.ok.1636, label %runtime.continue.1637, label %frame.failure.0
runtime.continue.1637:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1602, i32 %local.remove.offset.1599, i32 %local.remove.extent.1600, i32 %local.remove.payload.1601, i32 0, i32 0)
  %context.field.1638 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1639 = load i32, ptr %context.field.1638, align 4
  %runtime.ok.1640 = icmp eq i32 %context.value.1639, 0
  br i1 %runtime.ok.1640, label %runtime.continue.1641, label %frame.failure.0
runtime.continue.1641:
  %stack.sub.1642 = sub i32 0, %local.remove.payload.1601
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1642, i32 %stack.sub.1642)
  %context.field.1643 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1644 = load i32, ptr %context.field.1643, align 4
  %runtime.ok.1645 = icmp eq i32 %context.value.1644, 0
  br i1 %runtime.ok.1645, label %runtime.continue.1646, label %frame.failure.0
runtime.continue.1646:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1600)
  %context.field.1647 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1648 = load i32, ptr %context.field.1647, align 4
  %runtime.ok.1649 = icmp eq i32 %context.value.1648, 0
  br i1 %runtime.ok.1649, label %runtime.continue.1650, label %frame.failure.0
runtime.continue.1650:
  %local.is.active.1651 = load i1, ptr %local.active.8, align 1
  %local.later.offset.1652 = load i32, ptr %local.offset.9, align 4
  %stack.sub.1653 = sub i32 %local.later.offset.1652, %local.remove.extent.1600
  %local.later.offset.selected.1654 = select i1 %local.is.active.1651, i32 %stack.sub.1653, i32 %local.later.offset.1652
  store i32 %local.later.offset.selected.1654, ptr %local.offset.9, align 4
  %local.is.active.1655 = load i1, ptr %local.active.13, align 1
  %local.later.offset.1656 = load i32, ptr %local.offset.14, align 4
  %stack.sub.1657 = sub i32 %local.later.offset.1656, %local.remove.extent.1600
  %local.later.offset.selected.1658 = select i1 %local.is.active.1655, i32 %stack.sub.1657, i32 %local.later.offset.1656
  store i32 %local.later.offset.selected.1658, ptr %local.offset.14, align 4
  %local.is.active.1659 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1660 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1661 = sub i32 %local.later.offset.1660, %local.remove.extent.1600
  %local.later.offset.selected.1662 = select i1 %local.is.active.1659, i32 %stack.sub.1661, i32 %local.later.offset.1660
  store i32 %local.later.offset.selected.1662, ptr %local.offset.19, align 4
  %local.is.active.1663 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1664 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1665 = sub i32 %local.later.offset.1664, %local.remove.extent.1600
  %local.later.offset.selected.1666 = select i1 %local.is.active.1663, i32 %stack.sub.1665, i32 %local.later.offset.1664
  store i32 %local.later.offset.selected.1666, ptr %local.offset.24, align 4
  %local.is.active.1667 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1668 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1669 = sub i32 %local.later.offset.1668, %local.remove.extent.1600
  %local.later.offset.selected.1670 = select i1 %local.is.active.1667, i32 %stack.sub.1669, i32 %local.later.offset.1668
  store i32 %local.later.offset.selected.1670, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.1598
local.removed.1598:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  %context.field.1671 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1672 = load i32, ptr %context.field.1671, align 4
  %context.field.1673 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1674 = load i32, ptr %context.field.1673, align 4
  %context.field.1675 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1676 = load i32, ptr %context.field.1675, align 4
  %stack.offset.1677 = add i32 %context.value.36, %context.value.38
  %stack.offset.1678 = add i32 %context.value.1672, %context.value.1674
  %stack.sub.1679 = sub i32 %stack.offset.1677, %stack.offset.1678
  %stack.sub.1680 = sub i32 %context.value.38, %context.value.1674
  %stack.sub.1681 = sub i32 %context.value.1676, %context.value.40
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1679, i32 %stack.sub.1680)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1681)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 39, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 39, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.extent.pointer.24 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.25 = load i32, ptr %input.extent.pointer.24, align 4
  %host.pointer.26 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.payload.pointer.27 = alloca i32, align 4
  %input.measured.extent.pointer.28 = alloca i32, align 4
  %input.measure.status.29 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.26, i32 %input.host.extent.25, i32 0, i32 40, ptr %input.payload.pointer.27, ptr %input.measured.extent.pointer.28)
  %helper.ok.30 = icmp eq i32 %input.measure.status.29, 0
  br i1 %helper.ok.30, label %helper.continue.31, label %entry.failure.0
helper.continue.31:
  %input.measured.payload.32 = load i32, ptr %input.payload.pointer.27, align 4
  %input.measured.extent.33 = load i32, ptr %input.measured.extent.pointer.28, align 4
  %input.extent.exact.34 = icmp eq i32 %input.measured.extent.33, %input.host.extent.25
  br i1 %input.extent.exact.34, label %input.extent.exact.35, label %input.extent.invalid.36
input.extent.invalid.36:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 40, i32 %input.measured.extent.33, i32 %input.host.extent.25)
  br label %entry.failure.0
input.extent.exact.35:
  %stack.offset.37 = add i32 %stack.offset.23, %input.host.extent.25
  %input.total.exact.38 = icmp eq i32 %stack.offset.37, %input.bytes
  br i1 %input.total.exact.38, label %input.valid.39, label %input.invalid.40
input.invalid.40:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.37, i32 %input.bytes)
  br label %entry.failure.0
input.valid.39:
  %reserve.status.41 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 41)
  %reserve.ok.42 = icmp eq i32 %reserve.status.41, 0
  br i1 %reserve.ok.42, label %reserve.continue.43, label %entry.failure.0
reserve.continue.43:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.45 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.44, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 12, i32 42)
  %helper.ok.46 = icmp eq i32 %input.copy.status.45, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %entry.failure.0
helper.continue.47:
  %host.pointer.48 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.copy.status.49 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.23, ptr %host.pointer.48, i32 %input.host.extent.25, i32 0, i32 %input.measured.payload.32, i32 %input.host.extent.25, i32 1, i32 43)
  %helper.ok.50 = icmp eq i32 %input.copy.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %entry.failure.0
helper.continue.51:
  %entry.body.status.52 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 44)
  %entry.body.ok.53 = icmp eq i32 %entry.body.status.52, 0
  br i1 %entry.body.ok.53, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.54 = add i32 0, %input.bytes
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %value.size.57 = alloca %AlOwningValueSize, align 4
  %measure.status.58 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.54, i32 %context.value.56, i32 45, ptr %value.size.57)
  %helper.ok.59 = icmp eq i32 %measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %value.payload.pointer.61 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 0
  %value.extent.pointer.62 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 1
  %value.payload.63 = load i32, ptr %value.payload.pointer.61, align 4
  %value.extent.64 = load i32, ptr %value.extent.pointer.62, align 4
  %stack.offset.65 = add i32 %stack.offset.54, %value.extent.64
  %stack.offset.66 = add i32 0, %value.payload.63
  %entry.outputs.exact.67 = icmp eq i32 %stack.offset.65, %context.value.56
  br i1 %entry.outputs.exact.67, label %entry.outputs.exact.68, label %entry.failure.0
entry.outputs.exact.68:
  %stack.sub.69 = sub i32 %context.value.56, %stack.offset.54
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.54, i32 %stack.sub.69, i32 %stack.offset.66, i32 0, i32 9)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.69, i32 0, i32 0, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.69, i32 10)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %entry.failure.0
runtime.continue.81:
  %stack.sub.82 = sub i32 0, %stack.offset.66
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.82, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %entry.failure.0
runtime.continue.86:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.offset.93 = add i32 %context.value.88, %context.value.90
  %stack.sub.94 = sub i32 0, %stack.offset.93
  %stack.sub.95 = sub i32 0, %context.value.90
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.94, i32 %stack.sub.95)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.92)
  br label %entry.return.status
entry.return.status:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  ret i32 %context.value.97
}


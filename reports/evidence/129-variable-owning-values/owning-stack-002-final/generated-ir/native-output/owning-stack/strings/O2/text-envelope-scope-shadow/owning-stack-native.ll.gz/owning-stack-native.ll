%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %context.field.15 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.16 = load i32, ptr %context.field.15, align 4
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %frame.entered.21 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.22 = icmp eq i32 %frame.entered.21, 0
  br i1 %frame.enter.ok.22, label %frame.enter.continue.23, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.23:
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %stack.offset.26 = add i32 %argument.source, %argument.bytes
  %stack.offset.27 = add i32 %context.value.25, %argument.bytes
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.27, i32 1)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %frame.reserve.failure.1
reserve.continue.30:
  %value.size.31 = alloca %AlOwningValueSize, align 4
  %measure.status.32 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.26, i32 2, ptr %value.size.31)
  %helper.ok.33 = icmp eq i32 %measure.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %frame.failure.0
helper.continue.34:
  %value.payload.pointer.35 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 0
  %value.extent.pointer.36 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 1
  %value.payload.37 = load i32, ptr %value.payload.pointer.35, align 4
  %value.extent.38 = load i32, ptr %value.extent.pointer.36, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.25, i32 %argument.source, i32 %value.extent.38, i32 %value.payload.37, i32 8, i32 8)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, %value.extent.38
  %stack.offset.44 = add i32 %context.value.25, %value.extent.38
  %value.size.45 = alloca %AlOwningValueSize, align 4
  %measure.status.46 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.43, i32 %stack.offset.26, i32 3, ptr %value.size.45)
  %helper.ok.47 = icmp eq i32 %measure.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %value.payload.pointer.49 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.45, i32 0, i32 0
  %value.extent.pointer.50 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.45, i32 0, i32 1
  %value.payload.51 = load i32, ptr %value.payload.pointer.49, align 4
  %value.extent.52 = load i32, ptr %value.extent.pointer.50, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.44, i32 %stack.offset.43, i32 %value.extent.52, i32 %value.payload.51, i32 8, i32 8)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %stack.offset.43, %value.extent.52
  %stack.offset.58 = add i32 %stack.offset.44, %value.extent.52
  %arguments.exact.59 = icmp eq i32 %stack.offset.57, %stack.offset.26
  br i1 %arguments.exact.59, label %arguments.continue.60, label %frame.failure.0
arguments.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.66 = sub i32 %context.value.65, %value.extent.52
  %stack.sub.67 = sub i32 %stack.sub.66, %value.extent.38
  call void @al_owning_swap(ptr %ctx, i32 %stack.sub.67, i32 %value.extent.38, i32 %value.extent.52, i32 8, i32 8)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %local.is.active.72 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.73 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.74 = select i1 %local.is.active.72, i32 %local.sum.extent.73, i32 0
  %stack.offset.75 = add i32 0, %local.sum.selected.74
  %local.is.active.76 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.77 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.78 = select i1 %local.is.active.76, i32 %local.sum.extent.77, i32 0
  %stack.offset.79 = add i32 %stack.offset.75, %local.sum.selected.78
  %stack.offset.80 = add i32 0, %value.extent.52
  %stack.offset.81 = add i32 %stack.offset.80, %value.extent.38
  %stack.offset.82 = add i32 %stack.offset.79, %stack.offset.81
  %stack.offset.83 = add i32 %context.value.25, %stack.offset.82
  %cursor.status.84 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.83)
  %cursor.ok.85 = icmp eq i32 %cursor.status.84, 0
  br i1 %cursor.ok.85, label %cursor.continue.86, label %frame.failure.0
cursor.continue.86:
  %step.status.87 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.88 = icmp eq i32 %step.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  %local.is.active.90 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.91 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.92 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.93 = select i1 %local.is.active.90, i32 %local.previous.extent.91, i32 0
  %local.old.payload.94 = select i1 %local.is.active.90, i32 %local.previous.payload.92, i32 0
  %stack.offset.95 = add i32 %context.value.25, 0
  %stack.offset.96 = add i32 %stack.offset.95, %local.old.extent.93
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.sub.99 = sub i32 %context.value.98, %stack.offset.96
  %stack.sub.100 = sub i32 %context.value.98, %local.old.extent.93
  %stack.offset.101 = add i32 %stack.sub.100, %value.extent.38
  %local.grows.102 = icmp ugt i32 %value.extent.38, %local.old.extent.93
  br i1 %local.grows.102, label %local.grow.103, label %local.fixed.104
local.grow.103:
  %reserve.status.106 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.101, i32 6)
  %reserve.ok.107 = icmp eq i32 %reserve.status.106, 0
  br i1 %reserve.ok.107, label %reserve.continue.108, label %frame.failure.0
reserve.continue.108:
  %stack.sub.109 = sub i32 %value.extent.38, %local.old.extent.93
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.109)
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %runtime.ok.112 = icmp eq i32 %context.value.111, 0
  br i1 %runtime.ok.112, label %runtime.continue.113, label %frame.failure.0
runtime.continue.113:
  br label %local.layout.ready.105
local.fixed.104:
  br label %local.layout.ready.105
local.layout.ready.105:
  %stack.offset.114 = add i32 %stack.offset.95, %value.extent.38
  %local.is.active.115 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.116 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.117 = select i1 %local.is.active.115, i32 %local.suffix.payload.116, i32 0
  %stack.offset.118 = add i32 0, %local.suffix.selected.117
  %stack.offset.119 = add i32 0, %value.payload.51
  %stack.offset.120 = add i32 %stack.offset.119, %value.payload.37
  %stack.offset.121 = add i32 %stack.offset.118, %stack.offset.120
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.114, i32 %stack.offset.96, i32 %stack.sub.99, i32 %stack.offset.121, i32 0, i32 14)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %runtime.ok.124 = icmp eq i32 %context.value.123, 0
  br i1 %runtime.ok.124, label %runtime.continue.125, label %frame.failure.0
runtime.continue.125:
  %stack.sub.126 = sub i32 %context.value.98, %value.extent.38
  %stack.sub.127 = sub i32 %stack.sub.126, %local.old.extent.93
  %stack.offset.128 = add i32 %stack.sub.127, %value.extent.38
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.95, i32 %stack.offset.128, i32 %value.extent.38, i32 %value.payload.37, i32 8, i32 4)
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %runtime.ok.131 = icmp eq i32 %context.value.130, 0
  br i1 %runtime.ok.131, label %runtime.continue.132, label %frame.failure.0
runtime.continue.132:
  %stack.sub.133 = sub i32 %context.value.98, %local.old.extent.93
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.133, i32 0, i32 0, i32 0)
  %context.field.134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.135 = load i32, ptr %context.field.134, align 4
  %runtime.ok.136 = icmp eq i32 %context.value.135, 0
  br i1 %runtime.ok.136, label %runtime.continue.137, label %frame.failure.0
runtime.continue.137:
  %local.shrinks.138 = icmp ult i32 %value.extent.38, %local.old.extent.93
  br i1 %local.shrinks.138, label %local.shrink.139, label %local.counts.ready.140
local.shrink.139:
  %stack.sub.141 = sub i32 %local.old.extent.93, %value.extent.38
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.141)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %frame.failure.0
runtime.continue.145:
  br label %local.counts.ready.140
local.counts.ready.140:
  %local.payload.delta.146 = sub i32 %value.payload.37, %local.old.payload.94
  %stack.sub.147 = sub i32 0, %local.old.payload.94
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.147, i32 %local.payload.delta.146)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %local.is.active.152 = load i1, ptr %local.active.8, align 1
  %local.later.offset.153 = load i32, ptr %local.offset.9, align 4
  %stack.sub.154 = sub i32 %local.later.offset.153, %local.old.extent.93
  %stack.offset.155 = add i32 %stack.sub.154, %value.extent.38
  %local.later.offset.selected.156 = select i1 %local.is.active.152, i32 %stack.offset.155, i32 %local.later.offset.153
  store i32 %local.later.offset.selected.156, ptr %local.offset.9, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.95, ptr %local.offset.4, align 4
  store i32 %value.extent.38, ptr %local.extent.5, align 4
  store i32 %value.payload.37, ptr %local.payload.6, align 4
  store i32 8, ptr %local.type.7, align 4
  %local.is.active.157 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.158 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.159 = select i1 %local.is.active.157, i32 %local.sum.extent.158, i32 0
  %stack.offset.160 = add i32 0, %local.sum.selected.159
  %local.is.active.161 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.162 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.163 = select i1 %local.is.active.161, i32 %local.sum.extent.162, i32 0
  %stack.offset.164 = add i32 %stack.offset.160, %local.sum.selected.163
  %stack.offset.165 = add i32 0, %value.extent.52
  %stack.offset.166 = add i32 %stack.offset.164, %stack.offset.165
  %stack.offset.167 = add i32 %context.value.25, %stack.offset.166
  %cursor.status.168 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.167)
  %cursor.ok.169 = icmp eq i32 %cursor.status.168, 0
  br i1 %cursor.ok.169, label %cursor.continue.170, label %frame.failure.0
cursor.continue.170:
  %step.status.171 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.172 = icmp eq i32 %step.status.171, 0
  br i1 %helper.ok.172, label %helper.continue.173, label %frame.failure.0
helper.continue.173:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %step.status.174 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.175 = icmp eq i32 %step.status.174, 0
  br i1 %helper.ok.175, label %helper.continue.176, label %frame.failure.0
helper.continue.176:
  %local.is.active.177 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.178 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.179 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.180 = select i1 %local.is.active.177, i32 %local.previous.extent.178, i32 0
  %local.old.payload.181 = select i1 %local.is.active.177, i32 %local.previous.payload.179, i32 0
  %local.is.active.182 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.183 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.184 = select i1 %local.is.active.182, i32 %local.sum.extent.183, i32 0
  %stack.offset.185 = add i32 0, %local.sum.selected.184
  %stack.offset.186 = add i32 %context.value.25, %stack.offset.185
  %stack.offset.187 = add i32 %stack.offset.186, %local.old.extent.180
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %stack.sub.190 = sub i32 %context.value.189, %stack.offset.187
  %stack.sub.191 = sub i32 %context.value.189, %local.old.extent.180
  %stack.offset.192 = add i32 %stack.sub.191, %value.extent.52
  %local.grows.193 = icmp ugt i32 %value.extent.52, %local.old.extent.180
  br i1 %local.grows.193, label %local.grow.194, label %local.fixed.195
local.grow.194:
  %reserve.status.197 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.192, i32 9)
  %reserve.ok.198 = icmp eq i32 %reserve.status.197, 0
  br i1 %reserve.ok.198, label %reserve.continue.199, label %frame.failure.0
reserve.continue.199:
  %stack.sub.200 = sub i32 %value.extent.52, %local.old.extent.180
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.200)
  %context.field.201 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.202 = load i32, ptr %context.field.201, align 4
  %runtime.ok.203 = icmp eq i32 %context.value.202, 0
  br i1 %runtime.ok.203, label %runtime.continue.204, label %frame.failure.0
runtime.continue.204:
  br label %local.layout.ready.196
local.fixed.195:
  br label %local.layout.ready.196
local.layout.ready.196:
  %stack.offset.205 = add i32 %stack.offset.186, %value.extent.52
  %stack.offset.206 = add i32 0, %value.payload.51
  %stack.offset.207 = add i32 0, %stack.offset.206
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.205, i32 %stack.offset.187, i32 %stack.sub.190, i32 %stack.offset.207, i32 0, i32 14)
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %runtime.ok.210 = icmp eq i32 %context.value.209, 0
  br i1 %runtime.ok.210, label %runtime.continue.211, label %frame.failure.0
runtime.continue.211:
  %stack.sub.212 = sub i32 %context.value.189, %value.extent.52
  %stack.sub.213 = sub i32 %stack.sub.212, %local.old.extent.180
  %stack.offset.214 = add i32 %stack.sub.213, %value.extent.52
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.186, i32 %stack.offset.214, i32 %value.extent.52, i32 %value.payload.51, i32 8, i32 4)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  %stack.sub.219 = sub i32 %context.value.189, %local.old.extent.180
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.219, i32 0, i32 0, i32 0)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  %local.shrinks.224 = icmp ult i32 %value.extent.52, %local.old.extent.180
  br i1 %local.shrinks.224, label %local.shrink.225, label %local.counts.ready.226
local.shrink.225:
  %stack.sub.227 = sub i32 %local.old.extent.180, %value.extent.52
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.227)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %frame.failure.0
runtime.continue.231:
  br label %local.counts.ready.226
local.counts.ready.226:
  %local.payload.delta.232 = sub i32 %value.payload.51, %local.old.payload.181
  %stack.sub.233 = sub i32 0, %local.old.payload.181
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.233, i32 %local.payload.delta.232)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.186, ptr %local.offset.9, align 4
  store i32 %value.extent.52, ptr %local.extent.10, align 4
  store i32 %value.payload.51, ptr %local.payload.11, align 4
  store i32 8, ptr %local.type.12, align 4
  %local.is.active.238 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.239 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.240 = select i1 %local.is.active.238, i32 %local.sum.extent.239, i32 0
  %stack.offset.241 = add i32 0, %local.sum.selected.240
  %local.is.active.242 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.243 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.244 = select i1 %local.is.active.242, i32 %local.sum.extent.243, i32 0
  %stack.offset.245 = add i32 %stack.offset.241, %local.sum.selected.244
  %stack.offset.246 = add i32 %stack.offset.245, 0
  %stack.offset.247 = add i32 %context.value.25, %stack.offset.246
  %cursor.status.248 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.247)
  %cursor.ok.249 = icmp eq i32 %cursor.status.248, 0
  br i1 %cursor.ok.249, label %cursor.continue.250, label %frame.failure.0
cursor.continue.250:
  %local.is.active.251 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.251, label %local.remove.252, label %local.keep.253
local.keep.253:
  br label %local.removed.254
local.remove.252:
  %local.remove.offset.255 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.256 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.257 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.258 = load i32, ptr %local.type.12, align 4
  %stack.offset.259 = add i32 %local.remove.offset.255, %local.remove.extent.256
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %stack.sub.262 = sub i32 %context.value.261, %stack.offset.259
  %stack.offset.263 = add i32 0, 0
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.255, i32 %stack.offset.259, i32 %stack.sub.262, i32 %stack.offset.263, i32 0, i32 14)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %runtime.ok.266 = icmp eq i32 %context.value.265, 0
  br i1 %runtime.ok.266, label %runtime.continue.267, label %frame.failure.0
runtime.continue.267:
  %stack.sub.268 = sub i32 %context.value.261, %local.remove.extent.256
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.268, i32 0, i32 0, i32 0)
  %context.field.269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.270 = load i32, ptr %context.field.269, align 4
  %runtime.ok.271 = icmp eq i32 %context.value.270, 0
  br i1 %runtime.ok.271, label %runtime.continue.272, label %frame.failure.0
runtime.continue.272:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.258, i32 %local.remove.offset.255, i32 %local.remove.extent.256, i32 %local.remove.payload.257, i32 0, i32 0)
  %context.field.273 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.274 = load i32, ptr %context.field.273, align 4
  %runtime.ok.275 = icmp eq i32 %context.value.274, 0
  br i1 %runtime.ok.275, label %runtime.continue.276, label %frame.failure.0
runtime.continue.276:
  %stack.sub.277 = sub i32 0, %local.remove.payload.257
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.277, i32 %stack.sub.277)
  %context.field.278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.279 = load i32, ptr %context.field.278, align 4
  %runtime.ok.280 = icmp eq i32 %context.value.279, 0
  br i1 %runtime.ok.280, label %runtime.continue.281, label %frame.failure.0
runtime.continue.281:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.256)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.254
local.removed.254:
  %local.is.active.286 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.287 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.288 = select i1 %local.is.active.286, i32 %local.sum.extent.287, i32 0
  %stack.offset.289 = add i32 0, %local.sum.selected.288
  %local.is.active.290 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.291 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.292 = select i1 %local.is.active.290, i32 %local.sum.extent.291, i32 0
  %stack.offset.293 = add i32 %stack.offset.289, %local.sum.selected.292
  %stack.offset.294 = add i32 %stack.offset.293, 0
  %stack.offset.295 = add i32 %context.value.25, %stack.offset.294
  %cursor.status.296 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.295)
  %cursor.ok.297 = icmp eq i32 %cursor.status.296, 0
  br i1 %cursor.ok.297, label %cursor.continue.298, label %frame.failure.0
cursor.continue.298:
  %step.status.299 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.300 = icmp eq i32 %step.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %local.source.offset.302 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.303 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.304 = load i32, ptr %local.payload.6, align 4
  %context.field.305 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.306 = load i32, ptr %context.field.305, align 4
  %stack.offset.307 = add i32 %context.value.306, %local.source.extent.303
  %reserve.status.308 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.307, i32 11)
  %reserve.ok.309 = icmp eq i32 %reserve.status.308, 0
  br i1 %reserve.ok.309, label %reserve.continue.310, label %frame.failure.0
reserve.continue.310:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.306, i32 %local.source.offset.302, i32 %local.source.extent.303, i32 %local.source.payload.304, i32 8)
  %context.field.311 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.312 = load i32, ptr %context.field.311, align 4
  %runtime.ok.313 = icmp eq i32 %context.value.312, 0
  br i1 %runtime.ok.313, label %runtime.continue.314, label %frame.failure.0
runtime.continue.314:
  %local.is.active.315 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.316 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.317 = select i1 %local.is.active.315, i32 %local.sum.extent.316, i32 0
  %stack.offset.318 = add i32 0, %local.sum.selected.317
  %local.is.active.319 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.320 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.321 = select i1 %local.is.active.319, i32 %local.sum.extent.320, i32 0
  %stack.offset.322 = add i32 %stack.offset.318, %local.sum.selected.321
  %stack.offset.323 = add i32 0, %local.source.extent.303
  %stack.offset.324 = add i32 %stack.offset.322, %stack.offset.323
  %stack.offset.325 = add i32 %context.value.25, %stack.offset.324
  %cursor.status.326 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.325)
  %cursor.ok.327 = icmp eq i32 %cursor.status.326, 0
  br i1 %cursor.ok.327, label %cursor.continue.328, label %frame.failure.0
cursor.continue.328:
  %local.is.active.329 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.329, label %local.remove.330, label %local.keep.331
local.keep.331:
  br label %local.removed.332
local.remove.330:
  %local.remove.offset.333 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.334 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.335 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.336 = load i32, ptr %local.type.7, align 4
  %stack.offset.337 = add i32 %local.remove.offset.333, %local.remove.extent.334
  %context.field.338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.339 = load i32, ptr %context.field.338, align 4
  %stack.sub.340 = sub i32 %context.value.339, %stack.offset.337
  %local.is.active.341 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.342 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.343 = select i1 %local.is.active.341, i32 %local.suffix.payload.342, i32 0
  %stack.offset.344 = add i32 0, %local.suffix.selected.343
  %stack.offset.345 = add i32 0, %local.source.payload.304
  %stack.offset.346 = add i32 %stack.offset.344, %stack.offset.345
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.333, i32 %stack.offset.337, i32 %stack.sub.340, i32 %stack.offset.346, i32 0, i32 14)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  %stack.sub.351 = sub i32 %context.value.339, %local.remove.extent.334
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.351, i32 0, i32 0, i32 0)
  %context.field.352 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.353 = load i32, ptr %context.field.352, align 4
  %runtime.ok.354 = icmp eq i32 %context.value.353, 0
  br i1 %runtime.ok.354, label %runtime.continue.355, label %frame.failure.0
runtime.continue.355:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.336, i32 %local.remove.offset.333, i32 %local.remove.extent.334, i32 %local.remove.payload.335, i32 0, i32 0)
  %context.field.356 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.357 = load i32, ptr %context.field.356, align 4
  %runtime.ok.358 = icmp eq i32 %context.value.357, 0
  br i1 %runtime.ok.358, label %runtime.continue.359, label %frame.failure.0
runtime.continue.359:
  %stack.sub.360 = sub i32 0, %local.remove.payload.335
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.360, i32 %stack.sub.360)
  %context.field.361 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.362 = load i32, ptr %context.field.361, align 4
  %runtime.ok.363 = icmp eq i32 %context.value.362, 0
  br i1 %runtime.ok.363, label %runtime.continue.364, label %frame.failure.0
runtime.continue.364:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.334)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %local.is.active.369 = load i1, ptr %local.active.8, align 1
  %local.later.offset.370 = load i32, ptr %local.offset.9, align 4
  %stack.sub.371 = sub i32 %local.later.offset.370, %local.remove.extent.334
  %local.later.offset.selected.372 = select i1 %local.is.active.369, i32 %stack.sub.371, i32 %local.later.offset.370
  store i32 %local.later.offset.selected.372, ptr %local.offset.9, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.332
local.removed.332:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  %context.field.373 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.374 = load i32, ptr %context.field.373, align 4
  %context.field.375 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.376 = load i32, ptr %context.field.375, align 4
  %context.field.377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.378 = load i32, ptr %context.field.377, align 4
  %stack.offset.379 = add i32 %context.value.16, %context.value.18
  %stack.offset.380 = add i32 %context.value.374, %context.value.376
  %stack.sub.381 = sub i32 %stack.offset.379, %stack.offset.380
  %stack.sub.382 = sub i32 %context.value.18, %context.value.376
  %stack.sub.383 = sub i32 %context.value.378, %context.value.20
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.381, i32 %stack.sub.382)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.383)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 12, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 12, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.extent.pointer.24 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.25 = load i32, ptr %input.extent.pointer.24, align 4
  %host.pointer.26 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.payload.pointer.27 = alloca i32, align 4
  %input.measured.extent.pointer.28 = alloca i32, align 4
  %input.measure.status.29 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.26, i32 %input.host.extent.25, i32 0, i32 13, ptr %input.payload.pointer.27, ptr %input.measured.extent.pointer.28)
  %helper.ok.30 = icmp eq i32 %input.measure.status.29, 0
  br i1 %helper.ok.30, label %helper.continue.31, label %entry.failure.0
helper.continue.31:
  %input.measured.payload.32 = load i32, ptr %input.payload.pointer.27, align 4
  %input.measured.extent.33 = load i32, ptr %input.measured.extent.pointer.28, align 4
  %input.extent.exact.34 = icmp eq i32 %input.measured.extent.33, %input.host.extent.25
  br i1 %input.extent.exact.34, label %input.extent.exact.35, label %input.extent.invalid.36
input.extent.invalid.36:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 13, i32 %input.measured.extent.33, i32 %input.host.extent.25)
  br label %entry.failure.0
input.extent.exact.35:
  %stack.offset.37 = add i32 %stack.offset.23, %input.host.extent.25
  %input.total.exact.38 = icmp eq i32 %stack.offset.37, %input.bytes
  br i1 %input.total.exact.38, label %input.valid.39, label %input.invalid.40
input.invalid.40:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.37, i32 %input.bytes)
  br label %entry.failure.0
input.valid.39:
  %reserve.status.41 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 14)
  %reserve.ok.42 = icmp eq i32 %reserve.status.41, 0
  br i1 %reserve.ok.42, label %reserve.continue.43, label %entry.failure.0
reserve.continue.43:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.45 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.44, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 8, i32 15)
  %helper.ok.46 = icmp eq i32 %input.copy.status.45, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %entry.failure.0
helper.continue.47:
  %host.pointer.48 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.copy.status.49 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.23, ptr %host.pointer.48, i32 %input.host.extent.25, i32 0, i32 %input.measured.payload.32, i32 %input.host.extent.25, i32 8, i32 16)
  %helper.ok.50 = icmp eq i32 %input.copy.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %entry.failure.0
helper.continue.51:
  %entry.body.status.52 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 17)
  %entry.body.ok.53 = icmp eq i32 %entry.body.status.52, 0
  br i1 %entry.body.ok.53, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.54 = add i32 0, %input.bytes
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %value.size.57 = alloca %AlOwningValueSize, align 4
  %measure.status.58 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.54, i32 %context.value.56, i32 18, ptr %value.size.57)
  %helper.ok.59 = icmp eq i32 %measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %value.payload.pointer.61 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 0
  %value.extent.pointer.62 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 1
  %value.payload.63 = load i32, ptr %value.payload.pointer.61, align 4
  %value.extent.64 = load i32, ptr %value.extent.pointer.62, align 4
  %stack.offset.65 = add i32 %stack.offset.54, %value.extent.64
  %stack.offset.66 = add i32 0, %value.payload.63
  %entry.outputs.exact.67 = icmp eq i32 %stack.offset.65, %context.value.56
  br i1 %entry.outputs.exact.67, label %entry.outputs.exact.68, label %entry.failure.0
entry.outputs.exact.68:
  %stack.sub.69 = sub i32 %context.value.56, %stack.offset.54
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.54, i32 %stack.sub.69, i32 %stack.offset.66, i32 0, i32 9)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.69, i32 0, i32 0, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.69, i32 8)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %entry.failure.0
runtime.continue.81:
  %stack.sub.82 = sub i32 0, %stack.offset.66
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.82, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %entry.failure.0
runtime.continue.86:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.offset.93 = add i32 %context.value.88, %context.value.90
  %stack.sub.94 = sub i32 0, %stack.offset.93
  %stack.sub.95 = sub i32 0, %context.value.90
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.94, i32 %stack.sub.95)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.92)
  br label %entry.return.status
entry.return.status:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  ret i32 %context.value.97
}


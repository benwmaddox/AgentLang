%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 12, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %value.size.35 = alloca %AlOwningValueSize, align 4
  %measure.status.36 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.33, i32 %stack.offset.16, i32 3, ptr %value.size.35)
  %helper.ok.37 = icmp eq i32 %measure.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %frame.failure.0
helper.continue.38:
  %value.payload.pointer.39 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 0
  %value.extent.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.35, i32 0, i32 1
  %value.payload.41 = load i32, ptr %value.payload.pointer.39, align 4
  %value.extent.42 = load i32, ptr %value.extent.pointer.40, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.33, i32 %value.extent.42, i32 %value.payload.41, i32 12, i32 8)
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %runtime.ok.45 = icmp eq i32 %context.value.44, 0
  br i1 %runtime.ok.45, label %runtime.continue.46, label %frame.failure.0
runtime.continue.46:
  %stack.offset.47 = add i32 %stack.offset.33, %value.extent.42
  %stack.offset.48 = add i32 %stack.offset.34, %value.extent.42
  %arguments.exact.49 = icmp eq i32 %stack.offset.47, %stack.offset.16
  br i1 %arguments.exact.49, label %arguments.continue.50, label %frame.failure.0
arguments.continue.50:
  %step.status.51 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.52 = icmp eq i32 %step.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %stack.offset.54 = add i32 0, 0
  %stack.offset.55 = add i32 %context.value.15, %stack.offset.54
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.offset.59 = add i32 0, %value.extent.28
  %stack.offset.60 = add i32 %stack.offset.59, %value.extent.42
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.55, i32 %stack.offset.60, i32 5)
  %helper.ok.61 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.61, label %helper.continue.62, label %frame.failure.0
helper.continue.62:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %value.size.65 = alloca %AlOwningValueSize, align 4
  %measure.status.66 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %context.value.57, i32 %context.value.64, i32 6, ptr %value.size.65)
  %helper.ok.67 = icmp eq i32 %measure.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %frame.failure.0
helper.continue.68:
  %value.payload.pointer.69 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 0
  %value.extent.pointer.70 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.65, i32 0, i32 1
  %value.payload.71 = load i32, ptr %value.payload.pointer.69, align 4
  %value.extent.72 = load i32, ptr %value.extent.pointer.70, align 4
  %stack.offset.73 = add i32 %context.value.57, %value.extent.72
  %stack.offset.74 = add i32 0, %value.payload.71
  %callee.outputs.exact.75 = icmp eq i32 %stack.offset.73, %context.value.64
  br i1 %callee.outputs.exact.75, label %callee.outputs.continue.76, label %frame.failure.0
callee.outputs.continue.76:
  %stack.sub.77 = sub i32 %context.value.64, %context.value.57
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.55, i32 %context.value.57, i32 %stack.sub.77, i32 %stack.offset.74, i32 0, i32 9)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %frame.failure.0
runtime.continue.81:
  %stack.offset.82 = add i32 %stack.offset.55, %stack.sub.77
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.82, i32 0, i32 0, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %stack.offset.87 = add i32 0, %value.extent.72
  %stack.offset.88 = add i32 0, %stack.offset.87
  %stack.offset.89 = add i32 %context.value.15, %stack.offset.88
  %cursor.status.90 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.89)
  %cursor.ok.91 = icmp eq i32 %cursor.status.90, 0
  br i1 %cursor.ok.91, label %cursor.continue.92, label %frame.failure.0
cursor.continue.92:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.offset.99 = add i32 %context.value.6, %context.value.8
  %stack.offset.100 = add i32 %context.value.94, %context.value.96
  %stack.sub.101 = sub i32 %stack.offset.99, %stack.offset.100
  %stack.sub.102 = sub i32 %context.value.8, %context.value.96
  %stack.sub.103 = sub i32 %context.value.98, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.101, i32 %stack.sub.102)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.103)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %context.field.15 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.16 = load i32, ptr %context.field.15, align 4
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %frame.entered.21 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.22 = icmp eq i32 %frame.entered.21, 0
  br i1 %frame.enter.ok.22, label %frame.enter.continue.23, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.23:
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %stack.offset.26 = add i32 %argument.source, %argument.bytes
  %stack.offset.27 = add i32 %context.value.25, %argument.bytes
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.27, i32 7)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %frame.reserve.failure.1
reserve.continue.30:
  %value.size.31 = alloca %AlOwningValueSize, align 4
  %measure.status.32 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %argument.source, i32 %stack.offset.26, i32 8, ptr %value.size.31)
  %helper.ok.33 = icmp eq i32 %measure.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %frame.failure.0
helper.continue.34:
  %value.payload.pointer.35 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 0
  %value.extent.pointer.36 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 1
  %value.payload.37 = load i32, ptr %value.payload.pointer.35, align 4
  %value.extent.38 = load i32, ptr %value.extent.pointer.36, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.25, i32 %argument.source, i32 %value.extent.38, i32 %value.payload.37, i32 12, i32 8)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, %value.extent.38
  %stack.offset.44 = add i32 %context.value.25, %value.extent.38
  %value.size.45 = alloca %AlOwningValueSize, align 4
  %measure.status.46 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.43, i32 %stack.offset.26, i32 9, ptr %value.size.45)
  %helper.ok.47 = icmp eq i32 %measure.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %value.payload.pointer.49 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.45, i32 0, i32 0
  %value.extent.pointer.50 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.45, i32 0, i32 1
  %value.payload.51 = load i32, ptr %value.payload.pointer.49, align 4
  %value.extent.52 = load i32, ptr %value.extent.pointer.50, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.44, i32 %stack.offset.43, i32 %value.extent.52, i32 %value.payload.51, i32 12, i32 8)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %stack.offset.43, %value.extent.52
  %stack.offset.58 = add i32 %stack.offset.44, %value.extent.52
  %arguments.exact.59 = icmp eq i32 %stack.offset.57, %stack.offset.26
  br i1 %arguments.exact.59, label %arguments.continue.60, label %frame.failure.0
arguments.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %local.is.active.64 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.65 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.66 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.67 = select i1 %local.is.active.64, i32 %local.previous.extent.65, i32 0
  %local.old.payload.68 = select i1 %local.is.active.64, i32 %local.previous.payload.66, i32 0
  %stack.offset.69 = add i32 %context.value.25, 0
  %stack.offset.70 = add i32 %stack.offset.69, %local.old.extent.67
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %stack.sub.73 = sub i32 %context.value.72, %stack.offset.70
  %stack.sub.74 = sub i32 %context.value.72, %local.old.extent.67
  %stack.offset.75 = add i32 %stack.sub.74, %value.extent.52
  %local.grows.76 = icmp ugt i32 %value.extent.52, %local.old.extent.67
  br i1 %local.grows.76, label %local.grow.77, label %local.fixed.78
local.grow.77:
  %reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.75, i32 11)
  %reserve.ok.81 = icmp eq i32 %reserve.status.80, 0
  br i1 %reserve.ok.81, label %reserve.continue.82, label %frame.failure.0
reserve.continue.82:
  %stack.sub.83 = sub i32 %value.extent.52, %local.old.extent.67
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.83)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  br label %local.layout.ready.79
local.fixed.78:
  br label %local.layout.ready.79
local.layout.ready.79:
  %stack.offset.88 = add i32 %stack.offset.69, %value.extent.52
  %local.is.active.89 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.90 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.91 = select i1 %local.is.active.89, i32 %local.suffix.payload.90, i32 0
  %stack.offset.92 = add i32 0, %local.suffix.selected.91
  %stack.offset.93 = add i32 0, %value.payload.37
  %stack.offset.94 = add i32 %stack.offset.93, %value.payload.51
  %stack.offset.95 = add i32 %stack.offset.92, %stack.offset.94
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.88, i32 %stack.offset.70, i32 %stack.sub.73, i32 %stack.offset.95, i32 0, i32 14)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %runtime.ok.98 = icmp eq i32 %context.value.97, 0
  br i1 %runtime.ok.98, label %runtime.continue.99, label %frame.failure.0
runtime.continue.99:
  %stack.sub.100 = sub i32 %context.value.72, %value.extent.52
  %stack.sub.101 = sub i32 %stack.sub.100, %local.old.extent.67
  %stack.offset.102 = add i32 %stack.sub.101, %value.extent.52
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.69, i32 %stack.offset.102, i32 %value.extent.52, i32 %value.payload.51, i32 12, i32 4)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %stack.sub.107 = sub i32 %context.value.72, %local.old.extent.67
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.107, i32 0, i32 0, i32 0)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %local.shrinks.112 = icmp ult i32 %value.extent.52, %local.old.extent.67
  br i1 %local.shrinks.112, label %local.shrink.113, label %local.counts.ready.114
local.shrink.113:
  %stack.sub.115 = sub i32 %local.old.extent.67, %value.extent.52
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.115)
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %runtime.ok.118 = icmp eq i32 %context.value.117, 0
  br i1 %runtime.ok.118, label %runtime.continue.119, label %frame.failure.0
runtime.continue.119:
  br label %local.counts.ready.114
local.counts.ready.114:
  %local.payload.delta.120 = sub i32 %value.payload.51, %local.old.payload.68
  %stack.sub.121 = sub i32 0, %local.old.payload.68
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.121, i32 %local.payload.delta.120)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %runtime.ok.124 = icmp eq i32 %context.value.123, 0
  br i1 %runtime.ok.124, label %runtime.continue.125, label %frame.failure.0
runtime.continue.125:
  %local.is.active.126 = load i1, ptr %local.active.8, align 1
  %local.later.offset.127 = load i32, ptr %local.offset.9, align 4
  %stack.sub.128 = sub i32 %local.later.offset.127, %local.old.extent.67
  %stack.offset.129 = add i32 %stack.sub.128, %value.extent.52
  %local.later.offset.selected.130 = select i1 %local.is.active.126, i32 %stack.offset.129, i32 %local.later.offset.127
  store i32 %local.later.offset.selected.130, ptr %local.offset.9, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.69, ptr %local.offset.4, align 4
  store i32 %value.extent.52, ptr %local.extent.5, align 4
  store i32 %value.payload.51, ptr %local.payload.6, align 4
  store i32 12, ptr %local.type.7, align 4
  %local.is.active.131 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.132 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.133 = select i1 %local.is.active.131, i32 %local.sum.extent.132, i32 0
  %stack.offset.134 = add i32 0, %local.sum.selected.133
  %local.is.active.135 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.136 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.137 = select i1 %local.is.active.135, i32 %local.sum.extent.136, i32 0
  %stack.offset.138 = add i32 %stack.offset.134, %local.sum.selected.137
  %stack.offset.139 = add i32 0, %value.extent.38
  %stack.offset.140 = add i32 %stack.offset.138, %stack.offset.139
  %stack.offset.141 = add i32 %context.value.25, %stack.offset.140
  %cursor.status.142 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.141)
  %cursor.ok.143 = icmp eq i32 %cursor.status.142, 0
  br i1 %cursor.ok.143, label %cursor.continue.144, label %frame.failure.0
cursor.continue.144:
  %step.status.145 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.146 = icmp eq i32 %step.status.145, 0
  br i1 %helper.ok.146, label %helper.continue.147, label %frame.failure.0
helper.continue.147:
  %local.is.active.148 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.149 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.150 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.151 = select i1 %local.is.active.148, i32 %local.previous.extent.149, i32 0
  %local.old.payload.152 = select i1 %local.is.active.148, i32 %local.previous.payload.150, i32 0
  %local.is.active.153 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.154 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.155 = select i1 %local.is.active.153, i32 %local.sum.extent.154, i32 0
  %stack.offset.156 = add i32 0, %local.sum.selected.155
  %stack.offset.157 = add i32 %context.value.25, %stack.offset.156
  %stack.offset.158 = add i32 %stack.offset.157, %local.old.extent.151
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %stack.sub.161 = sub i32 %context.value.160, %stack.offset.158
  %stack.sub.162 = sub i32 %context.value.160, %local.old.extent.151
  %stack.offset.163 = add i32 %stack.sub.162, %value.extent.38
  %local.grows.164 = icmp ugt i32 %value.extent.38, %local.old.extent.151
  br i1 %local.grows.164, label %local.grow.165, label %local.fixed.166
local.grow.165:
  %reserve.status.168 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.163, i32 13)
  %reserve.ok.169 = icmp eq i32 %reserve.status.168, 0
  br i1 %reserve.ok.169, label %reserve.continue.170, label %frame.failure.0
reserve.continue.170:
  %stack.sub.171 = sub i32 %value.extent.38, %local.old.extent.151
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.171)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %frame.failure.0
runtime.continue.175:
  br label %local.layout.ready.167
local.fixed.166:
  br label %local.layout.ready.167
local.layout.ready.167:
  %stack.offset.176 = add i32 %stack.offset.157, %value.extent.38
  %stack.offset.177 = add i32 0, %value.payload.37
  %stack.offset.178 = add i32 0, %stack.offset.177
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.176, i32 %stack.offset.158, i32 %stack.sub.161, i32 %stack.offset.178, i32 0, i32 14)
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %runtime.ok.181 = icmp eq i32 %context.value.180, 0
  br i1 %runtime.ok.181, label %runtime.continue.182, label %frame.failure.0
runtime.continue.182:
  %stack.sub.183 = sub i32 %context.value.160, %value.extent.38
  %stack.sub.184 = sub i32 %stack.sub.183, %local.old.extent.151
  %stack.offset.185 = add i32 %stack.sub.184, %value.extent.38
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.157, i32 %stack.offset.185, i32 %value.extent.38, i32 %value.payload.37, i32 12, i32 4)
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %runtime.ok.188 = icmp eq i32 %context.value.187, 0
  br i1 %runtime.ok.188, label %runtime.continue.189, label %frame.failure.0
runtime.continue.189:
  %stack.sub.190 = sub i32 %context.value.160, %local.old.extent.151
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.190, i32 0, i32 0, i32 0)
  %context.field.191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.192 = load i32, ptr %context.field.191, align 4
  %runtime.ok.193 = icmp eq i32 %context.value.192, 0
  br i1 %runtime.ok.193, label %runtime.continue.194, label %frame.failure.0
runtime.continue.194:
  %local.shrinks.195 = icmp ult i32 %value.extent.38, %local.old.extent.151
  br i1 %local.shrinks.195, label %local.shrink.196, label %local.counts.ready.197
local.shrink.196:
  %stack.sub.198 = sub i32 %local.old.extent.151, %value.extent.38
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.198)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %frame.failure.0
runtime.continue.202:
  br label %local.counts.ready.197
local.counts.ready.197:
  %local.payload.delta.203 = sub i32 %value.payload.37, %local.old.payload.152
  %stack.sub.204 = sub i32 0, %local.old.payload.152
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.204, i32 %local.payload.delta.203)
  %context.field.205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.206 = load i32, ptr %context.field.205, align 4
  %runtime.ok.207 = icmp eq i32 %context.value.206, 0
  br i1 %runtime.ok.207, label %runtime.continue.208, label %frame.failure.0
runtime.continue.208:
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.157, ptr %local.offset.9, align 4
  store i32 %value.extent.38, ptr %local.extent.10, align 4
  store i32 %value.payload.37, ptr %local.payload.11, align 4
  store i32 12, ptr %local.type.12, align 4
  %local.is.active.209 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.210 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.211 = select i1 %local.is.active.209, i32 %local.sum.extent.210, i32 0
  %stack.offset.212 = add i32 0, %local.sum.selected.211
  %local.is.active.213 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.214 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.215 = select i1 %local.is.active.213, i32 %local.sum.extent.214, i32 0
  %stack.offset.216 = add i32 %stack.offset.212, %local.sum.selected.215
  %stack.offset.217 = add i32 %stack.offset.216, 0
  %stack.offset.218 = add i32 %context.value.25, %stack.offset.217
  %cursor.status.219 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.218)
  %cursor.ok.220 = icmp eq i32 %cursor.status.219, 0
  br i1 %cursor.ok.220, label %cursor.continue.221, label %frame.failure.0
cursor.continue.221:
  %step.status.222 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.223 = icmp eq i32 %step.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  %local.source.offset.225 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.226 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.227 = load i32, ptr %local.payload.11, align 4
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.offset.230 = add i32 %context.value.229, %local.source.extent.226
  %reserve.status.231 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.230, i32 15)
  %reserve.ok.232 = icmp eq i32 %reserve.status.231, 0
  br i1 %reserve.ok.232, label %reserve.continue.233, label %frame.failure.0
reserve.continue.233:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.229, i32 %local.source.offset.225, i32 %local.source.extent.226, i32 %local.source.payload.227, i32 12)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %local.is.active.238 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.239 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.240 = select i1 %local.is.active.238, i32 %local.sum.extent.239, i32 0
  %stack.offset.241 = add i32 0, %local.sum.selected.240
  %local.is.active.242 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.243 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.244 = select i1 %local.is.active.242, i32 %local.sum.extent.243, i32 0
  %stack.offset.245 = add i32 %stack.offset.241, %local.sum.selected.244
  %stack.offset.246 = add i32 0, %local.source.extent.226
  %stack.offset.247 = add i32 %stack.offset.245, %stack.offset.246
  %stack.offset.248 = add i32 %context.value.25, %stack.offset.247
  %cursor.status.249 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.248)
  %cursor.ok.250 = icmp eq i32 %cursor.status.249, 0
  br i1 %cursor.ok.250, label %cursor.continue.251, label %frame.failure.0
cursor.continue.251:
  %step.status.252 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.253 = icmp eq i32 %step.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  %local.source.offset.255 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.256 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.257 = load i32, ptr %local.payload.6, align 4
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %stack.offset.260 = add i32 %context.value.259, %local.source.extent.256
  %reserve.status.261 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.260, i32 17)
  %reserve.ok.262 = icmp eq i32 %reserve.status.261, 0
  br i1 %reserve.ok.262, label %reserve.continue.263, label %frame.failure.0
reserve.continue.263:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.259, i32 %local.source.offset.255, i32 %local.source.extent.256, i32 %local.source.payload.257, i32 12)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %runtime.ok.266 = icmp eq i32 %context.value.265, 0
  br i1 %runtime.ok.266, label %runtime.continue.267, label %frame.failure.0
runtime.continue.267:
  %local.is.active.268 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.269 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.270 = select i1 %local.is.active.268, i32 %local.sum.extent.269, i32 0
  %stack.offset.271 = add i32 0, %local.sum.selected.270
  %local.is.active.272 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.273 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.274 = select i1 %local.is.active.272, i32 %local.sum.extent.273, i32 0
  %stack.offset.275 = add i32 %stack.offset.271, %local.sum.selected.274
  %stack.offset.276 = add i32 0, %local.source.extent.226
  %stack.offset.277 = add i32 %stack.offset.276, %local.source.extent.256
  %stack.offset.278 = add i32 %stack.offset.275, %stack.offset.277
  %stack.offset.279 = add i32 %context.value.25, %stack.offset.278
  %cursor.status.280 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.279)
  %cursor.ok.281 = icmp eq i32 %cursor.status.280, 0
  br i1 %cursor.ok.281, label %cursor.continue.282, label %frame.failure.0
cursor.continue.282:
  %step.status.283 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.284 = icmp eq i32 %step.status.283, 0
  br i1 %helper.ok.284, label %helper.continue.285, label %frame.failure.0
helper.continue.285:
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %local.is.active.288 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.289 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.290 = select i1 %local.is.active.288, i32 %local.sum.extent.289, i32 0
  %stack.offset.291 = add i32 0, %local.sum.selected.290
  %local.is.active.292 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.293 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.294 = select i1 %local.is.active.292, i32 %local.sum.extent.293, i32 0
  %stack.offset.295 = add i32 %stack.offset.291, %local.sum.selected.294
  %stack.offset.296 = add i32 %stack.offset.295, 0
  %stack.offset.297 = add i32 %context.value.25, %stack.offset.296
  %stack.sub.298 = sub i32 %context.value.287, %local.source.extent.256
  %string.concat.units.299 = alloca i32, align 4
  %string.concat.payload.pointer.300 = alloca i32, align 4
  %string.concat.extent.pointer.301 = alloca i32, align 4
  %string.concat.plan.status.302 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.297, i32 %local.source.extent.226, i32 %stack.sub.298, i32 %local.source.extent.256, i32 19, ptr %string.concat.units.299, ptr %string.concat.payload.pointer.300, ptr %string.concat.extent.pointer.301)
  %helper.ok.303 = icmp eq i32 %string.concat.plan.status.302, 0
  br i1 %helper.ok.303, label %helper.continue.304, label %frame.failure.0
helper.continue.304:
  %string.concat.payload.305 = load i32, ptr %string.concat.payload.pointer.300, align 4
  %string.concat.extent.306 = load i32, ptr %string.concat.extent.pointer.301, align 4
  %stack.offset.307 = add i32 %context.value.287, %string.concat.extent.306
  %reserve.status.308 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.307, i32 20)
  %reserve.ok.309 = icmp eq i32 %reserve.status.308, 0
  br i1 %reserve.ok.309, label %reserve.continue.310, label %frame.failure.0
reserve.continue.310:
  %string.concat.write.status.311 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.287, i32 %string.concat.extent.306, i32 %stack.offset.297, i32 %local.source.extent.226, i32 %stack.sub.298, i32 %local.source.extent.256, i32 12, i32 19)
  %helper.ok.312 = icmp eq i32 %string.concat.write.status.311, 0
  br i1 %helper.ok.312, label %helper.continue.313, label %frame.failure.0
helper.continue.313:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.297, i32 %context.value.287, i32 %string.concat.extent.306, i32 %string.concat.payload.305, i32 12, i32 0)
  %context.field.314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.315 = load i32, ptr %context.field.314, align 4
  %runtime.ok.316 = icmp eq i32 %context.value.315, 0
  br i1 %runtime.ok.316, label %runtime.continue.317, label %frame.failure.0
runtime.continue.317:
  %stack.offset.318 = add i32 %stack.offset.297, %string.concat.extent.306
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.318, i32 0, i32 0, i32 0)
  %context.field.319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.320 = load i32, ptr %context.field.319, align 4
  %runtime.ok.321 = icmp eq i32 %context.value.320, 0
  br i1 %runtime.ok.321, label %runtime.continue.322, label %frame.failure.0
runtime.continue.322:
  %stack.offset.323 = add i32 %local.source.payload.227, %local.source.payload.257
  %stack.sub.324 = sub i32 %string.concat.payload.305, %stack.offset.323
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.324, i32 0)
  %context.field.325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.326 = load i32, ptr %context.field.325, align 4
  %runtime.ok.327 = icmp eq i32 %context.value.326, 0
  br i1 %runtime.ok.327, label %runtime.continue.328, label %frame.failure.0
runtime.continue.328:
  %local.is.active.329 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.330 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.331 = select i1 %local.is.active.329, i32 %local.sum.extent.330, i32 0
  %stack.offset.332 = add i32 0, %local.sum.selected.331
  %local.is.active.333 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.334 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.335 = select i1 %local.is.active.333, i32 %local.sum.extent.334, i32 0
  %stack.offset.336 = add i32 %stack.offset.332, %local.sum.selected.335
  %stack.offset.337 = add i32 0, %string.concat.extent.306
  %stack.offset.338 = add i32 %stack.offset.336, %stack.offset.337
  %stack.offset.339 = add i32 %context.value.25, %stack.offset.338
  %cursor.status.340 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.339)
  %cursor.ok.341 = icmp eq i32 %cursor.status.340, 0
  br i1 %cursor.ok.341, label %cursor.continue.342, label %frame.failure.0
cursor.continue.342:
  %local.is.active.343 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.343, label %local.remove.344, label %local.keep.345
local.keep.345:
  br label %local.removed.346
local.remove.344:
  %local.remove.offset.347 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.348 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.349 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.350 = load i32, ptr %local.type.12, align 4
  %stack.offset.351 = add i32 %local.remove.offset.347, %local.remove.extent.348
  %context.field.352 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.353 = load i32, ptr %context.field.352, align 4
  %stack.sub.354 = sub i32 %context.value.353, %stack.offset.351
  %stack.offset.355 = add i32 0, %string.concat.payload.305
  %stack.offset.356 = add i32 0, %stack.offset.355
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.347, i32 %stack.offset.351, i32 %stack.sub.354, i32 %stack.offset.356, i32 0, i32 14)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  %stack.sub.361 = sub i32 %context.value.353, %local.remove.extent.348
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.361, i32 0, i32 0, i32 0)
  %context.field.362 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.363 = load i32, ptr %context.field.362, align 4
  %runtime.ok.364 = icmp eq i32 %context.value.363, 0
  br i1 %runtime.ok.364, label %runtime.continue.365, label %frame.failure.0
runtime.continue.365:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.350, i32 %local.remove.offset.347, i32 %local.remove.extent.348, i32 %local.remove.payload.349, i32 0, i32 0)
  %context.field.366 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.367 = load i32, ptr %context.field.366, align 4
  %runtime.ok.368 = icmp eq i32 %context.value.367, 0
  br i1 %runtime.ok.368, label %runtime.continue.369, label %frame.failure.0
runtime.continue.369:
  %stack.sub.370 = sub i32 0, %local.remove.payload.349
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.370, i32 %stack.sub.370)
  %context.field.371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.372 = load i32, ptr %context.field.371, align 4
  %runtime.ok.373 = icmp eq i32 %context.value.372, 0
  br i1 %runtime.ok.373, label %runtime.continue.374, label %frame.failure.0
runtime.continue.374:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.348)
  %context.field.375 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.376 = load i32, ptr %context.field.375, align 4
  %runtime.ok.377 = icmp eq i32 %context.value.376, 0
  br i1 %runtime.ok.377, label %runtime.continue.378, label %frame.failure.0
runtime.continue.378:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.346
local.removed.346:
  %local.is.active.379 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.379, label %local.remove.380, label %local.keep.381
local.keep.381:
  br label %local.removed.382
local.remove.380:
  %local.remove.offset.383 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.384 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.385 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.386 = load i32, ptr %local.type.7, align 4
  %stack.offset.387 = add i32 %local.remove.offset.383, %local.remove.extent.384
  %context.field.388 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.389 = load i32, ptr %context.field.388, align 4
  %stack.sub.390 = sub i32 %context.value.389, %stack.offset.387
  %local.is.active.391 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.392 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.393 = select i1 %local.is.active.391, i32 %local.suffix.payload.392, i32 0
  %stack.offset.394 = add i32 0, %local.suffix.selected.393
  %stack.offset.395 = add i32 0, %string.concat.payload.305
  %stack.offset.396 = add i32 %stack.offset.394, %stack.offset.395
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.383, i32 %stack.offset.387, i32 %stack.sub.390, i32 %stack.offset.396, i32 0, i32 14)
  %context.field.397 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.398 = load i32, ptr %context.field.397, align 4
  %runtime.ok.399 = icmp eq i32 %context.value.398, 0
  br i1 %runtime.ok.399, label %runtime.continue.400, label %frame.failure.0
runtime.continue.400:
  %stack.sub.401 = sub i32 %context.value.389, %local.remove.extent.384
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.401, i32 0, i32 0, i32 0)
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %runtime.ok.404 = icmp eq i32 %context.value.403, 0
  br i1 %runtime.ok.404, label %runtime.continue.405, label %frame.failure.0
runtime.continue.405:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.386, i32 %local.remove.offset.383, i32 %local.remove.extent.384, i32 %local.remove.payload.385, i32 0, i32 0)
  %context.field.406 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.407 = load i32, ptr %context.field.406, align 4
  %runtime.ok.408 = icmp eq i32 %context.value.407, 0
  br i1 %runtime.ok.408, label %runtime.continue.409, label %frame.failure.0
runtime.continue.409:
  %stack.sub.410 = sub i32 0, %local.remove.payload.385
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.410, i32 %stack.sub.410)
  %context.field.411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.412 = load i32, ptr %context.field.411, align 4
  %runtime.ok.413 = icmp eq i32 %context.value.412, 0
  br i1 %runtime.ok.413, label %runtime.continue.414, label %frame.failure.0
runtime.continue.414:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.384)
  %context.field.415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.416 = load i32, ptr %context.field.415, align 4
  %runtime.ok.417 = icmp eq i32 %context.value.416, 0
  br i1 %runtime.ok.417, label %runtime.continue.418, label %frame.failure.0
runtime.continue.418:
  %local.is.active.419 = load i1, ptr %local.active.8, align 1
  %local.later.offset.420 = load i32, ptr %local.offset.9, align 4
  %stack.sub.421 = sub i32 %local.later.offset.420, %local.remove.extent.384
  %local.later.offset.selected.422 = select i1 %local.is.active.419, i32 %stack.sub.421, i32 %local.later.offset.420
  store i32 %local.later.offset.selected.422, ptr %local.offset.9, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.382
local.removed.382:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  %context.field.423 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.424 = load i32, ptr %context.field.423, align 4
  %context.field.425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.426 = load i32, ptr %context.field.425, align 4
  %context.field.427 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.428 = load i32, ptr %context.field.427, align 4
  %stack.offset.429 = add i32 %context.value.16, %context.value.18
  %stack.offset.430 = add i32 %context.value.424, %context.value.426
  %stack.sub.431 = sub i32 %stack.offset.429, %stack.offset.430
  %stack.sub.432 = sub i32 %context.value.18, %context.value.426
  %stack.sub.433 = sub i32 %context.value.428, %context.value.20
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.431, i32 %stack.sub.432)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.433)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 21, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.extent.pointer.24 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.25 = load i32, ptr %input.extent.pointer.24, align 4
  %host.pointer.26 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.payload.pointer.27 = alloca i32, align 4
  %input.measured.extent.pointer.28 = alloca i32, align 4
  %input.measure.status.29 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.26, i32 %input.host.extent.25, i32 0, i32 22, ptr %input.payload.pointer.27, ptr %input.measured.extent.pointer.28)
  %helper.ok.30 = icmp eq i32 %input.measure.status.29, 0
  br i1 %helper.ok.30, label %helper.continue.31, label %entry.failure.0
helper.continue.31:
  %input.measured.payload.32 = load i32, ptr %input.payload.pointer.27, align 4
  %input.measured.extent.33 = load i32, ptr %input.measured.extent.pointer.28, align 4
  %input.extent.exact.34 = icmp eq i32 %input.measured.extent.33, %input.host.extent.25
  br i1 %input.extent.exact.34, label %input.extent.exact.35, label %input.extent.invalid.36
input.extent.invalid.36:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 22, i32 %input.measured.extent.33, i32 %input.host.extent.25)
  br label %entry.failure.0
input.extent.exact.35:
  %stack.offset.37 = add i32 %stack.offset.23, %input.host.extent.25
  %input.total.exact.38 = icmp eq i32 %stack.offset.37, %input.bytes
  br i1 %input.total.exact.38, label %input.valid.39, label %input.invalid.40
input.invalid.40:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.37, i32 %input.bytes)
  br label %entry.failure.0
input.valid.39:
  %reserve.status.41 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 23)
  %reserve.ok.42 = icmp eq i32 %reserve.status.41, 0
  br i1 %reserve.ok.42, label %reserve.continue.43, label %entry.failure.0
reserve.continue.43:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.45 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.44, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 12, i32 24)
  %helper.ok.46 = icmp eq i32 %input.copy.status.45, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %entry.failure.0
helper.continue.47:
  %host.pointer.48 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.23
  %input.copy.status.49 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.23, ptr %host.pointer.48, i32 %input.host.extent.25, i32 0, i32 %input.measured.payload.32, i32 %input.host.extent.25, i32 12, i32 25)
  %helper.ok.50 = icmp eq i32 %input.copy.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %entry.failure.0
helper.continue.51:
  %entry.body.status.52 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 26)
  %entry.body.ok.53 = icmp eq i32 %entry.body.status.52, 0
  br i1 %entry.body.ok.53, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.54 = add i32 0, %input.bytes
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %value.size.57 = alloca %AlOwningValueSize, align 4
  %measure.status.58 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.54, i32 %context.value.56, i32 27, ptr %value.size.57)
  %helper.ok.59 = icmp eq i32 %measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %value.payload.pointer.61 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 0
  %value.extent.pointer.62 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.57, i32 0, i32 1
  %value.payload.63 = load i32, ptr %value.payload.pointer.61, align 4
  %value.extent.64 = load i32, ptr %value.extent.pointer.62, align 4
  %stack.offset.65 = add i32 %stack.offset.54, %value.extent.64
  %stack.offset.66 = add i32 0, %value.payload.63
  %entry.outputs.exact.67 = icmp eq i32 %stack.offset.65, %context.value.56
  br i1 %entry.outputs.exact.67, label %entry.outputs.exact.68, label %entry.failure.0
entry.outputs.exact.68:
  %stack.sub.69 = sub i32 %context.value.56, %stack.offset.54
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.54, i32 %stack.sub.69, i32 %stack.offset.66, i32 0, i32 9)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.69, i32 0, i32 0, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.69, i32 12)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %entry.failure.0
runtime.continue.81:
  %stack.sub.82 = sub i32 0, %stack.offset.66
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.82, i32 0)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %entry.failure.0
runtime.continue.86:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.offset.93 = add i32 %context.value.88, %context.value.90
  %stack.sub.94 = sub i32 0, %stack.offset.93
  %stack.sub.95 = sub i32 0, %context.value.90
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.94, i32 %stack.sub.95)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.92)
  br label %entry.return.status
entry.return.status:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  ret i32 %context.value.97
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 4, i32 11, i32 4, i32 2, i32 4294967295, i32 4294967295, i32 32, i32 32 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 6, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [6 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 6 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 11, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %stack.offset.40 = add i32 0, 0
  %stack.offset.41 = add i32 %context.value.15, %stack.offset.40
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %stack.offset.45 = add i32 0, %value.extent.28
  %callee.status.44 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.41, i32 %stack.offset.45, i32 4)
  %helper.ok.46 = icmp eq i32 %callee.status.44, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %frame.failure.0
helper.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %value.size.50 = alloca %AlOwningValueSize, align 4
  %measure.status.51 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %context.value.43, i32 %context.value.49, i32 5, ptr %value.size.50)
  %helper.ok.52 = icmp eq i32 %measure.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %value.payload.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 0
  %value.extent.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 1
  %value.payload.56 = load i32, ptr %value.payload.pointer.54, align 4
  %value.extent.57 = load i32, ptr %value.extent.pointer.55, align 4
  %stack.offset.58 = add i32 %context.value.43, %value.extent.57
  %stack.offset.59 = add i32 0, %value.payload.56
  %callee.outputs.exact.60 = icmp eq i32 %stack.offset.58, %context.value.49
  br i1 %callee.outputs.exact.60, label %callee.outputs.continue.61, label %frame.failure.0
callee.outputs.continue.61:
  %stack.sub.62 = sub i32 %context.value.49, %context.value.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.41, i32 %context.value.43, i32 %stack.sub.62, i32 %stack.offset.59, i32 0, i32 9)
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %runtime.ok.65 = icmp eq i32 %context.value.64, 0
  br i1 %runtime.ok.65, label %runtime.continue.66, label %frame.failure.0
runtime.continue.66:
  %stack.offset.67 = add i32 %stack.offset.41, %stack.sub.62
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.67, i32 0, i32 0, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %stack.offset.72 = add i32 0, %value.extent.57
  %stack.offset.73 = add i32 0, %stack.offset.72
  %stack.offset.74 = add i32 %context.value.15, %stack.offset.73
  %cursor.status.75 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.74)
  %cursor.ok.76 = icmp eq i32 %cursor.status.75, 0
  br i1 %cursor.ok.76, label %cursor.continue.77, label %frame.failure.0
cursor.continue.77:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %context.field.82 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.83 = load i32, ptr %context.field.82, align 4
  %stack.offset.84 = add i32 %context.value.6, %context.value.8
  %stack.offset.85 = add i32 %context.value.79, %context.value.81
  %stack.sub.86 = sub i32 %stack.offset.84, %stack.offset.85
  %stack.sub.87 = sub i32 %context.value.8, %context.value.81
  %stack.sub.88 = sub i32 %context.value.83, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.86, i32 %stack.sub.87)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.88)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %context.field.15 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.16 = load i32, ptr %context.field.15, align 4
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %frame.entered.21 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.22 = icmp eq i32 %frame.entered.21, 0
  br i1 %frame.enter.ok.22, label %frame.enter.continue.23, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.23:
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %stack.offset.26 = add i32 %argument.source, %argument.bytes
  %stack.offset.27 = add i32 %context.value.25, %argument.bytes
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.27, i32 6)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %frame.reserve.failure.1
reserve.continue.30:
  %value.size.31 = alloca %AlOwningValueSize, align 4
  %measure.status.32 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.26, i32 7, ptr %value.size.31)
  %helper.ok.33 = icmp eq i32 %measure.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %frame.failure.0
helper.continue.34:
  %value.payload.pointer.35 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 0
  %value.extent.pointer.36 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.31, i32 0, i32 1
  %value.payload.37 = load i32, ptr %value.payload.pointer.35, align 4
  %value.extent.38 = load i32, ptr %value.extent.pointer.36, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.25, i32 %argument.source, i32 %value.extent.38, i32 %value.payload.37, i32 11, i32 8)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, %value.extent.38
  %stack.offset.44 = add i32 %context.value.25, %value.extent.38
  %arguments.exact.45 = icmp eq i32 %stack.offset.43, %stack.offset.26
  br i1 %arguments.exact.45, label %arguments.continue.46, label %frame.failure.0
arguments.continue.46:
  %step.status.47 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.48 = icmp eq i32 %step.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  %local.is.active.50 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.51 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.52 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.53 = select i1 %local.is.active.50, i32 %local.previous.extent.51, i32 0
  %local.old.payload.54 = select i1 %local.is.active.50, i32 %local.previous.payload.52, i32 0
  %stack.offset.55 = add i32 %context.value.25, 0
  %stack.offset.56 = add i32 %stack.offset.55, %local.old.extent.53
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %stack.sub.59 = sub i32 %context.value.58, %stack.offset.56
  %stack.sub.60 = sub i32 %context.value.58, %local.old.extent.53
  %stack.offset.61 = add i32 %stack.sub.60, %value.extent.38
  %local.grows.62 = icmp ugt i32 %value.extent.38, %local.old.extent.53
  br i1 %local.grows.62, label %local.grow.63, label %local.fixed.64
local.grow.63:
  %reserve.status.66 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.61, i32 9)
  %reserve.ok.67 = icmp eq i32 %reserve.status.66, 0
  br i1 %reserve.ok.67, label %reserve.continue.68, label %frame.failure.0
reserve.continue.68:
  %stack.sub.69 = sub i32 %value.extent.38, %local.old.extent.53
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.69)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %frame.failure.0
runtime.continue.73:
  br label %local.layout.ready.65
local.fixed.64:
  br label %local.layout.ready.65
local.layout.ready.65:
  %stack.offset.74 = add i32 %stack.offset.55, %value.extent.38
  %local.is.active.75 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.76 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.77 = select i1 %local.is.active.75, i32 %local.suffix.payload.76, i32 0
  %stack.offset.78 = add i32 0, %local.suffix.selected.77
  %stack.offset.79 = add i32 0, %value.payload.37
  %stack.offset.80 = add i32 %stack.offset.78, %stack.offset.79
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.74, i32 %stack.offset.56, i32 %stack.sub.59, i32 %stack.offset.80, i32 0, i32 14)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %frame.failure.0
runtime.continue.84:
  %stack.sub.85 = sub i32 %context.value.58, %value.extent.38
  %stack.sub.86 = sub i32 %stack.sub.85, %local.old.extent.53
  %stack.offset.87 = add i32 %stack.sub.86, %value.extent.38
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.55, i32 %stack.offset.87, i32 %value.extent.38, i32 %value.payload.37, i32 11, i32 4)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %frame.failure.0
runtime.continue.91:
  %stack.sub.92 = sub i32 %context.value.58, %local.old.extent.53
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.92, i32 0, i32 0, i32 0)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %local.shrinks.97 = icmp ult i32 %value.extent.38, %local.old.extent.53
  br i1 %local.shrinks.97, label %local.shrink.98, label %local.counts.ready.99
local.shrink.98:
  %stack.sub.100 = sub i32 %local.old.extent.53, %value.extent.38
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.100)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %frame.failure.0
runtime.continue.104:
  br label %local.counts.ready.99
local.counts.ready.99:
  %local.payload.delta.105 = sub i32 %value.payload.37, %local.old.payload.54
  %stack.sub.106 = sub i32 0, %local.old.payload.54
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.106, i32 %local.payload.delta.105)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %runtime.ok.109 = icmp eq i32 %context.value.108, 0
  br i1 %runtime.ok.109, label %runtime.continue.110, label %frame.failure.0
runtime.continue.110:
  %local.is.active.111 = load i1, ptr %local.active.8, align 1
  %local.later.offset.112 = load i32, ptr %local.offset.9, align 4
  %stack.sub.113 = sub i32 %local.later.offset.112, %local.old.extent.53
  %stack.offset.114 = add i32 %stack.sub.113, %value.extent.38
  %local.later.offset.selected.115 = select i1 %local.is.active.111, i32 %stack.offset.114, i32 %local.later.offset.112
  store i32 %local.later.offset.selected.115, ptr %local.offset.9, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.55, ptr %local.offset.4, align 4
  store i32 %value.extent.38, ptr %local.extent.5, align 4
  store i32 %value.payload.37, ptr %local.payload.6, align 4
  store i32 11, ptr %local.type.7, align 4
  %local.is.active.116 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.117 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.118 = select i1 %local.is.active.116, i32 %local.sum.extent.117, i32 0
  %stack.offset.119 = add i32 0, %local.sum.selected.118
  %local.is.active.120 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.121 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.122 = select i1 %local.is.active.120, i32 %local.sum.extent.121, i32 0
  %stack.offset.123 = add i32 %stack.offset.119, %local.sum.selected.122
  %stack.offset.124 = add i32 %stack.offset.123, 0
  %stack.offset.125 = add i32 %context.value.25, %stack.offset.124
  %cursor.status.126 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.125)
  %cursor.ok.127 = icmp eq i32 %cursor.status.126, 0
  br i1 %cursor.ok.127, label %cursor.continue.128, label %frame.failure.0
cursor.continue.128:
  %step.status.129 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.130 = icmp eq i32 %step.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  %local.source.offset.132 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.133 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.134 = load i32, ptr %local.payload.6, align 4
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %stack.offset.137 = add i32 %context.value.136, %local.source.extent.133
  %reserve.status.138 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.137, i32 11)
  %reserve.ok.139 = icmp eq i32 %reserve.status.138, 0
  br i1 %reserve.ok.139, label %reserve.continue.140, label %frame.failure.0
reserve.continue.140:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.136, i32 %local.source.offset.132, i32 %local.source.extent.133, i32 %local.source.payload.134, i32 11)
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %runtime.ok.143 = icmp eq i32 %context.value.142, 0
  br i1 %runtime.ok.143, label %runtime.continue.144, label %frame.failure.0
runtime.continue.144:
  %local.is.active.145 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.146 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.147 = select i1 %local.is.active.145, i32 %local.sum.extent.146, i32 0
  %stack.offset.148 = add i32 0, %local.sum.selected.147
  %local.is.active.149 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.150 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.151 = select i1 %local.is.active.149, i32 %local.sum.extent.150, i32 0
  %stack.offset.152 = add i32 %stack.offset.148, %local.sum.selected.151
  %stack.offset.153 = add i32 0, %local.source.extent.133
  %stack.offset.154 = add i32 %stack.offset.152, %stack.offset.153
  %stack.offset.155 = add i32 %context.value.25, %stack.offset.154
  %cursor.status.156 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.155)
  %cursor.ok.157 = icmp eq i32 %cursor.status.156, 0
  br i1 %cursor.ok.157, label %cursor.continue.158, label %frame.failure.0
cursor.continue.158:
  %step.status.159 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.160 = icmp eq i32 %step.status.159, 0
  br i1 %helper.ok.160, label %helper.continue.161, label %frame.failure.0
helper.continue.161:
  %local.is.active.162 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.163 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.164 = select i1 %local.is.active.162, i32 %local.sum.extent.163, i32 0
  %stack.offset.165 = add i32 0, %local.sum.selected.164
  %local.is.active.166 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.167 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.168 = select i1 %local.is.active.166, i32 %local.sum.extent.167, i32 0
  %stack.offset.169 = add i32 %stack.offset.165, %local.sum.selected.168
  %stack.offset.170 = add i32 %stack.offset.169, 0
  %stack.offset.171 = add i32 %context.value.25, %stack.offset.170
  %field.location.172 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.173 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.171, i32 %local.source.extent.133, i32 1, i32 13, ptr %field.location.172)
  %helper.ok.174 = icmp eq i32 %field.location.status.173, 0
  br i1 %helper.ok.174, label %helper.continue.175, label %frame.failure.0
helper.continue.175:
  %field.offset.pointer.176 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.172, i32 0, i32 0
  %field.offset.177 = load i32, ptr %field.offset.pointer.176, align 4
  %field.payload.pointer.178 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.172, i32 0, i32 1
  %field.payload.179 = load i32, ptr %field.payload.pointer.178, align 4
  %field.extent.pointer.180 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.172, i32 0, i32 2
  %field.extent.181 = load i32, ptr %field.extent.pointer.180, align 4
  %stack.offset.182 = add i32 %stack.offset.171, %field.extent.181
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %field.result.grows.185 = icmp ugt i32 %stack.offset.182, %context.value.184
  br i1 %field.result.grows.185, label %field.result.reserve.186, label %field.result.existing.187
field.result.reserve.186:
  %reserve.status.189 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.182, i32 14)
  %reserve.ok.190 = icmp eq i32 %reserve.status.189, 0
  br i1 %reserve.ok.190, label %reserve.continue.191, label %frame.failure.0
reserve.continue.191:
  br label %field.result.ready.188
field.result.existing.187:
  br label %field.result.ready.188
field.result.ready.188:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.171, i32 %field.offset.177, i32 %field.extent.181, i32 %field.payload.179, i32 8, i32 7)
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %runtime.ok.194 = icmp eq i32 %context.value.193, 0
  br i1 %runtime.ok.194, label %runtime.continue.195, label %frame.failure.0
runtime.continue.195:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.182, i32 0, i32 0, i32 0)
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %runtime.ok.198 = icmp eq i32 %context.value.197, 0
  br i1 %runtime.ok.198, label %runtime.continue.199, label %frame.failure.0
runtime.continue.199:
  %stack.sub.200 = sub i32 %field.payload.179, %local.source.payload.134
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.200, i32 0)
  %context.field.201 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.202 = load i32, ptr %context.field.201, align 4
  %runtime.ok.203 = icmp eq i32 %context.value.202, 0
  br i1 %runtime.ok.203, label %runtime.continue.204, label %frame.failure.0
runtime.continue.204:
  %local.is.active.205 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.206 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.207 = select i1 %local.is.active.205, i32 %local.sum.extent.206, i32 0
  %stack.offset.208 = add i32 0, %local.sum.selected.207
  %local.is.active.209 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.210 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.211 = select i1 %local.is.active.209, i32 %local.sum.extent.210, i32 0
  %stack.offset.212 = add i32 %stack.offset.208, %local.sum.selected.211
  %stack.offset.213 = add i32 0, %field.extent.181
  %stack.offset.214 = add i32 %stack.offset.212, %stack.offset.213
  %stack.offset.215 = add i32 %context.value.25, %stack.offset.214
  %cursor.status.216 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.215)
  %cursor.ok.217 = icmp eq i32 %cursor.status.216, 0
  br i1 %cursor.ok.217, label %cursor.continue.218, label %frame.failure.0
cursor.continue.218:
  %step.status.219 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.220 = icmp eq i32 %step.status.219, 0
  br i1 %helper.ok.220, label %helper.continue.221, label %frame.failure.0
helper.continue.221:
  %local.is.active.222 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.223 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.224 = select i1 %local.is.active.222, i32 %local.sum.extent.223, i32 0
  %stack.offset.225 = add i32 0, %local.sum.selected.224
  %local.is.active.226 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.227 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.228 = select i1 %local.is.active.226, i32 %local.sum.extent.227, i32 0
  %stack.offset.229 = add i32 %stack.offset.225, %local.sum.selected.228
  %stack.offset.230 = add i32 %stack.offset.229, 0
  %stack.offset.231 = add i32 %context.value.25, %stack.offset.230
  %field.location.232 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.233 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.231, i32 %field.extent.181, i32 0, i32 16, ptr %field.location.232)
  %helper.ok.234 = icmp eq i32 %field.location.status.233, 0
  br i1 %helper.ok.234, label %helper.continue.235, label %frame.failure.0
helper.continue.235:
  %field.offset.pointer.236 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.232, i32 0, i32 0
  %field.offset.237 = load i32, ptr %field.offset.pointer.236, align 4
  %field.payload.pointer.238 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.232, i32 0, i32 1
  %field.payload.239 = load i32, ptr %field.payload.pointer.238, align 4
  %field.extent.pointer.240 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.232, i32 0, i32 2
  %field.extent.241 = load i32, ptr %field.extent.pointer.240, align 4
  %stack.offset.242 = add i32 %stack.offset.231, %field.extent.241
  %context.field.243 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.244 = load i32, ptr %context.field.243, align 4
  %field.result.grows.245 = icmp ugt i32 %stack.offset.242, %context.value.244
  br i1 %field.result.grows.245, label %field.result.reserve.246, label %field.result.existing.247
field.result.reserve.246:
  %reserve.status.249 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.242, i32 17)
  %reserve.ok.250 = icmp eq i32 %reserve.status.249, 0
  br i1 %reserve.ok.250, label %reserve.continue.251, label %frame.failure.0
reserve.continue.251:
  br label %field.result.ready.248
field.result.existing.247:
  br label %field.result.ready.248
field.result.ready.248:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.231, i32 %field.offset.237, i32 %field.extent.241, i32 %field.payload.239, i32 9, i32 7)
  %context.field.252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.253 = load i32, ptr %context.field.252, align 4
  %runtime.ok.254 = icmp eq i32 %context.value.253, 0
  br i1 %runtime.ok.254, label %runtime.continue.255, label %frame.failure.0
runtime.continue.255:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.242, i32 0, i32 0, i32 0)
  %context.field.256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.257 = load i32, ptr %context.field.256, align 4
  %runtime.ok.258 = icmp eq i32 %context.value.257, 0
  br i1 %runtime.ok.258, label %runtime.continue.259, label %frame.failure.0
runtime.continue.259:
  %stack.sub.260 = sub i32 %field.payload.239, %field.payload.179
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.260, i32 0)
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %runtime.ok.263 = icmp eq i32 %context.value.262, 0
  br i1 %runtime.ok.263, label %runtime.continue.264, label %frame.failure.0
runtime.continue.264:
  %local.is.active.265 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.266 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.267 = select i1 %local.is.active.265, i32 %local.sum.extent.266, i32 0
  %stack.offset.268 = add i32 0, %local.sum.selected.267
  %local.is.active.269 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.270 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.271 = select i1 %local.is.active.269, i32 %local.sum.extent.270, i32 0
  %stack.offset.272 = add i32 %stack.offset.268, %local.sum.selected.271
  %stack.offset.273 = add i32 0, %field.extent.241
  %stack.offset.274 = add i32 %stack.offset.272, %stack.offset.273
  %stack.offset.275 = add i32 %context.value.25, %stack.offset.274
  %cursor.status.276 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.275)
  %cursor.ok.277 = icmp eq i32 %cursor.status.276, 0
  br i1 %cursor.ok.277, label %cursor.continue.278, label %frame.failure.0
cursor.continue.278:
  %step.status.279 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.280 = icmp eq i32 %step.status.279, 0
  br i1 %helper.ok.280, label %helper.continue.281, label %frame.failure.0
helper.continue.281:
  %local.is.active.282 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.283 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.284 = select i1 %local.is.active.282, i32 %local.sum.extent.283, i32 0
  %stack.offset.285 = add i32 0, %local.sum.selected.284
  %local.is.active.286 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.287 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.288 = select i1 %local.is.active.286, i32 %local.sum.extent.287, i32 0
  %stack.offset.289 = add i32 %stack.offset.285, %local.sum.selected.288
  %stack.offset.290 = add i32 %stack.offset.289, 0
  %stack.offset.291 = add i32 %context.value.25, %stack.offset.290
  %field.location.292 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.293 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.291, i32 %field.extent.241, i32 0, i32 19, ptr %field.location.292)
  %helper.ok.294 = icmp eq i32 %field.location.status.293, 0
  br i1 %helper.ok.294, label %helper.continue.295, label %frame.failure.0
helper.continue.295:
  %field.offset.pointer.296 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.292, i32 0, i32 0
  %field.offset.297 = load i32, ptr %field.offset.pointer.296, align 4
  %field.payload.pointer.298 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.292, i32 0, i32 1
  %field.payload.299 = load i32, ptr %field.payload.pointer.298, align 4
  %field.extent.pointer.300 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.292, i32 0, i32 2
  %field.extent.301 = load i32, ptr %field.extent.pointer.300, align 4
  %stack.offset.302 = add i32 %stack.offset.291, %field.extent.301
  %context.field.303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.304 = load i32, ptr %context.field.303, align 4
  %field.result.grows.305 = icmp ugt i32 %stack.offset.302, %context.value.304
  br i1 %field.result.grows.305, label %field.result.reserve.306, label %field.result.existing.307
field.result.reserve.306:
  %reserve.status.309 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.302, i32 20)
  %reserve.ok.310 = icmp eq i32 %reserve.status.309, 0
  br i1 %reserve.ok.310, label %reserve.continue.311, label %frame.failure.0
reserve.continue.311:
  br label %field.result.ready.308
field.result.existing.307:
  br label %field.result.ready.308
field.result.ready.308:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.291, i32 %field.offset.297, i32 %field.extent.301, i32 %field.payload.299, i32 12, i32 7)
  %context.field.312 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.313 = load i32, ptr %context.field.312, align 4
  %runtime.ok.314 = icmp eq i32 %context.value.313, 0
  br i1 %runtime.ok.314, label %runtime.continue.315, label %frame.failure.0
runtime.continue.315:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.302, i32 0, i32 0, i32 0)
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %runtime.ok.318 = icmp eq i32 %context.value.317, 0
  br i1 %runtime.ok.318, label %runtime.continue.319, label %frame.failure.0
runtime.continue.319:
  %stack.sub.320 = sub i32 %field.payload.299, %field.payload.239
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.320, i32 0)
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %runtime.ok.323 = icmp eq i32 %context.value.322, 0
  br i1 %runtime.ok.323, label %runtime.continue.324, label %frame.failure.0
runtime.continue.324:
  %local.is.active.325 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.326 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.327 = select i1 %local.is.active.325, i32 %local.sum.extent.326, i32 0
  %stack.offset.328 = add i32 0, %local.sum.selected.327
  %local.is.active.329 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.330 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.331 = select i1 %local.is.active.329, i32 %local.sum.extent.330, i32 0
  %stack.offset.332 = add i32 %stack.offset.328, %local.sum.selected.331
  %stack.offset.333 = add i32 0, %field.extent.301
  %stack.offset.334 = add i32 %stack.offset.332, %stack.offset.333
  %stack.offset.335 = add i32 %context.value.25, %stack.offset.334
  %cursor.status.336 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.335)
  %cursor.ok.337 = icmp eq i32 %cursor.status.336, 0
  br i1 %cursor.ok.337, label %cursor.continue.338, label %frame.failure.0
cursor.continue.338:
  %step.status.339 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.340 = icmp eq i32 %step.status.339, 0
  br i1 %helper.ok.340, label %helper.continue.341, label %frame.failure.0
helper.continue.341:
  %context.field.342 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.343 = load i32, ptr %context.field.342, align 4
  %stack.offset.344 = add i32 %context.value.343, 16
  %reserve.status.345 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.344, i32 22)
  %reserve.ok.346 = icmp eq i32 %reserve.status.345, 0
  br i1 %reserve.ok.346, label %reserve.continue.347, label %frame.failure.0
reserve.continue.347:
  %literal.status.348 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.343, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 23)
  %helper.ok.349 = icmp eq i32 %literal.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %frame.failure.0
helper.continue.350:
  %local.is.active.351 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.352 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.353 = select i1 %local.is.active.351, i32 %local.sum.extent.352, i32 0
  %stack.offset.354 = add i32 0, %local.sum.selected.353
  %local.is.active.355 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.356 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.357 = select i1 %local.is.active.355, i32 %local.sum.extent.356, i32 0
  %stack.offset.358 = add i32 %stack.offset.354, %local.sum.selected.357
  %stack.offset.359 = add i32 0, %field.extent.301
  %stack.offset.360 = add i32 %stack.offset.359, 16
  %stack.offset.361 = add i32 %stack.offset.358, %stack.offset.360
  %stack.offset.362 = add i32 %context.value.25, %stack.offset.361
  %cursor.status.363 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.362)
  %cursor.ok.364 = icmp eq i32 %cursor.status.363, 0
  br i1 %cursor.ok.364, label %cursor.continue.365, label %frame.failure.0
cursor.continue.365:
  %step.status.366 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.367 = icmp eq i32 %step.status.366, 0
  br i1 %helper.ok.367, label %helper.continue.368, label %frame.failure.0
helper.continue.368:
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %local.is.active.371 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.372 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.373 = select i1 %local.is.active.371, i32 %local.sum.extent.372, i32 0
  %stack.offset.374 = add i32 0, %local.sum.selected.373
  %local.is.active.375 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.376 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.377 = select i1 %local.is.active.375, i32 %local.sum.extent.376, i32 0
  %stack.offset.378 = add i32 %stack.offset.374, %local.sum.selected.377
  %stack.offset.379 = add i32 %stack.offset.378, 0
  %stack.offset.380 = add i32 %context.value.25, %stack.offset.379
  %stack.sub.381 = sub i32 %context.value.370, 16
  %string.concat.units.382 = alloca i32, align 4
  %string.concat.payload.pointer.383 = alloca i32, align 4
  %string.concat.extent.pointer.384 = alloca i32, align 4
  %string.concat.plan.status.385 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.380, i32 %field.extent.301, i32 %stack.sub.381, i32 16, i32 25, ptr %string.concat.units.382, ptr %string.concat.payload.pointer.383, ptr %string.concat.extent.pointer.384)
  %helper.ok.386 = icmp eq i32 %string.concat.plan.status.385, 0
  br i1 %helper.ok.386, label %helper.continue.387, label %frame.failure.0
helper.continue.387:
  %string.concat.payload.388 = load i32, ptr %string.concat.payload.pointer.383, align 4
  %string.concat.extent.389 = load i32, ptr %string.concat.extent.pointer.384, align 4
  %stack.offset.390 = add i32 %context.value.370, %string.concat.extent.389
  %reserve.status.391 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.390, i32 26)
  %reserve.ok.392 = icmp eq i32 %reserve.status.391, 0
  br i1 %reserve.ok.392, label %reserve.continue.393, label %frame.failure.0
reserve.continue.393:
  %string.concat.write.status.394 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.370, i32 %string.concat.extent.389, i32 %stack.offset.380, i32 %field.extent.301, i32 %stack.sub.381, i32 16, i32 12, i32 25)
  %helper.ok.395 = icmp eq i32 %string.concat.write.status.394, 0
  br i1 %helper.ok.395, label %helper.continue.396, label %frame.failure.0
helper.continue.396:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.380, i32 %context.value.370, i32 %string.concat.extent.389, i32 %string.concat.payload.388, i32 12, i32 0)
  %context.field.397 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.398 = load i32, ptr %context.field.397, align 4
  %runtime.ok.399 = icmp eq i32 %context.value.398, 0
  br i1 %runtime.ok.399, label %runtime.continue.400, label %frame.failure.0
runtime.continue.400:
  %stack.offset.401 = add i32 %stack.offset.380, %string.concat.extent.389
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.401, i32 0, i32 0, i32 0)
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %runtime.ok.404 = icmp eq i32 %context.value.403, 0
  br i1 %runtime.ok.404, label %runtime.continue.405, label %frame.failure.0
runtime.continue.405:
  %stack.offset.406 = add i32 %field.payload.299, 10
  %stack.sub.407 = sub i32 %string.concat.payload.388, %stack.offset.406
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.407, i32 0)
  %context.field.408 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.409 = load i32, ptr %context.field.408, align 4
  %runtime.ok.410 = icmp eq i32 %context.value.409, 0
  br i1 %runtime.ok.410, label %runtime.continue.411, label %frame.failure.0
runtime.continue.411:
  %local.is.active.412 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.413 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.414 = select i1 %local.is.active.412, i32 %local.sum.extent.413, i32 0
  %stack.offset.415 = add i32 0, %local.sum.selected.414
  %local.is.active.416 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.417 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.418 = select i1 %local.is.active.416, i32 %local.sum.extent.417, i32 0
  %stack.offset.419 = add i32 %stack.offset.415, %local.sum.selected.418
  %stack.offset.420 = add i32 0, %string.concat.extent.389
  %stack.offset.421 = add i32 %stack.offset.419, %stack.offset.420
  %stack.offset.422 = add i32 %context.value.25, %stack.offset.421
  %cursor.status.423 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.422)
  %cursor.ok.424 = icmp eq i32 %cursor.status.423, 0
  br i1 %cursor.ok.424, label %cursor.continue.425, label %frame.failure.0
cursor.continue.425:
  %step.status.426 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.427 = icmp eq i32 %step.status.426, 0
  br i1 %helper.ok.427, label %helper.continue.428, label %frame.failure.0
helper.continue.428:
  %local.is.active.429 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.430 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.431 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.432 = select i1 %local.is.active.429, i32 %local.previous.extent.430, i32 0
  %local.old.payload.433 = select i1 %local.is.active.429, i32 %local.previous.payload.431, i32 0
  %local.is.active.434 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.435 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.436 = select i1 %local.is.active.434, i32 %local.sum.extent.435, i32 0
  %stack.offset.437 = add i32 0, %local.sum.selected.436
  %stack.offset.438 = add i32 %context.value.25, %stack.offset.437
  %stack.offset.439 = add i32 %stack.offset.438, %local.old.extent.432
  %context.field.440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.441 = load i32, ptr %context.field.440, align 4
  %stack.sub.442 = sub i32 %context.value.441, %stack.offset.439
  %stack.sub.443 = sub i32 %context.value.441, %local.old.extent.432
  %stack.offset.444 = add i32 %stack.sub.443, %string.concat.extent.389
  %local.grows.445 = icmp ugt i32 %string.concat.extent.389, %local.old.extent.432
  br i1 %local.grows.445, label %local.grow.446, label %local.fixed.447
local.grow.446:
  %reserve.status.449 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.444, i32 28)
  %reserve.ok.450 = icmp eq i32 %reserve.status.449, 0
  br i1 %reserve.ok.450, label %reserve.continue.451, label %frame.failure.0
reserve.continue.451:
  %stack.sub.452 = sub i32 %string.concat.extent.389, %local.old.extent.432
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.452)
  %context.field.453 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.454 = load i32, ptr %context.field.453, align 4
  %runtime.ok.455 = icmp eq i32 %context.value.454, 0
  br i1 %runtime.ok.455, label %runtime.continue.456, label %frame.failure.0
runtime.continue.456:
  br label %local.layout.ready.448
local.fixed.447:
  br label %local.layout.ready.448
local.layout.ready.448:
  %stack.offset.457 = add i32 %stack.offset.438, %string.concat.extent.389
  %stack.offset.458 = add i32 0, %string.concat.payload.388
  %stack.offset.459 = add i32 0, %stack.offset.458
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.457, i32 %stack.offset.439, i32 %stack.sub.442, i32 %stack.offset.459, i32 0, i32 14)
  %context.field.460 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.461 = load i32, ptr %context.field.460, align 4
  %runtime.ok.462 = icmp eq i32 %context.value.461, 0
  br i1 %runtime.ok.462, label %runtime.continue.463, label %frame.failure.0
runtime.continue.463:
  %stack.sub.464 = sub i32 %context.value.441, %string.concat.extent.389
  %stack.sub.465 = sub i32 %stack.sub.464, %local.old.extent.432
  %stack.offset.466 = add i32 %stack.sub.465, %string.concat.extent.389
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.438, i32 %stack.offset.466, i32 %string.concat.extent.389, i32 %string.concat.payload.388, i32 12, i32 4)
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %runtime.ok.469 = icmp eq i32 %context.value.468, 0
  br i1 %runtime.ok.469, label %runtime.continue.470, label %frame.failure.0
runtime.continue.470:
  %stack.sub.471 = sub i32 %context.value.441, %local.old.extent.432
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.471, i32 0, i32 0, i32 0)
  %context.field.472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.473 = load i32, ptr %context.field.472, align 4
  %runtime.ok.474 = icmp eq i32 %context.value.473, 0
  br i1 %runtime.ok.474, label %runtime.continue.475, label %frame.failure.0
runtime.continue.475:
  %local.shrinks.476 = icmp ult i32 %string.concat.extent.389, %local.old.extent.432
  br i1 %local.shrinks.476, label %local.shrink.477, label %local.counts.ready.478
local.shrink.477:
  %stack.sub.479 = sub i32 %local.old.extent.432, %string.concat.extent.389
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.479)
  %context.field.480 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.481 = load i32, ptr %context.field.480, align 4
  %runtime.ok.482 = icmp eq i32 %context.value.481, 0
  br i1 %runtime.ok.482, label %runtime.continue.483, label %frame.failure.0
runtime.continue.483:
  br label %local.counts.ready.478
local.counts.ready.478:
  %local.payload.delta.484 = sub i32 %string.concat.payload.388, %local.old.payload.433
  %stack.sub.485 = sub i32 0, %local.old.payload.433
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.485, i32 %local.payload.delta.484)
  %context.field.486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.487 = load i32, ptr %context.field.486, align 4
  %runtime.ok.488 = icmp eq i32 %context.value.487, 0
  br i1 %runtime.ok.488, label %runtime.continue.489, label %frame.failure.0
runtime.continue.489:
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.438, ptr %local.offset.9, align 4
  store i32 %string.concat.extent.389, ptr %local.extent.10, align 4
  store i32 %string.concat.payload.388, ptr %local.payload.11, align 4
  store i32 12, ptr %local.type.12, align 4
  %local.is.active.490 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.491 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.492 = select i1 %local.is.active.490, i32 %local.sum.extent.491, i32 0
  %stack.offset.493 = add i32 0, %local.sum.selected.492
  %local.is.active.494 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.495 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.496 = select i1 %local.is.active.494, i32 %local.sum.extent.495, i32 0
  %stack.offset.497 = add i32 %stack.offset.493, %local.sum.selected.496
  %stack.offset.498 = add i32 %stack.offset.497, 0
  %stack.offset.499 = add i32 %context.value.25, %stack.offset.498
  %cursor.status.500 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.499)
  %cursor.ok.501 = icmp eq i32 %cursor.status.500, 0
  br i1 %cursor.ok.501, label %cursor.continue.502, label %frame.failure.0
cursor.continue.502:
  %step.status.503 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.504 = icmp eq i32 %step.status.503, 0
  br i1 %helper.ok.504, label %helper.continue.505, label %frame.failure.0
helper.continue.505:
  %context.field.506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.507 = load i32, ptr %context.field.506, align 4
  %stack.offset.508 = add i32 %context.value.507, 8
  %reserve.status.509 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.508, i32 30)
  %reserve.ok.510 = icmp eq i32 %reserve.status.509, 0
  br i1 %reserve.ok.510, label %reserve.continue.511, label %frame.failure.0
reserve.continue.511:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.507, i64 1, i32 1)
  %context.field.512 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.513 = load i32, ptr %context.field.512, align 4
  %runtime.ok.514 = icmp eq i32 %context.value.513, 0
  br i1 %runtime.ok.514, label %runtime.continue.515, label %frame.failure.0
runtime.continue.515:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.517 = load i32, ptr %context.field.516, align 4
  %runtime.ok.518 = icmp eq i32 %context.value.517, 0
  br i1 %runtime.ok.518, label %runtime.continue.519, label %frame.failure.0
runtime.continue.519:
  %local.is.active.520 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.521 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.522 = select i1 %local.is.active.520, i32 %local.sum.extent.521, i32 0
  %stack.offset.523 = add i32 0, %local.sum.selected.522
  %local.is.active.524 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.525 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.526 = select i1 %local.is.active.524, i32 %local.sum.extent.525, i32 0
  %stack.offset.527 = add i32 %stack.offset.523, %local.sum.selected.526
  %stack.offset.528 = add i32 0, 8
  %stack.offset.529 = add i32 %stack.offset.527, %stack.offset.528
  %stack.offset.530 = add i32 %context.value.25, %stack.offset.529
  %cursor.status.531 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.530)
  %cursor.ok.532 = icmp eq i32 %cursor.status.531, 0
  br i1 %cursor.ok.532, label %cursor.continue.533, label %frame.failure.0
cursor.continue.533:
  %step.status.534 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %helper.ok.535 = icmp eq i32 %step.status.534, 0
  br i1 %helper.ok.535, label %helper.continue.536, label %frame.failure.0
helper.continue.536:
  %context.field.537 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.538 = load i32, ptr %context.field.537, align 4
  %stack.offset.539 = add i32 %context.value.538, 8
  %reserve.status.540 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.539, i32 32)
  %reserve.ok.541 = icmp eq i32 %reserve.status.540, 0
  br i1 %reserve.ok.541, label %reserve.continue.542, label %frame.failure.0
reserve.continue.542:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.538, i64 0, i32 1)
  %context.field.543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.544 = load i32, ptr %context.field.543, align 4
  %runtime.ok.545 = icmp eq i32 %context.value.544, 0
  br i1 %runtime.ok.545, label %runtime.continue.546, label %frame.failure.0
runtime.continue.546:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.548 = load i32, ptr %context.field.547, align 4
  %runtime.ok.549 = icmp eq i32 %context.value.548, 0
  br i1 %runtime.ok.549, label %runtime.continue.550, label %frame.failure.0
runtime.continue.550:
  %local.is.active.551 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.552 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.553 = select i1 %local.is.active.551, i32 %local.sum.extent.552, i32 0
  %stack.offset.554 = add i32 0, %local.sum.selected.553
  %local.is.active.555 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.556 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.557 = select i1 %local.is.active.555, i32 %local.sum.extent.556, i32 0
  %stack.offset.558 = add i32 %stack.offset.554, %local.sum.selected.557
  %stack.offset.559 = add i32 0, 8
  %stack.offset.560 = add i32 %stack.offset.559, 8
  %stack.offset.561 = add i32 %stack.offset.558, %stack.offset.560
  %stack.offset.562 = add i32 %context.value.25, %stack.offset.561
  %cursor.status.563 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.562)
  %cursor.ok.564 = icmp eq i32 %cursor.status.563, 0
  br i1 %cursor.ok.564, label %cursor.continue.565, label %frame.failure.0
cursor.continue.565:
  %step.status.566 = call i32 @al_owning_charge_step(ptr %ctx, i32 33)
  %helper.ok.567 = icmp eq i32 %step.status.566, 0
  br i1 %helper.ok.567, label %helper.continue.568, label %frame.failure.0
helper.continue.568:
  %context.field.569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.570 = load i32, ptr %context.field.569, align 4
  %stack.sub.571 = sub i32 %context.value.570, 8
  %stack.sub.572 = sub i32 %stack.sub.571, 8
  %integer.left.573 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.572)
  %context.field.575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.576 = load i32, ptr %context.field.575, align 4
  %runtime.ok.577 = icmp eq i32 %context.value.576, 0
  br i1 %runtime.ok.577, label %runtime.continue.578, label %frame.failure.0
runtime.continue.578:
  %integer.right.574 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.571)
  %context.field.579 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.580 = load i32, ptr %context.field.579, align 4
  %runtime.ok.581 = icmp eq i32 %context.value.580, 0
  br i1 %runtime.ok.581, label %runtime.continue.582, label %frame.failure.0
runtime.continue.582:
  %divide.zero.583 = icmp eq i64 %integer.right.574, 0
  br i1 %divide.zero.583, label %divide.zero.584, label %divide.nonzero.585
divide.zero.584:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 34, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.585:
  %divide.min.586 = icmp eq i64 %integer.left.573, -9223372036854775808
  %divide.minusone.587 = icmp eq i64 %integer.right.574, -1
  %divide.overflow.588 = and i1 %divide.min.586, %divide.minusone.587
  br i1 %divide.overflow.588, label %divide.overflow.589, label %divide.valid.590
divide.overflow.589:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 35, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.590:
  %divide.result.591 = sdiv i64 %integer.left.573, %integer.right.574
  %context.field.592 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.593 = load i32, ptr %context.field.592, align 4
  %stack.sub.594 = sub i32 %context.value.593, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.594, i32 8, i32 8, i32 1)
  %context.field.595 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.596 = load i32, ptr %context.field.595, align 4
  %runtime.ok.597 = icmp eq i32 %context.value.596, 0
  br i1 %runtime.ok.597, label %runtime.continue.598, label %frame.failure.0
runtime.continue.598:
  %context.field.599 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.600 = load i32, ptr %context.field.599, align 4
  %stack.sub.601 = sub i32 %context.value.600, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.601, i32 8, i32 8, i32 1)
  %context.field.602 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.603 = load i32, ptr %context.field.602, align 4
  %runtime.ok.604 = icmp eq i32 %context.value.603, 0
  br i1 %runtime.ok.604, label %runtime.continue.605, label %frame.failure.0
runtime.continue.605:
  %context.field.606 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.607 = load i32, ptr %context.field.606, align 4
  %stack.offset.608 = add i32 %context.value.607, 8
  %reserve.status.609 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.608, i32 36)
  %reserve.ok.610 = icmp eq i32 %reserve.status.609, 0
  br i1 %reserve.ok.610, label %reserve.continue.611, label %frame.failure.0
reserve.continue.611:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.607, i64 %divide.result.591, i32 1)
  %context.field.612 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.613 = load i32, ptr %context.field.612, align 4
  %runtime.ok.614 = icmp eq i32 %context.value.613, 0
  br i1 %runtime.ok.614, label %runtime.continue.615, label %frame.failure.0
runtime.continue.615:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.617 = load i32, ptr %context.field.616, align 4
  %runtime.ok.618 = icmp eq i32 %context.value.617, 0
  br i1 %runtime.ok.618, label %runtime.continue.619, label %frame.failure.0
runtime.continue.619:
  %local.is.active.620 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.621 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.622 = select i1 %local.is.active.620, i32 %local.sum.extent.621, i32 0
  %stack.offset.623 = add i32 0, %local.sum.selected.622
  %local.is.active.624 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.625 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.626 = select i1 %local.is.active.624, i32 %local.sum.extent.625, i32 0
  %stack.offset.627 = add i32 %stack.offset.623, %local.sum.selected.626
  %stack.offset.628 = add i32 0, 8
  %stack.offset.629 = add i32 %stack.offset.627, %stack.offset.628
  %stack.offset.630 = add i32 %context.value.25, %stack.offset.629
  %cursor.status.631 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.630)
  %cursor.ok.632 = icmp eq i32 %cursor.status.631, 0
  br i1 %cursor.ok.632, label %cursor.continue.633, label %frame.failure.0
cursor.continue.633:
  %local.is.active.634 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.634, label %local.remove.635, label %local.keep.636
local.keep.636:
  br label %local.removed.637
local.remove.635:
  %local.remove.offset.638 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.639 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.640 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.641 = load i32, ptr %local.type.12, align 4
  %stack.offset.642 = add i32 %local.remove.offset.638, %local.remove.extent.639
  %context.field.643 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.644 = load i32, ptr %context.field.643, align 4
  %stack.sub.645 = sub i32 %context.value.644, %stack.offset.642
  %stack.offset.646 = add i32 0, 8
  %stack.offset.647 = add i32 0, %stack.offset.646
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.638, i32 %stack.offset.642, i32 %stack.sub.645, i32 %stack.offset.647, i32 0, i32 14)
  %context.field.648 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.649 = load i32, ptr %context.field.648, align 4
  %runtime.ok.650 = icmp eq i32 %context.value.649, 0
  br i1 %runtime.ok.650, label %runtime.continue.651, label %frame.failure.0
runtime.continue.651:
  %stack.sub.652 = sub i32 %context.value.644, %local.remove.extent.639
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.652, i32 0, i32 0, i32 0)
  %context.field.653 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.654 = load i32, ptr %context.field.653, align 4
  %runtime.ok.655 = icmp eq i32 %context.value.654, 0
  br i1 %runtime.ok.655, label %runtime.continue.656, label %frame.failure.0
runtime.continue.656:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.641, i32 %local.remove.offset.638, i32 %local.remove.extent.639, i32 %local.remove.payload.640, i32 0, i32 0)
  %context.field.657 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.658 = load i32, ptr %context.field.657, align 4
  %runtime.ok.659 = icmp eq i32 %context.value.658, 0
  br i1 %runtime.ok.659, label %runtime.continue.660, label %frame.failure.0
runtime.continue.660:
  %stack.sub.661 = sub i32 0, %local.remove.payload.640
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.661, i32 %stack.sub.661)
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %runtime.ok.664 = icmp eq i32 %context.value.663, 0
  br i1 %runtime.ok.664, label %runtime.continue.665, label %frame.failure.0
runtime.continue.665:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.639)
  %context.field.666 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.667 = load i32, ptr %context.field.666, align 4
  %runtime.ok.668 = icmp eq i32 %context.value.667, 0
  br i1 %runtime.ok.668, label %runtime.continue.669, label %frame.failure.0
runtime.continue.669:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.637
local.removed.637:
  %local.is.active.670 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.670, label %local.remove.671, label %local.keep.672
local.keep.672:
  br label %local.removed.673
local.remove.671:
  %local.remove.offset.674 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.675 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.676 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.677 = load i32, ptr %local.type.7, align 4
  %stack.offset.678 = add i32 %local.remove.offset.674, %local.remove.extent.675
  %context.field.679 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.680 = load i32, ptr %context.field.679, align 4
  %stack.sub.681 = sub i32 %context.value.680, %stack.offset.678
  %local.is.active.682 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.683 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.684 = select i1 %local.is.active.682, i32 %local.suffix.payload.683, i32 0
  %stack.offset.685 = add i32 0, %local.suffix.selected.684
  %stack.offset.686 = add i32 0, 8
  %stack.offset.687 = add i32 %stack.offset.685, %stack.offset.686
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.674, i32 %stack.offset.678, i32 %stack.sub.681, i32 %stack.offset.687, i32 0, i32 14)
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %runtime.ok.690 = icmp eq i32 %context.value.689, 0
  br i1 %runtime.ok.690, label %runtime.continue.691, label %frame.failure.0
runtime.continue.691:
  %stack.sub.692 = sub i32 %context.value.680, %local.remove.extent.675
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.692, i32 0, i32 0, i32 0)
  %context.field.693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.694 = load i32, ptr %context.field.693, align 4
  %runtime.ok.695 = icmp eq i32 %context.value.694, 0
  br i1 %runtime.ok.695, label %runtime.continue.696, label %frame.failure.0
runtime.continue.696:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.677, i32 %local.remove.offset.674, i32 %local.remove.extent.675, i32 %local.remove.payload.676, i32 0, i32 0)
  %context.field.697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.698 = load i32, ptr %context.field.697, align 4
  %runtime.ok.699 = icmp eq i32 %context.value.698, 0
  br i1 %runtime.ok.699, label %runtime.continue.700, label %frame.failure.0
runtime.continue.700:
  %stack.sub.701 = sub i32 0, %local.remove.payload.676
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.701, i32 %stack.sub.701)
  %context.field.702 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.703 = load i32, ptr %context.field.702, align 4
  %runtime.ok.704 = icmp eq i32 %context.value.703, 0
  br i1 %runtime.ok.704, label %runtime.continue.705, label %frame.failure.0
runtime.continue.705:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.675)
  %context.field.706 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.707 = load i32, ptr %context.field.706, align 4
  %runtime.ok.708 = icmp eq i32 %context.value.707, 0
  br i1 %runtime.ok.708, label %runtime.continue.709, label %frame.failure.0
runtime.continue.709:
  %local.is.active.710 = load i1, ptr %local.active.8, align 1
  %local.later.offset.711 = load i32, ptr %local.offset.9, align 4
  %stack.sub.712 = sub i32 %local.later.offset.711, %local.remove.extent.675
  %local.later.offset.selected.713 = select i1 %local.is.active.710, i32 %stack.sub.712, i32 %local.later.offset.711
  store i32 %local.later.offset.selected.713, ptr %local.offset.9, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.673
local.removed.673:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.14, i32 0, i32 0, i32 0)
  %context.field.714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.715 = load i32, ptr %context.field.714, align 4
  %context.field.716 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.717 = load i32, ptr %context.field.716, align 4
  %context.field.718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.719 = load i32, ptr %context.field.718, align 4
  %stack.offset.720 = add i32 %context.value.16, %context.value.18
  %stack.offset.721 = add i32 %context.value.715, %context.value.717
  %stack.sub.722 = sub i32 %stack.offset.720, %stack.offset.721
  %stack.sub.723 = sub i32 %context.value.18, %context.value.717
  %stack.sub.724 = sub i32 %context.value.719, %context.value.20
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.722, i32 %stack.sub.723)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.724)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 37, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 37, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 38)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 11, i32 39)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 40)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %value.size.39 = alloca %AlOwningValueSize, align 4
  %measure.status.40 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.36, i32 %context.value.38, i32 41, ptr %value.size.39)
  %helper.ok.41 = icmp eq i32 %measure.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %entry.failure.0
helper.continue.42:
  %value.payload.pointer.43 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 0
  %value.extent.pointer.44 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 1
  %value.payload.45 = load i32, ptr %value.payload.pointer.43, align 4
  %value.extent.46 = load i32, ptr %value.extent.pointer.44, align 4
  %stack.offset.47 = add i32 %stack.offset.36, %value.extent.46
  %stack.offset.48 = add i32 0, %value.payload.45
  %entry.outputs.exact.49 = icmp eq i32 %stack.offset.47, %context.value.38
  br i1 %entry.outputs.exact.49, label %entry.outputs.exact.50, label %entry.failure.0
entry.outputs.exact.50:
  %stack.sub.51 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.51, i32 %stack.offset.48, i32 0, i32 9)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %entry.failure.0
runtime.continue.55:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.51, i32 0, i32 0, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.51, i32 1)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %entry.failure.0
runtime.continue.63:
  %stack.sub.64 = sub i32 0, %stack.offset.48
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.64, i32 0)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %entry.failure.0
runtime.continue.68:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.offset.75 = add i32 %context.value.70, %context.value.72
  %stack.sub.76 = sub i32 0, %stack.offset.75
  %stack.sub.77 = sub i32 0, %context.value.72
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.76, i32 %stack.sub.77)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.74)
  br label %entry.return.status
entry.return.status:
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  ret i32 %context.value.79
}


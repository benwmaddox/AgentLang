%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 4, i32 11, i32 4, i32 2, i32 4294967295, i32 4294967295, i32 32, i32 32 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 6, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [6 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 6 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00", align 8
@al_owning_string_literal_1 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 11, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %stack.offset.40 = add i32 0, 0
  %stack.offset.41 = add i32 %context.value.15, %stack.offset.40
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %stack.offset.45 = add i32 0, %value.extent.28
  %callee.status.44 = call i32 @agentlang_word_0002(ptr %ctx, i32 %stack.offset.41, i32 %stack.offset.45, i32 4)
  %helper.ok.46 = icmp eq i32 %callee.status.44, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %frame.failure.0
helper.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %value.size.50 = alloca %AlOwningValueSize, align 4
  %measure.status.51 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %context.value.43, i32 %context.value.49, i32 5, ptr %value.size.50)
  %helper.ok.52 = icmp eq i32 %measure.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %value.payload.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 0
  %value.extent.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.50, i32 0, i32 1
  %value.payload.56 = load i32, ptr %value.payload.pointer.54, align 4
  %value.extent.57 = load i32, ptr %value.extent.pointer.55, align 4
  %stack.offset.58 = add i32 %context.value.43, %value.extent.57
  %stack.offset.59 = add i32 0, %value.payload.56
  %value.size.60 = alloca %AlOwningValueSize, align 4
  %measure.status.61 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.58, i32 %context.value.49, i32 6, ptr %value.size.60)
  %helper.ok.62 = icmp eq i32 %measure.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %value.payload.pointer.64 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 0
  %value.extent.pointer.65 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.60, i32 0, i32 1
  %value.payload.66 = load i32, ptr %value.payload.pointer.64, align 4
  %value.extent.67 = load i32, ptr %value.extent.pointer.65, align 4
  %stack.offset.68 = add i32 %stack.offset.58, %value.extent.67
  %stack.offset.69 = add i32 %stack.offset.59, %value.payload.66
  %callee.outputs.exact.70 = icmp eq i32 %stack.offset.68, %context.value.49
  br i1 %callee.outputs.exact.70, label %callee.outputs.continue.71, label %frame.failure.0
callee.outputs.continue.71:
  %stack.sub.72 = sub i32 %context.value.49, %context.value.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.41, i32 %context.value.43, i32 %stack.sub.72, i32 %stack.offset.69, i32 0, i32 9)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %frame.failure.0
runtime.continue.76:
  %stack.offset.77 = add i32 %stack.offset.41, %stack.sub.72
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.77, i32 0, i32 0, i32 0)
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %runtime.ok.80 = icmp eq i32 %context.value.79, 0
  br i1 %runtime.ok.80, label %runtime.continue.81, label %frame.failure.0
runtime.continue.81:
  %stack.offset.82 = add i32 0, %value.extent.57
  %stack.offset.83 = add i32 %stack.offset.82, %value.extent.67
  %stack.offset.84 = add i32 0, %stack.offset.83
  %stack.offset.85 = add i32 %context.value.15, %stack.offset.84
  %cursor.status.86 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.85)
  %cursor.ok.87 = icmp eq i32 %cursor.status.86, 0
  br i1 %cursor.ok.87, label %cursor.continue.88, label %frame.failure.0
cursor.continue.88:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %stack.offset.95 = add i32 %context.value.6, %context.value.8
  %stack.offset.96 = add i32 %context.value.90, %context.value.92
  %stack.sub.97 = sub i32 %stack.offset.95, %stack.offset.96
  %stack.sub.98 = sub i32 %context.value.8, %context.value.92
  %stack.sub.99 = sub i32 %context.value.94, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.97, i32 %stack.sub.98)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.99)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.offset.19 = alloca i32, align 4
  %local.extent.20 = alloca i32, align 4
  %local.payload.21 = alloca i32, align 4
  %local.type.22 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  %local.active.23 = alloca i1, align 1
  %local.offset.24 = alloca i32, align 4
  %local.extent.25 = alloca i32, align 4
  %local.payload.26 = alloca i32, align 4
  %local.type.27 = alloca i32, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  %local.active.28 = alloca i1, align 1
  %local.offset.29 = alloca i32, align 4
  %local.extent.30 = alloca i32, align 4
  %local.payload.31 = alloca i32, align 4
  %local.type.32 = alloca i32, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %local.active.33 = alloca i1, align 1
  %local.offset.34 = alloca i32, align 4
  %local.extent.35 = alloca i32, align 4
  %local.payload.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.33, align 1
  store i32 0, ptr %local.offset.34, align 4
  store i32 0, ptr %local.extent.35, align 4
  store i32 0, ptr %local.payload.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %local.active.38 = alloca i1, align 1
  %local.offset.39 = alloca i32, align 4
  %local.extent.40 = alloca i32, align 4
  %local.payload.41 = alloca i32, align 4
  %local.type.42 = alloca i32, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.type.42, align 4
  %local.active.43 = alloca i1, align 1
  %local.offset.44 = alloca i32, align 4
  %local.extent.45 = alloca i32, align 4
  %local.payload.46 = alloca i32, align 4
  %local.type.47 = alloca i32, align 4
  store i1 false, ptr %local.active.43, align 1
  store i32 0, ptr %local.offset.44, align 4
  store i32 0, ptr %local.extent.45, align 4
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  %local.active.48 = alloca i1, align 1
  %local.offset.49 = alloca i32, align 4
  %local.extent.50 = alloca i32, align 4
  %local.payload.51 = alloca i32, align 4
  %local.type.52 = alloca i32, align 4
  store i1 false, ptr %local.active.48, align 1
  store i32 0, ptr %local.offset.49, align 4
  store i32 0, ptr %local.extent.50, align 4
  store i32 0, ptr %local.payload.51, align 4
  store i32 0, ptr %local.type.52, align 4
  %local.active.53 = alloca i1, align 1
  %local.offset.54 = alloca i32, align 4
  %local.extent.55 = alloca i32, align 4
  %local.payload.56 = alloca i32, align 4
  %local.type.57 = alloca i32, align 4
  store i1 false, ptr %local.active.53, align 1
  store i32 0, ptr %local.offset.54, align 4
  store i32 0, ptr %local.extent.55, align 4
  store i32 0, ptr %local.payload.56, align 4
  store i32 0, ptr %local.type.57, align 4
  %local.active.58 = alloca i1, align 1
  %local.offset.59 = alloca i32, align 4
  %local.extent.60 = alloca i32, align 4
  %local.payload.61 = alloca i32, align 4
  %local.type.62 = alloca i32, align 4
  store i1 false, ptr %local.active.58, align 1
  store i32 0, ptr %local.offset.59, align 4
  store i32 0, ptr %local.extent.60, align 4
  store i32 0, ptr %local.payload.61, align 4
  store i32 0, ptr %local.type.62, align 4
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %frame.entered.71 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.72 = icmp eq i32 %frame.entered.71, 0
  br i1 %frame.enter.ok.72, label %frame.enter.continue.73, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.offset.76 = add i32 %argument.source, %argument.bytes
  %stack.offset.77 = add i32 %context.value.75, %argument.bytes
  %reserve.status.78 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.77, i32 7)
  %reserve.ok.79 = icmp eq i32 %reserve.status.78, 0
  br i1 %reserve.ok.79, label %reserve.continue.80, label %frame.reserve.failure.1
reserve.continue.80:
  %value.size.81 = alloca %AlOwningValueSize, align 4
  %measure.status.82 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.76, i32 8, ptr %value.size.81)
  %helper.ok.83 = icmp eq i32 %measure.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %value.payload.pointer.85 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.81, i32 0, i32 0
  %value.extent.pointer.86 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.81, i32 0, i32 1
  %value.payload.87 = load i32, ptr %value.payload.pointer.85, align 4
  %value.extent.88 = load i32, ptr %value.extent.pointer.86, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.75, i32 %argument.source, i32 %value.extent.88, i32 %value.payload.87, i32 8, i32 8)
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %runtime.ok.91 = icmp eq i32 %context.value.90, 0
  br i1 %runtime.ok.91, label %runtime.continue.92, label %frame.failure.0
runtime.continue.92:
  %stack.offset.93 = add i32 %argument.source, %value.extent.88
  %stack.offset.94 = add i32 %context.value.75, %value.extent.88
  %arguments.exact.95 = icmp eq i32 %stack.offset.93, %stack.offset.76
  br i1 %arguments.exact.95, label %arguments.continue.96, label %frame.failure.0
arguments.continue.96:
  %step.status.97 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.98 = icmp eq i32 %step.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %frame.failure.0
helper.continue.99:
  %local.is.active.100 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.101 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.102 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.103 = select i1 %local.is.active.100, i32 %local.previous.extent.101, i32 0
  %local.old.payload.104 = select i1 %local.is.active.100, i32 %local.previous.payload.102, i32 0
  %stack.offset.105 = add i32 %context.value.75, 0
  %stack.offset.106 = add i32 %stack.offset.105, %local.old.extent.103
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.109 = sub i32 %context.value.108, %stack.offset.106
  %stack.sub.110 = sub i32 %context.value.108, %local.old.extent.103
  %stack.offset.111 = add i32 %stack.sub.110, %value.extent.88
  %local.grows.112 = icmp ugt i32 %value.extent.88, %local.old.extent.103
  br i1 %local.grows.112, label %local.grow.113, label %local.fixed.114
local.grow.113:
  %reserve.status.116 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.111, i32 10)
  %reserve.ok.117 = icmp eq i32 %reserve.status.116, 0
  br i1 %reserve.ok.117, label %reserve.continue.118, label %frame.failure.0
reserve.continue.118:
  %stack.sub.119 = sub i32 %value.extent.88, %local.old.extent.103
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.119)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %frame.failure.0
runtime.continue.123:
  br label %local.layout.ready.115
local.fixed.114:
  br label %local.layout.ready.115
local.layout.ready.115:
  %stack.offset.124 = add i32 %stack.offset.105, %value.extent.88
  %local.is.active.125 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.126 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.127 = select i1 %local.is.active.125, i32 %local.suffix.payload.126, i32 0
  %stack.offset.128 = add i32 0, %local.suffix.selected.127
  %local.is.active.129 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.130 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.131 = select i1 %local.is.active.129, i32 %local.suffix.payload.130, i32 0
  %stack.offset.132 = add i32 %stack.offset.128, %local.suffix.selected.131
  %local.is.active.133 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.134 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.135 = select i1 %local.is.active.133, i32 %local.suffix.payload.134, i32 0
  %stack.offset.136 = add i32 %stack.offset.132, %local.suffix.selected.135
  %local.is.active.137 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.138 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.139 = select i1 %local.is.active.137, i32 %local.suffix.payload.138, i32 0
  %stack.offset.140 = add i32 %stack.offset.136, %local.suffix.selected.139
  %local.is.active.141 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.142 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.143 = select i1 %local.is.active.141, i32 %local.suffix.payload.142, i32 0
  %stack.offset.144 = add i32 %stack.offset.140, %local.suffix.selected.143
  %local.is.active.145 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.146 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.147 = select i1 %local.is.active.145, i32 %local.suffix.payload.146, i32 0
  %stack.offset.148 = add i32 %stack.offset.144, %local.suffix.selected.147
  %local.is.active.149 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.150 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.151 = select i1 %local.is.active.149, i32 %local.suffix.payload.150, i32 0
  %stack.offset.152 = add i32 %stack.offset.148, %local.suffix.selected.151
  %local.is.active.153 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.154 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.155 = select i1 %local.is.active.153, i32 %local.suffix.payload.154, i32 0
  %stack.offset.156 = add i32 %stack.offset.152, %local.suffix.selected.155
  %local.is.active.157 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.158 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.159 = select i1 %local.is.active.157, i32 %local.suffix.payload.158, i32 0
  %stack.offset.160 = add i32 %stack.offset.156, %local.suffix.selected.159
  %local.is.active.161 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.162 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.163 = select i1 %local.is.active.161, i32 %local.suffix.payload.162, i32 0
  %stack.offset.164 = add i32 %stack.offset.160, %local.suffix.selected.163
  %local.is.active.165 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.166 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.167 = select i1 %local.is.active.165, i32 %local.suffix.payload.166, i32 0
  %stack.offset.168 = add i32 %stack.offset.164, %local.suffix.selected.167
  %stack.offset.169 = add i32 0, %value.payload.87
  %stack.offset.170 = add i32 %stack.offset.168, %stack.offset.169
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.124, i32 %stack.offset.106, i32 %stack.sub.109, i32 %stack.offset.170, i32 0, i32 14)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %stack.sub.175 = sub i32 %context.value.108, %value.extent.88
  %stack.sub.176 = sub i32 %stack.sub.175, %local.old.extent.103
  %stack.offset.177 = add i32 %stack.sub.176, %value.extent.88
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.105, i32 %stack.offset.177, i32 %value.extent.88, i32 %value.payload.87, i32 8, i32 4)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  %stack.sub.182 = sub i32 %context.value.108, %local.old.extent.103
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.182, i32 0, i32 0, i32 0)
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %runtime.ok.185 = icmp eq i32 %context.value.184, 0
  br i1 %runtime.ok.185, label %runtime.continue.186, label %frame.failure.0
runtime.continue.186:
  %local.shrinks.187 = icmp ult i32 %value.extent.88, %local.old.extent.103
  br i1 %local.shrinks.187, label %local.shrink.188, label %local.counts.ready.189
local.shrink.188:
  %stack.sub.190 = sub i32 %local.old.extent.103, %value.extent.88
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.190)
  %context.field.191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.192 = load i32, ptr %context.field.191, align 4
  %runtime.ok.193 = icmp eq i32 %context.value.192, 0
  br i1 %runtime.ok.193, label %runtime.continue.194, label %frame.failure.0
runtime.continue.194:
  br label %local.counts.ready.189
local.counts.ready.189:
  %local.payload.delta.195 = sub i32 %value.payload.87, %local.old.payload.104
  %stack.sub.196 = sub i32 0, %local.old.payload.104
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.196, i32 %local.payload.delta.195)
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %runtime.ok.199 = icmp eq i32 %context.value.198, 0
  br i1 %runtime.ok.199, label %runtime.continue.200, label %frame.failure.0
runtime.continue.200:
  %local.is.active.201 = load i1, ptr %local.active.8, align 1
  %local.later.offset.202 = load i32, ptr %local.offset.9, align 4
  %stack.sub.203 = sub i32 %local.later.offset.202, %local.old.extent.103
  %stack.offset.204 = add i32 %stack.sub.203, %value.extent.88
  %local.later.offset.selected.205 = select i1 %local.is.active.201, i32 %stack.offset.204, i32 %local.later.offset.202
  store i32 %local.later.offset.selected.205, ptr %local.offset.9, align 4
  %local.is.active.206 = load i1, ptr %local.active.13, align 1
  %local.later.offset.207 = load i32, ptr %local.offset.14, align 4
  %stack.sub.208 = sub i32 %local.later.offset.207, %local.old.extent.103
  %stack.offset.209 = add i32 %stack.sub.208, %value.extent.88
  %local.later.offset.selected.210 = select i1 %local.is.active.206, i32 %stack.offset.209, i32 %local.later.offset.207
  store i32 %local.later.offset.selected.210, ptr %local.offset.14, align 4
  %local.is.active.211 = load i1, ptr %local.active.18, align 1
  %local.later.offset.212 = load i32, ptr %local.offset.19, align 4
  %stack.sub.213 = sub i32 %local.later.offset.212, %local.old.extent.103
  %stack.offset.214 = add i32 %stack.sub.213, %value.extent.88
  %local.later.offset.selected.215 = select i1 %local.is.active.211, i32 %stack.offset.214, i32 %local.later.offset.212
  store i32 %local.later.offset.selected.215, ptr %local.offset.19, align 4
  %local.is.active.216 = load i1, ptr %local.active.23, align 1
  %local.later.offset.217 = load i32, ptr %local.offset.24, align 4
  %stack.sub.218 = sub i32 %local.later.offset.217, %local.old.extent.103
  %stack.offset.219 = add i32 %stack.sub.218, %value.extent.88
  %local.later.offset.selected.220 = select i1 %local.is.active.216, i32 %stack.offset.219, i32 %local.later.offset.217
  store i32 %local.later.offset.selected.220, ptr %local.offset.24, align 4
  %local.is.active.221 = load i1, ptr %local.active.28, align 1
  %local.later.offset.222 = load i32, ptr %local.offset.29, align 4
  %stack.sub.223 = sub i32 %local.later.offset.222, %local.old.extent.103
  %stack.offset.224 = add i32 %stack.sub.223, %value.extent.88
  %local.later.offset.selected.225 = select i1 %local.is.active.221, i32 %stack.offset.224, i32 %local.later.offset.222
  store i32 %local.later.offset.selected.225, ptr %local.offset.29, align 4
  %local.is.active.226 = load i1, ptr %local.active.33, align 1
  %local.later.offset.227 = load i32, ptr %local.offset.34, align 4
  %stack.sub.228 = sub i32 %local.later.offset.227, %local.old.extent.103
  %stack.offset.229 = add i32 %stack.sub.228, %value.extent.88
  %local.later.offset.selected.230 = select i1 %local.is.active.226, i32 %stack.offset.229, i32 %local.later.offset.227
  store i32 %local.later.offset.selected.230, ptr %local.offset.34, align 4
  %local.is.active.231 = load i1, ptr %local.active.38, align 1
  %local.later.offset.232 = load i32, ptr %local.offset.39, align 4
  %stack.sub.233 = sub i32 %local.later.offset.232, %local.old.extent.103
  %stack.offset.234 = add i32 %stack.sub.233, %value.extent.88
  %local.later.offset.selected.235 = select i1 %local.is.active.231, i32 %stack.offset.234, i32 %local.later.offset.232
  store i32 %local.later.offset.selected.235, ptr %local.offset.39, align 4
  %local.is.active.236 = load i1, ptr %local.active.43, align 1
  %local.later.offset.237 = load i32, ptr %local.offset.44, align 4
  %stack.sub.238 = sub i32 %local.later.offset.237, %local.old.extent.103
  %stack.offset.239 = add i32 %stack.sub.238, %value.extent.88
  %local.later.offset.selected.240 = select i1 %local.is.active.236, i32 %stack.offset.239, i32 %local.later.offset.237
  store i32 %local.later.offset.selected.240, ptr %local.offset.44, align 4
  %local.is.active.241 = load i1, ptr %local.active.48, align 1
  %local.later.offset.242 = load i32, ptr %local.offset.49, align 4
  %stack.sub.243 = sub i32 %local.later.offset.242, %local.old.extent.103
  %stack.offset.244 = add i32 %stack.sub.243, %value.extent.88
  %local.later.offset.selected.245 = select i1 %local.is.active.241, i32 %stack.offset.244, i32 %local.later.offset.242
  store i32 %local.later.offset.selected.245, ptr %local.offset.49, align 4
  %local.is.active.246 = load i1, ptr %local.active.53, align 1
  %local.later.offset.247 = load i32, ptr %local.offset.54, align 4
  %stack.sub.248 = sub i32 %local.later.offset.247, %local.old.extent.103
  %stack.offset.249 = add i32 %stack.sub.248, %value.extent.88
  %local.later.offset.selected.250 = select i1 %local.is.active.246, i32 %stack.offset.249, i32 %local.later.offset.247
  store i32 %local.later.offset.selected.250, ptr %local.offset.54, align 4
  %local.is.active.251 = load i1, ptr %local.active.58, align 1
  %local.later.offset.252 = load i32, ptr %local.offset.59, align 4
  %stack.sub.253 = sub i32 %local.later.offset.252, %local.old.extent.103
  %stack.offset.254 = add i32 %stack.sub.253, %value.extent.88
  %local.later.offset.selected.255 = select i1 %local.is.active.251, i32 %stack.offset.254, i32 %local.later.offset.252
  store i32 %local.later.offset.selected.255, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.105, ptr %local.offset.4, align 4
  store i32 %value.extent.88, ptr %local.extent.5, align 4
  store i32 %value.payload.87, ptr %local.payload.6, align 4
  store i32 8, ptr %local.type.7, align 4
  %local.is.active.256 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.257 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.258 = select i1 %local.is.active.256, i32 %local.sum.extent.257, i32 0
  %stack.offset.259 = add i32 0, %local.sum.selected.258
  %local.is.active.260 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.261 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.262 = select i1 %local.is.active.260, i32 %local.sum.extent.261, i32 0
  %stack.offset.263 = add i32 %stack.offset.259, %local.sum.selected.262
  %local.is.active.264 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.265 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.266 = select i1 %local.is.active.264, i32 %local.sum.extent.265, i32 0
  %stack.offset.267 = add i32 %stack.offset.263, %local.sum.selected.266
  %local.is.active.268 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.269 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.270 = select i1 %local.is.active.268, i32 %local.sum.extent.269, i32 0
  %stack.offset.271 = add i32 %stack.offset.267, %local.sum.selected.270
  %local.is.active.272 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.273 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.274 = select i1 %local.is.active.272, i32 %local.sum.extent.273, i32 0
  %stack.offset.275 = add i32 %stack.offset.271, %local.sum.selected.274
  %local.is.active.276 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.277 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.278 = select i1 %local.is.active.276, i32 %local.sum.extent.277, i32 0
  %stack.offset.279 = add i32 %stack.offset.275, %local.sum.selected.278
  %local.is.active.280 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.281 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.282 = select i1 %local.is.active.280, i32 %local.sum.extent.281, i32 0
  %stack.offset.283 = add i32 %stack.offset.279, %local.sum.selected.282
  %local.is.active.284 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.285 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.286 = select i1 %local.is.active.284, i32 %local.sum.extent.285, i32 0
  %stack.offset.287 = add i32 %stack.offset.283, %local.sum.selected.286
  %local.is.active.288 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.289 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.290 = select i1 %local.is.active.288, i32 %local.sum.extent.289, i32 0
  %stack.offset.291 = add i32 %stack.offset.287, %local.sum.selected.290
  %local.is.active.292 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.293 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.294 = select i1 %local.is.active.292, i32 %local.sum.extent.293, i32 0
  %stack.offset.295 = add i32 %stack.offset.291, %local.sum.selected.294
  %local.is.active.296 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.297 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.298 = select i1 %local.is.active.296, i32 %local.sum.extent.297, i32 0
  %stack.offset.299 = add i32 %stack.offset.295, %local.sum.selected.298
  %local.is.active.300 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.301 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.302 = select i1 %local.is.active.300, i32 %local.sum.extent.301, i32 0
  %stack.offset.303 = add i32 %stack.offset.299, %local.sum.selected.302
  %stack.offset.304 = add i32 %stack.offset.303, 0
  %stack.offset.305 = add i32 %context.value.75, %stack.offset.304
  %cursor.status.306 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.305)
  %cursor.ok.307 = icmp eq i32 %cursor.status.306, 0
  br i1 %cursor.ok.307, label %cursor.continue.308, label %frame.failure.0
cursor.continue.308:
  %step.status.309 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.310 = icmp eq i32 %step.status.309, 0
  br i1 %helper.ok.310, label %helper.continue.311, label %frame.failure.0
helper.continue.311:
  %local.source.offset.312 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.313 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.314 = load i32, ptr %local.payload.6, align 4
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.316 = load i32, ptr %context.field.315, align 4
  %stack.offset.317 = add i32 %context.value.316, %local.source.extent.313
  %reserve.status.318 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.317, i32 12)
  %reserve.ok.319 = icmp eq i32 %reserve.status.318, 0
  br i1 %reserve.ok.319, label %reserve.continue.320, label %frame.failure.0
reserve.continue.320:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.316, i32 %local.source.offset.312, i32 %local.source.extent.313, i32 %local.source.payload.314, i32 8)
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %runtime.ok.323 = icmp eq i32 %context.value.322, 0
  br i1 %runtime.ok.323, label %runtime.continue.324, label %frame.failure.0
runtime.continue.324:
  %local.is.active.325 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.326 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.327 = select i1 %local.is.active.325, i32 %local.sum.extent.326, i32 0
  %stack.offset.328 = add i32 0, %local.sum.selected.327
  %local.is.active.329 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.330 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.331 = select i1 %local.is.active.329, i32 %local.sum.extent.330, i32 0
  %stack.offset.332 = add i32 %stack.offset.328, %local.sum.selected.331
  %local.is.active.333 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.334 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.335 = select i1 %local.is.active.333, i32 %local.sum.extent.334, i32 0
  %stack.offset.336 = add i32 %stack.offset.332, %local.sum.selected.335
  %local.is.active.337 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.338 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.339 = select i1 %local.is.active.337, i32 %local.sum.extent.338, i32 0
  %stack.offset.340 = add i32 %stack.offset.336, %local.sum.selected.339
  %local.is.active.341 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.342 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.343 = select i1 %local.is.active.341, i32 %local.sum.extent.342, i32 0
  %stack.offset.344 = add i32 %stack.offset.340, %local.sum.selected.343
  %local.is.active.345 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.346 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.347 = select i1 %local.is.active.345, i32 %local.sum.extent.346, i32 0
  %stack.offset.348 = add i32 %stack.offset.344, %local.sum.selected.347
  %local.is.active.349 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.350 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.351 = select i1 %local.is.active.349, i32 %local.sum.extent.350, i32 0
  %stack.offset.352 = add i32 %stack.offset.348, %local.sum.selected.351
  %local.is.active.353 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.354 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.355 = select i1 %local.is.active.353, i32 %local.sum.extent.354, i32 0
  %stack.offset.356 = add i32 %stack.offset.352, %local.sum.selected.355
  %local.is.active.357 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.358 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.359 = select i1 %local.is.active.357, i32 %local.sum.extent.358, i32 0
  %stack.offset.360 = add i32 %stack.offset.356, %local.sum.selected.359
  %local.is.active.361 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.362 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.363 = select i1 %local.is.active.361, i32 %local.sum.extent.362, i32 0
  %stack.offset.364 = add i32 %stack.offset.360, %local.sum.selected.363
  %local.is.active.365 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.366 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.367 = select i1 %local.is.active.365, i32 %local.sum.extent.366, i32 0
  %stack.offset.368 = add i32 %stack.offset.364, %local.sum.selected.367
  %local.is.active.369 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.370 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.371 = select i1 %local.is.active.369, i32 %local.sum.extent.370, i32 0
  %stack.offset.372 = add i32 %stack.offset.368, %local.sum.selected.371
  %stack.offset.373 = add i32 0, %local.source.extent.313
  %stack.offset.374 = add i32 %stack.offset.372, %stack.offset.373
  %stack.offset.375 = add i32 %context.value.75, %stack.offset.374
  %cursor.status.376 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.375)
  %cursor.ok.377 = icmp eq i32 %cursor.status.376, 0
  br i1 %cursor.ok.377, label %cursor.continue.378, label %frame.failure.0
cursor.continue.378:
  %step.status.379 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.380 = icmp eq i32 %step.status.379, 0
  br i1 %helper.ok.380, label %helper.continue.381, label %frame.failure.0
helper.continue.381:
  %context.field.382 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.383 = load i32, ptr %context.field.382, align 4
  %stack.sub.384 = sub i32 %context.value.383, %local.source.extent.313
  %stack.offset.385 = add i32 %context.value.383, %local.source.extent.313
  %reserve.status.386 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.385, i32 14)
  %reserve.ok.387 = icmp eq i32 %reserve.status.386, 0
  br i1 %reserve.ok.387, label %reserve.continue.388, label %frame.failure.0
reserve.continue.388:
  call void @al_owning_duplicate(ptr %ctx, i32 %context.value.383, i32 %stack.sub.384, i32 %local.source.extent.313, i32 %local.source.payload.314, i32 8)
  %context.field.389 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.390 = load i32, ptr %context.field.389, align 4
  %runtime.ok.391 = icmp eq i32 %context.value.390, 0
  br i1 %runtime.ok.391, label %runtime.continue.392, label %frame.failure.0
runtime.continue.392:
  %local.is.active.393 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.394 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.395 = select i1 %local.is.active.393, i32 %local.sum.extent.394, i32 0
  %stack.offset.396 = add i32 0, %local.sum.selected.395
  %local.is.active.397 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.398 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.399 = select i1 %local.is.active.397, i32 %local.sum.extent.398, i32 0
  %stack.offset.400 = add i32 %stack.offset.396, %local.sum.selected.399
  %local.is.active.401 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.402 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.403 = select i1 %local.is.active.401, i32 %local.sum.extent.402, i32 0
  %stack.offset.404 = add i32 %stack.offset.400, %local.sum.selected.403
  %local.is.active.405 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.406 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.407 = select i1 %local.is.active.405, i32 %local.sum.extent.406, i32 0
  %stack.offset.408 = add i32 %stack.offset.404, %local.sum.selected.407
  %local.is.active.409 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.410 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.411 = select i1 %local.is.active.409, i32 %local.sum.extent.410, i32 0
  %stack.offset.412 = add i32 %stack.offset.408, %local.sum.selected.411
  %local.is.active.413 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.414 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.415 = select i1 %local.is.active.413, i32 %local.sum.extent.414, i32 0
  %stack.offset.416 = add i32 %stack.offset.412, %local.sum.selected.415
  %local.is.active.417 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.418 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.419 = select i1 %local.is.active.417, i32 %local.sum.extent.418, i32 0
  %stack.offset.420 = add i32 %stack.offset.416, %local.sum.selected.419
  %local.is.active.421 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.422 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.423 = select i1 %local.is.active.421, i32 %local.sum.extent.422, i32 0
  %stack.offset.424 = add i32 %stack.offset.420, %local.sum.selected.423
  %local.is.active.425 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.426 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.427 = select i1 %local.is.active.425, i32 %local.sum.extent.426, i32 0
  %stack.offset.428 = add i32 %stack.offset.424, %local.sum.selected.427
  %local.is.active.429 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.430 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.431 = select i1 %local.is.active.429, i32 %local.sum.extent.430, i32 0
  %stack.offset.432 = add i32 %stack.offset.428, %local.sum.selected.431
  %local.is.active.433 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.434 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.435 = select i1 %local.is.active.433, i32 %local.sum.extent.434, i32 0
  %stack.offset.436 = add i32 %stack.offset.432, %local.sum.selected.435
  %local.is.active.437 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.438 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.439 = select i1 %local.is.active.437, i32 %local.sum.extent.438, i32 0
  %stack.offset.440 = add i32 %stack.offset.436, %local.sum.selected.439
  %stack.offset.441 = add i32 0, %local.source.extent.313
  %stack.offset.442 = add i32 %stack.offset.441, %local.source.extent.313
  %stack.offset.443 = add i32 %stack.offset.440, %stack.offset.442
  %stack.offset.444 = add i32 %context.value.75, %stack.offset.443
  %cursor.status.445 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.444)
  %cursor.ok.446 = icmp eq i32 %cursor.status.445, 0
  br i1 %cursor.ok.446, label %cursor.continue.447, label %frame.failure.0
cursor.continue.447:
  %step.status.448 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.449 = icmp eq i32 %step.status.448, 0
  br i1 %helper.ok.449, label %helper.continue.450, label %frame.failure.0
helper.continue.450:
  %local.is.active.451 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.452 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.453 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.454 = select i1 %local.is.active.451, i32 %local.previous.extent.452, i32 0
  %local.old.payload.455 = select i1 %local.is.active.451, i32 %local.previous.payload.453, i32 0
  %local.is.active.456 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.457 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.458 = select i1 %local.is.active.456, i32 %local.sum.extent.457, i32 0
  %stack.offset.459 = add i32 0, %local.sum.selected.458
  %stack.offset.460 = add i32 %context.value.75, %stack.offset.459
  %stack.offset.461 = add i32 %stack.offset.460, %local.old.extent.454
  %context.field.462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.463 = load i32, ptr %context.field.462, align 4
  %stack.sub.464 = sub i32 %context.value.463, %stack.offset.461
  %stack.sub.465 = sub i32 %context.value.463, %local.old.extent.454
  %stack.offset.466 = add i32 %stack.sub.465, %local.source.extent.313
  %local.grows.467 = icmp ugt i32 %local.source.extent.313, %local.old.extent.454
  br i1 %local.grows.467, label %local.grow.468, label %local.fixed.469
local.grow.468:
  %reserve.status.471 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.466, i32 16)
  %reserve.ok.472 = icmp eq i32 %reserve.status.471, 0
  br i1 %reserve.ok.472, label %reserve.continue.473, label %frame.failure.0
reserve.continue.473:
  %stack.sub.474 = sub i32 %local.source.extent.313, %local.old.extent.454
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.474)
  %context.field.475 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.476 = load i32, ptr %context.field.475, align 4
  %runtime.ok.477 = icmp eq i32 %context.value.476, 0
  br i1 %runtime.ok.477, label %runtime.continue.478, label %frame.failure.0
runtime.continue.478:
  br label %local.layout.ready.470
local.fixed.469:
  br label %local.layout.ready.470
local.layout.ready.470:
  %stack.offset.479 = add i32 %stack.offset.460, %local.source.extent.313
  %local.is.active.480 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.481 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.482 = select i1 %local.is.active.480, i32 %local.suffix.payload.481, i32 0
  %stack.offset.483 = add i32 0, %local.suffix.selected.482
  %local.is.active.484 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.485 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.486 = select i1 %local.is.active.484, i32 %local.suffix.payload.485, i32 0
  %stack.offset.487 = add i32 %stack.offset.483, %local.suffix.selected.486
  %local.is.active.488 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.489 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.490 = select i1 %local.is.active.488, i32 %local.suffix.payload.489, i32 0
  %stack.offset.491 = add i32 %stack.offset.487, %local.suffix.selected.490
  %local.is.active.492 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.493 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.494 = select i1 %local.is.active.492, i32 %local.suffix.payload.493, i32 0
  %stack.offset.495 = add i32 %stack.offset.491, %local.suffix.selected.494
  %local.is.active.496 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.497 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.498 = select i1 %local.is.active.496, i32 %local.suffix.payload.497, i32 0
  %stack.offset.499 = add i32 %stack.offset.495, %local.suffix.selected.498
  %local.is.active.500 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.501 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.502 = select i1 %local.is.active.500, i32 %local.suffix.payload.501, i32 0
  %stack.offset.503 = add i32 %stack.offset.499, %local.suffix.selected.502
  %local.is.active.504 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.505 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.506 = select i1 %local.is.active.504, i32 %local.suffix.payload.505, i32 0
  %stack.offset.507 = add i32 %stack.offset.503, %local.suffix.selected.506
  %local.is.active.508 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.509 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.510 = select i1 %local.is.active.508, i32 %local.suffix.payload.509, i32 0
  %stack.offset.511 = add i32 %stack.offset.507, %local.suffix.selected.510
  %local.is.active.512 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.513 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.514 = select i1 %local.is.active.512, i32 %local.suffix.payload.513, i32 0
  %stack.offset.515 = add i32 %stack.offset.511, %local.suffix.selected.514
  %local.is.active.516 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.517 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.518 = select i1 %local.is.active.516, i32 %local.suffix.payload.517, i32 0
  %stack.offset.519 = add i32 %stack.offset.515, %local.suffix.selected.518
  %stack.offset.520 = add i32 0, %local.source.payload.314
  %stack.offset.521 = add i32 %stack.offset.520, %local.source.payload.314
  %stack.offset.522 = add i32 %stack.offset.519, %stack.offset.521
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.479, i32 %stack.offset.461, i32 %stack.sub.464, i32 %stack.offset.522, i32 0, i32 14)
  %context.field.523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.524 = load i32, ptr %context.field.523, align 4
  %runtime.ok.525 = icmp eq i32 %context.value.524, 0
  br i1 %runtime.ok.525, label %runtime.continue.526, label %frame.failure.0
runtime.continue.526:
  %stack.sub.527 = sub i32 %context.value.463, %local.source.extent.313
  %stack.sub.528 = sub i32 %stack.sub.527, %local.old.extent.454
  %stack.offset.529 = add i32 %stack.sub.528, %local.source.extent.313
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.460, i32 %stack.offset.529, i32 %local.source.extent.313, i32 %local.source.payload.314, i32 8, i32 4)
  %context.field.530 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.531 = load i32, ptr %context.field.530, align 4
  %runtime.ok.532 = icmp eq i32 %context.value.531, 0
  br i1 %runtime.ok.532, label %runtime.continue.533, label %frame.failure.0
runtime.continue.533:
  %stack.sub.534 = sub i32 %context.value.463, %local.old.extent.454
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.534, i32 0, i32 0, i32 0)
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %runtime.ok.537 = icmp eq i32 %context.value.536, 0
  br i1 %runtime.ok.537, label %runtime.continue.538, label %frame.failure.0
runtime.continue.538:
  %local.shrinks.539 = icmp ult i32 %local.source.extent.313, %local.old.extent.454
  br i1 %local.shrinks.539, label %local.shrink.540, label %local.counts.ready.541
local.shrink.540:
  %stack.sub.542 = sub i32 %local.old.extent.454, %local.source.extent.313
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.542)
  %context.field.543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.544 = load i32, ptr %context.field.543, align 4
  %runtime.ok.545 = icmp eq i32 %context.value.544, 0
  br i1 %runtime.ok.545, label %runtime.continue.546, label %frame.failure.0
runtime.continue.546:
  br label %local.counts.ready.541
local.counts.ready.541:
  %local.payload.delta.547 = sub i32 %local.source.payload.314, %local.old.payload.455
  %stack.sub.548 = sub i32 0, %local.old.payload.455
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.548, i32 %local.payload.delta.547)
  %context.field.549 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.550 = load i32, ptr %context.field.549, align 4
  %runtime.ok.551 = icmp eq i32 %context.value.550, 0
  br i1 %runtime.ok.551, label %runtime.continue.552, label %frame.failure.0
runtime.continue.552:
  %local.is.active.553 = load i1, ptr %local.active.13, align 1
  %local.later.offset.554 = load i32, ptr %local.offset.14, align 4
  %stack.sub.555 = sub i32 %local.later.offset.554, %local.old.extent.454
  %stack.offset.556 = add i32 %stack.sub.555, %local.source.extent.313
  %local.later.offset.selected.557 = select i1 %local.is.active.553, i32 %stack.offset.556, i32 %local.later.offset.554
  store i32 %local.later.offset.selected.557, ptr %local.offset.14, align 4
  %local.is.active.558 = load i1, ptr %local.active.18, align 1
  %local.later.offset.559 = load i32, ptr %local.offset.19, align 4
  %stack.sub.560 = sub i32 %local.later.offset.559, %local.old.extent.454
  %stack.offset.561 = add i32 %stack.sub.560, %local.source.extent.313
  %local.later.offset.selected.562 = select i1 %local.is.active.558, i32 %stack.offset.561, i32 %local.later.offset.559
  store i32 %local.later.offset.selected.562, ptr %local.offset.19, align 4
  %local.is.active.563 = load i1, ptr %local.active.23, align 1
  %local.later.offset.564 = load i32, ptr %local.offset.24, align 4
  %stack.sub.565 = sub i32 %local.later.offset.564, %local.old.extent.454
  %stack.offset.566 = add i32 %stack.sub.565, %local.source.extent.313
  %local.later.offset.selected.567 = select i1 %local.is.active.563, i32 %stack.offset.566, i32 %local.later.offset.564
  store i32 %local.later.offset.selected.567, ptr %local.offset.24, align 4
  %local.is.active.568 = load i1, ptr %local.active.28, align 1
  %local.later.offset.569 = load i32, ptr %local.offset.29, align 4
  %stack.sub.570 = sub i32 %local.later.offset.569, %local.old.extent.454
  %stack.offset.571 = add i32 %stack.sub.570, %local.source.extent.313
  %local.later.offset.selected.572 = select i1 %local.is.active.568, i32 %stack.offset.571, i32 %local.later.offset.569
  store i32 %local.later.offset.selected.572, ptr %local.offset.29, align 4
  %local.is.active.573 = load i1, ptr %local.active.33, align 1
  %local.later.offset.574 = load i32, ptr %local.offset.34, align 4
  %stack.sub.575 = sub i32 %local.later.offset.574, %local.old.extent.454
  %stack.offset.576 = add i32 %stack.sub.575, %local.source.extent.313
  %local.later.offset.selected.577 = select i1 %local.is.active.573, i32 %stack.offset.576, i32 %local.later.offset.574
  store i32 %local.later.offset.selected.577, ptr %local.offset.34, align 4
  %local.is.active.578 = load i1, ptr %local.active.38, align 1
  %local.later.offset.579 = load i32, ptr %local.offset.39, align 4
  %stack.sub.580 = sub i32 %local.later.offset.579, %local.old.extent.454
  %stack.offset.581 = add i32 %stack.sub.580, %local.source.extent.313
  %local.later.offset.selected.582 = select i1 %local.is.active.578, i32 %stack.offset.581, i32 %local.later.offset.579
  store i32 %local.later.offset.selected.582, ptr %local.offset.39, align 4
  %local.is.active.583 = load i1, ptr %local.active.43, align 1
  %local.later.offset.584 = load i32, ptr %local.offset.44, align 4
  %stack.sub.585 = sub i32 %local.later.offset.584, %local.old.extent.454
  %stack.offset.586 = add i32 %stack.sub.585, %local.source.extent.313
  %local.later.offset.selected.587 = select i1 %local.is.active.583, i32 %stack.offset.586, i32 %local.later.offset.584
  store i32 %local.later.offset.selected.587, ptr %local.offset.44, align 4
  %local.is.active.588 = load i1, ptr %local.active.48, align 1
  %local.later.offset.589 = load i32, ptr %local.offset.49, align 4
  %stack.sub.590 = sub i32 %local.later.offset.589, %local.old.extent.454
  %stack.offset.591 = add i32 %stack.sub.590, %local.source.extent.313
  %local.later.offset.selected.592 = select i1 %local.is.active.588, i32 %stack.offset.591, i32 %local.later.offset.589
  store i32 %local.later.offset.selected.592, ptr %local.offset.49, align 4
  %local.is.active.593 = load i1, ptr %local.active.53, align 1
  %local.later.offset.594 = load i32, ptr %local.offset.54, align 4
  %stack.sub.595 = sub i32 %local.later.offset.594, %local.old.extent.454
  %stack.offset.596 = add i32 %stack.sub.595, %local.source.extent.313
  %local.later.offset.selected.597 = select i1 %local.is.active.593, i32 %stack.offset.596, i32 %local.later.offset.594
  store i32 %local.later.offset.selected.597, ptr %local.offset.54, align 4
  %local.is.active.598 = load i1, ptr %local.active.58, align 1
  %local.later.offset.599 = load i32, ptr %local.offset.59, align 4
  %stack.sub.600 = sub i32 %local.later.offset.599, %local.old.extent.454
  %stack.offset.601 = add i32 %stack.sub.600, %local.source.extent.313
  %local.later.offset.selected.602 = select i1 %local.is.active.598, i32 %stack.offset.601, i32 %local.later.offset.599
  store i32 %local.later.offset.selected.602, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.460, ptr %local.offset.9, align 4
  store i32 %local.source.extent.313, ptr %local.extent.10, align 4
  store i32 %local.source.payload.314, ptr %local.payload.11, align 4
  store i32 8, ptr %local.type.12, align 4
  %local.is.active.603 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.604 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.605 = select i1 %local.is.active.603, i32 %local.sum.extent.604, i32 0
  %stack.offset.606 = add i32 0, %local.sum.selected.605
  %local.is.active.607 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.608 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.609 = select i1 %local.is.active.607, i32 %local.sum.extent.608, i32 0
  %stack.offset.610 = add i32 %stack.offset.606, %local.sum.selected.609
  %local.is.active.611 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.612 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.613 = select i1 %local.is.active.611, i32 %local.sum.extent.612, i32 0
  %stack.offset.614 = add i32 %stack.offset.610, %local.sum.selected.613
  %local.is.active.615 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.616 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.617 = select i1 %local.is.active.615, i32 %local.sum.extent.616, i32 0
  %stack.offset.618 = add i32 %stack.offset.614, %local.sum.selected.617
  %local.is.active.619 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.620 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.621 = select i1 %local.is.active.619, i32 %local.sum.extent.620, i32 0
  %stack.offset.622 = add i32 %stack.offset.618, %local.sum.selected.621
  %local.is.active.623 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.624 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.625 = select i1 %local.is.active.623, i32 %local.sum.extent.624, i32 0
  %stack.offset.626 = add i32 %stack.offset.622, %local.sum.selected.625
  %local.is.active.627 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.628 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.629 = select i1 %local.is.active.627, i32 %local.sum.extent.628, i32 0
  %stack.offset.630 = add i32 %stack.offset.626, %local.sum.selected.629
  %local.is.active.631 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.632 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.633 = select i1 %local.is.active.631, i32 %local.sum.extent.632, i32 0
  %stack.offset.634 = add i32 %stack.offset.630, %local.sum.selected.633
  %local.is.active.635 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.636 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.637 = select i1 %local.is.active.635, i32 %local.sum.extent.636, i32 0
  %stack.offset.638 = add i32 %stack.offset.634, %local.sum.selected.637
  %local.is.active.639 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.640 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.641 = select i1 %local.is.active.639, i32 %local.sum.extent.640, i32 0
  %stack.offset.642 = add i32 %stack.offset.638, %local.sum.selected.641
  %local.is.active.643 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.644 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.645 = select i1 %local.is.active.643, i32 %local.sum.extent.644, i32 0
  %stack.offset.646 = add i32 %stack.offset.642, %local.sum.selected.645
  %local.is.active.647 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.648 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.649 = select i1 %local.is.active.647, i32 %local.sum.extent.648, i32 0
  %stack.offset.650 = add i32 %stack.offset.646, %local.sum.selected.649
  %stack.offset.651 = add i32 0, %local.source.extent.313
  %stack.offset.652 = add i32 %stack.offset.650, %stack.offset.651
  %stack.offset.653 = add i32 %context.value.75, %stack.offset.652
  %cursor.status.654 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.653)
  %cursor.ok.655 = icmp eq i32 %cursor.status.654, 0
  br i1 %cursor.ok.655, label %cursor.continue.656, label %frame.failure.0
cursor.continue.656:
  %step.status.657 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.658 = icmp eq i32 %step.status.657, 0
  br i1 %helper.ok.658, label %helper.continue.659, label %frame.failure.0
helper.continue.659:
  %local.is.active.660 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.661 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.662 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.663 = select i1 %local.is.active.660, i32 %local.previous.extent.661, i32 0
  %local.old.payload.664 = select i1 %local.is.active.660, i32 %local.previous.payload.662, i32 0
  %local.is.active.665 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.666 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.667 = select i1 %local.is.active.665, i32 %local.sum.extent.666, i32 0
  %stack.offset.668 = add i32 0, %local.sum.selected.667
  %local.is.active.669 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.670 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.671 = select i1 %local.is.active.669, i32 %local.sum.extent.670, i32 0
  %stack.offset.672 = add i32 %stack.offset.668, %local.sum.selected.671
  %stack.offset.673 = add i32 %context.value.75, %stack.offset.672
  %stack.offset.674 = add i32 %stack.offset.673, %local.old.extent.663
  %context.field.675 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.676 = load i32, ptr %context.field.675, align 4
  %stack.sub.677 = sub i32 %context.value.676, %stack.offset.674
  %stack.sub.678 = sub i32 %context.value.676, %local.old.extent.663
  %stack.offset.679 = add i32 %stack.sub.678, %local.source.extent.313
  %local.grows.680 = icmp ugt i32 %local.source.extent.313, %local.old.extent.663
  br i1 %local.grows.680, label %local.grow.681, label %local.fixed.682
local.grow.681:
  %reserve.status.684 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.679, i32 18)
  %reserve.ok.685 = icmp eq i32 %reserve.status.684, 0
  br i1 %reserve.ok.685, label %reserve.continue.686, label %frame.failure.0
reserve.continue.686:
  %stack.sub.687 = sub i32 %local.source.extent.313, %local.old.extent.663
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.687)
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %runtime.ok.690 = icmp eq i32 %context.value.689, 0
  br i1 %runtime.ok.690, label %runtime.continue.691, label %frame.failure.0
runtime.continue.691:
  br label %local.layout.ready.683
local.fixed.682:
  br label %local.layout.ready.683
local.layout.ready.683:
  %stack.offset.692 = add i32 %stack.offset.673, %local.source.extent.313
  %local.is.active.693 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.694 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.695 = select i1 %local.is.active.693, i32 %local.suffix.payload.694, i32 0
  %stack.offset.696 = add i32 0, %local.suffix.selected.695
  %local.is.active.697 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.698 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.699 = select i1 %local.is.active.697, i32 %local.suffix.payload.698, i32 0
  %stack.offset.700 = add i32 %stack.offset.696, %local.suffix.selected.699
  %local.is.active.701 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.702 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.703 = select i1 %local.is.active.701, i32 %local.suffix.payload.702, i32 0
  %stack.offset.704 = add i32 %stack.offset.700, %local.suffix.selected.703
  %local.is.active.705 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.706 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.707 = select i1 %local.is.active.705, i32 %local.suffix.payload.706, i32 0
  %stack.offset.708 = add i32 %stack.offset.704, %local.suffix.selected.707
  %local.is.active.709 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.710 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.711 = select i1 %local.is.active.709, i32 %local.suffix.payload.710, i32 0
  %stack.offset.712 = add i32 %stack.offset.708, %local.suffix.selected.711
  %local.is.active.713 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.714 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.715 = select i1 %local.is.active.713, i32 %local.suffix.payload.714, i32 0
  %stack.offset.716 = add i32 %stack.offset.712, %local.suffix.selected.715
  %local.is.active.717 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.718 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.719 = select i1 %local.is.active.717, i32 %local.suffix.payload.718, i32 0
  %stack.offset.720 = add i32 %stack.offset.716, %local.suffix.selected.719
  %local.is.active.721 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.722 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.723 = select i1 %local.is.active.721, i32 %local.suffix.payload.722, i32 0
  %stack.offset.724 = add i32 %stack.offset.720, %local.suffix.selected.723
  %local.is.active.725 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.726 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.727 = select i1 %local.is.active.725, i32 %local.suffix.payload.726, i32 0
  %stack.offset.728 = add i32 %stack.offset.724, %local.suffix.selected.727
  %stack.offset.729 = add i32 0, %local.source.payload.314
  %stack.offset.730 = add i32 %stack.offset.728, %stack.offset.729
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.692, i32 %stack.offset.674, i32 %stack.sub.677, i32 %stack.offset.730, i32 0, i32 14)
  %context.field.731 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.732 = load i32, ptr %context.field.731, align 4
  %runtime.ok.733 = icmp eq i32 %context.value.732, 0
  br i1 %runtime.ok.733, label %runtime.continue.734, label %frame.failure.0
runtime.continue.734:
  %stack.sub.735 = sub i32 %context.value.676, %local.source.extent.313
  %stack.sub.736 = sub i32 %stack.sub.735, %local.old.extent.663
  %stack.offset.737 = add i32 %stack.sub.736, %local.source.extent.313
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.673, i32 %stack.offset.737, i32 %local.source.extent.313, i32 %local.source.payload.314, i32 8, i32 4)
  %context.field.738 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.739 = load i32, ptr %context.field.738, align 4
  %runtime.ok.740 = icmp eq i32 %context.value.739, 0
  br i1 %runtime.ok.740, label %runtime.continue.741, label %frame.failure.0
runtime.continue.741:
  %stack.sub.742 = sub i32 %context.value.676, %local.old.extent.663
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.742, i32 0, i32 0, i32 0)
  %context.field.743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.744 = load i32, ptr %context.field.743, align 4
  %runtime.ok.745 = icmp eq i32 %context.value.744, 0
  br i1 %runtime.ok.745, label %runtime.continue.746, label %frame.failure.0
runtime.continue.746:
  %local.shrinks.747 = icmp ult i32 %local.source.extent.313, %local.old.extent.663
  br i1 %local.shrinks.747, label %local.shrink.748, label %local.counts.ready.749
local.shrink.748:
  %stack.sub.750 = sub i32 %local.old.extent.663, %local.source.extent.313
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.750)
  %context.field.751 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.752 = load i32, ptr %context.field.751, align 4
  %runtime.ok.753 = icmp eq i32 %context.value.752, 0
  br i1 %runtime.ok.753, label %runtime.continue.754, label %frame.failure.0
runtime.continue.754:
  br label %local.counts.ready.749
local.counts.ready.749:
  %local.payload.delta.755 = sub i32 %local.source.payload.314, %local.old.payload.664
  %stack.sub.756 = sub i32 0, %local.old.payload.664
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.756, i32 %local.payload.delta.755)
  %context.field.757 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.758 = load i32, ptr %context.field.757, align 4
  %runtime.ok.759 = icmp eq i32 %context.value.758, 0
  br i1 %runtime.ok.759, label %runtime.continue.760, label %frame.failure.0
runtime.continue.760:
  %local.is.active.761 = load i1, ptr %local.active.18, align 1
  %local.later.offset.762 = load i32, ptr %local.offset.19, align 4
  %stack.sub.763 = sub i32 %local.later.offset.762, %local.old.extent.663
  %stack.offset.764 = add i32 %stack.sub.763, %local.source.extent.313
  %local.later.offset.selected.765 = select i1 %local.is.active.761, i32 %stack.offset.764, i32 %local.later.offset.762
  store i32 %local.later.offset.selected.765, ptr %local.offset.19, align 4
  %local.is.active.766 = load i1, ptr %local.active.23, align 1
  %local.later.offset.767 = load i32, ptr %local.offset.24, align 4
  %stack.sub.768 = sub i32 %local.later.offset.767, %local.old.extent.663
  %stack.offset.769 = add i32 %stack.sub.768, %local.source.extent.313
  %local.later.offset.selected.770 = select i1 %local.is.active.766, i32 %stack.offset.769, i32 %local.later.offset.767
  store i32 %local.later.offset.selected.770, ptr %local.offset.24, align 4
  %local.is.active.771 = load i1, ptr %local.active.28, align 1
  %local.later.offset.772 = load i32, ptr %local.offset.29, align 4
  %stack.sub.773 = sub i32 %local.later.offset.772, %local.old.extent.663
  %stack.offset.774 = add i32 %stack.sub.773, %local.source.extent.313
  %local.later.offset.selected.775 = select i1 %local.is.active.771, i32 %stack.offset.774, i32 %local.later.offset.772
  store i32 %local.later.offset.selected.775, ptr %local.offset.29, align 4
  %local.is.active.776 = load i1, ptr %local.active.33, align 1
  %local.later.offset.777 = load i32, ptr %local.offset.34, align 4
  %stack.sub.778 = sub i32 %local.later.offset.777, %local.old.extent.663
  %stack.offset.779 = add i32 %stack.sub.778, %local.source.extent.313
  %local.later.offset.selected.780 = select i1 %local.is.active.776, i32 %stack.offset.779, i32 %local.later.offset.777
  store i32 %local.later.offset.selected.780, ptr %local.offset.34, align 4
  %local.is.active.781 = load i1, ptr %local.active.38, align 1
  %local.later.offset.782 = load i32, ptr %local.offset.39, align 4
  %stack.sub.783 = sub i32 %local.later.offset.782, %local.old.extent.663
  %stack.offset.784 = add i32 %stack.sub.783, %local.source.extent.313
  %local.later.offset.selected.785 = select i1 %local.is.active.781, i32 %stack.offset.784, i32 %local.later.offset.782
  store i32 %local.later.offset.selected.785, ptr %local.offset.39, align 4
  %local.is.active.786 = load i1, ptr %local.active.43, align 1
  %local.later.offset.787 = load i32, ptr %local.offset.44, align 4
  %stack.sub.788 = sub i32 %local.later.offset.787, %local.old.extent.663
  %stack.offset.789 = add i32 %stack.sub.788, %local.source.extent.313
  %local.later.offset.selected.790 = select i1 %local.is.active.786, i32 %stack.offset.789, i32 %local.later.offset.787
  store i32 %local.later.offset.selected.790, ptr %local.offset.44, align 4
  %local.is.active.791 = load i1, ptr %local.active.48, align 1
  %local.later.offset.792 = load i32, ptr %local.offset.49, align 4
  %stack.sub.793 = sub i32 %local.later.offset.792, %local.old.extent.663
  %stack.offset.794 = add i32 %stack.sub.793, %local.source.extent.313
  %local.later.offset.selected.795 = select i1 %local.is.active.791, i32 %stack.offset.794, i32 %local.later.offset.792
  store i32 %local.later.offset.selected.795, ptr %local.offset.49, align 4
  %local.is.active.796 = load i1, ptr %local.active.53, align 1
  %local.later.offset.797 = load i32, ptr %local.offset.54, align 4
  %stack.sub.798 = sub i32 %local.later.offset.797, %local.old.extent.663
  %stack.offset.799 = add i32 %stack.sub.798, %local.source.extent.313
  %local.later.offset.selected.800 = select i1 %local.is.active.796, i32 %stack.offset.799, i32 %local.later.offset.797
  store i32 %local.later.offset.selected.800, ptr %local.offset.54, align 4
  %local.is.active.801 = load i1, ptr %local.active.58, align 1
  %local.later.offset.802 = load i32, ptr %local.offset.59, align 4
  %stack.sub.803 = sub i32 %local.later.offset.802, %local.old.extent.663
  %stack.offset.804 = add i32 %stack.sub.803, %local.source.extent.313
  %local.later.offset.selected.805 = select i1 %local.is.active.801, i32 %stack.offset.804, i32 %local.later.offset.802
  store i32 %local.later.offset.selected.805, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.673, ptr %local.offset.14, align 4
  store i32 %local.source.extent.313, ptr %local.extent.15, align 4
  store i32 %local.source.payload.314, ptr %local.payload.16, align 4
  store i32 8, ptr %local.type.17, align 4
  %local.is.active.806 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.807 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.808 = select i1 %local.is.active.806, i32 %local.sum.extent.807, i32 0
  %stack.offset.809 = add i32 0, %local.sum.selected.808
  %local.is.active.810 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.811 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.812 = select i1 %local.is.active.810, i32 %local.sum.extent.811, i32 0
  %stack.offset.813 = add i32 %stack.offset.809, %local.sum.selected.812
  %local.is.active.814 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.815 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.816 = select i1 %local.is.active.814, i32 %local.sum.extent.815, i32 0
  %stack.offset.817 = add i32 %stack.offset.813, %local.sum.selected.816
  %local.is.active.818 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.819 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.820 = select i1 %local.is.active.818, i32 %local.sum.extent.819, i32 0
  %stack.offset.821 = add i32 %stack.offset.817, %local.sum.selected.820
  %local.is.active.822 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.823 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.824 = select i1 %local.is.active.822, i32 %local.sum.extent.823, i32 0
  %stack.offset.825 = add i32 %stack.offset.821, %local.sum.selected.824
  %local.is.active.826 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.827 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.828 = select i1 %local.is.active.826, i32 %local.sum.extent.827, i32 0
  %stack.offset.829 = add i32 %stack.offset.825, %local.sum.selected.828
  %local.is.active.830 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.831 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.832 = select i1 %local.is.active.830, i32 %local.sum.extent.831, i32 0
  %stack.offset.833 = add i32 %stack.offset.829, %local.sum.selected.832
  %local.is.active.834 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.835 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.836 = select i1 %local.is.active.834, i32 %local.sum.extent.835, i32 0
  %stack.offset.837 = add i32 %stack.offset.833, %local.sum.selected.836
  %local.is.active.838 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.839 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.840 = select i1 %local.is.active.838, i32 %local.sum.extent.839, i32 0
  %stack.offset.841 = add i32 %stack.offset.837, %local.sum.selected.840
  %local.is.active.842 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.843 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.844 = select i1 %local.is.active.842, i32 %local.sum.extent.843, i32 0
  %stack.offset.845 = add i32 %stack.offset.841, %local.sum.selected.844
  %local.is.active.846 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.847 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.848 = select i1 %local.is.active.846, i32 %local.sum.extent.847, i32 0
  %stack.offset.849 = add i32 %stack.offset.845, %local.sum.selected.848
  %local.is.active.850 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.851 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.852 = select i1 %local.is.active.850, i32 %local.sum.extent.851, i32 0
  %stack.offset.853 = add i32 %stack.offset.849, %local.sum.selected.852
  %stack.offset.854 = add i32 %stack.offset.853, 0
  %stack.offset.855 = add i32 %context.value.75, %stack.offset.854
  %cursor.status.856 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.855)
  %cursor.ok.857 = icmp eq i32 %cursor.status.856, 0
  br i1 %cursor.ok.857, label %cursor.continue.858, label %frame.failure.0
cursor.continue.858:
  %step.status.859 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.860 = icmp eq i32 %step.status.859, 0
  br i1 %helper.ok.860, label %helper.continue.861, label %frame.failure.0
helper.continue.861:
  %local.source.offset.862 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.863 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.864 = load i32, ptr %local.payload.16, align 4
  %context.field.865 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.866 = load i32, ptr %context.field.865, align 4
  %stack.offset.867 = add i32 %context.value.866, %local.source.extent.863
  %reserve.status.868 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.867, i32 20)
  %reserve.ok.869 = icmp eq i32 %reserve.status.868, 0
  br i1 %reserve.ok.869, label %reserve.continue.870, label %frame.failure.0
reserve.continue.870:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.866, i32 %local.source.offset.862, i32 %local.source.extent.863, i32 %local.source.payload.864, i32 8)
  %context.field.871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.872 = load i32, ptr %context.field.871, align 4
  %runtime.ok.873 = icmp eq i32 %context.value.872, 0
  br i1 %runtime.ok.873, label %runtime.continue.874, label %frame.failure.0
runtime.continue.874:
  %local.is.active.875 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.876 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.877 = select i1 %local.is.active.875, i32 %local.sum.extent.876, i32 0
  %stack.offset.878 = add i32 0, %local.sum.selected.877
  %local.is.active.879 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.880 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.881 = select i1 %local.is.active.879, i32 %local.sum.extent.880, i32 0
  %stack.offset.882 = add i32 %stack.offset.878, %local.sum.selected.881
  %local.is.active.883 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.884 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.885 = select i1 %local.is.active.883, i32 %local.sum.extent.884, i32 0
  %stack.offset.886 = add i32 %stack.offset.882, %local.sum.selected.885
  %local.is.active.887 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.888 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.889 = select i1 %local.is.active.887, i32 %local.sum.extent.888, i32 0
  %stack.offset.890 = add i32 %stack.offset.886, %local.sum.selected.889
  %local.is.active.891 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.892 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.893 = select i1 %local.is.active.891, i32 %local.sum.extent.892, i32 0
  %stack.offset.894 = add i32 %stack.offset.890, %local.sum.selected.893
  %local.is.active.895 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.896 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.897 = select i1 %local.is.active.895, i32 %local.sum.extent.896, i32 0
  %stack.offset.898 = add i32 %stack.offset.894, %local.sum.selected.897
  %local.is.active.899 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.900 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.901 = select i1 %local.is.active.899, i32 %local.sum.extent.900, i32 0
  %stack.offset.902 = add i32 %stack.offset.898, %local.sum.selected.901
  %local.is.active.903 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.904 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.905 = select i1 %local.is.active.903, i32 %local.sum.extent.904, i32 0
  %stack.offset.906 = add i32 %stack.offset.902, %local.sum.selected.905
  %local.is.active.907 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.908 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.909 = select i1 %local.is.active.907, i32 %local.sum.extent.908, i32 0
  %stack.offset.910 = add i32 %stack.offset.906, %local.sum.selected.909
  %local.is.active.911 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.912 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.913 = select i1 %local.is.active.911, i32 %local.sum.extent.912, i32 0
  %stack.offset.914 = add i32 %stack.offset.910, %local.sum.selected.913
  %local.is.active.915 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.916 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.917 = select i1 %local.is.active.915, i32 %local.sum.extent.916, i32 0
  %stack.offset.918 = add i32 %stack.offset.914, %local.sum.selected.917
  %local.is.active.919 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.920 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.921 = select i1 %local.is.active.919, i32 %local.sum.extent.920, i32 0
  %stack.offset.922 = add i32 %stack.offset.918, %local.sum.selected.921
  %stack.offset.923 = add i32 0, %local.source.extent.863
  %stack.offset.924 = add i32 %stack.offset.922, %stack.offset.923
  %stack.offset.925 = add i32 %context.value.75, %stack.offset.924
  %cursor.status.926 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.925)
  %cursor.ok.927 = icmp eq i32 %cursor.status.926, 0
  br i1 %cursor.ok.927, label %cursor.continue.928, label %frame.failure.0
cursor.continue.928:
  %step.status.929 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.930 = icmp eq i32 %step.status.929, 0
  br i1 %helper.ok.930, label %helper.continue.931, label %frame.failure.0
helper.continue.931:
  %local.is.active.932 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.933 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.934 = select i1 %local.is.active.932, i32 %local.sum.extent.933, i32 0
  %stack.offset.935 = add i32 0, %local.sum.selected.934
  %local.is.active.936 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.937 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.938 = select i1 %local.is.active.936, i32 %local.sum.extent.937, i32 0
  %stack.offset.939 = add i32 %stack.offset.935, %local.sum.selected.938
  %local.is.active.940 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.941 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.942 = select i1 %local.is.active.940, i32 %local.sum.extent.941, i32 0
  %stack.offset.943 = add i32 %stack.offset.939, %local.sum.selected.942
  %local.is.active.944 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.945 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.946 = select i1 %local.is.active.944, i32 %local.sum.extent.945, i32 0
  %stack.offset.947 = add i32 %stack.offset.943, %local.sum.selected.946
  %local.is.active.948 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.949 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.950 = select i1 %local.is.active.948, i32 %local.sum.extent.949, i32 0
  %stack.offset.951 = add i32 %stack.offset.947, %local.sum.selected.950
  %local.is.active.952 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.953 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.954 = select i1 %local.is.active.952, i32 %local.sum.extent.953, i32 0
  %stack.offset.955 = add i32 %stack.offset.951, %local.sum.selected.954
  %local.is.active.956 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.957 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.958 = select i1 %local.is.active.956, i32 %local.sum.extent.957, i32 0
  %stack.offset.959 = add i32 %stack.offset.955, %local.sum.selected.958
  %local.is.active.960 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.961 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.962 = select i1 %local.is.active.960, i32 %local.sum.extent.961, i32 0
  %stack.offset.963 = add i32 %stack.offset.959, %local.sum.selected.962
  %local.is.active.964 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.965 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.966 = select i1 %local.is.active.964, i32 %local.sum.extent.965, i32 0
  %stack.offset.967 = add i32 %stack.offset.963, %local.sum.selected.966
  %local.is.active.968 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.969 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.970 = select i1 %local.is.active.968, i32 %local.sum.extent.969, i32 0
  %stack.offset.971 = add i32 %stack.offset.967, %local.sum.selected.970
  %local.is.active.972 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.973 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.974 = select i1 %local.is.active.972, i32 %local.sum.extent.973, i32 0
  %stack.offset.975 = add i32 %stack.offset.971, %local.sum.selected.974
  %local.is.active.976 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.977 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.978 = select i1 %local.is.active.976, i32 %local.sum.extent.977, i32 0
  %stack.offset.979 = add i32 %stack.offset.975, %local.sum.selected.978
  %stack.offset.980 = add i32 %stack.offset.979, 0
  %stack.offset.981 = add i32 %context.value.75, %stack.offset.980
  %field.location.982 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.983 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.981, i32 %local.source.extent.863, i32 0, i32 22, ptr %field.location.982)
  %helper.ok.984 = icmp eq i32 %field.location.status.983, 0
  br i1 %helper.ok.984, label %helper.continue.985, label %frame.failure.0
helper.continue.985:
  %field.offset.pointer.986 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.982, i32 0, i32 0
  %field.offset.987 = load i32, ptr %field.offset.pointer.986, align 4
  %field.payload.pointer.988 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.982, i32 0, i32 1
  %field.payload.989 = load i32, ptr %field.payload.pointer.988, align 4
  %field.extent.pointer.990 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.982, i32 0, i32 2
  %field.extent.991 = load i32, ptr %field.extent.pointer.990, align 4
  %stack.offset.992 = add i32 %stack.offset.981, %field.extent.991
  %context.field.993 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.994 = load i32, ptr %context.field.993, align 4
  %field.result.grows.995 = icmp ugt i32 %stack.offset.992, %context.value.994
  br i1 %field.result.grows.995, label %field.result.reserve.996, label %field.result.existing.997
field.result.reserve.996:
  %reserve.status.999 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.992, i32 23)
  %reserve.ok.1000 = icmp eq i32 %reserve.status.999, 0
  br i1 %reserve.ok.1000, label %reserve.continue.1001, label %frame.failure.0
reserve.continue.1001:
  br label %field.result.ready.998
field.result.existing.997:
  br label %field.result.ready.998
field.result.ready.998:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.981, i32 %field.offset.987, i32 %field.extent.991, i32 %field.payload.989, i32 9, i32 7)
  %context.field.1002 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1003 = load i32, ptr %context.field.1002, align 4
  %runtime.ok.1004 = icmp eq i32 %context.value.1003, 0
  br i1 %runtime.ok.1004, label %runtime.continue.1005, label %frame.failure.0
runtime.continue.1005:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.992, i32 0, i32 0, i32 0)
  %context.field.1006 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1007 = load i32, ptr %context.field.1006, align 4
  %runtime.ok.1008 = icmp eq i32 %context.value.1007, 0
  br i1 %runtime.ok.1008, label %runtime.continue.1009, label %frame.failure.0
runtime.continue.1009:
  %stack.sub.1010 = sub i32 %field.payload.989, %local.source.payload.864
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1010, i32 0)
  %context.field.1011 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1012 = load i32, ptr %context.field.1011, align 4
  %runtime.ok.1013 = icmp eq i32 %context.value.1012, 0
  br i1 %runtime.ok.1013, label %runtime.continue.1014, label %frame.failure.0
runtime.continue.1014:
  %local.is.active.1015 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1016 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1017 = select i1 %local.is.active.1015, i32 %local.sum.extent.1016, i32 0
  %stack.offset.1018 = add i32 0, %local.sum.selected.1017
  %local.is.active.1019 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1020 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1021 = select i1 %local.is.active.1019, i32 %local.sum.extent.1020, i32 0
  %stack.offset.1022 = add i32 %stack.offset.1018, %local.sum.selected.1021
  %local.is.active.1023 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1024 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1025 = select i1 %local.is.active.1023, i32 %local.sum.extent.1024, i32 0
  %stack.offset.1026 = add i32 %stack.offset.1022, %local.sum.selected.1025
  %local.is.active.1027 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1028 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1029 = select i1 %local.is.active.1027, i32 %local.sum.extent.1028, i32 0
  %stack.offset.1030 = add i32 %stack.offset.1026, %local.sum.selected.1029
  %local.is.active.1031 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1032 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1033 = select i1 %local.is.active.1031, i32 %local.sum.extent.1032, i32 0
  %stack.offset.1034 = add i32 %stack.offset.1030, %local.sum.selected.1033
  %local.is.active.1035 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1036 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1037 = select i1 %local.is.active.1035, i32 %local.sum.extent.1036, i32 0
  %stack.offset.1038 = add i32 %stack.offset.1034, %local.sum.selected.1037
  %local.is.active.1039 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1040 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1041 = select i1 %local.is.active.1039, i32 %local.sum.extent.1040, i32 0
  %stack.offset.1042 = add i32 %stack.offset.1038, %local.sum.selected.1041
  %local.is.active.1043 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1044 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1045 = select i1 %local.is.active.1043, i32 %local.sum.extent.1044, i32 0
  %stack.offset.1046 = add i32 %stack.offset.1042, %local.sum.selected.1045
  %local.is.active.1047 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1048 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1049 = select i1 %local.is.active.1047, i32 %local.sum.extent.1048, i32 0
  %stack.offset.1050 = add i32 %stack.offset.1046, %local.sum.selected.1049
  %local.is.active.1051 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1052 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1053 = select i1 %local.is.active.1051, i32 %local.sum.extent.1052, i32 0
  %stack.offset.1054 = add i32 %stack.offset.1050, %local.sum.selected.1053
  %local.is.active.1055 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1056 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1057 = select i1 %local.is.active.1055, i32 %local.sum.extent.1056, i32 0
  %stack.offset.1058 = add i32 %stack.offset.1054, %local.sum.selected.1057
  %local.is.active.1059 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1060 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1061 = select i1 %local.is.active.1059, i32 %local.sum.extent.1060, i32 0
  %stack.offset.1062 = add i32 %stack.offset.1058, %local.sum.selected.1061
  %stack.offset.1063 = add i32 0, %field.extent.991
  %stack.offset.1064 = add i32 %stack.offset.1062, %stack.offset.1063
  %stack.offset.1065 = add i32 %context.value.75, %stack.offset.1064
  %cursor.status.1066 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1065)
  %cursor.ok.1067 = icmp eq i32 %cursor.status.1066, 0
  br i1 %cursor.ok.1067, label %cursor.continue.1068, label %frame.failure.0
cursor.continue.1068:
  %step.status.1069 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.1070 = icmp eq i32 %step.status.1069, 0
  br i1 %helper.ok.1070, label %helper.continue.1071, label %frame.failure.0
helper.continue.1071:
  %local.is.active.1072 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1073 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1074 = select i1 %local.is.active.1072, i32 %local.sum.extent.1073, i32 0
  %stack.offset.1075 = add i32 0, %local.sum.selected.1074
  %local.is.active.1076 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1077 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1078 = select i1 %local.is.active.1076, i32 %local.sum.extent.1077, i32 0
  %stack.offset.1079 = add i32 %stack.offset.1075, %local.sum.selected.1078
  %local.is.active.1080 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1081 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1082 = select i1 %local.is.active.1080, i32 %local.sum.extent.1081, i32 0
  %stack.offset.1083 = add i32 %stack.offset.1079, %local.sum.selected.1082
  %local.is.active.1084 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1085 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1086 = select i1 %local.is.active.1084, i32 %local.sum.extent.1085, i32 0
  %stack.offset.1087 = add i32 %stack.offset.1083, %local.sum.selected.1086
  %local.is.active.1088 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1089 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1090 = select i1 %local.is.active.1088, i32 %local.sum.extent.1089, i32 0
  %stack.offset.1091 = add i32 %stack.offset.1087, %local.sum.selected.1090
  %local.is.active.1092 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1093 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1094 = select i1 %local.is.active.1092, i32 %local.sum.extent.1093, i32 0
  %stack.offset.1095 = add i32 %stack.offset.1091, %local.sum.selected.1094
  %local.is.active.1096 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1097 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1098 = select i1 %local.is.active.1096, i32 %local.sum.extent.1097, i32 0
  %stack.offset.1099 = add i32 %stack.offset.1095, %local.sum.selected.1098
  %local.is.active.1100 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1101 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1102 = select i1 %local.is.active.1100, i32 %local.sum.extent.1101, i32 0
  %stack.offset.1103 = add i32 %stack.offset.1099, %local.sum.selected.1102
  %local.is.active.1104 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1105 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1106 = select i1 %local.is.active.1104, i32 %local.sum.extent.1105, i32 0
  %stack.offset.1107 = add i32 %stack.offset.1103, %local.sum.selected.1106
  %local.is.active.1108 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1109 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1110 = select i1 %local.is.active.1108, i32 %local.sum.extent.1109, i32 0
  %stack.offset.1111 = add i32 %stack.offset.1107, %local.sum.selected.1110
  %local.is.active.1112 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1113 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1114 = select i1 %local.is.active.1112, i32 %local.sum.extent.1113, i32 0
  %stack.offset.1115 = add i32 %stack.offset.1111, %local.sum.selected.1114
  %local.is.active.1116 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1117 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1118 = select i1 %local.is.active.1116, i32 %local.sum.extent.1117, i32 0
  %stack.offset.1119 = add i32 %stack.offset.1115, %local.sum.selected.1118
  %stack.offset.1120 = add i32 %stack.offset.1119, 0
  %stack.offset.1121 = add i32 %context.value.75, %stack.offset.1120
  %field.location.1122 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.1123 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.1121, i32 %field.extent.991, i32 0, i32 25, ptr %field.location.1122)
  %helper.ok.1124 = icmp eq i32 %field.location.status.1123, 0
  br i1 %helper.ok.1124, label %helper.continue.1125, label %frame.failure.0
helper.continue.1125:
  %field.offset.pointer.1126 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1122, i32 0, i32 0
  %field.offset.1127 = load i32, ptr %field.offset.pointer.1126, align 4
  %field.payload.pointer.1128 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1122, i32 0, i32 1
  %field.payload.1129 = load i32, ptr %field.payload.pointer.1128, align 4
  %field.extent.pointer.1130 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1122, i32 0, i32 2
  %field.extent.1131 = load i32, ptr %field.extent.pointer.1130, align 4
  %stack.offset.1132 = add i32 %stack.offset.1121, %field.extent.1131
  %context.field.1133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1134 = load i32, ptr %context.field.1133, align 4
  %field.result.grows.1135 = icmp ugt i32 %stack.offset.1132, %context.value.1134
  br i1 %field.result.grows.1135, label %field.result.reserve.1136, label %field.result.existing.1137
field.result.reserve.1136:
  %reserve.status.1139 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1132, i32 26)
  %reserve.ok.1140 = icmp eq i32 %reserve.status.1139, 0
  br i1 %reserve.ok.1140, label %reserve.continue.1141, label %frame.failure.0
reserve.continue.1141:
  br label %field.result.ready.1138
field.result.existing.1137:
  br label %field.result.ready.1138
field.result.ready.1138:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1121, i32 %field.offset.1127, i32 %field.extent.1131, i32 %field.payload.1129, i32 12, i32 7)
  %context.field.1142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1143 = load i32, ptr %context.field.1142, align 4
  %runtime.ok.1144 = icmp eq i32 %context.value.1143, 0
  br i1 %runtime.ok.1144, label %runtime.continue.1145, label %frame.failure.0
runtime.continue.1145:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1132, i32 0, i32 0, i32 0)
  %context.field.1146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1147 = load i32, ptr %context.field.1146, align 4
  %runtime.ok.1148 = icmp eq i32 %context.value.1147, 0
  br i1 %runtime.ok.1148, label %runtime.continue.1149, label %frame.failure.0
runtime.continue.1149:
  %stack.sub.1150 = sub i32 %field.payload.1129, %field.payload.989
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1150, i32 0)
  %context.field.1151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1152 = load i32, ptr %context.field.1151, align 4
  %runtime.ok.1153 = icmp eq i32 %context.value.1152, 0
  br i1 %runtime.ok.1153, label %runtime.continue.1154, label %frame.failure.0
runtime.continue.1154:
  %local.is.active.1155 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1156 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1157 = select i1 %local.is.active.1155, i32 %local.sum.extent.1156, i32 0
  %stack.offset.1158 = add i32 0, %local.sum.selected.1157
  %local.is.active.1159 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1160 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1161 = select i1 %local.is.active.1159, i32 %local.sum.extent.1160, i32 0
  %stack.offset.1162 = add i32 %stack.offset.1158, %local.sum.selected.1161
  %local.is.active.1163 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1164 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1165 = select i1 %local.is.active.1163, i32 %local.sum.extent.1164, i32 0
  %stack.offset.1166 = add i32 %stack.offset.1162, %local.sum.selected.1165
  %local.is.active.1167 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1168 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1169 = select i1 %local.is.active.1167, i32 %local.sum.extent.1168, i32 0
  %stack.offset.1170 = add i32 %stack.offset.1166, %local.sum.selected.1169
  %local.is.active.1171 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1172 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1173 = select i1 %local.is.active.1171, i32 %local.sum.extent.1172, i32 0
  %stack.offset.1174 = add i32 %stack.offset.1170, %local.sum.selected.1173
  %local.is.active.1175 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1176 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1177 = select i1 %local.is.active.1175, i32 %local.sum.extent.1176, i32 0
  %stack.offset.1178 = add i32 %stack.offset.1174, %local.sum.selected.1177
  %local.is.active.1179 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1180 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1181 = select i1 %local.is.active.1179, i32 %local.sum.extent.1180, i32 0
  %stack.offset.1182 = add i32 %stack.offset.1178, %local.sum.selected.1181
  %local.is.active.1183 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1184 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1185 = select i1 %local.is.active.1183, i32 %local.sum.extent.1184, i32 0
  %stack.offset.1186 = add i32 %stack.offset.1182, %local.sum.selected.1185
  %local.is.active.1187 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1188 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1189 = select i1 %local.is.active.1187, i32 %local.sum.extent.1188, i32 0
  %stack.offset.1190 = add i32 %stack.offset.1186, %local.sum.selected.1189
  %local.is.active.1191 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1192 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1193 = select i1 %local.is.active.1191, i32 %local.sum.extent.1192, i32 0
  %stack.offset.1194 = add i32 %stack.offset.1190, %local.sum.selected.1193
  %local.is.active.1195 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1196 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1197 = select i1 %local.is.active.1195, i32 %local.sum.extent.1196, i32 0
  %stack.offset.1198 = add i32 %stack.offset.1194, %local.sum.selected.1197
  %local.is.active.1199 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1200 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1201 = select i1 %local.is.active.1199, i32 %local.sum.extent.1200, i32 0
  %stack.offset.1202 = add i32 %stack.offset.1198, %local.sum.selected.1201
  %stack.offset.1203 = add i32 0, %field.extent.1131
  %stack.offset.1204 = add i32 %stack.offset.1202, %stack.offset.1203
  %stack.offset.1205 = add i32 %context.value.75, %stack.offset.1204
  %cursor.status.1206 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1205)
  %cursor.ok.1207 = icmp eq i32 %cursor.status.1206, 0
  br i1 %cursor.ok.1207, label %cursor.continue.1208, label %frame.failure.0
cursor.continue.1208:
  %step.status.1209 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.1210 = icmp eq i32 %step.status.1209, 0
  br i1 %helper.ok.1210, label %helper.continue.1211, label %frame.failure.0
helper.continue.1211:
  %context.field.1212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1213 = load i32, ptr %context.field.1212, align 4
  %stack.offset.1214 = add i32 %context.value.1213, 16
  %reserve.status.1215 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1214, i32 28)
  %reserve.ok.1216 = icmp eq i32 %reserve.status.1215, 0
  br i1 %reserve.ok.1216, label %reserve.continue.1217, label %frame.failure.0
reserve.continue.1217:
  %literal.status.1218 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.1213, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 29)
  %helper.ok.1219 = icmp eq i32 %literal.status.1218, 0
  br i1 %helper.ok.1219, label %helper.continue.1220, label %frame.failure.0
helper.continue.1220:
  %local.is.active.1221 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1222 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1223 = select i1 %local.is.active.1221, i32 %local.sum.extent.1222, i32 0
  %stack.offset.1224 = add i32 0, %local.sum.selected.1223
  %local.is.active.1225 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1226 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1227 = select i1 %local.is.active.1225, i32 %local.sum.extent.1226, i32 0
  %stack.offset.1228 = add i32 %stack.offset.1224, %local.sum.selected.1227
  %local.is.active.1229 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1230 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1231 = select i1 %local.is.active.1229, i32 %local.sum.extent.1230, i32 0
  %stack.offset.1232 = add i32 %stack.offset.1228, %local.sum.selected.1231
  %local.is.active.1233 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1234 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1235 = select i1 %local.is.active.1233, i32 %local.sum.extent.1234, i32 0
  %stack.offset.1236 = add i32 %stack.offset.1232, %local.sum.selected.1235
  %local.is.active.1237 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1238 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1239 = select i1 %local.is.active.1237, i32 %local.sum.extent.1238, i32 0
  %stack.offset.1240 = add i32 %stack.offset.1236, %local.sum.selected.1239
  %local.is.active.1241 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1242 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1243 = select i1 %local.is.active.1241, i32 %local.sum.extent.1242, i32 0
  %stack.offset.1244 = add i32 %stack.offset.1240, %local.sum.selected.1243
  %local.is.active.1245 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1246 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1247 = select i1 %local.is.active.1245, i32 %local.sum.extent.1246, i32 0
  %stack.offset.1248 = add i32 %stack.offset.1244, %local.sum.selected.1247
  %local.is.active.1249 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1250 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1251 = select i1 %local.is.active.1249, i32 %local.sum.extent.1250, i32 0
  %stack.offset.1252 = add i32 %stack.offset.1248, %local.sum.selected.1251
  %local.is.active.1253 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1254 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1255 = select i1 %local.is.active.1253, i32 %local.sum.extent.1254, i32 0
  %stack.offset.1256 = add i32 %stack.offset.1252, %local.sum.selected.1255
  %local.is.active.1257 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1258 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1259 = select i1 %local.is.active.1257, i32 %local.sum.extent.1258, i32 0
  %stack.offset.1260 = add i32 %stack.offset.1256, %local.sum.selected.1259
  %local.is.active.1261 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1262 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1263 = select i1 %local.is.active.1261, i32 %local.sum.extent.1262, i32 0
  %stack.offset.1264 = add i32 %stack.offset.1260, %local.sum.selected.1263
  %local.is.active.1265 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1266 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1267 = select i1 %local.is.active.1265, i32 %local.sum.extent.1266, i32 0
  %stack.offset.1268 = add i32 %stack.offset.1264, %local.sum.selected.1267
  %stack.offset.1269 = add i32 0, %field.extent.1131
  %stack.offset.1270 = add i32 %stack.offset.1269, 16
  %stack.offset.1271 = add i32 %stack.offset.1268, %stack.offset.1270
  %stack.offset.1272 = add i32 %context.value.75, %stack.offset.1271
  %cursor.status.1273 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1272)
  %cursor.ok.1274 = icmp eq i32 %cursor.status.1273, 0
  br i1 %cursor.ok.1274, label %cursor.continue.1275, label %frame.failure.0
cursor.continue.1275:
  %step.status.1276 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.1277 = icmp eq i32 %step.status.1276, 0
  br i1 %helper.ok.1277, label %helper.continue.1278, label %frame.failure.0
helper.continue.1278:
  %context.field.1279 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1280 = load i32, ptr %context.field.1279, align 4
  %local.is.active.1281 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1282 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1283 = select i1 %local.is.active.1281, i32 %local.sum.extent.1282, i32 0
  %stack.offset.1284 = add i32 0, %local.sum.selected.1283
  %local.is.active.1285 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1286 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1287 = select i1 %local.is.active.1285, i32 %local.sum.extent.1286, i32 0
  %stack.offset.1288 = add i32 %stack.offset.1284, %local.sum.selected.1287
  %local.is.active.1289 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1290 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1291 = select i1 %local.is.active.1289, i32 %local.sum.extent.1290, i32 0
  %stack.offset.1292 = add i32 %stack.offset.1288, %local.sum.selected.1291
  %local.is.active.1293 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1294 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1295 = select i1 %local.is.active.1293, i32 %local.sum.extent.1294, i32 0
  %stack.offset.1296 = add i32 %stack.offset.1292, %local.sum.selected.1295
  %local.is.active.1297 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1298 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1299 = select i1 %local.is.active.1297, i32 %local.sum.extent.1298, i32 0
  %stack.offset.1300 = add i32 %stack.offset.1296, %local.sum.selected.1299
  %local.is.active.1301 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1302 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1303 = select i1 %local.is.active.1301, i32 %local.sum.extent.1302, i32 0
  %stack.offset.1304 = add i32 %stack.offset.1300, %local.sum.selected.1303
  %local.is.active.1305 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1306 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1307 = select i1 %local.is.active.1305, i32 %local.sum.extent.1306, i32 0
  %stack.offset.1308 = add i32 %stack.offset.1304, %local.sum.selected.1307
  %local.is.active.1309 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1310 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1311 = select i1 %local.is.active.1309, i32 %local.sum.extent.1310, i32 0
  %stack.offset.1312 = add i32 %stack.offset.1308, %local.sum.selected.1311
  %local.is.active.1313 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1314 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1315 = select i1 %local.is.active.1313, i32 %local.sum.extent.1314, i32 0
  %stack.offset.1316 = add i32 %stack.offset.1312, %local.sum.selected.1315
  %local.is.active.1317 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1318 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1319 = select i1 %local.is.active.1317, i32 %local.sum.extent.1318, i32 0
  %stack.offset.1320 = add i32 %stack.offset.1316, %local.sum.selected.1319
  %local.is.active.1321 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1322 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1323 = select i1 %local.is.active.1321, i32 %local.sum.extent.1322, i32 0
  %stack.offset.1324 = add i32 %stack.offset.1320, %local.sum.selected.1323
  %local.is.active.1325 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1326 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1327 = select i1 %local.is.active.1325, i32 %local.sum.extent.1326, i32 0
  %stack.offset.1328 = add i32 %stack.offset.1324, %local.sum.selected.1327
  %stack.offset.1329 = add i32 %stack.offset.1328, 0
  %stack.offset.1330 = add i32 %context.value.75, %stack.offset.1329
  %stack.sub.1331 = sub i32 %context.value.1280, 16
  %string.concat.units.1332 = alloca i32, align 4
  %string.concat.payload.pointer.1333 = alloca i32, align 4
  %string.concat.extent.pointer.1334 = alloca i32, align 4
  %string.concat.plan.status.1335 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.1330, i32 %field.extent.1131, i32 %stack.sub.1331, i32 16, i32 31, ptr %string.concat.units.1332, ptr %string.concat.payload.pointer.1333, ptr %string.concat.extent.pointer.1334)
  %helper.ok.1336 = icmp eq i32 %string.concat.plan.status.1335, 0
  br i1 %helper.ok.1336, label %helper.continue.1337, label %frame.failure.0
helper.continue.1337:
  %string.concat.payload.1338 = load i32, ptr %string.concat.payload.pointer.1333, align 4
  %string.concat.extent.1339 = load i32, ptr %string.concat.extent.pointer.1334, align 4
  %stack.offset.1340 = add i32 %context.value.1280, %string.concat.extent.1339
  %reserve.status.1341 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1340, i32 32)
  %reserve.ok.1342 = icmp eq i32 %reserve.status.1341, 0
  br i1 %reserve.ok.1342, label %reserve.continue.1343, label %frame.failure.0
reserve.continue.1343:
  %string.concat.write.status.1344 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.1280, i32 %string.concat.extent.1339, i32 %stack.offset.1330, i32 %field.extent.1131, i32 %stack.sub.1331, i32 16, i32 12, i32 31)
  %helper.ok.1345 = icmp eq i32 %string.concat.write.status.1344, 0
  br i1 %helper.ok.1345, label %helper.continue.1346, label %frame.failure.0
helper.continue.1346:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1330, i32 %context.value.1280, i32 %string.concat.extent.1339, i32 %string.concat.payload.1338, i32 12, i32 0)
  %context.field.1347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1348 = load i32, ptr %context.field.1347, align 4
  %runtime.ok.1349 = icmp eq i32 %context.value.1348, 0
  br i1 %runtime.ok.1349, label %runtime.continue.1350, label %frame.failure.0
runtime.continue.1350:
  %stack.offset.1351 = add i32 %stack.offset.1330, %string.concat.extent.1339
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1351, i32 0, i32 0, i32 0)
  %context.field.1352 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1353 = load i32, ptr %context.field.1352, align 4
  %runtime.ok.1354 = icmp eq i32 %context.value.1353, 0
  br i1 %runtime.ok.1354, label %runtime.continue.1355, label %frame.failure.0
runtime.continue.1355:
  %stack.offset.1356 = add i32 %field.payload.1129, 10
  %stack.sub.1357 = sub i32 %string.concat.payload.1338, %stack.offset.1356
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1357, i32 0)
  %context.field.1358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1359 = load i32, ptr %context.field.1358, align 4
  %runtime.ok.1360 = icmp eq i32 %context.value.1359, 0
  br i1 %runtime.ok.1360, label %runtime.continue.1361, label %frame.failure.0
runtime.continue.1361:
  %local.is.active.1362 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1363 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1364 = select i1 %local.is.active.1362, i32 %local.sum.extent.1363, i32 0
  %stack.offset.1365 = add i32 0, %local.sum.selected.1364
  %local.is.active.1366 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1367 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1368 = select i1 %local.is.active.1366, i32 %local.sum.extent.1367, i32 0
  %stack.offset.1369 = add i32 %stack.offset.1365, %local.sum.selected.1368
  %local.is.active.1370 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1371 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1372 = select i1 %local.is.active.1370, i32 %local.sum.extent.1371, i32 0
  %stack.offset.1373 = add i32 %stack.offset.1369, %local.sum.selected.1372
  %local.is.active.1374 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1375 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1376 = select i1 %local.is.active.1374, i32 %local.sum.extent.1375, i32 0
  %stack.offset.1377 = add i32 %stack.offset.1373, %local.sum.selected.1376
  %local.is.active.1378 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1379 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1380 = select i1 %local.is.active.1378, i32 %local.sum.extent.1379, i32 0
  %stack.offset.1381 = add i32 %stack.offset.1377, %local.sum.selected.1380
  %local.is.active.1382 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1383 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1384 = select i1 %local.is.active.1382, i32 %local.sum.extent.1383, i32 0
  %stack.offset.1385 = add i32 %stack.offset.1381, %local.sum.selected.1384
  %local.is.active.1386 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1387 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1388 = select i1 %local.is.active.1386, i32 %local.sum.extent.1387, i32 0
  %stack.offset.1389 = add i32 %stack.offset.1385, %local.sum.selected.1388
  %local.is.active.1390 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1391 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1392 = select i1 %local.is.active.1390, i32 %local.sum.extent.1391, i32 0
  %stack.offset.1393 = add i32 %stack.offset.1389, %local.sum.selected.1392
  %local.is.active.1394 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1395 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1396 = select i1 %local.is.active.1394, i32 %local.sum.extent.1395, i32 0
  %stack.offset.1397 = add i32 %stack.offset.1393, %local.sum.selected.1396
  %local.is.active.1398 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1399 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1400 = select i1 %local.is.active.1398, i32 %local.sum.extent.1399, i32 0
  %stack.offset.1401 = add i32 %stack.offset.1397, %local.sum.selected.1400
  %local.is.active.1402 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1403 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1404 = select i1 %local.is.active.1402, i32 %local.sum.extent.1403, i32 0
  %stack.offset.1405 = add i32 %stack.offset.1401, %local.sum.selected.1404
  %local.is.active.1406 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1407 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1408 = select i1 %local.is.active.1406, i32 %local.sum.extent.1407, i32 0
  %stack.offset.1409 = add i32 %stack.offset.1405, %local.sum.selected.1408
  %stack.offset.1410 = add i32 0, %string.concat.extent.1339
  %stack.offset.1411 = add i32 %stack.offset.1409, %stack.offset.1410
  %stack.offset.1412 = add i32 %context.value.75, %stack.offset.1411
  %cursor.status.1413 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1412)
  %cursor.ok.1414 = icmp eq i32 %cursor.status.1413, 0
  br i1 %cursor.ok.1414, label %cursor.continue.1415, label %frame.failure.0
cursor.continue.1415:
  %step.status.1416 = call i32 @al_owning_charge_step(ptr %ctx, i32 33)
  %helper.ok.1417 = icmp eq i32 %step.status.1416, 0
  br i1 %helper.ok.1417, label %helper.continue.1418, label %frame.failure.0
helper.continue.1418:
  %local.is.active.1419 = load i1, ptr %local.active.18, align 1
  %local.previous.extent.1420 = load i32, ptr %local.extent.20, align 4
  %local.previous.payload.1421 = load i32, ptr %local.payload.21, align 4
  %local.old.extent.1422 = select i1 %local.is.active.1419, i32 %local.previous.extent.1420, i32 0
  %local.old.payload.1423 = select i1 %local.is.active.1419, i32 %local.previous.payload.1421, i32 0
  %local.is.active.1424 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1425 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1426 = select i1 %local.is.active.1424, i32 %local.sum.extent.1425, i32 0
  %stack.offset.1427 = add i32 0, %local.sum.selected.1426
  %local.is.active.1428 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1429 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1430 = select i1 %local.is.active.1428, i32 %local.sum.extent.1429, i32 0
  %stack.offset.1431 = add i32 %stack.offset.1427, %local.sum.selected.1430
  %local.is.active.1432 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1433 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1434 = select i1 %local.is.active.1432, i32 %local.sum.extent.1433, i32 0
  %stack.offset.1435 = add i32 %stack.offset.1431, %local.sum.selected.1434
  %stack.offset.1436 = add i32 %context.value.75, %stack.offset.1435
  %stack.offset.1437 = add i32 %stack.offset.1436, %local.old.extent.1422
  %context.field.1438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1439 = load i32, ptr %context.field.1438, align 4
  %stack.sub.1440 = sub i32 %context.value.1439, %stack.offset.1437
  %stack.sub.1441 = sub i32 %context.value.1439, %local.old.extent.1422
  %stack.offset.1442 = add i32 %stack.sub.1441, %string.concat.extent.1339
  %local.grows.1443 = icmp ugt i32 %string.concat.extent.1339, %local.old.extent.1422
  br i1 %local.grows.1443, label %local.grow.1444, label %local.fixed.1445
local.grow.1444:
  %reserve.status.1447 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1442, i32 34)
  %reserve.ok.1448 = icmp eq i32 %reserve.status.1447, 0
  br i1 %reserve.ok.1448, label %reserve.continue.1449, label %frame.failure.0
reserve.continue.1449:
  %stack.sub.1450 = sub i32 %string.concat.extent.1339, %local.old.extent.1422
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.1450)
  %context.field.1451 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1452 = load i32, ptr %context.field.1451, align 4
  %runtime.ok.1453 = icmp eq i32 %context.value.1452, 0
  br i1 %runtime.ok.1453, label %runtime.continue.1454, label %frame.failure.0
runtime.continue.1454:
  br label %local.layout.ready.1446
local.fixed.1445:
  br label %local.layout.ready.1446
local.layout.ready.1446:
  %stack.offset.1455 = add i32 %stack.offset.1436, %string.concat.extent.1339
  %local.is.active.1456 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1457 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1458 = select i1 %local.is.active.1456, i32 %local.suffix.payload.1457, i32 0
  %stack.offset.1459 = add i32 0, %local.suffix.selected.1458
  %local.is.active.1460 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1461 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1462 = select i1 %local.is.active.1460, i32 %local.suffix.payload.1461, i32 0
  %stack.offset.1463 = add i32 %stack.offset.1459, %local.suffix.selected.1462
  %local.is.active.1464 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.1465 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.1466 = select i1 %local.is.active.1464, i32 %local.suffix.payload.1465, i32 0
  %stack.offset.1467 = add i32 %stack.offset.1463, %local.suffix.selected.1466
  %local.is.active.1468 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.1469 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.1470 = select i1 %local.is.active.1468, i32 %local.suffix.payload.1469, i32 0
  %stack.offset.1471 = add i32 %stack.offset.1467, %local.suffix.selected.1470
  %local.is.active.1472 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.1473 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.1474 = select i1 %local.is.active.1472, i32 %local.suffix.payload.1473, i32 0
  %stack.offset.1475 = add i32 %stack.offset.1471, %local.suffix.selected.1474
  %local.is.active.1476 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.1477 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.1478 = select i1 %local.is.active.1476, i32 %local.suffix.payload.1477, i32 0
  %stack.offset.1479 = add i32 %stack.offset.1475, %local.suffix.selected.1478
  %local.is.active.1480 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.1481 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.1482 = select i1 %local.is.active.1480, i32 %local.suffix.payload.1481, i32 0
  %stack.offset.1483 = add i32 %stack.offset.1479, %local.suffix.selected.1482
  %local.is.active.1484 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.1485 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.1486 = select i1 %local.is.active.1484, i32 %local.suffix.payload.1485, i32 0
  %stack.offset.1487 = add i32 %stack.offset.1483, %local.suffix.selected.1486
  %stack.offset.1488 = add i32 0, %string.concat.payload.1338
  %stack.offset.1489 = add i32 %stack.offset.1487, %stack.offset.1488
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1455, i32 %stack.offset.1437, i32 %stack.sub.1440, i32 %stack.offset.1489, i32 0, i32 14)
  %context.field.1490 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1491 = load i32, ptr %context.field.1490, align 4
  %runtime.ok.1492 = icmp eq i32 %context.value.1491, 0
  br i1 %runtime.ok.1492, label %runtime.continue.1493, label %frame.failure.0
runtime.continue.1493:
  %stack.sub.1494 = sub i32 %context.value.1439, %string.concat.extent.1339
  %stack.sub.1495 = sub i32 %stack.sub.1494, %local.old.extent.1422
  %stack.offset.1496 = add i32 %stack.sub.1495, %string.concat.extent.1339
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1436, i32 %stack.offset.1496, i32 %string.concat.extent.1339, i32 %string.concat.payload.1338, i32 12, i32 4)
  %context.field.1497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1498 = load i32, ptr %context.field.1497, align 4
  %runtime.ok.1499 = icmp eq i32 %context.value.1498, 0
  br i1 %runtime.ok.1499, label %runtime.continue.1500, label %frame.failure.0
runtime.continue.1500:
  %stack.sub.1501 = sub i32 %context.value.1439, %local.old.extent.1422
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1501, i32 0, i32 0, i32 0)
  %context.field.1502 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1503 = load i32, ptr %context.field.1502, align 4
  %runtime.ok.1504 = icmp eq i32 %context.value.1503, 0
  br i1 %runtime.ok.1504, label %runtime.continue.1505, label %frame.failure.0
runtime.continue.1505:
  %local.shrinks.1506 = icmp ult i32 %string.concat.extent.1339, %local.old.extent.1422
  br i1 %local.shrinks.1506, label %local.shrink.1507, label %local.counts.ready.1508
local.shrink.1507:
  %stack.sub.1509 = sub i32 %local.old.extent.1422, %string.concat.extent.1339
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1509)
  %context.field.1510 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1511 = load i32, ptr %context.field.1510, align 4
  %runtime.ok.1512 = icmp eq i32 %context.value.1511, 0
  br i1 %runtime.ok.1512, label %runtime.continue.1513, label %frame.failure.0
runtime.continue.1513:
  br label %local.counts.ready.1508
local.counts.ready.1508:
  %local.payload.delta.1514 = sub i32 %string.concat.payload.1338, %local.old.payload.1423
  %stack.sub.1515 = sub i32 0, %local.old.payload.1423
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1515, i32 %local.payload.delta.1514)
  %context.field.1516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1517 = load i32, ptr %context.field.1516, align 4
  %runtime.ok.1518 = icmp eq i32 %context.value.1517, 0
  br i1 %runtime.ok.1518, label %runtime.continue.1519, label %frame.failure.0
runtime.continue.1519:
  %local.is.active.1520 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1521 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1522 = sub i32 %local.later.offset.1521, %local.old.extent.1422
  %stack.offset.1523 = add i32 %stack.sub.1522, %string.concat.extent.1339
  %local.later.offset.selected.1524 = select i1 %local.is.active.1520, i32 %stack.offset.1523, i32 %local.later.offset.1521
  store i32 %local.later.offset.selected.1524, ptr %local.offset.24, align 4
  %local.is.active.1525 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1526 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1527 = sub i32 %local.later.offset.1526, %local.old.extent.1422
  %stack.offset.1528 = add i32 %stack.sub.1527, %string.concat.extent.1339
  %local.later.offset.selected.1529 = select i1 %local.is.active.1525, i32 %stack.offset.1528, i32 %local.later.offset.1526
  store i32 %local.later.offset.selected.1529, ptr %local.offset.29, align 4
  %local.is.active.1530 = load i1, ptr %local.active.33, align 1
  %local.later.offset.1531 = load i32, ptr %local.offset.34, align 4
  %stack.sub.1532 = sub i32 %local.later.offset.1531, %local.old.extent.1422
  %stack.offset.1533 = add i32 %stack.sub.1532, %string.concat.extent.1339
  %local.later.offset.selected.1534 = select i1 %local.is.active.1530, i32 %stack.offset.1533, i32 %local.later.offset.1531
  store i32 %local.later.offset.selected.1534, ptr %local.offset.34, align 4
  %local.is.active.1535 = load i1, ptr %local.active.38, align 1
  %local.later.offset.1536 = load i32, ptr %local.offset.39, align 4
  %stack.sub.1537 = sub i32 %local.later.offset.1536, %local.old.extent.1422
  %stack.offset.1538 = add i32 %stack.sub.1537, %string.concat.extent.1339
  %local.later.offset.selected.1539 = select i1 %local.is.active.1535, i32 %stack.offset.1538, i32 %local.later.offset.1536
  store i32 %local.later.offset.selected.1539, ptr %local.offset.39, align 4
  %local.is.active.1540 = load i1, ptr %local.active.43, align 1
  %local.later.offset.1541 = load i32, ptr %local.offset.44, align 4
  %stack.sub.1542 = sub i32 %local.later.offset.1541, %local.old.extent.1422
  %stack.offset.1543 = add i32 %stack.sub.1542, %string.concat.extent.1339
  %local.later.offset.selected.1544 = select i1 %local.is.active.1540, i32 %stack.offset.1543, i32 %local.later.offset.1541
  store i32 %local.later.offset.selected.1544, ptr %local.offset.44, align 4
  %local.is.active.1545 = load i1, ptr %local.active.48, align 1
  %local.later.offset.1546 = load i32, ptr %local.offset.49, align 4
  %stack.sub.1547 = sub i32 %local.later.offset.1546, %local.old.extent.1422
  %stack.offset.1548 = add i32 %stack.sub.1547, %string.concat.extent.1339
  %local.later.offset.selected.1549 = select i1 %local.is.active.1545, i32 %stack.offset.1548, i32 %local.later.offset.1546
  store i32 %local.later.offset.selected.1549, ptr %local.offset.49, align 4
  %local.is.active.1550 = load i1, ptr %local.active.53, align 1
  %local.later.offset.1551 = load i32, ptr %local.offset.54, align 4
  %stack.sub.1552 = sub i32 %local.later.offset.1551, %local.old.extent.1422
  %stack.offset.1553 = add i32 %stack.sub.1552, %string.concat.extent.1339
  %local.later.offset.selected.1554 = select i1 %local.is.active.1550, i32 %stack.offset.1553, i32 %local.later.offset.1551
  store i32 %local.later.offset.selected.1554, ptr %local.offset.54, align 4
  %local.is.active.1555 = load i1, ptr %local.active.58, align 1
  %local.later.offset.1556 = load i32, ptr %local.offset.59, align 4
  %stack.sub.1557 = sub i32 %local.later.offset.1556, %local.old.extent.1422
  %stack.offset.1558 = add i32 %stack.sub.1557, %string.concat.extent.1339
  %local.later.offset.selected.1559 = select i1 %local.is.active.1555, i32 %stack.offset.1558, i32 %local.later.offset.1556
  store i32 %local.later.offset.selected.1559, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.18, align 1
  store i32 %stack.offset.1436, ptr %local.offset.19, align 4
  store i32 %string.concat.extent.1339, ptr %local.extent.20, align 4
  store i32 %string.concat.payload.1338, ptr %local.payload.21, align 4
  store i32 12, ptr %local.type.22, align 4
  %local.is.active.1560 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1561 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1562 = select i1 %local.is.active.1560, i32 %local.sum.extent.1561, i32 0
  %stack.offset.1563 = add i32 0, %local.sum.selected.1562
  %local.is.active.1564 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1565 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1566 = select i1 %local.is.active.1564, i32 %local.sum.extent.1565, i32 0
  %stack.offset.1567 = add i32 %stack.offset.1563, %local.sum.selected.1566
  %local.is.active.1568 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1569 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1570 = select i1 %local.is.active.1568, i32 %local.sum.extent.1569, i32 0
  %stack.offset.1571 = add i32 %stack.offset.1567, %local.sum.selected.1570
  %local.is.active.1572 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1573 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1574 = select i1 %local.is.active.1572, i32 %local.sum.extent.1573, i32 0
  %stack.offset.1575 = add i32 %stack.offset.1571, %local.sum.selected.1574
  %local.is.active.1576 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1577 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1578 = select i1 %local.is.active.1576, i32 %local.sum.extent.1577, i32 0
  %stack.offset.1579 = add i32 %stack.offset.1575, %local.sum.selected.1578
  %local.is.active.1580 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1581 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1582 = select i1 %local.is.active.1580, i32 %local.sum.extent.1581, i32 0
  %stack.offset.1583 = add i32 %stack.offset.1579, %local.sum.selected.1582
  %local.is.active.1584 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1585 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1586 = select i1 %local.is.active.1584, i32 %local.sum.extent.1585, i32 0
  %stack.offset.1587 = add i32 %stack.offset.1583, %local.sum.selected.1586
  %local.is.active.1588 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1589 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1590 = select i1 %local.is.active.1588, i32 %local.sum.extent.1589, i32 0
  %stack.offset.1591 = add i32 %stack.offset.1587, %local.sum.selected.1590
  %local.is.active.1592 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1593 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1594 = select i1 %local.is.active.1592, i32 %local.sum.extent.1593, i32 0
  %stack.offset.1595 = add i32 %stack.offset.1591, %local.sum.selected.1594
  %local.is.active.1596 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1597 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1598 = select i1 %local.is.active.1596, i32 %local.sum.extent.1597, i32 0
  %stack.offset.1599 = add i32 %stack.offset.1595, %local.sum.selected.1598
  %local.is.active.1600 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1601 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1602 = select i1 %local.is.active.1600, i32 %local.sum.extent.1601, i32 0
  %stack.offset.1603 = add i32 %stack.offset.1599, %local.sum.selected.1602
  %local.is.active.1604 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1605 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1606 = select i1 %local.is.active.1604, i32 %local.sum.extent.1605, i32 0
  %stack.offset.1607 = add i32 %stack.offset.1603, %local.sum.selected.1606
  %stack.offset.1608 = add i32 %stack.offset.1607, 0
  %stack.offset.1609 = add i32 %context.value.75, %stack.offset.1608
  %cursor.status.1610 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1609)
  %cursor.ok.1611 = icmp eq i32 %cursor.status.1610, 0
  br i1 %cursor.ok.1611, label %cursor.continue.1612, label %frame.failure.0
cursor.continue.1612:
  %step.status.1613 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.1614 = icmp eq i32 %step.status.1613, 0
  br i1 %helper.ok.1614, label %helper.continue.1615, label %frame.failure.0
helper.continue.1615:
  %local.source.offset.1616 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.1617 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.1618 = load i32, ptr %local.payload.11, align 4
  %context.field.1619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1620 = load i32, ptr %context.field.1619, align 4
  %stack.offset.1621 = add i32 %context.value.1620, %local.source.extent.1617
  %reserve.status.1622 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1621, i32 36)
  %reserve.ok.1623 = icmp eq i32 %reserve.status.1622, 0
  br i1 %reserve.ok.1623, label %reserve.continue.1624, label %frame.failure.0
reserve.continue.1624:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1620, i32 %local.source.offset.1616, i32 %local.source.extent.1617, i32 %local.source.payload.1618, i32 8)
  %context.field.1625 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1626 = load i32, ptr %context.field.1625, align 4
  %runtime.ok.1627 = icmp eq i32 %context.value.1626, 0
  br i1 %runtime.ok.1627, label %runtime.continue.1628, label %frame.failure.0
runtime.continue.1628:
  %local.is.active.1629 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1630 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1631 = select i1 %local.is.active.1629, i32 %local.sum.extent.1630, i32 0
  %stack.offset.1632 = add i32 0, %local.sum.selected.1631
  %local.is.active.1633 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1634 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1635 = select i1 %local.is.active.1633, i32 %local.sum.extent.1634, i32 0
  %stack.offset.1636 = add i32 %stack.offset.1632, %local.sum.selected.1635
  %local.is.active.1637 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1638 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1639 = select i1 %local.is.active.1637, i32 %local.sum.extent.1638, i32 0
  %stack.offset.1640 = add i32 %stack.offset.1636, %local.sum.selected.1639
  %local.is.active.1641 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1642 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1643 = select i1 %local.is.active.1641, i32 %local.sum.extent.1642, i32 0
  %stack.offset.1644 = add i32 %stack.offset.1640, %local.sum.selected.1643
  %local.is.active.1645 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1646 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1647 = select i1 %local.is.active.1645, i32 %local.sum.extent.1646, i32 0
  %stack.offset.1648 = add i32 %stack.offset.1644, %local.sum.selected.1647
  %local.is.active.1649 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1650 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1651 = select i1 %local.is.active.1649, i32 %local.sum.extent.1650, i32 0
  %stack.offset.1652 = add i32 %stack.offset.1648, %local.sum.selected.1651
  %local.is.active.1653 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1654 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1655 = select i1 %local.is.active.1653, i32 %local.sum.extent.1654, i32 0
  %stack.offset.1656 = add i32 %stack.offset.1652, %local.sum.selected.1655
  %local.is.active.1657 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1658 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1659 = select i1 %local.is.active.1657, i32 %local.sum.extent.1658, i32 0
  %stack.offset.1660 = add i32 %stack.offset.1656, %local.sum.selected.1659
  %local.is.active.1661 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1662 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1663 = select i1 %local.is.active.1661, i32 %local.sum.extent.1662, i32 0
  %stack.offset.1664 = add i32 %stack.offset.1660, %local.sum.selected.1663
  %local.is.active.1665 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1666 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1667 = select i1 %local.is.active.1665, i32 %local.sum.extent.1666, i32 0
  %stack.offset.1668 = add i32 %stack.offset.1664, %local.sum.selected.1667
  %local.is.active.1669 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1670 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1671 = select i1 %local.is.active.1669, i32 %local.sum.extent.1670, i32 0
  %stack.offset.1672 = add i32 %stack.offset.1668, %local.sum.selected.1671
  %local.is.active.1673 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1674 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1675 = select i1 %local.is.active.1673, i32 %local.sum.extent.1674, i32 0
  %stack.offset.1676 = add i32 %stack.offset.1672, %local.sum.selected.1675
  %stack.offset.1677 = add i32 0, %local.source.extent.1617
  %stack.offset.1678 = add i32 %stack.offset.1676, %stack.offset.1677
  %stack.offset.1679 = add i32 %context.value.75, %stack.offset.1678
  %cursor.status.1680 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1679)
  %cursor.ok.1681 = icmp eq i32 %cursor.status.1680, 0
  br i1 %cursor.ok.1681, label %cursor.continue.1682, label %frame.failure.0
cursor.continue.1682:
  %step.status.1683 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %helper.ok.1684 = icmp eq i32 %step.status.1683, 0
  br i1 %helper.ok.1684, label %helper.continue.1685, label %frame.failure.0
helper.continue.1685:
  %local.is.active.1686 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1687 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1688 = select i1 %local.is.active.1686, i32 %local.sum.extent.1687, i32 0
  %stack.offset.1689 = add i32 0, %local.sum.selected.1688
  %local.is.active.1690 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1691 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1692 = select i1 %local.is.active.1690, i32 %local.sum.extent.1691, i32 0
  %stack.offset.1693 = add i32 %stack.offset.1689, %local.sum.selected.1692
  %local.is.active.1694 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1695 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1696 = select i1 %local.is.active.1694, i32 %local.sum.extent.1695, i32 0
  %stack.offset.1697 = add i32 %stack.offset.1693, %local.sum.selected.1696
  %local.is.active.1698 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1699 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1700 = select i1 %local.is.active.1698, i32 %local.sum.extent.1699, i32 0
  %stack.offset.1701 = add i32 %stack.offset.1697, %local.sum.selected.1700
  %local.is.active.1702 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1703 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1704 = select i1 %local.is.active.1702, i32 %local.sum.extent.1703, i32 0
  %stack.offset.1705 = add i32 %stack.offset.1701, %local.sum.selected.1704
  %local.is.active.1706 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1707 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1708 = select i1 %local.is.active.1706, i32 %local.sum.extent.1707, i32 0
  %stack.offset.1709 = add i32 %stack.offset.1705, %local.sum.selected.1708
  %local.is.active.1710 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1711 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1712 = select i1 %local.is.active.1710, i32 %local.sum.extent.1711, i32 0
  %stack.offset.1713 = add i32 %stack.offset.1709, %local.sum.selected.1712
  %local.is.active.1714 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1715 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1716 = select i1 %local.is.active.1714, i32 %local.sum.extent.1715, i32 0
  %stack.offset.1717 = add i32 %stack.offset.1713, %local.sum.selected.1716
  %local.is.active.1718 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1719 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1720 = select i1 %local.is.active.1718, i32 %local.sum.extent.1719, i32 0
  %stack.offset.1721 = add i32 %stack.offset.1717, %local.sum.selected.1720
  %local.is.active.1722 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1723 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1724 = select i1 %local.is.active.1722, i32 %local.sum.extent.1723, i32 0
  %stack.offset.1725 = add i32 %stack.offset.1721, %local.sum.selected.1724
  %local.is.active.1726 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1727 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1728 = select i1 %local.is.active.1726, i32 %local.sum.extent.1727, i32 0
  %stack.offset.1729 = add i32 %stack.offset.1725, %local.sum.selected.1728
  %local.is.active.1730 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1731 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1732 = select i1 %local.is.active.1730, i32 %local.sum.extent.1731, i32 0
  %stack.offset.1733 = add i32 %stack.offset.1729, %local.sum.selected.1732
  %stack.offset.1734 = add i32 %stack.offset.1733, 0
  %stack.offset.1735 = add i32 %context.value.75, %stack.offset.1734
  %field.location.1736 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.1737 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.1735, i32 %local.source.extent.1617, i32 0, i32 38, ptr %field.location.1736)
  %helper.ok.1738 = icmp eq i32 %field.location.status.1737, 0
  br i1 %helper.ok.1738, label %helper.continue.1739, label %frame.failure.0
helper.continue.1739:
  %field.offset.pointer.1740 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1736, i32 0, i32 0
  %field.offset.1741 = load i32, ptr %field.offset.pointer.1740, align 4
  %field.payload.pointer.1742 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1736, i32 0, i32 1
  %field.payload.1743 = load i32, ptr %field.payload.pointer.1742, align 4
  %field.extent.pointer.1744 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1736, i32 0, i32 2
  %field.extent.1745 = load i32, ptr %field.extent.pointer.1744, align 4
  %stack.offset.1746 = add i32 %stack.offset.1735, %field.extent.1745
  %context.field.1747 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1748 = load i32, ptr %context.field.1747, align 4
  %field.result.grows.1749 = icmp ugt i32 %stack.offset.1746, %context.value.1748
  br i1 %field.result.grows.1749, label %field.result.reserve.1750, label %field.result.existing.1751
field.result.reserve.1750:
  %reserve.status.1753 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1746, i32 39)
  %reserve.ok.1754 = icmp eq i32 %reserve.status.1753, 0
  br i1 %reserve.ok.1754, label %reserve.continue.1755, label %frame.failure.0
reserve.continue.1755:
  br label %field.result.ready.1752
field.result.existing.1751:
  br label %field.result.ready.1752
field.result.ready.1752:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1735, i32 %field.offset.1741, i32 %field.extent.1745, i32 %field.payload.1743, i32 9, i32 7)
  %context.field.1756 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1757 = load i32, ptr %context.field.1756, align 4
  %runtime.ok.1758 = icmp eq i32 %context.value.1757, 0
  br i1 %runtime.ok.1758, label %runtime.continue.1759, label %frame.failure.0
runtime.continue.1759:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1746, i32 0, i32 0, i32 0)
  %context.field.1760 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1761 = load i32, ptr %context.field.1760, align 4
  %runtime.ok.1762 = icmp eq i32 %context.value.1761, 0
  br i1 %runtime.ok.1762, label %runtime.continue.1763, label %frame.failure.0
runtime.continue.1763:
  %stack.sub.1764 = sub i32 %field.payload.1743, %local.source.payload.1618
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1764, i32 0)
  %context.field.1765 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1766 = load i32, ptr %context.field.1765, align 4
  %runtime.ok.1767 = icmp eq i32 %context.value.1766, 0
  br i1 %runtime.ok.1767, label %runtime.continue.1768, label %frame.failure.0
runtime.continue.1768:
  %local.is.active.1769 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1770 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1771 = select i1 %local.is.active.1769, i32 %local.sum.extent.1770, i32 0
  %stack.offset.1772 = add i32 0, %local.sum.selected.1771
  %local.is.active.1773 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1774 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1775 = select i1 %local.is.active.1773, i32 %local.sum.extent.1774, i32 0
  %stack.offset.1776 = add i32 %stack.offset.1772, %local.sum.selected.1775
  %local.is.active.1777 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1778 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1779 = select i1 %local.is.active.1777, i32 %local.sum.extent.1778, i32 0
  %stack.offset.1780 = add i32 %stack.offset.1776, %local.sum.selected.1779
  %local.is.active.1781 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1782 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1783 = select i1 %local.is.active.1781, i32 %local.sum.extent.1782, i32 0
  %stack.offset.1784 = add i32 %stack.offset.1780, %local.sum.selected.1783
  %local.is.active.1785 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1786 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1787 = select i1 %local.is.active.1785, i32 %local.sum.extent.1786, i32 0
  %stack.offset.1788 = add i32 %stack.offset.1784, %local.sum.selected.1787
  %local.is.active.1789 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1790 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1791 = select i1 %local.is.active.1789, i32 %local.sum.extent.1790, i32 0
  %stack.offset.1792 = add i32 %stack.offset.1788, %local.sum.selected.1791
  %local.is.active.1793 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1794 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1795 = select i1 %local.is.active.1793, i32 %local.sum.extent.1794, i32 0
  %stack.offset.1796 = add i32 %stack.offset.1792, %local.sum.selected.1795
  %local.is.active.1797 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1798 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1799 = select i1 %local.is.active.1797, i32 %local.sum.extent.1798, i32 0
  %stack.offset.1800 = add i32 %stack.offset.1796, %local.sum.selected.1799
  %local.is.active.1801 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1802 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1803 = select i1 %local.is.active.1801, i32 %local.sum.extent.1802, i32 0
  %stack.offset.1804 = add i32 %stack.offset.1800, %local.sum.selected.1803
  %local.is.active.1805 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1806 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1807 = select i1 %local.is.active.1805, i32 %local.sum.extent.1806, i32 0
  %stack.offset.1808 = add i32 %stack.offset.1804, %local.sum.selected.1807
  %local.is.active.1809 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1810 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1811 = select i1 %local.is.active.1809, i32 %local.sum.extent.1810, i32 0
  %stack.offset.1812 = add i32 %stack.offset.1808, %local.sum.selected.1811
  %local.is.active.1813 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1814 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1815 = select i1 %local.is.active.1813, i32 %local.sum.extent.1814, i32 0
  %stack.offset.1816 = add i32 %stack.offset.1812, %local.sum.selected.1815
  %stack.offset.1817 = add i32 0, %field.extent.1745
  %stack.offset.1818 = add i32 %stack.offset.1816, %stack.offset.1817
  %stack.offset.1819 = add i32 %context.value.75, %stack.offset.1818
  %cursor.status.1820 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1819)
  %cursor.ok.1821 = icmp eq i32 %cursor.status.1820, 0
  br i1 %cursor.ok.1821, label %cursor.continue.1822, label %frame.failure.0
cursor.continue.1822:
  %step.status.1823 = call i32 @al_owning_charge_step(ptr %ctx, i32 40)
  %helper.ok.1824 = icmp eq i32 %step.status.1823, 0
  br i1 %helper.ok.1824, label %helper.continue.1825, label %frame.failure.0
helper.continue.1825:
  %local.is.active.1826 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1827 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1828 = select i1 %local.is.active.1826, i32 %local.sum.extent.1827, i32 0
  %stack.offset.1829 = add i32 0, %local.sum.selected.1828
  %local.is.active.1830 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1831 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1832 = select i1 %local.is.active.1830, i32 %local.sum.extent.1831, i32 0
  %stack.offset.1833 = add i32 %stack.offset.1829, %local.sum.selected.1832
  %local.is.active.1834 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1835 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1836 = select i1 %local.is.active.1834, i32 %local.sum.extent.1835, i32 0
  %stack.offset.1837 = add i32 %stack.offset.1833, %local.sum.selected.1836
  %local.is.active.1838 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1839 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1840 = select i1 %local.is.active.1838, i32 %local.sum.extent.1839, i32 0
  %stack.offset.1841 = add i32 %stack.offset.1837, %local.sum.selected.1840
  %local.is.active.1842 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1843 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1844 = select i1 %local.is.active.1842, i32 %local.sum.extent.1843, i32 0
  %stack.offset.1845 = add i32 %stack.offset.1841, %local.sum.selected.1844
  %local.is.active.1846 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1847 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1848 = select i1 %local.is.active.1846, i32 %local.sum.extent.1847, i32 0
  %stack.offset.1849 = add i32 %stack.offset.1845, %local.sum.selected.1848
  %local.is.active.1850 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1851 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1852 = select i1 %local.is.active.1850, i32 %local.sum.extent.1851, i32 0
  %stack.offset.1853 = add i32 %stack.offset.1849, %local.sum.selected.1852
  %local.is.active.1854 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1855 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1856 = select i1 %local.is.active.1854, i32 %local.sum.extent.1855, i32 0
  %stack.offset.1857 = add i32 %stack.offset.1853, %local.sum.selected.1856
  %local.is.active.1858 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1859 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1860 = select i1 %local.is.active.1858, i32 %local.sum.extent.1859, i32 0
  %stack.offset.1861 = add i32 %stack.offset.1857, %local.sum.selected.1860
  %local.is.active.1862 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1863 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1864 = select i1 %local.is.active.1862, i32 %local.sum.extent.1863, i32 0
  %stack.offset.1865 = add i32 %stack.offset.1861, %local.sum.selected.1864
  %local.is.active.1866 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1867 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1868 = select i1 %local.is.active.1866, i32 %local.sum.extent.1867, i32 0
  %stack.offset.1869 = add i32 %stack.offset.1865, %local.sum.selected.1868
  %local.is.active.1870 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1871 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1872 = select i1 %local.is.active.1870, i32 %local.sum.extent.1871, i32 0
  %stack.offset.1873 = add i32 %stack.offset.1869, %local.sum.selected.1872
  %stack.offset.1874 = add i32 %stack.offset.1873, 0
  %stack.offset.1875 = add i32 %context.value.75, %stack.offset.1874
  %field.location.1876 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.1877 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.1875, i32 %field.extent.1745, i32 0, i32 41, ptr %field.location.1876)
  %helper.ok.1878 = icmp eq i32 %field.location.status.1877, 0
  br i1 %helper.ok.1878, label %helper.continue.1879, label %frame.failure.0
helper.continue.1879:
  %field.offset.pointer.1880 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1876, i32 0, i32 0
  %field.offset.1881 = load i32, ptr %field.offset.pointer.1880, align 4
  %field.payload.pointer.1882 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1876, i32 0, i32 1
  %field.payload.1883 = load i32, ptr %field.payload.pointer.1882, align 4
  %field.extent.pointer.1884 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1876, i32 0, i32 2
  %field.extent.1885 = load i32, ptr %field.extent.pointer.1884, align 4
  %stack.offset.1886 = add i32 %stack.offset.1875, %field.extent.1885
  %context.field.1887 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1888 = load i32, ptr %context.field.1887, align 4
  %field.result.grows.1889 = icmp ugt i32 %stack.offset.1886, %context.value.1888
  br i1 %field.result.grows.1889, label %field.result.reserve.1890, label %field.result.existing.1891
field.result.reserve.1890:
  %reserve.status.1893 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1886, i32 42)
  %reserve.ok.1894 = icmp eq i32 %reserve.status.1893, 0
  br i1 %reserve.ok.1894, label %reserve.continue.1895, label %frame.failure.0
reserve.continue.1895:
  br label %field.result.ready.1892
field.result.existing.1891:
  br label %field.result.ready.1892
field.result.ready.1892:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1875, i32 %field.offset.1881, i32 %field.extent.1885, i32 %field.payload.1883, i32 12, i32 7)
  %context.field.1896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1897 = load i32, ptr %context.field.1896, align 4
  %runtime.ok.1898 = icmp eq i32 %context.value.1897, 0
  br i1 %runtime.ok.1898, label %runtime.continue.1899, label %frame.failure.0
runtime.continue.1899:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1886, i32 0, i32 0, i32 0)
  %context.field.1900 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1901 = load i32, ptr %context.field.1900, align 4
  %runtime.ok.1902 = icmp eq i32 %context.value.1901, 0
  br i1 %runtime.ok.1902, label %runtime.continue.1903, label %frame.failure.0
runtime.continue.1903:
  %stack.sub.1904 = sub i32 %field.payload.1883, %field.payload.1743
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1904, i32 0)
  %context.field.1905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1906 = load i32, ptr %context.field.1905, align 4
  %runtime.ok.1907 = icmp eq i32 %context.value.1906, 0
  br i1 %runtime.ok.1907, label %runtime.continue.1908, label %frame.failure.0
runtime.continue.1908:
  %local.is.active.1909 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1910 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1911 = select i1 %local.is.active.1909, i32 %local.sum.extent.1910, i32 0
  %stack.offset.1912 = add i32 0, %local.sum.selected.1911
  %local.is.active.1913 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1914 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1915 = select i1 %local.is.active.1913, i32 %local.sum.extent.1914, i32 0
  %stack.offset.1916 = add i32 %stack.offset.1912, %local.sum.selected.1915
  %local.is.active.1917 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1918 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1919 = select i1 %local.is.active.1917, i32 %local.sum.extent.1918, i32 0
  %stack.offset.1920 = add i32 %stack.offset.1916, %local.sum.selected.1919
  %local.is.active.1921 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1922 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1923 = select i1 %local.is.active.1921, i32 %local.sum.extent.1922, i32 0
  %stack.offset.1924 = add i32 %stack.offset.1920, %local.sum.selected.1923
  %local.is.active.1925 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1926 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1927 = select i1 %local.is.active.1925, i32 %local.sum.extent.1926, i32 0
  %stack.offset.1928 = add i32 %stack.offset.1924, %local.sum.selected.1927
  %local.is.active.1929 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1930 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1931 = select i1 %local.is.active.1929, i32 %local.sum.extent.1930, i32 0
  %stack.offset.1932 = add i32 %stack.offset.1928, %local.sum.selected.1931
  %local.is.active.1933 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.1934 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.1935 = select i1 %local.is.active.1933, i32 %local.sum.extent.1934, i32 0
  %stack.offset.1936 = add i32 %stack.offset.1932, %local.sum.selected.1935
  %local.is.active.1937 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.1938 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.1939 = select i1 %local.is.active.1937, i32 %local.sum.extent.1938, i32 0
  %stack.offset.1940 = add i32 %stack.offset.1936, %local.sum.selected.1939
  %local.is.active.1941 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.1942 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.1943 = select i1 %local.is.active.1941, i32 %local.sum.extent.1942, i32 0
  %stack.offset.1944 = add i32 %stack.offset.1940, %local.sum.selected.1943
  %local.is.active.1945 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.1946 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.1947 = select i1 %local.is.active.1945, i32 %local.sum.extent.1946, i32 0
  %stack.offset.1948 = add i32 %stack.offset.1944, %local.sum.selected.1947
  %local.is.active.1949 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.1950 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.1951 = select i1 %local.is.active.1949, i32 %local.sum.extent.1950, i32 0
  %stack.offset.1952 = add i32 %stack.offset.1948, %local.sum.selected.1951
  %local.is.active.1953 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.1954 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.1955 = select i1 %local.is.active.1953, i32 %local.sum.extent.1954, i32 0
  %stack.offset.1956 = add i32 %stack.offset.1952, %local.sum.selected.1955
  %stack.offset.1957 = add i32 0, %field.extent.1885
  %stack.offset.1958 = add i32 %stack.offset.1956, %stack.offset.1957
  %stack.offset.1959 = add i32 %context.value.75, %stack.offset.1958
  %cursor.status.1960 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1959)
  %cursor.ok.1961 = icmp eq i32 %cursor.status.1960, 0
  br i1 %cursor.ok.1961, label %cursor.continue.1962, label %frame.failure.0
cursor.continue.1962:
  %step.status.1963 = call i32 @al_owning_charge_step(ptr %ctx, i32 43)
  %helper.ok.1964 = icmp eq i32 %step.status.1963, 0
  br i1 %helper.ok.1964, label %helper.continue.1965, label %frame.failure.0
helper.continue.1965:
  %context.field.1966 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1967 = load i32, ptr %context.field.1966, align 4
  %stack.offset.1968 = add i32 %context.value.1967, 16
  %reserve.status.1969 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1968, i32 44)
  %reserve.ok.1970 = icmp eq i32 %reserve.status.1969, 0
  br i1 %reserve.ok.1970, label %reserve.continue.1971, label %frame.failure.0
reserve.continue.1971:
  %literal.status.1972 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.1967, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_1, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 45)
  %helper.ok.1973 = icmp eq i32 %literal.status.1972, 0
  br i1 %helper.ok.1973, label %helper.continue.1974, label %frame.failure.0
helper.continue.1974:
  %local.is.active.1975 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1976 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1977 = select i1 %local.is.active.1975, i32 %local.sum.extent.1976, i32 0
  %stack.offset.1978 = add i32 0, %local.sum.selected.1977
  %local.is.active.1979 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1980 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1981 = select i1 %local.is.active.1979, i32 %local.sum.extent.1980, i32 0
  %stack.offset.1982 = add i32 %stack.offset.1978, %local.sum.selected.1981
  %local.is.active.1983 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1984 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1985 = select i1 %local.is.active.1983, i32 %local.sum.extent.1984, i32 0
  %stack.offset.1986 = add i32 %stack.offset.1982, %local.sum.selected.1985
  %local.is.active.1987 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1988 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1989 = select i1 %local.is.active.1987, i32 %local.sum.extent.1988, i32 0
  %stack.offset.1990 = add i32 %stack.offset.1986, %local.sum.selected.1989
  %local.is.active.1991 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1992 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1993 = select i1 %local.is.active.1991, i32 %local.sum.extent.1992, i32 0
  %stack.offset.1994 = add i32 %stack.offset.1990, %local.sum.selected.1993
  %local.is.active.1995 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1996 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1997 = select i1 %local.is.active.1995, i32 %local.sum.extent.1996, i32 0
  %stack.offset.1998 = add i32 %stack.offset.1994, %local.sum.selected.1997
  %local.is.active.1999 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2000 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2001 = select i1 %local.is.active.1999, i32 %local.sum.extent.2000, i32 0
  %stack.offset.2002 = add i32 %stack.offset.1998, %local.sum.selected.2001
  %local.is.active.2003 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2004 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2005 = select i1 %local.is.active.2003, i32 %local.sum.extent.2004, i32 0
  %stack.offset.2006 = add i32 %stack.offset.2002, %local.sum.selected.2005
  %local.is.active.2007 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2008 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2009 = select i1 %local.is.active.2007, i32 %local.sum.extent.2008, i32 0
  %stack.offset.2010 = add i32 %stack.offset.2006, %local.sum.selected.2009
  %local.is.active.2011 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2012 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2013 = select i1 %local.is.active.2011, i32 %local.sum.extent.2012, i32 0
  %stack.offset.2014 = add i32 %stack.offset.2010, %local.sum.selected.2013
  %local.is.active.2015 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2016 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2017 = select i1 %local.is.active.2015, i32 %local.sum.extent.2016, i32 0
  %stack.offset.2018 = add i32 %stack.offset.2014, %local.sum.selected.2017
  %local.is.active.2019 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2020 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2021 = select i1 %local.is.active.2019, i32 %local.sum.extent.2020, i32 0
  %stack.offset.2022 = add i32 %stack.offset.2018, %local.sum.selected.2021
  %stack.offset.2023 = add i32 0, %field.extent.1885
  %stack.offset.2024 = add i32 %stack.offset.2023, 16
  %stack.offset.2025 = add i32 %stack.offset.2022, %stack.offset.2024
  %stack.offset.2026 = add i32 %context.value.75, %stack.offset.2025
  %cursor.status.2027 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2026)
  %cursor.ok.2028 = icmp eq i32 %cursor.status.2027, 0
  br i1 %cursor.ok.2028, label %cursor.continue.2029, label %frame.failure.0
cursor.continue.2029:
  %step.status.2030 = call i32 @al_owning_charge_step(ptr %ctx, i32 46)
  %helper.ok.2031 = icmp eq i32 %step.status.2030, 0
  br i1 %helper.ok.2031, label %helper.continue.2032, label %frame.failure.0
helper.continue.2032:
  %context.field.2033 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2034 = load i32, ptr %context.field.2033, align 4
  %local.is.active.2035 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2036 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2037 = select i1 %local.is.active.2035, i32 %local.sum.extent.2036, i32 0
  %stack.offset.2038 = add i32 0, %local.sum.selected.2037
  %local.is.active.2039 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2040 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2041 = select i1 %local.is.active.2039, i32 %local.sum.extent.2040, i32 0
  %stack.offset.2042 = add i32 %stack.offset.2038, %local.sum.selected.2041
  %local.is.active.2043 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2044 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2045 = select i1 %local.is.active.2043, i32 %local.sum.extent.2044, i32 0
  %stack.offset.2046 = add i32 %stack.offset.2042, %local.sum.selected.2045
  %local.is.active.2047 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2048 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2049 = select i1 %local.is.active.2047, i32 %local.sum.extent.2048, i32 0
  %stack.offset.2050 = add i32 %stack.offset.2046, %local.sum.selected.2049
  %local.is.active.2051 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2052 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2053 = select i1 %local.is.active.2051, i32 %local.sum.extent.2052, i32 0
  %stack.offset.2054 = add i32 %stack.offset.2050, %local.sum.selected.2053
  %local.is.active.2055 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2056 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2057 = select i1 %local.is.active.2055, i32 %local.sum.extent.2056, i32 0
  %stack.offset.2058 = add i32 %stack.offset.2054, %local.sum.selected.2057
  %local.is.active.2059 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2060 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2061 = select i1 %local.is.active.2059, i32 %local.sum.extent.2060, i32 0
  %stack.offset.2062 = add i32 %stack.offset.2058, %local.sum.selected.2061
  %local.is.active.2063 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2064 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2065 = select i1 %local.is.active.2063, i32 %local.sum.extent.2064, i32 0
  %stack.offset.2066 = add i32 %stack.offset.2062, %local.sum.selected.2065
  %local.is.active.2067 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2068 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2069 = select i1 %local.is.active.2067, i32 %local.sum.extent.2068, i32 0
  %stack.offset.2070 = add i32 %stack.offset.2066, %local.sum.selected.2069
  %local.is.active.2071 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2072 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2073 = select i1 %local.is.active.2071, i32 %local.sum.extent.2072, i32 0
  %stack.offset.2074 = add i32 %stack.offset.2070, %local.sum.selected.2073
  %local.is.active.2075 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2076 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2077 = select i1 %local.is.active.2075, i32 %local.sum.extent.2076, i32 0
  %stack.offset.2078 = add i32 %stack.offset.2074, %local.sum.selected.2077
  %local.is.active.2079 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2080 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2081 = select i1 %local.is.active.2079, i32 %local.sum.extent.2080, i32 0
  %stack.offset.2082 = add i32 %stack.offset.2078, %local.sum.selected.2081
  %stack.offset.2083 = add i32 %stack.offset.2082, 0
  %stack.offset.2084 = add i32 %context.value.75, %stack.offset.2083
  %stack.sub.2085 = sub i32 %context.value.2034, 16
  %string.concat.units.2086 = alloca i32, align 4
  %string.concat.payload.pointer.2087 = alloca i32, align 4
  %string.concat.extent.pointer.2088 = alloca i32, align 4
  %string.concat.plan.status.2089 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.2084, i32 %field.extent.1885, i32 %stack.sub.2085, i32 16, i32 47, ptr %string.concat.units.2086, ptr %string.concat.payload.pointer.2087, ptr %string.concat.extent.pointer.2088)
  %helper.ok.2090 = icmp eq i32 %string.concat.plan.status.2089, 0
  br i1 %helper.ok.2090, label %helper.continue.2091, label %frame.failure.0
helper.continue.2091:
  %string.concat.payload.2092 = load i32, ptr %string.concat.payload.pointer.2087, align 4
  %string.concat.extent.2093 = load i32, ptr %string.concat.extent.pointer.2088, align 4
  %stack.offset.2094 = add i32 %context.value.2034, %string.concat.extent.2093
  %reserve.status.2095 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2094, i32 48)
  %reserve.ok.2096 = icmp eq i32 %reserve.status.2095, 0
  br i1 %reserve.ok.2096, label %reserve.continue.2097, label %frame.failure.0
reserve.continue.2097:
  %string.concat.write.status.2098 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.2034, i32 %string.concat.extent.2093, i32 %stack.offset.2084, i32 %field.extent.1885, i32 %stack.sub.2085, i32 16, i32 12, i32 47)
  %helper.ok.2099 = icmp eq i32 %string.concat.write.status.2098, 0
  br i1 %helper.ok.2099, label %helper.continue.2100, label %frame.failure.0
helper.continue.2100:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2084, i32 %context.value.2034, i32 %string.concat.extent.2093, i32 %string.concat.payload.2092, i32 12, i32 0)
  %context.field.2101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2102 = load i32, ptr %context.field.2101, align 4
  %runtime.ok.2103 = icmp eq i32 %context.value.2102, 0
  br i1 %runtime.ok.2103, label %runtime.continue.2104, label %frame.failure.0
runtime.continue.2104:
  %stack.offset.2105 = add i32 %stack.offset.2084, %string.concat.extent.2093
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.2105, i32 0, i32 0, i32 0)
  %context.field.2106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2107 = load i32, ptr %context.field.2106, align 4
  %runtime.ok.2108 = icmp eq i32 %context.value.2107, 0
  br i1 %runtime.ok.2108, label %runtime.continue.2109, label %frame.failure.0
runtime.continue.2109:
  %stack.offset.2110 = add i32 %field.payload.1883, 10
  %stack.sub.2111 = sub i32 %string.concat.payload.2092, %stack.offset.2110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2111, i32 0)
  %context.field.2112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2113 = load i32, ptr %context.field.2112, align 4
  %runtime.ok.2114 = icmp eq i32 %context.value.2113, 0
  br i1 %runtime.ok.2114, label %runtime.continue.2115, label %frame.failure.0
runtime.continue.2115:
  %local.is.active.2116 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2117 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2118 = select i1 %local.is.active.2116, i32 %local.sum.extent.2117, i32 0
  %stack.offset.2119 = add i32 0, %local.sum.selected.2118
  %local.is.active.2120 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2121 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2122 = select i1 %local.is.active.2120, i32 %local.sum.extent.2121, i32 0
  %stack.offset.2123 = add i32 %stack.offset.2119, %local.sum.selected.2122
  %local.is.active.2124 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2125 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2126 = select i1 %local.is.active.2124, i32 %local.sum.extent.2125, i32 0
  %stack.offset.2127 = add i32 %stack.offset.2123, %local.sum.selected.2126
  %local.is.active.2128 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2129 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2130 = select i1 %local.is.active.2128, i32 %local.sum.extent.2129, i32 0
  %stack.offset.2131 = add i32 %stack.offset.2127, %local.sum.selected.2130
  %local.is.active.2132 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2133 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2134 = select i1 %local.is.active.2132, i32 %local.sum.extent.2133, i32 0
  %stack.offset.2135 = add i32 %stack.offset.2131, %local.sum.selected.2134
  %local.is.active.2136 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2137 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2138 = select i1 %local.is.active.2136, i32 %local.sum.extent.2137, i32 0
  %stack.offset.2139 = add i32 %stack.offset.2135, %local.sum.selected.2138
  %local.is.active.2140 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2141 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2142 = select i1 %local.is.active.2140, i32 %local.sum.extent.2141, i32 0
  %stack.offset.2143 = add i32 %stack.offset.2139, %local.sum.selected.2142
  %local.is.active.2144 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2145 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2146 = select i1 %local.is.active.2144, i32 %local.sum.extent.2145, i32 0
  %stack.offset.2147 = add i32 %stack.offset.2143, %local.sum.selected.2146
  %local.is.active.2148 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2149 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2150 = select i1 %local.is.active.2148, i32 %local.sum.extent.2149, i32 0
  %stack.offset.2151 = add i32 %stack.offset.2147, %local.sum.selected.2150
  %local.is.active.2152 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2153 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2154 = select i1 %local.is.active.2152, i32 %local.sum.extent.2153, i32 0
  %stack.offset.2155 = add i32 %stack.offset.2151, %local.sum.selected.2154
  %local.is.active.2156 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2157 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2158 = select i1 %local.is.active.2156, i32 %local.sum.extent.2157, i32 0
  %stack.offset.2159 = add i32 %stack.offset.2155, %local.sum.selected.2158
  %local.is.active.2160 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2161 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2162 = select i1 %local.is.active.2160, i32 %local.sum.extent.2161, i32 0
  %stack.offset.2163 = add i32 %stack.offset.2159, %local.sum.selected.2162
  %stack.offset.2164 = add i32 0, %string.concat.extent.2093
  %stack.offset.2165 = add i32 %stack.offset.2163, %stack.offset.2164
  %stack.offset.2166 = add i32 %context.value.75, %stack.offset.2165
  %cursor.status.2167 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2166)
  %cursor.ok.2168 = icmp eq i32 %cursor.status.2167, 0
  br i1 %cursor.ok.2168, label %cursor.continue.2169, label %frame.failure.0
cursor.continue.2169:
  %step.status.2170 = call i32 @al_owning_charge_step(ptr %ctx, i32 49)
  %helper.ok.2171 = icmp eq i32 %step.status.2170, 0
  br i1 %helper.ok.2171, label %helper.continue.2172, label %frame.failure.0
helper.continue.2172:
  %local.is.active.2173 = load i1, ptr %local.active.23, align 1
  %local.previous.extent.2174 = load i32, ptr %local.extent.25, align 4
  %local.previous.payload.2175 = load i32, ptr %local.payload.26, align 4
  %local.old.extent.2176 = select i1 %local.is.active.2173, i32 %local.previous.extent.2174, i32 0
  %local.old.payload.2177 = select i1 %local.is.active.2173, i32 %local.previous.payload.2175, i32 0
  %local.is.active.2178 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2179 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2180 = select i1 %local.is.active.2178, i32 %local.sum.extent.2179, i32 0
  %stack.offset.2181 = add i32 0, %local.sum.selected.2180
  %local.is.active.2182 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2183 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2184 = select i1 %local.is.active.2182, i32 %local.sum.extent.2183, i32 0
  %stack.offset.2185 = add i32 %stack.offset.2181, %local.sum.selected.2184
  %local.is.active.2186 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2187 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2188 = select i1 %local.is.active.2186, i32 %local.sum.extent.2187, i32 0
  %stack.offset.2189 = add i32 %stack.offset.2185, %local.sum.selected.2188
  %local.is.active.2190 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2191 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2192 = select i1 %local.is.active.2190, i32 %local.sum.extent.2191, i32 0
  %stack.offset.2193 = add i32 %stack.offset.2189, %local.sum.selected.2192
  %stack.offset.2194 = add i32 %context.value.75, %stack.offset.2193
  %stack.offset.2195 = add i32 %stack.offset.2194, %local.old.extent.2176
  %context.field.2196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2197 = load i32, ptr %context.field.2196, align 4
  %stack.sub.2198 = sub i32 %context.value.2197, %stack.offset.2195
  %stack.sub.2199 = sub i32 %context.value.2197, %local.old.extent.2176
  %stack.offset.2200 = add i32 %stack.sub.2199, %string.concat.extent.2093
  %local.grows.2201 = icmp ugt i32 %string.concat.extent.2093, %local.old.extent.2176
  br i1 %local.grows.2201, label %local.grow.2202, label %local.fixed.2203
local.grow.2202:
  %reserve.status.2205 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2200, i32 50)
  %reserve.ok.2206 = icmp eq i32 %reserve.status.2205, 0
  br i1 %reserve.ok.2206, label %reserve.continue.2207, label %frame.failure.0
reserve.continue.2207:
  %stack.sub.2208 = sub i32 %string.concat.extent.2093, %local.old.extent.2176
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.2208)
  %context.field.2209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2210 = load i32, ptr %context.field.2209, align 4
  %runtime.ok.2211 = icmp eq i32 %context.value.2210, 0
  br i1 %runtime.ok.2211, label %runtime.continue.2212, label %frame.failure.0
runtime.continue.2212:
  br label %local.layout.ready.2204
local.fixed.2203:
  br label %local.layout.ready.2204
local.layout.ready.2204:
  %stack.offset.2213 = add i32 %stack.offset.2194, %string.concat.extent.2093
  %local.is.active.2214 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.2215 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.2216 = select i1 %local.is.active.2214, i32 %local.suffix.payload.2215, i32 0
  %stack.offset.2217 = add i32 0, %local.suffix.selected.2216
  %local.is.active.2218 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.2219 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.2220 = select i1 %local.is.active.2218, i32 %local.suffix.payload.2219, i32 0
  %stack.offset.2221 = add i32 %stack.offset.2217, %local.suffix.selected.2220
  %local.is.active.2222 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.2223 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.2224 = select i1 %local.is.active.2222, i32 %local.suffix.payload.2223, i32 0
  %stack.offset.2225 = add i32 %stack.offset.2221, %local.suffix.selected.2224
  %local.is.active.2226 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.2227 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.2228 = select i1 %local.is.active.2226, i32 %local.suffix.payload.2227, i32 0
  %stack.offset.2229 = add i32 %stack.offset.2225, %local.suffix.selected.2228
  %local.is.active.2230 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.2231 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.2232 = select i1 %local.is.active.2230, i32 %local.suffix.payload.2231, i32 0
  %stack.offset.2233 = add i32 %stack.offset.2229, %local.suffix.selected.2232
  %local.is.active.2234 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.2235 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.2236 = select i1 %local.is.active.2234, i32 %local.suffix.payload.2235, i32 0
  %stack.offset.2237 = add i32 %stack.offset.2233, %local.suffix.selected.2236
  %local.is.active.2238 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.2239 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.2240 = select i1 %local.is.active.2238, i32 %local.suffix.payload.2239, i32 0
  %stack.offset.2241 = add i32 %stack.offset.2237, %local.suffix.selected.2240
  %stack.offset.2242 = add i32 0, %string.concat.payload.2092
  %stack.offset.2243 = add i32 %stack.offset.2241, %stack.offset.2242
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2213, i32 %stack.offset.2195, i32 %stack.sub.2198, i32 %stack.offset.2243, i32 0, i32 14)
  %context.field.2244 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2245 = load i32, ptr %context.field.2244, align 4
  %runtime.ok.2246 = icmp eq i32 %context.value.2245, 0
  br i1 %runtime.ok.2246, label %runtime.continue.2247, label %frame.failure.0
runtime.continue.2247:
  %stack.sub.2248 = sub i32 %context.value.2197, %string.concat.extent.2093
  %stack.sub.2249 = sub i32 %stack.sub.2248, %local.old.extent.2176
  %stack.offset.2250 = add i32 %stack.sub.2249, %string.concat.extent.2093
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2194, i32 %stack.offset.2250, i32 %string.concat.extent.2093, i32 %string.concat.payload.2092, i32 12, i32 4)
  %context.field.2251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2252 = load i32, ptr %context.field.2251, align 4
  %runtime.ok.2253 = icmp eq i32 %context.value.2252, 0
  br i1 %runtime.ok.2253, label %runtime.continue.2254, label %frame.failure.0
runtime.continue.2254:
  %stack.sub.2255 = sub i32 %context.value.2197, %local.old.extent.2176
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.2255, i32 0, i32 0, i32 0)
  %context.field.2256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2257 = load i32, ptr %context.field.2256, align 4
  %runtime.ok.2258 = icmp eq i32 %context.value.2257, 0
  br i1 %runtime.ok.2258, label %runtime.continue.2259, label %frame.failure.0
runtime.continue.2259:
  %local.shrinks.2260 = icmp ult i32 %string.concat.extent.2093, %local.old.extent.2176
  br i1 %local.shrinks.2260, label %local.shrink.2261, label %local.counts.ready.2262
local.shrink.2261:
  %stack.sub.2263 = sub i32 %local.old.extent.2176, %string.concat.extent.2093
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2263)
  %context.field.2264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2265 = load i32, ptr %context.field.2264, align 4
  %runtime.ok.2266 = icmp eq i32 %context.value.2265, 0
  br i1 %runtime.ok.2266, label %runtime.continue.2267, label %frame.failure.0
runtime.continue.2267:
  br label %local.counts.ready.2262
local.counts.ready.2262:
  %local.payload.delta.2268 = sub i32 %string.concat.payload.2092, %local.old.payload.2177
  %stack.sub.2269 = sub i32 0, %local.old.payload.2177
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2269, i32 %local.payload.delta.2268)
  %context.field.2270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2271 = load i32, ptr %context.field.2270, align 4
  %runtime.ok.2272 = icmp eq i32 %context.value.2271, 0
  br i1 %runtime.ok.2272, label %runtime.continue.2273, label %frame.failure.0
runtime.continue.2273:
  %local.is.active.2274 = load i1, ptr %local.active.28, align 1
  %local.later.offset.2275 = load i32, ptr %local.offset.29, align 4
  %stack.sub.2276 = sub i32 %local.later.offset.2275, %local.old.extent.2176
  %stack.offset.2277 = add i32 %stack.sub.2276, %string.concat.extent.2093
  %local.later.offset.selected.2278 = select i1 %local.is.active.2274, i32 %stack.offset.2277, i32 %local.later.offset.2275
  store i32 %local.later.offset.selected.2278, ptr %local.offset.29, align 4
  %local.is.active.2279 = load i1, ptr %local.active.33, align 1
  %local.later.offset.2280 = load i32, ptr %local.offset.34, align 4
  %stack.sub.2281 = sub i32 %local.later.offset.2280, %local.old.extent.2176
  %stack.offset.2282 = add i32 %stack.sub.2281, %string.concat.extent.2093
  %local.later.offset.selected.2283 = select i1 %local.is.active.2279, i32 %stack.offset.2282, i32 %local.later.offset.2280
  store i32 %local.later.offset.selected.2283, ptr %local.offset.34, align 4
  %local.is.active.2284 = load i1, ptr %local.active.38, align 1
  %local.later.offset.2285 = load i32, ptr %local.offset.39, align 4
  %stack.sub.2286 = sub i32 %local.later.offset.2285, %local.old.extent.2176
  %stack.offset.2287 = add i32 %stack.sub.2286, %string.concat.extent.2093
  %local.later.offset.selected.2288 = select i1 %local.is.active.2284, i32 %stack.offset.2287, i32 %local.later.offset.2285
  store i32 %local.later.offset.selected.2288, ptr %local.offset.39, align 4
  %local.is.active.2289 = load i1, ptr %local.active.43, align 1
  %local.later.offset.2290 = load i32, ptr %local.offset.44, align 4
  %stack.sub.2291 = sub i32 %local.later.offset.2290, %local.old.extent.2176
  %stack.offset.2292 = add i32 %stack.sub.2291, %string.concat.extent.2093
  %local.later.offset.selected.2293 = select i1 %local.is.active.2289, i32 %stack.offset.2292, i32 %local.later.offset.2290
  store i32 %local.later.offset.selected.2293, ptr %local.offset.44, align 4
  %local.is.active.2294 = load i1, ptr %local.active.48, align 1
  %local.later.offset.2295 = load i32, ptr %local.offset.49, align 4
  %stack.sub.2296 = sub i32 %local.later.offset.2295, %local.old.extent.2176
  %stack.offset.2297 = add i32 %stack.sub.2296, %string.concat.extent.2093
  %local.later.offset.selected.2298 = select i1 %local.is.active.2294, i32 %stack.offset.2297, i32 %local.later.offset.2295
  store i32 %local.later.offset.selected.2298, ptr %local.offset.49, align 4
  %local.is.active.2299 = load i1, ptr %local.active.53, align 1
  %local.later.offset.2300 = load i32, ptr %local.offset.54, align 4
  %stack.sub.2301 = sub i32 %local.later.offset.2300, %local.old.extent.2176
  %stack.offset.2302 = add i32 %stack.sub.2301, %string.concat.extent.2093
  %local.later.offset.selected.2303 = select i1 %local.is.active.2299, i32 %stack.offset.2302, i32 %local.later.offset.2300
  store i32 %local.later.offset.selected.2303, ptr %local.offset.54, align 4
  %local.is.active.2304 = load i1, ptr %local.active.58, align 1
  %local.later.offset.2305 = load i32, ptr %local.offset.59, align 4
  %stack.sub.2306 = sub i32 %local.later.offset.2305, %local.old.extent.2176
  %stack.offset.2307 = add i32 %stack.sub.2306, %string.concat.extent.2093
  %local.later.offset.selected.2308 = select i1 %local.is.active.2304, i32 %stack.offset.2307, i32 %local.later.offset.2305
  store i32 %local.later.offset.selected.2308, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.23, align 1
  store i32 %stack.offset.2194, ptr %local.offset.24, align 4
  store i32 %string.concat.extent.2093, ptr %local.extent.25, align 4
  store i32 %string.concat.payload.2092, ptr %local.payload.26, align 4
  store i32 12, ptr %local.type.27, align 4
  %local.is.active.2309 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2310 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2311 = select i1 %local.is.active.2309, i32 %local.sum.extent.2310, i32 0
  %stack.offset.2312 = add i32 0, %local.sum.selected.2311
  %local.is.active.2313 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2314 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2315 = select i1 %local.is.active.2313, i32 %local.sum.extent.2314, i32 0
  %stack.offset.2316 = add i32 %stack.offset.2312, %local.sum.selected.2315
  %local.is.active.2317 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2318 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2319 = select i1 %local.is.active.2317, i32 %local.sum.extent.2318, i32 0
  %stack.offset.2320 = add i32 %stack.offset.2316, %local.sum.selected.2319
  %local.is.active.2321 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2322 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2323 = select i1 %local.is.active.2321, i32 %local.sum.extent.2322, i32 0
  %stack.offset.2324 = add i32 %stack.offset.2320, %local.sum.selected.2323
  %local.is.active.2325 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2326 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2327 = select i1 %local.is.active.2325, i32 %local.sum.extent.2326, i32 0
  %stack.offset.2328 = add i32 %stack.offset.2324, %local.sum.selected.2327
  %local.is.active.2329 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2330 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2331 = select i1 %local.is.active.2329, i32 %local.sum.extent.2330, i32 0
  %stack.offset.2332 = add i32 %stack.offset.2328, %local.sum.selected.2331
  %local.is.active.2333 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2334 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2335 = select i1 %local.is.active.2333, i32 %local.sum.extent.2334, i32 0
  %stack.offset.2336 = add i32 %stack.offset.2332, %local.sum.selected.2335
  %local.is.active.2337 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2338 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2339 = select i1 %local.is.active.2337, i32 %local.sum.extent.2338, i32 0
  %stack.offset.2340 = add i32 %stack.offset.2336, %local.sum.selected.2339
  %local.is.active.2341 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2342 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2343 = select i1 %local.is.active.2341, i32 %local.sum.extent.2342, i32 0
  %stack.offset.2344 = add i32 %stack.offset.2340, %local.sum.selected.2343
  %local.is.active.2345 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2346 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2347 = select i1 %local.is.active.2345, i32 %local.sum.extent.2346, i32 0
  %stack.offset.2348 = add i32 %stack.offset.2344, %local.sum.selected.2347
  %local.is.active.2349 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2350 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2351 = select i1 %local.is.active.2349, i32 %local.sum.extent.2350, i32 0
  %stack.offset.2352 = add i32 %stack.offset.2348, %local.sum.selected.2351
  %local.is.active.2353 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2354 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2355 = select i1 %local.is.active.2353, i32 %local.sum.extent.2354, i32 0
  %stack.offset.2356 = add i32 %stack.offset.2352, %local.sum.selected.2355
  %stack.offset.2357 = add i32 %stack.offset.2356, 0
  %stack.offset.2358 = add i32 %context.value.75, %stack.offset.2357
  %cursor.status.2359 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2358)
  %cursor.ok.2360 = icmp eq i32 %cursor.status.2359, 0
  br i1 %cursor.ok.2360, label %cursor.continue.2361, label %frame.failure.0
cursor.continue.2361:
  %step.status.2362 = call i32 @al_owning_charge_step(ptr %ctx, i32 51)
  %helper.ok.2363 = icmp eq i32 %step.status.2362, 0
  br i1 %helper.ok.2363, label %helper.continue.2364, label %frame.failure.0
helper.continue.2364:
  %local.source.offset.2365 = load i32, ptr %local.offset.19, align 4
  %local.source.extent.2366 = load i32, ptr %local.extent.20, align 4
  %local.source.payload.2367 = load i32, ptr %local.payload.21, align 4
  %context.field.2368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2369 = load i32, ptr %context.field.2368, align 4
  %stack.offset.2370 = add i32 %context.value.2369, %local.source.extent.2366
  %reserve.status.2371 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2370, i32 52)
  %reserve.ok.2372 = icmp eq i32 %reserve.status.2371, 0
  br i1 %reserve.ok.2372, label %reserve.continue.2373, label %frame.failure.0
reserve.continue.2373:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.2369, i32 %local.source.offset.2365, i32 %local.source.extent.2366, i32 %local.source.payload.2367, i32 12)
  %context.field.2374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2375 = load i32, ptr %context.field.2374, align 4
  %runtime.ok.2376 = icmp eq i32 %context.value.2375, 0
  br i1 %runtime.ok.2376, label %runtime.continue.2377, label %frame.failure.0
runtime.continue.2377:
  %local.is.active.2378 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2379 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2380 = select i1 %local.is.active.2378, i32 %local.sum.extent.2379, i32 0
  %stack.offset.2381 = add i32 0, %local.sum.selected.2380
  %local.is.active.2382 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2383 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2384 = select i1 %local.is.active.2382, i32 %local.sum.extent.2383, i32 0
  %stack.offset.2385 = add i32 %stack.offset.2381, %local.sum.selected.2384
  %local.is.active.2386 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2387 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2388 = select i1 %local.is.active.2386, i32 %local.sum.extent.2387, i32 0
  %stack.offset.2389 = add i32 %stack.offset.2385, %local.sum.selected.2388
  %local.is.active.2390 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2391 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2392 = select i1 %local.is.active.2390, i32 %local.sum.extent.2391, i32 0
  %stack.offset.2393 = add i32 %stack.offset.2389, %local.sum.selected.2392
  %local.is.active.2394 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2395 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2396 = select i1 %local.is.active.2394, i32 %local.sum.extent.2395, i32 0
  %stack.offset.2397 = add i32 %stack.offset.2393, %local.sum.selected.2396
  %local.is.active.2398 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2399 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2400 = select i1 %local.is.active.2398, i32 %local.sum.extent.2399, i32 0
  %stack.offset.2401 = add i32 %stack.offset.2397, %local.sum.selected.2400
  %local.is.active.2402 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2403 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2404 = select i1 %local.is.active.2402, i32 %local.sum.extent.2403, i32 0
  %stack.offset.2405 = add i32 %stack.offset.2401, %local.sum.selected.2404
  %local.is.active.2406 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2407 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2408 = select i1 %local.is.active.2406, i32 %local.sum.extent.2407, i32 0
  %stack.offset.2409 = add i32 %stack.offset.2405, %local.sum.selected.2408
  %local.is.active.2410 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2411 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2412 = select i1 %local.is.active.2410, i32 %local.sum.extent.2411, i32 0
  %stack.offset.2413 = add i32 %stack.offset.2409, %local.sum.selected.2412
  %local.is.active.2414 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2415 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2416 = select i1 %local.is.active.2414, i32 %local.sum.extent.2415, i32 0
  %stack.offset.2417 = add i32 %stack.offset.2413, %local.sum.selected.2416
  %local.is.active.2418 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2419 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2420 = select i1 %local.is.active.2418, i32 %local.sum.extent.2419, i32 0
  %stack.offset.2421 = add i32 %stack.offset.2417, %local.sum.selected.2420
  %local.is.active.2422 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2423 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2424 = select i1 %local.is.active.2422, i32 %local.sum.extent.2423, i32 0
  %stack.offset.2425 = add i32 %stack.offset.2421, %local.sum.selected.2424
  %stack.offset.2426 = add i32 0, %local.source.extent.2366
  %stack.offset.2427 = add i32 %stack.offset.2425, %stack.offset.2426
  %stack.offset.2428 = add i32 %context.value.75, %stack.offset.2427
  %cursor.status.2429 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2428)
  %cursor.ok.2430 = icmp eq i32 %cursor.status.2429, 0
  br i1 %cursor.ok.2430, label %cursor.continue.2431, label %frame.failure.0
cursor.continue.2431:
  %step.status.2432 = call i32 @al_owning_charge_step(ptr %ctx, i32 53)
  %helper.ok.2433 = icmp eq i32 %step.status.2432, 0
  br i1 %helper.ok.2433, label %helper.continue.2434, label %frame.failure.0
helper.continue.2434:
  %local.source.offset.2435 = load i32, ptr %local.offset.24, align 4
  %local.source.extent.2436 = load i32, ptr %local.extent.25, align 4
  %local.source.payload.2437 = load i32, ptr %local.payload.26, align 4
  %context.field.2438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2439 = load i32, ptr %context.field.2438, align 4
  %stack.offset.2440 = add i32 %context.value.2439, %local.source.extent.2436
  %reserve.status.2441 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2440, i32 54)
  %reserve.ok.2442 = icmp eq i32 %reserve.status.2441, 0
  br i1 %reserve.ok.2442, label %reserve.continue.2443, label %frame.failure.0
reserve.continue.2443:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.2439, i32 %local.source.offset.2435, i32 %local.source.extent.2436, i32 %local.source.payload.2437, i32 12)
  %context.field.2444 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2445 = load i32, ptr %context.field.2444, align 4
  %runtime.ok.2446 = icmp eq i32 %context.value.2445, 0
  br i1 %runtime.ok.2446, label %runtime.continue.2447, label %frame.failure.0
runtime.continue.2447:
  %local.is.active.2448 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2449 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2450 = select i1 %local.is.active.2448, i32 %local.sum.extent.2449, i32 0
  %stack.offset.2451 = add i32 0, %local.sum.selected.2450
  %local.is.active.2452 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2453 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2454 = select i1 %local.is.active.2452, i32 %local.sum.extent.2453, i32 0
  %stack.offset.2455 = add i32 %stack.offset.2451, %local.sum.selected.2454
  %local.is.active.2456 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2457 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2458 = select i1 %local.is.active.2456, i32 %local.sum.extent.2457, i32 0
  %stack.offset.2459 = add i32 %stack.offset.2455, %local.sum.selected.2458
  %local.is.active.2460 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2461 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2462 = select i1 %local.is.active.2460, i32 %local.sum.extent.2461, i32 0
  %stack.offset.2463 = add i32 %stack.offset.2459, %local.sum.selected.2462
  %local.is.active.2464 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2465 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2466 = select i1 %local.is.active.2464, i32 %local.sum.extent.2465, i32 0
  %stack.offset.2467 = add i32 %stack.offset.2463, %local.sum.selected.2466
  %local.is.active.2468 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2469 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2470 = select i1 %local.is.active.2468, i32 %local.sum.extent.2469, i32 0
  %stack.offset.2471 = add i32 %stack.offset.2467, %local.sum.selected.2470
  %local.is.active.2472 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2473 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2474 = select i1 %local.is.active.2472, i32 %local.sum.extent.2473, i32 0
  %stack.offset.2475 = add i32 %stack.offset.2471, %local.sum.selected.2474
  %local.is.active.2476 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2477 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2478 = select i1 %local.is.active.2476, i32 %local.sum.extent.2477, i32 0
  %stack.offset.2479 = add i32 %stack.offset.2475, %local.sum.selected.2478
  %local.is.active.2480 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2481 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2482 = select i1 %local.is.active.2480, i32 %local.sum.extent.2481, i32 0
  %stack.offset.2483 = add i32 %stack.offset.2479, %local.sum.selected.2482
  %local.is.active.2484 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2485 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2486 = select i1 %local.is.active.2484, i32 %local.sum.extent.2485, i32 0
  %stack.offset.2487 = add i32 %stack.offset.2483, %local.sum.selected.2486
  %local.is.active.2488 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2489 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2490 = select i1 %local.is.active.2488, i32 %local.sum.extent.2489, i32 0
  %stack.offset.2491 = add i32 %stack.offset.2487, %local.sum.selected.2490
  %local.is.active.2492 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2493 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2494 = select i1 %local.is.active.2492, i32 %local.sum.extent.2493, i32 0
  %stack.offset.2495 = add i32 %stack.offset.2491, %local.sum.selected.2494
  %stack.offset.2496 = add i32 0, %local.source.extent.2366
  %stack.offset.2497 = add i32 %stack.offset.2496, %local.source.extent.2436
  %stack.offset.2498 = add i32 %stack.offset.2495, %stack.offset.2497
  %stack.offset.2499 = add i32 %context.value.75, %stack.offset.2498
  %cursor.status.2500 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2499)
  %cursor.ok.2501 = icmp eq i32 %cursor.status.2500, 0
  br i1 %cursor.ok.2501, label %cursor.continue.2502, label %frame.failure.0
cursor.continue.2502:
  %step.status.2503 = call i32 @al_owning_charge_step(ptr %ctx, i32 55)
  %helper.ok.2504 = icmp eq i32 %step.status.2503, 0
  br i1 %helper.ok.2504, label %helper.continue.2505, label %frame.failure.0
helper.continue.2505:
  %context.field.2506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2507 = load i32, ptr %context.field.2506, align 4
  %local.is.active.2508 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2509 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2510 = select i1 %local.is.active.2508, i32 %local.sum.extent.2509, i32 0
  %stack.offset.2511 = add i32 0, %local.sum.selected.2510
  %local.is.active.2512 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2513 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2514 = select i1 %local.is.active.2512, i32 %local.sum.extent.2513, i32 0
  %stack.offset.2515 = add i32 %stack.offset.2511, %local.sum.selected.2514
  %local.is.active.2516 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2517 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2518 = select i1 %local.is.active.2516, i32 %local.sum.extent.2517, i32 0
  %stack.offset.2519 = add i32 %stack.offset.2515, %local.sum.selected.2518
  %local.is.active.2520 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2521 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2522 = select i1 %local.is.active.2520, i32 %local.sum.extent.2521, i32 0
  %stack.offset.2523 = add i32 %stack.offset.2519, %local.sum.selected.2522
  %local.is.active.2524 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2525 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2526 = select i1 %local.is.active.2524, i32 %local.sum.extent.2525, i32 0
  %stack.offset.2527 = add i32 %stack.offset.2523, %local.sum.selected.2526
  %local.is.active.2528 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2529 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2530 = select i1 %local.is.active.2528, i32 %local.sum.extent.2529, i32 0
  %stack.offset.2531 = add i32 %stack.offset.2527, %local.sum.selected.2530
  %local.is.active.2532 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2533 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2534 = select i1 %local.is.active.2532, i32 %local.sum.extent.2533, i32 0
  %stack.offset.2535 = add i32 %stack.offset.2531, %local.sum.selected.2534
  %local.is.active.2536 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2537 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2538 = select i1 %local.is.active.2536, i32 %local.sum.extent.2537, i32 0
  %stack.offset.2539 = add i32 %stack.offset.2535, %local.sum.selected.2538
  %local.is.active.2540 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2541 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2542 = select i1 %local.is.active.2540, i32 %local.sum.extent.2541, i32 0
  %stack.offset.2543 = add i32 %stack.offset.2539, %local.sum.selected.2542
  %local.is.active.2544 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2545 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2546 = select i1 %local.is.active.2544, i32 %local.sum.extent.2545, i32 0
  %stack.offset.2547 = add i32 %stack.offset.2543, %local.sum.selected.2546
  %local.is.active.2548 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2549 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2550 = select i1 %local.is.active.2548, i32 %local.sum.extent.2549, i32 0
  %stack.offset.2551 = add i32 %stack.offset.2547, %local.sum.selected.2550
  %local.is.active.2552 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2553 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2554 = select i1 %local.is.active.2552, i32 %local.sum.extent.2553, i32 0
  %stack.offset.2555 = add i32 %stack.offset.2551, %local.sum.selected.2554
  %stack.offset.2556 = add i32 %stack.offset.2555, 0
  %stack.offset.2557 = add i32 %context.value.75, %stack.offset.2556
  %stack.sub.2558 = sub i32 %context.value.2507, %local.source.extent.2436
  %string.concat.units.2559 = alloca i32, align 4
  %string.concat.payload.pointer.2560 = alloca i32, align 4
  %string.concat.extent.pointer.2561 = alloca i32, align 4
  %string.concat.plan.status.2562 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %stack.offset.2557, i32 %local.source.extent.2366, i32 %stack.sub.2558, i32 %local.source.extent.2436, i32 56, ptr %string.concat.units.2559, ptr %string.concat.payload.pointer.2560, ptr %string.concat.extent.pointer.2561)
  %helper.ok.2563 = icmp eq i32 %string.concat.plan.status.2562, 0
  br i1 %helper.ok.2563, label %helper.continue.2564, label %frame.failure.0
helper.continue.2564:
  %string.concat.payload.2565 = load i32, ptr %string.concat.payload.pointer.2560, align 4
  %string.concat.extent.2566 = load i32, ptr %string.concat.extent.pointer.2561, align 4
  %stack.offset.2567 = add i32 %context.value.2507, %string.concat.extent.2566
  %reserve.status.2568 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2567, i32 57)
  %reserve.ok.2569 = icmp eq i32 %reserve.status.2568, 0
  br i1 %reserve.ok.2569, label %reserve.continue.2570, label %frame.failure.0
reserve.continue.2570:
  %string.concat.write.status.2571 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.2507, i32 %string.concat.extent.2566, i32 %stack.offset.2557, i32 %local.source.extent.2366, i32 %stack.sub.2558, i32 %local.source.extent.2436, i32 12, i32 56)
  %helper.ok.2572 = icmp eq i32 %string.concat.write.status.2571, 0
  br i1 %helper.ok.2572, label %helper.continue.2573, label %frame.failure.0
helper.continue.2573:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2557, i32 %context.value.2507, i32 %string.concat.extent.2566, i32 %string.concat.payload.2565, i32 12, i32 0)
  %context.field.2574 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2575 = load i32, ptr %context.field.2574, align 4
  %runtime.ok.2576 = icmp eq i32 %context.value.2575, 0
  br i1 %runtime.ok.2576, label %runtime.continue.2577, label %frame.failure.0
runtime.continue.2577:
  %stack.offset.2578 = add i32 %stack.offset.2557, %string.concat.extent.2566
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.2578, i32 0, i32 0, i32 0)
  %context.field.2579 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2580 = load i32, ptr %context.field.2579, align 4
  %runtime.ok.2581 = icmp eq i32 %context.value.2580, 0
  br i1 %runtime.ok.2581, label %runtime.continue.2582, label %frame.failure.0
runtime.continue.2582:
  %stack.offset.2583 = add i32 %local.source.payload.2367, %local.source.payload.2437
  %stack.sub.2584 = sub i32 %string.concat.payload.2565, %stack.offset.2583
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2584, i32 0)
  %context.field.2585 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2586 = load i32, ptr %context.field.2585, align 4
  %runtime.ok.2587 = icmp eq i32 %context.value.2586, 0
  br i1 %runtime.ok.2587, label %runtime.continue.2588, label %frame.failure.0
runtime.continue.2588:
  %local.is.active.2589 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2590 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2591 = select i1 %local.is.active.2589, i32 %local.sum.extent.2590, i32 0
  %stack.offset.2592 = add i32 0, %local.sum.selected.2591
  %local.is.active.2593 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2594 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2595 = select i1 %local.is.active.2593, i32 %local.sum.extent.2594, i32 0
  %stack.offset.2596 = add i32 %stack.offset.2592, %local.sum.selected.2595
  %local.is.active.2597 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2598 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2599 = select i1 %local.is.active.2597, i32 %local.sum.extent.2598, i32 0
  %stack.offset.2600 = add i32 %stack.offset.2596, %local.sum.selected.2599
  %local.is.active.2601 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2602 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2603 = select i1 %local.is.active.2601, i32 %local.sum.extent.2602, i32 0
  %stack.offset.2604 = add i32 %stack.offset.2600, %local.sum.selected.2603
  %local.is.active.2605 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2606 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2607 = select i1 %local.is.active.2605, i32 %local.sum.extent.2606, i32 0
  %stack.offset.2608 = add i32 %stack.offset.2604, %local.sum.selected.2607
  %local.is.active.2609 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2610 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2611 = select i1 %local.is.active.2609, i32 %local.sum.extent.2610, i32 0
  %stack.offset.2612 = add i32 %stack.offset.2608, %local.sum.selected.2611
  %local.is.active.2613 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2614 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2615 = select i1 %local.is.active.2613, i32 %local.sum.extent.2614, i32 0
  %stack.offset.2616 = add i32 %stack.offset.2612, %local.sum.selected.2615
  %local.is.active.2617 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2618 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2619 = select i1 %local.is.active.2617, i32 %local.sum.extent.2618, i32 0
  %stack.offset.2620 = add i32 %stack.offset.2616, %local.sum.selected.2619
  %local.is.active.2621 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2622 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2623 = select i1 %local.is.active.2621, i32 %local.sum.extent.2622, i32 0
  %stack.offset.2624 = add i32 %stack.offset.2620, %local.sum.selected.2623
  %local.is.active.2625 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2626 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2627 = select i1 %local.is.active.2625, i32 %local.sum.extent.2626, i32 0
  %stack.offset.2628 = add i32 %stack.offset.2624, %local.sum.selected.2627
  %local.is.active.2629 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2630 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2631 = select i1 %local.is.active.2629, i32 %local.sum.extent.2630, i32 0
  %stack.offset.2632 = add i32 %stack.offset.2628, %local.sum.selected.2631
  %local.is.active.2633 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2634 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2635 = select i1 %local.is.active.2633, i32 %local.sum.extent.2634, i32 0
  %stack.offset.2636 = add i32 %stack.offset.2632, %local.sum.selected.2635
  %stack.offset.2637 = add i32 0, %string.concat.extent.2566
  %stack.offset.2638 = add i32 %stack.offset.2636, %stack.offset.2637
  %stack.offset.2639 = add i32 %context.value.75, %stack.offset.2638
  %cursor.status.2640 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2639)
  %cursor.ok.2641 = icmp eq i32 %cursor.status.2640, 0
  br i1 %cursor.ok.2641, label %cursor.continue.2642, label %frame.failure.0
cursor.continue.2642:
  %step.status.2643 = call i32 @al_owning_charge_step(ptr %ctx, i32 58)
  %helper.ok.2644 = icmp eq i32 %step.status.2643, 0
  br i1 %helper.ok.2644, label %helper.continue.2645, label %frame.failure.0
helper.continue.2645:
  %local.is.active.2646 = load i1, ptr %local.active.28, align 1
  %local.previous.extent.2647 = load i32, ptr %local.extent.30, align 4
  %local.previous.payload.2648 = load i32, ptr %local.payload.31, align 4
  %local.old.extent.2649 = select i1 %local.is.active.2646, i32 %local.previous.extent.2647, i32 0
  %local.old.payload.2650 = select i1 %local.is.active.2646, i32 %local.previous.payload.2648, i32 0
  %local.is.active.2651 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2652 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2653 = select i1 %local.is.active.2651, i32 %local.sum.extent.2652, i32 0
  %stack.offset.2654 = add i32 0, %local.sum.selected.2653
  %local.is.active.2655 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2656 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2657 = select i1 %local.is.active.2655, i32 %local.sum.extent.2656, i32 0
  %stack.offset.2658 = add i32 %stack.offset.2654, %local.sum.selected.2657
  %local.is.active.2659 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2660 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2661 = select i1 %local.is.active.2659, i32 %local.sum.extent.2660, i32 0
  %stack.offset.2662 = add i32 %stack.offset.2658, %local.sum.selected.2661
  %local.is.active.2663 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2664 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2665 = select i1 %local.is.active.2663, i32 %local.sum.extent.2664, i32 0
  %stack.offset.2666 = add i32 %stack.offset.2662, %local.sum.selected.2665
  %local.is.active.2667 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2668 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2669 = select i1 %local.is.active.2667, i32 %local.sum.extent.2668, i32 0
  %stack.offset.2670 = add i32 %stack.offset.2666, %local.sum.selected.2669
  %stack.offset.2671 = add i32 %context.value.75, %stack.offset.2670
  %stack.offset.2672 = add i32 %stack.offset.2671, %local.old.extent.2649
  %context.field.2673 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2674 = load i32, ptr %context.field.2673, align 4
  %stack.sub.2675 = sub i32 %context.value.2674, %stack.offset.2672
  %stack.sub.2676 = sub i32 %context.value.2674, %local.old.extent.2649
  %stack.offset.2677 = add i32 %stack.sub.2676, %string.concat.extent.2566
  %local.grows.2678 = icmp ugt i32 %string.concat.extent.2566, %local.old.extent.2649
  br i1 %local.grows.2678, label %local.grow.2679, label %local.fixed.2680
local.grow.2679:
  %reserve.status.2682 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2677, i32 59)
  %reserve.ok.2683 = icmp eq i32 %reserve.status.2682, 0
  br i1 %reserve.ok.2683, label %reserve.continue.2684, label %frame.failure.0
reserve.continue.2684:
  %stack.sub.2685 = sub i32 %string.concat.extent.2566, %local.old.extent.2649
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.2685)
  %context.field.2686 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2687 = load i32, ptr %context.field.2686, align 4
  %runtime.ok.2688 = icmp eq i32 %context.value.2687, 0
  br i1 %runtime.ok.2688, label %runtime.continue.2689, label %frame.failure.0
runtime.continue.2689:
  br label %local.layout.ready.2681
local.fixed.2680:
  br label %local.layout.ready.2681
local.layout.ready.2681:
  %stack.offset.2690 = add i32 %stack.offset.2671, %string.concat.extent.2566
  %local.is.active.2691 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.2692 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.2693 = select i1 %local.is.active.2691, i32 %local.suffix.payload.2692, i32 0
  %stack.offset.2694 = add i32 0, %local.suffix.selected.2693
  %local.is.active.2695 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.2696 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.2697 = select i1 %local.is.active.2695, i32 %local.suffix.payload.2696, i32 0
  %stack.offset.2698 = add i32 %stack.offset.2694, %local.suffix.selected.2697
  %local.is.active.2699 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.2700 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.2701 = select i1 %local.is.active.2699, i32 %local.suffix.payload.2700, i32 0
  %stack.offset.2702 = add i32 %stack.offset.2698, %local.suffix.selected.2701
  %local.is.active.2703 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.2704 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.2705 = select i1 %local.is.active.2703, i32 %local.suffix.payload.2704, i32 0
  %stack.offset.2706 = add i32 %stack.offset.2702, %local.suffix.selected.2705
  %local.is.active.2707 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.2708 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.2709 = select i1 %local.is.active.2707, i32 %local.suffix.payload.2708, i32 0
  %stack.offset.2710 = add i32 %stack.offset.2706, %local.suffix.selected.2709
  %local.is.active.2711 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.2712 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.2713 = select i1 %local.is.active.2711, i32 %local.suffix.payload.2712, i32 0
  %stack.offset.2714 = add i32 %stack.offset.2710, %local.suffix.selected.2713
  %stack.offset.2715 = add i32 0, %string.concat.payload.2565
  %stack.offset.2716 = add i32 %stack.offset.2714, %stack.offset.2715
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2690, i32 %stack.offset.2672, i32 %stack.sub.2675, i32 %stack.offset.2716, i32 0, i32 14)
  %context.field.2717 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2718 = load i32, ptr %context.field.2717, align 4
  %runtime.ok.2719 = icmp eq i32 %context.value.2718, 0
  br i1 %runtime.ok.2719, label %runtime.continue.2720, label %frame.failure.0
runtime.continue.2720:
  %stack.sub.2721 = sub i32 %context.value.2674, %string.concat.extent.2566
  %stack.sub.2722 = sub i32 %stack.sub.2721, %local.old.extent.2649
  %stack.offset.2723 = add i32 %stack.sub.2722, %string.concat.extent.2566
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2671, i32 %stack.offset.2723, i32 %string.concat.extent.2566, i32 %string.concat.payload.2565, i32 12, i32 4)
  %context.field.2724 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2725 = load i32, ptr %context.field.2724, align 4
  %runtime.ok.2726 = icmp eq i32 %context.value.2725, 0
  br i1 %runtime.ok.2726, label %runtime.continue.2727, label %frame.failure.0
runtime.continue.2727:
  %stack.sub.2728 = sub i32 %context.value.2674, %local.old.extent.2649
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.2728, i32 0, i32 0, i32 0)
  %context.field.2729 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2730 = load i32, ptr %context.field.2729, align 4
  %runtime.ok.2731 = icmp eq i32 %context.value.2730, 0
  br i1 %runtime.ok.2731, label %runtime.continue.2732, label %frame.failure.0
runtime.continue.2732:
  %local.shrinks.2733 = icmp ult i32 %string.concat.extent.2566, %local.old.extent.2649
  br i1 %local.shrinks.2733, label %local.shrink.2734, label %local.counts.ready.2735
local.shrink.2734:
  %stack.sub.2736 = sub i32 %local.old.extent.2649, %string.concat.extent.2566
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2736)
  %context.field.2737 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2738 = load i32, ptr %context.field.2737, align 4
  %runtime.ok.2739 = icmp eq i32 %context.value.2738, 0
  br i1 %runtime.ok.2739, label %runtime.continue.2740, label %frame.failure.0
runtime.continue.2740:
  br label %local.counts.ready.2735
local.counts.ready.2735:
  %local.payload.delta.2741 = sub i32 %string.concat.payload.2565, %local.old.payload.2650
  %stack.sub.2742 = sub i32 0, %local.old.payload.2650
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2742, i32 %local.payload.delta.2741)
  %context.field.2743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2744 = load i32, ptr %context.field.2743, align 4
  %runtime.ok.2745 = icmp eq i32 %context.value.2744, 0
  br i1 %runtime.ok.2745, label %runtime.continue.2746, label %frame.failure.0
runtime.continue.2746:
  %local.is.active.2747 = load i1, ptr %local.active.33, align 1
  %local.later.offset.2748 = load i32, ptr %local.offset.34, align 4
  %stack.sub.2749 = sub i32 %local.later.offset.2748, %local.old.extent.2649
  %stack.offset.2750 = add i32 %stack.sub.2749, %string.concat.extent.2566
  %local.later.offset.selected.2751 = select i1 %local.is.active.2747, i32 %stack.offset.2750, i32 %local.later.offset.2748
  store i32 %local.later.offset.selected.2751, ptr %local.offset.34, align 4
  %local.is.active.2752 = load i1, ptr %local.active.38, align 1
  %local.later.offset.2753 = load i32, ptr %local.offset.39, align 4
  %stack.sub.2754 = sub i32 %local.later.offset.2753, %local.old.extent.2649
  %stack.offset.2755 = add i32 %stack.sub.2754, %string.concat.extent.2566
  %local.later.offset.selected.2756 = select i1 %local.is.active.2752, i32 %stack.offset.2755, i32 %local.later.offset.2753
  store i32 %local.later.offset.selected.2756, ptr %local.offset.39, align 4
  %local.is.active.2757 = load i1, ptr %local.active.43, align 1
  %local.later.offset.2758 = load i32, ptr %local.offset.44, align 4
  %stack.sub.2759 = sub i32 %local.later.offset.2758, %local.old.extent.2649
  %stack.offset.2760 = add i32 %stack.sub.2759, %string.concat.extent.2566
  %local.later.offset.selected.2761 = select i1 %local.is.active.2757, i32 %stack.offset.2760, i32 %local.later.offset.2758
  store i32 %local.later.offset.selected.2761, ptr %local.offset.44, align 4
  %local.is.active.2762 = load i1, ptr %local.active.48, align 1
  %local.later.offset.2763 = load i32, ptr %local.offset.49, align 4
  %stack.sub.2764 = sub i32 %local.later.offset.2763, %local.old.extent.2649
  %stack.offset.2765 = add i32 %stack.sub.2764, %string.concat.extent.2566
  %local.later.offset.selected.2766 = select i1 %local.is.active.2762, i32 %stack.offset.2765, i32 %local.later.offset.2763
  store i32 %local.later.offset.selected.2766, ptr %local.offset.49, align 4
  %local.is.active.2767 = load i1, ptr %local.active.53, align 1
  %local.later.offset.2768 = load i32, ptr %local.offset.54, align 4
  %stack.sub.2769 = sub i32 %local.later.offset.2768, %local.old.extent.2649
  %stack.offset.2770 = add i32 %stack.sub.2769, %string.concat.extent.2566
  %local.later.offset.selected.2771 = select i1 %local.is.active.2767, i32 %stack.offset.2770, i32 %local.later.offset.2768
  store i32 %local.later.offset.selected.2771, ptr %local.offset.54, align 4
  %local.is.active.2772 = load i1, ptr %local.active.58, align 1
  %local.later.offset.2773 = load i32, ptr %local.offset.59, align 4
  %stack.sub.2774 = sub i32 %local.later.offset.2773, %local.old.extent.2649
  %stack.offset.2775 = add i32 %stack.sub.2774, %string.concat.extent.2566
  %local.later.offset.selected.2776 = select i1 %local.is.active.2772, i32 %stack.offset.2775, i32 %local.later.offset.2773
  store i32 %local.later.offset.selected.2776, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.28, align 1
  store i32 %stack.offset.2671, ptr %local.offset.29, align 4
  store i32 %string.concat.extent.2566, ptr %local.extent.30, align 4
  store i32 %string.concat.payload.2565, ptr %local.payload.31, align 4
  store i32 12, ptr %local.type.32, align 4
  %local.is.active.2777 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2778 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2779 = select i1 %local.is.active.2777, i32 %local.sum.extent.2778, i32 0
  %stack.offset.2780 = add i32 0, %local.sum.selected.2779
  %local.is.active.2781 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2782 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2783 = select i1 %local.is.active.2781, i32 %local.sum.extent.2782, i32 0
  %stack.offset.2784 = add i32 %stack.offset.2780, %local.sum.selected.2783
  %local.is.active.2785 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2786 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2787 = select i1 %local.is.active.2785, i32 %local.sum.extent.2786, i32 0
  %stack.offset.2788 = add i32 %stack.offset.2784, %local.sum.selected.2787
  %local.is.active.2789 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2790 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2791 = select i1 %local.is.active.2789, i32 %local.sum.extent.2790, i32 0
  %stack.offset.2792 = add i32 %stack.offset.2788, %local.sum.selected.2791
  %local.is.active.2793 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2794 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2795 = select i1 %local.is.active.2793, i32 %local.sum.extent.2794, i32 0
  %stack.offset.2796 = add i32 %stack.offset.2792, %local.sum.selected.2795
  %local.is.active.2797 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2798 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2799 = select i1 %local.is.active.2797, i32 %local.sum.extent.2798, i32 0
  %stack.offset.2800 = add i32 %stack.offset.2796, %local.sum.selected.2799
  %local.is.active.2801 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2802 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2803 = select i1 %local.is.active.2801, i32 %local.sum.extent.2802, i32 0
  %stack.offset.2804 = add i32 %stack.offset.2800, %local.sum.selected.2803
  %local.is.active.2805 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2806 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2807 = select i1 %local.is.active.2805, i32 %local.sum.extent.2806, i32 0
  %stack.offset.2808 = add i32 %stack.offset.2804, %local.sum.selected.2807
  %local.is.active.2809 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2810 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2811 = select i1 %local.is.active.2809, i32 %local.sum.extent.2810, i32 0
  %stack.offset.2812 = add i32 %stack.offset.2808, %local.sum.selected.2811
  %local.is.active.2813 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2814 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2815 = select i1 %local.is.active.2813, i32 %local.sum.extent.2814, i32 0
  %stack.offset.2816 = add i32 %stack.offset.2812, %local.sum.selected.2815
  %local.is.active.2817 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2818 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2819 = select i1 %local.is.active.2817, i32 %local.sum.extent.2818, i32 0
  %stack.offset.2820 = add i32 %stack.offset.2816, %local.sum.selected.2819
  %local.is.active.2821 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2822 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2823 = select i1 %local.is.active.2821, i32 %local.sum.extent.2822, i32 0
  %stack.offset.2824 = add i32 %stack.offset.2820, %local.sum.selected.2823
  %stack.offset.2825 = add i32 %stack.offset.2824, 0
  %stack.offset.2826 = add i32 %context.value.75, %stack.offset.2825
  %cursor.status.2827 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2826)
  %cursor.ok.2828 = icmp eq i32 %cursor.status.2827, 0
  br i1 %cursor.ok.2828, label %cursor.continue.2829, label %frame.failure.0
cursor.continue.2829:
  %step.status.2830 = call i32 @al_owning_charge_step(ptr %ctx, i32 60)
  %helper.ok.2831 = icmp eq i32 %step.status.2830, 0
  br i1 %helper.ok.2831, label %helper.continue.2832, label %frame.failure.0
helper.continue.2832:
  %local.source.offset.2833 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.2834 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.2835 = load i32, ptr %local.payload.16, align 4
  %context.field.2836 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2837 = load i32, ptr %context.field.2836, align 4
  %stack.offset.2838 = add i32 %context.value.2837, %local.source.extent.2834
  %reserve.status.2839 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2838, i32 61)
  %reserve.ok.2840 = icmp eq i32 %reserve.status.2839, 0
  br i1 %reserve.ok.2840, label %reserve.continue.2841, label %frame.failure.0
reserve.continue.2841:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.2837, i32 %local.source.offset.2833, i32 %local.source.extent.2834, i32 %local.source.payload.2835, i32 8)
  %context.field.2842 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2843 = load i32, ptr %context.field.2842, align 4
  %runtime.ok.2844 = icmp eq i32 %context.value.2843, 0
  br i1 %runtime.ok.2844, label %runtime.continue.2845, label %frame.failure.0
runtime.continue.2845:
  %local.is.active.2846 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2847 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2848 = select i1 %local.is.active.2846, i32 %local.sum.extent.2847, i32 0
  %stack.offset.2849 = add i32 0, %local.sum.selected.2848
  %local.is.active.2850 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2851 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2852 = select i1 %local.is.active.2850, i32 %local.sum.extent.2851, i32 0
  %stack.offset.2853 = add i32 %stack.offset.2849, %local.sum.selected.2852
  %local.is.active.2854 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2855 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2856 = select i1 %local.is.active.2854, i32 %local.sum.extent.2855, i32 0
  %stack.offset.2857 = add i32 %stack.offset.2853, %local.sum.selected.2856
  %local.is.active.2858 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2859 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2860 = select i1 %local.is.active.2858, i32 %local.sum.extent.2859, i32 0
  %stack.offset.2861 = add i32 %stack.offset.2857, %local.sum.selected.2860
  %local.is.active.2862 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2863 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2864 = select i1 %local.is.active.2862, i32 %local.sum.extent.2863, i32 0
  %stack.offset.2865 = add i32 %stack.offset.2861, %local.sum.selected.2864
  %local.is.active.2866 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2867 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2868 = select i1 %local.is.active.2866, i32 %local.sum.extent.2867, i32 0
  %stack.offset.2869 = add i32 %stack.offset.2865, %local.sum.selected.2868
  %local.is.active.2870 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2871 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2872 = select i1 %local.is.active.2870, i32 %local.sum.extent.2871, i32 0
  %stack.offset.2873 = add i32 %stack.offset.2869, %local.sum.selected.2872
  %local.is.active.2874 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2875 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2876 = select i1 %local.is.active.2874, i32 %local.sum.extent.2875, i32 0
  %stack.offset.2877 = add i32 %stack.offset.2873, %local.sum.selected.2876
  %local.is.active.2878 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2879 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2880 = select i1 %local.is.active.2878, i32 %local.sum.extent.2879, i32 0
  %stack.offset.2881 = add i32 %stack.offset.2877, %local.sum.selected.2880
  %local.is.active.2882 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2883 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2884 = select i1 %local.is.active.2882, i32 %local.sum.extent.2883, i32 0
  %stack.offset.2885 = add i32 %stack.offset.2881, %local.sum.selected.2884
  %local.is.active.2886 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2887 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2888 = select i1 %local.is.active.2886, i32 %local.sum.extent.2887, i32 0
  %stack.offset.2889 = add i32 %stack.offset.2885, %local.sum.selected.2888
  %local.is.active.2890 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2891 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2892 = select i1 %local.is.active.2890, i32 %local.sum.extent.2891, i32 0
  %stack.offset.2893 = add i32 %stack.offset.2889, %local.sum.selected.2892
  %stack.offset.2894 = add i32 0, %local.source.extent.2834
  %stack.offset.2895 = add i32 %stack.offset.2893, %stack.offset.2894
  %stack.offset.2896 = add i32 %context.value.75, %stack.offset.2895
  %cursor.status.2897 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.2896)
  %cursor.ok.2898 = icmp eq i32 %cursor.status.2897, 0
  br i1 %cursor.ok.2898, label %cursor.continue.2899, label %frame.failure.0
cursor.continue.2899:
  %step.status.2900 = call i32 @al_owning_charge_step(ptr %ctx, i32 62)
  %helper.ok.2901 = icmp eq i32 %step.status.2900, 0
  br i1 %helper.ok.2901, label %helper.continue.2902, label %frame.failure.0
helper.continue.2902:
  %local.is.active.2903 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2904 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2905 = select i1 %local.is.active.2903, i32 %local.sum.extent.2904, i32 0
  %stack.offset.2906 = add i32 0, %local.sum.selected.2905
  %local.is.active.2907 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2908 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2909 = select i1 %local.is.active.2907, i32 %local.sum.extent.2908, i32 0
  %stack.offset.2910 = add i32 %stack.offset.2906, %local.sum.selected.2909
  %local.is.active.2911 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2912 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2913 = select i1 %local.is.active.2911, i32 %local.sum.extent.2912, i32 0
  %stack.offset.2914 = add i32 %stack.offset.2910, %local.sum.selected.2913
  %local.is.active.2915 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2916 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.2917 = select i1 %local.is.active.2915, i32 %local.sum.extent.2916, i32 0
  %stack.offset.2918 = add i32 %stack.offset.2914, %local.sum.selected.2917
  %local.is.active.2919 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.2920 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.2921 = select i1 %local.is.active.2919, i32 %local.sum.extent.2920, i32 0
  %stack.offset.2922 = add i32 %stack.offset.2918, %local.sum.selected.2921
  %local.is.active.2923 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.2924 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.2925 = select i1 %local.is.active.2923, i32 %local.sum.extent.2924, i32 0
  %stack.offset.2926 = add i32 %stack.offset.2922, %local.sum.selected.2925
  %local.is.active.2927 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.2928 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.2929 = select i1 %local.is.active.2927, i32 %local.sum.extent.2928, i32 0
  %stack.offset.2930 = add i32 %stack.offset.2926, %local.sum.selected.2929
  %local.is.active.2931 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.2932 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.2933 = select i1 %local.is.active.2931, i32 %local.sum.extent.2932, i32 0
  %stack.offset.2934 = add i32 %stack.offset.2930, %local.sum.selected.2933
  %local.is.active.2935 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.2936 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.2937 = select i1 %local.is.active.2935, i32 %local.sum.extent.2936, i32 0
  %stack.offset.2938 = add i32 %stack.offset.2934, %local.sum.selected.2937
  %local.is.active.2939 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.2940 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.2941 = select i1 %local.is.active.2939, i32 %local.sum.extent.2940, i32 0
  %stack.offset.2942 = add i32 %stack.offset.2938, %local.sum.selected.2941
  %local.is.active.2943 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.2944 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.2945 = select i1 %local.is.active.2943, i32 %local.sum.extent.2944, i32 0
  %stack.offset.2946 = add i32 %stack.offset.2942, %local.sum.selected.2945
  %local.is.active.2947 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.2948 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.2949 = select i1 %local.is.active.2947, i32 %local.sum.extent.2948, i32 0
  %stack.offset.2950 = add i32 %stack.offset.2946, %local.sum.selected.2949
  %stack.offset.2951 = add i32 %stack.offset.2950, 0
  %stack.offset.2952 = add i32 %context.value.75, %stack.offset.2951
  %field.location.2953 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.2954 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.2952, i32 %local.source.extent.2834, i32 0, i32 63, ptr %field.location.2953)
  %helper.ok.2955 = icmp eq i32 %field.location.status.2954, 0
  br i1 %helper.ok.2955, label %helper.continue.2956, label %frame.failure.0
helper.continue.2956:
  %field.offset.pointer.2957 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.2953, i32 0, i32 0
  %field.offset.2958 = load i32, ptr %field.offset.pointer.2957, align 4
  %field.payload.pointer.2959 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.2953, i32 0, i32 1
  %field.payload.2960 = load i32, ptr %field.payload.pointer.2959, align 4
  %field.extent.pointer.2961 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.2953, i32 0, i32 2
  %field.extent.2962 = load i32, ptr %field.extent.pointer.2961, align 4
  %stack.offset.2963 = add i32 %stack.offset.2952, %field.extent.2962
  %context.field.2964 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2965 = load i32, ptr %context.field.2964, align 4
  %field.result.grows.2966 = icmp ugt i32 %stack.offset.2963, %context.value.2965
  br i1 %field.result.grows.2966, label %field.result.reserve.2967, label %field.result.existing.2968
field.result.reserve.2967:
  %reserve.status.2970 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2963, i32 64)
  %reserve.ok.2971 = icmp eq i32 %reserve.status.2970, 0
  br i1 %reserve.ok.2971, label %reserve.continue.2972, label %frame.failure.0
reserve.continue.2972:
  br label %field.result.ready.2969
field.result.existing.2968:
  br label %field.result.ready.2969
field.result.ready.2969:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.2952, i32 %field.offset.2958, i32 %field.extent.2962, i32 %field.payload.2960, i32 9, i32 7)
  %context.field.2973 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2974 = load i32, ptr %context.field.2973, align 4
  %runtime.ok.2975 = icmp eq i32 %context.value.2974, 0
  br i1 %runtime.ok.2975, label %runtime.continue.2976, label %frame.failure.0
runtime.continue.2976:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.2963, i32 0, i32 0, i32 0)
  %context.field.2977 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2978 = load i32, ptr %context.field.2977, align 4
  %runtime.ok.2979 = icmp eq i32 %context.value.2978, 0
  br i1 %runtime.ok.2979, label %runtime.continue.2980, label %frame.failure.0
runtime.continue.2980:
  %stack.sub.2981 = sub i32 %field.payload.2960, %local.source.payload.2835
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2981, i32 0)
  %context.field.2982 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2983 = load i32, ptr %context.field.2982, align 4
  %runtime.ok.2984 = icmp eq i32 %context.value.2983, 0
  br i1 %runtime.ok.2984, label %runtime.continue.2985, label %frame.failure.0
runtime.continue.2985:
  %local.is.active.2986 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.2987 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.2988 = select i1 %local.is.active.2986, i32 %local.sum.extent.2987, i32 0
  %stack.offset.2989 = add i32 0, %local.sum.selected.2988
  %local.is.active.2990 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.2991 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.2992 = select i1 %local.is.active.2990, i32 %local.sum.extent.2991, i32 0
  %stack.offset.2993 = add i32 %stack.offset.2989, %local.sum.selected.2992
  %local.is.active.2994 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.2995 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.2996 = select i1 %local.is.active.2994, i32 %local.sum.extent.2995, i32 0
  %stack.offset.2997 = add i32 %stack.offset.2993, %local.sum.selected.2996
  %local.is.active.2998 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.2999 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3000 = select i1 %local.is.active.2998, i32 %local.sum.extent.2999, i32 0
  %stack.offset.3001 = add i32 %stack.offset.2997, %local.sum.selected.3000
  %local.is.active.3002 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3003 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3004 = select i1 %local.is.active.3002, i32 %local.sum.extent.3003, i32 0
  %stack.offset.3005 = add i32 %stack.offset.3001, %local.sum.selected.3004
  %local.is.active.3006 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3007 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3008 = select i1 %local.is.active.3006, i32 %local.sum.extent.3007, i32 0
  %stack.offset.3009 = add i32 %stack.offset.3005, %local.sum.selected.3008
  %local.is.active.3010 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3011 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3012 = select i1 %local.is.active.3010, i32 %local.sum.extent.3011, i32 0
  %stack.offset.3013 = add i32 %stack.offset.3009, %local.sum.selected.3012
  %local.is.active.3014 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3015 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3016 = select i1 %local.is.active.3014, i32 %local.sum.extent.3015, i32 0
  %stack.offset.3017 = add i32 %stack.offset.3013, %local.sum.selected.3016
  %local.is.active.3018 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3019 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3020 = select i1 %local.is.active.3018, i32 %local.sum.extent.3019, i32 0
  %stack.offset.3021 = add i32 %stack.offset.3017, %local.sum.selected.3020
  %local.is.active.3022 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3023 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3024 = select i1 %local.is.active.3022, i32 %local.sum.extent.3023, i32 0
  %stack.offset.3025 = add i32 %stack.offset.3021, %local.sum.selected.3024
  %local.is.active.3026 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3027 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3028 = select i1 %local.is.active.3026, i32 %local.sum.extent.3027, i32 0
  %stack.offset.3029 = add i32 %stack.offset.3025, %local.sum.selected.3028
  %local.is.active.3030 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3031 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3032 = select i1 %local.is.active.3030, i32 %local.sum.extent.3031, i32 0
  %stack.offset.3033 = add i32 %stack.offset.3029, %local.sum.selected.3032
  %stack.offset.3034 = add i32 0, %field.extent.2962
  %stack.offset.3035 = add i32 %stack.offset.3033, %stack.offset.3034
  %stack.offset.3036 = add i32 %context.value.75, %stack.offset.3035
  %cursor.status.3037 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3036)
  %cursor.ok.3038 = icmp eq i32 %cursor.status.3037, 0
  br i1 %cursor.ok.3038, label %cursor.continue.3039, label %frame.failure.0
cursor.continue.3039:
  %step.status.3040 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %helper.ok.3041 = icmp eq i32 %step.status.3040, 0
  br i1 %helper.ok.3041, label %helper.continue.3042, label %frame.failure.0
helper.continue.3042:
  %local.is.active.3043 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3044 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3045 = select i1 %local.is.active.3043, i32 %local.sum.extent.3044, i32 0
  %stack.offset.3046 = add i32 0, %local.sum.selected.3045
  %local.is.active.3047 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3048 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3049 = select i1 %local.is.active.3047, i32 %local.sum.extent.3048, i32 0
  %stack.offset.3050 = add i32 %stack.offset.3046, %local.sum.selected.3049
  %local.is.active.3051 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3052 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3053 = select i1 %local.is.active.3051, i32 %local.sum.extent.3052, i32 0
  %stack.offset.3054 = add i32 %stack.offset.3050, %local.sum.selected.3053
  %local.is.active.3055 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3056 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3057 = select i1 %local.is.active.3055, i32 %local.sum.extent.3056, i32 0
  %stack.offset.3058 = add i32 %stack.offset.3054, %local.sum.selected.3057
  %local.is.active.3059 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3060 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3061 = select i1 %local.is.active.3059, i32 %local.sum.extent.3060, i32 0
  %stack.offset.3062 = add i32 %stack.offset.3058, %local.sum.selected.3061
  %local.is.active.3063 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3064 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3065 = select i1 %local.is.active.3063, i32 %local.sum.extent.3064, i32 0
  %stack.offset.3066 = add i32 %stack.offset.3062, %local.sum.selected.3065
  %local.is.active.3067 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3068 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3069 = select i1 %local.is.active.3067, i32 %local.sum.extent.3068, i32 0
  %stack.offset.3070 = add i32 %stack.offset.3066, %local.sum.selected.3069
  %local.is.active.3071 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3072 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3073 = select i1 %local.is.active.3071, i32 %local.sum.extent.3072, i32 0
  %stack.offset.3074 = add i32 %stack.offset.3070, %local.sum.selected.3073
  %local.is.active.3075 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3076 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3077 = select i1 %local.is.active.3075, i32 %local.sum.extent.3076, i32 0
  %stack.offset.3078 = add i32 %stack.offset.3074, %local.sum.selected.3077
  %local.is.active.3079 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3080 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3081 = select i1 %local.is.active.3079, i32 %local.sum.extent.3080, i32 0
  %stack.offset.3082 = add i32 %stack.offset.3078, %local.sum.selected.3081
  %local.is.active.3083 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3084 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3085 = select i1 %local.is.active.3083, i32 %local.sum.extent.3084, i32 0
  %stack.offset.3086 = add i32 %stack.offset.3082, %local.sum.selected.3085
  %local.is.active.3087 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3088 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3089 = select i1 %local.is.active.3087, i32 %local.sum.extent.3088, i32 0
  %stack.offset.3090 = add i32 %stack.offset.3086, %local.sum.selected.3089
  %stack.offset.3091 = add i32 %stack.offset.3090, 0
  %stack.offset.3092 = add i32 %context.value.75, %stack.offset.3091
  %field.location.3093 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.3094 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.3092, i32 %field.extent.2962, i32 0, i32 66, ptr %field.location.3093)
  %helper.ok.3095 = icmp eq i32 %field.location.status.3094, 0
  br i1 %helper.ok.3095, label %helper.continue.3096, label %frame.failure.0
helper.continue.3096:
  %field.offset.pointer.3097 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3093, i32 0, i32 0
  %field.offset.3098 = load i32, ptr %field.offset.pointer.3097, align 4
  %field.payload.pointer.3099 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3093, i32 0, i32 1
  %field.payload.3100 = load i32, ptr %field.payload.pointer.3099, align 4
  %field.extent.pointer.3101 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3093, i32 0, i32 2
  %field.extent.3102 = load i32, ptr %field.extent.pointer.3101, align 4
  %stack.offset.3103 = add i32 %stack.offset.3092, %field.extent.3102
  %context.field.3104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3105 = load i32, ptr %context.field.3104, align 4
  %field.result.grows.3106 = icmp ugt i32 %stack.offset.3103, %context.value.3105
  br i1 %field.result.grows.3106, label %field.result.reserve.3107, label %field.result.existing.3108
field.result.reserve.3107:
  %reserve.status.3110 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3103, i32 67)
  %reserve.ok.3111 = icmp eq i32 %reserve.status.3110, 0
  br i1 %reserve.ok.3111, label %reserve.continue.3112, label %frame.failure.0
reserve.continue.3112:
  br label %field.result.ready.3109
field.result.existing.3108:
  br label %field.result.ready.3109
field.result.ready.3109:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3092, i32 %field.offset.3098, i32 %field.extent.3102, i32 %field.payload.3100, i32 12, i32 7)
  %context.field.3113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3114 = load i32, ptr %context.field.3113, align 4
  %runtime.ok.3115 = icmp eq i32 %context.value.3114, 0
  br i1 %runtime.ok.3115, label %runtime.continue.3116, label %frame.failure.0
runtime.continue.3116:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.3103, i32 0, i32 0, i32 0)
  %context.field.3117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3118 = load i32, ptr %context.field.3117, align 4
  %runtime.ok.3119 = icmp eq i32 %context.value.3118, 0
  br i1 %runtime.ok.3119, label %runtime.continue.3120, label %frame.failure.0
runtime.continue.3120:
  %stack.sub.3121 = sub i32 %field.payload.3100, %field.payload.2960
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.3121, i32 0)
  %context.field.3122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3123 = load i32, ptr %context.field.3122, align 4
  %runtime.ok.3124 = icmp eq i32 %context.value.3123, 0
  br i1 %runtime.ok.3124, label %runtime.continue.3125, label %frame.failure.0
runtime.continue.3125:
  %local.is.active.3126 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3127 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3128 = select i1 %local.is.active.3126, i32 %local.sum.extent.3127, i32 0
  %stack.offset.3129 = add i32 0, %local.sum.selected.3128
  %local.is.active.3130 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3131 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3132 = select i1 %local.is.active.3130, i32 %local.sum.extent.3131, i32 0
  %stack.offset.3133 = add i32 %stack.offset.3129, %local.sum.selected.3132
  %local.is.active.3134 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3135 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3136 = select i1 %local.is.active.3134, i32 %local.sum.extent.3135, i32 0
  %stack.offset.3137 = add i32 %stack.offset.3133, %local.sum.selected.3136
  %local.is.active.3138 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3139 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3140 = select i1 %local.is.active.3138, i32 %local.sum.extent.3139, i32 0
  %stack.offset.3141 = add i32 %stack.offset.3137, %local.sum.selected.3140
  %local.is.active.3142 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3143 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3144 = select i1 %local.is.active.3142, i32 %local.sum.extent.3143, i32 0
  %stack.offset.3145 = add i32 %stack.offset.3141, %local.sum.selected.3144
  %local.is.active.3146 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3147 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3148 = select i1 %local.is.active.3146, i32 %local.sum.extent.3147, i32 0
  %stack.offset.3149 = add i32 %stack.offset.3145, %local.sum.selected.3148
  %local.is.active.3150 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3151 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3152 = select i1 %local.is.active.3150, i32 %local.sum.extent.3151, i32 0
  %stack.offset.3153 = add i32 %stack.offset.3149, %local.sum.selected.3152
  %local.is.active.3154 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3155 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3156 = select i1 %local.is.active.3154, i32 %local.sum.extent.3155, i32 0
  %stack.offset.3157 = add i32 %stack.offset.3153, %local.sum.selected.3156
  %local.is.active.3158 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3159 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3160 = select i1 %local.is.active.3158, i32 %local.sum.extent.3159, i32 0
  %stack.offset.3161 = add i32 %stack.offset.3157, %local.sum.selected.3160
  %local.is.active.3162 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3163 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3164 = select i1 %local.is.active.3162, i32 %local.sum.extent.3163, i32 0
  %stack.offset.3165 = add i32 %stack.offset.3161, %local.sum.selected.3164
  %local.is.active.3166 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3167 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3168 = select i1 %local.is.active.3166, i32 %local.sum.extent.3167, i32 0
  %stack.offset.3169 = add i32 %stack.offset.3165, %local.sum.selected.3168
  %local.is.active.3170 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3171 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3172 = select i1 %local.is.active.3170, i32 %local.sum.extent.3171, i32 0
  %stack.offset.3173 = add i32 %stack.offset.3169, %local.sum.selected.3172
  %stack.offset.3174 = add i32 0, %field.extent.3102
  %stack.offset.3175 = add i32 %stack.offset.3173, %stack.offset.3174
  %stack.offset.3176 = add i32 %context.value.75, %stack.offset.3175
  %cursor.status.3177 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3176)
  %cursor.ok.3178 = icmp eq i32 %cursor.status.3177, 0
  br i1 %cursor.ok.3178, label %cursor.continue.3179, label %frame.failure.0
cursor.continue.3179:
  %step.status.3180 = call i32 @al_owning_charge_step(ptr %ctx, i32 68)
  %helper.ok.3181 = icmp eq i32 %step.status.3180, 0
  br i1 %helper.ok.3181, label %helper.continue.3182, label %frame.failure.0
helper.continue.3182:
  %local.is.active.3183 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3184 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3185 = select i1 %local.is.active.3183, i32 %local.sum.extent.3184, i32 0
  %stack.offset.3186 = add i32 0, %local.sum.selected.3185
  %local.is.active.3187 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3188 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3189 = select i1 %local.is.active.3187, i32 %local.sum.extent.3188, i32 0
  %stack.offset.3190 = add i32 %stack.offset.3186, %local.sum.selected.3189
  %local.is.active.3191 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3192 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3193 = select i1 %local.is.active.3191, i32 %local.sum.extent.3192, i32 0
  %stack.offset.3194 = add i32 %stack.offset.3190, %local.sum.selected.3193
  %local.is.active.3195 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3196 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3197 = select i1 %local.is.active.3195, i32 %local.sum.extent.3196, i32 0
  %stack.offset.3198 = add i32 %stack.offset.3194, %local.sum.selected.3197
  %local.is.active.3199 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3200 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3201 = select i1 %local.is.active.3199, i32 %local.sum.extent.3200, i32 0
  %stack.offset.3202 = add i32 %stack.offset.3198, %local.sum.selected.3201
  %local.is.active.3203 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3204 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3205 = select i1 %local.is.active.3203, i32 %local.sum.extent.3204, i32 0
  %stack.offset.3206 = add i32 %stack.offset.3202, %local.sum.selected.3205
  %local.is.active.3207 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3208 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3209 = select i1 %local.is.active.3207, i32 %local.sum.extent.3208, i32 0
  %stack.offset.3210 = add i32 %stack.offset.3206, %local.sum.selected.3209
  %local.is.active.3211 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3212 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3213 = select i1 %local.is.active.3211, i32 %local.sum.extent.3212, i32 0
  %stack.offset.3214 = add i32 %stack.offset.3210, %local.sum.selected.3213
  %local.is.active.3215 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3216 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3217 = select i1 %local.is.active.3215, i32 %local.sum.extent.3216, i32 0
  %stack.offset.3218 = add i32 %stack.offset.3214, %local.sum.selected.3217
  %local.is.active.3219 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3220 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3221 = select i1 %local.is.active.3219, i32 %local.sum.extent.3220, i32 0
  %stack.offset.3222 = add i32 %stack.offset.3218, %local.sum.selected.3221
  %local.is.active.3223 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3224 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3225 = select i1 %local.is.active.3223, i32 %local.sum.extent.3224, i32 0
  %stack.offset.3226 = add i32 %stack.offset.3222, %local.sum.selected.3225
  %local.is.active.3227 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3228 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3229 = select i1 %local.is.active.3227, i32 %local.sum.extent.3228, i32 0
  %stack.offset.3230 = add i32 %stack.offset.3226, %local.sum.selected.3229
  %stack.offset.3231 = add i32 %stack.offset.3230, 0
  %stack.offset.3232 = add i32 %context.value.75, %stack.offset.3231
  %string.length.units.3233 = alloca i32, align 4
  %string.length.status.3234 = call i32 @al_owning_string_length(ptr %ctx, i32 %stack.offset.3232, i32 %field.extent.3102, i32 69, ptr %string.length.units.3233)
  %helper.ok.3235 = icmp eq i32 %string.length.status.3234, 0
  br i1 %helper.ok.3235, label %helper.continue.3236, label %frame.failure.0
helper.continue.3236:
  %string.length.value.3237 = load i32, ptr %string.length.units.3233, align 4
  %string.length.int.3238 = zext i32 %string.length.value.3237 to i64
  %context.field.3239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3240 = load i32, ptr %context.field.3239, align 4
  %stack.sub.3241 = sub i32 %context.value.3240, %field.extent.3102
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.3241, i32 %field.extent.3102, i32 %field.payload.3100, i32 12)
  %context.field.3242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3243 = load i32, ptr %context.field.3242, align 4
  %runtime.ok.3244 = icmp eq i32 %context.value.3243, 0
  br i1 %runtime.ok.3244, label %runtime.continue.3245, label %frame.failure.0
runtime.continue.3245:
  %context.field.3246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3247 = load i32, ptr %context.field.3246, align 4
  %stack.offset.3248 = add i32 %context.value.3247, 8
  %reserve.status.3249 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3248, i32 70)
  %reserve.ok.3250 = icmp eq i32 %reserve.status.3249, 0
  br i1 %reserve.ok.3250, label %reserve.continue.3251, label %frame.failure.0
reserve.continue.3251:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.3247, i64 %string.length.int.3238, i32 1)
  %context.field.3252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3253 = load i32, ptr %context.field.3252, align 4
  %runtime.ok.3254 = icmp eq i32 %context.value.3253, 0
  br i1 %runtime.ok.3254, label %runtime.continue.3255, label %frame.failure.0
runtime.continue.3255:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.3256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3257 = load i32, ptr %context.field.3256, align 4
  %runtime.ok.3258 = icmp eq i32 %context.value.3257, 0
  br i1 %runtime.ok.3258, label %runtime.continue.3259, label %frame.failure.0
runtime.continue.3259:
  %local.is.active.3260 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3261 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3262 = select i1 %local.is.active.3260, i32 %local.sum.extent.3261, i32 0
  %stack.offset.3263 = add i32 0, %local.sum.selected.3262
  %local.is.active.3264 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3265 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3266 = select i1 %local.is.active.3264, i32 %local.sum.extent.3265, i32 0
  %stack.offset.3267 = add i32 %stack.offset.3263, %local.sum.selected.3266
  %local.is.active.3268 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3269 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3270 = select i1 %local.is.active.3268, i32 %local.sum.extent.3269, i32 0
  %stack.offset.3271 = add i32 %stack.offset.3267, %local.sum.selected.3270
  %local.is.active.3272 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3273 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3274 = select i1 %local.is.active.3272, i32 %local.sum.extent.3273, i32 0
  %stack.offset.3275 = add i32 %stack.offset.3271, %local.sum.selected.3274
  %local.is.active.3276 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3277 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3278 = select i1 %local.is.active.3276, i32 %local.sum.extent.3277, i32 0
  %stack.offset.3279 = add i32 %stack.offset.3275, %local.sum.selected.3278
  %local.is.active.3280 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3281 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3282 = select i1 %local.is.active.3280, i32 %local.sum.extent.3281, i32 0
  %stack.offset.3283 = add i32 %stack.offset.3279, %local.sum.selected.3282
  %local.is.active.3284 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3285 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3286 = select i1 %local.is.active.3284, i32 %local.sum.extent.3285, i32 0
  %stack.offset.3287 = add i32 %stack.offset.3283, %local.sum.selected.3286
  %local.is.active.3288 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3289 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3290 = select i1 %local.is.active.3288, i32 %local.sum.extent.3289, i32 0
  %stack.offset.3291 = add i32 %stack.offset.3287, %local.sum.selected.3290
  %local.is.active.3292 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3293 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3294 = select i1 %local.is.active.3292, i32 %local.sum.extent.3293, i32 0
  %stack.offset.3295 = add i32 %stack.offset.3291, %local.sum.selected.3294
  %local.is.active.3296 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3297 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3298 = select i1 %local.is.active.3296, i32 %local.sum.extent.3297, i32 0
  %stack.offset.3299 = add i32 %stack.offset.3295, %local.sum.selected.3298
  %local.is.active.3300 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3301 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3302 = select i1 %local.is.active.3300, i32 %local.sum.extent.3301, i32 0
  %stack.offset.3303 = add i32 %stack.offset.3299, %local.sum.selected.3302
  %local.is.active.3304 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3305 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3306 = select i1 %local.is.active.3304, i32 %local.sum.extent.3305, i32 0
  %stack.offset.3307 = add i32 %stack.offset.3303, %local.sum.selected.3306
  %stack.offset.3308 = add i32 0, 8
  %stack.offset.3309 = add i32 %stack.offset.3307, %stack.offset.3308
  %stack.offset.3310 = add i32 %context.value.75, %stack.offset.3309
  %cursor.status.3311 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3310)
  %cursor.ok.3312 = icmp eq i32 %cursor.status.3311, 0
  br i1 %cursor.ok.3312, label %cursor.continue.3313, label %frame.failure.0
cursor.continue.3313:
  %step.status.3314 = call i32 @al_owning_charge_step(ptr %ctx, i32 71)
  %helper.ok.3315 = icmp eq i32 %step.status.3314, 0
  br i1 %helper.ok.3315, label %helper.continue.3316, label %frame.failure.0
helper.continue.3316:
  %local.is.active.3317 = load i1, ptr %local.active.33, align 1
  %local.previous.extent.3318 = load i32, ptr %local.extent.35, align 4
  %local.previous.payload.3319 = load i32, ptr %local.payload.36, align 4
  %local.old.extent.3320 = select i1 %local.is.active.3317, i32 %local.previous.extent.3318, i32 0
  %local.old.payload.3321 = select i1 %local.is.active.3317, i32 %local.previous.payload.3319, i32 0
  %local.is.active.3322 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3323 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3324 = select i1 %local.is.active.3322, i32 %local.sum.extent.3323, i32 0
  %stack.offset.3325 = add i32 0, %local.sum.selected.3324
  %local.is.active.3326 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3327 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3328 = select i1 %local.is.active.3326, i32 %local.sum.extent.3327, i32 0
  %stack.offset.3329 = add i32 %stack.offset.3325, %local.sum.selected.3328
  %local.is.active.3330 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3331 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3332 = select i1 %local.is.active.3330, i32 %local.sum.extent.3331, i32 0
  %stack.offset.3333 = add i32 %stack.offset.3329, %local.sum.selected.3332
  %local.is.active.3334 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3335 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3336 = select i1 %local.is.active.3334, i32 %local.sum.extent.3335, i32 0
  %stack.offset.3337 = add i32 %stack.offset.3333, %local.sum.selected.3336
  %local.is.active.3338 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3339 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3340 = select i1 %local.is.active.3338, i32 %local.sum.extent.3339, i32 0
  %stack.offset.3341 = add i32 %stack.offset.3337, %local.sum.selected.3340
  %local.is.active.3342 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3343 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3344 = select i1 %local.is.active.3342, i32 %local.sum.extent.3343, i32 0
  %stack.offset.3345 = add i32 %stack.offset.3341, %local.sum.selected.3344
  %stack.offset.3346 = add i32 %context.value.75, %stack.offset.3345
  %stack.offset.3347 = add i32 %stack.offset.3346, %local.old.extent.3320
  %context.field.3348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3349 = load i32, ptr %context.field.3348, align 4
  %stack.sub.3350 = sub i32 %context.value.3349, %stack.offset.3347
  %stack.sub.3351 = sub i32 %context.value.3349, %local.old.extent.3320
  %stack.offset.3352 = add i32 %stack.sub.3351, 8
  %local.grows.3353 = icmp ugt i32 8, %local.old.extent.3320
  br i1 %local.grows.3353, label %local.grow.3354, label %local.fixed.3355
local.grow.3354:
  %reserve.status.3357 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3352, i32 72)
  %reserve.ok.3358 = icmp eq i32 %reserve.status.3357, 0
  br i1 %reserve.ok.3358, label %reserve.continue.3359, label %frame.failure.0
reserve.continue.3359:
  %stack.sub.3360 = sub i32 8, %local.old.extent.3320
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.3360)
  %context.field.3361 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3362 = load i32, ptr %context.field.3361, align 4
  %runtime.ok.3363 = icmp eq i32 %context.value.3362, 0
  br i1 %runtime.ok.3363, label %runtime.continue.3364, label %frame.failure.0
runtime.continue.3364:
  br label %local.layout.ready.3356
local.fixed.3355:
  br label %local.layout.ready.3356
local.layout.ready.3356:
  %stack.offset.3365 = add i32 %stack.offset.3346, 8
  %local.is.active.3366 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.3367 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.3368 = select i1 %local.is.active.3366, i32 %local.suffix.payload.3367, i32 0
  %stack.offset.3369 = add i32 0, %local.suffix.selected.3368
  %local.is.active.3370 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.3371 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.3372 = select i1 %local.is.active.3370, i32 %local.suffix.payload.3371, i32 0
  %stack.offset.3373 = add i32 %stack.offset.3369, %local.suffix.selected.3372
  %local.is.active.3374 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.3375 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.3376 = select i1 %local.is.active.3374, i32 %local.suffix.payload.3375, i32 0
  %stack.offset.3377 = add i32 %stack.offset.3373, %local.suffix.selected.3376
  %local.is.active.3378 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.3379 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.3380 = select i1 %local.is.active.3378, i32 %local.suffix.payload.3379, i32 0
  %stack.offset.3381 = add i32 %stack.offset.3377, %local.suffix.selected.3380
  %local.is.active.3382 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.3383 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.3384 = select i1 %local.is.active.3382, i32 %local.suffix.payload.3383, i32 0
  %stack.offset.3385 = add i32 %stack.offset.3381, %local.suffix.selected.3384
  %stack.offset.3386 = add i32 0, 8
  %stack.offset.3387 = add i32 %stack.offset.3385, %stack.offset.3386
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3365, i32 %stack.offset.3347, i32 %stack.sub.3350, i32 %stack.offset.3387, i32 0, i32 14)
  %context.field.3388 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3389 = load i32, ptr %context.field.3388, align 4
  %runtime.ok.3390 = icmp eq i32 %context.value.3389, 0
  br i1 %runtime.ok.3390, label %runtime.continue.3391, label %frame.failure.0
runtime.continue.3391:
  %stack.sub.3392 = sub i32 %context.value.3349, 8
  %stack.sub.3393 = sub i32 %stack.sub.3392, %local.old.extent.3320
  %stack.offset.3394 = add i32 %stack.sub.3393, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3346, i32 %stack.offset.3394, i32 8, i32 8, i32 1, i32 4)
  %context.field.3395 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3396 = load i32, ptr %context.field.3395, align 4
  %runtime.ok.3397 = icmp eq i32 %context.value.3396, 0
  br i1 %runtime.ok.3397, label %runtime.continue.3398, label %frame.failure.0
runtime.continue.3398:
  %stack.sub.3399 = sub i32 %context.value.3349, %local.old.extent.3320
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.3399, i32 0, i32 0, i32 0)
  %context.field.3400 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3401 = load i32, ptr %context.field.3400, align 4
  %runtime.ok.3402 = icmp eq i32 %context.value.3401, 0
  br i1 %runtime.ok.3402, label %runtime.continue.3403, label %frame.failure.0
runtime.continue.3403:
  %local.shrinks.3404 = icmp ult i32 8, %local.old.extent.3320
  br i1 %local.shrinks.3404, label %local.shrink.3405, label %local.counts.ready.3406
local.shrink.3405:
  %stack.sub.3407 = sub i32 %local.old.extent.3320, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.3407)
  %context.field.3408 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3409 = load i32, ptr %context.field.3408, align 4
  %runtime.ok.3410 = icmp eq i32 %context.value.3409, 0
  br i1 %runtime.ok.3410, label %runtime.continue.3411, label %frame.failure.0
runtime.continue.3411:
  br label %local.counts.ready.3406
local.counts.ready.3406:
  %local.payload.delta.3412 = sub i32 8, %local.old.payload.3321
  %stack.sub.3413 = sub i32 0, %local.old.payload.3321
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.3413, i32 %local.payload.delta.3412)
  %context.field.3414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3415 = load i32, ptr %context.field.3414, align 4
  %runtime.ok.3416 = icmp eq i32 %context.value.3415, 0
  br i1 %runtime.ok.3416, label %runtime.continue.3417, label %frame.failure.0
runtime.continue.3417:
  %local.is.active.3418 = load i1, ptr %local.active.38, align 1
  %local.later.offset.3419 = load i32, ptr %local.offset.39, align 4
  %stack.sub.3420 = sub i32 %local.later.offset.3419, %local.old.extent.3320
  %stack.offset.3421 = add i32 %stack.sub.3420, 8
  %local.later.offset.selected.3422 = select i1 %local.is.active.3418, i32 %stack.offset.3421, i32 %local.later.offset.3419
  store i32 %local.later.offset.selected.3422, ptr %local.offset.39, align 4
  %local.is.active.3423 = load i1, ptr %local.active.43, align 1
  %local.later.offset.3424 = load i32, ptr %local.offset.44, align 4
  %stack.sub.3425 = sub i32 %local.later.offset.3424, %local.old.extent.3320
  %stack.offset.3426 = add i32 %stack.sub.3425, 8
  %local.later.offset.selected.3427 = select i1 %local.is.active.3423, i32 %stack.offset.3426, i32 %local.later.offset.3424
  store i32 %local.later.offset.selected.3427, ptr %local.offset.44, align 4
  %local.is.active.3428 = load i1, ptr %local.active.48, align 1
  %local.later.offset.3429 = load i32, ptr %local.offset.49, align 4
  %stack.sub.3430 = sub i32 %local.later.offset.3429, %local.old.extent.3320
  %stack.offset.3431 = add i32 %stack.sub.3430, 8
  %local.later.offset.selected.3432 = select i1 %local.is.active.3428, i32 %stack.offset.3431, i32 %local.later.offset.3429
  store i32 %local.later.offset.selected.3432, ptr %local.offset.49, align 4
  %local.is.active.3433 = load i1, ptr %local.active.53, align 1
  %local.later.offset.3434 = load i32, ptr %local.offset.54, align 4
  %stack.sub.3435 = sub i32 %local.later.offset.3434, %local.old.extent.3320
  %stack.offset.3436 = add i32 %stack.sub.3435, 8
  %local.later.offset.selected.3437 = select i1 %local.is.active.3433, i32 %stack.offset.3436, i32 %local.later.offset.3434
  store i32 %local.later.offset.selected.3437, ptr %local.offset.54, align 4
  %local.is.active.3438 = load i1, ptr %local.active.58, align 1
  %local.later.offset.3439 = load i32, ptr %local.offset.59, align 4
  %stack.sub.3440 = sub i32 %local.later.offset.3439, %local.old.extent.3320
  %stack.offset.3441 = add i32 %stack.sub.3440, 8
  %local.later.offset.selected.3442 = select i1 %local.is.active.3438, i32 %stack.offset.3441, i32 %local.later.offset.3439
  store i32 %local.later.offset.selected.3442, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.33, align 1
  store i32 %stack.offset.3346, ptr %local.offset.34, align 4
  store i32 8, ptr %local.extent.35, align 4
  store i32 8, ptr %local.payload.36, align 4
  store i32 1, ptr %local.type.37, align 4
  %local.is.active.3443 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3444 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3445 = select i1 %local.is.active.3443, i32 %local.sum.extent.3444, i32 0
  %stack.offset.3446 = add i32 0, %local.sum.selected.3445
  %local.is.active.3447 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3448 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3449 = select i1 %local.is.active.3447, i32 %local.sum.extent.3448, i32 0
  %stack.offset.3450 = add i32 %stack.offset.3446, %local.sum.selected.3449
  %local.is.active.3451 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3452 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3453 = select i1 %local.is.active.3451, i32 %local.sum.extent.3452, i32 0
  %stack.offset.3454 = add i32 %stack.offset.3450, %local.sum.selected.3453
  %local.is.active.3455 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3456 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3457 = select i1 %local.is.active.3455, i32 %local.sum.extent.3456, i32 0
  %stack.offset.3458 = add i32 %stack.offset.3454, %local.sum.selected.3457
  %local.is.active.3459 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3460 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3461 = select i1 %local.is.active.3459, i32 %local.sum.extent.3460, i32 0
  %stack.offset.3462 = add i32 %stack.offset.3458, %local.sum.selected.3461
  %local.is.active.3463 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3464 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3465 = select i1 %local.is.active.3463, i32 %local.sum.extent.3464, i32 0
  %stack.offset.3466 = add i32 %stack.offset.3462, %local.sum.selected.3465
  %local.is.active.3467 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3468 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3469 = select i1 %local.is.active.3467, i32 %local.sum.extent.3468, i32 0
  %stack.offset.3470 = add i32 %stack.offset.3466, %local.sum.selected.3469
  %local.is.active.3471 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3472 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3473 = select i1 %local.is.active.3471, i32 %local.sum.extent.3472, i32 0
  %stack.offset.3474 = add i32 %stack.offset.3470, %local.sum.selected.3473
  %local.is.active.3475 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3476 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3477 = select i1 %local.is.active.3475, i32 %local.sum.extent.3476, i32 0
  %stack.offset.3478 = add i32 %stack.offset.3474, %local.sum.selected.3477
  %local.is.active.3479 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3480 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3481 = select i1 %local.is.active.3479, i32 %local.sum.extent.3480, i32 0
  %stack.offset.3482 = add i32 %stack.offset.3478, %local.sum.selected.3481
  %local.is.active.3483 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3484 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3485 = select i1 %local.is.active.3483, i32 %local.sum.extent.3484, i32 0
  %stack.offset.3486 = add i32 %stack.offset.3482, %local.sum.selected.3485
  %local.is.active.3487 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3488 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3489 = select i1 %local.is.active.3487, i32 %local.sum.extent.3488, i32 0
  %stack.offset.3490 = add i32 %stack.offset.3486, %local.sum.selected.3489
  %stack.offset.3491 = add i32 %stack.offset.3490, 0
  %stack.offset.3492 = add i32 %context.value.75, %stack.offset.3491
  %cursor.status.3493 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3492)
  %cursor.ok.3494 = icmp eq i32 %cursor.status.3493, 0
  br i1 %cursor.ok.3494, label %cursor.continue.3495, label %frame.failure.0
cursor.continue.3495:
  %step.status.3496 = call i32 @al_owning_charge_step(ptr %ctx, i32 73)
  %helper.ok.3497 = icmp eq i32 %step.status.3496, 0
  br i1 %helper.ok.3497, label %helper.continue.3498, label %frame.failure.0
helper.continue.3498:
  store i1 false, ptr %local.active.43, align 1
  store i32 0, ptr %local.offset.44, align 4
  store i32 0, ptr %local.extent.45, align 4
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  store i1 false, ptr %local.active.48, align 1
  store i32 0, ptr %local.offset.49, align 4
  store i32 0, ptr %local.extent.50, align 4
  store i32 0, ptr %local.payload.51, align 4
  store i32 0, ptr %local.type.52, align 4
  %step.status.3499 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %helper.ok.3500 = icmp eq i32 %step.status.3499, 0
  br i1 %helper.ok.3500, label %helper.continue.3501, label %frame.failure.0
helper.continue.3501:
  %local.source.offset.3502 = load i32, ptr %local.offset.29, align 4
  %local.source.extent.3503 = load i32, ptr %local.extent.30, align 4
  %local.source.payload.3504 = load i32, ptr %local.payload.31, align 4
  %context.field.3505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3506 = load i32, ptr %context.field.3505, align 4
  %stack.offset.3507 = add i32 %context.value.3506, %local.source.extent.3503
  %reserve.status.3508 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3507, i32 75)
  %reserve.ok.3509 = icmp eq i32 %reserve.status.3508, 0
  br i1 %reserve.ok.3509, label %reserve.continue.3510, label %frame.failure.0
reserve.continue.3510:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.3506, i32 %local.source.offset.3502, i32 %local.source.extent.3503, i32 %local.source.payload.3504, i32 12)
  %context.field.3511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3512 = load i32, ptr %context.field.3511, align 4
  %runtime.ok.3513 = icmp eq i32 %context.value.3512, 0
  br i1 %runtime.ok.3513, label %runtime.continue.3514, label %frame.failure.0
runtime.continue.3514:
  %local.is.active.3515 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3516 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3517 = select i1 %local.is.active.3515, i32 %local.sum.extent.3516, i32 0
  %stack.offset.3518 = add i32 0, %local.sum.selected.3517
  %local.is.active.3519 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3520 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3521 = select i1 %local.is.active.3519, i32 %local.sum.extent.3520, i32 0
  %stack.offset.3522 = add i32 %stack.offset.3518, %local.sum.selected.3521
  %local.is.active.3523 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3524 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3525 = select i1 %local.is.active.3523, i32 %local.sum.extent.3524, i32 0
  %stack.offset.3526 = add i32 %stack.offset.3522, %local.sum.selected.3525
  %local.is.active.3527 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3528 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3529 = select i1 %local.is.active.3527, i32 %local.sum.extent.3528, i32 0
  %stack.offset.3530 = add i32 %stack.offset.3526, %local.sum.selected.3529
  %local.is.active.3531 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3532 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3533 = select i1 %local.is.active.3531, i32 %local.sum.extent.3532, i32 0
  %stack.offset.3534 = add i32 %stack.offset.3530, %local.sum.selected.3533
  %local.is.active.3535 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3536 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3537 = select i1 %local.is.active.3535, i32 %local.sum.extent.3536, i32 0
  %stack.offset.3538 = add i32 %stack.offset.3534, %local.sum.selected.3537
  %local.is.active.3539 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3540 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3541 = select i1 %local.is.active.3539, i32 %local.sum.extent.3540, i32 0
  %stack.offset.3542 = add i32 %stack.offset.3538, %local.sum.selected.3541
  %local.is.active.3543 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3544 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3545 = select i1 %local.is.active.3543, i32 %local.sum.extent.3544, i32 0
  %stack.offset.3546 = add i32 %stack.offset.3542, %local.sum.selected.3545
  %local.is.active.3547 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3548 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3549 = select i1 %local.is.active.3547, i32 %local.sum.extent.3548, i32 0
  %stack.offset.3550 = add i32 %stack.offset.3546, %local.sum.selected.3549
  %local.is.active.3551 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3552 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3553 = select i1 %local.is.active.3551, i32 %local.sum.extent.3552, i32 0
  %stack.offset.3554 = add i32 %stack.offset.3550, %local.sum.selected.3553
  %local.is.active.3555 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3556 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3557 = select i1 %local.is.active.3555, i32 %local.sum.extent.3556, i32 0
  %stack.offset.3558 = add i32 %stack.offset.3554, %local.sum.selected.3557
  %local.is.active.3559 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3560 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3561 = select i1 %local.is.active.3559, i32 %local.sum.extent.3560, i32 0
  %stack.offset.3562 = add i32 %stack.offset.3558, %local.sum.selected.3561
  %stack.offset.3563 = add i32 0, %local.source.extent.3503
  %stack.offset.3564 = add i32 %stack.offset.3562, %stack.offset.3563
  %stack.offset.3565 = add i32 %context.value.75, %stack.offset.3564
  %cursor.status.3566 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3565)
  %cursor.ok.3567 = icmp eq i32 %cursor.status.3566, 0
  br i1 %cursor.ok.3567, label %cursor.continue.3568, label %frame.failure.0
cursor.continue.3568:
  %step.status.3569 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %helper.ok.3570 = icmp eq i32 %step.status.3569, 0
  br i1 %helper.ok.3570, label %helper.continue.3571, label %frame.failure.0
helper.continue.3571:
  %local.is.active.3572 = load i1, ptr %local.active.43, align 1
  %local.previous.extent.3573 = load i32, ptr %local.extent.45, align 4
  %local.previous.payload.3574 = load i32, ptr %local.payload.46, align 4
  %local.old.extent.3575 = select i1 %local.is.active.3572, i32 %local.previous.extent.3573, i32 0
  %local.old.payload.3576 = select i1 %local.is.active.3572, i32 %local.previous.payload.3574, i32 0
  %local.is.active.3577 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3578 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3579 = select i1 %local.is.active.3577, i32 %local.sum.extent.3578, i32 0
  %stack.offset.3580 = add i32 0, %local.sum.selected.3579
  %local.is.active.3581 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3582 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3583 = select i1 %local.is.active.3581, i32 %local.sum.extent.3582, i32 0
  %stack.offset.3584 = add i32 %stack.offset.3580, %local.sum.selected.3583
  %local.is.active.3585 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3586 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3587 = select i1 %local.is.active.3585, i32 %local.sum.extent.3586, i32 0
  %stack.offset.3588 = add i32 %stack.offset.3584, %local.sum.selected.3587
  %local.is.active.3589 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3590 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3591 = select i1 %local.is.active.3589, i32 %local.sum.extent.3590, i32 0
  %stack.offset.3592 = add i32 %stack.offset.3588, %local.sum.selected.3591
  %local.is.active.3593 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3594 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3595 = select i1 %local.is.active.3593, i32 %local.sum.extent.3594, i32 0
  %stack.offset.3596 = add i32 %stack.offset.3592, %local.sum.selected.3595
  %local.is.active.3597 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3598 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3599 = select i1 %local.is.active.3597, i32 %local.sum.extent.3598, i32 0
  %stack.offset.3600 = add i32 %stack.offset.3596, %local.sum.selected.3599
  %local.is.active.3601 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3602 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3603 = select i1 %local.is.active.3601, i32 %local.sum.extent.3602, i32 0
  %stack.offset.3604 = add i32 %stack.offset.3600, %local.sum.selected.3603
  %local.is.active.3605 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3606 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3607 = select i1 %local.is.active.3605, i32 %local.sum.extent.3606, i32 0
  %stack.offset.3608 = add i32 %stack.offset.3604, %local.sum.selected.3607
  %stack.offset.3609 = add i32 %context.value.75, %stack.offset.3608
  %stack.offset.3610 = add i32 %stack.offset.3609, %local.old.extent.3575
  %context.field.3611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3612 = load i32, ptr %context.field.3611, align 4
  %stack.sub.3613 = sub i32 %context.value.3612, %stack.offset.3610
  %stack.sub.3614 = sub i32 %context.value.3612, %local.old.extent.3575
  %stack.offset.3615 = add i32 %stack.sub.3614, %local.source.extent.3503
  %local.grows.3616 = icmp ugt i32 %local.source.extent.3503, %local.old.extent.3575
  br i1 %local.grows.3616, label %local.grow.3617, label %local.fixed.3618
local.grow.3617:
  %reserve.status.3620 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3615, i32 77)
  %reserve.ok.3621 = icmp eq i32 %reserve.status.3620, 0
  br i1 %reserve.ok.3621, label %reserve.continue.3622, label %frame.failure.0
reserve.continue.3622:
  %stack.sub.3623 = sub i32 %local.source.extent.3503, %local.old.extent.3575
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.3623)
  %context.field.3624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3625 = load i32, ptr %context.field.3624, align 4
  %runtime.ok.3626 = icmp eq i32 %context.value.3625, 0
  br i1 %runtime.ok.3626, label %runtime.continue.3627, label %frame.failure.0
runtime.continue.3627:
  br label %local.layout.ready.3619
local.fixed.3618:
  br label %local.layout.ready.3619
local.layout.ready.3619:
  %stack.offset.3628 = add i32 %stack.offset.3609, %local.source.extent.3503
  %local.is.active.3629 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.3630 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.3631 = select i1 %local.is.active.3629, i32 %local.suffix.payload.3630, i32 0
  %stack.offset.3632 = add i32 0, %local.suffix.selected.3631
  %local.is.active.3633 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.3634 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.3635 = select i1 %local.is.active.3633, i32 %local.suffix.payload.3634, i32 0
  %stack.offset.3636 = add i32 %stack.offset.3632, %local.suffix.selected.3635
  %local.is.active.3637 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.3638 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.3639 = select i1 %local.is.active.3637, i32 %local.suffix.payload.3638, i32 0
  %stack.offset.3640 = add i32 %stack.offset.3636, %local.suffix.selected.3639
  %stack.offset.3641 = add i32 0, %local.source.payload.3504
  %stack.offset.3642 = add i32 %stack.offset.3640, %stack.offset.3641
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3628, i32 %stack.offset.3610, i32 %stack.sub.3613, i32 %stack.offset.3642, i32 0, i32 14)
  %context.field.3643 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3644 = load i32, ptr %context.field.3643, align 4
  %runtime.ok.3645 = icmp eq i32 %context.value.3644, 0
  br i1 %runtime.ok.3645, label %runtime.continue.3646, label %frame.failure.0
runtime.continue.3646:
  %stack.sub.3647 = sub i32 %context.value.3612, %local.source.extent.3503
  %stack.sub.3648 = sub i32 %stack.sub.3647, %local.old.extent.3575
  %stack.offset.3649 = add i32 %stack.sub.3648, %local.source.extent.3503
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3609, i32 %stack.offset.3649, i32 %local.source.extent.3503, i32 %local.source.payload.3504, i32 12, i32 4)
  %context.field.3650 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3651 = load i32, ptr %context.field.3650, align 4
  %runtime.ok.3652 = icmp eq i32 %context.value.3651, 0
  br i1 %runtime.ok.3652, label %runtime.continue.3653, label %frame.failure.0
runtime.continue.3653:
  %stack.sub.3654 = sub i32 %context.value.3612, %local.old.extent.3575
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.3654, i32 0, i32 0, i32 0)
  %context.field.3655 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3656 = load i32, ptr %context.field.3655, align 4
  %runtime.ok.3657 = icmp eq i32 %context.value.3656, 0
  br i1 %runtime.ok.3657, label %runtime.continue.3658, label %frame.failure.0
runtime.continue.3658:
  %local.shrinks.3659 = icmp ult i32 %local.source.extent.3503, %local.old.extent.3575
  br i1 %local.shrinks.3659, label %local.shrink.3660, label %local.counts.ready.3661
local.shrink.3660:
  %stack.sub.3662 = sub i32 %local.old.extent.3575, %local.source.extent.3503
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.3662)
  %context.field.3663 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3664 = load i32, ptr %context.field.3663, align 4
  %runtime.ok.3665 = icmp eq i32 %context.value.3664, 0
  br i1 %runtime.ok.3665, label %runtime.continue.3666, label %frame.failure.0
runtime.continue.3666:
  br label %local.counts.ready.3661
local.counts.ready.3661:
  %local.payload.delta.3667 = sub i32 %local.source.payload.3504, %local.old.payload.3576
  %stack.sub.3668 = sub i32 0, %local.old.payload.3576
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.3668, i32 %local.payload.delta.3667)
  %context.field.3669 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3670 = load i32, ptr %context.field.3669, align 4
  %runtime.ok.3671 = icmp eq i32 %context.value.3670, 0
  br i1 %runtime.ok.3671, label %runtime.continue.3672, label %frame.failure.0
runtime.continue.3672:
  %local.is.active.3673 = load i1, ptr %local.active.48, align 1
  %local.later.offset.3674 = load i32, ptr %local.offset.49, align 4
  %stack.sub.3675 = sub i32 %local.later.offset.3674, %local.old.extent.3575
  %stack.offset.3676 = add i32 %stack.sub.3675, %local.source.extent.3503
  %local.later.offset.selected.3677 = select i1 %local.is.active.3673, i32 %stack.offset.3676, i32 %local.later.offset.3674
  store i32 %local.later.offset.selected.3677, ptr %local.offset.49, align 4
  %local.is.active.3678 = load i1, ptr %local.active.53, align 1
  %local.later.offset.3679 = load i32, ptr %local.offset.54, align 4
  %stack.sub.3680 = sub i32 %local.later.offset.3679, %local.old.extent.3575
  %stack.offset.3681 = add i32 %stack.sub.3680, %local.source.extent.3503
  %local.later.offset.selected.3682 = select i1 %local.is.active.3678, i32 %stack.offset.3681, i32 %local.later.offset.3679
  store i32 %local.later.offset.selected.3682, ptr %local.offset.54, align 4
  %local.is.active.3683 = load i1, ptr %local.active.58, align 1
  %local.later.offset.3684 = load i32, ptr %local.offset.59, align 4
  %stack.sub.3685 = sub i32 %local.later.offset.3684, %local.old.extent.3575
  %stack.offset.3686 = add i32 %stack.sub.3685, %local.source.extent.3503
  %local.later.offset.selected.3687 = select i1 %local.is.active.3683, i32 %stack.offset.3686, i32 %local.later.offset.3684
  store i32 %local.later.offset.selected.3687, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.43, align 1
  store i32 %stack.offset.3609, ptr %local.offset.44, align 4
  store i32 %local.source.extent.3503, ptr %local.extent.45, align 4
  store i32 %local.source.payload.3504, ptr %local.payload.46, align 4
  store i32 12, ptr %local.type.47, align 4
  %local.is.active.3688 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3689 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3690 = select i1 %local.is.active.3688, i32 %local.sum.extent.3689, i32 0
  %stack.offset.3691 = add i32 0, %local.sum.selected.3690
  %local.is.active.3692 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3693 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3694 = select i1 %local.is.active.3692, i32 %local.sum.extent.3693, i32 0
  %stack.offset.3695 = add i32 %stack.offset.3691, %local.sum.selected.3694
  %local.is.active.3696 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3697 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3698 = select i1 %local.is.active.3696, i32 %local.sum.extent.3697, i32 0
  %stack.offset.3699 = add i32 %stack.offset.3695, %local.sum.selected.3698
  %local.is.active.3700 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3701 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3702 = select i1 %local.is.active.3700, i32 %local.sum.extent.3701, i32 0
  %stack.offset.3703 = add i32 %stack.offset.3699, %local.sum.selected.3702
  %local.is.active.3704 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3705 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3706 = select i1 %local.is.active.3704, i32 %local.sum.extent.3705, i32 0
  %stack.offset.3707 = add i32 %stack.offset.3703, %local.sum.selected.3706
  %local.is.active.3708 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3709 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3710 = select i1 %local.is.active.3708, i32 %local.sum.extent.3709, i32 0
  %stack.offset.3711 = add i32 %stack.offset.3707, %local.sum.selected.3710
  %local.is.active.3712 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3713 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3714 = select i1 %local.is.active.3712, i32 %local.sum.extent.3713, i32 0
  %stack.offset.3715 = add i32 %stack.offset.3711, %local.sum.selected.3714
  %local.is.active.3716 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3717 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3718 = select i1 %local.is.active.3716, i32 %local.sum.extent.3717, i32 0
  %stack.offset.3719 = add i32 %stack.offset.3715, %local.sum.selected.3718
  %local.is.active.3720 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3721 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3722 = select i1 %local.is.active.3720, i32 %local.sum.extent.3721, i32 0
  %stack.offset.3723 = add i32 %stack.offset.3719, %local.sum.selected.3722
  %local.is.active.3724 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3725 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3726 = select i1 %local.is.active.3724, i32 %local.sum.extent.3725, i32 0
  %stack.offset.3727 = add i32 %stack.offset.3723, %local.sum.selected.3726
  %local.is.active.3728 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3729 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3730 = select i1 %local.is.active.3728, i32 %local.sum.extent.3729, i32 0
  %stack.offset.3731 = add i32 %stack.offset.3727, %local.sum.selected.3730
  %local.is.active.3732 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3733 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3734 = select i1 %local.is.active.3732, i32 %local.sum.extent.3733, i32 0
  %stack.offset.3735 = add i32 %stack.offset.3731, %local.sum.selected.3734
  %stack.offset.3736 = add i32 %stack.offset.3735, 0
  %stack.offset.3737 = add i32 %context.value.75, %stack.offset.3736
  %cursor.status.3738 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3737)
  %cursor.ok.3739 = icmp eq i32 %cursor.status.3738, 0
  br i1 %cursor.ok.3739, label %cursor.continue.3740, label %frame.failure.0
cursor.continue.3740:
  %step.status.3741 = call i32 @al_owning_charge_step(ptr %ctx, i32 78)
  %helper.ok.3742 = icmp eq i32 %step.status.3741, 0
  br i1 %helper.ok.3742, label %helper.continue.3743, label %frame.failure.0
helper.continue.3743:
  %local.source.offset.3744 = load i32, ptr %local.offset.34, align 4
  %local.source.extent.3745 = load i32, ptr %local.extent.35, align 4
  %local.source.payload.3746 = load i32, ptr %local.payload.36, align 4
  %context.field.3747 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3748 = load i32, ptr %context.field.3747, align 4
  %stack.offset.3749 = add i32 %context.value.3748, %local.source.extent.3745
  %reserve.status.3750 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3749, i32 79)
  %reserve.ok.3751 = icmp eq i32 %reserve.status.3750, 0
  br i1 %reserve.ok.3751, label %reserve.continue.3752, label %frame.failure.0
reserve.continue.3752:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.3748, i32 %local.source.offset.3744, i32 %local.source.extent.3745, i32 %local.source.payload.3746, i32 1)
  %context.field.3753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3754 = load i32, ptr %context.field.3753, align 4
  %runtime.ok.3755 = icmp eq i32 %context.value.3754, 0
  br i1 %runtime.ok.3755, label %runtime.continue.3756, label %frame.failure.0
runtime.continue.3756:
  %local.is.active.3757 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3758 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3759 = select i1 %local.is.active.3757, i32 %local.sum.extent.3758, i32 0
  %stack.offset.3760 = add i32 0, %local.sum.selected.3759
  %local.is.active.3761 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3762 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3763 = select i1 %local.is.active.3761, i32 %local.sum.extent.3762, i32 0
  %stack.offset.3764 = add i32 %stack.offset.3760, %local.sum.selected.3763
  %local.is.active.3765 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3766 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3767 = select i1 %local.is.active.3765, i32 %local.sum.extent.3766, i32 0
  %stack.offset.3768 = add i32 %stack.offset.3764, %local.sum.selected.3767
  %local.is.active.3769 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3770 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3771 = select i1 %local.is.active.3769, i32 %local.sum.extent.3770, i32 0
  %stack.offset.3772 = add i32 %stack.offset.3768, %local.sum.selected.3771
  %local.is.active.3773 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3774 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3775 = select i1 %local.is.active.3773, i32 %local.sum.extent.3774, i32 0
  %stack.offset.3776 = add i32 %stack.offset.3772, %local.sum.selected.3775
  %local.is.active.3777 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3778 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3779 = select i1 %local.is.active.3777, i32 %local.sum.extent.3778, i32 0
  %stack.offset.3780 = add i32 %stack.offset.3776, %local.sum.selected.3779
  %local.is.active.3781 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3782 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3783 = select i1 %local.is.active.3781, i32 %local.sum.extent.3782, i32 0
  %stack.offset.3784 = add i32 %stack.offset.3780, %local.sum.selected.3783
  %local.is.active.3785 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3786 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3787 = select i1 %local.is.active.3785, i32 %local.sum.extent.3786, i32 0
  %stack.offset.3788 = add i32 %stack.offset.3784, %local.sum.selected.3787
  %local.is.active.3789 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3790 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3791 = select i1 %local.is.active.3789, i32 %local.sum.extent.3790, i32 0
  %stack.offset.3792 = add i32 %stack.offset.3788, %local.sum.selected.3791
  %local.is.active.3793 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3794 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3795 = select i1 %local.is.active.3793, i32 %local.sum.extent.3794, i32 0
  %stack.offset.3796 = add i32 %stack.offset.3792, %local.sum.selected.3795
  %local.is.active.3797 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3798 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3799 = select i1 %local.is.active.3797, i32 %local.sum.extent.3798, i32 0
  %stack.offset.3800 = add i32 %stack.offset.3796, %local.sum.selected.3799
  %local.is.active.3801 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3802 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3803 = select i1 %local.is.active.3801, i32 %local.sum.extent.3802, i32 0
  %stack.offset.3804 = add i32 %stack.offset.3800, %local.sum.selected.3803
  %stack.offset.3805 = add i32 0, %local.source.extent.3745
  %stack.offset.3806 = add i32 %stack.offset.3804, %stack.offset.3805
  %stack.offset.3807 = add i32 %context.value.75, %stack.offset.3806
  %cursor.status.3808 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3807)
  %cursor.ok.3809 = icmp eq i32 %cursor.status.3808, 0
  br i1 %cursor.ok.3809, label %cursor.continue.3810, label %frame.failure.0
cursor.continue.3810:
  %step.status.3811 = call i32 @al_owning_charge_step(ptr %ctx, i32 80)
  %helper.ok.3812 = icmp eq i32 %step.status.3811, 0
  br i1 %helper.ok.3812, label %helper.continue.3813, label %frame.failure.0
helper.continue.3813:
  %local.is.active.3814 = load i1, ptr %local.active.48, align 1
  %local.previous.extent.3815 = load i32, ptr %local.extent.50, align 4
  %local.previous.payload.3816 = load i32, ptr %local.payload.51, align 4
  %local.old.extent.3817 = select i1 %local.is.active.3814, i32 %local.previous.extent.3815, i32 0
  %local.old.payload.3818 = select i1 %local.is.active.3814, i32 %local.previous.payload.3816, i32 0
  %local.is.active.3819 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3820 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3821 = select i1 %local.is.active.3819, i32 %local.sum.extent.3820, i32 0
  %stack.offset.3822 = add i32 0, %local.sum.selected.3821
  %local.is.active.3823 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3824 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3825 = select i1 %local.is.active.3823, i32 %local.sum.extent.3824, i32 0
  %stack.offset.3826 = add i32 %stack.offset.3822, %local.sum.selected.3825
  %local.is.active.3827 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3828 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3829 = select i1 %local.is.active.3827, i32 %local.sum.extent.3828, i32 0
  %stack.offset.3830 = add i32 %stack.offset.3826, %local.sum.selected.3829
  %local.is.active.3831 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3832 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3833 = select i1 %local.is.active.3831, i32 %local.sum.extent.3832, i32 0
  %stack.offset.3834 = add i32 %stack.offset.3830, %local.sum.selected.3833
  %local.is.active.3835 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3836 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3837 = select i1 %local.is.active.3835, i32 %local.sum.extent.3836, i32 0
  %stack.offset.3838 = add i32 %stack.offset.3834, %local.sum.selected.3837
  %local.is.active.3839 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3840 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3841 = select i1 %local.is.active.3839, i32 %local.sum.extent.3840, i32 0
  %stack.offset.3842 = add i32 %stack.offset.3838, %local.sum.selected.3841
  %local.is.active.3843 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3844 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3845 = select i1 %local.is.active.3843, i32 %local.sum.extent.3844, i32 0
  %stack.offset.3846 = add i32 %stack.offset.3842, %local.sum.selected.3845
  %local.is.active.3847 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3848 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3849 = select i1 %local.is.active.3847, i32 %local.sum.extent.3848, i32 0
  %stack.offset.3850 = add i32 %stack.offset.3846, %local.sum.selected.3849
  %local.is.active.3851 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3852 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3853 = select i1 %local.is.active.3851, i32 %local.sum.extent.3852, i32 0
  %stack.offset.3854 = add i32 %stack.offset.3850, %local.sum.selected.3853
  %stack.offset.3855 = add i32 %context.value.75, %stack.offset.3854
  %stack.offset.3856 = add i32 %stack.offset.3855, %local.old.extent.3817
  %context.field.3857 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3858 = load i32, ptr %context.field.3857, align 4
  %stack.sub.3859 = sub i32 %context.value.3858, %stack.offset.3856
  %stack.sub.3860 = sub i32 %context.value.3858, %local.old.extent.3817
  %stack.offset.3861 = add i32 %stack.sub.3860, %local.source.extent.3745
  %local.grows.3862 = icmp ugt i32 %local.source.extent.3745, %local.old.extent.3817
  br i1 %local.grows.3862, label %local.grow.3863, label %local.fixed.3864
local.grow.3863:
  %reserve.status.3866 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3861, i32 81)
  %reserve.ok.3867 = icmp eq i32 %reserve.status.3866, 0
  br i1 %reserve.ok.3867, label %reserve.continue.3868, label %frame.failure.0
reserve.continue.3868:
  %stack.sub.3869 = sub i32 %local.source.extent.3745, %local.old.extent.3817
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.3869)
  %context.field.3870 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3871 = load i32, ptr %context.field.3870, align 4
  %runtime.ok.3872 = icmp eq i32 %context.value.3871, 0
  br i1 %runtime.ok.3872, label %runtime.continue.3873, label %frame.failure.0
runtime.continue.3873:
  br label %local.layout.ready.3865
local.fixed.3864:
  br label %local.layout.ready.3865
local.layout.ready.3865:
  %stack.offset.3874 = add i32 %stack.offset.3855, %local.source.extent.3745
  %local.is.active.3875 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.3876 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.3877 = select i1 %local.is.active.3875, i32 %local.suffix.payload.3876, i32 0
  %stack.offset.3878 = add i32 0, %local.suffix.selected.3877
  %local.is.active.3879 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.3880 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.3881 = select i1 %local.is.active.3879, i32 %local.suffix.payload.3880, i32 0
  %stack.offset.3882 = add i32 %stack.offset.3878, %local.suffix.selected.3881
  %stack.offset.3883 = add i32 0, %local.source.payload.3746
  %stack.offset.3884 = add i32 %stack.offset.3882, %stack.offset.3883
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3874, i32 %stack.offset.3856, i32 %stack.sub.3859, i32 %stack.offset.3884, i32 0, i32 14)
  %context.field.3885 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3886 = load i32, ptr %context.field.3885, align 4
  %runtime.ok.3887 = icmp eq i32 %context.value.3886, 0
  br i1 %runtime.ok.3887, label %runtime.continue.3888, label %frame.failure.0
runtime.continue.3888:
  %stack.sub.3889 = sub i32 %context.value.3858, %local.source.extent.3745
  %stack.sub.3890 = sub i32 %stack.sub.3889, %local.old.extent.3817
  %stack.offset.3891 = add i32 %stack.sub.3890, %local.source.extent.3745
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.3855, i32 %stack.offset.3891, i32 %local.source.extent.3745, i32 %local.source.payload.3746, i32 1, i32 4)
  %context.field.3892 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3893 = load i32, ptr %context.field.3892, align 4
  %runtime.ok.3894 = icmp eq i32 %context.value.3893, 0
  br i1 %runtime.ok.3894, label %runtime.continue.3895, label %frame.failure.0
runtime.continue.3895:
  %stack.sub.3896 = sub i32 %context.value.3858, %local.old.extent.3817
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.3896, i32 0, i32 0, i32 0)
  %context.field.3897 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3898 = load i32, ptr %context.field.3897, align 4
  %runtime.ok.3899 = icmp eq i32 %context.value.3898, 0
  br i1 %runtime.ok.3899, label %runtime.continue.3900, label %frame.failure.0
runtime.continue.3900:
  %local.shrinks.3901 = icmp ult i32 %local.source.extent.3745, %local.old.extent.3817
  br i1 %local.shrinks.3901, label %local.shrink.3902, label %local.counts.ready.3903
local.shrink.3902:
  %stack.sub.3904 = sub i32 %local.old.extent.3817, %local.source.extent.3745
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.3904)
  %context.field.3905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3906 = load i32, ptr %context.field.3905, align 4
  %runtime.ok.3907 = icmp eq i32 %context.value.3906, 0
  br i1 %runtime.ok.3907, label %runtime.continue.3908, label %frame.failure.0
runtime.continue.3908:
  br label %local.counts.ready.3903
local.counts.ready.3903:
  %local.payload.delta.3909 = sub i32 %local.source.payload.3746, %local.old.payload.3818
  %stack.sub.3910 = sub i32 0, %local.old.payload.3818
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.3910, i32 %local.payload.delta.3909)
  %context.field.3911 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3912 = load i32, ptr %context.field.3911, align 4
  %runtime.ok.3913 = icmp eq i32 %context.value.3912, 0
  br i1 %runtime.ok.3913, label %runtime.continue.3914, label %frame.failure.0
runtime.continue.3914:
  %local.is.active.3915 = load i1, ptr %local.active.53, align 1
  %local.later.offset.3916 = load i32, ptr %local.offset.54, align 4
  %stack.sub.3917 = sub i32 %local.later.offset.3916, %local.old.extent.3817
  %stack.offset.3918 = add i32 %stack.sub.3917, %local.source.extent.3745
  %local.later.offset.selected.3919 = select i1 %local.is.active.3915, i32 %stack.offset.3918, i32 %local.later.offset.3916
  store i32 %local.later.offset.selected.3919, ptr %local.offset.54, align 4
  %local.is.active.3920 = load i1, ptr %local.active.58, align 1
  %local.later.offset.3921 = load i32, ptr %local.offset.59, align 4
  %stack.sub.3922 = sub i32 %local.later.offset.3921, %local.old.extent.3817
  %stack.offset.3923 = add i32 %stack.sub.3922, %local.source.extent.3745
  %local.later.offset.selected.3924 = select i1 %local.is.active.3920, i32 %stack.offset.3923, i32 %local.later.offset.3921
  store i32 %local.later.offset.selected.3924, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.48, align 1
  store i32 %stack.offset.3855, ptr %local.offset.49, align 4
  store i32 %local.source.extent.3745, ptr %local.extent.50, align 4
  store i32 %local.source.payload.3746, ptr %local.payload.51, align 4
  store i32 1, ptr %local.type.52, align 4
  %local.is.active.3925 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3926 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3927 = select i1 %local.is.active.3925, i32 %local.sum.extent.3926, i32 0
  %stack.offset.3928 = add i32 0, %local.sum.selected.3927
  %local.is.active.3929 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3930 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.3931 = select i1 %local.is.active.3929, i32 %local.sum.extent.3930, i32 0
  %stack.offset.3932 = add i32 %stack.offset.3928, %local.sum.selected.3931
  %local.is.active.3933 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.3934 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.3935 = select i1 %local.is.active.3933, i32 %local.sum.extent.3934, i32 0
  %stack.offset.3936 = add i32 %stack.offset.3932, %local.sum.selected.3935
  %local.is.active.3937 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.3938 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.3939 = select i1 %local.is.active.3937, i32 %local.sum.extent.3938, i32 0
  %stack.offset.3940 = add i32 %stack.offset.3936, %local.sum.selected.3939
  %local.is.active.3941 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.3942 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.3943 = select i1 %local.is.active.3941, i32 %local.sum.extent.3942, i32 0
  %stack.offset.3944 = add i32 %stack.offset.3940, %local.sum.selected.3943
  %local.is.active.3945 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.3946 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.3947 = select i1 %local.is.active.3945, i32 %local.sum.extent.3946, i32 0
  %stack.offset.3948 = add i32 %stack.offset.3944, %local.sum.selected.3947
  %local.is.active.3949 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.3950 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.3951 = select i1 %local.is.active.3949, i32 %local.sum.extent.3950, i32 0
  %stack.offset.3952 = add i32 %stack.offset.3948, %local.sum.selected.3951
  %local.is.active.3953 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.3954 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.3955 = select i1 %local.is.active.3953, i32 %local.sum.extent.3954, i32 0
  %stack.offset.3956 = add i32 %stack.offset.3952, %local.sum.selected.3955
  %local.is.active.3957 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.3958 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.3959 = select i1 %local.is.active.3957, i32 %local.sum.extent.3958, i32 0
  %stack.offset.3960 = add i32 %stack.offset.3956, %local.sum.selected.3959
  %local.is.active.3961 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.3962 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.3963 = select i1 %local.is.active.3961, i32 %local.sum.extent.3962, i32 0
  %stack.offset.3964 = add i32 %stack.offset.3960, %local.sum.selected.3963
  %local.is.active.3965 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.3966 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.3967 = select i1 %local.is.active.3965, i32 %local.sum.extent.3966, i32 0
  %stack.offset.3968 = add i32 %stack.offset.3964, %local.sum.selected.3967
  %local.is.active.3969 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.3970 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.3971 = select i1 %local.is.active.3969, i32 %local.sum.extent.3970, i32 0
  %stack.offset.3972 = add i32 %stack.offset.3968, %local.sum.selected.3971
  %stack.offset.3973 = add i32 %stack.offset.3972, 0
  %stack.offset.3974 = add i32 %context.value.75, %stack.offset.3973
  %cursor.status.3975 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.3974)
  %cursor.ok.3976 = icmp eq i32 %cursor.status.3975, 0
  br i1 %cursor.ok.3976, label %cursor.continue.3977, label %frame.failure.0
cursor.continue.3977:
  %step.status.3978 = call i32 @al_owning_charge_step(ptr %ctx, i32 82)
  %helper.ok.3979 = icmp eq i32 %step.status.3978, 0
  br i1 %helper.ok.3979, label %helper.continue.3980, label %frame.failure.0
helper.continue.3980:
  %local.source.offset.3981 = load i32, ptr %local.offset.44, align 4
  %local.source.extent.3982 = load i32, ptr %local.extent.45, align 4
  %local.source.payload.3983 = load i32, ptr %local.payload.46, align 4
  %context.field.3984 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3985 = load i32, ptr %context.field.3984, align 4
  %stack.offset.3986 = add i32 %context.value.3985, %local.source.extent.3982
  %reserve.status.3987 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3986, i32 83)
  %reserve.ok.3988 = icmp eq i32 %reserve.status.3987, 0
  br i1 %reserve.ok.3988, label %reserve.continue.3989, label %frame.failure.0
reserve.continue.3989:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.3985, i32 %local.source.offset.3981, i32 %local.source.extent.3982, i32 %local.source.payload.3983, i32 12)
  %context.field.3990 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3991 = load i32, ptr %context.field.3990, align 4
  %runtime.ok.3992 = icmp eq i32 %context.value.3991, 0
  br i1 %runtime.ok.3992, label %runtime.continue.3993, label %frame.failure.0
runtime.continue.3993:
  %local.is.active.3994 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.3995 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.3996 = select i1 %local.is.active.3994, i32 %local.sum.extent.3995, i32 0
  %stack.offset.3997 = add i32 0, %local.sum.selected.3996
  %local.is.active.3998 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.3999 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4000 = select i1 %local.is.active.3998, i32 %local.sum.extent.3999, i32 0
  %stack.offset.4001 = add i32 %stack.offset.3997, %local.sum.selected.4000
  %local.is.active.4002 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4003 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4004 = select i1 %local.is.active.4002, i32 %local.sum.extent.4003, i32 0
  %stack.offset.4005 = add i32 %stack.offset.4001, %local.sum.selected.4004
  %local.is.active.4006 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4007 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4008 = select i1 %local.is.active.4006, i32 %local.sum.extent.4007, i32 0
  %stack.offset.4009 = add i32 %stack.offset.4005, %local.sum.selected.4008
  %local.is.active.4010 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4011 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4012 = select i1 %local.is.active.4010, i32 %local.sum.extent.4011, i32 0
  %stack.offset.4013 = add i32 %stack.offset.4009, %local.sum.selected.4012
  %local.is.active.4014 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4015 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4016 = select i1 %local.is.active.4014, i32 %local.sum.extent.4015, i32 0
  %stack.offset.4017 = add i32 %stack.offset.4013, %local.sum.selected.4016
  %local.is.active.4018 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4019 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4020 = select i1 %local.is.active.4018, i32 %local.sum.extent.4019, i32 0
  %stack.offset.4021 = add i32 %stack.offset.4017, %local.sum.selected.4020
  %local.is.active.4022 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4023 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4024 = select i1 %local.is.active.4022, i32 %local.sum.extent.4023, i32 0
  %stack.offset.4025 = add i32 %stack.offset.4021, %local.sum.selected.4024
  %local.is.active.4026 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4027 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4028 = select i1 %local.is.active.4026, i32 %local.sum.extent.4027, i32 0
  %stack.offset.4029 = add i32 %stack.offset.4025, %local.sum.selected.4028
  %local.is.active.4030 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4031 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4032 = select i1 %local.is.active.4030, i32 %local.sum.extent.4031, i32 0
  %stack.offset.4033 = add i32 %stack.offset.4029, %local.sum.selected.4032
  %local.is.active.4034 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4035 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4036 = select i1 %local.is.active.4034, i32 %local.sum.extent.4035, i32 0
  %stack.offset.4037 = add i32 %stack.offset.4033, %local.sum.selected.4036
  %local.is.active.4038 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4039 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4040 = select i1 %local.is.active.4038, i32 %local.sum.extent.4039, i32 0
  %stack.offset.4041 = add i32 %stack.offset.4037, %local.sum.selected.4040
  %stack.offset.4042 = add i32 0, %local.source.extent.3982
  %stack.offset.4043 = add i32 %stack.offset.4041, %stack.offset.4042
  %stack.offset.4044 = add i32 %context.value.75, %stack.offset.4043
  %cursor.status.4045 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4044)
  %cursor.ok.4046 = icmp eq i32 %cursor.status.4045, 0
  br i1 %cursor.ok.4046, label %cursor.continue.4047, label %frame.failure.0
cursor.continue.4047:
  %step.status.4048 = call i32 @al_owning_charge_step(ptr %ctx, i32 84)
  %helper.ok.4049 = icmp eq i32 %step.status.4048, 0
  br i1 %helper.ok.4049, label %helper.continue.4050, label %frame.failure.0
helper.continue.4050:
  %local.source.offset.4051 = load i32, ptr %local.offset.49, align 4
  %local.source.extent.4052 = load i32, ptr %local.extent.50, align 4
  %local.source.payload.4053 = load i32, ptr %local.payload.51, align 4
  %context.field.4054 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4055 = load i32, ptr %context.field.4054, align 4
  %stack.offset.4056 = add i32 %context.value.4055, %local.source.extent.4052
  %reserve.status.4057 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4056, i32 85)
  %reserve.ok.4058 = icmp eq i32 %reserve.status.4057, 0
  br i1 %reserve.ok.4058, label %reserve.continue.4059, label %frame.failure.0
reserve.continue.4059:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.4055, i32 %local.source.offset.4051, i32 %local.source.extent.4052, i32 %local.source.payload.4053, i32 1)
  %context.field.4060 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4061 = load i32, ptr %context.field.4060, align 4
  %runtime.ok.4062 = icmp eq i32 %context.value.4061, 0
  br i1 %runtime.ok.4062, label %runtime.continue.4063, label %frame.failure.0
runtime.continue.4063:
  %local.is.active.4064 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4065 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4066 = select i1 %local.is.active.4064, i32 %local.sum.extent.4065, i32 0
  %stack.offset.4067 = add i32 0, %local.sum.selected.4066
  %local.is.active.4068 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4069 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4070 = select i1 %local.is.active.4068, i32 %local.sum.extent.4069, i32 0
  %stack.offset.4071 = add i32 %stack.offset.4067, %local.sum.selected.4070
  %local.is.active.4072 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4073 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4074 = select i1 %local.is.active.4072, i32 %local.sum.extent.4073, i32 0
  %stack.offset.4075 = add i32 %stack.offset.4071, %local.sum.selected.4074
  %local.is.active.4076 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4077 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4078 = select i1 %local.is.active.4076, i32 %local.sum.extent.4077, i32 0
  %stack.offset.4079 = add i32 %stack.offset.4075, %local.sum.selected.4078
  %local.is.active.4080 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4081 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4082 = select i1 %local.is.active.4080, i32 %local.sum.extent.4081, i32 0
  %stack.offset.4083 = add i32 %stack.offset.4079, %local.sum.selected.4082
  %local.is.active.4084 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4085 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4086 = select i1 %local.is.active.4084, i32 %local.sum.extent.4085, i32 0
  %stack.offset.4087 = add i32 %stack.offset.4083, %local.sum.selected.4086
  %local.is.active.4088 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4089 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4090 = select i1 %local.is.active.4088, i32 %local.sum.extent.4089, i32 0
  %stack.offset.4091 = add i32 %stack.offset.4087, %local.sum.selected.4090
  %local.is.active.4092 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4093 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4094 = select i1 %local.is.active.4092, i32 %local.sum.extent.4093, i32 0
  %stack.offset.4095 = add i32 %stack.offset.4091, %local.sum.selected.4094
  %local.is.active.4096 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4097 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4098 = select i1 %local.is.active.4096, i32 %local.sum.extent.4097, i32 0
  %stack.offset.4099 = add i32 %stack.offset.4095, %local.sum.selected.4098
  %local.is.active.4100 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4101 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4102 = select i1 %local.is.active.4100, i32 %local.sum.extent.4101, i32 0
  %stack.offset.4103 = add i32 %stack.offset.4099, %local.sum.selected.4102
  %local.is.active.4104 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4105 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4106 = select i1 %local.is.active.4104, i32 %local.sum.extent.4105, i32 0
  %stack.offset.4107 = add i32 %stack.offset.4103, %local.sum.selected.4106
  %local.is.active.4108 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4109 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4110 = select i1 %local.is.active.4108, i32 %local.sum.extent.4109, i32 0
  %stack.offset.4111 = add i32 %stack.offset.4107, %local.sum.selected.4110
  %stack.offset.4112 = add i32 0, %local.source.extent.3982
  %stack.offset.4113 = add i32 %stack.offset.4112, %local.source.extent.4052
  %stack.offset.4114 = add i32 %stack.offset.4111, %stack.offset.4113
  %stack.offset.4115 = add i32 %context.value.75, %stack.offset.4114
  %cursor.status.4116 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4115)
  %cursor.ok.4117 = icmp eq i32 %cursor.status.4116, 0
  br i1 %cursor.ok.4117, label %cursor.continue.4118, label %frame.failure.0
cursor.continue.4118:
  %step.status.4119 = call i32 @al_owning_charge_step(ptr %ctx, i32 86)
  %helper.ok.4120 = icmp eq i32 %step.status.4119, 0
  br i1 %helper.ok.4120, label %helper.continue.4121, label %frame.failure.0
helper.continue.4121:
  %stack.offset.4122 = add i32 0, %local.source.payload.3983
  %stack.offset.4123 = add i32 %stack.offset.4122, %local.source.payload.4053
  %stack.offset.4124 = add i32 0, %local.source.extent.3982
  %stack.offset.4125 = add i32 %stack.offset.4124, %local.source.extent.4052
  %context.field.4126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4127 = load i32, ptr %context.field.4126, align 4
  %local.is.active.4128 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4129 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4130 = select i1 %local.is.active.4128, i32 %local.sum.extent.4129, i32 0
  %stack.offset.4131 = add i32 0, %local.sum.selected.4130
  %local.is.active.4132 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4133 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4134 = select i1 %local.is.active.4132, i32 %local.sum.extent.4133, i32 0
  %stack.offset.4135 = add i32 %stack.offset.4131, %local.sum.selected.4134
  %local.is.active.4136 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4137 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4138 = select i1 %local.is.active.4136, i32 %local.sum.extent.4137, i32 0
  %stack.offset.4139 = add i32 %stack.offset.4135, %local.sum.selected.4138
  %local.is.active.4140 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4141 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4142 = select i1 %local.is.active.4140, i32 %local.sum.extent.4141, i32 0
  %stack.offset.4143 = add i32 %stack.offset.4139, %local.sum.selected.4142
  %local.is.active.4144 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4145 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4146 = select i1 %local.is.active.4144, i32 %local.sum.extent.4145, i32 0
  %stack.offset.4147 = add i32 %stack.offset.4143, %local.sum.selected.4146
  %local.is.active.4148 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4149 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4150 = select i1 %local.is.active.4148, i32 %local.sum.extent.4149, i32 0
  %stack.offset.4151 = add i32 %stack.offset.4147, %local.sum.selected.4150
  %local.is.active.4152 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4153 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4154 = select i1 %local.is.active.4152, i32 %local.sum.extent.4153, i32 0
  %stack.offset.4155 = add i32 %stack.offset.4151, %local.sum.selected.4154
  %local.is.active.4156 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4157 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4158 = select i1 %local.is.active.4156, i32 %local.sum.extent.4157, i32 0
  %stack.offset.4159 = add i32 %stack.offset.4155, %local.sum.selected.4158
  %local.is.active.4160 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4161 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4162 = select i1 %local.is.active.4160, i32 %local.sum.extent.4161, i32 0
  %stack.offset.4163 = add i32 %stack.offset.4159, %local.sum.selected.4162
  %local.is.active.4164 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4165 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4166 = select i1 %local.is.active.4164, i32 %local.sum.extent.4165, i32 0
  %stack.offset.4167 = add i32 %stack.offset.4163, %local.sum.selected.4166
  %local.is.active.4168 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4169 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4170 = select i1 %local.is.active.4168, i32 %local.sum.extent.4169, i32 0
  %stack.offset.4171 = add i32 %stack.offset.4167, %local.sum.selected.4170
  %local.is.active.4172 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4173 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4174 = select i1 %local.is.active.4172, i32 %local.sum.extent.4173, i32 0
  %stack.offset.4175 = add i32 %stack.offset.4171, %local.sum.selected.4174
  %stack.offset.4176 = add i32 %stack.offset.4175, 0
  %stack.offset.4177 = add i32 %context.value.75, %stack.offset.4176
  %stack.offset.4178 = add i32 %context.value.4127, %stack.offset.4125
  %reserve.status.4179 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4178, i32 87)
  %reserve.ok.4180 = icmp eq i32 %reserve.status.4179, 0
  br i1 %reserve.ok.4180, label %reserve.continue.4181, label %frame.failure.0
reserve.continue.4181:
  %local.is.active.4182 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4183 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4184 = select i1 %local.is.active.4182, i32 %local.sum.extent.4183, i32 0
  %stack.offset.4185 = add i32 0, %local.sum.selected.4184
  %local.is.active.4186 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4187 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4188 = select i1 %local.is.active.4186, i32 %local.sum.extent.4187, i32 0
  %stack.offset.4189 = add i32 %stack.offset.4185, %local.sum.selected.4188
  %local.is.active.4190 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4191 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4192 = select i1 %local.is.active.4190, i32 %local.sum.extent.4191, i32 0
  %stack.offset.4193 = add i32 %stack.offset.4189, %local.sum.selected.4192
  %local.is.active.4194 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4195 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4196 = select i1 %local.is.active.4194, i32 %local.sum.extent.4195, i32 0
  %stack.offset.4197 = add i32 %stack.offset.4193, %local.sum.selected.4196
  %local.is.active.4198 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4199 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4200 = select i1 %local.is.active.4198, i32 %local.sum.extent.4199, i32 0
  %stack.offset.4201 = add i32 %stack.offset.4197, %local.sum.selected.4200
  %local.is.active.4202 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4203 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4204 = select i1 %local.is.active.4202, i32 %local.sum.extent.4203, i32 0
  %stack.offset.4205 = add i32 %stack.offset.4201, %local.sum.selected.4204
  %local.is.active.4206 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4207 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4208 = select i1 %local.is.active.4206, i32 %local.sum.extent.4207, i32 0
  %stack.offset.4209 = add i32 %stack.offset.4205, %local.sum.selected.4208
  %local.is.active.4210 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4211 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4212 = select i1 %local.is.active.4210, i32 %local.sum.extent.4211, i32 0
  %stack.offset.4213 = add i32 %stack.offset.4209, %local.sum.selected.4212
  %local.is.active.4214 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4215 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4216 = select i1 %local.is.active.4214, i32 %local.sum.extent.4215, i32 0
  %stack.offset.4217 = add i32 %stack.offset.4213, %local.sum.selected.4216
  %local.is.active.4218 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4219 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4220 = select i1 %local.is.active.4218, i32 %local.sum.extent.4219, i32 0
  %stack.offset.4221 = add i32 %stack.offset.4217, %local.sum.selected.4220
  %local.is.active.4222 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4223 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4224 = select i1 %local.is.active.4222, i32 %local.sum.extent.4223, i32 0
  %stack.offset.4225 = add i32 %stack.offset.4221, %local.sum.selected.4224
  %local.is.active.4226 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4227 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4228 = select i1 %local.is.active.4226, i32 %local.sum.extent.4227, i32 0
  %stack.offset.4229 = add i32 %stack.offset.4225, %local.sum.selected.4228
  %stack.offset.4230 = add i32 %stack.offset.4229, 0
  %stack.offset.4231 = add i32 %context.value.75, %stack.offset.4230
  %stack.offset.4232 = add i32 %context.value.4127, 0
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4232, i32 %stack.offset.4231, i32 %local.source.extent.3982, i32 %local.source.payload.3983, i32 12, i32 6)
  %context.field.4233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4234 = load i32, ptr %context.field.4233, align 4
  %runtime.ok.4235 = icmp eq i32 %context.value.4234, 0
  br i1 %runtime.ok.4235, label %runtime.continue.4236, label %frame.failure.0
runtime.continue.4236:
  %stack.offset.4237 = add i32 0, %local.source.extent.3982
  %local.is.active.4238 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4239 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4240 = select i1 %local.is.active.4238, i32 %local.sum.extent.4239, i32 0
  %stack.offset.4241 = add i32 0, %local.sum.selected.4240
  %local.is.active.4242 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4243 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4244 = select i1 %local.is.active.4242, i32 %local.sum.extent.4243, i32 0
  %stack.offset.4245 = add i32 %stack.offset.4241, %local.sum.selected.4244
  %local.is.active.4246 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4247 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4248 = select i1 %local.is.active.4246, i32 %local.sum.extent.4247, i32 0
  %stack.offset.4249 = add i32 %stack.offset.4245, %local.sum.selected.4248
  %local.is.active.4250 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4251 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4252 = select i1 %local.is.active.4250, i32 %local.sum.extent.4251, i32 0
  %stack.offset.4253 = add i32 %stack.offset.4249, %local.sum.selected.4252
  %local.is.active.4254 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4255 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4256 = select i1 %local.is.active.4254, i32 %local.sum.extent.4255, i32 0
  %stack.offset.4257 = add i32 %stack.offset.4253, %local.sum.selected.4256
  %local.is.active.4258 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4259 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4260 = select i1 %local.is.active.4258, i32 %local.sum.extent.4259, i32 0
  %stack.offset.4261 = add i32 %stack.offset.4257, %local.sum.selected.4260
  %local.is.active.4262 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4263 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4264 = select i1 %local.is.active.4262, i32 %local.sum.extent.4263, i32 0
  %stack.offset.4265 = add i32 %stack.offset.4261, %local.sum.selected.4264
  %local.is.active.4266 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4267 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4268 = select i1 %local.is.active.4266, i32 %local.sum.extent.4267, i32 0
  %stack.offset.4269 = add i32 %stack.offset.4265, %local.sum.selected.4268
  %local.is.active.4270 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4271 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4272 = select i1 %local.is.active.4270, i32 %local.sum.extent.4271, i32 0
  %stack.offset.4273 = add i32 %stack.offset.4269, %local.sum.selected.4272
  %local.is.active.4274 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4275 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4276 = select i1 %local.is.active.4274, i32 %local.sum.extent.4275, i32 0
  %stack.offset.4277 = add i32 %stack.offset.4273, %local.sum.selected.4276
  %local.is.active.4278 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4279 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4280 = select i1 %local.is.active.4278, i32 %local.sum.extent.4279, i32 0
  %stack.offset.4281 = add i32 %stack.offset.4277, %local.sum.selected.4280
  %local.is.active.4282 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4283 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4284 = select i1 %local.is.active.4282, i32 %local.sum.extent.4283, i32 0
  %stack.offset.4285 = add i32 %stack.offset.4281, %local.sum.selected.4284
  %stack.offset.4286 = add i32 0, %local.source.extent.3982
  %stack.offset.4287 = add i32 %stack.offset.4285, %stack.offset.4286
  %stack.offset.4288 = add i32 %context.value.75, %stack.offset.4287
  %stack.offset.4289 = add i32 %context.value.4127, %stack.offset.4237
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4289, i32 %stack.offset.4288, i32 %local.source.extent.4052, i32 %local.source.payload.4053, i32 1, i32 6)
  %context.field.4290 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4291 = load i32, ptr %context.field.4290, align 4
  %runtime.ok.4292 = icmp eq i32 %context.value.4291, 0
  br i1 %runtime.ok.4292, label %runtime.continue.4293, label %frame.failure.0
runtime.continue.4293:
  %stack.offset.4294 = add i32 %stack.offset.4237, %local.source.extent.4052
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4177, i32 %context.value.4127, i32 %stack.offset.4125, i32 %stack.offset.4123, i32 9, i32 6)
  %context.field.4295 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4296 = load i32, ptr %context.field.4295, align 4
  %runtime.ok.4297 = icmp eq i32 %context.value.4296, 0
  br i1 %runtime.ok.4297, label %runtime.continue.4298, label %frame.failure.0
runtime.continue.4298:
  %stack.offset.4299 = add i32 %stack.offset.4177, %stack.offset.4125
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.4299, i32 0, i32 0, i32 0)
  %context.field.4300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4301 = load i32, ptr %context.field.4300, align 4
  %runtime.ok.4302 = icmp eq i32 %context.value.4301, 0
  br i1 %runtime.ok.4302, label %runtime.continue.4303, label %frame.failure.0
runtime.continue.4303:
  %stack.offset.4304 = add i32 0, %local.source.payload.3983
  %stack.offset.4305 = add i32 %stack.offset.4304, %local.source.payload.4053
  %stack.sub.4306 = sub i32 %stack.offset.4123, %stack.offset.4305
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4306, i32 0)
  %context.field.4307 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4308 = load i32, ptr %context.field.4307, align 4
  %runtime.ok.4309 = icmp eq i32 %context.value.4308, 0
  br i1 %runtime.ok.4309, label %runtime.continue.4310, label %frame.failure.0
runtime.continue.4310:
  %local.is.active.4311 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4312 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4313 = select i1 %local.is.active.4311, i32 %local.sum.extent.4312, i32 0
  %stack.offset.4314 = add i32 0, %local.sum.selected.4313
  %local.is.active.4315 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4316 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4317 = select i1 %local.is.active.4315, i32 %local.sum.extent.4316, i32 0
  %stack.offset.4318 = add i32 %stack.offset.4314, %local.sum.selected.4317
  %local.is.active.4319 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4320 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4321 = select i1 %local.is.active.4319, i32 %local.sum.extent.4320, i32 0
  %stack.offset.4322 = add i32 %stack.offset.4318, %local.sum.selected.4321
  %local.is.active.4323 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4324 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4325 = select i1 %local.is.active.4323, i32 %local.sum.extent.4324, i32 0
  %stack.offset.4326 = add i32 %stack.offset.4322, %local.sum.selected.4325
  %local.is.active.4327 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4328 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4329 = select i1 %local.is.active.4327, i32 %local.sum.extent.4328, i32 0
  %stack.offset.4330 = add i32 %stack.offset.4326, %local.sum.selected.4329
  %local.is.active.4331 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4332 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4333 = select i1 %local.is.active.4331, i32 %local.sum.extent.4332, i32 0
  %stack.offset.4334 = add i32 %stack.offset.4330, %local.sum.selected.4333
  %local.is.active.4335 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4336 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4337 = select i1 %local.is.active.4335, i32 %local.sum.extent.4336, i32 0
  %stack.offset.4338 = add i32 %stack.offset.4334, %local.sum.selected.4337
  %local.is.active.4339 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4340 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4341 = select i1 %local.is.active.4339, i32 %local.sum.extent.4340, i32 0
  %stack.offset.4342 = add i32 %stack.offset.4338, %local.sum.selected.4341
  %local.is.active.4343 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4344 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4345 = select i1 %local.is.active.4343, i32 %local.sum.extent.4344, i32 0
  %stack.offset.4346 = add i32 %stack.offset.4342, %local.sum.selected.4345
  %local.is.active.4347 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4348 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4349 = select i1 %local.is.active.4347, i32 %local.sum.extent.4348, i32 0
  %stack.offset.4350 = add i32 %stack.offset.4346, %local.sum.selected.4349
  %local.is.active.4351 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4352 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4353 = select i1 %local.is.active.4351, i32 %local.sum.extent.4352, i32 0
  %stack.offset.4354 = add i32 %stack.offset.4350, %local.sum.selected.4353
  %local.is.active.4355 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4356 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4357 = select i1 %local.is.active.4355, i32 %local.sum.extent.4356, i32 0
  %stack.offset.4358 = add i32 %stack.offset.4354, %local.sum.selected.4357
  %stack.offset.4359 = add i32 0, %stack.offset.4125
  %stack.offset.4360 = add i32 %stack.offset.4358, %stack.offset.4359
  %stack.offset.4361 = add i32 %context.value.75, %stack.offset.4360
  %cursor.status.4362 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4361)
  %cursor.ok.4363 = icmp eq i32 %cursor.status.4362, 0
  br i1 %cursor.ok.4363, label %cursor.continue.4364, label %frame.failure.0
cursor.continue.4364:
  %local.is.active.4365 = load i1, ptr %local.active.48, align 1
  br i1 %local.is.active.4365, label %local.remove.4366, label %local.keep.4367
local.keep.4367:
  br label %local.removed.4368
local.remove.4366:
  %local.remove.offset.4369 = load i32, ptr %local.offset.49, align 4
  %local.remove.extent.4370 = load i32, ptr %local.extent.50, align 4
  %local.remove.payload.4371 = load i32, ptr %local.payload.51, align 4
  %local.remove.type.4372 = load i32, ptr %local.type.52, align 4
  %stack.offset.4373 = add i32 %local.remove.offset.4369, %local.remove.extent.4370
  %context.field.4374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4375 = load i32, ptr %context.field.4374, align 4
  %stack.sub.4376 = sub i32 %context.value.4375, %stack.offset.4373
  %local.is.active.4377 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.4378 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.4379 = select i1 %local.is.active.4377, i32 %local.suffix.payload.4378, i32 0
  %stack.offset.4380 = add i32 0, %local.suffix.selected.4379
  %local.is.active.4381 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.4382 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.4383 = select i1 %local.is.active.4381, i32 %local.suffix.payload.4382, i32 0
  %stack.offset.4384 = add i32 %stack.offset.4380, %local.suffix.selected.4383
  %stack.offset.4385 = add i32 0, %stack.offset.4123
  %stack.offset.4386 = add i32 %stack.offset.4384, %stack.offset.4385
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.4369, i32 %stack.offset.4373, i32 %stack.sub.4376, i32 %stack.offset.4386, i32 0, i32 14)
  %context.field.4387 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4388 = load i32, ptr %context.field.4387, align 4
  %runtime.ok.4389 = icmp eq i32 %context.value.4388, 0
  br i1 %runtime.ok.4389, label %runtime.continue.4390, label %frame.failure.0
runtime.continue.4390:
  %stack.sub.4391 = sub i32 %context.value.4375, %local.remove.extent.4370
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.4391, i32 0, i32 0, i32 0)
  %context.field.4392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4393 = load i32, ptr %context.field.4392, align 4
  %runtime.ok.4394 = icmp eq i32 %context.value.4393, 0
  br i1 %runtime.ok.4394, label %runtime.continue.4395, label %frame.failure.0
runtime.continue.4395:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.4372, i32 %local.remove.offset.4369, i32 %local.remove.extent.4370, i32 %local.remove.payload.4371, i32 0, i32 0)
  %context.field.4396 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4397 = load i32, ptr %context.field.4396, align 4
  %runtime.ok.4398 = icmp eq i32 %context.value.4397, 0
  br i1 %runtime.ok.4398, label %runtime.continue.4399, label %frame.failure.0
runtime.continue.4399:
  %stack.sub.4400 = sub i32 0, %local.remove.payload.4371
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4400, i32 %stack.sub.4400)
  %context.field.4401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4402 = load i32, ptr %context.field.4401, align 4
  %runtime.ok.4403 = icmp eq i32 %context.value.4402, 0
  br i1 %runtime.ok.4403, label %runtime.continue.4404, label %frame.failure.0
runtime.continue.4404:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.4370)
  %context.field.4405 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4406 = load i32, ptr %context.field.4405, align 4
  %runtime.ok.4407 = icmp eq i32 %context.value.4406, 0
  br i1 %runtime.ok.4407, label %runtime.continue.4408, label %frame.failure.0
runtime.continue.4408:
  %local.is.active.4409 = load i1, ptr %local.active.53, align 1
  %local.later.offset.4410 = load i32, ptr %local.offset.54, align 4
  %stack.sub.4411 = sub i32 %local.later.offset.4410, %local.remove.extent.4370
  %local.later.offset.selected.4412 = select i1 %local.is.active.4409, i32 %stack.sub.4411, i32 %local.later.offset.4410
  store i32 %local.later.offset.selected.4412, ptr %local.offset.54, align 4
  %local.is.active.4413 = load i1, ptr %local.active.58, align 1
  %local.later.offset.4414 = load i32, ptr %local.offset.59, align 4
  %stack.sub.4415 = sub i32 %local.later.offset.4414, %local.remove.extent.4370
  %local.later.offset.selected.4416 = select i1 %local.is.active.4413, i32 %stack.sub.4415, i32 %local.later.offset.4414
  store i32 %local.later.offset.selected.4416, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.48, align 1
  store i32 0, ptr %local.offset.49, align 4
  store i32 0, ptr %local.extent.50, align 4
  store i32 0, ptr %local.payload.51, align 4
  store i32 0, ptr %local.type.52, align 4
  br label %local.removed.4368
local.removed.4368:
  %local.is.active.4417 = load i1, ptr %local.active.43, align 1
  br i1 %local.is.active.4417, label %local.remove.4418, label %local.keep.4419
local.keep.4419:
  br label %local.removed.4420
local.remove.4418:
  %local.remove.offset.4421 = load i32, ptr %local.offset.44, align 4
  %local.remove.extent.4422 = load i32, ptr %local.extent.45, align 4
  %local.remove.payload.4423 = load i32, ptr %local.payload.46, align 4
  %local.remove.type.4424 = load i32, ptr %local.type.47, align 4
  %stack.offset.4425 = add i32 %local.remove.offset.4421, %local.remove.extent.4422
  %context.field.4426 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4427 = load i32, ptr %context.field.4426, align 4
  %stack.sub.4428 = sub i32 %context.value.4427, %stack.offset.4425
  %local.is.active.4429 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.4430 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.4431 = select i1 %local.is.active.4429, i32 %local.suffix.payload.4430, i32 0
  %stack.offset.4432 = add i32 0, %local.suffix.selected.4431
  %local.is.active.4433 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.4434 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.4435 = select i1 %local.is.active.4433, i32 %local.suffix.payload.4434, i32 0
  %stack.offset.4436 = add i32 %stack.offset.4432, %local.suffix.selected.4435
  %local.is.active.4437 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.4438 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.4439 = select i1 %local.is.active.4437, i32 %local.suffix.payload.4438, i32 0
  %stack.offset.4440 = add i32 %stack.offset.4436, %local.suffix.selected.4439
  %stack.offset.4441 = add i32 0, %stack.offset.4123
  %stack.offset.4442 = add i32 %stack.offset.4440, %stack.offset.4441
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.4421, i32 %stack.offset.4425, i32 %stack.sub.4428, i32 %stack.offset.4442, i32 0, i32 14)
  %context.field.4443 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4444 = load i32, ptr %context.field.4443, align 4
  %runtime.ok.4445 = icmp eq i32 %context.value.4444, 0
  br i1 %runtime.ok.4445, label %runtime.continue.4446, label %frame.failure.0
runtime.continue.4446:
  %stack.sub.4447 = sub i32 %context.value.4427, %local.remove.extent.4422
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.4447, i32 0, i32 0, i32 0)
  %context.field.4448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4449 = load i32, ptr %context.field.4448, align 4
  %runtime.ok.4450 = icmp eq i32 %context.value.4449, 0
  br i1 %runtime.ok.4450, label %runtime.continue.4451, label %frame.failure.0
runtime.continue.4451:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.4424, i32 %local.remove.offset.4421, i32 %local.remove.extent.4422, i32 %local.remove.payload.4423, i32 0, i32 0)
  %context.field.4452 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4453 = load i32, ptr %context.field.4452, align 4
  %runtime.ok.4454 = icmp eq i32 %context.value.4453, 0
  br i1 %runtime.ok.4454, label %runtime.continue.4455, label %frame.failure.0
runtime.continue.4455:
  %stack.sub.4456 = sub i32 0, %local.remove.payload.4423
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4456, i32 %stack.sub.4456)
  %context.field.4457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4458 = load i32, ptr %context.field.4457, align 4
  %runtime.ok.4459 = icmp eq i32 %context.value.4458, 0
  br i1 %runtime.ok.4459, label %runtime.continue.4460, label %frame.failure.0
runtime.continue.4460:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.4422)
  %context.field.4461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4462 = load i32, ptr %context.field.4461, align 4
  %runtime.ok.4463 = icmp eq i32 %context.value.4462, 0
  br i1 %runtime.ok.4463, label %runtime.continue.4464, label %frame.failure.0
runtime.continue.4464:
  %local.is.active.4465 = load i1, ptr %local.active.48, align 1
  %local.later.offset.4466 = load i32, ptr %local.offset.49, align 4
  %stack.sub.4467 = sub i32 %local.later.offset.4466, %local.remove.extent.4422
  %local.later.offset.selected.4468 = select i1 %local.is.active.4465, i32 %stack.sub.4467, i32 %local.later.offset.4466
  store i32 %local.later.offset.selected.4468, ptr %local.offset.49, align 4
  %local.is.active.4469 = load i1, ptr %local.active.53, align 1
  %local.later.offset.4470 = load i32, ptr %local.offset.54, align 4
  %stack.sub.4471 = sub i32 %local.later.offset.4470, %local.remove.extent.4422
  %local.later.offset.selected.4472 = select i1 %local.is.active.4469, i32 %stack.sub.4471, i32 %local.later.offset.4470
  store i32 %local.later.offset.selected.4472, ptr %local.offset.54, align 4
  %local.is.active.4473 = load i1, ptr %local.active.58, align 1
  %local.later.offset.4474 = load i32, ptr %local.offset.59, align 4
  %stack.sub.4475 = sub i32 %local.later.offset.4474, %local.remove.extent.4422
  %local.later.offset.selected.4476 = select i1 %local.is.active.4473, i32 %stack.sub.4475, i32 %local.later.offset.4474
  store i32 %local.later.offset.selected.4476, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.43, align 1
  store i32 0, ptr %local.offset.44, align 4
  store i32 0, ptr %local.extent.45, align 4
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  br label %local.removed.4420
local.removed.4420:
  %local.is.active.4477 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4478 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4479 = select i1 %local.is.active.4477, i32 %local.sum.extent.4478, i32 0
  %stack.offset.4480 = add i32 0, %local.sum.selected.4479
  %local.is.active.4481 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4482 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4483 = select i1 %local.is.active.4481, i32 %local.sum.extent.4482, i32 0
  %stack.offset.4484 = add i32 %stack.offset.4480, %local.sum.selected.4483
  %local.is.active.4485 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4486 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4487 = select i1 %local.is.active.4485, i32 %local.sum.extent.4486, i32 0
  %stack.offset.4488 = add i32 %stack.offset.4484, %local.sum.selected.4487
  %local.is.active.4489 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4490 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4491 = select i1 %local.is.active.4489, i32 %local.sum.extent.4490, i32 0
  %stack.offset.4492 = add i32 %stack.offset.4488, %local.sum.selected.4491
  %local.is.active.4493 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4494 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4495 = select i1 %local.is.active.4493, i32 %local.sum.extent.4494, i32 0
  %stack.offset.4496 = add i32 %stack.offset.4492, %local.sum.selected.4495
  %local.is.active.4497 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4498 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4499 = select i1 %local.is.active.4497, i32 %local.sum.extent.4498, i32 0
  %stack.offset.4500 = add i32 %stack.offset.4496, %local.sum.selected.4499
  %local.is.active.4501 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4502 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4503 = select i1 %local.is.active.4501, i32 %local.sum.extent.4502, i32 0
  %stack.offset.4504 = add i32 %stack.offset.4500, %local.sum.selected.4503
  %local.is.active.4505 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4506 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4507 = select i1 %local.is.active.4505, i32 %local.sum.extent.4506, i32 0
  %stack.offset.4508 = add i32 %stack.offset.4504, %local.sum.selected.4507
  %local.is.active.4509 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4510 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4511 = select i1 %local.is.active.4509, i32 %local.sum.extent.4510, i32 0
  %stack.offset.4512 = add i32 %stack.offset.4508, %local.sum.selected.4511
  %local.is.active.4513 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4514 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4515 = select i1 %local.is.active.4513, i32 %local.sum.extent.4514, i32 0
  %stack.offset.4516 = add i32 %stack.offset.4512, %local.sum.selected.4515
  %local.is.active.4517 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4518 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4519 = select i1 %local.is.active.4517, i32 %local.sum.extent.4518, i32 0
  %stack.offset.4520 = add i32 %stack.offset.4516, %local.sum.selected.4519
  %local.is.active.4521 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4522 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4523 = select i1 %local.is.active.4521, i32 %local.sum.extent.4522, i32 0
  %stack.offset.4524 = add i32 %stack.offset.4520, %local.sum.selected.4523
  %stack.offset.4525 = add i32 0, %stack.offset.4125
  %stack.offset.4526 = add i32 %stack.offset.4524, %stack.offset.4525
  %stack.offset.4527 = add i32 %context.value.75, %stack.offset.4526
  %cursor.status.4528 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4527)
  %cursor.ok.4529 = icmp eq i32 %cursor.status.4528, 0
  br i1 %cursor.ok.4529, label %cursor.continue.4530, label %frame.failure.0
cursor.continue.4530:
  %step.status.4531 = call i32 @al_owning_charge_step(ptr %ctx, i32 88)
  %helper.ok.4532 = icmp eq i32 %step.status.4531, 0
  br i1 %helper.ok.4532, label %helper.continue.4533, label %frame.failure.0
helper.continue.4533:
  %local.is.active.4534 = load i1, ptr %local.active.38, align 1
  %local.previous.extent.4535 = load i32, ptr %local.extent.40, align 4
  %local.previous.payload.4536 = load i32, ptr %local.payload.41, align 4
  %local.old.extent.4537 = select i1 %local.is.active.4534, i32 %local.previous.extent.4535, i32 0
  %local.old.payload.4538 = select i1 %local.is.active.4534, i32 %local.previous.payload.4536, i32 0
  %local.is.active.4539 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4540 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4541 = select i1 %local.is.active.4539, i32 %local.sum.extent.4540, i32 0
  %stack.offset.4542 = add i32 0, %local.sum.selected.4541
  %local.is.active.4543 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4544 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4545 = select i1 %local.is.active.4543, i32 %local.sum.extent.4544, i32 0
  %stack.offset.4546 = add i32 %stack.offset.4542, %local.sum.selected.4545
  %local.is.active.4547 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4548 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4549 = select i1 %local.is.active.4547, i32 %local.sum.extent.4548, i32 0
  %stack.offset.4550 = add i32 %stack.offset.4546, %local.sum.selected.4549
  %local.is.active.4551 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4552 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4553 = select i1 %local.is.active.4551, i32 %local.sum.extent.4552, i32 0
  %stack.offset.4554 = add i32 %stack.offset.4550, %local.sum.selected.4553
  %local.is.active.4555 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4556 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4557 = select i1 %local.is.active.4555, i32 %local.sum.extent.4556, i32 0
  %stack.offset.4558 = add i32 %stack.offset.4554, %local.sum.selected.4557
  %local.is.active.4559 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4560 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4561 = select i1 %local.is.active.4559, i32 %local.sum.extent.4560, i32 0
  %stack.offset.4562 = add i32 %stack.offset.4558, %local.sum.selected.4561
  %local.is.active.4563 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4564 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4565 = select i1 %local.is.active.4563, i32 %local.sum.extent.4564, i32 0
  %stack.offset.4566 = add i32 %stack.offset.4562, %local.sum.selected.4565
  %stack.offset.4567 = add i32 %context.value.75, %stack.offset.4566
  %stack.offset.4568 = add i32 %stack.offset.4567, %local.old.extent.4537
  %context.field.4569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4570 = load i32, ptr %context.field.4569, align 4
  %stack.sub.4571 = sub i32 %context.value.4570, %stack.offset.4568
  %stack.sub.4572 = sub i32 %context.value.4570, %local.old.extent.4537
  %stack.offset.4573 = add i32 %stack.sub.4572, %stack.offset.4125
  %local.grows.4574 = icmp ugt i32 %stack.offset.4125, %local.old.extent.4537
  br i1 %local.grows.4574, label %local.grow.4575, label %local.fixed.4576
local.grow.4575:
  %reserve.status.4578 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4573, i32 89)
  %reserve.ok.4579 = icmp eq i32 %reserve.status.4578, 0
  br i1 %reserve.ok.4579, label %reserve.continue.4580, label %frame.failure.0
reserve.continue.4580:
  %stack.sub.4581 = sub i32 %stack.offset.4125, %local.old.extent.4537
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.4581)
  %context.field.4582 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4583 = load i32, ptr %context.field.4582, align 4
  %runtime.ok.4584 = icmp eq i32 %context.value.4583, 0
  br i1 %runtime.ok.4584, label %runtime.continue.4585, label %frame.failure.0
runtime.continue.4585:
  br label %local.layout.ready.4577
local.fixed.4576:
  br label %local.layout.ready.4577
local.layout.ready.4577:
  %stack.offset.4586 = add i32 %stack.offset.4567, %stack.offset.4125
  %local.is.active.4587 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.4588 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.4589 = select i1 %local.is.active.4587, i32 %local.suffix.payload.4588, i32 0
  %stack.offset.4590 = add i32 0, %local.suffix.selected.4589
  %local.is.active.4591 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.4592 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.4593 = select i1 %local.is.active.4591, i32 %local.suffix.payload.4592, i32 0
  %stack.offset.4594 = add i32 %stack.offset.4590, %local.suffix.selected.4593
  %local.is.active.4595 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.4596 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.4597 = select i1 %local.is.active.4595, i32 %local.suffix.payload.4596, i32 0
  %stack.offset.4598 = add i32 %stack.offset.4594, %local.suffix.selected.4597
  %local.is.active.4599 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.4600 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.4601 = select i1 %local.is.active.4599, i32 %local.suffix.payload.4600, i32 0
  %stack.offset.4602 = add i32 %stack.offset.4598, %local.suffix.selected.4601
  %stack.offset.4603 = add i32 0, %stack.offset.4123
  %stack.offset.4604 = add i32 %stack.offset.4602, %stack.offset.4603
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4586, i32 %stack.offset.4568, i32 %stack.sub.4571, i32 %stack.offset.4604, i32 0, i32 14)
  %context.field.4605 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4606 = load i32, ptr %context.field.4605, align 4
  %runtime.ok.4607 = icmp eq i32 %context.value.4606, 0
  br i1 %runtime.ok.4607, label %runtime.continue.4608, label %frame.failure.0
runtime.continue.4608:
  %stack.sub.4609 = sub i32 %context.value.4570, %stack.offset.4125
  %stack.sub.4610 = sub i32 %stack.sub.4609, %local.old.extent.4537
  %stack.offset.4611 = add i32 %stack.sub.4610, %stack.offset.4125
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4567, i32 %stack.offset.4611, i32 %stack.offset.4125, i32 %stack.offset.4123, i32 9, i32 4)
  %context.field.4612 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4613 = load i32, ptr %context.field.4612, align 4
  %runtime.ok.4614 = icmp eq i32 %context.value.4613, 0
  br i1 %runtime.ok.4614, label %runtime.continue.4615, label %frame.failure.0
runtime.continue.4615:
  %stack.sub.4616 = sub i32 %context.value.4570, %local.old.extent.4537
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.4616, i32 0, i32 0, i32 0)
  %context.field.4617 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4618 = load i32, ptr %context.field.4617, align 4
  %runtime.ok.4619 = icmp eq i32 %context.value.4618, 0
  br i1 %runtime.ok.4619, label %runtime.continue.4620, label %frame.failure.0
runtime.continue.4620:
  %local.shrinks.4621 = icmp ult i32 %stack.offset.4125, %local.old.extent.4537
  br i1 %local.shrinks.4621, label %local.shrink.4622, label %local.counts.ready.4623
local.shrink.4622:
  %stack.sub.4624 = sub i32 %local.old.extent.4537, %stack.offset.4125
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.4624)
  %context.field.4625 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4626 = load i32, ptr %context.field.4625, align 4
  %runtime.ok.4627 = icmp eq i32 %context.value.4626, 0
  br i1 %runtime.ok.4627, label %runtime.continue.4628, label %frame.failure.0
runtime.continue.4628:
  br label %local.counts.ready.4623
local.counts.ready.4623:
  %local.payload.delta.4629 = sub i32 %stack.offset.4123, %local.old.payload.4538
  %stack.sub.4630 = sub i32 0, %local.old.payload.4538
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4630, i32 %local.payload.delta.4629)
  %context.field.4631 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4632 = load i32, ptr %context.field.4631, align 4
  %runtime.ok.4633 = icmp eq i32 %context.value.4632, 0
  br i1 %runtime.ok.4633, label %runtime.continue.4634, label %frame.failure.0
runtime.continue.4634:
  %local.is.active.4635 = load i1, ptr %local.active.43, align 1
  %local.later.offset.4636 = load i32, ptr %local.offset.44, align 4
  %stack.sub.4637 = sub i32 %local.later.offset.4636, %local.old.extent.4537
  %stack.offset.4638 = add i32 %stack.sub.4637, %stack.offset.4125
  %local.later.offset.selected.4639 = select i1 %local.is.active.4635, i32 %stack.offset.4638, i32 %local.later.offset.4636
  store i32 %local.later.offset.selected.4639, ptr %local.offset.44, align 4
  %local.is.active.4640 = load i1, ptr %local.active.48, align 1
  %local.later.offset.4641 = load i32, ptr %local.offset.49, align 4
  %stack.sub.4642 = sub i32 %local.later.offset.4641, %local.old.extent.4537
  %stack.offset.4643 = add i32 %stack.sub.4642, %stack.offset.4125
  %local.later.offset.selected.4644 = select i1 %local.is.active.4640, i32 %stack.offset.4643, i32 %local.later.offset.4641
  store i32 %local.later.offset.selected.4644, ptr %local.offset.49, align 4
  %local.is.active.4645 = load i1, ptr %local.active.53, align 1
  %local.later.offset.4646 = load i32, ptr %local.offset.54, align 4
  %stack.sub.4647 = sub i32 %local.later.offset.4646, %local.old.extent.4537
  %stack.offset.4648 = add i32 %stack.sub.4647, %stack.offset.4125
  %local.later.offset.selected.4649 = select i1 %local.is.active.4645, i32 %stack.offset.4648, i32 %local.later.offset.4646
  store i32 %local.later.offset.selected.4649, ptr %local.offset.54, align 4
  %local.is.active.4650 = load i1, ptr %local.active.58, align 1
  %local.later.offset.4651 = load i32, ptr %local.offset.59, align 4
  %stack.sub.4652 = sub i32 %local.later.offset.4651, %local.old.extent.4537
  %stack.offset.4653 = add i32 %stack.sub.4652, %stack.offset.4125
  %local.later.offset.selected.4654 = select i1 %local.is.active.4650, i32 %stack.offset.4653, i32 %local.later.offset.4651
  store i32 %local.later.offset.selected.4654, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.38, align 1
  store i32 %stack.offset.4567, ptr %local.offset.39, align 4
  store i32 %stack.offset.4125, ptr %local.extent.40, align 4
  store i32 %stack.offset.4123, ptr %local.payload.41, align 4
  store i32 9, ptr %local.type.42, align 4
  %local.is.active.4655 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4656 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4657 = select i1 %local.is.active.4655, i32 %local.sum.extent.4656, i32 0
  %stack.offset.4658 = add i32 0, %local.sum.selected.4657
  %local.is.active.4659 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4660 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4661 = select i1 %local.is.active.4659, i32 %local.sum.extent.4660, i32 0
  %stack.offset.4662 = add i32 %stack.offset.4658, %local.sum.selected.4661
  %local.is.active.4663 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4664 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4665 = select i1 %local.is.active.4663, i32 %local.sum.extent.4664, i32 0
  %stack.offset.4666 = add i32 %stack.offset.4662, %local.sum.selected.4665
  %local.is.active.4667 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4668 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4669 = select i1 %local.is.active.4667, i32 %local.sum.extent.4668, i32 0
  %stack.offset.4670 = add i32 %stack.offset.4666, %local.sum.selected.4669
  %local.is.active.4671 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4672 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4673 = select i1 %local.is.active.4671, i32 %local.sum.extent.4672, i32 0
  %stack.offset.4674 = add i32 %stack.offset.4670, %local.sum.selected.4673
  %local.is.active.4675 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4676 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4677 = select i1 %local.is.active.4675, i32 %local.sum.extent.4676, i32 0
  %stack.offset.4678 = add i32 %stack.offset.4674, %local.sum.selected.4677
  %local.is.active.4679 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4680 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4681 = select i1 %local.is.active.4679, i32 %local.sum.extent.4680, i32 0
  %stack.offset.4682 = add i32 %stack.offset.4678, %local.sum.selected.4681
  %local.is.active.4683 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4684 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4685 = select i1 %local.is.active.4683, i32 %local.sum.extent.4684, i32 0
  %stack.offset.4686 = add i32 %stack.offset.4682, %local.sum.selected.4685
  %local.is.active.4687 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4688 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4689 = select i1 %local.is.active.4687, i32 %local.sum.extent.4688, i32 0
  %stack.offset.4690 = add i32 %stack.offset.4686, %local.sum.selected.4689
  %local.is.active.4691 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4692 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4693 = select i1 %local.is.active.4691, i32 %local.sum.extent.4692, i32 0
  %stack.offset.4694 = add i32 %stack.offset.4690, %local.sum.selected.4693
  %local.is.active.4695 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4696 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4697 = select i1 %local.is.active.4695, i32 %local.sum.extent.4696, i32 0
  %stack.offset.4698 = add i32 %stack.offset.4694, %local.sum.selected.4697
  %local.is.active.4699 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4700 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4701 = select i1 %local.is.active.4699, i32 %local.sum.extent.4700, i32 0
  %stack.offset.4702 = add i32 %stack.offset.4698, %local.sum.selected.4701
  %stack.offset.4703 = add i32 %stack.offset.4702, 0
  %stack.offset.4704 = add i32 %context.value.75, %stack.offset.4703
  %cursor.status.4705 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4704)
  %cursor.ok.4706 = icmp eq i32 %cursor.status.4705, 0
  br i1 %cursor.ok.4706, label %cursor.continue.4707, label %frame.failure.0
cursor.continue.4707:
  %step.status.4708 = call i32 @al_owning_charge_step(ptr %ctx, i32 90)
  %helper.ok.4709 = icmp eq i32 %step.status.4708, 0
  br i1 %helper.ok.4709, label %helper.continue.4710, label %frame.failure.0
helper.continue.4710:
  store i1 false, ptr %local.active.53, align 1
  store i32 0, ptr %local.offset.54, align 4
  store i32 0, ptr %local.extent.55, align 4
  store i32 0, ptr %local.payload.56, align 4
  store i32 0, ptr %local.type.57, align 4
  store i1 false, ptr %local.active.58, align 1
  store i32 0, ptr %local.offset.59, align 4
  store i32 0, ptr %local.extent.60, align 4
  store i32 0, ptr %local.payload.61, align 4
  store i32 0, ptr %local.type.62, align 4
  %step.status.4711 = call i32 @al_owning_charge_step(ptr %ctx, i32 91)
  %helper.ok.4712 = icmp eq i32 %step.status.4711, 0
  br i1 %helper.ok.4712, label %helper.continue.4713, label %frame.failure.0
helper.continue.4713:
  %local.source.offset.4714 = load i32, ptr %local.offset.39, align 4
  %local.source.extent.4715 = load i32, ptr %local.extent.40, align 4
  %local.source.payload.4716 = load i32, ptr %local.payload.41, align 4
  %context.field.4717 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4718 = load i32, ptr %context.field.4717, align 4
  %stack.offset.4719 = add i32 %context.value.4718, %local.source.extent.4715
  %reserve.status.4720 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4719, i32 92)
  %reserve.ok.4721 = icmp eq i32 %reserve.status.4720, 0
  br i1 %reserve.ok.4721, label %reserve.continue.4722, label %frame.failure.0
reserve.continue.4722:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.4718, i32 %local.source.offset.4714, i32 %local.source.extent.4715, i32 %local.source.payload.4716, i32 9)
  %context.field.4723 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4724 = load i32, ptr %context.field.4723, align 4
  %runtime.ok.4725 = icmp eq i32 %context.value.4724, 0
  br i1 %runtime.ok.4725, label %runtime.continue.4726, label %frame.failure.0
runtime.continue.4726:
  %local.is.active.4727 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4728 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4729 = select i1 %local.is.active.4727, i32 %local.sum.extent.4728, i32 0
  %stack.offset.4730 = add i32 0, %local.sum.selected.4729
  %local.is.active.4731 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4732 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4733 = select i1 %local.is.active.4731, i32 %local.sum.extent.4732, i32 0
  %stack.offset.4734 = add i32 %stack.offset.4730, %local.sum.selected.4733
  %local.is.active.4735 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4736 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4737 = select i1 %local.is.active.4735, i32 %local.sum.extent.4736, i32 0
  %stack.offset.4738 = add i32 %stack.offset.4734, %local.sum.selected.4737
  %local.is.active.4739 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4740 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4741 = select i1 %local.is.active.4739, i32 %local.sum.extent.4740, i32 0
  %stack.offset.4742 = add i32 %stack.offset.4738, %local.sum.selected.4741
  %local.is.active.4743 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4744 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4745 = select i1 %local.is.active.4743, i32 %local.sum.extent.4744, i32 0
  %stack.offset.4746 = add i32 %stack.offset.4742, %local.sum.selected.4745
  %local.is.active.4747 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4748 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4749 = select i1 %local.is.active.4747, i32 %local.sum.extent.4748, i32 0
  %stack.offset.4750 = add i32 %stack.offset.4746, %local.sum.selected.4749
  %local.is.active.4751 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4752 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4753 = select i1 %local.is.active.4751, i32 %local.sum.extent.4752, i32 0
  %stack.offset.4754 = add i32 %stack.offset.4750, %local.sum.selected.4753
  %local.is.active.4755 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4756 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4757 = select i1 %local.is.active.4755, i32 %local.sum.extent.4756, i32 0
  %stack.offset.4758 = add i32 %stack.offset.4754, %local.sum.selected.4757
  %local.is.active.4759 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4760 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4761 = select i1 %local.is.active.4759, i32 %local.sum.extent.4760, i32 0
  %stack.offset.4762 = add i32 %stack.offset.4758, %local.sum.selected.4761
  %local.is.active.4763 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4764 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4765 = select i1 %local.is.active.4763, i32 %local.sum.extent.4764, i32 0
  %stack.offset.4766 = add i32 %stack.offset.4762, %local.sum.selected.4765
  %local.is.active.4767 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4768 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4769 = select i1 %local.is.active.4767, i32 %local.sum.extent.4768, i32 0
  %stack.offset.4770 = add i32 %stack.offset.4766, %local.sum.selected.4769
  %local.is.active.4771 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4772 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4773 = select i1 %local.is.active.4771, i32 %local.sum.extent.4772, i32 0
  %stack.offset.4774 = add i32 %stack.offset.4770, %local.sum.selected.4773
  %stack.offset.4775 = add i32 0, %local.source.extent.4715
  %stack.offset.4776 = add i32 %stack.offset.4774, %stack.offset.4775
  %stack.offset.4777 = add i32 %context.value.75, %stack.offset.4776
  %cursor.status.4778 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4777)
  %cursor.ok.4779 = icmp eq i32 %cursor.status.4778, 0
  br i1 %cursor.ok.4779, label %cursor.continue.4780, label %frame.failure.0
cursor.continue.4780:
  %step.status.4781 = call i32 @al_owning_charge_step(ptr %ctx, i32 93)
  %helper.ok.4782 = icmp eq i32 %step.status.4781, 0
  br i1 %helper.ok.4782, label %helper.continue.4783, label %frame.failure.0
helper.continue.4783:
  %local.is.active.4784 = load i1, ptr %local.active.53, align 1
  %local.previous.extent.4785 = load i32, ptr %local.extent.55, align 4
  %local.previous.payload.4786 = load i32, ptr %local.payload.56, align 4
  %local.old.extent.4787 = select i1 %local.is.active.4784, i32 %local.previous.extent.4785, i32 0
  %local.old.payload.4788 = select i1 %local.is.active.4784, i32 %local.previous.payload.4786, i32 0
  %local.is.active.4789 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4790 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4791 = select i1 %local.is.active.4789, i32 %local.sum.extent.4790, i32 0
  %stack.offset.4792 = add i32 0, %local.sum.selected.4791
  %local.is.active.4793 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4794 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4795 = select i1 %local.is.active.4793, i32 %local.sum.extent.4794, i32 0
  %stack.offset.4796 = add i32 %stack.offset.4792, %local.sum.selected.4795
  %local.is.active.4797 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4798 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4799 = select i1 %local.is.active.4797, i32 %local.sum.extent.4798, i32 0
  %stack.offset.4800 = add i32 %stack.offset.4796, %local.sum.selected.4799
  %local.is.active.4801 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4802 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4803 = select i1 %local.is.active.4801, i32 %local.sum.extent.4802, i32 0
  %stack.offset.4804 = add i32 %stack.offset.4800, %local.sum.selected.4803
  %local.is.active.4805 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4806 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4807 = select i1 %local.is.active.4805, i32 %local.sum.extent.4806, i32 0
  %stack.offset.4808 = add i32 %stack.offset.4804, %local.sum.selected.4807
  %local.is.active.4809 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4810 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4811 = select i1 %local.is.active.4809, i32 %local.sum.extent.4810, i32 0
  %stack.offset.4812 = add i32 %stack.offset.4808, %local.sum.selected.4811
  %local.is.active.4813 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4814 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4815 = select i1 %local.is.active.4813, i32 %local.sum.extent.4814, i32 0
  %stack.offset.4816 = add i32 %stack.offset.4812, %local.sum.selected.4815
  %local.is.active.4817 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4818 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4819 = select i1 %local.is.active.4817, i32 %local.sum.extent.4818, i32 0
  %stack.offset.4820 = add i32 %stack.offset.4816, %local.sum.selected.4819
  %local.is.active.4821 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4822 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4823 = select i1 %local.is.active.4821, i32 %local.sum.extent.4822, i32 0
  %stack.offset.4824 = add i32 %stack.offset.4820, %local.sum.selected.4823
  %local.is.active.4825 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4826 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4827 = select i1 %local.is.active.4825, i32 %local.sum.extent.4826, i32 0
  %stack.offset.4828 = add i32 %stack.offset.4824, %local.sum.selected.4827
  %stack.offset.4829 = add i32 %context.value.75, %stack.offset.4828
  %stack.offset.4830 = add i32 %stack.offset.4829, %local.old.extent.4787
  %context.field.4831 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4832 = load i32, ptr %context.field.4831, align 4
  %stack.sub.4833 = sub i32 %context.value.4832, %stack.offset.4830
  %stack.sub.4834 = sub i32 %context.value.4832, %local.old.extent.4787
  %stack.offset.4835 = add i32 %stack.sub.4834, %local.source.extent.4715
  %local.grows.4836 = icmp ugt i32 %local.source.extent.4715, %local.old.extent.4787
  br i1 %local.grows.4836, label %local.grow.4837, label %local.fixed.4838
local.grow.4837:
  %reserve.status.4840 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4835, i32 94)
  %reserve.ok.4841 = icmp eq i32 %reserve.status.4840, 0
  br i1 %reserve.ok.4841, label %reserve.continue.4842, label %frame.failure.0
reserve.continue.4842:
  %stack.sub.4843 = sub i32 %local.source.extent.4715, %local.old.extent.4787
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.4843)
  %context.field.4844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4845 = load i32, ptr %context.field.4844, align 4
  %runtime.ok.4846 = icmp eq i32 %context.value.4845, 0
  br i1 %runtime.ok.4846, label %runtime.continue.4847, label %frame.failure.0
runtime.continue.4847:
  br label %local.layout.ready.4839
local.fixed.4838:
  br label %local.layout.ready.4839
local.layout.ready.4839:
  %stack.offset.4848 = add i32 %stack.offset.4829, %local.source.extent.4715
  %local.is.active.4849 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.4850 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.4851 = select i1 %local.is.active.4849, i32 %local.suffix.payload.4850, i32 0
  %stack.offset.4852 = add i32 0, %local.suffix.selected.4851
  %stack.offset.4853 = add i32 0, %local.source.payload.4716
  %stack.offset.4854 = add i32 %stack.offset.4852, %stack.offset.4853
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4848, i32 %stack.offset.4830, i32 %stack.sub.4833, i32 %stack.offset.4854, i32 0, i32 14)
  %context.field.4855 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4856 = load i32, ptr %context.field.4855, align 4
  %runtime.ok.4857 = icmp eq i32 %context.value.4856, 0
  br i1 %runtime.ok.4857, label %runtime.continue.4858, label %frame.failure.0
runtime.continue.4858:
  %stack.sub.4859 = sub i32 %context.value.4832, %local.source.extent.4715
  %stack.sub.4860 = sub i32 %stack.sub.4859, %local.old.extent.4787
  %stack.offset.4861 = add i32 %stack.sub.4860, %local.source.extent.4715
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.4829, i32 %stack.offset.4861, i32 %local.source.extent.4715, i32 %local.source.payload.4716, i32 9, i32 4)
  %context.field.4862 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4863 = load i32, ptr %context.field.4862, align 4
  %runtime.ok.4864 = icmp eq i32 %context.value.4863, 0
  br i1 %runtime.ok.4864, label %runtime.continue.4865, label %frame.failure.0
runtime.continue.4865:
  %stack.sub.4866 = sub i32 %context.value.4832, %local.old.extent.4787
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.4866, i32 0, i32 0, i32 0)
  %context.field.4867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4868 = load i32, ptr %context.field.4867, align 4
  %runtime.ok.4869 = icmp eq i32 %context.value.4868, 0
  br i1 %runtime.ok.4869, label %runtime.continue.4870, label %frame.failure.0
runtime.continue.4870:
  %local.shrinks.4871 = icmp ult i32 %local.source.extent.4715, %local.old.extent.4787
  br i1 %local.shrinks.4871, label %local.shrink.4872, label %local.counts.ready.4873
local.shrink.4872:
  %stack.sub.4874 = sub i32 %local.old.extent.4787, %local.source.extent.4715
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.4874)
  %context.field.4875 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4876 = load i32, ptr %context.field.4875, align 4
  %runtime.ok.4877 = icmp eq i32 %context.value.4876, 0
  br i1 %runtime.ok.4877, label %runtime.continue.4878, label %frame.failure.0
runtime.continue.4878:
  br label %local.counts.ready.4873
local.counts.ready.4873:
  %local.payload.delta.4879 = sub i32 %local.source.payload.4716, %local.old.payload.4788
  %stack.sub.4880 = sub i32 0, %local.old.payload.4788
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4880, i32 %local.payload.delta.4879)
  %context.field.4881 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4882 = load i32, ptr %context.field.4881, align 4
  %runtime.ok.4883 = icmp eq i32 %context.value.4882, 0
  br i1 %runtime.ok.4883, label %runtime.continue.4884, label %frame.failure.0
runtime.continue.4884:
  %local.is.active.4885 = load i1, ptr %local.active.58, align 1
  %local.later.offset.4886 = load i32, ptr %local.offset.59, align 4
  %stack.sub.4887 = sub i32 %local.later.offset.4886, %local.old.extent.4787
  %stack.offset.4888 = add i32 %stack.sub.4887, %local.source.extent.4715
  %local.later.offset.selected.4889 = select i1 %local.is.active.4885, i32 %stack.offset.4888, i32 %local.later.offset.4886
  store i32 %local.later.offset.selected.4889, ptr %local.offset.59, align 4
  store i1 true, ptr %local.active.53, align 1
  store i32 %stack.offset.4829, ptr %local.offset.54, align 4
  store i32 %local.source.extent.4715, ptr %local.extent.55, align 4
  store i32 %local.source.payload.4716, ptr %local.payload.56, align 4
  store i32 9, ptr %local.type.57, align 4
  %local.is.active.4890 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4891 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4892 = select i1 %local.is.active.4890, i32 %local.sum.extent.4891, i32 0
  %stack.offset.4893 = add i32 0, %local.sum.selected.4892
  %local.is.active.4894 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4895 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4896 = select i1 %local.is.active.4894, i32 %local.sum.extent.4895, i32 0
  %stack.offset.4897 = add i32 %stack.offset.4893, %local.sum.selected.4896
  %local.is.active.4898 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4899 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4900 = select i1 %local.is.active.4898, i32 %local.sum.extent.4899, i32 0
  %stack.offset.4901 = add i32 %stack.offset.4897, %local.sum.selected.4900
  %local.is.active.4902 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4903 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4904 = select i1 %local.is.active.4902, i32 %local.sum.extent.4903, i32 0
  %stack.offset.4905 = add i32 %stack.offset.4901, %local.sum.selected.4904
  %local.is.active.4906 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4907 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4908 = select i1 %local.is.active.4906, i32 %local.sum.extent.4907, i32 0
  %stack.offset.4909 = add i32 %stack.offset.4905, %local.sum.selected.4908
  %local.is.active.4910 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4911 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4912 = select i1 %local.is.active.4910, i32 %local.sum.extent.4911, i32 0
  %stack.offset.4913 = add i32 %stack.offset.4909, %local.sum.selected.4912
  %local.is.active.4914 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4915 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4916 = select i1 %local.is.active.4914, i32 %local.sum.extent.4915, i32 0
  %stack.offset.4917 = add i32 %stack.offset.4913, %local.sum.selected.4916
  %local.is.active.4918 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4919 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4920 = select i1 %local.is.active.4918, i32 %local.sum.extent.4919, i32 0
  %stack.offset.4921 = add i32 %stack.offset.4917, %local.sum.selected.4920
  %local.is.active.4922 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4923 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4924 = select i1 %local.is.active.4922, i32 %local.sum.extent.4923, i32 0
  %stack.offset.4925 = add i32 %stack.offset.4921, %local.sum.selected.4924
  %local.is.active.4926 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4927 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4928 = select i1 %local.is.active.4926, i32 %local.sum.extent.4927, i32 0
  %stack.offset.4929 = add i32 %stack.offset.4925, %local.sum.selected.4928
  %local.is.active.4930 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.4931 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.4932 = select i1 %local.is.active.4930, i32 %local.sum.extent.4931, i32 0
  %stack.offset.4933 = add i32 %stack.offset.4929, %local.sum.selected.4932
  %local.is.active.4934 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.4935 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.4936 = select i1 %local.is.active.4934, i32 %local.sum.extent.4935, i32 0
  %stack.offset.4937 = add i32 %stack.offset.4933, %local.sum.selected.4936
  %stack.offset.4938 = add i32 %stack.offset.4937, 0
  %stack.offset.4939 = add i32 %context.value.75, %stack.offset.4938
  %cursor.status.4940 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.4939)
  %cursor.ok.4941 = icmp eq i32 %cursor.status.4940, 0
  br i1 %cursor.ok.4941, label %cursor.continue.4942, label %frame.failure.0
cursor.continue.4942:
  %step.status.4943 = call i32 @al_owning_charge_step(ptr %ctx, i32 95)
  %helper.ok.4944 = icmp eq i32 %step.status.4943, 0
  br i1 %helper.ok.4944, label %helper.continue.4945, label %frame.failure.0
helper.continue.4945:
  %local.source.offset.4946 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.4947 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.4948 = load i32, ptr %local.payload.6, align 4
  %context.field.4949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4950 = load i32, ptr %context.field.4949, align 4
  %stack.offset.4951 = add i32 %context.value.4950, %local.source.extent.4947
  %reserve.status.4952 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4951, i32 96)
  %reserve.ok.4953 = icmp eq i32 %reserve.status.4952, 0
  br i1 %reserve.ok.4953, label %reserve.continue.4954, label %frame.failure.0
reserve.continue.4954:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.4950, i32 %local.source.offset.4946, i32 %local.source.extent.4947, i32 %local.source.payload.4948, i32 8)
  %context.field.4955 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4956 = load i32, ptr %context.field.4955, align 4
  %runtime.ok.4957 = icmp eq i32 %context.value.4956, 0
  br i1 %runtime.ok.4957, label %runtime.continue.4958, label %frame.failure.0
runtime.continue.4958:
  %local.is.active.4959 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.4960 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.4961 = select i1 %local.is.active.4959, i32 %local.sum.extent.4960, i32 0
  %stack.offset.4962 = add i32 0, %local.sum.selected.4961
  %local.is.active.4963 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.4964 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.4965 = select i1 %local.is.active.4963, i32 %local.sum.extent.4964, i32 0
  %stack.offset.4966 = add i32 %stack.offset.4962, %local.sum.selected.4965
  %local.is.active.4967 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.4968 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.4969 = select i1 %local.is.active.4967, i32 %local.sum.extent.4968, i32 0
  %stack.offset.4970 = add i32 %stack.offset.4966, %local.sum.selected.4969
  %local.is.active.4971 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.4972 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.4973 = select i1 %local.is.active.4971, i32 %local.sum.extent.4972, i32 0
  %stack.offset.4974 = add i32 %stack.offset.4970, %local.sum.selected.4973
  %local.is.active.4975 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.4976 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.4977 = select i1 %local.is.active.4975, i32 %local.sum.extent.4976, i32 0
  %stack.offset.4978 = add i32 %stack.offset.4974, %local.sum.selected.4977
  %local.is.active.4979 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.4980 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.4981 = select i1 %local.is.active.4979, i32 %local.sum.extent.4980, i32 0
  %stack.offset.4982 = add i32 %stack.offset.4978, %local.sum.selected.4981
  %local.is.active.4983 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.4984 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.4985 = select i1 %local.is.active.4983, i32 %local.sum.extent.4984, i32 0
  %stack.offset.4986 = add i32 %stack.offset.4982, %local.sum.selected.4985
  %local.is.active.4987 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.4988 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.4989 = select i1 %local.is.active.4987, i32 %local.sum.extent.4988, i32 0
  %stack.offset.4990 = add i32 %stack.offset.4986, %local.sum.selected.4989
  %local.is.active.4991 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.4992 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.4993 = select i1 %local.is.active.4991, i32 %local.sum.extent.4992, i32 0
  %stack.offset.4994 = add i32 %stack.offset.4990, %local.sum.selected.4993
  %local.is.active.4995 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.4996 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.4997 = select i1 %local.is.active.4995, i32 %local.sum.extent.4996, i32 0
  %stack.offset.4998 = add i32 %stack.offset.4994, %local.sum.selected.4997
  %local.is.active.4999 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5000 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5001 = select i1 %local.is.active.4999, i32 %local.sum.extent.5000, i32 0
  %stack.offset.5002 = add i32 %stack.offset.4998, %local.sum.selected.5001
  %local.is.active.5003 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5004 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5005 = select i1 %local.is.active.5003, i32 %local.sum.extent.5004, i32 0
  %stack.offset.5006 = add i32 %stack.offset.5002, %local.sum.selected.5005
  %stack.offset.5007 = add i32 0, %local.source.extent.4947
  %stack.offset.5008 = add i32 %stack.offset.5006, %stack.offset.5007
  %stack.offset.5009 = add i32 %context.value.75, %stack.offset.5008
  %cursor.status.5010 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5009)
  %cursor.ok.5011 = icmp eq i32 %cursor.status.5010, 0
  br i1 %cursor.ok.5011, label %cursor.continue.5012, label %frame.failure.0
cursor.continue.5012:
  %step.status.5013 = call i32 @al_owning_charge_step(ptr %ctx, i32 97)
  %helper.ok.5014 = icmp eq i32 %step.status.5013, 0
  br i1 %helper.ok.5014, label %helper.continue.5015, label %frame.failure.0
helper.continue.5015:
  %local.is.active.5016 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5017 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5018 = select i1 %local.is.active.5016, i32 %local.sum.extent.5017, i32 0
  %stack.offset.5019 = add i32 0, %local.sum.selected.5018
  %local.is.active.5020 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5021 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5022 = select i1 %local.is.active.5020, i32 %local.sum.extent.5021, i32 0
  %stack.offset.5023 = add i32 %stack.offset.5019, %local.sum.selected.5022
  %local.is.active.5024 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5025 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5026 = select i1 %local.is.active.5024, i32 %local.sum.extent.5025, i32 0
  %stack.offset.5027 = add i32 %stack.offset.5023, %local.sum.selected.5026
  %local.is.active.5028 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5029 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5030 = select i1 %local.is.active.5028, i32 %local.sum.extent.5029, i32 0
  %stack.offset.5031 = add i32 %stack.offset.5027, %local.sum.selected.5030
  %local.is.active.5032 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5033 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5034 = select i1 %local.is.active.5032, i32 %local.sum.extent.5033, i32 0
  %stack.offset.5035 = add i32 %stack.offset.5031, %local.sum.selected.5034
  %local.is.active.5036 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5037 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5038 = select i1 %local.is.active.5036, i32 %local.sum.extent.5037, i32 0
  %stack.offset.5039 = add i32 %stack.offset.5035, %local.sum.selected.5038
  %local.is.active.5040 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5041 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5042 = select i1 %local.is.active.5040, i32 %local.sum.extent.5041, i32 0
  %stack.offset.5043 = add i32 %stack.offset.5039, %local.sum.selected.5042
  %local.is.active.5044 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5045 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5046 = select i1 %local.is.active.5044, i32 %local.sum.extent.5045, i32 0
  %stack.offset.5047 = add i32 %stack.offset.5043, %local.sum.selected.5046
  %local.is.active.5048 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5049 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5050 = select i1 %local.is.active.5048, i32 %local.sum.extent.5049, i32 0
  %stack.offset.5051 = add i32 %stack.offset.5047, %local.sum.selected.5050
  %local.is.active.5052 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5053 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5054 = select i1 %local.is.active.5052, i32 %local.sum.extent.5053, i32 0
  %stack.offset.5055 = add i32 %stack.offset.5051, %local.sum.selected.5054
  %local.is.active.5056 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5057 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5058 = select i1 %local.is.active.5056, i32 %local.sum.extent.5057, i32 0
  %stack.offset.5059 = add i32 %stack.offset.5055, %local.sum.selected.5058
  %local.is.active.5060 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5061 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5062 = select i1 %local.is.active.5060, i32 %local.sum.extent.5061, i32 0
  %stack.offset.5063 = add i32 %stack.offset.5059, %local.sum.selected.5062
  %stack.offset.5064 = add i32 %stack.offset.5063, 0
  %stack.offset.5065 = add i32 %context.value.75, %stack.offset.5064
  %field.location.5066 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.5067 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.5065, i32 %local.source.extent.4947, i32 1, i32 98, ptr %field.location.5066)
  %helper.ok.5068 = icmp eq i32 %field.location.status.5067, 0
  br i1 %helper.ok.5068, label %helper.continue.5069, label %frame.failure.0
helper.continue.5069:
  %field.offset.pointer.5070 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.5066, i32 0, i32 0
  %field.offset.5071 = load i32, ptr %field.offset.pointer.5070, align 4
  %field.payload.pointer.5072 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.5066, i32 0, i32 1
  %field.payload.5073 = load i32, ptr %field.payload.pointer.5072, align 4
  %field.extent.pointer.5074 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.5066, i32 0, i32 2
  %field.extent.5075 = load i32, ptr %field.extent.pointer.5074, align 4
  %stack.offset.5076 = add i32 %stack.offset.5065, %field.extent.5075
  %context.field.5077 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5078 = load i32, ptr %context.field.5077, align 4
  %field.result.grows.5079 = icmp ugt i32 %stack.offset.5076, %context.value.5078
  br i1 %field.result.grows.5079, label %field.result.reserve.5080, label %field.result.existing.5081
field.result.reserve.5080:
  %reserve.status.5083 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5076, i32 99)
  %reserve.ok.5084 = icmp eq i32 %reserve.status.5083, 0
  br i1 %reserve.ok.5084, label %reserve.continue.5085, label %frame.failure.0
reserve.continue.5085:
  br label %field.result.ready.5082
field.result.existing.5081:
  br label %field.result.ready.5082
field.result.ready.5082:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5065, i32 %field.offset.5071, i32 %field.extent.5075, i32 %field.payload.5073, i32 1, i32 7)
  %context.field.5086 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5087 = load i32, ptr %context.field.5086, align 4
  %runtime.ok.5088 = icmp eq i32 %context.value.5087, 0
  br i1 %runtime.ok.5088, label %runtime.continue.5089, label %frame.failure.0
runtime.continue.5089:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.5076, i32 0, i32 0, i32 0)
  %context.field.5090 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5091 = load i32, ptr %context.field.5090, align 4
  %runtime.ok.5092 = icmp eq i32 %context.value.5091, 0
  br i1 %runtime.ok.5092, label %runtime.continue.5093, label %frame.failure.0
runtime.continue.5093:
  %stack.sub.5094 = sub i32 %field.payload.5073, %local.source.payload.4948
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5094, i32 0)
  %context.field.5095 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5096 = load i32, ptr %context.field.5095, align 4
  %runtime.ok.5097 = icmp eq i32 %context.value.5096, 0
  br i1 %runtime.ok.5097, label %runtime.continue.5098, label %frame.failure.0
runtime.continue.5098:
  %local.is.active.5099 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5100 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5101 = select i1 %local.is.active.5099, i32 %local.sum.extent.5100, i32 0
  %stack.offset.5102 = add i32 0, %local.sum.selected.5101
  %local.is.active.5103 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5104 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5105 = select i1 %local.is.active.5103, i32 %local.sum.extent.5104, i32 0
  %stack.offset.5106 = add i32 %stack.offset.5102, %local.sum.selected.5105
  %local.is.active.5107 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5108 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5109 = select i1 %local.is.active.5107, i32 %local.sum.extent.5108, i32 0
  %stack.offset.5110 = add i32 %stack.offset.5106, %local.sum.selected.5109
  %local.is.active.5111 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5112 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5113 = select i1 %local.is.active.5111, i32 %local.sum.extent.5112, i32 0
  %stack.offset.5114 = add i32 %stack.offset.5110, %local.sum.selected.5113
  %local.is.active.5115 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5116 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5117 = select i1 %local.is.active.5115, i32 %local.sum.extent.5116, i32 0
  %stack.offset.5118 = add i32 %stack.offset.5114, %local.sum.selected.5117
  %local.is.active.5119 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5120 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5121 = select i1 %local.is.active.5119, i32 %local.sum.extent.5120, i32 0
  %stack.offset.5122 = add i32 %stack.offset.5118, %local.sum.selected.5121
  %local.is.active.5123 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5124 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5125 = select i1 %local.is.active.5123, i32 %local.sum.extent.5124, i32 0
  %stack.offset.5126 = add i32 %stack.offset.5122, %local.sum.selected.5125
  %local.is.active.5127 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5128 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5129 = select i1 %local.is.active.5127, i32 %local.sum.extent.5128, i32 0
  %stack.offset.5130 = add i32 %stack.offset.5126, %local.sum.selected.5129
  %local.is.active.5131 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5132 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5133 = select i1 %local.is.active.5131, i32 %local.sum.extent.5132, i32 0
  %stack.offset.5134 = add i32 %stack.offset.5130, %local.sum.selected.5133
  %local.is.active.5135 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5136 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5137 = select i1 %local.is.active.5135, i32 %local.sum.extent.5136, i32 0
  %stack.offset.5138 = add i32 %stack.offset.5134, %local.sum.selected.5137
  %local.is.active.5139 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5140 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5141 = select i1 %local.is.active.5139, i32 %local.sum.extent.5140, i32 0
  %stack.offset.5142 = add i32 %stack.offset.5138, %local.sum.selected.5141
  %local.is.active.5143 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5144 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5145 = select i1 %local.is.active.5143, i32 %local.sum.extent.5144, i32 0
  %stack.offset.5146 = add i32 %stack.offset.5142, %local.sum.selected.5145
  %stack.offset.5147 = add i32 0, %field.extent.5075
  %stack.offset.5148 = add i32 %stack.offset.5146, %stack.offset.5147
  %stack.offset.5149 = add i32 %context.value.75, %stack.offset.5148
  %cursor.status.5150 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5149)
  %cursor.ok.5151 = icmp eq i32 %cursor.status.5150, 0
  br i1 %cursor.ok.5151, label %cursor.continue.5152, label %frame.failure.0
cursor.continue.5152:
  %step.status.5153 = call i32 @al_owning_charge_step(ptr %ctx, i32 100)
  %helper.ok.5154 = icmp eq i32 %step.status.5153, 0
  br i1 %helper.ok.5154, label %helper.continue.5155, label %frame.failure.0
helper.continue.5155:
  %context.field.5156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5157 = load i32, ptr %context.field.5156, align 4
  %stack.offset.5158 = add i32 %context.value.5157, 8
  %reserve.status.5159 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5158, i32 101)
  %reserve.ok.5160 = icmp eq i32 %reserve.status.5159, 0
  br i1 %reserve.ok.5160, label %reserve.continue.5161, label %frame.failure.0
reserve.continue.5161:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.5157, i64 1, i32 1)
  %context.field.5162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5163 = load i32, ptr %context.field.5162, align 4
  %runtime.ok.5164 = icmp eq i32 %context.value.5163, 0
  br i1 %runtime.ok.5164, label %runtime.continue.5165, label %frame.failure.0
runtime.continue.5165:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.5166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5167 = load i32, ptr %context.field.5166, align 4
  %runtime.ok.5168 = icmp eq i32 %context.value.5167, 0
  br i1 %runtime.ok.5168, label %runtime.continue.5169, label %frame.failure.0
runtime.continue.5169:
  %local.is.active.5170 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5171 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5172 = select i1 %local.is.active.5170, i32 %local.sum.extent.5171, i32 0
  %stack.offset.5173 = add i32 0, %local.sum.selected.5172
  %local.is.active.5174 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5175 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5176 = select i1 %local.is.active.5174, i32 %local.sum.extent.5175, i32 0
  %stack.offset.5177 = add i32 %stack.offset.5173, %local.sum.selected.5176
  %local.is.active.5178 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5179 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5180 = select i1 %local.is.active.5178, i32 %local.sum.extent.5179, i32 0
  %stack.offset.5181 = add i32 %stack.offset.5177, %local.sum.selected.5180
  %local.is.active.5182 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5183 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5184 = select i1 %local.is.active.5182, i32 %local.sum.extent.5183, i32 0
  %stack.offset.5185 = add i32 %stack.offset.5181, %local.sum.selected.5184
  %local.is.active.5186 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5187 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5188 = select i1 %local.is.active.5186, i32 %local.sum.extent.5187, i32 0
  %stack.offset.5189 = add i32 %stack.offset.5185, %local.sum.selected.5188
  %local.is.active.5190 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5191 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5192 = select i1 %local.is.active.5190, i32 %local.sum.extent.5191, i32 0
  %stack.offset.5193 = add i32 %stack.offset.5189, %local.sum.selected.5192
  %local.is.active.5194 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5195 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5196 = select i1 %local.is.active.5194, i32 %local.sum.extent.5195, i32 0
  %stack.offset.5197 = add i32 %stack.offset.5193, %local.sum.selected.5196
  %local.is.active.5198 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5199 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5200 = select i1 %local.is.active.5198, i32 %local.sum.extent.5199, i32 0
  %stack.offset.5201 = add i32 %stack.offset.5197, %local.sum.selected.5200
  %local.is.active.5202 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5203 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5204 = select i1 %local.is.active.5202, i32 %local.sum.extent.5203, i32 0
  %stack.offset.5205 = add i32 %stack.offset.5201, %local.sum.selected.5204
  %local.is.active.5206 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5207 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5208 = select i1 %local.is.active.5206, i32 %local.sum.extent.5207, i32 0
  %stack.offset.5209 = add i32 %stack.offset.5205, %local.sum.selected.5208
  %local.is.active.5210 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5211 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5212 = select i1 %local.is.active.5210, i32 %local.sum.extent.5211, i32 0
  %stack.offset.5213 = add i32 %stack.offset.5209, %local.sum.selected.5212
  %local.is.active.5214 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5215 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5216 = select i1 %local.is.active.5214, i32 %local.sum.extent.5215, i32 0
  %stack.offset.5217 = add i32 %stack.offset.5213, %local.sum.selected.5216
  %stack.offset.5218 = add i32 0, %field.extent.5075
  %stack.offset.5219 = add i32 %stack.offset.5218, 8
  %stack.offset.5220 = add i32 %stack.offset.5217, %stack.offset.5219
  %stack.offset.5221 = add i32 %context.value.75, %stack.offset.5220
  %cursor.status.5222 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5221)
  %cursor.ok.5223 = icmp eq i32 %cursor.status.5222, 0
  br i1 %cursor.ok.5223, label %cursor.continue.5224, label %frame.failure.0
cursor.continue.5224:
  %step.status.5225 = call i32 @al_owning_charge_step(ptr %ctx, i32 102)
  %helper.ok.5226 = icmp eq i32 %step.status.5225, 0
  br i1 %helper.ok.5226, label %helper.continue.5227, label %frame.failure.0
helper.continue.5227:
  %context.field.5228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5229 = load i32, ptr %context.field.5228, align 4
  %stack.sub.5230 = sub i32 %context.value.5229, 8
  %stack.sub.5231 = sub i32 %stack.sub.5230, %field.extent.5075
  %integer.left.5232 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.5231)
  %context.field.5234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5235 = load i32, ptr %context.field.5234, align 4
  %runtime.ok.5236 = icmp eq i32 %context.value.5235, 0
  br i1 %runtime.ok.5236, label %runtime.continue.5237, label %frame.failure.0
runtime.continue.5237:
  %integer.right.5233 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.5230)
  %context.field.5238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5239 = load i32, ptr %context.field.5238, align 4
  %runtime.ok.5240 = icmp eq i32 %context.value.5239, 0
  br i1 %runtime.ok.5240, label %runtime.continue.5241, label %frame.failure.0
runtime.continue.5241:
  %integer.checked.5242 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.5232, i64 %integer.right.5233)
  %integer.result.5243 = extractvalue { i64, i1 } %integer.checked.5242, 0
  %integer.overflow.5244 = extractvalue { i64, i1 } %integer.checked.5242, 1
  br i1 %integer.overflow.5244, label %integer.overflow.5245, label %integer.valid.5246
integer.overflow.5245:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 103, i32 0, i32 0)
  br label %frame.failure.0
integer.valid.5246:
  %context.field.5247 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5248 = load i32, ptr %context.field.5247, align 4
  %stack.sub.5249 = sub i32 %context.value.5248, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.5249, i32 8, i32 8, i32 1)
  %context.field.5250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5251 = load i32, ptr %context.field.5250, align 4
  %runtime.ok.5252 = icmp eq i32 %context.value.5251, 0
  br i1 %runtime.ok.5252, label %runtime.continue.5253, label %frame.failure.0
runtime.continue.5253:
  %context.field.5254 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5255 = load i32, ptr %context.field.5254, align 4
  %stack.sub.5256 = sub i32 %context.value.5255, %field.extent.5075
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.5256, i32 %field.extent.5075, i32 %field.payload.5073, i32 1)
  %context.field.5257 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5258 = load i32, ptr %context.field.5257, align 4
  %runtime.ok.5259 = icmp eq i32 %context.value.5258, 0
  br i1 %runtime.ok.5259, label %runtime.continue.5260, label %frame.failure.0
runtime.continue.5260:
  %context.field.5261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5262 = load i32, ptr %context.field.5261, align 4
  %stack.offset.5263 = add i32 %context.value.5262, 8
  %reserve.status.5264 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5263, i32 104)
  %reserve.ok.5265 = icmp eq i32 %reserve.status.5264, 0
  br i1 %reserve.ok.5265, label %reserve.continue.5266, label %frame.failure.0
reserve.continue.5266:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.5262, i64 %integer.result.5243, i32 1)
  %context.field.5267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5268 = load i32, ptr %context.field.5267, align 4
  %runtime.ok.5269 = icmp eq i32 %context.value.5268, 0
  br i1 %runtime.ok.5269, label %runtime.continue.5270, label %frame.failure.0
runtime.continue.5270:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.5271 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5272 = load i32, ptr %context.field.5271, align 4
  %runtime.ok.5273 = icmp eq i32 %context.value.5272, 0
  br i1 %runtime.ok.5273, label %runtime.continue.5274, label %frame.failure.0
runtime.continue.5274:
  %local.is.active.5275 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5276 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5277 = select i1 %local.is.active.5275, i32 %local.sum.extent.5276, i32 0
  %stack.offset.5278 = add i32 0, %local.sum.selected.5277
  %local.is.active.5279 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5280 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5281 = select i1 %local.is.active.5279, i32 %local.sum.extent.5280, i32 0
  %stack.offset.5282 = add i32 %stack.offset.5278, %local.sum.selected.5281
  %local.is.active.5283 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5284 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5285 = select i1 %local.is.active.5283, i32 %local.sum.extent.5284, i32 0
  %stack.offset.5286 = add i32 %stack.offset.5282, %local.sum.selected.5285
  %local.is.active.5287 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5288 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5289 = select i1 %local.is.active.5287, i32 %local.sum.extent.5288, i32 0
  %stack.offset.5290 = add i32 %stack.offset.5286, %local.sum.selected.5289
  %local.is.active.5291 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5292 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5293 = select i1 %local.is.active.5291, i32 %local.sum.extent.5292, i32 0
  %stack.offset.5294 = add i32 %stack.offset.5290, %local.sum.selected.5293
  %local.is.active.5295 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5296 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5297 = select i1 %local.is.active.5295, i32 %local.sum.extent.5296, i32 0
  %stack.offset.5298 = add i32 %stack.offset.5294, %local.sum.selected.5297
  %local.is.active.5299 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5300 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5301 = select i1 %local.is.active.5299, i32 %local.sum.extent.5300, i32 0
  %stack.offset.5302 = add i32 %stack.offset.5298, %local.sum.selected.5301
  %local.is.active.5303 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5304 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5305 = select i1 %local.is.active.5303, i32 %local.sum.extent.5304, i32 0
  %stack.offset.5306 = add i32 %stack.offset.5302, %local.sum.selected.5305
  %local.is.active.5307 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5308 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5309 = select i1 %local.is.active.5307, i32 %local.sum.extent.5308, i32 0
  %stack.offset.5310 = add i32 %stack.offset.5306, %local.sum.selected.5309
  %local.is.active.5311 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5312 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5313 = select i1 %local.is.active.5311, i32 %local.sum.extent.5312, i32 0
  %stack.offset.5314 = add i32 %stack.offset.5310, %local.sum.selected.5313
  %local.is.active.5315 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5316 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5317 = select i1 %local.is.active.5315, i32 %local.sum.extent.5316, i32 0
  %stack.offset.5318 = add i32 %stack.offset.5314, %local.sum.selected.5317
  %local.is.active.5319 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5320 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5321 = select i1 %local.is.active.5319, i32 %local.sum.extent.5320, i32 0
  %stack.offset.5322 = add i32 %stack.offset.5318, %local.sum.selected.5321
  %stack.offset.5323 = add i32 0, 8
  %stack.offset.5324 = add i32 %stack.offset.5322, %stack.offset.5323
  %stack.offset.5325 = add i32 %context.value.75, %stack.offset.5324
  %cursor.status.5326 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5325)
  %cursor.ok.5327 = icmp eq i32 %cursor.status.5326, 0
  br i1 %cursor.ok.5327, label %cursor.continue.5328, label %frame.failure.0
cursor.continue.5328:
  %step.status.5329 = call i32 @al_owning_charge_step(ptr %ctx, i32 105)
  %helper.ok.5330 = icmp eq i32 %step.status.5329, 0
  br i1 %helper.ok.5330, label %helper.continue.5331, label %frame.failure.0
helper.continue.5331:
  %local.is.active.5332 = load i1, ptr %local.active.58, align 1
  %local.previous.extent.5333 = load i32, ptr %local.extent.60, align 4
  %local.previous.payload.5334 = load i32, ptr %local.payload.61, align 4
  %local.old.extent.5335 = select i1 %local.is.active.5332, i32 %local.previous.extent.5333, i32 0
  %local.old.payload.5336 = select i1 %local.is.active.5332, i32 %local.previous.payload.5334, i32 0
  %local.is.active.5337 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5338 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5339 = select i1 %local.is.active.5337, i32 %local.sum.extent.5338, i32 0
  %stack.offset.5340 = add i32 0, %local.sum.selected.5339
  %local.is.active.5341 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5342 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5343 = select i1 %local.is.active.5341, i32 %local.sum.extent.5342, i32 0
  %stack.offset.5344 = add i32 %stack.offset.5340, %local.sum.selected.5343
  %local.is.active.5345 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5346 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5347 = select i1 %local.is.active.5345, i32 %local.sum.extent.5346, i32 0
  %stack.offset.5348 = add i32 %stack.offset.5344, %local.sum.selected.5347
  %local.is.active.5349 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5350 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5351 = select i1 %local.is.active.5349, i32 %local.sum.extent.5350, i32 0
  %stack.offset.5352 = add i32 %stack.offset.5348, %local.sum.selected.5351
  %local.is.active.5353 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5354 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5355 = select i1 %local.is.active.5353, i32 %local.sum.extent.5354, i32 0
  %stack.offset.5356 = add i32 %stack.offset.5352, %local.sum.selected.5355
  %local.is.active.5357 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5358 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5359 = select i1 %local.is.active.5357, i32 %local.sum.extent.5358, i32 0
  %stack.offset.5360 = add i32 %stack.offset.5356, %local.sum.selected.5359
  %local.is.active.5361 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5362 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5363 = select i1 %local.is.active.5361, i32 %local.sum.extent.5362, i32 0
  %stack.offset.5364 = add i32 %stack.offset.5360, %local.sum.selected.5363
  %local.is.active.5365 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5366 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5367 = select i1 %local.is.active.5365, i32 %local.sum.extent.5366, i32 0
  %stack.offset.5368 = add i32 %stack.offset.5364, %local.sum.selected.5367
  %local.is.active.5369 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5370 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5371 = select i1 %local.is.active.5369, i32 %local.sum.extent.5370, i32 0
  %stack.offset.5372 = add i32 %stack.offset.5368, %local.sum.selected.5371
  %local.is.active.5373 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5374 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5375 = select i1 %local.is.active.5373, i32 %local.sum.extent.5374, i32 0
  %stack.offset.5376 = add i32 %stack.offset.5372, %local.sum.selected.5375
  %local.is.active.5377 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5378 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5379 = select i1 %local.is.active.5377, i32 %local.sum.extent.5378, i32 0
  %stack.offset.5380 = add i32 %stack.offset.5376, %local.sum.selected.5379
  %stack.offset.5381 = add i32 %context.value.75, %stack.offset.5380
  %stack.offset.5382 = add i32 %stack.offset.5381, %local.old.extent.5335
  %context.field.5383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5384 = load i32, ptr %context.field.5383, align 4
  %stack.sub.5385 = sub i32 %context.value.5384, %stack.offset.5382
  %stack.sub.5386 = sub i32 %context.value.5384, %local.old.extent.5335
  %stack.offset.5387 = add i32 %stack.sub.5386, 8
  %local.grows.5388 = icmp ugt i32 8, %local.old.extent.5335
  br i1 %local.grows.5388, label %local.grow.5389, label %local.fixed.5390
local.grow.5389:
  %reserve.status.5392 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5387, i32 106)
  %reserve.ok.5393 = icmp eq i32 %reserve.status.5392, 0
  br i1 %reserve.ok.5393, label %reserve.continue.5394, label %frame.failure.0
reserve.continue.5394:
  %stack.sub.5395 = sub i32 8, %local.old.extent.5335
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.5395)
  %context.field.5396 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5397 = load i32, ptr %context.field.5396, align 4
  %runtime.ok.5398 = icmp eq i32 %context.value.5397, 0
  br i1 %runtime.ok.5398, label %runtime.continue.5399, label %frame.failure.0
runtime.continue.5399:
  br label %local.layout.ready.5391
local.fixed.5390:
  br label %local.layout.ready.5391
local.layout.ready.5391:
  %stack.offset.5400 = add i32 %stack.offset.5381, 8
  %stack.offset.5401 = add i32 0, 8
  %stack.offset.5402 = add i32 0, %stack.offset.5401
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5400, i32 %stack.offset.5382, i32 %stack.sub.5385, i32 %stack.offset.5402, i32 0, i32 14)
  %context.field.5403 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5404 = load i32, ptr %context.field.5403, align 4
  %runtime.ok.5405 = icmp eq i32 %context.value.5404, 0
  br i1 %runtime.ok.5405, label %runtime.continue.5406, label %frame.failure.0
runtime.continue.5406:
  %stack.sub.5407 = sub i32 %context.value.5384, 8
  %stack.sub.5408 = sub i32 %stack.sub.5407, %local.old.extent.5335
  %stack.offset.5409 = add i32 %stack.sub.5408, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5381, i32 %stack.offset.5409, i32 8, i32 8, i32 1, i32 4)
  %context.field.5410 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5411 = load i32, ptr %context.field.5410, align 4
  %runtime.ok.5412 = icmp eq i32 %context.value.5411, 0
  br i1 %runtime.ok.5412, label %runtime.continue.5413, label %frame.failure.0
runtime.continue.5413:
  %stack.sub.5414 = sub i32 %context.value.5384, %local.old.extent.5335
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.5414, i32 0, i32 0, i32 0)
  %context.field.5415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5416 = load i32, ptr %context.field.5415, align 4
  %runtime.ok.5417 = icmp eq i32 %context.value.5416, 0
  br i1 %runtime.ok.5417, label %runtime.continue.5418, label %frame.failure.0
runtime.continue.5418:
  %local.shrinks.5419 = icmp ult i32 8, %local.old.extent.5335
  br i1 %local.shrinks.5419, label %local.shrink.5420, label %local.counts.ready.5421
local.shrink.5420:
  %stack.sub.5422 = sub i32 %local.old.extent.5335, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.5422)
  %context.field.5423 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5424 = load i32, ptr %context.field.5423, align 4
  %runtime.ok.5425 = icmp eq i32 %context.value.5424, 0
  br i1 %runtime.ok.5425, label %runtime.continue.5426, label %frame.failure.0
runtime.continue.5426:
  br label %local.counts.ready.5421
local.counts.ready.5421:
  %local.payload.delta.5427 = sub i32 8, %local.old.payload.5336
  %stack.sub.5428 = sub i32 0, %local.old.payload.5336
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5428, i32 %local.payload.delta.5427)
  %context.field.5429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5430 = load i32, ptr %context.field.5429, align 4
  %runtime.ok.5431 = icmp eq i32 %context.value.5430, 0
  br i1 %runtime.ok.5431, label %runtime.continue.5432, label %frame.failure.0
runtime.continue.5432:
  store i1 true, ptr %local.active.58, align 1
  store i32 %stack.offset.5381, ptr %local.offset.59, align 4
  store i32 8, ptr %local.extent.60, align 4
  store i32 8, ptr %local.payload.61, align 4
  store i32 1, ptr %local.type.62, align 4
  %local.is.active.5433 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5434 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5435 = select i1 %local.is.active.5433, i32 %local.sum.extent.5434, i32 0
  %stack.offset.5436 = add i32 0, %local.sum.selected.5435
  %local.is.active.5437 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5438 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5439 = select i1 %local.is.active.5437, i32 %local.sum.extent.5438, i32 0
  %stack.offset.5440 = add i32 %stack.offset.5436, %local.sum.selected.5439
  %local.is.active.5441 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5442 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5443 = select i1 %local.is.active.5441, i32 %local.sum.extent.5442, i32 0
  %stack.offset.5444 = add i32 %stack.offset.5440, %local.sum.selected.5443
  %local.is.active.5445 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5446 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5447 = select i1 %local.is.active.5445, i32 %local.sum.extent.5446, i32 0
  %stack.offset.5448 = add i32 %stack.offset.5444, %local.sum.selected.5447
  %local.is.active.5449 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5450 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5451 = select i1 %local.is.active.5449, i32 %local.sum.extent.5450, i32 0
  %stack.offset.5452 = add i32 %stack.offset.5448, %local.sum.selected.5451
  %local.is.active.5453 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5454 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5455 = select i1 %local.is.active.5453, i32 %local.sum.extent.5454, i32 0
  %stack.offset.5456 = add i32 %stack.offset.5452, %local.sum.selected.5455
  %local.is.active.5457 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5458 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5459 = select i1 %local.is.active.5457, i32 %local.sum.extent.5458, i32 0
  %stack.offset.5460 = add i32 %stack.offset.5456, %local.sum.selected.5459
  %local.is.active.5461 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5462 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5463 = select i1 %local.is.active.5461, i32 %local.sum.extent.5462, i32 0
  %stack.offset.5464 = add i32 %stack.offset.5460, %local.sum.selected.5463
  %local.is.active.5465 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5466 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5467 = select i1 %local.is.active.5465, i32 %local.sum.extent.5466, i32 0
  %stack.offset.5468 = add i32 %stack.offset.5464, %local.sum.selected.5467
  %local.is.active.5469 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5470 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5471 = select i1 %local.is.active.5469, i32 %local.sum.extent.5470, i32 0
  %stack.offset.5472 = add i32 %stack.offset.5468, %local.sum.selected.5471
  %local.is.active.5473 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5474 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5475 = select i1 %local.is.active.5473, i32 %local.sum.extent.5474, i32 0
  %stack.offset.5476 = add i32 %stack.offset.5472, %local.sum.selected.5475
  %local.is.active.5477 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5478 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5479 = select i1 %local.is.active.5477, i32 %local.sum.extent.5478, i32 0
  %stack.offset.5480 = add i32 %stack.offset.5476, %local.sum.selected.5479
  %stack.offset.5481 = add i32 %stack.offset.5480, 0
  %stack.offset.5482 = add i32 %context.value.75, %stack.offset.5481
  %cursor.status.5483 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5482)
  %cursor.ok.5484 = icmp eq i32 %cursor.status.5483, 0
  br i1 %cursor.ok.5484, label %cursor.continue.5485, label %frame.failure.0
cursor.continue.5485:
  %step.status.5486 = call i32 @al_owning_charge_step(ptr %ctx, i32 107)
  %helper.ok.5487 = icmp eq i32 %step.status.5486, 0
  br i1 %helper.ok.5487, label %helper.continue.5488, label %frame.failure.0
helper.continue.5488:
  %local.source.offset.5489 = load i32, ptr %local.offset.54, align 4
  %local.source.extent.5490 = load i32, ptr %local.extent.55, align 4
  %local.source.payload.5491 = load i32, ptr %local.payload.56, align 4
  %context.field.5492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5493 = load i32, ptr %context.field.5492, align 4
  %stack.offset.5494 = add i32 %context.value.5493, %local.source.extent.5490
  %reserve.status.5495 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5494, i32 108)
  %reserve.ok.5496 = icmp eq i32 %reserve.status.5495, 0
  br i1 %reserve.ok.5496, label %reserve.continue.5497, label %frame.failure.0
reserve.continue.5497:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.5493, i32 %local.source.offset.5489, i32 %local.source.extent.5490, i32 %local.source.payload.5491, i32 9)
  %context.field.5498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5499 = load i32, ptr %context.field.5498, align 4
  %runtime.ok.5500 = icmp eq i32 %context.value.5499, 0
  br i1 %runtime.ok.5500, label %runtime.continue.5501, label %frame.failure.0
runtime.continue.5501:
  %local.is.active.5502 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5503 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5504 = select i1 %local.is.active.5502, i32 %local.sum.extent.5503, i32 0
  %stack.offset.5505 = add i32 0, %local.sum.selected.5504
  %local.is.active.5506 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5507 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5508 = select i1 %local.is.active.5506, i32 %local.sum.extent.5507, i32 0
  %stack.offset.5509 = add i32 %stack.offset.5505, %local.sum.selected.5508
  %local.is.active.5510 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5511 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5512 = select i1 %local.is.active.5510, i32 %local.sum.extent.5511, i32 0
  %stack.offset.5513 = add i32 %stack.offset.5509, %local.sum.selected.5512
  %local.is.active.5514 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5515 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5516 = select i1 %local.is.active.5514, i32 %local.sum.extent.5515, i32 0
  %stack.offset.5517 = add i32 %stack.offset.5513, %local.sum.selected.5516
  %local.is.active.5518 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5519 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5520 = select i1 %local.is.active.5518, i32 %local.sum.extent.5519, i32 0
  %stack.offset.5521 = add i32 %stack.offset.5517, %local.sum.selected.5520
  %local.is.active.5522 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5523 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5524 = select i1 %local.is.active.5522, i32 %local.sum.extent.5523, i32 0
  %stack.offset.5525 = add i32 %stack.offset.5521, %local.sum.selected.5524
  %local.is.active.5526 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5527 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5528 = select i1 %local.is.active.5526, i32 %local.sum.extent.5527, i32 0
  %stack.offset.5529 = add i32 %stack.offset.5525, %local.sum.selected.5528
  %local.is.active.5530 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5531 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5532 = select i1 %local.is.active.5530, i32 %local.sum.extent.5531, i32 0
  %stack.offset.5533 = add i32 %stack.offset.5529, %local.sum.selected.5532
  %local.is.active.5534 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5535 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5536 = select i1 %local.is.active.5534, i32 %local.sum.extent.5535, i32 0
  %stack.offset.5537 = add i32 %stack.offset.5533, %local.sum.selected.5536
  %local.is.active.5538 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5539 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5540 = select i1 %local.is.active.5538, i32 %local.sum.extent.5539, i32 0
  %stack.offset.5541 = add i32 %stack.offset.5537, %local.sum.selected.5540
  %local.is.active.5542 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5543 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5544 = select i1 %local.is.active.5542, i32 %local.sum.extent.5543, i32 0
  %stack.offset.5545 = add i32 %stack.offset.5541, %local.sum.selected.5544
  %local.is.active.5546 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5547 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5548 = select i1 %local.is.active.5546, i32 %local.sum.extent.5547, i32 0
  %stack.offset.5549 = add i32 %stack.offset.5545, %local.sum.selected.5548
  %stack.offset.5550 = add i32 0, %local.source.extent.5490
  %stack.offset.5551 = add i32 %stack.offset.5549, %stack.offset.5550
  %stack.offset.5552 = add i32 %context.value.75, %stack.offset.5551
  %cursor.status.5553 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5552)
  %cursor.ok.5554 = icmp eq i32 %cursor.status.5553, 0
  br i1 %cursor.ok.5554, label %cursor.continue.5555, label %frame.failure.0
cursor.continue.5555:
  %step.status.5556 = call i32 @al_owning_charge_step(ptr %ctx, i32 109)
  %helper.ok.5557 = icmp eq i32 %step.status.5556, 0
  br i1 %helper.ok.5557, label %helper.continue.5558, label %frame.failure.0
helper.continue.5558:
  %local.source.offset.5559 = load i32, ptr %local.offset.59, align 4
  %local.source.extent.5560 = load i32, ptr %local.extent.60, align 4
  %local.source.payload.5561 = load i32, ptr %local.payload.61, align 4
  %context.field.5562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5563 = load i32, ptr %context.field.5562, align 4
  %stack.offset.5564 = add i32 %context.value.5563, %local.source.extent.5560
  %reserve.status.5565 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5564, i32 110)
  %reserve.ok.5566 = icmp eq i32 %reserve.status.5565, 0
  br i1 %reserve.ok.5566, label %reserve.continue.5567, label %frame.failure.0
reserve.continue.5567:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.5563, i32 %local.source.offset.5559, i32 %local.source.extent.5560, i32 %local.source.payload.5561, i32 1)
  %context.field.5568 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5569 = load i32, ptr %context.field.5568, align 4
  %runtime.ok.5570 = icmp eq i32 %context.value.5569, 0
  br i1 %runtime.ok.5570, label %runtime.continue.5571, label %frame.failure.0
runtime.continue.5571:
  %local.is.active.5572 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5573 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5574 = select i1 %local.is.active.5572, i32 %local.sum.extent.5573, i32 0
  %stack.offset.5575 = add i32 0, %local.sum.selected.5574
  %local.is.active.5576 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5577 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5578 = select i1 %local.is.active.5576, i32 %local.sum.extent.5577, i32 0
  %stack.offset.5579 = add i32 %stack.offset.5575, %local.sum.selected.5578
  %local.is.active.5580 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5581 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5582 = select i1 %local.is.active.5580, i32 %local.sum.extent.5581, i32 0
  %stack.offset.5583 = add i32 %stack.offset.5579, %local.sum.selected.5582
  %local.is.active.5584 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5585 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5586 = select i1 %local.is.active.5584, i32 %local.sum.extent.5585, i32 0
  %stack.offset.5587 = add i32 %stack.offset.5583, %local.sum.selected.5586
  %local.is.active.5588 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5589 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5590 = select i1 %local.is.active.5588, i32 %local.sum.extent.5589, i32 0
  %stack.offset.5591 = add i32 %stack.offset.5587, %local.sum.selected.5590
  %local.is.active.5592 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5593 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5594 = select i1 %local.is.active.5592, i32 %local.sum.extent.5593, i32 0
  %stack.offset.5595 = add i32 %stack.offset.5591, %local.sum.selected.5594
  %local.is.active.5596 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5597 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5598 = select i1 %local.is.active.5596, i32 %local.sum.extent.5597, i32 0
  %stack.offset.5599 = add i32 %stack.offset.5595, %local.sum.selected.5598
  %local.is.active.5600 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5601 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5602 = select i1 %local.is.active.5600, i32 %local.sum.extent.5601, i32 0
  %stack.offset.5603 = add i32 %stack.offset.5599, %local.sum.selected.5602
  %local.is.active.5604 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5605 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5606 = select i1 %local.is.active.5604, i32 %local.sum.extent.5605, i32 0
  %stack.offset.5607 = add i32 %stack.offset.5603, %local.sum.selected.5606
  %local.is.active.5608 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5609 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5610 = select i1 %local.is.active.5608, i32 %local.sum.extent.5609, i32 0
  %stack.offset.5611 = add i32 %stack.offset.5607, %local.sum.selected.5610
  %local.is.active.5612 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5613 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5614 = select i1 %local.is.active.5612, i32 %local.sum.extent.5613, i32 0
  %stack.offset.5615 = add i32 %stack.offset.5611, %local.sum.selected.5614
  %local.is.active.5616 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5617 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5618 = select i1 %local.is.active.5616, i32 %local.sum.extent.5617, i32 0
  %stack.offset.5619 = add i32 %stack.offset.5615, %local.sum.selected.5618
  %stack.offset.5620 = add i32 0, %local.source.extent.5490
  %stack.offset.5621 = add i32 %stack.offset.5620, %local.source.extent.5560
  %stack.offset.5622 = add i32 %stack.offset.5619, %stack.offset.5621
  %stack.offset.5623 = add i32 %context.value.75, %stack.offset.5622
  %cursor.status.5624 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5623)
  %cursor.ok.5625 = icmp eq i32 %cursor.status.5624, 0
  br i1 %cursor.ok.5625, label %cursor.continue.5626, label %frame.failure.0
cursor.continue.5626:
  %step.status.5627 = call i32 @al_owning_charge_step(ptr %ctx, i32 111)
  %helper.ok.5628 = icmp eq i32 %step.status.5627, 0
  br i1 %helper.ok.5628, label %helper.continue.5629, label %frame.failure.0
helper.continue.5629:
  %stack.offset.5630 = add i32 0, %local.source.payload.5491
  %stack.offset.5631 = add i32 %stack.offset.5630, %local.source.payload.5561
  %stack.offset.5632 = add i32 0, %local.source.extent.5490
  %stack.offset.5633 = add i32 %stack.offset.5632, %local.source.extent.5560
  %context.field.5634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5635 = load i32, ptr %context.field.5634, align 4
  %local.is.active.5636 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5637 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5638 = select i1 %local.is.active.5636, i32 %local.sum.extent.5637, i32 0
  %stack.offset.5639 = add i32 0, %local.sum.selected.5638
  %local.is.active.5640 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5641 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5642 = select i1 %local.is.active.5640, i32 %local.sum.extent.5641, i32 0
  %stack.offset.5643 = add i32 %stack.offset.5639, %local.sum.selected.5642
  %local.is.active.5644 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5645 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5646 = select i1 %local.is.active.5644, i32 %local.sum.extent.5645, i32 0
  %stack.offset.5647 = add i32 %stack.offset.5643, %local.sum.selected.5646
  %local.is.active.5648 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5649 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5650 = select i1 %local.is.active.5648, i32 %local.sum.extent.5649, i32 0
  %stack.offset.5651 = add i32 %stack.offset.5647, %local.sum.selected.5650
  %local.is.active.5652 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5653 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5654 = select i1 %local.is.active.5652, i32 %local.sum.extent.5653, i32 0
  %stack.offset.5655 = add i32 %stack.offset.5651, %local.sum.selected.5654
  %local.is.active.5656 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5657 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5658 = select i1 %local.is.active.5656, i32 %local.sum.extent.5657, i32 0
  %stack.offset.5659 = add i32 %stack.offset.5655, %local.sum.selected.5658
  %local.is.active.5660 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5661 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5662 = select i1 %local.is.active.5660, i32 %local.sum.extent.5661, i32 0
  %stack.offset.5663 = add i32 %stack.offset.5659, %local.sum.selected.5662
  %local.is.active.5664 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5665 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5666 = select i1 %local.is.active.5664, i32 %local.sum.extent.5665, i32 0
  %stack.offset.5667 = add i32 %stack.offset.5663, %local.sum.selected.5666
  %local.is.active.5668 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5669 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5670 = select i1 %local.is.active.5668, i32 %local.sum.extent.5669, i32 0
  %stack.offset.5671 = add i32 %stack.offset.5667, %local.sum.selected.5670
  %local.is.active.5672 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5673 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5674 = select i1 %local.is.active.5672, i32 %local.sum.extent.5673, i32 0
  %stack.offset.5675 = add i32 %stack.offset.5671, %local.sum.selected.5674
  %local.is.active.5676 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5677 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5678 = select i1 %local.is.active.5676, i32 %local.sum.extent.5677, i32 0
  %stack.offset.5679 = add i32 %stack.offset.5675, %local.sum.selected.5678
  %local.is.active.5680 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5681 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5682 = select i1 %local.is.active.5680, i32 %local.sum.extent.5681, i32 0
  %stack.offset.5683 = add i32 %stack.offset.5679, %local.sum.selected.5682
  %stack.offset.5684 = add i32 %stack.offset.5683, 0
  %stack.offset.5685 = add i32 %context.value.75, %stack.offset.5684
  %stack.offset.5686 = add i32 %context.value.5635, %stack.offset.5633
  %reserve.status.5687 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5686, i32 112)
  %reserve.ok.5688 = icmp eq i32 %reserve.status.5687, 0
  br i1 %reserve.ok.5688, label %reserve.continue.5689, label %frame.failure.0
reserve.continue.5689:
  %local.is.active.5690 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5691 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5692 = select i1 %local.is.active.5690, i32 %local.sum.extent.5691, i32 0
  %stack.offset.5693 = add i32 0, %local.sum.selected.5692
  %local.is.active.5694 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5695 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5696 = select i1 %local.is.active.5694, i32 %local.sum.extent.5695, i32 0
  %stack.offset.5697 = add i32 %stack.offset.5693, %local.sum.selected.5696
  %local.is.active.5698 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5699 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5700 = select i1 %local.is.active.5698, i32 %local.sum.extent.5699, i32 0
  %stack.offset.5701 = add i32 %stack.offset.5697, %local.sum.selected.5700
  %local.is.active.5702 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5703 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5704 = select i1 %local.is.active.5702, i32 %local.sum.extent.5703, i32 0
  %stack.offset.5705 = add i32 %stack.offset.5701, %local.sum.selected.5704
  %local.is.active.5706 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5707 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5708 = select i1 %local.is.active.5706, i32 %local.sum.extent.5707, i32 0
  %stack.offset.5709 = add i32 %stack.offset.5705, %local.sum.selected.5708
  %local.is.active.5710 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5711 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5712 = select i1 %local.is.active.5710, i32 %local.sum.extent.5711, i32 0
  %stack.offset.5713 = add i32 %stack.offset.5709, %local.sum.selected.5712
  %local.is.active.5714 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5715 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5716 = select i1 %local.is.active.5714, i32 %local.sum.extent.5715, i32 0
  %stack.offset.5717 = add i32 %stack.offset.5713, %local.sum.selected.5716
  %local.is.active.5718 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5719 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5720 = select i1 %local.is.active.5718, i32 %local.sum.extent.5719, i32 0
  %stack.offset.5721 = add i32 %stack.offset.5717, %local.sum.selected.5720
  %local.is.active.5722 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5723 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5724 = select i1 %local.is.active.5722, i32 %local.sum.extent.5723, i32 0
  %stack.offset.5725 = add i32 %stack.offset.5721, %local.sum.selected.5724
  %local.is.active.5726 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5727 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5728 = select i1 %local.is.active.5726, i32 %local.sum.extent.5727, i32 0
  %stack.offset.5729 = add i32 %stack.offset.5725, %local.sum.selected.5728
  %local.is.active.5730 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5731 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5732 = select i1 %local.is.active.5730, i32 %local.sum.extent.5731, i32 0
  %stack.offset.5733 = add i32 %stack.offset.5729, %local.sum.selected.5732
  %local.is.active.5734 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5735 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5736 = select i1 %local.is.active.5734, i32 %local.sum.extent.5735, i32 0
  %stack.offset.5737 = add i32 %stack.offset.5733, %local.sum.selected.5736
  %stack.offset.5738 = add i32 %stack.offset.5737, 0
  %stack.offset.5739 = add i32 %context.value.75, %stack.offset.5738
  %stack.offset.5740 = add i32 %context.value.5635, 0
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5740, i32 %stack.offset.5739, i32 %local.source.extent.5490, i32 %local.source.payload.5491, i32 9, i32 6)
  %context.field.5741 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5742 = load i32, ptr %context.field.5741, align 4
  %runtime.ok.5743 = icmp eq i32 %context.value.5742, 0
  br i1 %runtime.ok.5743, label %runtime.continue.5744, label %frame.failure.0
runtime.continue.5744:
  %stack.offset.5745 = add i32 0, %local.source.extent.5490
  %local.is.active.5746 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5747 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5748 = select i1 %local.is.active.5746, i32 %local.sum.extent.5747, i32 0
  %stack.offset.5749 = add i32 0, %local.sum.selected.5748
  %local.is.active.5750 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5751 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5752 = select i1 %local.is.active.5750, i32 %local.sum.extent.5751, i32 0
  %stack.offset.5753 = add i32 %stack.offset.5749, %local.sum.selected.5752
  %local.is.active.5754 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5755 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5756 = select i1 %local.is.active.5754, i32 %local.sum.extent.5755, i32 0
  %stack.offset.5757 = add i32 %stack.offset.5753, %local.sum.selected.5756
  %local.is.active.5758 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5759 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5760 = select i1 %local.is.active.5758, i32 %local.sum.extent.5759, i32 0
  %stack.offset.5761 = add i32 %stack.offset.5757, %local.sum.selected.5760
  %local.is.active.5762 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5763 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5764 = select i1 %local.is.active.5762, i32 %local.sum.extent.5763, i32 0
  %stack.offset.5765 = add i32 %stack.offset.5761, %local.sum.selected.5764
  %local.is.active.5766 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5767 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5768 = select i1 %local.is.active.5766, i32 %local.sum.extent.5767, i32 0
  %stack.offset.5769 = add i32 %stack.offset.5765, %local.sum.selected.5768
  %local.is.active.5770 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5771 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5772 = select i1 %local.is.active.5770, i32 %local.sum.extent.5771, i32 0
  %stack.offset.5773 = add i32 %stack.offset.5769, %local.sum.selected.5772
  %local.is.active.5774 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5775 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5776 = select i1 %local.is.active.5774, i32 %local.sum.extent.5775, i32 0
  %stack.offset.5777 = add i32 %stack.offset.5773, %local.sum.selected.5776
  %local.is.active.5778 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5779 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5780 = select i1 %local.is.active.5778, i32 %local.sum.extent.5779, i32 0
  %stack.offset.5781 = add i32 %stack.offset.5777, %local.sum.selected.5780
  %local.is.active.5782 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5783 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5784 = select i1 %local.is.active.5782, i32 %local.sum.extent.5783, i32 0
  %stack.offset.5785 = add i32 %stack.offset.5781, %local.sum.selected.5784
  %local.is.active.5786 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5787 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5788 = select i1 %local.is.active.5786, i32 %local.sum.extent.5787, i32 0
  %stack.offset.5789 = add i32 %stack.offset.5785, %local.sum.selected.5788
  %local.is.active.5790 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5791 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5792 = select i1 %local.is.active.5790, i32 %local.sum.extent.5791, i32 0
  %stack.offset.5793 = add i32 %stack.offset.5789, %local.sum.selected.5792
  %stack.offset.5794 = add i32 0, %local.source.extent.5490
  %stack.offset.5795 = add i32 %stack.offset.5793, %stack.offset.5794
  %stack.offset.5796 = add i32 %context.value.75, %stack.offset.5795
  %stack.offset.5797 = add i32 %context.value.5635, %stack.offset.5745
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5797, i32 %stack.offset.5796, i32 %local.source.extent.5560, i32 %local.source.payload.5561, i32 1, i32 6)
  %context.field.5798 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5799 = load i32, ptr %context.field.5798, align 4
  %runtime.ok.5800 = icmp eq i32 %context.value.5799, 0
  br i1 %runtime.ok.5800, label %runtime.continue.5801, label %frame.failure.0
runtime.continue.5801:
  %stack.offset.5802 = add i32 %stack.offset.5745, %local.source.extent.5560
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.5685, i32 %context.value.5635, i32 %stack.offset.5633, i32 %stack.offset.5631, i32 8, i32 6)
  %context.field.5803 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5804 = load i32, ptr %context.field.5803, align 4
  %runtime.ok.5805 = icmp eq i32 %context.value.5804, 0
  br i1 %runtime.ok.5805, label %runtime.continue.5806, label %frame.failure.0
runtime.continue.5806:
  %stack.offset.5807 = add i32 %stack.offset.5685, %stack.offset.5633
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.5807, i32 0, i32 0, i32 0)
  %context.field.5808 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5809 = load i32, ptr %context.field.5808, align 4
  %runtime.ok.5810 = icmp eq i32 %context.value.5809, 0
  br i1 %runtime.ok.5810, label %runtime.continue.5811, label %frame.failure.0
runtime.continue.5811:
  %stack.offset.5812 = add i32 0, %local.source.payload.5491
  %stack.offset.5813 = add i32 %stack.offset.5812, %local.source.payload.5561
  %stack.sub.5814 = sub i32 %stack.offset.5631, %stack.offset.5813
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5814, i32 0)
  %context.field.5815 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5816 = load i32, ptr %context.field.5815, align 4
  %runtime.ok.5817 = icmp eq i32 %context.value.5816, 0
  br i1 %runtime.ok.5817, label %runtime.continue.5818, label %frame.failure.0
runtime.continue.5818:
  %local.is.active.5819 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5820 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5821 = select i1 %local.is.active.5819, i32 %local.sum.extent.5820, i32 0
  %stack.offset.5822 = add i32 0, %local.sum.selected.5821
  %local.is.active.5823 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5824 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5825 = select i1 %local.is.active.5823, i32 %local.sum.extent.5824, i32 0
  %stack.offset.5826 = add i32 %stack.offset.5822, %local.sum.selected.5825
  %local.is.active.5827 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5828 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5829 = select i1 %local.is.active.5827, i32 %local.sum.extent.5828, i32 0
  %stack.offset.5830 = add i32 %stack.offset.5826, %local.sum.selected.5829
  %local.is.active.5831 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5832 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5833 = select i1 %local.is.active.5831, i32 %local.sum.extent.5832, i32 0
  %stack.offset.5834 = add i32 %stack.offset.5830, %local.sum.selected.5833
  %local.is.active.5835 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5836 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5837 = select i1 %local.is.active.5835, i32 %local.sum.extent.5836, i32 0
  %stack.offset.5838 = add i32 %stack.offset.5834, %local.sum.selected.5837
  %local.is.active.5839 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5840 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5841 = select i1 %local.is.active.5839, i32 %local.sum.extent.5840, i32 0
  %stack.offset.5842 = add i32 %stack.offset.5838, %local.sum.selected.5841
  %local.is.active.5843 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5844 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5845 = select i1 %local.is.active.5843, i32 %local.sum.extent.5844, i32 0
  %stack.offset.5846 = add i32 %stack.offset.5842, %local.sum.selected.5845
  %local.is.active.5847 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5848 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5849 = select i1 %local.is.active.5847, i32 %local.sum.extent.5848, i32 0
  %stack.offset.5850 = add i32 %stack.offset.5846, %local.sum.selected.5849
  %local.is.active.5851 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5852 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5853 = select i1 %local.is.active.5851, i32 %local.sum.extent.5852, i32 0
  %stack.offset.5854 = add i32 %stack.offset.5850, %local.sum.selected.5853
  %local.is.active.5855 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5856 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5857 = select i1 %local.is.active.5855, i32 %local.sum.extent.5856, i32 0
  %stack.offset.5858 = add i32 %stack.offset.5854, %local.sum.selected.5857
  %local.is.active.5859 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5860 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5861 = select i1 %local.is.active.5859, i32 %local.sum.extent.5860, i32 0
  %stack.offset.5862 = add i32 %stack.offset.5858, %local.sum.selected.5861
  %local.is.active.5863 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5864 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5865 = select i1 %local.is.active.5863, i32 %local.sum.extent.5864, i32 0
  %stack.offset.5866 = add i32 %stack.offset.5862, %local.sum.selected.5865
  %stack.offset.5867 = add i32 0, %stack.offset.5633
  %stack.offset.5868 = add i32 %stack.offset.5866, %stack.offset.5867
  %stack.offset.5869 = add i32 %context.value.75, %stack.offset.5868
  %cursor.status.5870 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.5869)
  %cursor.ok.5871 = icmp eq i32 %cursor.status.5870, 0
  br i1 %cursor.ok.5871, label %cursor.continue.5872, label %frame.failure.0
cursor.continue.5872:
  %local.is.active.5873 = load i1, ptr %local.active.58, align 1
  br i1 %local.is.active.5873, label %local.remove.5874, label %local.keep.5875
local.keep.5875:
  br label %local.removed.5876
local.remove.5874:
  %local.remove.offset.5877 = load i32, ptr %local.offset.59, align 4
  %local.remove.extent.5878 = load i32, ptr %local.extent.60, align 4
  %local.remove.payload.5879 = load i32, ptr %local.payload.61, align 4
  %local.remove.type.5880 = load i32, ptr %local.type.62, align 4
  %stack.offset.5881 = add i32 %local.remove.offset.5877, %local.remove.extent.5878
  %context.field.5882 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5883 = load i32, ptr %context.field.5882, align 4
  %stack.sub.5884 = sub i32 %context.value.5883, %stack.offset.5881
  %stack.offset.5885 = add i32 0, %stack.offset.5631
  %stack.offset.5886 = add i32 0, %stack.offset.5885
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.5877, i32 %stack.offset.5881, i32 %stack.sub.5884, i32 %stack.offset.5886, i32 0, i32 14)
  %context.field.5887 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5888 = load i32, ptr %context.field.5887, align 4
  %runtime.ok.5889 = icmp eq i32 %context.value.5888, 0
  br i1 %runtime.ok.5889, label %runtime.continue.5890, label %frame.failure.0
runtime.continue.5890:
  %stack.sub.5891 = sub i32 %context.value.5883, %local.remove.extent.5878
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.5891, i32 0, i32 0, i32 0)
  %context.field.5892 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5893 = load i32, ptr %context.field.5892, align 4
  %runtime.ok.5894 = icmp eq i32 %context.value.5893, 0
  br i1 %runtime.ok.5894, label %runtime.continue.5895, label %frame.failure.0
runtime.continue.5895:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.5880, i32 %local.remove.offset.5877, i32 %local.remove.extent.5878, i32 %local.remove.payload.5879, i32 0, i32 0)
  %context.field.5896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5897 = load i32, ptr %context.field.5896, align 4
  %runtime.ok.5898 = icmp eq i32 %context.value.5897, 0
  br i1 %runtime.ok.5898, label %runtime.continue.5899, label %frame.failure.0
runtime.continue.5899:
  %stack.sub.5900 = sub i32 0, %local.remove.payload.5879
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5900, i32 %stack.sub.5900)
  %context.field.5901 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5902 = load i32, ptr %context.field.5901, align 4
  %runtime.ok.5903 = icmp eq i32 %context.value.5902, 0
  br i1 %runtime.ok.5903, label %runtime.continue.5904, label %frame.failure.0
runtime.continue.5904:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.5878)
  %context.field.5905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5906 = load i32, ptr %context.field.5905, align 4
  %runtime.ok.5907 = icmp eq i32 %context.value.5906, 0
  br i1 %runtime.ok.5907, label %runtime.continue.5908, label %frame.failure.0
runtime.continue.5908:
  store i1 false, ptr %local.active.58, align 1
  store i32 0, ptr %local.offset.59, align 4
  store i32 0, ptr %local.extent.60, align 4
  store i32 0, ptr %local.payload.61, align 4
  store i32 0, ptr %local.type.62, align 4
  br label %local.removed.5876
local.removed.5876:
  %local.is.active.5909 = load i1, ptr %local.active.53, align 1
  br i1 %local.is.active.5909, label %local.remove.5910, label %local.keep.5911
local.keep.5911:
  br label %local.removed.5912
local.remove.5910:
  %local.remove.offset.5913 = load i32, ptr %local.offset.54, align 4
  %local.remove.extent.5914 = load i32, ptr %local.extent.55, align 4
  %local.remove.payload.5915 = load i32, ptr %local.payload.56, align 4
  %local.remove.type.5916 = load i32, ptr %local.type.57, align 4
  %stack.offset.5917 = add i32 %local.remove.offset.5913, %local.remove.extent.5914
  %context.field.5918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5919 = load i32, ptr %context.field.5918, align 4
  %stack.sub.5920 = sub i32 %context.value.5919, %stack.offset.5917
  %local.is.active.5921 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.5922 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.5923 = select i1 %local.is.active.5921, i32 %local.suffix.payload.5922, i32 0
  %stack.offset.5924 = add i32 0, %local.suffix.selected.5923
  %stack.offset.5925 = add i32 0, %stack.offset.5631
  %stack.offset.5926 = add i32 %stack.offset.5924, %stack.offset.5925
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.5913, i32 %stack.offset.5917, i32 %stack.sub.5920, i32 %stack.offset.5926, i32 0, i32 14)
  %context.field.5927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5928 = load i32, ptr %context.field.5927, align 4
  %runtime.ok.5929 = icmp eq i32 %context.value.5928, 0
  br i1 %runtime.ok.5929, label %runtime.continue.5930, label %frame.failure.0
runtime.continue.5930:
  %stack.sub.5931 = sub i32 %context.value.5919, %local.remove.extent.5914
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.5931, i32 0, i32 0, i32 0)
  %context.field.5932 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5933 = load i32, ptr %context.field.5932, align 4
  %runtime.ok.5934 = icmp eq i32 %context.value.5933, 0
  br i1 %runtime.ok.5934, label %runtime.continue.5935, label %frame.failure.0
runtime.continue.5935:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.5916, i32 %local.remove.offset.5913, i32 %local.remove.extent.5914, i32 %local.remove.payload.5915, i32 0, i32 0)
  %context.field.5936 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5937 = load i32, ptr %context.field.5936, align 4
  %runtime.ok.5938 = icmp eq i32 %context.value.5937, 0
  br i1 %runtime.ok.5938, label %runtime.continue.5939, label %frame.failure.0
runtime.continue.5939:
  %stack.sub.5940 = sub i32 0, %local.remove.payload.5915
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5940, i32 %stack.sub.5940)
  %context.field.5941 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5942 = load i32, ptr %context.field.5941, align 4
  %runtime.ok.5943 = icmp eq i32 %context.value.5942, 0
  br i1 %runtime.ok.5943, label %runtime.continue.5944, label %frame.failure.0
runtime.continue.5944:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.5914)
  %context.field.5945 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5946 = load i32, ptr %context.field.5945, align 4
  %runtime.ok.5947 = icmp eq i32 %context.value.5946, 0
  br i1 %runtime.ok.5947, label %runtime.continue.5948, label %frame.failure.0
runtime.continue.5948:
  %local.is.active.5949 = load i1, ptr %local.active.58, align 1
  %local.later.offset.5950 = load i32, ptr %local.offset.59, align 4
  %stack.sub.5951 = sub i32 %local.later.offset.5950, %local.remove.extent.5914
  %local.later.offset.selected.5952 = select i1 %local.is.active.5949, i32 %stack.sub.5951, i32 %local.later.offset.5950
  store i32 %local.later.offset.selected.5952, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.53, align 1
  store i32 0, ptr %local.offset.54, align 4
  store i32 0, ptr %local.extent.55, align 4
  store i32 0, ptr %local.payload.56, align 4
  store i32 0, ptr %local.type.57, align 4
  br label %local.removed.5912
local.removed.5912:
  %local.is.active.5953 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.5954 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.5955 = select i1 %local.is.active.5953, i32 %local.sum.extent.5954, i32 0
  %stack.offset.5956 = add i32 0, %local.sum.selected.5955
  %local.is.active.5957 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.5958 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.5959 = select i1 %local.is.active.5957, i32 %local.sum.extent.5958, i32 0
  %stack.offset.5960 = add i32 %stack.offset.5956, %local.sum.selected.5959
  %local.is.active.5961 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.5962 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.5963 = select i1 %local.is.active.5961, i32 %local.sum.extent.5962, i32 0
  %stack.offset.5964 = add i32 %stack.offset.5960, %local.sum.selected.5963
  %local.is.active.5965 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.5966 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.5967 = select i1 %local.is.active.5965, i32 %local.sum.extent.5966, i32 0
  %stack.offset.5968 = add i32 %stack.offset.5964, %local.sum.selected.5967
  %local.is.active.5969 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.5970 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.5971 = select i1 %local.is.active.5969, i32 %local.sum.extent.5970, i32 0
  %stack.offset.5972 = add i32 %stack.offset.5968, %local.sum.selected.5971
  %local.is.active.5973 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.5974 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.5975 = select i1 %local.is.active.5973, i32 %local.sum.extent.5974, i32 0
  %stack.offset.5976 = add i32 %stack.offset.5972, %local.sum.selected.5975
  %local.is.active.5977 = load i1, ptr %local.active.33, align 1
  %local.sum.extent.5978 = load i32, ptr %local.extent.35, align 4
  %local.sum.selected.5979 = select i1 %local.is.active.5977, i32 %local.sum.extent.5978, i32 0
  %stack.offset.5980 = add i32 %stack.offset.5976, %local.sum.selected.5979
  %local.is.active.5981 = load i1, ptr %local.active.38, align 1
  %local.sum.extent.5982 = load i32, ptr %local.extent.40, align 4
  %local.sum.selected.5983 = select i1 %local.is.active.5981, i32 %local.sum.extent.5982, i32 0
  %stack.offset.5984 = add i32 %stack.offset.5980, %local.sum.selected.5983
  %local.is.active.5985 = load i1, ptr %local.active.43, align 1
  %local.sum.extent.5986 = load i32, ptr %local.extent.45, align 4
  %local.sum.selected.5987 = select i1 %local.is.active.5985, i32 %local.sum.extent.5986, i32 0
  %stack.offset.5988 = add i32 %stack.offset.5984, %local.sum.selected.5987
  %local.is.active.5989 = load i1, ptr %local.active.48, align 1
  %local.sum.extent.5990 = load i32, ptr %local.extent.50, align 4
  %local.sum.selected.5991 = select i1 %local.is.active.5989, i32 %local.sum.extent.5990, i32 0
  %stack.offset.5992 = add i32 %stack.offset.5988, %local.sum.selected.5991
  %local.is.active.5993 = load i1, ptr %local.active.53, align 1
  %local.sum.extent.5994 = load i32, ptr %local.extent.55, align 4
  %local.sum.selected.5995 = select i1 %local.is.active.5993, i32 %local.sum.extent.5994, i32 0
  %stack.offset.5996 = add i32 %stack.offset.5992, %local.sum.selected.5995
  %local.is.active.5997 = load i1, ptr %local.active.58, align 1
  %local.sum.extent.5998 = load i32, ptr %local.extent.60, align 4
  %local.sum.selected.5999 = select i1 %local.is.active.5997, i32 %local.sum.extent.5998, i32 0
  %stack.offset.6000 = add i32 %stack.offset.5996, %local.sum.selected.5999
  %stack.offset.6001 = add i32 0, %stack.offset.5633
  %stack.offset.6002 = add i32 %stack.offset.6000, %stack.offset.6001
  %stack.offset.6003 = add i32 %context.value.75, %stack.offset.6002
  %cursor.status.6004 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.6003)
  %cursor.ok.6005 = icmp eq i32 %cursor.status.6004, 0
  br i1 %cursor.ok.6005, label %cursor.continue.6006, label %frame.failure.0
cursor.continue.6006:
  %local.is.active.6007 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.6007, label %local.remove.6008, label %local.keep.6009
local.keep.6009:
  br label %local.removed.6010
local.remove.6008:
  %local.remove.offset.6011 = load i32, ptr %local.offset.39, align 4
  %local.remove.extent.6012 = load i32, ptr %local.extent.40, align 4
  %local.remove.payload.6013 = load i32, ptr %local.payload.41, align 4
  %local.remove.type.6014 = load i32, ptr %local.type.42, align 4
  %stack.offset.6015 = add i32 %local.remove.offset.6011, %local.remove.extent.6012
  %context.field.6016 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6017 = load i32, ptr %context.field.6016, align 4
  %stack.sub.6018 = sub i32 %context.value.6017, %stack.offset.6015
  %local.is.active.6019 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6020 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6021 = select i1 %local.is.active.6019, i32 %local.suffix.payload.6020, i32 0
  %stack.offset.6022 = add i32 0, %local.suffix.selected.6021
  %local.is.active.6023 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6024 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6025 = select i1 %local.is.active.6023, i32 %local.suffix.payload.6024, i32 0
  %stack.offset.6026 = add i32 %stack.offset.6022, %local.suffix.selected.6025
  %local.is.active.6027 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6028 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6029 = select i1 %local.is.active.6027, i32 %local.suffix.payload.6028, i32 0
  %stack.offset.6030 = add i32 %stack.offset.6026, %local.suffix.selected.6029
  %local.is.active.6031 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6032 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6033 = select i1 %local.is.active.6031, i32 %local.suffix.payload.6032, i32 0
  %stack.offset.6034 = add i32 %stack.offset.6030, %local.suffix.selected.6033
  %stack.offset.6035 = add i32 0, %stack.offset.5631
  %stack.offset.6036 = add i32 %stack.offset.6034, %stack.offset.6035
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6011, i32 %stack.offset.6015, i32 %stack.sub.6018, i32 %stack.offset.6036, i32 0, i32 14)
  %context.field.6037 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6038 = load i32, ptr %context.field.6037, align 4
  %runtime.ok.6039 = icmp eq i32 %context.value.6038, 0
  br i1 %runtime.ok.6039, label %runtime.continue.6040, label %frame.failure.0
runtime.continue.6040:
  %stack.sub.6041 = sub i32 %context.value.6017, %local.remove.extent.6012
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6041, i32 0, i32 0, i32 0)
  %context.field.6042 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6043 = load i32, ptr %context.field.6042, align 4
  %runtime.ok.6044 = icmp eq i32 %context.value.6043, 0
  br i1 %runtime.ok.6044, label %runtime.continue.6045, label %frame.failure.0
runtime.continue.6045:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6014, i32 %local.remove.offset.6011, i32 %local.remove.extent.6012, i32 %local.remove.payload.6013, i32 0, i32 0)
  %context.field.6046 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6047 = load i32, ptr %context.field.6046, align 4
  %runtime.ok.6048 = icmp eq i32 %context.value.6047, 0
  br i1 %runtime.ok.6048, label %runtime.continue.6049, label %frame.failure.0
runtime.continue.6049:
  %stack.sub.6050 = sub i32 0, %local.remove.payload.6013
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6050, i32 %stack.sub.6050)
  %context.field.6051 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6052 = load i32, ptr %context.field.6051, align 4
  %runtime.ok.6053 = icmp eq i32 %context.value.6052, 0
  br i1 %runtime.ok.6053, label %runtime.continue.6054, label %frame.failure.0
runtime.continue.6054:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6012)
  %context.field.6055 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6056 = load i32, ptr %context.field.6055, align 4
  %runtime.ok.6057 = icmp eq i32 %context.value.6056, 0
  br i1 %runtime.ok.6057, label %runtime.continue.6058, label %frame.failure.0
runtime.continue.6058:
  %local.is.active.6059 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6060 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6061 = sub i32 %local.later.offset.6060, %local.remove.extent.6012
  %local.later.offset.selected.6062 = select i1 %local.is.active.6059, i32 %stack.sub.6061, i32 %local.later.offset.6060
  store i32 %local.later.offset.selected.6062, ptr %local.offset.44, align 4
  %local.is.active.6063 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6064 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6065 = sub i32 %local.later.offset.6064, %local.remove.extent.6012
  %local.later.offset.selected.6066 = select i1 %local.is.active.6063, i32 %stack.sub.6065, i32 %local.later.offset.6064
  store i32 %local.later.offset.selected.6066, ptr %local.offset.49, align 4
  %local.is.active.6067 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6068 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6069 = sub i32 %local.later.offset.6068, %local.remove.extent.6012
  %local.later.offset.selected.6070 = select i1 %local.is.active.6067, i32 %stack.sub.6069, i32 %local.later.offset.6068
  store i32 %local.later.offset.selected.6070, ptr %local.offset.54, align 4
  %local.is.active.6071 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6072 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6073 = sub i32 %local.later.offset.6072, %local.remove.extent.6012
  %local.later.offset.selected.6074 = select i1 %local.is.active.6071, i32 %stack.sub.6073, i32 %local.later.offset.6072
  store i32 %local.later.offset.selected.6074, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.type.42, align 4
  br label %local.removed.6010
local.removed.6010:
  %local.is.active.6075 = load i1, ptr %local.active.33, align 1
  br i1 %local.is.active.6075, label %local.remove.6076, label %local.keep.6077
local.keep.6077:
  br label %local.removed.6078
local.remove.6076:
  %local.remove.offset.6079 = load i32, ptr %local.offset.34, align 4
  %local.remove.extent.6080 = load i32, ptr %local.extent.35, align 4
  %local.remove.payload.6081 = load i32, ptr %local.payload.36, align 4
  %local.remove.type.6082 = load i32, ptr %local.type.37, align 4
  %stack.offset.6083 = add i32 %local.remove.offset.6079, %local.remove.extent.6080
  %context.field.6084 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6085 = load i32, ptr %context.field.6084, align 4
  %stack.sub.6086 = sub i32 %context.value.6085, %stack.offset.6083
  %local.is.active.6087 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6088 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6089 = select i1 %local.is.active.6087, i32 %local.suffix.payload.6088, i32 0
  %stack.offset.6090 = add i32 0, %local.suffix.selected.6089
  %local.is.active.6091 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6092 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6093 = select i1 %local.is.active.6091, i32 %local.suffix.payload.6092, i32 0
  %stack.offset.6094 = add i32 %stack.offset.6090, %local.suffix.selected.6093
  %local.is.active.6095 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6096 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6097 = select i1 %local.is.active.6095, i32 %local.suffix.payload.6096, i32 0
  %stack.offset.6098 = add i32 %stack.offset.6094, %local.suffix.selected.6097
  %local.is.active.6099 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6100 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6101 = select i1 %local.is.active.6099, i32 %local.suffix.payload.6100, i32 0
  %stack.offset.6102 = add i32 %stack.offset.6098, %local.suffix.selected.6101
  %local.is.active.6103 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6104 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6105 = select i1 %local.is.active.6103, i32 %local.suffix.payload.6104, i32 0
  %stack.offset.6106 = add i32 %stack.offset.6102, %local.suffix.selected.6105
  %stack.offset.6107 = add i32 0, %stack.offset.5631
  %stack.offset.6108 = add i32 %stack.offset.6106, %stack.offset.6107
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6079, i32 %stack.offset.6083, i32 %stack.sub.6086, i32 %stack.offset.6108, i32 0, i32 14)
  %context.field.6109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6110 = load i32, ptr %context.field.6109, align 4
  %runtime.ok.6111 = icmp eq i32 %context.value.6110, 0
  br i1 %runtime.ok.6111, label %runtime.continue.6112, label %frame.failure.0
runtime.continue.6112:
  %stack.sub.6113 = sub i32 %context.value.6085, %local.remove.extent.6080
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6113, i32 0, i32 0, i32 0)
  %context.field.6114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6115 = load i32, ptr %context.field.6114, align 4
  %runtime.ok.6116 = icmp eq i32 %context.value.6115, 0
  br i1 %runtime.ok.6116, label %runtime.continue.6117, label %frame.failure.0
runtime.continue.6117:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6082, i32 %local.remove.offset.6079, i32 %local.remove.extent.6080, i32 %local.remove.payload.6081, i32 0, i32 0)
  %context.field.6118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6119 = load i32, ptr %context.field.6118, align 4
  %runtime.ok.6120 = icmp eq i32 %context.value.6119, 0
  br i1 %runtime.ok.6120, label %runtime.continue.6121, label %frame.failure.0
runtime.continue.6121:
  %stack.sub.6122 = sub i32 0, %local.remove.payload.6081
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6122, i32 %stack.sub.6122)
  %context.field.6123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6124 = load i32, ptr %context.field.6123, align 4
  %runtime.ok.6125 = icmp eq i32 %context.value.6124, 0
  br i1 %runtime.ok.6125, label %runtime.continue.6126, label %frame.failure.0
runtime.continue.6126:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6080)
  %context.field.6127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6128 = load i32, ptr %context.field.6127, align 4
  %runtime.ok.6129 = icmp eq i32 %context.value.6128, 0
  br i1 %runtime.ok.6129, label %runtime.continue.6130, label %frame.failure.0
runtime.continue.6130:
  %local.is.active.6131 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6132 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6133 = sub i32 %local.later.offset.6132, %local.remove.extent.6080
  %local.later.offset.selected.6134 = select i1 %local.is.active.6131, i32 %stack.sub.6133, i32 %local.later.offset.6132
  store i32 %local.later.offset.selected.6134, ptr %local.offset.39, align 4
  %local.is.active.6135 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6136 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6137 = sub i32 %local.later.offset.6136, %local.remove.extent.6080
  %local.later.offset.selected.6138 = select i1 %local.is.active.6135, i32 %stack.sub.6137, i32 %local.later.offset.6136
  store i32 %local.later.offset.selected.6138, ptr %local.offset.44, align 4
  %local.is.active.6139 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6140 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6141 = sub i32 %local.later.offset.6140, %local.remove.extent.6080
  %local.later.offset.selected.6142 = select i1 %local.is.active.6139, i32 %stack.sub.6141, i32 %local.later.offset.6140
  store i32 %local.later.offset.selected.6142, ptr %local.offset.49, align 4
  %local.is.active.6143 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6144 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6145 = sub i32 %local.later.offset.6144, %local.remove.extent.6080
  %local.later.offset.selected.6146 = select i1 %local.is.active.6143, i32 %stack.sub.6145, i32 %local.later.offset.6144
  store i32 %local.later.offset.selected.6146, ptr %local.offset.54, align 4
  %local.is.active.6147 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6148 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6149 = sub i32 %local.later.offset.6148, %local.remove.extent.6080
  %local.later.offset.selected.6150 = select i1 %local.is.active.6147, i32 %stack.sub.6149, i32 %local.later.offset.6148
  store i32 %local.later.offset.selected.6150, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.33, align 1
  store i32 0, ptr %local.offset.34, align 4
  store i32 0, ptr %local.extent.35, align 4
  store i32 0, ptr %local.payload.36, align 4
  store i32 0, ptr %local.type.37, align 4
  br label %local.removed.6078
local.removed.6078:
  %local.is.active.6151 = load i1, ptr %local.active.28, align 1
  br i1 %local.is.active.6151, label %local.remove.6152, label %local.keep.6153
local.keep.6153:
  br label %local.removed.6154
local.remove.6152:
  %local.remove.offset.6155 = load i32, ptr %local.offset.29, align 4
  %local.remove.extent.6156 = load i32, ptr %local.extent.30, align 4
  %local.remove.payload.6157 = load i32, ptr %local.payload.31, align 4
  %local.remove.type.6158 = load i32, ptr %local.type.32, align 4
  %stack.offset.6159 = add i32 %local.remove.offset.6155, %local.remove.extent.6156
  %context.field.6160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6161 = load i32, ptr %context.field.6160, align 4
  %stack.sub.6162 = sub i32 %context.value.6161, %stack.offset.6159
  %local.is.active.6163 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6164 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6165 = select i1 %local.is.active.6163, i32 %local.suffix.payload.6164, i32 0
  %stack.offset.6166 = add i32 0, %local.suffix.selected.6165
  %local.is.active.6167 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6168 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6169 = select i1 %local.is.active.6167, i32 %local.suffix.payload.6168, i32 0
  %stack.offset.6170 = add i32 %stack.offset.6166, %local.suffix.selected.6169
  %local.is.active.6171 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6172 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6173 = select i1 %local.is.active.6171, i32 %local.suffix.payload.6172, i32 0
  %stack.offset.6174 = add i32 %stack.offset.6170, %local.suffix.selected.6173
  %local.is.active.6175 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6176 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6177 = select i1 %local.is.active.6175, i32 %local.suffix.payload.6176, i32 0
  %stack.offset.6178 = add i32 %stack.offset.6174, %local.suffix.selected.6177
  %local.is.active.6179 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6180 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6181 = select i1 %local.is.active.6179, i32 %local.suffix.payload.6180, i32 0
  %stack.offset.6182 = add i32 %stack.offset.6178, %local.suffix.selected.6181
  %local.is.active.6183 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6184 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6185 = select i1 %local.is.active.6183, i32 %local.suffix.payload.6184, i32 0
  %stack.offset.6186 = add i32 %stack.offset.6182, %local.suffix.selected.6185
  %stack.offset.6187 = add i32 0, %stack.offset.5631
  %stack.offset.6188 = add i32 %stack.offset.6186, %stack.offset.6187
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6155, i32 %stack.offset.6159, i32 %stack.sub.6162, i32 %stack.offset.6188, i32 0, i32 14)
  %context.field.6189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6190 = load i32, ptr %context.field.6189, align 4
  %runtime.ok.6191 = icmp eq i32 %context.value.6190, 0
  br i1 %runtime.ok.6191, label %runtime.continue.6192, label %frame.failure.0
runtime.continue.6192:
  %stack.sub.6193 = sub i32 %context.value.6161, %local.remove.extent.6156
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6193, i32 0, i32 0, i32 0)
  %context.field.6194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6195 = load i32, ptr %context.field.6194, align 4
  %runtime.ok.6196 = icmp eq i32 %context.value.6195, 0
  br i1 %runtime.ok.6196, label %runtime.continue.6197, label %frame.failure.0
runtime.continue.6197:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6158, i32 %local.remove.offset.6155, i32 %local.remove.extent.6156, i32 %local.remove.payload.6157, i32 0, i32 0)
  %context.field.6198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6199 = load i32, ptr %context.field.6198, align 4
  %runtime.ok.6200 = icmp eq i32 %context.value.6199, 0
  br i1 %runtime.ok.6200, label %runtime.continue.6201, label %frame.failure.0
runtime.continue.6201:
  %stack.sub.6202 = sub i32 0, %local.remove.payload.6157
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6202, i32 %stack.sub.6202)
  %context.field.6203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6204 = load i32, ptr %context.field.6203, align 4
  %runtime.ok.6205 = icmp eq i32 %context.value.6204, 0
  br i1 %runtime.ok.6205, label %runtime.continue.6206, label %frame.failure.0
runtime.continue.6206:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6156)
  %context.field.6207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6208 = load i32, ptr %context.field.6207, align 4
  %runtime.ok.6209 = icmp eq i32 %context.value.6208, 0
  br i1 %runtime.ok.6209, label %runtime.continue.6210, label %frame.failure.0
runtime.continue.6210:
  %local.is.active.6211 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6212 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6213 = sub i32 %local.later.offset.6212, %local.remove.extent.6156
  %local.later.offset.selected.6214 = select i1 %local.is.active.6211, i32 %stack.sub.6213, i32 %local.later.offset.6212
  store i32 %local.later.offset.selected.6214, ptr %local.offset.34, align 4
  %local.is.active.6215 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6216 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6217 = sub i32 %local.later.offset.6216, %local.remove.extent.6156
  %local.later.offset.selected.6218 = select i1 %local.is.active.6215, i32 %stack.sub.6217, i32 %local.later.offset.6216
  store i32 %local.later.offset.selected.6218, ptr %local.offset.39, align 4
  %local.is.active.6219 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6220 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6221 = sub i32 %local.later.offset.6220, %local.remove.extent.6156
  %local.later.offset.selected.6222 = select i1 %local.is.active.6219, i32 %stack.sub.6221, i32 %local.later.offset.6220
  store i32 %local.later.offset.selected.6222, ptr %local.offset.44, align 4
  %local.is.active.6223 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6224 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6225 = sub i32 %local.later.offset.6224, %local.remove.extent.6156
  %local.later.offset.selected.6226 = select i1 %local.is.active.6223, i32 %stack.sub.6225, i32 %local.later.offset.6224
  store i32 %local.later.offset.selected.6226, ptr %local.offset.49, align 4
  %local.is.active.6227 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6228 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6229 = sub i32 %local.later.offset.6228, %local.remove.extent.6156
  %local.later.offset.selected.6230 = select i1 %local.is.active.6227, i32 %stack.sub.6229, i32 %local.later.offset.6228
  store i32 %local.later.offset.selected.6230, ptr %local.offset.54, align 4
  %local.is.active.6231 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6232 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6233 = sub i32 %local.later.offset.6232, %local.remove.extent.6156
  %local.later.offset.selected.6234 = select i1 %local.is.active.6231, i32 %stack.sub.6233, i32 %local.later.offset.6232
  store i32 %local.later.offset.selected.6234, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  br label %local.removed.6154
local.removed.6154:
  %local.is.active.6235 = load i1, ptr %local.active.23, align 1
  br i1 %local.is.active.6235, label %local.remove.6236, label %local.keep.6237
local.keep.6237:
  br label %local.removed.6238
local.remove.6236:
  %local.remove.offset.6239 = load i32, ptr %local.offset.24, align 4
  %local.remove.extent.6240 = load i32, ptr %local.extent.25, align 4
  %local.remove.payload.6241 = load i32, ptr %local.payload.26, align 4
  %local.remove.type.6242 = load i32, ptr %local.type.27, align 4
  %stack.offset.6243 = add i32 %local.remove.offset.6239, %local.remove.extent.6240
  %context.field.6244 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6245 = load i32, ptr %context.field.6244, align 4
  %stack.sub.6246 = sub i32 %context.value.6245, %stack.offset.6243
  %local.is.active.6247 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.6248 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.6249 = select i1 %local.is.active.6247, i32 %local.suffix.payload.6248, i32 0
  %stack.offset.6250 = add i32 0, %local.suffix.selected.6249
  %local.is.active.6251 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6252 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6253 = select i1 %local.is.active.6251, i32 %local.suffix.payload.6252, i32 0
  %stack.offset.6254 = add i32 %stack.offset.6250, %local.suffix.selected.6253
  %local.is.active.6255 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6256 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6257 = select i1 %local.is.active.6255, i32 %local.suffix.payload.6256, i32 0
  %stack.offset.6258 = add i32 %stack.offset.6254, %local.suffix.selected.6257
  %local.is.active.6259 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6260 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6261 = select i1 %local.is.active.6259, i32 %local.suffix.payload.6260, i32 0
  %stack.offset.6262 = add i32 %stack.offset.6258, %local.suffix.selected.6261
  %local.is.active.6263 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6264 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6265 = select i1 %local.is.active.6263, i32 %local.suffix.payload.6264, i32 0
  %stack.offset.6266 = add i32 %stack.offset.6262, %local.suffix.selected.6265
  %local.is.active.6267 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6268 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6269 = select i1 %local.is.active.6267, i32 %local.suffix.payload.6268, i32 0
  %stack.offset.6270 = add i32 %stack.offset.6266, %local.suffix.selected.6269
  %local.is.active.6271 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6272 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6273 = select i1 %local.is.active.6271, i32 %local.suffix.payload.6272, i32 0
  %stack.offset.6274 = add i32 %stack.offset.6270, %local.suffix.selected.6273
  %stack.offset.6275 = add i32 0, %stack.offset.5631
  %stack.offset.6276 = add i32 %stack.offset.6274, %stack.offset.6275
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6239, i32 %stack.offset.6243, i32 %stack.sub.6246, i32 %stack.offset.6276, i32 0, i32 14)
  %context.field.6277 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6278 = load i32, ptr %context.field.6277, align 4
  %runtime.ok.6279 = icmp eq i32 %context.value.6278, 0
  br i1 %runtime.ok.6279, label %runtime.continue.6280, label %frame.failure.0
runtime.continue.6280:
  %stack.sub.6281 = sub i32 %context.value.6245, %local.remove.extent.6240
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6281, i32 0, i32 0, i32 0)
  %context.field.6282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6283 = load i32, ptr %context.field.6282, align 4
  %runtime.ok.6284 = icmp eq i32 %context.value.6283, 0
  br i1 %runtime.ok.6284, label %runtime.continue.6285, label %frame.failure.0
runtime.continue.6285:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6242, i32 %local.remove.offset.6239, i32 %local.remove.extent.6240, i32 %local.remove.payload.6241, i32 0, i32 0)
  %context.field.6286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6287 = load i32, ptr %context.field.6286, align 4
  %runtime.ok.6288 = icmp eq i32 %context.value.6287, 0
  br i1 %runtime.ok.6288, label %runtime.continue.6289, label %frame.failure.0
runtime.continue.6289:
  %stack.sub.6290 = sub i32 0, %local.remove.payload.6241
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6290, i32 %stack.sub.6290)
  %context.field.6291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6292 = load i32, ptr %context.field.6291, align 4
  %runtime.ok.6293 = icmp eq i32 %context.value.6292, 0
  br i1 %runtime.ok.6293, label %runtime.continue.6294, label %frame.failure.0
runtime.continue.6294:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6240)
  %context.field.6295 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6296 = load i32, ptr %context.field.6295, align 4
  %runtime.ok.6297 = icmp eq i32 %context.value.6296, 0
  br i1 %runtime.ok.6297, label %runtime.continue.6298, label %frame.failure.0
runtime.continue.6298:
  %local.is.active.6299 = load i1, ptr %local.active.28, align 1
  %local.later.offset.6300 = load i32, ptr %local.offset.29, align 4
  %stack.sub.6301 = sub i32 %local.later.offset.6300, %local.remove.extent.6240
  %local.later.offset.selected.6302 = select i1 %local.is.active.6299, i32 %stack.sub.6301, i32 %local.later.offset.6300
  store i32 %local.later.offset.selected.6302, ptr %local.offset.29, align 4
  %local.is.active.6303 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6304 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6305 = sub i32 %local.later.offset.6304, %local.remove.extent.6240
  %local.later.offset.selected.6306 = select i1 %local.is.active.6303, i32 %stack.sub.6305, i32 %local.later.offset.6304
  store i32 %local.later.offset.selected.6306, ptr %local.offset.34, align 4
  %local.is.active.6307 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6308 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6309 = sub i32 %local.later.offset.6308, %local.remove.extent.6240
  %local.later.offset.selected.6310 = select i1 %local.is.active.6307, i32 %stack.sub.6309, i32 %local.later.offset.6308
  store i32 %local.later.offset.selected.6310, ptr %local.offset.39, align 4
  %local.is.active.6311 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6312 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6313 = sub i32 %local.later.offset.6312, %local.remove.extent.6240
  %local.later.offset.selected.6314 = select i1 %local.is.active.6311, i32 %stack.sub.6313, i32 %local.later.offset.6312
  store i32 %local.later.offset.selected.6314, ptr %local.offset.44, align 4
  %local.is.active.6315 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6316 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6317 = sub i32 %local.later.offset.6316, %local.remove.extent.6240
  %local.later.offset.selected.6318 = select i1 %local.is.active.6315, i32 %stack.sub.6317, i32 %local.later.offset.6316
  store i32 %local.later.offset.selected.6318, ptr %local.offset.49, align 4
  %local.is.active.6319 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6320 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6321 = sub i32 %local.later.offset.6320, %local.remove.extent.6240
  %local.later.offset.selected.6322 = select i1 %local.is.active.6319, i32 %stack.sub.6321, i32 %local.later.offset.6320
  store i32 %local.later.offset.selected.6322, ptr %local.offset.54, align 4
  %local.is.active.6323 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6324 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6325 = sub i32 %local.later.offset.6324, %local.remove.extent.6240
  %local.later.offset.selected.6326 = select i1 %local.is.active.6323, i32 %stack.sub.6325, i32 %local.later.offset.6324
  store i32 %local.later.offset.selected.6326, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  br label %local.removed.6238
local.removed.6238:
  %local.is.active.6327 = load i1, ptr %local.active.18, align 1
  br i1 %local.is.active.6327, label %local.remove.6328, label %local.keep.6329
local.keep.6329:
  br label %local.removed.6330
local.remove.6328:
  %local.remove.offset.6331 = load i32, ptr %local.offset.19, align 4
  %local.remove.extent.6332 = load i32, ptr %local.extent.20, align 4
  %local.remove.payload.6333 = load i32, ptr %local.payload.21, align 4
  %local.remove.type.6334 = load i32, ptr %local.type.22, align 4
  %stack.offset.6335 = add i32 %local.remove.offset.6331, %local.remove.extent.6332
  %context.field.6336 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6337 = load i32, ptr %context.field.6336, align 4
  %stack.sub.6338 = sub i32 %context.value.6337, %stack.offset.6335
  %local.is.active.6339 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.6340 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.6341 = select i1 %local.is.active.6339, i32 %local.suffix.payload.6340, i32 0
  %stack.offset.6342 = add i32 0, %local.suffix.selected.6341
  %local.is.active.6343 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.6344 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.6345 = select i1 %local.is.active.6343, i32 %local.suffix.payload.6344, i32 0
  %stack.offset.6346 = add i32 %stack.offset.6342, %local.suffix.selected.6345
  %local.is.active.6347 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6348 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6349 = select i1 %local.is.active.6347, i32 %local.suffix.payload.6348, i32 0
  %stack.offset.6350 = add i32 %stack.offset.6346, %local.suffix.selected.6349
  %local.is.active.6351 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6352 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6353 = select i1 %local.is.active.6351, i32 %local.suffix.payload.6352, i32 0
  %stack.offset.6354 = add i32 %stack.offset.6350, %local.suffix.selected.6353
  %local.is.active.6355 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6356 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6357 = select i1 %local.is.active.6355, i32 %local.suffix.payload.6356, i32 0
  %stack.offset.6358 = add i32 %stack.offset.6354, %local.suffix.selected.6357
  %local.is.active.6359 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6360 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6361 = select i1 %local.is.active.6359, i32 %local.suffix.payload.6360, i32 0
  %stack.offset.6362 = add i32 %stack.offset.6358, %local.suffix.selected.6361
  %local.is.active.6363 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6364 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6365 = select i1 %local.is.active.6363, i32 %local.suffix.payload.6364, i32 0
  %stack.offset.6366 = add i32 %stack.offset.6362, %local.suffix.selected.6365
  %local.is.active.6367 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6368 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6369 = select i1 %local.is.active.6367, i32 %local.suffix.payload.6368, i32 0
  %stack.offset.6370 = add i32 %stack.offset.6366, %local.suffix.selected.6369
  %stack.offset.6371 = add i32 0, %stack.offset.5631
  %stack.offset.6372 = add i32 %stack.offset.6370, %stack.offset.6371
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6331, i32 %stack.offset.6335, i32 %stack.sub.6338, i32 %stack.offset.6372, i32 0, i32 14)
  %context.field.6373 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6374 = load i32, ptr %context.field.6373, align 4
  %runtime.ok.6375 = icmp eq i32 %context.value.6374, 0
  br i1 %runtime.ok.6375, label %runtime.continue.6376, label %frame.failure.0
runtime.continue.6376:
  %stack.sub.6377 = sub i32 %context.value.6337, %local.remove.extent.6332
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6377, i32 0, i32 0, i32 0)
  %context.field.6378 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6379 = load i32, ptr %context.field.6378, align 4
  %runtime.ok.6380 = icmp eq i32 %context.value.6379, 0
  br i1 %runtime.ok.6380, label %runtime.continue.6381, label %frame.failure.0
runtime.continue.6381:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6334, i32 %local.remove.offset.6331, i32 %local.remove.extent.6332, i32 %local.remove.payload.6333, i32 0, i32 0)
  %context.field.6382 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6383 = load i32, ptr %context.field.6382, align 4
  %runtime.ok.6384 = icmp eq i32 %context.value.6383, 0
  br i1 %runtime.ok.6384, label %runtime.continue.6385, label %frame.failure.0
runtime.continue.6385:
  %stack.sub.6386 = sub i32 0, %local.remove.payload.6333
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6386, i32 %stack.sub.6386)
  %context.field.6387 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6388 = load i32, ptr %context.field.6387, align 4
  %runtime.ok.6389 = icmp eq i32 %context.value.6388, 0
  br i1 %runtime.ok.6389, label %runtime.continue.6390, label %frame.failure.0
runtime.continue.6390:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6332)
  %context.field.6391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6392 = load i32, ptr %context.field.6391, align 4
  %runtime.ok.6393 = icmp eq i32 %context.value.6392, 0
  br i1 %runtime.ok.6393, label %runtime.continue.6394, label %frame.failure.0
runtime.continue.6394:
  %local.is.active.6395 = load i1, ptr %local.active.23, align 1
  %local.later.offset.6396 = load i32, ptr %local.offset.24, align 4
  %stack.sub.6397 = sub i32 %local.later.offset.6396, %local.remove.extent.6332
  %local.later.offset.selected.6398 = select i1 %local.is.active.6395, i32 %stack.sub.6397, i32 %local.later.offset.6396
  store i32 %local.later.offset.selected.6398, ptr %local.offset.24, align 4
  %local.is.active.6399 = load i1, ptr %local.active.28, align 1
  %local.later.offset.6400 = load i32, ptr %local.offset.29, align 4
  %stack.sub.6401 = sub i32 %local.later.offset.6400, %local.remove.extent.6332
  %local.later.offset.selected.6402 = select i1 %local.is.active.6399, i32 %stack.sub.6401, i32 %local.later.offset.6400
  store i32 %local.later.offset.selected.6402, ptr %local.offset.29, align 4
  %local.is.active.6403 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6404 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6405 = sub i32 %local.later.offset.6404, %local.remove.extent.6332
  %local.later.offset.selected.6406 = select i1 %local.is.active.6403, i32 %stack.sub.6405, i32 %local.later.offset.6404
  store i32 %local.later.offset.selected.6406, ptr %local.offset.34, align 4
  %local.is.active.6407 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6408 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6409 = sub i32 %local.later.offset.6408, %local.remove.extent.6332
  %local.later.offset.selected.6410 = select i1 %local.is.active.6407, i32 %stack.sub.6409, i32 %local.later.offset.6408
  store i32 %local.later.offset.selected.6410, ptr %local.offset.39, align 4
  %local.is.active.6411 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6412 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6413 = sub i32 %local.later.offset.6412, %local.remove.extent.6332
  %local.later.offset.selected.6414 = select i1 %local.is.active.6411, i32 %stack.sub.6413, i32 %local.later.offset.6412
  store i32 %local.later.offset.selected.6414, ptr %local.offset.44, align 4
  %local.is.active.6415 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6416 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6417 = sub i32 %local.later.offset.6416, %local.remove.extent.6332
  %local.later.offset.selected.6418 = select i1 %local.is.active.6415, i32 %stack.sub.6417, i32 %local.later.offset.6416
  store i32 %local.later.offset.selected.6418, ptr %local.offset.49, align 4
  %local.is.active.6419 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6420 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6421 = sub i32 %local.later.offset.6420, %local.remove.extent.6332
  %local.later.offset.selected.6422 = select i1 %local.is.active.6419, i32 %stack.sub.6421, i32 %local.later.offset.6420
  store i32 %local.later.offset.selected.6422, ptr %local.offset.54, align 4
  %local.is.active.6423 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6424 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6425 = sub i32 %local.later.offset.6424, %local.remove.extent.6332
  %local.later.offset.selected.6426 = select i1 %local.is.active.6423, i32 %stack.sub.6425, i32 %local.later.offset.6424
  store i32 %local.later.offset.selected.6426, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  br label %local.removed.6330
local.removed.6330:
  %local.is.active.6427 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.6427, label %local.remove.6428, label %local.keep.6429
local.keep.6429:
  br label %local.removed.6430
local.remove.6428:
  %local.remove.offset.6431 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.6432 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.6433 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.6434 = load i32, ptr %local.type.17, align 4
  %stack.offset.6435 = add i32 %local.remove.offset.6431, %local.remove.extent.6432
  %context.field.6436 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6437 = load i32, ptr %context.field.6436, align 4
  %stack.sub.6438 = sub i32 %context.value.6437, %stack.offset.6435
  %local.is.active.6439 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.6440 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.6441 = select i1 %local.is.active.6439, i32 %local.suffix.payload.6440, i32 0
  %stack.offset.6442 = add i32 0, %local.suffix.selected.6441
  %local.is.active.6443 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.6444 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.6445 = select i1 %local.is.active.6443, i32 %local.suffix.payload.6444, i32 0
  %stack.offset.6446 = add i32 %stack.offset.6442, %local.suffix.selected.6445
  %local.is.active.6447 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.6448 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.6449 = select i1 %local.is.active.6447, i32 %local.suffix.payload.6448, i32 0
  %stack.offset.6450 = add i32 %stack.offset.6446, %local.suffix.selected.6449
  %local.is.active.6451 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6452 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6453 = select i1 %local.is.active.6451, i32 %local.suffix.payload.6452, i32 0
  %stack.offset.6454 = add i32 %stack.offset.6450, %local.suffix.selected.6453
  %local.is.active.6455 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6456 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6457 = select i1 %local.is.active.6455, i32 %local.suffix.payload.6456, i32 0
  %stack.offset.6458 = add i32 %stack.offset.6454, %local.suffix.selected.6457
  %local.is.active.6459 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6460 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6461 = select i1 %local.is.active.6459, i32 %local.suffix.payload.6460, i32 0
  %stack.offset.6462 = add i32 %stack.offset.6458, %local.suffix.selected.6461
  %local.is.active.6463 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6464 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6465 = select i1 %local.is.active.6463, i32 %local.suffix.payload.6464, i32 0
  %stack.offset.6466 = add i32 %stack.offset.6462, %local.suffix.selected.6465
  %local.is.active.6467 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6468 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6469 = select i1 %local.is.active.6467, i32 %local.suffix.payload.6468, i32 0
  %stack.offset.6470 = add i32 %stack.offset.6466, %local.suffix.selected.6469
  %local.is.active.6471 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6472 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6473 = select i1 %local.is.active.6471, i32 %local.suffix.payload.6472, i32 0
  %stack.offset.6474 = add i32 %stack.offset.6470, %local.suffix.selected.6473
  %stack.offset.6475 = add i32 0, %stack.offset.5631
  %stack.offset.6476 = add i32 %stack.offset.6474, %stack.offset.6475
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6431, i32 %stack.offset.6435, i32 %stack.sub.6438, i32 %stack.offset.6476, i32 0, i32 14)
  %context.field.6477 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6478 = load i32, ptr %context.field.6477, align 4
  %runtime.ok.6479 = icmp eq i32 %context.value.6478, 0
  br i1 %runtime.ok.6479, label %runtime.continue.6480, label %frame.failure.0
runtime.continue.6480:
  %stack.sub.6481 = sub i32 %context.value.6437, %local.remove.extent.6432
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6481, i32 0, i32 0, i32 0)
  %context.field.6482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6483 = load i32, ptr %context.field.6482, align 4
  %runtime.ok.6484 = icmp eq i32 %context.value.6483, 0
  br i1 %runtime.ok.6484, label %runtime.continue.6485, label %frame.failure.0
runtime.continue.6485:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6434, i32 %local.remove.offset.6431, i32 %local.remove.extent.6432, i32 %local.remove.payload.6433, i32 0, i32 0)
  %context.field.6486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6487 = load i32, ptr %context.field.6486, align 4
  %runtime.ok.6488 = icmp eq i32 %context.value.6487, 0
  br i1 %runtime.ok.6488, label %runtime.continue.6489, label %frame.failure.0
runtime.continue.6489:
  %stack.sub.6490 = sub i32 0, %local.remove.payload.6433
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6490, i32 %stack.sub.6490)
  %context.field.6491 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6492 = load i32, ptr %context.field.6491, align 4
  %runtime.ok.6493 = icmp eq i32 %context.value.6492, 0
  br i1 %runtime.ok.6493, label %runtime.continue.6494, label %frame.failure.0
runtime.continue.6494:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6432)
  %context.field.6495 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6496 = load i32, ptr %context.field.6495, align 4
  %runtime.ok.6497 = icmp eq i32 %context.value.6496, 0
  br i1 %runtime.ok.6497, label %runtime.continue.6498, label %frame.failure.0
runtime.continue.6498:
  %local.is.active.6499 = load i1, ptr %local.active.18, align 1
  %local.later.offset.6500 = load i32, ptr %local.offset.19, align 4
  %stack.sub.6501 = sub i32 %local.later.offset.6500, %local.remove.extent.6432
  %local.later.offset.selected.6502 = select i1 %local.is.active.6499, i32 %stack.sub.6501, i32 %local.later.offset.6500
  store i32 %local.later.offset.selected.6502, ptr %local.offset.19, align 4
  %local.is.active.6503 = load i1, ptr %local.active.23, align 1
  %local.later.offset.6504 = load i32, ptr %local.offset.24, align 4
  %stack.sub.6505 = sub i32 %local.later.offset.6504, %local.remove.extent.6432
  %local.later.offset.selected.6506 = select i1 %local.is.active.6503, i32 %stack.sub.6505, i32 %local.later.offset.6504
  store i32 %local.later.offset.selected.6506, ptr %local.offset.24, align 4
  %local.is.active.6507 = load i1, ptr %local.active.28, align 1
  %local.later.offset.6508 = load i32, ptr %local.offset.29, align 4
  %stack.sub.6509 = sub i32 %local.later.offset.6508, %local.remove.extent.6432
  %local.later.offset.selected.6510 = select i1 %local.is.active.6507, i32 %stack.sub.6509, i32 %local.later.offset.6508
  store i32 %local.later.offset.selected.6510, ptr %local.offset.29, align 4
  %local.is.active.6511 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6512 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6513 = sub i32 %local.later.offset.6512, %local.remove.extent.6432
  %local.later.offset.selected.6514 = select i1 %local.is.active.6511, i32 %stack.sub.6513, i32 %local.later.offset.6512
  store i32 %local.later.offset.selected.6514, ptr %local.offset.34, align 4
  %local.is.active.6515 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6516 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6517 = sub i32 %local.later.offset.6516, %local.remove.extent.6432
  %local.later.offset.selected.6518 = select i1 %local.is.active.6515, i32 %stack.sub.6517, i32 %local.later.offset.6516
  store i32 %local.later.offset.selected.6518, ptr %local.offset.39, align 4
  %local.is.active.6519 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6520 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6521 = sub i32 %local.later.offset.6520, %local.remove.extent.6432
  %local.later.offset.selected.6522 = select i1 %local.is.active.6519, i32 %stack.sub.6521, i32 %local.later.offset.6520
  store i32 %local.later.offset.selected.6522, ptr %local.offset.44, align 4
  %local.is.active.6523 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6524 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6525 = sub i32 %local.later.offset.6524, %local.remove.extent.6432
  %local.later.offset.selected.6526 = select i1 %local.is.active.6523, i32 %stack.sub.6525, i32 %local.later.offset.6524
  store i32 %local.later.offset.selected.6526, ptr %local.offset.49, align 4
  %local.is.active.6527 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6528 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6529 = sub i32 %local.later.offset.6528, %local.remove.extent.6432
  %local.later.offset.selected.6530 = select i1 %local.is.active.6527, i32 %stack.sub.6529, i32 %local.later.offset.6528
  store i32 %local.later.offset.selected.6530, ptr %local.offset.54, align 4
  %local.is.active.6531 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6532 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6533 = sub i32 %local.later.offset.6532, %local.remove.extent.6432
  %local.later.offset.selected.6534 = select i1 %local.is.active.6531, i32 %stack.sub.6533, i32 %local.later.offset.6532
  store i32 %local.later.offset.selected.6534, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.6430
local.removed.6430:
  %local.is.active.6535 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.6535, label %local.remove.6536, label %local.keep.6537
local.keep.6537:
  br label %local.removed.6538
local.remove.6536:
  %local.remove.offset.6539 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.6540 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.6541 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.6542 = load i32, ptr %local.type.12, align 4
  %stack.offset.6543 = add i32 %local.remove.offset.6539, %local.remove.extent.6540
  %context.field.6544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6545 = load i32, ptr %context.field.6544, align 4
  %stack.sub.6546 = sub i32 %context.value.6545, %stack.offset.6543
  %local.is.active.6547 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.6548 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.6549 = select i1 %local.is.active.6547, i32 %local.suffix.payload.6548, i32 0
  %stack.offset.6550 = add i32 0, %local.suffix.selected.6549
  %local.is.active.6551 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.6552 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.6553 = select i1 %local.is.active.6551, i32 %local.suffix.payload.6552, i32 0
  %stack.offset.6554 = add i32 %stack.offset.6550, %local.suffix.selected.6553
  %local.is.active.6555 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.6556 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.6557 = select i1 %local.is.active.6555, i32 %local.suffix.payload.6556, i32 0
  %stack.offset.6558 = add i32 %stack.offset.6554, %local.suffix.selected.6557
  %local.is.active.6559 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.6560 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.6561 = select i1 %local.is.active.6559, i32 %local.suffix.payload.6560, i32 0
  %stack.offset.6562 = add i32 %stack.offset.6558, %local.suffix.selected.6561
  %local.is.active.6563 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6564 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6565 = select i1 %local.is.active.6563, i32 %local.suffix.payload.6564, i32 0
  %stack.offset.6566 = add i32 %stack.offset.6562, %local.suffix.selected.6565
  %local.is.active.6567 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6568 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6569 = select i1 %local.is.active.6567, i32 %local.suffix.payload.6568, i32 0
  %stack.offset.6570 = add i32 %stack.offset.6566, %local.suffix.selected.6569
  %local.is.active.6571 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6572 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6573 = select i1 %local.is.active.6571, i32 %local.suffix.payload.6572, i32 0
  %stack.offset.6574 = add i32 %stack.offset.6570, %local.suffix.selected.6573
  %local.is.active.6575 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6576 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6577 = select i1 %local.is.active.6575, i32 %local.suffix.payload.6576, i32 0
  %stack.offset.6578 = add i32 %stack.offset.6574, %local.suffix.selected.6577
  %local.is.active.6579 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6580 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6581 = select i1 %local.is.active.6579, i32 %local.suffix.payload.6580, i32 0
  %stack.offset.6582 = add i32 %stack.offset.6578, %local.suffix.selected.6581
  %local.is.active.6583 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6584 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6585 = select i1 %local.is.active.6583, i32 %local.suffix.payload.6584, i32 0
  %stack.offset.6586 = add i32 %stack.offset.6582, %local.suffix.selected.6585
  %stack.offset.6587 = add i32 0, %stack.offset.5631
  %stack.offset.6588 = add i32 %stack.offset.6586, %stack.offset.6587
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6539, i32 %stack.offset.6543, i32 %stack.sub.6546, i32 %stack.offset.6588, i32 0, i32 14)
  %context.field.6589 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6590 = load i32, ptr %context.field.6589, align 4
  %runtime.ok.6591 = icmp eq i32 %context.value.6590, 0
  br i1 %runtime.ok.6591, label %runtime.continue.6592, label %frame.failure.0
runtime.continue.6592:
  %stack.sub.6593 = sub i32 %context.value.6545, %local.remove.extent.6540
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6593, i32 0, i32 0, i32 0)
  %context.field.6594 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6595 = load i32, ptr %context.field.6594, align 4
  %runtime.ok.6596 = icmp eq i32 %context.value.6595, 0
  br i1 %runtime.ok.6596, label %runtime.continue.6597, label %frame.failure.0
runtime.continue.6597:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6542, i32 %local.remove.offset.6539, i32 %local.remove.extent.6540, i32 %local.remove.payload.6541, i32 0, i32 0)
  %context.field.6598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6599 = load i32, ptr %context.field.6598, align 4
  %runtime.ok.6600 = icmp eq i32 %context.value.6599, 0
  br i1 %runtime.ok.6600, label %runtime.continue.6601, label %frame.failure.0
runtime.continue.6601:
  %stack.sub.6602 = sub i32 0, %local.remove.payload.6541
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6602, i32 %stack.sub.6602)
  %context.field.6603 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6604 = load i32, ptr %context.field.6603, align 4
  %runtime.ok.6605 = icmp eq i32 %context.value.6604, 0
  br i1 %runtime.ok.6605, label %runtime.continue.6606, label %frame.failure.0
runtime.continue.6606:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6540)
  %context.field.6607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6608 = load i32, ptr %context.field.6607, align 4
  %runtime.ok.6609 = icmp eq i32 %context.value.6608, 0
  br i1 %runtime.ok.6609, label %runtime.continue.6610, label %frame.failure.0
runtime.continue.6610:
  %local.is.active.6611 = load i1, ptr %local.active.13, align 1
  %local.later.offset.6612 = load i32, ptr %local.offset.14, align 4
  %stack.sub.6613 = sub i32 %local.later.offset.6612, %local.remove.extent.6540
  %local.later.offset.selected.6614 = select i1 %local.is.active.6611, i32 %stack.sub.6613, i32 %local.later.offset.6612
  store i32 %local.later.offset.selected.6614, ptr %local.offset.14, align 4
  %local.is.active.6615 = load i1, ptr %local.active.18, align 1
  %local.later.offset.6616 = load i32, ptr %local.offset.19, align 4
  %stack.sub.6617 = sub i32 %local.later.offset.6616, %local.remove.extent.6540
  %local.later.offset.selected.6618 = select i1 %local.is.active.6615, i32 %stack.sub.6617, i32 %local.later.offset.6616
  store i32 %local.later.offset.selected.6618, ptr %local.offset.19, align 4
  %local.is.active.6619 = load i1, ptr %local.active.23, align 1
  %local.later.offset.6620 = load i32, ptr %local.offset.24, align 4
  %stack.sub.6621 = sub i32 %local.later.offset.6620, %local.remove.extent.6540
  %local.later.offset.selected.6622 = select i1 %local.is.active.6619, i32 %stack.sub.6621, i32 %local.later.offset.6620
  store i32 %local.later.offset.selected.6622, ptr %local.offset.24, align 4
  %local.is.active.6623 = load i1, ptr %local.active.28, align 1
  %local.later.offset.6624 = load i32, ptr %local.offset.29, align 4
  %stack.sub.6625 = sub i32 %local.later.offset.6624, %local.remove.extent.6540
  %local.later.offset.selected.6626 = select i1 %local.is.active.6623, i32 %stack.sub.6625, i32 %local.later.offset.6624
  store i32 %local.later.offset.selected.6626, ptr %local.offset.29, align 4
  %local.is.active.6627 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6628 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6629 = sub i32 %local.later.offset.6628, %local.remove.extent.6540
  %local.later.offset.selected.6630 = select i1 %local.is.active.6627, i32 %stack.sub.6629, i32 %local.later.offset.6628
  store i32 %local.later.offset.selected.6630, ptr %local.offset.34, align 4
  %local.is.active.6631 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6632 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6633 = sub i32 %local.later.offset.6632, %local.remove.extent.6540
  %local.later.offset.selected.6634 = select i1 %local.is.active.6631, i32 %stack.sub.6633, i32 %local.later.offset.6632
  store i32 %local.later.offset.selected.6634, ptr %local.offset.39, align 4
  %local.is.active.6635 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6636 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6637 = sub i32 %local.later.offset.6636, %local.remove.extent.6540
  %local.later.offset.selected.6638 = select i1 %local.is.active.6635, i32 %stack.sub.6637, i32 %local.later.offset.6636
  store i32 %local.later.offset.selected.6638, ptr %local.offset.44, align 4
  %local.is.active.6639 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6640 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6641 = sub i32 %local.later.offset.6640, %local.remove.extent.6540
  %local.later.offset.selected.6642 = select i1 %local.is.active.6639, i32 %stack.sub.6641, i32 %local.later.offset.6640
  store i32 %local.later.offset.selected.6642, ptr %local.offset.49, align 4
  %local.is.active.6643 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6644 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6645 = sub i32 %local.later.offset.6644, %local.remove.extent.6540
  %local.later.offset.selected.6646 = select i1 %local.is.active.6643, i32 %stack.sub.6645, i32 %local.later.offset.6644
  store i32 %local.later.offset.selected.6646, ptr %local.offset.54, align 4
  %local.is.active.6647 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6648 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6649 = sub i32 %local.later.offset.6648, %local.remove.extent.6540
  %local.later.offset.selected.6650 = select i1 %local.is.active.6647, i32 %stack.sub.6649, i32 %local.later.offset.6648
  store i32 %local.later.offset.selected.6650, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.6538
local.removed.6538:
  %local.is.active.6651 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.6651, label %local.remove.6652, label %local.keep.6653
local.keep.6653:
  br label %local.removed.6654
local.remove.6652:
  %local.remove.offset.6655 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.6656 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.6657 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.6658 = load i32, ptr %local.type.7, align 4
  %stack.offset.6659 = add i32 %local.remove.offset.6655, %local.remove.extent.6656
  %context.field.6660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.6661 = load i32, ptr %context.field.6660, align 4
  %stack.sub.6662 = sub i32 %context.value.6661, %stack.offset.6659
  %local.is.active.6663 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.6664 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.6665 = select i1 %local.is.active.6663, i32 %local.suffix.payload.6664, i32 0
  %stack.offset.6666 = add i32 0, %local.suffix.selected.6665
  %local.is.active.6667 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.6668 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.6669 = select i1 %local.is.active.6667, i32 %local.suffix.payload.6668, i32 0
  %stack.offset.6670 = add i32 %stack.offset.6666, %local.suffix.selected.6669
  %local.is.active.6671 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.6672 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.6673 = select i1 %local.is.active.6671, i32 %local.suffix.payload.6672, i32 0
  %stack.offset.6674 = add i32 %stack.offset.6670, %local.suffix.selected.6673
  %local.is.active.6675 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.6676 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.6677 = select i1 %local.is.active.6675, i32 %local.suffix.payload.6676, i32 0
  %stack.offset.6678 = add i32 %stack.offset.6674, %local.suffix.selected.6677
  %local.is.active.6679 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.6680 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.6681 = select i1 %local.is.active.6679, i32 %local.suffix.payload.6680, i32 0
  %stack.offset.6682 = add i32 %stack.offset.6678, %local.suffix.selected.6681
  %local.is.active.6683 = load i1, ptr %local.active.33, align 1
  %local.suffix.payload.6684 = load i32, ptr %local.payload.36, align 4
  %local.suffix.selected.6685 = select i1 %local.is.active.6683, i32 %local.suffix.payload.6684, i32 0
  %stack.offset.6686 = add i32 %stack.offset.6682, %local.suffix.selected.6685
  %local.is.active.6687 = load i1, ptr %local.active.38, align 1
  %local.suffix.payload.6688 = load i32, ptr %local.payload.41, align 4
  %local.suffix.selected.6689 = select i1 %local.is.active.6687, i32 %local.suffix.payload.6688, i32 0
  %stack.offset.6690 = add i32 %stack.offset.6686, %local.suffix.selected.6689
  %local.is.active.6691 = load i1, ptr %local.active.43, align 1
  %local.suffix.payload.6692 = load i32, ptr %local.payload.46, align 4
  %local.suffix.selected.6693 = select i1 %local.is.active.6691, i32 %local.suffix.payload.6692, i32 0
  %stack.offset.6694 = add i32 %stack.offset.6690, %local.suffix.selected.6693
  %local.is.active.6695 = load i1, ptr %local.active.48, align 1
  %local.suffix.payload.6696 = load i32, ptr %local.payload.51, align 4
  %local.suffix.selected.6697 = select i1 %local.is.active.6695, i32 %local.suffix.payload.6696, i32 0
  %stack.offset.6698 = add i32 %stack.offset.6694, %local.suffix.selected.6697
  %local.is.active.6699 = load i1, ptr %local.active.53, align 1
  %local.suffix.payload.6700 = load i32, ptr %local.payload.56, align 4
  %local.suffix.selected.6701 = select i1 %local.is.active.6699, i32 %local.suffix.payload.6700, i32 0
  %stack.offset.6702 = add i32 %stack.offset.6698, %local.suffix.selected.6701
  %local.is.active.6703 = load i1, ptr %local.active.58, align 1
  %local.suffix.payload.6704 = load i32, ptr %local.payload.61, align 4
  %local.suffix.selected.6705 = select i1 %local.is.active.6703, i32 %local.suffix.payload.6704, i32 0
  %stack.offset.6706 = add i32 %stack.offset.6702, %local.suffix.selected.6705
  %stack.offset.6707 = add i32 0, %stack.offset.5631
  %stack.offset.6708 = add i32 %stack.offset.6706, %stack.offset.6707
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.6655, i32 %stack.offset.6659, i32 %stack.sub.6662, i32 %stack.offset.6708, i32 0, i32 14)
  %context.field.6709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6710 = load i32, ptr %context.field.6709, align 4
  %runtime.ok.6711 = icmp eq i32 %context.value.6710, 0
  br i1 %runtime.ok.6711, label %runtime.continue.6712, label %frame.failure.0
runtime.continue.6712:
  %stack.sub.6713 = sub i32 %context.value.6661, %local.remove.extent.6656
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.6713, i32 0, i32 0, i32 0)
  %context.field.6714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6715 = load i32, ptr %context.field.6714, align 4
  %runtime.ok.6716 = icmp eq i32 %context.value.6715, 0
  br i1 %runtime.ok.6716, label %runtime.continue.6717, label %frame.failure.0
runtime.continue.6717:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.6658, i32 %local.remove.offset.6655, i32 %local.remove.extent.6656, i32 %local.remove.payload.6657, i32 0, i32 0)
  %context.field.6718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6719 = load i32, ptr %context.field.6718, align 4
  %runtime.ok.6720 = icmp eq i32 %context.value.6719, 0
  br i1 %runtime.ok.6720, label %runtime.continue.6721, label %frame.failure.0
runtime.continue.6721:
  %stack.sub.6722 = sub i32 0, %local.remove.payload.6657
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6722, i32 %stack.sub.6722)
  %context.field.6723 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6724 = load i32, ptr %context.field.6723, align 4
  %runtime.ok.6725 = icmp eq i32 %context.value.6724, 0
  br i1 %runtime.ok.6725, label %runtime.continue.6726, label %frame.failure.0
runtime.continue.6726:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.6656)
  %context.field.6727 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.6728 = load i32, ptr %context.field.6727, align 4
  %runtime.ok.6729 = icmp eq i32 %context.value.6728, 0
  br i1 %runtime.ok.6729, label %runtime.continue.6730, label %frame.failure.0
runtime.continue.6730:
  %local.is.active.6731 = load i1, ptr %local.active.8, align 1
  %local.later.offset.6732 = load i32, ptr %local.offset.9, align 4
  %stack.sub.6733 = sub i32 %local.later.offset.6732, %local.remove.extent.6656
  %local.later.offset.selected.6734 = select i1 %local.is.active.6731, i32 %stack.sub.6733, i32 %local.later.offset.6732
  store i32 %local.later.offset.selected.6734, ptr %local.offset.9, align 4
  %local.is.active.6735 = load i1, ptr %local.active.13, align 1
  %local.later.offset.6736 = load i32, ptr %local.offset.14, align 4
  %stack.sub.6737 = sub i32 %local.later.offset.6736, %local.remove.extent.6656
  %local.later.offset.selected.6738 = select i1 %local.is.active.6735, i32 %stack.sub.6737, i32 %local.later.offset.6736
  store i32 %local.later.offset.selected.6738, ptr %local.offset.14, align 4
  %local.is.active.6739 = load i1, ptr %local.active.18, align 1
  %local.later.offset.6740 = load i32, ptr %local.offset.19, align 4
  %stack.sub.6741 = sub i32 %local.later.offset.6740, %local.remove.extent.6656
  %local.later.offset.selected.6742 = select i1 %local.is.active.6739, i32 %stack.sub.6741, i32 %local.later.offset.6740
  store i32 %local.later.offset.selected.6742, ptr %local.offset.19, align 4
  %local.is.active.6743 = load i1, ptr %local.active.23, align 1
  %local.later.offset.6744 = load i32, ptr %local.offset.24, align 4
  %stack.sub.6745 = sub i32 %local.later.offset.6744, %local.remove.extent.6656
  %local.later.offset.selected.6746 = select i1 %local.is.active.6743, i32 %stack.sub.6745, i32 %local.later.offset.6744
  store i32 %local.later.offset.selected.6746, ptr %local.offset.24, align 4
  %local.is.active.6747 = load i1, ptr %local.active.28, align 1
  %local.later.offset.6748 = load i32, ptr %local.offset.29, align 4
  %stack.sub.6749 = sub i32 %local.later.offset.6748, %local.remove.extent.6656
  %local.later.offset.selected.6750 = select i1 %local.is.active.6747, i32 %stack.sub.6749, i32 %local.later.offset.6748
  store i32 %local.later.offset.selected.6750, ptr %local.offset.29, align 4
  %local.is.active.6751 = load i1, ptr %local.active.33, align 1
  %local.later.offset.6752 = load i32, ptr %local.offset.34, align 4
  %stack.sub.6753 = sub i32 %local.later.offset.6752, %local.remove.extent.6656
  %local.later.offset.selected.6754 = select i1 %local.is.active.6751, i32 %stack.sub.6753, i32 %local.later.offset.6752
  store i32 %local.later.offset.selected.6754, ptr %local.offset.34, align 4
  %local.is.active.6755 = load i1, ptr %local.active.38, align 1
  %local.later.offset.6756 = load i32, ptr %local.offset.39, align 4
  %stack.sub.6757 = sub i32 %local.later.offset.6756, %local.remove.extent.6656
  %local.later.offset.selected.6758 = select i1 %local.is.active.6755, i32 %stack.sub.6757, i32 %local.later.offset.6756
  store i32 %local.later.offset.selected.6758, ptr %local.offset.39, align 4
  %local.is.active.6759 = load i1, ptr %local.active.43, align 1
  %local.later.offset.6760 = load i32, ptr %local.offset.44, align 4
  %stack.sub.6761 = sub i32 %local.later.offset.6760, %local.remove.extent.6656
  %local.later.offset.selected.6762 = select i1 %local.is.active.6759, i32 %stack.sub.6761, i32 %local.later.offset.6760
  store i32 %local.later.offset.selected.6762, ptr %local.offset.44, align 4
  %local.is.active.6763 = load i1, ptr %local.active.48, align 1
  %local.later.offset.6764 = load i32, ptr %local.offset.49, align 4
  %stack.sub.6765 = sub i32 %local.later.offset.6764, %local.remove.extent.6656
  %local.later.offset.selected.6766 = select i1 %local.is.active.6763, i32 %stack.sub.6765, i32 %local.later.offset.6764
  store i32 %local.later.offset.selected.6766, ptr %local.offset.49, align 4
  %local.is.active.6767 = load i1, ptr %local.active.53, align 1
  %local.later.offset.6768 = load i32, ptr %local.offset.54, align 4
  %stack.sub.6769 = sub i32 %local.later.offset.6768, %local.remove.extent.6656
  %local.later.offset.selected.6770 = select i1 %local.is.active.6767, i32 %stack.sub.6769, i32 %local.later.offset.6768
  store i32 %local.later.offset.selected.6770, ptr %local.offset.54, align 4
  %local.is.active.6771 = load i1, ptr %local.active.58, align 1
  %local.later.offset.6772 = load i32, ptr %local.offset.59, align 4
  %stack.sub.6773 = sub i32 %local.later.offset.6772, %local.remove.extent.6656
  %local.later.offset.selected.6774 = select i1 %local.is.active.6771, i32 %stack.sub.6773, i32 %local.later.offset.6772
  store i32 %local.later.offset.selected.6774, ptr %local.offset.59, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.6654
local.removed.6654:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.64, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.64, i32 0, i32 0, i32 0)
  %context.field.6775 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6776 = load i32, ptr %context.field.6775, align 4
  %context.field.6777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.6778 = load i32, ptr %context.field.6777, align 4
  %context.field.6779 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.6780 = load i32, ptr %context.field.6779, align 4
  %stack.offset.6781 = add i32 %context.value.66, %context.value.68
  %stack.offset.6782 = add i32 %context.value.6776, %context.value.6778
  %stack.sub.6783 = sub i32 %stack.offset.6781, %stack.offset.6782
  %stack.sub.6784 = sub i32 %context.value.68, %context.value.6778
  %stack.sub.6785 = sub i32 %context.value.6780, %context.value.70
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.6783, i32 %stack.sub.6784)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.6785)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %frame.entered.26 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.27 = icmp eq i32 %frame.entered.26, 0
  br i1 %frame.enter.ok.27, label %frame.enter.continue.28, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.28:
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %stack.offset.31 = add i32 %argument.source, %argument.bytes
  %stack.offset.32 = add i32 %context.value.30, %argument.bytes
  %reserve.status.33 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.32, i32 113)
  %reserve.ok.34 = icmp eq i32 %reserve.status.33, 0
  br i1 %reserve.ok.34, label %reserve.continue.35, label %frame.reserve.failure.1
reserve.continue.35:
  %value.size.36 = alloca %AlOwningValueSize, align 4
  %measure.status.37 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.31, i32 114, ptr %value.size.36)
  %helper.ok.38 = icmp eq i32 %measure.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %value.payload.pointer.40 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.36, i32 0, i32 0
  %value.extent.pointer.41 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.36, i32 0, i32 1
  %value.payload.42 = load i32, ptr %value.payload.pointer.40, align 4
  %value.extent.43 = load i32, ptr %value.extent.pointer.41, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.30, i32 %argument.source, i32 %value.extent.43, i32 %value.payload.42, i32 8, i32 8)
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %runtime.ok.46 = icmp eq i32 %context.value.45, 0
  br i1 %runtime.ok.46, label %runtime.continue.47, label %frame.failure.0
runtime.continue.47:
  %stack.offset.48 = add i32 %argument.source, %value.extent.43
  %stack.offset.49 = add i32 %context.value.30, %value.extent.43
  %arguments.exact.50 = icmp eq i32 %stack.offset.48, %stack.offset.31
  br i1 %arguments.exact.50, label %arguments.continue.51, label %frame.failure.0
arguments.continue.51:
  %step.status.52 = call i32 @al_owning_charge_step(ptr %ctx, i32 115)
  %helper.ok.53 = icmp eq i32 %step.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %local.is.active.55 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.56 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.57 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.58 = select i1 %local.is.active.55, i32 %local.previous.extent.56, i32 0
  %local.old.payload.59 = select i1 %local.is.active.55, i32 %local.previous.payload.57, i32 0
  %stack.offset.60 = add i32 %context.value.30, 0
  %stack.offset.61 = add i32 %stack.offset.60, %local.old.extent.58
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.64 = sub i32 %context.value.63, %stack.offset.61
  %stack.sub.65 = sub i32 %context.value.63, %local.old.extent.58
  %stack.offset.66 = add i32 %stack.sub.65, %value.extent.43
  %local.grows.67 = icmp ugt i32 %value.extent.43, %local.old.extent.58
  br i1 %local.grows.67, label %local.grow.68, label %local.fixed.69
local.grow.68:
  %reserve.status.71 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.66, i32 116)
  %reserve.ok.72 = icmp eq i32 %reserve.status.71, 0
  br i1 %reserve.ok.72, label %reserve.continue.73, label %frame.failure.0
reserve.continue.73:
  %stack.sub.74 = sub i32 %value.extent.43, %local.old.extent.58
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.74)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  br label %local.layout.ready.70
local.fixed.69:
  br label %local.layout.ready.70
local.layout.ready.70:
  %stack.offset.79 = add i32 %stack.offset.60, %value.extent.43
  %local.is.active.80 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.81 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.82 = select i1 %local.is.active.80, i32 %local.suffix.payload.81, i32 0
  %stack.offset.83 = add i32 0, %local.suffix.selected.82
  %local.is.active.84 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.85 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.86 = select i1 %local.is.active.84, i32 %local.suffix.payload.85, i32 0
  %stack.offset.87 = add i32 %stack.offset.83, %local.suffix.selected.86
  %stack.offset.88 = add i32 0, %value.payload.42
  %stack.offset.89 = add i32 %stack.offset.87, %stack.offset.88
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.79, i32 %stack.offset.61, i32 %stack.sub.64, i32 %stack.offset.89, i32 0, i32 14)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %stack.sub.94 = sub i32 %context.value.63, %value.extent.43
  %stack.sub.95 = sub i32 %stack.sub.94, %local.old.extent.58
  %stack.offset.96 = add i32 %stack.sub.95, %value.extent.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.60, i32 %stack.offset.96, i32 %value.extent.43, i32 %value.payload.42, i32 8, i32 4)
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %runtime.ok.99 = icmp eq i32 %context.value.98, 0
  br i1 %runtime.ok.99, label %runtime.continue.100, label %frame.failure.0
runtime.continue.100:
  %stack.sub.101 = sub i32 %context.value.63, %local.old.extent.58
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.101, i32 0, i32 0, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %local.shrinks.106 = icmp ult i32 %value.extent.43, %local.old.extent.58
  br i1 %local.shrinks.106, label %local.shrink.107, label %local.counts.ready.108
local.shrink.107:
  %stack.sub.109 = sub i32 %local.old.extent.58, %value.extent.43
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.109)
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %runtime.ok.112 = icmp eq i32 %context.value.111, 0
  br i1 %runtime.ok.112, label %runtime.continue.113, label %frame.failure.0
runtime.continue.113:
  br label %local.counts.ready.108
local.counts.ready.108:
  %local.payload.delta.114 = sub i32 %value.payload.42, %local.old.payload.59
  %stack.sub.115 = sub i32 0, %local.old.payload.59
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.115, i32 %local.payload.delta.114)
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %runtime.ok.118 = icmp eq i32 %context.value.117, 0
  br i1 %runtime.ok.118, label %runtime.continue.119, label %frame.failure.0
runtime.continue.119:
  %local.is.active.120 = load i1, ptr %local.active.8, align 1
  %local.later.offset.121 = load i32, ptr %local.offset.9, align 4
  %stack.sub.122 = sub i32 %local.later.offset.121, %local.old.extent.58
  %stack.offset.123 = add i32 %stack.sub.122, %value.extent.43
  %local.later.offset.selected.124 = select i1 %local.is.active.120, i32 %stack.offset.123, i32 %local.later.offset.121
  store i32 %local.later.offset.selected.124, ptr %local.offset.9, align 4
  %local.is.active.125 = load i1, ptr %local.active.13, align 1
  %local.later.offset.126 = load i32, ptr %local.offset.14, align 4
  %stack.sub.127 = sub i32 %local.later.offset.126, %local.old.extent.58
  %stack.offset.128 = add i32 %stack.sub.127, %value.extent.43
  %local.later.offset.selected.129 = select i1 %local.is.active.125, i32 %stack.offset.128, i32 %local.later.offset.126
  store i32 %local.later.offset.selected.129, ptr %local.offset.14, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.60, ptr %local.offset.4, align 4
  store i32 %value.extent.43, ptr %local.extent.5, align 4
  store i32 %value.payload.42, ptr %local.payload.6, align 4
  store i32 8, ptr %local.type.7, align 4
  %local.is.active.130 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.131 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.132 = select i1 %local.is.active.130, i32 %local.sum.extent.131, i32 0
  %stack.offset.133 = add i32 0, %local.sum.selected.132
  %local.is.active.134 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.135 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.136 = select i1 %local.is.active.134, i32 %local.sum.extent.135, i32 0
  %stack.offset.137 = add i32 %stack.offset.133, %local.sum.selected.136
  %local.is.active.138 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.139 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.140 = select i1 %local.is.active.138, i32 %local.sum.extent.139, i32 0
  %stack.offset.141 = add i32 %stack.offset.137, %local.sum.selected.140
  %stack.offset.142 = add i32 %stack.offset.141, 0
  %stack.offset.143 = add i32 %context.value.30, %stack.offset.142
  %cursor.status.144 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.143)
  %cursor.ok.145 = icmp eq i32 %cursor.status.144, 0
  br i1 %cursor.ok.145, label %cursor.continue.146, label %frame.failure.0
cursor.continue.146:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 117)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %local.source.offset.150 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.151 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.152 = load i32, ptr %local.payload.6, align 4
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %stack.offset.155 = add i32 %context.value.154, %local.source.extent.151
  %reserve.status.156 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.155, i32 118)
  %reserve.ok.157 = icmp eq i32 %reserve.status.156, 0
  br i1 %reserve.ok.157, label %reserve.continue.158, label %frame.failure.0
reserve.continue.158:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.154, i32 %local.source.offset.150, i32 %local.source.extent.151, i32 %local.source.payload.152, i32 8)
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %runtime.ok.161 = icmp eq i32 %context.value.160, 0
  br i1 %runtime.ok.161, label %runtime.continue.162, label %frame.failure.0
runtime.continue.162:
  %local.is.active.163 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.164 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.165 = select i1 %local.is.active.163, i32 %local.sum.extent.164, i32 0
  %stack.offset.166 = add i32 0, %local.sum.selected.165
  %local.is.active.167 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.168 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.169 = select i1 %local.is.active.167, i32 %local.sum.extent.168, i32 0
  %stack.offset.170 = add i32 %stack.offset.166, %local.sum.selected.169
  %local.is.active.171 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.172 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.173 = select i1 %local.is.active.171, i32 %local.sum.extent.172, i32 0
  %stack.offset.174 = add i32 %stack.offset.170, %local.sum.selected.173
  %stack.offset.175 = add i32 0, %local.source.extent.151
  %stack.offset.176 = add i32 %stack.offset.174, %stack.offset.175
  %stack.offset.177 = add i32 %context.value.30, %stack.offset.176
  %cursor.status.178 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.177)
  %cursor.ok.179 = icmp eq i32 %cursor.status.178, 0
  br i1 %cursor.ok.179, label %cursor.continue.180, label %frame.failure.0
cursor.continue.180:
  %step.status.181 = call i32 @al_owning_charge_step(ptr %ctx, i32 119)
  %helper.ok.182 = icmp eq i32 %step.status.181, 0
  br i1 %helper.ok.182, label %helper.continue.183, label %frame.failure.0
helper.continue.183:
  %local.is.active.184 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.185 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.186 = select i1 %local.is.active.184, i32 %local.sum.extent.185, i32 0
  %stack.offset.187 = add i32 0, %local.sum.selected.186
  %local.is.active.188 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.189 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.190 = select i1 %local.is.active.188, i32 %local.sum.extent.189, i32 0
  %stack.offset.191 = add i32 %stack.offset.187, %local.sum.selected.190
  %local.is.active.192 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.193 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.194 = select i1 %local.is.active.192, i32 %local.sum.extent.193, i32 0
  %stack.offset.195 = add i32 %stack.offset.191, %local.sum.selected.194
  %stack.offset.196 = add i32 %stack.offset.195, 0
  %stack.offset.197 = add i32 %context.value.30, %stack.offset.196
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %stack.offset.201 = add i32 0, %local.source.extent.151
  %callee.status.200 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.197, i32 %stack.offset.201, i32 120)
  %helper.ok.202 = icmp eq i32 %callee.status.200, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %value.size.206 = alloca %AlOwningValueSize, align 4
  %measure.status.207 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %context.value.199, i32 %context.value.205, i32 121, ptr %value.size.206)
  %helper.ok.208 = icmp eq i32 %measure.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %value.payload.pointer.210 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.206, i32 0, i32 0
  %value.extent.pointer.211 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.206, i32 0, i32 1
  %value.payload.212 = load i32, ptr %value.payload.pointer.210, align 4
  %value.extent.213 = load i32, ptr %value.extent.pointer.211, align 4
  %stack.offset.214 = add i32 %context.value.199, %value.extent.213
  %stack.offset.215 = add i32 0, %value.payload.212
  %callee.outputs.exact.216 = icmp eq i32 %stack.offset.214, %context.value.205
  br i1 %callee.outputs.exact.216, label %callee.outputs.continue.217, label %frame.failure.0
callee.outputs.continue.217:
  %stack.sub.218 = sub i32 %context.value.205, %context.value.199
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.197, i32 %context.value.199, i32 %stack.sub.218, i32 %stack.offset.215, i32 0, i32 9)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  %stack.offset.223 = add i32 %stack.offset.197, %stack.sub.218
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.223, i32 0, i32 0, i32 0)
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %runtime.ok.226 = icmp eq i32 %context.value.225, 0
  br i1 %runtime.ok.226, label %runtime.continue.227, label %frame.failure.0
runtime.continue.227:
  %local.is.active.228 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.229 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.230 = select i1 %local.is.active.228, i32 %local.sum.extent.229, i32 0
  %stack.offset.231 = add i32 0, %local.sum.selected.230
  %local.is.active.232 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.233 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.234 = select i1 %local.is.active.232, i32 %local.sum.extent.233, i32 0
  %stack.offset.235 = add i32 %stack.offset.231, %local.sum.selected.234
  %local.is.active.236 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.237 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.238 = select i1 %local.is.active.236, i32 %local.sum.extent.237, i32 0
  %stack.offset.239 = add i32 %stack.offset.235, %local.sum.selected.238
  %stack.offset.240 = add i32 0, %value.extent.213
  %stack.offset.241 = add i32 %stack.offset.239, %stack.offset.240
  %stack.offset.242 = add i32 %context.value.30, %stack.offset.241
  %cursor.status.243 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.242)
  %cursor.ok.244 = icmp eq i32 %cursor.status.243, 0
  br i1 %cursor.ok.244, label %cursor.continue.245, label %frame.failure.0
cursor.continue.245:
  %step.status.246 = call i32 @al_owning_charge_step(ptr %ctx, i32 122)
  %helper.ok.247 = icmp eq i32 %step.status.246, 0
  br i1 %helper.ok.247, label %helper.continue.248, label %frame.failure.0
helper.continue.248:
  %local.is.active.249 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.250 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.251 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.252 = select i1 %local.is.active.249, i32 %local.previous.extent.250, i32 0
  %local.old.payload.253 = select i1 %local.is.active.249, i32 %local.previous.payload.251, i32 0
  %local.is.active.254 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.255 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.256 = select i1 %local.is.active.254, i32 %local.sum.extent.255, i32 0
  %stack.offset.257 = add i32 0, %local.sum.selected.256
  %stack.offset.258 = add i32 %context.value.30, %stack.offset.257
  %stack.offset.259 = add i32 %stack.offset.258, %local.old.extent.252
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %stack.sub.262 = sub i32 %context.value.261, %stack.offset.259
  %stack.sub.263 = sub i32 %context.value.261, %local.old.extent.252
  %stack.offset.264 = add i32 %stack.sub.263, %value.extent.213
  %local.grows.265 = icmp ugt i32 %value.extent.213, %local.old.extent.252
  br i1 %local.grows.265, label %local.grow.266, label %local.fixed.267
local.grow.266:
  %reserve.status.269 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.264, i32 123)
  %reserve.ok.270 = icmp eq i32 %reserve.status.269, 0
  br i1 %reserve.ok.270, label %reserve.continue.271, label %frame.failure.0
reserve.continue.271:
  %stack.sub.272 = sub i32 %value.extent.213, %local.old.extent.252
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.272)
  %context.field.273 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.274 = load i32, ptr %context.field.273, align 4
  %runtime.ok.275 = icmp eq i32 %context.value.274, 0
  br i1 %runtime.ok.275, label %runtime.continue.276, label %frame.failure.0
runtime.continue.276:
  br label %local.layout.ready.268
local.fixed.267:
  br label %local.layout.ready.268
local.layout.ready.268:
  %stack.offset.277 = add i32 %stack.offset.258, %value.extent.213
  %local.is.active.278 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.279 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.280 = select i1 %local.is.active.278, i32 %local.suffix.payload.279, i32 0
  %stack.offset.281 = add i32 0, %local.suffix.selected.280
  %stack.offset.282 = add i32 0, %value.payload.212
  %stack.offset.283 = add i32 %stack.offset.281, %stack.offset.282
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.277, i32 %stack.offset.259, i32 %stack.sub.262, i32 %stack.offset.283, i32 0, i32 14)
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %runtime.ok.286 = icmp eq i32 %context.value.285, 0
  br i1 %runtime.ok.286, label %runtime.continue.287, label %frame.failure.0
runtime.continue.287:
  %stack.sub.288 = sub i32 %context.value.261, %value.extent.213
  %stack.sub.289 = sub i32 %stack.sub.288, %local.old.extent.252
  %stack.offset.290 = add i32 %stack.sub.289, %value.extent.213
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.258, i32 %stack.offset.290, i32 %value.extent.213, i32 %value.payload.212, i32 8, i32 4)
  %context.field.291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.292 = load i32, ptr %context.field.291, align 4
  %runtime.ok.293 = icmp eq i32 %context.value.292, 0
  br i1 %runtime.ok.293, label %runtime.continue.294, label %frame.failure.0
runtime.continue.294:
  %stack.sub.295 = sub i32 %context.value.261, %local.old.extent.252
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.295, i32 0, i32 0, i32 0)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %runtime.ok.298 = icmp eq i32 %context.value.297, 0
  br i1 %runtime.ok.298, label %runtime.continue.299, label %frame.failure.0
runtime.continue.299:
  %local.shrinks.300 = icmp ult i32 %value.extent.213, %local.old.extent.252
  br i1 %local.shrinks.300, label %local.shrink.301, label %local.counts.ready.302
local.shrink.301:
  %stack.sub.303 = sub i32 %local.old.extent.252, %value.extent.213
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.303)
  %context.field.304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.305 = load i32, ptr %context.field.304, align 4
  %runtime.ok.306 = icmp eq i32 %context.value.305, 0
  br i1 %runtime.ok.306, label %runtime.continue.307, label %frame.failure.0
runtime.continue.307:
  br label %local.counts.ready.302
local.counts.ready.302:
  %local.payload.delta.308 = sub i32 %value.payload.212, %local.old.payload.253
  %stack.sub.309 = sub i32 0, %local.old.payload.253
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.309, i32 %local.payload.delta.308)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %frame.failure.0
runtime.continue.313:
  %local.is.active.314 = load i1, ptr %local.active.13, align 1
  %local.later.offset.315 = load i32, ptr %local.offset.14, align 4
  %stack.sub.316 = sub i32 %local.later.offset.315, %local.old.extent.252
  %stack.offset.317 = add i32 %stack.sub.316, %value.extent.213
  %local.later.offset.selected.318 = select i1 %local.is.active.314, i32 %stack.offset.317, i32 %local.later.offset.315
  store i32 %local.later.offset.selected.318, ptr %local.offset.14, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.258, ptr %local.offset.9, align 4
  store i32 %value.extent.213, ptr %local.extent.10, align 4
  store i32 %value.payload.212, ptr %local.payload.11, align 4
  store i32 8, ptr %local.type.12, align 4
  %local.is.active.319 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.320 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.321 = select i1 %local.is.active.319, i32 %local.sum.extent.320, i32 0
  %stack.offset.322 = add i32 0, %local.sum.selected.321
  %local.is.active.323 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.324 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.325 = select i1 %local.is.active.323, i32 %local.sum.extent.324, i32 0
  %stack.offset.326 = add i32 %stack.offset.322, %local.sum.selected.325
  %local.is.active.327 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.328 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.329 = select i1 %local.is.active.327, i32 %local.sum.extent.328, i32 0
  %stack.offset.330 = add i32 %stack.offset.326, %local.sum.selected.329
  %stack.offset.331 = add i32 %stack.offset.330, 0
  %stack.offset.332 = add i32 %context.value.30, %stack.offset.331
  %cursor.status.333 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.332)
  %cursor.ok.334 = icmp eq i32 %cursor.status.333, 0
  br i1 %cursor.ok.334, label %cursor.continue.335, label %frame.failure.0
cursor.continue.335:
  %step.status.336 = call i32 @al_owning_charge_step(ptr %ctx, i32 124)
  %helper.ok.337 = icmp eq i32 %step.status.336, 0
  br i1 %helper.ok.337, label %helper.continue.338, label %frame.failure.0
helper.continue.338:
  %local.source.offset.339 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.340 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.341 = load i32, ptr %local.payload.11, align 4
  %context.field.342 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.343 = load i32, ptr %context.field.342, align 4
  %stack.offset.344 = add i32 %context.value.343, %local.source.extent.340
  %reserve.status.345 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.344, i32 125)
  %reserve.ok.346 = icmp eq i32 %reserve.status.345, 0
  br i1 %reserve.ok.346, label %reserve.continue.347, label %frame.failure.0
reserve.continue.347:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.343, i32 %local.source.offset.339, i32 %local.source.extent.340, i32 %local.source.payload.341, i32 8)
  %context.field.348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.349 = load i32, ptr %context.field.348, align 4
  %runtime.ok.350 = icmp eq i32 %context.value.349, 0
  br i1 %runtime.ok.350, label %runtime.continue.351, label %frame.failure.0
runtime.continue.351:
  %local.is.active.352 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.353 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.354 = select i1 %local.is.active.352, i32 %local.sum.extent.353, i32 0
  %stack.offset.355 = add i32 0, %local.sum.selected.354
  %local.is.active.356 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.357 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.358 = select i1 %local.is.active.356, i32 %local.sum.extent.357, i32 0
  %stack.offset.359 = add i32 %stack.offset.355, %local.sum.selected.358
  %local.is.active.360 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.361 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.362 = select i1 %local.is.active.360, i32 %local.sum.extent.361, i32 0
  %stack.offset.363 = add i32 %stack.offset.359, %local.sum.selected.362
  %stack.offset.364 = add i32 0, %local.source.extent.340
  %stack.offset.365 = add i32 %stack.offset.363, %stack.offset.364
  %stack.offset.366 = add i32 %context.value.30, %stack.offset.365
  %cursor.status.367 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.366)
  %cursor.ok.368 = icmp eq i32 %cursor.status.367, 0
  br i1 %cursor.ok.368, label %cursor.continue.369, label %frame.failure.0
cursor.continue.369:
  %step.status.370 = call i32 @al_owning_charge_step(ptr %ctx, i32 126)
  %helper.ok.371 = icmp eq i32 %step.status.370, 0
  br i1 %helper.ok.371, label %helper.continue.372, label %frame.failure.0
helper.continue.372:
  %local.is.active.373 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.374 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.375 = select i1 %local.is.active.373, i32 %local.sum.extent.374, i32 0
  %stack.offset.376 = add i32 0, %local.sum.selected.375
  %local.is.active.377 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.378 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.379 = select i1 %local.is.active.377, i32 %local.sum.extent.378, i32 0
  %stack.offset.380 = add i32 %stack.offset.376, %local.sum.selected.379
  %local.is.active.381 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.382 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.383 = select i1 %local.is.active.381, i32 %local.sum.extent.382, i32 0
  %stack.offset.384 = add i32 %stack.offset.380, %local.sum.selected.383
  %stack.offset.385 = add i32 %stack.offset.384, 0
  %stack.offset.386 = add i32 %context.value.30, %stack.offset.385
  %field.location.387 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.388 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.386, i32 %local.source.extent.340, i32 0, i32 127, ptr %field.location.387)
  %helper.ok.389 = icmp eq i32 %field.location.status.388, 0
  br i1 %helper.ok.389, label %helper.continue.390, label %frame.failure.0
helper.continue.390:
  %field.offset.pointer.391 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.387, i32 0, i32 0
  %field.offset.392 = load i32, ptr %field.offset.pointer.391, align 4
  %field.payload.pointer.393 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.387, i32 0, i32 1
  %field.payload.394 = load i32, ptr %field.payload.pointer.393, align 4
  %field.extent.pointer.395 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.387, i32 0, i32 2
  %field.extent.396 = load i32, ptr %field.extent.pointer.395, align 4
  %stack.offset.397 = add i32 %stack.offset.386, %field.extent.396
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %field.result.grows.400 = icmp ugt i32 %stack.offset.397, %context.value.399
  br i1 %field.result.grows.400, label %field.result.reserve.401, label %field.result.existing.402
field.result.reserve.401:
  %reserve.status.404 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.397, i32 128)
  %reserve.ok.405 = icmp eq i32 %reserve.status.404, 0
  br i1 %reserve.ok.405, label %reserve.continue.406, label %frame.failure.0
reserve.continue.406:
  br label %field.result.ready.403
field.result.existing.402:
  br label %field.result.ready.403
field.result.ready.403:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.386, i32 %field.offset.392, i32 %field.extent.396, i32 %field.payload.394, i32 9, i32 7)
  %context.field.407 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.408 = load i32, ptr %context.field.407, align 4
  %runtime.ok.409 = icmp eq i32 %context.value.408, 0
  br i1 %runtime.ok.409, label %runtime.continue.410, label %frame.failure.0
runtime.continue.410:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.397, i32 0, i32 0, i32 0)
  %context.field.411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.412 = load i32, ptr %context.field.411, align 4
  %runtime.ok.413 = icmp eq i32 %context.value.412, 0
  br i1 %runtime.ok.413, label %runtime.continue.414, label %frame.failure.0
runtime.continue.414:
  %stack.sub.415 = sub i32 %field.payload.394, %local.source.payload.341
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.415, i32 0)
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %runtime.ok.418 = icmp eq i32 %context.value.417, 0
  br i1 %runtime.ok.418, label %runtime.continue.419, label %frame.failure.0
runtime.continue.419:
  %local.is.active.420 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.421 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.422 = select i1 %local.is.active.420, i32 %local.sum.extent.421, i32 0
  %stack.offset.423 = add i32 0, %local.sum.selected.422
  %local.is.active.424 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.425 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.426 = select i1 %local.is.active.424, i32 %local.sum.extent.425, i32 0
  %stack.offset.427 = add i32 %stack.offset.423, %local.sum.selected.426
  %local.is.active.428 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.429 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.430 = select i1 %local.is.active.428, i32 %local.sum.extent.429, i32 0
  %stack.offset.431 = add i32 %stack.offset.427, %local.sum.selected.430
  %stack.offset.432 = add i32 0, %field.extent.396
  %stack.offset.433 = add i32 %stack.offset.431, %stack.offset.432
  %stack.offset.434 = add i32 %context.value.30, %stack.offset.433
  %cursor.status.435 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.434)
  %cursor.ok.436 = icmp eq i32 %cursor.status.435, 0
  br i1 %cursor.ok.436, label %cursor.continue.437, label %frame.failure.0
cursor.continue.437:
  %step.status.438 = call i32 @al_owning_charge_step(ptr %ctx, i32 129)
  %helper.ok.439 = icmp eq i32 %step.status.438, 0
  br i1 %helper.ok.439, label %helper.continue.440, label %frame.failure.0
helper.continue.440:
  %local.is.active.441 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.442 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.443 = select i1 %local.is.active.441, i32 %local.sum.extent.442, i32 0
  %stack.offset.444 = add i32 0, %local.sum.selected.443
  %local.is.active.445 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.446 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.447 = select i1 %local.is.active.445, i32 %local.sum.extent.446, i32 0
  %stack.offset.448 = add i32 %stack.offset.444, %local.sum.selected.447
  %local.is.active.449 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.450 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.451 = select i1 %local.is.active.449, i32 %local.sum.extent.450, i32 0
  %stack.offset.452 = add i32 %stack.offset.448, %local.sum.selected.451
  %stack.offset.453 = add i32 %stack.offset.452, 0
  %stack.offset.454 = add i32 %context.value.30, %stack.offset.453
  %field.location.455 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.456 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %stack.offset.454, i32 %field.extent.396, i32 0, i32 130, ptr %field.location.455)
  %helper.ok.457 = icmp eq i32 %field.location.status.456, 0
  br i1 %helper.ok.457, label %helper.continue.458, label %frame.failure.0
helper.continue.458:
  %field.offset.pointer.459 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.455, i32 0, i32 0
  %field.offset.460 = load i32, ptr %field.offset.pointer.459, align 4
  %field.payload.pointer.461 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.455, i32 0, i32 1
  %field.payload.462 = load i32, ptr %field.payload.pointer.461, align 4
  %field.extent.pointer.463 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.455, i32 0, i32 2
  %field.extent.464 = load i32, ptr %field.extent.pointer.463, align 4
  %stack.offset.465 = add i32 %stack.offset.454, %field.extent.464
  %context.field.466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.467 = load i32, ptr %context.field.466, align 4
  %field.result.grows.468 = icmp ugt i32 %stack.offset.465, %context.value.467
  br i1 %field.result.grows.468, label %field.result.reserve.469, label %field.result.existing.470
field.result.reserve.469:
  %reserve.status.472 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.465, i32 131)
  %reserve.ok.473 = icmp eq i32 %reserve.status.472, 0
  br i1 %reserve.ok.473, label %reserve.continue.474, label %frame.failure.0
reserve.continue.474:
  br label %field.result.ready.471
field.result.existing.470:
  br label %field.result.ready.471
field.result.ready.471:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.454, i32 %field.offset.460, i32 %field.extent.464, i32 %field.payload.462, i32 12, i32 7)
  %context.field.475 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.476 = load i32, ptr %context.field.475, align 4
  %runtime.ok.477 = icmp eq i32 %context.value.476, 0
  br i1 %runtime.ok.477, label %runtime.continue.478, label %frame.failure.0
runtime.continue.478:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.465, i32 0, i32 0, i32 0)
  %context.field.479 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.480 = load i32, ptr %context.field.479, align 4
  %runtime.ok.481 = icmp eq i32 %context.value.480, 0
  br i1 %runtime.ok.481, label %runtime.continue.482, label %frame.failure.0
runtime.continue.482:
  %stack.sub.483 = sub i32 %field.payload.462, %field.payload.394
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.483, i32 0)
  %context.field.484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.485 = load i32, ptr %context.field.484, align 4
  %runtime.ok.486 = icmp eq i32 %context.value.485, 0
  br i1 %runtime.ok.486, label %runtime.continue.487, label %frame.failure.0
runtime.continue.487:
  %local.is.active.488 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.489 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.490 = select i1 %local.is.active.488, i32 %local.sum.extent.489, i32 0
  %stack.offset.491 = add i32 0, %local.sum.selected.490
  %local.is.active.492 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.493 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.494 = select i1 %local.is.active.492, i32 %local.sum.extent.493, i32 0
  %stack.offset.495 = add i32 %stack.offset.491, %local.sum.selected.494
  %local.is.active.496 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.497 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.498 = select i1 %local.is.active.496, i32 %local.sum.extent.497, i32 0
  %stack.offset.499 = add i32 %stack.offset.495, %local.sum.selected.498
  %stack.offset.500 = add i32 0, %field.extent.464
  %stack.offset.501 = add i32 %stack.offset.499, %stack.offset.500
  %stack.offset.502 = add i32 %context.value.30, %stack.offset.501
  %cursor.status.503 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.502)
  %cursor.ok.504 = icmp eq i32 %cursor.status.503, 0
  br i1 %cursor.ok.504, label %cursor.continue.505, label %frame.failure.0
cursor.continue.505:
  %step.status.506 = call i32 @al_owning_charge_step(ptr %ctx, i32 132)
  %helper.ok.507 = icmp eq i32 %step.status.506, 0
  br i1 %helper.ok.507, label %helper.continue.508, label %frame.failure.0
helper.continue.508:
  %local.is.active.509 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.510 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.511 = select i1 %local.is.active.509, i32 %local.sum.extent.510, i32 0
  %stack.offset.512 = add i32 0, %local.sum.selected.511
  %local.is.active.513 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.514 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.515 = select i1 %local.is.active.513, i32 %local.sum.extent.514, i32 0
  %stack.offset.516 = add i32 %stack.offset.512, %local.sum.selected.515
  %local.is.active.517 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.518 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.519 = select i1 %local.is.active.517, i32 %local.sum.extent.518, i32 0
  %stack.offset.520 = add i32 %stack.offset.516, %local.sum.selected.519
  %stack.offset.521 = add i32 %stack.offset.520, 0
  %stack.offset.522 = add i32 %context.value.30, %stack.offset.521
  %string.length.units.523 = alloca i32, align 4
  %string.length.status.524 = call i32 @al_owning_string_length(ptr %ctx, i32 %stack.offset.522, i32 %field.extent.464, i32 133, ptr %string.length.units.523)
  %helper.ok.525 = icmp eq i32 %string.length.status.524, 0
  br i1 %helper.ok.525, label %helper.continue.526, label %frame.failure.0
helper.continue.526:
  %string.length.value.527 = load i32, ptr %string.length.units.523, align 4
  %string.length.int.528 = zext i32 %string.length.value.527 to i64
  %context.field.529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.530 = load i32, ptr %context.field.529, align 4
  %stack.sub.531 = sub i32 %context.value.530, %field.extent.464
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.531, i32 %field.extent.464, i32 %field.payload.462, i32 12)
  %context.field.532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.533 = load i32, ptr %context.field.532, align 4
  %runtime.ok.534 = icmp eq i32 %context.value.533, 0
  br i1 %runtime.ok.534, label %runtime.continue.535, label %frame.failure.0
runtime.continue.535:
  %context.field.536 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.537 = load i32, ptr %context.field.536, align 4
  %stack.offset.538 = add i32 %context.value.537, 8
  %reserve.status.539 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.538, i32 134)
  %reserve.ok.540 = icmp eq i32 %reserve.status.539, 0
  br i1 %reserve.ok.540, label %reserve.continue.541, label %frame.failure.0
reserve.continue.541:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.537, i64 %string.length.int.528, i32 1)
  %context.field.542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.543 = load i32, ptr %context.field.542, align 4
  %runtime.ok.544 = icmp eq i32 %context.value.543, 0
  br i1 %runtime.ok.544, label %runtime.continue.545, label %frame.failure.0
runtime.continue.545:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.546 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.547 = load i32, ptr %context.field.546, align 4
  %runtime.ok.548 = icmp eq i32 %context.value.547, 0
  br i1 %runtime.ok.548, label %runtime.continue.549, label %frame.failure.0
runtime.continue.549:
  %local.is.active.550 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.551 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.552 = select i1 %local.is.active.550, i32 %local.sum.extent.551, i32 0
  %stack.offset.553 = add i32 0, %local.sum.selected.552
  %local.is.active.554 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.555 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.556 = select i1 %local.is.active.554, i32 %local.sum.extent.555, i32 0
  %stack.offset.557 = add i32 %stack.offset.553, %local.sum.selected.556
  %local.is.active.558 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.559 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.560 = select i1 %local.is.active.558, i32 %local.sum.extent.559, i32 0
  %stack.offset.561 = add i32 %stack.offset.557, %local.sum.selected.560
  %stack.offset.562 = add i32 0, 8
  %stack.offset.563 = add i32 %stack.offset.561, %stack.offset.562
  %stack.offset.564 = add i32 %context.value.30, %stack.offset.563
  %cursor.status.565 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.564)
  %cursor.ok.566 = icmp eq i32 %cursor.status.565, 0
  br i1 %cursor.ok.566, label %cursor.continue.567, label %frame.failure.0
cursor.continue.567:
  %step.status.568 = call i32 @al_owning_charge_step(ptr %ctx, i32 135)
  %helper.ok.569 = icmp eq i32 %step.status.568, 0
  br i1 %helper.ok.569, label %helper.continue.570, label %frame.failure.0
helper.continue.570:
  %local.is.active.571 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.572 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.573 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.574 = select i1 %local.is.active.571, i32 %local.previous.extent.572, i32 0
  %local.old.payload.575 = select i1 %local.is.active.571, i32 %local.previous.payload.573, i32 0
  %local.is.active.576 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.577 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.578 = select i1 %local.is.active.576, i32 %local.sum.extent.577, i32 0
  %stack.offset.579 = add i32 0, %local.sum.selected.578
  %local.is.active.580 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.581 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.582 = select i1 %local.is.active.580, i32 %local.sum.extent.581, i32 0
  %stack.offset.583 = add i32 %stack.offset.579, %local.sum.selected.582
  %stack.offset.584 = add i32 %context.value.30, %stack.offset.583
  %stack.offset.585 = add i32 %stack.offset.584, %local.old.extent.574
  %context.field.586 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.587 = load i32, ptr %context.field.586, align 4
  %stack.sub.588 = sub i32 %context.value.587, %stack.offset.585
  %stack.sub.589 = sub i32 %context.value.587, %local.old.extent.574
  %stack.offset.590 = add i32 %stack.sub.589, 8
  %local.grows.591 = icmp ugt i32 8, %local.old.extent.574
  br i1 %local.grows.591, label %local.grow.592, label %local.fixed.593
local.grow.592:
  %reserve.status.595 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.590, i32 136)
  %reserve.ok.596 = icmp eq i32 %reserve.status.595, 0
  br i1 %reserve.ok.596, label %reserve.continue.597, label %frame.failure.0
reserve.continue.597:
  %stack.sub.598 = sub i32 8, %local.old.extent.574
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.598)
  %context.field.599 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.600 = load i32, ptr %context.field.599, align 4
  %runtime.ok.601 = icmp eq i32 %context.value.600, 0
  br i1 %runtime.ok.601, label %runtime.continue.602, label %frame.failure.0
runtime.continue.602:
  br label %local.layout.ready.594
local.fixed.593:
  br label %local.layout.ready.594
local.layout.ready.594:
  %stack.offset.603 = add i32 %stack.offset.584, 8
  %stack.offset.604 = add i32 0, 8
  %stack.offset.605 = add i32 0, %stack.offset.604
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.603, i32 %stack.offset.585, i32 %stack.sub.588, i32 %stack.offset.605, i32 0, i32 14)
  %context.field.606 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.607 = load i32, ptr %context.field.606, align 4
  %runtime.ok.608 = icmp eq i32 %context.value.607, 0
  br i1 %runtime.ok.608, label %runtime.continue.609, label %frame.failure.0
runtime.continue.609:
  %stack.sub.610 = sub i32 %context.value.587, 8
  %stack.sub.611 = sub i32 %stack.sub.610, %local.old.extent.574
  %stack.offset.612 = add i32 %stack.sub.611, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.584, i32 %stack.offset.612, i32 8, i32 8, i32 1, i32 4)
  %context.field.613 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.614 = load i32, ptr %context.field.613, align 4
  %runtime.ok.615 = icmp eq i32 %context.value.614, 0
  br i1 %runtime.ok.615, label %runtime.continue.616, label %frame.failure.0
runtime.continue.616:
  %stack.sub.617 = sub i32 %context.value.587, %local.old.extent.574
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.617, i32 0, i32 0, i32 0)
  %context.field.618 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.619 = load i32, ptr %context.field.618, align 4
  %runtime.ok.620 = icmp eq i32 %context.value.619, 0
  br i1 %runtime.ok.620, label %runtime.continue.621, label %frame.failure.0
runtime.continue.621:
  %local.shrinks.622 = icmp ult i32 8, %local.old.extent.574
  br i1 %local.shrinks.622, label %local.shrink.623, label %local.counts.ready.624
local.shrink.623:
  %stack.sub.625 = sub i32 %local.old.extent.574, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.625)
  %context.field.626 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.627 = load i32, ptr %context.field.626, align 4
  %runtime.ok.628 = icmp eq i32 %context.value.627, 0
  br i1 %runtime.ok.628, label %runtime.continue.629, label %frame.failure.0
runtime.continue.629:
  br label %local.counts.ready.624
local.counts.ready.624:
  %local.payload.delta.630 = sub i32 8, %local.old.payload.575
  %stack.sub.631 = sub i32 0, %local.old.payload.575
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.631, i32 %local.payload.delta.630)
  %context.field.632 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.633 = load i32, ptr %context.field.632, align 4
  %runtime.ok.634 = icmp eq i32 %context.value.633, 0
  br i1 %runtime.ok.634, label %runtime.continue.635, label %frame.failure.0
runtime.continue.635:
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.584, ptr %local.offset.14, align 4
  store i32 8, ptr %local.extent.15, align 4
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  %local.is.active.636 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.637 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.638 = select i1 %local.is.active.636, i32 %local.sum.extent.637, i32 0
  %stack.offset.639 = add i32 0, %local.sum.selected.638
  %local.is.active.640 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.641 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.642 = select i1 %local.is.active.640, i32 %local.sum.extent.641, i32 0
  %stack.offset.643 = add i32 %stack.offset.639, %local.sum.selected.642
  %local.is.active.644 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.645 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.646 = select i1 %local.is.active.644, i32 %local.sum.extent.645, i32 0
  %stack.offset.647 = add i32 %stack.offset.643, %local.sum.selected.646
  %stack.offset.648 = add i32 %stack.offset.647, 0
  %stack.offset.649 = add i32 %context.value.30, %stack.offset.648
  %cursor.status.650 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.649)
  %cursor.ok.651 = icmp eq i32 %cursor.status.650, 0
  br i1 %cursor.ok.651, label %cursor.continue.652, label %frame.failure.0
cursor.continue.652:
  %step.status.653 = call i32 @al_owning_charge_step(ptr %ctx, i32 137)
  %helper.ok.654 = icmp eq i32 %step.status.653, 0
  br i1 %helper.ok.654, label %helper.continue.655, label %frame.failure.0
helper.continue.655:
  %local.source.offset.656 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.657 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.658 = load i32, ptr %local.payload.11, align 4
  %context.field.659 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.660 = load i32, ptr %context.field.659, align 4
  %stack.offset.661 = add i32 %context.value.660, %local.source.extent.657
  %reserve.status.662 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.661, i32 138)
  %reserve.ok.663 = icmp eq i32 %reserve.status.662, 0
  br i1 %reserve.ok.663, label %reserve.continue.664, label %frame.failure.0
reserve.continue.664:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.660, i32 %local.source.offset.656, i32 %local.source.extent.657, i32 %local.source.payload.658, i32 8)
  %context.field.665 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.666 = load i32, ptr %context.field.665, align 4
  %runtime.ok.667 = icmp eq i32 %context.value.666, 0
  br i1 %runtime.ok.667, label %runtime.continue.668, label %frame.failure.0
runtime.continue.668:
  %local.is.active.669 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.670 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.671 = select i1 %local.is.active.669, i32 %local.sum.extent.670, i32 0
  %stack.offset.672 = add i32 0, %local.sum.selected.671
  %local.is.active.673 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.674 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.675 = select i1 %local.is.active.673, i32 %local.sum.extent.674, i32 0
  %stack.offset.676 = add i32 %stack.offset.672, %local.sum.selected.675
  %local.is.active.677 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.678 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.679 = select i1 %local.is.active.677, i32 %local.sum.extent.678, i32 0
  %stack.offset.680 = add i32 %stack.offset.676, %local.sum.selected.679
  %stack.offset.681 = add i32 0, %local.source.extent.657
  %stack.offset.682 = add i32 %stack.offset.680, %stack.offset.681
  %stack.offset.683 = add i32 %context.value.30, %stack.offset.682
  %cursor.status.684 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.683)
  %cursor.ok.685 = icmp eq i32 %cursor.status.684, 0
  br i1 %cursor.ok.685, label %cursor.continue.686, label %frame.failure.0
cursor.continue.686:
  %step.status.687 = call i32 @al_owning_charge_step(ptr %ctx, i32 139)
  %helper.ok.688 = icmp eq i32 %step.status.687, 0
  br i1 %helper.ok.688, label %helper.continue.689, label %frame.failure.0
helper.continue.689:
  %local.source.offset.690 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.691 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.692 = load i32, ptr %local.payload.16, align 4
  %context.field.693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.694 = load i32, ptr %context.field.693, align 4
  %stack.offset.695 = add i32 %context.value.694, %local.source.extent.691
  %reserve.status.696 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.695, i32 140)
  %reserve.ok.697 = icmp eq i32 %reserve.status.696, 0
  br i1 %reserve.ok.697, label %reserve.continue.698, label %frame.failure.0
reserve.continue.698:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.694, i32 %local.source.offset.690, i32 %local.source.extent.691, i32 %local.source.payload.692, i32 1)
  %context.field.699 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.700 = load i32, ptr %context.field.699, align 4
  %runtime.ok.701 = icmp eq i32 %context.value.700, 0
  br i1 %runtime.ok.701, label %runtime.continue.702, label %frame.failure.0
runtime.continue.702:
  %local.is.active.703 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.704 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.705 = select i1 %local.is.active.703, i32 %local.sum.extent.704, i32 0
  %stack.offset.706 = add i32 0, %local.sum.selected.705
  %local.is.active.707 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.708 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.709 = select i1 %local.is.active.707, i32 %local.sum.extent.708, i32 0
  %stack.offset.710 = add i32 %stack.offset.706, %local.sum.selected.709
  %local.is.active.711 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.712 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.713 = select i1 %local.is.active.711, i32 %local.sum.extent.712, i32 0
  %stack.offset.714 = add i32 %stack.offset.710, %local.sum.selected.713
  %stack.offset.715 = add i32 0, %local.source.extent.657
  %stack.offset.716 = add i32 %stack.offset.715, %local.source.extent.691
  %stack.offset.717 = add i32 %stack.offset.714, %stack.offset.716
  %stack.offset.718 = add i32 %context.value.30, %stack.offset.717
  %cursor.status.719 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.718)
  %cursor.ok.720 = icmp eq i32 %cursor.status.719, 0
  br i1 %cursor.ok.720, label %cursor.continue.721, label %frame.failure.0
cursor.continue.721:
  %local.is.active.722 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.722, label %local.remove.723, label %local.keep.724
local.keep.724:
  br label %local.removed.725
local.remove.723:
  %local.remove.offset.726 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.727 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.728 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.729 = load i32, ptr %local.type.17, align 4
  %stack.offset.730 = add i32 %local.remove.offset.726, %local.remove.extent.727
  %context.field.731 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.732 = load i32, ptr %context.field.731, align 4
  %stack.sub.733 = sub i32 %context.value.732, %stack.offset.730
  %stack.offset.734 = add i32 0, %local.source.payload.658
  %stack.offset.735 = add i32 %stack.offset.734, %local.source.payload.692
  %stack.offset.736 = add i32 0, %stack.offset.735
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.726, i32 %stack.offset.730, i32 %stack.sub.733, i32 %stack.offset.736, i32 0, i32 14)
  %context.field.737 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.738 = load i32, ptr %context.field.737, align 4
  %runtime.ok.739 = icmp eq i32 %context.value.738, 0
  br i1 %runtime.ok.739, label %runtime.continue.740, label %frame.failure.0
runtime.continue.740:
  %stack.sub.741 = sub i32 %context.value.732, %local.remove.extent.727
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.741, i32 0, i32 0, i32 0)
  %context.field.742 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.743 = load i32, ptr %context.field.742, align 4
  %runtime.ok.744 = icmp eq i32 %context.value.743, 0
  br i1 %runtime.ok.744, label %runtime.continue.745, label %frame.failure.0
runtime.continue.745:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.729, i32 %local.remove.offset.726, i32 %local.remove.extent.727, i32 %local.remove.payload.728, i32 0, i32 0)
  %context.field.746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.747 = load i32, ptr %context.field.746, align 4
  %runtime.ok.748 = icmp eq i32 %context.value.747, 0
  br i1 %runtime.ok.748, label %runtime.continue.749, label %frame.failure.0
runtime.continue.749:
  %stack.sub.750 = sub i32 0, %local.remove.payload.728
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.750, i32 %stack.sub.750)
  %context.field.751 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.752 = load i32, ptr %context.field.751, align 4
  %runtime.ok.753 = icmp eq i32 %context.value.752, 0
  br i1 %runtime.ok.753, label %runtime.continue.754, label %frame.failure.0
runtime.continue.754:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.727)
  %context.field.755 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.756 = load i32, ptr %context.field.755, align 4
  %runtime.ok.757 = icmp eq i32 %context.value.756, 0
  br i1 %runtime.ok.757, label %runtime.continue.758, label %frame.failure.0
runtime.continue.758:
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.725
local.removed.725:
  %local.is.active.759 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.759, label %local.remove.760, label %local.keep.761
local.keep.761:
  br label %local.removed.762
local.remove.760:
  %local.remove.offset.763 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.764 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.765 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.766 = load i32, ptr %local.type.12, align 4
  %stack.offset.767 = add i32 %local.remove.offset.763, %local.remove.extent.764
  %context.field.768 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.769 = load i32, ptr %context.field.768, align 4
  %stack.sub.770 = sub i32 %context.value.769, %stack.offset.767
  %local.is.active.771 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.772 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.773 = select i1 %local.is.active.771, i32 %local.suffix.payload.772, i32 0
  %stack.offset.774 = add i32 0, %local.suffix.selected.773
  %stack.offset.775 = add i32 0, %local.source.payload.658
  %stack.offset.776 = add i32 %stack.offset.775, %local.source.payload.692
  %stack.offset.777 = add i32 %stack.offset.774, %stack.offset.776
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.763, i32 %stack.offset.767, i32 %stack.sub.770, i32 %stack.offset.777, i32 0, i32 14)
  %context.field.778 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.779 = load i32, ptr %context.field.778, align 4
  %runtime.ok.780 = icmp eq i32 %context.value.779, 0
  br i1 %runtime.ok.780, label %runtime.continue.781, label %frame.failure.0
runtime.continue.781:
  %stack.sub.782 = sub i32 %context.value.769, %local.remove.extent.764
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.782, i32 0, i32 0, i32 0)
  %context.field.783 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.784 = load i32, ptr %context.field.783, align 4
  %runtime.ok.785 = icmp eq i32 %context.value.784, 0
  br i1 %runtime.ok.785, label %runtime.continue.786, label %frame.failure.0
runtime.continue.786:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.766, i32 %local.remove.offset.763, i32 %local.remove.extent.764, i32 %local.remove.payload.765, i32 0, i32 0)
  %context.field.787 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.788 = load i32, ptr %context.field.787, align 4
  %runtime.ok.789 = icmp eq i32 %context.value.788, 0
  br i1 %runtime.ok.789, label %runtime.continue.790, label %frame.failure.0
runtime.continue.790:
  %stack.sub.791 = sub i32 0, %local.remove.payload.765
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.791, i32 %stack.sub.791)
  %context.field.792 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.793 = load i32, ptr %context.field.792, align 4
  %runtime.ok.794 = icmp eq i32 %context.value.793, 0
  br i1 %runtime.ok.794, label %runtime.continue.795, label %frame.failure.0
runtime.continue.795:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.764)
  %context.field.796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.797 = load i32, ptr %context.field.796, align 4
  %runtime.ok.798 = icmp eq i32 %context.value.797, 0
  br i1 %runtime.ok.798, label %runtime.continue.799, label %frame.failure.0
runtime.continue.799:
  %local.is.active.800 = load i1, ptr %local.active.13, align 1
  %local.later.offset.801 = load i32, ptr %local.offset.14, align 4
  %stack.sub.802 = sub i32 %local.later.offset.801, %local.remove.extent.764
  %local.later.offset.selected.803 = select i1 %local.is.active.800, i32 %stack.sub.802, i32 %local.later.offset.801
  store i32 %local.later.offset.selected.803, ptr %local.offset.14, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.762
local.removed.762:
  %local.is.active.804 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.804, label %local.remove.805, label %local.keep.806
local.keep.806:
  br label %local.removed.807
local.remove.805:
  %local.remove.offset.808 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.809 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.810 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.811 = load i32, ptr %local.type.7, align 4
  %stack.offset.812 = add i32 %local.remove.offset.808, %local.remove.extent.809
  %context.field.813 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.814 = load i32, ptr %context.field.813, align 4
  %stack.sub.815 = sub i32 %context.value.814, %stack.offset.812
  %local.is.active.816 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.817 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.818 = select i1 %local.is.active.816, i32 %local.suffix.payload.817, i32 0
  %stack.offset.819 = add i32 0, %local.suffix.selected.818
  %local.is.active.820 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.821 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.822 = select i1 %local.is.active.820, i32 %local.suffix.payload.821, i32 0
  %stack.offset.823 = add i32 %stack.offset.819, %local.suffix.selected.822
  %stack.offset.824 = add i32 0, %local.source.payload.658
  %stack.offset.825 = add i32 %stack.offset.824, %local.source.payload.692
  %stack.offset.826 = add i32 %stack.offset.823, %stack.offset.825
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.808, i32 %stack.offset.812, i32 %stack.sub.815, i32 %stack.offset.826, i32 0, i32 14)
  %context.field.827 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.828 = load i32, ptr %context.field.827, align 4
  %runtime.ok.829 = icmp eq i32 %context.value.828, 0
  br i1 %runtime.ok.829, label %runtime.continue.830, label %frame.failure.0
runtime.continue.830:
  %stack.sub.831 = sub i32 %context.value.814, %local.remove.extent.809
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.831, i32 0, i32 0, i32 0)
  %context.field.832 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.833 = load i32, ptr %context.field.832, align 4
  %runtime.ok.834 = icmp eq i32 %context.value.833, 0
  br i1 %runtime.ok.834, label %runtime.continue.835, label %frame.failure.0
runtime.continue.835:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.811, i32 %local.remove.offset.808, i32 %local.remove.extent.809, i32 %local.remove.payload.810, i32 0, i32 0)
  %context.field.836 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.837 = load i32, ptr %context.field.836, align 4
  %runtime.ok.838 = icmp eq i32 %context.value.837, 0
  br i1 %runtime.ok.838, label %runtime.continue.839, label %frame.failure.0
runtime.continue.839:
  %stack.sub.840 = sub i32 0, %local.remove.payload.810
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.840, i32 %stack.sub.840)
  %context.field.841 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.842 = load i32, ptr %context.field.841, align 4
  %runtime.ok.843 = icmp eq i32 %context.value.842, 0
  br i1 %runtime.ok.843, label %runtime.continue.844, label %frame.failure.0
runtime.continue.844:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.809)
  %context.field.845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.846 = load i32, ptr %context.field.845, align 4
  %runtime.ok.847 = icmp eq i32 %context.value.846, 0
  br i1 %runtime.ok.847, label %runtime.continue.848, label %frame.failure.0
runtime.continue.848:
  %local.is.active.849 = load i1, ptr %local.active.8, align 1
  %local.later.offset.850 = load i32, ptr %local.offset.9, align 4
  %stack.sub.851 = sub i32 %local.later.offset.850, %local.remove.extent.809
  %local.later.offset.selected.852 = select i1 %local.is.active.849, i32 %stack.sub.851, i32 %local.later.offset.850
  store i32 %local.later.offset.selected.852, ptr %local.offset.9, align 4
  %local.is.active.853 = load i1, ptr %local.active.13, align 1
  %local.later.offset.854 = load i32, ptr %local.offset.14, align 4
  %stack.sub.855 = sub i32 %local.later.offset.854, %local.remove.extent.809
  %local.later.offset.selected.856 = select i1 %local.is.active.853, i32 %stack.sub.855, i32 %local.later.offset.854
  store i32 %local.later.offset.selected.856, ptr %local.offset.14, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.807
local.removed.807:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  %context.field.857 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.858 = load i32, ptr %context.field.857, align 4
  %context.field.859 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.860 = load i32, ptr %context.field.859, align 4
  %context.field.861 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.862 = load i32, ptr %context.field.861, align 4
  %stack.offset.863 = add i32 %context.value.21, %context.value.23
  %stack.offset.864 = add i32 %context.value.858, %context.value.860
  %stack.sub.865 = sub i32 %stack.offset.863, %stack.offset.864
  %stack.sub.866 = sub i32 %context.value.23, %context.value.860
  %stack.sub.867 = sub i32 %context.value.862, %context.value.25
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.865, i32 %stack.sub.866)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.867)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.offset.4 = alloca i32, align 4
  %local.extent.5 = alloca i32, align 4
  %local.payload.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.type.12 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  %local.active.13 = alloca i1, align 1
  %local.offset.14 = alloca i32, align 4
  %local.extent.15 = alloca i32, align 4
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.offset.19 = alloca i32, align 4
  %local.extent.20 = alloca i32, align 4
  %local.payload.21 = alloca i32, align 4
  %local.type.22 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  %local.active.23 = alloca i1, align 1
  %local.offset.24 = alloca i32, align 4
  %local.extent.25 = alloca i32, align 4
  %local.payload.26 = alloca i32, align 4
  %local.type.27 = alloca i32, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  %local.active.28 = alloca i1, align 1
  %local.offset.29 = alloca i32, align 4
  %local.extent.30 = alloca i32, align 4
  %local.payload.31 = alloca i32, align 4
  %local.type.32 = alloca i32, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %context.field.35 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.36 = load i32, ptr %context.field.35, align 4
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %frame.entered.41 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.42 = icmp eq i32 %frame.entered.41, 0
  br i1 %frame.enter.ok.42, label %frame.enter.continue.43, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.offset.46 = add i32 %argument.source, %argument.bytes
  %stack.offset.47 = add i32 %context.value.45, %argument.bytes
  %reserve.status.48 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.47, i32 141)
  %reserve.ok.49 = icmp eq i32 %reserve.status.48, 0
  br i1 %reserve.ok.49, label %reserve.continue.50, label %frame.reserve.failure.1
reserve.continue.50:
  %value.size.51 = alloca %AlOwningValueSize, align 4
  %measure.status.52 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %argument.source, i32 %stack.offset.46, i32 142, ptr %value.size.51)
  %helper.ok.53 = icmp eq i32 %measure.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %value.payload.pointer.55 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.51, i32 0, i32 0
  %value.extent.pointer.56 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.51, i32 0, i32 1
  %value.payload.57 = load i32, ptr %value.payload.pointer.55, align 4
  %value.extent.58 = load i32, ptr %value.extent.pointer.56, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.45, i32 %argument.source, i32 %value.extent.58, i32 %value.payload.57, i32 11, i32 8)
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %runtime.ok.61 = icmp eq i32 %context.value.60, 0
  br i1 %runtime.ok.61, label %runtime.continue.62, label %frame.failure.0
runtime.continue.62:
  %stack.offset.63 = add i32 %argument.source, %value.extent.58
  %stack.offset.64 = add i32 %context.value.45, %value.extent.58
  %arguments.exact.65 = icmp eq i32 %stack.offset.63, %stack.offset.46
  br i1 %arguments.exact.65, label %arguments.continue.66, label %frame.failure.0
arguments.continue.66:
  %step.status.67 = call i32 @al_owning_charge_step(ptr %ctx, i32 143)
  %helper.ok.68 = icmp eq i32 %step.status.67, 0
  br i1 %helper.ok.68, label %helper.continue.69, label %frame.failure.0
helper.continue.69:
  %local.is.active.70 = load i1, ptr %local.active.3, align 1
  %local.previous.extent.71 = load i32, ptr %local.extent.5, align 4
  %local.previous.payload.72 = load i32, ptr %local.payload.6, align 4
  %local.old.extent.73 = select i1 %local.is.active.70, i32 %local.previous.extent.71, i32 0
  %local.old.payload.74 = select i1 %local.is.active.70, i32 %local.previous.payload.72, i32 0
  %stack.offset.75 = add i32 %context.value.45, 0
  %stack.offset.76 = add i32 %stack.offset.75, %local.old.extent.73
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %stack.sub.79 = sub i32 %context.value.78, %stack.offset.76
  %stack.sub.80 = sub i32 %context.value.78, %local.old.extent.73
  %stack.offset.81 = add i32 %stack.sub.80, %value.extent.58
  %local.grows.82 = icmp ugt i32 %value.extent.58, %local.old.extent.73
  br i1 %local.grows.82, label %local.grow.83, label %local.fixed.84
local.grow.83:
  %reserve.status.86 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.81, i32 144)
  %reserve.ok.87 = icmp eq i32 %reserve.status.86, 0
  br i1 %reserve.ok.87, label %reserve.continue.88, label %frame.failure.0
reserve.continue.88:
  %stack.sub.89 = sub i32 %value.extent.58, %local.old.extent.73
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.89)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  br label %local.layout.ready.85
local.fixed.84:
  br label %local.layout.ready.85
local.layout.ready.85:
  %stack.offset.94 = add i32 %stack.offset.75, %value.extent.58
  %local.is.active.95 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.96 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.97 = select i1 %local.is.active.95, i32 %local.suffix.payload.96, i32 0
  %stack.offset.98 = add i32 0, %local.suffix.selected.97
  %local.is.active.99 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.100 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.101 = select i1 %local.is.active.99, i32 %local.suffix.payload.100, i32 0
  %stack.offset.102 = add i32 %stack.offset.98, %local.suffix.selected.101
  %local.is.active.103 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.104 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.105 = select i1 %local.is.active.103, i32 %local.suffix.payload.104, i32 0
  %stack.offset.106 = add i32 %stack.offset.102, %local.suffix.selected.105
  %local.is.active.107 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.108 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.109 = select i1 %local.is.active.107, i32 %local.suffix.payload.108, i32 0
  %stack.offset.110 = add i32 %stack.offset.106, %local.suffix.selected.109
  %local.is.active.111 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.112 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.113 = select i1 %local.is.active.111, i32 %local.suffix.payload.112, i32 0
  %stack.offset.114 = add i32 %stack.offset.110, %local.suffix.selected.113
  %stack.offset.115 = add i32 0, %value.payload.57
  %stack.offset.116 = add i32 %stack.offset.114, %stack.offset.115
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.94, i32 %stack.offset.76, i32 %stack.sub.79, i32 %stack.offset.116, i32 0, i32 14)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  %stack.sub.121 = sub i32 %context.value.78, %value.extent.58
  %stack.sub.122 = sub i32 %stack.sub.121, %local.old.extent.73
  %stack.offset.123 = add i32 %stack.sub.122, %value.extent.58
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.75, i32 %stack.offset.123, i32 %value.extent.58, i32 %value.payload.57, i32 11, i32 4)
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %runtime.ok.126 = icmp eq i32 %context.value.125, 0
  br i1 %runtime.ok.126, label %runtime.continue.127, label %frame.failure.0
runtime.continue.127:
  %stack.sub.128 = sub i32 %context.value.78, %local.old.extent.73
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.128, i32 0, i32 0, i32 0)
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %runtime.ok.131 = icmp eq i32 %context.value.130, 0
  br i1 %runtime.ok.131, label %runtime.continue.132, label %frame.failure.0
runtime.continue.132:
  %local.shrinks.133 = icmp ult i32 %value.extent.58, %local.old.extent.73
  br i1 %local.shrinks.133, label %local.shrink.134, label %local.counts.ready.135
local.shrink.134:
  %stack.sub.136 = sub i32 %local.old.extent.73, %value.extent.58
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.136)
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %runtime.ok.139 = icmp eq i32 %context.value.138, 0
  br i1 %runtime.ok.139, label %runtime.continue.140, label %frame.failure.0
runtime.continue.140:
  br label %local.counts.ready.135
local.counts.ready.135:
  %local.payload.delta.141 = sub i32 %value.payload.57, %local.old.payload.74
  %stack.sub.142 = sub i32 0, %local.old.payload.74
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.142, i32 %local.payload.delta.141)
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %runtime.ok.145 = icmp eq i32 %context.value.144, 0
  br i1 %runtime.ok.145, label %runtime.continue.146, label %frame.failure.0
runtime.continue.146:
  %local.is.active.147 = load i1, ptr %local.active.8, align 1
  %local.later.offset.148 = load i32, ptr %local.offset.9, align 4
  %stack.sub.149 = sub i32 %local.later.offset.148, %local.old.extent.73
  %stack.offset.150 = add i32 %stack.sub.149, %value.extent.58
  %local.later.offset.selected.151 = select i1 %local.is.active.147, i32 %stack.offset.150, i32 %local.later.offset.148
  store i32 %local.later.offset.selected.151, ptr %local.offset.9, align 4
  %local.is.active.152 = load i1, ptr %local.active.13, align 1
  %local.later.offset.153 = load i32, ptr %local.offset.14, align 4
  %stack.sub.154 = sub i32 %local.later.offset.153, %local.old.extent.73
  %stack.offset.155 = add i32 %stack.sub.154, %value.extent.58
  %local.later.offset.selected.156 = select i1 %local.is.active.152, i32 %stack.offset.155, i32 %local.later.offset.153
  store i32 %local.later.offset.selected.156, ptr %local.offset.14, align 4
  %local.is.active.157 = load i1, ptr %local.active.18, align 1
  %local.later.offset.158 = load i32, ptr %local.offset.19, align 4
  %stack.sub.159 = sub i32 %local.later.offset.158, %local.old.extent.73
  %stack.offset.160 = add i32 %stack.sub.159, %value.extent.58
  %local.later.offset.selected.161 = select i1 %local.is.active.157, i32 %stack.offset.160, i32 %local.later.offset.158
  store i32 %local.later.offset.selected.161, ptr %local.offset.19, align 4
  %local.is.active.162 = load i1, ptr %local.active.23, align 1
  %local.later.offset.163 = load i32, ptr %local.offset.24, align 4
  %stack.sub.164 = sub i32 %local.later.offset.163, %local.old.extent.73
  %stack.offset.165 = add i32 %stack.sub.164, %value.extent.58
  %local.later.offset.selected.166 = select i1 %local.is.active.162, i32 %stack.offset.165, i32 %local.later.offset.163
  store i32 %local.later.offset.selected.166, ptr %local.offset.24, align 4
  %local.is.active.167 = load i1, ptr %local.active.28, align 1
  %local.later.offset.168 = load i32, ptr %local.offset.29, align 4
  %stack.sub.169 = sub i32 %local.later.offset.168, %local.old.extent.73
  %stack.offset.170 = add i32 %stack.sub.169, %value.extent.58
  %local.later.offset.selected.171 = select i1 %local.is.active.167, i32 %stack.offset.170, i32 %local.later.offset.168
  store i32 %local.later.offset.selected.171, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.3, align 1
  store i32 %stack.offset.75, ptr %local.offset.4, align 4
  store i32 %value.extent.58, ptr %local.extent.5, align 4
  store i32 %value.payload.57, ptr %local.payload.6, align 4
  store i32 11, ptr %local.type.7, align 4
  %local.is.active.172 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.173 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.174 = select i1 %local.is.active.172, i32 %local.sum.extent.173, i32 0
  %stack.offset.175 = add i32 0, %local.sum.selected.174
  %local.is.active.176 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.177 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.178 = select i1 %local.is.active.176, i32 %local.sum.extent.177, i32 0
  %stack.offset.179 = add i32 %stack.offset.175, %local.sum.selected.178
  %local.is.active.180 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.181 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.182 = select i1 %local.is.active.180, i32 %local.sum.extent.181, i32 0
  %stack.offset.183 = add i32 %stack.offset.179, %local.sum.selected.182
  %local.is.active.184 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.185 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.186 = select i1 %local.is.active.184, i32 %local.sum.extent.185, i32 0
  %stack.offset.187 = add i32 %stack.offset.183, %local.sum.selected.186
  %local.is.active.188 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.189 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.190 = select i1 %local.is.active.188, i32 %local.sum.extent.189, i32 0
  %stack.offset.191 = add i32 %stack.offset.187, %local.sum.selected.190
  %local.is.active.192 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.193 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.194 = select i1 %local.is.active.192, i32 %local.sum.extent.193, i32 0
  %stack.offset.195 = add i32 %stack.offset.191, %local.sum.selected.194
  %stack.offset.196 = add i32 %stack.offset.195, 0
  %stack.offset.197 = add i32 %context.value.45, %stack.offset.196
  %cursor.status.198 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.197)
  %cursor.ok.199 = icmp eq i32 %cursor.status.198, 0
  br i1 %cursor.ok.199, label %cursor.continue.200, label %frame.failure.0
cursor.continue.200:
  %step.status.201 = call i32 @al_owning_charge_step(ptr %ctx, i32 145)
  %helper.ok.202 = icmp eq i32 %step.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %local.source.offset.204 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.205 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.206 = load i32, ptr %local.payload.6, align 4
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %stack.offset.209 = add i32 %context.value.208, %local.source.extent.205
  %reserve.status.210 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.209, i32 146)
  %reserve.ok.211 = icmp eq i32 %reserve.status.210, 0
  br i1 %reserve.ok.211, label %reserve.continue.212, label %frame.failure.0
reserve.continue.212:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.208, i32 %local.source.offset.204, i32 %local.source.extent.205, i32 %local.source.payload.206, i32 11)
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %runtime.ok.215 = icmp eq i32 %context.value.214, 0
  br i1 %runtime.ok.215, label %runtime.continue.216, label %frame.failure.0
runtime.continue.216:
  %local.is.active.217 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.218 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.219 = select i1 %local.is.active.217, i32 %local.sum.extent.218, i32 0
  %stack.offset.220 = add i32 0, %local.sum.selected.219
  %local.is.active.221 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.222 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.223 = select i1 %local.is.active.221, i32 %local.sum.extent.222, i32 0
  %stack.offset.224 = add i32 %stack.offset.220, %local.sum.selected.223
  %local.is.active.225 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.226 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.227 = select i1 %local.is.active.225, i32 %local.sum.extent.226, i32 0
  %stack.offset.228 = add i32 %stack.offset.224, %local.sum.selected.227
  %local.is.active.229 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.230 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.231 = select i1 %local.is.active.229, i32 %local.sum.extent.230, i32 0
  %stack.offset.232 = add i32 %stack.offset.228, %local.sum.selected.231
  %local.is.active.233 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.234 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.235 = select i1 %local.is.active.233, i32 %local.sum.extent.234, i32 0
  %stack.offset.236 = add i32 %stack.offset.232, %local.sum.selected.235
  %local.is.active.237 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.238 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.239 = select i1 %local.is.active.237, i32 %local.sum.extent.238, i32 0
  %stack.offset.240 = add i32 %stack.offset.236, %local.sum.selected.239
  %stack.offset.241 = add i32 0, %local.source.extent.205
  %stack.offset.242 = add i32 %stack.offset.240, %stack.offset.241
  %stack.offset.243 = add i32 %context.value.45, %stack.offset.242
  %cursor.status.244 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.243)
  %cursor.ok.245 = icmp eq i32 %cursor.status.244, 0
  br i1 %cursor.ok.245, label %cursor.continue.246, label %frame.failure.0
cursor.continue.246:
  %step.status.247 = call i32 @al_owning_charge_step(ptr %ctx, i32 147)
  %helper.ok.248 = icmp eq i32 %step.status.247, 0
  br i1 %helper.ok.248, label %helper.continue.249, label %frame.failure.0
helper.continue.249:
  %local.is.active.250 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.251 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.252 = select i1 %local.is.active.250, i32 %local.sum.extent.251, i32 0
  %stack.offset.253 = add i32 0, %local.sum.selected.252
  %local.is.active.254 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.255 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.256 = select i1 %local.is.active.254, i32 %local.sum.extent.255, i32 0
  %stack.offset.257 = add i32 %stack.offset.253, %local.sum.selected.256
  %local.is.active.258 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.259 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.260 = select i1 %local.is.active.258, i32 %local.sum.extent.259, i32 0
  %stack.offset.261 = add i32 %stack.offset.257, %local.sum.selected.260
  %local.is.active.262 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.263 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.264 = select i1 %local.is.active.262, i32 %local.sum.extent.263, i32 0
  %stack.offset.265 = add i32 %stack.offset.261, %local.sum.selected.264
  %local.is.active.266 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.267 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.268 = select i1 %local.is.active.266, i32 %local.sum.extent.267, i32 0
  %stack.offset.269 = add i32 %stack.offset.265, %local.sum.selected.268
  %local.is.active.270 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.271 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.272 = select i1 %local.is.active.270, i32 %local.sum.extent.271, i32 0
  %stack.offset.273 = add i32 %stack.offset.269, %local.sum.selected.272
  %stack.offset.274 = add i32 %stack.offset.273, 0
  %stack.offset.275 = add i32 %context.value.45, %stack.offset.274
  %field.location.276 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.277 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.275, i32 %local.source.extent.205, i32 1, i32 148, ptr %field.location.276)
  %helper.ok.278 = icmp eq i32 %field.location.status.277, 0
  br i1 %helper.ok.278, label %helper.continue.279, label %frame.failure.0
helper.continue.279:
  %field.offset.pointer.280 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.276, i32 0, i32 0
  %field.offset.281 = load i32, ptr %field.offset.pointer.280, align 4
  %field.payload.pointer.282 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.276, i32 0, i32 1
  %field.payload.283 = load i32, ptr %field.payload.pointer.282, align 4
  %field.extent.pointer.284 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.276, i32 0, i32 2
  %field.extent.285 = load i32, ptr %field.extent.pointer.284, align 4
  %stack.offset.286 = add i32 %stack.offset.275, %field.extent.285
  %context.field.287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.288 = load i32, ptr %context.field.287, align 4
  %field.result.grows.289 = icmp ugt i32 %stack.offset.286, %context.value.288
  br i1 %field.result.grows.289, label %field.result.reserve.290, label %field.result.existing.291
field.result.reserve.290:
  %reserve.status.293 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.286, i32 149)
  %reserve.ok.294 = icmp eq i32 %reserve.status.293, 0
  br i1 %reserve.ok.294, label %reserve.continue.295, label %frame.failure.0
reserve.continue.295:
  br label %field.result.ready.292
field.result.existing.291:
  br label %field.result.ready.292
field.result.ready.292:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.275, i32 %field.offset.281, i32 %field.extent.285, i32 %field.payload.283, i32 8, i32 7)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %runtime.ok.298 = icmp eq i32 %context.value.297, 0
  br i1 %runtime.ok.298, label %runtime.continue.299, label %frame.failure.0
runtime.continue.299:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.286, i32 0, i32 0, i32 0)
  %context.field.300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.301 = load i32, ptr %context.field.300, align 4
  %runtime.ok.302 = icmp eq i32 %context.value.301, 0
  br i1 %runtime.ok.302, label %runtime.continue.303, label %frame.failure.0
runtime.continue.303:
  %stack.sub.304 = sub i32 %field.payload.283, %local.source.payload.206
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.304, i32 0)
  %context.field.305 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.306 = load i32, ptr %context.field.305, align 4
  %runtime.ok.307 = icmp eq i32 %context.value.306, 0
  br i1 %runtime.ok.307, label %runtime.continue.308, label %frame.failure.0
runtime.continue.308:
  %local.is.active.309 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.310 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.311 = select i1 %local.is.active.309, i32 %local.sum.extent.310, i32 0
  %stack.offset.312 = add i32 0, %local.sum.selected.311
  %local.is.active.313 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.314 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.315 = select i1 %local.is.active.313, i32 %local.sum.extent.314, i32 0
  %stack.offset.316 = add i32 %stack.offset.312, %local.sum.selected.315
  %local.is.active.317 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.318 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.319 = select i1 %local.is.active.317, i32 %local.sum.extent.318, i32 0
  %stack.offset.320 = add i32 %stack.offset.316, %local.sum.selected.319
  %local.is.active.321 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.322 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.323 = select i1 %local.is.active.321, i32 %local.sum.extent.322, i32 0
  %stack.offset.324 = add i32 %stack.offset.320, %local.sum.selected.323
  %local.is.active.325 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.326 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.327 = select i1 %local.is.active.325, i32 %local.sum.extent.326, i32 0
  %stack.offset.328 = add i32 %stack.offset.324, %local.sum.selected.327
  %local.is.active.329 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.330 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.331 = select i1 %local.is.active.329, i32 %local.sum.extent.330, i32 0
  %stack.offset.332 = add i32 %stack.offset.328, %local.sum.selected.331
  %stack.offset.333 = add i32 0, %field.extent.285
  %stack.offset.334 = add i32 %stack.offset.332, %stack.offset.333
  %stack.offset.335 = add i32 %context.value.45, %stack.offset.334
  %cursor.status.336 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.335)
  %cursor.ok.337 = icmp eq i32 %cursor.status.336, 0
  br i1 %cursor.ok.337, label %cursor.continue.338, label %frame.failure.0
cursor.continue.338:
  %step.status.339 = call i32 @al_owning_charge_step(ptr %ctx, i32 150)
  %helper.ok.340 = icmp eq i32 %step.status.339, 0
  br i1 %helper.ok.340, label %helper.continue.341, label %frame.failure.0
helper.continue.341:
  %local.is.active.342 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.343 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.344 = select i1 %local.is.active.342, i32 %local.sum.extent.343, i32 0
  %stack.offset.345 = add i32 0, %local.sum.selected.344
  %local.is.active.346 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.347 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.348 = select i1 %local.is.active.346, i32 %local.sum.extent.347, i32 0
  %stack.offset.349 = add i32 %stack.offset.345, %local.sum.selected.348
  %local.is.active.350 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.351 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.352 = select i1 %local.is.active.350, i32 %local.sum.extent.351, i32 0
  %stack.offset.353 = add i32 %stack.offset.349, %local.sum.selected.352
  %local.is.active.354 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.355 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.356 = select i1 %local.is.active.354, i32 %local.sum.extent.355, i32 0
  %stack.offset.357 = add i32 %stack.offset.353, %local.sum.selected.356
  %local.is.active.358 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.359 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.360 = select i1 %local.is.active.358, i32 %local.sum.extent.359, i32 0
  %stack.offset.361 = add i32 %stack.offset.357, %local.sum.selected.360
  %local.is.active.362 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.363 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.364 = select i1 %local.is.active.362, i32 %local.sum.extent.363, i32 0
  %stack.offset.365 = add i32 %stack.offset.361, %local.sum.selected.364
  %stack.offset.366 = add i32 %stack.offset.365, 0
  %stack.offset.367 = add i32 %context.value.45, %stack.offset.366
  %context.field.368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.369 = load i32, ptr %context.field.368, align 4
  %stack.offset.371 = add i32 0, %field.extent.285
  %callee.status.370 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.367, i32 %stack.offset.371, i32 151)
  %helper.ok.372 = icmp eq i32 %callee.status.370, 0
  br i1 %helper.ok.372, label %helper.continue.373, label %frame.failure.0
helper.continue.373:
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %value.size.376 = alloca %AlOwningValueSize, align 4
  %measure.status.377 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %context.value.369, i32 %context.value.375, i32 152, ptr %value.size.376)
  %helper.ok.378 = icmp eq i32 %measure.status.377, 0
  br i1 %helper.ok.378, label %helper.continue.379, label %frame.failure.0
helper.continue.379:
  %value.payload.pointer.380 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.376, i32 0, i32 0
  %value.extent.pointer.381 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.376, i32 0, i32 1
  %value.payload.382 = load i32, ptr %value.payload.pointer.380, align 4
  %value.extent.383 = load i32, ptr %value.extent.pointer.381, align 4
  %stack.offset.384 = add i32 %context.value.369, %value.extent.383
  %stack.offset.385 = add i32 0, %value.payload.382
  %value.size.386 = alloca %AlOwningValueSize, align 4
  %measure.status.387 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.384, i32 %context.value.375, i32 153, ptr %value.size.386)
  %helper.ok.388 = icmp eq i32 %measure.status.387, 0
  br i1 %helper.ok.388, label %helper.continue.389, label %frame.failure.0
helper.continue.389:
  %value.payload.pointer.390 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.386, i32 0, i32 0
  %value.extent.pointer.391 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.386, i32 0, i32 1
  %value.payload.392 = load i32, ptr %value.payload.pointer.390, align 4
  %value.extent.393 = load i32, ptr %value.extent.pointer.391, align 4
  %stack.offset.394 = add i32 %stack.offset.384, %value.extent.393
  %stack.offset.395 = add i32 %stack.offset.385, %value.payload.392
  %callee.outputs.exact.396 = icmp eq i32 %stack.offset.394, %context.value.375
  br i1 %callee.outputs.exact.396, label %callee.outputs.continue.397, label %frame.failure.0
callee.outputs.continue.397:
  %stack.sub.398 = sub i32 %context.value.375, %context.value.369
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.367, i32 %context.value.369, i32 %stack.sub.398, i32 %stack.offset.395, i32 0, i32 9)
  %context.field.399 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.400 = load i32, ptr %context.field.399, align 4
  %runtime.ok.401 = icmp eq i32 %context.value.400, 0
  br i1 %runtime.ok.401, label %runtime.continue.402, label %frame.failure.0
runtime.continue.402:
  %stack.offset.403 = add i32 %stack.offset.367, %stack.sub.398
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.403, i32 0, i32 0, i32 0)
  %context.field.404 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.405 = load i32, ptr %context.field.404, align 4
  %runtime.ok.406 = icmp eq i32 %context.value.405, 0
  br i1 %runtime.ok.406, label %runtime.continue.407, label %frame.failure.0
runtime.continue.407:
  %local.is.active.408 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.409 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.410 = select i1 %local.is.active.408, i32 %local.sum.extent.409, i32 0
  %stack.offset.411 = add i32 0, %local.sum.selected.410
  %local.is.active.412 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.413 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.414 = select i1 %local.is.active.412, i32 %local.sum.extent.413, i32 0
  %stack.offset.415 = add i32 %stack.offset.411, %local.sum.selected.414
  %local.is.active.416 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.417 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.418 = select i1 %local.is.active.416, i32 %local.sum.extent.417, i32 0
  %stack.offset.419 = add i32 %stack.offset.415, %local.sum.selected.418
  %local.is.active.420 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.421 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.422 = select i1 %local.is.active.420, i32 %local.sum.extent.421, i32 0
  %stack.offset.423 = add i32 %stack.offset.419, %local.sum.selected.422
  %local.is.active.424 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.425 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.426 = select i1 %local.is.active.424, i32 %local.sum.extent.425, i32 0
  %stack.offset.427 = add i32 %stack.offset.423, %local.sum.selected.426
  %local.is.active.428 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.429 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.430 = select i1 %local.is.active.428, i32 %local.sum.extent.429, i32 0
  %stack.offset.431 = add i32 %stack.offset.427, %local.sum.selected.430
  %stack.offset.432 = add i32 0, %value.extent.383
  %stack.offset.433 = add i32 %stack.offset.432, %value.extent.393
  %stack.offset.434 = add i32 %stack.offset.431, %stack.offset.433
  %stack.offset.435 = add i32 %context.value.45, %stack.offset.434
  %cursor.status.436 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.435)
  %cursor.ok.437 = icmp eq i32 %cursor.status.436, 0
  br i1 %cursor.ok.437, label %cursor.continue.438, label %frame.failure.0
cursor.continue.438:
  %step.status.439 = call i32 @al_owning_charge_step(ptr %ctx, i32 154)
  %helper.ok.440 = icmp eq i32 %step.status.439, 0
  br i1 %helper.ok.440, label %helper.continue.441, label %frame.failure.0
helper.continue.441:
  %local.is.active.442 = load i1, ptr %local.active.8, align 1
  %local.previous.extent.443 = load i32, ptr %local.extent.10, align 4
  %local.previous.payload.444 = load i32, ptr %local.payload.11, align 4
  %local.old.extent.445 = select i1 %local.is.active.442, i32 %local.previous.extent.443, i32 0
  %local.old.payload.446 = select i1 %local.is.active.442, i32 %local.previous.payload.444, i32 0
  %local.is.active.447 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.448 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.449 = select i1 %local.is.active.447, i32 %local.sum.extent.448, i32 0
  %stack.offset.450 = add i32 0, %local.sum.selected.449
  %stack.offset.451 = add i32 %context.value.45, %stack.offset.450
  %stack.offset.452 = add i32 %stack.offset.451, %local.old.extent.445
  %context.field.453 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.454 = load i32, ptr %context.field.453, align 4
  %stack.sub.455 = sub i32 %context.value.454, %stack.offset.452
  %stack.sub.456 = sub i32 %context.value.454, %local.old.extent.445
  %stack.offset.457 = add i32 %stack.sub.456, %value.extent.393
  %local.grows.458 = icmp ugt i32 %value.extent.393, %local.old.extent.445
  br i1 %local.grows.458, label %local.grow.459, label %local.fixed.460
local.grow.459:
  %reserve.status.462 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.457, i32 155)
  %reserve.ok.463 = icmp eq i32 %reserve.status.462, 0
  br i1 %reserve.ok.463, label %reserve.continue.464, label %frame.failure.0
reserve.continue.464:
  %stack.sub.465 = sub i32 %value.extent.393, %local.old.extent.445
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.465)
  %context.field.466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.467 = load i32, ptr %context.field.466, align 4
  %runtime.ok.468 = icmp eq i32 %context.value.467, 0
  br i1 %runtime.ok.468, label %runtime.continue.469, label %frame.failure.0
runtime.continue.469:
  br label %local.layout.ready.461
local.fixed.460:
  br label %local.layout.ready.461
local.layout.ready.461:
  %stack.offset.470 = add i32 %stack.offset.451, %value.extent.393
  %local.is.active.471 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.472 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.473 = select i1 %local.is.active.471, i32 %local.suffix.payload.472, i32 0
  %stack.offset.474 = add i32 0, %local.suffix.selected.473
  %local.is.active.475 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.476 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.477 = select i1 %local.is.active.475, i32 %local.suffix.payload.476, i32 0
  %stack.offset.478 = add i32 %stack.offset.474, %local.suffix.selected.477
  %local.is.active.479 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.480 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.481 = select i1 %local.is.active.479, i32 %local.suffix.payload.480, i32 0
  %stack.offset.482 = add i32 %stack.offset.478, %local.suffix.selected.481
  %local.is.active.483 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.484 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.485 = select i1 %local.is.active.483, i32 %local.suffix.payload.484, i32 0
  %stack.offset.486 = add i32 %stack.offset.482, %local.suffix.selected.485
  %stack.offset.487 = add i32 0, %value.payload.382
  %stack.offset.488 = add i32 %stack.offset.487, %value.payload.392
  %stack.offset.489 = add i32 %stack.offset.486, %stack.offset.488
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.470, i32 %stack.offset.452, i32 %stack.sub.455, i32 %stack.offset.489, i32 0, i32 14)
  %context.field.490 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.491 = load i32, ptr %context.field.490, align 4
  %runtime.ok.492 = icmp eq i32 %context.value.491, 0
  br i1 %runtime.ok.492, label %runtime.continue.493, label %frame.failure.0
runtime.continue.493:
  %stack.sub.494 = sub i32 %context.value.454, %value.extent.393
  %stack.sub.495 = sub i32 %stack.sub.494, %local.old.extent.445
  %stack.offset.496 = add i32 %stack.sub.495, %value.extent.393
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.451, i32 %stack.offset.496, i32 %value.extent.393, i32 %value.payload.392, i32 1, i32 4)
  %context.field.497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.498 = load i32, ptr %context.field.497, align 4
  %runtime.ok.499 = icmp eq i32 %context.value.498, 0
  br i1 %runtime.ok.499, label %runtime.continue.500, label %frame.failure.0
runtime.continue.500:
  %stack.sub.501 = sub i32 %context.value.454, %local.old.extent.445
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.501, i32 0, i32 0, i32 0)
  %context.field.502 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.503 = load i32, ptr %context.field.502, align 4
  %runtime.ok.504 = icmp eq i32 %context.value.503, 0
  br i1 %runtime.ok.504, label %runtime.continue.505, label %frame.failure.0
runtime.continue.505:
  %local.shrinks.506 = icmp ult i32 %value.extent.393, %local.old.extent.445
  br i1 %local.shrinks.506, label %local.shrink.507, label %local.counts.ready.508
local.shrink.507:
  %stack.sub.509 = sub i32 %local.old.extent.445, %value.extent.393
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.509)
  %context.field.510 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.511 = load i32, ptr %context.field.510, align 4
  %runtime.ok.512 = icmp eq i32 %context.value.511, 0
  br i1 %runtime.ok.512, label %runtime.continue.513, label %frame.failure.0
runtime.continue.513:
  br label %local.counts.ready.508
local.counts.ready.508:
  %local.payload.delta.514 = sub i32 %value.payload.392, %local.old.payload.446
  %stack.sub.515 = sub i32 0, %local.old.payload.446
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.515, i32 %local.payload.delta.514)
  %context.field.516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.517 = load i32, ptr %context.field.516, align 4
  %runtime.ok.518 = icmp eq i32 %context.value.517, 0
  br i1 %runtime.ok.518, label %runtime.continue.519, label %frame.failure.0
runtime.continue.519:
  %local.is.active.520 = load i1, ptr %local.active.13, align 1
  %local.later.offset.521 = load i32, ptr %local.offset.14, align 4
  %stack.sub.522 = sub i32 %local.later.offset.521, %local.old.extent.445
  %stack.offset.523 = add i32 %stack.sub.522, %value.extent.393
  %local.later.offset.selected.524 = select i1 %local.is.active.520, i32 %stack.offset.523, i32 %local.later.offset.521
  store i32 %local.later.offset.selected.524, ptr %local.offset.14, align 4
  %local.is.active.525 = load i1, ptr %local.active.18, align 1
  %local.later.offset.526 = load i32, ptr %local.offset.19, align 4
  %stack.sub.527 = sub i32 %local.later.offset.526, %local.old.extent.445
  %stack.offset.528 = add i32 %stack.sub.527, %value.extent.393
  %local.later.offset.selected.529 = select i1 %local.is.active.525, i32 %stack.offset.528, i32 %local.later.offset.526
  store i32 %local.later.offset.selected.529, ptr %local.offset.19, align 4
  %local.is.active.530 = load i1, ptr %local.active.23, align 1
  %local.later.offset.531 = load i32, ptr %local.offset.24, align 4
  %stack.sub.532 = sub i32 %local.later.offset.531, %local.old.extent.445
  %stack.offset.533 = add i32 %stack.sub.532, %value.extent.393
  %local.later.offset.selected.534 = select i1 %local.is.active.530, i32 %stack.offset.533, i32 %local.later.offset.531
  store i32 %local.later.offset.selected.534, ptr %local.offset.24, align 4
  %local.is.active.535 = load i1, ptr %local.active.28, align 1
  %local.later.offset.536 = load i32, ptr %local.offset.29, align 4
  %stack.sub.537 = sub i32 %local.later.offset.536, %local.old.extent.445
  %stack.offset.538 = add i32 %stack.sub.537, %value.extent.393
  %local.later.offset.selected.539 = select i1 %local.is.active.535, i32 %stack.offset.538, i32 %local.later.offset.536
  store i32 %local.later.offset.selected.539, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.8, align 1
  store i32 %stack.offset.451, ptr %local.offset.9, align 4
  store i32 %value.extent.393, ptr %local.extent.10, align 4
  store i32 %value.payload.392, ptr %local.payload.11, align 4
  store i32 1, ptr %local.type.12, align 4
  %local.is.active.540 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.541 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.542 = select i1 %local.is.active.540, i32 %local.sum.extent.541, i32 0
  %stack.offset.543 = add i32 0, %local.sum.selected.542
  %local.is.active.544 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.545 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.546 = select i1 %local.is.active.544, i32 %local.sum.extent.545, i32 0
  %stack.offset.547 = add i32 %stack.offset.543, %local.sum.selected.546
  %local.is.active.548 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.549 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.550 = select i1 %local.is.active.548, i32 %local.sum.extent.549, i32 0
  %stack.offset.551 = add i32 %stack.offset.547, %local.sum.selected.550
  %local.is.active.552 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.553 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.554 = select i1 %local.is.active.552, i32 %local.sum.extent.553, i32 0
  %stack.offset.555 = add i32 %stack.offset.551, %local.sum.selected.554
  %local.is.active.556 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.557 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.558 = select i1 %local.is.active.556, i32 %local.sum.extent.557, i32 0
  %stack.offset.559 = add i32 %stack.offset.555, %local.sum.selected.558
  %local.is.active.560 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.561 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.562 = select i1 %local.is.active.560, i32 %local.sum.extent.561, i32 0
  %stack.offset.563 = add i32 %stack.offset.559, %local.sum.selected.562
  %stack.offset.564 = add i32 0, %value.extent.383
  %stack.offset.565 = add i32 %stack.offset.563, %stack.offset.564
  %stack.offset.566 = add i32 %context.value.45, %stack.offset.565
  %cursor.status.567 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.566)
  %cursor.ok.568 = icmp eq i32 %cursor.status.567, 0
  br i1 %cursor.ok.568, label %cursor.continue.569, label %frame.failure.0
cursor.continue.569:
  %step.status.570 = call i32 @al_owning_charge_step(ptr %ctx, i32 156)
  %helper.ok.571 = icmp eq i32 %step.status.570, 0
  br i1 %helper.ok.571, label %helper.continue.572, label %frame.failure.0
helper.continue.572:
  %local.is.active.573 = load i1, ptr %local.active.13, align 1
  %local.previous.extent.574 = load i32, ptr %local.extent.15, align 4
  %local.previous.payload.575 = load i32, ptr %local.payload.16, align 4
  %local.old.extent.576 = select i1 %local.is.active.573, i32 %local.previous.extent.574, i32 0
  %local.old.payload.577 = select i1 %local.is.active.573, i32 %local.previous.payload.575, i32 0
  %local.is.active.578 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.579 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.580 = select i1 %local.is.active.578, i32 %local.sum.extent.579, i32 0
  %stack.offset.581 = add i32 0, %local.sum.selected.580
  %local.is.active.582 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.583 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.584 = select i1 %local.is.active.582, i32 %local.sum.extent.583, i32 0
  %stack.offset.585 = add i32 %stack.offset.581, %local.sum.selected.584
  %stack.offset.586 = add i32 %context.value.45, %stack.offset.585
  %stack.offset.587 = add i32 %stack.offset.586, %local.old.extent.576
  %context.field.588 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.589 = load i32, ptr %context.field.588, align 4
  %stack.sub.590 = sub i32 %context.value.589, %stack.offset.587
  %stack.sub.591 = sub i32 %context.value.589, %local.old.extent.576
  %stack.offset.592 = add i32 %stack.sub.591, %value.extent.383
  %local.grows.593 = icmp ugt i32 %value.extent.383, %local.old.extent.576
  br i1 %local.grows.593, label %local.grow.594, label %local.fixed.595
local.grow.594:
  %reserve.status.597 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.592, i32 157)
  %reserve.ok.598 = icmp eq i32 %reserve.status.597, 0
  br i1 %reserve.ok.598, label %reserve.continue.599, label %frame.failure.0
reserve.continue.599:
  %stack.sub.600 = sub i32 %value.extent.383, %local.old.extent.576
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.600)
  %context.field.601 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.602 = load i32, ptr %context.field.601, align 4
  %runtime.ok.603 = icmp eq i32 %context.value.602, 0
  br i1 %runtime.ok.603, label %runtime.continue.604, label %frame.failure.0
runtime.continue.604:
  br label %local.layout.ready.596
local.fixed.595:
  br label %local.layout.ready.596
local.layout.ready.596:
  %stack.offset.605 = add i32 %stack.offset.586, %value.extent.383
  %local.is.active.606 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.607 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.608 = select i1 %local.is.active.606, i32 %local.suffix.payload.607, i32 0
  %stack.offset.609 = add i32 0, %local.suffix.selected.608
  %local.is.active.610 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.611 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.612 = select i1 %local.is.active.610, i32 %local.suffix.payload.611, i32 0
  %stack.offset.613 = add i32 %stack.offset.609, %local.suffix.selected.612
  %local.is.active.614 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.615 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.616 = select i1 %local.is.active.614, i32 %local.suffix.payload.615, i32 0
  %stack.offset.617 = add i32 %stack.offset.613, %local.suffix.selected.616
  %stack.offset.618 = add i32 0, %value.payload.382
  %stack.offset.619 = add i32 %stack.offset.617, %stack.offset.618
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.605, i32 %stack.offset.587, i32 %stack.sub.590, i32 %stack.offset.619, i32 0, i32 14)
  %context.field.620 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.621 = load i32, ptr %context.field.620, align 4
  %runtime.ok.622 = icmp eq i32 %context.value.621, 0
  br i1 %runtime.ok.622, label %runtime.continue.623, label %frame.failure.0
runtime.continue.623:
  %stack.sub.624 = sub i32 %context.value.589, %value.extent.383
  %stack.sub.625 = sub i32 %stack.sub.624, %local.old.extent.576
  %stack.offset.626 = add i32 %stack.sub.625, %value.extent.383
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.586, i32 %stack.offset.626, i32 %value.extent.383, i32 %value.payload.382, i32 8, i32 4)
  %context.field.627 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.628 = load i32, ptr %context.field.627, align 4
  %runtime.ok.629 = icmp eq i32 %context.value.628, 0
  br i1 %runtime.ok.629, label %runtime.continue.630, label %frame.failure.0
runtime.continue.630:
  %stack.sub.631 = sub i32 %context.value.589, %local.old.extent.576
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.631, i32 0, i32 0, i32 0)
  %context.field.632 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.633 = load i32, ptr %context.field.632, align 4
  %runtime.ok.634 = icmp eq i32 %context.value.633, 0
  br i1 %runtime.ok.634, label %runtime.continue.635, label %frame.failure.0
runtime.continue.635:
  %local.shrinks.636 = icmp ult i32 %value.extent.383, %local.old.extent.576
  br i1 %local.shrinks.636, label %local.shrink.637, label %local.counts.ready.638
local.shrink.637:
  %stack.sub.639 = sub i32 %local.old.extent.576, %value.extent.383
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.639)
  %context.field.640 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.641 = load i32, ptr %context.field.640, align 4
  %runtime.ok.642 = icmp eq i32 %context.value.641, 0
  br i1 %runtime.ok.642, label %runtime.continue.643, label %frame.failure.0
runtime.continue.643:
  br label %local.counts.ready.638
local.counts.ready.638:
  %local.payload.delta.644 = sub i32 %value.payload.382, %local.old.payload.577
  %stack.sub.645 = sub i32 0, %local.old.payload.577
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.645, i32 %local.payload.delta.644)
  %context.field.646 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.647 = load i32, ptr %context.field.646, align 4
  %runtime.ok.648 = icmp eq i32 %context.value.647, 0
  br i1 %runtime.ok.648, label %runtime.continue.649, label %frame.failure.0
runtime.continue.649:
  %local.is.active.650 = load i1, ptr %local.active.18, align 1
  %local.later.offset.651 = load i32, ptr %local.offset.19, align 4
  %stack.sub.652 = sub i32 %local.later.offset.651, %local.old.extent.576
  %stack.offset.653 = add i32 %stack.sub.652, %value.extent.383
  %local.later.offset.selected.654 = select i1 %local.is.active.650, i32 %stack.offset.653, i32 %local.later.offset.651
  store i32 %local.later.offset.selected.654, ptr %local.offset.19, align 4
  %local.is.active.655 = load i1, ptr %local.active.23, align 1
  %local.later.offset.656 = load i32, ptr %local.offset.24, align 4
  %stack.sub.657 = sub i32 %local.later.offset.656, %local.old.extent.576
  %stack.offset.658 = add i32 %stack.sub.657, %value.extent.383
  %local.later.offset.selected.659 = select i1 %local.is.active.655, i32 %stack.offset.658, i32 %local.later.offset.656
  store i32 %local.later.offset.selected.659, ptr %local.offset.24, align 4
  %local.is.active.660 = load i1, ptr %local.active.28, align 1
  %local.later.offset.661 = load i32, ptr %local.offset.29, align 4
  %stack.sub.662 = sub i32 %local.later.offset.661, %local.old.extent.576
  %stack.offset.663 = add i32 %stack.sub.662, %value.extent.383
  %local.later.offset.selected.664 = select i1 %local.is.active.660, i32 %stack.offset.663, i32 %local.later.offset.661
  store i32 %local.later.offset.selected.664, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.13, align 1
  store i32 %stack.offset.586, ptr %local.offset.14, align 4
  store i32 %value.extent.383, ptr %local.extent.15, align 4
  store i32 %value.payload.382, ptr %local.payload.16, align 4
  store i32 8, ptr %local.type.17, align 4
  %local.is.active.665 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.666 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.667 = select i1 %local.is.active.665, i32 %local.sum.extent.666, i32 0
  %stack.offset.668 = add i32 0, %local.sum.selected.667
  %local.is.active.669 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.670 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.671 = select i1 %local.is.active.669, i32 %local.sum.extent.670, i32 0
  %stack.offset.672 = add i32 %stack.offset.668, %local.sum.selected.671
  %local.is.active.673 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.674 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.675 = select i1 %local.is.active.673, i32 %local.sum.extent.674, i32 0
  %stack.offset.676 = add i32 %stack.offset.672, %local.sum.selected.675
  %local.is.active.677 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.678 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.679 = select i1 %local.is.active.677, i32 %local.sum.extent.678, i32 0
  %stack.offset.680 = add i32 %stack.offset.676, %local.sum.selected.679
  %local.is.active.681 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.682 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.683 = select i1 %local.is.active.681, i32 %local.sum.extent.682, i32 0
  %stack.offset.684 = add i32 %stack.offset.680, %local.sum.selected.683
  %local.is.active.685 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.686 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.687 = select i1 %local.is.active.685, i32 %local.sum.extent.686, i32 0
  %stack.offset.688 = add i32 %stack.offset.684, %local.sum.selected.687
  %stack.offset.689 = add i32 %stack.offset.688, 0
  %stack.offset.690 = add i32 %context.value.45, %stack.offset.689
  %cursor.status.691 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.690)
  %cursor.ok.692 = icmp eq i32 %cursor.status.691, 0
  br i1 %cursor.ok.692, label %cursor.continue.693, label %frame.failure.0
cursor.continue.693:
  %step.status.694 = call i32 @al_owning_charge_step(ptr %ctx, i32 158)
  %helper.ok.695 = icmp eq i32 %step.status.694, 0
  br i1 %helper.ok.695, label %helper.continue.696, label %frame.failure.0
helper.continue.696:
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %step.status.697 = call i32 @al_owning_charge_step(ptr %ctx, i32 159)
  %helper.ok.698 = icmp eq i32 %step.status.697, 0
  br i1 %helper.ok.698, label %helper.continue.699, label %frame.failure.0
helper.continue.699:
  %local.source.offset.700 = load i32, ptr %local.offset.4, align 4
  %local.source.extent.701 = load i32, ptr %local.extent.5, align 4
  %local.source.payload.702 = load i32, ptr %local.payload.6, align 4
  %context.field.703 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.704 = load i32, ptr %context.field.703, align 4
  %stack.offset.705 = add i32 %context.value.704, %local.source.extent.701
  %reserve.status.706 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.705, i32 160)
  %reserve.ok.707 = icmp eq i32 %reserve.status.706, 0
  br i1 %reserve.ok.707, label %reserve.continue.708, label %frame.failure.0
reserve.continue.708:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.704, i32 %local.source.offset.700, i32 %local.source.extent.701, i32 %local.source.payload.702, i32 11)
  %context.field.709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.710 = load i32, ptr %context.field.709, align 4
  %runtime.ok.711 = icmp eq i32 %context.value.710, 0
  br i1 %runtime.ok.711, label %runtime.continue.712, label %frame.failure.0
runtime.continue.712:
  %local.is.active.713 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.714 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.715 = select i1 %local.is.active.713, i32 %local.sum.extent.714, i32 0
  %stack.offset.716 = add i32 0, %local.sum.selected.715
  %local.is.active.717 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.718 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.719 = select i1 %local.is.active.717, i32 %local.sum.extent.718, i32 0
  %stack.offset.720 = add i32 %stack.offset.716, %local.sum.selected.719
  %local.is.active.721 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.722 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.723 = select i1 %local.is.active.721, i32 %local.sum.extent.722, i32 0
  %stack.offset.724 = add i32 %stack.offset.720, %local.sum.selected.723
  %local.is.active.725 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.726 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.727 = select i1 %local.is.active.725, i32 %local.sum.extent.726, i32 0
  %stack.offset.728 = add i32 %stack.offset.724, %local.sum.selected.727
  %local.is.active.729 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.730 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.731 = select i1 %local.is.active.729, i32 %local.sum.extent.730, i32 0
  %stack.offset.732 = add i32 %stack.offset.728, %local.sum.selected.731
  %local.is.active.733 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.734 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.735 = select i1 %local.is.active.733, i32 %local.sum.extent.734, i32 0
  %stack.offset.736 = add i32 %stack.offset.732, %local.sum.selected.735
  %stack.offset.737 = add i32 0, %local.source.extent.701
  %stack.offset.738 = add i32 %stack.offset.736, %stack.offset.737
  %stack.offset.739 = add i32 %context.value.45, %stack.offset.738
  %cursor.status.740 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.739)
  %cursor.ok.741 = icmp eq i32 %cursor.status.740, 0
  br i1 %cursor.ok.741, label %cursor.continue.742, label %frame.failure.0
cursor.continue.742:
  %step.status.743 = call i32 @al_owning_charge_step(ptr %ctx, i32 161)
  %helper.ok.744 = icmp eq i32 %step.status.743, 0
  br i1 %helper.ok.744, label %helper.continue.745, label %frame.failure.0
helper.continue.745:
  %local.is.active.746 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.747 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.748 = select i1 %local.is.active.746, i32 %local.sum.extent.747, i32 0
  %stack.offset.749 = add i32 0, %local.sum.selected.748
  %local.is.active.750 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.751 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.752 = select i1 %local.is.active.750, i32 %local.sum.extent.751, i32 0
  %stack.offset.753 = add i32 %stack.offset.749, %local.sum.selected.752
  %local.is.active.754 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.755 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.756 = select i1 %local.is.active.754, i32 %local.sum.extent.755, i32 0
  %stack.offset.757 = add i32 %stack.offset.753, %local.sum.selected.756
  %local.is.active.758 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.759 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.760 = select i1 %local.is.active.758, i32 %local.sum.extent.759, i32 0
  %stack.offset.761 = add i32 %stack.offset.757, %local.sum.selected.760
  %local.is.active.762 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.763 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.764 = select i1 %local.is.active.762, i32 %local.sum.extent.763, i32 0
  %stack.offset.765 = add i32 %stack.offset.761, %local.sum.selected.764
  %local.is.active.766 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.767 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.768 = select i1 %local.is.active.766, i32 %local.sum.extent.767, i32 0
  %stack.offset.769 = add i32 %stack.offset.765, %local.sum.selected.768
  %stack.offset.770 = add i32 %stack.offset.769, 0
  %stack.offset.771 = add i32 %context.value.45, %stack.offset.770
  %field.location.772 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.773 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.771, i32 %local.source.extent.701, i32 0, i32 162, ptr %field.location.772)
  %helper.ok.774 = icmp eq i32 %field.location.status.773, 0
  br i1 %helper.ok.774, label %helper.continue.775, label %frame.failure.0
helper.continue.775:
  %field.offset.pointer.776 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.772, i32 0, i32 0
  %field.offset.777 = load i32, ptr %field.offset.pointer.776, align 4
  %field.payload.pointer.778 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.772, i32 0, i32 1
  %field.payload.779 = load i32, ptr %field.payload.pointer.778, align 4
  %field.extent.pointer.780 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.772, i32 0, i32 2
  %field.extent.781 = load i32, ptr %field.extent.pointer.780, align 4
  %stack.offset.782 = add i32 %stack.offset.771, %field.extent.781
  %context.field.783 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.784 = load i32, ptr %context.field.783, align 4
  %field.result.grows.785 = icmp ugt i32 %stack.offset.782, %context.value.784
  br i1 %field.result.grows.785, label %field.result.reserve.786, label %field.result.existing.787
field.result.reserve.786:
  %reserve.status.789 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.782, i32 163)
  %reserve.ok.790 = icmp eq i32 %reserve.status.789, 0
  br i1 %reserve.ok.790, label %reserve.continue.791, label %frame.failure.0
reserve.continue.791:
  br label %field.result.ready.788
field.result.existing.787:
  br label %field.result.ready.788
field.result.ready.788:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.771, i32 %field.offset.777, i32 %field.extent.781, i32 %field.payload.779, i32 1, i32 7)
  %context.field.792 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.793 = load i32, ptr %context.field.792, align 4
  %runtime.ok.794 = icmp eq i32 %context.value.793, 0
  br i1 %runtime.ok.794, label %runtime.continue.795, label %frame.failure.0
runtime.continue.795:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.782, i32 0, i32 0, i32 0)
  %context.field.796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.797 = load i32, ptr %context.field.796, align 4
  %runtime.ok.798 = icmp eq i32 %context.value.797, 0
  br i1 %runtime.ok.798, label %runtime.continue.799, label %frame.failure.0
runtime.continue.799:
  %stack.sub.800 = sub i32 %field.payload.779, %local.source.payload.702
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.800, i32 0)
  %context.field.801 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.802 = load i32, ptr %context.field.801, align 4
  %runtime.ok.803 = icmp eq i32 %context.value.802, 0
  br i1 %runtime.ok.803, label %runtime.continue.804, label %frame.failure.0
runtime.continue.804:
  %local.is.active.805 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.806 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.807 = select i1 %local.is.active.805, i32 %local.sum.extent.806, i32 0
  %stack.offset.808 = add i32 0, %local.sum.selected.807
  %local.is.active.809 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.810 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.811 = select i1 %local.is.active.809, i32 %local.sum.extent.810, i32 0
  %stack.offset.812 = add i32 %stack.offset.808, %local.sum.selected.811
  %local.is.active.813 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.814 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.815 = select i1 %local.is.active.813, i32 %local.sum.extent.814, i32 0
  %stack.offset.816 = add i32 %stack.offset.812, %local.sum.selected.815
  %local.is.active.817 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.818 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.819 = select i1 %local.is.active.817, i32 %local.sum.extent.818, i32 0
  %stack.offset.820 = add i32 %stack.offset.816, %local.sum.selected.819
  %local.is.active.821 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.822 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.823 = select i1 %local.is.active.821, i32 %local.sum.extent.822, i32 0
  %stack.offset.824 = add i32 %stack.offset.820, %local.sum.selected.823
  %local.is.active.825 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.826 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.827 = select i1 %local.is.active.825, i32 %local.sum.extent.826, i32 0
  %stack.offset.828 = add i32 %stack.offset.824, %local.sum.selected.827
  %stack.offset.829 = add i32 0, %field.extent.781
  %stack.offset.830 = add i32 %stack.offset.828, %stack.offset.829
  %stack.offset.831 = add i32 %context.value.45, %stack.offset.830
  %cursor.status.832 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.831)
  %cursor.ok.833 = icmp eq i32 %cursor.status.832, 0
  br i1 %cursor.ok.833, label %cursor.continue.834, label %frame.failure.0
cursor.continue.834:
  %step.status.835 = call i32 @al_owning_charge_step(ptr %ctx, i32 164)
  %helper.ok.836 = icmp eq i32 %step.status.835, 0
  br i1 %helper.ok.836, label %helper.continue.837, label %frame.failure.0
helper.continue.837:
  %context.field.838 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.839 = load i32, ptr %context.field.838, align 4
  %stack.offset.840 = add i32 %context.value.839, 8
  %reserve.status.841 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.840, i32 165)
  %reserve.ok.842 = icmp eq i32 %reserve.status.841, 0
  br i1 %reserve.ok.842, label %reserve.continue.843, label %frame.failure.0
reserve.continue.843:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.839, i64 1, i32 1)
  %context.field.844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.845 = load i32, ptr %context.field.844, align 4
  %runtime.ok.846 = icmp eq i32 %context.value.845, 0
  br i1 %runtime.ok.846, label %runtime.continue.847, label %frame.failure.0
runtime.continue.847:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.849 = load i32, ptr %context.field.848, align 4
  %runtime.ok.850 = icmp eq i32 %context.value.849, 0
  br i1 %runtime.ok.850, label %runtime.continue.851, label %frame.failure.0
runtime.continue.851:
  %local.is.active.852 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.853 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.854 = select i1 %local.is.active.852, i32 %local.sum.extent.853, i32 0
  %stack.offset.855 = add i32 0, %local.sum.selected.854
  %local.is.active.856 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.857 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.858 = select i1 %local.is.active.856, i32 %local.sum.extent.857, i32 0
  %stack.offset.859 = add i32 %stack.offset.855, %local.sum.selected.858
  %local.is.active.860 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.861 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.862 = select i1 %local.is.active.860, i32 %local.sum.extent.861, i32 0
  %stack.offset.863 = add i32 %stack.offset.859, %local.sum.selected.862
  %local.is.active.864 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.865 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.866 = select i1 %local.is.active.864, i32 %local.sum.extent.865, i32 0
  %stack.offset.867 = add i32 %stack.offset.863, %local.sum.selected.866
  %local.is.active.868 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.869 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.870 = select i1 %local.is.active.868, i32 %local.sum.extent.869, i32 0
  %stack.offset.871 = add i32 %stack.offset.867, %local.sum.selected.870
  %local.is.active.872 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.873 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.874 = select i1 %local.is.active.872, i32 %local.sum.extent.873, i32 0
  %stack.offset.875 = add i32 %stack.offset.871, %local.sum.selected.874
  %stack.offset.876 = add i32 0, %field.extent.781
  %stack.offset.877 = add i32 %stack.offset.876, 8
  %stack.offset.878 = add i32 %stack.offset.875, %stack.offset.877
  %stack.offset.879 = add i32 %context.value.45, %stack.offset.878
  %cursor.status.880 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.879)
  %cursor.ok.881 = icmp eq i32 %cursor.status.880, 0
  br i1 %cursor.ok.881, label %cursor.continue.882, label %frame.failure.0
cursor.continue.882:
  %step.status.883 = call i32 @al_owning_charge_step(ptr %ctx, i32 166)
  %helper.ok.884 = icmp eq i32 %step.status.883, 0
  br i1 %helper.ok.884, label %helper.continue.885, label %frame.failure.0
helper.continue.885:
  %context.field.886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.887 = load i32, ptr %context.field.886, align 4
  %stack.sub.888 = sub i32 %context.value.887, 8
  %stack.sub.889 = sub i32 %stack.sub.888, %field.extent.781
  %integer.left.890 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.889)
  %context.field.892 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.893 = load i32, ptr %context.field.892, align 4
  %runtime.ok.894 = icmp eq i32 %context.value.893, 0
  br i1 %runtime.ok.894, label %runtime.continue.895, label %frame.failure.0
runtime.continue.895:
  %integer.right.891 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.sub.888)
  %context.field.896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.897 = load i32, ptr %context.field.896, align 4
  %runtime.ok.898 = icmp eq i32 %context.value.897, 0
  br i1 %runtime.ok.898, label %runtime.continue.899, label %frame.failure.0
runtime.continue.899:
  %integer.checked.900 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.890, i64 %integer.right.891)
  %integer.result.901 = extractvalue { i64, i1 } %integer.checked.900, 0
  %integer.overflow.902 = extractvalue { i64, i1 } %integer.checked.900, 1
  br i1 %integer.overflow.902, label %integer.overflow.903, label %integer.valid.904
integer.overflow.903:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 167, i32 0, i32 0)
  br label %frame.failure.0
integer.valid.904:
  %context.field.905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.906 = load i32, ptr %context.field.905, align 4
  %stack.sub.907 = sub i32 %context.value.906, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.907, i32 8, i32 8, i32 1)
  %context.field.908 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.909 = load i32, ptr %context.field.908, align 4
  %runtime.ok.910 = icmp eq i32 %context.value.909, 0
  br i1 %runtime.ok.910, label %runtime.continue.911, label %frame.failure.0
runtime.continue.911:
  %context.field.912 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.913 = load i32, ptr %context.field.912, align 4
  %stack.sub.914 = sub i32 %context.value.913, %field.extent.781
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.914, i32 %field.extent.781, i32 %field.payload.779, i32 1)
  %context.field.915 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.916 = load i32, ptr %context.field.915, align 4
  %runtime.ok.917 = icmp eq i32 %context.value.916, 0
  br i1 %runtime.ok.917, label %runtime.continue.918, label %frame.failure.0
runtime.continue.918:
  %context.field.919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.920 = load i32, ptr %context.field.919, align 4
  %stack.offset.921 = add i32 %context.value.920, 8
  %reserve.status.922 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.921, i32 168)
  %reserve.ok.923 = icmp eq i32 %reserve.status.922, 0
  br i1 %reserve.ok.923, label %reserve.continue.924, label %frame.failure.0
reserve.continue.924:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.920, i64 %integer.result.901, i32 1)
  %context.field.925 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.926 = load i32, ptr %context.field.925, align 4
  %runtime.ok.927 = icmp eq i32 %context.value.926, 0
  br i1 %runtime.ok.927, label %runtime.continue.928, label %frame.failure.0
runtime.continue.928:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.929 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.930 = load i32, ptr %context.field.929, align 4
  %runtime.ok.931 = icmp eq i32 %context.value.930, 0
  br i1 %runtime.ok.931, label %runtime.continue.932, label %frame.failure.0
runtime.continue.932:
  %local.is.active.933 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.934 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.935 = select i1 %local.is.active.933, i32 %local.sum.extent.934, i32 0
  %stack.offset.936 = add i32 0, %local.sum.selected.935
  %local.is.active.937 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.938 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.939 = select i1 %local.is.active.937, i32 %local.sum.extent.938, i32 0
  %stack.offset.940 = add i32 %stack.offset.936, %local.sum.selected.939
  %local.is.active.941 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.942 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.943 = select i1 %local.is.active.941, i32 %local.sum.extent.942, i32 0
  %stack.offset.944 = add i32 %stack.offset.940, %local.sum.selected.943
  %local.is.active.945 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.946 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.947 = select i1 %local.is.active.945, i32 %local.sum.extent.946, i32 0
  %stack.offset.948 = add i32 %stack.offset.944, %local.sum.selected.947
  %local.is.active.949 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.950 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.951 = select i1 %local.is.active.949, i32 %local.sum.extent.950, i32 0
  %stack.offset.952 = add i32 %stack.offset.948, %local.sum.selected.951
  %local.is.active.953 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.954 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.955 = select i1 %local.is.active.953, i32 %local.sum.extent.954, i32 0
  %stack.offset.956 = add i32 %stack.offset.952, %local.sum.selected.955
  %stack.offset.957 = add i32 0, 8
  %stack.offset.958 = add i32 %stack.offset.956, %stack.offset.957
  %stack.offset.959 = add i32 %context.value.45, %stack.offset.958
  %cursor.status.960 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.959)
  %cursor.ok.961 = icmp eq i32 %cursor.status.960, 0
  br i1 %cursor.ok.961, label %cursor.continue.962, label %frame.failure.0
cursor.continue.962:
  %step.status.963 = call i32 @al_owning_charge_step(ptr %ctx, i32 169)
  %helper.ok.964 = icmp eq i32 %step.status.963, 0
  br i1 %helper.ok.964, label %helper.continue.965, label %frame.failure.0
helper.continue.965:
  %local.is.active.966 = load i1, ptr %local.active.23, align 1
  %local.previous.extent.967 = load i32, ptr %local.extent.25, align 4
  %local.previous.payload.968 = load i32, ptr %local.payload.26, align 4
  %local.old.extent.969 = select i1 %local.is.active.966, i32 %local.previous.extent.967, i32 0
  %local.old.payload.970 = select i1 %local.is.active.966, i32 %local.previous.payload.968, i32 0
  %local.is.active.971 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.972 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.973 = select i1 %local.is.active.971, i32 %local.sum.extent.972, i32 0
  %stack.offset.974 = add i32 0, %local.sum.selected.973
  %local.is.active.975 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.976 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.977 = select i1 %local.is.active.975, i32 %local.sum.extent.976, i32 0
  %stack.offset.978 = add i32 %stack.offset.974, %local.sum.selected.977
  %local.is.active.979 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.980 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.981 = select i1 %local.is.active.979, i32 %local.sum.extent.980, i32 0
  %stack.offset.982 = add i32 %stack.offset.978, %local.sum.selected.981
  %local.is.active.983 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.984 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.985 = select i1 %local.is.active.983, i32 %local.sum.extent.984, i32 0
  %stack.offset.986 = add i32 %stack.offset.982, %local.sum.selected.985
  %stack.offset.987 = add i32 %context.value.45, %stack.offset.986
  %stack.offset.988 = add i32 %stack.offset.987, %local.old.extent.969
  %context.field.989 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.990 = load i32, ptr %context.field.989, align 4
  %stack.sub.991 = sub i32 %context.value.990, %stack.offset.988
  %stack.sub.992 = sub i32 %context.value.990, %local.old.extent.969
  %stack.offset.993 = add i32 %stack.sub.992, 8
  %local.grows.994 = icmp ugt i32 8, %local.old.extent.969
  br i1 %local.grows.994, label %local.grow.995, label %local.fixed.996
local.grow.995:
  %reserve.status.998 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.993, i32 170)
  %reserve.ok.999 = icmp eq i32 %reserve.status.998, 0
  br i1 %reserve.ok.999, label %reserve.continue.1000, label %frame.failure.0
reserve.continue.1000:
  %stack.sub.1001 = sub i32 8, %local.old.extent.969
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.1001)
  %context.field.1002 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1003 = load i32, ptr %context.field.1002, align 4
  %runtime.ok.1004 = icmp eq i32 %context.value.1003, 0
  br i1 %runtime.ok.1004, label %runtime.continue.1005, label %frame.failure.0
runtime.continue.1005:
  br label %local.layout.ready.997
local.fixed.996:
  br label %local.layout.ready.997
local.layout.ready.997:
  %stack.offset.1006 = add i32 %stack.offset.987, 8
  %local.is.active.1007 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1008 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1009 = select i1 %local.is.active.1007, i32 %local.suffix.payload.1008, i32 0
  %stack.offset.1010 = add i32 0, %local.suffix.selected.1009
  %stack.offset.1011 = add i32 0, 8
  %stack.offset.1012 = add i32 %stack.offset.1010, %stack.offset.1011
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1006, i32 %stack.offset.988, i32 %stack.sub.991, i32 %stack.offset.1012, i32 0, i32 14)
  %context.field.1013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1014 = load i32, ptr %context.field.1013, align 4
  %runtime.ok.1015 = icmp eq i32 %context.value.1014, 0
  br i1 %runtime.ok.1015, label %runtime.continue.1016, label %frame.failure.0
runtime.continue.1016:
  %stack.sub.1017 = sub i32 %context.value.990, 8
  %stack.sub.1018 = sub i32 %stack.sub.1017, %local.old.extent.969
  %stack.offset.1019 = add i32 %stack.sub.1018, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.987, i32 %stack.offset.1019, i32 8, i32 8, i32 1, i32 4)
  %context.field.1020 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1021 = load i32, ptr %context.field.1020, align 4
  %runtime.ok.1022 = icmp eq i32 %context.value.1021, 0
  br i1 %runtime.ok.1022, label %runtime.continue.1023, label %frame.failure.0
runtime.continue.1023:
  %stack.sub.1024 = sub i32 %context.value.990, %local.old.extent.969
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1024, i32 0, i32 0, i32 0)
  %context.field.1025 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1026 = load i32, ptr %context.field.1025, align 4
  %runtime.ok.1027 = icmp eq i32 %context.value.1026, 0
  br i1 %runtime.ok.1027, label %runtime.continue.1028, label %frame.failure.0
runtime.continue.1028:
  %local.shrinks.1029 = icmp ult i32 8, %local.old.extent.969
  br i1 %local.shrinks.1029, label %local.shrink.1030, label %local.counts.ready.1031
local.shrink.1030:
  %stack.sub.1032 = sub i32 %local.old.extent.969, 8
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1032)
  %context.field.1033 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1034 = load i32, ptr %context.field.1033, align 4
  %runtime.ok.1035 = icmp eq i32 %context.value.1034, 0
  br i1 %runtime.ok.1035, label %runtime.continue.1036, label %frame.failure.0
runtime.continue.1036:
  br label %local.counts.ready.1031
local.counts.ready.1031:
  %local.payload.delta.1037 = sub i32 8, %local.old.payload.970
  %stack.sub.1038 = sub i32 0, %local.old.payload.970
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1038, i32 %local.payload.delta.1037)
  %context.field.1039 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1040 = load i32, ptr %context.field.1039, align 4
  %runtime.ok.1041 = icmp eq i32 %context.value.1040, 0
  br i1 %runtime.ok.1041, label %runtime.continue.1042, label %frame.failure.0
runtime.continue.1042:
  %local.is.active.1043 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1044 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1045 = sub i32 %local.later.offset.1044, %local.old.extent.969
  %stack.offset.1046 = add i32 %stack.sub.1045, 8
  %local.later.offset.selected.1047 = select i1 %local.is.active.1043, i32 %stack.offset.1046, i32 %local.later.offset.1044
  store i32 %local.later.offset.selected.1047, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.23, align 1
  store i32 %stack.offset.987, ptr %local.offset.24, align 4
  store i32 8, ptr %local.extent.25, align 4
  store i32 8, ptr %local.payload.26, align 4
  store i32 1, ptr %local.type.27, align 4
  %local.is.active.1048 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1049 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1050 = select i1 %local.is.active.1048, i32 %local.sum.extent.1049, i32 0
  %stack.offset.1051 = add i32 0, %local.sum.selected.1050
  %local.is.active.1052 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1053 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1054 = select i1 %local.is.active.1052, i32 %local.sum.extent.1053, i32 0
  %stack.offset.1055 = add i32 %stack.offset.1051, %local.sum.selected.1054
  %local.is.active.1056 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1057 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1058 = select i1 %local.is.active.1056, i32 %local.sum.extent.1057, i32 0
  %stack.offset.1059 = add i32 %stack.offset.1055, %local.sum.selected.1058
  %local.is.active.1060 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1061 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1062 = select i1 %local.is.active.1060, i32 %local.sum.extent.1061, i32 0
  %stack.offset.1063 = add i32 %stack.offset.1059, %local.sum.selected.1062
  %local.is.active.1064 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1065 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1066 = select i1 %local.is.active.1064, i32 %local.sum.extent.1065, i32 0
  %stack.offset.1067 = add i32 %stack.offset.1063, %local.sum.selected.1066
  %local.is.active.1068 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1069 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1070 = select i1 %local.is.active.1068, i32 %local.sum.extent.1069, i32 0
  %stack.offset.1071 = add i32 %stack.offset.1067, %local.sum.selected.1070
  %stack.offset.1072 = add i32 %stack.offset.1071, 0
  %stack.offset.1073 = add i32 %context.value.45, %stack.offset.1072
  %cursor.status.1074 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1073)
  %cursor.ok.1075 = icmp eq i32 %cursor.status.1074, 0
  br i1 %cursor.ok.1075, label %cursor.continue.1076, label %frame.failure.0
cursor.continue.1076:
  %step.status.1077 = call i32 @al_owning_charge_step(ptr %ctx, i32 171)
  %helper.ok.1078 = icmp eq i32 %step.status.1077, 0
  br i1 %helper.ok.1078, label %helper.continue.1079, label %frame.failure.0
helper.continue.1079:
  %local.source.offset.1080 = load i32, ptr %local.offset.14, align 4
  %local.source.extent.1081 = load i32, ptr %local.extent.15, align 4
  %local.source.payload.1082 = load i32, ptr %local.payload.16, align 4
  %context.field.1083 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1084 = load i32, ptr %context.field.1083, align 4
  %stack.offset.1085 = add i32 %context.value.1084, %local.source.extent.1081
  %reserve.status.1086 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1085, i32 172)
  %reserve.ok.1087 = icmp eq i32 %reserve.status.1086, 0
  br i1 %reserve.ok.1087, label %reserve.continue.1088, label %frame.failure.0
reserve.continue.1088:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1084, i32 %local.source.offset.1080, i32 %local.source.extent.1081, i32 %local.source.payload.1082, i32 8)
  %context.field.1089 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1090 = load i32, ptr %context.field.1089, align 4
  %runtime.ok.1091 = icmp eq i32 %context.value.1090, 0
  br i1 %runtime.ok.1091, label %runtime.continue.1092, label %frame.failure.0
runtime.continue.1092:
  %local.is.active.1093 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1094 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1095 = select i1 %local.is.active.1093, i32 %local.sum.extent.1094, i32 0
  %stack.offset.1096 = add i32 0, %local.sum.selected.1095
  %local.is.active.1097 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1098 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1099 = select i1 %local.is.active.1097, i32 %local.sum.extent.1098, i32 0
  %stack.offset.1100 = add i32 %stack.offset.1096, %local.sum.selected.1099
  %local.is.active.1101 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1102 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1103 = select i1 %local.is.active.1101, i32 %local.sum.extent.1102, i32 0
  %stack.offset.1104 = add i32 %stack.offset.1100, %local.sum.selected.1103
  %local.is.active.1105 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1106 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1107 = select i1 %local.is.active.1105, i32 %local.sum.extent.1106, i32 0
  %stack.offset.1108 = add i32 %stack.offset.1104, %local.sum.selected.1107
  %local.is.active.1109 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1110 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1111 = select i1 %local.is.active.1109, i32 %local.sum.extent.1110, i32 0
  %stack.offset.1112 = add i32 %stack.offset.1108, %local.sum.selected.1111
  %local.is.active.1113 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1114 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1115 = select i1 %local.is.active.1113, i32 %local.sum.extent.1114, i32 0
  %stack.offset.1116 = add i32 %stack.offset.1112, %local.sum.selected.1115
  %stack.offset.1117 = add i32 0, %local.source.extent.1081
  %stack.offset.1118 = add i32 %stack.offset.1116, %stack.offset.1117
  %stack.offset.1119 = add i32 %context.value.45, %stack.offset.1118
  %cursor.status.1120 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1119)
  %cursor.ok.1121 = icmp eq i32 %cursor.status.1120, 0
  br i1 %cursor.ok.1121, label %cursor.continue.1122, label %frame.failure.0
cursor.continue.1122:
  %step.status.1123 = call i32 @al_owning_charge_step(ptr %ctx, i32 173)
  %helper.ok.1124 = icmp eq i32 %step.status.1123, 0
  br i1 %helper.ok.1124, label %helper.continue.1125, label %frame.failure.0
helper.continue.1125:
  %local.is.active.1126 = load i1, ptr %local.active.28, align 1
  %local.previous.extent.1127 = load i32, ptr %local.extent.30, align 4
  %local.previous.payload.1128 = load i32, ptr %local.payload.31, align 4
  %local.old.extent.1129 = select i1 %local.is.active.1126, i32 %local.previous.extent.1127, i32 0
  %local.old.payload.1130 = select i1 %local.is.active.1126, i32 %local.previous.payload.1128, i32 0
  %local.is.active.1131 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1132 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1133 = select i1 %local.is.active.1131, i32 %local.sum.extent.1132, i32 0
  %stack.offset.1134 = add i32 0, %local.sum.selected.1133
  %local.is.active.1135 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1136 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1137 = select i1 %local.is.active.1135, i32 %local.sum.extent.1136, i32 0
  %stack.offset.1138 = add i32 %stack.offset.1134, %local.sum.selected.1137
  %local.is.active.1139 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1140 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1141 = select i1 %local.is.active.1139, i32 %local.sum.extent.1140, i32 0
  %stack.offset.1142 = add i32 %stack.offset.1138, %local.sum.selected.1141
  %local.is.active.1143 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1144 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1145 = select i1 %local.is.active.1143, i32 %local.sum.extent.1144, i32 0
  %stack.offset.1146 = add i32 %stack.offset.1142, %local.sum.selected.1145
  %local.is.active.1147 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1148 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1149 = select i1 %local.is.active.1147, i32 %local.sum.extent.1148, i32 0
  %stack.offset.1150 = add i32 %stack.offset.1146, %local.sum.selected.1149
  %stack.offset.1151 = add i32 %context.value.45, %stack.offset.1150
  %stack.offset.1152 = add i32 %stack.offset.1151, %local.old.extent.1129
  %context.field.1153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1154 = load i32, ptr %context.field.1153, align 4
  %stack.sub.1155 = sub i32 %context.value.1154, %stack.offset.1152
  %stack.sub.1156 = sub i32 %context.value.1154, %local.old.extent.1129
  %stack.offset.1157 = add i32 %stack.sub.1156, %local.source.extent.1081
  %local.grows.1158 = icmp ugt i32 %local.source.extent.1081, %local.old.extent.1129
  br i1 %local.grows.1158, label %local.grow.1159, label %local.fixed.1160
local.grow.1159:
  %reserve.status.1162 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1157, i32 174)
  %reserve.ok.1163 = icmp eq i32 %reserve.status.1162, 0
  br i1 %reserve.ok.1163, label %reserve.continue.1164, label %frame.failure.0
reserve.continue.1164:
  %stack.sub.1165 = sub i32 %local.source.extent.1081, %local.old.extent.1129
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.1165)
  %context.field.1166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1167 = load i32, ptr %context.field.1166, align 4
  %runtime.ok.1168 = icmp eq i32 %context.value.1167, 0
  br i1 %runtime.ok.1168, label %runtime.continue.1169, label %frame.failure.0
runtime.continue.1169:
  br label %local.layout.ready.1161
local.fixed.1160:
  br label %local.layout.ready.1161
local.layout.ready.1161:
  %stack.offset.1170 = add i32 %stack.offset.1151, %local.source.extent.1081
  %stack.offset.1171 = add i32 0, %local.source.payload.1082
  %stack.offset.1172 = add i32 0, %stack.offset.1171
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1170, i32 %stack.offset.1152, i32 %stack.sub.1155, i32 %stack.offset.1172, i32 0, i32 14)
  %context.field.1173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1174 = load i32, ptr %context.field.1173, align 4
  %runtime.ok.1175 = icmp eq i32 %context.value.1174, 0
  br i1 %runtime.ok.1175, label %runtime.continue.1176, label %frame.failure.0
runtime.continue.1176:
  %stack.sub.1177 = sub i32 %context.value.1154, %local.source.extent.1081
  %stack.sub.1178 = sub i32 %stack.sub.1177, %local.old.extent.1129
  %stack.offset.1179 = add i32 %stack.sub.1178, %local.source.extent.1081
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1151, i32 %stack.offset.1179, i32 %local.source.extent.1081, i32 %local.source.payload.1082, i32 8, i32 4)
  %context.field.1180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1181 = load i32, ptr %context.field.1180, align 4
  %runtime.ok.1182 = icmp eq i32 %context.value.1181, 0
  br i1 %runtime.ok.1182, label %runtime.continue.1183, label %frame.failure.0
runtime.continue.1183:
  %stack.sub.1184 = sub i32 %context.value.1154, %local.old.extent.1129
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1184, i32 0, i32 0, i32 0)
  %context.field.1185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1186 = load i32, ptr %context.field.1185, align 4
  %runtime.ok.1187 = icmp eq i32 %context.value.1186, 0
  br i1 %runtime.ok.1187, label %runtime.continue.1188, label %frame.failure.0
runtime.continue.1188:
  %local.shrinks.1189 = icmp ult i32 %local.source.extent.1081, %local.old.extent.1129
  br i1 %local.shrinks.1189, label %local.shrink.1190, label %local.counts.ready.1191
local.shrink.1190:
  %stack.sub.1192 = sub i32 %local.old.extent.1129, %local.source.extent.1081
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1192)
  %context.field.1193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1194 = load i32, ptr %context.field.1193, align 4
  %runtime.ok.1195 = icmp eq i32 %context.value.1194, 0
  br i1 %runtime.ok.1195, label %runtime.continue.1196, label %frame.failure.0
runtime.continue.1196:
  br label %local.counts.ready.1191
local.counts.ready.1191:
  %local.payload.delta.1197 = sub i32 %local.source.payload.1082, %local.old.payload.1130
  %stack.sub.1198 = sub i32 0, %local.old.payload.1130
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1198, i32 %local.payload.delta.1197)
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %runtime.ok.1201 = icmp eq i32 %context.value.1200, 0
  br i1 %runtime.ok.1201, label %runtime.continue.1202, label %frame.failure.0
runtime.continue.1202:
  store i1 true, ptr %local.active.28, align 1
  store i32 %stack.offset.1151, ptr %local.offset.29, align 4
  store i32 %local.source.extent.1081, ptr %local.extent.30, align 4
  store i32 %local.source.payload.1082, ptr %local.payload.31, align 4
  store i32 8, ptr %local.type.32, align 4
  %local.is.active.1203 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1204 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1205 = select i1 %local.is.active.1203, i32 %local.sum.extent.1204, i32 0
  %stack.offset.1206 = add i32 0, %local.sum.selected.1205
  %local.is.active.1207 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1208 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1209 = select i1 %local.is.active.1207, i32 %local.sum.extent.1208, i32 0
  %stack.offset.1210 = add i32 %stack.offset.1206, %local.sum.selected.1209
  %local.is.active.1211 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1212 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1213 = select i1 %local.is.active.1211, i32 %local.sum.extent.1212, i32 0
  %stack.offset.1214 = add i32 %stack.offset.1210, %local.sum.selected.1213
  %local.is.active.1215 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1216 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1217 = select i1 %local.is.active.1215, i32 %local.sum.extent.1216, i32 0
  %stack.offset.1218 = add i32 %stack.offset.1214, %local.sum.selected.1217
  %local.is.active.1219 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1220 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1221 = select i1 %local.is.active.1219, i32 %local.sum.extent.1220, i32 0
  %stack.offset.1222 = add i32 %stack.offset.1218, %local.sum.selected.1221
  %local.is.active.1223 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1224 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1225 = select i1 %local.is.active.1223, i32 %local.sum.extent.1224, i32 0
  %stack.offset.1226 = add i32 %stack.offset.1222, %local.sum.selected.1225
  %stack.offset.1227 = add i32 %stack.offset.1226, 0
  %stack.offset.1228 = add i32 %context.value.45, %stack.offset.1227
  %cursor.status.1229 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1228)
  %cursor.ok.1230 = icmp eq i32 %cursor.status.1229, 0
  br i1 %cursor.ok.1230, label %cursor.continue.1231, label %frame.failure.0
cursor.continue.1231:
  %step.status.1232 = call i32 @al_owning_charge_step(ptr %ctx, i32 175)
  %helper.ok.1233 = icmp eq i32 %step.status.1232, 0
  br i1 %helper.ok.1233, label %helper.continue.1234, label %frame.failure.0
helper.continue.1234:
  %local.source.offset.1235 = load i32, ptr %local.offset.24, align 4
  %local.source.extent.1236 = load i32, ptr %local.extent.25, align 4
  %local.source.payload.1237 = load i32, ptr %local.payload.26, align 4
  %context.field.1238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1239 = load i32, ptr %context.field.1238, align 4
  %stack.offset.1240 = add i32 %context.value.1239, %local.source.extent.1236
  %reserve.status.1241 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1240, i32 176)
  %reserve.ok.1242 = icmp eq i32 %reserve.status.1241, 0
  br i1 %reserve.ok.1242, label %reserve.continue.1243, label %frame.failure.0
reserve.continue.1243:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1239, i32 %local.source.offset.1235, i32 %local.source.extent.1236, i32 %local.source.payload.1237, i32 1)
  %context.field.1244 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1245 = load i32, ptr %context.field.1244, align 4
  %runtime.ok.1246 = icmp eq i32 %context.value.1245, 0
  br i1 %runtime.ok.1246, label %runtime.continue.1247, label %frame.failure.0
runtime.continue.1247:
  %local.is.active.1248 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1249 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1250 = select i1 %local.is.active.1248, i32 %local.sum.extent.1249, i32 0
  %stack.offset.1251 = add i32 0, %local.sum.selected.1250
  %local.is.active.1252 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1253 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1254 = select i1 %local.is.active.1252, i32 %local.sum.extent.1253, i32 0
  %stack.offset.1255 = add i32 %stack.offset.1251, %local.sum.selected.1254
  %local.is.active.1256 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1257 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1258 = select i1 %local.is.active.1256, i32 %local.sum.extent.1257, i32 0
  %stack.offset.1259 = add i32 %stack.offset.1255, %local.sum.selected.1258
  %local.is.active.1260 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1261 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1262 = select i1 %local.is.active.1260, i32 %local.sum.extent.1261, i32 0
  %stack.offset.1263 = add i32 %stack.offset.1259, %local.sum.selected.1262
  %local.is.active.1264 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1265 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1266 = select i1 %local.is.active.1264, i32 %local.sum.extent.1265, i32 0
  %stack.offset.1267 = add i32 %stack.offset.1263, %local.sum.selected.1266
  %local.is.active.1268 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1269 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1270 = select i1 %local.is.active.1268, i32 %local.sum.extent.1269, i32 0
  %stack.offset.1271 = add i32 %stack.offset.1267, %local.sum.selected.1270
  %stack.offset.1272 = add i32 0, %local.source.extent.1236
  %stack.offset.1273 = add i32 %stack.offset.1271, %stack.offset.1272
  %stack.offset.1274 = add i32 %context.value.45, %stack.offset.1273
  %cursor.status.1275 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1274)
  %cursor.ok.1276 = icmp eq i32 %cursor.status.1275, 0
  br i1 %cursor.ok.1276, label %cursor.continue.1277, label %frame.failure.0
cursor.continue.1277:
  %step.status.1278 = call i32 @al_owning_charge_step(ptr %ctx, i32 177)
  %helper.ok.1279 = icmp eq i32 %step.status.1278, 0
  br i1 %helper.ok.1279, label %helper.continue.1280, label %frame.failure.0
helper.continue.1280:
  %local.source.offset.1281 = load i32, ptr %local.offset.29, align 4
  %local.source.extent.1282 = load i32, ptr %local.extent.30, align 4
  %local.source.payload.1283 = load i32, ptr %local.payload.31, align 4
  %context.field.1284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1285 = load i32, ptr %context.field.1284, align 4
  %stack.offset.1286 = add i32 %context.value.1285, %local.source.extent.1282
  %reserve.status.1287 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1286, i32 178)
  %reserve.ok.1288 = icmp eq i32 %reserve.status.1287, 0
  br i1 %reserve.ok.1288, label %reserve.continue.1289, label %frame.failure.0
reserve.continue.1289:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1285, i32 %local.source.offset.1281, i32 %local.source.extent.1282, i32 %local.source.payload.1283, i32 8)
  %context.field.1290 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1291 = load i32, ptr %context.field.1290, align 4
  %runtime.ok.1292 = icmp eq i32 %context.value.1291, 0
  br i1 %runtime.ok.1292, label %runtime.continue.1293, label %frame.failure.0
runtime.continue.1293:
  %local.is.active.1294 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1295 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1296 = select i1 %local.is.active.1294, i32 %local.sum.extent.1295, i32 0
  %stack.offset.1297 = add i32 0, %local.sum.selected.1296
  %local.is.active.1298 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1299 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1300 = select i1 %local.is.active.1298, i32 %local.sum.extent.1299, i32 0
  %stack.offset.1301 = add i32 %stack.offset.1297, %local.sum.selected.1300
  %local.is.active.1302 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1303 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1304 = select i1 %local.is.active.1302, i32 %local.sum.extent.1303, i32 0
  %stack.offset.1305 = add i32 %stack.offset.1301, %local.sum.selected.1304
  %local.is.active.1306 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1307 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1308 = select i1 %local.is.active.1306, i32 %local.sum.extent.1307, i32 0
  %stack.offset.1309 = add i32 %stack.offset.1305, %local.sum.selected.1308
  %local.is.active.1310 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1311 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1312 = select i1 %local.is.active.1310, i32 %local.sum.extent.1311, i32 0
  %stack.offset.1313 = add i32 %stack.offset.1309, %local.sum.selected.1312
  %local.is.active.1314 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1315 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1316 = select i1 %local.is.active.1314, i32 %local.sum.extent.1315, i32 0
  %stack.offset.1317 = add i32 %stack.offset.1313, %local.sum.selected.1316
  %stack.offset.1318 = add i32 0, %local.source.extent.1236
  %stack.offset.1319 = add i32 %stack.offset.1318, %local.source.extent.1282
  %stack.offset.1320 = add i32 %stack.offset.1317, %stack.offset.1319
  %stack.offset.1321 = add i32 %context.value.45, %stack.offset.1320
  %cursor.status.1322 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1321)
  %cursor.ok.1323 = icmp eq i32 %cursor.status.1322, 0
  br i1 %cursor.ok.1323, label %cursor.continue.1324, label %frame.failure.0
cursor.continue.1324:
  %step.status.1325 = call i32 @al_owning_charge_step(ptr %ctx, i32 179)
  %helper.ok.1326 = icmp eq i32 %step.status.1325, 0
  br i1 %helper.ok.1326, label %helper.continue.1327, label %frame.failure.0
helper.continue.1327:
  %stack.offset.1328 = add i32 0, %local.source.payload.1237
  %stack.offset.1329 = add i32 %stack.offset.1328, %local.source.payload.1283
  %stack.offset.1330 = add i32 0, %local.source.extent.1236
  %stack.offset.1331 = add i32 %stack.offset.1330, %local.source.extent.1282
  %context.field.1332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1333 = load i32, ptr %context.field.1332, align 4
  %local.is.active.1334 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1335 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1336 = select i1 %local.is.active.1334, i32 %local.sum.extent.1335, i32 0
  %stack.offset.1337 = add i32 0, %local.sum.selected.1336
  %local.is.active.1338 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1339 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1340 = select i1 %local.is.active.1338, i32 %local.sum.extent.1339, i32 0
  %stack.offset.1341 = add i32 %stack.offset.1337, %local.sum.selected.1340
  %local.is.active.1342 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1343 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1344 = select i1 %local.is.active.1342, i32 %local.sum.extent.1343, i32 0
  %stack.offset.1345 = add i32 %stack.offset.1341, %local.sum.selected.1344
  %local.is.active.1346 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1347 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1348 = select i1 %local.is.active.1346, i32 %local.sum.extent.1347, i32 0
  %stack.offset.1349 = add i32 %stack.offset.1345, %local.sum.selected.1348
  %local.is.active.1350 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1351 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1352 = select i1 %local.is.active.1350, i32 %local.sum.extent.1351, i32 0
  %stack.offset.1353 = add i32 %stack.offset.1349, %local.sum.selected.1352
  %local.is.active.1354 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1355 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1356 = select i1 %local.is.active.1354, i32 %local.sum.extent.1355, i32 0
  %stack.offset.1357 = add i32 %stack.offset.1353, %local.sum.selected.1356
  %stack.offset.1358 = add i32 %stack.offset.1357, 0
  %stack.offset.1359 = add i32 %context.value.45, %stack.offset.1358
  %stack.offset.1360 = add i32 %context.value.1333, %stack.offset.1331
  %reserve.status.1361 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1360, i32 180)
  %reserve.ok.1362 = icmp eq i32 %reserve.status.1361, 0
  br i1 %reserve.ok.1362, label %reserve.continue.1363, label %frame.failure.0
reserve.continue.1363:
  %local.is.active.1364 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1365 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1366 = select i1 %local.is.active.1364, i32 %local.sum.extent.1365, i32 0
  %stack.offset.1367 = add i32 0, %local.sum.selected.1366
  %local.is.active.1368 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1369 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1370 = select i1 %local.is.active.1368, i32 %local.sum.extent.1369, i32 0
  %stack.offset.1371 = add i32 %stack.offset.1367, %local.sum.selected.1370
  %local.is.active.1372 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1373 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1374 = select i1 %local.is.active.1372, i32 %local.sum.extent.1373, i32 0
  %stack.offset.1375 = add i32 %stack.offset.1371, %local.sum.selected.1374
  %local.is.active.1376 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1377 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1378 = select i1 %local.is.active.1376, i32 %local.sum.extent.1377, i32 0
  %stack.offset.1379 = add i32 %stack.offset.1375, %local.sum.selected.1378
  %local.is.active.1380 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1381 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1382 = select i1 %local.is.active.1380, i32 %local.sum.extent.1381, i32 0
  %stack.offset.1383 = add i32 %stack.offset.1379, %local.sum.selected.1382
  %local.is.active.1384 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1385 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1386 = select i1 %local.is.active.1384, i32 %local.sum.extent.1385, i32 0
  %stack.offset.1387 = add i32 %stack.offset.1383, %local.sum.selected.1386
  %stack.offset.1388 = add i32 %stack.offset.1387, 0
  %stack.offset.1389 = add i32 %context.value.45, %stack.offset.1388
  %stack.offset.1390 = add i32 %context.value.1333, 0
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1390, i32 %stack.offset.1389, i32 %local.source.extent.1236, i32 %local.source.payload.1237, i32 1, i32 6)
  %context.field.1391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1392 = load i32, ptr %context.field.1391, align 4
  %runtime.ok.1393 = icmp eq i32 %context.value.1392, 0
  br i1 %runtime.ok.1393, label %runtime.continue.1394, label %frame.failure.0
runtime.continue.1394:
  %stack.offset.1395 = add i32 0, %local.source.extent.1236
  %local.is.active.1396 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1397 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1398 = select i1 %local.is.active.1396, i32 %local.sum.extent.1397, i32 0
  %stack.offset.1399 = add i32 0, %local.sum.selected.1398
  %local.is.active.1400 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1401 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1402 = select i1 %local.is.active.1400, i32 %local.sum.extent.1401, i32 0
  %stack.offset.1403 = add i32 %stack.offset.1399, %local.sum.selected.1402
  %local.is.active.1404 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1405 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1406 = select i1 %local.is.active.1404, i32 %local.sum.extent.1405, i32 0
  %stack.offset.1407 = add i32 %stack.offset.1403, %local.sum.selected.1406
  %local.is.active.1408 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1409 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1410 = select i1 %local.is.active.1408, i32 %local.sum.extent.1409, i32 0
  %stack.offset.1411 = add i32 %stack.offset.1407, %local.sum.selected.1410
  %local.is.active.1412 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1413 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1414 = select i1 %local.is.active.1412, i32 %local.sum.extent.1413, i32 0
  %stack.offset.1415 = add i32 %stack.offset.1411, %local.sum.selected.1414
  %local.is.active.1416 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1417 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1418 = select i1 %local.is.active.1416, i32 %local.sum.extent.1417, i32 0
  %stack.offset.1419 = add i32 %stack.offset.1415, %local.sum.selected.1418
  %stack.offset.1420 = add i32 0, %local.source.extent.1236
  %stack.offset.1421 = add i32 %stack.offset.1419, %stack.offset.1420
  %stack.offset.1422 = add i32 %context.value.45, %stack.offset.1421
  %stack.offset.1423 = add i32 %context.value.1333, %stack.offset.1395
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1423, i32 %stack.offset.1422, i32 %local.source.extent.1282, i32 %local.source.payload.1283, i32 8, i32 6)
  %context.field.1424 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1425 = load i32, ptr %context.field.1424, align 4
  %runtime.ok.1426 = icmp eq i32 %context.value.1425, 0
  br i1 %runtime.ok.1426, label %runtime.continue.1427, label %frame.failure.0
runtime.continue.1427:
  %stack.offset.1428 = add i32 %stack.offset.1395, %local.source.extent.1282
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1359, i32 %context.value.1333, i32 %stack.offset.1331, i32 %stack.offset.1329, i32 11, i32 6)
  %context.field.1429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1430 = load i32, ptr %context.field.1429, align 4
  %runtime.ok.1431 = icmp eq i32 %context.value.1430, 0
  br i1 %runtime.ok.1431, label %runtime.continue.1432, label %frame.failure.0
runtime.continue.1432:
  %stack.offset.1433 = add i32 %stack.offset.1359, %stack.offset.1331
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1433, i32 0, i32 0, i32 0)
  %context.field.1434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1435 = load i32, ptr %context.field.1434, align 4
  %runtime.ok.1436 = icmp eq i32 %context.value.1435, 0
  br i1 %runtime.ok.1436, label %runtime.continue.1437, label %frame.failure.0
runtime.continue.1437:
  %stack.offset.1438 = add i32 0, %local.source.payload.1237
  %stack.offset.1439 = add i32 %stack.offset.1438, %local.source.payload.1283
  %stack.sub.1440 = sub i32 %stack.offset.1329, %stack.offset.1439
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1440, i32 0)
  %context.field.1441 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1442 = load i32, ptr %context.field.1441, align 4
  %runtime.ok.1443 = icmp eq i32 %context.value.1442, 0
  br i1 %runtime.ok.1443, label %runtime.continue.1444, label %frame.failure.0
runtime.continue.1444:
  %local.is.active.1445 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1446 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1447 = select i1 %local.is.active.1445, i32 %local.sum.extent.1446, i32 0
  %stack.offset.1448 = add i32 0, %local.sum.selected.1447
  %local.is.active.1449 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1450 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1451 = select i1 %local.is.active.1449, i32 %local.sum.extent.1450, i32 0
  %stack.offset.1452 = add i32 %stack.offset.1448, %local.sum.selected.1451
  %local.is.active.1453 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1454 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1455 = select i1 %local.is.active.1453, i32 %local.sum.extent.1454, i32 0
  %stack.offset.1456 = add i32 %stack.offset.1452, %local.sum.selected.1455
  %local.is.active.1457 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1458 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1459 = select i1 %local.is.active.1457, i32 %local.sum.extent.1458, i32 0
  %stack.offset.1460 = add i32 %stack.offset.1456, %local.sum.selected.1459
  %local.is.active.1461 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1462 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1463 = select i1 %local.is.active.1461, i32 %local.sum.extent.1462, i32 0
  %stack.offset.1464 = add i32 %stack.offset.1460, %local.sum.selected.1463
  %local.is.active.1465 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1466 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1467 = select i1 %local.is.active.1465, i32 %local.sum.extent.1466, i32 0
  %stack.offset.1468 = add i32 %stack.offset.1464, %local.sum.selected.1467
  %stack.offset.1469 = add i32 0, %stack.offset.1331
  %stack.offset.1470 = add i32 %stack.offset.1468, %stack.offset.1469
  %stack.offset.1471 = add i32 %context.value.45, %stack.offset.1470
  %cursor.status.1472 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1471)
  %cursor.ok.1473 = icmp eq i32 %cursor.status.1472, 0
  br i1 %cursor.ok.1473, label %cursor.continue.1474, label %frame.failure.0
cursor.continue.1474:
  %local.is.active.1475 = load i1, ptr %local.active.28, align 1
  br i1 %local.is.active.1475, label %local.remove.1476, label %local.keep.1477
local.keep.1477:
  br label %local.removed.1478
local.remove.1476:
  %local.remove.offset.1479 = load i32, ptr %local.offset.29, align 4
  %local.remove.extent.1480 = load i32, ptr %local.extent.30, align 4
  %local.remove.payload.1481 = load i32, ptr %local.payload.31, align 4
  %local.remove.type.1482 = load i32, ptr %local.type.32, align 4
  %stack.offset.1483 = add i32 %local.remove.offset.1479, %local.remove.extent.1480
  %context.field.1484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1485 = load i32, ptr %context.field.1484, align 4
  %stack.sub.1486 = sub i32 %context.value.1485, %stack.offset.1483
  %stack.offset.1487 = add i32 0, %stack.offset.1329
  %stack.offset.1488 = add i32 0, %stack.offset.1487
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1479, i32 %stack.offset.1483, i32 %stack.sub.1486, i32 %stack.offset.1488, i32 0, i32 14)
  %context.field.1489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1490 = load i32, ptr %context.field.1489, align 4
  %runtime.ok.1491 = icmp eq i32 %context.value.1490, 0
  br i1 %runtime.ok.1491, label %runtime.continue.1492, label %frame.failure.0
runtime.continue.1492:
  %stack.sub.1493 = sub i32 %context.value.1485, %local.remove.extent.1480
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1493, i32 0, i32 0, i32 0)
  %context.field.1494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1495 = load i32, ptr %context.field.1494, align 4
  %runtime.ok.1496 = icmp eq i32 %context.value.1495, 0
  br i1 %runtime.ok.1496, label %runtime.continue.1497, label %frame.failure.0
runtime.continue.1497:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1482, i32 %local.remove.offset.1479, i32 %local.remove.extent.1480, i32 %local.remove.payload.1481, i32 0, i32 0)
  %context.field.1498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1499 = load i32, ptr %context.field.1498, align 4
  %runtime.ok.1500 = icmp eq i32 %context.value.1499, 0
  br i1 %runtime.ok.1500, label %runtime.continue.1501, label %frame.failure.0
runtime.continue.1501:
  %stack.sub.1502 = sub i32 0, %local.remove.payload.1481
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1502, i32 %stack.sub.1502)
  %context.field.1503 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1504 = load i32, ptr %context.field.1503, align 4
  %runtime.ok.1505 = icmp eq i32 %context.value.1504, 0
  br i1 %runtime.ok.1505, label %runtime.continue.1506, label %frame.failure.0
runtime.continue.1506:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1480)
  %context.field.1507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1508 = load i32, ptr %context.field.1507, align 4
  %runtime.ok.1509 = icmp eq i32 %context.value.1508, 0
  br i1 %runtime.ok.1509, label %runtime.continue.1510, label %frame.failure.0
runtime.continue.1510:
  store i1 false, ptr %local.active.28, align 1
  store i32 0, ptr %local.offset.29, align 4
  store i32 0, ptr %local.extent.30, align 4
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  br label %local.removed.1478
local.removed.1478:
  %local.is.active.1511 = load i1, ptr %local.active.23, align 1
  br i1 %local.is.active.1511, label %local.remove.1512, label %local.keep.1513
local.keep.1513:
  br label %local.removed.1514
local.remove.1512:
  %local.remove.offset.1515 = load i32, ptr %local.offset.24, align 4
  %local.remove.extent.1516 = load i32, ptr %local.extent.25, align 4
  %local.remove.payload.1517 = load i32, ptr %local.payload.26, align 4
  %local.remove.type.1518 = load i32, ptr %local.type.27, align 4
  %stack.offset.1519 = add i32 %local.remove.offset.1515, %local.remove.extent.1516
  %context.field.1520 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1521 = load i32, ptr %context.field.1520, align 4
  %stack.sub.1522 = sub i32 %context.value.1521, %stack.offset.1519
  %local.is.active.1523 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1524 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1525 = select i1 %local.is.active.1523, i32 %local.suffix.payload.1524, i32 0
  %stack.offset.1526 = add i32 0, %local.suffix.selected.1525
  %stack.offset.1527 = add i32 0, %stack.offset.1329
  %stack.offset.1528 = add i32 %stack.offset.1526, %stack.offset.1527
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1515, i32 %stack.offset.1519, i32 %stack.sub.1522, i32 %stack.offset.1528, i32 0, i32 14)
  %context.field.1529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1530 = load i32, ptr %context.field.1529, align 4
  %runtime.ok.1531 = icmp eq i32 %context.value.1530, 0
  br i1 %runtime.ok.1531, label %runtime.continue.1532, label %frame.failure.0
runtime.continue.1532:
  %stack.sub.1533 = sub i32 %context.value.1521, %local.remove.extent.1516
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1533, i32 0, i32 0, i32 0)
  %context.field.1534 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1535 = load i32, ptr %context.field.1534, align 4
  %runtime.ok.1536 = icmp eq i32 %context.value.1535, 0
  br i1 %runtime.ok.1536, label %runtime.continue.1537, label %frame.failure.0
runtime.continue.1537:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1518, i32 %local.remove.offset.1515, i32 %local.remove.extent.1516, i32 %local.remove.payload.1517, i32 0, i32 0)
  %context.field.1538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1539 = load i32, ptr %context.field.1538, align 4
  %runtime.ok.1540 = icmp eq i32 %context.value.1539, 0
  br i1 %runtime.ok.1540, label %runtime.continue.1541, label %frame.failure.0
runtime.continue.1541:
  %stack.sub.1542 = sub i32 0, %local.remove.payload.1517
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1542, i32 %stack.sub.1542)
  %context.field.1543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1544 = load i32, ptr %context.field.1543, align 4
  %runtime.ok.1545 = icmp eq i32 %context.value.1544, 0
  br i1 %runtime.ok.1545, label %runtime.continue.1546, label %frame.failure.0
runtime.continue.1546:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1516)
  %context.field.1547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1548 = load i32, ptr %context.field.1547, align 4
  %runtime.ok.1549 = icmp eq i32 %context.value.1548, 0
  br i1 %runtime.ok.1549, label %runtime.continue.1550, label %frame.failure.0
runtime.continue.1550:
  %local.is.active.1551 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1552 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1553 = sub i32 %local.later.offset.1552, %local.remove.extent.1516
  %local.later.offset.selected.1554 = select i1 %local.is.active.1551, i32 %stack.sub.1553, i32 %local.later.offset.1552
  store i32 %local.later.offset.selected.1554, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.23, align 1
  store i32 0, ptr %local.offset.24, align 4
  store i32 0, ptr %local.extent.25, align 4
  store i32 0, ptr %local.payload.26, align 4
  store i32 0, ptr %local.type.27, align 4
  br label %local.removed.1514
local.removed.1514:
  %local.is.active.1555 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1556 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1557 = select i1 %local.is.active.1555, i32 %local.sum.extent.1556, i32 0
  %stack.offset.1558 = add i32 0, %local.sum.selected.1557
  %local.is.active.1559 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1560 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1561 = select i1 %local.is.active.1559, i32 %local.sum.extent.1560, i32 0
  %stack.offset.1562 = add i32 %stack.offset.1558, %local.sum.selected.1561
  %local.is.active.1563 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1564 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1565 = select i1 %local.is.active.1563, i32 %local.sum.extent.1564, i32 0
  %stack.offset.1566 = add i32 %stack.offset.1562, %local.sum.selected.1565
  %local.is.active.1567 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1568 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1569 = select i1 %local.is.active.1567, i32 %local.sum.extent.1568, i32 0
  %stack.offset.1570 = add i32 %stack.offset.1566, %local.sum.selected.1569
  %local.is.active.1571 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1572 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1573 = select i1 %local.is.active.1571, i32 %local.sum.extent.1572, i32 0
  %stack.offset.1574 = add i32 %stack.offset.1570, %local.sum.selected.1573
  %local.is.active.1575 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1576 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1577 = select i1 %local.is.active.1575, i32 %local.sum.extent.1576, i32 0
  %stack.offset.1578 = add i32 %stack.offset.1574, %local.sum.selected.1577
  %stack.offset.1579 = add i32 0, %stack.offset.1331
  %stack.offset.1580 = add i32 %stack.offset.1578, %stack.offset.1579
  %stack.offset.1581 = add i32 %context.value.45, %stack.offset.1580
  %cursor.status.1582 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1581)
  %cursor.ok.1583 = icmp eq i32 %cursor.status.1582, 0
  br i1 %cursor.ok.1583, label %cursor.continue.1584, label %frame.failure.0
cursor.continue.1584:
  %step.status.1585 = call i32 @al_owning_charge_step(ptr %ctx, i32 181)
  %helper.ok.1586 = icmp eq i32 %step.status.1585, 0
  br i1 %helper.ok.1586, label %helper.continue.1587, label %frame.failure.0
helper.continue.1587:
  %local.is.active.1588 = load i1, ptr %local.active.18, align 1
  %local.previous.extent.1589 = load i32, ptr %local.extent.20, align 4
  %local.previous.payload.1590 = load i32, ptr %local.payload.21, align 4
  %local.old.extent.1591 = select i1 %local.is.active.1588, i32 %local.previous.extent.1589, i32 0
  %local.old.payload.1592 = select i1 %local.is.active.1588, i32 %local.previous.payload.1590, i32 0
  %local.is.active.1593 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1594 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1595 = select i1 %local.is.active.1593, i32 %local.sum.extent.1594, i32 0
  %stack.offset.1596 = add i32 0, %local.sum.selected.1595
  %local.is.active.1597 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1598 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1599 = select i1 %local.is.active.1597, i32 %local.sum.extent.1598, i32 0
  %stack.offset.1600 = add i32 %stack.offset.1596, %local.sum.selected.1599
  %local.is.active.1601 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1602 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1603 = select i1 %local.is.active.1601, i32 %local.sum.extent.1602, i32 0
  %stack.offset.1604 = add i32 %stack.offset.1600, %local.sum.selected.1603
  %stack.offset.1605 = add i32 %context.value.45, %stack.offset.1604
  %stack.offset.1606 = add i32 %stack.offset.1605, %local.old.extent.1591
  %context.field.1607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1608 = load i32, ptr %context.field.1607, align 4
  %stack.sub.1609 = sub i32 %context.value.1608, %stack.offset.1606
  %stack.sub.1610 = sub i32 %context.value.1608, %local.old.extent.1591
  %stack.offset.1611 = add i32 %stack.sub.1610, %stack.offset.1331
  %local.grows.1612 = icmp ugt i32 %stack.offset.1331, %local.old.extent.1591
  br i1 %local.grows.1612, label %local.grow.1613, label %local.fixed.1614
local.grow.1613:
  %reserve.status.1616 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1611, i32 182)
  %reserve.ok.1617 = icmp eq i32 %reserve.status.1616, 0
  br i1 %reserve.ok.1617, label %reserve.continue.1618, label %frame.failure.0
reserve.continue.1618:
  %stack.sub.1619 = sub i32 %stack.offset.1331, %local.old.extent.1591
  call void @al_owning_local_reserve(ptr %ctx, i32 %stack.sub.1619)
  %context.field.1620 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1621 = load i32, ptr %context.field.1620, align 4
  %runtime.ok.1622 = icmp eq i32 %context.value.1621, 0
  br i1 %runtime.ok.1622, label %runtime.continue.1623, label %frame.failure.0
runtime.continue.1623:
  br label %local.layout.ready.1615
local.fixed.1614:
  br label %local.layout.ready.1615
local.layout.ready.1615:
  %stack.offset.1624 = add i32 %stack.offset.1605, %stack.offset.1331
  %local.is.active.1625 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1626 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1627 = select i1 %local.is.active.1625, i32 %local.suffix.payload.1626, i32 0
  %stack.offset.1628 = add i32 0, %local.suffix.selected.1627
  %local.is.active.1629 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1630 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1631 = select i1 %local.is.active.1629, i32 %local.suffix.payload.1630, i32 0
  %stack.offset.1632 = add i32 %stack.offset.1628, %local.suffix.selected.1631
  %stack.offset.1633 = add i32 0, %stack.offset.1329
  %stack.offset.1634 = add i32 %stack.offset.1632, %stack.offset.1633
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1624, i32 %stack.offset.1606, i32 %stack.sub.1609, i32 %stack.offset.1634, i32 0, i32 14)
  %context.field.1635 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1636 = load i32, ptr %context.field.1635, align 4
  %runtime.ok.1637 = icmp eq i32 %context.value.1636, 0
  br i1 %runtime.ok.1637, label %runtime.continue.1638, label %frame.failure.0
runtime.continue.1638:
  %stack.sub.1639 = sub i32 %context.value.1608, %stack.offset.1331
  %stack.sub.1640 = sub i32 %stack.sub.1639, %local.old.extent.1591
  %stack.offset.1641 = add i32 %stack.sub.1640, %stack.offset.1331
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1605, i32 %stack.offset.1641, i32 %stack.offset.1331, i32 %stack.offset.1329, i32 11, i32 4)
  %context.field.1642 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1643 = load i32, ptr %context.field.1642, align 4
  %runtime.ok.1644 = icmp eq i32 %context.value.1643, 0
  br i1 %runtime.ok.1644, label %runtime.continue.1645, label %frame.failure.0
runtime.continue.1645:
  %stack.sub.1646 = sub i32 %context.value.1608, %local.old.extent.1591
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1646, i32 0, i32 0, i32 0)
  %context.field.1647 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1648 = load i32, ptr %context.field.1647, align 4
  %runtime.ok.1649 = icmp eq i32 %context.value.1648, 0
  br i1 %runtime.ok.1649, label %runtime.continue.1650, label %frame.failure.0
runtime.continue.1650:
  %local.shrinks.1651 = icmp ult i32 %stack.offset.1331, %local.old.extent.1591
  br i1 %local.shrinks.1651, label %local.shrink.1652, label %local.counts.ready.1653
local.shrink.1652:
  %stack.sub.1654 = sub i32 %local.old.extent.1591, %stack.offset.1331
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1654)
  %context.field.1655 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1656 = load i32, ptr %context.field.1655, align 4
  %runtime.ok.1657 = icmp eq i32 %context.value.1656, 0
  br i1 %runtime.ok.1657, label %runtime.continue.1658, label %frame.failure.0
runtime.continue.1658:
  br label %local.counts.ready.1653
local.counts.ready.1653:
  %local.payload.delta.1659 = sub i32 %stack.offset.1329, %local.old.payload.1592
  %stack.sub.1660 = sub i32 0, %local.old.payload.1592
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1660, i32 %local.payload.delta.1659)
  %context.field.1661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1662 = load i32, ptr %context.field.1661, align 4
  %runtime.ok.1663 = icmp eq i32 %context.value.1662, 0
  br i1 %runtime.ok.1663, label %runtime.continue.1664, label %frame.failure.0
runtime.continue.1664:
  %local.is.active.1665 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1666 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1667 = sub i32 %local.later.offset.1666, %local.old.extent.1591
  %stack.offset.1668 = add i32 %stack.sub.1667, %stack.offset.1331
  %local.later.offset.selected.1669 = select i1 %local.is.active.1665, i32 %stack.offset.1668, i32 %local.later.offset.1666
  store i32 %local.later.offset.selected.1669, ptr %local.offset.24, align 4
  %local.is.active.1670 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1671 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1672 = sub i32 %local.later.offset.1671, %local.old.extent.1591
  %stack.offset.1673 = add i32 %stack.sub.1672, %stack.offset.1331
  %local.later.offset.selected.1674 = select i1 %local.is.active.1670, i32 %stack.offset.1673, i32 %local.later.offset.1671
  store i32 %local.later.offset.selected.1674, ptr %local.offset.29, align 4
  store i1 true, ptr %local.active.18, align 1
  store i32 %stack.offset.1605, ptr %local.offset.19, align 4
  store i32 %stack.offset.1331, ptr %local.extent.20, align 4
  store i32 %stack.offset.1329, ptr %local.payload.21, align 4
  store i32 11, ptr %local.type.22, align 4
  %local.is.active.1675 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1676 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1677 = select i1 %local.is.active.1675, i32 %local.sum.extent.1676, i32 0
  %stack.offset.1678 = add i32 0, %local.sum.selected.1677
  %local.is.active.1679 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1680 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1681 = select i1 %local.is.active.1679, i32 %local.sum.extent.1680, i32 0
  %stack.offset.1682 = add i32 %stack.offset.1678, %local.sum.selected.1681
  %local.is.active.1683 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1684 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1685 = select i1 %local.is.active.1683, i32 %local.sum.extent.1684, i32 0
  %stack.offset.1686 = add i32 %stack.offset.1682, %local.sum.selected.1685
  %local.is.active.1687 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1688 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1689 = select i1 %local.is.active.1687, i32 %local.sum.extent.1688, i32 0
  %stack.offset.1690 = add i32 %stack.offset.1686, %local.sum.selected.1689
  %local.is.active.1691 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1692 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1693 = select i1 %local.is.active.1691, i32 %local.sum.extent.1692, i32 0
  %stack.offset.1694 = add i32 %stack.offset.1690, %local.sum.selected.1693
  %local.is.active.1695 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1696 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1697 = select i1 %local.is.active.1695, i32 %local.sum.extent.1696, i32 0
  %stack.offset.1698 = add i32 %stack.offset.1694, %local.sum.selected.1697
  %stack.offset.1699 = add i32 %stack.offset.1698, 0
  %stack.offset.1700 = add i32 %context.value.45, %stack.offset.1699
  %cursor.status.1701 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1700)
  %cursor.ok.1702 = icmp eq i32 %cursor.status.1701, 0
  br i1 %cursor.ok.1702, label %cursor.continue.1703, label %frame.failure.0
cursor.continue.1703:
  %step.status.1704 = call i32 @al_owning_charge_step(ptr %ctx, i32 183)
  %helper.ok.1705 = icmp eq i32 %step.status.1704, 0
  br i1 %helper.ok.1705, label %helper.continue.1706, label %frame.failure.0
helper.continue.1706:
  %local.source.offset.1707 = load i32, ptr %local.offset.19, align 4
  %local.source.extent.1708 = load i32, ptr %local.extent.20, align 4
  %local.source.payload.1709 = load i32, ptr %local.payload.21, align 4
  %context.field.1710 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1711 = load i32, ptr %context.field.1710, align 4
  %stack.offset.1712 = add i32 %context.value.1711, %local.source.extent.1708
  %reserve.status.1713 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1712, i32 184)
  %reserve.ok.1714 = icmp eq i32 %reserve.status.1713, 0
  br i1 %reserve.ok.1714, label %reserve.continue.1715, label %frame.failure.0
reserve.continue.1715:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1711, i32 %local.source.offset.1707, i32 %local.source.extent.1708, i32 %local.source.payload.1709, i32 11)
  %context.field.1716 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1717 = load i32, ptr %context.field.1716, align 4
  %runtime.ok.1718 = icmp eq i32 %context.value.1717, 0
  br i1 %runtime.ok.1718, label %runtime.continue.1719, label %frame.failure.0
runtime.continue.1719:
  %local.is.active.1720 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1721 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1722 = select i1 %local.is.active.1720, i32 %local.sum.extent.1721, i32 0
  %stack.offset.1723 = add i32 0, %local.sum.selected.1722
  %local.is.active.1724 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1725 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1726 = select i1 %local.is.active.1724, i32 %local.sum.extent.1725, i32 0
  %stack.offset.1727 = add i32 %stack.offset.1723, %local.sum.selected.1726
  %local.is.active.1728 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1729 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1730 = select i1 %local.is.active.1728, i32 %local.sum.extent.1729, i32 0
  %stack.offset.1731 = add i32 %stack.offset.1727, %local.sum.selected.1730
  %local.is.active.1732 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1733 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1734 = select i1 %local.is.active.1732, i32 %local.sum.extent.1733, i32 0
  %stack.offset.1735 = add i32 %stack.offset.1731, %local.sum.selected.1734
  %local.is.active.1736 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1737 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1738 = select i1 %local.is.active.1736, i32 %local.sum.extent.1737, i32 0
  %stack.offset.1739 = add i32 %stack.offset.1735, %local.sum.selected.1738
  %local.is.active.1740 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1741 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1742 = select i1 %local.is.active.1740, i32 %local.sum.extent.1741, i32 0
  %stack.offset.1743 = add i32 %stack.offset.1739, %local.sum.selected.1742
  %stack.offset.1744 = add i32 0, %local.source.extent.1708
  %stack.offset.1745 = add i32 %stack.offset.1743, %stack.offset.1744
  %stack.offset.1746 = add i32 %context.value.45, %stack.offset.1745
  %cursor.status.1747 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1746)
  %cursor.ok.1748 = icmp eq i32 %cursor.status.1747, 0
  br i1 %cursor.ok.1748, label %cursor.continue.1749, label %frame.failure.0
cursor.continue.1749:
  %step.status.1750 = call i32 @al_owning_charge_step(ptr %ctx, i32 185)
  %helper.ok.1751 = icmp eq i32 %step.status.1750, 0
  br i1 %helper.ok.1751, label %helper.continue.1752, label %frame.failure.0
helper.continue.1752:
  %local.source.offset.1753 = load i32, ptr %local.offset.9, align 4
  %local.source.extent.1754 = load i32, ptr %local.extent.10, align 4
  %local.source.payload.1755 = load i32, ptr %local.payload.11, align 4
  %context.field.1756 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1757 = load i32, ptr %context.field.1756, align 4
  %stack.offset.1758 = add i32 %context.value.1757, %local.source.extent.1754
  %reserve.status.1759 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1758, i32 186)
  %reserve.ok.1760 = icmp eq i32 %reserve.status.1759, 0
  br i1 %reserve.ok.1760, label %reserve.continue.1761, label %frame.failure.0
reserve.continue.1761:
  call void @al_owning_load_local(ptr %ctx, i32 %context.value.1757, i32 %local.source.offset.1753, i32 %local.source.extent.1754, i32 %local.source.payload.1755, i32 1)
  %context.field.1762 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1763 = load i32, ptr %context.field.1762, align 4
  %runtime.ok.1764 = icmp eq i32 %context.value.1763, 0
  br i1 %runtime.ok.1764, label %runtime.continue.1765, label %frame.failure.0
runtime.continue.1765:
  %local.is.active.1766 = load i1, ptr %local.active.3, align 1
  %local.sum.extent.1767 = load i32, ptr %local.extent.5, align 4
  %local.sum.selected.1768 = select i1 %local.is.active.1766, i32 %local.sum.extent.1767, i32 0
  %stack.offset.1769 = add i32 0, %local.sum.selected.1768
  %local.is.active.1770 = load i1, ptr %local.active.8, align 1
  %local.sum.extent.1771 = load i32, ptr %local.extent.10, align 4
  %local.sum.selected.1772 = select i1 %local.is.active.1770, i32 %local.sum.extent.1771, i32 0
  %stack.offset.1773 = add i32 %stack.offset.1769, %local.sum.selected.1772
  %local.is.active.1774 = load i1, ptr %local.active.13, align 1
  %local.sum.extent.1775 = load i32, ptr %local.extent.15, align 4
  %local.sum.selected.1776 = select i1 %local.is.active.1774, i32 %local.sum.extent.1775, i32 0
  %stack.offset.1777 = add i32 %stack.offset.1773, %local.sum.selected.1776
  %local.is.active.1778 = load i1, ptr %local.active.18, align 1
  %local.sum.extent.1779 = load i32, ptr %local.extent.20, align 4
  %local.sum.selected.1780 = select i1 %local.is.active.1778, i32 %local.sum.extent.1779, i32 0
  %stack.offset.1781 = add i32 %stack.offset.1777, %local.sum.selected.1780
  %local.is.active.1782 = load i1, ptr %local.active.23, align 1
  %local.sum.extent.1783 = load i32, ptr %local.extent.25, align 4
  %local.sum.selected.1784 = select i1 %local.is.active.1782, i32 %local.sum.extent.1783, i32 0
  %stack.offset.1785 = add i32 %stack.offset.1781, %local.sum.selected.1784
  %local.is.active.1786 = load i1, ptr %local.active.28, align 1
  %local.sum.extent.1787 = load i32, ptr %local.extent.30, align 4
  %local.sum.selected.1788 = select i1 %local.is.active.1786, i32 %local.sum.extent.1787, i32 0
  %stack.offset.1789 = add i32 %stack.offset.1785, %local.sum.selected.1788
  %stack.offset.1790 = add i32 0, %local.source.extent.1708
  %stack.offset.1791 = add i32 %stack.offset.1790, %local.source.extent.1754
  %stack.offset.1792 = add i32 %stack.offset.1789, %stack.offset.1791
  %stack.offset.1793 = add i32 %context.value.45, %stack.offset.1792
  %cursor.status.1794 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1793)
  %cursor.ok.1795 = icmp eq i32 %cursor.status.1794, 0
  br i1 %cursor.ok.1795, label %cursor.continue.1796, label %frame.failure.0
cursor.continue.1796:
  %local.is.active.1797 = load i1, ptr %local.active.18, align 1
  br i1 %local.is.active.1797, label %local.remove.1798, label %local.keep.1799
local.keep.1799:
  br label %local.removed.1800
local.remove.1798:
  %local.remove.offset.1801 = load i32, ptr %local.offset.19, align 4
  %local.remove.extent.1802 = load i32, ptr %local.extent.20, align 4
  %local.remove.payload.1803 = load i32, ptr %local.payload.21, align 4
  %local.remove.type.1804 = load i32, ptr %local.type.22, align 4
  %stack.offset.1805 = add i32 %local.remove.offset.1801, %local.remove.extent.1802
  %context.field.1806 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1807 = load i32, ptr %context.field.1806, align 4
  %stack.sub.1808 = sub i32 %context.value.1807, %stack.offset.1805
  %local.is.active.1809 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1810 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1811 = select i1 %local.is.active.1809, i32 %local.suffix.payload.1810, i32 0
  %stack.offset.1812 = add i32 0, %local.suffix.selected.1811
  %local.is.active.1813 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1814 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1815 = select i1 %local.is.active.1813, i32 %local.suffix.payload.1814, i32 0
  %stack.offset.1816 = add i32 %stack.offset.1812, %local.suffix.selected.1815
  %stack.offset.1817 = add i32 0, %local.source.payload.1709
  %stack.offset.1818 = add i32 %stack.offset.1817, %local.source.payload.1755
  %stack.offset.1819 = add i32 %stack.offset.1816, %stack.offset.1818
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1801, i32 %stack.offset.1805, i32 %stack.sub.1808, i32 %stack.offset.1819, i32 0, i32 14)
  %context.field.1820 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1821 = load i32, ptr %context.field.1820, align 4
  %runtime.ok.1822 = icmp eq i32 %context.value.1821, 0
  br i1 %runtime.ok.1822, label %runtime.continue.1823, label %frame.failure.0
runtime.continue.1823:
  %stack.sub.1824 = sub i32 %context.value.1807, %local.remove.extent.1802
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1824, i32 0, i32 0, i32 0)
  %context.field.1825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1826 = load i32, ptr %context.field.1825, align 4
  %runtime.ok.1827 = icmp eq i32 %context.value.1826, 0
  br i1 %runtime.ok.1827, label %runtime.continue.1828, label %frame.failure.0
runtime.continue.1828:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1804, i32 %local.remove.offset.1801, i32 %local.remove.extent.1802, i32 %local.remove.payload.1803, i32 0, i32 0)
  %context.field.1829 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1830 = load i32, ptr %context.field.1829, align 4
  %runtime.ok.1831 = icmp eq i32 %context.value.1830, 0
  br i1 %runtime.ok.1831, label %runtime.continue.1832, label %frame.failure.0
runtime.continue.1832:
  %stack.sub.1833 = sub i32 0, %local.remove.payload.1803
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1833, i32 %stack.sub.1833)
  %context.field.1834 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1835 = load i32, ptr %context.field.1834, align 4
  %runtime.ok.1836 = icmp eq i32 %context.value.1835, 0
  br i1 %runtime.ok.1836, label %runtime.continue.1837, label %frame.failure.0
runtime.continue.1837:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1802)
  %context.field.1838 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1839 = load i32, ptr %context.field.1838, align 4
  %runtime.ok.1840 = icmp eq i32 %context.value.1839, 0
  br i1 %runtime.ok.1840, label %runtime.continue.1841, label %frame.failure.0
runtime.continue.1841:
  %local.is.active.1842 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1843 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1844 = sub i32 %local.later.offset.1843, %local.remove.extent.1802
  %local.later.offset.selected.1845 = select i1 %local.is.active.1842, i32 %stack.sub.1844, i32 %local.later.offset.1843
  store i32 %local.later.offset.selected.1845, ptr %local.offset.24, align 4
  %local.is.active.1846 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1847 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1848 = sub i32 %local.later.offset.1847, %local.remove.extent.1802
  %local.later.offset.selected.1849 = select i1 %local.is.active.1846, i32 %stack.sub.1848, i32 %local.later.offset.1847
  store i32 %local.later.offset.selected.1849, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.offset.19, align 4
  store i32 0, ptr %local.extent.20, align 4
  store i32 0, ptr %local.payload.21, align 4
  store i32 0, ptr %local.type.22, align 4
  br label %local.removed.1800
local.removed.1800:
  %local.is.active.1850 = load i1, ptr %local.active.13, align 1
  br i1 %local.is.active.1850, label %local.remove.1851, label %local.keep.1852
local.keep.1852:
  br label %local.removed.1853
local.remove.1851:
  %local.remove.offset.1854 = load i32, ptr %local.offset.14, align 4
  %local.remove.extent.1855 = load i32, ptr %local.extent.15, align 4
  %local.remove.payload.1856 = load i32, ptr %local.payload.16, align 4
  %local.remove.type.1857 = load i32, ptr %local.type.17, align 4
  %stack.offset.1858 = add i32 %local.remove.offset.1854, %local.remove.extent.1855
  %context.field.1859 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1860 = load i32, ptr %context.field.1859, align 4
  %stack.sub.1861 = sub i32 %context.value.1860, %stack.offset.1858
  %local.is.active.1862 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1863 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1864 = select i1 %local.is.active.1862, i32 %local.suffix.payload.1863, i32 0
  %stack.offset.1865 = add i32 0, %local.suffix.selected.1864
  %local.is.active.1866 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1867 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1868 = select i1 %local.is.active.1866, i32 %local.suffix.payload.1867, i32 0
  %stack.offset.1869 = add i32 %stack.offset.1865, %local.suffix.selected.1868
  %local.is.active.1870 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1871 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1872 = select i1 %local.is.active.1870, i32 %local.suffix.payload.1871, i32 0
  %stack.offset.1873 = add i32 %stack.offset.1869, %local.suffix.selected.1872
  %stack.offset.1874 = add i32 0, %local.source.payload.1709
  %stack.offset.1875 = add i32 %stack.offset.1874, %local.source.payload.1755
  %stack.offset.1876 = add i32 %stack.offset.1873, %stack.offset.1875
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1854, i32 %stack.offset.1858, i32 %stack.sub.1861, i32 %stack.offset.1876, i32 0, i32 14)
  %context.field.1877 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1878 = load i32, ptr %context.field.1877, align 4
  %runtime.ok.1879 = icmp eq i32 %context.value.1878, 0
  br i1 %runtime.ok.1879, label %runtime.continue.1880, label %frame.failure.0
runtime.continue.1880:
  %stack.sub.1881 = sub i32 %context.value.1860, %local.remove.extent.1855
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1881, i32 0, i32 0, i32 0)
  %context.field.1882 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1883 = load i32, ptr %context.field.1882, align 4
  %runtime.ok.1884 = icmp eq i32 %context.value.1883, 0
  br i1 %runtime.ok.1884, label %runtime.continue.1885, label %frame.failure.0
runtime.continue.1885:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1857, i32 %local.remove.offset.1854, i32 %local.remove.extent.1855, i32 %local.remove.payload.1856, i32 0, i32 0)
  %context.field.1886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1887 = load i32, ptr %context.field.1886, align 4
  %runtime.ok.1888 = icmp eq i32 %context.value.1887, 0
  br i1 %runtime.ok.1888, label %runtime.continue.1889, label %frame.failure.0
runtime.continue.1889:
  %stack.sub.1890 = sub i32 0, %local.remove.payload.1856
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1890, i32 %stack.sub.1890)
  %context.field.1891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1892 = load i32, ptr %context.field.1891, align 4
  %runtime.ok.1893 = icmp eq i32 %context.value.1892, 0
  br i1 %runtime.ok.1893, label %runtime.continue.1894, label %frame.failure.0
runtime.continue.1894:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1855)
  %context.field.1895 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1896 = load i32, ptr %context.field.1895, align 4
  %runtime.ok.1897 = icmp eq i32 %context.value.1896, 0
  br i1 %runtime.ok.1897, label %runtime.continue.1898, label %frame.failure.0
runtime.continue.1898:
  %local.is.active.1899 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1900 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1901 = sub i32 %local.later.offset.1900, %local.remove.extent.1855
  %local.later.offset.selected.1902 = select i1 %local.is.active.1899, i32 %stack.sub.1901, i32 %local.later.offset.1900
  store i32 %local.later.offset.selected.1902, ptr %local.offset.19, align 4
  %local.is.active.1903 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1904 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1905 = sub i32 %local.later.offset.1904, %local.remove.extent.1855
  %local.later.offset.selected.1906 = select i1 %local.is.active.1903, i32 %stack.sub.1905, i32 %local.later.offset.1904
  store i32 %local.later.offset.selected.1906, ptr %local.offset.24, align 4
  %local.is.active.1907 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1908 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1909 = sub i32 %local.later.offset.1908, %local.remove.extent.1855
  %local.later.offset.selected.1910 = select i1 %local.is.active.1907, i32 %stack.sub.1909, i32 %local.later.offset.1908
  store i32 %local.later.offset.selected.1910, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.13, align 1
  store i32 0, ptr %local.offset.14, align 4
  store i32 0, ptr %local.extent.15, align 4
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  br label %local.removed.1853
local.removed.1853:
  %local.is.active.1911 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1911, label %local.remove.1912, label %local.keep.1913
local.keep.1913:
  br label %local.removed.1914
local.remove.1912:
  %local.remove.offset.1915 = load i32, ptr %local.offset.9, align 4
  %local.remove.extent.1916 = load i32, ptr %local.extent.10, align 4
  %local.remove.payload.1917 = load i32, ptr %local.payload.11, align 4
  %local.remove.type.1918 = load i32, ptr %local.type.12, align 4
  %stack.offset.1919 = add i32 %local.remove.offset.1915, %local.remove.extent.1916
  %context.field.1920 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1921 = load i32, ptr %context.field.1920, align 4
  %stack.sub.1922 = sub i32 %context.value.1921, %stack.offset.1919
  %local.is.active.1923 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1924 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1925 = select i1 %local.is.active.1923, i32 %local.suffix.payload.1924, i32 0
  %stack.offset.1926 = add i32 0, %local.suffix.selected.1925
  %local.is.active.1927 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.1928 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.1929 = select i1 %local.is.active.1927, i32 %local.suffix.payload.1928, i32 0
  %stack.offset.1930 = add i32 %stack.offset.1926, %local.suffix.selected.1929
  %local.is.active.1931 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.1932 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.1933 = select i1 %local.is.active.1931, i32 %local.suffix.payload.1932, i32 0
  %stack.offset.1934 = add i32 %stack.offset.1930, %local.suffix.selected.1933
  %local.is.active.1935 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.1936 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.1937 = select i1 %local.is.active.1935, i32 %local.suffix.payload.1936, i32 0
  %stack.offset.1938 = add i32 %stack.offset.1934, %local.suffix.selected.1937
  %stack.offset.1939 = add i32 0, %local.source.payload.1709
  %stack.offset.1940 = add i32 %stack.offset.1939, %local.source.payload.1755
  %stack.offset.1941 = add i32 %stack.offset.1938, %stack.offset.1940
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1915, i32 %stack.offset.1919, i32 %stack.sub.1922, i32 %stack.offset.1941, i32 0, i32 14)
  %context.field.1942 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1943 = load i32, ptr %context.field.1942, align 4
  %runtime.ok.1944 = icmp eq i32 %context.value.1943, 0
  br i1 %runtime.ok.1944, label %runtime.continue.1945, label %frame.failure.0
runtime.continue.1945:
  %stack.sub.1946 = sub i32 %context.value.1921, %local.remove.extent.1916
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.1946, i32 0, i32 0, i32 0)
  %context.field.1947 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1948 = load i32, ptr %context.field.1947, align 4
  %runtime.ok.1949 = icmp eq i32 %context.value.1948, 0
  br i1 %runtime.ok.1949, label %runtime.continue.1950, label %frame.failure.0
runtime.continue.1950:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1918, i32 %local.remove.offset.1915, i32 %local.remove.extent.1916, i32 %local.remove.payload.1917, i32 0, i32 0)
  %context.field.1951 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1952 = load i32, ptr %context.field.1951, align 4
  %runtime.ok.1953 = icmp eq i32 %context.value.1952, 0
  br i1 %runtime.ok.1953, label %runtime.continue.1954, label %frame.failure.0
runtime.continue.1954:
  %stack.sub.1955 = sub i32 0, %local.remove.payload.1917
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1955, i32 %stack.sub.1955)
  %context.field.1956 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1957 = load i32, ptr %context.field.1956, align 4
  %runtime.ok.1958 = icmp eq i32 %context.value.1957, 0
  br i1 %runtime.ok.1958, label %runtime.continue.1959, label %frame.failure.0
runtime.continue.1959:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1916)
  %context.field.1960 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1961 = load i32, ptr %context.field.1960, align 4
  %runtime.ok.1962 = icmp eq i32 %context.value.1961, 0
  br i1 %runtime.ok.1962, label %runtime.continue.1963, label %frame.failure.0
runtime.continue.1963:
  %local.is.active.1964 = load i1, ptr %local.active.13, align 1
  %local.later.offset.1965 = load i32, ptr %local.offset.14, align 4
  %stack.sub.1966 = sub i32 %local.later.offset.1965, %local.remove.extent.1916
  %local.later.offset.selected.1967 = select i1 %local.is.active.1964, i32 %stack.sub.1966, i32 %local.later.offset.1965
  store i32 %local.later.offset.selected.1967, ptr %local.offset.14, align 4
  %local.is.active.1968 = load i1, ptr %local.active.18, align 1
  %local.later.offset.1969 = load i32, ptr %local.offset.19, align 4
  %stack.sub.1970 = sub i32 %local.later.offset.1969, %local.remove.extent.1916
  %local.later.offset.selected.1971 = select i1 %local.is.active.1968, i32 %stack.sub.1970, i32 %local.later.offset.1969
  store i32 %local.later.offset.selected.1971, ptr %local.offset.19, align 4
  %local.is.active.1972 = load i1, ptr %local.active.23, align 1
  %local.later.offset.1973 = load i32, ptr %local.offset.24, align 4
  %stack.sub.1974 = sub i32 %local.later.offset.1973, %local.remove.extent.1916
  %local.later.offset.selected.1975 = select i1 %local.is.active.1972, i32 %stack.sub.1974, i32 %local.later.offset.1973
  store i32 %local.later.offset.selected.1975, ptr %local.offset.24, align 4
  %local.is.active.1976 = load i1, ptr %local.active.28, align 1
  %local.later.offset.1977 = load i32, ptr %local.offset.29, align 4
  %stack.sub.1978 = sub i32 %local.later.offset.1977, %local.remove.extent.1916
  %local.later.offset.selected.1979 = select i1 %local.is.active.1976, i32 %stack.sub.1978, i32 %local.later.offset.1977
  store i32 %local.later.offset.selected.1979, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.type.12, align 4
  br label %local.removed.1914
local.removed.1914:
  %local.is.active.1980 = load i1, ptr %local.active.3, align 1
  br i1 %local.is.active.1980, label %local.remove.1981, label %local.keep.1982
local.keep.1982:
  br label %local.removed.1983
local.remove.1981:
  %local.remove.offset.1984 = load i32, ptr %local.offset.4, align 4
  %local.remove.extent.1985 = load i32, ptr %local.extent.5, align 4
  %local.remove.payload.1986 = load i32, ptr %local.payload.6, align 4
  %local.remove.type.1987 = load i32, ptr %local.type.7, align 4
  %stack.offset.1988 = add i32 %local.remove.offset.1984, %local.remove.extent.1985
  %context.field.1989 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1990 = load i32, ptr %context.field.1989, align 4
  %stack.sub.1991 = sub i32 %context.value.1990, %stack.offset.1988
  %local.is.active.1992 = load i1, ptr %local.active.8, align 1
  %local.suffix.payload.1993 = load i32, ptr %local.payload.11, align 4
  %local.suffix.selected.1994 = select i1 %local.is.active.1992, i32 %local.suffix.payload.1993, i32 0
  %stack.offset.1995 = add i32 0, %local.suffix.selected.1994
  %local.is.active.1996 = load i1, ptr %local.active.13, align 1
  %local.suffix.payload.1997 = load i32, ptr %local.payload.16, align 4
  %local.suffix.selected.1998 = select i1 %local.is.active.1996, i32 %local.suffix.payload.1997, i32 0
  %stack.offset.1999 = add i32 %stack.offset.1995, %local.suffix.selected.1998
  %local.is.active.2000 = load i1, ptr %local.active.18, align 1
  %local.suffix.payload.2001 = load i32, ptr %local.payload.21, align 4
  %local.suffix.selected.2002 = select i1 %local.is.active.2000, i32 %local.suffix.payload.2001, i32 0
  %stack.offset.2003 = add i32 %stack.offset.1999, %local.suffix.selected.2002
  %local.is.active.2004 = load i1, ptr %local.active.23, align 1
  %local.suffix.payload.2005 = load i32, ptr %local.payload.26, align 4
  %local.suffix.selected.2006 = select i1 %local.is.active.2004, i32 %local.suffix.payload.2005, i32 0
  %stack.offset.2007 = add i32 %stack.offset.2003, %local.suffix.selected.2006
  %local.is.active.2008 = load i1, ptr %local.active.28, align 1
  %local.suffix.payload.2009 = load i32, ptr %local.payload.31, align 4
  %local.suffix.selected.2010 = select i1 %local.is.active.2008, i32 %local.suffix.payload.2009, i32 0
  %stack.offset.2011 = add i32 %stack.offset.2007, %local.suffix.selected.2010
  %stack.offset.2012 = add i32 0, %local.source.payload.1709
  %stack.offset.2013 = add i32 %stack.offset.2012, %local.source.payload.1755
  %stack.offset.2014 = add i32 %stack.offset.2011, %stack.offset.2013
  call void @al_owning_move_range(ptr %ctx, i32 %local.remove.offset.1984, i32 %stack.offset.1988, i32 %stack.sub.1991, i32 %stack.offset.2014, i32 0, i32 14)
  %context.field.2015 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2016 = load i32, ptr %context.field.2015, align 4
  %runtime.ok.2017 = icmp eq i32 %context.value.2016, 0
  br i1 %runtime.ok.2017, label %runtime.continue.2018, label %frame.failure.0
runtime.continue.2018:
  %stack.sub.2019 = sub i32 %context.value.1990, %local.remove.extent.1985
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.2019, i32 0, i32 0, i32 0)
  %context.field.2020 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2021 = load i32, ptr %context.field.2020, align 4
  %runtime.ok.2022 = icmp eq i32 %context.value.2021, 0
  br i1 %runtime.ok.2022, label %runtime.continue.2023, label %frame.failure.0
runtime.continue.2023:
  call void @al_owning_record_layout(ptr %ctx, i32 13, i32 %local.remove.type.1987, i32 %local.remove.offset.1984, i32 %local.remove.extent.1985, i32 %local.remove.payload.1986, i32 0, i32 0)
  %context.field.2024 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2025 = load i32, ptr %context.field.2024, align 4
  %runtime.ok.2026 = icmp eq i32 %context.value.2025, 0
  br i1 %runtime.ok.2026, label %runtime.continue.2027, label %frame.failure.0
runtime.continue.2027:
  %stack.sub.2028 = sub i32 0, %local.remove.payload.1986
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2028, i32 %stack.sub.2028)
  %context.field.2029 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2030 = load i32, ptr %context.field.2029, align 4
  %runtime.ok.2031 = icmp eq i32 %context.value.2030, 0
  br i1 %runtime.ok.2031, label %runtime.continue.2032, label %frame.failure.0
runtime.continue.2032:
  call void @al_owning_local_release(ptr %ctx, i32 %local.remove.extent.1985)
  %context.field.2033 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2034 = load i32, ptr %context.field.2033, align 4
  %runtime.ok.2035 = icmp eq i32 %context.value.2034, 0
  br i1 %runtime.ok.2035, label %runtime.continue.2036, label %frame.failure.0
runtime.continue.2036:
  %local.is.active.2037 = load i1, ptr %local.active.8, align 1
  %local.later.offset.2038 = load i32, ptr %local.offset.9, align 4
  %stack.sub.2039 = sub i32 %local.later.offset.2038, %local.remove.extent.1985
  %local.later.offset.selected.2040 = select i1 %local.is.active.2037, i32 %stack.sub.2039, i32 %local.later.offset.2038
  store i32 %local.later.offset.selected.2040, ptr %local.offset.9, align 4
  %local.is.active.2041 = load i1, ptr %local.active.13, align 1
  %local.later.offset.2042 = load i32, ptr %local.offset.14, align 4
  %stack.sub.2043 = sub i32 %local.later.offset.2042, %local.remove.extent.1985
  %local.later.offset.selected.2044 = select i1 %local.is.active.2041, i32 %stack.sub.2043, i32 %local.later.offset.2042
  store i32 %local.later.offset.selected.2044, ptr %local.offset.14, align 4
  %local.is.active.2045 = load i1, ptr %local.active.18, align 1
  %local.later.offset.2046 = load i32, ptr %local.offset.19, align 4
  %stack.sub.2047 = sub i32 %local.later.offset.2046, %local.remove.extent.1985
  %local.later.offset.selected.2048 = select i1 %local.is.active.2045, i32 %stack.sub.2047, i32 %local.later.offset.2046
  store i32 %local.later.offset.selected.2048, ptr %local.offset.19, align 4
  %local.is.active.2049 = load i1, ptr %local.active.23, align 1
  %local.later.offset.2050 = load i32, ptr %local.offset.24, align 4
  %stack.sub.2051 = sub i32 %local.later.offset.2050, %local.remove.extent.1985
  %local.later.offset.selected.2052 = select i1 %local.is.active.2049, i32 %stack.sub.2051, i32 %local.later.offset.2050
  store i32 %local.later.offset.selected.2052, ptr %local.offset.24, align 4
  %local.is.active.2053 = load i1, ptr %local.active.28, align 1
  %local.later.offset.2054 = load i32, ptr %local.offset.29, align 4
  %stack.sub.2055 = sub i32 %local.later.offset.2054, %local.remove.extent.1985
  %local.later.offset.selected.2056 = select i1 %local.is.active.2053, i32 %stack.sub.2055, i32 %local.later.offset.2054
  store i32 %local.later.offset.selected.2056, ptr %local.offset.29, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.offset.4, align 4
  store i32 0, ptr %local.extent.5, align 4
  store i32 0, ptr %local.payload.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %local.removed.1983
local.removed.1983:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.34, i32 0, i32 0, i32 0)
  %context.field.2057 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.2058 = load i32, ptr %context.field.2057, align 4
  %context.field.2059 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.2060 = load i32, ptr %context.field.2059, align 4
  %context.field.2061 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.2062 = load i32, ptr %context.field.2061, align 4
  %stack.offset.2063 = add i32 %context.value.36, %context.value.38
  %stack.offset.2064 = add i32 %context.value.2058, %context.value.2060
  %stack.sub.2065 = sub i32 %stack.offset.2063, %stack.offset.2064
  %stack.sub.2066 = sub i32 %context.value.38, %context.value.2060
  %stack.sub.2067 = sub i32 %context.value.2062, %context.value.40
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2065, i32 %stack.sub.2066)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2067)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 187, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 187, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 188)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 11, i32 189)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 190)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %value.size.39 = alloca %AlOwningValueSize, align 4
  %measure.status.40 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %stack.offset.36, i32 %context.value.38, i32 191, ptr %value.size.39)
  %helper.ok.41 = icmp eq i32 %measure.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %entry.failure.0
helper.continue.42:
  %value.payload.pointer.43 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 0
  %value.extent.pointer.44 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 1
  %value.payload.45 = load i32, ptr %value.payload.pointer.43, align 4
  %value.extent.46 = load i32, ptr %value.extent.pointer.44, align 4
  %stack.offset.47 = add i32 %stack.offset.36, %value.extent.46
  %stack.offset.48 = add i32 0, %value.payload.45
  %value.size.49 = alloca %AlOwningValueSize, align 4
  %measure.status.50 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 0, i32 %stack.offset.47, i32 %context.value.38, i32 192, ptr %value.size.49)
  %helper.ok.51 = icmp eq i32 %measure.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %entry.failure.0
helper.continue.52:
  %value.payload.pointer.53 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 0
  %value.extent.pointer.54 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.49, i32 0, i32 1
  %value.payload.55 = load i32, ptr %value.payload.pointer.53, align 4
  %value.extent.56 = load i32, ptr %value.extent.pointer.54, align 4
  %stack.offset.57 = add i32 %stack.offset.47, %value.extent.56
  %stack.offset.58 = add i32 %stack.offset.48, %value.payload.55
  %entry.outputs.exact.59 = icmp eq i32 %stack.offset.57, %context.value.38
  br i1 %entry.outputs.exact.59, label %entry.outputs.exact.60, label %entry.failure.0
entry.outputs.exact.60:
  %stack.sub.61 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.61, i32 %stack.offset.58, i32 0, i32 9)
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %runtime.ok.64 = icmp eq i32 %context.value.63, 0
  br i1 %runtime.ok.64, label %runtime.continue.65, label %entry.failure.0
runtime.continue.65:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.61, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %entry.failure.0
runtime.continue.69:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.61, i32 0)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  %stack.sub.74 = sub i32 0, %stack.offset.58
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.74, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %entry.failure.0
runtime.continue.78:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %stack.offset.85 = add i32 %context.value.80, %context.value.82
  %stack.sub.86 = sub i32 0, %stack.offset.85
  %stack.sub.87 = sub i32 0, %context.value.82
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.86, i32 %stack.sub.87)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.84)
  br label %entry.return.status
entry.return.status:
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  ret i32 %context.value.89
}


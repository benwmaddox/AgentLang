%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 8, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %stack.sub.42 = sub i32 %context.value.41, %value.extent.28
  %stack.offset.43 = add i32 %context.value.41, %value.extent.28
  %reserve.status.44 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.43, i32 4)
  %reserve.ok.45 = icmp eq i32 %reserve.status.44, 0
  br i1 %reserve.ok.45, label %reserve.continue.46, label %frame.failure.0
reserve.continue.46:
  call void @al_owning_duplicate(ptr %ctx, i32 %context.value.41, i32 %stack.sub.42, i32 %value.extent.28, i32 %value.payload.27, i32 8)
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %runtime.ok.49 = icmp eq i32 %context.value.48, 0
  br i1 %runtime.ok.49, label %runtime.continue.50, label %frame.failure.0
runtime.continue.50:
  %stack.offset.51 = add i32 0, %value.extent.28
  %stack.offset.52 = add i32 %stack.offset.51, %value.extent.28
  %stack.offset.53 = add i32 0, %stack.offset.52
  %stack.offset.54 = add i32 %context.value.15, %stack.offset.53
  %cursor.status.55 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.54)
  %cursor.ok.56 = icmp eq i32 %cursor.status.55, 0
  br i1 %cursor.ok.56, label %cursor.continue.57, label %frame.failure.0
cursor.continue.57:
  %step.status.58 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.59 = icmp eq i32 %step.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.sub.63 = sub i32 %context.value.62, %value.extent.28
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.63, i32 %value.extent.28, i32 %value.payload.27, i32 8)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %stack.offset.68 = add i32 0, %value.extent.28
  %stack.offset.69 = add i32 0, %stack.offset.68
  %stack.offset.70 = add i32 %context.value.15, %stack.offset.69
  %cursor.status.71 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.70)
  %cursor.ok.72 = icmp eq i32 %cursor.status.71, 0
  br i1 %cursor.ok.72, label %cursor.continue.73, label %frame.failure.0
cursor.continue.73:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %stack.offset.80 = add i32 %context.value.6, %context.value.8
  %stack.offset.81 = add i32 %context.value.75, %context.value.77
  %stack.sub.82 = sub i32 %stack.offset.80, %stack.offset.81
  %stack.sub.83 = sub i32 %context.value.8, %context.value.77
  %stack.sub.84 = sub i32 %context.value.79, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.82, i32 %stack.sub.83)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.84)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 6, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 7)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 8, i32 8)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 9)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %value.size.39 = alloca %AlOwningValueSize, align 4
  %measure.status.40 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %stack.offset.36, i32 %context.value.38, i32 10, ptr %value.size.39)
  %helper.ok.41 = icmp eq i32 %measure.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %entry.failure.0
helper.continue.42:
  %value.payload.pointer.43 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 0
  %value.extent.pointer.44 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.39, i32 0, i32 1
  %value.payload.45 = load i32, ptr %value.payload.pointer.43, align 4
  %value.extent.46 = load i32, ptr %value.extent.pointer.44, align 4
  %stack.offset.47 = add i32 %stack.offset.36, %value.extent.46
  %stack.offset.48 = add i32 0, %value.payload.45
  %entry.outputs.exact.49 = icmp eq i32 %stack.offset.47, %context.value.38
  br i1 %entry.outputs.exact.49, label %entry.outputs.exact.50, label %entry.failure.0
entry.outputs.exact.50:
  %stack.sub.51 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.51, i32 %stack.offset.48, i32 0, i32 9)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %entry.failure.0
runtime.continue.55:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.51, i32 0, i32 0, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.51, i32 8)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %entry.failure.0
runtime.continue.63:
  %stack.sub.64 = sub i32 0, %stack.offset.48
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.64, i32 0)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %entry.failure.0
runtime.continue.68:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.offset.75 = add i32 %context.value.70, %context.value.72
  %stack.sub.76 = sub i32 0, %stack.offset.75
  %stack.sub.77 = sub i32 0, %context.value.72
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.76, i32 %stack.sub.77)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.74)
  br label %entry.return.status
entry.return.status:
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.79 = load i32, ptr %context.field.78, align 4
  ret i32 %context.value.79
}


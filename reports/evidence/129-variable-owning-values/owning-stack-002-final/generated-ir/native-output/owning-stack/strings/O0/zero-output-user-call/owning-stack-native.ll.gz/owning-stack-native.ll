%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 1)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.16, i32 2, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 8, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %stack.offset.40 = add i32 0, 0
  %stack.offset.41 = add i32 %context.value.15, %stack.offset.40
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %stack.offset.45 = add i32 0, %value.extent.28
  %callee.status.44 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.41, i32 %stack.offset.45, i32 4)
  %helper.ok.46 = icmp eq i32 %callee.status.44, 0
  br i1 %helper.ok.46, label %helper.continue.47, label %frame.failure.0
helper.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %callee.outputs.exact.50 = icmp eq i32 %context.value.43, %context.value.49
  br i1 %callee.outputs.exact.50, label %callee.outputs.continue.51, label %frame.failure.0
callee.outputs.continue.51:
  %stack.sub.52 = sub i32 %context.value.49, %context.value.43
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.41, i32 %context.value.43, i32 %stack.sub.52, i32 0, i32 0, i32 9)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %stack.offset.41, %stack.sub.52
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.57, i32 0, i32 0, i32 0)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %stack.offset.62 = add i32 0, 0
  %stack.offset.63 = add i32 %context.value.15, %stack.offset.62
  %cursor.status.64 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.63)
  %cursor.ok.65 = icmp eq i32 %cursor.status.64, 0
  br i1 %cursor.ok.65, label %cursor.continue.66, label %frame.failure.0
cursor.continue.66:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %stack.offset.73 = add i32 %context.value.6, %context.value.8
  %stack.offset.74 = add i32 %context.value.68, %context.value.70
  %stack.sub.75 = sub i32 %stack.offset.73, %stack.offset.74
  %stack.sub.76 = sub i32 %context.value.8, %context.value.70
  %stack.sub.77 = sub i32 %context.value.72, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.75, i32 %stack.sub.76)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.77)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %argument.bytes, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.enter.ok.12, label %frame.enter.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.enter.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %argument.source, %argument.bytes
  %stack.offset.17 = add i32 %context.value.15, %argument.bytes
  %reserve.status.18 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.17, i32 5)
  %reserve.ok.19 = icmp eq i32 %reserve.status.18, 0
  br i1 %reserve.ok.19, label %reserve.continue.20, label %frame.reserve.failure.1
reserve.continue.20:
  %value.size.21 = alloca %AlOwningValueSize, align 4
  %measure.status.22 = call i32 @al_owning_measure_value(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %argument.source, i32 %stack.offset.16, i32 6, ptr %value.size.21)
  %helper.ok.23 = icmp eq i32 %measure.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %value.payload.pointer.25 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 0
  %value.extent.pointer.26 = getelementptr inbounds %AlOwningValueSize, ptr %value.size.21, i32 0, i32 1
  %value.payload.27 = load i32, ptr %value.payload.pointer.25, align 4
  %value.extent.28 = load i32, ptr %value.extent.pointer.26, align 4
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 %value.extent.28, i32 %value.payload.27, i32 8, i32 8)
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %runtime.ok.31 = icmp eq i32 %context.value.30, 0
  br i1 %runtime.ok.31, label %runtime.continue.32, label %frame.failure.0
runtime.continue.32:
  %stack.offset.33 = add i32 %argument.source, %value.extent.28
  %stack.offset.34 = add i32 %context.value.15, %value.extent.28
  %arguments.exact.35 = icmp eq i32 %stack.offset.33, %stack.offset.16
  br i1 %arguments.exact.35, label %arguments.continue.36, label %frame.failure.0
arguments.continue.36:
  %step.status.37 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.38 = icmp eq i32 %step.status.37, 0
  br i1 %helper.ok.38, label %helper.continue.39, label %frame.failure.0
helper.continue.39:
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %stack.sub.42 = sub i32 %context.value.41, %value.extent.28
  call void @al_owning_drop(ptr %ctx, i32 %stack.sub.42, i32 %value.extent.28, i32 %value.payload.27, i32 8)
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %runtime.ok.45 = icmp eq i32 %context.value.44, 0
  br i1 %runtime.ok.45, label %runtime.continue.46, label %frame.failure.0
runtime.continue.46:
  %stack.offset.47 = add i32 0, 0
  %stack.offset.48 = add i32 %context.value.15, %stack.offset.47
  %cursor.status.49 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.48)
  %cursor.ok.50 = icmp eq i32 %cursor.status.49, 0
  br i1 %cursor.ok.50, label %cursor.continue.51, label %frame.failure.0
cursor.continue.51:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.offset.58 = add i32 %context.value.6, %context.value.8
  %stack.offset.59 = add i32 %context.value.53, %context.value.55
  %stack.sub.60 = sub i32 %stack.offset.58, %stack.offset.59
  %stack.sub.61 = sub i32 %context.value.8, %context.value.55
  %stack.sub.62 = sub i32 %context.value.57, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.60, i32 %stack.sub.61)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.62)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.extent.pointer.10 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.11 = load i32, ptr %input.extent.pointer.10, align 4
  %host.pointer.12 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.13 = alloca i32, align 4
  %input.measured.extent.pointer.14 = alloca i32, align 4
  %input.measure.status.15 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.12, i32 %input.host.extent.11, i32 0, i32 8, ptr %input.payload.pointer.13, ptr %input.measured.extent.pointer.14)
  %helper.ok.16 = icmp eq i32 %input.measure.status.15, 0
  br i1 %helper.ok.16, label %helper.continue.17, label %entry.failure.0
helper.continue.17:
  %input.measured.payload.18 = load i32, ptr %input.payload.pointer.13, align 4
  %input.measured.extent.19 = load i32, ptr %input.measured.extent.pointer.14, align 4
  %input.extent.exact.20 = icmp eq i32 %input.measured.extent.19, %input.host.extent.11
  br i1 %input.extent.exact.20, label %input.extent.exact.21, label %input.extent.invalid.22
input.extent.invalid.22:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 8, i32 %input.measured.extent.19, i32 %input.host.extent.11)
  br label %entry.failure.0
input.extent.exact.21:
  %stack.offset.23 = add i32 0, %input.host.extent.11
  %input.total.exact.24 = icmp eq i32 %stack.offset.23, %input.bytes
  br i1 %input.total.exact.24, label %input.valid.25, label %input.invalid.26
input.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.23, i32 %input.bytes)
  br label %entry.failure.0
input.valid.25:
  %reserve.status.27 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.23, i32 9)
  %reserve.ok.28 = icmp eq i32 %reserve.status.27, 0
  br i1 %reserve.ok.28, label %reserve.continue.29, label %entry.failure.0
reserve.continue.29:
  %host.pointer.30 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.31 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.30, i32 %input.host.extent.11, i32 0, i32 %input.measured.payload.18, i32 %input.host.extent.11, i32 8, i32 10)
  %helper.ok.32 = icmp eq i32 %input.copy.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %entry.failure.0
helper.continue.33:
  %entry.body.status.34 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 %input.bytes, i32 11)
  %entry.body.ok.35 = icmp eq i32 %entry.body.status.34, 0
  br i1 %entry.body.ok.35, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %stack.offset.36 = add i32 0, %input.bytes
  %context.field.37 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.38 = load i32, ptr %context.field.37, align 4
  %entry.outputs.exact.39 = icmp eq i32 %stack.offset.36, %context.value.38
  br i1 %entry.outputs.exact.39, label %entry.outputs.exact.40, label %entry.failure.0
entry.outputs.exact.40:
  %stack.sub.41 = sub i32 %context.value.38, %stack.offset.36
  call void @al_owning_move_range(ptr %ctx, i32 0, i32 %stack.offset.36, i32 %stack.sub.41, i32 0, i32 0, i32 9)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.sub.41, i32 0, i32 0, i32 0)
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %runtime.ok.48 = icmp eq i32 %context.value.47, 0
  br i1 %runtime.ok.48, label %runtime.continue.49, label %entry.failure.0
runtime.continue.49:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 %stack.sub.41, i32 0)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %entry.failure.0
runtime.continue.53:
  %stack.sub.54 = sub i32 0, 0
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.54, i32 0)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %entry.failure.0
runtime.continue.58:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.offset.65 = add i32 %context.value.60, %context.value.62
  %stack.sub.66 = sub i32 0, %stack.offset.65
  %stack.sub.67 = sub i32 0, %context.value.62
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.66, i32 %stack.sub.67)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.64)
  br label %entry.return.status
entry.return.status:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  ret i32 %context.value.69
}


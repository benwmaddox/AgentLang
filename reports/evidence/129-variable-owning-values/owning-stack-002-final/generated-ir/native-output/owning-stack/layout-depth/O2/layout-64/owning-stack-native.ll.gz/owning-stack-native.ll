%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 8
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 8, i32 8, i32 63, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  %step.status.28 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %step.ok.29 = icmp eq i32 %step.status.28, 0
  br i1 %step.ok.29, label %step.continue.30, label %frame.failure.0
step.continue.30:
  %stack.offset.31 = add i32 %context.value.15, 8
  %reserve.status.32 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.31, i32 3)
  %reserve.ok.33 = icmp eq i32 %reserve.status.32, 0
  br i1 %reserve.ok.33, label %reserve.continue.34, label %frame.failure.0
reserve.continue.34:
  %callee.status.35 = call i32 @agentlang_word_0000(ptr %ctx, i32 %context.value.15, i32 %context.value.15, i32 4)
  %callee.ok.36 = icmp eq i32 %callee.status.35, 0
  br i1 %callee.ok.36, label %callee.returned.37, label %frame.failure.0
callee.returned.37:
  %stack.offset.38 = add i32 %context.value.15, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.38, i32 0, i32 0, i32 0)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %context.value.15, 8
  %cursor.check.44 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.43)
  %cursor.ok.45 = icmp eq i32 %cursor.check.44, 0
  br i1 %cursor.ok.45, label %cursor.continue.46, label %frame.failure.0
cursor.continue.46:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 8, i32 8, i32 63, i32 9)
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %runtime.ok.49 = icmp eq i32 %context.value.48, 0
  br i1 %runtime.ok.49, label %runtime.continue.50, label %frame.failure.0
runtime.continue.50:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %baseline.live.total.57 = add i32 %context.value.6, %context.value.8
  %current.live.total.58 = add i32 %context.value.52, %context.value.54
  %cleanup.live.delta.59 = sub i32 %baseline.live.total.57, %current.live.total.58
  %cleanup.local.delta.60 = sub i32 %context.value.8, %context.value.54
  %cleanup.reserved.delta.61 = sub i32 %context.value.56, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.59, i32 %cleanup.local.delta.60)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.61)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %frame.entered.14 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.15 = icmp eq i32 %frame.entered.14, 0
  br i1 %frame.entered.ok.15, label %frame.entered.continue.16, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.16:
  %context.field.17 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.18 = load i32, ptr %context.field.17, align 4
  %stack.offset.19 = add i32 %context.value.18, 8
  %stack.offset.20 = add i32 %context.value.18, 16
  %reserve.status.21 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.20, i32 5)
  %reserve.ok.22 = icmp eq i32 %reserve.status.21, 0
  br i1 %reserve.ok.22, label %reserve.continue.23, label %frame.reserve.failure.1
reserve.continue.23:
  call void @al_owning_local_reserve(ptr %ctx, i32 8)
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %runtime.ok.26 = icmp eq i32 %context.value.25, 0
  br i1 %runtime.ok.26, label %runtime.continue.27, label %frame.failure.0
runtime.continue.27:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.19, i32 %argument.source, i32 8, i32 8, i32 63, i32 8)
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %runtime.ok.30 = icmp eq i32 %context.value.29, 0
  br i1 %runtime.ok.30, label %runtime.continue.31, label %frame.failure.0
runtime.continue.31:
  %step.status.32 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %step.ok.33 = icmp eq i32 %step.status.32, 0
  br i1 %step.ok.33, label %step.continue.34, label %frame.failure.0
step.continue.34:
  %local.is.active.35 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.36 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.37 = select i1 %local.is.active.35, i32 %local.previous.payload.36, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.18, i32 %stack.offset.19, i32 8, i32 8, i32 8, i32 %local.old.payload.37, i32 63)
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %runtime.ok.40 = icmp eq i32 %context.value.39, 0
  br i1 %runtime.ok.40, label %runtime.continue.41, label %frame.failure.0
runtime.continue.41:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 63, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.19, i32 8, i32 8, i32 63)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %frame.failure.0
runtime.continue.45:
  %cursor.check.46 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.19)
  %cursor.ok.47 = icmp eq i32 %cursor.check.46, 0
  br i1 %cursor.ok.47, label %cursor.continue.48, label %frame.failure.0
cursor.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %step.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %step.ok.50, label %step.continue.51, label %frame.failure.0
step.continue.51:
  %stack.offset.52 = add i32 %stack.offset.19, 8
  %reserve.status.53 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 8)
  %reserve.ok.54 = icmp eq i32 %reserve.status.53, 0
  br i1 %reserve.ok.54, label %reserve.continue.55, label %frame.failure.0
reserve.continue.55:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.19, i32 %context.value.18, i32 8, i32 8, i32 63)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %stack.offset.60 = add i32 %stack.offset.19, 8
  %cursor.check.61 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.60)
  %cursor.ok.62 = icmp eq i32 %cursor.check.61, 0
  br i1 %cursor.ok.62, label %cursor.continue.63, label %frame.failure.0
cursor.continue.63:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.19, i32 8, i32 8, i32 63, i32 9)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %local.is.active.68 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.69 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.70 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.71 = select i1 %local.is.active.68, i32 %local.clear.payload.69, i32 0
  %local.clear.live.type.72 = select i1 %local.is.active.68, i32 %local.clear.type.70, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.18, i32 8, i32 %local.clear.live.payload.71, i32 %local.clear.live.type.72)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %frame.failure.0
runtime.continue.76:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  call void @al_owning_local_release(ptr %ctx, i32 8)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.18, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.7, i32 0, i32 0, i32 0)
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %baseline.live.total.83 = add i32 %context.value.9, %context.value.11
  %current.live.total.84 = add i32 %context.value.78, %context.value.80
  %cleanup.live.delta.85 = sub i32 %baseline.live.total.83, %current.live.total.84
  %cleanup.local.delta.86 = sub i32 %context.value.11, %context.value.80
  %cleanup.reserved.delta.87 = sub i32 %context.value.82, %context.value.13
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.85, i32 %cleanup.local.delta.86)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.87)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 8
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 8, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 8, i32 9)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 8, i32 8, i32 63)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.19 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.20 = load i32, ptr %context.field.19, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.26 = load i32, ptr %context.field.25, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.27 = add i32 %context.value.22, %context.value.24
  %entry.failure.delta.28 = sub i32 0, %entry.failure.live.27
  %entry.failure.local.delta.29 = sub i32 0, %context.value.24
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.28, i32 %entry.failure.local.delta.29)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.26)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 8, i32 63)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %entry.failure.0
runtime.continue.33:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %runtime.ok.36 = icmp eq i32 %context.value.35, 0
  br i1 %runtime.ok.36, label %runtime.continue.37, label %entry.failure.0
runtime.continue.37:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %entry.cleanup.total.live.46 = add i32 %context.value.41, %context.value.43
  %entry.cleanup.live.delta.47 = sub i32 0, %entry.cleanup.total.live.46
  %entry.cleanup.local.delta.48 = sub i32 0, %context.value.43
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.47, i32 %entry.cleanup.local.delta.48)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.45)
  br label %entry.return.status
entry.return.status:
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.50 = load i32, ptr %context.field.49, align 4
  ret i32 %context.value.50
}


target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_4 = private constant [2 x i32] [i32 5, i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_6 = private constant [2 x i32] [i32 0, i32 4]
@agentlang_type_descriptors = private constant [7 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([7 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 7, i32 0 }
@agentlang_root_type_ids = private constant [1 x i32] [i32 6]
@agentlang_input_type_ids = private constant [2 x i32] [i32 6, i32 0]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %call.depth.13 = add i32 %depth, 1
  call void @agentlang_fn_70ec5f193927c2851d017305efe52c2118509a21d7261494fb18b9373b61954d_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.13, i64 %arg0, i64 %arg1)
  %callee.status.14 = load i32, ptr %status, align 4
  %callee.succeeded.15 = icmp eq i32 %callee.status.14, 0
  br i1 %callee.succeeded.15, label %callee.continue.17, label %callee.failure.16
callee.failure.16:
  ret void
callee.continue.17:
  %call.output.ptr.18 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.19 = load i64, ptr %call.output.ptr.18, align 8
  %output.ptr.20 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %call.output.19, ptr %output.ptr.20, align 8
  ret void
}

define internal void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.25 = load i32, ptr %ctx.field.24, align 4
  %steps.next.26 = add i32 %steps.current.25, 1
  store i32 %steps.next.26, ptr %ctx.field.24, align 4
  %steps.over.27 = icmp ugt i32 %steps.next.26, 10000
  br i1 %steps.over.27, label %failure.28, label %continue.29
failure.28:
  %ctx.field.30 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.30, align 4
  %status.diagnostic.31 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.31, align 4
  ret void
continue.29:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.33 = load i32, ptr %ctx.field.32, align 4
  %steps.next.34 = add i32 %steps.current.33, 1
  store i32 %steps.next.34, ptr %ctx.field.32, align 4
  %steps.over.35 = icmp ugt i32 %steps.next.34, 10000
  br i1 %steps.over.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %depth.exceeded.40 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.40, label %failure.41, label %continue.42
failure.41:
  %ctx.field.43 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.43, align 4
  %status.diagnostic.44 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.44, align 4
  ret void
continue.42:
  %checked.tuple.45 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %arg0, i64 100)
  %checked.raw.46 = extractvalue { i64, i1 } %checked.tuple.45, 0
  %checked.overflow.47 = extractvalue { i64, i1 } %checked.tuple.45, 1
  br i1 %checked.overflow.47, label %overflow.48, label %checked.49
overflow.48:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.51 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %arg0, ptr %ctx.field.50, align 8
  store i64 100, ptr %ctx.field.51, align 8
  %ctx.field.52 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.52, align 4
  %status.diagnostic.53 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.53, align 4
  ret void
checked.49:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.55 = load i32, ptr %ctx.field.54, align 4
  %steps.next.56 = add i32 %steps.current.55, 1
  store i32 %steps.next.56, ptr %ctx.field.54, align 4
  %steps.over.57 = icmp ugt i32 %steps.next.56, 10000
  br i1 %steps.over.57, label %failure.58, label %continue.59
failure.58:
  %ctx.field.60 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.60, align 4
  %status.diagnostic.61 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.61, align 4
  ret void
continue.59:
  %depth.exceeded.62 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.62, label %failure.63, label %continue.64
failure.63:
  %ctx.field.65 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.65, align 4
  %status.diagnostic.66 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.66, align 4
  ret void
continue.64:
  %call.depth.67 = add i32 %depth, 1
  call void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.67, i64 %arg0, i64 %checked.raw.46)
  %callee.status.68 = load i32, ptr %status, align 4
  %callee.succeeded.69 = icmp eq i32 %callee.status.68, 0
  br i1 %callee.succeeded.69, label %callee.continue.71, label %callee.failure.70
callee.failure.70:
  ret void
callee.continue.71:
  %call.output.ptr.72 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.73 = load i64, ptr %call.output.ptr.72, align 8
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.75 = load i32, ptr %ctx.field.74, align 4
  %steps.next.76 = add i32 %steps.current.75, 1
  store i32 %steps.next.76, ptr %ctx.field.74, align 4
  %steps.over.77 = icmp ugt i32 %steps.next.76, 10000
  br i1 %steps.over.77, label %failure.78, label %continue.79
failure.78:
  %ctx.field.80 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.80, align 4
  %status.diagnostic.81 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.81, align 4
  ret void
continue.79:
  %depth.exceeded.82 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.88 = load i32, ptr %ctx.field.87, align 4
  %steps.next.89 = add i32 %steps.current.88, 1
  store i32 %steps.next.89, ptr %ctx.field.87, align 4
  %steps.over.90 = icmp ugt i32 %steps.next.89, 10000
  br i1 %steps.over.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %ctx.field.95 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.96 = load i32, ptr %ctx.field.95, align 4
  %steps.next.97 = add i32 %steps.current.96, 1
  store i32 %steps.next.97, ptr %ctx.field.95, align 4
  %steps.over.98 = icmp ugt i32 %steps.next.97, 10000
  br i1 %steps.over.98, label %failure.99, label %continue.100
failure.99:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.101, align 4
  %status.diagnostic.102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.102, align 4
  ret void
continue.100:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.104 = load i32, ptr %ctx.field.103, align 4
  %steps.next.105 = add i32 %steps.current.104, 1
  store i32 %steps.next.105, ptr %ctx.field.103, align 4
  %steps.over.106 = icmp ugt i32 %steps.next.105, 10000
  br i1 %steps.over.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.112 = load i32, ptr %ctx.field.111, align 4
  %steps.next.113 = add i32 %steps.current.112, 1
  store i32 %steps.next.113, ptr %ctx.field.111, align 4
  %steps.over.114 = icmp ugt i32 %steps.next.113, 10000
  br i1 %steps.over.114, label %failure.115, label %continue.116
failure.115:
  %ctx.field.117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.117, align 4
  %status.diagnostic.118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.118, align 4
  ret void
continue.116:
  %depth.exceeded.119 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.119, label %failure.120, label %continue.121
failure.120:
  %ctx.field.122 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.122, align 4
  %status.diagnostic.123 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.123, align 4
  ret void
continue.121:
  %workspace.slot.124 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.125 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 4, i64 %call.output.73, i32 0, ptr %workspace.slot.124)
  switch i32 %record.field.status.125, label %runtime.invalid.result.131 [ i32 0, label %runtime.success.126 i32 1, label %runtime.invalid.request.127 i32 2, label %runtime.invalid.reference.128 i32 3, label %runtime.scratch.capacity.129 i32 4, label %runtime.retained.capacity.130 ]
runtime.invalid.request.127:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.128:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.129:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.130:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.131:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.126:
  %record.field.value.132 = load i64, ptr %workspace.slot.124, align 8
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.134 = load i32, ptr %ctx.field.133, align 4
  %steps.next.135 = add i32 %steps.current.134, 1
  store i32 %steps.next.135, ptr %ctx.field.133, align 4
  %steps.over.136 = icmp ugt i32 %steps.next.135, 10000
  br i1 %steps.over.136, label %failure.137, label %continue.138
failure.137:
  %ctx.field.139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.139, align 4
  %status.diagnostic.140 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.140, align 4
  ret void
continue.138:
  %depth.exceeded.141 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.141, label %failure.142, label %continue.143
failure.142:
  %ctx.field.144 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.144, align 4
  %status.diagnostic.145 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.145, align 4
  ret void
continue.143:
  %workspace.slot.146 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.147 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.field.value.132, i32 0, ptr %workspace.slot.146)
  switch i32 %record.field.status.147, label %runtime.invalid.result.153 [ i32 0, label %runtime.success.148 i32 1, label %runtime.invalid.request.149 i32 2, label %runtime.invalid.reference.150 i32 3, label %runtime.scratch.capacity.151 i32 4, label %runtime.retained.capacity.152 ]
runtime.invalid.request.149:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.150:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.151:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.152:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.153:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.148:
  %record.field.value.154 = load i64, ptr %workspace.slot.146, align 8
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.156 = load i32, ptr %ctx.field.155, align 4
  %steps.next.157 = add i32 %steps.current.156, 1
  store i32 %steps.next.157, ptr %ctx.field.155, align 4
  %steps.over.158 = icmp ugt i32 %steps.next.157, 10000
  br i1 %steps.over.158, label %failure.159, label %continue.160
failure.159:
  %ctx.field.161 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.161, align 4
  %status.diagnostic.162 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.162, align 4
  ret void
continue.160:
  %ctx.field.163 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.164 = load i32, ptr %ctx.field.163, align 4
  %steps.next.165 = add i32 %steps.current.164, 1
  store i32 %steps.next.165, ptr %ctx.field.163, align 4
  %steps.over.166 = icmp ugt i32 %steps.next.165, 10000
  br i1 %steps.over.166, label %failure.167, label %continue.168
failure.167:
  %ctx.field.169 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.169, align 4
  %status.diagnostic.170 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.170, align 4
  ret void
continue.168:
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.172 = load i32, ptr %ctx.field.171, align 4
  %steps.next.173 = add i32 %steps.current.172, 1
  store i32 %steps.next.173, ptr %ctx.field.171, align 4
  %steps.over.174 = icmp ugt i32 %steps.next.173, 10000
  br i1 %steps.over.174, label %failure.175, label %continue.176
failure.175:
  %ctx.field.177 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.177, align 4
  %status.diagnostic.178 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.178, align 4
  ret void
continue.176:
  %depth.exceeded.179 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.179, label %failure.180, label %continue.181
failure.180:
  %ctx.field.182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.182, align 4
  %status.diagnostic.183 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.183, align 4
  ret void
continue.181:
  %workspace.slot.184 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.185 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 4, i64 %call.output.73, i32 0, ptr %workspace.slot.184)
  switch i32 %record.field.status.185, label %runtime.invalid.result.191 [ i32 0, label %runtime.success.186 i32 1, label %runtime.invalid.request.187 i32 2, label %runtime.invalid.reference.188 i32 3, label %runtime.scratch.capacity.189 i32 4, label %runtime.retained.capacity.190 ]
runtime.invalid.request.187:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.188:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.189:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.190:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.191:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.186:
  %record.field.value.192 = load i64, ptr %workspace.slot.184, align 8
  %ctx.field.193 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.194 = load i32, ptr %ctx.field.193, align 4
  %steps.next.195 = add i32 %steps.current.194, 1
  store i32 %steps.next.195, ptr %ctx.field.193, align 4
  %steps.over.196 = icmp ugt i32 %steps.next.195, 10000
  br i1 %steps.over.196, label %failure.197, label %continue.198
failure.197:
  %ctx.field.199 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.199, align 4
  %status.diagnostic.200 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.200, align 4
  ret void
continue.198:
  %depth.exceeded.201 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.201, label %failure.202, label %continue.203
failure.202:
  %ctx.field.204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.204, align 4
  %status.diagnostic.205 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.205, align 4
  ret void
continue.203:
  %workspace.slot.206 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.207 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.field.value.192, i32 0, ptr %workspace.slot.206)
  switch i32 %record.field.status.207, label %runtime.invalid.result.213 [ i32 0, label %runtime.success.208 i32 1, label %runtime.invalid.request.209 i32 2, label %runtime.invalid.reference.210 i32 3, label %runtime.scratch.capacity.211 i32 4, label %runtime.retained.capacity.212 ]
runtime.invalid.request.209:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.210:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.211:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.212:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.213:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.208:
  %record.field.value.214 = load i64, ptr %workspace.slot.206, align 8
  %ctx.field.215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.216 = load i32, ptr %ctx.field.215, align 4
  %steps.next.217 = add i32 %steps.current.216, 1
  store i32 %steps.next.217, ptr %ctx.field.215, align 4
  %steps.over.218 = icmp ugt i32 %steps.next.217, 10000
  br i1 %steps.over.218, label %failure.219, label %continue.220
failure.219:
  %ctx.field.221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.221, align 4
  %status.diagnostic.222 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.222, align 4
  ret void
continue.220:
  %ctx.field.223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.224 = load i32, ptr %ctx.field.223, align 4
  %steps.next.225 = add i32 %steps.current.224, 1
  store i32 %steps.next.225, ptr %ctx.field.223, align 4
  %steps.over.226 = icmp ugt i32 %steps.next.225, 10000
  br i1 %steps.over.226, label %failure.227, label %continue.228
failure.227:
  %ctx.field.229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.229, align 4
  %status.diagnostic.230 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.230, align 4
  ret void
continue.228:
  %ctx.field.231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.232 = load i32, ptr %ctx.field.231, align 4
  %steps.next.233 = add i32 %steps.current.232, 1
  store i32 %steps.next.233, ptr %ctx.field.231, align 4
  %steps.over.234 = icmp ugt i32 %steps.next.233, 10000
  br i1 %steps.over.234, label %failure.235, label %continue.236
failure.235:
  %ctx.field.237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.237, align 4
  %status.diagnostic.238 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.238, align 4
  ret void
continue.236:
  %ctx.field.239 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.240 = load i32, ptr %ctx.field.239, align 4
  %steps.next.241 = add i32 %steps.current.240, 1
  store i32 %steps.next.241, ptr %ctx.field.239, align 4
  %steps.over.242 = icmp ugt i32 %steps.next.241, 10000
  br i1 %steps.over.242, label %failure.243, label %continue.244
failure.243:
  %ctx.field.245 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.245, align 4
  %status.diagnostic.246 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.246, align 4
  ret void
continue.244:
  %depth.exceeded.247 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.247, label %failure.248, label %continue.249
failure.248:
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.250, align 4
  %status.diagnostic.251 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.251, align 4
  ret void
continue.249:
  %checked.tuple.252 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %record.field.value.154, i64 %record.field.value.214)
  %checked.raw.253 = extractvalue { i64, i1 } %checked.tuple.252, 0
  %checked.overflow.254 = extractvalue { i64, i1 } %checked.tuple.252, 1
  br i1 %checked.overflow.254, label %overflow.255, label %checked.256
overflow.255:
  %ctx.field.257 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %record.field.value.154, ptr %ctx.field.257, align 8
  store i64 %record.field.value.214, ptr %ctx.field.258, align 8
  %ctx.field.259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.259, align 4
  %status.diagnostic.260 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.260, align 4
  ret void
checked.256:
  %output.ptr.261 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %checked.raw.253, ptr %output.ptr.261, align 8
  ret void
}

define internal void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.25 = load i32, ptr %ctx.field.24, align 4
  %steps.next.26 = add i32 %steps.current.25, 1
  store i32 %steps.next.26, ptr %ctx.field.24, align 4
  %steps.over.27 = icmp ugt i32 %steps.next.26, 10000
  br i1 %steps.over.27, label %failure.28, label %continue.29
failure.28:
  %ctx.field.30 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.30, align 4
  %status.diagnostic.31 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.31, align 4
  ret void
continue.29:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.33 = load i32, ptr %ctx.field.32, align 4
  %steps.next.34 = add i32 %steps.current.33, 1
  store i32 %steps.next.34, ptr %ctx.field.32, align 4
  %steps.over.35 = icmp ugt i32 %steps.next.34, 10000
  br i1 %steps.over.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.41 = load i32, ptr %ctx.field.40, align 4
  %steps.next.42 = add i32 %steps.current.41, 1
  store i32 %steps.next.42, ptr %ctx.field.40, align 4
  %steps.over.43 = icmp ugt i32 %steps.next.42, 10000
  br i1 %steps.over.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %ctx.field.48 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.49 = load i32, ptr %ctx.field.48, align 4
  %steps.next.50 = add i32 %steps.current.49, 1
  store i32 %steps.next.50, ptr %ctx.field.48, align 4
  %steps.over.51 = icmp ugt i32 %steps.next.50, 10000
  br i1 %steps.over.51, label %failure.52, label %continue.53
failure.52:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.54, align 4
  %status.diagnostic.55 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.55, align 4
  ret void
continue.53:
  %depth.exceeded.56 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.56, label %failure.57, label %continue.58
failure.57:
  %ctx.field.59 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.59, align 4
  %status.diagnostic.60 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.60, align 4
  ret void
continue.58:
  %workspace.slot.61 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %arg0, ptr %workspace.slot.61, align 8
  %workspace.slot.62 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.63 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.62)
  switch i32 %record.make.status.63, label %runtime.invalid.result.69 [ i32 0, label %runtime.success.64 i32 1, label %runtime.invalid.request.65 i32 2, label %runtime.invalid.reference.66 i32 3, label %runtime.scratch.capacity.67 i32 4, label %runtime.retained.capacity.68 ]
runtime.invalid.request.65:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.66:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.67:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.68:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.69:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.64:
  %record.make.handle.70 = load i64, ptr %workspace.slot.62, align 8
  %ctx.field.71 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.72 = load i32, ptr %ctx.field.71, align 4
  %steps.next.73 = add i32 %steps.current.72, 1
  store i32 %steps.next.73, ptr %ctx.field.71, align 4
  %steps.over.74 = icmp ugt i32 %steps.next.73, 10000
  br i1 %steps.over.74, label %failure.75, label %continue.76
failure.75:
  %ctx.field.77 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.77, align 4
  %status.diagnostic.78 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.78, align 4
  ret void
continue.76:
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.80 = load i32, ptr %ctx.field.79, align 4
  %steps.next.81 = add i32 %steps.current.80, 1
  store i32 %steps.next.81, ptr %ctx.field.79, align 4
  %steps.over.82 = icmp ugt i32 %steps.next.81, 10000
  br i1 %steps.over.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.88 = load i32, ptr %ctx.field.87, align 4
  %steps.next.89 = add i32 %steps.current.88, 1
  store i32 %steps.next.89, ptr %ctx.field.87, align 4
  %steps.over.90 = icmp ugt i32 %steps.next.89, 10000
  br i1 %steps.over.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %ctx.field.95 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.96 = load i32, ptr %ctx.field.95, align 4
  %steps.next.97 = add i32 %steps.current.96, 1
  store i32 %steps.next.97, ptr %ctx.field.95, align 4
  %steps.over.98 = icmp ugt i32 %steps.next.97, 10000
  br i1 %steps.over.98, label %failure.99, label %continue.100
failure.99:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.101, align 4
  %status.diagnostic.102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.102, align 4
  ret void
continue.100:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.104 = load i32, ptr %ctx.field.103, align 4
  %steps.next.105 = add i32 %steps.current.104, 1
  store i32 %steps.next.105, ptr %ctx.field.103, align 4
  %steps.over.106 = icmp ugt i32 %steps.next.105, 10000
  br i1 %steps.over.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.112 = load i32, ptr %ctx.field.111, align 4
  %steps.next.113 = add i32 %steps.current.112, 1
  store i32 %steps.next.113, ptr %ctx.field.111, align 4
  %steps.over.114 = icmp ugt i32 %steps.next.113, 10000
  br i1 %steps.over.114, label %failure.115, label %continue.116
failure.115:
  %ctx.field.117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.117, align 4
  %status.diagnostic.118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.118, align 4
  ret void
continue.116:
  %ctx.field.119 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.120 = load i32, ptr %ctx.field.119, align 4
  %steps.next.121 = add i32 %steps.current.120, 1
  store i32 %steps.next.121, ptr %ctx.field.119, align 4
  %steps.over.122 = icmp ugt i32 %steps.next.121, 10000
  br i1 %steps.over.122, label %failure.123, label %continue.124
failure.123:
  %ctx.field.125 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.125, align 4
  %status.diagnostic.126 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.126, align 4
  ret void
continue.124:
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.128 = load i32, ptr %ctx.field.127, align 4
  %steps.next.129 = add i32 %steps.current.128, 1
  store i32 %steps.next.129, ptr %ctx.field.127, align 4
  %steps.over.130 = icmp ugt i32 %steps.next.129, 10000
  br i1 %steps.over.130, label %failure.131, label %continue.132
failure.131:
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.133, align 4
  %status.diagnostic.134 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.134, align 4
  ret void
continue.132:
  %ctx.field.135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.136 = load i32, ptr %ctx.field.135, align 4
  %steps.next.137 = add i32 %steps.current.136, 1
  store i32 %steps.next.137, ptr %ctx.field.135, align 4
  %steps.over.138 = icmp ugt i32 %steps.next.137, 10000
  br i1 %steps.over.138, label %failure.139, label %continue.140
failure.139:
  %ctx.field.141 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.141, align 4
  %status.diagnostic.142 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.142, align 4
  ret void
continue.140:
  %depth.exceeded.143 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.143, label %failure.144, label %continue.145
failure.144:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.146, align 4
  %status.diagnostic.147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.147, align 4
  ret void
continue.145:
  %workspace.slot.148 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.70, ptr %workspace.slot.148, align 8
  %workspace.slot.149 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %arg1, ptr %workspace.slot.149, align 8
  %workspace.slot.150 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.151 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.150)
  switch i32 %record.make.status.151, label %runtime.invalid.result.157 [ i32 0, label %runtime.success.152 i32 1, label %runtime.invalid.request.153 i32 2, label %runtime.invalid.reference.154 i32 3, label %runtime.scratch.capacity.155 i32 4, label %runtime.retained.capacity.156 ]
runtime.invalid.request.153:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.154:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.155:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.156:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.157:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.152:
  %record.make.handle.158 = load i64, ptr %workspace.slot.150, align 8
  %output.ptr.159 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.158, ptr %output.ptr.159, align 8
  ret void
}

define internal void @agentlang_fn_70ec5f193927c2851d017305efe52c2118509a21d7261494fb18b9373b61954d_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.25 = load i32, ptr %ctx.field.24, align 4
  %steps.next.26 = add i32 %steps.current.25, 1
  store i32 %steps.next.26, ptr %ctx.field.24, align 4
  %steps.over.27 = icmp ugt i32 %steps.next.26, 10000
  br i1 %steps.over.27, label %failure.28, label %continue.29
failure.28:
  %ctx.field.30 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.30, align 4
  %status.diagnostic.31 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.31, align 4
  ret void
continue.29:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.33 = load i32, ptr %ctx.field.32, align 4
  %steps.next.34 = add i32 %steps.current.33, 1
  store i32 %steps.next.34, ptr %ctx.field.32, align 4
  %steps.over.35 = icmp ugt i32 %steps.next.34, 10000
  br i1 %steps.over.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.41 = load i32, ptr %ctx.field.40, align 4
  %steps.next.42 = add i32 %steps.current.41, 1
  store i32 %steps.next.42, ptr %ctx.field.40, align 4
  %steps.over.43 = icmp ugt i32 %steps.next.42, 10000
  br i1 %steps.over.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %depth.exceeded.48 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.48, label %failure.49, label %continue.50
failure.49:
  %ctx.field.51 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.51, align 4
  %status.diagnostic.52 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.52, align 4
  ret void
continue.50:
  %checked.tuple.53 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %arg1, i64 1000)
  %checked.raw.54 = extractvalue { i64, i1 } %checked.tuple.53, 0
  %checked.overflow.55 = extractvalue { i64, i1 } %checked.tuple.53, 1
  br i1 %checked.overflow.55, label %overflow.56, label %checked.57
overflow.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.59 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %arg1, ptr %ctx.field.58, align 8
  store i64 1000, ptr %ctx.field.59, align 8
  %ctx.field.60 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.60, align 4
  %status.diagnostic.61 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.61, align 4
  ret void
checked.57:
  %ctx.field.62 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.63 = load i32, ptr %ctx.field.62, align 4
  %steps.next.64 = add i32 %steps.current.63, 1
  store i32 %steps.next.64, ptr %ctx.field.62, align 4
  %steps.over.65 = icmp ugt i32 %steps.next.64, 10000
  br i1 %steps.over.65, label %failure.66, label %continue.67
failure.66:
  %ctx.field.68 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.68, align 4
  %status.diagnostic.69 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.69, align 4
  ret void
continue.67:
  %depth.exceeded.70 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.70, label %failure.71, label %continue.72
failure.71:
  %ctx.field.73 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.73, align 4
  %status.diagnostic.74 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.74, align 4
  ret void
continue.72:
  %call.depth.75 = add i32 %depth, 1
  call void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.75, i64 %arg1, i64 %checked.raw.54)
  %callee.status.76 = load i32, ptr %status, align 4
  %callee.succeeded.77 = icmp eq i32 %callee.status.76, 0
  br i1 %callee.succeeded.77, label %callee.continue.79, label %callee.failure.78
callee.failure.78:
  ret void
callee.continue.79:
  %call.output.ptr.80 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.81 = load i64, ptr %call.output.ptr.80, align 8
  %ctx.field.82 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.83 = load i32, ptr %ctx.field.82, align 4
  %steps.next.84 = add i32 %steps.current.83, 1
  store i32 %steps.next.84, ptr %ctx.field.82, align 4
  %steps.over.85 = icmp ugt i32 %steps.next.84, 10000
  br i1 %steps.over.85, label %failure.86, label %continue.87
failure.86:
  %ctx.field.88 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.88, align 4
  %status.diagnostic.89 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.89, align 4
  ret void
continue.87:
  %ctx.field.90 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.91 = load i32, ptr %ctx.field.90, align 4
  %steps.next.92 = add i32 %steps.current.91, 1
  store i32 %steps.next.92, ptr %ctx.field.90, align 4
  %steps.over.93 = icmp ugt i32 %steps.next.92, 10000
  br i1 %steps.over.93, label %failure.94, label %continue.95
failure.94:
  %ctx.field.96 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.96, align 4
  %status.diagnostic.97 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.97, align 4
  ret void
continue.95:
  %ctx.field.98 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.99 = load i32, ptr %ctx.field.98, align 4
  %steps.next.100 = add i32 %steps.current.99, 1
  store i32 %steps.next.100, ptr %ctx.field.98, align 4
  %steps.over.101 = icmp ugt i32 %steps.next.100, 10000
  br i1 %steps.over.101, label %failure.102, label %continue.103
failure.102:
  %ctx.field.104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.104, align 4
  %status.diagnostic.105 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.105, align 4
  ret void
continue.103:
  %depth.exceeded.106 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %call.depth.111 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.111, i64 %arg1)
  %callee.status.112 = load i32, ptr %status, align 4
  %callee.succeeded.113 = icmp eq i32 %callee.status.112, 0
  br i1 %callee.succeeded.113, label %callee.continue.115, label %callee.failure.114
callee.failure.114:
  ret void
callee.continue.115:
  %call.output.ptr.116 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.117 = load i64, ptr %call.output.ptr.116, align 8
  %ctx.field.118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.119 = load i32, ptr %ctx.field.118, align 4
  %steps.next.120 = add i32 %steps.current.119, 1
  store i32 %steps.next.120, ptr %ctx.field.118, align 4
  %steps.over.121 = icmp ugt i32 %steps.next.120, 10000
  br i1 %steps.over.121, label %failure.122, label %continue.123
failure.122:
  %ctx.field.124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.124, align 4
  %status.diagnostic.125 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.125, align 4
  ret void
continue.123:
  %ctx.field.126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.127 = load i32, ptr %ctx.field.126, align 4
  %steps.next.128 = add i32 %steps.current.127, 1
  store i32 %steps.next.128, ptr %ctx.field.126, align 4
  %steps.over.129 = icmp ugt i32 %steps.next.128, 10000
  br i1 %steps.over.129, label %failure.130, label %continue.131
failure.130:
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.132, align 4
  %status.diagnostic.133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.133, align 4
  ret void
continue.131:
  %ctx.field.134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.135 = load i32, ptr %ctx.field.134, align 4
  %steps.next.136 = add i32 %steps.current.135, 1
  store i32 %steps.next.136, ptr %ctx.field.134, align 4
  %steps.over.137 = icmp ugt i32 %steps.next.136, 10000
  br i1 %steps.over.137, label %failure.138, label %continue.139
failure.138:
  %ctx.field.140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 66, ptr %ctx.field.140, align 4
  %status.diagnostic.141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.141, align 4
  ret void
continue.139:
  %ctx.field.142 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.143 = load i32, ptr %ctx.field.142, align 4
  %steps.next.144 = add i32 %steps.current.143, 1
  store i32 %steps.next.144, ptr %ctx.field.142, align 4
  %steps.over.145 = icmp ugt i32 %steps.next.144, 10000
  br i1 %steps.over.145, label %failure.146, label %continue.147
failure.146:
  %ctx.field.148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 67, ptr %ctx.field.148, align 4
  %status.diagnostic.149 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.149, align 4
  ret void
continue.147:
  %depth.exceeded.150 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.150, label %failure.151, label %continue.152
failure.151:
  %ctx.field.153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 68, ptr %ctx.field.153, align 4
  %status.diagnostic.154 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.154, align 4
  ret void
continue.152:
  %call.depth.155 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.155, i64 %arg1)
  %callee.status.156 = load i32, ptr %status, align 4
  %callee.succeeded.157 = icmp eq i32 %callee.status.156, 0
  br i1 %callee.succeeded.157, label %callee.continue.159, label %callee.failure.158
callee.failure.158:
  ret void
callee.continue.159:
  %call.output.ptr.160 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.161 = load i64, ptr %call.output.ptr.160, align 8
  %ctx.field.162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.163 = load i32, ptr %ctx.field.162, align 4
  %steps.next.164 = add i32 %steps.current.163, 1
  store i32 %steps.next.164, ptr %ctx.field.162, align 4
  %steps.over.165 = icmp ugt i32 %steps.next.164, 10000
  br i1 %steps.over.165, label %failure.166, label %continue.167
failure.166:
  %ctx.field.168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 69, ptr %ctx.field.168, align 4
  %status.diagnostic.169 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.169, align 4
  ret void
continue.167:
  %ctx.field.170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.171 = load i32, ptr %ctx.field.170, align 4
  %steps.next.172 = add i32 %steps.current.171, 1
  store i32 %steps.next.172, ptr %ctx.field.170, align 4
  %steps.over.173 = icmp ugt i32 %steps.next.172, 10000
  br i1 %steps.over.173, label %failure.174, label %continue.175
failure.174:
  %ctx.field.176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 70, ptr %ctx.field.176, align 4
  %status.diagnostic.177 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.177, align 4
  ret void
continue.175:
  %ctx.field.178 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.179 = load i32, ptr %ctx.field.178, align 4
  %steps.next.180 = add i32 %steps.current.179, 1
  store i32 %steps.next.180, ptr %ctx.field.178, align 4
  %steps.over.181 = icmp ugt i32 %steps.next.180, 10000
  br i1 %steps.over.181, label %failure.182, label %continue.183
failure.182:
  %ctx.field.184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 71, ptr %ctx.field.184, align 4
  %status.diagnostic.185 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.185, align 4
  ret void
continue.183:
  %ctx.field.186 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.187 = load i32, ptr %ctx.field.186, align 4
  %steps.next.188 = add i32 %steps.current.187, 1
  store i32 %steps.next.188, ptr %ctx.field.186, align 4
  %steps.over.189 = icmp ugt i32 %steps.next.188, 10000
  br i1 %steps.over.189, label %failure.190, label %continue.191
failure.190:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 72, ptr %ctx.field.192, align 4
  %status.diagnostic.193 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.193, align 4
  ret void
continue.191:
  %depth.exceeded.194 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.194, label %failure.195, label %continue.196
failure.195:
  %ctx.field.197 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 73, ptr %ctx.field.197, align 4
  %status.diagnostic.198 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.198, align 4
  ret void
continue.196:
  %call.depth.199 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.199, i64 %arg1)
  %callee.status.200 = load i32, ptr %status, align 4
  %callee.succeeded.201 = icmp eq i32 %callee.status.200, 0
  br i1 %callee.succeeded.201, label %callee.continue.203, label %callee.failure.202
callee.failure.202:
  ret void
callee.continue.203:
  %call.output.ptr.204 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.205 = load i64, ptr %call.output.ptr.204, align 8
  %ctx.field.206 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.207 = load i32, ptr %ctx.field.206, align 4
  %steps.next.208 = add i32 %steps.current.207, 1
  store i32 %steps.next.208, ptr %ctx.field.206, align 4
  %steps.over.209 = icmp ugt i32 %steps.next.208, 10000
  br i1 %steps.over.209, label %failure.210, label %continue.211
failure.210:
  %ctx.field.212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 74, ptr %ctx.field.212, align 4
  %status.diagnostic.213 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.213, align 4
  ret void
continue.211:
  %ctx.field.214 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.215 = load i32, ptr %ctx.field.214, align 4
  %steps.next.216 = add i32 %steps.current.215, 1
  store i32 %steps.next.216, ptr %ctx.field.214, align 4
  %steps.over.217 = icmp ugt i32 %steps.next.216, 10000
  br i1 %steps.over.217, label %failure.218, label %continue.219
failure.218:
  %ctx.field.220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 75, ptr %ctx.field.220, align 4
  %status.diagnostic.221 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.221, align 4
  ret void
continue.219:
  %ctx.field.222 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.223 = load i32, ptr %ctx.field.222, align 4
  %steps.next.224 = add i32 %steps.current.223, 1
  store i32 %steps.next.224, ptr %ctx.field.222, align 4
  %steps.over.225 = icmp ugt i32 %steps.next.224, 10000
  br i1 %steps.over.225, label %failure.226, label %continue.227
failure.226:
  %ctx.field.228 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 76, ptr %ctx.field.228, align 4
  %status.diagnostic.229 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.229, align 4
  ret void
continue.227:
  %ctx.field.230 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.231 = load i32, ptr %ctx.field.230, align 4
  %steps.next.232 = add i32 %steps.current.231, 1
  store i32 %steps.next.232, ptr %ctx.field.230, align 4
  %steps.over.233 = icmp ugt i32 %steps.next.232, 10000
  br i1 %steps.over.233, label %failure.234, label %continue.235
failure.234:
  %ctx.field.236 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 77, ptr %ctx.field.236, align 4
  %status.diagnostic.237 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.237, align 4
  ret void
continue.235:
  %depth.exceeded.238 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.238, label %failure.239, label %continue.240
failure.239:
  %ctx.field.241 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 78, ptr %ctx.field.241, align 4
  %status.diagnostic.242 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.242, align 4
  ret void
continue.240:
  %call.depth.243 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.243, i64 %arg1)
  %callee.status.244 = load i32, ptr %status, align 4
  %callee.succeeded.245 = icmp eq i32 %callee.status.244, 0
  br i1 %callee.succeeded.245, label %callee.continue.247, label %callee.failure.246
callee.failure.246:
  ret void
callee.continue.247:
  %call.output.ptr.248 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.249 = load i64, ptr %call.output.ptr.248, align 8
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.251 = load i32, ptr %ctx.field.250, align 4
  %steps.next.252 = add i32 %steps.current.251, 1
  store i32 %steps.next.252, ptr %ctx.field.250, align 4
  %steps.over.253 = icmp ugt i32 %steps.next.252, 10000
  br i1 %steps.over.253, label %failure.254, label %continue.255
failure.254:
  %ctx.field.256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 79, ptr %ctx.field.256, align 4
  %status.diagnostic.257 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.257, align 4
  ret void
continue.255:
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.259 = load i32, ptr %ctx.field.258, align 4
  %steps.next.260 = add i32 %steps.current.259, 1
  store i32 %steps.next.260, ptr %ctx.field.258, align 4
  %steps.over.261 = icmp ugt i32 %steps.next.260, 10000
  br i1 %steps.over.261, label %failure.262, label %continue.263
failure.262:
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 80, ptr %ctx.field.264, align 4
  %status.diagnostic.265 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.265, align 4
  ret void
continue.263:
  %ctx.field.266 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.267 = load i32, ptr %ctx.field.266, align 4
  %steps.next.268 = add i32 %steps.current.267, 1
  store i32 %steps.next.268, ptr %ctx.field.266, align 4
  %steps.over.269 = icmp ugt i32 %steps.next.268, 10000
  br i1 %steps.over.269, label %failure.270, label %continue.271
failure.270:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 81, ptr %ctx.field.272, align 4
  %status.diagnostic.273 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.273, align 4
  ret void
continue.271:
  %ctx.field.274 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.275 = load i32, ptr %ctx.field.274, align 4
  %steps.next.276 = add i32 %steps.current.275, 1
  store i32 %steps.next.276, ptr %ctx.field.274, align 4
  %steps.over.277 = icmp ugt i32 %steps.next.276, 10000
  br i1 %steps.over.277, label %failure.278, label %continue.279
failure.278:
  %ctx.field.280 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 82, ptr %ctx.field.280, align 4
  %status.diagnostic.281 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.281, align 4
  ret void
continue.279:
  %depth.exceeded.282 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.282, label %failure.283, label %continue.284
failure.283:
  %ctx.field.285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 83, ptr %ctx.field.285, align 4
  %status.diagnostic.286 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.286, align 4
  ret void
continue.284:
  %call.depth.287 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.287, i64 %arg1)
  %callee.status.288 = load i32, ptr %status, align 4
  %callee.succeeded.289 = icmp eq i32 %callee.status.288, 0
  br i1 %callee.succeeded.289, label %callee.continue.291, label %callee.failure.290
callee.failure.290:
  ret void
callee.continue.291:
  %call.output.ptr.292 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.293 = load i64, ptr %call.output.ptr.292, align 8
  %ctx.field.294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.295 = load i32, ptr %ctx.field.294, align 4
  %steps.next.296 = add i32 %steps.current.295, 1
  store i32 %steps.next.296, ptr %ctx.field.294, align 4
  %steps.over.297 = icmp ugt i32 %steps.next.296, 10000
  br i1 %steps.over.297, label %failure.298, label %continue.299
failure.298:
  %ctx.field.300 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 84, ptr %ctx.field.300, align 4
  %status.diagnostic.301 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.301, align 4
  ret void
continue.299:
  %ctx.field.302 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.303 = load i32, ptr %ctx.field.302, align 4
  %steps.next.304 = add i32 %steps.current.303, 1
  store i32 %steps.next.304, ptr %ctx.field.302, align 4
  %steps.over.305 = icmp ugt i32 %steps.next.304, 10000
  br i1 %steps.over.305, label %failure.306, label %continue.307
failure.306:
  %ctx.field.308 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 85, ptr %ctx.field.308, align 4
  %status.diagnostic.309 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.309, align 4
  ret void
continue.307:
  %ctx.field.310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.311 = load i32, ptr %ctx.field.310, align 4
  %steps.next.312 = add i32 %steps.current.311, 1
  store i32 %steps.next.312, ptr %ctx.field.310, align 4
  %steps.over.313 = icmp ugt i32 %steps.next.312, 10000
  br i1 %steps.over.313, label %failure.314, label %continue.315
failure.314:
  %ctx.field.316 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 86, ptr %ctx.field.316, align 4
  %status.diagnostic.317 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.317, align 4
  ret void
continue.315:
  %ctx.field.318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.319 = load i32, ptr %ctx.field.318, align 4
  %steps.next.320 = add i32 %steps.current.319, 1
  store i32 %steps.next.320, ptr %ctx.field.318, align 4
  %steps.over.321 = icmp ugt i32 %steps.next.320, 10000
  br i1 %steps.over.321, label %failure.322, label %continue.323
failure.322:
  %ctx.field.324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 87, ptr %ctx.field.324, align 4
  %status.diagnostic.325 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.325, align 4
  ret void
continue.323:
  %depth.exceeded.326 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.326, label %failure.327, label %continue.328
failure.327:
  %ctx.field.329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 88, ptr %ctx.field.329, align 4
  %status.diagnostic.330 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.330, align 4
  ret void
continue.328:
  %call.depth.331 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.331, i64 %arg1)
  %callee.status.332 = load i32, ptr %status, align 4
  %callee.succeeded.333 = icmp eq i32 %callee.status.332, 0
  br i1 %callee.succeeded.333, label %callee.continue.335, label %callee.failure.334
callee.failure.334:
  ret void
callee.continue.335:
  %call.output.ptr.336 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.337 = load i64, ptr %call.output.ptr.336, align 8
  %ctx.field.338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.339 = load i32, ptr %ctx.field.338, align 4
  %steps.next.340 = add i32 %steps.current.339, 1
  store i32 %steps.next.340, ptr %ctx.field.338, align 4
  %steps.over.341 = icmp ugt i32 %steps.next.340, 10000
  br i1 %steps.over.341, label %failure.342, label %continue.343
failure.342:
  %ctx.field.344 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 89, ptr %ctx.field.344, align 4
  %status.diagnostic.345 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.345, align 4
  ret void
continue.343:
  %ctx.field.346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.347 = load i32, ptr %ctx.field.346, align 4
  %steps.next.348 = add i32 %steps.current.347, 1
  store i32 %steps.next.348, ptr %ctx.field.346, align 4
  %steps.over.349 = icmp ugt i32 %steps.next.348, 10000
  br i1 %steps.over.349, label %failure.350, label %continue.351
failure.350:
  %ctx.field.352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 90, ptr %ctx.field.352, align 4
  %status.diagnostic.353 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.353, align 4
  ret void
continue.351:
  %ctx.field.354 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.355 = load i32, ptr %ctx.field.354, align 4
  %steps.next.356 = add i32 %steps.current.355, 1
  store i32 %steps.next.356, ptr %ctx.field.354, align 4
  %steps.over.357 = icmp ugt i32 %steps.next.356, 10000
  br i1 %steps.over.357, label %failure.358, label %continue.359
failure.358:
  %ctx.field.360 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 91, ptr %ctx.field.360, align 4
  %status.diagnostic.361 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.361, align 4
  ret void
continue.359:
  %ctx.field.362 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.363 = load i32, ptr %ctx.field.362, align 4
  %steps.next.364 = add i32 %steps.current.363, 1
  store i32 %steps.next.364, ptr %ctx.field.362, align 4
  %steps.over.365 = icmp ugt i32 %steps.next.364, 10000
  br i1 %steps.over.365, label %failure.366, label %continue.367
failure.366:
  %ctx.field.368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 92, ptr %ctx.field.368, align 4
  %status.diagnostic.369 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.369, align 4
  ret void
continue.367:
  %depth.exceeded.370 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.370, label %failure.371, label %continue.372
failure.371:
  %ctx.field.373 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 93, ptr %ctx.field.373, align 4
  %status.diagnostic.374 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.374, align 4
  ret void
continue.372:
  %call.depth.375 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.375, i64 %arg1)
  %callee.status.376 = load i32, ptr %status, align 4
  %callee.succeeded.377 = icmp eq i32 %callee.status.376, 0
  br i1 %callee.succeeded.377, label %callee.continue.379, label %callee.failure.378
callee.failure.378:
  ret void
callee.continue.379:
  %call.output.ptr.380 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.381 = load i64, ptr %call.output.ptr.380, align 8
  %ctx.field.382 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.383 = load i32, ptr %ctx.field.382, align 4
  %steps.next.384 = add i32 %steps.current.383, 1
  store i32 %steps.next.384, ptr %ctx.field.382, align 4
  %steps.over.385 = icmp ugt i32 %steps.next.384, 10000
  br i1 %steps.over.385, label %failure.386, label %continue.387
failure.386:
  %ctx.field.388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 94, ptr %ctx.field.388, align 4
  %status.diagnostic.389 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.389, align 4
  ret void
continue.387:
  %ctx.field.390 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.391 = load i32, ptr %ctx.field.390, align 4
  %steps.next.392 = add i32 %steps.current.391, 1
  store i32 %steps.next.392, ptr %ctx.field.390, align 4
  %steps.over.393 = icmp ugt i32 %steps.next.392, 10000
  br i1 %steps.over.393, label %failure.394, label %continue.395
failure.394:
  %ctx.field.396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 95, ptr %ctx.field.396, align 4
  %status.diagnostic.397 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.397, align 4
  ret void
continue.395:
  %ctx.field.398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.399 = load i32, ptr %ctx.field.398, align 4
  %steps.next.400 = add i32 %steps.current.399, 1
  store i32 %steps.next.400, ptr %ctx.field.398, align 4
  %steps.over.401 = icmp ugt i32 %steps.next.400, 10000
  br i1 %steps.over.401, label %failure.402, label %continue.403
failure.402:
  %ctx.field.404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 96, ptr %ctx.field.404, align 4
  %status.diagnostic.405 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.405, align 4
  ret void
continue.403:
  %ctx.field.406 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.407 = load i32, ptr %ctx.field.406, align 4
  %steps.next.408 = add i32 %steps.current.407, 1
  store i32 %steps.next.408, ptr %ctx.field.406, align 4
  %steps.over.409 = icmp ugt i32 %steps.next.408, 10000
  br i1 %steps.over.409, label %failure.410, label %continue.411
failure.410:
  %ctx.field.412 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 97, ptr %ctx.field.412, align 4
  %status.diagnostic.413 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.413, align 4
  ret void
continue.411:
  %depth.exceeded.414 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.414, label %failure.415, label %continue.416
failure.415:
  %ctx.field.417 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 98, ptr %ctx.field.417, align 4
  %status.diagnostic.418 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.418, align 4
  ret void
continue.416:
  %call.depth.419 = add i32 %depth, 1
  call void @agentlang_fn_2c57c82922e1f4a0b755556dae82bfd918d0f6e367b783e31ea3ce04942d1699_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.419, i64 %arg1)
  %callee.status.420 = load i32, ptr %status, align 4
  %callee.succeeded.421 = icmp eq i32 %callee.status.420, 0
  br i1 %callee.succeeded.421, label %callee.continue.423, label %callee.failure.422
callee.failure.422:
  ret void
callee.continue.423:
  %call.output.ptr.424 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.425 = load i64, ptr %call.output.ptr.424, align 8
  %ctx.field.426 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.427 = load i32, ptr %ctx.field.426, align 4
  %steps.next.428 = add i32 %steps.current.427, 1
  store i32 %steps.next.428, ptr %ctx.field.426, align 4
  %steps.over.429 = icmp ugt i32 %steps.next.428, 10000
  br i1 %steps.over.429, label %failure.430, label %continue.431
failure.430:
  %ctx.field.432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 99, ptr %ctx.field.432, align 4
  %status.diagnostic.433 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.433, align 4
  ret void
continue.431:
  %ctx.field.434 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.435 = load i32, ptr %ctx.field.434, align 4
  %steps.next.436 = add i32 %steps.current.435, 1
  store i32 %steps.next.436, ptr %ctx.field.434, align 4
  %steps.over.437 = icmp ugt i32 %steps.next.436, 10000
  br i1 %steps.over.437, label %failure.438, label %continue.439
failure.438:
  %ctx.field.440 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 100, ptr %ctx.field.440, align 4
  %status.diagnostic.441 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.441, align 4
  ret void
continue.439:
  %ctx.field.442 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.443 = load i32, ptr %ctx.field.442, align 4
  %steps.next.444 = add i32 %steps.current.443, 1
  store i32 %steps.next.444, ptr %ctx.field.442, align 4
  %steps.over.445 = icmp ugt i32 %steps.next.444, 10000
  br i1 %steps.over.445, label %failure.446, label %continue.447
failure.446:
  %ctx.field.448 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 101, ptr %ctx.field.448, align 4
  %status.diagnostic.449 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.449, align 4
  ret void
continue.447:
  %ctx.field.450 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.451 = load i32, ptr %ctx.field.450, align 4
  %steps.next.452 = add i32 %steps.current.451, 1
  store i32 %steps.next.452, ptr %ctx.field.450, align 4
  %steps.over.453 = icmp ugt i32 %steps.next.452, 10000
  br i1 %steps.over.453, label %failure.454, label %continue.455
failure.454:
  %ctx.field.456 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 102, ptr %ctx.field.456, align 4
  %status.diagnostic.457 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.457, align 4
  ret void
continue.455:
  %depth.exceeded.458 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.458, label %failure.459, label %continue.460
failure.459:
  %ctx.field.461 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 103, ptr %ctx.field.461, align 4
  %status.diagnostic.462 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.462, align 4
  ret void
continue.460:
  %workspace.slot.463 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.464 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 4, i64 %call.output.81, i32 0, ptr %workspace.slot.463)
  switch i32 %record.field.status.464, label %runtime.invalid.result.470 [ i32 0, label %runtime.success.465 i32 1, label %runtime.invalid.request.466 i32 2, label %runtime.invalid.reference.467 i32 3, label %runtime.scratch.capacity.468 i32 4, label %runtime.retained.capacity.469 ]
runtime.invalid.request.466:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.467:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.468:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.469:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.470:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.465:
  %record.field.value.471 = load i64, ptr %workspace.slot.463, align 8
  %ctx.field.472 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.473 = load i32, ptr %ctx.field.472, align 4
  %steps.next.474 = add i32 %steps.current.473, 1
  store i32 %steps.next.474, ptr %ctx.field.472, align 4
  %steps.over.475 = icmp ugt i32 %steps.next.474, 10000
  br i1 %steps.over.475, label %failure.476, label %continue.477
failure.476:
  %ctx.field.478 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 104, ptr %ctx.field.478, align 4
  %status.diagnostic.479 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.479, align 4
  ret void
continue.477:
  %depth.exceeded.480 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.480, label %failure.481, label %continue.482
failure.481:
  %ctx.field.483 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 105, ptr %ctx.field.483, align 4
  %status.diagnostic.484 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.484, align 4
  ret void
continue.482:
  %workspace.slot.485 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.486 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.field.value.471, i32 0, ptr %workspace.slot.485)
  switch i32 %record.field.status.486, label %runtime.invalid.result.492 [ i32 0, label %runtime.success.487 i32 1, label %runtime.invalid.request.488 i32 2, label %runtime.invalid.reference.489 i32 3, label %runtime.scratch.capacity.490 i32 4, label %runtime.retained.capacity.491 ]
runtime.invalid.request.488:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.489:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.490:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.491:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.492:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.487:
  %record.field.value.493 = load i64, ptr %workspace.slot.485, align 8
  %ctx.field.494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.495 = load i32, ptr %ctx.field.494, align 4
  %steps.next.496 = add i32 %steps.current.495, 1
  store i32 %steps.next.496, ptr %ctx.field.494, align 4
  %steps.over.497 = icmp ugt i32 %steps.next.496, 10000
  br i1 %steps.over.497, label %failure.498, label %continue.499
failure.498:
  %ctx.field.500 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 106, ptr %ctx.field.500, align 4
  %status.diagnostic.501 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.501, align 4
  ret void
continue.499:
  %ctx.field.502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.503 = load i32, ptr %ctx.field.502, align 4
  %steps.next.504 = add i32 %steps.current.503, 1
  store i32 %steps.next.504, ptr %ctx.field.502, align 4
  %steps.over.505 = icmp ugt i32 %steps.next.504, 10000
  br i1 %steps.over.505, label %failure.506, label %continue.507
failure.506:
  %ctx.field.508 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 107, ptr %ctx.field.508, align 4
  %status.diagnostic.509 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.509, align 4
  ret void
continue.507:
  %ctx.field.510 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.511 = load i32, ptr %ctx.field.510, align 4
  %steps.next.512 = add i32 %steps.current.511, 1
  store i32 %steps.next.512, ptr %ctx.field.510, align 4
  %steps.over.513 = icmp ugt i32 %steps.next.512, 10000
  br i1 %steps.over.513, label %failure.514, label %continue.515
failure.514:
  %ctx.field.516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 108, ptr %ctx.field.516, align 4
  %status.diagnostic.517 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.517, align 4
  ret void
continue.515:
  %ctx.field.518 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.519 = load i32, ptr %ctx.field.518, align 4
  %steps.next.520 = add i32 %steps.current.519, 1
  store i32 %steps.next.520, ptr %ctx.field.518, align 4
  %steps.over.521 = icmp ugt i32 %steps.next.520, 10000
  br i1 %steps.over.521, label %failure.522, label %continue.523
failure.522:
  %ctx.field.524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 109, ptr %ctx.field.524, align 4
  %status.diagnostic.525 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.525, align 4
  ret void
continue.523:
  %depth.exceeded.526 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.526, label %failure.527, label %continue.528
failure.527:
  %ctx.field.529 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 110, ptr %ctx.field.529, align 4
  %status.diagnostic.530 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.530, align 4
  ret void
continue.528:
  %scalar.equals.531 = icmp eq i64 %record.field.value.493, %arg1
  %bool.slot.532 = zext i1 %scalar.equals.531 to i64
  %ctx.field.533 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.534 = load i32, ptr %ctx.field.533, align 4
  %steps.next.535 = add i32 %steps.current.534, 1
  store i32 %steps.next.535, ptr %ctx.field.533, align 4
  %steps.over.536 = icmp ugt i32 %steps.next.535, 10000
  br i1 %steps.over.536, label %failure.537, label %continue.538
failure.537:
  %ctx.field.539 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 111, ptr %ctx.field.539, align 4
  %status.diagnostic.540 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.540, align 4
  ret void
continue.538:
  %if.condition.541 = icmp ne i64 %bool.slot.532, 0
  br i1 %if.condition.541, label %if.then.542, label %if.else.543
if.then.542:
  %ctx.field.545 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.546 = load i32, ptr %ctx.field.545, align 4
  %steps.next.547 = add i32 %steps.current.546, 1
  store i32 %steps.next.547, ptr %ctx.field.545, align 4
  %steps.over.548 = icmp ugt i32 %steps.next.547, 10000
  br i1 %steps.over.548, label %failure.549, label %continue.550
failure.549:
  %ctx.field.551 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 112, ptr %ctx.field.551, align 4
  %status.diagnostic.552 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.552, align 4
  ret void
continue.550:
  %ctx.field.553 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.554 = load i32, ptr %ctx.field.553, align 4
  %steps.next.555 = add i32 %steps.current.554, 1
  store i32 %steps.next.555, ptr %ctx.field.553, align 4
  %steps.over.556 = icmp ugt i32 %steps.next.555, 10000
  br i1 %steps.over.556, label %failure.557, label %continue.558
failure.557:
  %ctx.field.559 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 113, ptr %ctx.field.559, align 4
  %status.diagnostic.560 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.560, align 4
  ret void
continue.558:
  br label %if.merge.544
if.else.543:
  %ctx.field.561 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.562 = load i32, ptr %ctx.field.561, align 4
  %steps.next.563 = add i32 %steps.current.562, 1
  store i32 %steps.next.563, ptr %ctx.field.561, align 4
  %steps.over.564 = icmp ugt i32 %steps.next.563, 10000
  br i1 %steps.over.564, label %failure.565, label %continue.566
failure.565:
  %ctx.field.567 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 114, ptr %ctx.field.567, align 4
  %status.diagnostic.568 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.568, align 4
  ret void
continue.566:
  %ctx.field.569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.570 = load i32, ptr %ctx.field.569, align 4
  %steps.next.571 = add i32 %steps.current.570, 1
  store i32 %steps.next.571, ptr %ctx.field.569, align 4
  %steps.over.572 = icmp ugt i32 %steps.next.571, 10000
  br i1 %steps.over.572, label %failure.573, label %continue.574
failure.573:
  %ctx.field.575 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 115, ptr %ctx.field.575, align 4
  %status.diagnostic.576 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.576, align 4
  ret void
continue.574:
  br label %if.merge.544
if.merge.544:
  %stack.phi.577 = phi i64 [ 1, %continue.558 ], [ 2, %continue.574 ]
  %local.phi.578 = phi i64 [ %arg1, %continue.558 ], [ %arg1, %continue.574 ]
  %local.phi.579 = phi i64 [ %arg0, %continue.558 ], [ %arg0, %continue.574 ]
  %local.phi.580 = phi i64 [ %call.output.81, %continue.558 ], [ %call.output.81, %continue.574 ]
  %local.phi.581 = phi i64 [ %record.field.value.493, %continue.558 ], [ %record.field.value.493, %continue.574 ]
  %ctx.field.582 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.583 = load i32, ptr %ctx.field.582, align 4
  %steps.next.584 = add i32 %steps.current.583, 1
  store i32 %steps.next.584, ptr %ctx.field.582, align 4
  %steps.over.585 = icmp ugt i32 %steps.next.584, 10000
  br i1 %steps.over.585, label %failure.586, label %continue.587
failure.586:
  %ctx.field.588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 116, ptr %ctx.field.588, align 4
  %status.diagnostic.589 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.589, align 4
  ret void
continue.587:
  %ctx.field.590 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.591 = load i32, ptr %ctx.field.590, align 4
  %steps.next.592 = add i32 %steps.current.591, 1
  store i32 %steps.next.592, ptr %ctx.field.590, align 4
  %steps.over.593 = icmp ugt i32 %steps.next.592, 10000
  br i1 %steps.over.593, label %failure.594, label %continue.595
failure.594:
  %ctx.field.596 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 117, ptr %ctx.field.596, align 4
  %status.diagnostic.597 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.597, align 4
  ret void
continue.595:
  %ctx.field.598 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.599 = load i32, ptr %ctx.field.598, align 4
  %steps.next.600 = add i32 %steps.current.599, 1
  store i32 %steps.next.600, ptr %ctx.field.598, align 4
  %steps.over.601 = icmp ugt i32 %steps.next.600, 10000
  br i1 %steps.over.601, label %failure.602, label %continue.603
failure.602:
  %ctx.field.604 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 118, ptr %ctx.field.604, align 4
  %status.diagnostic.605 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.605, align 4
  ret void
continue.603:
  %ctx.field.606 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.607 = load i32, ptr %ctx.field.606, align 4
  %steps.next.608 = add i32 %steps.current.607, 1
  store i32 %steps.next.608, ptr %ctx.field.606, align 4
  %steps.over.609 = icmp ugt i32 %steps.next.608, 10000
  br i1 %steps.over.609, label %failure.610, label %continue.611
failure.610:
  %ctx.field.612 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 119, ptr %ctx.field.612, align 4
  %status.diagnostic.613 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.613, align 4
  ret void
continue.611:
  %depth.exceeded.614 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.614, label %failure.615, label %continue.616
failure.615:
  %ctx.field.617 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 120, ptr %ctx.field.617, align 4
  %status.diagnostic.618 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.618, align 4
  ret void
continue.616:
  %workspace.slot.619 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.620 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 6, i64 %local.phi.579, i32 0, ptr %workspace.slot.619)
  switch i32 %record.field.status.620, label %runtime.invalid.result.626 [ i32 0, label %runtime.success.621 i32 1, label %runtime.invalid.request.622 i32 2, label %runtime.invalid.reference.623 i32 3, label %runtime.scratch.capacity.624 i32 4, label %runtime.retained.capacity.625 ]
runtime.invalid.request.622:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.623:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.624:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.625:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.626:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.621:
  %record.field.value.627 = load i64, ptr %workspace.slot.619, align 8
  %ctx.field.628 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.629 = load i32, ptr %ctx.field.628, align 4
  %steps.next.630 = add i32 %steps.current.629, 1
  store i32 %steps.next.630, ptr %ctx.field.628, align 4
  %steps.over.631 = icmp ugt i32 %steps.next.630, 10000
  br i1 %steps.over.631, label %failure.632, label %continue.633
failure.632:
  %ctx.field.634 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 121, ptr %ctx.field.634, align 4
  %status.diagnostic.635 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.635, align 4
  ret void
continue.633:
  %ctx.field.636 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.637 = load i32, ptr %ctx.field.636, align 4
  %steps.next.638 = add i32 %steps.current.637, 1
  store i32 %steps.next.638, ptr %ctx.field.636, align 4
  %steps.over.639 = icmp ugt i32 %steps.next.638, 10000
  br i1 %steps.over.639, label %failure.640, label %continue.641
failure.640:
  %ctx.field.642 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 122, ptr %ctx.field.642, align 4
  %status.diagnostic.643 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.643, align 4
  ret void
continue.641:
  %depth.exceeded.644 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.644, label %failure.645, label %continue.646
failure.645:
  %ctx.field.647 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 123, ptr %ctx.field.647, align 4
  %status.diagnostic.648 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.648, align 4
  ret void
continue.646:
  %checked.tuple.649 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %record.field.value.627, i64 %stack.phi.577)
  %checked.raw.650 = extractvalue { i64, i1 } %checked.tuple.649, 0
  %checked.overflow.651 = extractvalue { i64, i1 } %checked.tuple.649, 1
  br i1 %checked.overflow.651, label %overflow.652, label %checked.653
overflow.652:
  %ctx.field.654 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.655 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %record.field.value.627, ptr %ctx.field.654, align 8
  store i64 %stack.phi.577, ptr %ctx.field.655, align 8
  %ctx.field.656 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 124, ptr %ctx.field.656, align 4
  %status.diagnostic.657 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.657, align 4
  ret void
checked.653:
  %ctx.field.658 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.659 = load i32, ptr %ctx.field.658, align 4
  %steps.next.660 = add i32 %steps.current.659, 1
  store i32 %steps.next.660, ptr %ctx.field.658, align 4
  %steps.over.661 = icmp ugt i32 %steps.next.660, 10000
  br i1 %steps.over.661, label %failure.662, label %continue.663
failure.662:
  %ctx.field.664 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 125, ptr %ctx.field.664, align 4
  %status.diagnostic.665 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.665, align 4
  ret void
continue.663:
  %ctx.field.666 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.667 = load i32, ptr %ctx.field.666, align 4
  %steps.next.668 = add i32 %steps.current.667, 1
  store i32 %steps.next.668, ptr %ctx.field.666, align 4
  %steps.over.669 = icmp ugt i32 %steps.next.668, 10000
  br i1 %steps.over.669, label %failure.670, label %continue.671
failure.670:
  %ctx.field.672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 126, ptr %ctx.field.672, align 4
  %status.diagnostic.673 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.673, align 4
  ret void
continue.671:
  %ctx.field.674 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.675 = load i32, ptr %ctx.field.674, align 4
  %steps.next.676 = add i32 %steps.current.675, 1
  store i32 %steps.next.676, ptr %ctx.field.674, align 4
  %steps.over.677 = icmp ugt i32 %steps.next.676, 10000
  br i1 %steps.over.677, label %failure.678, label %continue.679
failure.678:
  %ctx.field.680 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 127, ptr %ctx.field.680, align 4
  %status.diagnostic.681 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.681, align 4
  ret void
continue.679:
  %ctx.field.682 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.683 = load i32, ptr %ctx.field.682, align 4
  %steps.next.684 = add i32 %steps.current.683, 1
  store i32 %steps.next.684, ptr %ctx.field.682, align 4
  %steps.over.685 = icmp ugt i32 %steps.next.684, 10000
  br i1 %steps.over.685, label %failure.686, label %continue.687
failure.686:
  %ctx.field.688 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 128, ptr %ctx.field.688, align 4
  %status.diagnostic.689 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.689, align 4
  ret void
continue.687:
  %ctx.field.690 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.691 = load i32, ptr %ctx.field.690, align 4
  %steps.next.692 = add i32 %steps.current.691, 1
  store i32 %steps.next.692, ptr %ctx.field.690, align 4
  %steps.over.693 = icmp ugt i32 %steps.next.692, 10000
  br i1 %steps.over.693, label %failure.694, label %continue.695
failure.694:
  %ctx.field.696 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 129, ptr %ctx.field.696, align 4
  %status.diagnostic.697 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.697, align 4
  ret void
continue.695:
  %ctx.field.698 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.699 = load i32, ptr %ctx.field.698, align 4
  %steps.next.700 = add i32 %steps.current.699, 1
  store i32 %steps.next.700, ptr %ctx.field.698, align 4
  %steps.over.701 = icmp ugt i32 %steps.next.700, 10000
  br i1 %steps.over.701, label %failure.702, label %continue.703
failure.702:
  %ctx.field.704 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 130, ptr %ctx.field.704, align 4
  %status.diagnostic.705 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.705, align 4
  ret void
continue.703:
  %depth.exceeded.706 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.706, label %failure.707, label %continue.708
failure.707:
  %ctx.field.709 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 131, ptr %ctx.field.709, align 4
  %status.diagnostic.710 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.710, align 4
  ret void
continue.708:
  %workspace.slot.711 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %checked.raw.650, ptr %workspace.slot.711, align 8
  %workspace.slot.712 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %local.phi.580, ptr %workspace.slot.712, align 8
  %workspace.slot.713 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.714 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 2, ptr %workspace.slot.713)
  switch i32 %record.make.status.714, label %runtime.invalid.result.720 [ i32 0, label %runtime.success.715 i32 1, label %runtime.invalid.request.716 i32 2, label %runtime.invalid.reference.717 i32 3, label %runtime.scratch.capacity.718 i32 4, label %runtime.retained.capacity.719 ]
runtime.invalid.request.716:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.717:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.718:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.719:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.720:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.715:
  %record.make.handle.721 = load i64, ptr %workspace.slot.713, align 8
  %output.ptr.722 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.721, ptr %output.ptr.722, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 1, i32 %capacity, ptr %status, i32 3)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr @agentlang_input_type_ids, i32 2)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  %entry.arg0.ptr = getelementptr inbounds i64, ptr %workspace, i64 0
  %entry.arg0 = load i64, ptr %entry.arg0.ptr, align 8
  %entry.arg1.ptr = getelementptr inbounds i64, ptr %workspace, i64 1
  %entry.arg1 = load i64, ptr %entry.arg1.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0, i64 %entry.arg0, i64 %entry.arg1)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 1, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

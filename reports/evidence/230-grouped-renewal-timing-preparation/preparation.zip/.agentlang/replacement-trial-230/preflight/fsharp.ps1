#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../'))
$hostScriptPath = Join-Path $repositoryRoot 'scripts/Start-SubagentTrialHostV2.ps1'
$cliDll = Join-Path $repositoryRoot '.agentlang/replacement-trial-230/runtime/conventional/AgentLang.Conventional.Cli.dll'
$projectPath = Join-Path $repositoryRoot '.agentlang/replacement-trial-230/preflight/projects/fsharp'
$tracePath = Join-Path $repositoryRoot '.agentlang/replacement-trial-230/preflight/traces/fsharp.jsonl'
$tempPath = Join-Path $repositoryRoot '.agentlang/replacement-trial-230/root/scratch/temp'
$tmpPath = Join-Path $repositoryRoot '.agentlang/replacement-trial-230/root/scratch/tmp'
[IO.Directory]::CreateDirectory($tempPath) | Out-Null
[IO.Directory]::CreateDirectory($tmpPath) | Out-Null
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($tracePath)) | Out-Null
$env:MSBuildEnableWorkloadResolver = 'false'
$env:TEMP = $tempPath
$env:TMP = $tmpPath
$hostArguments = @{
    CliDll = $cliDll
    ProjectPath = $projectPath
    TracePath = $tracePath
    AllowedOperations = @('inspect', 'read', 'search', 'patch', 'replace', 'validate')
    Profile = 'conventional'
    Capabilities = @()
    ClockValue = '2000-01-01T00:00:00Z'
    MaxRequestBytes = 262144
    MaxResponseBytes = 524288
    ExchangeTimeoutMilliseconds = 120000
    MaxExchanges = 100
}
$hostArguments.Add('AdditionalCliArguments', @('--validation-project', 'SubscriptionBatch.Conventional.fsproj', '--max-requests', '100'))
& $hostScriptPath @hostArguments

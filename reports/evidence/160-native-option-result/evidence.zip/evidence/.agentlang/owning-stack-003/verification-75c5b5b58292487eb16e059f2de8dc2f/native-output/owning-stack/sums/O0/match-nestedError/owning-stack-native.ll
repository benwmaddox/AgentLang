%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [24 x i8] c"\05\00\00\00\00\00\00\00\65\00\72\00\72\00\6F\00\72\00\00\00\00\00\00\00", align 8
@al_owning_string_literal_1 = private unnamed_addr constant [16 x i8] c"\04\00\00\00\00\00\00\00\6E\00\6F\00\6E\00\65\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %descriptor.element.31 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 0
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 1
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 2
  %descriptor.value.37 = load i32, ptr %descriptor.field.36, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 3
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 4
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %argument.type.valid.42 = icmp eq i32 %descriptor.value.33, 8
  br i1 %argument.type.valid.42, label %argument.type.ok.43, label %frame.failure.0
argument.type.ok.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.sub.48 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.46 = icmp ule i32 %descriptor.value.41, %context.value.45
  %descriptor.offset.inside.47 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.49 = icmp ule i32 %descriptor.value.37, %stack.sub.48
  %descriptor.payload.inside.50 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.51 = and i1 %descriptor.owner.inside.46, %descriptor.offset.inside.47
  %descriptor.range.inside.53 = and i1 %descriptor.owner.offset.valid.51, %descriptor.extent.inside.49
  %descriptor.range.valid.52 = and i1 %descriptor.range.inside.53, %descriptor.payload.inside.50
  %descriptor.type.valid.54 = icmp eq i32 8, 8
  %descriptor.valid.55 = and i1 %descriptor.range.valid.52, %descriptor.type.valid.54
  br i1 %descriptor.valid.55, label %descriptor.valid.56, label %descriptor.invalid.57
descriptor.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.56:
  %descriptor.initialized.status.58 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.59 = icmp eq i32 %descriptor.initialized.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %option.case.index.pointer.64 = alloca i32, align 4
  %option.case.location.65 = alloca %AlOwningFieldLocation, align 4
  %option.case.location.status.66 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %descriptor.value.35, i32 %descriptor.value.37, i32 2, ptr %option.case.index.pointer.64, ptr %option.case.location.65)
  %helper.ok.67 = icmp eq i32 %option.case.location.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %frame.failure.0
helper.continue.68:
  %option.case.index.69 = load i32, ptr %option.case.index.pointer.64, align 4
  %option.payload.offset.pointer.70 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 0
  %option.payload.offset.71 = load i32, ptr %option.payload.offset.pointer.70, align 4
  %option.payload.bytes.pointer.72 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 1
  %option.payload.bytes.73 = load i32, ptr %option.payload.bytes.pointer.72, align 4
  %option.payload.extent.pointer.74 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 2
  %option.payload.extent.75 = load i32, ptr %option.payload.extent.pointer.74, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %descriptor.value.35, i32 %descriptor.value.37, i32 %descriptor.value.39, i32 0, i32 0)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  switch i32 %option.case.index.69, label %option.invalid-tag.82 [ i32 0, label %option.some.80 i32 1, label %option.none.81 ]
option.invalid-tag.82:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 %option.case.index.69, i32 2)
  br label %frame.failure.0
option.some.80:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %stack.sub.88 = sub i32 %descriptor.value.41, %option.payload.offset.71
  %descriptor.owner.inside.86 = icmp ule i32 %descriptor.value.41, %context.value.85
  %descriptor.offset.inside.87 = icmp ule i32 %option.payload.offset.71, %descriptor.value.41
  %descriptor.extent.inside.89 = icmp ule i32 %option.payload.extent.75, %stack.sub.88
  %descriptor.payload.inside.90 = icmp ule i32 %option.payload.bytes.73, %option.payload.extent.75
  %descriptor.owner.offset.valid.91 = and i1 %descriptor.owner.inside.86, %descriptor.offset.inside.87
  %descriptor.range.inside.93 = and i1 %descriptor.owner.offset.valid.91, %descriptor.extent.inside.89
  %descriptor.range.valid.92 = and i1 %descriptor.range.inside.93, %descriptor.payload.inside.90
  %descriptor.type.valid.94 = icmp eq i32 9, 9
  %descriptor.valid.95 = and i1 %descriptor.range.valid.92, %descriptor.type.valid.94
  br i1 %descriptor.valid.95, label %descriptor.valid.96, label %descriptor.invalid.97
descriptor.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.96:
  %descriptor.initialized.status.98 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %option.payload.offset.71, i32 %option.payload.extent.75)
  %helper.ok.99 = icmp eq i32 %descriptor.initialized.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  store i1 true, ptr %local.active.2, align 1
  store i32 %option.payload.offset.71, ptr %local.offset.3, align 4
  store i32 %option.payload.extent.75, ptr %local.extent.4, align 4
  store i32 %option.payload.bytes.73, ptr %local.payload.5, align 4
  store i32 %descriptor.value.41, ptr %local.owner.end.6, align 4
  store i32 9, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %option.payload.offset.71, i32 20, i32 %option.payload.bytes.73, i32 %descriptor.value.41, i32 %option.payload.extent.75)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %frame.failure.0
runtime.continue.104:
  %step.status.105 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.106 = icmp eq i32 %step.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %frame.failure.0
helper.continue.107:
  %local.resolved.offset.108 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.109 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.110 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.111 = load i32, ptr %local.owner.end.6, align 4
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %local.resolved.owner.end.111, %local.resolved.offset.108
  %descriptor.owner.inside.114 = icmp ule i32 %local.resolved.owner.end.111, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %local.resolved.offset.108, %local.resolved.owner.end.111
  %descriptor.extent.inside.117 = icmp ule i32 %local.resolved.extent.109, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %local.resolved.payload.110, %local.resolved.extent.109
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 9, 9
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %frame.failure.0
helper.continue.128:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.108, i32 20, i32 %local.resolved.payload.110, i32 %local.resolved.owner.end.111, i32 %local.resolved.extent.109)
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %runtime.ok.131 = icmp eq i32 %context.value.130, 0
  br i1 %runtime.ok.131, label %runtime.continue.132, label %frame.failure.0
runtime.continue.132:
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %stack.sub.137 = sub i32 %local.resolved.owner.end.111, %local.resolved.offset.108
  %descriptor.owner.inside.135 = icmp ule i32 %local.resolved.owner.end.111, %context.value.134
  %descriptor.offset.inside.136 = icmp ule i32 %local.resolved.offset.108, %local.resolved.owner.end.111
  %descriptor.extent.inside.138 = icmp ule i32 %local.resolved.extent.109, %stack.sub.137
  %descriptor.payload.inside.139 = icmp ule i32 %local.resolved.payload.110, %local.resolved.extent.109
  %descriptor.owner.offset.valid.140 = and i1 %descriptor.owner.inside.135, %descriptor.offset.inside.136
  %descriptor.range.inside.142 = and i1 %descriptor.owner.offset.valid.140, %descriptor.extent.inside.138
  %descriptor.range.valid.141 = and i1 %descriptor.range.inside.142, %descriptor.payload.inside.139
  %descriptor.type.valid.143 = icmp eq i32 9, 9
  %descriptor.valid.144 = and i1 %descriptor.range.valid.141, %descriptor.type.valid.143
  br i1 %descriptor.valid.144, label %descriptor.valid.145, label %descriptor.invalid.146
descriptor.invalid.146:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.145:
  %descriptor.initialized.status.147 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109)
  %helper.ok.148 = icmp eq i32 %descriptor.initialized.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %local.is.active.150 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.150, label %local.descriptor.active.151, label %local.descriptor.inactive.152
local.descriptor.active.151:
  %local.check.offset.154 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.155 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.156 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.157 = load i32, ptr %local.owner.end.6, align 4
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %stack.sub.162 = sub i32 %local.check.owner.end.157, %local.check.offset.154
  %descriptor.owner.inside.160 = icmp ule i32 %local.check.owner.end.157, %context.value.159
  %descriptor.offset.inside.161 = icmp ule i32 %local.check.offset.154, %local.check.owner.end.157
  %descriptor.extent.inside.163 = icmp ule i32 %local.check.extent.155, %stack.sub.162
  %descriptor.payload.inside.164 = icmp ule i32 %local.check.payload.156, %local.check.extent.155
  %descriptor.owner.offset.valid.165 = and i1 %descriptor.owner.inside.160, %descriptor.offset.inside.161
  %descriptor.range.inside.167 = and i1 %descriptor.owner.offset.valid.165, %descriptor.extent.inside.163
  %descriptor.range.valid.166 = and i1 %descriptor.range.inside.167, %descriptor.payload.inside.164
  br i1 %descriptor.range.valid.166, label %descriptor.valid.168, label %descriptor.invalid.169
descriptor.invalid.169:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.168:
  %descriptor.initialized.status.170 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.154, i32 %local.check.extent.155)
  %helper.ok.171 = icmp eq i32 %descriptor.initialized.status.170, 0
  br i1 %helper.ok.171, label %helper.continue.172, label %frame.failure.0
helper.continue.172:
  br label %local.descriptor.checked.153
local.descriptor.inactive.152:
  br label %local.descriptor.checked.153
local.descriptor.checked.153:
  %local.is.active.173 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.173, label %local.descriptor.active.174, label %local.descriptor.inactive.175
local.descriptor.active.174:
  %local.check.offset.177 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.178 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.179 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.180 = load i32, ptr %local.owner.end.12, align 4
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %stack.sub.185 = sub i32 %local.check.owner.end.180, %local.check.offset.177
  %descriptor.owner.inside.183 = icmp ule i32 %local.check.owner.end.180, %context.value.182
  %descriptor.offset.inside.184 = icmp ule i32 %local.check.offset.177, %local.check.owner.end.180
  %descriptor.extent.inside.186 = icmp ule i32 %local.check.extent.178, %stack.sub.185
  %descriptor.payload.inside.187 = icmp ule i32 %local.check.payload.179, %local.check.extent.178
  %descriptor.owner.offset.valid.188 = and i1 %descriptor.owner.inside.183, %descriptor.offset.inside.184
  %descriptor.range.inside.190 = and i1 %descriptor.owner.offset.valid.188, %descriptor.extent.inside.186
  %descriptor.range.valid.189 = and i1 %descriptor.range.inside.190, %descriptor.payload.inside.187
  br i1 %descriptor.range.valid.189, label %descriptor.valid.191, label %descriptor.invalid.192
descriptor.invalid.192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.191:
  %descriptor.initialized.status.193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.177, i32 %local.check.extent.178)
  %helper.ok.194 = icmp eq i32 %descriptor.initialized.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %frame.failure.0
helper.continue.195:
  br label %local.descriptor.checked.176
local.descriptor.inactive.175:
  br label %local.descriptor.checked.176
local.descriptor.checked.176:
  %local.is.active.196 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.196, label %local.descriptor.active.197, label %local.descriptor.inactive.198
local.descriptor.active.197:
  %local.check.offset.200 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.201 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.202 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.203 = load i32, ptr %local.owner.end.18, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %stack.sub.208 = sub i32 %local.check.owner.end.203, %local.check.offset.200
  %descriptor.owner.inside.206 = icmp ule i32 %local.check.owner.end.203, %context.value.205
  %descriptor.offset.inside.207 = icmp ule i32 %local.check.offset.200, %local.check.owner.end.203
  %descriptor.extent.inside.209 = icmp ule i32 %local.check.extent.201, %stack.sub.208
  %descriptor.payload.inside.210 = icmp ule i32 %local.check.payload.202, %local.check.extent.201
  %descriptor.owner.offset.valid.211 = and i1 %descriptor.owner.inside.206, %descriptor.offset.inside.207
  %descriptor.range.inside.213 = and i1 %descriptor.owner.offset.valid.211, %descriptor.extent.inside.209
  %descriptor.range.valid.212 = and i1 %descriptor.range.inside.213, %descriptor.payload.inside.210
  br i1 %descriptor.range.valid.212, label %descriptor.valid.214, label %descriptor.invalid.215
descriptor.invalid.215:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.214:
  %descriptor.initialized.status.216 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.200, i32 %local.check.extent.201)
  %helper.ok.217 = icmp eq i32 %descriptor.initialized.status.216, 0
  br i1 %helper.ok.217, label %helper.continue.218, label %frame.failure.0
helper.continue.218:
  br label %local.descriptor.checked.199
local.descriptor.inactive.198:
  br label %local.descriptor.checked.199
local.descriptor.checked.199:
  %step.status.219 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.220 = icmp eq i32 %step.status.219, 0
  br i1 %helper.ok.220, label %helper.continue.221, label %frame.failure.0
helper.continue.221:
  %result.case.index.pointer.222 = alloca i32, align 4
  %result.case.location.223 = alloca %AlOwningFieldLocation, align 4
  %result.case.location.status.224 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109, i32 5, ptr %result.case.index.pointer.222, ptr %result.case.location.223)
  %helper.ok.225 = icmp eq i32 %result.case.location.status.224, 0
  br i1 %helper.ok.225, label %helper.continue.226, label %frame.failure.0
helper.continue.226:
  %result.case.index.227 = load i32, ptr %result.case.index.pointer.222, align 4
  %result.payload.offset.pointer.228 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 0
  %result.payload.offset.229 = load i32, ptr %result.payload.offset.pointer.228, align 4
  %result.payload.bytes.pointer.230 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 1
  %result.payload.bytes.231 = load i32, ptr %result.payload.bytes.pointer.230, align 4
  %result.payload.extent.pointer.232 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 2
  %result.payload.extent.233 = load i32, ptr %result.payload.extent.pointer.232, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 9, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109, i32 %local.resolved.payload.110, i32 0, i32 0)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  switch i32 %result.case.index.227, label %result.invalid-tag.240 [ i32 0, label %result.ok.238 i32 1, label %result.error.239 ]
result.invalid-tag.240:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 %result.case.index.227, i32 2)
  br label %frame.failure.0
result.ok.238:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %stack.sub.246 = sub i32 %local.resolved.owner.end.111, %result.payload.offset.229
  %descriptor.owner.inside.244 = icmp ule i32 %local.resolved.owner.end.111, %context.value.243
  %descriptor.offset.inside.245 = icmp ule i32 %result.payload.offset.229, %local.resolved.owner.end.111
  %descriptor.extent.inside.247 = icmp ule i32 %result.payload.extent.233, %stack.sub.246
  %descriptor.payload.inside.248 = icmp ule i32 %result.payload.bytes.231, %result.payload.extent.233
  %descriptor.owner.offset.valid.249 = and i1 %descriptor.owner.inside.244, %descriptor.offset.inside.245
  %descriptor.range.inside.251 = and i1 %descriptor.owner.offset.valid.249, %descriptor.extent.inside.247
  %descriptor.range.valid.250 = and i1 %descriptor.range.inside.251, %descriptor.payload.inside.248
  %descriptor.type.valid.252 = icmp eq i32 7, 7
  %descriptor.valid.253 = and i1 %descriptor.range.valid.250, %descriptor.type.valid.252
  br i1 %descriptor.valid.253, label %descriptor.valid.254, label %descriptor.invalid.255
descriptor.invalid.255:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.254:
  %descriptor.initialized.status.256 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.payload.offset.229, i32 %result.payload.extent.233)
  %helper.ok.257 = icmp eq i32 %descriptor.initialized.status.256, 0
  br i1 %helper.ok.257, label %helper.continue.258, label %frame.failure.0
helper.continue.258:
  store i1 true, ptr %local.active.8, align 1
  store i32 %result.payload.offset.229, ptr %local.offset.9, align 4
  store i32 %result.payload.extent.233, ptr %local.extent.10, align 4
  store i32 %result.payload.bytes.231, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.111, ptr %local.owner.end.12, align 4
  store i32 7, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %result.payload.offset.229, i32 20, i32 %result.payload.bytes.231, i32 %local.resolved.owner.end.111, i32 %result.payload.extent.233)
  %context.field.259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.260 = load i32, ptr %context.field.259, align 4
  %runtime.ok.261 = icmp eq i32 %context.value.260, 0
  br i1 %runtime.ok.261, label %runtime.continue.262, label %frame.failure.0
runtime.continue.262:
  %step.status.263 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.264 = icmp eq i32 %step.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %frame.failure.0
helper.continue.265:
  %local.resolved.offset.266 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.267 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.268 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.269 = load i32, ptr %local.owner.end.12, align 4
  %context.field.270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.271 = load i32, ptr %context.field.270, align 4
  %stack.sub.274 = sub i32 %local.resolved.owner.end.269, %local.resolved.offset.266
  %descriptor.owner.inside.272 = icmp ule i32 %local.resolved.owner.end.269, %context.value.271
  %descriptor.offset.inside.273 = icmp ule i32 %local.resolved.offset.266, %local.resolved.owner.end.269
  %descriptor.extent.inside.275 = icmp ule i32 %local.resolved.extent.267, %stack.sub.274
  %descriptor.payload.inside.276 = icmp ule i32 %local.resolved.payload.268, %local.resolved.extent.267
  %descriptor.owner.offset.valid.277 = and i1 %descriptor.owner.inside.272, %descriptor.offset.inside.273
  %descriptor.range.inside.279 = and i1 %descriptor.owner.offset.valid.277, %descriptor.extent.inside.275
  %descriptor.range.valid.278 = and i1 %descriptor.range.inside.279, %descriptor.payload.inside.276
  %descriptor.type.valid.280 = icmp eq i32 7, 7
  %descriptor.valid.281 = and i1 %descriptor.range.valid.278, %descriptor.type.valid.280
  br i1 %descriptor.valid.281, label %descriptor.valid.282, label %descriptor.invalid.283
descriptor.invalid.283:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.282:
  %descriptor.initialized.status.284 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.266, i32 %local.resolved.extent.267)
  %helper.ok.285 = icmp eq i32 %descriptor.initialized.status.284, 0
  br i1 %helper.ok.285, label %helper.continue.286, label %frame.failure.0
helper.continue.286:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %local.resolved.offset.266, i32 20, i32 %local.resolved.payload.268, i32 %local.resolved.owner.end.269, i32 %local.resolved.extent.267)
  %context.field.287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.288 = load i32, ptr %context.field.287, align 4
  %runtime.ok.289 = icmp eq i32 %context.value.288, 0
  br i1 %runtime.ok.289, label %runtime.continue.290, label %frame.failure.0
runtime.continue.290:
  %context.field.291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.292 = load i32, ptr %context.field.291, align 4
  %stack.sub.295 = sub i32 %local.resolved.owner.end.269, %local.resolved.offset.266
  %descriptor.owner.inside.293 = icmp ule i32 %local.resolved.owner.end.269, %context.value.292
  %descriptor.offset.inside.294 = icmp ule i32 %local.resolved.offset.266, %local.resolved.owner.end.269
  %descriptor.extent.inside.296 = icmp ule i32 %local.resolved.extent.267, %stack.sub.295
  %descriptor.payload.inside.297 = icmp ule i32 %local.resolved.payload.268, %local.resolved.extent.267
  %descriptor.owner.offset.valid.298 = and i1 %descriptor.owner.inside.293, %descriptor.offset.inside.294
  %descriptor.range.inside.300 = and i1 %descriptor.owner.offset.valid.298, %descriptor.extent.inside.296
  %descriptor.range.valid.299 = and i1 %descriptor.range.inside.300, %descriptor.payload.inside.297
  %descriptor.type.valid.301 = icmp eq i32 7, 7
  %descriptor.valid.302 = and i1 %descriptor.range.valid.299, %descriptor.type.valid.301
  br i1 %descriptor.valid.302, label %descriptor.valid.303, label %descriptor.invalid.304
descriptor.invalid.304:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.303:
  %descriptor.initialized.status.305 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.266, i32 %local.resolved.extent.267)
  %helper.ok.306 = icmp eq i32 %descriptor.initialized.status.305, 0
  br i1 %helper.ok.306, label %helper.continue.307, label %frame.failure.0
helper.continue.307:
  %local.is.active.308 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.308, label %local.descriptor.active.309, label %local.descriptor.inactive.310
local.descriptor.active.309:
  %local.check.offset.312 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.313 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.314 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.315 = load i32, ptr %local.owner.end.6, align 4
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %stack.sub.320 = sub i32 %local.check.owner.end.315, %local.check.offset.312
  %descriptor.owner.inside.318 = icmp ule i32 %local.check.owner.end.315, %context.value.317
  %descriptor.offset.inside.319 = icmp ule i32 %local.check.offset.312, %local.check.owner.end.315
  %descriptor.extent.inside.321 = icmp ule i32 %local.check.extent.313, %stack.sub.320
  %descriptor.payload.inside.322 = icmp ule i32 %local.check.payload.314, %local.check.extent.313
  %descriptor.owner.offset.valid.323 = and i1 %descriptor.owner.inside.318, %descriptor.offset.inside.319
  %descriptor.range.inside.325 = and i1 %descriptor.owner.offset.valid.323, %descriptor.extent.inside.321
  %descriptor.range.valid.324 = and i1 %descriptor.range.inside.325, %descriptor.payload.inside.322
  br i1 %descriptor.range.valid.324, label %descriptor.valid.326, label %descriptor.invalid.327
descriptor.invalid.327:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.326:
  %descriptor.initialized.status.328 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.312, i32 %local.check.extent.313)
  %helper.ok.329 = icmp eq i32 %descriptor.initialized.status.328, 0
  br i1 %helper.ok.329, label %helper.continue.330, label %frame.failure.0
helper.continue.330:
  br label %local.descriptor.checked.311
local.descriptor.inactive.310:
  br label %local.descriptor.checked.311
local.descriptor.checked.311:
  %local.is.active.331 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.331, label %local.descriptor.active.332, label %local.descriptor.inactive.333
local.descriptor.active.332:
  %local.check.offset.335 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.336 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.337 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.338 = load i32, ptr %local.owner.end.12, align 4
  %context.field.339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.340 = load i32, ptr %context.field.339, align 4
  %stack.sub.343 = sub i32 %local.check.owner.end.338, %local.check.offset.335
  %descriptor.owner.inside.341 = icmp ule i32 %local.check.owner.end.338, %context.value.340
  %descriptor.offset.inside.342 = icmp ule i32 %local.check.offset.335, %local.check.owner.end.338
  %descriptor.extent.inside.344 = icmp ule i32 %local.check.extent.336, %stack.sub.343
  %descriptor.payload.inside.345 = icmp ule i32 %local.check.payload.337, %local.check.extent.336
  %descriptor.owner.offset.valid.346 = and i1 %descriptor.owner.inside.341, %descriptor.offset.inside.342
  %descriptor.range.inside.348 = and i1 %descriptor.owner.offset.valid.346, %descriptor.extent.inside.344
  %descriptor.range.valid.347 = and i1 %descriptor.range.inside.348, %descriptor.payload.inside.345
  br i1 %descriptor.range.valid.347, label %descriptor.valid.349, label %descriptor.invalid.350
descriptor.invalid.350:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.349:
  %descriptor.initialized.status.351 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.335, i32 %local.check.extent.336)
  %helper.ok.352 = icmp eq i32 %descriptor.initialized.status.351, 0
  br i1 %helper.ok.352, label %helper.continue.353, label %frame.failure.0
helper.continue.353:
  br label %local.descriptor.checked.334
local.descriptor.inactive.333:
  br label %local.descriptor.checked.334
local.descriptor.checked.334:
  %local.is.active.354 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.354, label %local.descriptor.active.355, label %local.descriptor.inactive.356
local.descriptor.active.355:
  %local.check.offset.358 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.359 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.360 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.361 = load i32, ptr %local.owner.end.18, align 4
  %context.field.362 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.363 = load i32, ptr %context.field.362, align 4
  %stack.sub.366 = sub i32 %local.check.owner.end.361, %local.check.offset.358
  %descriptor.owner.inside.364 = icmp ule i32 %local.check.owner.end.361, %context.value.363
  %descriptor.offset.inside.365 = icmp ule i32 %local.check.offset.358, %local.check.owner.end.361
  %descriptor.extent.inside.367 = icmp ule i32 %local.check.extent.359, %stack.sub.366
  %descriptor.payload.inside.368 = icmp ule i32 %local.check.payload.360, %local.check.extent.359
  %descriptor.owner.offset.valid.369 = and i1 %descriptor.owner.inside.364, %descriptor.offset.inside.365
  %descriptor.range.inside.371 = and i1 %descriptor.owner.offset.valid.369, %descriptor.extent.inside.367
  %descriptor.range.valid.370 = and i1 %descriptor.range.inside.371, %descriptor.payload.inside.368
  br i1 %descriptor.range.valid.370, label %descriptor.valid.372, label %descriptor.invalid.373
descriptor.invalid.373:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.372:
  %descriptor.initialized.status.374 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.358, i32 %local.check.extent.359)
  %helper.ok.375 = icmp eq i32 %descriptor.initialized.status.374, 0
  br i1 %helper.ok.375, label %helper.continue.376, label %frame.failure.0
helper.continue.376:
  br label %local.descriptor.checked.357
local.descriptor.inactive.356:
  br label %local.descriptor.checked.357
local.descriptor.checked.357:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  br label %result.join.241
result.error.239:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.378 = load i32, ptr %context.field.377, align 4
  %stack.sub.381 = sub i32 %local.resolved.owner.end.111, %result.payload.offset.229
  %descriptor.owner.inside.379 = icmp ule i32 %local.resolved.owner.end.111, %context.value.378
  %descriptor.offset.inside.380 = icmp ule i32 %result.payload.offset.229, %local.resolved.owner.end.111
  %descriptor.extent.inside.382 = icmp ule i32 %result.payload.extent.233, %stack.sub.381
  %descriptor.payload.inside.383 = icmp ule i32 %result.payload.bytes.231, %result.payload.extent.233
  %descriptor.owner.offset.valid.384 = and i1 %descriptor.owner.inside.379, %descriptor.offset.inside.380
  %descriptor.range.inside.386 = and i1 %descriptor.owner.offset.valid.384, %descriptor.extent.inside.382
  %descriptor.range.valid.385 = and i1 %descriptor.range.inside.386, %descriptor.payload.inside.383
  %descriptor.type.valid.387 = icmp eq i32 1, 1
  %descriptor.valid.388 = and i1 %descriptor.range.valid.385, %descriptor.type.valid.387
  br i1 %descriptor.valid.388, label %descriptor.valid.389, label %descriptor.invalid.390
descriptor.invalid.390:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.389:
  %descriptor.initialized.status.391 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.payload.offset.229, i32 %result.payload.extent.233)
  %helper.ok.392 = icmp eq i32 %descriptor.initialized.status.391, 0
  br i1 %helper.ok.392, label %helper.continue.393, label %frame.failure.0
helper.continue.393:
  store i1 true, ptr %local.active.14, align 1
  store i32 %result.payload.offset.229, ptr %local.offset.15, align 4
  store i32 %result.payload.extent.233, ptr %local.extent.16, align 4
  store i32 %result.payload.bytes.231, ptr %local.payload.17, align 4
  store i32 %local.resolved.owner.end.111, ptr %local.owner.end.18, align 4
  store i32 1, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %result.payload.offset.229, i32 20, i32 %result.payload.bytes.231, i32 %local.resolved.owner.end.111, i32 %result.payload.extent.233)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  %step.status.398 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.399 = icmp eq i32 %step.status.398, 0
  br i1 %helper.ok.399, label %helper.continue.400, label %frame.failure.0
helper.continue.400:
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %stack.offset.403 = add i32 %context.value.402, 24
  %reserve.status.404 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.403, i32 8)
  %reserve.ok.405 = icmp eq i32 %reserve.status.404, 0
  br i1 %reserve.ok.405, label %reserve.continue.406, label %frame.failure.0
reserve.continue.406:
  %literal.status.407 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.402, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 18, i32 24, i32 7, i32 9)
  %helper.ok.408 = icmp eq i32 %literal.status.407, 0
  br i1 %helper.ok.408, label %helper.continue.409, label %frame.failure.0
helper.continue.409:
  %context.field.410 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.411 = load i32, ptr %context.field.410, align 4
  %stack.sub.414 = sub i32 %stack.offset.403, %context.value.402
  %descriptor.owner.inside.412 = icmp ule i32 %stack.offset.403, %context.value.411
  %descriptor.offset.inside.413 = icmp ule i32 %context.value.402, %stack.offset.403
  %descriptor.extent.inside.415 = icmp ule i32 24, %stack.sub.414
  %descriptor.payload.inside.416 = icmp ule i32 18, 24
  %descriptor.owner.offset.valid.417 = and i1 %descriptor.owner.inside.412, %descriptor.offset.inside.413
  %descriptor.range.inside.419 = and i1 %descriptor.owner.offset.valid.417, %descriptor.extent.inside.415
  %descriptor.range.valid.418 = and i1 %descriptor.range.inside.419, %descriptor.payload.inside.416
  %descriptor.type.valid.420 = icmp eq i32 7, 7
  %descriptor.valid.421 = and i1 %descriptor.range.valid.418, %descriptor.type.valid.420
  br i1 %descriptor.valid.421, label %descriptor.valid.422, label %descriptor.invalid.423
descriptor.invalid.423:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.422:
  %descriptor.initialized.status.424 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.402, i32 24)
  %helper.ok.425 = icmp eq i32 %descriptor.initialized.status.424, 0
  br i1 %helper.ok.425, label %helper.continue.426, label %frame.failure.0
helper.continue.426:
  %local.is.active.427 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.427, label %local.descriptor.active.428, label %local.descriptor.inactive.429
local.descriptor.active.428:
  %local.check.offset.431 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.432 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.433 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.434 = load i32, ptr %local.owner.end.6, align 4
  %context.field.435 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.436 = load i32, ptr %context.field.435, align 4
  %stack.sub.439 = sub i32 %local.check.owner.end.434, %local.check.offset.431
  %descriptor.owner.inside.437 = icmp ule i32 %local.check.owner.end.434, %context.value.436
  %descriptor.offset.inside.438 = icmp ule i32 %local.check.offset.431, %local.check.owner.end.434
  %descriptor.extent.inside.440 = icmp ule i32 %local.check.extent.432, %stack.sub.439
  %descriptor.payload.inside.441 = icmp ule i32 %local.check.payload.433, %local.check.extent.432
  %descriptor.owner.offset.valid.442 = and i1 %descriptor.owner.inside.437, %descriptor.offset.inside.438
  %descriptor.range.inside.444 = and i1 %descriptor.owner.offset.valid.442, %descriptor.extent.inside.440
  %descriptor.range.valid.443 = and i1 %descriptor.range.inside.444, %descriptor.payload.inside.441
  br i1 %descriptor.range.valid.443, label %descriptor.valid.445, label %descriptor.invalid.446
descriptor.invalid.446:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.445:
  %descriptor.initialized.status.447 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.431, i32 %local.check.extent.432)
  %helper.ok.448 = icmp eq i32 %descriptor.initialized.status.447, 0
  br i1 %helper.ok.448, label %helper.continue.449, label %frame.failure.0
helper.continue.449:
  br label %local.descriptor.checked.430
local.descriptor.inactive.429:
  br label %local.descriptor.checked.430
local.descriptor.checked.430:
  %local.is.active.450 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.450, label %local.descriptor.active.451, label %local.descriptor.inactive.452
local.descriptor.active.451:
  %local.check.offset.454 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.455 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.456 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.457 = load i32, ptr %local.owner.end.12, align 4
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %stack.sub.462 = sub i32 %local.check.owner.end.457, %local.check.offset.454
  %descriptor.owner.inside.460 = icmp ule i32 %local.check.owner.end.457, %context.value.459
  %descriptor.offset.inside.461 = icmp ule i32 %local.check.offset.454, %local.check.owner.end.457
  %descriptor.extent.inside.463 = icmp ule i32 %local.check.extent.455, %stack.sub.462
  %descriptor.payload.inside.464 = icmp ule i32 %local.check.payload.456, %local.check.extent.455
  %descriptor.owner.offset.valid.465 = and i1 %descriptor.owner.inside.460, %descriptor.offset.inside.461
  %descriptor.range.inside.467 = and i1 %descriptor.owner.offset.valid.465, %descriptor.extent.inside.463
  %descriptor.range.valid.466 = and i1 %descriptor.range.inside.467, %descriptor.payload.inside.464
  br i1 %descriptor.range.valid.466, label %descriptor.valid.468, label %descriptor.invalid.469
descriptor.invalid.469:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.468:
  %descriptor.initialized.status.470 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.454, i32 %local.check.extent.455)
  %helper.ok.471 = icmp eq i32 %descriptor.initialized.status.470, 0
  br i1 %helper.ok.471, label %helper.continue.472, label %frame.failure.0
helper.continue.472:
  br label %local.descriptor.checked.453
local.descriptor.inactive.452:
  br label %local.descriptor.checked.453
local.descriptor.checked.453:
  %local.is.active.473 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.473, label %local.descriptor.active.474, label %local.descriptor.inactive.475
local.descriptor.active.474:
  %local.check.offset.477 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.478 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.479 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.480 = load i32, ptr %local.owner.end.18, align 4
  %context.field.481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.482 = load i32, ptr %context.field.481, align 4
  %stack.sub.485 = sub i32 %local.check.owner.end.480, %local.check.offset.477
  %descriptor.owner.inside.483 = icmp ule i32 %local.check.owner.end.480, %context.value.482
  %descriptor.offset.inside.484 = icmp ule i32 %local.check.offset.477, %local.check.owner.end.480
  %descriptor.extent.inside.486 = icmp ule i32 %local.check.extent.478, %stack.sub.485
  %descriptor.payload.inside.487 = icmp ule i32 %local.check.payload.479, %local.check.extent.478
  %descriptor.owner.offset.valid.488 = and i1 %descriptor.owner.inside.483, %descriptor.offset.inside.484
  %descriptor.range.inside.490 = and i1 %descriptor.owner.offset.valid.488, %descriptor.extent.inside.486
  %descriptor.range.valid.489 = and i1 %descriptor.range.inside.490, %descriptor.payload.inside.487
  br i1 %descriptor.range.valid.489, label %descriptor.valid.491, label %descriptor.invalid.492
descriptor.invalid.492:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.491:
  %descriptor.initialized.status.493 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.477, i32 %local.check.extent.478)
  %helper.ok.494 = icmp eq i32 %descriptor.initialized.status.493, 0
  br i1 %helper.ok.494, label %helper.continue.495, label %frame.failure.0
helper.continue.495:
  br label %local.descriptor.checked.476
local.descriptor.inactive.475:
  br label %local.descriptor.checked.476
local.descriptor.checked.476:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  br label %result.join.241
result.join.241:
  %result.value.offset.496 = phi i32 [ %local.resolved.offset.266, %local.descriptor.checked.357 ], [ %context.value.402, %local.descriptor.checked.476 ]
  %result.value.extent.497 = phi i32 [ %local.resolved.extent.267, %local.descriptor.checked.357 ], [ 24, %local.descriptor.checked.476 ]
  %result.value.payload.498 = phi i32 [ %local.resolved.payload.268, %local.descriptor.checked.357 ], [ 18, %local.descriptor.checked.476 ]
  %result.value.owner.end.499 = phi i32 [ %local.resolved.owner.end.269, %local.descriptor.checked.357 ], [ %stack.offset.403, %local.descriptor.checked.476 ]
  %context.field.500 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.501 = load i32, ptr %context.field.500, align 4
  %stack.sub.504 = sub i32 %result.value.owner.end.499, %result.value.offset.496
  %descriptor.owner.inside.502 = icmp ule i32 %result.value.owner.end.499, %context.value.501
  %descriptor.offset.inside.503 = icmp ule i32 %result.value.offset.496, %result.value.owner.end.499
  %descriptor.extent.inside.505 = icmp ule i32 %result.value.extent.497, %stack.sub.504
  %descriptor.payload.inside.506 = icmp ule i32 %result.value.payload.498, %result.value.extent.497
  %descriptor.owner.offset.valid.507 = and i1 %descriptor.owner.inside.502, %descriptor.offset.inside.503
  %descriptor.range.inside.509 = and i1 %descriptor.owner.offset.valid.507, %descriptor.extent.inside.505
  %descriptor.range.valid.508 = and i1 %descriptor.range.inside.509, %descriptor.payload.inside.506
  %descriptor.type.valid.510 = icmp eq i32 7, 7
  %descriptor.valid.511 = and i1 %descriptor.range.valid.508, %descriptor.type.valid.510
  br i1 %descriptor.valid.511, label %descriptor.valid.512, label %descriptor.invalid.513
descriptor.invalid.513:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.512:
  %descriptor.initialized.status.514 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.value.offset.496, i32 %result.value.extent.497)
  %helper.ok.515 = icmp eq i32 %descriptor.initialized.status.514, 0
  br i1 %helper.ok.515, label %helper.continue.516, label %frame.failure.0
helper.continue.516:
  %local.is.active.517 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.517, label %local.descriptor.active.518, label %local.descriptor.inactive.519
local.descriptor.active.518:
  %local.check.offset.521 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.522 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.523 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.524 = load i32, ptr %local.owner.end.6, align 4
  %context.field.525 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.526 = load i32, ptr %context.field.525, align 4
  %stack.sub.529 = sub i32 %local.check.owner.end.524, %local.check.offset.521
  %descriptor.owner.inside.527 = icmp ule i32 %local.check.owner.end.524, %context.value.526
  %descriptor.offset.inside.528 = icmp ule i32 %local.check.offset.521, %local.check.owner.end.524
  %descriptor.extent.inside.530 = icmp ule i32 %local.check.extent.522, %stack.sub.529
  %descriptor.payload.inside.531 = icmp ule i32 %local.check.payload.523, %local.check.extent.522
  %descriptor.owner.offset.valid.532 = and i1 %descriptor.owner.inside.527, %descriptor.offset.inside.528
  %descriptor.range.inside.534 = and i1 %descriptor.owner.offset.valid.532, %descriptor.extent.inside.530
  %descriptor.range.valid.533 = and i1 %descriptor.range.inside.534, %descriptor.payload.inside.531
  br i1 %descriptor.range.valid.533, label %descriptor.valid.535, label %descriptor.invalid.536
descriptor.invalid.536:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.535:
  %descriptor.initialized.status.537 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.521, i32 %local.check.extent.522)
  %helper.ok.538 = icmp eq i32 %descriptor.initialized.status.537, 0
  br i1 %helper.ok.538, label %helper.continue.539, label %frame.failure.0
helper.continue.539:
  br label %local.descriptor.checked.520
local.descriptor.inactive.519:
  br label %local.descriptor.checked.520
local.descriptor.checked.520:
  %local.is.active.540 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.540, label %local.descriptor.active.541, label %local.descriptor.inactive.542
local.descriptor.active.541:
  %local.check.offset.544 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.545 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.546 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.547 = load i32, ptr %local.owner.end.12, align 4
  %context.field.548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.549 = load i32, ptr %context.field.548, align 4
  %stack.sub.552 = sub i32 %local.check.owner.end.547, %local.check.offset.544
  %descriptor.owner.inside.550 = icmp ule i32 %local.check.owner.end.547, %context.value.549
  %descriptor.offset.inside.551 = icmp ule i32 %local.check.offset.544, %local.check.owner.end.547
  %descriptor.extent.inside.553 = icmp ule i32 %local.check.extent.545, %stack.sub.552
  %descriptor.payload.inside.554 = icmp ule i32 %local.check.payload.546, %local.check.extent.545
  %descriptor.owner.offset.valid.555 = and i1 %descriptor.owner.inside.550, %descriptor.offset.inside.551
  %descriptor.range.inside.557 = and i1 %descriptor.owner.offset.valid.555, %descriptor.extent.inside.553
  %descriptor.range.valid.556 = and i1 %descriptor.range.inside.557, %descriptor.payload.inside.554
  br i1 %descriptor.range.valid.556, label %descriptor.valid.558, label %descriptor.invalid.559
descriptor.invalid.559:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.558:
  %descriptor.initialized.status.560 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.544, i32 %local.check.extent.545)
  %helper.ok.561 = icmp eq i32 %descriptor.initialized.status.560, 0
  br i1 %helper.ok.561, label %helper.continue.562, label %frame.failure.0
helper.continue.562:
  br label %local.descriptor.checked.543
local.descriptor.inactive.542:
  br label %local.descriptor.checked.543
local.descriptor.checked.543:
  %local.is.active.563 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.563, label %local.descriptor.active.564, label %local.descriptor.inactive.565
local.descriptor.active.564:
  %local.check.offset.567 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.568 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.569 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.570 = load i32, ptr %local.owner.end.18, align 4
  %context.field.571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.572 = load i32, ptr %context.field.571, align 4
  %stack.sub.575 = sub i32 %local.check.owner.end.570, %local.check.offset.567
  %descriptor.owner.inside.573 = icmp ule i32 %local.check.owner.end.570, %context.value.572
  %descriptor.offset.inside.574 = icmp ule i32 %local.check.offset.567, %local.check.owner.end.570
  %descriptor.extent.inside.576 = icmp ule i32 %local.check.extent.568, %stack.sub.575
  %descriptor.payload.inside.577 = icmp ule i32 %local.check.payload.569, %local.check.extent.568
  %descriptor.owner.offset.valid.578 = and i1 %descriptor.owner.inside.573, %descriptor.offset.inside.574
  %descriptor.range.inside.580 = and i1 %descriptor.owner.offset.valid.578, %descriptor.extent.inside.576
  %descriptor.range.valid.579 = and i1 %descriptor.range.inside.580, %descriptor.payload.inside.577
  br i1 %descriptor.range.valid.579, label %descriptor.valid.581, label %descriptor.invalid.582
descriptor.invalid.582:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.581:
  %descriptor.initialized.status.583 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.567, i32 %local.check.extent.568)
  %helper.ok.584 = icmp eq i32 %descriptor.initialized.status.583, 0
  br i1 %helper.ok.584, label %helper.continue.585, label %frame.failure.0
helper.continue.585:
  br label %local.descriptor.checked.566
local.descriptor.inactive.565:
  br label %local.descriptor.checked.566
local.descriptor.checked.566:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %option.join.83
option.none.81:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %step.status.586 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.587 = icmp eq i32 %step.status.586, 0
  br i1 %helper.ok.587, label %helper.continue.588, label %frame.failure.0
helper.continue.588:
  %context.field.589 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.590 = load i32, ptr %context.field.589, align 4
  %stack.offset.591 = add i32 %context.value.590, 16
  %reserve.status.592 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.591, i32 11)
  %reserve.ok.593 = icmp eq i32 %reserve.status.592, 0
  br i1 %reserve.ok.593, label %reserve.continue.594, label %frame.failure.0
reserve.continue.594:
  %literal.status.595 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.590, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_1, i64 0, i64 0), i32 16, i32 16, i32 16, i32 7, i32 12)
  %helper.ok.596 = icmp eq i32 %literal.status.595, 0
  br i1 %helper.ok.596, label %helper.continue.597, label %frame.failure.0
helper.continue.597:
  %context.field.598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.599 = load i32, ptr %context.field.598, align 4
  %stack.sub.602 = sub i32 %stack.offset.591, %context.value.590
  %descriptor.owner.inside.600 = icmp ule i32 %stack.offset.591, %context.value.599
  %descriptor.offset.inside.601 = icmp ule i32 %context.value.590, %stack.offset.591
  %descriptor.extent.inside.603 = icmp ule i32 16, %stack.sub.602
  %descriptor.payload.inside.604 = icmp ule i32 16, 16
  %descriptor.owner.offset.valid.605 = and i1 %descriptor.owner.inside.600, %descriptor.offset.inside.601
  %descriptor.range.inside.607 = and i1 %descriptor.owner.offset.valid.605, %descriptor.extent.inside.603
  %descriptor.range.valid.606 = and i1 %descriptor.range.inside.607, %descriptor.payload.inside.604
  %descriptor.type.valid.608 = icmp eq i32 7, 7
  %descriptor.valid.609 = and i1 %descriptor.range.valid.606, %descriptor.type.valid.608
  br i1 %descriptor.valid.609, label %descriptor.valid.610, label %descriptor.invalid.611
descriptor.invalid.611:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.610:
  %descriptor.initialized.status.612 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.590, i32 16)
  %helper.ok.613 = icmp eq i32 %descriptor.initialized.status.612, 0
  br i1 %helper.ok.613, label %helper.continue.614, label %frame.failure.0
helper.continue.614:
  %local.is.active.615 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.615, label %local.descriptor.active.616, label %local.descriptor.inactive.617
local.descriptor.active.616:
  %local.check.offset.619 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.620 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.621 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.622 = load i32, ptr %local.owner.end.6, align 4
  %context.field.623 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.624 = load i32, ptr %context.field.623, align 4
  %stack.sub.627 = sub i32 %local.check.owner.end.622, %local.check.offset.619
  %descriptor.owner.inside.625 = icmp ule i32 %local.check.owner.end.622, %context.value.624
  %descriptor.offset.inside.626 = icmp ule i32 %local.check.offset.619, %local.check.owner.end.622
  %descriptor.extent.inside.628 = icmp ule i32 %local.check.extent.620, %stack.sub.627
  %descriptor.payload.inside.629 = icmp ule i32 %local.check.payload.621, %local.check.extent.620
  %descriptor.owner.offset.valid.630 = and i1 %descriptor.owner.inside.625, %descriptor.offset.inside.626
  %descriptor.range.inside.632 = and i1 %descriptor.owner.offset.valid.630, %descriptor.extent.inside.628
  %descriptor.range.valid.631 = and i1 %descriptor.range.inside.632, %descriptor.payload.inside.629
  br i1 %descriptor.range.valid.631, label %descriptor.valid.633, label %descriptor.invalid.634
descriptor.invalid.634:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.633:
  %descriptor.initialized.status.635 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.619, i32 %local.check.extent.620)
  %helper.ok.636 = icmp eq i32 %descriptor.initialized.status.635, 0
  br i1 %helper.ok.636, label %helper.continue.637, label %frame.failure.0
helper.continue.637:
  br label %local.descriptor.checked.618
local.descriptor.inactive.617:
  br label %local.descriptor.checked.618
local.descriptor.checked.618:
  %local.is.active.638 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.638, label %local.descriptor.active.639, label %local.descriptor.inactive.640
local.descriptor.active.639:
  %local.check.offset.642 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.643 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.644 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.645 = load i32, ptr %local.owner.end.12, align 4
  %context.field.646 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.647 = load i32, ptr %context.field.646, align 4
  %stack.sub.650 = sub i32 %local.check.owner.end.645, %local.check.offset.642
  %descriptor.owner.inside.648 = icmp ule i32 %local.check.owner.end.645, %context.value.647
  %descriptor.offset.inside.649 = icmp ule i32 %local.check.offset.642, %local.check.owner.end.645
  %descriptor.extent.inside.651 = icmp ule i32 %local.check.extent.643, %stack.sub.650
  %descriptor.payload.inside.652 = icmp ule i32 %local.check.payload.644, %local.check.extent.643
  %descriptor.owner.offset.valid.653 = and i1 %descriptor.owner.inside.648, %descriptor.offset.inside.649
  %descriptor.range.inside.655 = and i1 %descriptor.owner.offset.valid.653, %descriptor.extent.inside.651
  %descriptor.range.valid.654 = and i1 %descriptor.range.inside.655, %descriptor.payload.inside.652
  br i1 %descriptor.range.valid.654, label %descriptor.valid.656, label %descriptor.invalid.657
descriptor.invalid.657:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.656:
  %descriptor.initialized.status.658 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.642, i32 %local.check.extent.643)
  %helper.ok.659 = icmp eq i32 %descriptor.initialized.status.658, 0
  br i1 %helper.ok.659, label %helper.continue.660, label %frame.failure.0
helper.continue.660:
  br label %local.descriptor.checked.641
local.descriptor.inactive.640:
  br label %local.descriptor.checked.641
local.descriptor.checked.641:
  %local.is.active.661 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.661, label %local.descriptor.active.662, label %local.descriptor.inactive.663
local.descriptor.active.662:
  %local.check.offset.665 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.666 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.667 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.668 = load i32, ptr %local.owner.end.18, align 4
  %context.field.669 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.670 = load i32, ptr %context.field.669, align 4
  %stack.sub.673 = sub i32 %local.check.owner.end.668, %local.check.offset.665
  %descriptor.owner.inside.671 = icmp ule i32 %local.check.owner.end.668, %context.value.670
  %descriptor.offset.inside.672 = icmp ule i32 %local.check.offset.665, %local.check.owner.end.668
  %descriptor.extent.inside.674 = icmp ule i32 %local.check.extent.666, %stack.sub.673
  %descriptor.payload.inside.675 = icmp ule i32 %local.check.payload.667, %local.check.extent.666
  %descriptor.owner.offset.valid.676 = and i1 %descriptor.owner.inside.671, %descriptor.offset.inside.672
  %descriptor.range.inside.678 = and i1 %descriptor.owner.offset.valid.676, %descriptor.extent.inside.674
  %descriptor.range.valid.677 = and i1 %descriptor.range.inside.678, %descriptor.payload.inside.675
  br i1 %descriptor.range.valid.677, label %descriptor.valid.679, label %descriptor.invalid.680
descriptor.invalid.680:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.679:
  %descriptor.initialized.status.681 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.665, i32 %local.check.extent.666)
  %helper.ok.682 = icmp eq i32 %descriptor.initialized.status.681, 0
  br i1 %helper.ok.682, label %helper.continue.683, label %frame.failure.0
helper.continue.683:
  br label %local.descriptor.checked.664
local.descriptor.inactive.663:
  br label %local.descriptor.checked.664
local.descriptor.checked.664:
  br label %option.join.83
option.join.83:
  %option.value.offset.684 = phi i32 [ %result.value.offset.496, %local.descriptor.checked.566 ], [ %context.value.590, %local.descriptor.checked.664 ]
  %option.value.extent.685 = phi i32 [ %result.value.extent.497, %local.descriptor.checked.566 ], [ 16, %local.descriptor.checked.664 ]
  %option.value.payload.686 = phi i32 [ %result.value.payload.498, %local.descriptor.checked.566 ], [ 16, %local.descriptor.checked.664 ]
  %option.value.owner.end.687 = phi i32 [ %result.value.owner.end.499, %local.descriptor.checked.566 ], [ %stack.offset.591, %local.descriptor.checked.664 ]
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %stack.sub.692 = sub i32 %option.value.owner.end.687, %option.value.offset.684
  %descriptor.owner.inside.690 = icmp ule i32 %option.value.owner.end.687, %context.value.689
  %descriptor.offset.inside.691 = icmp ule i32 %option.value.offset.684, %option.value.owner.end.687
  %descriptor.extent.inside.693 = icmp ule i32 %option.value.extent.685, %stack.sub.692
  %descriptor.payload.inside.694 = icmp ule i32 %option.value.payload.686, %option.value.extent.685
  %descriptor.owner.offset.valid.695 = and i1 %descriptor.owner.inside.690, %descriptor.offset.inside.691
  %descriptor.range.inside.697 = and i1 %descriptor.owner.offset.valid.695, %descriptor.extent.inside.693
  %descriptor.range.valid.696 = and i1 %descriptor.range.inside.697, %descriptor.payload.inside.694
  %descriptor.type.valid.698 = icmp eq i32 7, 7
  %descriptor.valid.699 = and i1 %descriptor.range.valid.696, %descriptor.type.valid.698
  br i1 %descriptor.valid.699, label %descriptor.valid.700, label %descriptor.invalid.701
descriptor.invalid.701:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.700:
  %descriptor.initialized.status.702 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %option.value.offset.684, i32 %option.value.extent.685)
  %helper.ok.703 = icmp eq i32 %descriptor.initialized.status.702, 0
  br i1 %helper.ok.703, label %helper.continue.704, label %frame.failure.0
helper.continue.704:
  %local.is.active.705 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.705, label %local.descriptor.active.706, label %local.descriptor.inactive.707
local.descriptor.active.706:
  %local.check.offset.709 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.710 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.711 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.712 = load i32, ptr %local.owner.end.6, align 4
  %context.field.713 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.714 = load i32, ptr %context.field.713, align 4
  %stack.sub.717 = sub i32 %local.check.owner.end.712, %local.check.offset.709
  %descriptor.owner.inside.715 = icmp ule i32 %local.check.owner.end.712, %context.value.714
  %descriptor.offset.inside.716 = icmp ule i32 %local.check.offset.709, %local.check.owner.end.712
  %descriptor.extent.inside.718 = icmp ule i32 %local.check.extent.710, %stack.sub.717
  %descriptor.payload.inside.719 = icmp ule i32 %local.check.payload.711, %local.check.extent.710
  %descriptor.owner.offset.valid.720 = and i1 %descriptor.owner.inside.715, %descriptor.offset.inside.716
  %descriptor.range.inside.722 = and i1 %descriptor.owner.offset.valid.720, %descriptor.extent.inside.718
  %descriptor.range.valid.721 = and i1 %descriptor.range.inside.722, %descriptor.payload.inside.719
  br i1 %descriptor.range.valid.721, label %descriptor.valid.723, label %descriptor.invalid.724
descriptor.invalid.724:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.723:
  %descriptor.initialized.status.725 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.709, i32 %local.check.extent.710)
  %helper.ok.726 = icmp eq i32 %descriptor.initialized.status.725, 0
  br i1 %helper.ok.726, label %helper.continue.727, label %frame.failure.0
helper.continue.727:
  br label %local.descriptor.checked.708
local.descriptor.inactive.707:
  br label %local.descriptor.checked.708
local.descriptor.checked.708:
  %local.is.active.728 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.728, label %local.descriptor.active.729, label %local.descriptor.inactive.730
local.descriptor.active.729:
  %local.check.offset.732 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.733 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.734 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.735 = load i32, ptr %local.owner.end.12, align 4
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.737 = load i32, ptr %context.field.736, align 4
  %stack.sub.740 = sub i32 %local.check.owner.end.735, %local.check.offset.732
  %descriptor.owner.inside.738 = icmp ule i32 %local.check.owner.end.735, %context.value.737
  %descriptor.offset.inside.739 = icmp ule i32 %local.check.offset.732, %local.check.owner.end.735
  %descriptor.extent.inside.741 = icmp ule i32 %local.check.extent.733, %stack.sub.740
  %descriptor.payload.inside.742 = icmp ule i32 %local.check.payload.734, %local.check.extent.733
  %descriptor.owner.offset.valid.743 = and i1 %descriptor.owner.inside.738, %descriptor.offset.inside.739
  %descriptor.range.inside.745 = and i1 %descriptor.owner.offset.valid.743, %descriptor.extent.inside.741
  %descriptor.range.valid.744 = and i1 %descriptor.range.inside.745, %descriptor.payload.inside.742
  br i1 %descriptor.range.valid.744, label %descriptor.valid.746, label %descriptor.invalid.747
descriptor.invalid.747:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.746:
  %descriptor.initialized.status.748 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.732, i32 %local.check.extent.733)
  %helper.ok.749 = icmp eq i32 %descriptor.initialized.status.748, 0
  br i1 %helper.ok.749, label %helper.continue.750, label %frame.failure.0
helper.continue.750:
  br label %local.descriptor.checked.731
local.descriptor.inactive.730:
  br label %local.descriptor.checked.731
local.descriptor.checked.731:
  %local.is.active.751 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.751, label %local.descriptor.active.752, label %local.descriptor.inactive.753
local.descriptor.active.752:
  %local.check.offset.755 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.756 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.757 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.758 = load i32, ptr %local.owner.end.18, align 4
  %context.field.759 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.760 = load i32, ptr %context.field.759, align 4
  %stack.sub.763 = sub i32 %local.check.owner.end.758, %local.check.offset.755
  %descriptor.owner.inside.761 = icmp ule i32 %local.check.owner.end.758, %context.value.760
  %descriptor.offset.inside.762 = icmp ule i32 %local.check.offset.755, %local.check.owner.end.758
  %descriptor.extent.inside.764 = icmp ule i32 %local.check.extent.756, %stack.sub.763
  %descriptor.payload.inside.765 = icmp ule i32 %local.check.payload.757, %local.check.extent.756
  %descriptor.owner.offset.valid.766 = and i1 %descriptor.owner.inside.761, %descriptor.offset.inside.762
  %descriptor.range.inside.768 = and i1 %descriptor.owner.offset.valid.766, %descriptor.extent.inside.764
  %descriptor.range.valid.767 = and i1 %descriptor.range.inside.768, %descriptor.payload.inside.765
  br i1 %descriptor.range.valid.767, label %descriptor.valid.769, label %descriptor.invalid.770
descriptor.invalid.770:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.769:
  %descriptor.initialized.status.771 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.755, i32 %local.check.extent.756)
  %helper.ok.772 = icmp eq i32 %descriptor.initialized.status.771, 0
  br i1 %helper.ok.772, label %helper.continue.773, label %frame.failure.0
helper.continue.773:
  br label %local.descriptor.checked.754
local.descriptor.inactive.753:
  br label %local.descriptor.checked.754
local.descriptor.checked.754:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.774 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.775 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.774, i32 0, i32 0
  store i32 7, ptr %descriptor.field.775, align 4
  %descriptor.field.776 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.774, i32 0, i32 1
  store i32 %option.value.offset.684, ptr %descriptor.field.776, align 4
  %descriptor.field.777 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.774, i32 0, i32 2
  store i32 %option.value.extent.685, ptr %descriptor.field.777, align 4
  %descriptor.field.778 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.774, i32 0, i32 3
  store i32 %option.value.payload.686, ptr %descriptor.field.778, align 4
  %descriptor.field.779 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.774, i32 0, i32 4
  store i32 %option.value.owner.end.687, ptr %descriptor.field.779, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %option.value.offset.684, i32 20, i32 %option.value.payload.686, i32 %option.value.owner.end.687, i32 %option.value.extent.685)
  %context.field.780 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.781 = load i32, ptr %context.field.780, align 4
  %runtime.ok.782 = icmp eq i32 %context.value.781, 0
  br i1 %runtime.ok.782, label %runtime.continue.783, label %frame.failure.0
runtime.continue.783:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.784 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.785 = load i32, ptr %context.field.784, align 4
  %context.field.786 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.787 = load i32, ptr %context.field.786, align 4
  %context.field.788 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.789 = load i32, ptr %context.field.788, align 4
  %stack.offset.790 = add i32 %context.value.23, %context.value.25
  %stack.offset.791 = add i32 %context.value.785, %context.value.787
  %stack.sub.792 = sub i32 %stack.offset.790, %stack.offset.791
  %stack.sub.793 = sub i32 %context.value.25, %context.value.787
  %stack.sub.794 = sub i32 %context.value.789, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.792, i32 %stack.sub.793)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.794)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 13, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 13, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 13, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 14)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 8, i32 15)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 8, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 16)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 7
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 7, 7
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 7)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [2 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 2, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %argument.type.valid.30 = icmp eq i32 %descriptor.value.21, 8
  br i1 %argument.type.valid.30, label %argument.type.ok.31, label %frame.failure.0
argument.type.ok.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.sub.36 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.34 = icmp ule i32 %descriptor.value.29, %context.value.33
  %descriptor.offset.inside.35 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.37 = icmp ule i32 %descriptor.value.25, %stack.sub.36
  %descriptor.payload.inside.38 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.39 = and i1 %descriptor.owner.inside.34, %descriptor.offset.inside.35
  %descriptor.range.inside.41 = and i1 %descriptor.owner.offset.valid.39, %descriptor.extent.inside.37
  %descriptor.range.valid.40 = and i1 %descriptor.range.inside.41, %descriptor.payload.inside.38
  %descriptor.type.valid.42 = icmp eq i32 8, 8
  %descriptor.valid.43 = and i1 %descriptor.range.valid.40, %descriptor.type.valid.42
  br i1 %descriptor.valid.43, label %descriptor.valid.44, label %descriptor.invalid.45
descriptor.invalid.45:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.44:
  %descriptor.initialized.status.46 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.47 = icmp eq i32 %descriptor.initialized.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %frame.failure.0
helper.continue.51:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.23, ptr %local.offset.3, align 4
  store i32 %descriptor.value.25, ptr %local.extent.4, align 4
  store i32 %descriptor.value.27, ptr %local.payload.5, align 4
  store i32 %descriptor.value.29, ptr %local.owner.end.6, align 4
  store i32 8, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.23, i32 20, i32 %descriptor.value.27, i32 %descriptor.value.29, i32 %descriptor.value.25)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.56, label %local.descriptor.active.57, label %local.descriptor.inactive.58
local.descriptor.active.57:
  %local.check.offset.60 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.61 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.62 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.63 = load i32, ptr %local.owner.end.6, align 4
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %local.check.owner.end.63, %local.check.offset.60
  %descriptor.owner.inside.66 = icmp ule i32 %local.check.owner.end.63, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %local.check.offset.60, %local.check.owner.end.63
  %descriptor.extent.inside.69 = icmp ule i32 %local.check.extent.61, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %local.check.payload.62, %local.check.extent.61
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  br i1 %descriptor.range.valid.72, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.60, i32 %local.check.extent.61)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  br label %local.descriptor.checked.59
local.descriptor.inactive.58:
  br label %local.descriptor.checked.59
local.descriptor.checked.59:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %local.resolved.offset.82 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.83 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.84 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.85 = load i32, ptr %local.owner.end.6, align 4
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.88 = icmp ule i32 %local.resolved.owner.end.85, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.91 = icmp ule i32 %local.resolved.extent.83, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 8, 8
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.109 = icmp ule i32 %local.resolved.owner.end.85, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.112 = icmp ule i32 %local.resolved.extent.83, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 8, 8
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %frame.failure.0
helper.continue.123:
  %local.is.active.124 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.124, label %local.descriptor.active.125, label %local.descriptor.inactive.126
local.descriptor.active.125:
  %local.check.offset.128 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.129 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.130 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.131 = load i32, ptr %local.owner.end.6, align 4
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %local.check.owner.end.131, %local.check.offset.128
  %descriptor.owner.inside.134 = icmp ule i32 %local.check.owner.end.131, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %local.check.offset.128, %local.check.owner.end.131
  %descriptor.extent.inside.137 = icmp ule i32 %local.check.extent.129, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %local.check.payload.130, %local.check.extent.129
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  br i1 %descriptor.range.valid.140, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.128, i32 %local.check.extent.129)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  br label %local.descriptor.checked.127
local.descriptor.inactive.126:
  br label %local.descriptor.checked.127
local.descriptor.checked.127:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %call.arguments.150 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.151 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.150, i32 0
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 0
  store i32 8, ptr %descriptor.field.152, align 4
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 1
  store i32 %local.resolved.offset.82, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 2
  store i32 %local.resolved.extent.83, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 3
  store i32 %local.resolved.payload.84, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 4
  store i32 %local.resolved.owner.end.85, ptr %descriptor.field.156, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  %call.results.161 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.162 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.150, ptr %call.results.161, i32 4)
  %helper.ok.163 = icmp eq i32 %callee.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  %descriptor.element.165 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.161, i32 0
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 0
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 1
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 2
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 3
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 4
  %descriptor.value.175 = load i32, ptr %descriptor.field.174, align 4
  %callee.result.type.valid.176 = icmp eq i32 %descriptor.value.167, 8
  br i1 %callee.result.type.valid.176, label %callee.result.type.ok.177, label %frame.failure.0
callee.result.type.ok.177:
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.182 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.180 = icmp ule i32 %descriptor.value.175, %context.value.179
  %descriptor.offset.inside.181 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.183 = icmp ule i32 %descriptor.value.171, %stack.sub.182
  %descriptor.payload.inside.184 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.185 = and i1 %descriptor.owner.inside.180, %descriptor.offset.inside.181
  %descriptor.range.inside.187 = and i1 %descriptor.owner.offset.valid.185, %descriptor.extent.inside.183
  %descriptor.range.valid.186 = and i1 %descriptor.range.inside.187, %descriptor.payload.inside.184
  %descriptor.type.valid.188 = icmp eq i32 8, 8
  %descriptor.valid.189 = and i1 %descriptor.range.valid.186, %descriptor.type.valid.188
  br i1 %descriptor.valid.189, label %descriptor.valid.190, label %descriptor.invalid.191
descriptor.invalid.191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.190:
  %descriptor.initialized.status.192 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.193 = icmp eq i32 %descriptor.initialized.status.192, 0
  br i1 %helper.ok.193, label %helper.continue.194, label %frame.failure.0
helper.continue.194:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.169, i32 20, i32 %descriptor.value.173, i32 %descriptor.value.175, i32 %descriptor.value.171)
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %runtime.ok.197 = icmp eq i32 %context.value.196, 0
  br i1 %runtime.ok.197, label %runtime.continue.198, label %frame.failure.0
runtime.continue.198:
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %stack.sub.203 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.201 = icmp ule i32 %descriptor.value.175, %context.value.200
  %descriptor.offset.inside.202 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.204 = icmp ule i32 %descriptor.value.171, %stack.sub.203
  %descriptor.payload.inside.205 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.206 = and i1 %descriptor.owner.inside.201, %descriptor.offset.inside.202
  %descriptor.range.inside.208 = and i1 %descriptor.owner.offset.valid.206, %descriptor.extent.inside.204
  %descriptor.range.valid.207 = and i1 %descriptor.range.inside.208, %descriptor.payload.inside.205
  %descriptor.type.valid.209 = icmp eq i32 8, 8
  %descriptor.valid.210 = and i1 %descriptor.range.valid.207, %descriptor.type.valid.209
  br i1 %descriptor.valid.210, label %descriptor.valid.211, label %descriptor.invalid.212
descriptor.invalid.212:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.211:
  %descriptor.initialized.status.213 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.214 = icmp eq i32 %descriptor.initialized.status.213, 0
  br i1 %helper.ok.214, label %helper.continue.215, label %frame.failure.0
helper.continue.215:
  %local.is.active.216 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.216, label %local.descriptor.active.217, label %local.descriptor.inactive.218
local.descriptor.active.217:
  %local.check.offset.220 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.221 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.222 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.223 = load i32, ptr %local.owner.end.6, align 4
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %stack.sub.228 = sub i32 %local.check.owner.end.223, %local.check.offset.220
  %descriptor.owner.inside.226 = icmp ule i32 %local.check.owner.end.223, %context.value.225
  %descriptor.offset.inside.227 = icmp ule i32 %local.check.offset.220, %local.check.owner.end.223
  %descriptor.extent.inside.229 = icmp ule i32 %local.check.extent.221, %stack.sub.228
  %descriptor.payload.inside.230 = icmp ule i32 %local.check.payload.222, %local.check.extent.221
  %descriptor.owner.offset.valid.231 = and i1 %descriptor.owner.inside.226, %descriptor.offset.inside.227
  %descriptor.range.inside.233 = and i1 %descriptor.owner.offset.valid.231, %descriptor.extent.inside.229
  %descriptor.range.valid.232 = and i1 %descriptor.range.inside.233, %descriptor.payload.inside.230
  br i1 %descriptor.range.valid.232, label %descriptor.valid.234, label %descriptor.invalid.235
descriptor.invalid.235:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.234:
  %descriptor.initialized.status.236 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.220, i32 %local.check.extent.221)
  %helper.ok.237 = icmp eq i32 %descriptor.initialized.status.236, 0
  br i1 %helper.ok.237, label %helper.continue.238, label %frame.failure.0
helper.continue.238:
  br label %local.descriptor.checked.219
local.descriptor.inactive.218:
  br label %local.descriptor.checked.219
local.descriptor.checked.219:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.239 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.240 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.239, i32 0, i32 0
  store i32 8, ptr %descriptor.field.240, align 4
  %descriptor.field.241 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.239, i32 0, i32 1
  store i32 %descriptor.value.169, ptr %descriptor.field.241, align 4
  %descriptor.field.242 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.239, i32 0, i32 2
  store i32 %descriptor.value.171, ptr %descriptor.field.242, align 4
  %descriptor.field.243 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.239, i32 0, i32 3
  store i32 %descriptor.value.173, ptr %descriptor.field.243, align 4
  %descriptor.field.244 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.239, i32 0, i32 4
  store i32 %descriptor.value.175, ptr %descriptor.field.244, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.169, i32 20, i32 %descriptor.value.173, i32 %descriptor.value.175, i32 %descriptor.value.171)
  %context.field.245 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.246 = load i32, ptr %context.field.245, align 4
  %runtime.ok.247 = icmp eq i32 %context.value.246, 0
  br i1 %runtime.ok.247, label %runtime.continue.248, label %frame.failure.0
runtime.continue.248:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.250 = load i32, ptr %context.field.249, align 4
  %context.field.251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.252 = load i32, ptr %context.field.251, align 4
  %context.field.253 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.254 = load i32, ptr %context.field.253, align 4
  %stack.offset.255 = add i32 %context.value.11, %context.value.13
  %stack.offset.256 = add i32 %context.value.250, %context.value.252
  %stack.sub.257 = sub i32 %stack.offset.255, %stack.offset.256
  %stack.sub.258 = sub i32 %context.value.13, %context.value.252
  %stack.sub.259 = sub i32 %context.value.254, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.257, i32 %stack.sub.258)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.259)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %argument.type.valid.30 = icmp eq i32 %descriptor.value.21, 8
  br i1 %argument.type.valid.30, label %argument.type.ok.31, label %frame.failure.0
argument.type.ok.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.sub.36 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.34 = icmp ule i32 %descriptor.value.29, %context.value.33
  %descriptor.offset.inside.35 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.37 = icmp ule i32 %descriptor.value.25, %stack.sub.36
  %descriptor.payload.inside.38 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.39 = and i1 %descriptor.owner.inside.34, %descriptor.offset.inside.35
  %descriptor.range.inside.41 = and i1 %descriptor.owner.offset.valid.39, %descriptor.extent.inside.37
  %descriptor.range.valid.40 = and i1 %descriptor.range.inside.41, %descriptor.payload.inside.38
  %descriptor.type.valid.42 = icmp eq i32 8, 8
  %descriptor.valid.43 = and i1 %descriptor.range.valid.40, %descriptor.type.valid.42
  br i1 %descriptor.valid.43, label %descriptor.valid.44, label %descriptor.invalid.45
descriptor.invalid.45:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.44:
  %descriptor.initialized.status.46 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.47 = icmp eq i32 %descriptor.initialized.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %frame.failure.0
helper.continue.51:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.23, ptr %local.offset.3, align 4
  store i32 %descriptor.value.25, ptr %local.extent.4, align 4
  store i32 %descriptor.value.27, ptr %local.payload.5, align 4
  store i32 %descriptor.value.29, ptr %local.owner.end.6, align 4
  store i32 8, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.23, i32 20, i32 %descriptor.value.27, i32 %descriptor.value.29, i32 %descriptor.value.25)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.56, label %local.descriptor.active.57, label %local.descriptor.inactive.58
local.descriptor.active.57:
  %local.check.offset.60 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.61 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.62 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.63 = load i32, ptr %local.owner.end.6, align 4
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %local.check.owner.end.63, %local.check.offset.60
  %descriptor.owner.inside.66 = icmp ule i32 %local.check.owner.end.63, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %local.check.offset.60, %local.check.owner.end.63
  %descriptor.extent.inside.69 = icmp ule i32 %local.check.extent.61, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %local.check.payload.62, %local.check.extent.61
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  br i1 %descriptor.range.valid.72, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.60, i32 %local.check.extent.61)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  br label %local.descriptor.checked.59
local.descriptor.inactive.58:
  br label %local.descriptor.checked.59
local.descriptor.checked.59:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %local.resolved.offset.82 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.83 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.84 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.85 = load i32, ptr %local.owner.end.6, align 4
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.88 = icmp ule i32 %local.resolved.owner.end.85, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.91 = icmp ule i32 %local.resolved.extent.83, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 8, 8
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.109 = icmp ule i32 %local.resolved.owner.end.85, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.112 = icmp ule i32 %local.resolved.extent.83, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 8, 8
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %frame.failure.0
helper.continue.123:
  %local.is.active.124 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.124, label %local.descriptor.active.125, label %local.descriptor.inactive.126
local.descriptor.active.125:
  %local.check.offset.128 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.129 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.130 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.131 = load i32, ptr %local.owner.end.6, align 4
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %local.check.owner.end.131, %local.check.offset.128
  %descriptor.owner.inside.134 = icmp ule i32 %local.check.owner.end.131, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %local.check.offset.128, %local.check.owner.end.131
  %descriptor.extent.inside.137 = icmp ule i32 %local.check.extent.129, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %local.check.payload.130, %local.check.extent.129
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  br i1 %descriptor.range.valid.140, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.128, i32 %local.check.extent.129)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  br label %local.descriptor.checked.127
local.descriptor.inactive.126:
  br label %local.descriptor.checked.127
local.descriptor.checked.127:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %stack.sub.149 = sub i32 %context.value.148, %context.value.9
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.9, i32 %stack.sub.149, i32 0, i32 0, i32 0)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %descriptor.element.158 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.159 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.158, i32 0, i32 0
  store i32 8, ptr %descriptor.field.159, align 4
  %descriptor.field.160 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.158, i32 0, i32 1
  store i32 %local.resolved.offset.82, ptr %descriptor.field.160, align 4
  %descriptor.field.161 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.158, i32 0, i32 2
  store i32 %local.resolved.extent.83, ptr %descriptor.field.161, align 4
  %descriptor.field.162 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.158, i32 0, i32 3
  store i32 %local.resolved.payload.84, ptr %descriptor.field.162, align 4
  %descriptor.field.163 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.158, i32 0, i32 4
  store i32 %local.resolved.owner.end.85, ptr %descriptor.field.163, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.11, %context.value.13
  %stack.offset.175 = add i32 %context.value.169, %context.value.171
  %stack.sub.176 = sub i32 %stack.offset.174, %stack.offset.175
  %stack.sub.177 = sub i32 %context.value.13, %context.value.171
  %stack.sub.178 = sub i32 %context.value.173, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.176, i32 %stack.sub.177)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.178)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 7, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 8)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 8, i32 9)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 8, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 10)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 8
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 8, 8
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 8)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


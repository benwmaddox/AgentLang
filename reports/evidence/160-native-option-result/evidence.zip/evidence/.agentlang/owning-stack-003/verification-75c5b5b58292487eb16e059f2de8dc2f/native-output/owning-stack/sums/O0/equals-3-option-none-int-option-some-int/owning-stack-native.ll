%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.17, i64 1, i32 8)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.17, i32 8, i32 8, i32 0, i32 0)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %frame.failure.0
runtime.continue.33:
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %stack.sub.38 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.36 = icmp ule i32 %stack.offset.18, %context.value.35
  %descriptor.offset.inside.37 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.39 = icmp ule i32 8, %stack.sub.38
  %descriptor.payload.inside.40 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.41 = and i1 %descriptor.owner.inside.36, %descriptor.offset.inside.37
  %descriptor.range.inside.43 = and i1 %descriptor.owner.offset.valid.41, %descriptor.extent.inside.39
  %descriptor.range.valid.42 = and i1 %descriptor.range.inside.43, %descriptor.payload.inside.40
  %descriptor.type.valid.44 = icmp eq i32 8, 8
  %descriptor.valid.45 = and i1 %descriptor.range.valid.42, %descriptor.type.valid.44
  br i1 %descriptor.valid.45, label %descriptor.valid.46, label %descriptor.invalid.47
descriptor.invalid.47:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.46:
  %descriptor.initialized.status.48 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.49 = icmp eq i32 %descriptor.initialized.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %frame.failure.0
helper.continue.50:
  %step.status.51 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.52 = icmp eq i32 %step.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %stack.offset.56 = add i32 %context.value.55, 8
  %reserve.status.57 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.56, i32 4)
  %reserve.ok.58 = icmp eq i32 %reserve.status.57, 0
  br i1 %reserve.ok.58, label %reserve.continue.59, label %frame.failure.0
reserve.continue.59:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.55, i64 42, i32 1)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.70 = icmp ule i32 %stack.offset.18, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.73 = icmp ule i32 8, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 8, 8
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %stack.offset.56, %context.value.55
  %descriptor.owner.inside.87 = icmp ule i32 %stack.offset.56, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %context.value.55, %stack.offset.56
  %descriptor.extent.inside.90 = icmp ule i32 8, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 1, 1
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.55, i32 8)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  %step.status.102 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.103 = icmp eq i32 %step.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %stack.offset.107 = add i32 8, 8
  %stack.offset.108 = add i32 8, 8
  %stack.offset.109 = add i32 %context.value.106, %stack.offset.107
  %reserve.status.110 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.109, i32 6)
  %reserve.ok.111 = icmp eq i32 %reserve.status.110, 0
  br i1 %reserve.ok.111, label %reserve.continue.112, label %frame.failure.0
reserve.continue.112:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.106, i64 0, i32 8)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  %stack.offset.117 = add i32 %context.value.106, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.117, i32 %context.value.55, i32 8, i32 8, i32 1, i32 6)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %runtime.ok.124 = icmp eq i32 %context.value.123, 0
  br i1 %runtime.ok.124, label %runtime.continue.125, label %frame.failure.0
runtime.continue.125:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.106, i32 %stack.offset.107, i32 %stack.offset.108, i32 %context.value.55, i32 8)
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %runtime.ok.128 = icmp eq i32 %context.value.127, 0
  br i1 %runtime.ok.128, label %runtime.continue.129, label %frame.failure.0
runtime.continue.129:
  %context.field.130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.131 = load i32, ptr %context.field.130, align 4
  %stack.sub.134 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.132 = icmp ule i32 %stack.offset.18, %context.value.131
  %descriptor.offset.inside.133 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.135 = icmp ule i32 8, %stack.sub.134
  %descriptor.payload.inside.136 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.137 = and i1 %descriptor.owner.inside.132, %descriptor.offset.inside.133
  %descriptor.range.inside.139 = and i1 %descriptor.owner.offset.valid.137, %descriptor.extent.inside.135
  %descriptor.range.valid.138 = and i1 %descriptor.range.inside.139, %descriptor.payload.inside.136
  %descriptor.type.valid.140 = icmp eq i32 8, 8
  %descriptor.valid.141 = and i1 %descriptor.range.valid.138, %descriptor.type.valid.140
  br i1 %descriptor.valid.141, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %stack.sub.151 = sub i32 %stack.offset.109, %context.value.106
  %descriptor.owner.inside.149 = icmp ule i32 %stack.offset.109, %context.value.148
  %descriptor.offset.inside.150 = icmp ule i32 %context.value.106, %stack.offset.109
  %descriptor.extent.inside.152 = icmp ule i32 %stack.offset.107, %stack.sub.151
  %descriptor.payload.inside.153 = icmp ule i32 %stack.offset.108, %stack.offset.107
  %descriptor.owner.offset.valid.154 = and i1 %descriptor.owner.inside.149, %descriptor.offset.inside.150
  %descriptor.range.inside.156 = and i1 %descriptor.owner.offset.valid.154, %descriptor.extent.inside.152
  %descriptor.range.valid.155 = and i1 %descriptor.range.inside.156, %descriptor.payload.inside.153
  %descriptor.type.valid.157 = icmp eq i32 8, 8
  %descriptor.valid.158 = and i1 %descriptor.range.valid.155, %descriptor.type.valid.157
  br i1 %descriptor.valid.158, label %descriptor.valid.159, label %descriptor.invalid.160
descriptor.invalid.160:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.159:
  %descriptor.initialized.status.161 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.106, i32 %stack.offset.107)
  %helper.ok.162 = icmp eq i32 %descriptor.initialized.status.161, 0
  br i1 %helper.ok.162, label %helper.continue.163, label %frame.failure.0
helper.continue.163:
  %step.status.164 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.165 = icmp eq i32 %step.status.164, 0
  br i1 %helper.ok.165, label %helper.continue.166, label %frame.failure.0
helper.continue.166:
  %equals.same.extent.167 = icmp eq i32 8, %stack.offset.107
  br i1 %equals.same.extent.167, label %equals.compare.168, label %equals.different.169
equals.compare.168:
  %equals.result.171 = call i32 @al_owning_equal(ptr %ctx, i32 %context.value.17, i32 %context.value.106, i32 8)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %frame.failure.0
runtime.continue.175:
  br label %equals.join.170
equals.different.169:
  br label %equals.join.170
equals.join.170:
  %equals.value.176 = phi i32 [ %equals.result.171, %runtime.continue.175 ], [ 0, %equals.different.169 ]
  %equals.bool.177 = icmp ne i32 %equals.value.176, 0
  %equals.i64.178 = zext i1 %equals.bool.177 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.106, i32 %stack.offset.107, i32 %stack.offset.108, i32 0, i32 0)
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %runtime.ok.181 = icmp eq i32 %context.value.180, 0
  br i1 %runtime.ok.181, label %runtime.continue.182, label %frame.failure.0
runtime.continue.182:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.17, i32 8, i32 8, i32 0, i32 0)
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %runtime.ok.185 = icmp eq i32 %context.value.184, 0
  br i1 %runtime.ok.185, label %runtime.continue.186, label %frame.failure.0
runtime.continue.186:
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.offset.189 = add i32 %context.value.188, 8
  %reserve.status.190 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.189, i32 8)
  %reserve.ok.191 = icmp eq i32 %reserve.status.190, 0
  br i1 %reserve.ok.191, label %reserve.continue.192, label %frame.failure.0
reserve.continue.192:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.188, i64 %equals.i64.178, i32 2)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %frame.failure.0
runtime.continue.196:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %runtime.ok.199 = icmp eq i32 %context.value.198, 0
  br i1 %runtime.ok.199, label %runtime.continue.200, label %frame.failure.0
runtime.continue.200:
  %stack.offset.201 = add i32 %context.value.188, 8
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %stack.sub.206 = sub i32 %stack.offset.201, %context.value.188
  %descriptor.owner.inside.204 = icmp ule i32 %stack.offset.201, %context.value.203
  %descriptor.offset.inside.205 = icmp ule i32 %context.value.188, %stack.offset.201
  %descriptor.extent.inside.207 = icmp ule i32 8, %stack.sub.206
  %descriptor.payload.inside.208 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.209 = and i1 %descriptor.owner.inside.204, %descriptor.offset.inside.205
  %descriptor.range.inside.211 = and i1 %descriptor.owner.offset.valid.209, %descriptor.extent.inside.207
  %descriptor.range.valid.210 = and i1 %descriptor.range.inside.211, %descriptor.payload.inside.208
  %descriptor.type.valid.212 = icmp eq i32 2, 2
  %descriptor.valid.213 = and i1 %descriptor.range.valid.210, %descriptor.type.valid.212
  br i1 %descriptor.valid.213, label %descriptor.valid.214, label %descriptor.invalid.215
descriptor.invalid.215:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.214:
  %descriptor.initialized.status.216 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.188, i32 8)
  %helper.ok.217 = icmp eq i32 %descriptor.initialized.status.216, 0
  br i1 %helper.ok.217, label %helper.continue.218, label %frame.failure.0
helper.continue.218:
  %descriptor.element.219 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.220 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.219, i32 0, i32 0
  store i32 2, ptr %descriptor.field.220, align 4
  %descriptor.field.221 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.219, i32 0, i32 1
  store i32 %context.value.188, ptr %descriptor.field.221, align 4
  %descriptor.field.222 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.219, i32 0, i32 2
  store i32 8, ptr %descriptor.field.222, align 4
  %descriptor.field.223 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.219, i32 0, i32 3
  store i32 8, ptr %descriptor.field.223, align 4
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.219, i32 0, i32 4
  store i32 %stack.offset.201, ptr %descriptor.field.224, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.188, i32 20, i32 8, i32 %stack.offset.201, i32 8)
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %runtime.ok.227 = icmp eq i32 %context.value.226, 0
  br i1 %runtime.ok.227, label %runtime.continue.228, label %frame.failure.0
runtime.continue.228:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %context.field.231 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.232 = load i32, ptr %context.field.231, align 4
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %stack.offset.235 = add i32 %context.value.5, %context.value.7
  %stack.offset.236 = add i32 %context.value.230, %context.value.232
  %stack.sub.237 = sub i32 %stack.offset.235, %stack.offset.236
  %stack.sub.238 = sub i32 %context.value.7, %context.value.232
  %stack.sub.239 = sub i32 %context.value.234, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.237, i32 %stack.sub.238)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.239)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 9)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 10)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 2
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 2, 2
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 2)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 2
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 2, 2
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %if.condition.raw.46 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.17)
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %runtime.ok.49 = icmp eq i32 %context.value.48, 0
  br i1 %runtime.ok.49, label %runtime.continue.50, label %frame.failure.0
runtime.continue.50:
  %if.condition.51 = icmp ne i64 %if.condition.raw.46, 0
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 2, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  br i1 %if.condition.51, label %if.then.56, label %if.else.57
if.then.56:
  %step.status.59 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.60 = icmp eq i32 %step.status.59, 0
  br i1 %helper.ok.60, label %helper.continue.61, label %frame.failure.0
helper.continue.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.offset.64 = add i32 %context.value.63, 8
  %reserve.status.65 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.64, i32 3)
  %reserve.ok.66 = icmp eq i32 %reserve.status.65, 0
  br i1 %reserve.ok.66, label %reserve.continue.67, label %frame.failure.0
reserve.continue.67:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.63, i64 42, i32 1)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %frame.failure.0
runtime.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.64, %context.value.63
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.64, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.63, %stack.offset.64
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.63, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 8, 8
  %stack.offset.99 = add i32 8, 8
  %stack.offset.100 = add i32 %context.value.97, %stack.offset.98
  %reserve.status.101 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.100, i32 5)
  %reserve.ok.102 = icmp eq i32 %reserve.status.101, 0
  br i1 %reserve.ok.102, label %reserve.continue.103, label %frame.failure.0
reserve.continue.103:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 8)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %stack.offset.108 = add i32 %context.value.97, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.108, i32 %context.value.63, i32 8, i32 8, i32 1, i32 6)
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %runtime.ok.111 = icmp eq i32 %context.value.110, 0
  br i1 %runtime.ok.111, label %runtime.continue.112, label %frame.failure.0
runtime.continue.112:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.97, i32 %stack.offset.98, i32 %stack.offset.99, i32 %context.value.63, i32 8)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.sub.125 = sub i32 %stack.offset.100, %context.value.97
  %descriptor.owner.inside.123 = icmp ule i32 %stack.offset.100, %context.value.122
  %descriptor.offset.inside.124 = icmp ule i32 %context.value.97, %stack.offset.100
  %descriptor.extent.inside.126 = icmp ule i32 %stack.offset.98, %stack.sub.125
  %descriptor.payload.inside.127 = icmp ule i32 %stack.offset.99, %stack.offset.98
  %descriptor.owner.offset.valid.128 = and i1 %descriptor.owner.inside.123, %descriptor.offset.inside.124
  %descriptor.range.inside.130 = and i1 %descriptor.owner.offset.valid.128, %descriptor.extent.inside.126
  %descriptor.range.valid.129 = and i1 %descriptor.range.inside.130, %descriptor.payload.inside.127
  %descriptor.type.valid.131 = icmp eq i32 8, 8
  %descriptor.valid.132 = and i1 %descriptor.range.valid.129, %descriptor.type.valid.131
  br i1 %descriptor.valid.132, label %descriptor.valid.133, label %descriptor.invalid.134
descriptor.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.133:
  %descriptor.initialized.status.135 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 %stack.offset.98)
  %helper.ok.136 = icmp eq i32 %descriptor.initialized.status.135, 0
  br i1 %helper.ok.136, label %helper.continue.137, label %frame.failure.0
helper.continue.137:
  br label %if.join.58
if.else.57:
  %step.status.138 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.139 = icmp eq i32 %step.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.offset.143 = add i32 %context.value.142, 8
  %reserve.status.144 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.143, i32 7)
  %reserve.ok.145 = icmp eq i32 %reserve.status.144, 0
  br i1 %reserve.ok.145, label %reserve.continue.146, label %frame.failure.0
reserve.continue.146:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.142, i64 1, i32 8)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.142, i32 8, i32 8, i32 0, i32 0)
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %runtime.ok.157 = icmp eq i32 %context.value.156, 0
  br i1 %runtime.ok.157, label %runtime.continue.158, label %frame.failure.0
runtime.continue.158:
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %stack.sub.163 = sub i32 %stack.offset.143, %context.value.142
  %descriptor.owner.inside.161 = icmp ule i32 %stack.offset.143, %context.value.160
  %descriptor.offset.inside.162 = icmp ule i32 %context.value.142, %stack.offset.143
  %descriptor.extent.inside.164 = icmp ule i32 8, %stack.sub.163
  %descriptor.payload.inside.165 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.166 = and i1 %descriptor.owner.inside.161, %descriptor.offset.inside.162
  %descriptor.range.inside.168 = and i1 %descriptor.owner.offset.valid.166, %descriptor.extent.inside.164
  %descriptor.range.valid.167 = and i1 %descriptor.range.inside.168, %descriptor.payload.inside.165
  %descriptor.type.valid.169 = icmp eq i32 8, 8
  %descriptor.valid.170 = and i1 %descriptor.range.valid.167, %descriptor.type.valid.169
  br i1 %descriptor.valid.170, label %descriptor.valid.171, label %descriptor.invalid.172
descriptor.invalid.172:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.171:
  %descriptor.initialized.status.173 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.142, i32 8)
  %helper.ok.174 = icmp eq i32 %descriptor.initialized.status.173, 0
  br i1 %helper.ok.174, label %helper.continue.175, label %frame.failure.0
helper.continue.175:
  br label %if.join.58
if.join.58:
  %if.value.offset.176 = phi i32 [ %context.value.97, %helper.continue.137 ], [ %context.value.142, %helper.continue.175 ]
  %if.value.extent.177 = phi i32 [ %stack.offset.98, %helper.continue.137 ], [ 8, %helper.continue.175 ]
  %if.value.payload.178 = phi i32 [ %stack.offset.99, %helper.continue.137 ], [ 8, %helper.continue.175 ]
  %if.value.owner.end.179 = phi i32 [ %stack.offset.100, %helper.continue.137 ], [ %stack.offset.143, %helper.continue.175 ]
  %context.field.180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.181 = load i32, ptr %context.field.180, align 4
  %stack.sub.184 = sub i32 %if.value.owner.end.179, %if.value.offset.176
  %descriptor.owner.inside.182 = icmp ule i32 %if.value.owner.end.179, %context.value.181
  %descriptor.offset.inside.183 = icmp ule i32 %if.value.offset.176, %if.value.owner.end.179
  %descriptor.extent.inside.185 = icmp ule i32 %if.value.extent.177, %stack.sub.184
  %descriptor.payload.inside.186 = icmp ule i32 %if.value.payload.178, %if.value.extent.177
  %descriptor.owner.offset.valid.187 = and i1 %descriptor.owner.inside.182, %descriptor.offset.inside.183
  %descriptor.range.inside.189 = and i1 %descriptor.owner.offset.valid.187, %descriptor.extent.inside.185
  %descriptor.range.valid.188 = and i1 %descriptor.range.inside.189, %descriptor.payload.inside.186
  %descriptor.type.valid.190 = icmp eq i32 8, 8
  %descriptor.valid.191 = and i1 %descriptor.range.valid.188, %descriptor.type.valid.190
  br i1 %descriptor.valid.191, label %descriptor.valid.192, label %descriptor.invalid.193
descriptor.invalid.193:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.192:
  %descriptor.initialized.status.194 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %if.value.offset.176, i32 %if.value.extent.177)
  %helper.ok.195 = icmp eq i32 %descriptor.initialized.status.194, 0
  br i1 %helper.ok.195, label %helper.continue.196, label %frame.failure.0
helper.continue.196:
  %descriptor.element.197 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 0
  store i32 8, ptr %descriptor.field.198, align 4
  %descriptor.field.199 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 1
  store i32 %if.value.offset.176, ptr %descriptor.field.199, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 2
  store i32 %if.value.extent.177, ptr %descriptor.field.200, align 4
  %descriptor.field.201 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 3
  store i32 %if.value.payload.178, ptr %descriptor.field.201, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 4
  store i32 %if.value.owner.end.179, ptr %descriptor.field.202, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %if.value.offset.176, i32 20, i32 %if.value.payload.178, i32 %if.value.owner.end.179, i32 %if.value.extent.177)
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %runtime.ok.205 = icmp eq i32 %context.value.204, 0
  br i1 %runtime.ok.205, label %runtime.continue.206, label %frame.failure.0
runtime.continue.206:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %context.field.211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.212 = load i32, ptr %context.field.211, align 4
  %stack.offset.213 = add i32 %context.value.5, %context.value.7
  %stack.offset.214 = add i32 %context.value.208, %context.value.210
  %stack.sub.215 = sub i32 %stack.offset.213, %stack.offset.214
  %stack.sub.216 = sub i32 %context.value.7, %context.value.210
  %stack.sub.217 = sub i32 %context.value.212, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.215, i32 %stack.sub.216)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.217)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 8, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 8, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 8, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 9)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 2, i32 10)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 2, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 11)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 8
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 8, 8
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 8)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 2 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\03\00\00\00\00\00\00\00\41\00\00\00\42\00\00\00", align 8
@al_owning_string_literal_1 = private unnamed_addr constant [16 x i8] c"\03\00\00\00\00\00\00\00\41\00\00\00\43\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 16
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  %literal.status.22 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.17, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 14, i32 16, i32 7, i32 3)
  %helper.ok.23 = icmp eq i32 %literal.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %stack.sub.29 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.27 = icmp ule i32 %stack.offset.18, %context.value.26
  %descriptor.offset.inside.28 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.30 = icmp ule i32 16, %stack.sub.29
  %descriptor.payload.inside.31 = icmp ule i32 14, 16
  %descriptor.owner.offset.valid.32 = and i1 %descriptor.owner.inside.27, %descriptor.offset.inside.28
  %descriptor.range.inside.34 = and i1 %descriptor.owner.offset.valid.32, %descriptor.extent.inside.30
  %descriptor.range.valid.33 = and i1 %descriptor.range.inside.34, %descriptor.payload.inside.31
  %descriptor.type.valid.35 = icmp eq i32 7, 7
  %descriptor.valid.36 = and i1 %descriptor.range.valid.33, %descriptor.type.valid.35
  br i1 %descriptor.valid.36, label %descriptor.valid.37, label %descriptor.invalid.38
descriptor.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.37:
  %descriptor.initialized.status.39 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 16)
  %helper.ok.40 = icmp eq i32 %descriptor.initialized.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %frame.failure.0
helper.continue.41:
  %step.status.42 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.43 = icmp eq i32 %step.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %frame.failure.0
helper.continue.44:
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %stack.offset.47 = add i32 8, 16
  %stack.offset.48 = add i32 8, 14
  %stack.offset.49 = add i32 %context.value.46, %stack.offset.47
  %reserve.status.50 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.49, i32 5)
  %reserve.ok.51 = icmp eq i32 %reserve.status.50, 0
  br i1 %reserve.ok.51, label %reserve.continue.52, label %frame.failure.0
reserve.continue.52:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.46, i64 0, i32 8)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %context.value.46, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.57, i32 %context.value.17, i32 16, i32 14, i32 7, i32 6)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %runtime.ok.64 = icmp eq i32 %context.value.63, 0
  br i1 %runtime.ok.64, label %runtime.continue.65, label %frame.failure.0
runtime.continue.65:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.46, i32 %stack.offset.47, i32 %stack.offset.48, i32 %context.value.17, i32 16)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %frame.failure.0
runtime.continue.69:
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.72 = icmp ule i32 %stack.offset.49, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.75 = icmp ule i32 %stack.offset.47, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  %descriptor.type.valid.80 = icmp eq i32 8, 8
  %descriptor.valid.81 = and i1 %descriptor.range.valid.78, %descriptor.type.valid.80
  br i1 %descriptor.valid.81, label %descriptor.valid.82, label %descriptor.invalid.83
descriptor.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.82:
  %descriptor.initialized.status.84 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.85 = icmp eq i32 %descriptor.initialized.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %step.status.87 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.88 = icmp eq i32 %step.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %stack.offset.92 = add i32 %context.value.91, 16
  %reserve.status.93 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.92, i32 7)
  %reserve.ok.94 = icmp eq i32 %reserve.status.93, 0
  br i1 %reserve.ok.94, label %reserve.continue.95, label %frame.failure.0
reserve.continue.95:
  %literal.status.96 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.91, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_1, i64 0, i64 0), i32 16, i32 14, i32 16, i32 7, i32 8)
  %helper.ok.97 = icmp eq i32 %literal.status.96, 0
  br i1 %helper.ok.97, label %helper.continue.98, label %frame.failure.0
helper.continue.98:
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %stack.sub.103 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.101 = icmp ule i32 %stack.offset.49, %context.value.100
  %descriptor.offset.inside.102 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.104 = icmp ule i32 %stack.offset.47, %stack.sub.103
  %descriptor.payload.inside.105 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.106 = and i1 %descriptor.owner.inside.101, %descriptor.offset.inside.102
  %descriptor.range.inside.108 = and i1 %descriptor.owner.offset.valid.106, %descriptor.extent.inside.104
  %descriptor.range.valid.107 = and i1 %descriptor.range.inside.108, %descriptor.payload.inside.105
  %descriptor.type.valid.109 = icmp eq i32 8, 8
  %descriptor.valid.110 = and i1 %descriptor.range.valid.107, %descriptor.type.valid.109
  br i1 %descriptor.valid.110, label %descriptor.valid.111, label %descriptor.invalid.112
descriptor.invalid.112:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.111:
  %descriptor.initialized.status.113 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.114 = icmp eq i32 %descriptor.initialized.status.113, 0
  br i1 %helper.ok.114, label %helper.continue.115, label %frame.failure.0
helper.continue.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %stack.offset.92, %context.value.91
  %descriptor.owner.inside.118 = icmp ule i32 %stack.offset.92, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %context.value.91, %stack.offset.92
  %descriptor.extent.inside.121 = icmp ule i32 16, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 14, 16
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 7, 7
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.91, i32 16)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %step.status.133 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.134 = icmp eq i32 %step.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %stack.offset.138 = add i32 8, 16
  %stack.offset.139 = add i32 8, 14
  %stack.offset.140 = add i32 %context.value.137, %stack.offset.138
  %reserve.status.141 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.140, i32 10)
  %reserve.ok.142 = icmp eq i32 %reserve.status.141, 0
  br i1 %reserve.ok.142, label %reserve.continue.143, label %frame.failure.0
reserve.continue.143:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.137, i64 0, i32 8)
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  %runtime.ok.146 = icmp eq i32 %context.value.145, 0
  br i1 %runtime.ok.146, label %runtime.continue.147, label %frame.failure.0
runtime.continue.147:
  %stack.offset.148 = add i32 %context.value.137, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.148, i32 %context.value.91, i32 16, i32 14, i32 7, i32 6)
  %context.field.149 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.150 = load i32, ptr %context.field.149, align 4
  %runtime.ok.151 = icmp eq i32 %context.value.150, 0
  br i1 %runtime.ok.151, label %runtime.continue.152, label %frame.failure.0
runtime.continue.152:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %runtime.ok.155 = icmp eq i32 %context.value.154, 0
  br i1 %runtime.ok.155, label %runtime.continue.156, label %frame.failure.0
runtime.continue.156:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.137, i32 %stack.offset.138, i32 %stack.offset.139, i32 %context.value.91, i32 16)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %stack.sub.165 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.163 = icmp ule i32 %stack.offset.49, %context.value.162
  %descriptor.offset.inside.164 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.166 = icmp ule i32 %stack.offset.47, %stack.sub.165
  %descriptor.payload.inside.167 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.168 = and i1 %descriptor.owner.inside.163, %descriptor.offset.inside.164
  %descriptor.range.inside.170 = and i1 %descriptor.owner.offset.valid.168, %descriptor.extent.inside.166
  %descriptor.range.valid.169 = and i1 %descriptor.range.inside.170, %descriptor.payload.inside.167
  %descriptor.type.valid.171 = icmp eq i32 8, 8
  %descriptor.valid.172 = and i1 %descriptor.range.valid.169, %descriptor.type.valid.171
  br i1 %descriptor.valid.172, label %descriptor.valid.173, label %descriptor.invalid.174
descriptor.invalid.174:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.173:
  %descriptor.initialized.status.175 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.176 = icmp eq i32 %descriptor.initialized.status.175, 0
  br i1 %helper.ok.176, label %helper.continue.177, label %frame.failure.0
helper.continue.177:
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.182 = sub i32 %stack.offset.140, %context.value.137
  %descriptor.owner.inside.180 = icmp ule i32 %stack.offset.140, %context.value.179
  %descriptor.offset.inside.181 = icmp ule i32 %context.value.137, %stack.offset.140
  %descriptor.extent.inside.183 = icmp ule i32 %stack.offset.138, %stack.sub.182
  %descriptor.payload.inside.184 = icmp ule i32 %stack.offset.139, %stack.offset.138
  %descriptor.owner.offset.valid.185 = and i1 %descriptor.owner.inside.180, %descriptor.offset.inside.181
  %descriptor.range.inside.187 = and i1 %descriptor.owner.offset.valid.185, %descriptor.extent.inside.183
  %descriptor.range.valid.186 = and i1 %descriptor.range.inside.187, %descriptor.payload.inside.184
  %descriptor.type.valid.188 = icmp eq i32 8, 8
  %descriptor.valid.189 = and i1 %descriptor.range.valid.186, %descriptor.type.valid.188
  br i1 %descriptor.valid.189, label %descriptor.valid.190, label %descriptor.invalid.191
descriptor.invalid.191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.190:
  %descriptor.initialized.status.192 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.137, i32 %stack.offset.138)
  %helper.ok.193 = icmp eq i32 %descriptor.initialized.status.192, 0
  br i1 %helper.ok.193, label %helper.continue.194, label %frame.failure.0
helper.continue.194:
  %step.status.195 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.196 = icmp eq i32 %step.status.195, 0
  br i1 %helper.ok.196, label %helper.continue.197, label %frame.failure.0
helper.continue.197:
  %equals.same.extent.198 = icmp eq i32 %stack.offset.47, %stack.offset.138
  br i1 %equals.same.extent.198, label %equals.compare.199, label %equals.different.200
equals.compare.199:
  %equals.result.202 = call i32 @al_owning_equal(ptr %ctx, i32 %context.value.46, i32 %context.value.137, i32 %stack.offset.47)
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %runtime.ok.205 = icmp eq i32 %context.value.204, 0
  br i1 %runtime.ok.205, label %runtime.continue.206, label %frame.failure.0
runtime.continue.206:
  br label %equals.join.201
equals.different.200:
  br label %equals.join.201
equals.join.201:
  %equals.value.207 = phi i32 [ %equals.result.202, %runtime.continue.206 ], [ 0, %equals.different.200 ]
  %equals.bool.208 = icmp ne i32 %equals.value.207, 0
  %equals.i64.209 = zext i1 %equals.bool.208 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.137, i32 %stack.offset.138, i32 %stack.offset.139, i32 0, i32 0)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.46, i32 %stack.offset.47, i32 %stack.offset.48, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %runtime.ok.216 = icmp eq i32 %context.value.215, 0
  br i1 %runtime.ok.216, label %runtime.continue.217, label %frame.failure.0
runtime.continue.217:
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.219, 8
  %reserve.status.221 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.220, i32 12)
  %reserve.ok.222 = icmp eq i32 %reserve.status.221, 0
  br i1 %reserve.ok.222, label %reserve.continue.223, label %frame.failure.0
reserve.continue.223:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.219, i64 %equals.i64.209, i32 2)
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %runtime.ok.226 = icmp eq i32 %context.value.225, 0
  br i1 %runtime.ok.226, label %runtime.continue.227, label %frame.failure.0
runtime.continue.227:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %frame.failure.0
runtime.continue.231:
  %stack.offset.232 = add i32 %context.value.219, 8
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %stack.sub.237 = sub i32 %stack.offset.232, %context.value.219
  %descriptor.owner.inside.235 = icmp ule i32 %stack.offset.232, %context.value.234
  %descriptor.offset.inside.236 = icmp ule i32 %context.value.219, %stack.offset.232
  %descriptor.extent.inside.238 = icmp ule i32 8, %stack.sub.237
  %descriptor.payload.inside.239 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.240 = and i1 %descriptor.owner.inside.235, %descriptor.offset.inside.236
  %descriptor.range.inside.242 = and i1 %descriptor.owner.offset.valid.240, %descriptor.extent.inside.238
  %descriptor.range.valid.241 = and i1 %descriptor.range.inside.242, %descriptor.payload.inside.239
  %descriptor.type.valid.243 = icmp eq i32 2, 2
  %descriptor.valid.244 = and i1 %descriptor.range.valid.241, %descriptor.type.valid.243
  br i1 %descriptor.valid.244, label %descriptor.valid.245, label %descriptor.invalid.246
descriptor.invalid.246:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.245:
  %descriptor.initialized.status.247 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.219, i32 8)
  %helper.ok.248 = icmp eq i32 %descriptor.initialized.status.247, 0
  br i1 %helper.ok.248, label %helper.continue.249, label %frame.failure.0
helper.continue.249:
  %descriptor.element.250 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.251 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.250, i32 0, i32 0
  store i32 2, ptr %descriptor.field.251, align 4
  %descriptor.field.252 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.250, i32 0, i32 1
  store i32 %context.value.219, ptr %descriptor.field.252, align 4
  %descriptor.field.253 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.250, i32 0, i32 2
  store i32 8, ptr %descriptor.field.253, align 4
  %descriptor.field.254 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.250, i32 0, i32 3
  store i32 8, ptr %descriptor.field.254, align 4
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.250, i32 0, i32 4
  store i32 %stack.offset.232, ptr %descriptor.field.255, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.219, i32 20, i32 8, i32 %stack.offset.232, i32 8)
  %context.field.256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.257 = load i32, ptr %context.field.256, align 4
  %runtime.ok.258 = icmp eq i32 %context.value.257, 0
  br i1 %runtime.ok.258, label %runtime.continue.259, label %frame.failure.0
runtime.continue.259:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %context.field.262 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.263 = load i32, ptr %context.field.262, align 4
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %stack.offset.266 = add i32 %context.value.5, %context.value.7
  %stack.offset.267 = add i32 %context.value.261, %context.value.263
  %stack.sub.268 = sub i32 %stack.offset.266, %stack.offset.267
  %stack.sub.269 = sub i32 %context.value.7, %context.value.263
  %stack.sub.270 = sub i32 %context.value.265, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.268, i32 %stack.sub.269)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.270)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 13)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 14)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 2
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 2, 2
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 2)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


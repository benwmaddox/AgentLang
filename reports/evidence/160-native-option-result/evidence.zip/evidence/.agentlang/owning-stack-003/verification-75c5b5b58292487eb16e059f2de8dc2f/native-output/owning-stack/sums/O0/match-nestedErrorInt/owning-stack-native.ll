%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %descriptor.element.31 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 0
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 1
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 2
  %descriptor.value.37 = load i32, ptr %descriptor.field.36, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 3
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 4
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %argument.type.valid.42 = icmp eq i32 %descriptor.value.33, 8
  br i1 %argument.type.valid.42, label %argument.type.ok.43, label %frame.failure.0
argument.type.ok.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.sub.48 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.46 = icmp ule i32 %descriptor.value.41, %context.value.45
  %descriptor.offset.inside.47 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.49 = icmp ule i32 %descriptor.value.37, %stack.sub.48
  %descriptor.payload.inside.50 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.51 = and i1 %descriptor.owner.inside.46, %descriptor.offset.inside.47
  %descriptor.range.inside.53 = and i1 %descriptor.owner.offset.valid.51, %descriptor.extent.inside.49
  %descriptor.range.valid.52 = and i1 %descriptor.range.inside.53, %descriptor.payload.inside.50
  %descriptor.type.valid.54 = icmp eq i32 8, 8
  %descriptor.valid.55 = and i1 %descriptor.range.valid.52, %descriptor.type.valid.54
  br i1 %descriptor.valid.55, label %descriptor.valid.56, label %descriptor.invalid.57
descriptor.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.56:
  %descriptor.initialized.status.58 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.59 = icmp eq i32 %descriptor.initialized.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  %option.case.index.pointer.64 = alloca i32, align 4
  %option.case.location.65 = alloca %AlOwningFieldLocation, align 4
  %option.case.location.status.66 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %descriptor.value.35, i32 %descriptor.value.37, i32 2, ptr %option.case.index.pointer.64, ptr %option.case.location.65)
  %helper.ok.67 = icmp eq i32 %option.case.location.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %frame.failure.0
helper.continue.68:
  %option.case.index.69 = load i32, ptr %option.case.index.pointer.64, align 4
  %option.payload.offset.pointer.70 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 0
  %option.payload.offset.71 = load i32, ptr %option.payload.offset.pointer.70, align 4
  %option.payload.bytes.pointer.72 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 1
  %option.payload.bytes.73 = load i32, ptr %option.payload.bytes.pointer.72, align 4
  %option.payload.extent.pointer.74 = getelementptr inbounds %AlOwningFieldLocation, ptr %option.case.location.65, i32 0, i32 2
  %option.payload.extent.75 = load i32, ptr %option.payload.extent.pointer.74, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %descriptor.value.35, i32 %descriptor.value.37, i32 %descriptor.value.39, i32 0, i32 0)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  switch i32 %option.case.index.69, label %option.invalid-tag.82 [ i32 0, label %option.some.80 i32 1, label %option.none.81 ]
option.invalid-tag.82:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 %option.case.index.69, i32 2)
  br label %frame.failure.0
option.some.80:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %stack.sub.88 = sub i32 %descriptor.value.41, %option.payload.offset.71
  %descriptor.owner.inside.86 = icmp ule i32 %descriptor.value.41, %context.value.85
  %descriptor.offset.inside.87 = icmp ule i32 %option.payload.offset.71, %descriptor.value.41
  %descriptor.extent.inside.89 = icmp ule i32 %option.payload.extent.75, %stack.sub.88
  %descriptor.payload.inside.90 = icmp ule i32 %option.payload.bytes.73, %option.payload.extent.75
  %descriptor.owner.offset.valid.91 = and i1 %descriptor.owner.inside.86, %descriptor.offset.inside.87
  %descriptor.range.inside.93 = and i1 %descriptor.owner.offset.valid.91, %descriptor.extent.inside.89
  %descriptor.range.valid.92 = and i1 %descriptor.range.inside.93, %descriptor.payload.inside.90
  %descriptor.type.valid.94 = icmp eq i32 9, 9
  %descriptor.valid.95 = and i1 %descriptor.range.valid.92, %descriptor.type.valid.94
  br i1 %descriptor.valid.95, label %descriptor.valid.96, label %descriptor.invalid.97
descriptor.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.96:
  %descriptor.initialized.status.98 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %option.payload.offset.71, i32 %option.payload.extent.75)
  %helper.ok.99 = icmp eq i32 %descriptor.initialized.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  store i1 true, ptr %local.active.2, align 1
  store i32 %option.payload.offset.71, ptr %local.offset.3, align 4
  store i32 %option.payload.extent.75, ptr %local.extent.4, align 4
  store i32 %option.payload.bytes.73, ptr %local.payload.5, align 4
  store i32 %descriptor.value.41, ptr %local.owner.end.6, align 4
  store i32 9, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %option.payload.offset.71, i32 20, i32 %option.payload.bytes.73, i32 %descriptor.value.41, i32 %option.payload.extent.75)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %frame.failure.0
runtime.continue.104:
  %step.status.105 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.106 = icmp eq i32 %step.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %frame.failure.0
helper.continue.107:
  %local.resolved.offset.108 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.109 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.110 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.111 = load i32, ptr %local.owner.end.6, align 4
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %local.resolved.owner.end.111, %local.resolved.offset.108
  %descriptor.owner.inside.114 = icmp ule i32 %local.resolved.owner.end.111, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %local.resolved.offset.108, %local.resolved.owner.end.111
  %descriptor.extent.inside.117 = icmp ule i32 %local.resolved.extent.109, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %local.resolved.payload.110, %local.resolved.extent.109
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 9, 9
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %frame.failure.0
helper.continue.128:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.108, i32 20, i32 %local.resolved.payload.110, i32 %local.resolved.owner.end.111, i32 %local.resolved.extent.109)
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %runtime.ok.131 = icmp eq i32 %context.value.130, 0
  br i1 %runtime.ok.131, label %runtime.continue.132, label %frame.failure.0
runtime.continue.132:
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %stack.sub.137 = sub i32 %local.resolved.owner.end.111, %local.resolved.offset.108
  %descriptor.owner.inside.135 = icmp ule i32 %local.resolved.owner.end.111, %context.value.134
  %descriptor.offset.inside.136 = icmp ule i32 %local.resolved.offset.108, %local.resolved.owner.end.111
  %descriptor.extent.inside.138 = icmp ule i32 %local.resolved.extent.109, %stack.sub.137
  %descriptor.payload.inside.139 = icmp ule i32 %local.resolved.payload.110, %local.resolved.extent.109
  %descriptor.owner.offset.valid.140 = and i1 %descriptor.owner.inside.135, %descriptor.offset.inside.136
  %descriptor.range.inside.142 = and i1 %descriptor.owner.offset.valid.140, %descriptor.extent.inside.138
  %descriptor.range.valid.141 = and i1 %descriptor.range.inside.142, %descriptor.payload.inside.139
  %descriptor.type.valid.143 = icmp eq i32 9, 9
  %descriptor.valid.144 = and i1 %descriptor.range.valid.141, %descriptor.type.valid.143
  br i1 %descriptor.valid.144, label %descriptor.valid.145, label %descriptor.invalid.146
descriptor.invalid.146:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.145:
  %descriptor.initialized.status.147 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109)
  %helper.ok.148 = icmp eq i32 %descriptor.initialized.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %local.is.active.150 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.150, label %local.descriptor.active.151, label %local.descriptor.inactive.152
local.descriptor.active.151:
  %local.check.offset.154 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.155 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.156 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.157 = load i32, ptr %local.owner.end.6, align 4
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %stack.sub.162 = sub i32 %local.check.owner.end.157, %local.check.offset.154
  %descriptor.owner.inside.160 = icmp ule i32 %local.check.owner.end.157, %context.value.159
  %descriptor.offset.inside.161 = icmp ule i32 %local.check.offset.154, %local.check.owner.end.157
  %descriptor.extent.inside.163 = icmp ule i32 %local.check.extent.155, %stack.sub.162
  %descriptor.payload.inside.164 = icmp ule i32 %local.check.payload.156, %local.check.extent.155
  %descriptor.owner.offset.valid.165 = and i1 %descriptor.owner.inside.160, %descriptor.offset.inside.161
  %descriptor.range.inside.167 = and i1 %descriptor.owner.offset.valid.165, %descriptor.extent.inside.163
  %descriptor.range.valid.166 = and i1 %descriptor.range.inside.167, %descriptor.payload.inside.164
  br i1 %descriptor.range.valid.166, label %descriptor.valid.168, label %descriptor.invalid.169
descriptor.invalid.169:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.168:
  %descriptor.initialized.status.170 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.154, i32 %local.check.extent.155)
  %helper.ok.171 = icmp eq i32 %descriptor.initialized.status.170, 0
  br i1 %helper.ok.171, label %helper.continue.172, label %frame.failure.0
helper.continue.172:
  br label %local.descriptor.checked.153
local.descriptor.inactive.152:
  br label %local.descriptor.checked.153
local.descriptor.checked.153:
  %local.is.active.173 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.173, label %local.descriptor.active.174, label %local.descriptor.inactive.175
local.descriptor.active.174:
  %local.check.offset.177 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.178 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.179 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.180 = load i32, ptr %local.owner.end.12, align 4
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %stack.sub.185 = sub i32 %local.check.owner.end.180, %local.check.offset.177
  %descriptor.owner.inside.183 = icmp ule i32 %local.check.owner.end.180, %context.value.182
  %descriptor.offset.inside.184 = icmp ule i32 %local.check.offset.177, %local.check.owner.end.180
  %descriptor.extent.inside.186 = icmp ule i32 %local.check.extent.178, %stack.sub.185
  %descriptor.payload.inside.187 = icmp ule i32 %local.check.payload.179, %local.check.extent.178
  %descriptor.owner.offset.valid.188 = and i1 %descriptor.owner.inside.183, %descriptor.offset.inside.184
  %descriptor.range.inside.190 = and i1 %descriptor.owner.offset.valid.188, %descriptor.extent.inside.186
  %descriptor.range.valid.189 = and i1 %descriptor.range.inside.190, %descriptor.payload.inside.187
  br i1 %descriptor.range.valid.189, label %descriptor.valid.191, label %descriptor.invalid.192
descriptor.invalid.192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.191:
  %descriptor.initialized.status.193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.177, i32 %local.check.extent.178)
  %helper.ok.194 = icmp eq i32 %descriptor.initialized.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %frame.failure.0
helper.continue.195:
  br label %local.descriptor.checked.176
local.descriptor.inactive.175:
  br label %local.descriptor.checked.176
local.descriptor.checked.176:
  %local.is.active.196 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.196, label %local.descriptor.active.197, label %local.descriptor.inactive.198
local.descriptor.active.197:
  %local.check.offset.200 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.201 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.202 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.203 = load i32, ptr %local.owner.end.18, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %stack.sub.208 = sub i32 %local.check.owner.end.203, %local.check.offset.200
  %descriptor.owner.inside.206 = icmp ule i32 %local.check.owner.end.203, %context.value.205
  %descriptor.offset.inside.207 = icmp ule i32 %local.check.offset.200, %local.check.owner.end.203
  %descriptor.extent.inside.209 = icmp ule i32 %local.check.extent.201, %stack.sub.208
  %descriptor.payload.inside.210 = icmp ule i32 %local.check.payload.202, %local.check.extent.201
  %descriptor.owner.offset.valid.211 = and i1 %descriptor.owner.inside.206, %descriptor.offset.inside.207
  %descriptor.range.inside.213 = and i1 %descriptor.owner.offset.valid.211, %descriptor.extent.inside.209
  %descriptor.range.valid.212 = and i1 %descriptor.range.inside.213, %descriptor.payload.inside.210
  br i1 %descriptor.range.valid.212, label %descriptor.valid.214, label %descriptor.invalid.215
descriptor.invalid.215:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.214:
  %descriptor.initialized.status.216 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.200, i32 %local.check.extent.201)
  %helper.ok.217 = icmp eq i32 %descriptor.initialized.status.216, 0
  br i1 %helper.ok.217, label %helper.continue.218, label %frame.failure.0
helper.continue.218:
  br label %local.descriptor.checked.199
local.descriptor.inactive.198:
  br label %local.descriptor.checked.199
local.descriptor.checked.199:
  %step.status.219 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.220 = icmp eq i32 %step.status.219, 0
  br i1 %helper.ok.220, label %helper.continue.221, label %frame.failure.0
helper.continue.221:
  %result.case.index.pointer.222 = alloca i32, align 4
  %result.case.location.223 = alloca %AlOwningFieldLocation, align 4
  %result.case.location.status.224 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109, i32 5, ptr %result.case.index.pointer.222, ptr %result.case.location.223)
  %helper.ok.225 = icmp eq i32 %result.case.location.status.224, 0
  br i1 %helper.ok.225, label %helper.continue.226, label %frame.failure.0
helper.continue.226:
  %result.case.index.227 = load i32, ptr %result.case.index.pointer.222, align 4
  %result.payload.offset.pointer.228 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 0
  %result.payload.offset.229 = load i32, ptr %result.payload.offset.pointer.228, align 4
  %result.payload.bytes.pointer.230 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 1
  %result.payload.bytes.231 = load i32, ptr %result.payload.bytes.pointer.230, align 4
  %result.payload.extent.pointer.232 = getelementptr inbounds %AlOwningFieldLocation, ptr %result.case.location.223, i32 0, i32 2
  %result.payload.extent.233 = load i32, ptr %result.payload.extent.pointer.232, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 9, i32 %local.resolved.offset.108, i32 %local.resolved.extent.109, i32 %local.resolved.payload.110, i32 0, i32 0)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  switch i32 %result.case.index.227, label %result.invalid-tag.240 [ i32 0, label %result.ok.238 i32 1, label %result.error.239 ]
result.invalid-tag.240:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 %result.case.index.227, i32 2)
  br label %frame.failure.0
result.ok.238:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %stack.sub.246 = sub i32 %local.resolved.owner.end.111, %result.payload.offset.229
  %descriptor.owner.inside.244 = icmp ule i32 %local.resolved.owner.end.111, %context.value.243
  %descriptor.offset.inside.245 = icmp ule i32 %result.payload.offset.229, %local.resolved.owner.end.111
  %descriptor.extent.inside.247 = icmp ule i32 %result.payload.extent.233, %stack.sub.246
  %descriptor.payload.inside.248 = icmp ule i32 %result.payload.bytes.231, %result.payload.extent.233
  %descriptor.owner.offset.valid.249 = and i1 %descriptor.owner.inside.244, %descriptor.offset.inside.245
  %descriptor.range.inside.251 = and i1 %descriptor.owner.offset.valid.249, %descriptor.extent.inside.247
  %descriptor.range.valid.250 = and i1 %descriptor.range.inside.251, %descriptor.payload.inside.248
  %descriptor.type.valid.252 = icmp eq i32 7, 7
  %descriptor.valid.253 = and i1 %descriptor.range.valid.250, %descriptor.type.valid.252
  br i1 %descriptor.valid.253, label %descriptor.valid.254, label %descriptor.invalid.255
descriptor.invalid.255:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.254:
  %descriptor.initialized.status.256 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.payload.offset.229, i32 %result.payload.extent.233)
  %helper.ok.257 = icmp eq i32 %descriptor.initialized.status.256, 0
  br i1 %helper.ok.257, label %helper.continue.258, label %frame.failure.0
helper.continue.258:
  store i1 true, ptr %local.active.8, align 1
  store i32 %result.payload.offset.229, ptr %local.offset.9, align 4
  store i32 %result.payload.extent.233, ptr %local.extent.10, align 4
  store i32 %result.payload.bytes.231, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.111, ptr %local.owner.end.12, align 4
  store i32 7, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %result.payload.offset.229, i32 20, i32 %result.payload.bytes.231, i32 %local.resolved.owner.end.111, i32 %result.payload.extent.233)
  %context.field.259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.260 = load i32, ptr %context.field.259, align 4
  %runtime.ok.261 = icmp eq i32 %context.value.260, 0
  br i1 %runtime.ok.261, label %runtime.continue.262, label %frame.failure.0
runtime.continue.262:
  %step.status.263 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.264 = icmp eq i32 %step.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %frame.failure.0
helper.continue.265:
  %context.field.266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.267 = load i32, ptr %context.field.266, align 4
  %stack.offset.268 = add i32 %context.value.267, 8
  %reserve.status.269 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.268, i32 7)
  %reserve.ok.270 = icmp eq i32 %reserve.status.269, 0
  br i1 %reserve.ok.270, label %reserve.continue.271, label %frame.failure.0
reserve.continue.271:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.267, i64 -1, i32 1)
  %context.field.272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.273 = load i32, ptr %context.field.272, align 4
  %runtime.ok.274 = icmp eq i32 %context.value.273, 0
  br i1 %runtime.ok.274, label %runtime.continue.275, label %frame.failure.0
runtime.continue.275:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.277 = load i32, ptr %context.field.276, align 4
  %runtime.ok.278 = icmp eq i32 %context.value.277, 0
  br i1 %runtime.ok.278, label %runtime.continue.279, label %frame.failure.0
runtime.continue.279:
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %stack.sub.284 = sub i32 %stack.offset.268, %context.value.267
  %descriptor.owner.inside.282 = icmp ule i32 %stack.offset.268, %context.value.281
  %descriptor.offset.inside.283 = icmp ule i32 %context.value.267, %stack.offset.268
  %descriptor.extent.inside.285 = icmp ule i32 8, %stack.sub.284
  %descriptor.payload.inside.286 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.287 = and i1 %descriptor.owner.inside.282, %descriptor.offset.inside.283
  %descriptor.range.inside.289 = and i1 %descriptor.owner.offset.valid.287, %descriptor.extent.inside.285
  %descriptor.range.valid.288 = and i1 %descriptor.range.inside.289, %descriptor.payload.inside.286
  %descriptor.type.valid.290 = icmp eq i32 1, 1
  %descriptor.valid.291 = and i1 %descriptor.range.valid.288, %descriptor.type.valid.290
  br i1 %descriptor.valid.291, label %descriptor.valid.292, label %descriptor.invalid.293
descriptor.invalid.293:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.292:
  %descriptor.initialized.status.294 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.267, i32 8)
  %helper.ok.295 = icmp eq i32 %descriptor.initialized.status.294, 0
  br i1 %helper.ok.295, label %helper.continue.296, label %frame.failure.0
helper.continue.296:
  %local.is.active.297 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.297, label %local.descriptor.active.298, label %local.descriptor.inactive.299
local.descriptor.active.298:
  %local.check.offset.301 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.302 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.303 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.304 = load i32, ptr %local.owner.end.6, align 4
  %context.field.305 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.306 = load i32, ptr %context.field.305, align 4
  %stack.sub.309 = sub i32 %local.check.owner.end.304, %local.check.offset.301
  %descriptor.owner.inside.307 = icmp ule i32 %local.check.owner.end.304, %context.value.306
  %descriptor.offset.inside.308 = icmp ule i32 %local.check.offset.301, %local.check.owner.end.304
  %descriptor.extent.inside.310 = icmp ule i32 %local.check.extent.302, %stack.sub.309
  %descriptor.payload.inside.311 = icmp ule i32 %local.check.payload.303, %local.check.extent.302
  %descriptor.owner.offset.valid.312 = and i1 %descriptor.owner.inside.307, %descriptor.offset.inside.308
  %descriptor.range.inside.314 = and i1 %descriptor.owner.offset.valid.312, %descriptor.extent.inside.310
  %descriptor.range.valid.313 = and i1 %descriptor.range.inside.314, %descriptor.payload.inside.311
  br i1 %descriptor.range.valid.313, label %descriptor.valid.315, label %descriptor.invalid.316
descriptor.invalid.316:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.315:
  %descriptor.initialized.status.317 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.301, i32 %local.check.extent.302)
  %helper.ok.318 = icmp eq i32 %descriptor.initialized.status.317, 0
  br i1 %helper.ok.318, label %helper.continue.319, label %frame.failure.0
helper.continue.319:
  br label %local.descriptor.checked.300
local.descriptor.inactive.299:
  br label %local.descriptor.checked.300
local.descriptor.checked.300:
  %local.is.active.320 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.320, label %local.descriptor.active.321, label %local.descriptor.inactive.322
local.descriptor.active.321:
  %local.check.offset.324 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.325 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.326 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.327 = load i32, ptr %local.owner.end.12, align 4
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %stack.sub.332 = sub i32 %local.check.owner.end.327, %local.check.offset.324
  %descriptor.owner.inside.330 = icmp ule i32 %local.check.owner.end.327, %context.value.329
  %descriptor.offset.inside.331 = icmp ule i32 %local.check.offset.324, %local.check.owner.end.327
  %descriptor.extent.inside.333 = icmp ule i32 %local.check.extent.325, %stack.sub.332
  %descriptor.payload.inside.334 = icmp ule i32 %local.check.payload.326, %local.check.extent.325
  %descriptor.owner.offset.valid.335 = and i1 %descriptor.owner.inside.330, %descriptor.offset.inside.331
  %descriptor.range.inside.337 = and i1 %descriptor.owner.offset.valid.335, %descriptor.extent.inside.333
  %descriptor.range.valid.336 = and i1 %descriptor.range.inside.337, %descriptor.payload.inside.334
  br i1 %descriptor.range.valid.336, label %descriptor.valid.338, label %descriptor.invalid.339
descriptor.invalid.339:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.338:
  %descriptor.initialized.status.340 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.324, i32 %local.check.extent.325)
  %helper.ok.341 = icmp eq i32 %descriptor.initialized.status.340, 0
  br i1 %helper.ok.341, label %helper.continue.342, label %frame.failure.0
helper.continue.342:
  br label %local.descriptor.checked.323
local.descriptor.inactive.322:
  br label %local.descriptor.checked.323
local.descriptor.checked.323:
  %local.is.active.343 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.343, label %local.descriptor.active.344, label %local.descriptor.inactive.345
local.descriptor.active.344:
  %local.check.offset.347 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.348 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.349 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.350 = load i32, ptr %local.owner.end.18, align 4
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %stack.sub.355 = sub i32 %local.check.owner.end.350, %local.check.offset.347
  %descriptor.owner.inside.353 = icmp ule i32 %local.check.owner.end.350, %context.value.352
  %descriptor.offset.inside.354 = icmp ule i32 %local.check.offset.347, %local.check.owner.end.350
  %descriptor.extent.inside.356 = icmp ule i32 %local.check.extent.348, %stack.sub.355
  %descriptor.payload.inside.357 = icmp ule i32 %local.check.payload.349, %local.check.extent.348
  %descriptor.owner.offset.valid.358 = and i1 %descriptor.owner.inside.353, %descriptor.offset.inside.354
  %descriptor.range.inside.360 = and i1 %descriptor.owner.offset.valid.358, %descriptor.extent.inside.356
  %descriptor.range.valid.359 = and i1 %descriptor.range.inside.360, %descriptor.payload.inside.357
  br i1 %descriptor.range.valid.359, label %descriptor.valid.361, label %descriptor.invalid.362
descriptor.invalid.362:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.361:
  %descriptor.initialized.status.363 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.347, i32 %local.check.extent.348)
  %helper.ok.364 = icmp eq i32 %descriptor.initialized.status.363, 0
  br i1 %helper.ok.364, label %helper.continue.365, label %frame.failure.0
helper.continue.365:
  br label %local.descriptor.checked.346
local.descriptor.inactive.345:
  br label %local.descriptor.checked.346
local.descriptor.checked.346:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  br label %result.join.241
result.error.239:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.366 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.367 = load i32, ptr %context.field.366, align 4
  %stack.sub.370 = sub i32 %local.resolved.owner.end.111, %result.payload.offset.229
  %descriptor.owner.inside.368 = icmp ule i32 %local.resolved.owner.end.111, %context.value.367
  %descriptor.offset.inside.369 = icmp ule i32 %result.payload.offset.229, %local.resolved.owner.end.111
  %descriptor.extent.inside.371 = icmp ule i32 %result.payload.extent.233, %stack.sub.370
  %descriptor.payload.inside.372 = icmp ule i32 %result.payload.bytes.231, %result.payload.extent.233
  %descriptor.owner.offset.valid.373 = and i1 %descriptor.owner.inside.368, %descriptor.offset.inside.369
  %descriptor.range.inside.375 = and i1 %descriptor.owner.offset.valid.373, %descriptor.extent.inside.371
  %descriptor.range.valid.374 = and i1 %descriptor.range.inside.375, %descriptor.payload.inside.372
  %descriptor.type.valid.376 = icmp eq i32 1, 1
  %descriptor.valid.377 = and i1 %descriptor.range.valid.374, %descriptor.type.valid.376
  br i1 %descriptor.valid.377, label %descriptor.valid.378, label %descriptor.invalid.379
descriptor.invalid.379:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.378:
  %descriptor.initialized.status.380 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.payload.offset.229, i32 %result.payload.extent.233)
  %helper.ok.381 = icmp eq i32 %descriptor.initialized.status.380, 0
  br i1 %helper.ok.381, label %helper.continue.382, label %frame.failure.0
helper.continue.382:
  store i1 true, ptr %local.active.14, align 1
  store i32 %result.payload.offset.229, ptr %local.offset.15, align 4
  store i32 %result.payload.extent.233, ptr %local.extent.16, align 4
  store i32 %result.payload.bytes.231, ptr %local.payload.17, align 4
  store i32 %local.resolved.owner.end.111, ptr %local.owner.end.18, align 4
  store i32 1, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %result.payload.offset.229, i32 20, i32 %result.payload.bytes.231, i32 %local.resolved.owner.end.111, i32 %result.payload.extent.233)
  %context.field.383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.384 = load i32, ptr %context.field.383, align 4
  %runtime.ok.385 = icmp eq i32 %context.value.384, 0
  br i1 %runtime.ok.385, label %runtime.continue.386, label %frame.failure.0
runtime.continue.386:
  %step.status.387 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.388 = icmp eq i32 %step.status.387, 0
  br i1 %helper.ok.388, label %helper.continue.389, label %frame.failure.0
helper.continue.389:
  %local.resolved.offset.390 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.391 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.392 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.393 = load i32, ptr %local.owner.end.18, align 4
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %stack.sub.398 = sub i32 %local.resolved.owner.end.393, %local.resolved.offset.390
  %descriptor.owner.inside.396 = icmp ule i32 %local.resolved.owner.end.393, %context.value.395
  %descriptor.offset.inside.397 = icmp ule i32 %local.resolved.offset.390, %local.resolved.owner.end.393
  %descriptor.extent.inside.399 = icmp ule i32 %local.resolved.extent.391, %stack.sub.398
  %descriptor.payload.inside.400 = icmp ule i32 %local.resolved.payload.392, %local.resolved.extent.391
  %descriptor.owner.offset.valid.401 = and i1 %descriptor.owner.inside.396, %descriptor.offset.inside.397
  %descriptor.range.inside.403 = and i1 %descriptor.owner.offset.valid.401, %descriptor.extent.inside.399
  %descriptor.range.valid.402 = and i1 %descriptor.range.inside.403, %descriptor.payload.inside.400
  %descriptor.type.valid.404 = icmp eq i32 1, 1
  %descriptor.valid.405 = and i1 %descriptor.range.valid.402, %descriptor.type.valid.404
  br i1 %descriptor.valid.405, label %descriptor.valid.406, label %descriptor.invalid.407
descriptor.invalid.407:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.406:
  %descriptor.initialized.status.408 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.390, i32 %local.resolved.extent.391)
  %helper.ok.409 = icmp eq i32 %descriptor.initialized.status.408, 0
  br i1 %helper.ok.409, label %helper.continue.410, label %frame.failure.0
helper.continue.410:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.390, i32 20, i32 %local.resolved.payload.392, i32 %local.resolved.owner.end.393, i32 %local.resolved.extent.391)
  %context.field.411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.412 = load i32, ptr %context.field.411, align 4
  %runtime.ok.413 = icmp eq i32 %context.value.412, 0
  br i1 %runtime.ok.413, label %runtime.continue.414, label %frame.failure.0
runtime.continue.414:
  %context.field.415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.416 = load i32, ptr %context.field.415, align 4
  %stack.sub.419 = sub i32 %local.resolved.owner.end.393, %local.resolved.offset.390
  %descriptor.owner.inside.417 = icmp ule i32 %local.resolved.owner.end.393, %context.value.416
  %descriptor.offset.inside.418 = icmp ule i32 %local.resolved.offset.390, %local.resolved.owner.end.393
  %descriptor.extent.inside.420 = icmp ule i32 %local.resolved.extent.391, %stack.sub.419
  %descriptor.payload.inside.421 = icmp ule i32 %local.resolved.payload.392, %local.resolved.extent.391
  %descriptor.owner.offset.valid.422 = and i1 %descriptor.owner.inside.417, %descriptor.offset.inside.418
  %descriptor.range.inside.424 = and i1 %descriptor.owner.offset.valid.422, %descriptor.extent.inside.420
  %descriptor.range.valid.423 = and i1 %descriptor.range.inside.424, %descriptor.payload.inside.421
  %descriptor.type.valid.425 = icmp eq i32 1, 1
  %descriptor.valid.426 = and i1 %descriptor.range.valid.423, %descriptor.type.valid.425
  br i1 %descriptor.valid.426, label %descriptor.valid.427, label %descriptor.invalid.428
descriptor.invalid.428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.427:
  %descriptor.initialized.status.429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.390, i32 %local.resolved.extent.391)
  %helper.ok.430 = icmp eq i32 %descriptor.initialized.status.429, 0
  br i1 %helper.ok.430, label %helper.continue.431, label %frame.failure.0
helper.continue.431:
  %local.is.active.432 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.432, label %local.descriptor.active.433, label %local.descriptor.inactive.434
local.descriptor.active.433:
  %local.check.offset.436 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.437 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.438 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.439 = load i32, ptr %local.owner.end.6, align 4
  %context.field.440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.441 = load i32, ptr %context.field.440, align 4
  %stack.sub.444 = sub i32 %local.check.owner.end.439, %local.check.offset.436
  %descriptor.owner.inside.442 = icmp ule i32 %local.check.owner.end.439, %context.value.441
  %descriptor.offset.inside.443 = icmp ule i32 %local.check.offset.436, %local.check.owner.end.439
  %descriptor.extent.inside.445 = icmp ule i32 %local.check.extent.437, %stack.sub.444
  %descriptor.payload.inside.446 = icmp ule i32 %local.check.payload.438, %local.check.extent.437
  %descriptor.owner.offset.valid.447 = and i1 %descriptor.owner.inside.442, %descriptor.offset.inside.443
  %descriptor.range.inside.449 = and i1 %descriptor.owner.offset.valid.447, %descriptor.extent.inside.445
  %descriptor.range.valid.448 = and i1 %descriptor.range.inside.449, %descriptor.payload.inside.446
  br i1 %descriptor.range.valid.448, label %descriptor.valid.450, label %descriptor.invalid.451
descriptor.invalid.451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.450:
  %descriptor.initialized.status.452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.436, i32 %local.check.extent.437)
  %helper.ok.453 = icmp eq i32 %descriptor.initialized.status.452, 0
  br i1 %helper.ok.453, label %helper.continue.454, label %frame.failure.0
helper.continue.454:
  br label %local.descriptor.checked.435
local.descriptor.inactive.434:
  br label %local.descriptor.checked.435
local.descriptor.checked.435:
  %local.is.active.455 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.455, label %local.descriptor.active.456, label %local.descriptor.inactive.457
local.descriptor.active.456:
  %local.check.offset.459 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.460 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.461 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.462 = load i32, ptr %local.owner.end.12, align 4
  %context.field.463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.464 = load i32, ptr %context.field.463, align 4
  %stack.sub.467 = sub i32 %local.check.owner.end.462, %local.check.offset.459
  %descriptor.owner.inside.465 = icmp ule i32 %local.check.owner.end.462, %context.value.464
  %descriptor.offset.inside.466 = icmp ule i32 %local.check.offset.459, %local.check.owner.end.462
  %descriptor.extent.inside.468 = icmp ule i32 %local.check.extent.460, %stack.sub.467
  %descriptor.payload.inside.469 = icmp ule i32 %local.check.payload.461, %local.check.extent.460
  %descriptor.owner.offset.valid.470 = and i1 %descriptor.owner.inside.465, %descriptor.offset.inside.466
  %descriptor.range.inside.472 = and i1 %descriptor.owner.offset.valid.470, %descriptor.extent.inside.468
  %descriptor.range.valid.471 = and i1 %descriptor.range.inside.472, %descriptor.payload.inside.469
  br i1 %descriptor.range.valid.471, label %descriptor.valid.473, label %descriptor.invalid.474
descriptor.invalid.474:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.473:
  %descriptor.initialized.status.475 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.459, i32 %local.check.extent.460)
  %helper.ok.476 = icmp eq i32 %descriptor.initialized.status.475, 0
  br i1 %helper.ok.476, label %helper.continue.477, label %frame.failure.0
helper.continue.477:
  br label %local.descriptor.checked.458
local.descriptor.inactive.457:
  br label %local.descriptor.checked.458
local.descriptor.checked.458:
  %local.is.active.478 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.478, label %local.descriptor.active.479, label %local.descriptor.inactive.480
local.descriptor.active.479:
  %local.check.offset.482 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.483 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.484 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.485 = load i32, ptr %local.owner.end.18, align 4
  %context.field.486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.487 = load i32, ptr %context.field.486, align 4
  %stack.sub.490 = sub i32 %local.check.owner.end.485, %local.check.offset.482
  %descriptor.owner.inside.488 = icmp ule i32 %local.check.owner.end.485, %context.value.487
  %descriptor.offset.inside.489 = icmp ule i32 %local.check.offset.482, %local.check.owner.end.485
  %descriptor.extent.inside.491 = icmp ule i32 %local.check.extent.483, %stack.sub.490
  %descriptor.payload.inside.492 = icmp ule i32 %local.check.payload.484, %local.check.extent.483
  %descriptor.owner.offset.valid.493 = and i1 %descriptor.owner.inside.488, %descriptor.offset.inside.489
  %descriptor.range.inside.495 = and i1 %descriptor.owner.offset.valid.493, %descriptor.extent.inside.491
  %descriptor.range.valid.494 = and i1 %descriptor.range.inside.495, %descriptor.payload.inside.492
  br i1 %descriptor.range.valid.494, label %descriptor.valid.496, label %descriptor.invalid.497
descriptor.invalid.497:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.496:
  %descriptor.initialized.status.498 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.482, i32 %local.check.extent.483)
  %helper.ok.499 = icmp eq i32 %descriptor.initialized.status.498, 0
  br i1 %helper.ok.499, label %helper.continue.500, label %frame.failure.0
helper.continue.500:
  br label %local.descriptor.checked.481
local.descriptor.inactive.480:
  br label %local.descriptor.checked.481
local.descriptor.checked.481:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  br label %result.join.241
result.join.241:
  %result.value.offset.501 = phi i32 [ %context.value.267, %local.descriptor.checked.346 ], [ %local.resolved.offset.390, %local.descriptor.checked.481 ]
  %result.value.extent.502 = phi i32 [ 8, %local.descriptor.checked.346 ], [ %local.resolved.extent.391, %local.descriptor.checked.481 ]
  %result.value.payload.503 = phi i32 [ 8, %local.descriptor.checked.346 ], [ %local.resolved.payload.392, %local.descriptor.checked.481 ]
  %result.value.owner.end.504 = phi i32 [ %stack.offset.268, %local.descriptor.checked.346 ], [ %local.resolved.owner.end.393, %local.descriptor.checked.481 ]
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %stack.sub.509 = sub i32 %result.value.owner.end.504, %result.value.offset.501
  %descriptor.owner.inside.507 = icmp ule i32 %result.value.owner.end.504, %context.value.506
  %descriptor.offset.inside.508 = icmp ule i32 %result.value.offset.501, %result.value.owner.end.504
  %descriptor.extent.inside.510 = icmp ule i32 %result.value.extent.502, %stack.sub.509
  %descriptor.payload.inside.511 = icmp ule i32 %result.value.payload.503, %result.value.extent.502
  %descriptor.owner.offset.valid.512 = and i1 %descriptor.owner.inside.507, %descriptor.offset.inside.508
  %descriptor.range.inside.514 = and i1 %descriptor.owner.offset.valid.512, %descriptor.extent.inside.510
  %descriptor.range.valid.513 = and i1 %descriptor.range.inside.514, %descriptor.payload.inside.511
  %descriptor.type.valid.515 = icmp eq i32 1, 1
  %descriptor.valid.516 = and i1 %descriptor.range.valid.513, %descriptor.type.valid.515
  br i1 %descriptor.valid.516, label %descriptor.valid.517, label %descriptor.invalid.518
descriptor.invalid.518:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.517:
  %descriptor.initialized.status.519 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %result.value.offset.501, i32 %result.value.extent.502)
  %helper.ok.520 = icmp eq i32 %descriptor.initialized.status.519, 0
  br i1 %helper.ok.520, label %helper.continue.521, label %frame.failure.0
helper.continue.521:
  %local.is.active.522 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.522, label %local.descriptor.active.523, label %local.descriptor.inactive.524
local.descriptor.active.523:
  %local.check.offset.526 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.527 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.528 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.529 = load i32, ptr %local.owner.end.6, align 4
  %context.field.530 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.531 = load i32, ptr %context.field.530, align 4
  %stack.sub.534 = sub i32 %local.check.owner.end.529, %local.check.offset.526
  %descriptor.owner.inside.532 = icmp ule i32 %local.check.owner.end.529, %context.value.531
  %descriptor.offset.inside.533 = icmp ule i32 %local.check.offset.526, %local.check.owner.end.529
  %descriptor.extent.inside.535 = icmp ule i32 %local.check.extent.527, %stack.sub.534
  %descriptor.payload.inside.536 = icmp ule i32 %local.check.payload.528, %local.check.extent.527
  %descriptor.owner.offset.valid.537 = and i1 %descriptor.owner.inside.532, %descriptor.offset.inside.533
  %descriptor.range.inside.539 = and i1 %descriptor.owner.offset.valid.537, %descriptor.extent.inside.535
  %descriptor.range.valid.538 = and i1 %descriptor.range.inside.539, %descriptor.payload.inside.536
  br i1 %descriptor.range.valid.538, label %descriptor.valid.540, label %descriptor.invalid.541
descriptor.invalid.541:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.540:
  %descriptor.initialized.status.542 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.526, i32 %local.check.extent.527)
  %helper.ok.543 = icmp eq i32 %descriptor.initialized.status.542, 0
  br i1 %helper.ok.543, label %helper.continue.544, label %frame.failure.0
helper.continue.544:
  br label %local.descriptor.checked.525
local.descriptor.inactive.524:
  br label %local.descriptor.checked.525
local.descriptor.checked.525:
  %local.is.active.545 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.545, label %local.descriptor.active.546, label %local.descriptor.inactive.547
local.descriptor.active.546:
  %local.check.offset.549 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.550 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.551 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.552 = load i32, ptr %local.owner.end.12, align 4
  %context.field.553 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.554 = load i32, ptr %context.field.553, align 4
  %stack.sub.557 = sub i32 %local.check.owner.end.552, %local.check.offset.549
  %descriptor.owner.inside.555 = icmp ule i32 %local.check.owner.end.552, %context.value.554
  %descriptor.offset.inside.556 = icmp ule i32 %local.check.offset.549, %local.check.owner.end.552
  %descriptor.extent.inside.558 = icmp ule i32 %local.check.extent.550, %stack.sub.557
  %descriptor.payload.inside.559 = icmp ule i32 %local.check.payload.551, %local.check.extent.550
  %descriptor.owner.offset.valid.560 = and i1 %descriptor.owner.inside.555, %descriptor.offset.inside.556
  %descriptor.range.inside.562 = and i1 %descriptor.owner.offset.valid.560, %descriptor.extent.inside.558
  %descriptor.range.valid.561 = and i1 %descriptor.range.inside.562, %descriptor.payload.inside.559
  br i1 %descriptor.range.valid.561, label %descriptor.valid.563, label %descriptor.invalid.564
descriptor.invalid.564:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.563:
  %descriptor.initialized.status.565 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.549, i32 %local.check.extent.550)
  %helper.ok.566 = icmp eq i32 %descriptor.initialized.status.565, 0
  br i1 %helper.ok.566, label %helper.continue.567, label %frame.failure.0
helper.continue.567:
  br label %local.descriptor.checked.548
local.descriptor.inactive.547:
  br label %local.descriptor.checked.548
local.descriptor.checked.548:
  %local.is.active.568 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.568, label %local.descriptor.active.569, label %local.descriptor.inactive.570
local.descriptor.active.569:
  %local.check.offset.572 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.573 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.574 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.575 = load i32, ptr %local.owner.end.18, align 4
  %context.field.576 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.577 = load i32, ptr %context.field.576, align 4
  %stack.sub.580 = sub i32 %local.check.owner.end.575, %local.check.offset.572
  %descriptor.owner.inside.578 = icmp ule i32 %local.check.owner.end.575, %context.value.577
  %descriptor.offset.inside.579 = icmp ule i32 %local.check.offset.572, %local.check.owner.end.575
  %descriptor.extent.inside.581 = icmp ule i32 %local.check.extent.573, %stack.sub.580
  %descriptor.payload.inside.582 = icmp ule i32 %local.check.payload.574, %local.check.extent.573
  %descriptor.owner.offset.valid.583 = and i1 %descriptor.owner.inside.578, %descriptor.offset.inside.579
  %descriptor.range.inside.585 = and i1 %descriptor.owner.offset.valid.583, %descriptor.extent.inside.581
  %descriptor.range.valid.584 = and i1 %descriptor.range.inside.585, %descriptor.payload.inside.582
  br i1 %descriptor.range.valid.584, label %descriptor.valid.586, label %descriptor.invalid.587
descriptor.invalid.587:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.586:
  %descriptor.initialized.status.588 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.572, i32 %local.check.extent.573)
  %helper.ok.589 = icmp eq i32 %descriptor.initialized.status.588, 0
  br i1 %helper.ok.589, label %helper.continue.590, label %frame.failure.0
helper.continue.590:
  br label %local.descriptor.checked.571
local.descriptor.inactive.570:
  br label %local.descriptor.checked.571
local.descriptor.checked.571:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  br label %option.join.83
option.none.81:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %step.status.591 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.592 = icmp eq i32 %step.status.591, 0
  br i1 %helper.ok.592, label %helper.continue.593, label %frame.failure.0
helper.continue.593:
  %context.field.594 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.595 = load i32, ptr %context.field.594, align 4
  %stack.offset.596 = add i32 %context.value.595, 8
  %reserve.status.597 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.596, i32 10)
  %reserve.ok.598 = icmp eq i32 %reserve.status.597, 0
  br i1 %reserve.ok.598, label %reserve.continue.599, label %frame.failure.0
reserve.continue.599:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.595, i64 -1, i32 1)
  %context.field.600 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.601 = load i32, ptr %context.field.600, align 4
  %runtime.ok.602 = icmp eq i32 %context.value.601, 0
  br i1 %runtime.ok.602, label %runtime.continue.603, label %frame.failure.0
runtime.continue.603:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.605 = load i32, ptr %context.field.604, align 4
  %runtime.ok.606 = icmp eq i32 %context.value.605, 0
  br i1 %runtime.ok.606, label %runtime.continue.607, label %frame.failure.0
runtime.continue.607:
  %context.field.608 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.609 = load i32, ptr %context.field.608, align 4
  %stack.sub.612 = sub i32 %stack.offset.596, %context.value.595
  %descriptor.owner.inside.610 = icmp ule i32 %stack.offset.596, %context.value.609
  %descriptor.offset.inside.611 = icmp ule i32 %context.value.595, %stack.offset.596
  %descriptor.extent.inside.613 = icmp ule i32 8, %stack.sub.612
  %descriptor.payload.inside.614 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.615 = and i1 %descriptor.owner.inside.610, %descriptor.offset.inside.611
  %descriptor.range.inside.617 = and i1 %descriptor.owner.offset.valid.615, %descriptor.extent.inside.613
  %descriptor.range.valid.616 = and i1 %descriptor.range.inside.617, %descriptor.payload.inside.614
  %descriptor.type.valid.618 = icmp eq i32 1, 1
  %descriptor.valid.619 = and i1 %descriptor.range.valid.616, %descriptor.type.valid.618
  br i1 %descriptor.valid.619, label %descriptor.valid.620, label %descriptor.invalid.621
descriptor.invalid.621:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.620:
  %descriptor.initialized.status.622 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.595, i32 8)
  %helper.ok.623 = icmp eq i32 %descriptor.initialized.status.622, 0
  br i1 %helper.ok.623, label %helper.continue.624, label %frame.failure.0
helper.continue.624:
  %local.is.active.625 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.625, label %local.descriptor.active.626, label %local.descriptor.inactive.627
local.descriptor.active.626:
  %local.check.offset.629 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.630 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.631 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.632 = load i32, ptr %local.owner.end.6, align 4
  %context.field.633 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.634 = load i32, ptr %context.field.633, align 4
  %stack.sub.637 = sub i32 %local.check.owner.end.632, %local.check.offset.629
  %descriptor.owner.inside.635 = icmp ule i32 %local.check.owner.end.632, %context.value.634
  %descriptor.offset.inside.636 = icmp ule i32 %local.check.offset.629, %local.check.owner.end.632
  %descriptor.extent.inside.638 = icmp ule i32 %local.check.extent.630, %stack.sub.637
  %descriptor.payload.inside.639 = icmp ule i32 %local.check.payload.631, %local.check.extent.630
  %descriptor.owner.offset.valid.640 = and i1 %descriptor.owner.inside.635, %descriptor.offset.inside.636
  %descriptor.range.inside.642 = and i1 %descriptor.owner.offset.valid.640, %descriptor.extent.inside.638
  %descriptor.range.valid.641 = and i1 %descriptor.range.inside.642, %descriptor.payload.inside.639
  br i1 %descriptor.range.valid.641, label %descriptor.valid.643, label %descriptor.invalid.644
descriptor.invalid.644:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.643:
  %descriptor.initialized.status.645 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.629, i32 %local.check.extent.630)
  %helper.ok.646 = icmp eq i32 %descriptor.initialized.status.645, 0
  br i1 %helper.ok.646, label %helper.continue.647, label %frame.failure.0
helper.continue.647:
  br label %local.descriptor.checked.628
local.descriptor.inactive.627:
  br label %local.descriptor.checked.628
local.descriptor.checked.628:
  %local.is.active.648 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.648, label %local.descriptor.active.649, label %local.descriptor.inactive.650
local.descriptor.active.649:
  %local.check.offset.652 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.653 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.654 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.655 = load i32, ptr %local.owner.end.12, align 4
  %context.field.656 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.657 = load i32, ptr %context.field.656, align 4
  %stack.sub.660 = sub i32 %local.check.owner.end.655, %local.check.offset.652
  %descriptor.owner.inside.658 = icmp ule i32 %local.check.owner.end.655, %context.value.657
  %descriptor.offset.inside.659 = icmp ule i32 %local.check.offset.652, %local.check.owner.end.655
  %descriptor.extent.inside.661 = icmp ule i32 %local.check.extent.653, %stack.sub.660
  %descriptor.payload.inside.662 = icmp ule i32 %local.check.payload.654, %local.check.extent.653
  %descriptor.owner.offset.valid.663 = and i1 %descriptor.owner.inside.658, %descriptor.offset.inside.659
  %descriptor.range.inside.665 = and i1 %descriptor.owner.offset.valid.663, %descriptor.extent.inside.661
  %descriptor.range.valid.664 = and i1 %descriptor.range.inside.665, %descriptor.payload.inside.662
  br i1 %descriptor.range.valid.664, label %descriptor.valid.666, label %descriptor.invalid.667
descriptor.invalid.667:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.666:
  %descriptor.initialized.status.668 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.652, i32 %local.check.extent.653)
  %helper.ok.669 = icmp eq i32 %descriptor.initialized.status.668, 0
  br i1 %helper.ok.669, label %helper.continue.670, label %frame.failure.0
helper.continue.670:
  br label %local.descriptor.checked.651
local.descriptor.inactive.650:
  br label %local.descriptor.checked.651
local.descriptor.checked.651:
  %local.is.active.671 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.671, label %local.descriptor.active.672, label %local.descriptor.inactive.673
local.descriptor.active.672:
  %local.check.offset.675 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.676 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.677 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.678 = load i32, ptr %local.owner.end.18, align 4
  %context.field.679 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.680 = load i32, ptr %context.field.679, align 4
  %stack.sub.683 = sub i32 %local.check.owner.end.678, %local.check.offset.675
  %descriptor.owner.inside.681 = icmp ule i32 %local.check.owner.end.678, %context.value.680
  %descriptor.offset.inside.682 = icmp ule i32 %local.check.offset.675, %local.check.owner.end.678
  %descriptor.extent.inside.684 = icmp ule i32 %local.check.extent.676, %stack.sub.683
  %descriptor.payload.inside.685 = icmp ule i32 %local.check.payload.677, %local.check.extent.676
  %descriptor.owner.offset.valid.686 = and i1 %descriptor.owner.inside.681, %descriptor.offset.inside.682
  %descriptor.range.inside.688 = and i1 %descriptor.owner.offset.valid.686, %descriptor.extent.inside.684
  %descriptor.range.valid.687 = and i1 %descriptor.range.inside.688, %descriptor.payload.inside.685
  br i1 %descriptor.range.valid.687, label %descriptor.valid.689, label %descriptor.invalid.690
descriptor.invalid.690:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.689:
  %descriptor.initialized.status.691 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.675, i32 %local.check.extent.676)
  %helper.ok.692 = icmp eq i32 %descriptor.initialized.status.691, 0
  br i1 %helper.ok.692, label %helper.continue.693, label %frame.failure.0
helper.continue.693:
  br label %local.descriptor.checked.674
local.descriptor.inactive.673:
  br label %local.descriptor.checked.674
local.descriptor.checked.674:
  br label %option.join.83
option.join.83:
  %option.value.offset.694 = phi i32 [ %result.value.offset.501, %local.descriptor.checked.571 ], [ %context.value.595, %local.descriptor.checked.674 ]
  %option.value.extent.695 = phi i32 [ %result.value.extent.502, %local.descriptor.checked.571 ], [ 8, %local.descriptor.checked.674 ]
  %option.value.payload.696 = phi i32 [ %result.value.payload.503, %local.descriptor.checked.571 ], [ 8, %local.descriptor.checked.674 ]
  %option.value.owner.end.697 = phi i32 [ %result.value.owner.end.504, %local.descriptor.checked.571 ], [ %stack.offset.596, %local.descriptor.checked.674 ]
  %context.field.698 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.699 = load i32, ptr %context.field.698, align 4
  %stack.sub.702 = sub i32 %option.value.owner.end.697, %option.value.offset.694
  %descriptor.owner.inside.700 = icmp ule i32 %option.value.owner.end.697, %context.value.699
  %descriptor.offset.inside.701 = icmp ule i32 %option.value.offset.694, %option.value.owner.end.697
  %descriptor.extent.inside.703 = icmp ule i32 %option.value.extent.695, %stack.sub.702
  %descriptor.payload.inside.704 = icmp ule i32 %option.value.payload.696, %option.value.extent.695
  %descriptor.owner.offset.valid.705 = and i1 %descriptor.owner.inside.700, %descriptor.offset.inside.701
  %descriptor.range.inside.707 = and i1 %descriptor.owner.offset.valid.705, %descriptor.extent.inside.703
  %descriptor.range.valid.706 = and i1 %descriptor.range.inside.707, %descriptor.payload.inside.704
  %descriptor.type.valid.708 = icmp eq i32 1, 1
  %descriptor.valid.709 = and i1 %descriptor.range.valid.706, %descriptor.type.valid.708
  br i1 %descriptor.valid.709, label %descriptor.valid.710, label %descriptor.invalid.711
descriptor.invalid.711:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.710:
  %descriptor.initialized.status.712 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %option.value.offset.694, i32 %option.value.extent.695)
  %helper.ok.713 = icmp eq i32 %descriptor.initialized.status.712, 0
  br i1 %helper.ok.713, label %helper.continue.714, label %frame.failure.0
helper.continue.714:
  %local.is.active.715 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.715, label %local.descriptor.active.716, label %local.descriptor.inactive.717
local.descriptor.active.716:
  %local.check.offset.719 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.720 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.721 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.722 = load i32, ptr %local.owner.end.6, align 4
  %context.field.723 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.724 = load i32, ptr %context.field.723, align 4
  %stack.sub.727 = sub i32 %local.check.owner.end.722, %local.check.offset.719
  %descriptor.owner.inside.725 = icmp ule i32 %local.check.owner.end.722, %context.value.724
  %descriptor.offset.inside.726 = icmp ule i32 %local.check.offset.719, %local.check.owner.end.722
  %descriptor.extent.inside.728 = icmp ule i32 %local.check.extent.720, %stack.sub.727
  %descriptor.payload.inside.729 = icmp ule i32 %local.check.payload.721, %local.check.extent.720
  %descriptor.owner.offset.valid.730 = and i1 %descriptor.owner.inside.725, %descriptor.offset.inside.726
  %descriptor.range.inside.732 = and i1 %descriptor.owner.offset.valid.730, %descriptor.extent.inside.728
  %descriptor.range.valid.731 = and i1 %descriptor.range.inside.732, %descriptor.payload.inside.729
  br i1 %descriptor.range.valid.731, label %descriptor.valid.733, label %descriptor.invalid.734
descriptor.invalid.734:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.733:
  %descriptor.initialized.status.735 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.719, i32 %local.check.extent.720)
  %helper.ok.736 = icmp eq i32 %descriptor.initialized.status.735, 0
  br i1 %helper.ok.736, label %helper.continue.737, label %frame.failure.0
helper.continue.737:
  br label %local.descriptor.checked.718
local.descriptor.inactive.717:
  br label %local.descriptor.checked.718
local.descriptor.checked.718:
  %local.is.active.738 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.738, label %local.descriptor.active.739, label %local.descriptor.inactive.740
local.descriptor.active.739:
  %local.check.offset.742 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.743 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.744 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.745 = load i32, ptr %local.owner.end.12, align 4
  %context.field.746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.747 = load i32, ptr %context.field.746, align 4
  %stack.sub.750 = sub i32 %local.check.owner.end.745, %local.check.offset.742
  %descriptor.owner.inside.748 = icmp ule i32 %local.check.owner.end.745, %context.value.747
  %descriptor.offset.inside.749 = icmp ule i32 %local.check.offset.742, %local.check.owner.end.745
  %descriptor.extent.inside.751 = icmp ule i32 %local.check.extent.743, %stack.sub.750
  %descriptor.payload.inside.752 = icmp ule i32 %local.check.payload.744, %local.check.extent.743
  %descriptor.owner.offset.valid.753 = and i1 %descriptor.owner.inside.748, %descriptor.offset.inside.749
  %descriptor.range.inside.755 = and i1 %descriptor.owner.offset.valid.753, %descriptor.extent.inside.751
  %descriptor.range.valid.754 = and i1 %descriptor.range.inside.755, %descriptor.payload.inside.752
  br i1 %descriptor.range.valid.754, label %descriptor.valid.756, label %descriptor.invalid.757
descriptor.invalid.757:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.756:
  %descriptor.initialized.status.758 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.742, i32 %local.check.extent.743)
  %helper.ok.759 = icmp eq i32 %descriptor.initialized.status.758, 0
  br i1 %helper.ok.759, label %helper.continue.760, label %frame.failure.0
helper.continue.760:
  br label %local.descriptor.checked.741
local.descriptor.inactive.740:
  br label %local.descriptor.checked.741
local.descriptor.checked.741:
  %local.is.active.761 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.761, label %local.descriptor.active.762, label %local.descriptor.inactive.763
local.descriptor.active.762:
  %local.check.offset.765 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.766 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.767 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.768 = load i32, ptr %local.owner.end.18, align 4
  %context.field.769 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.770 = load i32, ptr %context.field.769, align 4
  %stack.sub.773 = sub i32 %local.check.owner.end.768, %local.check.offset.765
  %descriptor.owner.inside.771 = icmp ule i32 %local.check.owner.end.768, %context.value.770
  %descriptor.offset.inside.772 = icmp ule i32 %local.check.offset.765, %local.check.owner.end.768
  %descriptor.extent.inside.774 = icmp ule i32 %local.check.extent.766, %stack.sub.773
  %descriptor.payload.inside.775 = icmp ule i32 %local.check.payload.767, %local.check.extent.766
  %descriptor.owner.offset.valid.776 = and i1 %descriptor.owner.inside.771, %descriptor.offset.inside.772
  %descriptor.range.inside.778 = and i1 %descriptor.owner.offset.valid.776, %descriptor.extent.inside.774
  %descriptor.range.valid.777 = and i1 %descriptor.range.inside.778, %descriptor.payload.inside.775
  br i1 %descriptor.range.valid.777, label %descriptor.valid.779, label %descriptor.invalid.780
descriptor.invalid.780:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.779:
  %descriptor.initialized.status.781 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.765, i32 %local.check.extent.766)
  %helper.ok.782 = icmp eq i32 %descriptor.initialized.status.781, 0
  br i1 %helper.ok.782, label %helper.continue.783, label %frame.failure.0
helper.continue.783:
  br label %local.descriptor.checked.764
local.descriptor.inactive.763:
  br label %local.descriptor.checked.764
local.descriptor.checked.764:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.784 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.785 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.784, i32 0, i32 0
  store i32 1, ptr %descriptor.field.785, align 4
  %descriptor.field.786 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.784, i32 0, i32 1
  store i32 %option.value.offset.694, ptr %descriptor.field.786, align 4
  %descriptor.field.787 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.784, i32 0, i32 2
  store i32 %option.value.extent.695, ptr %descriptor.field.787, align 4
  %descriptor.field.788 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.784, i32 0, i32 3
  store i32 %option.value.payload.696, ptr %descriptor.field.788, align 4
  %descriptor.field.789 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.784, i32 0, i32 4
  store i32 %option.value.owner.end.697, ptr %descriptor.field.789, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %option.value.offset.694, i32 20, i32 %option.value.payload.696, i32 %option.value.owner.end.697, i32 %option.value.extent.695)
  %context.field.790 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.791 = load i32, ptr %context.field.790, align 4
  %runtime.ok.792 = icmp eq i32 %context.value.791, 0
  br i1 %runtime.ok.792, label %runtime.continue.793, label %frame.failure.0
runtime.continue.793:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.794 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.795 = load i32, ptr %context.field.794, align 4
  %context.field.796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.797 = load i32, ptr %context.field.796, align 4
  %context.field.798 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.799 = load i32, ptr %context.field.798, align 4
  %stack.offset.800 = add i32 %context.value.23, %context.value.25
  %stack.offset.801 = add i32 %context.value.795, %context.value.797
  %stack.sub.802 = sub i32 %stack.offset.800, %stack.offset.801
  %stack.sub.803 = sub i32 %context.value.25, %context.value.797
  %stack.sub.804 = sub i32 %context.value.799, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.802, i32 %stack.sub.803)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.804)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 11, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 12)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 8, i32 13)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 8, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 14)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 1
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 1, 1
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


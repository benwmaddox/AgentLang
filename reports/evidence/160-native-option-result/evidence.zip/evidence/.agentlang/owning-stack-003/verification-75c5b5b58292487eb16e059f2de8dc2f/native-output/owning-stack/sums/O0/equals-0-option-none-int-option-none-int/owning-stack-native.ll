%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.17, i64 1, i32 8)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.17, i32 8, i32 8, i32 0, i32 0)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %frame.failure.0
runtime.continue.33:
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %stack.sub.38 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.36 = icmp ule i32 %stack.offset.18, %context.value.35
  %descriptor.offset.inside.37 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.39 = icmp ule i32 8, %stack.sub.38
  %descriptor.payload.inside.40 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.41 = and i1 %descriptor.owner.inside.36, %descriptor.offset.inside.37
  %descriptor.range.inside.43 = and i1 %descriptor.owner.offset.valid.41, %descriptor.extent.inside.39
  %descriptor.range.valid.42 = and i1 %descriptor.range.inside.43, %descriptor.payload.inside.40
  %descriptor.type.valid.44 = icmp eq i32 8, 8
  %descriptor.valid.45 = and i1 %descriptor.range.valid.42, %descriptor.type.valid.44
  br i1 %descriptor.valid.45, label %descriptor.valid.46, label %descriptor.invalid.47
descriptor.invalid.47:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.46:
  %descriptor.initialized.status.48 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.49 = icmp eq i32 %descriptor.initialized.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %frame.failure.0
helper.continue.50:
  %step.status.51 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.52 = icmp eq i32 %step.status.51, 0
  br i1 %helper.ok.52, label %helper.continue.53, label %frame.failure.0
helper.continue.53:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %stack.offset.56 = add i32 %context.value.55, 8
  %reserve.status.57 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.56, i32 4)
  %reserve.ok.58 = icmp eq i32 %reserve.status.57, 0
  br i1 %reserve.ok.58, label %reserve.continue.59, label %frame.failure.0
reserve.continue.59:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.55, i64 1, i32 8)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.55, i32 8, i32 8, i32 0, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.18, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 8, 8
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %stack.sub.93 = sub i32 %stack.offset.56, %context.value.55
  %descriptor.owner.inside.91 = icmp ule i32 %stack.offset.56, %context.value.90
  %descriptor.offset.inside.92 = icmp ule i32 %context.value.55, %stack.offset.56
  %descriptor.extent.inside.94 = icmp ule i32 8, %stack.sub.93
  %descriptor.payload.inside.95 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.96 = and i1 %descriptor.owner.inside.91, %descriptor.offset.inside.92
  %descriptor.range.inside.98 = and i1 %descriptor.owner.offset.valid.96, %descriptor.extent.inside.94
  %descriptor.range.valid.97 = and i1 %descriptor.range.inside.98, %descriptor.payload.inside.95
  %descriptor.type.valid.99 = icmp eq i32 8, 8
  %descriptor.valid.100 = and i1 %descriptor.range.valid.97, %descriptor.type.valid.99
  br i1 %descriptor.valid.100, label %descriptor.valid.101, label %descriptor.invalid.102
descriptor.invalid.102:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.101:
  %descriptor.initialized.status.103 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.55, i32 8)
  %helper.ok.104 = icmp eq i32 %descriptor.initialized.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %step.status.106 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.107 = icmp eq i32 %step.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %equals.same.extent.109 = icmp eq i32 8, 8
  br i1 %equals.same.extent.109, label %equals.compare.110, label %equals.different.111
equals.compare.110:
  %equals.result.113 = call i32 @al_owning_equal(ptr %ctx, i32 %context.value.17, i32 %context.value.55, i32 8)
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %runtime.ok.116 = icmp eq i32 %context.value.115, 0
  br i1 %runtime.ok.116, label %runtime.continue.117, label %frame.failure.0
runtime.continue.117:
  br label %equals.join.112
equals.different.111:
  br label %equals.join.112
equals.join.112:
  %equals.value.118 = phi i32 [ %equals.result.113, %runtime.continue.117 ], [ 0, %equals.different.111 ]
  %equals.bool.119 = icmp ne i32 %equals.value.118, 0
  %equals.i64.120 = zext i1 %equals.bool.119 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.55, i32 8, i32 8, i32 0, i32 0)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %runtime.ok.123 = icmp eq i32 %context.value.122, 0
  br i1 %runtime.ok.123, label %runtime.continue.124, label %frame.failure.0
runtime.continue.124:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.17, i32 8, i32 8, i32 0, i32 0)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %runtime.ok.127 = icmp eq i32 %context.value.126, 0
  br i1 %runtime.ok.127, label %runtime.continue.128, label %frame.failure.0
runtime.continue.128:
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %stack.offset.131 = add i32 %context.value.130, 8
  %reserve.status.132 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.131, i32 6)
  %reserve.ok.133 = icmp eq i32 %reserve.status.132, 0
  br i1 %reserve.ok.133, label %reserve.continue.134, label %frame.failure.0
reserve.continue.134:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.130, i64 %equals.i64.120, i32 2)
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %runtime.ok.137 = icmp eq i32 %context.value.136, 0
  br i1 %runtime.ok.137, label %runtime.continue.138, label %frame.failure.0
runtime.continue.138:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %frame.failure.0
runtime.continue.142:
  %stack.offset.143 = add i32 %context.value.130, 8
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.145 = load i32, ptr %context.field.144, align 4
  %stack.sub.148 = sub i32 %stack.offset.143, %context.value.130
  %descriptor.owner.inside.146 = icmp ule i32 %stack.offset.143, %context.value.145
  %descriptor.offset.inside.147 = icmp ule i32 %context.value.130, %stack.offset.143
  %descriptor.extent.inside.149 = icmp ule i32 8, %stack.sub.148
  %descriptor.payload.inside.150 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.151 = and i1 %descriptor.owner.inside.146, %descriptor.offset.inside.147
  %descriptor.range.inside.153 = and i1 %descriptor.owner.offset.valid.151, %descriptor.extent.inside.149
  %descriptor.range.valid.152 = and i1 %descriptor.range.inside.153, %descriptor.payload.inside.150
  %descriptor.type.valid.154 = icmp eq i32 2, 2
  %descriptor.valid.155 = and i1 %descriptor.range.valid.152, %descriptor.type.valid.154
  br i1 %descriptor.valid.155, label %descriptor.valid.156, label %descriptor.invalid.157
descriptor.invalid.157:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.156:
  %descriptor.initialized.status.158 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.130, i32 8)
  %helper.ok.159 = icmp eq i32 %descriptor.initialized.status.158, 0
  br i1 %helper.ok.159, label %helper.continue.160, label %frame.failure.0
helper.continue.160:
  %descriptor.element.161 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.162 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.161, i32 0, i32 0
  store i32 2, ptr %descriptor.field.162, align 4
  %descriptor.field.163 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.161, i32 0, i32 1
  store i32 %context.value.130, ptr %descriptor.field.163, align 4
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.161, i32 0, i32 2
  store i32 8, ptr %descriptor.field.164, align 4
  %descriptor.field.165 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.161, i32 0, i32 3
  store i32 8, ptr %descriptor.field.165, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.161, i32 0, i32 4
  store i32 %stack.offset.143, ptr %descriptor.field.166, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.130, i32 20, i32 8, i32 %stack.offset.143, i32 8)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %context.field.173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.174 = load i32, ptr %context.field.173, align 4
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.5, %context.value.7
  %stack.offset.178 = add i32 %context.value.172, %context.value.174
  %stack.sub.179 = sub i32 %stack.offset.177, %stack.offset.178
  %stack.sub.180 = sub i32 %context.value.7, %context.value.174
  %stack.sub.181 = sub i32 %context.value.176, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.179, i32 %stack.sub.180)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.181)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 7)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 8)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 2
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 2, 2
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 2)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 6, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\03\00\00\00\00\00\00\00\41\00\00\00\42\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 16
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  %literal.status.22 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.17, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 14, i32 16, i32 7, i32 3)
  %helper.ok.23 = icmp eq i32 %literal.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %stack.sub.29 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.27 = icmp ule i32 %stack.offset.18, %context.value.26
  %descriptor.offset.inside.28 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.30 = icmp ule i32 16, %stack.sub.29
  %descriptor.payload.inside.31 = icmp ule i32 14, 16
  %descriptor.owner.offset.valid.32 = and i1 %descriptor.owner.inside.27, %descriptor.offset.inside.28
  %descriptor.range.inside.34 = and i1 %descriptor.owner.offset.valid.32, %descriptor.extent.inside.30
  %descriptor.range.valid.33 = and i1 %descriptor.range.inside.34, %descriptor.payload.inside.31
  %descriptor.type.valid.35 = icmp eq i32 7, 7
  %descriptor.valid.36 = and i1 %descriptor.range.valid.33, %descriptor.type.valid.35
  br i1 %descriptor.valid.36, label %descriptor.valid.37, label %descriptor.invalid.38
descriptor.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.37:
  %descriptor.initialized.status.39 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 16)
  %helper.ok.40 = icmp eq i32 %descriptor.initialized.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %frame.failure.0
helper.continue.41:
  %step.status.42 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.43 = icmp eq i32 %step.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %frame.failure.0
helper.continue.44:
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %stack.offset.47 = add i32 8, 16
  %stack.offset.48 = add i32 8, 14
  %stack.offset.49 = add i32 %context.value.46, %stack.offset.47
  %reserve.status.50 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.49, i32 5)
  %reserve.ok.51 = icmp eq i32 %reserve.status.50, 0
  br i1 %reserve.ok.51, label %reserve.continue.52, label %frame.failure.0
reserve.continue.52:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.46, i64 0, i32 8)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %context.value.46, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.57, i32 %context.value.17, i32 16, i32 14, i32 7, i32 6)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %runtime.ok.64 = icmp eq i32 %context.value.63, 0
  br i1 %runtime.ok.64, label %runtime.continue.65, label %frame.failure.0
runtime.continue.65:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.46, i32 %stack.offset.47, i32 %stack.offset.48, i32 %context.value.17, i32 16)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %frame.failure.0
runtime.continue.69:
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.72 = icmp ule i32 %stack.offset.49, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.75 = icmp ule i32 %stack.offset.47, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  %descriptor.type.valid.80 = icmp eq i32 8, 8
  %descriptor.valid.81 = and i1 %descriptor.range.valid.78, %descriptor.type.valid.80
  br i1 %descriptor.valid.81, label %descriptor.valid.82, label %descriptor.invalid.83
descriptor.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.82:
  %descriptor.initialized.status.84 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.85 = icmp eq i32 %descriptor.initialized.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %step.status.87 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.88 = icmp eq i32 %step.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %stack.offset.92 = add i32 %context.value.91, 8
  %reserve.status.93 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.92, i32 7)
  %reserve.ok.94 = icmp eq i32 %reserve.status.93, 0
  br i1 %reserve.ok.94, label %reserve.continue.95, label %frame.failure.0
reserve.continue.95:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.91, i64 99, i32 1)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %runtime.ok.98 = icmp eq i32 %context.value.97, 0
  br i1 %runtime.ok.98, label %runtime.continue.99, label %frame.failure.0
runtime.continue.99:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %stack.sub.108 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.106 = icmp ule i32 %stack.offset.49, %context.value.105
  %descriptor.offset.inside.107 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.109 = icmp ule i32 %stack.offset.47, %stack.sub.108
  %descriptor.payload.inside.110 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.111 = and i1 %descriptor.owner.inside.106, %descriptor.offset.inside.107
  %descriptor.range.inside.113 = and i1 %descriptor.owner.offset.valid.111, %descriptor.extent.inside.109
  %descriptor.range.valid.112 = and i1 %descriptor.range.inside.113, %descriptor.payload.inside.110
  %descriptor.type.valid.114 = icmp eq i32 8, 8
  %descriptor.valid.115 = and i1 %descriptor.range.valid.112, %descriptor.type.valid.114
  br i1 %descriptor.valid.115, label %descriptor.valid.116, label %descriptor.invalid.117
descriptor.invalid.117:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.116:
  %descriptor.initialized.status.118 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.119 = icmp eq i32 %descriptor.initialized.status.118, 0
  br i1 %helper.ok.119, label %helper.continue.120, label %frame.failure.0
helper.continue.120:
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.sub.125 = sub i32 %stack.offset.92, %context.value.91
  %descriptor.owner.inside.123 = icmp ule i32 %stack.offset.92, %context.value.122
  %descriptor.offset.inside.124 = icmp ule i32 %context.value.91, %stack.offset.92
  %descriptor.extent.inside.126 = icmp ule i32 8, %stack.sub.125
  %descriptor.payload.inside.127 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.128 = and i1 %descriptor.owner.inside.123, %descriptor.offset.inside.124
  %descriptor.range.inside.130 = and i1 %descriptor.owner.offset.valid.128, %descriptor.extent.inside.126
  %descriptor.range.valid.129 = and i1 %descriptor.range.inside.130, %descriptor.payload.inside.127
  %descriptor.type.valid.131 = icmp eq i32 1, 1
  %descriptor.valid.132 = and i1 %descriptor.range.valid.129, %descriptor.type.valid.131
  br i1 %descriptor.valid.132, label %descriptor.valid.133, label %descriptor.invalid.134
descriptor.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.133:
  %descriptor.initialized.status.135 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.91, i32 8)
  %helper.ok.136 = icmp eq i32 %descriptor.initialized.status.135, 0
  br i1 %helper.ok.136, label %helper.continue.137, label %frame.failure.0
helper.continue.137:
  %step.status.138 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.139 = icmp eq i32 %step.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %stack.offset.141 = add i32 0, %stack.offset.48
  %stack.offset.142 = add i32 %stack.offset.141, 8
  %stack.offset.143 = add i32 0, %stack.offset.47
  %stack.offset.144 = add i32 %stack.offset.143, 8
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %stack.offset.147 = add i32 %context.value.146, %stack.offset.144
  %reserve.status.148 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.147, i32 9)
  %reserve.ok.149 = icmp eq i32 %reserve.status.148, 0
  br i1 %reserve.ok.149, label %reserve.continue.150, label %frame.failure.0
reserve.continue.150:
  %stack.offset.151 = add i32 %context.value.146, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.151, i32 %context.value.46, i32 %stack.offset.47, i32 %stack.offset.48, i32 8, i32 6)
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %runtime.ok.154 = icmp eq i32 %context.value.153, 0
  br i1 %runtime.ok.154, label %runtime.continue.155, label %frame.failure.0
runtime.continue.155:
  %stack.offset.156 = add i32 0, %stack.offset.47
  %stack.offset.157 = add i32 %context.value.146, %stack.offset.156
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.157, i32 %context.value.91, i32 8, i32 8, i32 1, i32 6)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %stack.offset.162 = add i32 %stack.offset.156, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %context.value.146, i32 %stack.offset.144, i32 %stack.offset.142, i32 0, i32 0)
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %runtime.ok.165 = icmp eq i32 %context.value.164, 0
  br i1 %runtime.ok.165, label %runtime.continue.166, label %frame.failure.0
runtime.continue.166:
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %stack.sub.171 = sub i32 %stack.offset.147, %context.value.146
  %descriptor.owner.inside.169 = icmp ule i32 %stack.offset.147, %context.value.168
  %descriptor.offset.inside.170 = icmp ule i32 %context.value.146, %stack.offset.147
  %descriptor.extent.inside.172 = icmp ule i32 %stack.offset.144, %stack.sub.171
  %descriptor.payload.inside.173 = icmp ule i32 %stack.offset.142, %stack.offset.144
  %descriptor.owner.offset.valid.174 = and i1 %descriptor.owner.inside.169, %descriptor.offset.inside.170
  %descriptor.range.inside.176 = and i1 %descriptor.owner.offset.valid.174, %descriptor.extent.inside.172
  %descriptor.range.valid.175 = and i1 %descriptor.range.inside.176, %descriptor.payload.inside.173
  %descriptor.type.valid.177 = icmp eq i32 6, 6
  %descriptor.valid.178 = and i1 %descriptor.range.valid.175, %descriptor.type.valid.177
  br i1 %descriptor.valid.178, label %descriptor.valid.179, label %descriptor.invalid.180
descriptor.invalid.180:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.179:
  %descriptor.initialized.status.181 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.146, i32 %stack.offset.144)
  %helper.ok.182 = icmp eq i32 %descriptor.initialized.status.181, 0
  br i1 %helper.ok.182, label %helper.continue.183, label %frame.failure.0
helper.continue.183:
  %descriptor.element.184 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.184, i32 0, i32 0
  store i32 6, ptr %descriptor.field.185, align 4
  %descriptor.field.186 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.184, i32 0, i32 1
  store i32 %context.value.146, ptr %descriptor.field.186, align 4
  %descriptor.field.187 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.184, i32 0, i32 2
  store i32 %stack.offset.144, ptr %descriptor.field.187, align 4
  %descriptor.field.188 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.184, i32 0, i32 3
  store i32 %stack.offset.142, ptr %descriptor.field.188, align 4
  %descriptor.field.189 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.184, i32 0, i32 4
  store i32 %stack.offset.147, ptr %descriptor.field.189, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.146, i32 20, i32 %stack.offset.142, i32 %stack.offset.147, i32 %stack.offset.144)
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %runtime.ok.192 = icmp eq i32 %context.value.191, 0
  br i1 %runtime.ok.192, label %runtime.continue.193, label %frame.failure.0
runtime.continue.193:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %stack.offset.200 = add i32 %context.value.5, %context.value.7
  %stack.offset.201 = add i32 %context.value.195, %context.value.197
  %stack.sub.202 = sub i32 %stack.offset.200, %stack.offset.201
  %stack.sub.203 = sub i32 %context.value.7, %context.value.197
  %stack.sub.204 = sub i32 %context.value.199, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.202, i32 %stack.sub.203)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.204)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 10)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 11)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 6
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 6, 6
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 6)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


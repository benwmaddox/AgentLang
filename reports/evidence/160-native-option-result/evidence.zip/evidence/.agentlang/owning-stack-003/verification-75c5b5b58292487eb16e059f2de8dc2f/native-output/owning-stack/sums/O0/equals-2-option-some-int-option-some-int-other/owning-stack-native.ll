%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.17, i64 42, i32 1)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %stack.sub.34 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.32 = icmp ule i32 %stack.offset.18, %context.value.31
  %descriptor.offset.inside.33 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.35 = icmp ule i32 8, %stack.sub.34
  %descriptor.payload.inside.36 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.37 = and i1 %descriptor.owner.inside.32, %descriptor.offset.inside.33
  %descriptor.range.inside.39 = and i1 %descriptor.owner.offset.valid.37, %descriptor.extent.inside.35
  %descriptor.range.valid.38 = and i1 %descriptor.range.inside.39, %descriptor.payload.inside.36
  %descriptor.type.valid.40 = icmp eq i32 1, 1
  %descriptor.valid.41 = and i1 %descriptor.range.valid.38, %descriptor.type.valid.40
  br i1 %descriptor.valid.41, label %descriptor.valid.42, label %descriptor.invalid.43
descriptor.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.42:
  %descriptor.initialized.status.44 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.45 = icmp eq i32 %descriptor.initialized.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %frame.failure.0
helper.continue.46:
  %step.status.47 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.48 = icmp eq i32 %step.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %stack.offset.52 = add i32 8, 8
  %stack.offset.53 = add i32 8, 8
  %stack.offset.54 = add i32 %context.value.51, %stack.offset.52
  %reserve.status.55 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.54, i32 4)
  %reserve.ok.56 = icmp eq i32 %reserve.status.55, 0
  br i1 %reserve.ok.56, label %reserve.continue.57, label %frame.failure.0
reserve.continue.57:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.51, i64 0, i32 8)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %stack.offset.62 = add i32 %context.value.51, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.62, i32 %context.value.17, i32 8, i32 8, i32 1, i32 6)
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %runtime.ok.65 = icmp eq i32 %context.value.64, 0
  br i1 %runtime.ok.65, label %runtime.continue.66, label %frame.failure.0
runtime.continue.66:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.51, i32 %stack.offset.52, i32 %stack.offset.53, i32 %context.value.17, i32 8)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %stack.sub.79 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.77 = icmp ule i32 %stack.offset.54, %context.value.76
  %descriptor.offset.inside.78 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.80 = icmp ule i32 %stack.offset.52, %stack.sub.79
  %descriptor.payload.inside.81 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.82 = and i1 %descriptor.owner.inside.77, %descriptor.offset.inside.78
  %descriptor.range.inside.84 = and i1 %descriptor.owner.offset.valid.82, %descriptor.extent.inside.80
  %descriptor.range.valid.83 = and i1 %descriptor.range.inside.84, %descriptor.payload.inside.81
  %descriptor.type.valid.85 = icmp eq i32 8, 8
  %descriptor.valid.86 = and i1 %descriptor.range.valid.83, %descriptor.type.valid.85
  br i1 %descriptor.valid.86, label %descriptor.valid.87, label %descriptor.invalid.88
descriptor.invalid.88:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.87:
  %descriptor.initialized.status.89 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.90 = icmp eq i32 %descriptor.initialized.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %step.status.92 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.93 = icmp eq i32 %step.status.92, 0
  br i1 %helper.ok.93, label %helper.continue.94, label %frame.failure.0
helper.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.offset.97 = add i32 %context.value.96, 8
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 6)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %frame.failure.0
reserve.continue.100:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.96, i64 43, i32 1)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %frame.failure.0
runtime.continue.104:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %runtime.ok.107 = icmp eq i32 %context.value.106, 0
  br i1 %runtime.ok.107, label %runtime.continue.108, label %frame.failure.0
runtime.continue.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.111 = icmp ule i32 %stack.offset.54, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.114 = icmp ule i32 %stack.offset.52, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 8, 8
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %frame.failure.0
helper.continue.125:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.sub.130 = sub i32 %stack.offset.97, %context.value.96
  %descriptor.owner.inside.128 = icmp ule i32 %stack.offset.97, %context.value.127
  %descriptor.offset.inside.129 = icmp ule i32 %context.value.96, %stack.offset.97
  %descriptor.extent.inside.131 = icmp ule i32 8, %stack.sub.130
  %descriptor.payload.inside.132 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.133 = and i1 %descriptor.owner.inside.128, %descriptor.offset.inside.129
  %descriptor.range.inside.135 = and i1 %descriptor.owner.offset.valid.133, %descriptor.extent.inside.131
  %descriptor.range.valid.134 = and i1 %descriptor.range.inside.135, %descriptor.payload.inside.132
  %descriptor.type.valid.136 = icmp eq i32 1, 1
  %descriptor.valid.137 = and i1 %descriptor.range.valid.134, %descriptor.type.valid.136
  br i1 %descriptor.valid.137, label %descriptor.valid.138, label %descriptor.invalid.139
descriptor.invalid.139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.138:
  %descriptor.initialized.status.140 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.96, i32 8)
  %helper.ok.141 = icmp eq i32 %descriptor.initialized.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %step.status.143 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.144 = icmp eq i32 %step.status.143, 0
  br i1 %helper.ok.144, label %helper.continue.145, label %frame.failure.0
helper.continue.145:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.offset.148 = add i32 8, 8
  %stack.offset.149 = add i32 8, 8
  %stack.offset.150 = add i32 %context.value.147, %stack.offset.148
  %reserve.status.151 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.150, i32 8)
  %reserve.ok.152 = icmp eq i32 %reserve.status.151, 0
  br i1 %reserve.ok.152, label %reserve.continue.153, label %frame.failure.0
reserve.continue.153:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.147, i64 0, i32 8)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %stack.offset.158 = add i32 %context.value.147, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.158, i32 %context.value.96, i32 8, i32 8, i32 1, i32 6)
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %runtime.ok.161 = icmp eq i32 %context.value.160, 0
  br i1 %runtime.ok.161, label %runtime.continue.162, label %frame.failure.0
runtime.continue.162:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %runtime.ok.165 = icmp eq i32 %context.value.164, 0
  br i1 %runtime.ok.165, label %runtime.continue.166, label %frame.failure.0
runtime.continue.166:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.147, i32 %stack.offset.148, i32 %stack.offset.149, i32 %context.value.96, i32 8)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %stack.sub.175 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.173 = icmp ule i32 %stack.offset.54, %context.value.172
  %descriptor.offset.inside.174 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.176 = icmp ule i32 %stack.offset.52, %stack.sub.175
  %descriptor.payload.inside.177 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.178 = and i1 %descriptor.owner.inside.173, %descriptor.offset.inside.174
  %descriptor.range.inside.180 = and i1 %descriptor.owner.offset.valid.178, %descriptor.extent.inside.176
  %descriptor.range.valid.179 = and i1 %descriptor.range.inside.180, %descriptor.payload.inside.177
  %descriptor.type.valid.181 = icmp eq i32 8, 8
  %descriptor.valid.182 = and i1 %descriptor.range.valid.179, %descriptor.type.valid.181
  br i1 %descriptor.valid.182, label %descriptor.valid.183, label %descriptor.invalid.184
descriptor.invalid.184:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.183:
  %descriptor.initialized.status.185 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.186 = icmp eq i32 %descriptor.initialized.status.185, 0
  br i1 %helper.ok.186, label %helper.continue.187, label %frame.failure.0
helper.continue.187:
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %stack.sub.192 = sub i32 %stack.offset.150, %context.value.147
  %descriptor.owner.inside.190 = icmp ule i32 %stack.offset.150, %context.value.189
  %descriptor.offset.inside.191 = icmp ule i32 %context.value.147, %stack.offset.150
  %descriptor.extent.inside.193 = icmp ule i32 %stack.offset.148, %stack.sub.192
  %descriptor.payload.inside.194 = icmp ule i32 %stack.offset.149, %stack.offset.148
  %descriptor.owner.offset.valid.195 = and i1 %descriptor.owner.inside.190, %descriptor.offset.inside.191
  %descriptor.range.inside.197 = and i1 %descriptor.owner.offset.valid.195, %descriptor.extent.inside.193
  %descriptor.range.valid.196 = and i1 %descriptor.range.inside.197, %descriptor.payload.inside.194
  %descriptor.type.valid.198 = icmp eq i32 8, 8
  %descriptor.valid.199 = and i1 %descriptor.range.valid.196, %descriptor.type.valid.198
  br i1 %descriptor.valid.199, label %descriptor.valid.200, label %descriptor.invalid.201
descriptor.invalid.201:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.200:
  %descriptor.initialized.status.202 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.147, i32 %stack.offset.148)
  %helper.ok.203 = icmp eq i32 %descriptor.initialized.status.202, 0
  br i1 %helper.ok.203, label %helper.continue.204, label %frame.failure.0
helper.continue.204:
  %step.status.205 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.206 = icmp eq i32 %step.status.205, 0
  br i1 %helper.ok.206, label %helper.continue.207, label %frame.failure.0
helper.continue.207:
  %equals.same.extent.208 = icmp eq i32 %stack.offset.52, %stack.offset.148
  br i1 %equals.same.extent.208, label %equals.compare.209, label %equals.different.210
equals.compare.209:
  %equals.result.212 = call i32 @al_owning_equal(ptr %ctx, i32 %context.value.51, i32 %context.value.147, i32 %stack.offset.52)
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %runtime.ok.215 = icmp eq i32 %context.value.214, 0
  br i1 %runtime.ok.215, label %runtime.continue.216, label %frame.failure.0
runtime.continue.216:
  br label %equals.join.211
equals.different.210:
  br label %equals.join.211
equals.join.211:
  %equals.value.217 = phi i32 [ %equals.result.212, %runtime.continue.216 ], [ 0, %equals.different.210 ]
  %equals.bool.218 = icmp ne i32 %equals.value.217, 0
  %equals.i64.219 = zext i1 %equals.bool.218 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.147, i32 %stack.offset.148, i32 %stack.offset.149, i32 0, i32 0)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.51, i32 %stack.offset.52, i32 %stack.offset.53, i32 0, i32 0)
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %runtime.ok.226 = icmp eq i32 %context.value.225, 0
  br i1 %runtime.ok.226, label %runtime.continue.227, label %frame.failure.0
runtime.continue.227:
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.offset.230 = add i32 %context.value.229, 8
  %reserve.status.231 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.230, i32 10)
  %reserve.ok.232 = icmp eq i32 %reserve.status.231, 0
  br i1 %reserve.ok.232, label %reserve.continue.233, label %frame.failure.0
reserve.continue.233:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.229, i64 %equals.i64.219, i32 2)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.239 = load i32, ptr %context.field.238, align 4
  %runtime.ok.240 = icmp eq i32 %context.value.239, 0
  br i1 %runtime.ok.240, label %runtime.continue.241, label %frame.failure.0
runtime.continue.241:
  %stack.offset.242 = add i32 %context.value.229, 8
  %context.field.243 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.244 = load i32, ptr %context.field.243, align 4
  %stack.sub.247 = sub i32 %stack.offset.242, %context.value.229
  %descriptor.owner.inside.245 = icmp ule i32 %stack.offset.242, %context.value.244
  %descriptor.offset.inside.246 = icmp ule i32 %context.value.229, %stack.offset.242
  %descriptor.extent.inside.248 = icmp ule i32 8, %stack.sub.247
  %descriptor.payload.inside.249 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.250 = and i1 %descriptor.owner.inside.245, %descriptor.offset.inside.246
  %descriptor.range.inside.252 = and i1 %descriptor.owner.offset.valid.250, %descriptor.extent.inside.248
  %descriptor.range.valid.251 = and i1 %descriptor.range.inside.252, %descriptor.payload.inside.249
  %descriptor.type.valid.253 = icmp eq i32 2, 2
  %descriptor.valid.254 = and i1 %descriptor.range.valid.251, %descriptor.type.valid.253
  br i1 %descriptor.valid.254, label %descriptor.valid.255, label %descriptor.invalid.256
descriptor.invalid.256:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.255:
  %descriptor.initialized.status.257 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.229, i32 8)
  %helper.ok.258 = icmp eq i32 %descriptor.initialized.status.257, 0
  br i1 %helper.ok.258, label %helper.continue.259, label %frame.failure.0
helper.continue.259:
  %descriptor.element.260 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.261 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.260, i32 0, i32 0
  store i32 2, ptr %descriptor.field.261, align 4
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.260, i32 0, i32 1
  store i32 %context.value.229, ptr %descriptor.field.262, align 4
  %descriptor.field.263 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.260, i32 0, i32 2
  store i32 8, ptr %descriptor.field.263, align 4
  %descriptor.field.264 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.260, i32 0, i32 3
  store i32 8, ptr %descriptor.field.264, align 4
  %descriptor.field.265 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.260, i32 0, i32 4
  store i32 %stack.offset.242, ptr %descriptor.field.265, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.229, i32 20, i32 8, i32 %stack.offset.242, i32 8)
  %context.field.266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.267 = load i32, ptr %context.field.266, align 4
  %runtime.ok.268 = icmp eq i32 %context.value.267, 0
  br i1 %runtime.ok.268, label %runtime.continue.269, label %frame.failure.0
runtime.continue.269:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.271 = load i32, ptr %context.field.270, align 4
  %context.field.272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.273 = load i32, ptr %context.field.272, align 4
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %stack.offset.276 = add i32 %context.value.5, %context.value.7
  %stack.offset.277 = add i32 %context.value.271, %context.value.273
  %stack.sub.278 = sub i32 %stack.offset.276, %stack.offset.277
  %stack.sub.279 = sub i32 %context.value.7, %context.value.273
  %stack.sub.280 = sub i32 %context.value.275, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.278, i32 %stack.sub.279)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.280)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 11)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 12)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 2
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 2, 2
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 2)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


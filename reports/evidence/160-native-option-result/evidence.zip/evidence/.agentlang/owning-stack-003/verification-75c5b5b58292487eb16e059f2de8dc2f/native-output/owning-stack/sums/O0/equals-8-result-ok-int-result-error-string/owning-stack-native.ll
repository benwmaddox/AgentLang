%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 8, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 2 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\02\00\00\00\00\00\00\00\6E\00\6F\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.17, i64 7, i32 1)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %stack.sub.34 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.32 = icmp ule i32 %stack.offset.18, %context.value.31
  %descriptor.offset.inside.33 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.35 = icmp ule i32 8, %stack.sub.34
  %descriptor.payload.inside.36 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.37 = and i1 %descriptor.owner.inside.32, %descriptor.offset.inside.33
  %descriptor.range.inside.39 = and i1 %descriptor.owner.offset.valid.37, %descriptor.extent.inside.35
  %descriptor.range.valid.38 = and i1 %descriptor.range.inside.39, %descriptor.payload.inside.36
  %descriptor.type.valid.40 = icmp eq i32 1, 1
  %descriptor.valid.41 = and i1 %descriptor.range.valid.38, %descriptor.type.valid.40
  br i1 %descriptor.valid.41, label %descriptor.valid.42, label %descriptor.invalid.43
descriptor.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.42:
  %descriptor.initialized.status.44 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.45 = icmp eq i32 %descriptor.initialized.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %frame.failure.0
helper.continue.46:
  %step.status.47 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.48 = icmp eq i32 %step.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %stack.offset.52 = add i32 8, 8
  %stack.offset.53 = add i32 8, 8
  %stack.offset.54 = add i32 %context.value.51, %stack.offset.52
  %reserve.status.55 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.54, i32 4)
  %reserve.ok.56 = icmp eq i32 %reserve.status.55, 0
  br i1 %reserve.ok.56, label %reserve.continue.57, label %frame.failure.0
reserve.continue.57:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.51, i64 0, i32 8)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %stack.offset.62 = add i32 %context.value.51, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.62, i32 %context.value.17, i32 8, i32 8, i32 1, i32 6)
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %runtime.ok.65 = icmp eq i32 %context.value.64, 0
  br i1 %runtime.ok.65, label %runtime.continue.66, label %frame.failure.0
runtime.continue.66:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.51, i32 %stack.offset.52, i32 %stack.offset.53, i32 %context.value.17, i32 8)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %stack.sub.79 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.77 = icmp ule i32 %stack.offset.54, %context.value.76
  %descriptor.offset.inside.78 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.80 = icmp ule i32 %stack.offset.52, %stack.sub.79
  %descriptor.payload.inside.81 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.82 = and i1 %descriptor.owner.inside.77, %descriptor.offset.inside.78
  %descriptor.range.inside.84 = and i1 %descriptor.owner.offset.valid.82, %descriptor.extent.inside.80
  %descriptor.range.valid.83 = and i1 %descriptor.range.inside.84, %descriptor.payload.inside.81
  %descriptor.type.valid.85 = icmp eq i32 8, 8
  %descriptor.valid.86 = and i1 %descriptor.range.valid.83, %descriptor.type.valid.85
  br i1 %descriptor.valid.86, label %descriptor.valid.87, label %descriptor.invalid.88
descriptor.invalid.88:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.87:
  %descriptor.initialized.status.89 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.90 = icmp eq i32 %descriptor.initialized.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %step.status.92 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.93 = icmp eq i32 %step.status.92, 0
  br i1 %helper.ok.93, label %helper.continue.94, label %frame.failure.0
helper.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.offset.97 = add i32 %context.value.96, 16
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 6)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %frame.failure.0
reserve.continue.100:
  %literal.status.101 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.96, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 12, i32 16, i32 7, i32 7)
  %helper.ok.102 = icmp eq i32 %literal.status.101, 0
  br i1 %helper.ok.102, label %helper.continue.103, label %frame.failure.0
helper.continue.103:
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %stack.sub.108 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.106 = icmp ule i32 %stack.offset.54, %context.value.105
  %descriptor.offset.inside.107 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.109 = icmp ule i32 %stack.offset.52, %stack.sub.108
  %descriptor.payload.inside.110 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.111 = and i1 %descriptor.owner.inside.106, %descriptor.offset.inside.107
  %descriptor.range.inside.113 = and i1 %descriptor.owner.offset.valid.111, %descriptor.extent.inside.109
  %descriptor.range.valid.112 = and i1 %descriptor.range.inside.113, %descriptor.payload.inside.110
  %descriptor.type.valid.114 = icmp eq i32 8, 8
  %descriptor.valid.115 = and i1 %descriptor.range.valid.112, %descriptor.type.valid.114
  br i1 %descriptor.valid.115, label %descriptor.valid.116, label %descriptor.invalid.117
descriptor.invalid.117:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.116:
  %descriptor.initialized.status.118 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.119 = icmp eq i32 %descriptor.initialized.status.118, 0
  br i1 %helper.ok.119, label %helper.continue.120, label %frame.failure.0
helper.continue.120:
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.sub.125 = sub i32 %stack.offset.97, %context.value.96
  %descriptor.owner.inside.123 = icmp ule i32 %stack.offset.97, %context.value.122
  %descriptor.offset.inside.124 = icmp ule i32 %context.value.96, %stack.offset.97
  %descriptor.extent.inside.126 = icmp ule i32 16, %stack.sub.125
  %descriptor.payload.inside.127 = icmp ule i32 12, 16
  %descriptor.owner.offset.valid.128 = and i1 %descriptor.owner.inside.123, %descriptor.offset.inside.124
  %descriptor.range.inside.130 = and i1 %descriptor.owner.offset.valid.128, %descriptor.extent.inside.126
  %descriptor.range.valid.129 = and i1 %descriptor.range.inside.130, %descriptor.payload.inside.127
  %descriptor.type.valid.131 = icmp eq i32 7, 7
  %descriptor.valid.132 = and i1 %descriptor.range.valid.129, %descriptor.type.valid.131
  br i1 %descriptor.valid.132, label %descriptor.valid.133, label %descriptor.invalid.134
descriptor.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.133:
  %descriptor.initialized.status.135 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.96, i32 16)
  %helper.ok.136 = icmp eq i32 %descriptor.initialized.status.135, 0
  br i1 %helper.ok.136, label %helper.continue.137, label %frame.failure.0
helper.continue.137:
  %step.status.138 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.139 = icmp eq i32 %step.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.offset.143 = add i32 8, 16
  %stack.offset.144 = add i32 8, 12
  %stack.offset.145 = add i32 %context.value.142, %stack.offset.143
  %reserve.status.146 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.145, i32 9)
  %reserve.ok.147 = icmp eq i32 %reserve.status.146, 0
  br i1 %reserve.ok.147, label %reserve.continue.148, label %frame.failure.0
reserve.continue.148:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.142, i64 1, i32 8)
  %context.field.149 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.150 = load i32, ptr %context.field.149, align 4
  %runtime.ok.151 = icmp eq i32 %context.value.150, 0
  br i1 %runtime.ok.151, label %runtime.continue.152, label %frame.failure.0
runtime.continue.152:
  %stack.offset.153 = add i32 %context.value.142, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.153, i32 %context.value.96, i32 16, i32 12, i32 7, i32 6)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 8, i32 %context.value.142, i32 %stack.offset.143, i32 %stack.offset.144, i32 %context.value.96, i32 16)
  %context.field.162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.163 = load i32, ptr %context.field.162, align 4
  %runtime.ok.164 = icmp eq i32 %context.value.163, 0
  br i1 %runtime.ok.164, label %runtime.continue.165, label %frame.failure.0
runtime.continue.165:
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.sub.170 = sub i32 %stack.offset.54, %context.value.51
  %descriptor.owner.inside.168 = icmp ule i32 %stack.offset.54, %context.value.167
  %descriptor.offset.inside.169 = icmp ule i32 %context.value.51, %stack.offset.54
  %descriptor.extent.inside.171 = icmp ule i32 %stack.offset.52, %stack.sub.170
  %descriptor.payload.inside.172 = icmp ule i32 %stack.offset.53, %stack.offset.52
  %descriptor.owner.offset.valid.173 = and i1 %descriptor.owner.inside.168, %descriptor.offset.inside.169
  %descriptor.range.inside.175 = and i1 %descriptor.owner.offset.valid.173, %descriptor.extent.inside.171
  %descriptor.range.valid.174 = and i1 %descriptor.range.inside.175, %descriptor.payload.inside.172
  %descriptor.type.valid.176 = icmp eq i32 8, 8
  %descriptor.valid.177 = and i1 %descriptor.range.valid.174, %descriptor.type.valid.176
  br i1 %descriptor.valid.177, label %descriptor.valid.178, label %descriptor.invalid.179
descriptor.invalid.179:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.178:
  %descriptor.initialized.status.180 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.51, i32 %stack.offset.52)
  %helper.ok.181 = icmp eq i32 %descriptor.initialized.status.180, 0
  br i1 %helper.ok.181, label %helper.continue.182, label %frame.failure.0
helper.continue.182:
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %stack.sub.187 = sub i32 %stack.offset.145, %context.value.142
  %descriptor.owner.inside.185 = icmp ule i32 %stack.offset.145, %context.value.184
  %descriptor.offset.inside.186 = icmp ule i32 %context.value.142, %stack.offset.145
  %descriptor.extent.inside.188 = icmp ule i32 %stack.offset.143, %stack.sub.187
  %descriptor.payload.inside.189 = icmp ule i32 %stack.offset.144, %stack.offset.143
  %descriptor.owner.offset.valid.190 = and i1 %descriptor.owner.inside.185, %descriptor.offset.inside.186
  %descriptor.range.inside.192 = and i1 %descriptor.owner.offset.valid.190, %descriptor.extent.inside.188
  %descriptor.range.valid.191 = and i1 %descriptor.range.inside.192, %descriptor.payload.inside.189
  %descriptor.type.valid.193 = icmp eq i32 8, 8
  %descriptor.valid.194 = and i1 %descriptor.range.valid.191, %descriptor.type.valid.193
  br i1 %descriptor.valid.194, label %descriptor.valid.195, label %descriptor.invalid.196
descriptor.invalid.196:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.195:
  %descriptor.initialized.status.197 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.142, i32 %stack.offset.143)
  %helper.ok.198 = icmp eq i32 %descriptor.initialized.status.197, 0
  br i1 %helper.ok.198, label %helper.continue.199, label %frame.failure.0
helper.continue.199:
  %step.status.200 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.201 = icmp eq i32 %step.status.200, 0
  br i1 %helper.ok.201, label %helper.continue.202, label %frame.failure.0
helper.continue.202:
  %equals.same.extent.203 = icmp eq i32 %stack.offset.52, %stack.offset.143
  br i1 %equals.same.extent.203, label %equals.compare.204, label %equals.different.205
equals.compare.204:
  %equals.result.207 = call i32 @al_owning_equal(ptr %ctx, i32 %context.value.51, i32 %context.value.142, i32 %stack.offset.52)
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %runtime.ok.210 = icmp eq i32 %context.value.209, 0
  br i1 %runtime.ok.210, label %runtime.continue.211, label %frame.failure.0
runtime.continue.211:
  br label %equals.join.206
equals.different.205:
  br label %equals.join.206
equals.join.206:
  %equals.value.212 = phi i32 [ %equals.result.207, %runtime.continue.211 ], [ 0, %equals.different.205 ]
  %equals.bool.213 = icmp ne i32 %equals.value.212, 0
  %equals.i64.214 = zext i1 %equals.bool.213 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.142, i32 %stack.offset.143, i32 %stack.offset.144, i32 0, i32 0)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.51, i32 %stack.offset.52, i32 %stack.offset.53, i32 0, i32 0)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %stack.offset.225 = add i32 %context.value.224, 8
  %reserve.status.226 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.225, i32 11)
  %reserve.ok.227 = icmp eq i32 %reserve.status.226, 0
  br i1 %reserve.ok.227, label %reserve.continue.228, label %frame.failure.0
reserve.continue.228:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.224, i64 %equals.i64.214, i32 2)
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %runtime.ok.231 = icmp eq i32 %context.value.230, 0
  br i1 %runtime.ok.231, label %runtime.continue.232, label %frame.failure.0
runtime.continue.232:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %runtime.ok.235 = icmp eq i32 %context.value.234, 0
  br i1 %runtime.ok.235, label %runtime.continue.236, label %frame.failure.0
runtime.continue.236:
  %stack.offset.237 = add i32 %context.value.224, 8
  %context.field.238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.239 = load i32, ptr %context.field.238, align 4
  %stack.sub.242 = sub i32 %stack.offset.237, %context.value.224
  %descriptor.owner.inside.240 = icmp ule i32 %stack.offset.237, %context.value.239
  %descriptor.offset.inside.241 = icmp ule i32 %context.value.224, %stack.offset.237
  %descriptor.extent.inside.243 = icmp ule i32 8, %stack.sub.242
  %descriptor.payload.inside.244 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.245 = and i1 %descriptor.owner.inside.240, %descriptor.offset.inside.241
  %descriptor.range.inside.247 = and i1 %descriptor.owner.offset.valid.245, %descriptor.extent.inside.243
  %descriptor.range.valid.246 = and i1 %descriptor.range.inside.247, %descriptor.payload.inside.244
  %descriptor.type.valid.248 = icmp eq i32 2, 2
  %descriptor.valid.249 = and i1 %descriptor.range.valid.246, %descriptor.type.valid.248
  br i1 %descriptor.valid.249, label %descriptor.valid.250, label %descriptor.invalid.251
descriptor.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.250:
  %descriptor.initialized.status.252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.224, i32 8)
  %helper.ok.253 = icmp eq i32 %descriptor.initialized.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  %descriptor.element.255 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.255, i32 0, i32 0
  store i32 2, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.255, i32 0, i32 1
  store i32 %context.value.224, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.255, i32 0, i32 2
  store i32 8, ptr %descriptor.field.258, align 4
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.255, i32 0, i32 3
  store i32 8, ptr %descriptor.field.259, align 4
  %descriptor.field.260 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.255, i32 0, i32 4
  store i32 %stack.offset.237, ptr %descriptor.field.260, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.224, i32 20, i32 8, i32 %stack.offset.237, i32 8)
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %runtime.ok.263 = icmp eq i32 %context.value.262, 0
  br i1 %runtime.ok.263, label %runtime.continue.264, label %frame.failure.0
runtime.continue.264:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.265 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.266 = load i32, ptr %context.field.265, align 4
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %context.field.269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.270 = load i32, ptr %context.field.269, align 4
  %stack.offset.271 = add i32 %context.value.5, %context.value.7
  %stack.offset.272 = add i32 %context.value.266, %context.value.268
  %stack.sub.273 = sub i32 %stack.offset.271, %stack.offset.272
  %stack.sub.274 = sub i32 %context.value.7, %context.value.268
  %stack.sub.275 = sub i32 %context.value.270, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.273, i32 %stack.sub.274)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.275)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 12)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 13)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 2
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 2, 2
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 2)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


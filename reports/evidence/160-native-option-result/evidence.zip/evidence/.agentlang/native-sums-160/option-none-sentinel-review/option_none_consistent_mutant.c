#include "owning_stack_runtime.h"
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

static const al_owning_type_descriptor types[] = {
    {AL_OWNING_TYPE_I64, 1u, 0u, 0u, 8u, 8u, 8u, 8u, 0u},
    {AL_OWNING_TYPE_OPTION, 2u, 0u, 2u, 16u, 16u, 16u, 16u, 2u}};
static const al_owning_field_descriptor fields[] = {
    {0u, 8u, 0u, 0u}, {0u, 8u, 0u, 0u}};
static const al_owning_layout layout = {
    AL_OWNING_LAYOUT_ABI_VERSION, types, 2u, fields, 2u};

int main(void) {
  uint8_t stack[64] = {0u};
  uint8_t initialized[8] = {0u};
  uint8_t poisoned[8] = {0u};
  al_owning_stack_context context;
  uint8_t none_with_payload[16] = {0u};
  uint32_t payload = UINT32_C(0xAABBCCDD);
  uint32_t extent = UINT32_C(0x11223344);
  uint32_t case_index = UINT32_C(0x55667788);
  al_owning_field_location location = {
      UINT32_C(0xAABBCCDD), UINT32_C(0x11223344), UINT32_C(0x55667788)};
  int32_t measured;
  int32_t located;
  memset(&context, 0, sizeof(context));
  context.abi_version = AL_OWNING_STACK_ABI_VERSION;
  context.stack_capacity_bytes = sizeof(stack);
  context.stack_data = stack;
  context.init_bitmap = initialized;
  context.poison_bitmap = poisoned;
  context.init_bitmap_bytes = sizeof(initialized);
  al_owning_begin(&context);
  none_with_payload[0] = 1u;
  none_with_payload[8] = 0x28u;
  none_with_payload[9] = 0x27u;
  none_with_payload[10] = 0x26u;
  none_with_payload[11] = 0x25u;
  none_with_payload[12] = 0x24u;
  none_with_payload[13] = 0x23u;
  none_with_payload[14] = 0x22u;
  none_with_payload[15] = 0x21u;
  measured = al_owning_measure_external_value(
      &context, &layout, 1u, none_with_payload, sizeof(none_with_payload),
      0u, 77u, &payload, &extent);
  memset(&context, 0, sizeof(context));
  context.abi_version = AL_OWNING_STACK_ABI_VERSION;
  context.stack_capacity_bytes = sizeof(stack);
  context.stack_data = stack;
  context.init_bitmap = initialized;
  context.poison_bitmap = poisoned;
  context.init_bitmap_bytes = sizeof(initialized);
  al_owning_begin(&context);
  if (al_owning_reserve_to(&context, sizeof(none_with_payload), 77u) != 0)
    return 2;
  al_owning_copy_external(&context, 0u, none_with_payload,
                         sizeof(none_with_payload), sizeof(none_with_payload),
                         2u);
  located = al_owning_locate_sum_case(
      &context, &layout, 1u, 0u, sizeof(none_with_payload), 77u,
      &case_index, &location);
  printf("measure=%d payload=%" PRIu32 " extent=%" PRIu32
         " locate=%d case=%" PRIu32 " offset=%" PRIu32
         " child_payload=%" PRIu32 " child_extent=%" PRIu32 "\n",
         measured, payload, extent, located, case_index, location.offset_bytes,
         location.payload_bytes, location.extent_bytes);
  return 0;
}




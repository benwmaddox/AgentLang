# Independent review record

The read-only reviewer inspected the native sentinel repair, coherent mutants,
output preservation, descriptor ABI, and mailbox validation changes. The initial
review found a real defect: Option.None could carry a child when size metadata
was consistent. Before/after compiled reproducers demonstrate acceptance by the
frozen snapshot and rejection by repaired code. The reviewer confirmed that the
new tests target the sentinel rule rather than incidental size inconsistency.

The reviewer also found an avoidable per-operation owner scan across all fields
and types. It now runs only for sentinel child rows. A subsequent read-only
review found ordinary field acceptance unchanged and no actionable defect in
that optimization.

The subsequent review covered the new sum layout, construction, matching,
local storage, user calls and lifetime paths. Construction copies a selected
child once; matching first validates the case through the native helper, then
forms a payload view. Locals and calls transfer descriptors. Branch exits remove
case locals and restore outer state. Lifetime analysis conservatively carries
backing-owner provenance. No actionable finding remained in those paths.

These reviews ran no builds or tests. They did not audit the full emitter or all
host serialization/equality paths. Later changes resolved display names and
corrected harness metadata/copy accounting; they did not alter the reviewed sum
execution semantics. Parent-owned fresh gates provide executable evidence.

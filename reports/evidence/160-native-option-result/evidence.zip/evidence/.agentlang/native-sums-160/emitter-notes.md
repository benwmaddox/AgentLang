# OwningStackAot Option/Result implementation notes

The selected stable-arena dynamic emitter now builds closed Option/Result layouts with ABI 3 and unchanged descriptor sizes. Sum case rows use Some/None or Ok/Error tags 0/1, payload offset 8, and Option.None's no-child sentinel in emitted metadata. Host values are measured, encoded, and decoded with tag and payload validation; dynamic constructors inline-copy one active child, and match binders alias the checked active payload descriptor. Traversals include both match branches, and emitted manifests expose `cases` rows with camel-case JSON names corresponding to `OwningStackCaseLayout`'s `CaseName`, `Tag`, `PayloadType`, `OffsetBytes`, `PayloadBytes`, `ExtentBytes`, `IsDynamic`, `MinimumPayloadBytes`, and `MinimumExtentBytes` properties.

The native locate helper declaration follows the C owner's contract. Specialized mailbox role roots remain restricted to the existing String/Record roles; this emitter change does not broaden them. The legacy fixed emitter and shared-graph `LlvmAot` backend were not extended.

Static checks run: `git diff --check -- src/AgentLang.Llvm/OwningStackAot.fs`. No .NET build or test was run because the root task is serializing shared LLVM builds.

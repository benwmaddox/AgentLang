# Native Option/Result lifetime work

`ArenaLifetime.fs` now models `OptionNone` as a fresh inline owner and `OptionSome`/`ResultOk`/`ResultError` as a fresh sum owner plus the payload origins. `MatchOption` and `MatchResult` pass the sum origins to case binders, remove those binders after each arm, and merge verified arm exits. Rewind decisions remain compile-time only; unknown and effectful calls retain the existing conservative behavior.

`ArenaLifetimeTests.fs` adds dead-sum rewind, escaping None/whole-sum/payload, one-arm escape, dead Option/Result matches, local and nested sums, and unavailable user-call provenance coverage. Duplicate-site false-wins and determinism cases remain in place.

Validation was not run because the root task requested that no .NET builds run while the other implementation is in progress. No emitter lifecycle helper was needed.

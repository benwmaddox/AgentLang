# Native Option/Result

Status: implementation in progress. This is an interim engineering report,
not a completed native conformance result or a new agent-efficacy trial.

The approved representation extends the stable-arena owning backend with inline
Option/Result tags and payloads, keeping the interpreter's typed semantic IR
authoritative. Layout ABI advances to 3 while physical descriptors retain their
existing sizes. Stack ABI remains 1. The older graph-backed backend remains
separate. See [the implementation boundary](../docs/NATIVE-SUMS-IMPLEMENTATION.md).

Compiler analysis now models constructed sum owners and case-local views instead
of treating every sum operation as unknown. It merges arm exits conservatively:
dead sum scopes can rewind; escaping sums/payloads and uncertain calls retain
storage. No runtime liveness scan, reference counting or compaction is added.

## Verified so far

An isolated executable links the actual `ArenaLifetime.fs` and its actual test
module against a freshly built Core project. This avoids compiling the LLVM
emitter while another worker is editing it. The Release build passes with zero
warnings/errors; all 44 lifetime assertions pass, including new Option/Result
cases. Logs and the runner project are under `.agentlang/native-sums-160/`.

This proves the focused analysis tests, not native execution, generated-code
safety across all programs, or the full runtime contract. Native scanner work,
LLVM emission, host codecs and independent O0/O2 conformance are still being
integrated. Full storage, capacity, malformed-input, mailbox and local Release
gates must pass before this milestone is committed and pushed.

An independently copied scanner/storage-test snapshot also passes fresh O2 and
trap-mode UBSan builds: 50 cases, 606 checks, layout ABI 3. The two runs report
identical deterministic metrics, including unchanged physical layout/type/field
sizes of 40/36/16 bytes. This includes native sum scanner and malformed-layout
cases, but not generated LLVM sum execution. Source hashes and logs are saved
under `.agentlang/native-sums-160/root-storage-snapshot/`. The first compile used
the sandbox's default temporary directory and failed to rename object files;
the same compilation passed after selecting workspace-local TEMP/TMP.

The LLVM project now builds with zero warnings/errors. Its first integrated
build exposed two F# errors: a diagnostic helper lacked the instruction span,
and manifest case projection still expected tuples after cases became records.
Both were corrected before the accepted second build. This verifies compilation,
not generated-code parity.

Independent review found a missing mandatory-None-sentinel check in the initial
scanner snapshot and live code. A descriptor with consistently adjusted sizes
could give Option.None a real payload, violating the eight-byte None contract.
The earlier malformed-row test rejected stale size metadata instead of proving
that the sentinel was mandatory. Both validators now enforce it. An independently
compiled coherent mutant is accepted by the immutable snapshot as a 16-byte None
and rejected by current code; failed measurement and lookup preserve all output
sentinels. Fresh O0, O2 and trap-mode UBSan storage runs agree: 50 cases / 612
checks, including 34 dynamic cases / 423 checks. Bank tests pass 56 checks at
O0/O2; mailbox tests pass at both levels. Final stack/bank logs use suffix -003,
mailbox logs use -004, and the reproducer logs are in
`.agentlang/native-sums-160/option-none-sentinel-review/`.

The full LLVM test executable builds in Release with zero warnings/errors.
Its integrated `--arena-lifetime` mode passes all 44 assertions, confirming the
earlier isolated analysis result in the actual LLVM project. The full executable
passes 476 assertions, including the existing graph-backed ABI, records, retained
re-entry and module checks. This is regression evidence for that scope; it does
not replace the new owning Option/Result conformance gate, which remains pending.
Logs: `llvm-tests-build-001.log`, `llvm-tests-run-001.log`, and
`llvm-lifetime-integrated-001.log` under `.agentlang/native-sums-160/`.

The first owning-value-stack integration gate failed while freshly building its
expanded test runner: FS3373 rejected a nested string literal in an interpolated
diagnostic at Program.fs line 983. Native generated sum cases did not execute.
Failure evidence is retained in
`.agentlang/owning-stack-003/verification-95d1e0c631574f71849dd61778645537/`;
The interpolation was corrected. The second focused build then exposed two
call sites passing a SourceSpan where the fixture encoder required a span
callback (FS0001, lines 1145–1146). Both failed attempts are retained. The third focused runner
build now passes with zero warnings/errors after correcting both callbacks.
A fresh integration gate is running against the stable corrected sources.

That second gate reached experiment execution but rejected a nested Result match
test before sum native cases ran: its Option arm omitted loading the bound
payload onto the operand stack (`TYPE_MATCH_REQUIRES_RESULT`). The fixture body
has been corrected without removing the nested extraction case. The failed
evidence remains in `verification-0f4c8b465f664e8192e2941ba379a903`.

The owning-mailbox integration gate passes all 592 recorded checks with fresh
isolated build artifacts (no failed check rows):
`.agentlang/owning-mailbox-001/integration-run-b147ea62f4cd4c8d8876674c20819f79/integration-evidence.json`.
This establishes the gate's existing mailbox contract under layout ABI 3,
including O0/O2 diagnostic and trusted-generated runtime profiles;
the new sum interpreter/native parity gate is still pending.

The corrected third native-value-stack gate is running against stable source
handoffs. Full local Release validation is also running with serial build and
package auditing disabled; its evidence path is
`.agentlang/native-sums-160/full-validation-001.json`. Neither running process
is counted as a pass. No milestone commit or push has been made.

The third sum gate failed while rendering evidence for the isolated-surrogate
case: `ValueInspection.toJson` cannot transcode that UTF-16 value into UTF-8
JSON. The fixture's direct Value and literal-byte comparisons remain intact;
the harness now uses its existing recursive code-unit-safe value formatter for
all sum evidence instead of removing the case. Failed evidence is retained in
`verification-900122a625c241a1b07962802c5f43df`.

Final native review found no further semantic or memory-safety defect within
its reviewed diff, but identified an avoidable mailbox validation cost: every
field scanned all type descriptors. The owner scan now runs only for sentinel
fields; ordinary fields retain bounds/flags/reserved validation. Fresh mailbox
C tests pass at O0/O2 (`owning_mailbox_test_*‑005.log`). The earlier 592-check
integration pass predates this optimization and will be rerun.

The fresh second mailbox integration gate now passes all 592 checks with zero
failed check rows after the optimization. Accepted evidence:
`.agentlang/owning-mailbox-001/integration-run-89b34080693044e88b37006eed016863/integration-evidence.json`.

The fourth sum gate completes both O0/O2 suites but reports four failed checks
(two categories at each optimization): 4 of 1,236 experiment check rows fail,
all within the 294 sum check rows. These counts do not establish acceptance.
The layout report omits three oracle
types: Option<SumSignal>, Option<Empty>, and Result<Empty, Empty>. A Result-match
fallback arm returns the correct newly materialized string and exact bytes, but
its test applies a zero-deep-copy predicate intended for extracted payloads;
the trace reports 24 deep-copy bytes and zero move bytes. Layout collection and
copy accounting are under investigation; zero-copy extraction requirements and
all oracle cases remain required. Evidence:
`verification-11963132e28746f49187e6208d1a0006/native-value-stack-evidence.json`.

A second read-only review found no actionable defect in the guarded mailbox
scan or the new sum layout/constructor/match/call/local/lifetime paths. It
confirmed validated match payload views, descriptor-only locals/calls, branch
local restoration and conservative owner provenance. It ran no tests and did
not audit the entire emitter or all host serialization/equality paths; the
integration gates remain necessary.

The conformance correction now collects type layouts from every compiled sum
test body and delays the independent layout oracle until those programs exist.
Fallback-string tests pin the exact emitted LLVM global bytes and associated
constant-store call, calculate payload/aligned extent from fixture code units,
and require that exact deep-copy count. Input payload-view extraction continues
to require zero deep-copy bytes. Prior O0/O2 IR confirmed the literal/store
pair; a fresh fifth gate is running. Its result is not yet established.

The fifth gate completes O0/O2 with fallback-copy checks passing, but both layout
oracles still fail on the same three nominal-bearing sums. Source inspection
identified the actual metadata defect: sum layout names use `IrTypes.format`,
which exposes internal nominal keys inside composite types. The display-name
formatter is being made recursive over resolved Option/Result children; the
physical representation and internal type identities remain unchanged. This
is a product metadata correction, not an oracle relaxation. Failed evidence:
`verification-f3266bdfe37845ccb96476bc986bf77b/native-value-stack-evidence.json`.

The recursive display-name correction is complete and a sixth fresh sum gate
is running. The mailbox-policy gate passes all 741 checks with no failed rows:
`.agentlang/owning-mailbox-002/policy-run-410f3b453cba422689b7a3c666d99401/policy-evidence.json`.
The local real-I/O gate runs host-side to permit loopback sockets; full Release
validation remains live. These policy regression results do not choose a final
memory design or establish a throughput advantage.

The first real-I/O run is invalid for acceptance: its source-stability check
fails because `OwningStackAot.fs` changed during the run when the composite-name
bug was corrected. It records 210,086 check rows with this single failure;
passing behavioral rows do not override the failed provenance requirement.
This is a coordinator scheduling error. The run is retained at
`.agentlang/owning-mailbox-003/io-run-c7c1c9602c184f67ab36efaebbbf2532/io-evidence.json`
and will be repeated after the sum gate confirms stable final sources.

The sixth sum gate confirms resolved top-level type names, but its two layout
checks still fail when the harness renders typed case payload keys directly as
strings (`@type0`, `@type1`). All reported case offsets, extents and flags match.
The public case payload is an IrType key; the harness must resolve it through
the returned layouts' Type/TypeName relation before comparing display names.
The pinned expected names and typed identities remain required. Evidence:
`verification-30423812e1744c90b1546400a237049f/native-value-stack-evidence.json`.

The harness now resolves typed case keys through public layout Type/TypeName
pairs for both checks and evidence summaries. No fixture or runtime change was
needed for this step. A seventh fresh sum gate and second real-I/O gate are
running against stable runtime sources; full Release validation remains live.

The second host-side real-I/O gate passes all 207,422 check rows with zero
failures, including its source-stability check. Accepted evidence:
`.agentlang/owning-mailbox-003/io-run-01bdb24ec8664fb1952813aea6d98f32/io-evidence.json`.
The invalid first run remains preserved separately.

Real-I/O acceptance covers O0/O2, diagnostic/fast/trusted-generated profiles,
and both return/keep suspension policies. Raw check counts include variable
I/O event observations and are not fixed scenario counts or throughput evidence.

The preceding efficacy result remains [report 159](159-retained-io-vocabulary-follow-on.md):
both submissions passed behavior, but AgentLang duplicated an inspected helper
while F# reused it. Native implementation work does not alter that finding.

set -eu
D=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258/rails-logs
mkdir -p "$D"
for r in preflight-1 preflight-2; do cp "/home/ben/cm258/$r/logs/container.log" "$D/$r-container.log"; done
wc -c "$D"/*
grep -ciE 'cookie|session_token|password|secret' "$D"/* || true
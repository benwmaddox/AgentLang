set -eu
H=/mnt/d/code/AgentLang/.agentlang/once-campfire-verification
M=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258
W="$HOME/cm258/$1"
OUT="$M/contracts-$1"
test ! -e "$OUT" || { echo "contracts exist: $OUT"; exit 2; }
COOKIE="$(cat "$M/private/rails-cookie.txt")"
CSS="$2"
cd "$H"
ruby bench/contracts.rb http://127.0.0.1:13774 "$COOKIE" "$W/db/production.sqlite3" fixtures/default/labels.json "$CSS" "$OUT" > "$M/preflight-$1.json"
ruby -rjson -e 'p=JSON.parse(File.read(ARGV[0]))["preflight"]; p.each { |k,v| puts "#{k}: ids=#{v["message_ids"]&.length} decoded=#{v["decoded_bytes"]} wire=#{v["wire_bytes"]} enc=#{v["encoding"]}" }' "$M/preflight-$1.json"
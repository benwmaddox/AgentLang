#requires -Version 7.0
# Serve the shared Rails-built seed with the AOT native host on 13773 and validate the
# room page with the harness loadgen against the Rails-derived room_show contract.
param(
  [Parameter(Mandatory)][string]$BuildO2,
  [Parameter(Mandatory)][string]$Preflight,
  [Parameter(Mandatory)][string]$Contract,
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,32}$')][string]$RunName
)
$ErrorActionPreference = 'Stop'
$w = $PSScriptRoot
$out = Join-Path $w "native-contract/$RunName"
if (Test-Path -LiteralPath $out) { throw 'Run roots are immutable.' }
$null = New-Item -ItemType Directory -Path $out -Force
function Note([string]$t) { "$([DateTime]::UtcNow.ToString('O')) $t" | Add-Content -LiteralPath (Join-Path $out 'driver.log') -Encoding utf8NoBOM; Write-Output $t }
if (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 13773, 13774) { throw 'Port 13773/13774 busy.' }

$labels = Get-Content (Join-Path $w '../once-campfire-verification/fixtures/default/labels.json') -Raw | ConvertFrom-Json
$room = $labels.'rooms.watercooler'
$cookie = [IO.File]::ReadAllText((Join-Path $w "private/rails-cookie-$Preflight.txt"))
$db = Join-Path $w "private/native-db-$Preflight/production.sqlite3"
$secret = Join-Path $w 'private/secret-key-base.txt'
$lg = Join-Path $w 'loadgen-target/release/loadgen.exe'
$stopName = 'Local\CampfireMatched258Stop'

$hostArgs = @('--module', (Join-Path $BuildO2 'owning-stack-native-host.dll'), '--manifest', (Join-Path $BuildO2 'owning-stack-native-host-manifest.json'),
              '--db', $db, '--secret-file', $secret, '--port', '13773', '--workers', '4', '--stop-event', $stopName)
$hostLog = Join-Path $out 'native-host.log'
$hostProc = Start-Process -FilePath (Join-Path $BuildO2 'native_http_host.exe') -ArgumentList $hostArgs -PassThru -NoNewWindow `
  -RedirectStandardOutput $hostLog -RedirectStandardError (Join-Path $out 'native-host.stderr.log')
$null = $hostProc.Handle
try {
  $deadline = [DateTime]::UtcNow.AddSeconds(60)
  while ([DateTime]::UtcNow -lt $deadline -and -not $hostProc.HasExited -and -not ((Test-Path $hostLog) -and (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet))) { Start-Sleep -Milliseconds 200 }
  if (-not (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet)) { throw 'native host not READY' }
  Note "native ready pid=$($hostProc.Id)"
  foreach ($gzip in 0, 1) {
    $json = & $lg http --base http://127.0.0.1:13773 --cookie $cookie --path "/rooms/$room" --validate $Contract --conc 4 --requests 400 --gzip $gzip 2>(Join-Path $out "loadgen-gzip$gzip.err.log")
    $json | Set-Content -LiteralPath (Join-Path $out "loadgen-gzip$gzip.json") -Encoding utf8NoBOM
    Note "gzip=$gzip exit=$LASTEXITCODE $json"
  }
} finally {
  try { $e = [Threading.EventWaitHandle]::OpenExisting($stopName); [void]$e.Set(); $e.Dispose() } catch { Note "stop event unavailable: $($_.Exception.Message)" }
  if (-not $hostProc.WaitForExit(60000)) { Note 'native host did not exit' } else { $hostProc.WaitForExit(); Note "native exit=$($hostProc.ExitCode)" }
}

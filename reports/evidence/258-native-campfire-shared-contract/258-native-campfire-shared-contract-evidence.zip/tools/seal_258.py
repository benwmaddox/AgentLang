#!/usr/bin/env python3
"""Seal report-258 shared-contract evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
A = REPO / ".agentlang"
P256 = A / "campfire-native-profile-256"
HERE = A / "campfire-native-markup-257"
OUT = REPO / "reports" / "evidence" / "258-native-campfire-shared-contract"
M = A / "campfire-matched-258"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|config\.json$|secret|private-request|private-measure|\.env$|labels\.json$|rails-cookie|cookie\.txt$)")
COOKIE = re.compile(rb"(?im)(_campfire_session|session_token)=[A-Za-z0-9%+/=_-]{16,}|^\s*cookie\s*:")
BUILD = "build-trusted-generated-20261013T105302342Z-32b1586745dd427a95e5318fa46e2727"
GATE = A / "campfire-native-room-read-252" / "test-runs" / "20261013T105032097Z-748dbc78586d47b2a814a835b61a31b2"
HTTP_TESTS = A / "campfire-logout-245" / "http-tests" / "runs" / "20261013T105611296Z-4d5bf0cf795a4df0b3023bd125ad24b1"
SOURCES = ["applications/campfire/Http/ResponseRenderer.fs", "applications/campfire/Native/http/campfire_http_renderer.c",
           "tests/AgentLang.Campfire.Http.Tests/Program.fs", "scripts/Build-CampfireNativeHttp.ps1"]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect() -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    for attempt in ("c", "d"):
        for opt in ("o0", "o2"):
            name = f"markup257-off-{opt}-{attempt}"
            d = HERE / "validation" / name
            for f in sorted(d.iterdir()):
                items.append((f, f"parity/{name}/{f.name}"))
            r = P256 / "runs" / name
            if r.exists():
                for f in sorted(p for p in r.iterdir() if p.is_file()):
                    items.append((f, f"parity-runs/{name}/{f.name}"))
            v = P256 / "http-validation" / f"{name}-off-{opt}"
            if v.exists():
                for f in sorted(v.iterdir()):
                    items.append((f, f"http-validation/{v.name}/{f.name}"))
    root = P256 / "http-host" / BUILD
    for rel in ("http_host_pins.h", "source-pins.json", "O0/build-receipt.json", "O2/build-receipt.json", "O0/native-imports.txt", "O2/native-imports.txt"):
        items.append((root / rel, f"build/{rel}"))
    for name in ("test-receipt.json", "test-source-freeze.json", "test-run.log"):
        items.append((GATE / name, f"room-read-gate/{name}"))
    items.append((HTTP_TESTS / "receipt.json", "http-tests/receipt.json"))
    items.append((HERE / "reference-build-c.log", "reference/reference-build-c.log"))
    for run in ("contract-a", "contract-b"):
        for f in sorted((M / "native-contract" / run).iterdir()):
            items.append((f, f"native-contract/{run}/{f.name}"))
    items.append((M / "harness-generated-hashes-258.json", "harness-contract/harness-generated-hashes.json"))
    for f in sorted((M / "rails-logs").iterdir()):
        items.append((f, f"rails/{f.name}"))
    items.append((A / "once-campfire-verification" / "fixtures" / "default" / "source.json", "seed/source.json"))
    items.append((A / "campfire-matched-258-loadgen-build.log", "loadgen/build.log"))
    for name in ("start-rails.sh", "contracts.sh", "copy-db.sh", "copy-logs.sh", "Native-Contract.ps1", "seal_258.py"):
        items.append((M / name, f"tools/{name}"))
    items.append((HERE / "Validate-Markup.ps1", "tools/Validate-Markup.ps1"))
    for rel in SOURCES:
        items.append((REPO / rel, f"sources/{rel}"))
    return items


def main() -> int:
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries = []
    blobs = {}
    for path, arc in collect():
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) or BANNED.search(arc):
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        if COOKIE.search(data):
            raise SystemExit(f"refused possible credential content: {arc}")
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "campfire-native-shared-contract-evidence-v1", "report": "258", "entries": entries,
                            "excluded": ["fixture and seed databases", "secret_key_base and credentials env", "Rails-issued cookies", "seed labels (contain fixture passwords)"]}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "258-native-campfire-shared-contract-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
        if names != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

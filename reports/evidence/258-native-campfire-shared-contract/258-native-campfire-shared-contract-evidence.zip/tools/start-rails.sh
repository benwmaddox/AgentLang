set -eu
H=/mnt/d/code/AgentLang/.agentlang/once-campfire-verification
W="$HOME/cm258/$1"
test ! -e "$W" || { echo "immutable workspace exists: $W"; exit 2; }
if docker ps -a --format '{{.Names}}' | grep -qx cm258-rails; then echo "container cm258-rails already exists"; exit 2; fi
mkdir -p "$W/logs"
cp -r "$H/fixtures/default/db" "$W/db"; cp -r "$H/fixtures/default/storage" "$W/files"
sqlite3 "$W/db/production.sqlite3" "UPDATE push_subscriptions SET endpoint = 'https://127.0.0.1:9/push/' || id; UPDATE webhooks SET url = 'http://127.0.0.1:9/hook/' || id;"
docker run -d --name cm258-rails -p 127.0.0.1:13774:13774 ${CPUSET:+--cpuset-cpus "$CPUSET"} --env-file "$H/fixtures/default/reference.env" \
  -e WEB_CONCURRENCY=3 -e JOB_CONCURRENCY=3 -e RAILS_MAX_THREADS=5 -e RAILS_LOG_LEVEL=warn -e HTTP_PORT=13774 -e TARGET_PORT=13775 \
  -v "$W/db:/rails/storage/db" -v "$W/files:/rails/storage/files" -v "$W/logs:/rails/storage/logs" \
  once-campfire-verification:reference-90b3300 >/dev/null
for i in $(seq 1 900); do
  if curl -fsS -o /dev/null http://127.0.0.1:13774/up 2>/dev/null; then break; fi; sleep 0.1
done
curl -fsS -o /dev/null http://127.0.0.1:13774/up || { docker logs cm258-rails 2>&1 | tail -20; exit 3; }
docker exec --user root cm258-rails chmod -R a+rwX /rails/storage/db
echo "rails ready workspace=$W image=$(docker image inspect -f '{{.Id}}' once-campfire-verification:reference-90b3300)"
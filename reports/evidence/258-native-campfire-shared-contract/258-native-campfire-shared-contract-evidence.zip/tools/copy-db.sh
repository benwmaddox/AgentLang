set -eu
M=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258/private/native-db-$1
test ! -e "$M" || { echo exists; exit 2; }
T=$(mktemp -d); cp /home/ben/cm258/$1/db/production.sqlite3* "$T/"
sqlite3 "$T/production.sqlite3" "PRAGMA wal_checkpoint(TRUNCATE);" >/dev/null
sqlite3 "$T/production.sqlite3" "PRAGMA integrity_check;"
mkdir -p "$M"; cp "$T/production.sqlite3" "$M/production.sqlite3"
sqlite3 -readonly "$M/production.sqlite3" "SELECT COUNT(*) FROM sessions;"
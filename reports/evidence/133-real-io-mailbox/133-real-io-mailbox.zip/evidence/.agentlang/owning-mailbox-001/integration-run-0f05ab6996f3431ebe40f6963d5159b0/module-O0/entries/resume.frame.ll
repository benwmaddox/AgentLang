define internal i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 6
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 6, 6
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %call.arguments.106 = alloca [3 x %AlOwningDescriptor], align 4
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  store i32 5, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.111, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.112, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 1
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  store i32 4, ptr %descriptor.field.118, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.119, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.120, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.121, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.122, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %descriptor.element.127 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 2
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 0
  store i32 6, ptr %descriptor.field.128, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.129, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.130, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.131, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.132, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %runtime.ok.135 = icmp eq i32 %context.value.134, 0
  br i1 %runtime.ok.135, label %runtime.continue.136, label %frame.failure.0
runtime.continue.136:
  %call.results.137 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.138 = call i32 @agentlang_word_0002(ptr %ctx, ptr %call.arguments.106, ptr %call.results.137, i32 6)
  %helper.ok.139 = icmp eq i32 %callee.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %descriptor.element.141 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.137, i32 0
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 0
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 1
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 2
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 3
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 4
  %descriptor.value.151 = load i32, ptr %descriptor.field.150, align 4
  %callee.result.type.valid.152 = icmp eq i32 %descriptor.value.143, 5
  br i1 %callee.result.type.valid.152, label %callee.result.type.ok.153, label %frame.failure.0
callee.result.type.ok.153:
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %stack.sub.158 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.156 = icmp ule i32 %descriptor.value.151, %context.value.155
  %descriptor.offset.inside.157 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.159 = icmp ule i32 %descriptor.value.147, %stack.sub.158
  %descriptor.payload.inside.160 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.161 = and i1 %descriptor.owner.inside.156, %descriptor.offset.inside.157
  %descriptor.range.inside.163 = and i1 %descriptor.owner.offset.valid.161, %descriptor.extent.inside.159
  %descriptor.range.valid.162 = and i1 %descriptor.range.inside.163, %descriptor.payload.inside.160
  %descriptor.type.valid.164 = icmp eq i32 5, 5
  %descriptor.valid.165 = and i1 %descriptor.range.valid.162, %descriptor.type.valid.164
  br i1 %descriptor.valid.165, label %descriptor.valid.166, label %descriptor.invalid.167
descriptor.invalid.167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.166:
  %descriptor.initialized.status.168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.169 = icmp eq i32 %descriptor.initialized.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %frame.failure.0
helper.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.177 = icmp ule i32 %descriptor.value.151, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.180 = icmp ule i32 %descriptor.value.147, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  %descriptor.type.valid.185 = icmp eq i32 5, 5
  %descriptor.valid.186 = and i1 %descriptor.range.valid.183, %descriptor.type.valid.185
  br i1 %descriptor.valid.186, label %descriptor.valid.187, label %descriptor.invalid.188
descriptor.invalid.188:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.187:
  %descriptor.initialized.status.189 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.190 = icmp eq i32 %descriptor.initialized.status.189, 0
  br i1 %helper.ok.190, label %helper.continue.191, label %frame.failure.0
helper.continue.191:
  %descriptor.element.192 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 0
  store i32 5, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 1
  store i32 %descriptor.value.145, ptr %descriptor.field.194, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 2
  store i32 %descriptor.value.147, ptr %descriptor.field.195, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 3
  store i32 %descriptor.value.149, ptr %descriptor.field.196, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 4
  store i32 %descriptor.value.151, ptr %descriptor.field.197, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %runtime.ok.200 = icmp eq i32 %context.value.199, 0
  br i1 %runtime.ok.200, label %runtime.continue.201, label %frame.failure.0
runtime.continue.201:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.offset.208 = add i32 %context.value.5, %context.value.7
  %stack.offset.209 = add i32 %context.value.203, %context.value.205
  %stack.sub.210 = sub i32 %stack.offset.208, %stack.offset.209
  %stack.sub.211 = sub i32 %context.value.7, %context.value.205
  %stack.sub.212 = sub i32 %context.value.207, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.210, i32 %stack.sub.211)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.212)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


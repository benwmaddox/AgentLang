%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 1, i32 4294967295, i32 4294967295, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 1, i32 1, i32 4294967295, i32 4294967295, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }], align 4
@agentlang_owning_mailbox_layout = constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 2 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\04\00\00\00\00\00\00\00\46\00\41\00\49\00\4C\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare i32 @agentlang_owning_mailbox_preflight(ptr, ptr, i32, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @agentlang_owning_mailbox_associated_preflight(ptr, ptr, i32, ptr, i32, ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 6, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.58 = call i32 @agentlang_word_0001(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 5
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 5, 5
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 5, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 6
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 6, 6
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 5, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 6, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %call.results.97 = alloca [2 x %AlOwningDescriptor], align 4
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.76, ptr %call.results.97, i32 4)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 5
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 5, 5
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %descriptor.element.135 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 1
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 0
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 1
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 2
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 3
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 4
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %callee.result.type.valid.146 = icmp eq i32 %descriptor.value.137, 4
  br i1 %callee.result.type.valid.146, label %callee.result.type.ok.147, label %frame.failure.0
callee.result.type.ok.147:
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %stack.sub.152 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.150 = icmp ule i32 %descriptor.value.145, %context.value.149
  %descriptor.offset.inside.151 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.153 = icmp ule i32 %descriptor.value.141, %stack.sub.152
  %descriptor.payload.inside.154 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.155 = and i1 %descriptor.owner.inside.150, %descriptor.offset.inside.151
  %descriptor.range.inside.157 = and i1 %descriptor.owner.offset.valid.155, %descriptor.extent.inside.153
  %descriptor.range.valid.156 = and i1 %descriptor.range.inside.157, %descriptor.payload.inside.154
  %descriptor.type.valid.158 = icmp eq i32 4, 4
  %descriptor.valid.159 = and i1 %descriptor.range.valid.156, %descriptor.type.valid.158
  br i1 %descriptor.valid.159, label %descriptor.valid.160, label %descriptor.invalid.161
descriptor.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.160:
  %descriptor.initialized.status.162 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.163 = icmp eq i32 %descriptor.initialized.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %runtime.ok.167 = icmp eq i32 %context.value.166, 0
  br i1 %runtime.ok.167, label %runtime.continue.168, label %frame.failure.0
runtime.continue.168:
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.171 = icmp ule i32 %descriptor.value.111, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.174 = icmp ule i32 %descriptor.value.107, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  %descriptor.type.valid.179 = icmp eq i32 5, 5
  %descriptor.valid.180 = and i1 %descriptor.range.valid.177, %descriptor.type.valid.179
  br i1 %descriptor.valid.180, label %descriptor.valid.181, label %descriptor.invalid.182
descriptor.invalid.182:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.181:
  %descriptor.initialized.status.183 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.184 = icmp eq i32 %descriptor.initialized.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %frame.failure.0
helper.continue.185:
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %stack.sub.190 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.188 = icmp ule i32 %descriptor.value.145, %context.value.187
  %descriptor.offset.inside.189 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.191 = icmp ule i32 %descriptor.value.141, %stack.sub.190
  %descriptor.payload.inside.192 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.193 = and i1 %descriptor.owner.inside.188, %descriptor.offset.inside.189
  %descriptor.range.inside.195 = and i1 %descriptor.owner.offset.valid.193, %descriptor.extent.inside.191
  %descriptor.range.valid.194 = and i1 %descriptor.range.inside.195, %descriptor.payload.inside.192
  %descriptor.type.valid.196 = icmp eq i32 4, 4
  %descriptor.valid.197 = and i1 %descriptor.range.valid.194, %descriptor.type.valid.196
  br i1 %descriptor.valid.197, label %descriptor.valid.198, label %descriptor.invalid.199
descriptor.invalid.199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.198:
  %descriptor.initialized.status.200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.201 = icmp eq i32 %descriptor.initialized.status.200, 0
  br i1 %helper.ok.201, label %helper.continue.202, label %frame.failure.0
helper.continue.202:
  %descriptor.element.203 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 0
  store i32 5, ptr %descriptor.field.204, align 4
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.208, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %runtime.ok.211 = icmp eq i32 %context.value.210, 0
  br i1 %runtime.ok.211, label %runtime.continue.212, label %frame.failure.0
runtime.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 4, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.139, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.141, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.143, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.145, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %stack.offset.229 = add i32 %context.value.5, %context.value.7
  %stack.offset.230 = add i32 %context.value.224, %context.value.226
  %stack.sub.231 = sub i32 %stack.offset.229, %stack.offset.230
  %stack.sub.232 = sub i32 %context.value.7, %context.value.226
  %stack.sub.233 = sub i32 %context.value.228, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.231, i32 %stack.sub.232)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.233)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 6
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 6, 6
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %call.arguments.106 = alloca [3 x %AlOwningDescriptor], align 4
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  store i32 5, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.111, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.112, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 1
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  store i32 4, ptr %descriptor.field.118, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.119, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.120, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.121, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.122, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %descriptor.element.127 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 2
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 0
  store i32 6, ptr %descriptor.field.128, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.129, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.130, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.131, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.132, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %runtime.ok.135 = icmp eq i32 %context.value.134, 0
  br i1 %runtime.ok.135, label %runtime.continue.136, label %frame.failure.0
runtime.continue.136:
  %call.results.137 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.138 = call i32 @agentlang_word_0002(ptr %ctx, ptr %call.arguments.106, ptr %call.results.137, i32 6)
  %helper.ok.139 = icmp eq i32 %callee.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %descriptor.element.141 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.137, i32 0
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 0
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 1
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 2
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 3
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 4
  %descriptor.value.151 = load i32, ptr %descriptor.field.150, align 4
  %callee.result.type.valid.152 = icmp eq i32 %descriptor.value.143, 5
  br i1 %callee.result.type.valid.152, label %callee.result.type.ok.153, label %frame.failure.0
callee.result.type.ok.153:
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %stack.sub.158 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.156 = icmp ule i32 %descriptor.value.151, %context.value.155
  %descriptor.offset.inside.157 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.159 = icmp ule i32 %descriptor.value.147, %stack.sub.158
  %descriptor.payload.inside.160 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.161 = and i1 %descriptor.owner.inside.156, %descriptor.offset.inside.157
  %descriptor.range.inside.163 = and i1 %descriptor.owner.offset.valid.161, %descriptor.extent.inside.159
  %descriptor.range.valid.162 = and i1 %descriptor.range.inside.163, %descriptor.payload.inside.160
  %descriptor.type.valid.164 = icmp eq i32 5, 5
  %descriptor.valid.165 = and i1 %descriptor.range.valid.162, %descriptor.type.valid.164
  br i1 %descriptor.valid.165, label %descriptor.valid.166, label %descriptor.invalid.167
descriptor.invalid.167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.166:
  %descriptor.initialized.status.168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.169 = icmp eq i32 %descriptor.initialized.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %frame.failure.0
helper.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.177 = icmp ule i32 %descriptor.value.151, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.180 = icmp ule i32 %descriptor.value.147, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  %descriptor.type.valid.185 = icmp eq i32 5, 5
  %descriptor.valid.186 = and i1 %descriptor.range.valid.183, %descriptor.type.valid.185
  br i1 %descriptor.valid.186, label %descriptor.valid.187, label %descriptor.invalid.188
descriptor.invalid.188:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.187:
  %descriptor.initialized.status.189 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.190 = icmp eq i32 %descriptor.initialized.status.189, 0
  br i1 %helper.ok.190, label %helper.continue.191, label %frame.failure.0
helper.continue.191:
  %descriptor.element.192 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 0
  store i32 5, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 1
  store i32 %descriptor.value.145, ptr %descriptor.field.194, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 2
  store i32 %descriptor.value.147, ptr %descriptor.field.195, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 3
  store i32 %descriptor.value.149, ptr %descriptor.field.196, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 4
  store i32 %descriptor.value.151, ptr %descriptor.field.197, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %runtime.ok.200 = icmp eq i32 %context.value.199, 0
  br i1 %runtime.ok.200, label %runtime.continue.201, label %frame.failure.0
runtime.continue.201:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.offset.208 = add i32 %context.value.5, %context.value.7
  %stack.offset.209 = add i32 %context.value.203, %context.value.205
  %stack.sub.210 = sub i32 %stack.offset.208, %stack.offset.209
  %stack.sub.211 = sub i32 %context.value.7, %context.value.205
  %stack.sub.212 = sub i32 %context.value.207, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.210, i32 %stack.sub.211)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.212)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %frame.entered.34 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.35 = icmp eq i32 %frame.entered.34, 0
  br i1 %frame.enter.ok.35, label %frame.enter.continue.36, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.36:
  %descriptor.element.37 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 0
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 1
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %descriptor.field.42 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 2
  %descriptor.value.43 = load i32, ptr %descriptor.field.42, align 4
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 3
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 4
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %argument.type.valid.48 = icmp eq i32 %descriptor.value.39, 5
  br i1 %argument.type.valid.48, label %argument.type.ok.49, label %frame.failure.0
argument.type.ok.49:
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %stack.sub.54 = sub i32 %descriptor.value.47, %descriptor.value.41
  %descriptor.owner.inside.52 = icmp ule i32 %descriptor.value.47, %context.value.51
  %descriptor.offset.inside.53 = icmp ule i32 %descriptor.value.41, %descriptor.value.47
  %descriptor.extent.inside.55 = icmp ule i32 %descriptor.value.43, %stack.sub.54
  %descriptor.payload.inside.56 = icmp ule i32 %descriptor.value.45, %descriptor.value.43
  %descriptor.owner.offset.valid.57 = and i1 %descriptor.owner.inside.52, %descriptor.offset.inside.53
  %descriptor.range.inside.59 = and i1 %descriptor.owner.offset.valid.57, %descriptor.extent.inside.55
  %descriptor.range.valid.58 = and i1 %descriptor.range.inside.59, %descriptor.payload.inside.56
  %descriptor.type.valid.60 = icmp eq i32 5, 5
  %descriptor.valid.61 = and i1 %descriptor.range.valid.58, %descriptor.type.valid.60
  br i1 %descriptor.valid.61, label %descriptor.valid.62, label %descriptor.invalid.63
descriptor.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.62:
  %descriptor.initialized.status.64 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.41, i32 %descriptor.value.43)
  %helper.ok.65 = icmp eq i32 %descriptor.initialized.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %frame.failure.0
helper.continue.66:
  %descriptor.element.67 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 0
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 1
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 2
  %descriptor.value.73 = load i32, ptr %descriptor.field.72, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 3
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 4
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %argument.type.valid.78 = icmp eq i32 %descriptor.value.69, 6
  br i1 %argument.type.valid.78, label %argument.type.ok.79, label %frame.failure.0
argument.type.ok.79:
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.sub.84 = sub i32 %descriptor.value.77, %descriptor.value.71
  %descriptor.owner.inside.82 = icmp ule i32 %descriptor.value.77, %context.value.81
  %descriptor.offset.inside.83 = icmp ule i32 %descriptor.value.71, %descriptor.value.77
  %descriptor.extent.inside.85 = icmp ule i32 %descriptor.value.73, %stack.sub.84
  %descriptor.payload.inside.86 = icmp ule i32 %descriptor.value.75, %descriptor.value.73
  %descriptor.owner.offset.valid.87 = and i1 %descriptor.owner.inside.82, %descriptor.offset.inside.83
  %descriptor.range.inside.89 = and i1 %descriptor.owner.offset.valid.87, %descriptor.extent.inside.85
  %descriptor.range.valid.88 = and i1 %descriptor.range.inside.89, %descriptor.payload.inside.86
  %descriptor.type.valid.90 = icmp eq i32 6, 6
  %descriptor.valid.91 = and i1 %descriptor.range.valid.88, %descriptor.type.valid.90
  br i1 %descriptor.valid.91, label %descriptor.valid.92, label %descriptor.invalid.93
descriptor.invalid.93:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.92:
  %descriptor.initialized.status.94 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.71, i32 %descriptor.value.73)
  %helper.ok.95 = icmp eq i32 %descriptor.initialized.status.94, 0
  br i1 %helper.ok.95, label %helper.continue.96, label %frame.failure.0
helper.continue.96:
  %step.status.97 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.98 = icmp eq i32 %step.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %frame.failure.0
helper.continue.99:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.71, ptr %local.offset.3, align 4
  store i32 %descriptor.value.73, ptr %local.extent.4, align 4
  store i32 %descriptor.value.75, ptr %local.payload.5, align 4
  store i32 %descriptor.value.77, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.71, i32 20, i32 %descriptor.value.75, i32 %descriptor.value.77, i32 %descriptor.value.73)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %stack.sub.108 = sub i32 %descriptor.value.47, %descriptor.value.41
  %descriptor.owner.inside.106 = icmp ule i32 %descriptor.value.47, %context.value.105
  %descriptor.offset.inside.107 = icmp ule i32 %descriptor.value.41, %descriptor.value.47
  %descriptor.extent.inside.109 = icmp ule i32 %descriptor.value.43, %stack.sub.108
  %descriptor.payload.inside.110 = icmp ule i32 %descriptor.value.45, %descriptor.value.43
  %descriptor.owner.offset.valid.111 = and i1 %descriptor.owner.inside.106, %descriptor.offset.inside.107
  %descriptor.range.inside.113 = and i1 %descriptor.owner.offset.valid.111, %descriptor.extent.inside.109
  %descriptor.range.valid.112 = and i1 %descriptor.range.inside.113, %descriptor.payload.inside.110
  %descriptor.type.valid.114 = icmp eq i32 5, 5
  %descriptor.valid.115 = and i1 %descriptor.range.valid.112, %descriptor.type.valid.114
  br i1 %descriptor.valid.115, label %descriptor.valid.116, label %descriptor.invalid.117
descriptor.invalid.117:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.116:
  %descriptor.initialized.status.118 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.41, i32 %descriptor.value.43)
  %helper.ok.119 = icmp eq i32 %descriptor.initialized.status.118, 0
  br i1 %helper.ok.119, label %helper.continue.120, label %frame.failure.0
helper.continue.120:
  %local.is.active.121 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.121, label %local.descriptor.active.122, label %local.descriptor.inactive.123
local.descriptor.active.122:
  %local.check.offset.125 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.126 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.127 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.128 = load i32, ptr %local.owner.end.6, align 4
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %stack.sub.133 = sub i32 %local.check.owner.end.128, %local.check.offset.125
  %descriptor.owner.inside.131 = icmp ule i32 %local.check.owner.end.128, %context.value.130
  %descriptor.offset.inside.132 = icmp ule i32 %local.check.offset.125, %local.check.owner.end.128
  %descriptor.extent.inside.134 = icmp ule i32 %local.check.extent.126, %stack.sub.133
  %descriptor.payload.inside.135 = icmp ule i32 %local.check.payload.127, %local.check.extent.126
  %descriptor.owner.offset.valid.136 = and i1 %descriptor.owner.inside.131, %descriptor.offset.inside.132
  %descriptor.range.inside.138 = and i1 %descriptor.owner.offset.valid.136, %descriptor.extent.inside.134
  %descriptor.range.valid.137 = and i1 %descriptor.range.inside.138, %descriptor.payload.inside.135
  br i1 %descriptor.range.valid.137, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.125, i32 %local.check.extent.126)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  br label %local.descriptor.checked.124
local.descriptor.inactive.123:
  br label %local.descriptor.checked.124
local.descriptor.checked.124:
  %local.is.active.144 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.144, label %local.descriptor.active.145, label %local.descriptor.inactive.146
local.descriptor.active.145:
  %local.check.offset.148 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.149 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.150 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.151 = load i32, ptr %local.owner.end.12, align 4
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %local.check.owner.end.151, %local.check.offset.148
  %descriptor.owner.inside.154 = icmp ule i32 %local.check.owner.end.151, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %local.check.offset.148, %local.check.owner.end.151
  %descriptor.extent.inside.157 = icmp ule i32 %local.check.extent.149, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %local.check.payload.150, %local.check.extent.149
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  br i1 %descriptor.range.valid.160, label %descriptor.valid.162, label %descriptor.invalid.163
descriptor.invalid.163:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.162:
  %descriptor.initialized.status.164 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.148, i32 %local.check.extent.149)
  %helper.ok.165 = icmp eq i32 %descriptor.initialized.status.164, 0
  br i1 %helper.ok.165, label %helper.continue.166, label %frame.failure.0
helper.continue.166:
  br label %local.descriptor.checked.147
local.descriptor.inactive.146:
  br label %local.descriptor.checked.147
local.descriptor.checked.147:
  %local.is.active.167 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.167, label %local.descriptor.active.168, label %local.descriptor.inactive.169
local.descriptor.active.168:
  %local.check.offset.171 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.172 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.173 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.174 = load i32, ptr %local.owner.end.18, align 4
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %local.check.owner.end.174, %local.check.offset.171
  %descriptor.owner.inside.177 = icmp ule i32 %local.check.owner.end.174, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %local.check.offset.171, %local.check.owner.end.174
  %descriptor.extent.inside.180 = icmp ule i32 %local.check.extent.172, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %local.check.payload.173, %local.check.extent.172
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  br i1 %descriptor.range.valid.183, label %descriptor.valid.185, label %descriptor.invalid.186
descriptor.invalid.186:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.185:
  %descriptor.initialized.status.187 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.171, i32 %local.check.extent.172)
  %helper.ok.188 = icmp eq i32 %descriptor.initialized.status.187, 0
  br i1 %helper.ok.188, label %helper.continue.189, label %frame.failure.0
helper.continue.189:
  br label %local.descriptor.checked.170
local.descriptor.inactive.169:
  br label %local.descriptor.checked.170
local.descriptor.checked.170:
  %local.is.active.190 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.190, label %local.descriptor.active.191, label %local.descriptor.inactive.192
local.descriptor.active.191:
  %local.check.offset.194 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.195 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.196 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.197 = load i32, ptr %local.owner.end.24, align 4
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %stack.sub.202 = sub i32 %local.check.owner.end.197, %local.check.offset.194
  %descriptor.owner.inside.200 = icmp ule i32 %local.check.owner.end.197, %context.value.199
  %descriptor.offset.inside.201 = icmp ule i32 %local.check.offset.194, %local.check.owner.end.197
  %descriptor.extent.inside.203 = icmp ule i32 %local.check.extent.195, %stack.sub.202
  %descriptor.payload.inside.204 = icmp ule i32 %local.check.payload.196, %local.check.extent.195
  %descriptor.owner.offset.valid.205 = and i1 %descriptor.owner.inside.200, %descriptor.offset.inside.201
  %descriptor.range.inside.207 = and i1 %descriptor.owner.offset.valid.205, %descriptor.extent.inside.203
  %descriptor.range.valid.206 = and i1 %descriptor.range.inside.207, %descriptor.payload.inside.204
  br i1 %descriptor.range.valid.206, label %descriptor.valid.208, label %descriptor.invalid.209
descriptor.invalid.209:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.208:
  %descriptor.initialized.status.210 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.194, i32 %local.check.extent.195)
  %helper.ok.211 = icmp eq i32 %descriptor.initialized.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  br label %local.descriptor.checked.193
local.descriptor.inactive.192:
  br label %local.descriptor.checked.193
local.descriptor.checked.193:
  %step.status.213 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.214 = icmp eq i32 %step.status.213, 0
  br i1 %helper.ok.214, label %helper.continue.215, label %frame.failure.0
helper.continue.215:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.41, ptr %local.offset.9, align 4
  store i32 %descriptor.value.43, ptr %local.extent.10, align 4
  store i32 %descriptor.value.45, ptr %local.payload.11, align 4
  store i32 %descriptor.value.47, ptr %local.owner.end.12, align 4
  store i32 5, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.41, i32 20, i32 %descriptor.value.45, i32 %descriptor.value.47, i32 %descriptor.value.43)
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %runtime.ok.218 = icmp eq i32 %context.value.217, 0
  br i1 %runtime.ok.218, label %runtime.continue.219, label %frame.failure.0
runtime.continue.219:
  %local.is.active.220 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.220, label %local.descriptor.active.221, label %local.descriptor.inactive.222
local.descriptor.active.221:
  %local.check.offset.224 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.225 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.226 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.227 = load i32, ptr %local.owner.end.6, align 4
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.sub.232 = sub i32 %local.check.owner.end.227, %local.check.offset.224
  %descriptor.owner.inside.230 = icmp ule i32 %local.check.owner.end.227, %context.value.229
  %descriptor.offset.inside.231 = icmp ule i32 %local.check.offset.224, %local.check.owner.end.227
  %descriptor.extent.inside.233 = icmp ule i32 %local.check.extent.225, %stack.sub.232
  %descriptor.payload.inside.234 = icmp ule i32 %local.check.payload.226, %local.check.extent.225
  %descriptor.owner.offset.valid.235 = and i1 %descriptor.owner.inside.230, %descriptor.offset.inside.231
  %descriptor.range.inside.237 = and i1 %descriptor.owner.offset.valid.235, %descriptor.extent.inside.233
  %descriptor.range.valid.236 = and i1 %descriptor.range.inside.237, %descriptor.payload.inside.234
  br i1 %descriptor.range.valid.236, label %descriptor.valid.238, label %descriptor.invalid.239
descriptor.invalid.239:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.238:
  %descriptor.initialized.status.240 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.224, i32 %local.check.extent.225)
  %helper.ok.241 = icmp eq i32 %descriptor.initialized.status.240, 0
  br i1 %helper.ok.241, label %helper.continue.242, label %frame.failure.0
helper.continue.242:
  br label %local.descriptor.checked.223
local.descriptor.inactive.222:
  br label %local.descriptor.checked.223
local.descriptor.checked.223:
  %local.is.active.243 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.243, label %local.descriptor.active.244, label %local.descriptor.inactive.245
local.descriptor.active.244:
  %local.check.offset.247 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.248 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.249 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.250 = load i32, ptr %local.owner.end.12, align 4
  %context.field.251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.252 = load i32, ptr %context.field.251, align 4
  %stack.sub.255 = sub i32 %local.check.owner.end.250, %local.check.offset.247
  %descriptor.owner.inside.253 = icmp ule i32 %local.check.owner.end.250, %context.value.252
  %descriptor.offset.inside.254 = icmp ule i32 %local.check.offset.247, %local.check.owner.end.250
  %descriptor.extent.inside.256 = icmp ule i32 %local.check.extent.248, %stack.sub.255
  %descriptor.payload.inside.257 = icmp ule i32 %local.check.payload.249, %local.check.extent.248
  %descriptor.owner.offset.valid.258 = and i1 %descriptor.owner.inside.253, %descriptor.offset.inside.254
  %descriptor.range.inside.260 = and i1 %descriptor.owner.offset.valid.258, %descriptor.extent.inside.256
  %descriptor.range.valid.259 = and i1 %descriptor.range.inside.260, %descriptor.payload.inside.257
  br i1 %descriptor.range.valid.259, label %descriptor.valid.261, label %descriptor.invalid.262
descriptor.invalid.262:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.261:
  %descriptor.initialized.status.263 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.247, i32 %local.check.extent.248)
  %helper.ok.264 = icmp eq i32 %descriptor.initialized.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %frame.failure.0
helper.continue.265:
  br label %local.descriptor.checked.246
local.descriptor.inactive.245:
  br label %local.descriptor.checked.246
local.descriptor.checked.246:
  %local.is.active.266 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.266, label %local.descriptor.active.267, label %local.descriptor.inactive.268
local.descriptor.active.267:
  %local.check.offset.270 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.271 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.272 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.273 = load i32, ptr %local.owner.end.18, align 4
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %stack.sub.278 = sub i32 %local.check.owner.end.273, %local.check.offset.270
  %descriptor.owner.inside.276 = icmp ule i32 %local.check.owner.end.273, %context.value.275
  %descriptor.offset.inside.277 = icmp ule i32 %local.check.offset.270, %local.check.owner.end.273
  %descriptor.extent.inside.279 = icmp ule i32 %local.check.extent.271, %stack.sub.278
  %descriptor.payload.inside.280 = icmp ule i32 %local.check.payload.272, %local.check.extent.271
  %descriptor.owner.offset.valid.281 = and i1 %descriptor.owner.inside.276, %descriptor.offset.inside.277
  %descriptor.range.inside.283 = and i1 %descriptor.owner.offset.valid.281, %descriptor.extent.inside.279
  %descriptor.range.valid.282 = and i1 %descriptor.range.inside.283, %descriptor.payload.inside.280
  br i1 %descriptor.range.valid.282, label %descriptor.valid.284, label %descriptor.invalid.285
descriptor.invalid.285:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.284:
  %descriptor.initialized.status.286 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.270, i32 %local.check.extent.271)
  %helper.ok.287 = icmp eq i32 %descriptor.initialized.status.286, 0
  br i1 %helper.ok.287, label %helper.continue.288, label %frame.failure.0
helper.continue.288:
  br label %local.descriptor.checked.269
local.descriptor.inactive.268:
  br label %local.descriptor.checked.269
local.descriptor.checked.269:
  %local.is.active.289 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.289, label %local.descriptor.active.290, label %local.descriptor.inactive.291
local.descriptor.active.290:
  %local.check.offset.293 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.294 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.295 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.296 = load i32, ptr %local.owner.end.24, align 4
  %context.field.297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.298 = load i32, ptr %context.field.297, align 4
  %stack.sub.301 = sub i32 %local.check.owner.end.296, %local.check.offset.293
  %descriptor.owner.inside.299 = icmp ule i32 %local.check.owner.end.296, %context.value.298
  %descriptor.offset.inside.300 = icmp ule i32 %local.check.offset.293, %local.check.owner.end.296
  %descriptor.extent.inside.302 = icmp ule i32 %local.check.extent.294, %stack.sub.301
  %descriptor.payload.inside.303 = icmp ule i32 %local.check.payload.295, %local.check.extent.294
  %descriptor.owner.offset.valid.304 = and i1 %descriptor.owner.inside.299, %descriptor.offset.inside.300
  %descriptor.range.inside.306 = and i1 %descriptor.owner.offset.valid.304, %descriptor.extent.inside.302
  %descriptor.range.valid.305 = and i1 %descriptor.range.inside.306, %descriptor.payload.inside.303
  br i1 %descriptor.range.valid.305, label %descriptor.valid.307, label %descriptor.invalid.308
descriptor.invalid.308:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.307:
  %descriptor.initialized.status.309 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.293, i32 %local.check.extent.294)
  %helper.ok.310 = icmp eq i32 %descriptor.initialized.status.309, 0
  br i1 %helper.ok.310, label %helper.continue.311, label %frame.failure.0
helper.continue.311:
  br label %local.descriptor.checked.292
local.descriptor.inactive.291:
  br label %local.descriptor.checked.292
local.descriptor.checked.292:
  %step.status.312 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.313 = icmp eq i32 %step.status.312, 0
  br i1 %helper.ok.313, label %helper.continue.314, label %frame.failure.0
helper.continue.314:
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.316 = load i32, ptr %context.field.315, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %step.status.317 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.318 = icmp eq i32 %step.status.317, 0
  br i1 %helper.ok.318, label %helper.continue.319, label %frame.failure.0
helper.continue.319:
  %local.resolved.offset.320 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.321 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.322 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.323 = load i32, ptr %local.owner.end.6, align 4
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %stack.sub.328 = sub i32 %local.resolved.owner.end.323, %local.resolved.offset.320
  %descriptor.owner.inside.326 = icmp ule i32 %local.resolved.owner.end.323, %context.value.325
  %descriptor.offset.inside.327 = icmp ule i32 %local.resolved.offset.320, %local.resolved.owner.end.323
  %descriptor.extent.inside.329 = icmp ule i32 %local.resolved.extent.321, %stack.sub.328
  %descriptor.payload.inside.330 = icmp ule i32 %local.resolved.payload.322, %local.resolved.extent.321
  %descriptor.owner.offset.valid.331 = and i1 %descriptor.owner.inside.326, %descriptor.offset.inside.327
  %descriptor.range.inside.333 = and i1 %descriptor.owner.offset.valid.331, %descriptor.extent.inside.329
  %descriptor.range.valid.332 = and i1 %descriptor.range.inside.333, %descriptor.payload.inside.330
  %descriptor.type.valid.334 = icmp eq i32 6, 6
  %descriptor.valid.335 = and i1 %descriptor.range.valid.332, %descriptor.type.valid.334
  br i1 %descriptor.valid.335, label %descriptor.valid.336, label %descriptor.invalid.337
descriptor.invalid.337:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.336:
  %descriptor.initialized.status.338 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.320, i32 %local.resolved.extent.321)
  %helper.ok.339 = icmp eq i32 %descriptor.initialized.status.338, 0
  br i1 %helper.ok.339, label %helper.continue.340, label %frame.failure.0
helper.continue.340:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.320, i32 20, i32 %local.resolved.payload.322, i32 %local.resolved.owner.end.323, i32 %local.resolved.extent.321)
  %context.field.341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.342 = load i32, ptr %context.field.341, align 4
  %runtime.ok.343 = icmp eq i32 %context.value.342, 0
  br i1 %runtime.ok.343, label %runtime.continue.344, label %frame.failure.0
runtime.continue.344:
  %context.field.345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.346 = load i32, ptr %context.field.345, align 4
  %stack.sub.349 = sub i32 %local.resolved.owner.end.323, %local.resolved.offset.320
  %descriptor.owner.inside.347 = icmp ule i32 %local.resolved.owner.end.323, %context.value.346
  %descriptor.offset.inside.348 = icmp ule i32 %local.resolved.offset.320, %local.resolved.owner.end.323
  %descriptor.extent.inside.350 = icmp ule i32 %local.resolved.extent.321, %stack.sub.349
  %descriptor.payload.inside.351 = icmp ule i32 %local.resolved.payload.322, %local.resolved.extent.321
  %descriptor.owner.offset.valid.352 = and i1 %descriptor.owner.inside.347, %descriptor.offset.inside.348
  %descriptor.range.inside.354 = and i1 %descriptor.owner.offset.valid.352, %descriptor.extent.inside.350
  %descriptor.range.valid.353 = and i1 %descriptor.range.inside.354, %descriptor.payload.inside.351
  %descriptor.type.valid.355 = icmp eq i32 6, 6
  %descriptor.valid.356 = and i1 %descriptor.range.valid.353, %descriptor.type.valid.355
  br i1 %descriptor.valid.356, label %descriptor.valid.357, label %descriptor.invalid.358
descriptor.invalid.358:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.357:
  %descriptor.initialized.status.359 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.320, i32 %local.resolved.extent.321)
  %helper.ok.360 = icmp eq i32 %descriptor.initialized.status.359, 0
  br i1 %helper.ok.360, label %helper.continue.361, label %frame.failure.0
helper.continue.361:
  %local.is.active.362 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.362, label %local.descriptor.active.363, label %local.descriptor.inactive.364
local.descriptor.active.363:
  %local.check.offset.366 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.367 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.368 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.369 = load i32, ptr %local.owner.end.6, align 4
  %context.field.370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.371 = load i32, ptr %context.field.370, align 4
  %stack.sub.374 = sub i32 %local.check.owner.end.369, %local.check.offset.366
  %descriptor.owner.inside.372 = icmp ule i32 %local.check.owner.end.369, %context.value.371
  %descriptor.offset.inside.373 = icmp ule i32 %local.check.offset.366, %local.check.owner.end.369
  %descriptor.extent.inside.375 = icmp ule i32 %local.check.extent.367, %stack.sub.374
  %descriptor.payload.inside.376 = icmp ule i32 %local.check.payload.368, %local.check.extent.367
  %descriptor.owner.offset.valid.377 = and i1 %descriptor.owner.inside.372, %descriptor.offset.inside.373
  %descriptor.range.inside.379 = and i1 %descriptor.owner.offset.valid.377, %descriptor.extent.inside.375
  %descriptor.range.valid.378 = and i1 %descriptor.range.inside.379, %descriptor.payload.inside.376
  br i1 %descriptor.range.valid.378, label %descriptor.valid.380, label %descriptor.invalid.381
descriptor.invalid.381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.380:
  %descriptor.initialized.status.382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.366, i32 %local.check.extent.367)
  %helper.ok.383 = icmp eq i32 %descriptor.initialized.status.382, 0
  br i1 %helper.ok.383, label %helper.continue.384, label %frame.failure.0
helper.continue.384:
  br label %local.descriptor.checked.365
local.descriptor.inactive.364:
  br label %local.descriptor.checked.365
local.descriptor.checked.365:
  %local.is.active.385 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.385, label %local.descriptor.active.386, label %local.descriptor.inactive.387
local.descriptor.active.386:
  %local.check.offset.389 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.390 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.391 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.392 = load i32, ptr %local.owner.end.12, align 4
  %context.field.393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.394 = load i32, ptr %context.field.393, align 4
  %stack.sub.397 = sub i32 %local.check.owner.end.392, %local.check.offset.389
  %descriptor.owner.inside.395 = icmp ule i32 %local.check.owner.end.392, %context.value.394
  %descriptor.offset.inside.396 = icmp ule i32 %local.check.offset.389, %local.check.owner.end.392
  %descriptor.extent.inside.398 = icmp ule i32 %local.check.extent.390, %stack.sub.397
  %descriptor.payload.inside.399 = icmp ule i32 %local.check.payload.391, %local.check.extent.390
  %descriptor.owner.offset.valid.400 = and i1 %descriptor.owner.inside.395, %descriptor.offset.inside.396
  %descriptor.range.inside.402 = and i1 %descriptor.owner.offset.valid.400, %descriptor.extent.inside.398
  %descriptor.range.valid.401 = and i1 %descriptor.range.inside.402, %descriptor.payload.inside.399
  br i1 %descriptor.range.valid.401, label %descriptor.valid.403, label %descriptor.invalid.404
descriptor.invalid.404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.403:
  %descriptor.initialized.status.405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.389, i32 %local.check.extent.390)
  %helper.ok.406 = icmp eq i32 %descriptor.initialized.status.405, 0
  br i1 %helper.ok.406, label %helper.continue.407, label %frame.failure.0
helper.continue.407:
  br label %local.descriptor.checked.388
local.descriptor.inactive.387:
  br label %local.descriptor.checked.388
local.descriptor.checked.388:
  %local.is.active.408 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.408, label %local.descriptor.active.409, label %local.descriptor.inactive.410
local.descriptor.active.409:
  %local.check.offset.412 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.413 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.414 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.415 = load i32, ptr %local.owner.end.18, align 4
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %stack.sub.420 = sub i32 %local.check.owner.end.415, %local.check.offset.412
  %descriptor.owner.inside.418 = icmp ule i32 %local.check.owner.end.415, %context.value.417
  %descriptor.offset.inside.419 = icmp ule i32 %local.check.offset.412, %local.check.owner.end.415
  %descriptor.extent.inside.421 = icmp ule i32 %local.check.extent.413, %stack.sub.420
  %descriptor.payload.inside.422 = icmp ule i32 %local.check.payload.414, %local.check.extent.413
  %descriptor.owner.offset.valid.423 = and i1 %descriptor.owner.inside.418, %descriptor.offset.inside.419
  %descriptor.range.inside.425 = and i1 %descriptor.owner.offset.valid.423, %descriptor.extent.inside.421
  %descriptor.range.valid.424 = and i1 %descriptor.range.inside.425, %descriptor.payload.inside.422
  br i1 %descriptor.range.valid.424, label %descriptor.valid.426, label %descriptor.invalid.427
descriptor.invalid.427:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.426:
  %descriptor.initialized.status.428 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.412, i32 %local.check.extent.413)
  %helper.ok.429 = icmp eq i32 %descriptor.initialized.status.428, 0
  br i1 %helper.ok.429, label %helper.continue.430, label %frame.failure.0
helper.continue.430:
  br label %local.descriptor.checked.411
local.descriptor.inactive.410:
  br label %local.descriptor.checked.411
local.descriptor.checked.411:
  %local.is.active.431 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.431, label %local.descriptor.active.432, label %local.descriptor.inactive.433
local.descriptor.active.432:
  %local.check.offset.435 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.436 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.437 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.438 = load i32, ptr %local.owner.end.24, align 4
  %context.field.439 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.440 = load i32, ptr %context.field.439, align 4
  %stack.sub.443 = sub i32 %local.check.owner.end.438, %local.check.offset.435
  %descriptor.owner.inside.441 = icmp ule i32 %local.check.owner.end.438, %context.value.440
  %descriptor.offset.inside.442 = icmp ule i32 %local.check.offset.435, %local.check.owner.end.438
  %descriptor.extent.inside.444 = icmp ule i32 %local.check.extent.436, %stack.sub.443
  %descriptor.payload.inside.445 = icmp ule i32 %local.check.payload.437, %local.check.extent.436
  %descriptor.owner.offset.valid.446 = and i1 %descriptor.owner.inside.441, %descriptor.offset.inside.442
  %descriptor.range.inside.448 = and i1 %descriptor.owner.offset.valid.446, %descriptor.extent.inside.444
  %descriptor.range.valid.447 = and i1 %descriptor.range.inside.448, %descriptor.payload.inside.445
  br i1 %descriptor.range.valid.447, label %descriptor.valid.449, label %descriptor.invalid.450
descriptor.invalid.450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.449:
  %descriptor.initialized.status.451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.435, i32 %local.check.extent.436)
  %helper.ok.452 = icmp eq i32 %descriptor.initialized.status.451, 0
  br i1 %helper.ok.452, label %helper.continue.453, label %frame.failure.0
helper.continue.453:
  br label %local.descriptor.checked.434
local.descriptor.inactive.433:
  br label %local.descriptor.checked.434
local.descriptor.checked.434:
  %step.status.454 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.455 = icmp eq i32 %step.status.454, 0
  br i1 %helper.ok.455, label %helper.continue.456, label %frame.failure.0
helper.continue.456:
  store i1 true, ptr %local.active.20, align 1
  store i32 %local.resolved.offset.320, ptr %local.offset.21, align 4
  store i32 %local.resolved.extent.321, ptr %local.extent.22, align 4
  store i32 %local.resolved.payload.322, ptr %local.payload.23, align 4
  store i32 %local.resolved.owner.end.323, ptr %local.owner.end.24, align 4
  store i32 6, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.320, i32 20, i32 %local.resolved.payload.322, i32 %local.resolved.owner.end.323, i32 %local.resolved.extent.321)
  %context.field.457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.458 = load i32, ptr %context.field.457, align 4
  %runtime.ok.459 = icmp eq i32 %context.value.458, 0
  br i1 %runtime.ok.459, label %runtime.continue.460, label %frame.failure.0
runtime.continue.460:
  %local.is.active.461 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.461, label %local.descriptor.active.462, label %local.descriptor.inactive.463
local.descriptor.active.462:
  %local.check.offset.465 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.466 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.467 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.468 = load i32, ptr %local.owner.end.6, align 4
  %context.field.469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.470 = load i32, ptr %context.field.469, align 4
  %stack.sub.473 = sub i32 %local.check.owner.end.468, %local.check.offset.465
  %descriptor.owner.inside.471 = icmp ule i32 %local.check.owner.end.468, %context.value.470
  %descriptor.offset.inside.472 = icmp ule i32 %local.check.offset.465, %local.check.owner.end.468
  %descriptor.extent.inside.474 = icmp ule i32 %local.check.extent.466, %stack.sub.473
  %descriptor.payload.inside.475 = icmp ule i32 %local.check.payload.467, %local.check.extent.466
  %descriptor.owner.offset.valid.476 = and i1 %descriptor.owner.inside.471, %descriptor.offset.inside.472
  %descriptor.range.inside.478 = and i1 %descriptor.owner.offset.valid.476, %descriptor.extent.inside.474
  %descriptor.range.valid.477 = and i1 %descriptor.range.inside.478, %descriptor.payload.inside.475
  br i1 %descriptor.range.valid.477, label %descriptor.valid.479, label %descriptor.invalid.480
descriptor.invalid.480:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.479:
  %descriptor.initialized.status.481 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.465, i32 %local.check.extent.466)
  %helper.ok.482 = icmp eq i32 %descriptor.initialized.status.481, 0
  br i1 %helper.ok.482, label %helper.continue.483, label %frame.failure.0
helper.continue.483:
  br label %local.descriptor.checked.464
local.descriptor.inactive.463:
  br label %local.descriptor.checked.464
local.descriptor.checked.464:
  %local.is.active.484 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.484, label %local.descriptor.active.485, label %local.descriptor.inactive.486
local.descriptor.active.485:
  %local.check.offset.488 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.489 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.490 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.491 = load i32, ptr %local.owner.end.12, align 4
  %context.field.492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.493 = load i32, ptr %context.field.492, align 4
  %stack.sub.496 = sub i32 %local.check.owner.end.491, %local.check.offset.488
  %descriptor.owner.inside.494 = icmp ule i32 %local.check.owner.end.491, %context.value.493
  %descriptor.offset.inside.495 = icmp ule i32 %local.check.offset.488, %local.check.owner.end.491
  %descriptor.extent.inside.497 = icmp ule i32 %local.check.extent.489, %stack.sub.496
  %descriptor.payload.inside.498 = icmp ule i32 %local.check.payload.490, %local.check.extent.489
  %descriptor.owner.offset.valid.499 = and i1 %descriptor.owner.inside.494, %descriptor.offset.inside.495
  %descriptor.range.inside.501 = and i1 %descriptor.owner.offset.valid.499, %descriptor.extent.inside.497
  %descriptor.range.valid.500 = and i1 %descriptor.range.inside.501, %descriptor.payload.inside.498
  br i1 %descriptor.range.valid.500, label %descriptor.valid.502, label %descriptor.invalid.503
descriptor.invalid.503:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.502:
  %descriptor.initialized.status.504 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.488, i32 %local.check.extent.489)
  %helper.ok.505 = icmp eq i32 %descriptor.initialized.status.504, 0
  br i1 %helper.ok.505, label %helper.continue.506, label %frame.failure.0
helper.continue.506:
  br label %local.descriptor.checked.487
local.descriptor.inactive.486:
  br label %local.descriptor.checked.487
local.descriptor.checked.487:
  %local.is.active.507 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.507, label %local.descriptor.active.508, label %local.descriptor.inactive.509
local.descriptor.active.508:
  %local.check.offset.511 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.512 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.513 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.514 = load i32, ptr %local.owner.end.18, align 4
  %context.field.515 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.516 = load i32, ptr %context.field.515, align 4
  %stack.sub.519 = sub i32 %local.check.owner.end.514, %local.check.offset.511
  %descriptor.owner.inside.517 = icmp ule i32 %local.check.owner.end.514, %context.value.516
  %descriptor.offset.inside.518 = icmp ule i32 %local.check.offset.511, %local.check.owner.end.514
  %descriptor.extent.inside.520 = icmp ule i32 %local.check.extent.512, %stack.sub.519
  %descriptor.payload.inside.521 = icmp ule i32 %local.check.payload.513, %local.check.extent.512
  %descriptor.owner.offset.valid.522 = and i1 %descriptor.owner.inside.517, %descriptor.offset.inside.518
  %descriptor.range.inside.524 = and i1 %descriptor.owner.offset.valid.522, %descriptor.extent.inside.520
  %descriptor.range.valid.523 = and i1 %descriptor.range.inside.524, %descriptor.payload.inside.521
  br i1 %descriptor.range.valid.523, label %descriptor.valid.525, label %descriptor.invalid.526
descriptor.invalid.526:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.525:
  %descriptor.initialized.status.527 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.511, i32 %local.check.extent.512)
  %helper.ok.528 = icmp eq i32 %descriptor.initialized.status.527, 0
  br i1 %helper.ok.528, label %helper.continue.529, label %frame.failure.0
helper.continue.529:
  br label %local.descriptor.checked.510
local.descriptor.inactive.509:
  br label %local.descriptor.checked.510
local.descriptor.checked.510:
  %local.is.active.530 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.530, label %local.descriptor.active.531, label %local.descriptor.inactive.532
local.descriptor.active.531:
  %local.check.offset.534 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.535 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.536 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.537 = load i32, ptr %local.owner.end.24, align 4
  %context.field.538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.539 = load i32, ptr %context.field.538, align 4
  %stack.sub.542 = sub i32 %local.check.owner.end.537, %local.check.offset.534
  %descriptor.owner.inside.540 = icmp ule i32 %local.check.owner.end.537, %context.value.539
  %descriptor.offset.inside.541 = icmp ule i32 %local.check.offset.534, %local.check.owner.end.537
  %descriptor.extent.inside.543 = icmp ule i32 %local.check.extent.535, %stack.sub.542
  %descriptor.payload.inside.544 = icmp ule i32 %local.check.payload.536, %local.check.extent.535
  %descriptor.owner.offset.valid.545 = and i1 %descriptor.owner.inside.540, %descriptor.offset.inside.541
  %descriptor.range.inside.547 = and i1 %descriptor.owner.offset.valid.545, %descriptor.extent.inside.543
  %descriptor.range.valid.546 = and i1 %descriptor.range.inside.547, %descriptor.payload.inside.544
  br i1 %descriptor.range.valid.546, label %descriptor.valid.548, label %descriptor.invalid.549
descriptor.invalid.549:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.548:
  %descriptor.initialized.status.550 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.534, i32 %local.check.extent.535)
  %helper.ok.551 = icmp eq i32 %descriptor.initialized.status.550, 0
  br i1 %helper.ok.551, label %helper.continue.552, label %frame.failure.0
helper.continue.552:
  br label %local.descriptor.checked.533
local.descriptor.inactive.532:
  br label %local.descriptor.checked.533
local.descriptor.checked.533:
  %step.status.553 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.554 = icmp eq i32 %step.status.553, 0
  br i1 %helper.ok.554, label %helper.continue.555, label %frame.failure.0
helper.continue.555:
  %local.resolved.offset.556 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.557 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.558 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.559 = load i32, ptr %local.owner.end.24, align 4
  %context.field.560 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.561 = load i32, ptr %context.field.560, align 4
  %stack.sub.564 = sub i32 %local.resolved.owner.end.559, %local.resolved.offset.556
  %descriptor.owner.inside.562 = icmp ule i32 %local.resolved.owner.end.559, %context.value.561
  %descriptor.offset.inside.563 = icmp ule i32 %local.resolved.offset.556, %local.resolved.owner.end.559
  %descriptor.extent.inside.565 = icmp ule i32 %local.resolved.extent.557, %stack.sub.564
  %descriptor.payload.inside.566 = icmp ule i32 %local.resolved.payload.558, %local.resolved.extent.557
  %descriptor.owner.offset.valid.567 = and i1 %descriptor.owner.inside.562, %descriptor.offset.inside.563
  %descriptor.range.inside.569 = and i1 %descriptor.owner.offset.valid.567, %descriptor.extent.inside.565
  %descriptor.range.valid.568 = and i1 %descriptor.range.inside.569, %descriptor.payload.inside.566
  %descriptor.type.valid.570 = icmp eq i32 6, 6
  %descriptor.valid.571 = and i1 %descriptor.range.valid.568, %descriptor.type.valid.570
  br i1 %descriptor.valid.571, label %descriptor.valid.572, label %descriptor.invalid.573
descriptor.invalid.573:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.572:
  %descriptor.initialized.status.574 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557)
  %helper.ok.575 = icmp eq i32 %descriptor.initialized.status.574, 0
  br i1 %helper.ok.575, label %helper.continue.576, label %frame.failure.0
helper.continue.576:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.556, i32 20, i32 %local.resolved.payload.558, i32 %local.resolved.owner.end.559, i32 %local.resolved.extent.557)
  %context.field.577 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.578 = load i32, ptr %context.field.577, align 4
  %runtime.ok.579 = icmp eq i32 %context.value.578, 0
  br i1 %runtime.ok.579, label %runtime.continue.580, label %frame.failure.0
runtime.continue.580:
  %context.field.581 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.582 = load i32, ptr %context.field.581, align 4
  %stack.sub.585 = sub i32 %local.resolved.owner.end.559, %local.resolved.offset.556
  %descriptor.owner.inside.583 = icmp ule i32 %local.resolved.owner.end.559, %context.value.582
  %descriptor.offset.inside.584 = icmp ule i32 %local.resolved.offset.556, %local.resolved.owner.end.559
  %descriptor.extent.inside.586 = icmp ule i32 %local.resolved.extent.557, %stack.sub.585
  %descriptor.payload.inside.587 = icmp ule i32 %local.resolved.payload.558, %local.resolved.extent.557
  %descriptor.owner.offset.valid.588 = and i1 %descriptor.owner.inside.583, %descriptor.offset.inside.584
  %descriptor.range.inside.590 = and i1 %descriptor.owner.offset.valid.588, %descriptor.extent.inside.586
  %descriptor.range.valid.589 = and i1 %descriptor.range.inside.590, %descriptor.payload.inside.587
  %descriptor.type.valid.591 = icmp eq i32 6, 6
  %descriptor.valid.592 = and i1 %descriptor.range.valid.589, %descriptor.type.valid.591
  br i1 %descriptor.valid.592, label %descriptor.valid.593, label %descriptor.invalid.594
descriptor.invalid.594:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.593:
  %descriptor.initialized.status.595 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557)
  %helper.ok.596 = icmp eq i32 %descriptor.initialized.status.595, 0
  br i1 %helper.ok.596, label %helper.continue.597, label %frame.failure.0
helper.continue.597:
  %local.is.active.598 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.598, label %local.descriptor.active.599, label %local.descriptor.inactive.600
local.descriptor.active.599:
  %local.check.offset.602 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.603 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.604 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.605 = load i32, ptr %local.owner.end.6, align 4
  %context.field.606 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.607 = load i32, ptr %context.field.606, align 4
  %stack.sub.610 = sub i32 %local.check.owner.end.605, %local.check.offset.602
  %descriptor.owner.inside.608 = icmp ule i32 %local.check.owner.end.605, %context.value.607
  %descriptor.offset.inside.609 = icmp ule i32 %local.check.offset.602, %local.check.owner.end.605
  %descriptor.extent.inside.611 = icmp ule i32 %local.check.extent.603, %stack.sub.610
  %descriptor.payload.inside.612 = icmp ule i32 %local.check.payload.604, %local.check.extent.603
  %descriptor.owner.offset.valid.613 = and i1 %descriptor.owner.inside.608, %descriptor.offset.inside.609
  %descriptor.range.inside.615 = and i1 %descriptor.owner.offset.valid.613, %descriptor.extent.inside.611
  %descriptor.range.valid.614 = and i1 %descriptor.range.inside.615, %descriptor.payload.inside.612
  br i1 %descriptor.range.valid.614, label %descriptor.valid.616, label %descriptor.invalid.617
descriptor.invalid.617:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.616:
  %descriptor.initialized.status.618 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.602, i32 %local.check.extent.603)
  %helper.ok.619 = icmp eq i32 %descriptor.initialized.status.618, 0
  br i1 %helper.ok.619, label %helper.continue.620, label %frame.failure.0
helper.continue.620:
  br label %local.descriptor.checked.601
local.descriptor.inactive.600:
  br label %local.descriptor.checked.601
local.descriptor.checked.601:
  %local.is.active.621 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.621, label %local.descriptor.active.622, label %local.descriptor.inactive.623
local.descriptor.active.622:
  %local.check.offset.625 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.626 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.627 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.628 = load i32, ptr %local.owner.end.12, align 4
  %context.field.629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.630 = load i32, ptr %context.field.629, align 4
  %stack.sub.633 = sub i32 %local.check.owner.end.628, %local.check.offset.625
  %descriptor.owner.inside.631 = icmp ule i32 %local.check.owner.end.628, %context.value.630
  %descriptor.offset.inside.632 = icmp ule i32 %local.check.offset.625, %local.check.owner.end.628
  %descriptor.extent.inside.634 = icmp ule i32 %local.check.extent.626, %stack.sub.633
  %descriptor.payload.inside.635 = icmp ule i32 %local.check.payload.627, %local.check.extent.626
  %descriptor.owner.offset.valid.636 = and i1 %descriptor.owner.inside.631, %descriptor.offset.inside.632
  %descriptor.range.inside.638 = and i1 %descriptor.owner.offset.valid.636, %descriptor.extent.inside.634
  %descriptor.range.valid.637 = and i1 %descriptor.range.inside.638, %descriptor.payload.inside.635
  br i1 %descriptor.range.valid.637, label %descriptor.valid.639, label %descriptor.invalid.640
descriptor.invalid.640:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.639:
  %descriptor.initialized.status.641 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.625, i32 %local.check.extent.626)
  %helper.ok.642 = icmp eq i32 %descriptor.initialized.status.641, 0
  br i1 %helper.ok.642, label %helper.continue.643, label %frame.failure.0
helper.continue.643:
  br label %local.descriptor.checked.624
local.descriptor.inactive.623:
  br label %local.descriptor.checked.624
local.descriptor.checked.624:
  %local.is.active.644 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.644, label %local.descriptor.active.645, label %local.descriptor.inactive.646
local.descriptor.active.645:
  %local.check.offset.648 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.649 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.650 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.651 = load i32, ptr %local.owner.end.18, align 4
  %context.field.652 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.653 = load i32, ptr %context.field.652, align 4
  %stack.sub.656 = sub i32 %local.check.owner.end.651, %local.check.offset.648
  %descriptor.owner.inside.654 = icmp ule i32 %local.check.owner.end.651, %context.value.653
  %descriptor.offset.inside.655 = icmp ule i32 %local.check.offset.648, %local.check.owner.end.651
  %descriptor.extent.inside.657 = icmp ule i32 %local.check.extent.649, %stack.sub.656
  %descriptor.payload.inside.658 = icmp ule i32 %local.check.payload.650, %local.check.extent.649
  %descriptor.owner.offset.valid.659 = and i1 %descriptor.owner.inside.654, %descriptor.offset.inside.655
  %descriptor.range.inside.661 = and i1 %descriptor.owner.offset.valid.659, %descriptor.extent.inside.657
  %descriptor.range.valid.660 = and i1 %descriptor.range.inside.661, %descriptor.payload.inside.658
  br i1 %descriptor.range.valid.660, label %descriptor.valid.662, label %descriptor.invalid.663
descriptor.invalid.663:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.662:
  %descriptor.initialized.status.664 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.648, i32 %local.check.extent.649)
  %helper.ok.665 = icmp eq i32 %descriptor.initialized.status.664, 0
  br i1 %helper.ok.665, label %helper.continue.666, label %frame.failure.0
helper.continue.666:
  br label %local.descriptor.checked.647
local.descriptor.inactive.646:
  br label %local.descriptor.checked.647
local.descriptor.checked.647:
  %local.is.active.667 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.667, label %local.descriptor.active.668, label %local.descriptor.inactive.669
local.descriptor.active.668:
  %local.check.offset.671 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.672 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.673 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.674 = load i32, ptr %local.owner.end.24, align 4
  %context.field.675 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.676 = load i32, ptr %context.field.675, align 4
  %stack.sub.679 = sub i32 %local.check.owner.end.674, %local.check.offset.671
  %descriptor.owner.inside.677 = icmp ule i32 %local.check.owner.end.674, %context.value.676
  %descriptor.offset.inside.678 = icmp ule i32 %local.check.offset.671, %local.check.owner.end.674
  %descriptor.extent.inside.680 = icmp ule i32 %local.check.extent.672, %stack.sub.679
  %descriptor.payload.inside.681 = icmp ule i32 %local.check.payload.673, %local.check.extent.672
  %descriptor.owner.offset.valid.682 = and i1 %descriptor.owner.inside.677, %descriptor.offset.inside.678
  %descriptor.range.inside.684 = and i1 %descriptor.owner.offset.valid.682, %descriptor.extent.inside.680
  %descriptor.range.valid.683 = and i1 %descriptor.range.inside.684, %descriptor.payload.inside.681
  br i1 %descriptor.range.valid.683, label %descriptor.valid.685, label %descriptor.invalid.686
descriptor.invalid.686:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.685:
  %descriptor.initialized.status.687 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.671, i32 %local.check.extent.672)
  %helper.ok.688 = icmp eq i32 %descriptor.initialized.status.687, 0
  br i1 %helper.ok.688, label %helper.continue.689, label %frame.failure.0
helper.continue.689:
  br label %local.descriptor.checked.670
local.descriptor.inactive.669:
  br label %local.descriptor.checked.670
local.descriptor.checked.670:
  %step.status.690 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.691 = icmp eq i32 %step.status.690, 0
  br i1 %helper.ok.691, label %helper.continue.692, label %frame.failure.0
helper.continue.692:
  %stack.offset.693 = add i32 0, %local.resolved.payload.558
  %stack.offset.694 = add i32 0, %local.resolved.extent.557
  %context.field.695 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.696 = load i32, ptr %context.field.695, align 4
  %stack.offset.697 = add i32 %context.value.696, %stack.offset.694
  %reserve.status.698 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.697, i32 14)
  %reserve.ok.699 = icmp eq i32 %reserve.status.698, 0
  br i1 %reserve.ok.699, label %reserve.continue.700, label %frame.failure.0
reserve.continue.700:
  %stack.offset.701 = add i32 %context.value.696, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.701, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557, i32 %local.resolved.payload.558, i32 6, i32 6)
  %context.field.702 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.703 = load i32, ptr %context.field.702, align 4
  %runtime.ok.704 = icmp eq i32 %context.value.703, 0
  br i1 %runtime.ok.704, label %runtime.continue.705, label %frame.failure.0
runtime.continue.705:
  %stack.offset.706 = add i32 0, %local.resolved.extent.557
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.696, i32 %stack.offset.694, i32 %stack.offset.693, i32 0, i32 0)
  %context.field.707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.708 = load i32, ptr %context.field.707, align 4
  %runtime.ok.709 = icmp eq i32 %context.value.708, 0
  br i1 %runtime.ok.709, label %runtime.continue.710, label %frame.failure.0
runtime.continue.710:
  %context.field.711 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.712 = load i32, ptr %context.field.711, align 4
  %stack.sub.715 = sub i32 %stack.offset.697, %context.value.696
  %descriptor.owner.inside.713 = icmp ule i32 %stack.offset.697, %context.value.712
  %descriptor.offset.inside.714 = icmp ule i32 %context.value.696, %stack.offset.697
  %descriptor.extent.inside.716 = icmp ule i32 %stack.offset.694, %stack.sub.715
  %descriptor.payload.inside.717 = icmp ule i32 %stack.offset.693, %stack.offset.694
  %descriptor.owner.offset.valid.718 = and i1 %descriptor.owner.inside.713, %descriptor.offset.inside.714
  %descriptor.range.inside.720 = and i1 %descriptor.owner.offset.valid.718, %descriptor.extent.inside.716
  %descriptor.range.valid.719 = and i1 %descriptor.range.inside.720, %descriptor.payload.inside.717
  %descriptor.type.valid.721 = icmp eq i32 4, 4
  %descriptor.valid.722 = and i1 %descriptor.range.valid.719, %descriptor.type.valid.721
  br i1 %descriptor.valid.722, label %descriptor.valid.723, label %descriptor.invalid.724
descriptor.invalid.724:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.723:
  %descriptor.initialized.status.725 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.696, i32 %stack.offset.694)
  %helper.ok.726 = icmp eq i32 %descriptor.initialized.status.725, 0
  br i1 %helper.ok.726, label %helper.continue.727, label %frame.failure.0
helper.continue.727:
  %local.is.active.728 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.728, label %local.descriptor.active.729, label %local.descriptor.inactive.730
local.descriptor.active.729:
  %local.check.offset.732 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.733 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.734 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.735 = load i32, ptr %local.owner.end.6, align 4
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.737 = load i32, ptr %context.field.736, align 4
  %stack.sub.740 = sub i32 %local.check.owner.end.735, %local.check.offset.732
  %descriptor.owner.inside.738 = icmp ule i32 %local.check.owner.end.735, %context.value.737
  %descriptor.offset.inside.739 = icmp ule i32 %local.check.offset.732, %local.check.owner.end.735
  %descriptor.extent.inside.741 = icmp ule i32 %local.check.extent.733, %stack.sub.740
  %descriptor.payload.inside.742 = icmp ule i32 %local.check.payload.734, %local.check.extent.733
  %descriptor.owner.offset.valid.743 = and i1 %descriptor.owner.inside.738, %descriptor.offset.inside.739
  %descriptor.range.inside.745 = and i1 %descriptor.owner.offset.valid.743, %descriptor.extent.inside.741
  %descriptor.range.valid.744 = and i1 %descriptor.range.inside.745, %descriptor.payload.inside.742
  br i1 %descriptor.range.valid.744, label %descriptor.valid.746, label %descriptor.invalid.747
descriptor.invalid.747:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.746:
  %descriptor.initialized.status.748 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.732, i32 %local.check.extent.733)
  %helper.ok.749 = icmp eq i32 %descriptor.initialized.status.748, 0
  br i1 %helper.ok.749, label %helper.continue.750, label %frame.failure.0
helper.continue.750:
  br label %local.descriptor.checked.731
local.descriptor.inactive.730:
  br label %local.descriptor.checked.731
local.descriptor.checked.731:
  %local.is.active.751 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.751, label %local.descriptor.active.752, label %local.descriptor.inactive.753
local.descriptor.active.752:
  %local.check.offset.755 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.756 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.757 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.758 = load i32, ptr %local.owner.end.12, align 4
  %context.field.759 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.760 = load i32, ptr %context.field.759, align 4
  %stack.sub.763 = sub i32 %local.check.owner.end.758, %local.check.offset.755
  %descriptor.owner.inside.761 = icmp ule i32 %local.check.owner.end.758, %context.value.760
  %descriptor.offset.inside.762 = icmp ule i32 %local.check.offset.755, %local.check.owner.end.758
  %descriptor.extent.inside.764 = icmp ule i32 %local.check.extent.756, %stack.sub.763
  %descriptor.payload.inside.765 = icmp ule i32 %local.check.payload.757, %local.check.extent.756
  %descriptor.owner.offset.valid.766 = and i1 %descriptor.owner.inside.761, %descriptor.offset.inside.762
  %descriptor.range.inside.768 = and i1 %descriptor.owner.offset.valid.766, %descriptor.extent.inside.764
  %descriptor.range.valid.767 = and i1 %descriptor.range.inside.768, %descriptor.payload.inside.765
  br i1 %descriptor.range.valid.767, label %descriptor.valid.769, label %descriptor.invalid.770
descriptor.invalid.770:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.769:
  %descriptor.initialized.status.771 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.755, i32 %local.check.extent.756)
  %helper.ok.772 = icmp eq i32 %descriptor.initialized.status.771, 0
  br i1 %helper.ok.772, label %helper.continue.773, label %frame.failure.0
helper.continue.773:
  br label %local.descriptor.checked.754
local.descriptor.inactive.753:
  br label %local.descriptor.checked.754
local.descriptor.checked.754:
  %local.is.active.774 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.774, label %local.descriptor.active.775, label %local.descriptor.inactive.776
local.descriptor.active.775:
  %local.check.offset.778 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.779 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.780 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.781 = load i32, ptr %local.owner.end.18, align 4
  %context.field.782 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.783 = load i32, ptr %context.field.782, align 4
  %stack.sub.786 = sub i32 %local.check.owner.end.781, %local.check.offset.778
  %descriptor.owner.inside.784 = icmp ule i32 %local.check.owner.end.781, %context.value.783
  %descriptor.offset.inside.785 = icmp ule i32 %local.check.offset.778, %local.check.owner.end.781
  %descriptor.extent.inside.787 = icmp ule i32 %local.check.extent.779, %stack.sub.786
  %descriptor.payload.inside.788 = icmp ule i32 %local.check.payload.780, %local.check.extent.779
  %descriptor.owner.offset.valid.789 = and i1 %descriptor.owner.inside.784, %descriptor.offset.inside.785
  %descriptor.range.inside.791 = and i1 %descriptor.owner.offset.valid.789, %descriptor.extent.inside.787
  %descriptor.range.valid.790 = and i1 %descriptor.range.inside.791, %descriptor.payload.inside.788
  br i1 %descriptor.range.valid.790, label %descriptor.valid.792, label %descriptor.invalid.793
descriptor.invalid.793:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.792:
  %descriptor.initialized.status.794 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.778, i32 %local.check.extent.779)
  %helper.ok.795 = icmp eq i32 %descriptor.initialized.status.794, 0
  br i1 %helper.ok.795, label %helper.continue.796, label %frame.failure.0
helper.continue.796:
  br label %local.descriptor.checked.777
local.descriptor.inactive.776:
  br label %local.descriptor.checked.777
local.descriptor.checked.777:
  %local.is.active.797 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.797, label %local.descriptor.active.798, label %local.descriptor.inactive.799
local.descriptor.active.798:
  %local.check.offset.801 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.802 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.803 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.804 = load i32, ptr %local.owner.end.24, align 4
  %context.field.805 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.806 = load i32, ptr %context.field.805, align 4
  %stack.sub.809 = sub i32 %local.check.owner.end.804, %local.check.offset.801
  %descriptor.owner.inside.807 = icmp ule i32 %local.check.owner.end.804, %context.value.806
  %descriptor.offset.inside.808 = icmp ule i32 %local.check.offset.801, %local.check.owner.end.804
  %descriptor.extent.inside.810 = icmp ule i32 %local.check.extent.802, %stack.sub.809
  %descriptor.payload.inside.811 = icmp ule i32 %local.check.payload.803, %local.check.extent.802
  %descriptor.owner.offset.valid.812 = and i1 %descriptor.owner.inside.807, %descriptor.offset.inside.808
  %descriptor.range.inside.814 = and i1 %descriptor.owner.offset.valid.812, %descriptor.extent.inside.810
  %descriptor.range.valid.813 = and i1 %descriptor.range.inside.814, %descriptor.payload.inside.811
  br i1 %descriptor.range.valid.813, label %descriptor.valid.815, label %descriptor.invalid.816
descriptor.invalid.816:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.815:
  %descriptor.initialized.status.817 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.801, i32 %local.check.extent.802)
  %helper.ok.818 = icmp eq i32 %descriptor.initialized.status.817, 0
  br i1 %helper.ok.818, label %helper.continue.819, label %frame.failure.0
helper.continue.819:
  br label %local.descriptor.checked.800
local.descriptor.inactive.799:
  br label %local.descriptor.checked.800
local.descriptor.checked.800:
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.820 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.821 = load i32, ptr %context.field.820, align 4
  %stack.sub.824 = sub i32 %stack.offset.697, %context.value.696
  %descriptor.owner.inside.822 = icmp ule i32 %stack.offset.697, %context.value.821
  %descriptor.offset.inside.823 = icmp ule i32 %context.value.696, %stack.offset.697
  %descriptor.extent.inside.825 = icmp ule i32 %stack.offset.694, %stack.sub.824
  %descriptor.payload.inside.826 = icmp ule i32 %stack.offset.693, %stack.offset.694
  %descriptor.owner.offset.valid.827 = and i1 %descriptor.owner.inside.822, %descriptor.offset.inside.823
  %descriptor.range.inside.829 = and i1 %descriptor.owner.offset.valid.827, %descriptor.extent.inside.825
  %descriptor.range.valid.828 = and i1 %descriptor.range.inside.829, %descriptor.payload.inside.826
  %descriptor.type.valid.830 = icmp eq i32 4, 4
  %descriptor.valid.831 = and i1 %descriptor.range.valid.828, %descriptor.type.valid.830
  br i1 %descriptor.valid.831, label %descriptor.valid.832, label %descriptor.invalid.833
descriptor.invalid.833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.832:
  %descriptor.initialized.status.834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.696, i32 %stack.offset.694)
  %helper.ok.835 = icmp eq i32 %descriptor.initialized.status.834, 0
  br i1 %helper.ok.835, label %helper.continue.836, label %frame.failure.0
helper.continue.836:
  %local.is.active.837 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.837, label %local.descriptor.active.838, label %local.descriptor.inactive.839
local.descriptor.active.838:
  %local.check.offset.841 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.842 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.843 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.844 = load i32, ptr %local.owner.end.6, align 4
  %context.field.845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.846 = load i32, ptr %context.field.845, align 4
  %stack.sub.849 = sub i32 %local.check.owner.end.844, %local.check.offset.841
  %descriptor.owner.inside.847 = icmp ule i32 %local.check.owner.end.844, %context.value.846
  %descriptor.offset.inside.848 = icmp ule i32 %local.check.offset.841, %local.check.owner.end.844
  %descriptor.extent.inside.850 = icmp ule i32 %local.check.extent.842, %stack.sub.849
  %descriptor.payload.inside.851 = icmp ule i32 %local.check.payload.843, %local.check.extent.842
  %descriptor.owner.offset.valid.852 = and i1 %descriptor.owner.inside.847, %descriptor.offset.inside.848
  %descriptor.range.inside.854 = and i1 %descriptor.owner.offset.valid.852, %descriptor.extent.inside.850
  %descriptor.range.valid.853 = and i1 %descriptor.range.inside.854, %descriptor.payload.inside.851
  br i1 %descriptor.range.valid.853, label %descriptor.valid.855, label %descriptor.invalid.856
descriptor.invalid.856:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.855:
  %descriptor.initialized.status.857 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.841, i32 %local.check.extent.842)
  %helper.ok.858 = icmp eq i32 %descriptor.initialized.status.857, 0
  br i1 %helper.ok.858, label %helper.continue.859, label %frame.failure.0
helper.continue.859:
  br label %local.descriptor.checked.840
local.descriptor.inactive.839:
  br label %local.descriptor.checked.840
local.descriptor.checked.840:
  %local.is.active.860 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.860, label %local.descriptor.active.861, label %local.descriptor.inactive.862
local.descriptor.active.861:
  %local.check.offset.864 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.865 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.866 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.867 = load i32, ptr %local.owner.end.12, align 4
  %context.field.868 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.869 = load i32, ptr %context.field.868, align 4
  %stack.sub.872 = sub i32 %local.check.owner.end.867, %local.check.offset.864
  %descriptor.owner.inside.870 = icmp ule i32 %local.check.owner.end.867, %context.value.869
  %descriptor.offset.inside.871 = icmp ule i32 %local.check.offset.864, %local.check.owner.end.867
  %descriptor.extent.inside.873 = icmp ule i32 %local.check.extent.865, %stack.sub.872
  %descriptor.payload.inside.874 = icmp ule i32 %local.check.payload.866, %local.check.extent.865
  %descriptor.owner.offset.valid.875 = and i1 %descriptor.owner.inside.870, %descriptor.offset.inside.871
  %descriptor.range.inside.877 = and i1 %descriptor.owner.offset.valid.875, %descriptor.extent.inside.873
  %descriptor.range.valid.876 = and i1 %descriptor.range.inside.877, %descriptor.payload.inside.874
  br i1 %descriptor.range.valid.876, label %descriptor.valid.878, label %descriptor.invalid.879
descriptor.invalid.879:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.878:
  %descriptor.initialized.status.880 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.864, i32 %local.check.extent.865)
  %helper.ok.881 = icmp eq i32 %descriptor.initialized.status.880, 0
  br i1 %helper.ok.881, label %helper.continue.882, label %frame.failure.0
helper.continue.882:
  br label %local.descriptor.checked.863
local.descriptor.inactive.862:
  br label %local.descriptor.checked.863
local.descriptor.checked.863:
  %local.is.active.883 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.883, label %local.descriptor.active.884, label %local.descriptor.inactive.885
local.descriptor.active.884:
  %local.check.offset.887 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.888 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.889 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.890 = load i32, ptr %local.owner.end.18, align 4
  %context.field.891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.892 = load i32, ptr %context.field.891, align 4
  %stack.sub.895 = sub i32 %local.check.owner.end.890, %local.check.offset.887
  %descriptor.owner.inside.893 = icmp ule i32 %local.check.owner.end.890, %context.value.892
  %descriptor.offset.inside.894 = icmp ule i32 %local.check.offset.887, %local.check.owner.end.890
  %descriptor.extent.inside.896 = icmp ule i32 %local.check.extent.888, %stack.sub.895
  %descriptor.payload.inside.897 = icmp ule i32 %local.check.payload.889, %local.check.extent.888
  %descriptor.owner.offset.valid.898 = and i1 %descriptor.owner.inside.893, %descriptor.offset.inside.894
  %descriptor.range.inside.900 = and i1 %descriptor.owner.offset.valid.898, %descriptor.extent.inside.896
  %descriptor.range.valid.899 = and i1 %descriptor.range.inside.900, %descriptor.payload.inside.897
  br i1 %descriptor.range.valid.899, label %descriptor.valid.901, label %descriptor.invalid.902
descriptor.invalid.902:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.901:
  %descriptor.initialized.status.903 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.887, i32 %local.check.extent.888)
  %helper.ok.904 = icmp eq i32 %descriptor.initialized.status.903, 0
  br i1 %helper.ok.904, label %helper.continue.905, label %frame.failure.0
helper.continue.905:
  br label %local.descriptor.checked.886
local.descriptor.inactive.885:
  br label %local.descriptor.checked.886
local.descriptor.checked.886:
  %local.is.active.906 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.906, label %local.descriptor.active.907, label %local.descriptor.inactive.908
local.descriptor.active.907:
  %local.check.offset.910 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.911 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.912 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.913 = load i32, ptr %local.owner.end.24, align 4
  %context.field.914 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.915 = load i32, ptr %context.field.914, align 4
  %stack.sub.918 = sub i32 %local.check.owner.end.913, %local.check.offset.910
  %descriptor.owner.inside.916 = icmp ule i32 %local.check.owner.end.913, %context.value.915
  %descriptor.offset.inside.917 = icmp ule i32 %local.check.offset.910, %local.check.owner.end.913
  %descriptor.extent.inside.919 = icmp ule i32 %local.check.extent.911, %stack.sub.918
  %descriptor.payload.inside.920 = icmp ule i32 %local.check.payload.912, %local.check.extent.911
  %descriptor.owner.offset.valid.921 = and i1 %descriptor.owner.inside.916, %descriptor.offset.inside.917
  %descriptor.range.inside.923 = and i1 %descriptor.owner.offset.valid.921, %descriptor.extent.inside.919
  %descriptor.range.valid.922 = and i1 %descriptor.range.inside.923, %descriptor.payload.inside.920
  br i1 %descriptor.range.valid.922, label %descriptor.valid.924, label %descriptor.invalid.925
descriptor.invalid.925:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.924:
  %descriptor.initialized.status.926 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.910, i32 %local.check.extent.911)
  %helper.ok.927 = icmp eq i32 %descriptor.initialized.status.926, 0
  br i1 %helper.ok.927, label %helper.continue.928, label %frame.failure.0
helper.continue.928:
  br label %local.descriptor.checked.909
local.descriptor.inactive.908:
  br label %local.descriptor.checked.909
local.descriptor.checked.909:
  %step.status.929 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.930 = icmp eq i32 %step.status.929, 0
  br i1 %helper.ok.930, label %helper.continue.931, label %frame.failure.0
helper.continue.931:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.696, ptr %local.offset.15, align 4
  store i32 %stack.offset.694, ptr %local.extent.16, align 4
  store i32 %stack.offset.693, ptr %local.payload.17, align 4
  store i32 %stack.offset.697, ptr %local.owner.end.18, align 4
  store i32 4, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.696, i32 20, i32 %stack.offset.693, i32 %stack.offset.697, i32 %stack.offset.694)
  %context.field.932 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.933 = load i32, ptr %context.field.932, align 4
  %runtime.ok.934 = icmp eq i32 %context.value.933, 0
  br i1 %runtime.ok.934, label %runtime.continue.935, label %frame.failure.0
runtime.continue.935:
  %local.is.active.936 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.936, label %local.descriptor.active.937, label %local.descriptor.inactive.938
local.descriptor.active.937:
  %local.check.offset.940 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.941 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.942 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.943 = load i32, ptr %local.owner.end.6, align 4
  %context.field.944 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.945 = load i32, ptr %context.field.944, align 4
  %stack.sub.948 = sub i32 %local.check.owner.end.943, %local.check.offset.940
  %descriptor.owner.inside.946 = icmp ule i32 %local.check.owner.end.943, %context.value.945
  %descriptor.offset.inside.947 = icmp ule i32 %local.check.offset.940, %local.check.owner.end.943
  %descriptor.extent.inside.949 = icmp ule i32 %local.check.extent.941, %stack.sub.948
  %descriptor.payload.inside.950 = icmp ule i32 %local.check.payload.942, %local.check.extent.941
  %descriptor.owner.offset.valid.951 = and i1 %descriptor.owner.inside.946, %descriptor.offset.inside.947
  %descriptor.range.inside.953 = and i1 %descriptor.owner.offset.valid.951, %descriptor.extent.inside.949
  %descriptor.range.valid.952 = and i1 %descriptor.range.inside.953, %descriptor.payload.inside.950
  br i1 %descriptor.range.valid.952, label %descriptor.valid.954, label %descriptor.invalid.955
descriptor.invalid.955:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.954:
  %descriptor.initialized.status.956 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.940, i32 %local.check.extent.941)
  %helper.ok.957 = icmp eq i32 %descriptor.initialized.status.956, 0
  br i1 %helper.ok.957, label %helper.continue.958, label %frame.failure.0
helper.continue.958:
  br label %local.descriptor.checked.939
local.descriptor.inactive.938:
  br label %local.descriptor.checked.939
local.descriptor.checked.939:
  %local.is.active.959 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.959, label %local.descriptor.active.960, label %local.descriptor.inactive.961
local.descriptor.active.960:
  %local.check.offset.963 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.964 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.965 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.966 = load i32, ptr %local.owner.end.12, align 4
  %context.field.967 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.968 = load i32, ptr %context.field.967, align 4
  %stack.sub.971 = sub i32 %local.check.owner.end.966, %local.check.offset.963
  %descriptor.owner.inside.969 = icmp ule i32 %local.check.owner.end.966, %context.value.968
  %descriptor.offset.inside.970 = icmp ule i32 %local.check.offset.963, %local.check.owner.end.966
  %descriptor.extent.inside.972 = icmp ule i32 %local.check.extent.964, %stack.sub.971
  %descriptor.payload.inside.973 = icmp ule i32 %local.check.payload.965, %local.check.extent.964
  %descriptor.owner.offset.valid.974 = and i1 %descriptor.owner.inside.969, %descriptor.offset.inside.970
  %descriptor.range.inside.976 = and i1 %descriptor.owner.offset.valid.974, %descriptor.extent.inside.972
  %descriptor.range.valid.975 = and i1 %descriptor.range.inside.976, %descriptor.payload.inside.973
  br i1 %descriptor.range.valid.975, label %descriptor.valid.977, label %descriptor.invalid.978
descriptor.invalid.978:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.977:
  %descriptor.initialized.status.979 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.963, i32 %local.check.extent.964)
  %helper.ok.980 = icmp eq i32 %descriptor.initialized.status.979, 0
  br i1 %helper.ok.980, label %helper.continue.981, label %frame.failure.0
helper.continue.981:
  br label %local.descriptor.checked.962
local.descriptor.inactive.961:
  br label %local.descriptor.checked.962
local.descriptor.checked.962:
  %local.is.active.982 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.982, label %local.descriptor.active.983, label %local.descriptor.inactive.984
local.descriptor.active.983:
  %local.check.offset.986 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.987 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.988 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.989 = load i32, ptr %local.owner.end.18, align 4
  %context.field.990 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.991 = load i32, ptr %context.field.990, align 4
  %stack.sub.994 = sub i32 %local.check.owner.end.989, %local.check.offset.986
  %descriptor.owner.inside.992 = icmp ule i32 %local.check.owner.end.989, %context.value.991
  %descriptor.offset.inside.993 = icmp ule i32 %local.check.offset.986, %local.check.owner.end.989
  %descriptor.extent.inside.995 = icmp ule i32 %local.check.extent.987, %stack.sub.994
  %descriptor.payload.inside.996 = icmp ule i32 %local.check.payload.988, %local.check.extent.987
  %descriptor.owner.offset.valid.997 = and i1 %descriptor.owner.inside.992, %descriptor.offset.inside.993
  %descriptor.range.inside.999 = and i1 %descriptor.owner.offset.valid.997, %descriptor.extent.inside.995
  %descriptor.range.valid.998 = and i1 %descriptor.range.inside.999, %descriptor.payload.inside.996
  br i1 %descriptor.range.valid.998, label %descriptor.valid.1000, label %descriptor.invalid.1001
descriptor.invalid.1001:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1000:
  %descriptor.initialized.status.1002 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.986, i32 %local.check.extent.987)
  %helper.ok.1003 = icmp eq i32 %descriptor.initialized.status.1002, 0
  br i1 %helper.ok.1003, label %helper.continue.1004, label %frame.failure.0
helper.continue.1004:
  br label %local.descriptor.checked.985
local.descriptor.inactive.984:
  br label %local.descriptor.checked.985
local.descriptor.checked.985:
  %local.is.active.1005 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1005, label %local.descriptor.active.1006, label %local.descriptor.inactive.1007
local.descriptor.active.1006:
  %local.check.offset.1009 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1010 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1011 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1012 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1014 = load i32, ptr %context.field.1013, align 4
  %stack.sub.1017 = sub i32 %local.check.owner.end.1012, %local.check.offset.1009
  %descriptor.owner.inside.1015 = icmp ule i32 %local.check.owner.end.1012, %context.value.1014
  %descriptor.offset.inside.1016 = icmp ule i32 %local.check.offset.1009, %local.check.owner.end.1012
  %descriptor.extent.inside.1018 = icmp ule i32 %local.check.extent.1010, %stack.sub.1017
  %descriptor.payload.inside.1019 = icmp ule i32 %local.check.payload.1011, %local.check.extent.1010
  %descriptor.owner.offset.valid.1020 = and i1 %descriptor.owner.inside.1015, %descriptor.offset.inside.1016
  %descriptor.range.inside.1022 = and i1 %descriptor.owner.offset.valid.1020, %descriptor.extent.inside.1018
  %descriptor.range.valid.1021 = and i1 %descriptor.range.inside.1022, %descriptor.payload.inside.1019
  br i1 %descriptor.range.valid.1021, label %descriptor.valid.1023, label %descriptor.invalid.1024
descriptor.invalid.1024:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1023:
  %descriptor.initialized.status.1025 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1009, i32 %local.check.extent.1010)
  %helper.ok.1026 = icmp eq i32 %descriptor.initialized.status.1025, 0
  br i1 %helper.ok.1026, label %helper.continue.1027, label %frame.failure.0
helper.continue.1027:
  br label %local.descriptor.checked.1008
local.descriptor.inactive.1007:
  br label %local.descriptor.checked.1008
local.descriptor.checked.1008:
  %step.status.1028 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.1029 = icmp eq i32 %step.status.1028, 0
  br i1 %helper.ok.1029, label %helper.continue.1030, label %frame.failure.0
helper.continue.1030:
  %local.resolved.offset.1031 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.1032 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.1033 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.1034 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1035 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1036 = load i32, ptr %context.field.1035, align 4
  %stack.sub.1039 = sub i32 %local.resolved.owner.end.1034, %local.resolved.offset.1031
  %descriptor.owner.inside.1037 = icmp ule i32 %local.resolved.owner.end.1034, %context.value.1036
  %descriptor.offset.inside.1038 = icmp ule i32 %local.resolved.offset.1031, %local.resolved.owner.end.1034
  %descriptor.extent.inside.1040 = icmp ule i32 %local.resolved.extent.1032, %stack.sub.1039
  %descriptor.payload.inside.1041 = icmp ule i32 %local.resolved.payload.1033, %local.resolved.extent.1032
  %descriptor.owner.offset.valid.1042 = and i1 %descriptor.owner.inside.1037, %descriptor.offset.inside.1038
  %descriptor.range.inside.1044 = and i1 %descriptor.owner.offset.valid.1042, %descriptor.extent.inside.1040
  %descriptor.range.valid.1043 = and i1 %descriptor.range.inside.1044, %descriptor.payload.inside.1041
  %descriptor.type.valid.1045 = icmp eq i32 5, 5
  %descriptor.valid.1046 = and i1 %descriptor.range.valid.1043, %descriptor.type.valid.1045
  br i1 %descriptor.valid.1046, label %descriptor.valid.1047, label %descriptor.invalid.1048
descriptor.invalid.1048:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1047:
  %descriptor.initialized.status.1049 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1031, i32 %local.resolved.extent.1032)
  %helper.ok.1050 = icmp eq i32 %descriptor.initialized.status.1049, 0
  br i1 %helper.ok.1050, label %helper.continue.1051, label %frame.failure.0
helper.continue.1051:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.1031, i32 20, i32 %local.resolved.payload.1033, i32 %local.resolved.owner.end.1034, i32 %local.resolved.extent.1032)
  %context.field.1052 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1053 = load i32, ptr %context.field.1052, align 4
  %runtime.ok.1054 = icmp eq i32 %context.value.1053, 0
  br i1 %runtime.ok.1054, label %runtime.continue.1055, label %frame.failure.0
runtime.continue.1055:
  %context.field.1056 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1057 = load i32, ptr %context.field.1056, align 4
  %stack.sub.1060 = sub i32 %local.resolved.owner.end.1034, %local.resolved.offset.1031
  %descriptor.owner.inside.1058 = icmp ule i32 %local.resolved.owner.end.1034, %context.value.1057
  %descriptor.offset.inside.1059 = icmp ule i32 %local.resolved.offset.1031, %local.resolved.owner.end.1034
  %descriptor.extent.inside.1061 = icmp ule i32 %local.resolved.extent.1032, %stack.sub.1060
  %descriptor.payload.inside.1062 = icmp ule i32 %local.resolved.payload.1033, %local.resolved.extent.1032
  %descriptor.owner.offset.valid.1063 = and i1 %descriptor.owner.inside.1058, %descriptor.offset.inside.1059
  %descriptor.range.inside.1065 = and i1 %descriptor.owner.offset.valid.1063, %descriptor.extent.inside.1061
  %descriptor.range.valid.1064 = and i1 %descriptor.range.inside.1065, %descriptor.payload.inside.1062
  %descriptor.type.valid.1066 = icmp eq i32 5, 5
  %descriptor.valid.1067 = and i1 %descriptor.range.valid.1064, %descriptor.type.valid.1066
  br i1 %descriptor.valid.1067, label %descriptor.valid.1068, label %descriptor.invalid.1069
descriptor.invalid.1069:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1068:
  %descriptor.initialized.status.1070 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1031, i32 %local.resolved.extent.1032)
  %helper.ok.1071 = icmp eq i32 %descriptor.initialized.status.1070, 0
  br i1 %helper.ok.1071, label %helper.continue.1072, label %frame.failure.0
helper.continue.1072:
  %local.is.active.1073 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1073, label %local.descriptor.active.1074, label %local.descriptor.inactive.1075
local.descriptor.active.1074:
  %local.check.offset.1077 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1078 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1079 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1080 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1081 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1082 = load i32, ptr %context.field.1081, align 4
  %stack.sub.1085 = sub i32 %local.check.owner.end.1080, %local.check.offset.1077
  %descriptor.owner.inside.1083 = icmp ule i32 %local.check.owner.end.1080, %context.value.1082
  %descriptor.offset.inside.1084 = icmp ule i32 %local.check.offset.1077, %local.check.owner.end.1080
  %descriptor.extent.inside.1086 = icmp ule i32 %local.check.extent.1078, %stack.sub.1085
  %descriptor.payload.inside.1087 = icmp ule i32 %local.check.payload.1079, %local.check.extent.1078
  %descriptor.owner.offset.valid.1088 = and i1 %descriptor.owner.inside.1083, %descriptor.offset.inside.1084
  %descriptor.range.inside.1090 = and i1 %descriptor.owner.offset.valid.1088, %descriptor.extent.inside.1086
  %descriptor.range.valid.1089 = and i1 %descriptor.range.inside.1090, %descriptor.payload.inside.1087
  br i1 %descriptor.range.valid.1089, label %descriptor.valid.1091, label %descriptor.invalid.1092
descriptor.invalid.1092:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1091:
  %descriptor.initialized.status.1093 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1077, i32 %local.check.extent.1078)
  %helper.ok.1094 = icmp eq i32 %descriptor.initialized.status.1093, 0
  br i1 %helper.ok.1094, label %helper.continue.1095, label %frame.failure.0
helper.continue.1095:
  br label %local.descriptor.checked.1076
local.descriptor.inactive.1075:
  br label %local.descriptor.checked.1076
local.descriptor.checked.1076:
  %local.is.active.1096 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1096, label %local.descriptor.active.1097, label %local.descriptor.inactive.1098
local.descriptor.active.1097:
  %local.check.offset.1100 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1101 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1102 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1103 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1105 = load i32, ptr %context.field.1104, align 4
  %stack.sub.1108 = sub i32 %local.check.owner.end.1103, %local.check.offset.1100
  %descriptor.owner.inside.1106 = icmp ule i32 %local.check.owner.end.1103, %context.value.1105
  %descriptor.offset.inside.1107 = icmp ule i32 %local.check.offset.1100, %local.check.owner.end.1103
  %descriptor.extent.inside.1109 = icmp ule i32 %local.check.extent.1101, %stack.sub.1108
  %descriptor.payload.inside.1110 = icmp ule i32 %local.check.payload.1102, %local.check.extent.1101
  %descriptor.owner.offset.valid.1111 = and i1 %descriptor.owner.inside.1106, %descriptor.offset.inside.1107
  %descriptor.range.inside.1113 = and i1 %descriptor.owner.offset.valid.1111, %descriptor.extent.inside.1109
  %descriptor.range.valid.1112 = and i1 %descriptor.range.inside.1113, %descriptor.payload.inside.1110
  br i1 %descriptor.range.valid.1112, label %descriptor.valid.1114, label %descriptor.invalid.1115
descriptor.invalid.1115:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1114:
  %descriptor.initialized.status.1116 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1100, i32 %local.check.extent.1101)
  %helper.ok.1117 = icmp eq i32 %descriptor.initialized.status.1116, 0
  br i1 %helper.ok.1117, label %helper.continue.1118, label %frame.failure.0
helper.continue.1118:
  br label %local.descriptor.checked.1099
local.descriptor.inactive.1098:
  br label %local.descriptor.checked.1099
local.descriptor.checked.1099:
  %local.is.active.1119 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1119, label %local.descriptor.active.1120, label %local.descriptor.inactive.1121
local.descriptor.active.1120:
  %local.check.offset.1123 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1124 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1125 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1126 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1128 = load i32, ptr %context.field.1127, align 4
  %stack.sub.1131 = sub i32 %local.check.owner.end.1126, %local.check.offset.1123
  %descriptor.owner.inside.1129 = icmp ule i32 %local.check.owner.end.1126, %context.value.1128
  %descriptor.offset.inside.1130 = icmp ule i32 %local.check.offset.1123, %local.check.owner.end.1126
  %descriptor.extent.inside.1132 = icmp ule i32 %local.check.extent.1124, %stack.sub.1131
  %descriptor.payload.inside.1133 = icmp ule i32 %local.check.payload.1125, %local.check.extent.1124
  %descriptor.owner.offset.valid.1134 = and i1 %descriptor.owner.inside.1129, %descriptor.offset.inside.1130
  %descriptor.range.inside.1136 = and i1 %descriptor.owner.offset.valid.1134, %descriptor.extent.inside.1132
  %descriptor.range.valid.1135 = and i1 %descriptor.range.inside.1136, %descriptor.payload.inside.1133
  br i1 %descriptor.range.valid.1135, label %descriptor.valid.1137, label %descriptor.invalid.1138
descriptor.invalid.1138:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1137:
  %descriptor.initialized.status.1139 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1123, i32 %local.check.extent.1124)
  %helper.ok.1140 = icmp eq i32 %descriptor.initialized.status.1139, 0
  br i1 %helper.ok.1140, label %helper.continue.1141, label %frame.failure.0
helper.continue.1141:
  br label %local.descriptor.checked.1122
local.descriptor.inactive.1121:
  br label %local.descriptor.checked.1122
local.descriptor.checked.1122:
  %local.is.active.1142 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1142, label %local.descriptor.active.1143, label %local.descriptor.inactive.1144
local.descriptor.active.1143:
  %local.check.offset.1146 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1147 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1148 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1149 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1151 = load i32, ptr %context.field.1150, align 4
  %stack.sub.1154 = sub i32 %local.check.owner.end.1149, %local.check.offset.1146
  %descriptor.owner.inside.1152 = icmp ule i32 %local.check.owner.end.1149, %context.value.1151
  %descriptor.offset.inside.1153 = icmp ule i32 %local.check.offset.1146, %local.check.owner.end.1149
  %descriptor.extent.inside.1155 = icmp ule i32 %local.check.extent.1147, %stack.sub.1154
  %descriptor.payload.inside.1156 = icmp ule i32 %local.check.payload.1148, %local.check.extent.1147
  %descriptor.owner.offset.valid.1157 = and i1 %descriptor.owner.inside.1152, %descriptor.offset.inside.1153
  %descriptor.range.inside.1159 = and i1 %descriptor.owner.offset.valid.1157, %descriptor.extent.inside.1155
  %descriptor.range.valid.1158 = and i1 %descriptor.range.inside.1159, %descriptor.payload.inside.1156
  br i1 %descriptor.range.valid.1158, label %descriptor.valid.1160, label %descriptor.invalid.1161
descriptor.invalid.1161:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1160:
  %descriptor.initialized.status.1162 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1146, i32 %local.check.extent.1147)
  %helper.ok.1163 = icmp eq i32 %descriptor.initialized.status.1162, 0
  br i1 %helper.ok.1163, label %helper.continue.1164, label %frame.failure.0
helper.continue.1164:
  br label %local.descriptor.checked.1145
local.descriptor.inactive.1144:
  br label %local.descriptor.checked.1145
local.descriptor.checked.1145:
  %step.status.1165 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.1166 = icmp eq i32 %step.status.1165, 0
  br i1 %helper.ok.1166, label %helper.continue.1167, label %frame.failure.0
helper.continue.1167:
  %local.resolved.offset.1168 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.1169 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.1170 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.1171 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1173 = load i32, ptr %context.field.1172, align 4
  %stack.sub.1176 = sub i32 %local.resolved.owner.end.1171, %local.resolved.offset.1168
  %descriptor.owner.inside.1174 = icmp ule i32 %local.resolved.owner.end.1171, %context.value.1173
  %descriptor.offset.inside.1175 = icmp ule i32 %local.resolved.offset.1168, %local.resolved.owner.end.1171
  %descriptor.extent.inside.1177 = icmp ule i32 %local.resolved.extent.1169, %stack.sub.1176
  %descriptor.payload.inside.1178 = icmp ule i32 %local.resolved.payload.1170, %local.resolved.extent.1169
  %descriptor.owner.offset.valid.1179 = and i1 %descriptor.owner.inside.1174, %descriptor.offset.inside.1175
  %descriptor.range.inside.1181 = and i1 %descriptor.owner.offset.valid.1179, %descriptor.extent.inside.1177
  %descriptor.range.valid.1180 = and i1 %descriptor.range.inside.1181, %descriptor.payload.inside.1178
  %descriptor.type.valid.1182 = icmp eq i32 4, 4
  %descriptor.valid.1183 = and i1 %descriptor.range.valid.1180, %descriptor.type.valid.1182
  br i1 %descriptor.valid.1183, label %descriptor.valid.1184, label %descriptor.invalid.1185
descriptor.invalid.1185:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1184:
  %descriptor.initialized.status.1186 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1168, i32 %local.resolved.extent.1169)
  %helper.ok.1187 = icmp eq i32 %descriptor.initialized.status.1186, 0
  br i1 %helper.ok.1187, label %helper.continue.1188, label %frame.failure.0
helper.continue.1188:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.1168, i32 20, i32 %local.resolved.payload.1170, i32 %local.resolved.owner.end.1171, i32 %local.resolved.extent.1169)
  %context.field.1189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1190 = load i32, ptr %context.field.1189, align 4
  %runtime.ok.1191 = icmp eq i32 %context.value.1190, 0
  br i1 %runtime.ok.1191, label %runtime.continue.1192, label %frame.failure.0
runtime.continue.1192:
  %context.field.1193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1194 = load i32, ptr %context.field.1193, align 4
  %stack.sub.1197 = sub i32 %local.resolved.owner.end.1034, %local.resolved.offset.1031
  %descriptor.owner.inside.1195 = icmp ule i32 %local.resolved.owner.end.1034, %context.value.1194
  %descriptor.offset.inside.1196 = icmp ule i32 %local.resolved.offset.1031, %local.resolved.owner.end.1034
  %descriptor.extent.inside.1198 = icmp ule i32 %local.resolved.extent.1032, %stack.sub.1197
  %descriptor.payload.inside.1199 = icmp ule i32 %local.resolved.payload.1033, %local.resolved.extent.1032
  %descriptor.owner.offset.valid.1200 = and i1 %descriptor.owner.inside.1195, %descriptor.offset.inside.1196
  %descriptor.range.inside.1202 = and i1 %descriptor.owner.offset.valid.1200, %descriptor.extent.inside.1198
  %descriptor.range.valid.1201 = and i1 %descriptor.range.inside.1202, %descriptor.payload.inside.1199
  %descriptor.type.valid.1203 = icmp eq i32 5, 5
  %descriptor.valid.1204 = and i1 %descriptor.range.valid.1201, %descriptor.type.valid.1203
  br i1 %descriptor.valid.1204, label %descriptor.valid.1205, label %descriptor.invalid.1206
descriptor.invalid.1206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1205:
  %descriptor.initialized.status.1207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1031, i32 %local.resolved.extent.1032)
  %helper.ok.1208 = icmp eq i32 %descriptor.initialized.status.1207, 0
  br i1 %helper.ok.1208, label %helper.continue.1209, label %frame.failure.0
helper.continue.1209:
  %context.field.1210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1211 = load i32, ptr %context.field.1210, align 4
  %stack.sub.1214 = sub i32 %local.resolved.owner.end.1171, %local.resolved.offset.1168
  %descriptor.owner.inside.1212 = icmp ule i32 %local.resolved.owner.end.1171, %context.value.1211
  %descriptor.offset.inside.1213 = icmp ule i32 %local.resolved.offset.1168, %local.resolved.owner.end.1171
  %descriptor.extent.inside.1215 = icmp ule i32 %local.resolved.extent.1169, %stack.sub.1214
  %descriptor.payload.inside.1216 = icmp ule i32 %local.resolved.payload.1170, %local.resolved.extent.1169
  %descriptor.owner.offset.valid.1217 = and i1 %descriptor.owner.inside.1212, %descriptor.offset.inside.1213
  %descriptor.range.inside.1219 = and i1 %descriptor.owner.offset.valid.1217, %descriptor.extent.inside.1215
  %descriptor.range.valid.1218 = and i1 %descriptor.range.inside.1219, %descriptor.payload.inside.1216
  %descriptor.type.valid.1220 = icmp eq i32 4, 4
  %descriptor.valid.1221 = and i1 %descriptor.range.valid.1218, %descriptor.type.valid.1220
  br i1 %descriptor.valid.1221, label %descriptor.valid.1222, label %descriptor.invalid.1223
descriptor.invalid.1223:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1222:
  %descriptor.initialized.status.1224 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1168, i32 %local.resolved.extent.1169)
  %helper.ok.1225 = icmp eq i32 %descriptor.initialized.status.1224, 0
  br i1 %helper.ok.1225, label %helper.continue.1226, label %frame.failure.0
helper.continue.1226:
  %local.is.active.1227 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1227, label %local.descriptor.active.1228, label %local.descriptor.inactive.1229
local.descriptor.active.1228:
  %local.check.offset.1231 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1232 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1233 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1234 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1236 = load i32, ptr %context.field.1235, align 4
  %stack.sub.1239 = sub i32 %local.check.owner.end.1234, %local.check.offset.1231
  %descriptor.owner.inside.1237 = icmp ule i32 %local.check.owner.end.1234, %context.value.1236
  %descriptor.offset.inside.1238 = icmp ule i32 %local.check.offset.1231, %local.check.owner.end.1234
  %descriptor.extent.inside.1240 = icmp ule i32 %local.check.extent.1232, %stack.sub.1239
  %descriptor.payload.inside.1241 = icmp ule i32 %local.check.payload.1233, %local.check.extent.1232
  %descriptor.owner.offset.valid.1242 = and i1 %descriptor.owner.inside.1237, %descriptor.offset.inside.1238
  %descriptor.range.inside.1244 = and i1 %descriptor.owner.offset.valid.1242, %descriptor.extent.inside.1240
  %descriptor.range.valid.1243 = and i1 %descriptor.range.inside.1244, %descriptor.payload.inside.1241
  br i1 %descriptor.range.valid.1243, label %descriptor.valid.1245, label %descriptor.invalid.1246
descriptor.invalid.1246:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1245:
  %descriptor.initialized.status.1247 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1231, i32 %local.check.extent.1232)
  %helper.ok.1248 = icmp eq i32 %descriptor.initialized.status.1247, 0
  br i1 %helper.ok.1248, label %helper.continue.1249, label %frame.failure.0
helper.continue.1249:
  br label %local.descriptor.checked.1230
local.descriptor.inactive.1229:
  br label %local.descriptor.checked.1230
local.descriptor.checked.1230:
  %local.is.active.1250 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1250, label %local.descriptor.active.1251, label %local.descriptor.inactive.1252
local.descriptor.active.1251:
  %local.check.offset.1254 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1255 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1256 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1257 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1259 = load i32, ptr %context.field.1258, align 4
  %stack.sub.1262 = sub i32 %local.check.owner.end.1257, %local.check.offset.1254
  %descriptor.owner.inside.1260 = icmp ule i32 %local.check.owner.end.1257, %context.value.1259
  %descriptor.offset.inside.1261 = icmp ule i32 %local.check.offset.1254, %local.check.owner.end.1257
  %descriptor.extent.inside.1263 = icmp ule i32 %local.check.extent.1255, %stack.sub.1262
  %descriptor.payload.inside.1264 = icmp ule i32 %local.check.payload.1256, %local.check.extent.1255
  %descriptor.owner.offset.valid.1265 = and i1 %descriptor.owner.inside.1260, %descriptor.offset.inside.1261
  %descriptor.range.inside.1267 = and i1 %descriptor.owner.offset.valid.1265, %descriptor.extent.inside.1263
  %descriptor.range.valid.1266 = and i1 %descriptor.range.inside.1267, %descriptor.payload.inside.1264
  br i1 %descriptor.range.valid.1266, label %descriptor.valid.1268, label %descriptor.invalid.1269
descriptor.invalid.1269:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1268:
  %descriptor.initialized.status.1270 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1254, i32 %local.check.extent.1255)
  %helper.ok.1271 = icmp eq i32 %descriptor.initialized.status.1270, 0
  br i1 %helper.ok.1271, label %helper.continue.1272, label %frame.failure.0
helper.continue.1272:
  br label %local.descriptor.checked.1253
local.descriptor.inactive.1252:
  br label %local.descriptor.checked.1253
local.descriptor.checked.1253:
  %local.is.active.1273 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1273, label %local.descriptor.active.1274, label %local.descriptor.inactive.1275
local.descriptor.active.1274:
  %local.check.offset.1277 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1278 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1279 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1280 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1282 = load i32, ptr %context.field.1281, align 4
  %stack.sub.1285 = sub i32 %local.check.owner.end.1280, %local.check.offset.1277
  %descriptor.owner.inside.1283 = icmp ule i32 %local.check.owner.end.1280, %context.value.1282
  %descriptor.offset.inside.1284 = icmp ule i32 %local.check.offset.1277, %local.check.owner.end.1280
  %descriptor.extent.inside.1286 = icmp ule i32 %local.check.extent.1278, %stack.sub.1285
  %descriptor.payload.inside.1287 = icmp ule i32 %local.check.payload.1279, %local.check.extent.1278
  %descriptor.owner.offset.valid.1288 = and i1 %descriptor.owner.inside.1283, %descriptor.offset.inside.1284
  %descriptor.range.inside.1290 = and i1 %descriptor.owner.offset.valid.1288, %descriptor.extent.inside.1286
  %descriptor.range.valid.1289 = and i1 %descriptor.range.inside.1290, %descriptor.payload.inside.1287
  br i1 %descriptor.range.valid.1289, label %descriptor.valid.1291, label %descriptor.invalid.1292
descriptor.invalid.1292:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1291:
  %descriptor.initialized.status.1293 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1277, i32 %local.check.extent.1278)
  %helper.ok.1294 = icmp eq i32 %descriptor.initialized.status.1293, 0
  br i1 %helper.ok.1294, label %helper.continue.1295, label %frame.failure.0
helper.continue.1295:
  br label %local.descriptor.checked.1276
local.descriptor.inactive.1275:
  br label %local.descriptor.checked.1276
local.descriptor.checked.1276:
  %local.is.active.1296 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1296, label %local.descriptor.active.1297, label %local.descriptor.inactive.1298
local.descriptor.active.1297:
  %local.check.offset.1300 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1301 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1302 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1303 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1305 = load i32, ptr %context.field.1304, align 4
  %stack.sub.1308 = sub i32 %local.check.owner.end.1303, %local.check.offset.1300
  %descriptor.owner.inside.1306 = icmp ule i32 %local.check.owner.end.1303, %context.value.1305
  %descriptor.offset.inside.1307 = icmp ule i32 %local.check.offset.1300, %local.check.owner.end.1303
  %descriptor.extent.inside.1309 = icmp ule i32 %local.check.extent.1301, %stack.sub.1308
  %descriptor.payload.inside.1310 = icmp ule i32 %local.check.payload.1302, %local.check.extent.1301
  %descriptor.owner.offset.valid.1311 = and i1 %descriptor.owner.inside.1306, %descriptor.offset.inside.1307
  %descriptor.range.inside.1313 = and i1 %descriptor.owner.offset.valid.1311, %descriptor.extent.inside.1309
  %descriptor.range.valid.1312 = and i1 %descriptor.range.inside.1313, %descriptor.payload.inside.1310
  br i1 %descriptor.range.valid.1312, label %descriptor.valid.1314, label %descriptor.invalid.1315
descriptor.invalid.1315:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1314:
  %descriptor.initialized.status.1316 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1300, i32 %local.check.extent.1301)
  %helper.ok.1317 = icmp eq i32 %descriptor.initialized.status.1316, 0
  br i1 %helper.ok.1317, label %helper.continue.1318, label %frame.failure.0
helper.continue.1318:
  br label %local.descriptor.checked.1299
local.descriptor.inactive.1298:
  br label %local.descriptor.checked.1299
local.descriptor.checked.1299:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1319 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1320 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1319, i32 0, i32 0
  store i32 5, ptr %descriptor.field.1320, align 4
  %descriptor.field.1321 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1319, i32 0, i32 1
  store i32 %local.resolved.offset.1031, ptr %descriptor.field.1321, align 4
  %descriptor.field.1322 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1319, i32 0, i32 2
  store i32 %local.resolved.extent.1032, ptr %descriptor.field.1322, align 4
  %descriptor.field.1323 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1319, i32 0, i32 3
  store i32 %local.resolved.payload.1033, ptr %descriptor.field.1323, align 4
  %descriptor.field.1324 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1319, i32 0, i32 4
  store i32 %local.resolved.owner.end.1034, ptr %descriptor.field.1324, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.1031, i32 20, i32 %local.resolved.payload.1033, i32 %local.resolved.owner.end.1034, i32 %local.resolved.extent.1032)
  %context.field.1325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1326 = load i32, ptr %context.field.1325, align 4
  %runtime.ok.1327 = icmp eq i32 %context.value.1326, 0
  br i1 %runtime.ok.1327, label %runtime.continue.1328, label %frame.failure.0
runtime.continue.1328:
  %descriptor.element.1329 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.1330 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1329, i32 0, i32 0
  store i32 4, ptr %descriptor.field.1330, align 4
  %descriptor.field.1331 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1329, i32 0, i32 1
  store i32 %local.resolved.offset.1168, ptr %descriptor.field.1331, align 4
  %descriptor.field.1332 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1329, i32 0, i32 2
  store i32 %local.resolved.extent.1169, ptr %descriptor.field.1332, align 4
  %descriptor.field.1333 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1329, i32 0, i32 3
  store i32 %local.resolved.payload.1170, ptr %descriptor.field.1333, align 4
  %descriptor.field.1334 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1329, i32 0, i32 4
  store i32 %local.resolved.owner.end.1171, ptr %descriptor.field.1334, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.1168, i32 20, i32 %local.resolved.payload.1170, i32 %local.resolved.owner.end.1171, i32 %local.resolved.extent.1169)
  %context.field.1335 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1336 = load i32, ptr %context.field.1335, align 4
  %runtime.ok.1337 = icmp eq i32 %context.value.1336, 0
  br i1 %runtime.ok.1337, label %runtime.continue.1338, label %frame.failure.0
runtime.continue.1338:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.27, i32 0, i32 0, i32 0)
  %context.field.1339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1340 = load i32, ptr %context.field.1339, align 4
  %context.field.1341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1342 = load i32, ptr %context.field.1341, align 4
  %context.field.1343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1344 = load i32, ptr %context.field.1343, align 4
  %stack.offset.1345 = add i32 %context.value.29, %context.value.31
  %stack.offset.1346 = add i32 %context.value.1340, %context.value.1342
  %stack.sub.1347 = sub i32 %stack.offset.1345, %stack.offset.1346
  %stack.sub.1348 = sub i32 %context.value.31, %context.value.1342
  %stack.sub.1349 = sub i32 %context.value.1344, %context.value.33
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1347, i32 %stack.sub.1348)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1349)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 6
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 6, 6
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.29, ptr %local.offset.3, align 4
  store i32 %descriptor.value.31, ptr %local.extent.4, align 4
  store i32 %descriptor.value.33, ptr %local.payload.5, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %local.is.active.62 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.62, label %local.descriptor.active.63, label %local.descriptor.inactive.64
local.descriptor.active.63:
  %local.check.offset.66 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.67 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.68 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.69 = load i32, ptr %local.owner.end.6, align 4
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %local.check.owner.end.69, %local.check.offset.66
  %descriptor.owner.inside.72 = icmp ule i32 %local.check.owner.end.69, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %local.check.offset.66, %local.check.owner.end.69
  %descriptor.extent.inside.75 = icmp ule i32 %local.check.extent.67, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %local.check.payload.68, %local.check.extent.67
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  br i1 %descriptor.range.valid.78, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.66, i32 %local.check.extent.67)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  br label %local.descriptor.checked.65
local.descriptor.inactive.64:
  br label %local.descriptor.checked.65
local.descriptor.checked.65:
  %local.is.active.85 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.85, label %local.descriptor.active.86, label %local.descriptor.inactive.87
local.descriptor.active.86:
  %local.check.offset.89 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.90 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.91 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.92 = load i32, ptr %local.owner.end.12, align 4
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %stack.sub.97 = sub i32 %local.check.owner.end.92, %local.check.offset.89
  %descriptor.owner.inside.95 = icmp ule i32 %local.check.owner.end.92, %context.value.94
  %descriptor.offset.inside.96 = icmp ule i32 %local.check.offset.89, %local.check.owner.end.92
  %descriptor.extent.inside.98 = icmp ule i32 %local.check.extent.90, %stack.sub.97
  %descriptor.payload.inside.99 = icmp ule i32 %local.check.payload.91, %local.check.extent.90
  %descriptor.owner.offset.valid.100 = and i1 %descriptor.owner.inside.95, %descriptor.offset.inside.96
  %descriptor.range.inside.102 = and i1 %descriptor.owner.offset.valid.100, %descriptor.extent.inside.98
  %descriptor.range.valid.101 = and i1 %descriptor.range.inside.102, %descriptor.payload.inside.99
  br i1 %descriptor.range.valid.101, label %descriptor.valid.103, label %descriptor.invalid.104
descriptor.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.103:
  %descriptor.initialized.status.105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.89, i32 %local.check.extent.90)
  %helper.ok.106 = icmp eq i32 %descriptor.initialized.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %frame.failure.0
helper.continue.107:
  br label %local.descriptor.checked.88
local.descriptor.inactive.87:
  br label %local.descriptor.checked.88
local.descriptor.checked.88:
  %step.status.108 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.109 = icmp eq i32 %step.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.112 = load i32, ptr %context.field.111, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %step.status.113 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.114 = icmp eq i32 %step.status.113, 0
  br i1 %helper.ok.114, label %helper.continue.115, label %frame.failure.0
helper.continue.115:
  %local.resolved.offset.116 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.117 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.118 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.119 = load i32, ptr %local.owner.end.6, align 4
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %stack.sub.124 = sub i32 %local.resolved.owner.end.119, %local.resolved.offset.116
  %descriptor.owner.inside.122 = icmp ule i32 %local.resolved.owner.end.119, %context.value.121
  %descriptor.offset.inside.123 = icmp ule i32 %local.resolved.offset.116, %local.resolved.owner.end.119
  %descriptor.extent.inside.125 = icmp ule i32 %local.resolved.extent.117, %stack.sub.124
  %descriptor.payload.inside.126 = icmp ule i32 %local.resolved.payload.118, %local.resolved.extent.117
  %descriptor.owner.offset.valid.127 = and i1 %descriptor.owner.inside.122, %descriptor.offset.inside.123
  %descriptor.range.inside.129 = and i1 %descriptor.owner.offset.valid.127, %descriptor.extent.inside.125
  %descriptor.range.valid.128 = and i1 %descriptor.range.inside.129, %descriptor.payload.inside.126
  %descriptor.type.valid.130 = icmp eq i32 6, 6
  %descriptor.valid.131 = and i1 %descriptor.range.valid.128, %descriptor.type.valid.130
  br i1 %descriptor.valid.131, label %descriptor.valid.132, label %descriptor.invalid.133
descriptor.invalid.133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.132:
  %descriptor.initialized.status.134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.116, i32 %local.resolved.extent.117)
  %helper.ok.135 = icmp eq i32 %descriptor.initialized.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.116, i32 20, i32 %local.resolved.payload.118, i32 %local.resolved.owner.end.119, i32 %local.resolved.extent.117)
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %runtime.ok.139 = icmp eq i32 %context.value.138, 0
  br i1 %runtime.ok.139, label %runtime.continue.140, label %frame.failure.0
runtime.continue.140:
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %local.resolved.owner.end.119, %local.resolved.offset.116
  %descriptor.owner.inside.143 = icmp ule i32 %local.resolved.owner.end.119, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %local.resolved.offset.116, %local.resolved.owner.end.119
  %descriptor.extent.inside.146 = icmp ule i32 %local.resolved.extent.117, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %local.resolved.payload.118, %local.resolved.extent.117
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  %descriptor.type.valid.151 = icmp eq i32 6, 6
  %descriptor.valid.152 = and i1 %descriptor.range.valid.149, %descriptor.type.valid.151
  br i1 %descriptor.valid.152, label %descriptor.valid.153, label %descriptor.invalid.154
descriptor.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.153:
  %descriptor.initialized.status.155 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.116, i32 %local.resolved.extent.117)
  %helper.ok.156 = icmp eq i32 %descriptor.initialized.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %frame.failure.0
helper.continue.157:
  %local.is.active.158 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.158, label %local.descriptor.active.159, label %local.descriptor.inactive.160
local.descriptor.active.159:
  %local.check.offset.162 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.163 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.164 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.165 = load i32, ptr %local.owner.end.6, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.sub.170 = sub i32 %local.check.owner.end.165, %local.check.offset.162
  %descriptor.owner.inside.168 = icmp ule i32 %local.check.owner.end.165, %context.value.167
  %descriptor.offset.inside.169 = icmp ule i32 %local.check.offset.162, %local.check.owner.end.165
  %descriptor.extent.inside.171 = icmp ule i32 %local.check.extent.163, %stack.sub.170
  %descriptor.payload.inside.172 = icmp ule i32 %local.check.payload.164, %local.check.extent.163
  %descriptor.owner.offset.valid.173 = and i1 %descriptor.owner.inside.168, %descriptor.offset.inside.169
  %descriptor.range.inside.175 = and i1 %descriptor.owner.offset.valid.173, %descriptor.extent.inside.171
  %descriptor.range.valid.174 = and i1 %descriptor.range.inside.175, %descriptor.payload.inside.172
  br i1 %descriptor.range.valid.174, label %descriptor.valid.176, label %descriptor.invalid.177
descriptor.invalid.177:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.176:
  %descriptor.initialized.status.178 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.162, i32 %local.check.extent.163)
  %helper.ok.179 = icmp eq i32 %descriptor.initialized.status.178, 0
  br i1 %helper.ok.179, label %helper.continue.180, label %frame.failure.0
helper.continue.180:
  br label %local.descriptor.checked.161
local.descriptor.inactive.160:
  br label %local.descriptor.checked.161
local.descriptor.checked.161:
  %local.is.active.181 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.181, label %local.descriptor.active.182, label %local.descriptor.inactive.183
local.descriptor.active.182:
  %local.check.offset.185 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.186 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.187 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.188 = load i32, ptr %local.owner.end.12, align 4
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %stack.sub.193 = sub i32 %local.check.owner.end.188, %local.check.offset.185
  %descriptor.owner.inside.191 = icmp ule i32 %local.check.owner.end.188, %context.value.190
  %descriptor.offset.inside.192 = icmp ule i32 %local.check.offset.185, %local.check.owner.end.188
  %descriptor.extent.inside.194 = icmp ule i32 %local.check.extent.186, %stack.sub.193
  %descriptor.payload.inside.195 = icmp ule i32 %local.check.payload.187, %local.check.extent.186
  %descriptor.owner.offset.valid.196 = and i1 %descriptor.owner.inside.191, %descriptor.offset.inside.192
  %descriptor.range.inside.198 = and i1 %descriptor.owner.offset.valid.196, %descriptor.extent.inside.194
  %descriptor.range.valid.197 = and i1 %descriptor.range.inside.198, %descriptor.payload.inside.195
  br i1 %descriptor.range.valid.197, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.185, i32 %local.check.extent.186)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  br label %local.descriptor.checked.184
local.descriptor.inactive.183:
  br label %local.descriptor.checked.184
local.descriptor.checked.184:
  %step.status.204 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.205 = icmp eq i32 %step.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  store i1 true, ptr %local.active.8, align 1
  store i32 %local.resolved.offset.116, ptr %local.offset.9, align 4
  store i32 %local.resolved.extent.117, ptr %local.extent.10, align 4
  store i32 %local.resolved.payload.118, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.119, ptr %local.owner.end.12, align 4
  store i32 6, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.116, i32 20, i32 %local.resolved.payload.118, i32 %local.resolved.owner.end.119, i32 %local.resolved.extent.117)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  %local.is.active.211 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.211, label %local.descriptor.active.212, label %local.descriptor.inactive.213
local.descriptor.active.212:
  %local.check.offset.215 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.216 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.217 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.218 = load i32, ptr %local.owner.end.6, align 4
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %stack.sub.223 = sub i32 %local.check.owner.end.218, %local.check.offset.215
  %descriptor.owner.inside.221 = icmp ule i32 %local.check.owner.end.218, %context.value.220
  %descriptor.offset.inside.222 = icmp ule i32 %local.check.offset.215, %local.check.owner.end.218
  %descriptor.extent.inside.224 = icmp ule i32 %local.check.extent.216, %stack.sub.223
  %descriptor.payload.inside.225 = icmp ule i32 %local.check.payload.217, %local.check.extent.216
  %descriptor.owner.offset.valid.226 = and i1 %descriptor.owner.inside.221, %descriptor.offset.inside.222
  %descriptor.range.inside.228 = and i1 %descriptor.owner.offset.valid.226, %descriptor.extent.inside.224
  %descriptor.range.valid.227 = and i1 %descriptor.range.inside.228, %descriptor.payload.inside.225
  br i1 %descriptor.range.valid.227, label %descriptor.valid.229, label %descriptor.invalid.230
descriptor.invalid.230:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.229:
  %descriptor.initialized.status.231 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.215, i32 %local.check.extent.216)
  %helper.ok.232 = icmp eq i32 %descriptor.initialized.status.231, 0
  br i1 %helper.ok.232, label %helper.continue.233, label %frame.failure.0
helper.continue.233:
  br label %local.descriptor.checked.214
local.descriptor.inactive.213:
  br label %local.descriptor.checked.214
local.descriptor.checked.214:
  %local.is.active.234 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.234, label %local.descriptor.active.235, label %local.descriptor.inactive.236
local.descriptor.active.235:
  %local.check.offset.238 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.239 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.240 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.241 = load i32, ptr %local.owner.end.12, align 4
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %stack.sub.246 = sub i32 %local.check.owner.end.241, %local.check.offset.238
  %descriptor.owner.inside.244 = icmp ule i32 %local.check.owner.end.241, %context.value.243
  %descriptor.offset.inside.245 = icmp ule i32 %local.check.offset.238, %local.check.owner.end.241
  %descriptor.extent.inside.247 = icmp ule i32 %local.check.extent.239, %stack.sub.246
  %descriptor.payload.inside.248 = icmp ule i32 %local.check.payload.240, %local.check.extent.239
  %descriptor.owner.offset.valid.249 = and i1 %descriptor.owner.inside.244, %descriptor.offset.inside.245
  %descriptor.range.inside.251 = and i1 %descriptor.owner.offset.valid.249, %descriptor.extent.inside.247
  %descriptor.range.valid.250 = and i1 %descriptor.range.inside.251, %descriptor.payload.inside.248
  br i1 %descriptor.range.valid.250, label %descriptor.valid.252, label %descriptor.invalid.253
descriptor.invalid.253:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.252:
  %descriptor.initialized.status.254 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.238, i32 %local.check.extent.239)
  %helper.ok.255 = icmp eq i32 %descriptor.initialized.status.254, 0
  br i1 %helper.ok.255, label %helper.continue.256, label %frame.failure.0
helper.continue.256:
  br label %local.descriptor.checked.237
local.descriptor.inactive.236:
  br label %local.descriptor.checked.237
local.descriptor.checked.237:
  %step.status.257 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.258 = icmp eq i32 %step.status.257, 0
  br i1 %helper.ok.258, label %helper.continue.259, label %frame.failure.0
helper.continue.259:
  %local.resolved.offset.260 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.261 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.262 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.263 = load i32, ptr %local.owner.end.12, align 4
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %stack.sub.268 = sub i32 %local.resolved.owner.end.263, %local.resolved.offset.260
  %descriptor.owner.inside.266 = icmp ule i32 %local.resolved.owner.end.263, %context.value.265
  %descriptor.offset.inside.267 = icmp ule i32 %local.resolved.offset.260, %local.resolved.owner.end.263
  %descriptor.extent.inside.269 = icmp ule i32 %local.resolved.extent.261, %stack.sub.268
  %descriptor.payload.inside.270 = icmp ule i32 %local.resolved.payload.262, %local.resolved.extent.261
  %descriptor.owner.offset.valid.271 = and i1 %descriptor.owner.inside.266, %descriptor.offset.inside.267
  %descriptor.range.inside.273 = and i1 %descriptor.owner.offset.valid.271, %descriptor.extent.inside.269
  %descriptor.range.valid.272 = and i1 %descriptor.range.inside.273, %descriptor.payload.inside.270
  %descriptor.type.valid.274 = icmp eq i32 6, 6
  %descriptor.valid.275 = and i1 %descriptor.range.valid.272, %descriptor.type.valid.274
  br i1 %descriptor.valid.275, label %descriptor.valid.276, label %descriptor.invalid.277
descriptor.invalid.277:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.276:
  %descriptor.initialized.status.278 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261)
  %helper.ok.279 = icmp eq i32 %descriptor.initialized.status.278, 0
  br i1 %helper.ok.279, label %helper.continue.280, label %frame.failure.0
helper.continue.280:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.260, i32 20, i32 %local.resolved.payload.262, i32 %local.resolved.owner.end.263, i32 %local.resolved.extent.261)
  %context.field.281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.282 = load i32, ptr %context.field.281, align 4
  %runtime.ok.283 = icmp eq i32 %context.value.282, 0
  br i1 %runtime.ok.283, label %runtime.continue.284, label %frame.failure.0
runtime.continue.284:
  %context.field.285 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.286 = load i32, ptr %context.field.285, align 4
  %stack.sub.289 = sub i32 %local.resolved.owner.end.263, %local.resolved.offset.260
  %descriptor.owner.inside.287 = icmp ule i32 %local.resolved.owner.end.263, %context.value.286
  %descriptor.offset.inside.288 = icmp ule i32 %local.resolved.offset.260, %local.resolved.owner.end.263
  %descriptor.extent.inside.290 = icmp ule i32 %local.resolved.extent.261, %stack.sub.289
  %descriptor.payload.inside.291 = icmp ule i32 %local.resolved.payload.262, %local.resolved.extent.261
  %descriptor.owner.offset.valid.292 = and i1 %descriptor.owner.inside.287, %descriptor.offset.inside.288
  %descriptor.range.inside.294 = and i1 %descriptor.owner.offset.valid.292, %descriptor.extent.inside.290
  %descriptor.range.valid.293 = and i1 %descriptor.range.inside.294, %descriptor.payload.inside.291
  %descriptor.type.valid.295 = icmp eq i32 6, 6
  %descriptor.valid.296 = and i1 %descriptor.range.valid.293, %descriptor.type.valid.295
  br i1 %descriptor.valid.296, label %descriptor.valid.297, label %descriptor.invalid.298
descriptor.invalid.298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.297:
  %descriptor.initialized.status.299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261)
  %helper.ok.300 = icmp eq i32 %descriptor.initialized.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %local.is.active.302 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.302, label %local.descriptor.active.303, label %local.descriptor.inactive.304
local.descriptor.active.303:
  %local.check.offset.306 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.307 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.308 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.309 = load i32, ptr %local.owner.end.6, align 4
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %stack.sub.314 = sub i32 %local.check.owner.end.309, %local.check.offset.306
  %descriptor.owner.inside.312 = icmp ule i32 %local.check.owner.end.309, %context.value.311
  %descriptor.offset.inside.313 = icmp ule i32 %local.check.offset.306, %local.check.owner.end.309
  %descriptor.extent.inside.315 = icmp ule i32 %local.check.extent.307, %stack.sub.314
  %descriptor.payload.inside.316 = icmp ule i32 %local.check.payload.308, %local.check.extent.307
  %descriptor.owner.offset.valid.317 = and i1 %descriptor.owner.inside.312, %descriptor.offset.inside.313
  %descriptor.range.inside.319 = and i1 %descriptor.owner.offset.valid.317, %descriptor.extent.inside.315
  %descriptor.range.valid.318 = and i1 %descriptor.range.inside.319, %descriptor.payload.inside.316
  br i1 %descriptor.range.valid.318, label %descriptor.valid.320, label %descriptor.invalid.321
descriptor.invalid.321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.320:
  %descriptor.initialized.status.322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.306, i32 %local.check.extent.307)
  %helper.ok.323 = icmp eq i32 %descriptor.initialized.status.322, 0
  br i1 %helper.ok.323, label %helper.continue.324, label %frame.failure.0
helper.continue.324:
  br label %local.descriptor.checked.305
local.descriptor.inactive.304:
  br label %local.descriptor.checked.305
local.descriptor.checked.305:
  %local.is.active.325 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.325, label %local.descriptor.active.326, label %local.descriptor.inactive.327
local.descriptor.active.326:
  %local.check.offset.329 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.330 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.331 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.332 = load i32, ptr %local.owner.end.12, align 4
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %stack.sub.337 = sub i32 %local.check.owner.end.332, %local.check.offset.329
  %descriptor.owner.inside.335 = icmp ule i32 %local.check.owner.end.332, %context.value.334
  %descriptor.offset.inside.336 = icmp ule i32 %local.check.offset.329, %local.check.owner.end.332
  %descriptor.extent.inside.338 = icmp ule i32 %local.check.extent.330, %stack.sub.337
  %descriptor.payload.inside.339 = icmp ule i32 %local.check.payload.331, %local.check.extent.330
  %descriptor.owner.offset.valid.340 = and i1 %descriptor.owner.inside.335, %descriptor.offset.inside.336
  %descriptor.range.inside.342 = and i1 %descriptor.owner.offset.valid.340, %descriptor.extent.inside.338
  %descriptor.range.valid.341 = and i1 %descriptor.range.inside.342, %descriptor.payload.inside.339
  br i1 %descriptor.range.valid.341, label %descriptor.valid.343, label %descriptor.invalid.344
descriptor.invalid.344:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.343:
  %descriptor.initialized.status.345 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.329, i32 %local.check.extent.330)
  %helper.ok.346 = icmp eq i32 %descriptor.initialized.status.345, 0
  br i1 %helper.ok.346, label %helper.continue.347, label %frame.failure.0
helper.continue.347:
  br label %local.descriptor.checked.328
local.descriptor.inactive.327:
  br label %local.descriptor.checked.328
local.descriptor.checked.328:
  %step.status.348 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.349 = icmp eq i32 %step.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %frame.failure.0
helper.continue.350:
  %stack.offset.351 = add i32 0, %local.resolved.payload.262
  %stack.offset.352 = add i32 0, %local.resolved.extent.261
  %context.field.353 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.354 = load i32, ptr %context.field.353, align 4
  %stack.offset.355 = add i32 %context.value.354, %stack.offset.352
  %reserve.status.356 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.355, i32 24)
  %reserve.ok.357 = icmp eq i32 %reserve.status.356, 0
  br i1 %reserve.ok.357, label %reserve.continue.358, label %frame.failure.0
reserve.continue.358:
  %stack.offset.359 = add i32 %context.value.354, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.359, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261, i32 %local.resolved.payload.262, i32 6, i32 6)
  %context.field.360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.361 = load i32, ptr %context.field.360, align 4
  %runtime.ok.362 = icmp eq i32 %context.value.361, 0
  br i1 %runtime.ok.362, label %runtime.continue.363, label %frame.failure.0
runtime.continue.363:
  %stack.offset.364 = add i32 0, %local.resolved.extent.261
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.354, i32 %stack.offset.352, i32 %stack.offset.351, i32 0, i32 0)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %stack.sub.373 = sub i32 %stack.offset.355, %context.value.354
  %descriptor.owner.inside.371 = icmp ule i32 %stack.offset.355, %context.value.370
  %descriptor.offset.inside.372 = icmp ule i32 %context.value.354, %stack.offset.355
  %descriptor.extent.inside.374 = icmp ule i32 %stack.offset.352, %stack.sub.373
  %descriptor.payload.inside.375 = icmp ule i32 %stack.offset.351, %stack.offset.352
  %descriptor.owner.offset.valid.376 = and i1 %descriptor.owner.inside.371, %descriptor.offset.inside.372
  %descriptor.range.inside.378 = and i1 %descriptor.owner.offset.valid.376, %descriptor.extent.inside.374
  %descriptor.range.valid.377 = and i1 %descriptor.range.inside.378, %descriptor.payload.inside.375
  %descriptor.type.valid.379 = icmp eq i32 5, 5
  %descriptor.valid.380 = and i1 %descriptor.range.valid.377, %descriptor.type.valid.379
  br i1 %descriptor.valid.380, label %descriptor.valid.381, label %descriptor.invalid.382
descriptor.invalid.382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.381:
  %descriptor.initialized.status.383 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.354, i32 %stack.offset.352)
  %helper.ok.384 = icmp eq i32 %descriptor.initialized.status.383, 0
  br i1 %helper.ok.384, label %helper.continue.385, label %frame.failure.0
helper.continue.385:
  %local.is.active.386 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.386, label %local.descriptor.active.387, label %local.descriptor.inactive.388
local.descriptor.active.387:
  %local.check.offset.390 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.391 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.392 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.393 = load i32, ptr %local.owner.end.6, align 4
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %stack.sub.398 = sub i32 %local.check.owner.end.393, %local.check.offset.390
  %descriptor.owner.inside.396 = icmp ule i32 %local.check.owner.end.393, %context.value.395
  %descriptor.offset.inside.397 = icmp ule i32 %local.check.offset.390, %local.check.owner.end.393
  %descriptor.extent.inside.399 = icmp ule i32 %local.check.extent.391, %stack.sub.398
  %descriptor.payload.inside.400 = icmp ule i32 %local.check.payload.392, %local.check.extent.391
  %descriptor.owner.offset.valid.401 = and i1 %descriptor.owner.inside.396, %descriptor.offset.inside.397
  %descriptor.range.inside.403 = and i1 %descriptor.owner.offset.valid.401, %descriptor.extent.inside.399
  %descriptor.range.valid.402 = and i1 %descriptor.range.inside.403, %descriptor.payload.inside.400
  br i1 %descriptor.range.valid.402, label %descriptor.valid.404, label %descriptor.invalid.405
descriptor.invalid.405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.404:
  %descriptor.initialized.status.406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.390, i32 %local.check.extent.391)
  %helper.ok.407 = icmp eq i32 %descriptor.initialized.status.406, 0
  br i1 %helper.ok.407, label %helper.continue.408, label %frame.failure.0
helper.continue.408:
  br label %local.descriptor.checked.389
local.descriptor.inactive.388:
  br label %local.descriptor.checked.389
local.descriptor.checked.389:
  %local.is.active.409 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.409, label %local.descriptor.active.410, label %local.descriptor.inactive.411
local.descriptor.active.410:
  %local.check.offset.413 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.414 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.415 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.416 = load i32, ptr %local.owner.end.12, align 4
  %context.field.417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.418 = load i32, ptr %context.field.417, align 4
  %stack.sub.421 = sub i32 %local.check.owner.end.416, %local.check.offset.413
  %descriptor.owner.inside.419 = icmp ule i32 %local.check.owner.end.416, %context.value.418
  %descriptor.offset.inside.420 = icmp ule i32 %local.check.offset.413, %local.check.owner.end.416
  %descriptor.extent.inside.422 = icmp ule i32 %local.check.extent.414, %stack.sub.421
  %descriptor.payload.inside.423 = icmp ule i32 %local.check.payload.415, %local.check.extent.414
  %descriptor.owner.offset.valid.424 = and i1 %descriptor.owner.inside.419, %descriptor.offset.inside.420
  %descriptor.range.inside.426 = and i1 %descriptor.owner.offset.valid.424, %descriptor.extent.inside.422
  %descriptor.range.valid.425 = and i1 %descriptor.range.inside.426, %descriptor.payload.inside.423
  br i1 %descriptor.range.valid.425, label %descriptor.valid.427, label %descriptor.invalid.428
descriptor.invalid.428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.427:
  %descriptor.initialized.status.429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.413, i32 %local.check.extent.414)
  %helper.ok.430 = icmp eq i32 %descriptor.initialized.status.429, 0
  br i1 %helper.ok.430, label %helper.continue.431, label %frame.failure.0
helper.continue.431:
  br label %local.descriptor.checked.412
local.descriptor.inactive.411:
  br label %local.descriptor.checked.412
local.descriptor.checked.412:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.432 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.433 = load i32, ptr %context.field.432, align 4
  %stack.sub.436 = sub i32 %stack.offset.355, %context.value.354
  %descriptor.owner.inside.434 = icmp ule i32 %stack.offset.355, %context.value.433
  %descriptor.offset.inside.435 = icmp ule i32 %context.value.354, %stack.offset.355
  %descriptor.extent.inside.437 = icmp ule i32 %stack.offset.352, %stack.sub.436
  %descriptor.payload.inside.438 = icmp ule i32 %stack.offset.351, %stack.offset.352
  %descriptor.owner.offset.valid.439 = and i1 %descriptor.owner.inside.434, %descriptor.offset.inside.435
  %descriptor.range.inside.441 = and i1 %descriptor.owner.offset.valid.439, %descriptor.extent.inside.437
  %descriptor.range.valid.440 = and i1 %descriptor.range.inside.441, %descriptor.payload.inside.438
  %descriptor.type.valid.442 = icmp eq i32 5, 5
  %descriptor.valid.443 = and i1 %descriptor.range.valid.440, %descriptor.type.valid.442
  br i1 %descriptor.valid.443, label %descriptor.valid.444, label %descriptor.invalid.445
descriptor.invalid.445:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.444:
  %descriptor.initialized.status.446 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.354, i32 %stack.offset.352)
  %helper.ok.447 = icmp eq i32 %descriptor.initialized.status.446, 0
  br i1 %helper.ok.447, label %helper.continue.448, label %frame.failure.0
helper.continue.448:
  %local.is.active.449 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.449, label %local.descriptor.active.450, label %local.descriptor.inactive.451
local.descriptor.active.450:
  %local.check.offset.453 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.454 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.455 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.456 = load i32, ptr %local.owner.end.6, align 4
  %context.field.457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.458 = load i32, ptr %context.field.457, align 4
  %stack.sub.461 = sub i32 %local.check.owner.end.456, %local.check.offset.453
  %descriptor.owner.inside.459 = icmp ule i32 %local.check.owner.end.456, %context.value.458
  %descriptor.offset.inside.460 = icmp ule i32 %local.check.offset.453, %local.check.owner.end.456
  %descriptor.extent.inside.462 = icmp ule i32 %local.check.extent.454, %stack.sub.461
  %descriptor.payload.inside.463 = icmp ule i32 %local.check.payload.455, %local.check.extent.454
  %descriptor.owner.offset.valid.464 = and i1 %descriptor.owner.inside.459, %descriptor.offset.inside.460
  %descriptor.range.inside.466 = and i1 %descriptor.owner.offset.valid.464, %descriptor.extent.inside.462
  %descriptor.range.valid.465 = and i1 %descriptor.range.inside.466, %descriptor.payload.inside.463
  br i1 %descriptor.range.valid.465, label %descriptor.valid.467, label %descriptor.invalid.468
descriptor.invalid.468:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.467:
  %descriptor.initialized.status.469 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.453, i32 %local.check.extent.454)
  %helper.ok.470 = icmp eq i32 %descriptor.initialized.status.469, 0
  br i1 %helper.ok.470, label %helper.continue.471, label %frame.failure.0
helper.continue.471:
  br label %local.descriptor.checked.452
local.descriptor.inactive.451:
  br label %local.descriptor.checked.452
local.descriptor.checked.452:
  %local.is.active.472 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.472, label %local.descriptor.active.473, label %local.descriptor.inactive.474
local.descriptor.active.473:
  %local.check.offset.476 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.477 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.478 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.479 = load i32, ptr %local.owner.end.12, align 4
  %context.field.480 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.481 = load i32, ptr %context.field.480, align 4
  %stack.sub.484 = sub i32 %local.check.owner.end.479, %local.check.offset.476
  %descriptor.owner.inside.482 = icmp ule i32 %local.check.owner.end.479, %context.value.481
  %descriptor.offset.inside.483 = icmp ule i32 %local.check.offset.476, %local.check.owner.end.479
  %descriptor.extent.inside.485 = icmp ule i32 %local.check.extent.477, %stack.sub.484
  %descriptor.payload.inside.486 = icmp ule i32 %local.check.payload.478, %local.check.extent.477
  %descriptor.owner.offset.valid.487 = and i1 %descriptor.owner.inside.482, %descriptor.offset.inside.483
  %descriptor.range.inside.489 = and i1 %descriptor.owner.offset.valid.487, %descriptor.extent.inside.485
  %descriptor.range.valid.488 = and i1 %descriptor.range.inside.489, %descriptor.payload.inside.486
  br i1 %descriptor.range.valid.488, label %descriptor.valid.490, label %descriptor.invalid.491
descriptor.invalid.491:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.490:
  %descriptor.initialized.status.492 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.476, i32 %local.check.extent.477)
  %helper.ok.493 = icmp eq i32 %descriptor.initialized.status.492, 0
  br i1 %helper.ok.493, label %helper.continue.494, label %frame.failure.0
helper.continue.494:
  br label %local.descriptor.checked.475
local.descriptor.inactive.474:
  br label %local.descriptor.checked.475
local.descriptor.checked.475:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.495 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.496 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.495, i32 0, i32 0
  store i32 5, ptr %descriptor.field.496, align 4
  %descriptor.field.497 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.495, i32 0, i32 1
  store i32 %context.value.354, ptr %descriptor.field.497, align 4
  %descriptor.field.498 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.495, i32 0, i32 2
  store i32 %stack.offset.352, ptr %descriptor.field.498, align 4
  %descriptor.field.499 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.495, i32 0, i32 3
  store i32 %stack.offset.351, ptr %descriptor.field.499, align 4
  %descriptor.field.500 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.495, i32 0, i32 4
  store i32 %stack.offset.355, ptr %descriptor.field.500, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.354, i32 20, i32 %stack.offset.351, i32 %stack.offset.355, i32 %stack.offset.352)
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  %runtime.ok.503 = icmp eq i32 %context.value.502, 0
  br i1 %runtime.ok.503, label %runtime.continue.504, label %frame.failure.0
runtime.continue.504:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %context.field.507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.508 = load i32, ptr %context.field.507, align 4
  %context.field.509 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.510 = load i32, ptr %context.field.509, align 4
  %stack.offset.511 = add i32 %context.value.17, %context.value.19
  %stack.offset.512 = add i32 %context.value.506, %context.value.508
  %stack.sub.513 = sub i32 %stack.offset.511, %stack.offset.512
  %stack.sub.514 = sub i32 %context.value.19, %context.value.508
  %stack.sub.515 = sub i32 %context.value.510, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.513, i32 %stack.sub.514)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.515)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %local.active.38 = alloca i1, align 1
  %local.offset.39 = alloca i32, align 4
  %local.extent.40 = alloca i32, align 4
  %local.payload.41 = alloca i32, align 4
  %local.owner.end.42 = alloca i32, align 4
  %local.type.43 = alloca i32, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %frame.entered.52 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.53 = icmp eq i32 %frame.entered.52, 0
  br i1 %frame.enter.ok.53, label %frame.enter.continue.54, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.54:
  %descriptor.element.55 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 0
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 1
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 2
  %descriptor.value.61 = load i32, ptr %descriptor.field.60, align 4
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 3
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 4
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %argument.type.valid.66 = icmp eq i32 %descriptor.value.57, 5
  br i1 %argument.type.valid.66, label %argument.type.ok.67, label %frame.failure.0
argument.type.ok.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.70 = icmp ule i32 %descriptor.value.65, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.73 = icmp ule i32 %descriptor.value.61, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 5, 5
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %descriptor.element.85 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 0
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 1
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 2
  %descriptor.value.91 = load i32, ptr %descriptor.field.90, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 3
  %descriptor.value.93 = load i32, ptr %descriptor.field.92, align 4
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 4
  %descriptor.value.95 = load i32, ptr %descriptor.field.94, align 4
  %argument.type.valid.96 = icmp eq i32 %descriptor.value.87, 4
  br i1 %argument.type.valid.96, label %argument.type.ok.97, label %frame.failure.0
argument.type.ok.97:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.102 = sub i32 %descriptor.value.95, %descriptor.value.89
  %descriptor.owner.inside.100 = icmp ule i32 %descriptor.value.95, %context.value.99
  %descriptor.offset.inside.101 = icmp ule i32 %descriptor.value.89, %descriptor.value.95
  %descriptor.extent.inside.103 = icmp ule i32 %descriptor.value.91, %stack.sub.102
  %descriptor.payload.inside.104 = icmp ule i32 %descriptor.value.93, %descriptor.value.91
  %descriptor.owner.offset.valid.105 = and i1 %descriptor.owner.inside.100, %descriptor.offset.inside.101
  %descriptor.range.inside.107 = and i1 %descriptor.owner.offset.valid.105, %descriptor.extent.inside.103
  %descriptor.range.valid.106 = and i1 %descriptor.range.inside.107, %descriptor.payload.inside.104
  %descriptor.type.valid.108 = icmp eq i32 4, 4
  %descriptor.valid.109 = and i1 %descriptor.range.valid.106, %descriptor.type.valid.108
  br i1 %descriptor.valid.109, label %descriptor.valid.110, label %descriptor.invalid.111
descriptor.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.110:
  %descriptor.initialized.status.112 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.89, i32 %descriptor.value.91)
  %helper.ok.113 = icmp eq i32 %descriptor.initialized.status.112, 0
  br i1 %helper.ok.113, label %helper.continue.114, label %frame.failure.0
helper.continue.114:
  %descriptor.element.115 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 0
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 1
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 2
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 3
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 4
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %argument.type.valid.126 = icmp eq i32 %descriptor.value.117, 6
  br i1 %argument.type.valid.126, label %argument.type.ok.127, label %frame.failure.0
argument.type.ok.127:
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %stack.sub.132 = sub i32 %descriptor.value.125, %descriptor.value.119
  %descriptor.owner.inside.130 = icmp ule i32 %descriptor.value.125, %context.value.129
  %descriptor.offset.inside.131 = icmp ule i32 %descriptor.value.119, %descriptor.value.125
  %descriptor.extent.inside.133 = icmp ule i32 %descriptor.value.121, %stack.sub.132
  %descriptor.payload.inside.134 = icmp ule i32 %descriptor.value.123, %descriptor.value.121
  %descriptor.owner.offset.valid.135 = and i1 %descriptor.owner.inside.130, %descriptor.offset.inside.131
  %descriptor.range.inside.137 = and i1 %descriptor.owner.offset.valid.135, %descriptor.extent.inside.133
  %descriptor.range.valid.136 = and i1 %descriptor.range.inside.137, %descriptor.payload.inside.134
  %descriptor.type.valid.138 = icmp eq i32 6, 6
  %descriptor.valid.139 = and i1 %descriptor.range.valid.136, %descriptor.type.valid.138
  br i1 %descriptor.valid.139, label %descriptor.valid.140, label %descriptor.invalid.141
descriptor.invalid.141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.140:
  %descriptor.initialized.status.142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.119, i32 %descriptor.value.121)
  %helper.ok.143 = icmp eq i32 %descriptor.initialized.status.142, 0
  br i1 %helper.ok.143, label %helper.continue.144, label %frame.failure.0
helper.continue.144:
  %step.status.145 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.146 = icmp eq i32 %step.status.145, 0
  br i1 %helper.ok.146, label %helper.continue.147, label %frame.failure.0
helper.continue.147:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.119, ptr %local.offset.3, align 4
  store i32 %descriptor.value.121, ptr %local.extent.4, align 4
  store i32 %descriptor.value.123, ptr %local.payload.5, align 4
  store i32 %descriptor.value.125, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.119, i32 20, i32 %descriptor.value.123, i32 %descriptor.value.125, i32 %descriptor.value.121)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.154 = icmp ule i32 %descriptor.value.65, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.157 = icmp ule i32 %descriptor.value.61, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  %descriptor.type.valid.162 = icmp eq i32 5, 5
  %descriptor.valid.163 = and i1 %descriptor.range.valid.160, %descriptor.type.valid.162
  br i1 %descriptor.valid.163, label %descriptor.valid.164, label %descriptor.invalid.165
descriptor.invalid.165:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.164:
  %descriptor.initialized.status.166 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.167 = icmp eq i32 %descriptor.initialized.status.166, 0
  br i1 %helper.ok.167, label %helper.continue.168, label %frame.failure.0
helper.continue.168:
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %descriptor.value.95, %descriptor.value.89
  %descriptor.owner.inside.171 = icmp ule i32 %descriptor.value.95, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %descriptor.value.89, %descriptor.value.95
  %descriptor.extent.inside.174 = icmp ule i32 %descriptor.value.91, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %descriptor.value.93, %descriptor.value.91
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  %descriptor.type.valid.179 = icmp eq i32 4, 4
  %descriptor.valid.180 = and i1 %descriptor.range.valid.177, %descriptor.type.valid.179
  br i1 %descriptor.valid.180, label %descriptor.valid.181, label %descriptor.invalid.182
descriptor.invalid.182:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.181:
  %descriptor.initialized.status.183 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.89, i32 %descriptor.value.91)
  %helper.ok.184 = icmp eq i32 %descriptor.initialized.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %frame.failure.0
helper.continue.185:
  %local.is.active.186 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.186, label %local.descriptor.active.187, label %local.descriptor.inactive.188
local.descriptor.active.187:
  %local.check.offset.190 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.191 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.192 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.193 = load i32, ptr %local.owner.end.6, align 4
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %stack.sub.198 = sub i32 %local.check.owner.end.193, %local.check.offset.190
  %descriptor.owner.inside.196 = icmp ule i32 %local.check.owner.end.193, %context.value.195
  %descriptor.offset.inside.197 = icmp ule i32 %local.check.offset.190, %local.check.owner.end.193
  %descriptor.extent.inside.199 = icmp ule i32 %local.check.extent.191, %stack.sub.198
  %descriptor.payload.inside.200 = icmp ule i32 %local.check.payload.192, %local.check.extent.191
  %descriptor.owner.offset.valid.201 = and i1 %descriptor.owner.inside.196, %descriptor.offset.inside.197
  %descriptor.range.inside.203 = and i1 %descriptor.owner.offset.valid.201, %descriptor.extent.inside.199
  %descriptor.range.valid.202 = and i1 %descriptor.range.inside.203, %descriptor.payload.inside.200
  br i1 %descriptor.range.valid.202, label %descriptor.valid.204, label %descriptor.invalid.205
descriptor.invalid.205:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.204:
  %descriptor.initialized.status.206 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.190, i32 %local.check.extent.191)
  %helper.ok.207 = icmp eq i32 %descriptor.initialized.status.206, 0
  br i1 %helper.ok.207, label %helper.continue.208, label %frame.failure.0
helper.continue.208:
  br label %local.descriptor.checked.189
local.descriptor.inactive.188:
  br label %local.descriptor.checked.189
local.descriptor.checked.189:
  %local.is.active.209 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.209, label %local.descriptor.active.210, label %local.descriptor.inactive.211
local.descriptor.active.210:
  %local.check.offset.213 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.214 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.215 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.216 = load i32, ptr %local.owner.end.12, align 4
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %stack.sub.221 = sub i32 %local.check.owner.end.216, %local.check.offset.213
  %descriptor.owner.inside.219 = icmp ule i32 %local.check.owner.end.216, %context.value.218
  %descriptor.offset.inside.220 = icmp ule i32 %local.check.offset.213, %local.check.owner.end.216
  %descriptor.extent.inside.222 = icmp ule i32 %local.check.extent.214, %stack.sub.221
  %descriptor.payload.inside.223 = icmp ule i32 %local.check.payload.215, %local.check.extent.214
  %descriptor.owner.offset.valid.224 = and i1 %descriptor.owner.inside.219, %descriptor.offset.inside.220
  %descriptor.range.inside.226 = and i1 %descriptor.owner.offset.valid.224, %descriptor.extent.inside.222
  %descriptor.range.valid.225 = and i1 %descriptor.range.inside.226, %descriptor.payload.inside.223
  br i1 %descriptor.range.valid.225, label %descriptor.valid.227, label %descriptor.invalid.228
descriptor.invalid.228:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.227:
  %descriptor.initialized.status.229 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.213, i32 %local.check.extent.214)
  %helper.ok.230 = icmp eq i32 %descriptor.initialized.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  br label %local.descriptor.checked.212
local.descriptor.inactive.211:
  br label %local.descriptor.checked.212
local.descriptor.checked.212:
  %local.is.active.232 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.232, label %local.descriptor.active.233, label %local.descriptor.inactive.234
local.descriptor.active.233:
  %local.check.offset.236 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.237 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.238 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.239 = load i32, ptr %local.owner.end.18, align 4
  %context.field.240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.241 = load i32, ptr %context.field.240, align 4
  %stack.sub.244 = sub i32 %local.check.owner.end.239, %local.check.offset.236
  %descriptor.owner.inside.242 = icmp ule i32 %local.check.owner.end.239, %context.value.241
  %descriptor.offset.inside.243 = icmp ule i32 %local.check.offset.236, %local.check.owner.end.239
  %descriptor.extent.inside.245 = icmp ule i32 %local.check.extent.237, %stack.sub.244
  %descriptor.payload.inside.246 = icmp ule i32 %local.check.payload.238, %local.check.extent.237
  %descriptor.owner.offset.valid.247 = and i1 %descriptor.owner.inside.242, %descriptor.offset.inside.243
  %descriptor.range.inside.249 = and i1 %descriptor.owner.offset.valid.247, %descriptor.extent.inside.245
  %descriptor.range.valid.248 = and i1 %descriptor.range.inside.249, %descriptor.payload.inside.246
  br i1 %descriptor.range.valid.248, label %descriptor.valid.250, label %descriptor.invalid.251
descriptor.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.250:
  %descriptor.initialized.status.252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.236, i32 %local.check.extent.237)
  %helper.ok.253 = icmp eq i32 %descriptor.initialized.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  br label %local.descriptor.checked.235
local.descriptor.inactive.234:
  br label %local.descriptor.checked.235
local.descriptor.checked.235:
  %local.is.active.255 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.255, label %local.descriptor.active.256, label %local.descriptor.inactive.257
local.descriptor.active.256:
  %local.check.offset.259 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.260 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.261 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.262 = load i32, ptr %local.owner.end.24, align 4
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %stack.sub.267 = sub i32 %local.check.owner.end.262, %local.check.offset.259
  %descriptor.owner.inside.265 = icmp ule i32 %local.check.owner.end.262, %context.value.264
  %descriptor.offset.inside.266 = icmp ule i32 %local.check.offset.259, %local.check.owner.end.262
  %descriptor.extent.inside.268 = icmp ule i32 %local.check.extent.260, %stack.sub.267
  %descriptor.payload.inside.269 = icmp ule i32 %local.check.payload.261, %local.check.extent.260
  %descriptor.owner.offset.valid.270 = and i1 %descriptor.owner.inside.265, %descriptor.offset.inside.266
  %descriptor.range.inside.272 = and i1 %descriptor.owner.offset.valid.270, %descriptor.extent.inside.268
  %descriptor.range.valid.271 = and i1 %descriptor.range.inside.272, %descriptor.payload.inside.269
  br i1 %descriptor.range.valid.271, label %descriptor.valid.273, label %descriptor.invalid.274
descriptor.invalid.274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.273:
  %descriptor.initialized.status.275 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.259, i32 %local.check.extent.260)
  %helper.ok.276 = icmp eq i32 %descriptor.initialized.status.275, 0
  br i1 %helper.ok.276, label %helper.continue.277, label %frame.failure.0
helper.continue.277:
  br label %local.descriptor.checked.258
local.descriptor.inactive.257:
  br label %local.descriptor.checked.258
local.descriptor.checked.258:
  %local.is.active.278 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.30, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %local.is.active.301 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.36, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %local.is.active.324 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.324, label %local.descriptor.active.325, label %local.descriptor.inactive.326
local.descriptor.active.325:
  %local.check.offset.328 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.329 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.330 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.331 = load i32, ptr %local.owner.end.42, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %local.check.owner.end.331, %local.check.offset.328
  %descriptor.owner.inside.334 = icmp ule i32 %local.check.owner.end.331, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %local.check.offset.328, %local.check.owner.end.331
  %descriptor.extent.inside.337 = icmp ule i32 %local.check.extent.329, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %local.check.payload.330, %local.check.extent.329
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  br i1 %descriptor.range.valid.340, label %descriptor.valid.342, label %descriptor.invalid.343
descriptor.invalid.343:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.342:
  %descriptor.initialized.status.344 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.328, i32 %local.check.extent.329)
  %helper.ok.345 = icmp eq i32 %descriptor.initialized.status.344, 0
  br i1 %helper.ok.345, label %helper.continue.346, label %frame.failure.0
helper.continue.346:
  br label %local.descriptor.checked.327
local.descriptor.inactive.326:
  br label %local.descriptor.checked.327
local.descriptor.checked.327:
  %step.status.347 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.348 = icmp eq i32 %step.status.347, 0
  br i1 %helper.ok.348, label %helper.continue.349, label %frame.failure.0
helper.continue.349:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.89, ptr %local.offset.9, align 4
  store i32 %descriptor.value.91, ptr %local.extent.10, align 4
  store i32 %descriptor.value.93, ptr %local.payload.11, align 4
  store i32 %descriptor.value.95, ptr %local.owner.end.12, align 4
  store i32 4, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.89, i32 20, i32 %descriptor.value.93, i32 %descriptor.value.95, i32 %descriptor.value.91)
  %context.field.350 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.351 = load i32, ptr %context.field.350, align 4
  %runtime.ok.352 = icmp eq i32 %context.value.351, 0
  br i1 %runtime.ok.352, label %runtime.continue.353, label %frame.failure.0
runtime.continue.353:
  %context.field.354 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.355 = load i32, ptr %context.field.354, align 4
  %stack.sub.358 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.356 = icmp ule i32 %descriptor.value.65, %context.value.355
  %descriptor.offset.inside.357 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.359 = icmp ule i32 %descriptor.value.61, %stack.sub.358
  %descriptor.payload.inside.360 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.361 = and i1 %descriptor.owner.inside.356, %descriptor.offset.inside.357
  %descriptor.range.inside.363 = and i1 %descriptor.owner.offset.valid.361, %descriptor.extent.inside.359
  %descriptor.range.valid.362 = and i1 %descriptor.range.inside.363, %descriptor.payload.inside.360
  %descriptor.type.valid.364 = icmp eq i32 5, 5
  %descriptor.valid.365 = and i1 %descriptor.range.valid.362, %descriptor.type.valid.364
  br i1 %descriptor.valid.365, label %descriptor.valid.366, label %descriptor.invalid.367
descriptor.invalid.367:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.366:
  %descriptor.initialized.status.368 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.369 = icmp eq i32 %descriptor.initialized.status.368, 0
  br i1 %helper.ok.369, label %helper.continue.370, label %frame.failure.0
helper.continue.370:
  %local.is.active.371 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.371, label %local.descriptor.active.372, label %local.descriptor.inactive.373
local.descriptor.active.372:
  %local.check.offset.375 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.376 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.377 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.378 = load i32, ptr %local.owner.end.6, align 4
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %stack.sub.383 = sub i32 %local.check.owner.end.378, %local.check.offset.375
  %descriptor.owner.inside.381 = icmp ule i32 %local.check.owner.end.378, %context.value.380
  %descriptor.offset.inside.382 = icmp ule i32 %local.check.offset.375, %local.check.owner.end.378
  %descriptor.extent.inside.384 = icmp ule i32 %local.check.extent.376, %stack.sub.383
  %descriptor.payload.inside.385 = icmp ule i32 %local.check.payload.377, %local.check.extent.376
  %descriptor.owner.offset.valid.386 = and i1 %descriptor.owner.inside.381, %descriptor.offset.inside.382
  %descriptor.range.inside.388 = and i1 %descriptor.owner.offset.valid.386, %descriptor.extent.inside.384
  %descriptor.range.valid.387 = and i1 %descriptor.range.inside.388, %descriptor.payload.inside.385
  br i1 %descriptor.range.valid.387, label %descriptor.valid.389, label %descriptor.invalid.390
descriptor.invalid.390:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.389:
  %descriptor.initialized.status.391 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.375, i32 %local.check.extent.376)
  %helper.ok.392 = icmp eq i32 %descriptor.initialized.status.391, 0
  br i1 %helper.ok.392, label %helper.continue.393, label %frame.failure.0
helper.continue.393:
  br label %local.descriptor.checked.374
local.descriptor.inactive.373:
  br label %local.descriptor.checked.374
local.descriptor.checked.374:
  %local.is.active.394 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.394, label %local.descriptor.active.395, label %local.descriptor.inactive.396
local.descriptor.active.395:
  %local.check.offset.398 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.399 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.400 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.401 = load i32, ptr %local.owner.end.12, align 4
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %stack.sub.406 = sub i32 %local.check.owner.end.401, %local.check.offset.398
  %descriptor.owner.inside.404 = icmp ule i32 %local.check.owner.end.401, %context.value.403
  %descriptor.offset.inside.405 = icmp ule i32 %local.check.offset.398, %local.check.owner.end.401
  %descriptor.extent.inside.407 = icmp ule i32 %local.check.extent.399, %stack.sub.406
  %descriptor.payload.inside.408 = icmp ule i32 %local.check.payload.400, %local.check.extent.399
  %descriptor.owner.offset.valid.409 = and i1 %descriptor.owner.inside.404, %descriptor.offset.inside.405
  %descriptor.range.inside.411 = and i1 %descriptor.owner.offset.valid.409, %descriptor.extent.inside.407
  %descriptor.range.valid.410 = and i1 %descriptor.range.inside.411, %descriptor.payload.inside.408
  br i1 %descriptor.range.valid.410, label %descriptor.valid.412, label %descriptor.invalid.413
descriptor.invalid.413:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.412:
  %descriptor.initialized.status.414 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.398, i32 %local.check.extent.399)
  %helper.ok.415 = icmp eq i32 %descriptor.initialized.status.414, 0
  br i1 %helper.ok.415, label %helper.continue.416, label %frame.failure.0
helper.continue.416:
  br label %local.descriptor.checked.397
local.descriptor.inactive.396:
  br label %local.descriptor.checked.397
local.descriptor.checked.397:
  %local.is.active.417 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.417, label %local.descriptor.active.418, label %local.descriptor.inactive.419
local.descriptor.active.418:
  %local.check.offset.421 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.422 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.423 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.424 = load i32, ptr %local.owner.end.18, align 4
  %context.field.425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.426 = load i32, ptr %context.field.425, align 4
  %stack.sub.429 = sub i32 %local.check.owner.end.424, %local.check.offset.421
  %descriptor.owner.inside.427 = icmp ule i32 %local.check.owner.end.424, %context.value.426
  %descriptor.offset.inside.428 = icmp ule i32 %local.check.offset.421, %local.check.owner.end.424
  %descriptor.extent.inside.430 = icmp ule i32 %local.check.extent.422, %stack.sub.429
  %descriptor.payload.inside.431 = icmp ule i32 %local.check.payload.423, %local.check.extent.422
  %descriptor.owner.offset.valid.432 = and i1 %descriptor.owner.inside.427, %descriptor.offset.inside.428
  %descriptor.range.inside.434 = and i1 %descriptor.owner.offset.valid.432, %descriptor.extent.inside.430
  %descriptor.range.valid.433 = and i1 %descriptor.range.inside.434, %descriptor.payload.inside.431
  br i1 %descriptor.range.valid.433, label %descriptor.valid.435, label %descriptor.invalid.436
descriptor.invalid.436:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.435:
  %descriptor.initialized.status.437 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.421, i32 %local.check.extent.422)
  %helper.ok.438 = icmp eq i32 %descriptor.initialized.status.437, 0
  br i1 %helper.ok.438, label %helper.continue.439, label %frame.failure.0
helper.continue.439:
  br label %local.descriptor.checked.420
local.descriptor.inactive.419:
  br label %local.descriptor.checked.420
local.descriptor.checked.420:
  %local.is.active.440 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.440, label %local.descriptor.active.441, label %local.descriptor.inactive.442
local.descriptor.active.441:
  %local.check.offset.444 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.445 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.446 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.447 = load i32, ptr %local.owner.end.24, align 4
  %context.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.449 = load i32, ptr %context.field.448, align 4
  %stack.sub.452 = sub i32 %local.check.owner.end.447, %local.check.offset.444
  %descriptor.owner.inside.450 = icmp ule i32 %local.check.owner.end.447, %context.value.449
  %descriptor.offset.inside.451 = icmp ule i32 %local.check.offset.444, %local.check.owner.end.447
  %descriptor.extent.inside.453 = icmp ule i32 %local.check.extent.445, %stack.sub.452
  %descriptor.payload.inside.454 = icmp ule i32 %local.check.payload.446, %local.check.extent.445
  %descriptor.owner.offset.valid.455 = and i1 %descriptor.owner.inside.450, %descriptor.offset.inside.451
  %descriptor.range.inside.457 = and i1 %descriptor.owner.offset.valid.455, %descriptor.extent.inside.453
  %descriptor.range.valid.456 = and i1 %descriptor.range.inside.457, %descriptor.payload.inside.454
  br i1 %descriptor.range.valid.456, label %descriptor.valid.458, label %descriptor.invalid.459
descriptor.invalid.459:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.458:
  %descriptor.initialized.status.460 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.444, i32 %local.check.extent.445)
  %helper.ok.461 = icmp eq i32 %descriptor.initialized.status.460, 0
  br i1 %helper.ok.461, label %helper.continue.462, label %frame.failure.0
helper.continue.462:
  br label %local.descriptor.checked.443
local.descriptor.inactive.442:
  br label %local.descriptor.checked.443
local.descriptor.checked.443:
  %local.is.active.463 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.463, label %local.descriptor.active.464, label %local.descriptor.inactive.465
local.descriptor.active.464:
  %local.check.offset.467 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.468 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.469 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.470 = load i32, ptr %local.owner.end.30, align 4
  %context.field.471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.472 = load i32, ptr %context.field.471, align 4
  %stack.sub.475 = sub i32 %local.check.owner.end.470, %local.check.offset.467
  %descriptor.owner.inside.473 = icmp ule i32 %local.check.owner.end.470, %context.value.472
  %descriptor.offset.inside.474 = icmp ule i32 %local.check.offset.467, %local.check.owner.end.470
  %descriptor.extent.inside.476 = icmp ule i32 %local.check.extent.468, %stack.sub.475
  %descriptor.payload.inside.477 = icmp ule i32 %local.check.payload.469, %local.check.extent.468
  %descriptor.owner.offset.valid.478 = and i1 %descriptor.owner.inside.473, %descriptor.offset.inside.474
  %descriptor.range.inside.480 = and i1 %descriptor.owner.offset.valid.478, %descriptor.extent.inside.476
  %descriptor.range.valid.479 = and i1 %descriptor.range.inside.480, %descriptor.payload.inside.477
  br i1 %descriptor.range.valid.479, label %descriptor.valid.481, label %descriptor.invalid.482
descriptor.invalid.482:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.481:
  %descriptor.initialized.status.483 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.467, i32 %local.check.extent.468)
  %helper.ok.484 = icmp eq i32 %descriptor.initialized.status.483, 0
  br i1 %helper.ok.484, label %helper.continue.485, label %frame.failure.0
helper.continue.485:
  br label %local.descriptor.checked.466
local.descriptor.inactive.465:
  br label %local.descriptor.checked.466
local.descriptor.checked.466:
  %local.is.active.486 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.486, label %local.descriptor.active.487, label %local.descriptor.inactive.488
local.descriptor.active.487:
  %local.check.offset.490 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.491 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.492 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.493 = load i32, ptr %local.owner.end.36, align 4
  %context.field.494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.495 = load i32, ptr %context.field.494, align 4
  %stack.sub.498 = sub i32 %local.check.owner.end.493, %local.check.offset.490
  %descriptor.owner.inside.496 = icmp ule i32 %local.check.owner.end.493, %context.value.495
  %descriptor.offset.inside.497 = icmp ule i32 %local.check.offset.490, %local.check.owner.end.493
  %descriptor.extent.inside.499 = icmp ule i32 %local.check.extent.491, %stack.sub.498
  %descriptor.payload.inside.500 = icmp ule i32 %local.check.payload.492, %local.check.extent.491
  %descriptor.owner.offset.valid.501 = and i1 %descriptor.owner.inside.496, %descriptor.offset.inside.497
  %descriptor.range.inside.503 = and i1 %descriptor.owner.offset.valid.501, %descriptor.extent.inside.499
  %descriptor.range.valid.502 = and i1 %descriptor.range.inside.503, %descriptor.payload.inside.500
  br i1 %descriptor.range.valid.502, label %descriptor.valid.504, label %descriptor.invalid.505
descriptor.invalid.505:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.504:
  %descriptor.initialized.status.506 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.490, i32 %local.check.extent.491)
  %helper.ok.507 = icmp eq i32 %descriptor.initialized.status.506, 0
  br i1 %helper.ok.507, label %helper.continue.508, label %frame.failure.0
helper.continue.508:
  br label %local.descriptor.checked.489
local.descriptor.inactive.488:
  br label %local.descriptor.checked.489
local.descriptor.checked.489:
  %local.is.active.509 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.509, label %local.descriptor.active.510, label %local.descriptor.inactive.511
local.descriptor.active.510:
  %local.check.offset.513 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.514 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.515 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.516 = load i32, ptr %local.owner.end.42, align 4
  %context.field.517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.518 = load i32, ptr %context.field.517, align 4
  %stack.sub.521 = sub i32 %local.check.owner.end.516, %local.check.offset.513
  %descriptor.owner.inside.519 = icmp ule i32 %local.check.owner.end.516, %context.value.518
  %descriptor.offset.inside.520 = icmp ule i32 %local.check.offset.513, %local.check.owner.end.516
  %descriptor.extent.inside.522 = icmp ule i32 %local.check.extent.514, %stack.sub.521
  %descriptor.payload.inside.523 = icmp ule i32 %local.check.payload.515, %local.check.extent.514
  %descriptor.owner.offset.valid.524 = and i1 %descriptor.owner.inside.519, %descriptor.offset.inside.520
  %descriptor.range.inside.526 = and i1 %descriptor.owner.offset.valid.524, %descriptor.extent.inside.522
  %descriptor.range.valid.525 = and i1 %descriptor.range.inside.526, %descriptor.payload.inside.523
  br i1 %descriptor.range.valid.525, label %descriptor.valid.527, label %descriptor.invalid.528
descriptor.invalid.528:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.527:
  %descriptor.initialized.status.529 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.513, i32 %local.check.extent.514)
  %helper.ok.530 = icmp eq i32 %descriptor.initialized.status.529, 0
  br i1 %helper.ok.530, label %helper.continue.531, label %frame.failure.0
helper.continue.531:
  br label %local.descriptor.checked.512
local.descriptor.inactive.511:
  br label %local.descriptor.checked.512
local.descriptor.checked.512:
  %step.status.532 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.533 = icmp eq i32 %step.status.532, 0
  br i1 %helper.ok.533, label %helper.continue.534, label %frame.failure.0
helper.continue.534:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.59, ptr %local.offset.15, align 4
  store i32 %descriptor.value.61, ptr %local.extent.16, align 4
  store i32 %descriptor.value.63, ptr %local.payload.17, align 4
  store i32 %descriptor.value.65, ptr %local.owner.end.18, align 4
  store i32 5, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.59, i32 20, i32 %descriptor.value.63, i32 %descriptor.value.65, i32 %descriptor.value.61)
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %runtime.ok.537 = icmp eq i32 %context.value.536, 0
  br i1 %runtime.ok.537, label %runtime.continue.538, label %frame.failure.0
runtime.continue.538:
  %local.is.active.539 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.539, label %local.descriptor.active.540, label %local.descriptor.inactive.541
local.descriptor.active.540:
  %local.check.offset.543 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.544 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.545 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.546 = load i32, ptr %local.owner.end.6, align 4
  %context.field.547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.548 = load i32, ptr %context.field.547, align 4
  %stack.sub.551 = sub i32 %local.check.owner.end.546, %local.check.offset.543
  %descriptor.owner.inside.549 = icmp ule i32 %local.check.owner.end.546, %context.value.548
  %descriptor.offset.inside.550 = icmp ule i32 %local.check.offset.543, %local.check.owner.end.546
  %descriptor.extent.inside.552 = icmp ule i32 %local.check.extent.544, %stack.sub.551
  %descriptor.payload.inside.553 = icmp ule i32 %local.check.payload.545, %local.check.extent.544
  %descriptor.owner.offset.valid.554 = and i1 %descriptor.owner.inside.549, %descriptor.offset.inside.550
  %descriptor.range.inside.556 = and i1 %descriptor.owner.offset.valid.554, %descriptor.extent.inside.552
  %descriptor.range.valid.555 = and i1 %descriptor.range.inside.556, %descriptor.payload.inside.553
  br i1 %descriptor.range.valid.555, label %descriptor.valid.557, label %descriptor.invalid.558
descriptor.invalid.558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.557:
  %descriptor.initialized.status.559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.543, i32 %local.check.extent.544)
  %helper.ok.560 = icmp eq i32 %descriptor.initialized.status.559, 0
  br i1 %helper.ok.560, label %helper.continue.561, label %frame.failure.0
helper.continue.561:
  br label %local.descriptor.checked.542
local.descriptor.inactive.541:
  br label %local.descriptor.checked.542
local.descriptor.checked.542:
  %local.is.active.562 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.562, label %local.descriptor.active.563, label %local.descriptor.inactive.564
local.descriptor.active.563:
  %local.check.offset.566 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.567 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.568 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.569 = load i32, ptr %local.owner.end.12, align 4
  %context.field.570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.571 = load i32, ptr %context.field.570, align 4
  %stack.sub.574 = sub i32 %local.check.owner.end.569, %local.check.offset.566
  %descriptor.owner.inside.572 = icmp ule i32 %local.check.owner.end.569, %context.value.571
  %descriptor.offset.inside.573 = icmp ule i32 %local.check.offset.566, %local.check.owner.end.569
  %descriptor.extent.inside.575 = icmp ule i32 %local.check.extent.567, %stack.sub.574
  %descriptor.payload.inside.576 = icmp ule i32 %local.check.payload.568, %local.check.extent.567
  %descriptor.owner.offset.valid.577 = and i1 %descriptor.owner.inside.572, %descriptor.offset.inside.573
  %descriptor.range.inside.579 = and i1 %descriptor.owner.offset.valid.577, %descriptor.extent.inside.575
  %descriptor.range.valid.578 = and i1 %descriptor.range.inside.579, %descriptor.payload.inside.576
  br i1 %descriptor.range.valid.578, label %descriptor.valid.580, label %descriptor.invalid.581
descriptor.invalid.581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.580:
  %descriptor.initialized.status.582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.566, i32 %local.check.extent.567)
  %helper.ok.583 = icmp eq i32 %descriptor.initialized.status.582, 0
  br i1 %helper.ok.583, label %helper.continue.584, label %frame.failure.0
helper.continue.584:
  br label %local.descriptor.checked.565
local.descriptor.inactive.564:
  br label %local.descriptor.checked.565
local.descriptor.checked.565:
  %local.is.active.585 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.585, label %local.descriptor.active.586, label %local.descriptor.inactive.587
local.descriptor.active.586:
  %local.check.offset.589 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.590 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.591 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.592 = load i32, ptr %local.owner.end.18, align 4
  %context.field.593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.594 = load i32, ptr %context.field.593, align 4
  %stack.sub.597 = sub i32 %local.check.owner.end.592, %local.check.offset.589
  %descriptor.owner.inside.595 = icmp ule i32 %local.check.owner.end.592, %context.value.594
  %descriptor.offset.inside.596 = icmp ule i32 %local.check.offset.589, %local.check.owner.end.592
  %descriptor.extent.inside.598 = icmp ule i32 %local.check.extent.590, %stack.sub.597
  %descriptor.payload.inside.599 = icmp ule i32 %local.check.payload.591, %local.check.extent.590
  %descriptor.owner.offset.valid.600 = and i1 %descriptor.owner.inside.595, %descriptor.offset.inside.596
  %descriptor.range.inside.602 = and i1 %descriptor.owner.offset.valid.600, %descriptor.extent.inside.598
  %descriptor.range.valid.601 = and i1 %descriptor.range.inside.602, %descriptor.payload.inside.599
  br i1 %descriptor.range.valid.601, label %descriptor.valid.603, label %descriptor.invalid.604
descriptor.invalid.604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.603:
  %descriptor.initialized.status.605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.589, i32 %local.check.extent.590)
  %helper.ok.606 = icmp eq i32 %descriptor.initialized.status.605, 0
  br i1 %helper.ok.606, label %helper.continue.607, label %frame.failure.0
helper.continue.607:
  br label %local.descriptor.checked.588
local.descriptor.inactive.587:
  br label %local.descriptor.checked.588
local.descriptor.checked.588:
  %local.is.active.608 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.608, label %local.descriptor.active.609, label %local.descriptor.inactive.610
local.descriptor.active.609:
  %local.check.offset.612 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.613 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.614 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.615 = load i32, ptr %local.owner.end.24, align 4
  %context.field.616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.617 = load i32, ptr %context.field.616, align 4
  %stack.sub.620 = sub i32 %local.check.owner.end.615, %local.check.offset.612
  %descriptor.owner.inside.618 = icmp ule i32 %local.check.owner.end.615, %context.value.617
  %descriptor.offset.inside.619 = icmp ule i32 %local.check.offset.612, %local.check.owner.end.615
  %descriptor.extent.inside.621 = icmp ule i32 %local.check.extent.613, %stack.sub.620
  %descriptor.payload.inside.622 = icmp ule i32 %local.check.payload.614, %local.check.extent.613
  %descriptor.owner.offset.valid.623 = and i1 %descriptor.owner.inside.618, %descriptor.offset.inside.619
  %descriptor.range.inside.625 = and i1 %descriptor.owner.offset.valid.623, %descriptor.extent.inside.621
  %descriptor.range.valid.624 = and i1 %descriptor.range.inside.625, %descriptor.payload.inside.622
  br i1 %descriptor.range.valid.624, label %descriptor.valid.626, label %descriptor.invalid.627
descriptor.invalid.627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.626:
  %descriptor.initialized.status.628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.612, i32 %local.check.extent.613)
  %helper.ok.629 = icmp eq i32 %descriptor.initialized.status.628, 0
  br i1 %helper.ok.629, label %helper.continue.630, label %frame.failure.0
helper.continue.630:
  br label %local.descriptor.checked.611
local.descriptor.inactive.610:
  br label %local.descriptor.checked.611
local.descriptor.checked.611:
  %local.is.active.631 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.631, label %local.descriptor.active.632, label %local.descriptor.inactive.633
local.descriptor.active.632:
  %local.check.offset.635 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.636 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.637 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.638 = load i32, ptr %local.owner.end.30, align 4
  %context.field.639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.640 = load i32, ptr %context.field.639, align 4
  %stack.sub.643 = sub i32 %local.check.owner.end.638, %local.check.offset.635
  %descriptor.owner.inside.641 = icmp ule i32 %local.check.owner.end.638, %context.value.640
  %descriptor.offset.inside.642 = icmp ule i32 %local.check.offset.635, %local.check.owner.end.638
  %descriptor.extent.inside.644 = icmp ule i32 %local.check.extent.636, %stack.sub.643
  %descriptor.payload.inside.645 = icmp ule i32 %local.check.payload.637, %local.check.extent.636
  %descriptor.owner.offset.valid.646 = and i1 %descriptor.owner.inside.641, %descriptor.offset.inside.642
  %descriptor.range.inside.648 = and i1 %descriptor.owner.offset.valid.646, %descriptor.extent.inside.644
  %descriptor.range.valid.647 = and i1 %descriptor.range.inside.648, %descriptor.payload.inside.645
  br i1 %descriptor.range.valid.647, label %descriptor.valid.649, label %descriptor.invalid.650
descriptor.invalid.650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.649:
  %descriptor.initialized.status.651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.635, i32 %local.check.extent.636)
  %helper.ok.652 = icmp eq i32 %descriptor.initialized.status.651, 0
  br i1 %helper.ok.652, label %helper.continue.653, label %frame.failure.0
helper.continue.653:
  br label %local.descriptor.checked.634
local.descriptor.inactive.633:
  br label %local.descriptor.checked.634
local.descriptor.checked.634:
  %local.is.active.654 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.654, label %local.descriptor.active.655, label %local.descriptor.inactive.656
local.descriptor.active.655:
  %local.check.offset.658 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.659 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.660 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.661 = load i32, ptr %local.owner.end.36, align 4
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %stack.sub.666 = sub i32 %local.check.owner.end.661, %local.check.offset.658
  %descriptor.owner.inside.664 = icmp ule i32 %local.check.owner.end.661, %context.value.663
  %descriptor.offset.inside.665 = icmp ule i32 %local.check.offset.658, %local.check.owner.end.661
  %descriptor.extent.inside.667 = icmp ule i32 %local.check.extent.659, %stack.sub.666
  %descriptor.payload.inside.668 = icmp ule i32 %local.check.payload.660, %local.check.extent.659
  %descriptor.owner.offset.valid.669 = and i1 %descriptor.owner.inside.664, %descriptor.offset.inside.665
  %descriptor.range.inside.671 = and i1 %descriptor.owner.offset.valid.669, %descriptor.extent.inside.667
  %descriptor.range.valid.670 = and i1 %descriptor.range.inside.671, %descriptor.payload.inside.668
  br i1 %descriptor.range.valid.670, label %descriptor.valid.672, label %descriptor.invalid.673
descriptor.invalid.673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.672:
  %descriptor.initialized.status.674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.658, i32 %local.check.extent.659)
  %helper.ok.675 = icmp eq i32 %descriptor.initialized.status.674, 0
  br i1 %helper.ok.675, label %helper.continue.676, label %frame.failure.0
helper.continue.676:
  br label %local.descriptor.checked.657
local.descriptor.inactive.656:
  br label %local.descriptor.checked.657
local.descriptor.checked.657:
  %local.is.active.677 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.677, label %local.descriptor.active.678, label %local.descriptor.inactive.679
local.descriptor.active.678:
  %local.check.offset.681 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.682 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.683 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.684 = load i32, ptr %local.owner.end.42, align 4
  %context.field.685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.686 = load i32, ptr %context.field.685, align 4
  %stack.sub.689 = sub i32 %local.check.owner.end.684, %local.check.offset.681
  %descriptor.owner.inside.687 = icmp ule i32 %local.check.owner.end.684, %context.value.686
  %descriptor.offset.inside.688 = icmp ule i32 %local.check.offset.681, %local.check.owner.end.684
  %descriptor.extent.inside.690 = icmp ule i32 %local.check.extent.682, %stack.sub.689
  %descriptor.payload.inside.691 = icmp ule i32 %local.check.payload.683, %local.check.extent.682
  %descriptor.owner.offset.valid.692 = and i1 %descriptor.owner.inside.687, %descriptor.offset.inside.688
  %descriptor.range.inside.694 = and i1 %descriptor.owner.offset.valid.692, %descriptor.extent.inside.690
  %descriptor.range.valid.693 = and i1 %descriptor.range.inside.694, %descriptor.payload.inside.691
  br i1 %descriptor.range.valid.693, label %descriptor.valid.695, label %descriptor.invalid.696
descriptor.invalid.696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.695:
  %descriptor.initialized.status.697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.681, i32 %local.check.extent.682)
  %helper.ok.698 = icmp eq i32 %descriptor.initialized.status.697, 0
  br i1 %helper.ok.698, label %helper.continue.699, label %frame.failure.0
helper.continue.699:
  br label %local.descriptor.checked.680
local.descriptor.inactive.679:
  br label %local.descriptor.checked.680
local.descriptor.checked.680:
  %step.status.700 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.701 = icmp eq i32 %step.status.700, 0
  br i1 %helper.ok.701, label %helper.continue.702, label %frame.failure.0
helper.continue.702:
  %local.resolved.offset.703 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.704 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.705 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.706 = load i32, ptr %local.owner.end.6, align 4
  %context.field.707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.708 = load i32, ptr %context.field.707, align 4
  %stack.sub.711 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.709 = icmp ule i32 %local.resolved.owner.end.706, %context.value.708
  %descriptor.offset.inside.710 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.712 = icmp ule i32 %local.resolved.extent.704, %stack.sub.711
  %descriptor.payload.inside.713 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.714 = and i1 %descriptor.owner.inside.709, %descriptor.offset.inside.710
  %descriptor.range.inside.716 = and i1 %descriptor.owner.offset.valid.714, %descriptor.extent.inside.712
  %descriptor.range.valid.715 = and i1 %descriptor.range.inside.716, %descriptor.payload.inside.713
  %descriptor.type.valid.717 = icmp eq i32 6, 6
  %descriptor.valid.718 = and i1 %descriptor.range.valid.715, %descriptor.type.valid.717
  br i1 %descriptor.valid.718, label %descriptor.valid.719, label %descriptor.invalid.720
descriptor.invalid.720:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.719:
  %descriptor.initialized.status.721 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.722 = icmp eq i32 %descriptor.initialized.status.721, 0
  br i1 %helper.ok.722, label %helper.continue.723, label %frame.failure.0
helper.continue.723:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.703, i32 20, i32 %local.resolved.payload.705, i32 %local.resolved.owner.end.706, i32 %local.resolved.extent.704)
  %context.field.724 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.725 = load i32, ptr %context.field.724, align 4
  %runtime.ok.726 = icmp eq i32 %context.value.725, 0
  br i1 %runtime.ok.726, label %runtime.continue.727, label %frame.failure.0
runtime.continue.727:
  %context.field.728 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.729 = load i32, ptr %context.field.728, align 4
  %stack.sub.732 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.730 = icmp ule i32 %local.resolved.owner.end.706, %context.value.729
  %descriptor.offset.inside.731 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.733 = icmp ule i32 %local.resolved.extent.704, %stack.sub.732
  %descriptor.payload.inside.734 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.735 = and i1 %descriptor.owner.inside.730, %descriptor.offset.inside.731
  %descriptor.range.inside.737 = and i1 %descriptor.owner.offset.valid.735, %descriptor.extent.inside.733
  %descriptor.range.valid.736 = and i1 %descriptor.range.inside.737, %descriptor.payload.inside.734
  %descriptor.type.valid.738 = icmp eq i32 6, 6
  %descriptor.valid.739 = and i1 %descriptor.range.valid.736, %descriptor.type.valid.738
  br i1 %descriptor.valid.739, label %descriptor.valid.740, label %descriptor.invalid.741
descriptor.invalid.741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.740:
  %descriptor.initialized.status.742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.743 = icmp eq i32 %descriptor.initialized.status.742, 0
  br i1 %helper.ok.743, label %helper.continue.744, label %frame.failure.0
helper.continue.744:
  %local.is.active.745 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.745, label %local.descriptor.active.746, label %local.descriptor.inactive.747
local.descriptor.active.746:
  %local.check.offset.749 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.750 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.751 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.752 = load i32, ptr %local.owner.end.6, align 4
  %context.field.753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.754 = load i32, ptr %context.field.753, align 4
  %stack.sub.757 = sub i32 %local.check.owner.end.752, %local.check.offset.749
  %descriptor.owner.inside.755 = icmp ule i32 %local.check.owner.end.752, %context.value.754
  %descriptor.offset.inside.756 = icmp ule i32 %local.check.offset.749, %local.check.owner.end.752
  %descriptor.extent.inside.758 = icmp ule i32 %local.check.extent.750, %stack.sub.757
  %descriptor.payload.inside.759 = icmp ule i32 %local.check.payload.751, %local.check.extent.750
  %descriptor.owner.offset.valid.760 = and i1 %descriptor.owner.inside.755, %descriptor.offset.inside.756
  %descriptor.range.inside.762 = and i1 %descriptor.owner.offset.valid.760, %descriptor.extent.inside.758
  %descriptor.range.valid.761 = and i1 %descriptor.range.inside.762, %descriptor.payload.inside.759
  br i1 %descriptor.range.valid.761, label %descriptor.valid.763, label %descriptor.invalid.764
descriptor.invalid.764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.763:
  %descriptor.initialized.status.765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.749, i32 %local.check.extent.750)
  %helper.ok.766 = icmp eq i32 %descriptor.initialized.status.765, 0
  br i1 %helper.ok.766, label %helper.continue.767, label %frame.failure.0
helper.continue.767:
  br label %local.descriptor.checked.748
local.descriptor.inactive.747:
  br label %local.descriptor.checked.748
local.descriptor.checked.748:
  %local.is.active.768 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.768, label %local.descriptor.active.769, label %local.descriptor.inactive.770
local.descriptor.active.769:
  %local.check.offset.772 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.773 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.774 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.775 = load i32, ptr %local.owner.end.12, align 4
  %context.field.776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.777 = load i32, ptr %context.field.776, align 4
  %stack.sub.780 = sub i32 %local.check.owner.end.775, %local.check.offset.772
  %descriptor.owner.inside.778 = icmp ule i32 %local.check.owner.end.775, %context.value.777
  %descriptor.offset.inside.779 = icmp ule i32 %local.check.offset.772, %local.check.owner.end.775
  %descriptor.extent.inside.781 = icmp ule i32 %local.check.extent.773, %stack.sub.780
  %descriptor.payload.inside.782 = icmp ule i32 %local.check.payload.774, %local.check.extent.773
  %descriptor.owner.offset.valid.783 = and i1 %descriptor.owner.inside.778, %descriptor.offset.inside.779
  %descriptor.range.inside.785 = and i1 %descriptor.owner.offset.valid.783, %descriptor.extent.inside.781
  %descriptor.range.valid.784 = and i1 %descriptor.range.inside.785, %descriptor.payload.inside.782
  br i1 %descriptor.range.valid.784, label %descriptor.valid.786, label %descriptor.invalid.787
descriptor.invalid.787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.786:
  %descriptor.initialized.status.788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.772, i32 %local.check.extent.773)
  %helper.ok.789 = icmp eq i32 %descriptor.initialized.status.788, 0
  br i1 %helper.ok.789, label %helper.continue.790, label %frame.failure.0
helper.continue.790:
  br label %local.descriptor.checked.771
local.descriptor.inactive.770:
  br label %local.descriptor.checked.771
local.descriptor.checked.771:
  %local.is.active.791 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.791, label %local.descriptor.active.792, label %local.descriptor.inactive.793
local.descriptor.active.792:
  %local.check.offset.795 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.796 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.797 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.798 = load i32, ptr %local.owner.end.18, align 4
  %context.field.799 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.800 = load i32, ptr %context.field.799, align 4
  %stack.sub.803 = sub i32 %local.check.owner.end.798, %local.check.offset.795
  %descriptor.owner.inside.801 = icmp ule i32 %local.check.owner.end.798, %context.value.800
  %descriptor.offset.inside.802 = icmp ule i32 %local.check.offset.795, %local.check.owner.end.798
  %descriptor.extent.inside.804 = icmp ule i32 %local.check.extent.796, %stack.sub.803
  %descriptor.payload.inside.805 = icmp ule i32 %local.check.payload.797, %local.check.extent.796
  %descriptor.owner.offset.valid.806 = and i1 %descriptor.owner.inside.801, %descriptor.offset.inside.802
  %descriptor.range.inside.808 = and i1 %descriptor.owner.offset.valid.806, %descriptor.extent.inside.804
  %descriptor.range.valid.807 = and i1 %descriptor.range.inside.808, %descriptor.payload.inside.805
  br i1 %descriptor.range.valid.807, label %descriptor.valid.809, label %descriptor.invalid.810
descriptor.invalid.810:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.809:
  %descriptor.initialized.status.811 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.795, i32 %local.check.extent.796)
  %helper.ok.812 = icmp eq i32 %descriptor.initialized.status.811, 0
  br i1 %helper.ok.812, label %helper.continue.813, label %frame.failure.0
helper.continue.813:
  br label %local.descriptor.checked.794
local.descriptor.inactive.793:
  br label %local.descriptor.checked.794
local.descriptor.checked.794:
  %local.is.active.814 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.814, label %local.descriptor.active.815, label %local.descriptor.inactive.816
local.descriptor.active.815:
  %local.check.offset.818 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.819 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.820 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.821 = load i32, ptr %local.owner.end.24, align 4
  %context.field.822 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.823 = load i32, ptr %context.field.822, align 4
  %stack.sub.826 = sub i32 %local.check.owner.end.821, %local.check.offset.818
  %descriptor.owner.inside.824 = icmp ule i32 %local.check.owner.end.821, %context.value.823
  %descriptor.offset.inside.825 = icmp ule i32 %local.check.offset.818, %local.check.owner.end.821
  %descriptor.extent.inside.827 = icmp ule i32 %local.check.extent.819, %stack.sub.826
  %descriptor.payload.inside.828 = icmp ule i32 %local.check.payload.820, %local.check.extent.819
  %descriptor.owner.offset.valid.829 = and i1 %descriptor.owner.inside.824, %descriptor.offset.inside.825
  %descriptor.range.inside.831 = and i1 %descriptor.owner.offset.valid.829, %descriptor.extent.inside.827
  %descriptor.range.valid.830 = and i1 %descriptor.range.inside.831, %descriptor.payload.inside.828
  br i1 %descriptor.range.valid.830, label %descriptor.valid.832, label %descriptor.invalid.833
descriptor.invalid.833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.832:
  %descriptor.initialized.status.834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.818, i32 %local.check.extent.819)
  %helper.ok.835 = icmp eq i32 %descriptor.initialized.status.834, 0
  br i1 %helper.ok.835, label %helper.continue.836, label %frame.failure.0
helper.continue.836:
  br label %local.descriptor.checked.817
local.descriptor.inactive.816:
  br label %local.descriptor.checked.817
local.descriptor.checked.817:
  %local.is.active.837 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.837, label %local.descriptor.active.838, label %local.descriptor.inactive.839
local.descriptor.active.838:
  %local.check.offset.841 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.842 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.843 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.844 = load i32, ptr %local.owner.end.30, align 4
  %context.field.845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.846 = load i32, ptr %context.field.845, align 4
  %stack.sub.849 = sub i32 %local.check.owner.end.844, %local.check.offset.841
  %descriptor.owner.inside.847 = icmp ule i32 %local.check.owner.end.844, %context.value.846
  %descriptor.offset.inside.848 = icmp ule i32 %local.check.offset.841, %local.check.owner.end.844
  %descriptor.extent.inside.850 = icmp ule i32 %local.check.extent.842, %stack.sub.849
  %descriptor.payload.inside.851 = icmp ule i32 %local.check.payload.843, %local.check.extent.842
  %descriptor.owner.offset.valid.852 = and i1 %descriptor.owner.inside.847, %descriptor.offset.inside.848
  %descriptor.range.inside.854 = and i1 %descriptor.owner.offset.valid.852, %descriptor.extent.inside.850
  %descriptor.range.valid.853 = and i1 %descriptor.range.inside.854, %descriptor.payload.inside.851
  br i1 %descriptor.range.valid.853, label %descriptor.valid.855, label %descriptor.invalid.856
descriptor.invalid.856:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.855:
  %descriptor.initialized.status.857 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.841, i32 %local.check.extent.842)
  %helper.ok.858 = icmp eq i32 %descriptor.initialized.status.857, 0
  br i1 %helper.ok.858, label %helper.continue.859, label %frame.failure.0
helper.continue.859:
  br label %local.descriptor.checked.840
local.descriptor.inactive.839:
  br label %local.descriptor.checked.840
local.descriptor.checked.840:
  %local.is.active.860 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.860, label %local.descriptor.active.861, label %local.descriptor.inactive.862
local.descriptor.active.861:
  %local.check.offset.864 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.865 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.866 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.867 = load i32, ptr %local.owner.end.36, align 4
  %context.field.868 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.869 = load i32, ptr %context.field.868, align 4
  %stack.sub.872 = sub i32 %local.check.owner.end.867, %local.check.offset.864
  %descriptor.owner.inside.870 = icmp ule i32 %local.check.owner.end.867, %context.value.869
  %descriptor.offset.inside.871 = icmp ule i32 %local.check.offset.864, %local.check.owner.end.867
  %descriptor.extent.inside.873 = icmp ule i32 %local.check.extent.865, %stack.sub.872
  %descriptor.payload.inside.874 = icmp ule i32 %local.check.payload.866, %local.check.extent.865
  %descriptor.owner.offset.valid.875 = and i1 %descriptor.owner.inside.870, %descriptor.offset.inside.871
  %descriptor.range.inside.877 = and i1 %descriptor.owner.offset.valid.875, %descriptor.extent.inside.873
  %descriptor.range.valid.876 = and i1 %descriptor.range.inside.877, %descriptor.payload.inside.874
  br i1 %descriptor.range.valid.876, label %descriptor.valid.878, label %descriptor.invalid.879
descriptor.invalid.879:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.878:
  %descriptor.initialized.status.880 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.864, i32 %local.check.extent.865)
  %helper.ok.881 = icmp eq i32 %descriptor.initialized.status.880, 0
  br i1 %helper.ok.881, label %helper.continue.882, label %frame.failure.0
helper.continue.882:
  br label %local.descriptor.checked.863
local.descriptor.inactive.862:
  br label %local.descriptor.checked.863
local.descriptor.checked.863:
  %local.is.active.883 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.883, label %local.descriptor.active.884, label %local.descriptor.inactive.885
local.descriptor.active.884:
  %local.check.offset.887 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.888 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.889 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.890 = load i32, ptr %local.owner.end.42, align 4
  %context.field.891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.892 = load i32, ptr %context.field.891, align 4
  %stack.sub.895 = sub i32 %local.check.owner.end.890, %local.check.offset.887
  %descriptor.owner.inside.893 = icmp ule i32 %local.check.owner.end.890, %context.value.892
  %descriptor.offset.inside.894 = icmp ule i32 %local.check.offset.887, %local.check.owner.end.890
  %descriptor.extent.inside.896 = icmp ule i32 %local.check.extent.888, %stack.sub.895
  %descriptor.payload.inside.897 = icmp ule i32 %local.check.payload.889, %local.check.extent.888
  %descriptor.owner.offset.valid.898 = and i1 %descriptor.owner.inside.893, %descriptor.offset.inside.894
  %descriptor.range.inside.900 = and i1 %descriptor.owner.offset.valid.898, %descriptor.extent.inside.896
  %descriptor.range.valid.899 = and i1 %descriptor.range.inside.900, %descriptor.payload.inside.897
  br i1 %descriptor.range.valid.899, label %descriptor.valid.901, label %descriptor.invalid.902
descriptor.invalid.902:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.901:
  %descriptor.initialized.status.903 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.887, i32 %local.check.extent.888)
  %helper.ok.904 = icmp eq i32 %descriptor.initialized.status.903, 0
  br i1 %helper.ok.904, label %helper.continue.905, label %frame.failure.0
helper.continue.905:
  br label %local.descriptor.checked.886
local.descriptor.inactive.885:
  br label %local.descriptor.checked.886
local.descriptor.checked.886:
  %step.status.906 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.907 = icmp eq i32 %step.status.906, 0
  br i1 %helper.ok.907, label %helper.continue.908, label %frame.failure.0
helper.continue.908:
  %context.field.909 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.910 = load i32, ptr %context.field.909, align 4
  %stack.offset.911 = add i32 %context.value.910, 16
  %reserve.status.912 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.911, i32 30)
  %reserve.ok.913 = icmp eq i32 %reserve.status.912, 0
  br i1 %reserve.ok.913, label %reserve.continue.914, label %frame.failure.0
reserve.continue.914:
  %literal.status.915 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.910, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 16, i32 16, i32 6, i32 31)
  %helper.ok.916 = icmp eq i32 %literal.status.915, 0
  br i1 %helper.ok.916, label %helper.continue.917, label %frame.failure.0
helper.continue.917:
  %context.field.918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.919 = load i32, ptr %context.field.918, align 4
  %stack.sub.922 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.920 = icmp ule i32 %local.resolved.owner.end.706, %context.value.919
  %descriptor.offset.inside.921 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.923 = icmp ule i32 %local.resolved.extent.704, %stack.sub.922
  %descriptor.payload.inside.924 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.925 = and i1 %descriptor.owner.inside.920, %descriptor.offset.inside.921
  %descriptor.range.inside.927 = and i1 %descriptor.owner.offset.valid.925, %descriptor.extent.inside.923
  %descriptor.range.valid.926 = and i1 %descriptor.range.inside.927, %descriptor.payload.inside.924
  %descriptor.type.valid.928 = icmp eq i32 6, 6
  %descriptor.valid.929 = and i1 %descriptor.range.valid.926, %descriptor.type.valid.928
  br i1 %descriptor.valid.929, label %descriptor.valid.930, label %descriptor.invalid.931
descriptor.invalid.931:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.930:
  %descriptor.initialized.status.932 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.933 = icmp eq i32 %descriptor.initialized.status.932, 0
  br i1 %helper.ok.933, label %helper.continue.934, label %frame.failure.0
helper.continue.934:
  %context.field.935 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.936 = load i32, ptr %context.field.935, align 4
  %stack.sub.939 = sub i32 %stack.offset.911, %context.value.910
  %descriptor.owner.inside.937 = icmp ule i32 %stack.offset.911, %context.value.936
  %descriptor.offset.inside.938 = icmp ule i32 %context.value.910, %stack.offset.911
  %descriptor.extent.inside.940 = icmp ule i32 16, %stack.sub.939
  %descriptor.payload.inside.941 = icmp ule i32 16, 16
  %descriptor.owner.offset.valid.942 = and i1 %descriptor.owner.inside.937, %descriptor.offset.inside.938
  %descriptor.range.inside.944 = and i1 %descriptor.owner.offset.valid.942, %descriptor.extent.inside.940
  %descriptor.range.valid.943 = and i1 %descriptor.range.inside.944, %descriptor.payload.inside.941
  %descriptor.type.valid.945 = icmp eq i32 6, 6
  %descriptor.valid.946 = and i1 %descriptor.range.valid.943, %descriptor.type.valid.945
  br i1 %descriptor.valid.946, label %descriptor.valid.947, label %descriptor.invalid.948
descriptor.invalid.948:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.947:
  %descriptor.initialized.status.949 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.910, i32 16)
  %helper.ok.950 = icmp eq i32 %descriptor.initialized.status.949, 0
  br i1 %helper.ok.950, label %helper.continue.951, label %frame.failure.0
helper.continue.951:
  %local.is.active.952 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.952, label %local.descriptor.active.953, label %local.descriptor.inactive.954
local.descriptor.active.953:
  %local.check.offset.956 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.957 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.958 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.959 = load i32, ptr %local.owner.end.6, align 4
  %context.field.960 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.961 = load i32, ptr %context.field.960, align 4
  %stack.sub.964 = sub i32 %local.check.owner.end.959, %local.check.offset.956
  %descriptor.owner.inside.962 = icmp ule i32 %local.check.owner.end.959, %context.value.961
  %descriptor.offset.inside.963 = icmp ule i32 %local.check.offset.956, %local.check.owner.end.959
  %descriptor.extent.inside.965 = icmp ule i32 %local.check.extent.957, %stack.sub.964
  %descriptor.payload.inside.966 = icmp ule i32 %local.check.payload.958, %local.check.extent.957
  %descriptor.owner.offset.valid.967 = and i1 %descriptor.owner.inside.962, %descriptor.offset.inside.963
  %descriptor.range.inside.969 = and i1 %descriptor.owner.offset.valid.967, %descriptor.extent.inside.965
  %descriptor.range.valid.968 = and i1 %descriptor.range.inside.969, %descriptor.payload.inside.966
  br i1 %descriptor.range.valid.968, label %descriptor.valid.970, label %descriptor.invalid.971
descriptor.invalid.971:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.970:
  %descriptor.initialized.status.972 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.956, i32 %local.check.extent.957)
  %helper.ok.973 = icmp eq i32 %descriptor.initialized.status.972, 0
  br i1 %helper.ok.973, label %helper.continue.974, label %frame.failure.0
helper.continue.974:
  br label %local.descriptor.checked.955
local.descriptor.inactive.954:
  br label %local.descriptor.checked.955
local.descriptor.checked.955:
  %local.is.active.975 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.975, label %local.descriptor.active.976, label %local.descriptor.inactive.977
local.descriptor.active.976:
  %local.check.offset.979 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.980 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.981 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.982 = load i32, ptr %local.owner.end.12, align 4
  %context.field.983 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.984 = load i32, ptr %context.field.983, align 4
  %stack.sub.987 = sub i32 %local.check.owner.end.982, %local.check.offset.979
  %descriptor.owner.inside.985 = icmp ule i32 %local.check.owner.end.982, %context.value.984
  %descriptor.offset.inside.986 = icmp ule i32 %local.check.offset.979, %local.check.owner.end.982
  %descriptor.extent.inside.988 = icmp ule i32 %local.check.extent.980, %stack.sub.987
  %descriptor.payload.inside.989 = icmp ule i32 %local.check.payload.981, %local.check.extent.980
  %descriptor.owner.offset.valid.990 = and i1 %descriptor.owner.inside.985, %descriptor.offset.inside.986
  %descriptor.range.inside.992 = and i1 %descriptor.owner.offset.valid.990, %descriptor.extent.inside.988
  %descriptor.range.valid.991 = and i1 %descriptor.range.inside.992, %descriptor.payload.inside.989
  br i1 %descriptor.range.valid.991, label %descriptor.valid.993, label %descriptor.invalid.994
descriptor.invalid.994:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.993:
  %descriptor.initialized.status.995 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.979, i32 %local.check.extent.980)
  %helper.ok.996 = icmp eq i32 %descriptor.initialized.status.995, 0
  br i1 %helper.ok.996, label %helper.continue.997, label %frame.failure.0
helper.continue.997:
  br label %local.descriptor.checked.978
local.descriptor.inactive.977:
  br label %local.descriptor.checked.978
local.descriptor.checked.978:
  %local.is.active.998 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.998, label %local.descriptor.active.999, label %local.descriptor.inactive.1000
local.descriptor.active.999:
  %local.check.offset.1002 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1003 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1004 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1005 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1006 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1007 = load i32, ptr %context.field.1006, align 4
  %stack.sub.1010 = sub i32 %local.check.owner.end.1005, %local.check.offset.1002
  %descriptor.owner.inside.1008 = icmp ule i32 %local.check.owner.end.1005, %context.value.1007
  %descriptor.offset.inside.1009 = icmp ule i32 %local.check.offset.1002, %local.check.owner.end.1005
  %descriptor.extent.inside.1011 = icmp ule i32 %local.check.extent.1003, %stack.sub.1010
  %descriptor.payload.inside.1012 = icmp ule i32 %local.check.payload.1004, %local.check.extent.1003
  %descriptor.owner.offset.valid.1013 = and i1 %descriptor.owner.inside.1008, %descriptor.offset.inside.1009
  %descriptor.range.inside.1015 = and i1 %descriptor.owner.offset.valid.1013, %descriptor.extent.inside.1011
  %descriptor.range.valid.1014 = and i1 %descriptor.range.inside.1015, %descriptor.payload.inside.1012
  br i1 %descriptor.range.valid.1014, label %descriptor.valid.1016, label %descriptor.invalid.1017
descriptor.invalid.1017:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1016:
  %descriptor.initialized.status.1018 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1002, i32 %local.check.extent.1003)
  %helper.ok.1019 = icmp eq i32 %descriptor.initialized.status.1018, 0
  br i1 %helper.ok.1019, label %helper.continue.1020, label %frame.failure.0
helper.continue.1020:
  br label %local.descriptor.checked.1001
local.descriptor.inactive.1000:
  br label %local.descriptor.checked.1001
local.descriptor.checked.1001:
  %local.is.active.1021 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1021, label %local.descriptor.active.1022, label %local.descriptor.inactive.1023
local.descriptor.active.1022:
  %local.check.offset.1025 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1026 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1027 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1028 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1029 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1030 = load i32, ptr %context.field.1029, align 4
  %stack.sub.1033 = sub i32 %local.check.owner.end.1028, %local.check.offset.1025
  %descriptor.owner.inside.1031 = icmp ule i32 %local.check.owner.end.1028, %context.value.1030
  %descriptor.offset.inside.1032 = icmp ule i32 %local.check.offset.1025, %local.check.owner.end.1028
  %descriptor.extent.inside.1034 = icmp ule i32 %local.check.extent.1026, %stack.sub.1033
  %descriptor.payload.inside.1035 = icmp ule i32 %local.check.payload.1027, %local.check.extent.1026
  %descriptor.owner.offset.valid.1036 = and i1 %descriptor.owner.inside.1031, %descriptor.offset.inside.1032
  %descriptor.range.inside.1038 = and i1 %descriptor.owner.offset.valid.1036, %descriptor.extent.inside.1034
  %descriptor.range.valid.1037 = and i1 %descriptor.range.inside.1038, %descriptor.payload.inside.1035
  br i1 %descriptor.range.valid.1037, label %descriptor.valid.1039, label %descriptor.invalid.1040
descriptor.invalid.1040:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1039:
  %descriptor.initialized.status.1041 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1025, i32 %local.check.extent.1026)
  %helper.ok.1042 = icmp eq i32 %descriptor.initialized.status.1041, 0
  br i1 %helper.ok.1042, label %helper.continue.1043, label %frame.failure.0
helper.continue.1043:
  br label %local.descriptor.checked.1024
local.descriptor.inactive.1023:
  br label %local.descriptor.checked.1024
local.descriptor.checked.1024:
  %local.is.active.1044 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1044, label %local.descriptor.active.1045, label %local.descriptor.inactive.1046
local.descriptor.active.1045:
  %local.check.offset.1048 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1049 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1050 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1051 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1052 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1053 = load i32, ptr %context.field.1052, align 4
  %stack.sub.1056 = sub i32 %local.check.owner.end.1051, %local.check.offset.1048
  %descriptor.owner.inside.1054 = icmp ule i32 %local.check.owner.end.1051, %context.value.1053
  %descriptor.offset.inside.1055 = icmp ule i32 %local.check.offset.1048, %local.check.owner.end.1051
  %descriptor.extent.inside.1057 = icmp ule i32 %local.check.extent.1049, %stack.sub.1056
  %descriptor.payload.inside.1058 = icmp ule i32 %local.check.payload.1050, %local.check.extent.1049
  %descriptor.owner.offset.valid.1059 = and i1 %descriptor.owner.inside.1054, %descriptor.offset.inside.1055
  %descriptor.range.inside.1061 = and i1 %descriptor.owner.offset.valid.1059, %descriptor.extent.inside.1057
  %descriptor.range.valid.1060 = and i1 %descriptor.range.inside.1061, %descriptor.payload.inside.1058
  br i1 %descriptor.range.valid.1060, label %descriptor.valid.1062, label %descriptor.invalid.1063
descriptor.invalid.1063:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1062:
  %descriptor.initialized.status.1064 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1048, i32 %local.check.extent.1049)
  %helper.ok.1065 = icmp eq i32 %descriptor.initialized.status.1064, 0
  br i1 %helper.ok.1065, label %helper.continue.1066, label %frame.failure.0
helper.continue.1066:
  br label %local.descriptor.checked.1047
local.descriptor.inactive.1046:
  br label %local.descriptor.checked.1047
local.descriptor.checked.1047:
  %local.is.active.1067 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1067, label %local.descriptor.active.1068, label %local.descriptor.inactive.1069
local.descriptor.active.1068:
  %local.check.offset.1071 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1072 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1073 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1074 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1075 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1076 = load i32, ptr %context.field.1075, align 4
  %stack.sub.1079 = sub i32 %local.check.owner.end.1074, %local.check.offset.1071
  %descriptor.owner.inside.1077 = icmp ule i32 %local.check.owner.end.1074, %context.value.1076
  %descriptor.offset.inside.1078 = icmp ule i32 %local.check.offset.1071, %local.check.owner.end.1074
  %descriptor.extent.inside.1080 = icmp ule i32 %local.check.extent.1072, %stack.sub.1079
  %descriptor.payload.inside.1081 = icmp ule i32 %local.check.payload.1073, %local.check.extent.1072
  %descriptor.owner.offset.valid.1082 = and i1 %descriptor.owner.inside.1077, %descriptor.offset.inside.1078
  %descriptor.range.inside.1084 = and i1 %descriptor.owner.offset.valid.1082, %descriptor.extent.inside.1080
  %descriptor.range.valid.1083 = and i1 %descriptor.range.inside.1084, %descriptor.payload.inside.1081
  br i1 %descriptor.range.valid.1083, label %descriptor.valid.1085, label %descriptor.invalid.1086
descriptor.invalid.1086:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1085:
  %descriptor.initialized.status.1087 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1071, i32 %local.check.extent.1072)
  %helper.ok.1088 = icmp eq i32 %descriptor.initialized.status.1087, 0
  br i1 %helper.ok.1088, label %helper.continue.1089, label %frame.failure.0
helper.continue.1089:
  br label %local.descriptor.checked.1070
local.descriptor.inactive.1069:
  br label %local.descriptor.checked.1070
local.descriptor.checked.1070:
  %local.is.active.1090 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1090, label %local.descriptor.active.1091, label %local.descriptor.inactive.1092
local.descriptor.active.1091:
  %local.check.offset.1094 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1095 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1096 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1097 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1098 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1099 = load i32, ptr %context.field.1098, align 4
  %stack.sub.1102 = sub i32 %local.check.owner.end.1097, %local.check.offset.1094
  %descriptor.owner.inside.1100 = icmp ule i32 %local.check.owner.end.1097, %context.value.1099
  %descriptor.offset.inside.1101 = icmp ule i32 %local.check.offset.1094, %local.check.owner.end.1097
  %descriptor.extent.inside.1103 = icmp ule i32 %local.check.extent.1095, %stack.sub.1102
  %descriptor.payload.inside.1104 = icmp ule i32 %local.check.payload.1096, %local.check.extent.1095
  %descriptor.owner.offset.valid.1105 = and i1 %descriptor.owner.inside.1100, %descriptor.offset.inside.1101
  %descriptor.range.inside.1107 = and i1 %descriptor.owner.offset.valid.1105, %descriptor.extent.inside.1103
  %descriptor.range.valid.1106 = and i1 %descriptor.range.inside.1107, %descriptor.payload.inside.1104
  br i1 %descriptor.range.valid.1106, label %descriptor.valid.1108, label %descriptor.invalid.1109
descriptor.invalid.1109:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1108:
  %descriptor.initialized.status.1110 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1094, i32 %local.check.extent.1095)
  %helper.ok.1111 = icmp eq i32 %descriptor.initialized.status.1110, 0
  br i1 %helper.ok.1111, label %helper.continue.1112, label %frame.failure.0
helper.continue.1112:
  br label %local.descriptor.checked.1093
local.descriptor.inactive.1092:
  br label %local.descriptor.checked.1093
local.descriptor.checked.1093:
  %step.status.1113 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %helper.ok.1114 = icmp eq i32 %step.status.1113, 0
  br i1 %helper.ok.1114, label %helper.continue.1115, label %frame.failure.0
helper.continue.1115:
  %equals.same.extent.1116 = icmp eq i32 %local.resolved.extent.704, 16
  br i1 %equals.same.extent.1116, label %equals.compare.1117, label %equals.different.1118
equals.compare.1117:
  %equals.result.1120 = call i32 @al_owning_equal(ptr %ctx, i32 %local.resolved.offset.703, i32 %context.value.910, i32 %local.resolved.extent.704)
  %context.field.1121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1122 = load i32, ptr %context.field.1121, align 4
  %runtime.ok.1123 = icmp eq i32 %context.value.1122, 0
  br i1 %runtime.ok.1123, label %runtime.continue.1124, label %frame.failure.0
runtime.continue.1124:
  br label %equals.join.1119
equals.different.1118:
  br label %equals.join.1119
equals.join.1119:
  %equals.value.1125 = phi i32 [ %equals.result.1120, %runtime.continue.1124 ], [ 0, %equals.different.1118 ]
  %equals.bool.1126 = icmp ne i32 %equals.value.1125, 0
  %equals.i64.1127 = zext i1 %equals.bool.1126 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %context.value.910, i32 16, i32 16, i32 0, i32 0)
  %context.field.1128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1129 = load i32, ptr %context.field.1128, align 4
  %runtime.ok.1130 = icmp eq i32 %context.value.1129, 0
  br i1 %runtime.ok.1130, label %runtime.continue.1131, label %frame.failure.0
runtime.continue.1131:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704, i32 %local.resolved.payload.705, i32 0, i32 0)
  %context.field.1132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1133 = load i32, ptr %context.field.1132, align 4
  %runtime.ok.1134 = icmp eq i32 %context.value.1133, 0
  br i1 %runtime.ok.1134, label %runtime.continue.1135, label %frame.failure.0
runtime.continue.1135:
  %context.field.1136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1137 = load i32, ptr %context.field.1136, align 4
  %stack.offset.1138 = add i32 %context.value.1137, 8
  %reserve.status.1139 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1138, i32 33)
  %reserve.ok.1140 = icmp eq i32 %reserve.status.1139, 0
  br i1 %reserve.ok.1140, label %reserve.continue.1141, label %frame.failure.0
reserve.continue.1141:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1137, i64 %equals.i64.1127, i32 2)
  %context.field.1142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1143 = load i32, ptr %context.field.1142, align 4
  %runtime.ok.1144 = icmp eq i32 %context.value.1143, 0
  br i1 %runtime.ok.1144, label %runtime.continue.1145, label %frame.failure.0
runtime.continue.1145:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1147 = load i32, ptr %context.field.1146, align 4
  %runtime.ok.1148 = icmp eq i32 %context.value.1147, 0
  br i1 %runtime.ok.1148, label %runtime.continue.1149, label %frame.failure.0
runtime.continue.1149:
  %stack.offset.1150 = add i32 %context.value.1137, 8
  %context.field.1151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1152 = load i32, ptr %context.field.1151, align 4
  %stack.sub.1155 = sub i32 %stack.offset.1150, %context.value.1137
  %descriptor.owner.inside.1153 = icmp ule i32 %stack.offset.1150, %context.value.1152
  %descriptor.offset.inside.1154 = icmp ule i32 %context.value.1137, %stack.offset.1150
  %descriptor.extent.inside.1156 = icmp ule i32 8, %stack.sub.1155
  %descriptor.payload.inside.1157 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1158 = and i1 %descriptor.owner.inside.1153, %descriptor.offset.inside.1154
  %descriptor.range.inside.1160 = and i1 %descriptor.owner.offset.valid.1158, %descriptor.extent.inside.1156
  %descriptor.range.valid.1159 = and i1 %descriptor.range.inside.1160, %descriptor.payload.inside.1157
  %descriptor.type.valid.1161 = icmp eq i32 2, 2
  %descriptor.valid.1162 = and i1 %descriptor.range.valid.1159, %descriptor.type.valid.1161
  br i1 %descriptor.valid.1162, label %descriptor.valid.1163, label %descriptor.invalid.1164
descriptor.invalid.1164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1163:
  %descriptor.initialized.status.1165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1137, i32 8)
  %helper.ok.1166 = icmp eq i32 %descriptor.initialized.status.1165, 0
  br i1 %helper.ok.1166, label %helper.continue.1167, label %frame.failure.0
helper.continue.1167:
  %local.is.active.1168 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1168, label %local.descriptor.active.1169, label %local.descriptor.inactive.1170
local.descriptor.active.1169:
  %local.check.offset.1172 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1173 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1174 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1175 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1177 = load i32, ptr %context.field.1176, align 4
  %stack.sub.1180 = sub i32 %local.check.owner.end.1175, %local.check.offset.1172
  %descriptor.owner.inside.1178 = icmp ule i32 %local.check.owner.end.1175, %context.value.1177
  %descriptor.offset.inside.1179 = icmp ule i32 %local.check.offset.1172, %local.check.owner.end.1175
  %descriptor.extent.inside.1181 = icmp ule i32 %local.check.extent.1173, %stack.sub.1180
  %descriptor.payload.inside.1182 = icmp ule i32 %local.check.payload.1174, %local.check.extent.1173
  %descriptor.owner.offset.valid.1183 = and i1 %descriptor.owner.inside.1178, %descriptor.offset.inside.1179
  %descriptor.range.inside.1185 = and i1 %descriptor.owner.offset.valid.1183, %descriptor.extent.inside.1181
  %descriptor.range.valid.1184 = and i1 %descriptor.range.inside.1185, %descriptor.payload.inside.1182
  br i1 %descriptor.range.valid.1184, label %descriptor.valid.1186, label %descriptor.invalid.1187
descriptor.invalid.1187:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1186:
  %descriptor.initialized.status.1188 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1172, i32 %local.check.extent.1173)
  %helper.ok.1189 = icmp eq i32 %descriptor.initialized.status.1188, 0
  br i1 %helper.ok.1189, label %helper.continue.1190, label %frame.failure.0
helper.continue.1190:
  br label %local.descriptor.checked.1171
local.descriptor.inactive.1170:
  br label %local.descriptor.checked.1171
local.descriptor.checked.1171:
  %local.is.active.1191 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1191, label %local.descriptor.active.1192, label %local.descriptor.inactive.1193
local.descriptor.active.1192:
  %local.check.offset.1195 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1196 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1197 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1198 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %stack.sub.1203 = sub i32 %local.check.owner.end.1198, %local.check.offset.1195
  %descriptor.owner.inside.1201 = icmp ule i32 %local.check.owner.end.1198, %context.value.1200
  %descriptor.offset.inside.1202 = icmp ule i32 %local.check.offset.1195, %local.check.owner.end.1198
  %descriptor.extent.inside.1204 = icmp ule i32 %local.check.extent.1196, %stack.sub.1203
  %descriptor.payload.inside.1205 = icmp ule i32 %local.check.payload.1197, %local.check.extent.1196
  %descriptor.owner.offset.valid.1206 = and i1 %descriptor.owner.inside.1201, %descriptor.offset.inside.1202
  %descriptor.range.inside.1208 = and i1 %descriptor.owner.offset.valid.1206, %descriptor.extent.inside.1204
  %descriptor.range.valid.1207 = and i1 %descriptor.range.inside.1208, %descriptor.payload.inside.1205
  br i1 %descriptor.range.valid.1207, label %descriptor.valid.1209, label %descriptor.invalid.1210
descriptor.invalid.1210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1209:
  %descriptor.initialized.status.1211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1195, i32 %local.check.extent.1196)
  %helper.ok.1212 = icmp eq i32 %descriptor.initialized.status.1211, 0
  br i1 %helper.ok.1212, label %helper.continue.1213, label %frame.failure.0
helper.continue.1213:
  br label %local.descriptor.checked.1194
local.descriptor.inactive.1193:
  br label %local.descriptor.checked.1194
local.descriptor.checked.1194:
  %local.is.active.1214 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1214, label %local.descriptor.active.1215, label %local.descriptor.inactive.1216
local.descriptor.active.1215:
  %local.check.offset.1218 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1219 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1220 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1221 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1223 = load i32, ptr %context.field.1222, align 4
  %stack.sub.1226 = sub i32 %local.check.owner.end.1221, %local.check.offset.1218
  %descriptor.owner.inside.1224 = icmp ule i32 %local.check.owner.end.1221, %context.value.1223
  %descriptor.offset.inside.1225 = icmp ule i32 %local.check.offset.1218, %local.check.owner.end.1221
  %descriptor.extent.inside.1227 = icmp ule i32 %local.check.extent.1219, %stack.sub.1226
  %descriptor.payload.inside.1228 = icmp ule i32 %local.check.payload.1220, %local.check.extent.1219
  %descriptor.owner.offset.valid.1229 = and i1 %descriptor.owner.inside.1224, %descriptor.offset.inside.1225
  %descriptor.range.inside.1231 = and i1 %descriptor.owner.offset.valid.1229, %descriptor.extent.inside.1227
  %descriptor.range.valid.1230 = and i1 %descriptor.range.inside.1231, %descriptor.payload.inside.1228
  br i1 %descriptor.range.valid.1230, label %descriptor.valid.1232, label %descriptor.invalid.1233
descriptor.invalid.1233:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1232:
  %descriptor.initialized.status.1234 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1218, i32 %local.check.extent.1219)
  %helper.ok.1235 = icmp eq i32 %descriptor.initialized.status.1234, 0
  br i1 %helper.ok.1235, label %helper.continue.1236, label %frame.failure.0
helper.continue.1236:
  br label %local.descriptor.checked.1217
local.descriptor.inactive.1216:
  br label %local.descriptor.checked.1217
local.descriptor.checked.1217:
  %local.is.active.1237 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1237, label %local.descriptor.active.1238, label %local.descriptor.inactive.1239
local.descriptor.active.1238:
  %local.check.offset.1241 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1242 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1243 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1244 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1245 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1246 = load i32, ptr %context.field.1245, align 4
  %stack.sub.1249 = sub i32 %local.check.owner.end.1244, %local.check.offset.1241
  %descriptor.owner.inside.1247 = icmp ule i32 %local.check.owner.end.1244, %context.value.1246
  %descriptor.offset.inside.1248 = icmp ule i32 %local.check.offset.1241, %local.check.owner.end.1244
  %descriptor.extent.inside.1250 = icmp ule i32 %local.check.extent.1242, %stack.sub.1249
  %descriptor.payload.inside.1251 = icmp ule i32 %local.check.payload.1243, %local.check.extent.1242
  %descriptor.owner.offset.valid.1252 = and i1 %descriptor.owner.inside.1247, %descriptor.offset.inside.1248
  %descriptor.range.inside.1254 = and i1 %descriptor.owner.offset.valid.1252, %descriptor.extent.inside.1250
  %descriptor.range.valid.1253 = and i1 %descriptor.range.inside.1254, %descriptor.payload.inside.1251
  br i1 %descriptor.range.valid.1253, label %descriptor.valid.1255, label %descriptor.invalid.1256
descriptor.invalid.1256:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1255:
  %descriptor.initialized.status.1257 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1241, i32 %local.check.extent.1242)
  %helper.ok.1258 = icmp eq i32 %descriptor.initialized.status.1257, 0
  br i1 %helper.ok.1258, label %helper.continue.1259, label %frame.failure.0
helper.continue.1259:
  br label %local.descriptor.checked.1240
local.descriptor.inactive.1239:
  br label %local.descriptor.checked.1240
local.descriptor.checked.1240:
  %local.is.active.1260 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1260, label %local.descriptor.active.1261, label %local.descriptor.inactive.1262
local.descriptor.active.1261:
  %local.check.offset.1264 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1265 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1266 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1267 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1269 = load i32, ptr %context.field.1268, align 4
  %stack.sub.1272 = sub i32 %local.check.owner.end.1267, %local.check.offset.1264
  %descriptor.owner.inside.1270 = icmp ule i32 %local.check.owner.end.1267, %context.value.1269
  %descriptor.offset.inside.1271 = icmp ule i32 %local.check.offset.1264, %local.check.owner.end.1267
  %descriptor.extent.inside.1273 = icmp ule i32 %local.check.extent.1265, %stack.sub.1272
  %descriptor.payload.inside.1274 = icmp ule i32 %local.check.payload.1266, %local.check.extent.1265
  %descriptor.owner.offset.valid.1275 = and i1 %descriptor.owner.inside.1270, %descriptor.offset.inside.1271
  %descriptor.range.inside.1277 = and i1 %descriptor.owner.offset.valid.1275, %descriptor.extent.inside.1273
  %descriptor.range.valid.1276 = and i1 %descriptor.range.inside.1277, %descriptor.payload.inside.1274
  br i1 %descriptor.range.valid.1276, label %descriptor.valid.1278, label %descriptor.invalid.1279
descriptor.invalid.1279:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1278:
  %descriptor.initialized.status.1280 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1264, i32 %local.check.extent.1265)
  %helper.ok.1281 = icmp eq i32 %descriptor.initialized.status.1280, 0
  br i1 %helper.ok.1281, label %helper.continue.1282, label %frame.failure.0
helper.continue.1282:
  br label %local.descriptor.checked.1263
local.descriptor.inactive.1262:
  br label %local.descriptor.checked.1263
local.descriptor.checked.1263:
  %local.is.active.1283 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1283, label %local.descriptor.active.1284, label %local.descriptor.inactive.1285
local.descriptor.active.1284:
  %local.check.offset.1287 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1288 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1289 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1290 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1292 = load i32, ptr %context.field.1291, align 4
  %stack.sub.1295 = sub i32 %local.check.owner.end.1290, %local.check.offset.1287
  %descriptor.owner.inside.1293 = icmp ule i32 %local.check.owner.end.1290, %context.value.1292
  %descriptor.offset.inside.1294 = icmp ule i32 %local.check.offset.1287, %local.check.owner.end.1290
  %descriptor.extent.inside.1296 = icmp ule i32 %local.check.extent.1288, %stack.sub.1295
  %descriptor.payload.inside.1297 = icmp ule i32 %local.check.payload.1289, %local.check.extent.1288
  %descriptor.owner.offset.valid.1298 = and i1 %descriptor.owner.inside.1293, %descriptor.offset.inside.1294
  %descriptor.range.inside.1300 = and i1 %descriptor.owner.offset.valid.1298, %descriptor.extent.inside.1296
  %descriptor.range.valid.1299 = and i1 %descriptor.range.inside.1300, %descriptor.payload.inside.1297
  br i1 %descriptor.range.valid.1299, label %descriptor.valid.1301, label %descriptor.invalid.1302
descriptor.invalid.1302:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1301:
  %descriptor.initialized.status.1303 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1287, i32 %local.check.extent.1288)
  %helper.ok.1304 = icmp eq i32 %descriptor.initialized.status.1303, 0
  br i1 %helper.ok.1304, label %helper.continue.1305, label %frame.failure.0
helper.continue.1305:
  br label %local.descriptor.checked.1286
local.descriptor.inactive.1285:
  br label %local.descriptor.checked.1286
local.descriptor.checked.1286:
  %local.is.active.1306 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1306, label %local.descriptor.active.1307, label %local.descriptor.inactive.1308
local.descriptor.active.1307:
  %local.check.offset.1310 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1311 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1312 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1313 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1315 = load i32, ptr %context.field.1314, align 4
  %stack.sub.1318 = sub i32 %local.check.owner.end.1313, %local.check.offset.1310
  %descriptor.owner.inside.1316 = icmp ule i32 %local.check.owner.end.1313, %context.value.1315
  %descriptor.offset.inside.1317 = icmp ule i32 %local.check.offset.1310, %local.check.owner.end.1313
  %descriptor.extent.inside.1319 = icmp ule i32 %local.check.extent.1311, %stack.sub.1318
  %descriptor.payload.inside.1320 = icmp ule i32 %local.check.payload.1312, %local.check.extent.1311
  %descriptor.owner.offset.valid.1321 = and i1 %descriptor.owner.inside.1316, %descriptor.offset.inside.1317
  %descriptor.range.inside.1323 = and i1 %descriptor.owner.offset.valid.1321, %descriptor.extent.inside.1319
  %descriptor.range.valid.1322 = and i1 %descriptor.range.inside.1323, %descriptor.payload.inside.1320
  br i1 %descriptor.range.valid.1322, label %descriptor.valid.1324, label %descriptor.invalid.1325
descriptor.invalid.1325:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1324:
  %descriptor.initialized.status.1326 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1310, i32 %local.check.extent.1311)
  %helper.ok.1327 = icmp eq i32 %descriptor.initialized.status.1326, 0
  br i1 %helper.ok.1327, label %helper.continue.1328, label %frame.failure.0
helper.continue.1328:
  br label %local.descriptor.checked.1309
local.descriptor.inactive.1308:
  br label %local.descriptor.checked.1309
local.descriptor.checked.1309:
  %step.status.1329 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %helper.ok.1330 = icmp eq i32 %step.status.1329, 0
  br i1 %helper.ok.1330, label %helper.continue.1331, label %frame.failure.0
helper.continue.1331:
  %if.condition.raw.1332 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1137)
  %context.field.1333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1334 = load i32, ptr %context.field.1333, align 4
  %runtime.ok.1335 = icmp eq i32 %context.value.1334, 0
  br i1 %runtime.ok.1335, label %runtime.continue.1336, label %frame.failure.0
runtime.continue.1336:
  %if.condition.1337 = icmp ne i64 %if.condition.raw.1332, 0
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 2, i32 %context.value.1137, i32 8, i32 8, i32 0, i32 0)
  %context.field.1338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1339 = load i32, ptr %context.field.1338, align 4
  %runtime.ok.1340 = icmp eq i32 %context.value.1339, 0
  br i1 %runtime.ok.1340, label %runtime.continue.1341, label %frame.failure.0
runtime.continue.1341:
  br i1 %if.condition.1337, label %if.then.1342, label %if.else.1343
if.then.1342:
  %step.status.1345 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.1346 = icmp eq i32 %step.status.1345, 0
  br i1 %helper.ok.1346, label %helper.continue.1347, label %frame.failure.0
helper.continue.1347:
  %context.field.1348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1349 = load i32, ptr %context.field.1348, align 4
  %step.status.1350 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %helper.ok.1351 = icmp eq i32 %step.status.1350, 0
  br i1 %helper.ok.1351, label %helper.continue.1352, label %frame.failure.0
helper.continue.1352:
  %context.field.1353 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1354 = load i32, ptr %context.field.1353, align 4
  %stack.offset.1355 = add i32 %context.value.1354, 8
  %reserve.status.1356 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1355, i32 37)
  %reserve.ok.1357 = icmp eq i32 %reserve.status.1356, 0
  br i1 %reserve.ok.1357, label %reserve.continue.1358, label %frame.failure.0
reserve.continue.1358:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1354, i64 1, i32 1)
  %context.field.1359 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1360 = load i32, ptr %context.field.1359, align 4
  %runtime.ok.1361 = icmp eq i32 %context.value.1360, 0
  br i1 %runtime.ok.1361, label %runtime.continue.1362, label %frame.failure.0
runtime.continue.1362:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1363 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1364 = load i32, ptr %context.field.1363, align 4
  %runtime.ok.1365 = icmp eq i32 %context.value.1364, 0
  br i1 %runtime.ok.1365, label %runtime.continue.1366, label %frame.failure.0
runtime.continue.1366:
  %context.field.1367 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1368 = load i32, ptr %context.field.1367, align 4
  %stack.sub.1371 = sub i32 %stack.offset.1355, %context.value.1354
  %descriptor.owner.inside.1369 = icmp ule i32 %stack.offset.1355, %context.value.1368
  %descriptor.offset.inside.1370 = icmp ule i32 %context.value.1354, %stack.offset.1355
  %descriptor.extent.inside.1372 = icmp ule i32 8, %stack.sub.1371
  %descriptor.payload.inside.1373 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1374 = and i1 %descriptor.owner.inside.1369, %descriptor.offset.inside.1370
  %descriptor.range.inside.1376 = and i1 %descriptor.owner.offset.valid.1374, %descriptor.extent.inside.1372
  %descriptor.range.valid.1375 = and i1 %descriptor.range.inside.1376, %descriptor.payload.inside.1373
  %descriptor.type.valid.1377 = icmp eq i32 1, 1
  %descriptor.valid.1378 = and i1 %descriptor.range.valid.1375, %descriptor.type.valid.1377
  br i1 %descriptor.valid.1378, label %descriptor.valid.1379, label %descriptor.invalid.1380
descriptor.invalid.1380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1379:
  %descriptor.initialized.status.1381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1354, i32 8)
  %helper.ok.1382 = icmp eq i32 %descriptor.initialized.status.1381, 0
  br i1 %helper.ok.1382, label %helper.continue.1383, label %frame.failure.0
helper.continue.1383:
  %local.is.active.1384 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1384, label %local.descriptor.active.1385, label %local.descriptor.inactive.1386
local.descriptor.active.1385:
  %local.check.offset.1388 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1389 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1390 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1391 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1393 = load i32, ptr %context.field.1392, align 4
  %stack.sub.1396 = sub i32 %local.check.owner.end.1391, %local.check.offset.1388
  %descriptor.owner.inside.1394 = icmp ule i32 %local.check.owner.end.1391, %context.value.1393
  %descriptor.offset.inside.1395 = icmp ule i32 %local.check.offset.1388, %local.check.owner.end.1391
  %descriptor.extent.inside.1397 = icmp ule i32 %local.check.extent.1389, %stack.sub.1396
  %descriptor.payload.inside.1398 = icmp ule i32 %local.check.payload.1390, %local.check.extent.1389
  %descriptor.owner.offset.valid.1399 = and i1 %descriptor.owner.inside.1394, %descriptor.offset.inside.1395
  %descriptor.range.inside.1401 = and i1 %descriptor.owner.offset.valid.1399, %descriptor.extent.inside.1397
  %descriptor.range.valid.1400 = and i1 %descriptor.range.inside.1401, %descriptor.payload.inside.1398
  br i1 %descriptor.range.valid.1400, label %descriptor.valid.1402, label %descriptor.invalid.1403
descriptor.invalid.1403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1402:
  %descriptor.initialized.status.1404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1388, i32 %local.check.extent.1389)
  %helper.ok.1405 = icmp eq i32 %descriptor.initialized.status.1404, 0
  br i1 %helper.ok.1405, label %helper.continue.1406, label %frame.failure.0
helper.continue.1406:
  br label %local.descriptor.checked.1387
local.descriptor.inactive.1386:
  br label %local.descriptor.checked.1387
local.descriptor.checked.1387:
  %local.is.active.1407 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1407, label %local.descriptor.active.1408, label %local.descriptor.inactive.1409
local.descriptor.active.1408:
  %local.check.offset.1411 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1412 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1413 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1414 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1416 = load i32, ptr %context.field.1415, align 4
  %stack.sub.1419 = sub i32 %local.check.owner.end.1414, %local.check.offset.1411
  %descriptor.owner.inside.1417 = icmp ule i32 %local.check.owner.end.1414, %context.value.1416
  %descriptor.offset.inside.1418 = icmp ule i32 %local.check.offset.1411, %local.check.owner.end.1414
  %descriptor.extent.inside.1420 = icmp ule i32 %local.check.extent.1412, %stack.sub.1419
  %descriptor.payload.inside.1421 = icmp ule i32 %local.check.payload.1413, %local.check.extent.1412
  %descriptor.owner.offset.valid.1422 = and i1 %descriptor.owner.inside.1417, %descriptor.offset.inside.1418
  %descriptor.range.inside.1424 = and i1 %descriptor.owner.offset.valid.1422, %descriptor.extent.inside.1420
  %descriptor.range.valid.1423 = and i1 %descriptor.range.inside.1424, %descriptor.payload.inside.1421
  br i1 %descriptor.range.valid.1423, label %descriptor.valid.1425, label %descriptor.invalid.1426
descriptor.invalid.1426:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1425:
  %descriptor.initialized.status.1427 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1411, i32 %local.check.extent.1412)
  %helper.ok.1428 = icmp eq i32 %descriptor.initialized.status.1427, 0
  br i1 %helper.ok.1428, label %helper.continue.1429, label %frame.failure.0
helper.continue.1429:
  br label %local.descriptor.checked.1410
local.descriptor.inactive.1409:
  br label %local.descriptor.checked.1410
local.descriptor.checked.1410:
  %local.is.active.1430 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1430, label %local.descriptor.active.1431, label %local.descriptor.inactive.1432
local.descriptor.active.1431:
  %local.check.offset.1434 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1435 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1436 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1437 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1439 = load i32, ptr %context.field.1438, align 4
  %stack.sub.1442 = sub i32 %local.check.owner.end.1437, %local.check.offset.1434
  %descriptor.owner.inside.1440 = icmp ule i32 %local.check.owner.end.1437, %context.value.1439
  %descriptor.offset.inside.1441 = icmp ule i32 %local.check.offset.1434, %local.check.owner.end.1437
  %descriptor.extent.inside.1443 = icmp ule i32 %local.check.extent.1435, %stack.sub.1442
  %descriptor.payload.inside.1444 = icmp ule i32 %local.check.payload.1436, %local.check.extent.1435
  %descriptor.owner.offset.valid.1445 = and i1 %descriptor.owner.inside.1440, %descriptor.offset.inside.1441
  %descriptor.range.inside.1447 = and i1 %descriptor.owner.offset.valid.1445, %descriptor.extent.inside.1443
  %descriptor.range.valid.1446 = and i1 %descriptor.range.inside.1447, %descriptor.payload.inside.1444
  br i1 %descriptor.range.valid.1446, label %descriptor.valid.1448, label %descriptor.invalid.1449
descriptor.invalid.1449:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1448:
  %descriptor.initialized.status.1450 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1434, i32 %local.check.extent.1435)
  %helper.ok.1451 = icmp eq i32 %descriptor.initialized.status.1450, 0
  br i1 %helper.ok.1451, label %helper.continue.1452, label %frame.failure.0
helper.continue.1452:
  br label %local.descriptor.checked.1433
local.descriptor.inactive.1432:
  br label %local.descriptor.checked.1433
local.descriptor.checked.1433:
  %local.is.active.1453 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1453, label %local.descriptor.active.1454, label %local.descriptor.inactive.1455
local.descriptor.active.1454:
  %local.check.offset.1457 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1458 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1459 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1460 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1462 = load i32, ptr %context.field.1461, align 4
  %stack.sub.1465 = sub i32 %local.check.owner.end.1460, %local.check.offset.1457
  %descriptor.owner.inside.1463 = icmp ule i32 %local.check.owner.end.1460, %context.value.1462
  %descriptor.offset.inside.1464 = icmp ule i32 %local.check.offset.1457, %local.check.owner.end.1460
  %descriptor.extent.inside.1466 = icmp ule i32 %local.check.extent.1458, %stack.sub.1465
  %descriptor.payload.inside.1467 = icmp ule i32 %local.check.payload.1459, %local.check.extent.1458
  %descriptor.owner.offset.valid.1468 = and i1 %descriptor.owner.inside.1463, %descriptor.offset.inside.1464
  %descriptor.range.inside.1470 = and i1 %descriptor.owner.offset.valid.1468, %descriptor.extent.inside.1466
  %descriptor.range.valid.1469 = and i1 %descriptor.range.inside.1470, %descriptor.payload.inside.1467
  br i1 %descriptor.range.valid.1469, label %descriptor.valid.1471, label %descriptor.invalid.1472
descriptor.invalid.1472:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1471:
  %descriptor.initialized.status.1473 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1457, i32 %local.check.extent.1458)
  %helper.ok.1474 = icmp eq i32 %descriptor.initialized.status.1473, 0
  br i1 %helper.ok.1474, label %helper.continue.1475, label %frame.failure.0
helper.continue.1475:
  br label %local.descriptor.checked.1456
local.descriptor.inactive.1455:
  br label %local.descriptor.checked.1456
local.descriptor.checked.1456:
  %local.is.active.1476 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1476, label %local.descriptor.active.1477, label %local.descriptor.inactive.1478
local.descriptor.active.1477:
  %local.check.offset.1480 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1481 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1482 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1483 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1485 = load i32, ptr %context.field.1484, align 4
  %stack.sub.1488 = sub i32 %local.check.owner.end.1483, %local.check.offset.1480
  %descriptor.owner.inside.1486 = icmp ule i32 %local.check.owner.end.1483, %context.value.1485
  %descriptor.offset.inside.1487 = icmp ule i32 %local.check.offset.1480, %local.check.owner.end.1483
  %descriptor.extent.inside.1489 = icmp ule i32 %local.check.extent.1481, %stack.sub.1488
  %descriptor.payload.inside.1490 = icmp ule i32 %local.check.payload.1482, %local.check.extent.1481
  %descriptor.owner.offset.valid.1491 = and i1 %descriptor.owner.inside.1486, %descriptor.offset.inside.1487
  %descriptor.range.inside.1493 = and i1 %descriptor.owner.offset.valid.1491, %descriptor.extent.inside.1489
  %descriptor.range.valid.1492 = and i1 %descriptor.range.inside.1493, %descriptor.payload.inside.1490
  br i1 %descriptor.range.valid.1492, label %descriptor.valid.1494, label %descriptor.invalid.1495
descriptor.invalid.1495:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1494:
  %descriptor.initialized.status.1496 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1480, i32 %local.check.extent.1481)
  %helper.ok.1497 = icmp eq i32 %descriptor.initialized.status.1496, 0
  br i1 %helper.ok.1497, label %helper.continue.1498, label %frame.failure.0
helper.continue.1498:
  br label %local.descriptor.checked.1479
local.descriptor.inactive.1478:
  br label %local.descriptor.checked.1479
local.descriptor.checked.1479:
  %local.is.active.1499 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1499, label %local.descriptor.active.1500, label %local.descriptor.inactive.1501
local.descriptor.active.1500:
  %local.check.offset.1503 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1504 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1505 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1506 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1508 = load i32, ptr %context.field.1507, align 4
  %stack.sub.1511 = sub i32 %local.check.owner.end.1506, %local.check.offset.1503
  %descriptor.owner.inside.1509 = icmp ule i32 %local.check.owner.end.1506, %context.value.1508
  %descriptor.offset.inside.1510 = icmp ule i32 %local.check.offset.1503, %local.check.owner.end.1506
  %descriptor.extent.inside.1512 = icmp ule i32 %local.check.extent.1504, %stack.sub.1511
  %descriptor.payload.inside.1513 = icmp ule i32 %local.check.payload.1505, %local.check.extent.1504
  %descriptor.owner.offset.valid.1514 = and i1 %descriptor.owner.inside.1509, %descriptor.offset.inside.1510
  %descriptor.range.inside.1516 = and i1 %descriptor.owner.offset.valid.1514, %descriptor.extent.inside.1512
  %descriptor.range.valid.1515 = and i1 %descriptor.range.inside.1516, %descriptor.payload.inside.1513
  br i1 %descriptor.range.valid.1515, label %descriptor.valid.1517, label %descriptor.invalid.1518
descriptor.invalid.1518:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1517:
  %descriptor.initialized.status.1519 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1503, i32 %local.check.extent.1504)
  %helper.ok.1520 = icmp eq i32 %descriptor.initialized.status.1519, 0
  br i1 %helper.ok.1520, label %helper.continue.1521, label %frame.failure.0
helper.continue.1521:
  br label %local.descriptor.checked.1502
local.descriptor.inactive.1501:
  br label %local.descriptor.checked.1502
local.descriptor.checked.1502:
  %local.is.active.1522 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1522, label %local.descriptor.active.1523, label %local.descriptor.inactive.1524
local.descriptor.active.1523:
  %local.check.offset.1526 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1527 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1528 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1529 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1530 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1531 = load i32, ptr %context.field.1530, align 4
  %stack.sub.1534 = sub i32 %local.check.owner.end.1529, %local.check.offset.1526
  %descriptor.owner.inside.1532 = icmp ule i32 %local.check.owner.end.1529, %context.value.1531
  %descriptor.offset.inside.1533 = icmp ule i32 %local.check.offset.1526, %local.check.owner.end.1529
  %descriptor.extent.inside.1535 = icmp ule i32 %local.check.extent.1527, %stack.sub.1534
  %descriptor.payload.inside.1536 = icmp ule i32 %local.check.payload.1528, %local.check.extent.1527
  %descriptor.owner.offset.valid.1537 = and i1 %descriptor.owner.inside.1532, %descriptor.offset.inside.1533
  %descriptor.range.inside.1539 = and i1 %descriptor.owner.offset.valid.1537, %descriptor.extent.inside.1535
  %descriptor.range.valid.1538 = and i1 %descriptor.range.inside.1539, %descriptor.payload.inside.1536
  br i1 %descriptor.range.valid.1538, label %descriptor.valid.1540, label %descriptor.invalid.1541
descriptor.invalid.1541:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1540:
  %descriptor.initialized.status.1542 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1526, i32 %local.check.extent.1527)
  %helper.ok.1543 = icmp eq i32 %descriptor.initialized.status.1542, 0
  br i1 %helper.ok.1543, label %helper.continue.1544, label %frame.failure.0
helper.continue.1544:
  br label %local.descriptor.checked.1525
local.descriptor.inactive.1524:
  br label %local.descriptor.checked.1525
local.descriptor.checked.1525:
  %step.status.1545 = call i32 @al_owning_charge_step(ptr %ctx, i32 38)
  %helper.ok.1546 = icmp eq i32 %step.status.1545, 0
  br i1 %helper.ok.1546, label %helper.continue.1547, label %frame.failure.0
helper.continue.1547:
  %context.field.1548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1549 = load i32, ptr %context.field.1548, align 4
  %stack.offset.1550 = add i32 %context.value.1549, 8
  %reserve.status.1551 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1550, i32 39)
  %reserve.ok.1552 = icmp eq i32 %reserve.status.1551, 0
  br i1 %reserve.ok.1552, label %reserve.continue.1553, label %frame.failure.0
reserve.continue.1553:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1549, i64 0, i32 1)
  %context.field.1554 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1555 = load i32, ptr %context.field.1554, align 4
  %runtime.ok.1556 = icmp eq i32 %context.value.1555, 0
  br i1 %runtime.ok.1556, label %runtime.continue.1557, label %frame.failure.0
runtime.continue.1557:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1558 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1559 = load i32, ptr %context.field.1558, align 4
  %runtime.ok.1560 = icmp eq i32 %context.value.1559, 0
  br i1 %runtime.ok.1560, label %runtime.continue.1561, label %frame.failure.0
runtime.continue.1561:
  %context.field.1562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1563 = load i32, ptr %context.field.1562, align 4
  %stack.sub.1566 = sub i32 %stack.offset.1355, %context.value.1354
  %descriptor.owner.inside.1564 = icmp ule i32 %stack.offset.1355, %context.value.1563
  %descriptor.offset.inside.1565 = icmp ule i32 %context.value.1354, %stack.offset.1355
  %descriptor.extent.inside.1567 = icmp ule i32 8, %stack.sub.1566
  %descriptor.payload.inside.1568 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1569 = and i1 %descriptor.owner.inside.1564, %descriptor.offset.inside.1565
  %descriptor.range.inside.1571 = and i1 %descriptor.owner.offset.valid.1569, %descriptor.extent.inside.1567
  %descriptor.range.valid.1570 = and i1 %descriptor.range.inside.1571, %descriptor.payload.inside.1568
  %descriptor.type.valid.1572 = icmp eq i32 1, 1
  %descriptor.valid.1573 = and i1 %descriptor.range.valid.1570, %descriptor.type.valid.1572
  br i1 %descriptor.valid.1573, label %descriptor.valid.1574, label %descriptor.invalid.1575
descriptor.invalid.1575:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1574:
  %descriptor.initialized.status.1576 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1354, i32 8)
  %helper.ok.1577 = icmp eq i32 %descriptor.initialized.status.1576, 0
  br i1 %helper.ok.1577, label %helper.continue.1578, label %frame.failure.0
helper.continue.1578:
  %context.field.1579 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1580 = load i32, ptr %context.field.1579, align 4
  %stack.sub.1583 = sub i32 %stack.offset.1550, %context.value.1549
  %descriptor.owner.inside.1581 = icmp ule i32 %stack.offset.1550, %context.value.1580
  %descriptor.offset.inside.1582 = icmp ule i32 %context.value.1549, %stack.offset.1550
  %descriptor.extent.inside.1584 = icmp ule i32 8, %stack.sub.1583
  %descriptor.payload.inside.1585 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1586 = and i1 %descriptor.owner.inside.1581, %descriptor.offset.inside.1582
  %descriptor.range.inside.1588 = and i1 %descriptor.owner.offset.valid.1586, %descriptor.extent.inside.1584
  %descriptor.range.valid.1587 = and i1 %descriptor.range.inside.1588, %descriptor.payload.inside.1585
  %descriptor.type.valid.1589 = icmp eq i32 1, 1
  %descriptor.valid.1590 = and i1 %descriptor.range.valid.1587, %descriptor.type.valid.1589
  br i1 %descriptor.valid.1590, label %descriptor.valid.1591, label %descriptor.invalid.1592
descriptor.invalid.1592:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1591:
  %descriptor.initialized.status.1593 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1549, i32 8)
  %helper.ok.1594 = icmp eq i32 %descriptor.initialized.status.1593, 0
  br i1 %helper.ok.1594, label %helper.continue.1595, label %frame.failure.0
helper.continue.1595:
  %local.is.active.1596 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1596, label %local.descriptor.active.1597, label %local.descriptor.inactive.1598
local.descriptor.active.1597:
  %local.check.offset.1600 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1601 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1602 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1603 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1605 = load i32, ptr %context.field.1604, align 4
  %stack.sub.1608 = sub i32 %local.check.owner.end.1603, %local.check.offset.1600
  %descriptor.owner.inside.1606 = icmp ule i32 %local.check.owner.end.1603, %context.value.1605
  %descriptor.offset.inside.1607 = icmp ule i32 %local.check.offset.1600, %local.check.owner.end.1603
  %descriptor.extent.inside.1609 = icmp ule i32 %local.check.extent.1601, %stack.sub.1608
  %descriptor.payload.inside.1610 = icmp ule i32 %local.check.payload.1602, %local.check.extent.1601
  %descriptor.owner.offset.valid.1611 = and i1 %descriptor.owner.inside.1606, %descriptor.offset.inside.1607
  %descriptor.range.inside.1613 = and i1 %descriptor.owner.offset.valid.1611, %descriptor.extent.inside.1609
  %descriptor.range.valid.1612 = and i1 %descriptor.range.inside.1613, %descriptor.payload.inside.1610
  br i1 %descriptor.range.valid.1612, label %descriptor.valid.1614, label %descriptor.invalid.1615
descriptor.invalid.1615:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1614:
  %descriptor.initialized.status.1616 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1600, i32 %local.check.extent.1601)
  %helper.ok.1617 = icmp eq i32 %descriptor.initialized.status.1616, 0
  br i1 %helper.ok.1617, label %helper.continue.1618, label %frame.failure.0
helper.continue.1618:
  br label %local.descriptor.checked.1599
local.descriptor.inactive.1598:
  br label %local.descriptor.checked.1599
local.descriptor.checked.1599:
  %local.is.active.1619 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1619, label %local.descriptor.active.1620, label %local.descriptor.inactive.1621
local.descriptor.active.1620:
  %local.check.offset.1623 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1624 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1625 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1626 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1627 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1628 = load i32, ptr %context.field.1627, align 4
  %stack.sub.1631 = sub i32 %local.check.owner.end.1626, %local.check.offset.1623
  %descriptor.owner.inside.1629 = icmp ule i32 %local.check.owner.end.1626, %context.value.1628
  %descriptor.offset.inside.1630 = icmp ule i32 %local.check.offset.1623, %local.check.owner.end.1626
  %descriptor.extent.inside.1632 = icmp ule i32 %local.check.extent.1624, %stack.sub.1631
  %descriptor.payload.inside.1633 = icmp ule i32 %local.check.payload.1625, %local.check.extent.1624
  %descriptor.owner.offset.valid.1634 = and i1 %descriptor.owner.inside.1629, %descriptor.offset.inside.1630
  %descriptor.range.inside.1636 = and i1 %descriptor.owner.offset.valid.1634, %descriptor.extent.inside.1632
  %descriptor.range.valid.1635 = and i1 %descriptor.range.inside.1636, %descriptor.payload.inside.1633
  br i1 %descriptor.range.valid.1635, label %descriptor.valid.1637, label %descriptor.invalid.1638
descriptor.invalid.1638:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1637:
  %descriptor.initialized.status.1639 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1623, i32 %local.check.extent.1624)
  %helper.ok.1640 = icmp eq i32 %descriptor.initialized.status.1639, 0
  br i1 %helper.ok.1640, label %helper.continue.1641, label %frame.failure.0
helper.continue.1641:
  br label %local.descriptor.checked.1622
local.descriptor.inactive.1621:
  br label %local.descriptor.checked.1622
local.descriptor.checked.1622:
  %local.is.active.1642 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1642, label %local.descriptor.active.1643, label %local.descriptor.inactive.1644
local.descriptor.active.1643:
  %local.check.offset.1646 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1647 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1648 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1649 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1650 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1651 = load i32, ptr %context.field.1650, align 4
  %stack.sub.1654 = sub i32 %local.check.owner.end.1649, %local.check.offset.1646
  %descriptor.owner.inside.1652 = icmp ule i32 %local.check.owner.end.1649, %context.value.1651
  %descriptor.offset.inside.1653 = icmp ule i32 %local.check.offset.1646, %local.check.owner.end.1649
  %descriptor.extent.inside.1655 = icmp ule i32 %local.check.extent.1647, %stack.sub.1654
  %descriptor.payload.inside.1656 = icmp ule i32 %local.check.payload.1648, %local.check.extent.1647
  %descriptor.owner.offset.valid.1657 = and i1 %descriptor.owner.inside.1652, %descriptor.offset.inside.1653
  %descriptor.range.inside.1659 = and i1 %descriptor.owner.offset.valid.1657, %descriptor.extent.inside.1655
  %descriptor.range.valid.1658 = and i1 %descriptor.range.inside.1659, %descriptor.payload.inside.1656
  br i1 %descriptor.range.valid.1658, label %descriptor.valid.1660, label %descriptor.invalid.1661
descriptor.invalid.1661:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1660:
  %descriptor.initialized.status.1662 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1646, i32 %local.check.extent.1647)
  %helper.ok.1663 = icmp eq i32 %descriptor.initialized.status.1662, 0
  br i1 %helper.ok.1663, label %helper.continue.1664, label %frame.failure.0
helper.continue.1664:
  br label %local.descriptor.checked.1645
local.descriptor.inactive.1644:
  br label %local.descriptor.checked.1645
local.descriptor.checked.1645:
  %local.is.active.1665 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1665, label %local.descriptor.active.1666, label %local.descriptor.inactive.1667
local.descriptor.active.1666:
  %local.check.offset.1669 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1670 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1671 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1672 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1673 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1674 = load i32, ptr %context.field.1673, align 4
  %stack.sub.1677 = sub i32 %local.check.owner.end.1672, %local.check.offset.1669
  %descriptor.owner.inside.1675 = icmp ule i32 %local.check.owner.end.1672, %context.value.1674
  %descriptor.offset.inside.1676 = icmp ule i32 %local.check.offset.1669, %local.check.owner.end.1672
  %descriptor.extent.inside.1678 = icmp ule i32 %local.check.extent.1670, %stack.sub.1677
  %descriptor.payload.inside.1679 = icmp ule i32 %local.check.payload.1671, %local.check.extent.1670
  %descriptor.owner.offset.valid.1680 = and i1 %descriptor.owner.inside.1675, %descriptor.offset.inside.1676
  %descriptor.range.inside.1682 = and i1 %descriptor.owner.offset.valid.1680, %descriptor.extent.inside.1678
  %descriptor.range.valid.1681 = and i1 %descriptor.range.inside.1682, %descriptor.payload.inside.1679
  br i1 %descriptor.range.valid.1681, label %descriptor.valid.1683, label %descriptor.invalid.1684
descriptor.invalid.1684:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1683:
  %descriptor.initialized.status.1685 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1669, i32 %local.check.extent.1670)
  %helper.ok.1686 = icmp eq i32 %descriptor.initialized.status.1685, 0
  br i1 %helper.ok.1686, label %helper.continue.1687, label %frame.failure.0
helper.continue.1687:
  br label %local.descriptor.checked.1668
local.descriptor.inactive.1667:
  br label %local.descriptor.checked.1668
local.descriptor.checked.1668:
  %local.is.active.1688 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1688, label %local.descriptor.active.1689, label %local.descriptor.inactive.1690
local.descriptor.active.1689:
  %local.check.offset.1692 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1693 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1694 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1695 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1696 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1697 = load i32, ptr %context.field.1696, align 4
  %stack.sub.1700 = sub i32 %local.check.owner.end.1695, %local.check.offset.1692
  %descriptor.owner.inside.1698 = icmp ule i32 %local.check.owner.end.1695, %context.value.1697
  %descriptor.offset.inside.1699 = icmp ule i32 %local.check.offset.1692, %local.check.owner.end.1695
  %descriptor.extent.inside.1701 = icmp ule i32 %local.check.extent.1693, %stack.sub.1700
  %descriptor.payload.inside.1702 = icmp ule i32 %local.check.payload.1694, %local.check.extent.1693
  %descriptor.owner.offset.valid.1703 = and i1 %descriptor.owner.inside.1698, %descriptor.offset.inside.1699
  %descriptor.range.inside.1705 = and i1 %descriptor.owner.offset.valid.1703, %descriptor.extent.inside.1701
  %descriptor.range.valid.1704 = and i1 %descriptor.range.inside.1705, %descriptor.payload.inside.1702
  br i1 %descriptor.range.valid.1704, label %descriptor.valid.1706, label %descriptor.invalid.1707
descriptor.invalid.1707:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1706:
  %descriptor.initialized.status.1708 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1692, i32 %local.check.extent.1693)
  %helper.ok.1709 = icmp eq i32 %descriptor.initialized.status.1708, 0
  br i1 %helper.ok.1709, label %helper.continue.1710, label %frame.failure.0
helper.continue.1710:
  br label %local.descriptor.checked.1691
local.descriptor.inactive.1690:
  br label %local.descriptor.checked.1691
local.descriptor.checked.1691:
  %local.is.active.1711 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1711, label %local.descriptor.active.1712, label %local.descriptor.inactive.1713
local.descriptor.active.1712:
  %local.check.offset.1715 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1716 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1717 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1718 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1719 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1720 = load i32, ptr %context.field.1719, align 4
  %stack.sub.1723 = sub i32 %local.check.owner.end.1718, %local.check.offset.1715
  %descriptor.owner.inside.1721 = icmp ule i32 %local.check.owner.end.1718, %context.value.1720
  %descriptor.offset.inside.1722 = icmp ule i32 %local.check.offset.1715, %local.check.owner.end.1718
  %descriptor.extent.inside.1724 = icmp ule i32 %local.check.extent.1716, %stack.sub.1723
  %descriptor.payload.inside.1725 = icmp ule i32 %local.check.payload.1717, %local.check.extent.1716
  %descriptor.owner.offset.valid.1726 = and i1 %descriptor.owner.inside.1721, %descriptor.offset.inside.1722
  %descriptor.range.inside.1728 = and i1 %descriptor.owner.offset.valid.1726, %descriptor.extent.inside.1724
  %descriptor.range.valid.1727 = and i1 %descriptor.range.inside.1728, %descriptor.payload.inside.1725
  br i1 %descriptor.range.valid.1727, label %descriptor.valid.1729, label %descriptor.invalid.1730
descriptor.invalid.1730:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1729:
  %descriptor.initialized.status.1731 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1715, i32 %local.check.extent.1716)
  %helper.ok.1732 = icmp eq i32 %descriptor.initialized.status.1731, 0
  br i1 %helper.ok.1732, label %helper.continue.1733, label %frame.failure.0
helper.continue.1733:
  br label %local.descriptor.checked.1714
local.descriptor.inactive.1713:
  br label %local.descriptor.checked.1714
local.descriptor.checked.1714:
  %local.is.active.1734 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1734, label %local.descriptor.active.1735, label %local.descriptor.inactive.1736
local.descriptor.active.1735:
  %local.check.offset.1738 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1739 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1740 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1741 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1742 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1743 = load i32, ptr %context.field.1742, align 4
  %stack.sub.1746 = sub i32 %local.check.owner.end.1741, %local.check.offset.1738
  %descriptor.owner.inside.1744 = icmp ule i32 %local.check.owner.end.1741, %context.value.1743
  %descriptor.offset.inside.1745 = icmp ule i32 %local.check.offset.1738, %local.check.owner.end.1741
  %descriptor.extent.inside.1747 = icmp ule i32 %local.check.extent.1739, %stack.sub.1746
  %descriptor.payload.inside.1748 = icmp ule i32 %local.check.payload.1740, %local.check.extent.1739
  %descriptor.owner.offset.valid.1749 = and i1 %descriptor.owner.inside.1744, %descriptor.offset.inside.1745
  %descriptor.range.inside.1751 = and i1 %descriptor.owner.offset.valid.1749, %descriptor.extent.inside.1747
  %descriptor.range.valid.1750 = and i1 %descriptor.range.inside.1751, %descriptor.payload.inside.1748
  br i1 %descriptor.range.valid.1750, label %descriptor.valid.1752, label %descriptor.invalid.1753
descriptor.invalid.1753:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1752:
  %descriptor.initialized.status.1754 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1738, i32 %local.check.extent.1739)
  %helper.ok.1755 = icmp eq i32 %descriptor.initialized.status.1754, 0
  br i1 %helper.ok.1755, label %helper.continue.1756, label %frame.failure.0
helper.continue.1756:
  br label %local.descriptor.checked.1737
local.descriptor.inactive.1736:
  br label %local.descriptor.checked.1737
local.descriptor.checked.1737:
  %step.status.1757 = call i32 @al_owning_charge_step(ptr %ctx, i32 40)
  %helper.ok.1758 = icmp eq i32 %step.status.1757, 0
  br i1 %helper.ok.1758, label %helper.continue.1759, label %frame.failure.0
helper.continue.1759:
  %integer.left.1760 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1354)
  %context.field.1762 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1763 = load i32, ptr %context.field.1762, align 4
  %runtime.ok.1764 = icmp eq i32 %context.value.1763, 0
  br i1 %runtime.ok.1764, label %runtime.continue.1765, label %frame.failure.0
runtime.continue.1765:
  %integer.right.1761 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1549)
  %context.field.1766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1767 = load i32, ptr %context.field.1766, align 4
  %runtime.ok.1768 = icmp eq i32 %context.value.1767, 0
  br i1 %runtime.ok.1768, label %runtime.continue.1769, label %frame.failure.0
runtime.continue.1769:
  %divide.zero.1770 = icmp eq i64 %integer.right.1761, 0
  br i1 %divide.zero.1770, label %divide.zero.1771, label %divide.nonzero.1772
divide.zero.1771:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 41, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.1772:
  %divide.min.1773 = icmp eq i64 %integer.left.1760, -9223372036854775808
  %divide.minusone.1774 = icmp eq i64 %integer.right.1761, -1
  %divide.overflow.1775 = and i1 %divide.min.1773, %divide.minusone.1774
  br i1 %divide.overflow.1775, label %divide.overflow.1776, label %divide.valid.1777
divide.overflow.1776:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 42, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.1777:
  %divide.result.1778 = sdiv i64 %integer.left.1760, %integer.right.1761
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1549, i32 8, i32 8, i32 0, i32 0)
  %context.field.1779 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1780 = load i32, ptr %context.field.1779, align 4
  %runtime.ok.1781 = icmp eq i32 %context.value.1780, 0
  br i1 %runtime.ok.1781, label %runtime.continue.1782, label %frame.failure.0
runtime.continue.1782:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1354, i32 8, i32 8, i32 0, i32 0)
  %context.field.1783 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1784 = load i32, ptr %context.field.1783, align 4
  %runtime.ok.1785 = icmp eq i32 %context.value.1784, 0
  br i1 %runtime.ok.1785, label %runtime.continue.1786, label %frame.failure.0
runtime.continue.1786:
  %context.field.1787 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1788 = load i32, ptr %context.field.1787, align 4
  %stack.offset.1789 = add i32 %context.value.1788, 8
  %reserve.status.1790 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1789, i32 43)
  %reserve.ok.1791 = icmp eq i32 %reserve.status.1790, 0
  br i1 %reserve.ok.1791, label %reserve.continue.1792, label %frame.failure.0
reserve.continue.1792:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1788, i64 %divide.result.1778, i32 1)
  %context.field.1793 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1794 = load i32, ptr %context.field.1793, align 4
  %runtime.ok.1795 = icmp eq i32 %context.value.1794, 0
  br i1 %runtime.ok.1795, label %runtime.continue.1796, label %frame.failure.0
runtime.continue.1796:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1797 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1798 = load i32, ptr %context.field.1797, align 4
  %runtime.ok.1799 = icmp eq i32 %context.value.1798, 0
  br i1 %runtime.ok.1799, label %runtime.continue.1800, label %frame.failure.0
runtime.continue.1800:
  %stack.offset.1801 = add i32 %context.value.1788, 8
  %context.field.1802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1803 = load i32, ptr %context.field.1802, align 4
  %stack.sub.1806 = sub i32 %stack.offset.1801, %context.value.1788
  %descriptor.owner.inside.1804 = icmp ule i32 %stack.offset.1801, %context.value.1803
  %descriptor.offset.inside.1805 = icmp ule i32 %context.value.1788, %stack.offset.1801
  %descriptor.extent.inside.1807 = icmp ule i32 8, %stack.sub.1806
  %descriptor.payload.inside.1808 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1809 = and i1 %descriptor.owner.inside.1804, %descriptor.offset.inside.1805
  %descriptor.range.inside.1811 = and i1 %descriptor.owner.offset.valid.1809, %descriptor.extent.inside.1807
  %descriptor.range.valid.1810 = and i1 %descriptor.range.inside.1811, %descriptor.payload.inside.1808
  %descriptor.type.valid.1812 = icmp eq i32 1, 1
  %descriptor.valid.1813 = and i1 %descriptor.range.valid.1810, %descriptor.type.valid.1812
  br i1 %descriptor.valid.1813, label %descriptor.valid.1814, label %descriptor.invalid.1815
descriptor.invalid.1815:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1814:
  %descriptor.initialized.status.1816 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1788, i32 8)
  %helper.ok.1817 = icmp eq i32 %descriptor.initialized.status.1816, 0
  br i1 %helper.ok.1817, label %helper.continue.1818, label %frame.failure.0
helper.continue.1818:
  %local.is.active.1819 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1819, label %local.descriptor.active.1820, label %local.descriptor.inactive.1821
local.descriptor.active.1820:
  %local.check.offset.1823 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1824 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1825 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1826 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1827 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1828 = load i32, ptr %context.field.1827, align 4
  %stack.sub.1831 = sub i32 %local.check.owner.end.1826, %local.check.offset.1823
  %descriptor.owner.inside.1829 = icmp ule i32 %local.check.owner.end.1826, %context.value.1828
  %descriptor.offset.inside.1830 = icmp ule i32 %local.check.offset.1823, %local.check.owner.end.1826
  %descriptor.extent.inside.1832 = icmp ule i32 %local.check.extent.1824, %stack.sub.1831
  %descriptor.payload.inside.1833 = icmp ule i32 %local.check.payload.1825, %local.check.extent.1824
  %descriptor.owner.offset.valid.1834 = and i1 %descriptor.owner.inside.1829, %descriptor.offset.inside.1830
  %descriptor.range.inside.1836 = and i1 %descriptor.owner.offset.valid.1834, %descriptor.extent.inside.1832
  %descriptor.range.valid.1835 = and i1 %descriptor.range.inside.1836, %descriptor.payload.inside.1833
  br i1 %descriptor.range.valid.1835, label %descriptor.valid.1837, label %descriptor.invalid.1838
descriptor.invalid.1838:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1837:
  %descriptor.initialized.status.1839 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1823, i32 %local.check.extent.1824)
  %helper.ok.1840 = icmp eq i32 %descriptor.initialized.status.1839, 0
  br i1 %helper.ok.1840, label %helper.continue.1841, label %frame.failure.0
helper.continue.1841:
  br label %local.descriptor.checked.1822
local.descriptor.inactive.1821:
  br label %local.descriptor.checked.1822
local.descriptor.checked.1822:
  %local.is.active.1842 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1842, label %local.descriptor.active.1843, label %local.descriptor.inactive.1844
local.descriptor.active.1843:
  %local.check.offset.1846 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1847 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1848 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1849 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1850 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1851 = load i32, ptr %context.field.1850, align 4
  %stack.sub.1854 = sub i32 %local.check.owner.end.1849, %local.check.offset.1846
  %descriptor.owner.inside.1852 = icmp ule i32 %local.check.owner.end.1849, %context.value.1851
  %descriptor.offset.inside.1853 = icmp ule i32 %local.check.offset.1846, %local.check.owner.end.1849
  %descriptor.extent.inside.1855 = icmp ule i32 %local.check.extent.1847, %stack.sub.1854
  %descriptor.payload.inside.1856 = icmp ule i32 %local.check.payload.1848, %local.check.extent.1847
  %descriptor.owner.offset.valid.1857 = and i1 %descriptor.owner.inside.1852, %descriptor.offset.inside.1853
  %descriptor.range.inside.1859 = and i1 %descriptor.owner.offset.valid.1857, %descriptor.extent.inside.1855
  %descriptor.range.valid.1858 = and i1 %descriptor.range.inside.1859, %descriptor.payload.inside.1856
  br i1 %descriptor.range.valid.1858, label %descriptor.valid.1860, label %descriptor.invalid.1861
descriptor.invalid.1861:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1860:
  %descriptor.initialized.status.1862 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1846, i32 %local.check.extent.1847)
  %helper.ok.1863 = icmp eq i32 %descriptor.initialized.status.1862, 0
  br i1 %helper.ok.1863, label %helper.continue.1864, label %frame.failure.0
helper.continue.1864:
  br label %local.descriptor.checked.1845
local.descriptor.inactive.1844:
  br label %local.descriptor.checked.1845
local.descriptor.checked.1845:
  %local.is.active.1865 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1865, label %local.descriptor.active.1866, label %local.descriptor.inactive.1867
local.descriptor.active.1866:
  %local.check.offset.1869 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1870 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1871 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1872 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1873 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1874 = load i32, ptr %context.field.1873, align 4
  %stack.sub.1877 = sub i32 %local.check.owner.end.1872, %local.check.offset.1869
  %descriptor.owner.inside.1875 = icmp ule i32 %local.check.owner.end.1872, %context.value.1874
  %descriptor.offset.inside.1876 = icmp ule i32 %local.check.offset.1869, %local.check.owner.end.1872
  %descriptor.extent.inside.1878 = icmp ule i32 %local.check.extent.1870, %stack.sub.1877
  %descriptor.payload.inside.1879 = icmp ule i32 %local.check.payload.1871, %local.check.extent.1870
  %descriptor.owner.offset.valid.1880 = and i1 %descriptor.owner.inside.1875, %descriptor.offset.inside.1876
  %descriptor.range.inside.1882 = and i1 %descriptor.owner.offset.valid.1880, %descriptor.extent.inside.1878
  %descriptor.range.valid.1881 = and i1 %descriptor.range.inside.1882, %descriptor.payload.inside.1879
  br i1 %descriptor.range.valid.1881, label %descriptor.valid.1883, label %descriptor.invalid.1884
descriptor.invalid.1884:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1883:
  %descriptor.initialized.status.1885 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1869, i32 %local.check.extent.1870)
  %helper.ok.1886 = icmp eq i32 %descriptor.initialized.status.1885, 0
  br i1 %helper.ok.1886, label %helper.continue.1887, label %frame.failure.0
helper.continue.1887:
  br label %local.descriptor.checked.1868
local.descriptor.inactive.1867:
  br label %local.descriptor.checked.1868
local.descriptor.checked.1868:
  %local.is.active.1888 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1888, label %local.descriptor.active.1889, label %local.descriptor.inactive.1890
local.descriptor.active.1889:
  %local.check.offset.1892 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1893 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1894 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1895 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1897 = load i32, ptr %context.field.1896, align 4
  %stack.sub.1900 = sub i32 %local.check.owner.end.1895, %local.check.offset.1892
  %descriptor.owner.inside.1898 = icmp ule i32 %local.check.owner.end.1895, %context.value.1897
  %descriptor.offset.inside.1899 = icmp ule i32 %local.check.offset.1892, %local.check.owner.end.1895
  %descriptor.extent.inside.1901 = icmp ule i32 %local.check.extent.1893, %stack.sub.1900
  %descriptor.payload.inside.1902 = icmp ule i32 %local.check.payload.1894, %local.check.extent.1893
  %descriptor.owner.offset.valid.1903 = and i1 %descriptor.owner.inside.1898, %descriptor.offset.inside.1899
  %descriptor.range.inside.1905 = and i1 %descriptor.owner.offset.valid.1903, %descriptor.extent.inside.1901
  %descriptor.range.valid.1904 = and i1 %descriptor.range.inside.1905, %descriptor.payload.inside.1902
  br i1 %descriptor.range.valid.1904, label %descriptor.valid.1906, label %descriptor.invalid.1907
descriptor.invalid.1907:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1906:
  %descriptor.initialized.status.1908 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1892, i32 %local.check.extent.1893)
  %helper.ok.1909 = icmp eq i32 %descriptor.initialized.status.1908, 0
  br i1 %helper.ok.1909, label %helper.continue.1910, label %frame.failure.0
helper.continue.1910:
  br label %local.descriptor.checked.1891
local.descriptor.inactive.1890:
  br label %local.descriptor.checked.1891
local.descriptor.checked.1891:
  %local.is.active.1911 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1911, label %local.descriptor.active.1912, label %local.descriptor.inactive.1913
local.descriptor.active.1912:
  %local.check.offset.1915 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1916 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1917 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1918 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1920 = load i32, ptr %context.field.1919, align 4
  %stack.sub.1923 = sub i32 %local.check.owner.end.1918, %local.check.offset.1915
  %descriptor.owner.inside.1921 = icmp ule i32 %local.check.owner.end.1918, %context.value.1920
  %descriptor.offset.inside.1922 = icmp ule i32 %local.check.offset.1915, %local.check.owner.end.1918
  %descriptor.extent.inside.1924 = icmp ule i32 %local.check.extent.1916, %stack.sub.1923
  %descriptor.payload.inside.1925 = icmp ule i32 %local.check.payload.1917, %local.check.extent.1916
  %descriptor.owner.offset.valid.1926 = and i1 %descriptor.owner.inside.1921, %descriptor.offset.inside.1922
  %descriptor.range.inside.1928 = and i1 %descriptor.owner.offset.valid.1926, %descriptor.extent.inside.1924
  %descriptor.range.valid.1927 = and i1 %descriptor.range.inside.1928, %descriptor.payload.inside.1925
  br i1 %descriptor.range.valid.1927, label %descriptor.valid.1929, label %descriptor.invalid.1930
descriptor.invalid.1930:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1929:
  %descriptor.initialized.status.1931 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1915, i32 %local.check.extent.1916)
  %helper.ok.1932 = icmp eq i32 %descriptor.initialized.status.1931, 0
  br i1 %helper.ok.1932, label %helper.continue.1933, label %frame.failure.0
helper.continue.1933:
  br label %local.descriptor.checked.1914
local.descriptor.inactive.1913:
  br label %local.descriptor.checked.1914
local.descriptor.checked.1914:
  %local.is.active.1934 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1934, label %local.descriptor.active.1935, label %local.descriptor.inactive.1936
local.descriptor.active.1935:
  %local.check.offset.1938 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1939 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1940 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1941 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1942 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1943 = load i32, ptr %context.field.1942, align 4
  %stack.sub.1946 = sub i32 %local.check.owner.end.1941, %local.check.offset.1938
  %descriptor.owner.inside.1944 = icmp ule i32 %local.check.owner.end.1941, %context.value.1943
  %descriptor.offset.inside.1945 = icmp ule i32 %local.check.offset.1938, %local.check.owner.end.1941
  %descriptor.extent.inside.1947 = icmp ule i32 %local.check.extent.1939, %stack.sub.1946
  %descriptor.payload.inside.1948 = icmp ule i32 %local.check.payload.1940, %local.check.extent.1939
  %descriptor.owner.offset.valid.1949 = and i1 %descriptor.owner.inside.1944, %descriptor.offset.inside.1945
  %descriptor.range.inside.1951 = and i1 %descriptor.owner.offset.valid.1949, %descriptor.extent.inside.1947
  %descriptor.range.valid.1950 = and i1 %descriptor.range.inside.1951, %descriptor.payload.inside.1948
  br i1 %descriptor.range.valid.1950, label %descriptor.valid.1952, label %descriptor.invalid.1953
descriptor.invalid.1953:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1952:
  %descriptor.initialized.status.1954 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1938, i32 %local.check.extent.1939)
  %helper.ok.1955 = icmp eq i32 %descriptor.initialized.status.1954, 0
  br i1 %helper.ok.1955, label %helper.continue.1956, label %frame.failure.0
helper.continue.1956:
  br label %local.descriptor.checked.1937
local.descriptor.inactive.1936:
  br label %local.descriptor.checked.1937
local.descriptor.checked.1937:
  %local.is.active.1957 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1957, label %local.descriptor.active.1958, label %local.descriptor.inactive.1959
local.descriptor.active.1958:
  %local.check.offset.1961 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1962 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1963 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1964 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1965 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1966 = load i32, ptr %context.field.1965, align 4
  %stack.sub.1969 = sub i32 %local.check.owner.end.1964, %local.check.offset.1961
  %descriptor.owner.inside.1967 = icmp ule i32 %local.check.owner.end.1964, %context.value.1966
  %descriptor.offset.inside.1968 = icmp ule i32 %local.check.offset.1961, %local.check.owner.end.1964
  %descriptor.extent.inside.1970 = icmp ule i32 %local.check.extent.1962, %stack.sub.1969
  %descriptor.payload.inside.1971 = icmp ule i32 %local.check.payload.1963, %local.check.extent.1962
  %descriptor.owner.offset.valid.1972 = and i1 %descriptor.owner.inside.1967, %descriptor.offset.inside.1968
  %descriptor.range.inside.1974 = and i1 %descriptor.owner.offset.valid.1972, %descriptor.extent.inside.1970
  %descriptor.range.valid.1973 = and i1 %descriptor.range.inside.1974, %descriptor.payload.inside.1971
  br i1 %descriptor.range.valid.1973, label %descriptor.valid.1975, label %descriptor.invalid.1976
descriptor.invalid.1976:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1975:
  %descriptor.initialized.status.1977 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1961, i32 %local.check.extent.1962)
  %helper.ok.1978 = icmp eq i32 %descriptor.initialized.status.1977, 0
  br i1 %helper.ok.1978, label %helper.continue.1979, label %frame.failure.0
helper.continue.1979:
  br label %local.descriptor.checked.1960
local.descriptor.inactive.1959:
  br label %local.descriptor.checked.1960
local.descriptor.checked.1960:
  %context.field.1980 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1981 = load i32, ptr %context.field.1980, align 4
  %stack.sub.1984 = sub i32 %stack.offset.1801, %context.value.1788
  %descriptor.owner.inside.1982 = icmp ule i32 %stack.offset.1801, %context.value.1981
  %descriptor.offset.inside.1983 = icmp ule i32 %context.value.1788, %stack.offset.1801
  %descriptor.extent.inside.1985 = icmp ule i32 8, %stack.sub.1984
  %descriptor.payload.inside.1986 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1987 = and i1 %descriptor.owner.inside.1982, %descriptor.offset.inside.1983
  %descriptor.range.inside.1989 = and i1 %descriptor.owner.offset.valid.1987, %descriptor.extent.inside.1985
  %descriptor.range.valid.1988 = and i1 %descriptor.range.inside.1989, %descriptor.payload.inside.1986
  %descriptor.type.valid.1990 = icmp eq i32 1, 1
  %descriptor.valid.1991 = and i1 %descriptor.range.valid.1988, %descriptor.type.valid.1990
  br i1 %descriptor.valid.1991, label %descriptor.valid.1992, label %descriptor.invalid.1993
descriptor.invalid.1993:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1992:
  %descriptor.initialized.status.1994 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1788, i32 8)
  %helper.ok.1995 = icmp eq i32 %descriptor.initialized.status.1994, 0
  br i1 %helper.ok.1995, label %helper.continue.1996, label %frame.failure.0
helper.continue.1996:
  %local.is.active.1997 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1997, label %local.descriptor.active.1998, label %local.descriptor.inactive.1999
local.descriptor.active.1998:
  %local.check.offset.2001 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2002 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2003 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2004 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2005 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2006 = load i32, ptr %context.field.2005, align 4
  %stack.sub.2009 = sub i32 %local.check.owner.end.2004, %local.check.offset.2001
  %descriptor.owner.inside.2007 = icmp ule i32 %local.check.owner.end.2004, %context.value.2006
  %descriptor.offset.inside.2008 = icmp ule i32 %local.check.offset.2001, %local.check.owner.end.2004
  %descriptor.extent.inside.2010 = icmp ule i32 %local.check.extent.2002, %stack.sub.2009
  %descriptor.payload.inside.2011 = icmp ule i32 %local.check.payload.2003, %local.check.extent.2002
  %descriptor.owner.offset.valid.2012 = and i1 %descriptor.owner.inside.2007, %descriptor.offset.inside.2008
  %descriptor.range.inside.2014 = and i1 %descriptor.owner.offset.valid.2012, %descriptor.extent.inside.2010
  %descriptor.range.valid.2013 = and i1 %descriptor.range.inside.2014, %descriptor.payload.inside.2011
  br i1 %descriptor.range.valid.2013, label %descriptor.valid.2015, label %descriptor.invalid.2016
descriptor.invalid.2016:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2015:
  %descriptor.initialized.status.2017 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2001, i32 %local.check.extent.2002)
  %helper.ok.2018 = icmp eq i32 %descriptor.initialized.status.2017, 0
  br i1 %helper.ok.2018, label %helper.continue.2019, label %frame.failure.0
helper.continue.2019:
  br label %local.descriptor.checked.2000
local.descriptor.inactive.1999:
  br label %local.descriptor.checked.2000
local.descriptor.checked.2000:
  %local.is.active.2020 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2020, label %local.descriptor.active.2021, label %local.descriptor.inactive.2022
local.descriptor.active.2021:
  %local.check.offset.2024 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2025 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2026 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2027 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2028 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2029 = load i32, ptr %context.field.2028, align 4
  %stack.sub.2032 = sub i32 %local.check.owner.end.2027, %local.check.offset.2024
  %descriptor.owner.inside.2030 = icmp ule i32 %local.check.owner.end.2027, %context.value.2029
  %descriptor.offset.inside.2031 = icmp ule i32 %local.check.offset.2024, %local.check.owner.end.2027
  %descriptor.extent.inside.2033 = icmp ule i32 %local.check.extent.2025, %stack.sub.2032
  %descriptor.payload.inside.2034 = icmp ule i32 %local.check.payload.2026, %local.check.extent.2025
  %descriptor.owner.offset.valid.2035 = and i1 %descriptor.owner.inside.2030, %descriptor.offset.inside.2031
  %descriptor.range.inside.2037 = and i1 %descriptor.owner.offset.valid.2035, %descriptor.extent.inside.2033
  %descriptor.range.valid.2036 = and i1 %descriptor.range.inside.2037, %descriptor.payload.inside.2034
  br i1 %descriptor.range.valid.2036, label %descriptor.valid.2038, label %descriptor.invalid.2039
descriptor.invalid.2039:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2038:
  %descriptor.initialized.status.2040 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2024, i32 %local.check.extent.2025)
  %helper.ok.2041 = icmp eq i32 %descriptor.initialized.status.2040, 0
  br i1 %helper.ok.2041, label %helper.continue.2042, label %frame.failure.0
helper.continue.2042:
  br label %local.descriptor.checked.2023
local.descriptor.inactive.2022:
  br label %local.descriptor.checked.2023
local.descriptor.checked.2023:
  %local.is.active.2043 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2043, label %local.descriptor.active.2044, label %local.descriptor.inactive.2045
local.descriptor.active.2044:
  %local.check.offset.2047 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2048 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2049 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2050 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2051 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2052 = load i32, ptr %context.field.2051, align 4
  %stack.sub.2055 = sub i32 %local.check.owner.end.2050, %local.check.offset.2047
  %descriptor.owner.inside.2053 = icmp ule i32 %local.check.owner.end.2050, %context.value.2052
  %descriptor.offset.inside.2054 = icmp ule i32 %local.check.offset.2047, %local.check.owner.end.2050
  %descriptor.extent.inside.2056 = icmp ule i32 %local.check.extent.2048, %stack.sub.2055
  %descriptor.payload.inside.2057 = icmp ule i32 %local.check.payload.2049, %local.check.extent.2048
  %descriptor.owner.offset.valid.2058 = and i1 %descriptor.owner.inside.2053, %descriptor.offset.inside.2054
  %descriptor.range.inside.2060 = and i1 %descriptor.owner.offset.valid.2058, %descriptor.extent.inside.2056
  %descriptor.range.valid.2059 = and i1 %descriptor.range.inside.2060, %descriptor.payload.inside.2057
  br i1 %descriptor.range.valid.2059, label %descriptor.valid.2061, label %descriptor.invalid.2062
descriptor.invalid.2062:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2061:
  %descriptor.initialized.status.2063 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2047, i32 %local.check.extent.2048)
  %helper.ok.2064 = icmp eq i32 %descriptor.initialized.status.2063, 0
  br i1 %helper.ok.2064, label %helper.continue.2065, label %frame.failure.0
helper.continue.2065:
  br label %local.descriptor.checked.2046
local.descriptor.inactive.2045:
  br label %local.descriptor.checked.2046
local.descriptor.checked.2046:
  %local.is.active.2066 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2066, label %local.descriptor.active.2067, label %local.descriptor.inactive.2068
local.descriptor.active.2067:
  %local.check.offset.2070 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2071 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2072 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2073 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2074 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2075 = load i32, ptr %context.field.2074, align 4
  %stack.sub.2078 = sub i32 %local.check.owner.end.2073, %local.check.offset.2070
  %descriptor.owner.inside.2076 = icmp ule i32 %local.check.owner.end.2073, %context.value.2075
  %descriptor.offset.inside.2077 = icmp ule i32 %local.check.offset.2070, %local.check.owner.end.2073
  %descriptor.extent.inside.2079 = icmp ule i32 %local.check.extent.2071, %stack.sub.2078
  %descriptor.payload.inside.2080 = icmp ule i32 %local.check.payload.2072, %local.check.extent.2071
  %descriptor.owner.offset.valid.2081 = and i1 %descriptor.owner.inside.2076, %descriptor.offset.inside.2077
  %descriptor.range.inside.2083 = and i1 %descriptor.owner.offset.valid.2081, %descriptor.extent.inside.2079
  %descriptor.range.valid.2082 = and i1 %descriptor.range.inside.2083, %descriptor.payload.inside.2080
  br i1 %descriptor.range.valid.2082, label %descriptor.valid.2084, label %descriptor.invalid.2085
descriptor.invalid.2085:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2084:
  %descriptor.initialized.status.2086 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2070, i32 %local.check.extent.2071)
  %helper.ok.2087 = icmp eq i32 %descriptor.initialized.status.2086, 0
  br i1 %helper.ok.2087, label %helper.continue.2088, label %frame.failure.0
helper.continue.2088:
  br label %local.descriptor.checked.2069
local.descriptor.inactive.2068:
  br label %local.descriptor.checked.2069
local.descriptor.checked.2069:
  %local.is.active.2089 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2089, label %local.descriptor.active.2090, label %local.descriptor.inactive.2091
local.descriptor.active.2090:
  %local.check.offset.2093 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2094 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2095 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2096 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2098 = load i32, ptr %context.field.2097, align 4
  %stack.sub.2101 = sub i32 %local.check.owner.end.2096, %local.check.offset.2093
  %descriptor.owner.inside.2099 = icmp ule i32 %local.check.owner.end.2096, %context.value.2098
  %descriptor.offset.inside.2100 = icmp ule i32 %local.check.offset.2093, %local.check.owner.end.2096
  %descriptor.extent.inside.2102 = icmp ule i32 %local.check.extent.2094, %stack.sub.2101
  %descriptor.payload.inside.2103 = icmp ule i32 %local.check.payload.2095, %local.check.extent.2094
  %descriptor.owner.offset.valid.2104 = and i1 %descriptor.owner.inside.2099, %descriptor.offset.inside.2100
  %descriptor.range.inside.2106 = and i1 %descriptor.owner.offset.valid.2104, %descriptor.extent.inside.2102
  %descriptor.range.valid.2105 = and i1 %descriptor.range.inside.2106, %descriptor.payload.inside.2103
  br i1 %descriptor.range.valid.2105, label %descriptor.valid.2107, label %descriptor.invalid.2108
descriptor.invalid.2108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2107:
  %descriptor.initialized.status.2109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2093, i32 %local.check.extent.2094)
  %helper.ok.2110 = icmp eq i32 %descriptor.initialized.status.2109, 0
  br i1 %helper.ok.2110, label %helper.continue.2111, label %frame.failure.0
helper.continue.2111:
  br label %local.descriptor.checked.2092
local.descriptor.inactive.2091:
  br label %local.descriptor.checked.2092
local.descriptor.checked.2092:
  %local.is.active.2112 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2112, label %local.descriptor.active.2113, label %local.descriptor.inactive.2114
local.descriptor.active.2113:
  %local.check.offset.2116 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2117 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2118 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2119 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2121 = load i32, ptr %context.field.2120, align 4
  %stack.sub.2124 = sub i32 %local.check.owner.end.2119, %local.check.offset.2116
  %descriptor.owner.inside.2122 = icmp ule i32 %local.check.owner.end.2119, %context.value.2121
  %descriptor.offset.inside.2123 = icmp ule i32 %local.check.offset.2116, %local.check.owner.end.2119
  %descriptor.extent.inside.2125 = icmp ule i32 %local.check.extent.2117, %stack.sub.2124
  %descriptor.payload.inside.2126 = icmp ule i32 %local.check.payload.2118, %local.check.extent.2117
  %descriptor.owner.offset.valid.2127 = and i1 %descriptor.owner.inside.2122, %descriptor.offset.inside.2123
  %descriptor.range.inside.2129 = and i1 %descriptor.owner.offset.valid.2127, %descriptor.extent.inside.2125
  %descriptor.range.valid.2128 = and i1 %descriptor.range.inside.2129, %descriptor.payload.inside.2126
  br i1 %descriptor.range.valid.2128, label %descriptor.valid.2130, label %descriptor.invalid.2131
descriptor.invalid.2131:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2130:
  %descriptor.initialized.status.2132 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2116, i32 %local.check.extent.2117)
  %helper.ok.2133 = icmp eq i32 %descriptor.initialized.status.2132, 0
  br i1 %helper.ok.2133, label %helper.continue.2134, label %frame.failure.0
helper.continue.2134:
  br label %local.descriptor.checked.2115
local.descriptor.inactive.2114:
  br label %local.descriptor.checked.2115
local.descriptor.checked.2115:
  %local.is.active.2135 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2135, label %local.descriptor.active.2136, label %local.descriptor.inactive.2137
local.descriptor.active.2136:
  %local.check.offset.2139 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2140 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2141 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2142 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2144 = load i32, ptr %context.field.2143, align 4
  %stack.sub.2147 = sub i32 %local.check.owner.end.2142, %local.check.offset.2139
  %descriptor.owner.inside.2145 = icmp ule i32 %local.check.owner.end.2142, %context.value.2144
  %descriptor.offset.inside.2146 = icmp ule i32 %local.check.offset.2139, %local.check.owner.end.2142
  %descriptor.extent.inside.2148 = icmp ule i32 %local.check.extent.2140, %stack.sub.2147
  %descriptor.payload.inside.2149 = icmp ule i32 %local.check.payload.2141, %local.check.extent.2140
  %descriptor.owner.offset.valid.2150 = and i1 %descriptor.owner.inside.2145, %descriptor.offset.inside.2146
  %descriptor.range.inside.2152 = and i1 %descriptor.owner.offset.valid.2150, %descriptor.extent.inside.2148
  %descriptor.range.valid.2151 = and i1 %descriptor.range.inside.2152, %descriptor.payload.inside.2149
  br i1 %descriptor.range.valid.2151, label %descriptor.valid.2153, label %descriptor.invalid.2154
descriptor.invalid.2154:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2153:
  %descriptor.initialized.status.2155 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2139, i32 %local.check.extent.2140)
  %helper.ok.2156 = icmp eq i32 %descriptor.initialized.status.2155, 0
  br i1 %helper.ok.2156, label %helper.continue.2157, label %frame.failure.0
helper.continue.2157:
  br label %local.descriptor.checked.2138
local.descriptor.inactive.2137:
  br label %local.descriptor.checked.2138
local.descriptor.checked.2138:
  br label %if.join.1344
if.else.1343:
  %step.status.2158 = call i32 @al_owning_charge_step(ptr %ctx, i32 44)
  %helper.ok.2159 = icmp eq i32 %step.status.2158, 0
  br i1 %helper.ok.2159, label %helper.continue.2160, label %frame.failure.0
helper.continue.2160:
  %context.field.2161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2162 = load i32, ptr %context.field.2161, align 4
  %step.status.2163 = call i32 @al_owning_charge_step(ptr %ctx, i32 45)
  %helper.ok.2164 = icmp eq i32 %step.status.2163, 0
  br i1 %helper.ok.2164, label %helper.continue.2165, label %frame.failure.0
helper.continue.2165:
  %context.field.2166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2167 = load i32, ptr %context.field.2166, align 4
  %stack.offset.2168 = add i32 %context.value.2167, 8
  %reserve.status.2169 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2168, i32 46)
  %reserve.ok.2170 = icmp eq i32 %reserve.status.2169, 0
  br i1 %reserve.ok.2170, label %reserve.continue.2171, label %frame.failure.0
reserve.continue.2171:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.2167, i64 0, i32 1)
  %context.field.2172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2173 = load i32, ptr %context.field.2172, align 4
  %runtime.ok.2174 = icmp eq i32 %context.value.2173, 0
  br i1 %runtime.ok.2174, label %runtime.continue.2175, label %frame.failure.0
runtime.continue.2175:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.2176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2177 = load i32, ptr %context.field.2176, align 4
  %runtime.ok.2178 = icmp eq i32 %context.value.2177, 0
  br i1 %runtime.ok.2178, label %runtime.continue.2179, label %frame.failure.0
runtime.continue.2179:
  %context.field.2180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2181 = load i32, ptr %context.field.2180, align 4
  %stack.sub.2184 = sub i32 %stack.offset.2168, %context.value.2167
  %descriptor.owner.inside.2182 = icmp ule i32 %stack.offset.2168, %context.value.2181
  %descriptor.offset.inside.2183 = icmp ule i32 %context.value.2167, %stack.offset.2168
  %descriptor.extent.inside.2185 = icmp ule i32 8, %stack.sub.2184
  %descriptor.payload.inside.2186 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2187 = and i1 %descriptor.owner.inside.2182, %descriptor.offset.inside.2183
  %descriptor.range.inside.2189 = and i1 %descriptor.owner.offset.valid.2187, %descriptor.extent.inside.2185
  %descriptor.range.valid.2188 = and i1 %descriptor.range.inside.2189, %descriptor.payload.inside.2186
  %descriptor.type.valid.2190 = icmp eq i32 1, 1
  %descriptor.valid.2191 = and i1 %descriptor.range.valid.2188, %descriptor.type.valid.2190
  br i1 %descriptor.valid.2191, label %descriptor.valid.2192, label %descriptor.invalid.2193
descriptor.invalid.2193:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2192:
  %descriptor.initialized.status.2194 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2167, i32 8)
  %helper.ok.2195 = icmp eq i32 %descriptor.initialized.status.2194, 0
  br i1 %helper.ok.2195, label %helper.continue.2196, label %frame.failure.0
helper.continue.2196:
  %local.is.active.2197 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2197, label %local.descriptor.active.2198, label %local.descriptor.inactive.2199
local.descriptor.active.2198:
  %local.check.offset.2201 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2202 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2203 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2204 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2206 = load i32, ptr %context.field.2205, align 4
  %stack.sub.2209 = sub i32 %local.check.owner.end.2204, %local.check.offset.2201
  %descriptor.owner.inside.2207 = icmp ule i32 %local.check.owner.end.2204, %context.value.2206
  %descriptor.offset.inside.2208 = icmp ule i32 %local.check.offset.2201, %local.check.owner.end.2204
  %descriptor.extent.inside.2210 = icmp ule i32 %local.check.extent.2202, %stack.sub.2209
  %descriptor.payload.inside.2211 = icmp ule i32 %local.check.payload.2203, %local.check.extent.2202
  %descriptor.owner.offset.valid.2212 = and i1 %descriptor.owner.inside.2207, %descriptor.offset.inside.2208
  %descriptor.range.inside.2214 = and i1 %descriptor.owner.offset.valid.2212, %descriptor.extent.inside.2210
  %descriptor.range.valid.2213 = and i1 %descriptor.range.inside.2214, %descriptor.payload.inside.2211
  br i1 %descriptor.range.valid.2213, label %descriptor.valid.2215, label %descriptor.invalid.2216
descriptor.invalid.2216:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2215:
  %descriptor.initialized.status.2217 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2201, i32 %local.check.extent.2202)
  %helper.ok.2218 = icmp eq i32 %descriptor.initialized.status.2217, 0
  br i1 %helper.ok.2218, label %helper.continue.2219, label %frame.failure.0
helper.continue.2219:
  br label %local.descriptor.checked.2200
local.descriptor.inactive.2199:
  br label %local.descriptor.checked.2200
local.descriptor.checked.2200:
  %local.is.active.2220 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2220, label %local.descriptor.active.2221, label %local.descriptor.inactive.2222
local.descriptor.active.2221:
  %local.check.offset.2224 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2225 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2226 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2227 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2229 = load i32, ptr %context.field.2228, align 4
  %stack.sub.2232 = sub i32 %local.check.owner.end.2227, %local.check.offset.2224
  %descriptor.owner.inside.2230 = icmp ule i32 %local.check.owner.end.2227, %context.value.2229
  %descriptor.offset.inside.2231 = icmp ule i32 %local.check.offset.2224, %local.check.owner.end.2227
  %descriptor.extent.inside.2233 = icmp ule i32 %local.check.extent.2225, %stack.sub.2232
  %descriptor.payload.inside.2234 = icmp ule i32 %local.check.payload.2226, %local.check.extent.2225
  %descriptor.owner.offset.valid.2235 = and i1 %descriptor.owner.inside.2230, %descriptor.offset.inside.2231
  %descriptor.range.inside.2237 = and i1 %descriptor.owner.offset.valid.2235, %descriptor.extent.inside.2233
  %descriptor.range.valid.2236 = and i1 %descriptor.range.inside.2237, %descriptor.payload.inside.2234
  br i1 %descriptor.range.valid.2236, label %descriptor.valid.2238, label %descriptor.invalid.2239
descriptor.invalid.2239:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2238:
  %descriptor.initialized.status.2240 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2224, i32 %local.check.extent.2225)
  %helper.ok.2241 = icmp eq i32 %descriptor.initialized.status.2240, 0
  br i1 %helper.ok.2241, label %helper.continue.2242, label %frame.failure.0
helper.continue.2242:
  br label %local.descriptor.checked.2223
local.descriptor.inactive.2222:
  br label %local.descriptor.checked.2223
local.descriptor.checked.2223:
  %local.is.active.2243 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2243, label %local.descriptor.active.2244, label %local.descriptor.inactive.2245
local.descriptor.active.2244:
  %local.check.offset.2247 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2248 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2249 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2250 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2252 = load i32, ptr %context.field.2251, align 4
  %stack.sub.2255 = sub i32 %local.check.owner.end.2250, %local.check.offset.2247
  %descriptor.owner.inside.2253 = icmp ule i32 %local.check.owner.end.2250, %context.value.2252
  %descriptor.offset.inside.2254 = icmp ule i32 %local.check.offset.2247, %local.check.owner.end.2250
  %descriptor.extent.inside.2256 = icmp ule i32 %local.check.extent.2248, %stack.sub.2255
  %descriptor.payload.inside.2257 = icmp ule i32 %local.check.payload.2249, %local.check.extent.2248
  %descriptor.owner.offset.valid.2258 = and i1 %descriptor.owner.inside.2253, %descriptor.offset.inside.2254
  %descriptor.range.inside.2260 = and i1 %descriptor.owner.offset.valid.2258, %descriptor.extent.inside.2256
  %descriptor.range.valid.2259 = and i1 %descriptor.range.inside.2260, %descriptor.payload.inside.2257
  br i1 %descriptor.range.valid.2259, label %descriptor.valid.2261, label %descriptor.invalid.2262
descriptor.invalid.2262:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2261:
  %descriptor.initialized.status.2263 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2247, i32 %local.check.extent.2248)
  %helper.ok.2264 = icmp eq i32 %descriptor.initialized.status.2263, 0
  br i1 %helper.ok.2264, label %helper.continue.2265, label %frame.failure.0
helper.continue.2265:
  br label %local.descriptor.checked.2246
local.descriptor.inactive.2245:
  br label %local.descriptor.checked.2246
local.descriptor.checked.2246:
  %local.is.active.2266 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2266, label %local.descriptor.active.2267, label %local.descriptor.inactive.2268
local.descriptor.active.2267:
  %local.check.offset.2270 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2271 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2272 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2273 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2275 = load i32, ptr %context.field.2274, align 4
  %stack.sub.2278 = sub i32 %local.check.owner.end.2273, %local.check.offset.2270
  %descriptor.owner.inside.2276 = icmp ule i32 %local.check.owner.end.2273, %context.value.2275
  %descriptor.offset.inside.2277 = icmp ule i32 %local.check.offset.2270, %local.check.owner.end.2273
  %descriptor.extent.inside.2279 = icmp ule i32 %local.check.extent.2271, %stack.sub.2278
  %descriptor.payload.inside.2280 = icmp ule i32 %local.check.payload.2272, %local.check.extent.2271
  %descriptor.owner.offset.valid.2281 = and i1 %descriptor.owner.inside.2276, %descriptor.offset.inside.2277
  %descriptor.range.inside.2283 = and i1 %descriptor.owner.offset.valid.2281, %descriptor.extent.inside.2279
  %descriptor.range.valid.2282 = and i1 %descriptor.range.inside.2283, %descriptor.payload.inside.2280
  br i1 %descriptor.range.valid.2282, label %descriptor.valid.2284, label %descriptor.invalid.2285
descriptor.invalid.2285:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2284:
  %descriptor.initialized.status.2286 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2270, i32 %local.check.extent.2271)
  %helper.ok.2287 = icmp eq i32 %descriptor.initialized.status.2286, 0
  br i1 %helper.ok.2287, label %helper.continue.2288, label %frame.failure.0
helper.continue.2288:
  br label %local.descriptor.checked.2269
local.descriptor.inactive.2268:
  br label %local.descriptor.checked.2269
local.descriptor.checked.2269:
  %local.is.active.2289 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2289, label %local.descriptor.active.2290, label %local.descriptor.inactive.2291
local.descriptor.active.2290:
  %local.check.offset.2293 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2294 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2295 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2296 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2298 = load i32, ptr %context.field.2297, align 4
  %stack.sub.2301 = sub i32 %local.check.owner.end.2296, %local.check.offset.2293
  %descriptor.owner.inside.2299 = icmp ule i32 %local.check.owner.end.2296, %context.value.2298
  %descriptor.offset.inside.2300 = icmp ule i32 %local.check.offset.2293, %local.check.owner.end.2296
  %descriptor.extent.inside.2302 = icmp ule i32 %local.check.extent.2294, %stack.sub.2301
  %descriptor.payload.inside.2303 = icmp ule i32 %local.check.payload.2295, %local.check.extent.2294
  %descriptor.owner.offset.valid.2304 = and i1 %descriptor.owner.inside.2299, %descriptor.offset.inside.2300
  %descriptor.range.inside.2306 = and i1 %descriptor.owner.offset.valid.2304, %descriptor.extent.inside.2302
  %descriptor.range.valid.2305 = and i1 %descriptor.range.inside.2306, %descriptor.payload.inside.2303
  br i1 %descriptor.range.valid.2305, label %descriptor.valid.2307, label %descriptor.invalid.2308
descriptor.invalid.2308:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2307:
  %descriptor.initialized.status.2309 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2293, i32 %local.check.extent.2294)
  %helper.ok.2310 = icmp eq i32 %descriptor.initialized.status.2309, 0
  br i1 %helper.ok.2310, label %helper.continue.2311, label %frame.failure.0
helper.continue.2311:
  br label %local.descriptor.checked.2292
local.descriptor.inactive.2291:
  br label %local.descriptor.checked.2292
local.descriptor.checked.2292:
  %local.is.active.2312 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2312, label %local.descriptor.active.2313, label %local.descriptor.inactive.2314
local.descriptor.active.2313:
  %local.check.offset.2316 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2317 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2318 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2319 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2320 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2321 = load i32, ptr %context.field.2320, align 4
  %stack.sub.2324 = sub i32 %local.check.owner.end.2319, %local.check.offset.2316
  %descriptor.owner.inside.2322 = icmp ule i32 %local.check.owner.end.2319, %context.value.2321
  %descriptor.offset.inside.2323 = icmp ule i32 %local.check.offset.2316, %local.check.owner.end.2319
  %descriptor.extent.inside.2325 = icmp ule i32 %local.check.extent.2317, %stack.sub.2324
  %descriptor.payload.inside.2326 = icmp ule i32 %local.check.payload.2318, %local.check.extent.2317
  %descriptor.owner.offset.valid.2327 = and i1 %descriptor.owner.inside.2322, %descriptor.offset.inside.2323
  %descriptor.range.inside.2329 = and i1 %descriptor.owner.offset.valid.2327, %descriptor.extent.inside.2325
  %descriptor.range.valid.2328 = and i1 %descriptor.range.inside.2329, %descriptor.payload.inside.2326
  br i1 %descriptor.range.valid.2328, label %descriptor.valid.2330, label %descriptor.invalid.2331
descriptor.invalid.2331:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2330:
  %descriptor.initialized.status.2332 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2316, i32 %local.check.extent.2317)
  %helper.ok.2333 = icmp eq i32 %descriptor.initialized.status.2332, 0
  br i1 %helper.ok.2333, label %helper.continue.2334, label %frame.failure.0
helper.continue.2334:
  br label %local.descriptor.checked.2315
local.descriptor.inactive.2314:
  br label %local.descriptor.checked.2315
local.descriptor.checked.2315:
  %local.is.active.2335 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2335, label %local.descriptor.active.2336, label %local.descriptor.inactive.2337
local.descriptor.active.2336:
  %local.check.offset.2339 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2340 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2341 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2342 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2344 = load i32, ptr %context.field.2343, align 4
  %stack.sub.2347 = sub i32 %local.check.owner.end.2342, %local.check.offset.2339
  %descriptor.owner.inside.2345 = icmp ule i32 %local.check.owner.end.2342, %context.value.2344
  %descriptor.offset.inside.2346 = icmp ule i32 %local.check.offset.2339, %local.check.owner.end.2342
  %descriptor.extent.inside.2348 = icmp ule i32 %local.check.extent.2340, %stack.sub.2347
  %descriptor.payload.inside.2349 = icmp ule i32 %local.check.payload.2341, %local.check.extent.2340
  %descriptor.owner.offset.valid.2350 = and i1 %descriptor.owner.inside.2345, %descriptor.offset.inside.2346
  %descriptor.range.inside.2352 = and i1 %descriptor.owner.offset.valid.2350, %descriptor.extent.inside.2348
  %descriptor.range.valid.2351 = and i1 %descriptor.range.inside.2352, %descriptor.payload.inside.2349
  br i1 %descriptor.range.valid.2351, label %descriptor.valid.2353, label %descriptor.invalid.2354
descriptor.invalid.2354:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2353:
  %descriptor.initialized.status.2355 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2339, i32 %local.check.extent.2340)
  %helper.ok.2356 = icmp eq i32 %descriptor.initialized.status.2355, 0
  br i1 %helper.ok.2356, label %helper.continue.2357, label %frame.failure.0
helper.continue.2357:
  br label %local.descriptor.checked.2338
local.descriptor.inactive.2337:
  br label %local.descriptor.checked.2338
local.descriptor.checked.2338:
  %context.field.2358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2359 = load i32, ptr %context.field.2358, align 4
  %stack.sub.2362 = sub i32 %stack.offset.2168, %context.value.2167
  %descriptor.owner.inside.2360 = icmp ule i32 %stack.offset.2168, %context.value.2359
  %descriptor.offset.inside.2361 = icmp ule i32 %context.value.2167, %stack.offset.2168
  %descriptor.extent.inside.2363 = icmp ule i32 8, %stack.sub.2362
  %descriptor.payload.inside.2364 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2365 = and i1 %descriptor.owner.inside.2360, %descriptor.offset.inside.2361
  %descriptor.range.inside.2367 = and i1 %descriptor.owner.offset.valid.2365, %descriptor.extent.inside.2363
  %descriptor.range.valid.2366 = and i1 %descriptor.range.inside.2367, %descriptor.payload.inside.2364
  %descriptor.type.valid.2368 = icmp eq i32 1, 1
  %descriptor.valid.2369 = and i1 %descriptor.range.valid.2366, %descriptor.type.valid.2368
  br i1 %descriptor.valid.2369, label %descriptor.valid.2370, label %descriptor.invalid.2371
descriptor.invalid.2371:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2370:
  %descriptor.initialized.status.2372 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2167, i32 8)
  %helper.ok.2373 = icmp eq i32 %descriptor.initialized.status.2372, 0
  br i1 %helper.ok.2373, label %helper.continue.2374, label %frame.failure.0
helper.continue.2374:
  %local.is.active.2375 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2375, label %local.descriptor.active.2376, label %local.descriptor.inactive.2377
local.descriptor.active.2376:
  %local.check.offset.2379 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2380 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2381 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2382 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2384 = load i32, ptr %context.field.2383, align 4
  %stack.sub.2387 = sub i32 %local.check.owner.end.2382, %local.check.offset.2379
  %descriptor.owner.inside.2385 = icmp ule i32 %local.check.owner.end.2382, %context.value.2384
  %descriptor.offset.inside.2386 = icmp ule i32 %local.check.offset.2379, %local.check.owner.end.2382
  %descriptor.extent.inside.2388 = icmp ule i32 %local.check.extent.2380, %stack.sub.2387
  %descriptor.payload.inside.2389 = icmp ule i32 %local.check.payload.2381, %local.check.extent.2380
  %descriptor.owner.offset.valid.2390 = and i1 %descriptor.owner.inside.2385, %descriptor.offset.inside.2386
  %descriptor.range.inside.2392 = and i1 %descriptor.owner.offset.valid.2390, %descriptor.extent.inside.2388
  %descriptor.range.valid.2391 = and i1 %descriptor.range.inside.2392, %descriptor.payload.inside.2389
  br i1 %descriptor.range.valid.2391, label %descriptor.valid.2393, label %descriptor.invalid.2394
descriptor.invalid.2394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2393:
  %descriptor.initialized.status.2395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2379, i32 %local.check.extent.2380)
  %helper.ok.2396 = icmp eq i32 %descriptor.initialized.status.2395, 0
  br i1 %helper.ok.2396, label %helper.continue.2397, label %frame.failure.0
helper.continue.2397:
  br label %local.descriptor.checked.2378
local.descriptor.inactive.2377:
  br label %local.descriptor.checked.2378
local.descriptor.checked.2378:
  %local.is.active.2398 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2398, label %local.descriptor.active.2399, label %local.descriptor.inactive.2400
local.descriptor.active.2399:
  %local.check.offset.2402 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2403 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2404 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2405 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2406 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2407 = load i32, ptr %context.field.2406, align 4
  %stack.sub.2410 = sub i32 %local.check.owner.end.2405, %local.check.offset.2402
  %descriptor.owner.inside.2408 = icmp ule i32 %local.check.owner.end.2405, %context.value.2407
  %descriptor.offset.inside.2409 = icmp ule i32 %local.check.offset.2402, %local.check.owner.end.2405
  %descriptor.extent.inside.2411 = icmp ule i32 %local.check.extent.2403, %stack.sub.2410
  %descriptor.payload.inside.2412 = icmp ule i32 %local.check.payload.2404, %local.check.extent.2403
  %descriptor.owner.offset.valid.2413 = and i1 %descriptor.owner.inside.2408, %descriptor.offset.inside.2409
  %descriptor.range.inside.2415 = and i1 %descriptor.owner.offset.valid.2413, %descriptor.extent.inside.2411
  %descriptor.range.valid.2414 = and i1 %descriptor.range.inside.2415, %descriptor.payload.inside.2412
  br i1 %descriptor.range.valid.2414, label %descriptor.valid.2416, label %descriptor.invalid.2417
descriptor.invalid.2417:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2416:
  %descriptor.initialized.status.2418 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2402, i32 %local.check.extent.2403)
  %helper.ok.2419 = icmp eq i32 %descriptor.initialized.status.2418, 0
  br i1 %helper.ok.2419, label %helper.continue.2420, label %frame.failure.0
helper.continue.2420:
  br label %local.descriptor.checked.2401
local.descriptor.inactive.2400:
  br label %local.descriptor.checked.2401
local.descriptor.checked.2401:
  %local.is.active.2421 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2421, label %local.descriptor.active.2422, label %local.descriptor.inactive.2423
local.descriptor.active.2422:
  %local.check.offset.2425 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2426 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2427 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2428 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2430 = load i32, ptr %context.field.2429, align 4
  %stack.sub.2433 = sub i32 %local.check.owner.end.2428, %local.check.offset.2425
  %descriptor.owner.inside.2431 = icmp ule i32 %local.check.owner.end.2428, %context.value.2430
  %descriptor.offset.inside.2432 = icmp ule i32 %local.check.offset.2425, %local.check.owner.end.2428
  %descriptor.extent.inside.2434 = icmp ule i32 %local.check.extent.2426, %stack.sub.2433
  %descriptor.payload.inside.2435 = icmp ule i32 %local.check.payload.2427, %local.check.extent.2426
  %descriptor.owner.offset.valid.2436 = and i1 %descriptor.owner.inside.2431, %descriptor.offset.inside.2432
  %descriptor.range.inside.2438 = and i1 %descriptor.owner.offset.valid.2436, %descriptor.extent.inside.2434
  %descriptor.range.valid.2437 = and i1 %descriptor.range.inside.2438, %descriptor.payload.inside.2435
  br i1 %descriptor.range.valid.2437, label %descriptor.valid.2439, label %descriptor.invalid.2440
descriptor.invalid.2440:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2439:
  %descriptor.initialized.status.2441 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2425, i32 %local.check.extent.2426)
  %helper.ok.2442 = icmp eq i32 %descriptor.initialized.status.2441, 0
  br i1 %helper.ok.2442, label %helper.continue.2443, label %frame.failure.0
helper.continue.2443:
  br label %local.descriptor.checked.2424
local.descriptor.inactive.2423:
  br label %local.descriptor.checked.2424
local.descriptor.checked.2424:
  %local.is.active.2444 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2444, label %local.descriptor.active.2445, label %local.descriptor.inactive.2446
local.descriptor.active.2445:
  %local.check.offset.2448 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2449 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2450 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2451 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2452 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2453 = load i32, ptr %context.field.2452, align 4
  %stack.sub.2456 = sub i32 %local.check.owner.end.2451, %local.check.offset.2448
  %descriptor.owner.inside.2454 = icmp ule i32 %local.check.owner.end.2451, %context.value.2453
  %descriptor.offset.inside.2455 = icmp ule i32 %local.check.offset.2448, %local.check.owner.end.2451
  %descriptor.extent.inside.2457 = icmp ule i32 %local.check.extent.2449, %stack.sub.2456
  %descriptor.payload.inside.2458 = icmp ule i32 %local.check.payload.2450, %local.check.extent.2449
  %descriptor.owner.offset.valid.2459 = and i1 %descriptor.owner.inside.2454, %descriptor.offset.inside.2455
  %descriptor.range.inside.2461 = and i1 %descriptor.owner.offset.valid.2459, %descriptor.extent.inside.2457
  %descriptor.range.valid.2460 = and i1 %descriptor.range.inside.2461, %descriptor.payload.inside.2458
  br i1 %descriptor.range.valid.2460, label %descriptor.valid.2462, label %descriptor.invalid.2463
descriptor.invalid.2463:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2462:
  %descriptor.initialized.status.2464 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2448, i32 %local.check.extent.2449)
  %helper.ok.2465 = icmp eq i32 %descriptor.initialized.status.2464, 0
  br i1 %helper.ok.2465, label %helper.continue.2466, label %frame.failure.0
helper.continue.2466:
  br label %local.descriptor.checked.2447
local.descriptor.inactive.2446:
  br label %local.descriptor.checked.2447
local.descriptor.checked.2447:
  %local.is.active.2467 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2467, label %local.descriptor.active.2468, label %local.descriptor.inactive.2469
local.descriptor.active.2468:
  %local.check.offset.2471 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2472 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2473 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2474 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2475 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2476 = load i32, ptr %context.field.2475, align 4
  %stack.sub.2479 = sub i32 %local.check.owner.end.2474, %local.check.offset.2471
  %descriptor.owner.inside.2477 = icmp ule i32 %local.check.owner.end.2474, %context.value.2476
  %descriptor.offset.inside.2478 = icmp ule i32 %local.check.offset.2471, %local.check.owner.end.2474
  %descriptor.extent.inside.2480 = icmp ule i32 %local.check.extent.2472, %stack.sub.2479
  %descriptor.payload.inside.2481 = icmp ule i32 %local.check.payload.2473, %local.check.extent.2472
  %descriptor.owner.offset.valid.2482 = and i1 %descriptor.owner.inside.2477, %descriptor.offset.inside.2478
  %descriptor.range.inside.2484 = and i1 %descriptor.owner.offset.valid.2482, %descriptor.extent.inside.2480
  %descriptor.range.valid.2483 = and i1 %descriptor.range.inside.2484, %descriptor.payload.inside.2481
  br i1 %descriptor.range.valid.2483, label %descriptor.valid.2485, label %descriptor.invalid.2486
descriptor.invalid.2486:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2485:
  %descriptor.initialized.status.2487 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2471, i32 %local.check.extent.2472)
  %helper.ok.2488 = icmp eq i32 %descriptor.initialized.status.2487, 0
  br i1 %helper.ok.2488, label %helper.continue.2489, label %frame.failure.0
helper.continue.2489:
  br label %local.descriptor.checked.2470
local.descriptor.inactive.2469:
  br label %local.descriptor.checked.2470
local.descriptor.checked.2470:
  %local.is.active.2490 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2490, label %local.descriptor.active.2491, label %local.descriptor.inactive.2492
local.descriptor.active.2491:
  %local.check.offset.2494 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2495 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2496 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2497 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2499 = load i32, ptr %context.field.2498, align 4
  %stack.sub.2502 = sub i32 %local.check.owner.end.2497, %local.check.offset.2494
  %descriptor.owner.inside.2500 = icmp ule i32 %local.check.owner.end.2497, %context.value.2499
  %descriptor.offset.inside.2501 = icmp ule i32 %local.check.offset.2494, %local.check.owner.end.2497
  %descriptor.extent.inside.2503 = icmp ule i32 %local.check.extent.2495, %stack.sub.2502
  %descriptor.payload.inside.2504 = icmp ule i32 %local.check.payload.2496, %local.check.extent.2495
  %descriptor.owner.offset.valid.2505 = and i1 %descriptor.owner.inside.2500, %descriptor.offset.inside.2501
  %descriptor.range.inside.2507 = and i1 %descriptor.owner.offset.valid.2505, %descriptor.extent.inside.2503
  %descriptor.range.valid.2506 = and i1 %descriptor.range.inside.2507, %descriptor.payload.inside.2504
  br i1 %descriptor.range.valid.2506, label %descriptor.valid.2508, label %descriptor.invalid.2509
descriptor.invalid.2509:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2508:
  %descriptor.initialized.status.2510 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2494, i32 %local.check.extent.2495)
  %helper.ok.2511 = icmp eq i32 %descriptor.initialized.status.2510, 0
  br i1 %helper.ok.2511, label %helper.continue.2512, label %frame.failure.0
helper.continue.2512:
  br label %local.descriptor.checked.2493
local.descriptor.inactive.2492:
  br label %local.descriptor.checked.2493
local.descriptor.checked.2493:
  %local.is.active.2513 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2513, label %local.descriptor.active.2514, label %local.descriptor.inactive.2515
local.descriptor.active.2514:
  %local.check.offset.2517 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2518 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2519 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2520 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2521 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2522 = load i32, ptr %context.field.2521, align 4
  %stack.sub.2525 = sub i32 %local.check.owner.end.2520, %local.check.offset.2517
  %descriptor.owner.inside.2523 = icmp ule i32 %local.check.owner.end.2520, %context.value.2522
  %descriptor.offset.inside.2524 = icmp ule i32 %local.check.offset.2517, %local.check.owner.end.2520
  %descriptor.extent.inside.2526 = icmp ule i32 %local.check.extent.2518, %stack.sub.2525
  %descriptor.payload.inside.2527 = icmp ule i32 %local.check.payload.2519, %local.check.extent.2518
  %descriptor.owner.offset.valid.2528 = and i1 %descriptor.owner.inside.2523, %descriptor.offset.inside.2524
  %descriptor.range.inside.2530 = and i1 %descriptor.owner.offset.valid.2528, %descriptor.extent.inside.2526
  %descriptor.range.valid.2529 = and i1 %descriptor.range.inside.2530, %descriptor.payload.inside.2527
  br i1 %descriptor.range.valid.2529, label %descriptor.valid.2531, label %descriptor.invalid.2532
descriptor.invalid.2532:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2531:
  %descriptor.initialized.status.2533 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2517, i32 %local.check.extent.2518)
  %helper.ok.2534 = icmp eq i32 %descriptor.initialized.status.2533, 0
  br i1 %helper.ok.2534, label %helper.continue.2535, label %frame.failure.0
helper.continue.2535:
  br label %local.descriptor.checked.2516
local.descriptor.inactive.2515:
  br label %local.descriptor.checked.2516
local.descriptor.checked.2516:
  br label %if.join.1344
if.join.1344:
  %if.value.offset.2536 = phi i32 [ %context.value.1788, %local.descriptor.checked.2138 ], [ %context.value.2167, %local.descriptor.checked.2516 ]
  %if.value.extent.2537 = phi i32 [ 8, %local.descriptor.checked.2138 ], [ 8, %local.descriptor.checked.2516 ]
  %if.value.payload.2538 = phi i32 [ 8, %local.descriptor.checked.2138 ], [ 8, %local.descriptor.checked.2516 ]
  %if.value.owner.end.2539 = phi i32 [ %stack.offset.1801, %local.descriptor.checked.2138 ], [ %stack.offset.2168, %local.descriptor.checked.2516 ]
  %context.field.2540 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2541 = load i32, ptr %context.field.2540, align 4
  %stack.sub.2544 = sub i32 %if.value.owner.end.2539, %if.value.offset.2536
  %descriptor.owner.inside.2542 = icmp ule i32 %if.value.owner.end.2539, %context.value.2541
  %descriptor.offset.inside.2543 = icmp ule i32 %if.value.offset.2536, %if.value.owner.end.2539
  %descriptor.extent.inside.2545 = icmp ule i32 %if.value.extent.2537, %stack.sub.2544
  %descriptor.payload.inside.2546 = icmp ule i32 %if.value.payload.2538, %if.value.extent.2537
  %descriptor.owner.offset.valid.2547 = and i1 %descriptor.owner.inside.2542, %descriptor.offset.inside.2543
  %descriptor.range.inside.2549 = and i1 %descriptor.owner.offset.valid.2547, %descriptor.extent.inside.2545
  %descriptor.range.valid.2548 = and i1 %descriptor.range.inside.2549, %descriptor.payload.inside.2546
  %descriptor.type.valid.2550 = icmp eq i32 1, 1
  %descriptor.valid.2551 = and i1 %descriptor.range.valid.2548, %descriptor.type.valid.2550
  br i1 %descriptor.valid.2551, label %descriptor.valid.2552, label %descriptor.invalid.2553
descriptor.invalid.2553:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2552:
  %descriptor.initialized.status.2554 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %if.value.offset.2536, i32 %if.value.extent.2537)
  %helper.ok.2555 = icmp eq i32 %descriptor.initialized.status.2554, 0
  br i1 %helper.ok.2555, label %helper.continue.2556, label %frame.failure.0
helper.continue.2556:
  %local.is.active.2557 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2557, label %local.descriptor.active.2558, label %local.descriptor.inactive.2559
local.descriptor.active.2558:
  %local.check.offset.2561 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2562 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2563 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2564 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2565 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2566 = load i32, ptr %context.field.2565, align 4
  %stack.sub.2569 = sub i32 %local.check.owner.end.2564, %local.check.offset.2561
  %descriptor.owner.inside.2567 = icmp ule i32 %local.check.owner.end.2564, %context.value.2566
  %descriptor.offset.inside.2568 = icmp ule i32 %local.check.offset.2561, %local.check.owner.end.2564
  %descriptor.extent.inside.2570 = icmp ule i32 %local.check.extent.2562, %stack.sub.2569
  %descriptor.payload.inside.2571 = icmp ule i32 %local.check.payload.2563, %local.check.extent.2562
  %descriptor.owner.offset.valid.2572 = and i1 %descriptor.owner.inside.2567, %descriptor.offset.inside.2568
  %descriptor.range.inside.2574 = and i1 %descriptor.owner.offset.valid.2572, %descriptor.extent.inside.2570
  %descriptor.range.valid.2573 = and i1 %descriptor.range.inside.2574, %descriptor.payload.inside.2571
  br i1 %descriptor.range.valid.2573, label %descriptor.valid.2575, label %descriptor.invalid.2576
descriptor.invalid.2576:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2575:
  %descriptor.initialized.status.2577 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2561, i32 %local.check.extent.2562)
  %helper.ok.2578 = icmp eq i32 %descriptor.initialized.status.2577, 0
  br i1 %helper.ok.2578, label %helper.continue.2579, label %frame.failure.0
helper.continue.2579:
  br label %local.descriptor.checked.2560
local.descriptor.inactive.2559:
  br label %local.descriptor.checked.2560
local.descriptor.checked.2560:
  %local.is.active.2580 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2580, label %local.descriptor.active.2581, label %local.descriptor.inactive.2582
local.descriptor.active.2581:
  %local.check.offset.2584 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2585 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2586 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2587 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2588 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2589 = load i32, ptr %context.field.2588, align 4
  %stack.sub.2592 = sub i32 %local.check.owner.end.2587, %local.check.offset.2584
  %descriptor.owner.inside.2590 = icmp ule i32 %local.check.owner.end.2587, %context.value.2589
  %descriptor.offset.inside.2591 = icmp ule i32 %local.check.offset.2584, %local.check.owner.end.2587
  %descriptor.extent.inside.2593 = icmp ule i32 %local.check.extent.2585, %stack.sub.2592
  %descriptor.payload.inside.2594 = icmp ule i32 %local.check.payload.2586, %local.check.extent.2585
  %descriptor.owner.offset.valid.2595 = and i1 %descriptor.owner.inside.2590, %descriptor.offset.inside.2591
  %descriptor.range.inside.2597 = and i1 %descriptor.owner.offset.valid.2595, %descriptor.extent.inside.2593
  %descriptor.range.valid.2596 = and i1 %descriptor.range.inside.2597, %descriptor.payload.inside.2594
  br i1 %descriptor.range.valid.2596, label %descriptor.valid.2598, label %descriptor.invalid.2599
descriptor.invalid.2599:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2598:
  %descriptor.initialized.status.2600 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2584, i32 %local.check.extent.2585)
  %helper.ok.2601 = icmp eq i32 %descriptor.initialized.status.2600, 0
  br i1 %helper.ok.2601, label %helper.continue.2602, label %frame.failure.0
helper.continue.2602:
  br label %local.descriptor.checked.2583
local.descriptor.inactive.2582:
  br label %local.descriptor.checked.2583
local.descriptor.checked.2583:
  %local.is.active.2603 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2603, label %local.descriptor.active.2604, label %local.descriptor.inactive.2605
local.descriptor.active.2604:
  %local.check.offset.2607 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2608 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2609 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2610 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2612 = load i32, ptr %context.field.2611, align 4
  %stack.sub.2615 = sub i32 %local.check.owner.end.2610, %local.check.offset.2607
  %descriptor.owner.inside.2613 = icmp ule i32 %local.check.owner.end.2610, %context.value.2612
  %descriptor.offset.inside.2614 = icmp ule i32 %local.check.offset.2607, %local.check.owner.end.2610
  %descriptor.extent.inside.2616 = icmp ule i32 %local.check.extent.2608, %stack.sub.2615
  %descriptor.payload.inside.2617 = icmp ule i32 %local.check.payload.2609, %local.check.extent.2608
  %descriptor.owner.offset.valid.2618 = and i1 %descriptor.owner.inside.2613, %descriptor.offset.inside.2614
  %descriptor.range.inside.2620 = and i1 %descriptor.owner.offset.valid.2618, %descriptor.extent.inside.2616
  %descriptor.range.valid.2619 = and i1 %descriptor.range.inside.2620, %descriptor.payload.inside.2617
  br i1 %descriptor.range.valid.2619, label %descriptor.valid.2621, label %descriptor.invalid.2622
descriptor.invalid.2622:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2621:
  %descriptor.initialized.status.2623 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2607, i32 %local.check.extent.2608)
  %helper.ok.2624 = icmp eq i32 %descriptor.initialized.status.2623, 0
  br i1 %helper.ok.2624, label %helper.continue.2625, label %frame.failure.0
helper.continue.2625:
  br label %local.descriptor.checked.2606
local.descriptor.inactive.2605:
  br label %local.descriptor.checked.2606
local.descriptor.checked.2606:
  %local.is.active.2626 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2626, label %local.descriptor.active.2627, label %local.descriptor.inactive.2628
local.descriptor.active.2627:
  %local.check.offset.2630 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2631 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2632 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2633 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2635 = load i32, ptr %context.field.2634, align 4
  %stack.sub.2638 = sub i32 %local.check.owner.end.2633, %local.check.offset.2630
  %descriptor.owner.inside.2636 = icmp ule i32 %local.check.owner.end.2633, %context.value.2635
  %descriptor.offset.inside.2637 = icmp ule i32 %local.check.offset.2630, %local.check.owner.end.2633
  %descriptor.extent.inside.2639 = icmp ule i32 %local.check.extent.2631, %stack.sub.2638
  %descriptor.payload.inside.2640 = icmp ule i32 %local.check.payload.2632, %local.check.extent.2631
  %descriptor.owner.offset.valid.2641 = and i1 %descriptor.owner.inside.2636, %descriptor.offset.inside.2637
  %descriptor.range.inside.2643 = and i1 %descriptor.owner.offset.valid.2641, %descriptor.extent.inside.2639
  %descriptor.range.valid.2642 = and i1 %descriptor.range.inside.2643, %descriptor.payload.inside.2640
  br i1 %descriptor.range.valid.2642, label %descriptor.valid.2644, label %descriptor.invalid.2645
descriptor.invalid.2645:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2644:
  %descriptor.initialized.status.2646 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2630, i32 %local.check.extent.2631)
  %helper.ok.2647 = icmp eq i32 %descriptor.initialized.status.2646, 0
  br i1 %helper.ok.2647, label %helper.continue.2648, label %frame.failure.0
helper.continue.2648:
  br label %local.descriptor.checked.2629
local.descriptor.inactive.2628:
  br label %local.descriptor.checked.2629
local.descriptor.checked.2629:
  %local.is.active.2649 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2649, label %local.descriptor.active.2650, label %local.descriptor.inactive.2651
local.descriptor.active.2650:
  %local.check.offset.2653 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2654 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2655 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2656 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2657 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2658 = load i32, ptr %context.field.2657, align 4
  %stack.sub.2661 = sub i32 %local.check.owner.end.2656, %local.check.offset.2653
  %descriptor.owner.inside.2659 = icmp ule i32 %local.check.owner.end.2656, %context.value.2658
  %descriptor.offset.inside.2660 = icmp ule i32 %local.check.offset.2653, %local.check.owner.end.2656
  %descriptor.extent.inside.2662 = icmp ule i32 %local.check.extent.2654, %stack.sub.2661
  %descriptor.payload.inside.2663 = icmp ule i32 %local.check.payload.2655, %local.check.extent.2654
  %descriptor.owner.offset.valid.2664 = and i1 %descriptor.owner.inside.2659, %descriptor.offset.inside.2660
  %descriptor.range.inside.2666 = and i1 %descriptor.owner.offset.valid.2664, %descriptor.extent.inside.2662
  %descriptor.range.valid.2665 = and i1 %descriptor.range.inside.2666, %descriptor.payload.inside.2663
  br i1 %descriptor.range.valid.2665, label %descriptor.valid.2667, label %descriptor.invalid.2668
descriptor.invalid.2668:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2667:
  %descriptor.initialized.status.2669 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2653, i32 %local.check.extent.2654)
  %helper.ok.2670 = icmp eq i32 %descriptor.initialized.status.2669, 0
  br i1 %helper.ok.2670, label %helper.continue.2671, label %frame.failure.0
helper.continue.2671:
  br label %local.descriptor.checked.2652
local.descriptor.inactive.2651:
  br label %local.descriptor.checked.2652
local.descriptor.checked.2652:
  %local.is.active.2672 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2672, label %local.descriptor.active.2673, label %local.descriptor.inactive.2674
local.descriptor.active.2673:
  %local.check.offset.2676 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2677 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2678 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2679 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2681 = load i32, ptr %context.field.2680, align 4
  %stack.sub.2684 = sub i32 %local.check.owner.end.2679, %local.check.offset.2676
  %descriptor.owner.inside.2682 = icmp ule i32 %local.check.owner.end.2679, %context.value.2681
  %descriptor.offset.inside.2683 = icmp ule i32 %local.check.offset.2676, %local.check.owner.end.2679
  %descriptor.extent.inside.2685 = icmp ule i32 %local.check.extent.2677, %stack.sub.2684
  %descriptor.payload.inside.2686 = icmp ule i32 %local.check.payload.2678, %local.check.extent.2677
  %descriptor.owner.offset.valid.2687 = and i1 %descriptor.owner.inside.2682, %descriptor.offset.inside.2683
  %descriptor.range.inside.2689 = and i1 %descriptor.owner.offset.valid.2687, %descriptor.extent.inside.2685
  %descriptor.range.valid.2688 = and i1 %descriptor.range.inside.2689, %descriptor.payload.inside.2686
  br i1 %descriptor.range.valid.2688, label %descriptor.valid.2690, label %descriptor.invalid.2691
descriptor.invalid.2691:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2690:
  %descriptor.initialized.status.2692 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2676, i32 %local.check.extent.2677)
  %helper.ok.2693 = icmp eq i32 %descriptor.initialized.status.2692, 0
  br i1 %helper.ok.2693, label %helper.continue.2694, label %frame.failure.0
helper.continue.2694:
  br label %local.descriptor.checked.2675
local.descriptor.inactive.2674:
  br label %local.descriptor.checked.2675
local.descriptor.checked.2675:
  %local.is.active.2695 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2695, label %local.descriptor.active.2696, label %local.descriptor.inactive.2697
local.descriptor.active.2696:
  %local.check.offset.2699 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2700 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2701 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2702 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2703 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2704 = load i32, ptr %context.field.2703, align 4
  %stack.sub.2707 = sub i32 %local.check.owner.end.2702, %local.check.offset.2699
  %descriptor.owner.inside.2705 = icmp ule i32 %local.check.owner.end.2702, %context.value.2704
  %descriptor.offset.inside.2706 = icmp ule i32 %local.check.offset.2699, %local.check.owner.end.2702
  %descriptor.extent.inside.2708 = icmp ule i32 %local.check.extent.2700, %stack.sub.2707
  %descriptor.payload.inside.2709 = icmp ule i32 %local.check.payload.2701, %local.check.extent.2700
  %descriptor.owner.offset.valid.2710 = and i1 %descriptor.owner.inside.2705, %descriptor.offset.inside.2706
  %descriptor.range.inside.2712 = and i1 %descriptor.owner.offset.valid.2710, %descriptor.extent.inside.2708
  %descriptor.range.valid.2711 = and i1 %descriptor.range.inside.2712, %descriptor.payload.inside.2709
  br i1 %descriptor.range.valid.2711, label %descriptor.valid.2713, label %descriptor.invalid.2714
descriptor.invalid.2714:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2713:
  %descriptor.initialized.status.2715 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2699, i32 %local.check.extent.2700)
  %helper.ok.2716 = icmp eq i32 %descriptor.initialized.status.2715, 0
  br i1 %helper.ok.2716, label %helper.continue.2717, label %frame.failure.0
helper.continue.2717:
  br label %local.descriptor.checked.2698
local.descriptor.inactive.2697:
  br label %local.descriptor.checked.2698
local.descriptor.checked.2698:
  %step.status.2718 = call i32 @al_owning_charge_step(ptr %ctx, i32 47)
  %helper.ok.2719 = icmp eq i32 %step.status.2718, 0
  br i1 %helper.ok.2719, label %helper.continue.2720, label %frame.failure.0
helper.continue.2720:
  store i1 true, ptr %local.active.20, align 1
  store i32 %if.value.offset.2536, ptr %local.offset.21, align 4
  store i32 %if.value.extent.2537, ptr %local.extent.22, align 4
  store i32 %if.value.payload.2538, ptr %local.payload.23, align 4
  store i32 %if.value.owner.end.2539, ptr %local.owner.end.24, align 4
  store i32 1, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %if.value.offset.2536, i32 20, i32 %if.value.payload.2538, i32 %if.value.owner.end.2539, i32 %if.value.extent.2537)
  %context.field.2721 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2722 = load i32, ptr %context.field.2721, align 4
  %runtime.ok.2723 = icmp eq i32 %context.value.2722, 0
  br i1 %runtime.ok.2723, label %runtime.continue.2724, label %frame.failure.0
runtime.continue.2724:
  %local.is.active.2725 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2725, label %local.descriptor.active.2726, label %local.descriptor.inactive.2727
local.descriptor.active.2726:
  %local.check.offset.2729 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2730 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2731 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2732 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2733 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2734 = load i32, ptr %context.field.2733, align 4
  %stack.sub.2737 = sub i32 %local.check.owner.end.2732, %local.check.offset.2729
  %descriptor.owner.inside.2735 = icmp ule i32 %local.check.owner.end.2732, %context.value.2734
  %descriptor.offset.inside.2736 = icmp ule i32 %local.check.offset.2729, %local.check.owner.end.2732
  %descriptor.extent.inside.2738 = icmp ule i32 %local.check.extent.2730, %stack.sub.2737
  %descriptor.payload.inside.2739 = icmp ule i32 %local.check.payload.2731, %local.check.extent.2730
  %descriptor.owner.offset.valid.2740 = and i1 %descriptor.owner.inside.2735, %descriptor.offset.inside.2736
  %descriptor.range.inside.2742 = and i1 %descriptor.owner.offset.valid.2740, %descriptor.extent.inside.2738
  %descriptor.range.valid.2741 = and i1 %descriptor.range.inside.2742, %descriptor.payload.inside.2739
  br i1 %descriptor.range.valid.2741, label %descriptor.valid.2743, label %descriptor.invalid.2744
descriptor.invalid.2744:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2743:
  %descriptor.initialized.status.2745 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2729, i32 %local.check.extent.2730)
  %helper.ok.2746 = icmp eq i32 %descriptor.initialized.status.2745, 0
  br i1 %helper.ok.2746, label %helper.continue.2747, label %frame.failure.0
helper.continue.2747:
  br label %local.descriptor.checked.2728
local.descriptor.inactive.2727:
  br label %local.descriptor.checked.2728
local.descriptor.checked.2728:
  %local.is.active.2748 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2748, label %local.descriptor.active.2749, label %local.descriptor.inactive.2750
local.descriptor.active.2749:
  %local.check.offset.2752 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2753 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2754 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2755 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2756 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2757 = load i32, ptr %context.field.2756, align 4
  %stack.sub.2760 = sub i32 %local.check.owner.end.2755, %local.check.offset.2752
  %descriptor.owner.inside.2758 = icmp ule i32 %local.check.owner.end.2755, %context.value.2757
  %descriptor.offset.inside.2759 = icmp ule i32 %local.check.offset.2752, %local.check.owner.end.2755
  %descriptor.extent.inside.2761 = icmp ule i32 %local.check.extent.2753, %stack.sub.2760
  %descriptor.payload.inside.2762 = icmp ule i32 %local.check.payload.2754, %local.check.extent.2753
  %descriptor.owner.offset.valid.2763 = and i1 %descriptor.owner.inside.2758, %descriptor.offset.inside.2759
  %descriptor.range.inside.2765 = and i1 %descriptor.owner.offset.valid.2763, %descriptor.extent.inside.2761
  %descriptor.range.valid.2764 = and i1 %descriptor.range.inside.2765, %descriptor.payload.inside.2762
  br i1 %descriptor.range.valid.2764, label %descriptor.valid.2766, label %descriptor.invalid.2767
descriptor.invalid.2767:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2766:
  %descriptor.initialized.status.2768 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2752, i32 %local.check.extent.2753)
  %helper.ok.2769 = icmp eq i32 %descriptor.initialized.status.2768, 0
  br i1 %helper.ok.2769, label %helper.continue.2770, label %frame.failure.0
helper.continue.2770:
  br label %local.descriptor.checked.2751
local.descriptor.inactive.2750:
  br label %local.descriptor.checked.2751
local.descriptor.checked.2751:
  %local.is.active.2771 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2771, label %local.descriptor.active.2772, label %local.descriptor.inactive.2773
local.descriptor.active.2772:
  %local.check.offset.2775 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2776 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2777 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2778 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2779 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2780 = load i32, ptr %context.field.2779, align 4
  %stack.sub.2783 = sub i32 %local.check.owner.end.2778, %local.check.offset.2775
  %descriptor.owner.inside.2781 = icmp ule i32 %local.check.owner.end.2778, %context.value.2780
  %descriptor.offset.inside.2782 = icmp ule i32 %local.check.offset.2775, %local.check.owner.end.2778
  %descriptor.extent.inside.2784 = icmp ule i32 %local.check.extent.2776, %stack.sub.2783
  %descriptor.payload.inside.2785 = icmp ule i32 %local.check.payload.2777, %local.check.extent.2776
  %descriptor.owner.offset.valid.2786 = and i1 %descriptor.owner.inside.2781, %descriptor.offset.inside.2782
  %descriptor.range.inside.2788 = and i1 %descriptor.owner.offset.valid.2786, %descriptor.extent.inside.2784
  %descriptor.range.valid.2787 = and i1 %descriptor.range.inside.2788, %descriptor.payload.inside.2785
  br i1 %descriptor.range.valid.2787, label %descriptor.valid.2789, label %descriptor.invalid.2790
descriptor.invalid.2790:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2789:
  %descriptor.initialized.status.2791 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2775, i32 %local.check.extent.2776)
  %helper.ok.2792 = icmp eq i32 %descriptor.initialized.status.2791, 0
  br i1 %helper.ok.2792, label %helper.continue.2793, label %frame.failure.0
helper.continue.2793:
  br label %local.descriptor.checked.2774
local.descriptor.inactive.2773:
  br label %local.descriptor.checked.2774
local.descriptor.checked.2774:
  %local.is.active.2794 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2794, label %local.descriptor.active.2795, label %local.descriptor.inactive.2796
local.descriptor.active.2795:
  %local.check.offset.2798 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2799 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2800 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2801 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2803 = load i32, ptr %context.field.2802, align 4
  %stack.sub.2806 = sub i32 %local.check.owner.end.2801, %local.check.offset.2798
  %descriptor.owner.inside.2804 = icmp ule i32 %local.check.owner.end.2801, %context.value.2803
  %descriptor.offset.inside.2805 = icmp ule i32 %local.check.offset.2798, %local.check.owner.end.2801
  %descriptor.extent.inside.2807 = icmp ule i32 %local.check.extent.2799, %stack.sub.2806
  %descriptor.payload.inside.2808 = icmp ule i32 %local.check.payload.2800, %local.check.extent.2799
  %descriptor.owner.offset.valid.2809 = and i1 %descriptor.owner.inside.2804, %descriptor.offset.inside.2805
  %descriptor.range.inside.2811 = and i1 %descriptor.owner.offset.valid.2809, %descriptor.extent.inside.2807
  %descriptor.range.valid.2810 = and i1 %descriptor.range.inside.2811, %descriptor.payload.inside.2808
  br i1 %descriptor.range.valid.2810, label %descriptor.valid.2812, label %descriptor.invalid.2813
descriptor.invalid.2813:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2812:
  %descriptor.initialized.status.2814 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2798, i32 %local.check.extent.2799)
  %helper.ok.2815 = icmp eq i32 %descriptor.initialized.status.2814, 0
  br i1 %helper.ok.2815, label %helper.continue.2816, label %frame.failure.0
helper.continue.2816:
  br label %local.descriptor.checked.2797
local.descriptor.inactive.2796:
  br label %local.descriptor.checked.2797
local.descriptor.checked.2797:
  %local.is.active.2817 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2817, label %local.descriptor.active.2818, label %local.descriptor.inactive.2819
local.descriptor.active.2818:
  %local.check.offset.2821 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2822 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2823 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2824 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2826 = load i32, ptr %context.field.2825, align 4
  %stack.sub.2829 = sub i32 %local.check.owner.end.2824, %local.check.offset.2821
  %descriptor.owner.inside.2827 = icmp ule i32 %local.check.owner.end.2824, %context.value.2826
  %descriptor.offset.inside.2828 = icmp ule i32 %local.check.offset.2821, %local.check.owner.end.2824
  %descriptor.extent.inside.2830 = icmp ule i32 %local.check.extent.2822, %stack.sub.2829
  %descriptor.payload.inside.2831 = icmp ule i32 %local.check.payload.2823, %local.check.extent.2822
  %descriptor.owner.offset.valid.2832 = and i1 %descriptor.owner.inside.2827, %descriptor.offset.inside.2828
  %descriptor.range.inside.2834 = and i1 %descriptor.owner.offset.valid.2832, %descriptor.extent.inside.2830
  %descriptor.range.valid.2833 = and i1 %descriptor.range.inside.2834, %descriptor.payload.inside.2831
  br i1 %descriptor.range.valid.2833, label %descriptor.valid.2835, label %descriptor.invalid.2836
descriptor.invalid.2836:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2835:
  %descriptor.initialized.status.2837 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2821, i32 %local.check.extent.2822)
  %helper.ok.2838 = icmp eq i32 %descriptor.initialized.status.2837, 0
  br i1 %helper.ok.2838, label %helper.continue.2839, label %frame.failure.0
helper.continue.2839:
  br label %local.descriptor.checked.2820
local.descriptor.inactive.2819:
  br label %local.descriptor.checked.2820
local.descriptor.checked.2820:
  %local.is.active.2840 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2840, label %local.descriptor.active.2841, label %local.descriptor.inactive.2842
local.descriptor.active.2841:
  %local.check.offset.2844 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2845 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2846 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2847 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2849 = load i32, ptr %context.field.2848, align 4
  %stack.sub.2852 = sub i32 %local.check.owner.end.2847, %local.check.offset.2844
  %descriptor.owner.inside.2850 = icmp ule i32 %local.check.owner.end.2847, %context.value.2849
  %descriptor.offset.inside.2851 = icmp ule i32 %local.check.offset.2844, %local.check.owner.end.2847
  %descriptor.extent.inside.2853 = icmp ule i32 %local.check.extent.2845, %stack.sub.2852
  %descriptor.payload.inside.2854 = icmp ule i32 %local.check.payload.2846, %local.check.extent.2845
  %descriptor.owner.offset.valid.2855 = and i1 %descriptor.owner.inside.2850, %descriptor.offset.inside.2851
  %descriptor.range.inside.2857 = and i1 %descriptor.owner.offset.valid.2855, %descriptor.extent.inside.2853
  %descriptor.range.valid.2856 = and i1 %descriptor.range.inside.2857, %descriptor.payload.inside.2854
  br i1 %descriptor.range.valid.2856, label %descriptor.valid.2858, label %descriptor.invalid.2859
descriptor.invalid.2859:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2858:
  %descriptor.initialized.status.2860 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2844, i32 %local.check.extent.2845)
  %helper.ok.2861 = icmp eq i32 %descriptor.initialized.status.2860, 0
  br i1 %helper.ok.2861, label %helper.continue.2862, label %frame.failure.0
helper.continue.2862:
  br label %local.descriptor.checked.2843
local.descriptor.inactive.2842:
  br label %local.descriptor.checked.2843
local.descriptor.checked.2843:
  %local.is.active.2863 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2863, label %local.descriptor.active.2864, label %local.descriptor.inactive.2865
local.descriptor.active.2864:
  %local.check.offset.2867 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2868 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2869 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2870 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2872 = load i32, ptr %context.field.2871, align 4
  %stack.sub.2875 = sub i32 %local.check.owner.end.2870, %local.check.offset.2867
  %descriptor.owner.inside.2873 = icmp ule i32 %local.check.owner.end.2870, %context.value.2872
  %descriptor.offset.inside.2874 = icmp ule i32 %local.check.offset.2867, %local.check.owner.end.2870
  %descriptor.extent.inside.2876 = icmp ule i32 %local.check.extent.2868, %stack.sub.2875
  %descriptor.payload.inside.2877 = icmp ule i32 %local.check.payload.2869, %local.check.extent.2868
  %descriptor.owner.offset.valid.2878 = and i1 %descriptor.owner.inside.2873, %descriptor.offset.inside.2874
  %descriptor.range.inside.2880 = and i1 %descriptor.owner.offset.valid.2878, %descriptor.extent.inside.2876
  %descriptor.range.valid.2879 = and i1 %descriptor.range.inside.2880, %descriptor.payload.inside.2877
  br i1 %descriptor.range.valid.2879, label %descriptor.valid.2881, label %descriptor.invalid.2882
descriptor.invalid.2882:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2881:
  %descriptor.initialized.status.2883 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2867, i32 %local.check.extent.2868)
  %helper.ok.2884 = icmp eq i32 %descriptor.initialized.status.2883, 0
  br i1 %helper.ok.2884, label %helper.continue.2885, label %frame.failure.0
helper.continue.2885:
  br label %local.descriptor.checked.2866
local.descriptor.inactive.2865:
  br label %local.descriptor.checked.2866
local.descriptor.checked.2866:
  %step.status.2886 = call i32 @al_owning_charge_step(ptr %ctx, i32 48)
  %helper.ok.2887 = icmp eq i32 %step.status.2886, 0
  br i1 %helper.ok.2887, label %helper.continue.2888, label %frame.failure.0
helper.continue.2888:
  %local.resolved.offset.2889 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.2890 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.2891 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.2892 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2893 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2894 = load i32, ptr %context.field.2893, align 4
  %stack.sub.2897 = sub i32 %local.resolved.owner.end.2892, %local.resolved.offset.2889
  %descriptor.owner.inside.2895 = icmp ule i32 %local.resolved.owner.end.2892, %context.value.2894
  %descriptor.offset.inside.2896 = icmp ule i32 %local.resolved.offset.2889, %local.resolved.owner.end.2892
  %descriptor.extent.inside.2898 = icmp ule i32 %local.resolved.extent.2890, %stack.sub.2897
  %descriptor.payload.inside.2899 = icmp ule i32 %local.resolved.payload.2891, %local.resolved.extent.2890
  %descriptor.owner.offset.valid.2900 = and i1 %descriptor.owner.inside.2895, %descriptor.offset.inside.2896
  %descriptor.range.inside.2902 = and i1 %descriptor.owner.offset.valid.2900, %descriptor.extent.inside.2898
  %descriptor.range.valid.2901 = and i1 %descriptor.range.inside.2902, %descriptor.payload.inside.2899
  %descriptor.type.valid.2903 = icmp eq i32 5, 5
  %descriptor.valid.2904 = and i1 %descriptor.range.valid.2901, %descriptor.type.valid.2903
  br i1 %descriptor.valid.2904, label %descriptor.valid.2905, label %descriptor.invalid.2906
descriptor.invalid.2906:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2905:
  %descriptor.initialized.status.2907 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2889, i32 %local.resolved.extent.2890)
  %helper.ok.2908 = icmp eq i32 %descriptor.initialized.status.2907, 0
  br i1 %helper.ok.2908, label %helper.continue.2909, label %frame.failure.0
helper.continue.2909:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.2889, i32 20, i32 %local.resolved.payload.2891, i32 %local.resolved.owner.end.2892, i32 %local.resolved.extent.2890)
  %context.field.2910 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2911 = load i32, ptr %context.field.2910, align 4
  %runtime.ok.2912 = icmp eq i32 %context.value.2911, 0
  br i1 %runtime.ok.2912, label %runtime.continue.2913, label %frame.failure.0
runtime.continue.2913:
  %context.field.2914 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2915 = load i32, ptr %context.field.2914, align 4
  %stack.sub.2918 = sub i32 %local.resolved.owner.end.2892, %local.resolved.offset.2889
  %descriptor.owner.inside.2916 = icmp ule i32 %local.resolved.owner.end.2892, %context.value.2915
  %descriptor.offset.inside.2917 = icmp ule i32 %local.resolved.offset.2889, %local.resolved.owner.end.2892
  %descriptor.extent.inside.2919 = icmp ule i32 %local.resolved.extent.2890, %stack.sub.2918
  %descriptor.payload.inside.2920 = icmp ule i32 %local.resolved.payload.2891, %local.resolved.extent.2890
  %descriptor.owner.offset.valid.2921 = and i1 %descriptor.owner.inside.2916, %descriptor.offset.inside.2917
  %descriptor.range.inside.2923 = and i1 %descriptor.owner.offset.valid.2921, %descriptor.extent.inside.2919
  %descriptor.range.valid.2922 = and i1 %descriptor.range.inside.2923, %descriptor.payload.inside.2920
  %descriptor.type.valid.2924 = icmp eq i32 5, 5
  %descriptor.valid.2925 = and i1 %descriptor.range.valid.2922, %descriptor.type.valid.2924
  br i1 %descriptor.valid.2925, label %descriptor.valid.2926, label %descriptor.invalid.2927
descriptor.invalid.2927:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2926:
  %descriptor.initialized.status.2928 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2889, i32 %local.resolved.extent.2890)
  %helper.ok.2929 = icmp eq i32 %descriptor.initialized.status.2928, 0
  br i1 %helper.ok.2929, label %helper.continue.2930, label %frame.failure.0
helper.continue.2930:
  %local.is.active.2931 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2931, label %local.descriptor.active.2932, label %local.descriptor.inactive.2933
local.descriptor.active.2932:
  %local.check.offset.2935 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2936 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2937 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2938 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2939 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2940 = load i32, ptr %context.field.2939, align 4
  %stack.sub.2943 = sub i32 %local.check.owner.end.2938, %local.check.offset.2935
  %descriptor.owner.inside.2941 = icmp ule i32 %local.check.owner.end.2938, %context.value.2940
  %descriptor.offset.inside.2942 = icmp ule i32 %local.check.offset.2935, %local.check.owner.end.2938
  %descriptor.extent.inside.2944 = icmp ule i32 %local.check.extent.2936, %stack.sub.2943
  %descriptor.payload.inside.2945 = icmp ule i32 %local.check.payload.2937, %local.check.extent.2936
  %descriptor.owner.offset.valid.2946 = and i1 %descriptor.owner.inside.2941, %descriptor.offset.inside.2942
  %descriptor.range.inside.2948 = and i1 %descriptor.owner.offset.valid.2946, %descriptor.extent.inside.2944
  %descriptor.range.valid.2947 = and i1 %descriptor.range.inside.2948, %descriptor.payload.inside.2945
  br i1 %descriptor.range.valid.2947, label %descriptor.valid.2949, label %descriptor.invalid.2950
descriptor.invalid.2950:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2949:
  %descriptor.initialized.status.2951 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2935, i32 %local.check.extent.2936)
  %helper.ok.2952 = icmp eq i32 %descriptor.initialized.status.2951, 0
  br i1 %helper.ok.2952, label %helper.continue.2953, label %frame.failure.0
helper.continue.2953:
  br label %local.descriptor.checked.2934
local.descriptor.inactive.2933:
  br label %local.descriptor.checked.2934
local.descriptor.checked.2934:
  %local.is.active.2954 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2954, label %local.descriptor.active.2955, label %local.descriptor.inactive.2956
local.descriptor.active.2955:
  %local.check.offset.2958 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2959 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2960 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2961 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2962 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2963 = load i32, ptr %context.field.2962, align 4
  %stack.sub.2966 = sub i32 %local.check.owner.end.2961, %local.check.offset.2958
  %descriptor.owner.inside.2964 = icmp ule i32 %local.check.owner.end.2961, %context.value.2963
  %descriptor.offset.inside.2965 = icmp ule i32 %local.check.offset.2958, %local.check.owner.end.2961
  %descriptor.extent.inside.2967 = icmp ule i32 %local.check.extent.2959, %stack.sub.2966
  %descriptor.payload.inside.2968 = icmp ule i32 %local.check.payload.2960, %local.check.extent.2959
  %descriptor.owner.offset.valid.2969 = and i1 %descriptor.owner.inside.2964, %descriptor.offset.inside.2965
  %descriptor.range.inside.2971 = and i1 %descriptor.owner.offset.valid.2969, %descriptor.extent.inside.2967
  %descriptor.range.valid.2970 = and i1 %descriptor.range.inside.2971, %descriptor.payload.inside.2968
  br i1 %descriptor.range.valid.2970, label %descriptor.valid.2972, label %descriptor.invalid.2973
descriptor.invalid.2973:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2972:
  %descriptor.initialized.status.2974 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2958, i32 %local.check.extent.2959)
  %helper.ok.2975 = icmp eq i32 %descriptor.initialized.status.2974, 0
  br i1 %helper.ok.2975, label %helper.continue.2976, label %frame.failure.0
helper.continue.2976:
  br label %local.descriptor.checked.2957
local.descriptor.inactive.2956:
  br label %local.descriptor.checked.2957
local.descriptor.checked.2957:
  %local.is.active.2977 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2977, label %local.descriptor.active.2978, label %local.descriptor.inactive.2979
local.descriptor.active.2978:
  %local.check.offset.2981 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2982 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2983 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2984 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2986 = load i32, ptr %context.field.2985, align 4
  %stack.sub.2989 = sub i32 %local.check.owner.end.2984, %local.check.offset.2981
  %descriptor.owner.inside.2987 = icmp ule i32 %local.check.owner.end.2984, %context.value.2986
  %descriptor.offset.inside.2988 = icmp ule i32 %local.check.offset.2981, %local.check.owner.end.2984
  %descriptor.extent.inside.2990 = icmp ule i32 %local.check.extent.2982, %stack.sub.2989
  %descriptor.payload.inside.2991 = icmp ule i32 %local.check.payload.2983, %local.check.extent.2982
  %descriptor.owner.offset.valid.2992 = and i1 %descriptor.owner.inside.2987, %descriptor.offset.inside.2988
  %descriptor.range.inside.2994 = and i1 %descriptor.owner.offset.valid.2992, %descriptor.extent.inside.2990
  %descriptor.range.valid.2993 = and i1 %descriptor.range.inside.2994, %descriptor.payload.inside.2991
  br i1 %descriptor.range.valid.2993, label %descriptor.valid.2995, label %descriptor.invalid.2996
descriptor.invalid.2996:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2995:
  %descriptor.initialized.status.2997 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2981, i32 %local.check.extent.2982)
  %helper.ok.2998 = icmp eq i32 %descriptor.initialized.status.2997, 0
  br i1 %helper.ok.2998, label %helper.continue.2999, label %frame.failure.0
helper.continue.2999:
  br label %local.descriptor.checked.2980
local.descriptor.inactive.2979:
  br label %local.descriptor.checked.2980
local.descriptor.checked.2980:
  %local.is.active.3000 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3000, label %local.descriptor.active.3001, label %local.descriptor.inactive.3002
local.descriptor.active.3001:
  %local.check.offset.3004 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3005 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3006 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3007 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3008 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3009 = load i32, ptr %context.field.3008, align 4
  %stack.sub.3012 = sub i32 %local.check.owner.end.3007, %local.check.offset.3004
  %descriptor.owner.inside.3010 = icmp ule i32 %local.check.owner.end.3007, %context.value.3009
  %descriptor.offset.inside.3011 = icmp ule i32 %local.check.offset.3004, %local.check.owner.end.3007
  %descriptor.extent.inside.3013 = icmp ule i32 %local.check.extent.3005, %stack.sub.3012
  %descriptor.payload.inside.3014 = icmp ule i32 %local.check.payload.3006, %local.check.extent.3005
  %descriptor.owner.offset.valid.3015 = and i1 %descriptor.owner.inside.3010, %descriptor.offset.inside.3011
  %descriptor.range.inside.3017 = and i1 %descriptor.owner.offset.valid.3015, %descriptor.extent.inside.3013
  %descriptor.range.valid.3016 = and i1 %descriptor.range.inside.3017, %descriptor.payload.inside.3014
  br i1 %descriptor.range.valid.3016, label %descriptor.valid.3018, label %descriptor.invalid.3019
descriptor.invalid.3019:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3018:
  %descriptor.initialized.status.3020 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3004, i32 %local.check.extent.3005)
  %helper.ok.3021 = icmp eq i32 %descriptor.initialized.status.3020, 0
  br i1 %helper.ok.3021, label %helper.continue.3022, label %frame.failure.0
helper.continue.3022:
  br label %local.descriptor.checked.3003
local.descriptor.inactive.3002:
  br label %local.descriptor.checked.3003
local.descriptor.checked.3003:
  %local.is.active.3023 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3023, label %local.descriptor.active.3024, label %local.descriptor.inactive.3025
local.descriptor.active.3024:
  %local.check.offset.3027 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3028 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3029 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3030 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3031 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3032 = load i32, ptr %context.field.3031, align 4
  %stack.sub.3035 = sub i32 %local.check.owner.end.3030, %local.check.offset.3027
  %descriptor.owner.inside.3033 = icmp ule i32 %local.check.owner.end.3030, %context.value.3032
  %descriptor.offset.inside.3034 = icmp ule i32 %local.check.offset.3027, %local.check.owner.end.3030
  %descriptor.extent.inside.3036 = icmp ule i32 %local.check.extent.3028, %stack.sub.3035
  %descriptor.payload.inside.3037 = icmp ule i32 %local.check.payload.3029, %local.check.extent.3028
  %descriptor.owner.offset.valid.3038 = and i1 %descriptor.owner.inside.3033, %descriptor.offset.inside.3034
  %descriptor.range.inside.3040 = and i1 %descriptor.owner.offset.valid.3038, %descriptor.extent.inside.3036
  %descriptor.range.valid.3039 = and i1 %descriptor.range.inside.3040, %descriptor.payload.inside.3037
  br i1 %descriptor.range.valid.3039, label %descriptor.valid.3041, label %descriptor.invalid.3042
descriptor.invalid.3042:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3041:
  %descriptor.initialized.status.3043 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3027, i32 %local.check.extent.3028)
  %helper.ok.3044 = icmp eq i32 %descriptor.initialized.status.3043, 0
  br i1 %helper.ok.3044, label %helper.continue.3045, label %frame.failure.0
helper.continue.3045:
  br label %local.descriptor.checked.3026
local.descriptor.inactive.3025:
  br label %local.descriptor.checked.3026
local.descriptor.checked.3026:
  %local.is.active.3046 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3046, label %local.descriptor.active.3047, label %local.descriptor.inactive.3048
local.descriptor.active.3047:
  %local.check.offset.3050 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3051 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3052 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3053 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3054 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3055 = load i32, ptr %context.field.3054, align 4
  %stack.sub.3058 = sub i32 %local.check.owner.end.3053, %local.check.offset.3050
  %descriptor.owner.inside.3056 = icmp ule i32 %local.check.owner.end.3053, %context.value.3055
  %descriptor.offset.inside.3057 = icmp ule i32 %local.check.offset.3050, %local.check.owner.end.3053
  %descriptor.extent.inside.3059 = icmp ule i32 %local.check.extent.3051, %stack.sub.3058
  %descriptor.payload.inside.3060 = icmp ule i32 %local.check.payload.3052, %local.check.extent.3051
  %descriptor.owner.offset.valid.3061 = and i1 %descriptor.owner.inside.3056, %descriptor.offset.inside.3057
  %descriptor.range.inside.3063 = and i1 %descriptor.owner.offset.valid.3061, %descriptor.extent.inside.3059
  %descriptor.range.valid.3062 = and i1 %descriptor.range.inside.3063, %descriptor.payload.inside.3060
  br i1 %descriptor.range.valid.3062, label %descriptor.valid.3064, label %descriptor.invalid.3065
descriptor.invalid.3065:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3064:
  %descriptor.initialized.status.3066 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3050, i32 %local.check.extent.3051)
  %helper.ok.3067 = icmp eq i32 %descriptor.initialized.status.3066, 0
  br i1 %helper.ok.3067, label %helper.continue.3068, label %frame.failure.0
helper.continue.3068:
  br label %local.descriptor.checked.3049
local.descriptor.inactive.3048:
  br label %local.descriptor.checked.3049
local.descriptor.checked.3049:
  %local.is.active.3069 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3069, label %local.descriptor.active.3070, label %local.descriptor.inactive.3071
local.descriptor.active.3070:
  %local.check.offset.3073 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3074 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3075 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3076 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3077 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3078 = load i32, ptr %context.field.3077, align 4
  %stack.sub.3081 = sub i32 %local.check.owner.end.3076, %local.check.offset.3073
  %descriptor.owner.inside.3079 = icmp ule i32 %local.check.owner.end.3076, %context.value.3078
  %descriptor.offset.inside.3080 = icmp ule i32 %local.check.offset.3073, %local.check.owner.end.3076
  %descriptor.extent.inside.3082 = icmp ule i32 %local.check.extent.3074, %stack.sub.3081
  %descriptor.payload.inside.3083 = icmp ule i32 %local.check.payload.3075, %local.check.extent.3074
  %descriptor.owner.offset.valid.3084 = and i1 %descriptor.owner.inside.3079, %descriptor.offset.inside.3080
  %descriptor.range.inside.3086 = and i1 %descriptor.owner.offset.valid.3084, %descriptor.extent.inside.3082
  %descriptor.range.valid.3085 = and i1 %descriptor.range.inside.3086, %descriptor.payload.inside.3083
  br i1 %descriptor.range.valid.3085, label %descriptor.valid.3087, label %descriptor.invalid.3088
descriptor.invalid.3088:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3087:
  %descriptor.initialized.status.3089 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3073, i32 %local.check.extent.3074)
  %helper.ok.3090 = icmp eq i32 %descriptor.initialized.status.3089, 0
  br i1 %helper.ok.3090, label %helper.continue.3091, label %frame.failure.0
helper.continue.3091:
  br label %local.descriptor.checked.3072
local.descriptor.inactive.3071:
  br label %local.descriptor.checked.3072
local.descriptor.checked.3072:
  %step.status.3092 = call i32 @al_owning_charge_step(ptr %ctx, i32 49)
  %helper.ok.3093 = icmp eq i32 %step.status.3092, 0
  br i1 %helper.ok.3093, label %helper.continue.3094, label %frame.failure.0
helper.continue.3094:
  %field.location.3095 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.3096 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %local.resolved.offset.2889, i32 %local.resolved.extent.2890, i32 0, i32 50, ptr %field.location.3095)
  %helper.ok.3097 = icmp eq i32 %field.location.status.3096, 0
  br i1 %helper.ok.3097, label %helper.continue.3098, label %frame.failure.0
helper.continue.3098:
  %field.offset.pointer.3099 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3095, i32 0, i32 0
  %field.offset.3100 = load i32, ptr %field.offset.pointer.3099, align 4
  %field.payload.pointer.3101 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3095, i32 0, i32 1
  %field.payload.3102 = load i32, ptr %field.payload.pointer.3101, align 4
  %field.extent.pointer.3103 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3095, i32 0, i32 2
  %field.extent.3104 = load i32, ptr %field.extent.pointer.3103, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 6, i32 %local.resolved.offset.2889, i32 %field.extent.3104, i32 %field.payload.3102, i32 %field.offset.3100, i32 %field.extent.3104)
  %context.field.3105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3106 = load i32, ptr %context.field.3105, align 4
  %runtime.ok.3107 = icmp eq i32 %context.value.3106, 0
  br i1 %runtime.ok.3107, label %runtime.continue.3108, label %frame.failure.0
runtime.continue.3108:
  %context.field.3109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3110 = load i32, ptr %context.field.3109, align 4
  %stack.sub.3113 = sub i32 %local.resolved.owner.end.2892, %field.offset.3100
  %descriptor.owner.inside.3111 = icmp ule i32 %local.resolved.owner.end.2892, %context.value.3110
  %descriptor.offset.inside.3112 = icmp ule i32 %field.offset.3100, %local.resolved.owner.end.2892
  %descriptor.extent.inside.3114 = icmp ule i32 %field.extent.3104, %stack.sub.3113
  %descriptor.payload.inside.3115 = icmp ule i32 %field.payload.3102, %field.extent.3104
  %descriptor.owner.offset.valid.3116 = and i1 %descriptor.owner.inside.3111, %descriptor.offset.inside.3112
  %descriptor.range.inside.3118 = and i1 %descriptor.owner.offset.valid.3116, %descriptor.extent.inside.3114
  %descriptor.range.valid.3117 = and i1 %descriptor.range.inside.3118, %descriptor.payload.inside.3115
  %descriptor.type.valid.3119 = icmp eq i32 6, 6
  %descriptor.valid.3120 = and i1 %descriptor.range.valid.3117, %descriptor.type.valid.3119
  br i1 %descriptor.valid.3120, label %descriptor.valid.3121, label %descriptor.invalid.3122
descriptor.invalid.3122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3121:
  %descriptor.initialized.status.3123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3100, i32 %field.extent.3104)
  %helper.ok.3124 = icmp eq i32 %descriptor.initialized.status.3123, 0
  br i1 %helper.ok.3124, label %helper.continue.3125, label %frame.failure.0
helper.continue.3125:
  %local.is.active.3126 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3126, label %local.descriptor.active.3127, label %local.descriptor.inactive.3128
local.descriptor.active.3127:
  %local.check.offset.3130 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3131 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3132 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3133 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3135 = load i32, ptr %context.field.3134, align 4
  %stack.sub.3138 = sub i32 %local.check.owner.end.3133, %local.check.offset.3130
  %descriptor.owner.inside.3136 = icmp ule i32 %local.check.owner.end.3133, %context.value.3135
  %descriptor.offset.inside.3137 = icmp ule i32 %local.check.offset.3130, %local.check.owner.end.3133
  %descriptor.extent.inside.3139 = icmp ule i32 %local.check.extent.3131, %stack.sub.3138
  %descriptor.payload.inside.3140 = icmp ule i32 %local.check.payload.3132, %local.check.extent.3131
  %descriptor.owner.offset.valid.3141 = and i1 %descriptor.owner.inside.3136, %descriptor.offset.inside.3137
  %descriptor.range.inside.3143 = and i1 %descriptor.owner.offset.valid.3141, %descriptor.extent.inside.3139
  %descriptor.range.valid.3142 = and i1 %descriptor.range.inside.3143, %descriptor.payload.inside.3140
  br i1 %descriptor.range.valid.3142, label %descriptor.valid.3144, label %descriptor.invalid.3145
descriptor.invalid.3145:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3144:
  %descriptor.initialized.status.3146 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3130, i32 %local.check.extent.3131)
  %helper.ok.3147 = icmp eq i32 %descriptor.initialized.status.3146, 0
  br i1 %helper.ok.3147, label %helper.continue.3148, label %frame.failure.0
helper.continue.3148:
  br label %local.descriptor.checked.3129
local.descriptor.inactive.3128:
  br label %local.descriptor.checked.3129
local.descriptor.checked.3129:
  %local.is.active.3149 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3149, label %local.descriptor.active.3150, label %local.descriptor.inactive.3151
local.descriptor.active.3150:
  %local.check.offset.3153 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3154 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3155 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3156 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3158 = load i32, ptr %context.field.3157, align 4
  %stack.sub.3161 = sub i32 %local.check.owner.end.3156, %local.check.offset.3153
  %descriptor.owner.inside.3159 = icmp ule i32 %local.check.owner.end.3156, %context.value.3158
  %descriptor.offset.inside.3160 = icmp ule i32 %local.check.offset.3153, %local.check.owner.end.3156
  %descriptor.extent.inside.3162 = icmp ule i32 %local.check.extent.3154, %stack.sub.3161
  %descriptor.payload.inside.3163 = icmp ule i32 %local.check.payload.3155, %local.check.extent.3154
  %descriptor.owner.offset.valid.3164 = and i1 %descriptor.owner.inside.3159, %descriptor.offset.inside.3160
  %descriptor.range.inside.3166 = and i1 %descriptor.owner.offset.valid.3164, %descriptor.extent.inside.3162
  %descriptor.range.valid.3165 = and i1 %descriptor.range.inside.3166, %descriptor.payload.inside.3163
  br i1 %descriptor.range.valid.3165, label %descriptor.valid.3167, label %descriptor.invalid.3168
descriptor.invalid.3168:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3167:
  %descriptor.initialized.status.3169 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3153, i32 %local.check.extent.3154)
  %helper.ok.3170 = icmp eq i32 %descriptor.initialized.status.3169, 0
  br i1 %helper.ok.3170, label %helper.continue.3171, label %frame.failure.0
helper.continue.3171:
  br label %local.descriptor.checked.3152
local.descriptor.inactive.3151:
  br label %local.descriptor.checked.3152
local.descriptor.checked.3152:
  %local.is.active.3172 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3172, label %local.descriptor.active.3173, label %local.descriptor.inactive.3174
local.descriptor.active.3173:
  %local.check.offset.3176 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3177 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3178 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3179 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3181 = load i32, ptr %context.field.3180, align 4
  %stack.sub.3184 = sub i32 %local.check.owner.end.3179, %local.check.offset.3176
  %descriptor.owner.inside.3182 = icmp ule i32 %local.check.owner.end.3179, %context.value.3181
  %descriptor.offset.inside.3183 = icmp ule i32 %local.check.offset.3176, %local.check.owner.end.3179
  %descriptor.extent.inside.3185 = icmp ule i32 %local.check.extent.3177, %stack.sub.3184
  %descriptor.payload.inside.3186 = icmp ule i32 %local.check.payload.3178, %local.check.extent.3177
  %descriptor.owner.offset.valid.3187 = and i1 %descriptor.owner.inside.3182, %descriptor.offset.inside.3183
  %descriptor.range.inside.3189 = and i1 %descriptor.owner.offset.valid.3187, %descriptor.extent.inside.3185
  %descriptor.range.valid.3188 = and i1 %descriptor.range.inside.3189, %descriptor.payload.inside.3186
  br i1 %descriptor.range.valid.3188, label %descriptor.valid.3190, label %descriptor.invalid.3191
descriptor.invalid.3191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3190:
  %descriptor.initialized.status.3192 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3176, i32 %local.check.extent.3177)
  %helper.ok.3193 = icmp eq i32 %descriptor.initialized.status.3192, 0
  br i1 %helper.ok.3193, label %helper.continue.3194, label %frame.failure.0
helper.continue.3194:
  br label %local.descriptor.checked.3175
local.descriptor.inactive.3174:
  br label %local.descriptor.checked.3175
local.descriptor.checked.3175:
  %local.is.active.3195 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3195, label %local.descriptor.active.3196, label %local.descriptor.inactive.3197
local.descriptor.active.3196:
  %local.check.offset.3199 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3200 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3201 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3202 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3204 = load i32, ptr %context.field.3203, align 4
  %stack.sub.3207 = sub i32 %local.check.owner.end.3202, %local.check.offset.3199
  %descriptor.owner.inside.3205 = icmp ule i32 %local.check.owner.end.3202, %context.value.3204
  %descriptor.offset.inside.3206 = icmp ule i32 %local.check.offset.3199, %local.check.owner.end.3202
  %descriptor.extent.inside.3208 = icmp ule i32 %local.check.extent.3200, %stack.sub.3207
  %descriptor.payload.inside.3209 = icmp ule i32 %local.check.payload.3201, %local.check.extent.3200
  %descriptor.owner.offset.valid.3210 = and i1 %descriptor.owner.inside.3205, %descriptor.offset.inside.3206
  %descriptor.range.inside.3212 = and i1 %descriptor.owner.offset.valid.3210, %descriptor.extent.inside.3208
  %descriptor.range.valid.3211 = and i1 %descriptor.range.inside.3212, %descriptor.payload.inside.3209
  br i1 %descriptor.range.valid.3211, label %descriptor.valid.3213, label %descriptor.invalid.3214
descriptor.invalid.3214:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3213:
  %descriptor.initialized.status.3215 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3199, i32 %local.check.extent.3200)
  %helper.ok.3216 = icmp eq i32 %descriptor.initialized.status.3215, 0
  br i1 %helper.ok.3216, label %helper.continue.3217, label %frame.failure.0
helper.continue.3217:
  br label %local.descriptor.checked.3198
local.descriptor.inactive.3197:
  br label %local.descriptor.checked.3198
local.descriptor.checked.3198:
  %local.is.active.3218 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3218, label %local.descriptor.active.3219, label %local.descriptor.inactive.3220
local.descriptor.active.3219:
  %local.check.offset.3222 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3223 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3224 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3225 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3227 = load i32, ptr %context.field.3226, align 4
  %stack.sub.3230 = sub i32 %local.check.owner.end.3225, %local.check.offset.3222
  %descriptor.owner.inside.3228 = icmp ule i32 %local.check.owner.end.3225, %context.value.3227
  %descriptor.offset.inside.3229 = icmp ule i32 %local.check.offset.3222, %local.check.owner.end.3225
  %descriptor.extent.inside.3231 = icmp ule i32 %local.check.extent.3223, %stack.sub.3230
  %descriptor.payload.inside.3232 = icmp ule i32 %local.check.payload.3224, %local.check.extent.3223
  %descriptor.owner.offset.valid.3233 = and i1 %descriptor.owner.inside.3228, %descriptor.offset.inside.3229
  %descriptor.range.inside.3235 = and i1 %descriptor.owner.offset.valid.3233, %descriptor.extent.inside.3231
  %descriptor.range.valid.3234 = and i1 %descriptor.range.inside.3235, %descriptor.payload.inside.3232
  br i1 %descriptor.range.valid.3234, label %descriptor.valid.3236, label %descriptor.invalid.3237
descriptor.invalid.3237:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3236:
  %descriptor.initialized.status.3238 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3222, i32 %local.check.extent.3223)
  %helper.ok.3239 = icmp eq i32 %descriptor.initialized.status.3238, 0
  br i1 %helper.ok.3239, label %helper.continue.3240, label %frame.failure.0
helper.continue.3240:
  br label %local.descriptor.checked.3221
local.descriptor.inactive.3220:
  br label %local.descriptor.checked.3221
local.descriptor.checked.3221:
  %local.is.active.3241 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3241, label %local.descriptor.active.3242, label %local.descriptor.inactive.3243
local.descriptor.active.3242:
  %local.check.offset.3245 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3246 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3247 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3248 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3250 = load i32, ptr %context.field.3249, align 4
  %stack.sub.3253 = sub i32 %local.check.owner.end.3248, %local.check.offset.3245
  %descriptor.owner.inside.3251 = icmp ule i32 %local.check.owner.end.3248, %context.value.3250
  %descriptor.offset.inside.3252 = icmp ule i32 %local.check.offset.3245, %local.check.owner.end.3248
  %descriptor.extent.inside.3254 = icmp ule i32 %local.check.extent.3246, %stack.sub.3253
  %descriptor.payload.inside.3255 = icmp ule i32 %local.check.payload.3247, %local.check.extent.3246
  %descriptor.owner.offset.valid.3256 = and i1 %descriptor.owner.inside.3251, %descriptor.offset.inside.3252
  %descriptor.range.inside.3258 = and i1 %descriptor.owner.offset.valid.3256, %descriptor.extent.inside.3254
  %descriptor.range.valid.3257 = and i1 %descriptor.range.inside.3258, %descriptor.payload.inside.3255
  br i1 %descriptor.range.valid.3257, label %descriptor.valid.3259, label %descriptor.invalid.3260
descriptor.invalid.3260:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3259:
  %descriptor.initialized.status.3261 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3245, i32 %local.check.extent.3246)
  %helper.ok.3262 = icmp eq i32 %descriptor.initialized.status.3261, 0
  br i1 %helper.ok.3262, label %helper.continue.3263, label %frame.failure.0
helper.continue.3263:
  br label %local.descriptor.checked.3244
local.descriptor.inactive.3243:
  br label %local.descriptor.checked.3244
local.descriptor.checked.3244:
  %local.is.active.3264 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3264, label %local.descriptor.active.3265, label %local.descriptor.inactive.3266
local.descriptor.active.3265:
  %local.check.offset.3268 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3269 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3270 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3271 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3273 = load i32, ptr %context.field.3272, align 4
  %stack.sub.3276 = sub i32 %local.check.owner.end.3271, %local.check.offset.3268
  %descriptor.owner.inside.3274 = icmp ule i32 %local.check.owner.end.3271, %context.value.3273
  %descriptor.offset.inside.3275 = icmp ule i32 %local.check.offset.3268, %local.check.owner.end.3271
  %descriptor.extent.inside.3277 = icmp ule i32 %local.check.extent.3269, %stack.sub.3276
  %descriptor.payload.inside.3278 = icmp ule i32 %local.check.payload.3270, %local.check.extent.3269
  %descriptor.owner.offset.valid.3279 = and i1 %descriptor.owner.inside.3274, %descriptor.offset.inside.3275
  %descriptor.range.inside.3281 = and i1 %descriptor.owner.offset.valid.3279, %descriptor.extent.inside.3277
  %descriptor.range.valid.3280 = and i1 %descriptor.range.inside.3281, %descriptor.payload.inside.3278
  br i1 %descriptor.range.valid.3280, label %descriptor.valid.3282, label %descriptor.invalid.3283
descriptor.invalid.3283:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3282:
  %descriptor.initialized.status.3284 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3268, i32 %local.check.extent.3269)
  %helper.ok.3285 = icmp eq i32 %descriptor.initialized.status.3284, 0
  br i1 %helper.ok.3285, label %helper.continue.3286, label %frame.failure.0
helper.continue.3286:
  br label %local.descriptor.checked.3267
local.descriptor.inactive.3266:
  br label %local.descriptor.checked.3267
local.descriptor.checked.3267:
  %step.status.3287 = call i32 @al_owning_charge_step(ptr %ctx, i32 51)
  %helper.ok.3288 = icmp eq i32 %step.status.3287, 0
  br i1 %helper.ok.3288, label %helper.continue.3289, label %frame.failure.0
helper.continue.3289:
  %local.resolved.offset.3290 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.3291 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.3292 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.3293 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3294 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3295 = load i32, ptr %context.field.3294, align 4
  %stack.sub.3298 = sub i32 %local.resolved.owner.end.3293, %local.resolved.offset.3290
  %descriptor.owner.inside.3296 = icmp ule i32 %local.resolved.owner.end.3293, %context.value.3295
  %descriptor.offset.inside.3297 = icmp ule i32 %local.resolved.offset.3290, %local.resolved.owner.end.3293
  %descriptor.extent.inside.3299 = icmp ule i32 %local.resolved.extent.3291, %stack.sub.3298
  %descriptor.payload.inside.3300 = icmp ule i32 %local.resolved.payload.3292, %local.resolved.extent.3291
  %descriptor.owner.offset.valid.3301 = and i1 %descriptor.owner.inside.3296, %descriptor.offset.inside.3297
  %descriptor.range.inside.3303 = and i1 %descriptor.owner.offset.valid.3301, %descriptor.extent.inside.3299
  %descriptor.range.valid.3302 = and i1 %descriptor.range.inside.3303, %descriptor.payload.inside.3300
  %descriptor.type.valid.3304 = icmp eq i32 4, 4
  %descriptor.valid.3305 = and i1 %descriptor.range.valid.3302, %descriptor.type.valid.3304
  br i1 %descriptor.valid.3305, label %descriptor.valid.3306, label %descriptor.invalid.3307
descriptor.invalid.3307:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3306:
  %descriptor.initialized.status.3308 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3290, i32 %local.resolved.extent.3291)
  %helper.ok.3309 = icmp eq i32 %descriptor.initialized.status.3308, 0
  br i1 %helper.ok.3309, label %helper.continue.3310, label %frame.failure.0
helper.continue.3310:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.3290, i32 20, i32 %local.resolved.payload.3292, i32 %local.resolved.owner.end.3293, i32 %local.resolved.extent.3291)
  %context.field.3311 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3312 = load i32, ptr %context.field.3311, align 4
  %runtime.ok.3313 = icmp eq i32 %context.value.3312, 0
  br i1 %runtime.ok.3313, label %runtime.continue.3314, label %frame.failure.0
runtime.continue.3314:
  %context.field.3315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3316 = load i32, ptr %context.field.3315, align 4
  %stack.sub.3319 = sub i32 %local.resolved.owner.end.2892, %field.offset.3100
  %descriptor.owner.inside.3317 = icmp ule i32 %local.resolved.owner.end.2892, %context.value.3316
  %descriptor.offset.inside.3318 = icmp ule i32 %field.offset.3100, %local.resolved.owner.end.2892
  %descriptor.extent.inside.3320 = icmp ule i32 %field.extent.3104, %stack.sub.3319
  %descriptor.payload.inside.3321 = icmp ule i32 %field.payload.3102, %field.extent.3104
  %descriptor.owner.offset.valid.3322 = and i1 %descriptor.owner.inside.3317, %descriptor.offset.inside.3318
  %descriptor.range.inside.3324 = and i1 %descriptor.owner.offset.valid.3322, %descriptor.extent.inside.3320
  %descriptor.range.valid.3323 = and i1 %descriptor.range.inside.3324, %descriptor.payload.inside.3321
  %descriptor.type.valid.3325 = icmp eq i32 6, 6
  %descriptor.valid.3326 = and i1 %descriptor.range.valid.3323, %descriptor.type.valid.3325
  br i1 %descriptor.valid.3326, label %descriptor.valid.3327, label %descriptor.invalid.3328
descriptor.invalid.3328:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3327:
  %descriptor.initialized.status.3329 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3100, i32 %field.extent.3104)
  %helper.ok.3330 = icmp eq i32 %descriptor.initialized.status.3329, 0
  br i1 %helper.ok.3330, label %helper.continue.3331, label %frame.failure.0
helper.continue.3331:
  %context.field.3332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3333 = load i32, ptr %context.field.3332, align 4
  %stack.sub.3336 = sub i32 %local.resolved.owner.end.3293, %local.resolved.offset.3290
  %descriptor.owner.inside.3334 = icmp ule i32 %local.resolved.owner.end.3293, %context.value.3333
  %descriptor.offset.inside.3335 = icmp ule i32 %local.resolved.offset.3290, %local.resolved.owner.end.3293
  %descriptor.extent.inside.3337 = icmp ule i32 %local.resolved.extent.3291, %stack.sub.3336
  %descriptor.payload.inside.3338 = icmp ule i32 %local.resolved.payload.3292, %local.resolved.extent.3291
  %descriptor.owner.offset.valid.3339 = and i1 %descriptor.owner.inside.3334, %descriptor.offset.inside.3335
  %descriptor.range.inside.3341 = and i1 %descriptor.owner.offset.valid.3339, %descriptor.extent.inside.3337
  %descriptor.range.valid.3340 = and i1 %descriptor.range.inside.3341, %descriptor.payload.inside.3338
  %descriptor.type.valid.3342 = icmp eq i32 4, 4
  %descriptor.valid.3343 = and i1 %descriptor.range.valid.3340, %descriptor.type.valid.3342
  br i1 %descriptor.valid.3343, label %descriptor.valid.3344, label %descriptor.invalid.3345
descriptor.invalid.3345:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3344:
  %descriptor.initialized.status.3346 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3290, i32 %local.resolved.extent.3291)
  %helper.ok.3347 = icmp eq i32 %descriptor.initialized.status.3346, 0
  br i1 %helper.ok.3347, label %helper.continue.3348, label %frame.failure.0
helper.continue.3348:
  %local.is.active.3349 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3349, label %local.descriptor.active.3350, label %local.descriptor.inactive.3351
local.descriptor.active.3350:
  %local.check.offset.3353 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3354 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3355 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3356 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3358 = load i32, ptr %context.field.3357, align 4
  %stack.sub.3361 = sub i32 %local.check.owner.end.3356, %local.check.offset.3353
  %descriptor.owner.inside.3359 = icmp ule i32 %local.check.owner.end.3356, %context.value.3358
  %descriptor.offset.inside.3360 = icmp ule i32 %local.check.offset.3353, %local.check.owner.end.3356
  %descriptor.extent.inside.3362 = icmp ule i32 %local.check.extent.3354, %stack.sub.3361
  %descriptor.payload.inside.3363 = icmp ule i32 %local.check.payload.3355, %local.check.extent.3354
  %descriptor.owner.offset.valid.3364 = and i1 %descriptor.owner.inside.3359, %descriptor.offset.inside.3360
  %descriptor.range.inside.3366 = and i1 %descriptor.owner.offset.valid.3364, %descriptor.extent.inside.3362
  %descriptor.range.valid.3365 = and i1 %descriptor.range.inside.3366, %descriptor.payload.inside.3363
  br i1 %descriptor.range.valid.3365, label %descriptor.valid.3367, label %descriptor.invalid.3368
descriptor.invalid.3368:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3367:
  %descriptor.initialized.status.3369 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3353, i32 %local.check.extent.3354)
  %helper.ok.3370 = icmp eq i32 %descriptor.initialized.status.3369, 0
  br i1 %helper.ok.3370, label %helper.continue.3371, label %frame.failure.0
helper.continue.3371:
  br label %local.descriptor.checked.3352
local.descriptor.inactive.3351:
  br label %local.descriptor.checked.3352
local.descriptor.checked.3352:
  %local.is.active.3372 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3372, label %local.descriptor.active.3373, label %local.descriptor.inactive.3374
local.descriptor.active.3373:
  %local.check.offset.3376 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3377 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3378 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3379 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3380 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3381 = load i32, ptr %context.field.3380, align 4
  %stack.sub.3384 = sub i32 %local.check.owner.end.3379, %local.check.offset.3376
  %descriptor.owner.inside.3382 = icmp ule i32 %local.check.owner.end.3379, %context.value.3381
  %descriptor.offset.inside.3383 = icmp ule i32 %local.check.offset.3376, %local.check.owner.end.3379
  %descriptor.extent.inside.3385 = icmp ule i32 %local.check.extent.3377, %stack.sub.3384
  %descriptor.payload.inside.3386 = icmp ule i32 %local.check.payload.3378, %local.check.extent.3377
  %descriptor.owner.offset.valid.3387 = and i1 %descriptor.owner.inside.3382, %descriptor.offset.inside.3383
  %descriptor.range.inside.3389 = and i1 %descriptor.owner.offset.valid.3387, %descriptor.extent.inside.3385
  %descriptor.range.valid.3388 = and i1 %descriptor.range.inside.3389, %descriptor.payload.inside.3386
  br i1 %descriptor.range.valid.3388, label %descriptor.valid.3390, label %descriptor.invalid.3391
descriptor.invalid.3391:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3390:
  %descriptor.initialized.status.3392 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3376, i32 %local.check.extent.3377)
  %helper.ok.3393 = icmp eq i32 %descriptor.initialized.status.3392, 0
  br i1 %helper.ok.3393, label %helper.continue.3394, label %frame.failure.0
helper.continue.3394:
  br label %local.descriptor.checked.3375
local.descriptor.inactive.3374:
  br label %local.descriptor.checked.3375
local.descriptor.checked.3375:
  %local.is.active.3395 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3395, label %local.descriptor.active.3396, label %local.descriptor.inactive.3397
local.descriptor.active.3396:
  %local.check.offset.3399 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3400 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3401 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3402 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3403 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3404 = load i32, ptr %context.field.3403, align 4
  %stack.sub.3407 = sub i32 %local.check.owner.end.3402, %local.check.offset.3399
  %descriptor.owner.inside.3405 = icmp ule i32 %local.check.owner.end.3402, %context.value.3404
  %descriptor.offset.inside.3406 = icmp ule i32 %local.check.offset.3399, %local.check.owner.end.3402
  %descriptor.extent.inside.3408 = icmp ule i32 %local.check.extent.3400, %stack.sub.3407
  %descriptor.payload.inside.3409 = icmp ule i32 %local.check.payload.3401, %local.check.extent.3400
  %descriptor.owner.offset.valid.3410 = and i1 %descriptor.owner.inside.3405, %descriptor.offset.inside.3406
  %descriptor.range.inside.3412 = and i1 %descriptor.owner.offset.valid.3410, %descriptor.extent.inside.3408
  %descriptor.range.valid.3411 = and i1 %descriptor.range.inside.3412, %descriptor.payload.inside.3409
  br i1 %descriptor.range.valid.3411, label %descriptor.valid.3413, label %descriptor.invalid.3414
descriptor.invalid.3414:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3413:
  %descriptor.initialized.status.3415 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3399, i32 %local.check.extent.3400)
  %helper.ok.3416 = icmp eq i32 %descriptor.initialized.status.3415, 0
  br i1 %helper.ok.3416, label %helper.continue.3417, label %frame.failure.0
helper.continue.3417:
  br label %local.descriptor.checked.3398
local.descriptor.inactive.3397:
  br label %local.descriptor.checked.3398
local.descriptor.checked.3398:
  %local.is.active.3418 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3418, label %local.descriptor.active.3419, label %local.descriptor.inactive.3420
local.descriptor.active.3419:
  %local.check.offset.3422 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3423 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3424 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3425 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3426 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3427 = load i32, ptr %context.field.3426, align 4
  %stack.sub.3430 = sub i32 %local.check.owner.end.3425, %local.check.offset.3422
  %descriptor.owner.inside.3428 = icmp ule i32 %local.check.owner.end.3425, %context.value.3427
  %descriptor.offset.inside.3429 = icmp ule i32 %local.check.offset.3422, %local.check.owner.end.3425
  %descriptor.extent.inside.3431 = icmp ule i32 %local.check.extent.3423, %stack.sub.3430
  %descriptor.payload.inside.3432 = icmp ule i32 %local.check.payload.3424, %local.check.extent.3423
  %descriptor.owner.offset.valid.3433 = and i1 %descriptor.owner.inside.3428, %descriptor.offset.inside.3429
  %descriptor.range.inside.3435 = and i1 %descriptor.owner.offset.valid.3433, %descriptor.extent.inside.3431
  %descriptor.range.valid.3434 = and i1 %descriptor.range.inside.3435, %descriptor.payload.inside.3432
  br i1 %descriptor.range.valid.3434, label %descriptor.valid.3436, label %descriptor.invalid.3437
descriptor.invalid.3437:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3436:
  %descriptor.initialized.status.3438 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3422, i32 %local.check.extent.3423)
  %helper.ok.3439 = icmp eq i32 %descriptor.initialized.status.3438, 0
  br i1 %helper.ok.3439, label %helper.continue.3440, label %frame.failure.0
helper.continue.3440:
  br label %local.descriptor.checked.3421
local.descriptor.inactive.3420:
  br label %local.descriptor.checked.3421
local.descriptor.checked.3421:
  %local.is.active.3441 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3441, label %local.descriptor.active.3442, label %local.descriptor.inactive.3443
local.descriptor.active.3442:
  %local.check.offset.3445 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3446 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3447 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3448 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3450 = load i32, ptr %context.field.3449, align 4
  %stack.sub.3453 = sub i32 %local.check.owner.end.3448, %local.check.offset.3445
  %descriptor.owner.inside.3451 = icmp ule i32 %local.check.owner.end.3448, %context.value.3450
  %descriptor.offset.inside.3452 = icmp ule i32 %local.check.offset.3445, %local.check.owner.end.3448
  %descriptor.extent.inside.3454 = icmp ule i32 %local.check.extent.3446, %stack.sub.3453
  %descriptor.payload.inside.3455 = icmp ule i32 %local.check.payload.3447, %local.check.extent.3446
  %descriptor.owner.offset.valid.3456 = and i1 %descriptor.owner.inside.3451, %descriptor.offset.inside.3452
  %descriptor.range.inside.3458 = and i1 %descriptor.owner.offset.valid.3456, %descriptor.extent.inside.3454
  %descriptor.range.valid.3457 = and i1 %descriptor.range.inside.3458, %descriptor.payload.inside.3455
  br i1 %descriptor.range.valid.3457, label %descriptor.valid.3459, label %descriptor.invalid.3460
descriptor.invalid.3460:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3459:
  %descriptor.initialized.status.3461 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3445, i32 %local.check.extent.3446)
  %helper.ok.3462 = icmp eq i32 %descriptor.initialized.status.3461, 0
  br i1 %helper.ok.3462, label %helper.continue.3463, label %frame.failure.0
helper.continue.3463:
  br label %local.descriptor.checked.3444
local.descriptor.inactive.3443:
  br label %local.descriptor.checked.3444
local.descriptor.checked.3444:
  %local.is.active.3464 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3464, label %local.descriptor.active.3465, label %local.descriptor.inactive.3466
local.descriptor.active.3465:
  %local.check.offset.3468 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3469 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3470 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3471 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3473 = load i32, ptr %context.field.3472, align 4
  %stack.sub.3476 = sub i32 %local.check.owner.end.3471, %local.check.offset.3468
  %descriptor.owner.inside.3474 = icmp ule i32 %local.check.owner.end.3471, %context.value.3473
  %descriptor.offset.inside.3475 = icmp ule i32 %local.check.offset.3468, %local.check.owner.end.3471
  %descriptor.extent.inside.3477 = icmp ule i32 %local.check.extent.3469, %stack.sub.3476
  %descriptor.payload.inside.3478 = icmp ule i32 %local.check.payload.3470, %local.check.extent.3469
  %descriptor.owner.offset.valid.3479 = and i1 %descriptor.owner.inside.3474, %descriptor.offset.inside.3475
  %descriptor.range.inside.3481 = and i1 %descriptor.owner.offset.valid.3479, %descriptor.extent.inside.3477
  %descriptor.range.valid.3480 = and i1 %descriptor.range.inside.3481, %descriptor.payload.inside.3478
  br i1 %descriptor.range.valid.3480, label %descriptor.valid.3482, label %descriptor.invalid.3483
descriptor.invalid.3483:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3482:
  %descriptor.initialized.status.3484 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3468, i32 %local.check.extent.3469)
  %helper.ok.3485 = icmp eq i32 %descriptor.initialized.status.3484, 0
  br i1 %helper.ok.3485, label %helper.continue.3486, label %frame.failure.0
helper.continue.3486:
  br label %local.descriptor.checked.3467
local.descriptor.inactive.3466:
  br label %local.descriptor.checked.3467
local.descriptor.checked.3467:
  %local.is.active.3487 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3487, label %local.descriptor.active.3488, label %local.descriptor.inactive.3489
local.descriptor.active.3488:
  %local.check.offset.3491 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3492 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3493 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3494 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3495 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3496 = load i32, ptr %context.field.3495, align 4
  %stack.sub.3499 = sub i32 %local.check.owner.end.3494, %local.check.offset.3491
  %descriptor.owner.inside.3497 = icmp ule i32 %local.check.owner.end.3494, %context.value.3496
  %descriptor.offset.inside.3498 = icmp ule i32 %local.check.offset.3491, %local.check.owner.end.3494
  %descriptor.extent.inside.3500 = icmp ule i32 %local.check.extent.3492, %stack.sub.3499
  %descriptor.payload.inside.3501 = icmp ule i32 %local.check.payload.3493, %local.check.extent.3492
  %descriptor.owner.offset.valid.3502 = and i1 %descriptor.owner.inside.3497, %descriptor.offset.inside.3498
  %descriptor.range.inside.3504 = and i1 %descriptor.owner.offset.valid.3502, %descriptor.extent.inside.3500
  %descriptor.range.valid.3503 = and i1 %descriptor.range.inside.3504, %descriptor.payload.inside.3501
  br i1 %descriptor.range.valid.3503, label %descriptor.valid.3505, label %descriptor.invalid.3506
descriptor.invalid.3506:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3505:
  %descriptor.initialized.status.3507 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3491, i32 %local.check.extent.3492)
  %helper.ok.3508 = icmp eq i32 %descriptor.initialized.status.3507, 0
  br i1 %helper.ok.3508, label %helper.continue.3509, label %frame.failure.0
helper.continue.3509:
  br label %local.descriptor.checked.3490
local.descriptor.inactive.3489:
  br label %local.descriptor.checked.3490
local.descriptor.checked.3490:
  %step.status.3510 = call i32 @al_owning_charge_step(ptr %ctx, i32 52)
  %helper.ok.3511 = icmp eq i32 %step.status.3510, 0
  br i1 %helper.ok.3511, label %helper.continue.3512, label %frame.failure.0
helper.continue.3512:
  %field.location.3513 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.3514 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %local.resolved.offset.3290, i32 %local.resolved.extent.3291, i32 0, i32 53, ptr %field.location.3513)
  %helper.ok.3515 = icmp eq i32 %field.location.status.3514, 0
  br i1 %helper.ok.3515, label %helper.continue.3516, label %frame.failure.0
helper.continue.3516:
  %field.offset.pointer.3517 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3513, i32 0, i32 0
  %field.offset.3518 = load i32, ptr %field.offset.pointer.3517, align 4
  %field.payload.pointer.3519 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3513, i32 0, i32 1
  %field.payload.3520 = load i32, ptr %field.payload.pointer.3519, align 4
  %field.extent.pointer.3521 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3513, i32 0, i32 2
  %field.extent.3522 = load i32, ptr %field.extent.pointer.3521, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 6, i32 %local.resolved.offset.3290, i32 %field.extent.3522, i32 %field.payload.3520, i32 %field.offset.3518, i32 %field.extent.3522)
  %context.field.3523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3524 = load i32, ptr %context.field.3523, align 4
  %runtime.ok.3525 = icmp eq i32 %context.value.3524, 0
  br i1 %runtime.ok.3525, label %runtime.continue.3526, label %frame.failure.0
runtime.continue.3526:
  %context.field.3527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3528 = load i32, ptr %context.field.3527, align 4
  %stack.sub.3531 = sub i32 %local.resolved.owner.end.2892, %field.offset.3100
  %descriptor.owner.inside.3529 = icmp ule i32 %local.resolved.owner.end.2892, %context.value.3528
  %descriptor.offset.inside.3530 = icmp ule i32 %field.offset.3100, %local.resolved.owner.end.2892
  %descriptor.extent.inside.3532 = icmp ule i32 %field.extent.3104, %stack.sub.3531
  %descriptor.payload.inside.3533 = icmp ule i32 %field.payload.3102, %field.extent.3104
  %descriptor.owner.offset.valid.3534 = and i1 %descriptor.owner.inside.3529, %descriptor.offset.inside.3530
  %descriptor.range.inside.3536 = and i1 %descriptor.owner.offset.valid.3534, %descriptor.extent.inside.3532
  %descriptor.range.valid.3535 = and i1 %descriptor.range.inside.3536, %descriptor.payload.inside.3533
  %descriptor.type.valid.3537 = icmp eq i32 6, 6
  %descriptor.valid.3538 = and i1 %descriptor.range.valid.3535, %descriptor.type.valid.3537
  br i1 %descriptor.valid.3538, label %descriptor.valid.3539, label %descriptor.invalid.3540
descriptor.invalid.3540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3539:
  %descriptor.initialized.status.3541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3100, i32 %field.extent.3104)
  %helper.ok.3542 = icmp eq i32 %descriptor.initialized.status.3541, 0
  br i1 %helper.ok.3542, label %helper.continue.3543, label %frame.failure.0
helper.continue.3543:
  %context.field.3544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3545 = load i32, ptr %context.field.3544, align 4
  %stack.sub.3548 = sub i32 %local.resolved.owner.end.3293, %field.offset.3518
  %descriptor.owner.inside.3546 = icmp ule i32 %local.resolved.owner.end.3293, %context.value.3545
  %descriptor.offset.inside.3547 = icmp ule i32 %field.offset.3518, %local.resolved.owner.end.3293
  %descriptor.extent.inside.3549 = icmp ule i32 %field.extent.3522, %stack.sub.3548
  %descriptor.payload.inside.3550 = icmp ule i32 %field.payload.3520, %field.extent.3522
  %descriptor.owner.offset.valid.3551 = and i1 %descriptor.owner.inside.3546, %descriptor.offset.inside.3547
  %descriptor.range.inside.3553 = and i1 %descriptor.owner.offset.valid.3551, %descriptor.extent.inside.3549
  %descriptor.range.valid.3552 = and i1 %descriptor.range.inside.3553, %descriptor.payload.inside.3550
  %descriptor.type.valid.3554 = icmp eq i32 6, 6
  %descriptor.valid.3555 = and i1 %descriptor.range.valid.3552, %descriptor.type.valid.3554
  br i1 %descriptor.valid.3555, label %descriptor.valid.3556, label %descriptor.invalid.3557
descriptor.invalid.3557:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3556:
  %descriptor.initialized.status.3558 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3518, i32 %field.extent.3522)
  %helper.ok.3559 = icmp eq i32 %descriptor.initialized.status.3558, 0
  br i1 %helper.ok.3559, label %helper.continue.3560, label %frame.failure.0
helper.continue.3560:
  %local.is.active.3561 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3561, label %local.descriptor.active.3562, label %local.descriptor.inactive.3563
local.descriptor.active.3562:
  %local.check.offset.3565 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3566 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3567 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3568 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3570 = load i32, ptr %context.field.3569, align 4
  %stack.sub.3573 = sub i32 %local.check.owner.end.3568, %local.check.offset.3565
  %descriptor.owner.inside.3571 = icmp ule i32 %local.check.owner.end.3568, %context.value.3570
  %descriptor.offset.inside.3572 = icmp ule i32 %local.check.offset.3565, %local.check.owner.end.3568
  %descriptor.extent.inside.3574 = icmp ule i32 %local.check.extent.3566, %stack.sub.3573
  %descriptor.payload.inside.3575 = icmp ule i32 %local.check.payload.3567, %local.check.extent.3566
  %descriptor.owner.offset.valid.3576 = and i1 %descriptor.owner.inside.3571, %descriptor.offset.inside.3572
  %descriptor.range.inside.3578 = and i1 %descriptor.owner.offset.valid.3576, %descriptor.extent.inside.3574
  %descriptor.range.valid.3577 = and i1 %descriptor.range.inside.3578, %descriptor.payload.inside.3575
  br i1 %descriptor.range.valid.3577, label %descriptor.valid.3579, label %descriptor.invalid.3580
descriptor.invalid.3580:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3579:
  %descriptor.initialized.status.3581 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3565, i32 %local.check.extent.3566)
  %helper.ok.3582 = icmp eq i32 %descriptor.initialized.status.3581, 0
  br i1 %helper.ok.3582, label %helper.continue.3583, label %frame.failure.0
helper.continue.3583:
  br label %local.descriptor.checked.3564
local.descriptor.inactive.3563:
  br label %local.descriptor.checked.3564
local.descriptor.checked.3564:
  %local.is.active.3584 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3584, label %local.descriptor.active.3585, label %local.descriptor.inactive.3586
local.descriptor.active.3585:
  %local.check.offset.3588 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3589 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3590 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3591 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3592 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3593 = load i32, ptr %context.field.3592, align 4
  %stack.sub.3596 = sub i32 %local.check.owner.end.3591, %local.check.offset.3588
  %descriptor.owner.inside.3594 = icmp ule i32 %local.check.owner.end.3591, %context.value.3593
  %descriptor.offset.inside.3595 = icmp ule i32 %local.check.offset.3588, %local.check.owner.end.3591
  %descriptor.extent.inside.3597 = icmp ule i32 %local.check.extent.3589, %stack.sub.3596
  %descriptor.payload.inside.3598 = icmp ule i32 %local.check.payload.3590, %local.check.extent.3589
  %descriptor.owner.offset.valid.3599 = and i1 %descriptor.owner.inside.3594, %descriptor.offset.inside.3595
  %descriptor.range.inside.3601 = and i1 %descriptor.owner.offset.valid.3599, %descriptor.extent.inside.3597
  %descriptor.range.valid.3600 = and i1 %descriptor.range.inside.3601, %descriptor.payload.inside.3598
  br i1 %descriptor.range.valid.3600, label %descriptor.valid.3602, label %descriptor.invalid.3603
descriptor.invalid.3603:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3602:
  %descriptor.initialized.status.3604 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3588, i32 %local.check.extent.3589)
  %helper.ok.3605 = icmp eq i32 %descriptor.initialized.status.3604, 0
  br i1 %helper.ok.3605, label %helper.continue.3606, label %frame.failure.0
helper.continue.3606:
  br label %local.descriptor.checked.3587
local.descriptor.inactive.3586:
  br label %local.descriptor.checked.3587
local.descriptor.checked.3587:
  %local.is.active.3607 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3607, label %local.descriptor.active.3608, label %local.descriptor.inactive.3609
local.descriptor.active.3608:
  %local.check.offset.3611 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3612 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3613 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3614 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3615 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3616 = load i32, ptr %context.field.3615, align 4
  %stack.sub.3619 = sub i32 %local.check.owner.end.3614, %local.check.offset.3611
  %descriptor.owner.inside.3617 = icmp ule i32 %local.check.owner.end.3614, %context.value.3616
  %descriptor.offset.inside.3618 = icmp ule i32 %local.check.offset.3611, %local.check.owner.end.3614
  %descriptor.extent.inside.3620 = icmp ule i32 %local.check.extent.3612, %stack.sub.3619
  %descriptor.payload.inside.3621 = icmp ule i32 %local.check.payload.3613, %local.check.extent.3612
  %descriptor.owner.offset.valid.3622 = and i1 %descriptor.owner.inside.3617, %descriptor.offset.inside.3618
  %descriptor.range.inside.3624 = and i1 %descriptor.owner.offset.valid.3622, %descriptor.extent.inside.3620
  %descriptor.range.valid.3623 = and i1 %descriptor.range.inside.3624, %descriptor.payload.inside.3621
  br i1 %descriptor.range.valid.3623, label %descriptor.valid.3625, label %descriptor.invalid.3626
descriptor.invalid.3626:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3625:
  %descriptor.initialized.status.3627 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3611, i32 %local.check.extent.3612)
  %helper.ok.3628 = icmp eq i32 %descriptor.initialized.status.3627, 0
  br i1 %helper.ok.3628, label %helper.continue.3629, label %frame.failure.0
helper.continue.3629:
  br label %local.descriptor.checked.3610
local.descriptor.inactive.3609:
  br label %local.descriptor.checked.3610
local.descriptor.checked.3610:
  %local.is.active.3630 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3630, label %local.descriptor.active.3631, label %local.descriptor.inactive.3632
local.descriptor.active.3631:
  %local.check.offset.3634 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3635 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3636 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3637 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3638 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3639 = load i32, ptr %context.field.3638, align 4
  %stack.sub.3642 = sub i32 %local.check.owner.end.3637, %local.check.offset.3634
  %descriptor.owner.inside.3640 = icmp ule i32 %local.check.owner.end.3637, %context.value.3639
  %descriptor.offset.inside.3641 = icmp ule i32 %local.check.offset.3634, %local.check.owner.end.3637
  %descriptor.extent.inside.3643 = icmp ule i32 %local.check.extent.3635, %stack.sub.3642
  %descriptor.payload.inside.3644 = icmp ule i32 %local.check.payload.3636, %local.check.extent.3635
  %descriptor.owner.offset.valid.3645 = and i1 %descriptor.owner.inside.3640, %descriptor.offset.inside.3641
  %descriptor.range.inside.3647 = and i1 %descriptor.owner.offset.valid.3645, %descriptor.extent.inside.3643
  %descriptor.range.valid.3646 = and i1 %descriptor.range.inside.3647, %descriptor.payload.inside.3644
  br i1 %descriptor.range.valid.3646, label %descriptor.valid.3648, label %descriptor.invalid.3649
descriptor.invalid.3649:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3648:
  %descriptor.initialized.status.3650 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3634, i32 %local.check.extent.3635)
  %helper.ok.3651 = icmp eq i32 %descriptor.initialized.status.3650, 0
  br i1 %helper.ok.3651, label %helper.continue.3652, label %frame.failure.0
helper.continue.3652:
  br label %local.descriptor.checked.3633
local.descriptor.inactive.3632:
  br label %local.descriptor.checked.3633
local.descriptor.checked.3633:
  %local.is.active.3653 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3653, label %local.descriptor.active.3654, label %local.descriptor.inactive.3655
local.descriptor.active.3654:
  %local.check.offset.3657 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3658 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3659 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3660 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3662 = load i32, ptr %context.field.3661, align 4
  %stack.sub.3665 = sub i32 %local.check.owner.end.3660, %local.check.offset.3657
  %descriptor.owner.inside.3663 = icmp ule i32 %local.check.owner.end.3660, %context.value.3662
  %descriptor.offset.inside.3664 = icmp ule i32 %local.check.offset.3657, %local.check.owner.end.3660
  %descriptor.extent.inside.3666 = icmp ule i32 %local.check.extent.3658, %stack.sub.3665
  %descriptor.payload.inside.3667 = icmp ule i32 %local.check.payload.3659, %local.check.extent.3658
  %descriptor.owner.offset.valid.3668 = and i1 %descriptor.owner.inside.3663, %descriptor.offset.inside.3664
  %descriptor.range.inside.3670 = and i1 %descriptor.owner.offset.valid.3668, %descriptor.extent.inside.3666
  %descriptor.range.valid.3669 = and i1 %descriptor.range.inside.3670, %descriptor.payload.inside.3667
  br i1 %descriptor.range.valid.3669, label %descriptor.valid.3671, label %descriptor.invalid.3672
descriptor.invalid.3672:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3671:
  %descriptor.initialized.status.3673 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3657, i32 %local.check.extent.3658)
  %helper.ok.3674 = icmp eq i32 %descriptor.initialized.status.3673, 0
  br i1 %helper.ok.3674, label %helper.continue.3675, label %frame.failure.0
helper.continue.3675:
  br label %local.descriptor.checked.3656
local.descriptor.inactive.3655:
  br label %local.descriptor.checked.3656
local.descriptor.checked.3656:
  %local.is.active.3676 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3676, label %local.descriptor.active.3677, label %local.descriptor.inactive.3678
local.descriptor.active.3677:
  %local.check.offset.3680 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3681 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3682 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3683 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3685 = load i32, ptr %context.field.3684, align 4
  %stack.sub.3688 = sub i32 %local.check.owner.end.3683, %local.check.offset.3680
  %descriptor.owner.inside.3686 = icmp ule i32 %local.check.owner.end.3683, %context.value.3685
  %descriptor.offset.inside.3687 = icmp ule i32 %local.check.offset.3680, %local.check.owner.end.3683
  %descriptor.extent.inside.3689 = icmp ule i32 %local.check.extent.3681, %stack.sub.3688
  %descriptor.payload.inside.3690 = icmp ule i32 %local.check.payload.3682, %local.check.extent.3681
  %descriptor.owner.offset.valid.3691 = and i1 %descriptor.owner.inside.3686, %descriptor.offset.inside.3687
  %descriptor.range.inside.3693 = and i1 %descriptor.owner.offset.valid.3691, %descriptor.extent.inside.3689
  %descriptor.range.valid.3692 = and i1 %descriptor.range.inside.3693, %descriptor.payload.inside.3690
  br i1 %descriptor.range.valid.3692, label %descriptor.valid.3694, label %descriptor.invalid.3695
descriptor.invalid.3695:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3694:
  %descriptor.initialized.status.3696 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3680, i32 %local.check.extent.3681)
  %helper.ok.3697 = icmp eq i32 %descriptor.initialized.status.3696, 0
  br i1 %helper.ok.3697, label %helper.continue.3698, label %frame.failure.0
helper.continue.3698:
  br label %local.descriptor.checked.3679
local.descriptor.inactive.3678:
  br label %local.descriptor.checked.3679
local.descriptor.checked.3679:
  %local.is.active.3699 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3699, label %local.descriptor.active.3700, label %local.descriptor.inactive.3701
local.descriptor.active.3700:
  %local.check.offset.3703 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3704 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3705 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3706 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3708 = load i32, ptr %context.field.3707, align 4
  %stack.sub.3711 = sub i32 %local.check.owner.end.3706, %local.check.offset.3703
  %descriptor.owner.inside.3709 = icmp ule i32 %local.check.owner.end.3706, %context.value.3708
  %descriptor.offset.inside.3710 = icmp ule i32 %local.check.offset.3703, %local.check.owner.end.3706
  %descriptor.extent.inside.3712 = icmp ule i32 %local.check.extent.3704, %stack.sub.3711
  %descriptor.payload.inside.3713 = icmp ule i32 %local.check.payload.3705, %local.check.extent.3704
  %descriptor.owner.offset.valid.3714 = and i1 %descriptor.owner.inside.3709, %descriptor.offset.inside.3710
  %descriptor.range.inside.3716 = and i1 %descriptor.owner.offset.valid.3714, %descriptor.extent.inside.3712
  %descriptor.range.valid.3715 = and i1 %descriptor.range.inside.3716, %descriptor.payload.inside.3713
  br i1 %descriptor.range.valid.3715, label %descriptor.valid.3717, label %descriptor.invalid.3718
descriptor.invalid.3718:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3717:
  %descriptor.initialized.status.3719 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3703, i32 %local.check.extent.3704)
  %helper.ok.3720 = icmp eq i32 %descriptor.initialized.status.3719, 0
  br i1 %helper.ok.3720, label %helper.continue.3721, label %frame.failure.0
helper.continue.3721:
  br label %local.descriptor.checked.3702
local.descriptor.inactive.3701:
  br label %local.descriptor.checked.3702
local.descriptor.checked.3702:
  %step.status.3722 = call i32 @al_owning_charge_step(ptr %ctx, i32 54)
  %helper.ok.3723 = icmp eq i32 %step.status.3722, 0
  br i1 %helper.ok.3723, label %helper.continue.3724, label %frame.failure.0
helper.continue.3724:
  %context.field.3725 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3726 = load i32, ptr %context.field.3725, align 4
  %string.concat.units.3727 = alloca i32, align 4
  %string.concat.payload.pointer.3728 = alloca i32, align 4
  %string.concat.extent.pointer.3729 = alloca i32, align 4
  %string.concat.plan.status.3730 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %field.offset.3100, i32 %field.extent.3104, i32 %field.offset.3518, i32 %field.extent.3522, i32 55, ptr %string.concat.units.3727, ptr %string.concat.payload.pointer.3728, ptr %string.concat.extent.pointer.3729)
  %helper.ok.3731 = icmp eq i32 %string.concat.plan.status.3730, 0
  br i1 %helper.ok.3731, label %helper.continue.3732, label %frame.failure.0
helper.continue.3732:
  %string.concat.payload.3733 = load i32, ptr %string.concat.payload.pointer.3728, align 4
  %string.concat.extent.3734 = load i32, ptr %string.concat.extent.pointer.3729, align 4
  %stack.offset.3735 = add i32 %context.value.3726, %string.concat.extent.3734
  %reserve.status.3736 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3735, i32 56)
  %reserve.ok.3737 = icmp eq i32 %reserve.status.3736, 0
  br i1 %reserve.ok.3737, label %reserve.continue.3738, label %frame.failure.0
reserve.continue.3738:
  %string.concat.write.status.3739 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.3726, i32 %string.concat.extent.3734, i32 %field.offset.3100, i32 %field.extent.3104, i32 %field.offset.3518, i32 %field.extent.3522, i32 6, i32 55)
  %helper.ok.3740 = icmp eq i32 %string.concat.write.status.3739, 0
  br i1 %helper.ok.3740, label %helper.continue.3741, label %frame.failure.0
helper.continue.3741:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.3733, i32 0)
  %context.field.3742 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3743 = load i32, ptr %context.field.3742, align 4
  %runtime.ok.3744 = icmp eq i32 %context.value.3743, 0
  br i1 %runtime.ok.3744, label %runtime.continue.3745, label %frame.failure.0
runtime.continue.3745:
  %context.field.3746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3747 = load i32, ptr %context.field.3746, align 4
  %stack.sub.3750 = sub i32 %stack.offset.3735, %context.value.3726
  %descriptor.owner.inside.3748 = icmp ule i32 %stack.offset.3735, %context.value.3747
  %descriptor.offset.inside.3749 = icmp ule i32 %context.value.3726, %stack.offset.3735
  %descriptor.extent.inside.3751 = icmp ule i32 %string.concat.extent.3734, %stack.sub.3750
  %descriptor.payload.inside.3752 = icmp ule i32 %string.concat.payload.3733, %string.concat.extent.3734
  %descriptor.owner.offset.valid.3753 = and i1 %descriptor.owner.inside.3748, %descriptor.offset.inside.3749
  %descriptor.range.inside.3755 = and i1 %descriptor.owner.offset.valid.3753, %descriptor.extent.inside.3751
  %descriptor.range.valid.3754 = and i1 %descriptor.range.inside.3755, %descriptor.payload.inside.3752
  %descriptor.type.valid.3756 = icmp eq i32 6, 6
  %descriptor.valid.3757 = and i1 %descriptor.range.valid.3754, %descriptor.type.valid.3756
  br i1 %descriptor.valid.3757, label %descriptor.valid.3758, label %descriptor.invalid.3759
descriptor.invalid.3759:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3758:
  %descriptor.initialized.status.3760 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.3726, i32 %string.concat.extent.3734)
  %helper.ok.3761 = icmp eq i32 %descriptor.initialized.status.3760, 0
  br i1 %helper.ok.3761, label %helper.continue.3762, label %frame.failure.0
helper.continue.3762:
  %local.is.active.3763 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3763, label %local.descriptor.active.3764, label %local.descriptor.inactive.3765
local.descriptor.active.3764:
  %local.check.offset.3767 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3768 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3769 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3770 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3771 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3772 = load i32, ptr %context.field.3771, align 4
  %stack.sub.3775 = sub i32 %local.check.owner.end.3770, %local.check.offset.3767
  %descriptor.owner.inside.3773 = icmp ule i32 %local.check.owner.end.3770, %context.value.3772
  %descriptor.offset.inside.3774 = icmp ule i32 %local.check.offset.3767, %local.check.owner.end.3770
  %descriptor.extent.inside.3776 = icmp ule i32 %local.check.extent.3768, %stack.sub.3775
  %descriptor.payload.inside.3777 = icmp ule i32 %local.check.payload.3769, %local.check.extent.3768
  %descriptor.owner.offset.valid.3778 = and i1 %descriptor.owner.inside.3773, %descriptor.offset.inside.3774
  %descriptor.range.inside.3780 = and i1 %descriptor.owner.offset.valid.3778, %descriptor.extent.inside.3776
  %descriptor.range.valid.3779 = and i1 %descriptor.range.inside.3780, %descriptor.payload.inside.3777
  br i1 %descriptor.range.valid.3779, label %descriptor.valid.3781, label %descriptor.invalid.3782
descriptor.invalid.3782:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3781:
  %descriptor.initialized.status.3783 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3767, i32 %local.check.extent.3768)
  %helper.ok.3784 = icmp eq i32 %descriptor.initialized.status.3783, 0
  br i1 %helper.ok.3784, label %helper.continue.3785, label %frame.failure.0
helper.continue.3785:
  br label %local.descriptor.checked.3766
local.descriptor.inactive.3765:
  br label %local.descriptor.checked.3766
local.descriptor.checked.3766:
  %local.is.active.3786 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3786, label %local.descriptor.active.3787, label %local.descriptor.inactive.3788
local.descriptor.active.3787:
  %local.check.offset.3790 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3791 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3792 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3793 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3794 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3795 = load i32, ptr %context.field.3794, align 4
  %stack.sub.3798 = sub i32 %local.check.owner.end.3793, %local.check.offset.3790
  %descriptor.owner.inside.3796 = icmp ule i32 %local.check.owner.end.3793, %context.value.3795
  %descriptor.offset.inside.3797 = icmp ule i32 %local.check.offset.3790, %local.check.owner.end.3793
  %descriptor.extent.inside.3799 = icmp ule i32 %local.check.extent.3791, %stack.sub.3798
  %descriptor.payload.inside.3800 = icmp ule i32 %local.check.payload.3792, %local.check.extent.3791
  %descriptor.owner.offset.valid.3801 = and i1 %descriptor.owner.inside.3796, %descriptor.offset.inside.3797
  %descriptor.range.inside.3803 = and i1 %descriptor.owner.offset.valid.3801, %descriptor.extent.inside.3799
  %descriptor.range.valid.3802 = and i1 %descriptor.range.inside.3803, %descriptor.payload.inside.3800
  br i1 %descriptor.range.valid.3802, label %descriptor.valid.3804, label %descriptor.invalid.3805
descriptor.invalid.3805:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3804:
  %descriptor.initialized.status.3806 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3790, i32 %local.check.extent.3791)
  %helper.ok.3807 = icmp eq i32 %descriptor.initialized.status.3806, 0
  br i1 %helper.ok.3807, label %helper.continue.3808, label %frame.failure.0
helper.continue.3808:
  br label %local.descriptor.checked.3789
local.descriptor.inactive.3788:
  br label %local.descriptor.checked.3789
local.descriptor.checked.3789:
  %local.is.active.3809 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3809, label %local.descriptor.active.3810, label %local.descriptor.inactive.3811
local.descriptor.active.3810:
  %local.check.offset.3813 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3814 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3815 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3816 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3817 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3818 = load i32, ptr %context.field.3817, align 4
  %stack.sub.3821 = sub i32 %local.check.owner.end.3816, %local.check.offset.3813
  %descriptor.owner.inside.3819 = icmp ule i32 %local.check.owner.end.3816, %context.value.3818
  %descriptor.offset.inside.3820 = icmp ule i32 %local.check.offset.3813, %local.check.owner.end.3816
  %descriptor.extent.inside.3822 = icmp ule i32 %local.check.extent.3814, %stack.sub.3821
  %descriptor.payload.inside.3823 = icmp ule i32 %local.check.payload.3815, %local.check.extent.3814
  %descriptor.owner.offset.valid.3824 = and i1 %descriptor.owner.inside.3819, %descriptor.offset.inside.3820
  %descriptor.range.inside.3826 = and i1 %descriptor.owner.offset.valid.3824, %descriptor.extent.inside.3822
  %descriptor.range.valid.3825 = and i1 %descriptor.range.inside.3826, %descriptor.payload.inside.3823
  br i1 %descriptor.range.valid.3825, label %descriptor.valid.3827, label %descriptor.invalid.3828
descriptor.invalid.3828:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3827:
  %descriptor.initialized.status.3829 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3813, i32 %local.check.extent.3814)
  %helper.ok.3830 = icmp eq i32 %descriptor.initialized.status.3829, 0
  br i1 %helper.ok.3830, label %helper.continue.3831, label %frame.failure.0
helper.continue.3831:
  br label %local.descriptor.checked.3812
local.descriptor.inactive.3811:
  br label %local.descriptor.checked.3812
local.descriptor.checked.3812:
  %local.is.active.3832 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3832, label %local.descriptor.active.3833, label %local.descriptor.inactive.3834
local.descriptor.active.3833:
  %local.check.offset.3836 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3837 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3838 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3839 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3840 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3841 = load i32, ptr %context.field.3840, align 4
  %stack.sub.3844 = sub i32 %local.check.owner.end.3839, %local.check.offset.3836
  %descriptor.owner.inside.3842 = icmp ule i32 %local.check.owner.end.3839, %context.value.3841
  %descriptor.offset.inside.3843 = icmp ule i32 %local.check.offset.3836, %local.check.owner.end.3839
  %descriptor.extent.inside.3845 = icmp ule i32 %local.check.extent.3837, %stack.sub.3844
  %descriptor.payload.inside.3846 = icmp ule i32 %local.check.payload.3838, %local.check.extent.3837
  %descriptor.owner.offset.valid.3847 = and i1 %descriptor.owner.inside.3842, %descriptor.offset.inside.3843
  %descriptor.range.inside.3849 = and i1 %descriptor.owner.offset.valid.3847, %descriptor.extent.inside.3845
  %descriptor.range.valid.3848 = and i1 %descriptor.range.inside.3849, %descriptor.payload.inside.3846
  br i1 %descriptor.range.valid.3848, label %descriptor.valid.3850, label %descriptor.invalid.3851
descriptor.invalid.3851:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3850:
  %descriptor.initialized.status.3852 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3836, i32 %local.check.extent.3837)
  %helper.ok.3853 = icmp eq i32 %descriptor.initialized.status.3852, 0
  br i1 %helper.ok.3853, label %helper.continue.3854, label %frame.failure.0
helper.continue.3854:
  br label %local.descriptor.checked.3835
local.descriptor.inactive.3834:
  br label %local.descriptor.checked.3835
local.descriptor.checked.3835:
  %local.is.active.3855 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3855, label %local.descriptor.active.3856, label %local.descriptor.inactive.3857
local.descriptor.active.3856:
  %local.check.offset.3859 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3860 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3861 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3862 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3863 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3864 = load i32, ptr %context.field.3863, align 4
  %stack.sub.3867 = sub i32 %local.check.owner.end.3862, %local.check.offset.3859
  %descriptor.owner.inside.3865 = icmp ule i32 %local.check.owner.end.3862, %context.value.3864
  %descriptor.offset.inside.3866 = icmp ule i32 %local.check.offset.3859, %local.check.owner.end.3862
  %descriptor.extent.inside.3868 = icmp ule i32 %local.check.extent.3860, %stack.sub.3867
  %descriptor.payload.inside.3869 = icmp ule i32 %local.check.payload.3861, %local.check.extent.3860
  %descriptor.owner.offset.valid.3870 = and i1 %descriptor.owner.inside.3865, %descriptor.offset.inside.3866
  %descriptor.range.inside.3872 = and i1 %descriptor.owner.offset.valid.3870, %descriptor.extent.inside.3868
  %descriptor.range.valid.3871 = and i1 %descriptor.range.inside.3872, %descriptor.payload.inside.3869
  br i1 %descriptor.range.valid.3871, label %descriptor.valid.3873, label %descriptor.invalid.3874
descriptor.invalid.3874:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3873:
  %descriptor.initialized.status.3875 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3859, i32 %local.check.extent.3860)
  %helper.ok.3876 = icmp eq i32 %descriptor.initialized.status.3875, 0
  br i1 %helper.ok.3876, label %helper.continue.3877, label %frame.failure.0
helper.continue.3877:
  br label %local.descriptor.checked.3858
local.descriptor.inactive.3857:
  br label %local.descriptor.checked.3858
local.descriptor.checked.3858:
  %local.is.active.3878 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3878, label %local.descriptor.active.3879, label %local.descriptor.inactive.3880
local.descriptor.active.3879:
  %local.check.offset.3882 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3883 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3884 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3885 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3887 = load i32, ptr %context.field.3886, align 4
  %stack.sub.3890 = sub i32 %local.check.owner.end.3885, %local.check.offset.3882
  %descriptor.owner.inside.3888 = icmp ule i32 %local.check.owner.end.3885, %context.value.3887
  %descriptor.offset.inside.3889 = icmp ule i32 %local.check.offset.3882, %local.check.owner.end.3885
  %descriptor.extent.inside.3891 = icmp ule i32 %local.check.extent.3883, %stack.sub.3890
  %descriptor.payload.inside.3892 = icmp ule i32 %local.check.payload.3884, %local.check.extent.3883
  %descriptor.owner.offset.valid.3893 = and i1 %descriptor.owner.inside.3888, %descriptor.offset.inside.3889
  %descriptor.range.inside.3895 = and i1 %descriptor.owner.offset.valid.3893, %descriptor.extent.inside.3891
  %descriptor.range.valid.3894 = and i1 %descriptor.range.inside.3895, %descriptor.payload.inside.3892
  br i1 %descriptor.range.valid.3894, label %descriptor.valid.3896, label %descriptor.invalid.3897
descriptor.invalid.3897:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3896:
  %descriptor.initialized.status.3898 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3882, i32 %local.check.extent.3883)
  %helper.ok.3899 = icmp eq i32 %descriptor.initialized.status.3898, 0
  br i1 %helper.ok.3899, label %helper.continue.3900, label %frame.failure.0
helper.continue.3900:
  br label %local.descriptor.checked.3881
local.descriptor.inactive.3880:
  br label %local.descriptor.checked.3881
local.descriptor.checked.3881:
  %local.is.active.3901 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3901, label %local.descriptor.active.3902, label %local.descriptor.inactive.3903
local.descriptor.active.3902:
  %local.check.offset.3905 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3906 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3907 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3908 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3909 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3910 = load i32, ptr %context.field.3909, align 4
  %stack.sub.3913 = sub i32 %local.check.owner.end.3908, %local.check.offset.3905
  %descriptor.owner.inside.3911 = icmp ule i32 %local.check.owner.end.3908, %context.value.3910
  %descriptor.offset.inside.3912 = icmp ule i32 %local.check.offset.3905, %local.check.owner.end.3908
  %descriptor.extent.inside.3914 = icmp ule i32 %local.check.extent.3906, %stack.sub.3913
  %descriptor.payload.inside.3915 = icmp ule i32 %local.check.payload.3907, %local.check.extent.3906
  %descriptor.owner.offset.valid.3916 = and i1 %descriptor.owner.inside.3911, %descriptor.offset.inside.3912
  %descriptor.range.inside.3918 = and i1 %descriptor.owner.offset.valid.3916, %descriptor.extent.inside.3914
  %descriptor.range.valid.3917 = and i1 %descriptor.range.inside.3918, %descriptor.payload.inside.3915
  br i1 %descriptor.range.valid.3917, label %descriptor.valid.3919, label %descriptor.invalid.3920
descriptor.invalid.3920:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3919:
  %descriptor.initialized.status.3921 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3905, i32 %local.check.extent.3906)
  %helper.ok.3922 = icmp eq i32 %descriptor.initialized.status.3921, 0
  br i1 %helper.ok.3922, label %helper.continue.3923, label %frame.failure.0
helper.continue.3923:
  br label %local.descriptor.checked.3904
local.descriptor.inactive.3903:
  br label %local.descriptor.checked.3904
local.descriptor.checked.3904:
  %step.status.3924 = call i32 @al_owning_charge_step(ptr %ctx, i32 57)
  %helper.ok.3925 = icmp eq i32 %step.status.3924, 0
  br i1 %helper.ok.3925, label %helper.continue.3926, label %frame.failure.0
helper.continue.3926:
  store i1 true, ptr %local.active.26, align 1
  store i32 %context.value.3726, ptr %local.offset.27, align 4
  store i32 %string.concat.extent.3734, ptr %local.extent.28, align 4
  store i32 %string.concat.payload.3733, ptr %local.payload.29, align 4
  store i32 %stack.offset.3735, ptr %local.owner.end.30, align 4
  store i32 6, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.3726, i32 20, i32 %string.concat.payload.3733, i32 %stack.offset.3735, i32 %string.concat.extent.3734)
  %context.field.3927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3928 = load i32, ptr %context.field.3927, align 4
  %runtime.ok.3929 = icmp eq i32 %context.value.3928, 0
  br i1 %runtime.ok.3929, label %runtime.continue.3930, label %frame.failure.0
runtime.continue.3930:
  %local.is.active.3931 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3931, label %local.descriptor.active.3932, label %local.descriptor.inactive.3933
local.descriptor.active.3932:
  %local.check.offset.3935 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3936 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3937 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3938 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3939 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3940 = load i32, ptr %context.field.3939, align 4
  %stack.sub.3943 = sub i32 %local.check.owner.end.3938, %local.check.offset.3935
  %descriptor.owner.inside.3941 = icmp ule i32 %local.check.owner.end.3938, %context.value.3940
  %descriptor.offset.inside.3942 = icmp ule i32 %local.check.offset.3935, %local.check.owner.end.3938
  %descriptor.extent.inside.3944 = icmp ule i32 %local.check.extent.3936, %stack.sub.3943
  %descriptor.payload.inside.3945 = icmp ule i32 %local.check.payload.3937, %local.check.extent.3936
  %descriptor.owner.offset.valid.3946 = and i1 %descriptor.owner.inside.3941, %descriptor.offset.inside.3942
  %descriptor.range.inside.3948 = and i1 %descriptor.owner.offset.valid.3946, %descriptor.extent.inside.3944
  %descriptor.range.valid.3947 = and i1 %descriptor.range.inside.3948, %descriptor.payload.inside.3945
  br i1 %descriptor.range.valid.3947, label %descriptor.valid.3949, label %descriptor.invalid.3950
descriptor.invalid.3950:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3949:
  %descriptor.initialized.status.3951 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3935, i32 %local.check.extent.3936)
  %helper.ok.3952 = icmp eq i32 %descriptor.initialized.status.3951, 0
  br i1 %helper.ok.3952, label %helper.continue.3953, label %frame.failure.0
helper.continue.3953:
  br label %local.descriptor.checked.3934
local.descriptor.inactive.3933:
  br label %local.descriptor.checked.3934
local.descriptor.checked.3934:
  %local.is.active.3954 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3954, label %local.descriptor.active.3955, label %local.descriptor.inactive.3956
local.descriptor.active.3955:
  %local.check.offset.3958 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3959 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3960 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3961 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3962 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3963 = load i32, ptr %context.field.3962, align 4
  %stack.sub.3966 = sub i32 %local.check.owner.end.3961, %local.check.offset.3958
  %descriptor.owner.inside.3964 = icmp ule i32 %local.check.owner.end.3961, %context.value.3963
  %descriptor.offset.inside.3965 = icmp ule i32 %local.check.offset.3958, %local.check.owner.end.3961
  %descriptor.extent.inside.3967 = icmp ule i32 %local.check.extent.3959, %stack.sub.3966
  %descriptor.payload.inside.3968 = icmp ule i32 %local.check.payload.3960, %local.check.extent.3959
  %descriptor.owner.offset.valid.3969 = and i1 %descriptor.owner.inside.3964, %descriptor.offset.inside.3965
  %descriptor.range.inside.3971 = and i1 %descriptor.owner.offset.valid.3969, %descriptor.extent.inside.3967
  %descriptor.range.valid.3970 = and i1 %descriptor.range.inside.3971, %descriptor.payload.inside.3968
  br i1 %descriptor.range.valid.3970, label %descriptor.valid.3972, label %descriptor.invalid.3973
descriptor.invalid.3973:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3972:
  %descriptor.initialized.status.3974 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3958, i32 %local.check.extent.3959)
  %helper.ok.3975 = icmp eq i32 %descriptor.initialized.status.3974, 0
  br i1 %helper.ok.3975, label %helper.continue.3976, label %frame.failure.0
helper.continue.3976:
  br label %local.descriptor.checked.3957
local.descriptor.inactive.3956:
  br label %local.descriptor.checked.3957
local.descriptor.checked.3957:
  %local.is.active.3977 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3977, label %local.descriptor.active.3978, label %local.descriptor.inactive.3979
local.descriptor.active.3978:
  %local.check.offset.3981 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3982 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3983 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3984 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3986 = load i32, ptr %context.field.3985, align 4
  %stack.sub.3989 = sub i32 %local.check.owner.end.3984, %local.check.offset.3981
  %descriptor.owner.inside.3987 = icmp ule i32 %local.check.owner.end.3984, %context.value.3986
  %descriptor.offset.inside.3988 = icmp ule i32 %local.check.offset.3981, %local.check.owner.end.3984
  %descriptor.extent.inside.3990 = icmp ule i32 %local.check.extent.3982, %stack.sub.3989
  %descriptor.payload.inside.3991 = icmp ule i32 %local.check.payload.3983, %local.check.extent.3982
  %descriptor.owner.offset.valid.3992 = and i1 %descriptor.owner.inside.3987, %descriptor.offset.inside.3988
  %descriptor.range.inside.3994 = and i1 %descriptor.owner.offset.valid.3992, %descriptor.extent.inside.3990
  %descriptor.range.valid.3993 = and i1 %descriptor.range.inside.3994, %descriptor.payload.inside.3991
  br i1 %descriptor.range.valid.3993, label %descriptor.valid.3995, label %descriptor.invalid.3996
descriptor.invalid.3996:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3995:
  %descriptor.initialized.status.3997 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3981, i32 %local.check.extent.3982)
  %helper.ok.3998 = icmp eq i32 %descriptor.initialized.status.3997, 0
  br i1 %helper.ok.3998, label %helper.continue.3999, label %frame.failure.0
helper.continue.3999:
  br label %local.descriptor.checked.3980
local.descriptor.inactive.3979:
  br label %local.descriptor.checked.3980
local.descriptor.checked.3980:
  %local.is.active.4000 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4000, label %local.descriptor.active.4001, label %local.descriptor.inactive.4002
local.descriptor.active.4001:
  %local.check.offset.4004 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4005 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4006 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4007 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4008 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4009 = load i32, ptr %context.field.4008, align 4
  %stack.sub.4012 = sub i32 %local.check.owner.end.4007, %local.check.offset.4004
  %descriptor.owner.inside.4010 = icmp ule i32 %local.check.owner.end.4007, %context.value.4009
  %descriptor.offset.inside.4011 = icmp ule i32 %local.check.offset.4004, %local.check.owner.end.4007
  %descriptor.extent.inside.4013 = icmp ule i32 %local.check.extent.4005, %stack.sub.4012
  %descriptor.payload.inside.4014 = icmp ule i32 %local.check.payload.4006, %local.check.extent.4005
  %descriptor.owner.offset.valid.4015 = and i1 %descriptor.owner.inside.4010, %descriptor.offset.inside.4011
  %descriptor.range.inside.4017 = and i1 %descriptor.owner.offset.valid.4015, %descriptor.extent.inside.4013
  %descriptor.range.valid.4016 = and i1 %descriptor.range.inside.4017, %descriptor.payload.inside.4014
  br i1 %descriptor.range.valid.4016, label %descriptor.valid.4018, label %descriptor.invalid.4019
descriptor.invalid.4019:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4018:
  %descriptor.initialized.status.4020 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4004, i32 %local.check.extent.4005)
  %helper.ok.4021 = icmp eq i32 %descriptor.initialized.status.4020, 0
  br i1 %helper.ok.4021, label %helper.continue.4022, label %frame.failure.0
helper.continue.4022:
  br label %local.descriptor.checked.4003
local.descriptor.inactive.4002:
  br label %local.descriptor.checked.4003
local.descriptor.checked.4003:
  %local.is.active.4023 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4023, label %local.descriptor.active.4024, label %local.descriptor.inactive.4025
local.descriptor.active.4024:
  %local.check.offset.4027 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4028 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4029 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4030 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4031 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4032 = load i32, ptr %context.field.4031, align 4
  %stack.sub.4035 = sub i32 %local.check.owner.end.4030, %local.check.offset.4027
  %descriptor.owner.inside.4033 = icmp ule i32 %local.check.owner.end.4030, %context.value.4032
  %descriptor.offset.inside.4034 = icmp ule i32 %local.check.offset.4027, %local.check.owner.end.4030
  %descriptor.extent.inside.4036 = icmp ule i32 %local.check.extent.4028, %stack.sub.4035
  %descriptor.payload.inside.4037 = icmp ule i32 %local.check.payload.4029, %local.check.extent.4028
  %descriptor.owner.offset.valid.4038 = and i1 %descriptor.owner.inside.4033, %descriptor.offset.inside.4034
  %descriptor.range.inside.4040 = and i1 %descriptor.owner.offset.valid.4038, %descriptor.extent.inside.4036
  %descriptor.range.valid.4039 = and i1 %descriptor.range.inside.4040, %descriptor.payload.inside.4037
  br i1 %descriptor.range.valid.4039, label %descriptor.valid.4041, label %descriptor.invalid.4042
descriptor.invalid.4042:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4041:
  %descriptor.initialized.status.4043 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4027, i32 %local.check.extent.4028)
  %helper.ok.4044 = icmp eq i32 %descriptor.initialized.status.4043, 0
  br i1 %helper.ok.4044, label %helper.continue.4045, label %frame.failure.0
helper.continue.4045:
  br label %local.descriptor.checked.4026
local.descriptor.inactive.4025:
  br label %local.descriptor.checked.4026
local.descriptor.checked.4026:
  %local.is.active.4046 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4046, label %local.descriptor.active.4047, label %local.descriptor.inactive.4048
local.descriptor.active.4047:
  %local.check.offset.4050 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4051 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4052 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4053 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4054 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4055 = load i32, ptr %context.field.4054, align 4
  %stack.sub.4058 = sub i32 %local.check.owner.end.4053, %local.check.offset.4050
  %descriptor.owner.inside.4056 = icmp ule i32 %local.check.owner.end.4053, %context.value.4055
  %descriptor.offset.inside.4057 = icmp ule i32 %local.check.offset.4050, %local.check.owner.end.4053
  %descriptor.extent.inside.4059 = icmp ule i32 %local.check.extent.4051, %stack.sub.4058
  %descriptor.payload.inside.4060 = icmp ule i32 %local.check.payload.4052, %local.check.extent.4051
  %descriptor.owner.offset.valid.4061 = and i1 %descriptor.owner.inside.4056, %descriptor.offset.inside.4057
  %descriptor.range.inside.4063 = and i1 %descriptor.owner.offset.valid.4061, %descriptor.extent.inside.4059
  %descriptor.range.valid.4062 = and i1 %descriptor.range.inside.4063, %descriptor.payload.inside.4060
  br i1 %descriptor.range.valid.4062, label %descriptor.valid.4064, label %descriptor.invalid.4065
descriptor.invalid.4065:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4064:
  %descriptor.initialized.status.4066 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4050, i32 %local.check.extent.4051)
  %helper.ok.4067 = icmp eq i32 %descriptor.initialized.status.4066, 0
  br i1 %helper.ok.4067, label %helper.continue.4068, label %frame.failure.0
helper.continue.4068:
  br label %local.descriptor.checked.4049
local.descriptor.inactive.4048:
  br label %local.descriptor.checked.4049
local.descriptor.checked.4049:
  %local.is.active.4069 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4069, label %local.descriptor.active.4070, label %local.descriptor.inactive.4071
local.descriptor.active.4070:
  %local.check.offset.4073 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4074 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4075 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4076 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4077 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4078 = load i32, ptr %context.field.4077, align 4
  %stack.sub.4081 = sub i32 %local.check.owner.end.4076, %local.check.offset.4073
  %descriptor.owner.inside.4079 = icmp ule i32 %local.check.owner.end.4076, %context.value.4078
  %descriptor.offset.inside.4080 = icmp ule i32 %local.check.offset.4073, %local.check.owner.end.4076
  %descriptor.extent.inside.4082 = icmp ule i32 %local.check.extent.4074, %stack.sub.4081
  %descriptor.payload.inside.4083 = icmp ule i32 %local.check.payload.4075, %local.check.extent.4074
  %descriptor.owner.offset.valid.4084 = and i1 %descriptor.owner.inside.4079, %descriptor.offset.inside.4080
  %descriptor.range.inside.4086 = and i1 %descriptor.owner.offset.valid.4084, %descriptor.extent.inside.4082
  %descriptor.range.valid.4085 = and i1 %descriptor.range.inside.4086, %descriptor.payload.inside.4083
  br i1 %descriptor.range.valid.4085, label %descriptor.valid.4087, label %descriptor.invalid.4088
descriptor.invalid.4088:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4087:
  %descriptor.initialized.status.4089 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4073, i32 %local.check.extent.4074)
  %helper.ok.4090 = icmp eq i32 %descriptor.initialized.status.4089, 0
  br i1 %helper.ok.4090, label %helper.continue.4091, label %frame.failure.0
helper.continue.4091:
  br label %local.descriptor.checked.4072
local.descriptor.inactive.4071:
  br label %local.descriptor.checked.4072
local.descriptor.checked.4072:
  %step.status.4092 = call i32 @al_owning_charge_step(ptr %ctx, i32 58)
  %helper.ok.4093 = icmp eq i32 %step.status.4092, 0
  br i1 %helper.ok.4093, label %helper.continue.4094, label %frame.failure.0
helper.continue.4094:
  %local.resolved.offset.4095 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.4096 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.4097 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.4098 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4099 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4100 = load i32, ptr %context.field.4099, align 4
  %stack.sub.4103 = sub i32 %local.resolved.owner.end.4098, %local.resolved.offset.4095
  %descriptor.owner.inside.4101 = icmp ule i32 %local.resolved.owner.end.4098, %context.value.4100
  %descriptor.offset.inside.4102 = icmp ule i32 %local.resolved.offset.4095, %local.resolved.owner.end.4098
  %descriptor.extent.inside.4104 = icmp ule i32 %local.resolved.extent.4096, %stack.sub.4103
  %descriptor.payload.inside.4105 = icmp ule i32 %local.resolved.payload.4097, %local.resolved.extent.4096
  %descriptor.owner.offset.valid.4106 = and i1 %descriptor.owner.inside.4101, %descriptor.offset.inside.4102
  %descriptor.range.inside.4108 = and i1 %descriptor.owner.offset.valid.4106, %descriptor.extent.inside.4104
  %descriptor.range.valid.4107 = and i1 %descriptor.range.inside.4108, %descriptor.payload.inside.4105
  %descriptor.type.valid.4109 = icmp eq i32 6, 6
  %descriptor.valid.4110 = and i1 %descriptor.range.valid.4107, %descriptor.type.valid.4109
  br i1 %descriptor.valid.4110, label %descriptor.valid.4111, label %descriptor.invalid.4112
descriptor.invalid.4112:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4111:
  %descriptor.initialized.status.4113 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4095, i32 %local.resolved.extent.4096)
  %helper.ok.4114 = icmp eq i32 %descriptor.initialized.status.4113, 0
  br i1 %helper.ok.4114, label %helper.continue.4115, label %frame.failure.0
helper.continue.4115:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4095, i32 20, i32 %local.resolved.payload.4097, i32 %local.resolved.owner.end.4098, i32 %local.resolved.extent.4096)
  %context.field.4116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4117 = load i32, ptr %context.field.4116, align 4
  %runtime.ok.4118 = icmp eq i32 %context.value.4117, 0
  br i1 %runtime.ok.4118, label %runtime.continue.4119, label %frame.failure.0
runtime.continue.4119:
  %context.field.4120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4121 = load i32, ptr %context.field.4120, align 4
  %stack.sub.4124 = sub i32 %local.resolved.owner.end.4098, %local.resolved.offset.4095
  %descriptor.owner.inside.4122 = icmp ule i32 %local.resolved.owner.end.4098, %context.value.4121
  %descriptor.offset.inside.4123 = icmp ule i32 %local.resolved.offset.4095, %local.resolved.owner.end.4098
  %descriptor.extent.inside.4125 = icmp ule i32 %local.resolved.extent.4096, %stack.sub.4124
  %descriptor.payload.inside.4126 = icmp ule i32 %local.resolved.payload.4097, %local.resolved.extent.4096
  %descriptor.owner.offset.valid.4127 = and i1 %descriptor.owner.inside.4122, %descriptor.offset.inside.4123
  %descriptor.range.inside.4129 = and i1 %descriptor.owner.offset.valid.4127, %descriptor.extent.inside.4125
  %descriptor.range.valid.4128 = and i1 %descriptor.range.inside.4129, %descriptor.payload.inside.4126
  %descriptor.type.valid.4130 = icmp eq i32 6, 6
  %descriptor.valid.4131 = and i1 %descriptor.range.valid.4128, %descriptor.type.valid.4130
  br i1 %descriptor.valid.4131, label %descriptor.valid.4132, label %descriptor.invalid.4133
descriptor.invalid.4133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4132:
  %descriptor.initialized.status.4134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4095, i32 %local.resolved.extent.4096)
  %helper.ok.4135 = icmp eq i32 %descriptor.initialized.status.4134, 0
  br i1 %helper.ok.4135, label %helper.continue.4136, label %frame.failure.0
helper.continue.4136:
  %local.is.active.4137 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4137, label %local.descriptor.active.4138, label %local.descriptor.inactive.4139
local.descriptor.active.4138:
  %local.check.offset.4141 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4142 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4143 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4144 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4146 = load i32, ptr %context.field.4145, align 4
  %stack.sub.4149 = sub i32 %local.check.owner.end.4144, %local.check.offset.4141
  %descriptor.owner.inside.4147 = icmp ule i32 %local.check.owner.end.4144, %context.value.4146
  %descriptor.offset.inside.4148 = icmp ule i32 %local.check.offset.4141, %local.check.owner.end.4144
  %descriptor.extent.inside.4150 = icmp ule i32 %local.check.extent.4142, %stack.sub.4149
  %descriptor.payload.inside.4151 = icmp ule i32 %local.check.payload.4143, %local.check.extent.4142
  %descriptor.owner.offset.valid.4152 = and i1 %descriptor.owner.inside.4147, %descriptor.offset.inside.4148
  %descriptor.range.inside.4154 = and i1 %descriptor.owner.offset.valid.4152, %descriptor.extent.inside.4150
  %descriptor.range.valid.4153 = and i1 %descriptor.range.inside.4154, %descriptor.payload.inside.4151
  br i1 %descriptor.range.valid.4153, label %descriptor.valid.4155, label %descriptor.invalid.4156
descriptor.invalid.4156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4155:
  %descriptor.initialized.status.4157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4141, i32 %local.check.extent.4142)
  %helper.ok.4158 = icmp eq i32 %descriptor.initialized.status.4157, 0
  br i1 %helper.ok.4158, label %helper.continue.4159, label %frame.failure.0
helper.continue.4159:
  br label %local.descriptor.checked.4140
local.descriptor.inactive.4139:
  br label %local.descriptor.checked.4140
local.descriptor.checked.4140:
  %local.is.active.4160 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4160, label %local.descriptor.active.4161, label %local.descriptor.inactive.4162
local.descriptor.active.4161:
  %local.check.offset.4164 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4165 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4166 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4167 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4169 = load i32, ptr %context.field.4168, align 4
  %stack.sub.4172 = sub i32 %local.check.owner.end.4167, %local.check.offset.4164
  %descriptor.owner.inside.4170 = icmp ule i32 %local.check.owner.end.4167, %context.value.4169
  %descriptor.offset.inside.4171 = icmp ule i32 %local.check.offset.4164, %local.check.owner.end.4167
  %descriptor.extent.inside.4173 = icmp ule i32 %local.check.extent.4165, %stack.sub.4172
  %descriptor.payload.inside.4174 = icmp ule i32 %local.check.payload.4166, %local.check.extent.4165
  %descriptor.owner.offset.valid.4175 = and i1 %descriptor.owner.inside.4170, %descriptor.offset.inside.4171
  %descriptor.range.inside.4177 = and i1 %descriptor.owner.offset.valid.4175, %descriptor.extent.inside.4173
  %descriptor.range.valid.4176 = and i1 %descriptor.range.inside.4177, %descriptor.payload.inside.4174
  br i1 %descriptor.range.valid.4176, label %descriptor.valid.4178, label %descriptor.invalid.4179
descriptor.invalid.4179:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4178:
  %descriptor.initialized.status.4180 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4164, i32 %local.check.extent.4165)
  %helper.ok.4181 = icmp eq i32 %descriptor.initialized.status.4180, 0
  br i1 %helper.ok.4181, label %helper.continue.4182, label %frame.failure.0
helper.continue.4182:
  br label %local.descriptor.checked.4163
local.descriptor.inactive.4162:
  br label %local.descriptor.checked.4163
local.descriptor.checked.4163:
  %local.is.active.4183 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4183, label %local.descriptor.active.4184, label %local.descriptor.inactive.4185
local.descriptor.active.4184:
  %local.check.offset.4187 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4188 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4189 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4190 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4192 = load i32, ptr %context.field.4191, align 4
  %stack.sub.4195 = sub i32 %local.check.owner.end.4190, %local.check.offset.4187
  %descriptor.owner.inside.4193 = icmp ule i32 %local.check.owner.end.4190, %context.value.4192
  %descriptor.offset.inside.4194 = icmp ule i32 %local.check.offset.4187, %local.check.owner.end.4190
  %descriptor.extent.inside.4196 = icmp ule i32 %local.check.extent.4188, %stack.sub.4195
  %descriptor.payload.inside.4197 = icmp ule i32 %local.check.payload.4189, %local.check.extent.4188
  %descriptor.owner.offset.valid.4198 = and i1 %descriptor.owner.inside.4193, %descriptor.offset.inside.4194
  %descriptor.range.inside.4200 = and i1 %descriptor.owner.offset.valid.4198, %descriptor.extent.inside.4196
  %descriptor.range.valid.4199 = and i1 %descriptor.range.inside.4200, %descriptor.payload.inside.4197
  br i1 %descriptor.range.valid.4199, label %descriptor.valid.4201, label %descriptor.invalid.4202
descriptor.invalid.4202:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4201:
  %descriptor.initialized.status.4203 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4187, i32 %local.check.extent.4188)
  %helper.ok.4204 = icmp eq i32 %descriptor.initialized.status.4203, 0
  br i1 %helper.ok.4204, label %helper.continue.4205, label %frame.failure.0
helper.continue.4205:
  br label %local.descriptor.checked.4186
local.descriptor.inactive.4185:
  br label %local.descriptor.checked.4186
local.descriptor.checked.4186:
  %local.is.active.4206 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4206, label %local.descriptor.active.4207, label %local.descriptor.inactive.4208
local.descriptor.active.4207:
  %local.check.offset.4210 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4211 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4212 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4213 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4215 = load i32, ptr %context.field.4214, align 4
  %stack.sub.4218 = sub i32 %local.check.owner.end.4213, %local.check.offset.4210
  %descriptor.owner.inside.4216 = icmp ule i32 %local.check.owner.end.4213, %context.value.4215
  %descriptor.offset.inside.4217 = icmp ule i32 %local.check.offset.4210, %local.check.owner.end.4213
  %descriptor.extent.inside.4219 = icmp ule i32 %local.check.extent.4211, %stack.sub.4218
  %descriptor.payload.inside.4220 = icmp ule i32 %local.check.payload.4212, %local.check.extent.4211
  %descriptor.owner.offset.valid.4221 = and i1 %descriptor.owner.inside.4216, %descriptor.offset.inside.4217
  %descriptor.range.inside.4223 = and i1 %descriptor.owner.offset.valid.4221, %descriptor.extent.inside.4219
  %descriptor.range.valid.4222 = and i1 %descriptor.range.inside.4223, %descriptor.payload.inside.4220
  br i1 %descriptor.range.valid.4222, label %descriptor.valid.4224, label %descriptor.invalid.4225
descriptor.invalid.4225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4224:
  %descriptor.initialized.status.4226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4210, i32 %local.check.extent.4211)
  %helper.ok.4227 = icmp eq i32 %descriptor.initialized.status.4226, 0
  br i1 %helper.ok.4227, label %helper.continue.4228, label %frame.failure.0
helper.continue.4228:
  br label %local.descriptor.checked.4209
local.descriptor.inactive.4208:
  br label %local.descriptor.checked.4209
local.descriptor.checked.4209:
  %local.is.active.4229 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4229, label %local.descriptor.active.4230, label %local.descriptor.inactive.4231
local.descriptor.active.4230:
  %local.check.offset.4233 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4234 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4235 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4236 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4238 = load i32, ptr %context.field.4237, align 4
  %stack.sub.4241 = sub i32 %local.check.owner.end.4236, %local.check.offset.4233
  %descriptor.owner.inside.4239 = icmp ule i32 %local.check.owner.end.4236, %context.value.4238
  %descriptor.offset.inside.4240 = icmp ule i32 %local.check.offset.4233, %local.check.owner.end.4236
  %descriptor.extent.inside.4242 = icmp ule i32 %local.check.extent.4234, %stack.sub.4241
  %descriptor.payload.inside.4243 = icmp ule i32 %local.check.payload.4235, %local.check.extent.4234
  %descriptor.owner.offset.valid.4244 = and i1 %descriptor.owner.inside.4239, %descriptor.offset.inside.4240
  %descriptor.range.inside.4246 = and i1 %descriptor.owner.offset.valid.4244, %descriptor.extent.inside.4242
  %descriptor.range.valid.4245 = and i1 %descriptor.range.inside.4246, %descriptor.payload.inside.4243
  br i1 %descriptor.range.valid.4245, label %descriptor.valid.4247, label %descriptor.invalid.4248
descriptor.invalid.4248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4247:
  %descriptor.initialized.status.4249 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4233, i32 %local.check.extent.4234)
  %helper.ok.4250 = icmp eq i32 %descriptor.initialized.status.4249, 0
  br i1 %helper.ok.4250, label %helper.continue.4251, label %frame.failure.0
helper.continue.4251:
  br label %local.descriptor.checked.4232
local.descriptor.inactive.4231:
  br label %local.descriptor.checked.4232
local.descriptor.checked.4232:
  %local.is.active.4252 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4252, label %local.descriptor.active.4253, label %local.descriptor.inactive.4254
local.descriptor.active.4253:
  %local.check.offset.4256 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4257 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4258 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4259 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4261 = load i32, ptr %context.field.4260, align 4
  %stack.sub.4264 = sub i32 %local.check.owner.end.4259, %local.check.offset.4256
  %descriptor.owner.inside.4262 = icmp ule i32 %local.check.owner.end.4259, %context.value.4261
  %descriptor.offset.inside.4263 = icmp ule i32 %local.check.offset.4256, %local.check.owner.end.4259
  %descriptor.extent.inside.4265 = icmp ule i32 %local.check.extent.4257, %stack.sub.4264
  %descriptor.payload.inside.4266 = icmp ule i32 %local.check.payload.4258, %local.check.extent.4257
  %descriptor.owner.offset.valid.4267 = and i1 %descriptor.owner.inside.4262, %descriptor.offset.inside.4263
  %descriptor.range.inside.4269 = and i1 %descriptor.owner.offset.valid.4267, %descriptor.extent.inside.4265
  %descriptor.range.valid.4268 = and i1 %descriptor.range.inside.4269, %descriptor.payload.inside.4266
  br i1 %descriptor.range.valid.4268, label %descriptor.valid.4270, label %descriptor.invalid.4271
descriptor.invalid.4271:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4270:
  %descriptor.initialized.status.4272 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4256, i32 %local.check.extent.4257)
  %helper.ok.4273 = icmp eq i32 %descriptor.initialized.status.4272, 0
  br i1 %helper.ok.4273, label %helper.continue.4274, label %frame.failure.0
helper.continue.4274:
  br label %local.descriptor.checked.4255
local.descriptor.inactive.4254:
  br label %local.descriptor.checked.4255
local.descriptor.checked.4255:
  %local.is.active.4275 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4275, label %local.descriptor.active.4276, label %local.descriptor.inactive.4277
local.descriptor.active.4276:
  %local.check.offset.4279 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4280 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4281 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4282 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4283 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4284 = load i32, ptr %context.field.4283, align 4
  %stack.sub.4287 = sub i32 %local.check.owner.end.4282, %local.check.offset.4279
  %descriptor.owner.inside.4285 = icmp ule i32 %local.check.owner.end.4282, %context.value.4284
  %descriptor.offset.inside.4286 = icmp ule i32 %local.check.offset.4279, %local.check.owner.end.4282
  %descriptor.extent.inside.4288 = icmp ule i32 %local.check.extent.4280, %stack.sub.4287
  %descriptor.payload.inside.4289 = icmp ule i32 %local.check.payload.4281, %local.check.extent.4280
  %descriptor.owner.offset.valid.4290 = and i1 %descriptor.owner.inside.4285, %descriptor.offset.inside.4286
  %descriptor.range.inside.4292 = and i1 %descriptor.owner.offset.valid.4290, %descriptor.extent.inside.4288
  %descriptor.range.valid.4291 = and i1 %descriptor.range.inside.4292, %descriptor.payload.inside.4289
  br i1 %descriptor.range.valid.4291, label %descriptor.valid.4293, label %descriptor.invalid.4294
descriptor.invalid.4294:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4293:
  %descriptor.initialized.status.4295 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4279, i32 %local.check.extent.4280)
  %helper.ok.4296 = icmp eq i32 %descriptor.initialized.status.4295, 0
  br i1 %helper.ok.4296, label %helper.continue.4297, label %frame.failure.0
helper.continue.4297:
  br label %local.descriptor.checked.4278
local.descriptor.inactive.4277:
  br label %local.descriptor.checked.4278
local.descriptor.checked.4278:
  %step.status.4298 = call i32 @al_owning_charge_step(ptr %ctx, i32 59)
  %helper.ok.4299 = icmp eq i32 %step.status.4298, 0
  br i1 %helper.ok.4299, label %helper.continue.4300, label %frame.failure.0
helper.continue.4300:
  %local.resolved.offset.4301 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.4302 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.4303 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.4304 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4305 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4306 = load i32, ptr %context.field.4305, align 4
  %stack.sub.4309 = sub i32 %local.resolved.owner.end.4304, %local.resolved.offset.4301
  %descriptor.owner.inside.4307 = icmp ule i32 %local.resolved.owner.end.4304, %context.value.4306
  %descriptor.offset.inside.4308 = icmp ule i32 %local.resolved.offset.4301, %local.resolved.owner.end.4304
  %descriptor.extent.inside.4310 = icmp ule i32 %local.resolved.extent.4302, %stack.sub.4309
  %descriptor.payload.inside.4311 = icmp ule i32 %local.resolved.payload.4303, %local.resolved.extent.4302
  %descriptor.owner.offset.valid.4312 = and i1 %descriptor.owner.inside.4307, %descriptor.offset.inside.4308
  %descriptor.range.inside.4314 = and i1 %descriptor.owner.offset.valid.4312, %descriptor.extent.inside.4310
  %descriptor.range.valid.4313 = and i1 %descriptor.range.inside.4314, %descriptor.payload.inside.4311
  %descriptor.type.valid.4315 = icmp eq i32 6, 6
  %descriptor.valid.4316 = and i1 %descriptor.range.valid.4313, %descriptor.type.valid.4315
  br i1 %descriptor.valid.4316, label %descriptor.valid.4317, label %descriptor.invalid.4318
descriptor.invalid.4318:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4317:
  %descriptor.initialized.status.4319 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4301, i32 %local.resolved.extent.4302)
  %helper.ok.4320 = icmp eq i32 %descriptor.initialized.status.4319, 0
  br i1 %helper.ok.4320, label %helper.continue.4321, label %frame.failure.0
helper.continue.4321:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4301, i32 20, i32 %local.resolved.payload.4303, i32 %local.resolved.owner.end.4304, i32 %local.resolved.extent.4302)
  %context.field.4322 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4323 = load i32, ptr %context.field.4322, align 4
  %runtime.ok.4324 = icmp eq i32 %context.value.4323, 0
  br i1 %runtime.ok.4324, label %runtime.continue.4325, label %frame.failure.0
runtime.continue.4325:
  %context.field.4326 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4327 = load i32, ptr %context.field.4326, align 4
  %stack.sub.4330 = sub i32 %local.resolved.owner.end.4098, %local.resolved.offset.4095
  %descriptor.owner.inside.4328 = icmp ule i32 %local.resolved.owner.end.4098, %context.value.4327
  %descriptor.offset.inside.4329 = icmp ule i32 %local.resolved.offset.4095, %local.resolved.owner.end.4098
  %descriptor.extent.inside.4331 = icmp ule i32 %local.resolved.extent.4096, %stack.sub.4330
  %descriptor.payload.inside.4332 = icmp ule i32 %local.resolved.payload.4097, %local.resolved.extent.4096
  %descriptor.owner.offset.valid.4333 = and i1 %descriptor.owner.inside.4328, %descriptor.offset.inside.4329
  %descriptor.range.inside.4335 = and i1 %descriptor.owner.offset.valid.4333, %descriptor.extent.inside.4331
  %descriptor.range.valid.4334 = and i1 %descriptor.range.inside.4335, %descriptor.payload.inside.4332
  %descriptor.type.valid.4336 = icmp eq i32 6, 6
  %descriptor.valid.4337 = and i1 %descriptor.range.valid.4334, %descriptor.type.valid.4336
  br i1 %descriptor.valid.4337, label %descriptor.valid.4338, label %descriptor.invalid.4339
descriptor.invalid.4339:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4338:
  %descriptor.initialized.status.4340 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4095, i32 %local.resolved.extent.4096)
  %helper.ok.4341 = icmp eq i32 %descriptor.initialized.status.4340, 0
  br i1 %helper.ok.4341, label %helper.continue.4342, label %frame.failure.0
helper.continue.4342:
  %context.field.4343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4344 = load i32, ptr %context.field.4343, align 4
  %stack.sub.4347 = sub i32 %local.resolved.owner.end.4304, %local.resolved.offset.4301
  %descriptor.owner.inside.4345 = icmp ule i32 %local.resolved.owner.end.4304, %context.value.4344
  %descriptor.offset.inside.4346 = icmp ule i32 %local.resolved.offset.4301, %local.resolved.owner.end.4304
  %descriptor.extent.inside.4348 = icmp ule i32 %local.resolved.extent.4302, %stack.sub.4347
  %descriptor.payload.inside.4349 = icmp ule i32 %local.resolved.payload.4303, %local.resolved.extent.4302
  %descriptor.owner.offset.valid.4350 = and i1 %descriptor.owner.inside.4345, %descriptor.offset.inside.4346
  %descriptor.range.inside.4352 = and i1 %descriptor.owner.offset.valid.4350, %descriptor.extent.inside.4348
  %descriptor.range.valid.4351 = and i1 %descriptor.range.inside.4352, %descriptor.payload.inside.4349
  %descriptor.type.valid.4353 = icmp eq i32 6, 6
  %descriptor.valid.4354 = and i1 %descriptor.range.valid.4351, %descriptor.type.valid.4353
  br i1 %descriptor.valid.4354, label %descriptor.valid.4355, label %descriptor.invalid.4356
descriptor.invalid.4356:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4355:
  %descriptor.initialized.status.4357 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4301, i32 %local.resolved.extent.4302)
  %helper.ok.4358 = icmp eq i32 %descriptor.initialized.status.4357, 0
  br i1 %helper.ok.4358, label %helper.continue.4359, label %frame.failure.0
helper.continue.4359:
  %local.is.active.4360 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4360, label %local.descriptor.active.4361, label %local.descriptor.inactive.4362
local.descriptor.active.4361:
  %local.check.offset.4364 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4365 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4366 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4367 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4369 = load i32, ptr %context.field.4368, align 4
  %stack.sub.4372 = sub i32 %local.check.owner.end.4367, %local.check.offset.4364
  %descriptor.owner.inside.4370 = icmp ule i32 %local.check.owner.end.4367, %context.value.4369
  %descriptor.offset.inside.4371 = icmp ule i32 %local.check.offset.4364, %local.check.owner.end.4367
  %descriptor.extent.inside.4373 = icmp ule i32 %local.check.extent.4365, %stack.sub.4372
  %descriptor.payload.inside.4374 = icmp ule i32 %local.check.payload.4366, %local.check.extent.4365
  %descriptor.owner.offset.valid.4375 = and i1 %descriptor.owner.inside.4370, %descriptor.offset.inside.4371
  %descriptor.range.inside.4377 = and i1 %descriptor.owner.offset.valid.4375, %descriptor.extent.inside.4373
  %descriptor.range.valid.4376 = and i1 %descriptor.range.inside.4377, %descriptor.payload.inside.4374
  br i1 %descriptor.range.valid.4376, label %descriptor.valid.4378, label %descriptor.invalid.4379
descriptor.invalid.4379:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4378:
  %descriptor.initialized.status.4380 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4364, i32 %local.check.extent.4365)
  %helper.ok.4381 = icmp eq i32 %descriptor.initialized.status.4380, 0
  br i1 %helper.ok.4381, label %helper.continue.4382, label %frame.failure.0
helper.continue.4382:
  br label %local.descriptor.checked.4363
local.descriptor.inactive.4362:
  br label %local.descriptor.checked.4363
local.descriptor.checked.4363:
  %local.is.active.4383 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4383, label %local.descriptor.active.4384, label %local.descriptor.inactive.4385
local.descriptor.active.4384:
  %local.check.offset.4387 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4388 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4389 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4390 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4392 = load i32, ptr %context.field.4391, align 4
  %stack.sub.4395 = sub i32 %local.check.owner.end.4390, %local.check.offset.4387
  %descriptor.owner.inside.4393 = icmp ule i32 %local.check.owner.end.4390, %context.value.4392
  %descriptor.offset.inside.4394 = icmp ule i32 %local.check.offset.4387, %local.check.owner.end.4390
  %descriptor.extent.inside.4396 = icmp ule i32 %local.check.extent.4388, %stack.sub.4395
  %descriptor.payload.inside.4397 = icmp ule i32 %local.check.payload.4389, %local.check.extent.4388
  %descriptor.owner.offset.valid.4398 = and i1 %descriptor.owner.inside.4393, %descriptor.offset.inside.4394
  %descriptor.range.inside.4400 = and i1 %descriptor.owner.offset.valid.4398, %descriptor.extent.inside.4396
  %descriptor.range.valid.4399 = and i1 %descriptor.range.inside.4400, %descriptor.payload.inside.4397
  br i1 %descriptor.range.valid.4399, label %descriptor.valid.4401, label %descriptor.invalid.4402
descriptor.invalid.4402:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4401:
  %descriptor.initialized.status.4403 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4387, i32 %local.check.extent.4388)
  %helper.ok.4404 = icmp eq i32 %descriptor.initialized.status.4403, 0
  br i1 %helper.ok.4404, label %helper.continue.4405, label %frame.failure.0
helper.continue.4405:
  br label %local.descriptor.checked.4386
local.descriptor.inactive.4385:
  br label %local.descriptor.checked.4386
local.descriptor.checked.4386:
  %local.is.active.4406 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4406, label %local.descriptor.active.4407, label %local.descriptor.inactive.4408
local.descriptor.active.4407:
  %local.check.offset.4410 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4411 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4412 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4413 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4415 = load i32, ptr %context.field.4414, align 4
  %stack.sub.4418 = sub i32 %local.check.owner.end.4413, %local.check.offset.4410
  %descriptor.owner.inside.4416 = icmp ule i32 %local.check.owner.end.4413, %context.value.4415
  %descriptor.offset.inside.4417 = icmp ule i32 %local.check.offset.4410, %local.check.owner.end.4413
  %descriptor.extent.inside.4419 = icmp ule i32 %local.check.extent.4411, %stack.sub.4418
  %descriptor.payload.inside.4420 = icmp ule i32 %local.check.payload.4412, %local.check.extent.4411
  %descriptor.owner.offset.valid.4421 = and i1 %descriptor.owner.inside.4416, %descriptor.offset.inside.4417
  %descriptor.range.inside.4423 = and i1 %descriptor.owner.offset.valid.4421, %descriptor.extent.inside.4419
  %descriptor.range.valid.4422 = and i1 %descriptor.range.inside.4423, %descriptor.payload.inside.4420
  br i1 %descriptor.range.valid.4422, label %descriptor.valid.4424, label %descriptor.invalid.4425
descriptor.invalid.4425:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4424:
  %descriptor.initialized.status.4426 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4410, i32 %local.check.extent.4411)
  %helper.ok.4427 = icmp eq i32 %descriptor.initialized.status.4426, 0
  br i1 %helper.ok.4427, label %helper.continue.4428, label %frame.failure.0
helper.continue.4428:
  br label %local.descriptor.checked.4409
local.descriptor.inactive.4408:
  br label %local.descriptor.checked.4409
local.descriptor.checked.4409:
  %local.is.active.4429 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4429, label %local.descriptor.active.4430, label %local.descriptor.inactive.4431
local.descriptor.active.4430:
  %local.check.offset.4433 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4434 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4435 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4436 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4438 = load i32, ptr %context.field.4437, align 4
  %stack.sub.4441 = sub i32 %local.check.owner.end.4436, %local.check.offset.4433
  %descriptor.owner.inside.4439 = icmp ule i32 %local.check.owner.end.4436, %context.value.4438
  %descriptor.offset.inside.4440 = icmp ule i32 %local.check.offset.4433, %local.check.owner.end.4436
  %descriptor.extent.inside.4442 = icmp ule i32 %local.check.extent.4434, %stack.sub.4441
  %descriptor.payload.inside.4443 = icmp ule i32 %local.check.payload.4435, %local.check.extent.4434
  %descriptor.owner.offset.valid.4444 = and i1 %descriptor.owner.inside.4439, %descriptor.offset.inside.4440
  %descriptor.range.inside.4446 = and i1 %descriptor.owner.offset.valid.4444, %descriptor.extent.inside.4442
  %descriptor.range.valid.4445 = and i1 %descriptor.range.inside.4446, %descriptor.payload.inside.4443
  br i1 %descriptor.range.valid.4445, label %descriptor.valid.4447, label %descriptor.invalid.4448
descriptor.invalid.4448:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4447:
  %descriptor.initialized.status.4449 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4433, i32 %local.check.extent.4434)
  %helper.ok.4450 = icmp eq i32 %descriptor.initialized.status.4449, 0
  br i1 %helper.ok.4450, label %helper.continue.4451, label %frame.failure.0
helper.continue.4451:
  br label %local.descriptor.checked.4432
local.descriptor.inactive.4431:
  br label %local.descriptor.checked.4432
local.descriptor.checked.4432:
  %local.is.active.4452 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4452, label %local.descriptor.active.4453, label %local.descriptor.inactive.4454
local.descriptor.active.4453:
  %local.check.offset.4456 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4457 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4458 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4459 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4460 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4461 = load i32, ptr %context.field.4460, align 4
  %stack.sub.4464 = sub i32 %local.check.owner.end.4459, %local.check.offset.4456
  %descriptor.owner.inside.4462 = icmp ule i32 %local.check.owner.end.4459, %context.value.4461
  %descriptor.offset.inside.4463 = icmp ule i32 %local.check.offset.4456, %local.check.owner.end.4459
  %descriptor.extent.inside.4465 = icmp ule i32 %local.check.extent.4457, %stack.sub.4464
  %descriptor.payload.inside.4466 = icmp ule i32 %local.check.payload.4458, %local.check.extent.4457
  %descriptor.owner.offset.valid.4467 = and i1 %descriptor.owner.inside.4462, %descriptor.offset.inside.4463
  %descriptor.range.inside.4469 = and i1 %descriptor.owner.offset.valid.4467, %descriptor.extent.inside.4465
  %descriptor.range.valid.4468 = and i1 %descriptor.range.inside.4469, %descriptor.payload.inside.4466
  br i1 %descriptor.range.valid.4468, label %descriptor.valid.4470, label %descriptor.invalid.4471
descriptor.invalid.4471:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4470:
  %descriptor.initialized.status.4472 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4456, i32 %local.check.extent.4457)
  %helper.ok.4473 = icmp eq i32 %descriptor.initialized.status.4472, 0
  br i1 %helper.ok.4473, label %helper.continue.4474, label %frame.failure.0
helper.continue.4474:
  br label %local.descriptor.checked.4455
local.descriptor.inactive.4454:
  br label %local.descriptor.checked.4455
local.descriptor.checked.4455:
  %local.is.active.4475 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4475, label %local.descriptor.active.4476, label %local.descriptor.inactive.4477
local.descriptor.active.4476:
  %local.check.offset.4479 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4480 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4481 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4482 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4483 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4484 = load i32, ptr %context.field.4483, align 4
  %stack.sub.4487 = sub i32 %local.check.owner.end.4482, %local.check.offset.4479
  %descriptor.owner.inside.4485 = icmp ule i32 %local.check.owner.end.4482, %context.value.4484
  %descriptor.offset.inside.4486 = icmp ule i32 %local.check.offset.4479, %local.check.owner.end.4482
  %descriptor.extent.inside.4488 = icmp ule i32 %local.check.extent.4480, %stack.sub.4487
  %descriptor.payload.inside.4489 = icmp ule i32 %local.check.payload.4481, %local.check.extent.4480
  %descriptor.owner.offset.valid.4490 = and i1 %descriptor.owner.inside.4485, %descriptor.offset.inside.4486
  %descriptor.range.inside.4492 = and i1 %descriptor.owner.offset.valid.4490, %descriptor.extent.inside.4488
  %descriptor.range.valid.4491 = and i1 %descriptor.range.inside.4492, %descriptor.payload.inside.4489
  br i1 %descriptor.range.valid.4491, label %descriptor.valid.4493, label %descriptor.invalid.4494
descriptor.invalid.4494:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4493:
  %descriptor.initialized.status.4495 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4479, i32 %local.check.extent.4480)
  %helper.ok.4496 = icmp eq i32 %descriptor.initialized.status.4495, 0
  br i1 %helper.ok.4496, label %helper.continue.4497, label %frame.failure.0
helper.continue.4497:
  br label %local.descriptor.checked.4478
local.descriptor.inactive.4477:
  br label %local.descriptor.checked.4478
local.descriptor.checked.4478:
  %local.is.active.4498 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4498, label %local.descriptor.active.4499, label %local.descriptor.inactive.4500
local.descriptor.active.4499:
  %local.check.offset.4502 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4503 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4504 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4505 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4507 = load i32, ptr %context.field.4506, align 4
  %stack.sub.4510 = sub i32 %local.check.owner.end.4505, %local.check.offset.4502
  %descriptor.owner.inside.4508 = icmp ule i32 %local.check.owner.end.4505, %context.value.4507
  %descriptor.offset.inside.4509 = icmp ule i32 %local.check.offset.4502, %local.check.owner.end.4505
  %descriptor.extent.inside.4511 = icmp ule i32 %local.check.extent.4503, %stack.sub.4510
  %descriptor.payload.inside.4512 = icmp ule i32 %local.check.payload.4504, %local.check.extent.4503
  %descriptor.owner.offset.valid.4513 = and i1 %descriptor.owner.inside.4508, %descriptor.offset.inside.4509
  %descriptor.range.inside.4515 = and i1 %descriptor.owner.offset.valid.4513, %descriptor.extent.inside.4511
  %descriptor.range.valid.4514 = and i1 %descriptor.range.inside.4515, %descriptor.payload.inside.4512
  br i1 %descriptor.range.valid.4514, label %descriptor.valid.4516, label %descriptor.invalid.4517
descriptor.invalid.4517:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4516:
  %descriptor.initialized.status.4518 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4502, i32 %local.check.extent.4503)
  %helper.ok.4519 = icmp eq i32 %descriptor.initialized.status.4518, 0
  br i1 %helper.ok.4519, label %helper.continue.4520, label %frame.failure.0
helper.continue.4520:
  br label %local.descriptor.checked.4501
local.descriptor.inactive.4500:
  br label %local.descriptor.checked.4501
local.descriptor.checked.4501:
  %step.status.4521 = call i32 @al_owning_charge_step(ptr %ctx, i32 60)
  %helper.ok.4522 = icmp eq i32 %step.status.4521, 0
  br i1 %helper.ok.4522, label %helper.continue.4523, label %frame.failure.0
helper.continue.4523:
  %context.field.4524 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4525 = load i32, ptr %context.field.4524, align 4
  %string.concat.units.4526 = alloca i32, align 4
  %string.concat.payload.pointer.4527 = alloca i32, align 4
  %string.concat.extent.pointer.4528 = alloca i32, align 4
  %string.concat.plan.status.4529 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %local.resolved.offset.4095, i32 %local.resolved.extent.4096, i32 %local.resolved.offset.4301, i32 %local.resolved.extent.4302, i32 61, ptr %string.concat.units.4526, ptr %string.concat.payload.pointer.4527, ptr %string.concat.extent.pointer.4528)
  %helper.ok.4530 = icmp eq i32 %string.concat.plan.status.4529, 0
  br i1 %helper.ok.4530, label %helper.continue.4531, label %frame.failure.0
helper.continue.4531:
  %string.concat.payload.4532 = load i32, ptr %string.concat.payload.pointer.4527, align 4
  %string.concat.extent.4533 = load i32, ptr %string.concat.extent.pointer.4528, align 4
  %stack.offset.4534 = add i32 %context.value.4525, %string.concat.extent.4533
  %reserve.status.4535 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4534, i32 62)
  %reserve.ok.4536 = icmp eq i32 %reserve.status.4535, 0
  br i1 %reserve.ok.4536, label %reserve.continue.4537, label %frame.failure.0
reserve.continue.4537:
  %string.concat.write.status.4538 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.4525, i32 %string.concat.extent.4533, i32 %local.resolved.offset.4095, i32 %local.resolved.extent.4096, i32 %local.resolved.offset.4301, i32 %local.resolved.extent.4302, i32 6, i32 61)
  %helper.ok.4539 = icmp eq i32 %string.concat.write.status.4538, 0
  br i1 %helper.ok.4539, label %helper.continue.4540, label %frame.failure.0
helper.continue.4540:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.4532, i32 0)
  %context.field.4541 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4542 = load i32, ptr %context.field.4541, align 4
  %runtime.ok.4543 = icmp eq i32 %context.value.4542, 0
  br i1 %runtime.ok.4543, label %runtime.continue.4544, label %frame.failure.0
runtime.continue.4544:
  %context.field.4545 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4546 = load i32, ptr %context.field.4545, align 4
  %stack.sub.4549 = sub i32 %stack.offset.4534, %context.value.4525
  %descriptor.owner.inside.4547 = icmp ule i32 %stack.offset.4534, %context.value.4546
  %descriptor.offset.inside.4548 = icmp ule i32 %context.value.4525, %stack.offset.4534
  %descriptor.extent.inside.4550 = icmp ule i32 %string.concat.extent.4533, %stack.sub.4549
  %descriptor.payload.inside.4551 = icmp ule i32 %string.concat.payload.4532, %string.concat.extent.4533
  %descriptor.owner.offset.valid.4552 = and i1 %descriptor.owner.inside.4547, %descriptor.offset.inside.4548
  %descriptor.range.inside.4554 = and i1 %descriptor.owner.offset.valid.4552, %descriptor.extent.inside.4550
  %descriptor.range.valid.4553 = and i1 %descriptor.range.inside.4554, %descriptor.payload.inside.4551
  %descriptor.type.valid.4555 = icmp eq i32 6, 6
  %descriptor.valid.4556 = and i1 %descriptor.range.valid.4553, %descriptor.type.valid.4555
  br i1 %descriptor.valid.4556, label %descriptor.valid.4557, label %descriptor.invalid.4558
descriptor.invalid.4558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4557:
  %descriptor.initialized.status.4559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.4525, i32 %string.concat.extent.4533)
  %helper.ok.4560 = icmp eq i32 %descriptor.initialized.status.4559, 0
  br i1 %helper.ok.4560, label %helper.continue.4561, label %frame.failure.0
helper.continue.4561:
  %local.is.active.4562 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4562, label %local.descriptor.active.4563, label %local.descriptor.inactive.4564
local.descriptor.active.4563:
  %local.check.offset.4566 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4567 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4568 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4569 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4571 = load i32, ptr %context.field.4570, align 4
  %stack.sub.4574 = sub i32 %local.check.owner.end.4569, %local.check.offset.4566
  %descriptor.owner.inside.4572 = icmp ule i32 %local.check.owner.end.4569, %context.value.4571
  %descriptor.offset.inside.4573 = icmp ule i32 %local.check.offset.4566, %local.check.owner.end.4569
  %descriptor.extent.inside.4575 = icmp ule i32 %local.check.extent.4567, %stack.sub.4574
  %descriptor.payload.inside.4576 = icmp ule i32 %local.check.payload.4568, %local.check.extent.4567
  %descriptor.owner.offset.valid.4577 = and i1 %descriptor.owner.inside.4572, %descriptor.offset.inside.4573
  %descriptor.range.inside.4579 = and i1 %descriptor.owner.offset.valid.4577, %descriptor.extent.inside.4575
  %descriptor.range.valid.4578 = and i1 %descriptor.range.inside.4579, %descriptor.payload.inside.4576
  br i1 %descriptor.range.valid.4578, label %descriptor.valid.4580, label %descriptor.invalid.4581
descriptor.invalid.4581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4580:
  %descriptor.initialized.status.4582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4566, i32 %local.check.extent.4567)
  %helper.ok.4583 = icmp eq i32 %descriptor.initialized.status.4582, 0
  br i1 %helper.ok.4583, label %helper.continue.4584, label %frame.failure.0
helper.continue.4584:
  br label %local.descriptor.checked.4565
local.descriptor.inactive.4564:
  br label %local.descriptor.checked.4565
local.descriptor.checked.4565:
  %local.is.active.4585 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4585, label %local.descriptor.active.4586, label %local.descriptor.inactive.4587
local.descriptor.active.4586:
  %local.check.offset.4589 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4590 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4591 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4592 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4594 = load i32, ptr %context.field.4593, align 4
  %stack.sub.4597 = sub i32 %local.check.owner.end.4592, %local.check.offset.4589
  %descriptor.owner.inside.4595 = icmp ule i32 %local.check.owner.end.4592, %context.value.4594
  %descriptor.offset.inside.4596 = icmp ule i32 %local.check.offset.4589, %local.check.owner.end.4592
  %descriptor.extent.inside.4598 = icmp ule i32 %local.check.extent.4590, %stack.sub.4597
  %descriptor.payload.inside.4599 = icmp ule i32 %local.check.payload.4591, %local.check.extent.4590
  %descriptor.owner.offset.valid.4600 = and i1 %descriptor.owner.inside.4595, %descriptor.offset.inside.4596
  %descriptor.range.inside.4602 = and i1 %descriptor.owner.offset.valid.4600, %descriptor.extent.inside.4598
  %descriptor.range.valid.4601 = and i1 %descriptor.range.inside.4602, %descriptor.payload.inside.4599
  br i1 %descriptor.range.valid.4601, label %descriptor.valid.4603, label %descriptor.invalid.4604
descriptor.invalid.4604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4603:
  %descriptor.initialized.status.4605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4589, i32 %local.check.extent.4590)
  %helper.ok.4606 = icmp eq i32 %descriptor.initialized.status.4605, 0
  br i1 %helper.ok.4606, label %helper.continue.4607, label %frame.failure.0
helper.continue.4607:
  br label %local.descriptor.checked.4588
local.descriptor.inactive.4587:
  br label %local.descriptor.checked.4588
local.descriptor.checked.4588:
  %local.is.active.4608 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4608, label %local.descriptor.active.4609, label %local.descriptor.inactive.4610
local.descriptor.active.4609:
  %local.check.offset.4612 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4613 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4614 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4615 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4617 = load i32, ptr %context.field.4616, align 4
  %stack.sub.4620 = sub i32 %local.check.owner.end.4615, %local.check.offset.4612
  %descriptor.owner.inside.4618 = icmp ule i32 %local.check.owner.end.4615, %context.value.4617
  %descriptor.offset.inside.4619 = icmp ule i32 %local.check.offset.4612, %local.check.owner.end.4615
  %descriptor.extent.inside.4621 = icmp ule i32 %local.check.extent.4613, %stack.sub.4620
  %descriptor.payload.inside.4622 = icmp ule i32 %local.check.payload.4614, %local.check.extent.4613
  %descriptor.owner.offset.valid.4623 = and i1 %descriptor.owner.inside.4618, %descriptor.offset.inside.4619
  %descriptor.range.inside.4625 = and i1 %descriptor.owner.offset.valid.4623, %descriptor.extent.inside.4621
  %descriptor.range.valid.4624 = and i1 %descriptor.range.inside.4625, %descriptor.payload.inside.4622
  br i1 %descriptor.range.valid.4624, label %descriptor.valid.4626, label %descriptor.invalid.4627
descriptor.invalid.4627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4626:
  %descriptor.initialized.status.4628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4612, i32 %local.check.extent.4613)
  %helper.ok.4629 = icmp eq i32 %descriptor.initialized.status.4628, 0
  br i1 %helper.ok.4629, label %helper.continue.4630, label %frame.failure.0
helper.continue.4630:
  br label %local.descriptor.checked.4611
local.descriptor.inactive.4610:
  br label %local.descriptor.checked.4611
local.descriptor.checked.4611:
  %local.is.active.4631 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4631, label %local.descriptor.active.4632, label %local.descriptor.inactive.4633
local.descriptor.active.4632:
  %local.check.offset.4635 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4636 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4637 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4638 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4640 = load i32, ptr %context.field.4639, align 4
  %stack.sub.4643 = sub i32 %local.check.owner.end.4638, %local.check.offset.4635
  %descriptor.owner.inside.4641 = icmp ule i32 %local.check.owner.end.4638, %context.value.4640
  %descriptor.offset.inside.4642 = icmp ule i32 %local.check.offset.4635, %local.check.owner.end.4638
  %descriptor.extent.inside.4644 = icmp ule i32 %local.check.extent.4636, %stack.sub.4643
  %descriptor.payload.inside.4645 = icmp ule i32 %local.check.payload.4637, %local.check.extent.4636
  %descriptor.owner.offset.valid.4646 = and i1 %descriptor.owner.inside.4641, %descriptor.offset.inside.4642
  %descriptor.range.inside.4648 = and i1 %descriptor.owner.offset.valid.4646, %descriptor.extent.inside.4644
  %descriptor.range.valid.4647 = and i1 %descriptor.range.inside.4648, %descriptor.payload.inside.4645
  br i1 %descriptor.range.valid.4647, label %descriptor.valid.4649, label %descriptor.invalid.4650
descriptor.invalid.4650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4649:
  %descriptor.initialized.status.4651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4635, i32 %local.check.extent.4636)
  %helper.ok.4652 = icmp eq i32 %descriptor.initialized.status.4651, 0
  br i1 %helper.ok.4652, label %helper.continue.4653, label %frame.failure.0
helper.continue.4653:
  br label %local.descriptor.checked.4634
local.descriptor.inactive.4633:
  br label %local.descriptor.checked.4634
local.descriptor.checked.4634:
  %local.is.active.4654 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4654, label %local.descriptor.active.4655, label %local.descriptor.inactive.4656
local.descriptor.active.4655:
  %local.check.offset.4658 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4659 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4660 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4661 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4663 = load i32, ptr %context.field.4662, align 4
  %stack.sub.4666 = sub i32 %local.check.owner.end.4661, %local.check.offset.4658
  %descriptor.owner.inside.4664 = icmp ule i32 %local.check.owner.end.4661, %context.value.4663
  %descriptor.offset.inside.4665 = icmp ule i32 %local.check.offset.4658, %local.check.owner.end.4661
  %descriptor.extent.inside.4667 = icmp ule i32 %local.check.extent.4659, %stack.sub.4666
  %descriptor.payload.inside.4668 = icmp ule i32 %local.check.payload.4660, %local.check.extent.4659
  %descriptor.owner.offset.valid.4669 = and i1 %descriptor.owner.inside.4664, %descriptor.offset.inside.4665
  %descriptor.range.inside.4671 = and i1 %descriptor.owner.offset.valid.4669, %descriptor.extent.inside.4667
  %descriptor.range.valid.4670 = and i1 %descriptor.range.inside.4671, %descriptor.payload.inside.4668
  br i1 %descriptor.range.valid.4670, label %descriptor.valid.4672, label %descriptor.invalid.4673
descriptor.invalid.4673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4672:
  %descriptor.initialized.status.4674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4658, i32 %local.check.extent.4659)
  %helper.ok.4675 = icmp eq i32 %descriptor.initialized.status.4674, 0
  br i1 %helper.ok.4675, label %helper.continue.4676, label %frame.failure.0
helper.continue.4676:
  br label %local.descriptor.checked.4657
local.descriptor.inactive.4656:
  br label %local.descriptor.checked.4657
local.descriptor.checked.4657:
  %local.is.active.4677 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4677, label %local.descriptor.active.4678, label %local.descriptor.inactive.4679
local.descriptor.active.4678:
  %local.check.offset.4681 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4682 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4683 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4684 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4686 = load i32, ptr %context.field.4685, align 4
  %stack.sub.4689 = sub i32 %local.check.owner.end.4684, %local.check.offset.4681
  %descriptor.owner.inside.4687 = icmp ule i32 %local.check.owner.end.4684, %context.value.4686
  %descriptor.offset.inside.4688 = icmp ule i32 %local.check.offset.4681, %local.check.owner.end.4684
  %descriptor.extent.inside.4690 = icmp ule i32 %local.check.extent.4682, %stack.sub.4689
  %descriptor.payload.inside.4691 = icmp ule i32 %local.check.payload.4683, %local.check.extent.4682
  %descriptor.owner.offset.valid.4692 = and i1 %descriptor.owner.inside.4687, %descriptor.offset.inside.4688
  %descriptor.range.inside.4694 = and i1 %descriptor.owner.offset.valid.4692, %descriptor.extent.inside.4690
  %descriptor.range.valid.4693 = and i1 %descriptor.range.inside.4694, %descriptor.payload.inside.4691
  br i1 %descriptor.range.valid.4693, label %descriptor.valid.4695, label %descriptor.invalid.4696
descriptor.invalid.4696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4695:
  %descriptor.initialized.status.4697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4681, i32 %local.check.extent.4682)
  %helper.ok.4698 = icmp eq i32 %descriptor.initialized.status.4697, 0
  br i1 %helper.ok.4698, label %helper.continue.4699, label %frame.failure.0
helper.continue.4699:
  br label %local.descriptor.checked.4680
local.descriptor.inactive.4679:
  br label %local.descriptor.checked.4680
local.descriptor.checked.4680:
  %local.is.active.4700 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4700, label %local.descriptor.active.4701, label %local.descriptor.inactive.4702
local.descriptor.active.4701:
  %local.check.offset.4704 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4705 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4706 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4707 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4708 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4709 = load i32, ptr %context.field.4708, align 4
  %stack.sub.4712 = sub i32 %local.check.owner.end.4707, %local.check.offset.4704
  %descriptor.owner.inside.4710 = icmp ule i32 %local.check.owner.end.4707, %context.value.4709
  %descriptor.offset.inside.4711 = icmp ule i32 %local.check.offset.4704, %local.check.owner.end.4707
  %descriptor.extent.inside.4713 = icmp ule i32 %local.check.extent.4705, %stack.sub.4712
  %descriptor.payload.inside.4714 = icmp ule i32 %local.check.payload.4706, %local.check.extent.4705
  %descriptor.owner.offset.valid.4715 = and i1 %descriptor.owner.inside.4710, %descriptor.offset.inside.4711
  %descriptor.range.inside.4717 = and i1 %descriptor.owner.offset.valid.4715, %descriptor.extent.inside.4713
  %descriptor.range.valid.4716 = and i1 %descriptor.range.inside.4717, %descriptor.payload.inside.4714
  br i1 %descriptor.range.valid.4716, label %descriptor.valid.4718, label %descriptor.invalid.4719
descriptor.invalid.4719:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4718:
  %descriptor.initialized.status.4720 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4704, i32 %local.check.extent.4705)
  %helper.ok.4721 = icmp eq i32 %descriptor.initialized.status.4720, 0
  br i1 %helper.ok.4721, label %helper.continue.4722, label %frame.failure.0
helper.continue.4722:
  br label %local.descriptor.checked.4703
local.descriptor.inactive.4702:
  br label %local.descriptor.checked.4703
local.descriptor.checked.4703:
  %step.status.4723 = call i32 @al_owning_charge_step(ptr %ctx, i32 63)
  %helper.ok.4724 = icmp eq i32 %step.status.4723, 0
  br i1 %helper.ok.4724, label %helper.continue.4725, label %frame.failure.0
helper.continue.4725:
  store i1 true, ptr %local.active.32, align 1
  store i32 %context.value.4525, ptr %local.offset.33, align 4
  store i32 %string.concat.extent.4533, ptr %local.extent.34, align 4
  store i32 %string.concat.payload.4532, ptr %local.payload.35, align 4
  store i32 %stack.offset.4534, ptr %local.owner.end.36, align 4
  store i32 6, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.4525, i32 20, i32 %string.concat.payload.4532, i32 %stack.offset.4534, i32 %string.concat.extent.4533)
  %context.field.4726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4727 = load i32, ptr %context.field.4726, align 4
  %runtime.ok.4728 = icmp eq i32 %context.value.4727, 0
  br i1 %runtime.ok.4728, label %runtime.continue.4729, label %frame.failure.0
runtime.continue.4729:
  %local.is.active.4730 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4730, label %local.descriptor.active.4731, label %local.descriptor.inactive.4732
local.descriptor.active.4731:
  %local.check.offset.4734 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4735 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4736 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4737 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4738 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4739 = load i32, ptr %context.field.4738, align 4
  %stack.sub.4742 = sub i32 %local.check.owner.end.4737, %local.check.offset.4734
  %descriptor.owner.inside.4740 = icmp ule i32 %local.check.owner.end.4737, %context.value.4739
  %descriptor.offset.inside.4741 = icmp ule i32 %local.check.offset.4734, %local.check.owner.end.4737
  %descriptor.extent.inside.4743 = icmp ule i32 %local.check.extent.4735, %stack.sub.4742
  %descriptor.payload.inside.4744 = icmp ule i32 %local.check.payload.4736, %local.check.extent.4735
  %descriptor.owner.offset.valid.4745 = and i1 %descriptor.owner.inside.4740, %descriptor.offset.inside.4741
  %descriptor.range.inside.4747 = and i1 %descriptor.owner.offset.valid.4745, %descriptor.extent.inside.4743
  %descriptor.range.valid.4746 = and i1 %descriptor.range.inside.4747, %descriptor.payload.inside.4744
  br i1 %descriptor.range.valid.4746, label %descriptor.valid.4748, label %descriptor.invalid.4749
descriptor.invalid.4749:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4748:
  %descriptor.initialized.status.4750 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4734, i32 %local.check.extent.4735)
  %helper.ok.4751 = icmp eq i32 %descriptor.initialized.status.4750, 0
  br i1 %helper.ok.4751, label %helper.continue.4752, label %frame.failure.0
helper.continue.4752:
  br label %local.descriptor.checked.4733
local.descriptor.inactive.4732:
  br label %local.descriptor.checked.4733
local.descriptor.checked.4733:
  %local.is.active.4753 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4753, label %local.descriptor.active.4754, label %local.descriptor.inactive.4755
local.descriptor.active.4754:
  %local.check.offset.4757 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4758 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4759 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4760 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4761 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4762 = load i32, ptr %context.field.4761, align 4
  %stack.sub.4765 = sub i32 %local.check.owner.end.4760, %local.check.offset.4757
  %descriptor.owner.inside.4763 = icmp ule i32 %local.check.owner.end.4760, %context.value.4762
  %descriptor.offset.inside.4764 = icmp ule i32 %local.check.offset.4757, %local.check.owner.end.4760
  %descriptor.extent.inside.4766 = icmp ule i32 %local.check.extent.4758, %stack.sub.4765
  %descriptor.payload.inside.4767 = icmp ule i32 %local.check.payload.4759, %local.check.extent.4758
  %descriptor.owner.offset.valid.4768 = and i1 %descriptor.owner.inside.4763, %descriptor.offset.inside.4764
  %descriptor.range.inside.4770 = and i1 %descriptor.owner.offset.valid.4768, %descriptor.extent.inside.4766
  %descriptor.range.valid.4769 = and i1 %descriptor.range.inside.4770, %descriptor.payload.inside.4767
  br i1 %descriptor.range.valid.4769, label %descriptor.valid.4771, label %descriptor.invalid.4772
descriptor.invalid.4772:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4771:
  %descriptor.initialized.status.4773 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4757, i32 %local.check.extent.4758)
  %helper.ok.4774 = icmp eq i32 %descriptor.initialized.status.4773, 0
  br i1 %helper.ok.4774, label %helper.continue.4775, label %frame.failure.0
helper.continue.4775:
  br label %local.descriptor.checked.4756
local.descriptor.inactive.4755:
  br label %local.descriptor.checked.4756
local.descriptor.checked.4756:
  %local.is.active.4776 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4776, label %local.descriptor.active.4777, label %local.descriptor.inactive.4778
local.descriptor.active.4777:
  %local.check.offset.4780 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4781 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4782 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4783 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4784 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4785 = load i32, ptr %context.field.4784, align 4
  %stack.sub.4788 = sub i32 %local.check.owner.end.4783, %local.check.offset.4780
  %descriptor.owner.inside.4786 = icmp ule i32 %local.check.owner.end.4783, %context.value.4785
  %descriptor.offset.inside.4787 = icmp ule i32 %local.check.offset.4780, %local.check.owner.end.4783
  %descriptor.extent.inside.4789 = icmp ule i32 %local.check.extent.4781, %stack.sub.4788
  %descriptor.payload.inside.4790 = icmp ule i32 %local.check.payload.4782, %local.check.extent.4781
  %descriptor.owner.offset.valid.4791 = and i1 %descriptor.owner.inside.4786, %descriptor.offset.inside.4787
  %descriptor.range.inside.4793 = and i1 %descriptor.owner.offset.valid.4791, %descriptor.extent.inside.4789
  %descriptor.range.valid.4792 = and i1 %descriptor.range.inside.4793, %descriptor.payload.inside.4790
  br i1 %descriptor.range.valid.4792, label %descriptor.valid.4794, label %descriptor.invalid.4795
descriptor.invalid.4795:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4794:
  %descriptor.initialized.status.4796 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4780, i32 %local.check.extent.4781)
  %helper.ok.4797 = icmp eq i32 %descriptor.initialized.status.4796, 0
  br i1 %helper.ok.4797, label %helper.continue.4798, label %frame.failure.0
helper.continue.4798:
  br label %local.descriptor.checked.4779
local.descriptor.inactive.4778:
  br label %local.descriptor.checked.4779
local.descriptor.checked.4779:
  %local.is.active.4799 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4799, label %local.descriptor.active.4800, label %local.descriptor.inactive.4801
local.descriptor.active.4800:
  %local.check.offset.4803 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4804 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4805 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4806 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4807 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4808 = load i32, ptr %context.field.4807, align 4
  %stack.sub.4811 = sub i32 %local.check.owner.end.4806, %local.check.offset.4803
  %descriptor.owner.inside.4809 = icmp ule i32 %local.check.owner.end.4806, %context.value.4808
  %descriptor.offset.inside.4810 = icmp ule i32 %local.check.offset.4803, %local.check.owner.end.4806
  %descriptor.extent.inside.4812 = icmp ule i32 %local.check.extent.4804, %stack.sub.4811
  %descriptor.payload.inside.4813 = icmp ule i32 %local.check.payload.4805, %local.check.extent.4804
  %descriptor.owner.offset.valid.4814 = and i1 %descriptor.owner.inside.4809, %descriptor.offset.inside.4810
  %descriptor.range.inside.4816 = and i1 %descriptor.owner.offset.valid.4814, %descriptor.extent.inside.4812
  %descriptor.range.valid.4815 = and i1 %descriptor.range.inside.4816, %descriptor.payload.inside.4813
  br i1 %descriptor.range.valid.4815, label %descriptor.valid.4817, label %descriptor.invalid.4818
descriptor.invalid.4818:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4817:
  %descriptor.initialized.status.4819 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4803, i32 %local.check.extent.4804)
  %helper.ok.4820 = icmp eq i32 %descriptor.initialized.status.4819, 0
  br i1 %helper.ok.4820, label %helper.continue.4821, label %frame.failure.0
helper.continue.4821:
  br label %local.descriptor.checked.4802
local.descriptor.inactive.4801:
  br label %local.descriptor.checked.4802
local.descriptor.checked.4802:
  %local.is.active.4822 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4822, label %local.descriptor.active.4823, label %local.descriptor.inactive.4824
local.descriptor.active.4823:
  %local.check.offset.4826 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4827 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4828 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4829 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4830 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4831 = load i32, ptr %context.field.4830, align 4
  %stack.sub.4834 = sub i32 %local.check.owner.end.4829, %local.check.offset.4826
  %descriptor.owner.inside.4832 = icmp ule i32 %local.check.owner.end.4829, %context.value.4831
  %descriptor.offset.inside.4833 = icmp ule i32 %local.check.offset.4826, %local.check.owner.end.4829
  %descriptor.extent.inside.4835 = icmp ule i32 %local.check.extent.4827, %stack.sub.4834
  %descriptor.payload.inside.4836 = icmp ule i32 %local.check.payload.4828, %local.check.extent.4827
  %descriptor.owner.offset.valid.4837 = and i1 %descriptor.owner.inside.4832, %descriptor.offset.inside.4833
  %descriptor.range.inside.4839 = and i1 %descriptor.owner.offset.valid.4837, %descriptor.extent.inside.4835
  %descriptor.range.valid.4838 = and i1 %descriptor.range.inside.4839, %descriptor.payload.inside.4836
  br i1 %descriptor.range.valid.4838, label %descriptor.valid.4840, label %descriptor.invalid.4841
descriptor.invalid.4841:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4840:
  %descriptor.initialized.status.4842 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4826, i32 %local.check.extent.4827)
  %helper.ok.4843 = icmp eq i32 %descriptor.initialized.status.4842, 0
  br i1 %helper.ok.4843, label %helper.continue.4844, label %frame.failure.0
helper.continue.4844:
  br label %local.descriptor.checked.4825
local.descriptor.inactive.4824:
  br label %local.descriptor.checked.4825
local.descriptor.checked.4825:
  %local.is.active.4845 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4845, label %local.descriptor.active.4846, label %local.descriptor.inactive.4847
local.descriptor.active.4846:
  %local.check.offset.4849 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4850 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4851 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4852 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4853 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4854 = load i32, ptr %context.field.4853, align 4
  %stack.sub.4857 = sub i32 %local.check.owner.end.4852, %local.check.offset.4849
  %descriptor.owner.inside.4855 = icmp ule i32 %local.check.owner.end.4852, %context.value.4854
  %descriptor.offset.inside.4856 = icmp ule i32 %local.check.offset.4849, %local.check.owner.end.4852
  %descriptor.extent.inside.4858 = icmp ule i32 %local.check.extent.4850, %stack.sub.4857
  %descriptor.payload.inside.4859 = icmp ule i32 %local.check.payload.4851, %local.check.extent.4850
  %descriptor.owner.offset.valid.4860 = and i1 %descriptor.owner.inside.4855, %descriptor.offset.inside.4856
  %descriptor.range.inside.4862 = and i1 %descriptor.owner.offset.valid.4860, %descriptor.extent.inside.4858
  %descriptor.range.valid.4861 = and i1 %descriptor.range.inside.4862, %descriptor.payload.inside.4859
  br i1 %descriptor.range.valid.4861, label %descriptor.valid.4863, label %descriptor.invalid.4864
descriptor.invalid.4864:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4863:
  %descriptor.initialized.status.4865 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4849, i32 %local.check.extent.4850)
  %helper.ok.4866 = icmp eq i32 %descriptor.initialized.status.4865, 0
  br i1 %helper.ok.4866, label %helper.continue.4867, label %frame.failure.0
helper.continue.4867:
  br label %local.descriptor.checked.4848
local.descriptor.inactive.4847:
  br label %local.descriptor.checked.4848
local.descriptor.checked.4848:
  %local.is.active.4868 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4868, label %local.descriptor.active.4869, label %local.descriptor.inactive.4870
local.descriptor.active.4869:
  %local.check.offset.4872 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4873 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4874 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4875 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4877 = load i32, ptr %context.field.4876, align 4
  %stack.sub.4880 = sub i32 %local.check.owner.end.4875, %local.check.offset.4872
  %descriptor.owner.inside.4878 = icmp ule i32 %local.check.owner.end.4875, %context.value.4877
  %descriptor.offset.inside.4879 = icmp ule i32 %local.check.offset.4872, %local.check.owner.end.4875
  %descriptor.extent.inside.4881 = icmp ule i32 %local.check.extent.4873, %stack.sub.4880
  %descriptor.payload.inside.4882 = icmp ule i32 %local.check.payload.4874, %local.check.extent.4873
  %descriptor.owner.offset.valid.4883 = and i1 %descriptor.owner.inside.4878, %descriptor.offset.inside.4879
  %descriptor.range.inside.4885 = and i1 %descriptor.owner.offset.valid.4883, %descriptor.extent.inside.4881
  %descriptor.range.valid.4884 = and i1 %descriptor.range.inside.4885, %descriptor.payload.inside.4882
  br i1 %descriptor.range.valid.4884, label %descriptor.valid.4886, label %descriptor.invalid.4887
descriptor.invalid.4887:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4886:
  %descriptor.initialized.status.4888 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4872, i32 %local.check.extent.4873)
  %helper.ok.4889 = icmp eq i32 %descriptor.initialized.status.4888, 0
  br i1 %helper.ok.4889, label %helper.continue.4890, label %frame.failure.0
helper.continue.4890:
  br label %local.descriptor.checked.4871
local.descriptor.inactive.4870:
  br label %local.descriptor.checked.4871
local.descriptor.checked.4871:
  %step.status.4891 = call i32 @al_owning_charge_step(ptr %ctx, i32 64)
  %helper.ok.4892 = icmp eq i32 %step.status.4891, 0
  br i1 %helper.ok.4892, label %helper.continue.4893, label %frame.failure.0
helper.continue.4893:
  %context.field.4894 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4895 = load i32, ptr %context.field.4894, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %step.status.4896 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %helper.ok.4897 = icmp eq i32 %step.status.4896, 0
  br i1 %helper.ok.4897, label %helper.continue.4898, label %frame.failure.0
helper.continue.4898:
  %local.resolved.offset.4899 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.4900 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.4901 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.4902 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4903 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4904 = load i32, ptr %context.field.4903, align 4
  %stack.sub.4907 = sub i32 %local.resolved.owner.end.4902, %local.resolved.offset.4899
  %descriptor.owner.inside.4905 = icmp ule i32 %local.resolved.owner.end.4902, %context.value.4904
  %descriptor.offset.inside.4906 = icmp ule i32 %local.resolved.offset.4899, %local.resolved.owner.end.4902
  %descriptor.extent.inside.4908 = icmp ule i32 %local.resolved.extent.4900, %stack.sub.4907
  %descriptor.payload.inside.4909 = icmp ule i32 %local.resolved.payload.4901, %local.resolved.extent.4900
  %descriptor.owner.offset.valid.4910 = and i1 %descriptor.owner.inside.4905, %descriptor.offset.inside.4906
  %descriptor.range.inside.4912 = and i1 %descriptor.owner.offset.valid.4910, %descriptor.extent.inside.4908
  %descriptor.range.valid.4911 = and i1 %descriptor.range.inside.4912, %descriptor.payload.inside.4909
  %descriptor.type.valid.4913 = icmp eq i32 6, 6
  %descriptor.valid.4914 = and i1 %descriptor.range.valid.4911, %descriptor.type.valid.4913
  br i1 %descriptor.valid.4914, label %descriptor.valid.4915, label %descriptor.invalid.4916
descriptor.invalid.4916:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4915:
  %descriptor.initialized.status.4917 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4899, i32 %local.resolved.extent.4900)
  %helper.ok.4918 = icmp eq i32 %descriptor.initialized.status.4917, 0
  br i1 %helper.ok.4918, label %helper.continue.4919, label %frame.failure.0
helper.continue.4919:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4899, i32 20, i32 %local.resolved.payload.4901, i32 %local.resolved.owner.end.4902, i32 %local.resolved.extent.4900)
  %context.field.4920 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4921 = load i32, ptr %context.field.4920, align 4
  %runtime.ok.4922 = icmp eq i32 %context.value.4921, 0
  br i1 %runtime.ok.4922, label %runtime.continue.4923, label %frame.failure.0
runtime.continue.4923:
  %context.field.4924 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4925 = load i32, ptr %context.field.4924, align 4
  %stack.sub.4928 = sub i32 %local.resolved.owner.end.4902, %local.resolved.offset.4899
  %descriptor.owner.inside.4926 = icmp ule i32 %local.resolved.owner.end.4902, %context.value.4925
  %descriptor.offset.inside.4927 = icmp ule i32 %local.resolved.offset.4899, %local.resolved.owner.end.4902
  %descriptor.extent.inside.4929 = icmp ule i32 %local.resolved.extent.4900, %stack.sub.4928
  %descriptor.payload.inside.4930 = icmp ule i32 %local.resolved.payload.4901, %local.resolved.extent.4900
  %descriptor.owner.offset.valid.4931 = and i1 %descriptor.owner.inside.4926, %descriptor.offset.inside.4927
  %descriptor.range.inside.4933 = and i1 %descriptor.owner.offset.valid.4931, %descriptor.extent.inside.4929
  %descriptor.range.valid.4932 = and i1 %descriptor.range.inside.4933, %descriptor.payload.inside.4930
  %descriptor.type.valid.4934 = icmp eq i32 6, 6
  %descriptor.valid.4935 = and i1 %descriptor.range.valid.4932, %descriptor.type.valid.4934
  br i1 %descriptor.valid.4935, label %descriptor.valid.4936, label %descriptor.invalid.4937
descriptor.invalid.4937:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4936:
  %descriptor.initialized.status.4938 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4899, i32 %local.resolved.extent.4900)
  %helper.ok.4939 = icmp eq i32 %descriptor.initialized.status.4938, 0
  br i1 %helper.ok.4939, label %helper.continue.4940, label %frame.failure.0
helper.continue.4940:
  %local.is.active.4941 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4941, label %local.descriptor.active.4942, label %local.descriptor.inactive.4943
local.descriptor.active.4942:
  %local.check.offset.4945 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4946 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4947 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4948 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4950 = load i32, ptr %context.field.4949, align 4
  %stack.sub.4953 = sub i32 %local.check.owner.end.4948, %local.check.offset.4945
  %descriptor.owner.inside.4951 = icmp ule i32 %local.check.owner.end.4948, %context.value.4950
  %descriptor.offset.inside.4952 = icmp ule i32 %local.check.offset.4945, %local.check.owner.end.4948
  %descriptor.extent.inside.4954 = icmp ule i32 %local.check.extent.4946, %stack.sub.4953
  %descriptor.payload.inside.4955 = icmp ule i32 %local.check.payload.4947, %local.check.extent.4946
  %descriptor.owner.offset.valid.4956 = and i1 %descriptor.owner.inside.4951, %descriptor.offset.inside.4952
  %descriptor.range.inside.4958 = and i1 %descriptor.owner.offset.valid.4956, %descriptor.extent.inside.4954
  %descriptor.range.valid.4957 = and i1 %descriptor.range.inside.4958, %descriptor.payload.inside.4955
  br i1 %descriptor.range.valid.4957, label %descriptor.valid.4959, label %descriptor.invalid.4960
descriptor.invalid.4960:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4959:
  %descriptor.initialized.status.4961 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4945, i32 %local.check.extent.4946)
  %helper.ok.4962 = icmp eq i32 %descriptor.initialized.status.4961, 0
  br i1 %helper.ok.4962, label %helper.continue.4963, label %frame.failure.0
helper.continue.4963:
  br label %local.descriptor.checked.4944
local.descriptor.inactive.4943:
  br label %local.descriptor.checked.4944
local.descriptor.checked.4944:
  %local.is.active.4964 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4964, label %local.descriptor.active.4965, label %local.descriptor.inactive.4966
local.descriptor.active.4965:
  %local.check.offset.4968 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4969 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4970 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4971 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4972 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4973 = load i32, ptr %context.field.4972, align 4
  %stack.sub.4976 = sub i32 %local.check.owner.end.4971, %local.check.offset.4968
  %descriptor.owner.inside.4974 = icmp ule i32 %local.check.owner.end.4971, %context.value.4973
  %descriptor.offset.inside.4975 = icmp ule i32 %local.check.offset.4968, %local.check.owner.end.4971
  %descriptor.extent.inside.4977 = icmp ule i32 %local.check.extent.4969, %stack.sub.4976
  %descriptor.payload.inside.4978 = icmp ule i32 %local.check.payload.4970, %local.check.extent.4969
  %descriptor.owner.offset.valid.4979 = and i1 %descriptor.owner.inside.4974, %descriptor.offset.inside.4975
  %descriptor.range.inside.4981 = and i1 %descriptor.owner.offset.valid.4979, %descriptor.extent.inside.4977
  %descriptor.range.valid.4980 = and i1 %descriptor.range.inside.4981, %descriptor.payload.inside.4978
  br i1 %descriptor.range.valid.4980, label %descriptor.valid.4982, label %descriptor.invalid.4983
descriptor.invalid.4983:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4982:
  %descriptor.initialized.status.4984 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4968, i32 %local.check.extent.4969)
  %helper.ok.4985 = icmp eq i32 %descriptor.initialized.status.4984, 0
  br i1 %helper.ok.4985, label %helper.continue.4986, label %frame.failure.0
helper.continue.4986:
  br label %local.descriptor.checked.4967
local.descriptor.inactive.4966:
  br label %local.descriptor.checked.4967
local.descriptor.checked.4967:
  %local.is.active.4987 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4987, label %local.descriptor.active.4988, label %local.descriptor.inactive.4989
local.descriptor.active.4988:
  %local.check.offset.4991 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4992 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4993 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4994 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4995 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4996 = load i32, ptr %context.field.4995, align 4
  %stack.sub.4999 = sub i32 %local.check.owner.end.4994, %local.check.offset.4991
  %descriptor.owner.inside.4997 = icmp ule i32 %local.check.owner.end.4994, %context.value.4996
  %descriptor.offset.inside.4998 = icmp ule i32 %local.check.offset.4991, %local.check.owner.end.4994
  %descriptor.extent.inside.5000 = icmp ule i32 %local.check.extent.4992, %stack.sub.4999
  %descriptor.payload.inside.5001 = icmp ule i32 %local.check.payload.4993, %local.check.extent.4992
  %descriptor.owner.offset.valid.5002 = and i1 %descriptor.owner.inside.4997, %descriptor.offset.inside.4998
  %descriptor.range.inside.5004 = and i1 %descriptor.owner.offset.valid.5002, %descriptor.extent.inside.5000
  %descriptor.range.valid.5003 = and i1 %descriptor.range.inside.5004, %descriptor.payload.inside.5001
  br i1 %descriptor.range.valid.5003, label %descriptor.valid.5005, label %descriptor.invalid.5006
descriptor.invalid.5006:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5005:
  %descriptor.initialized.status.5007 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4991, i32 %local.check.extent.4992)
  %helper.ok.5008 = icmp eq i32 %descriptor.initialized.status.5007, 0
  br i1 %helper.ok.5008, label %helper.continue.5009, label %frame.failure.0
helper.continue.5009:
  br label %local.descriptor.checked.4990
local.descriptor.inactive.4989:
  br label %local.descriptor.checked.4990
local.descriptor.checked.4990:
  %local.is.active.5010 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5010, label %local.descriptor.active.5011, label %local.descriptor.inactive.5012
local.descriptor.active.5011:
  %local.check.offset.5014 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5015 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5016 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5017 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5018 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5019 = load i32, ptr %context.field.5018, align 4
  %stack.sub.5022 = sub i32 %local.check.owner.end.5017, %local.check.offset.5014
  %descriptor.owner.inside.5020 = icmp ule i32 %local.check.owner.end.5017, %context.value.5019
  %descriptor.offset.inside.5021 = icmp ule i32 %local.check.offset.5014, %local.check.owner.end.5017
  %descriptor.extent.inside.5023 = icmp ule i32 %local.check.extent.5015, %stack.sub.5022
  %descriptor.payload.inside.5024 = icmp ule i32 %local.check.payload.5016, %local.check.extent.5015
  %descriptor.owner.offset.valid.5025 = and i1 %descriptor.owner.inside.5020, %descriptor.offset.inside.5021
  %descriptor.range.inside.5027 = and i1 %descriptor.owner.offset.valid.5025, %descriptor.extent.inside.5023
  %descriptor.range.valid.5026 = and i1 %descriptor.range.inside.5027, %descriptor.payload.inside.5024
  br i1 %descriptor.range.valid.5026, label %descriptor.valid.5028, label %descriptor.invalid.5029
descriptor.invalid.5029:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5028:
  %descriptor.initialized.status.5030 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5014, i32 %local.check.extent.5015)
  %helper.ok.5031 = icmp eq i32 %descriptor.initialized.status.5030, 0
  br i1 %helper.ok.5031, label %helper.continue.5032, label %frame.failure.0
helper.continue.5032:
  br label %local.descriptor.checked.5013
local.descriptor.inactive.5012:
  br label %local.descriptor.checked.5013
local.descriptor.checked.5013:
  %local.is.active.5033 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5033, label %local.descriptor.active.5034, label %local.descriptor.inactive.5035
local.descriptor.active.5034:
  %local.check.offset.5037 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5038 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5039 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5040 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5041 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5042 = load i32, ptr %context.field.5041, align 4
  %stack.sub.5045 = sub i32 %local.check.owner.end.5040, %local.check.offset.5037
  %descriptor.owner.inside.5043 = icmp ule i32 %local.check.owner.end.5040, %context.value.5042
  %descriptor.offset.inside.5044 = icmp ule i32 %local.check.offset.5037, %local.check.owner.end.5040
  %descriptor.extent.inside.5046 = icmp ule i32 %local.check.extent.5038, %stack.sub.5045
  %descriptor.payload.inside.5047 = icmp ule i32 %local.check.payload.5039, %local.check.extent.5038
  %descriptor.owner.offset.valid.5048 = and i1 %descriptor.owner.inside.5043, %descriptor.offset.inside.5044
  %descriptor.range.inside.5050 = and i1 %descriptor.owner.offset.valid.5048, %descriptor.extent.inside.5046
  %descriptor.range.valid.5049 = and i1 %descriptor.range.inside.5050, %descriptor.payload.inside.5047
  br i1 %descriptor.range.valid.5049, label %descriptor.valid.5051, label %descriptor.invalid.5052
descriptor.invalid.5052:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5051:
  %descriptor.initialized.status.5053 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5037, i32 %local.check.extent.5038)
  %helper.ok.5054 = icmp eq i32 %descriptor.initialized.status.5053, 0
  br i1 %helper.ok.5054, label %helper.continue.5055, label %frame.failure.0
helper.continue.5055:
  br label %local.descriptor.checked.5036
local.descriptor.inactive.5035:
  br label %local.descriptor.checked.5036
local.descriptor.checked.5036:
  %local.is.active.5056 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5056, label %local.descriptor.active.5057, label %local.descriptor.inactive.5058
local.descriptor.active.5057:
  %local.check.offset.5060 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5061 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5062 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5063 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5064 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5065 = load i32, ptr %context.field.5064, align 4
  %stack.sub.5068 = sub i32 %local.check.owner.end.5063, %local.check.offset.5060
  %descriptor.owner.inside.5066 = icmp ule i32 %local.check.owner.end.5063, %context.value.5065
  %descriptor.offset.inside.5067 = icmp ule i32 %local.check.offset.5060, %local.check.owner.end.5063
  %descriptor.extent.inside.5069 = icmp ule i32 %local.check.extent.5061, %stack.sub.5068
  %descriptor.payload.inside.5070 = icmp ule i32 %local.check.payload.5062, %local.check.extent.5061
  %descriptor.owner.offset.valid.5071 = and i1 %descriptor.owner.inside.5066, %descriptor.offset.inside.5067
  %descriptor.range.inside.5073 = and i1 %descriptor.owner.offset.valid.5071, %descriptor.extent.inside.5069
  %descriptor.range.valid.5072 = and i1 %descriptor.range.inside.5073, %descriptor.payload.inside.5070
  br i1 %descriptor.range.valid.5072, label %descriptor.valid.5074, label %descriptor.invalid.5075
descriptor.invalid.5075:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5074:
  %descriptor.initialized.status.5076 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5060, i32 %local.check.extent.5061)
  %helper.ok.5077 = icmp eq i32 %descriptor.initialized.status.5076, 0
  br i1 %helper.ok.5077, label %helper.continue.5078, label %frame.failure.0
helper.continue.5078:
  br label %local.descriptor.checked.5059
local.descriptor.inactive.5058:
  br label %local.descriptor.checked.5059
local.descriptor.checked.5059:
  %local.is.active.5079 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5079, label %local.descriptor.active.5080, label %local.descriptor.inactive.5081
local.descriptor.active.5080:
  %local.check.offset.5083 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5084 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5085 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5086 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5087 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5088 = load i32, ptr %context.field.5087, align 4
  %stack.sub.5091 = sub i32 %local.check.owner.end.5086, %local.check.offset.5083
  %descriptor.owner.inside.5089 = icmp ule i32 %local.check.owner.end.5086, %context.value.5088
  %descriptor.offset.inside.5090 = icmp ule i32 %local.check.offset.5083, %local.check.owner.end.5086
  %descriptor.extent.inside.5092 = icmp ule i32 %local.check.extent.5084, %stack.sub.5091
  %descriptor.payload.inside.5093 = icmp ule i32 %local.check.payload.5085, %local.check.extent.5084
  %descriptor.owner.offset.valid.5094 = and i1 %descriptor.owner.inside.5089, %descriptor.offset.inside.5090
  %descriptor.range.inside.5096 = and i1 %descriptor.owner.offset.valid.5094, %descriptor.extent.inside.5092
  %descriptor.range.valid.5095 = and i1 %descriptor.range.inside.5096, %descriptor.payload.inside.5093
  br i1 %descriptor.range.valid.5095, label %descriptor.valid.5097, label %descriptor.invalid.5098
descriptor.invalid.5098:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5097:
  %descriptor.initialized.status.5099 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5083, i32 %local.check.extent.5084)
  %helper.ok.5100 = icmp eq i32 %descriptor.initialized.status.5099, 0
  br i1 %helper.ok.5100, label %helper.continue.5101, label %frame.failure.0
helper.continue.5101:
  br label %local.descriptor.checked.5082
local.descriptor.inactive.5081:
  br label %local.descriptor.checked.5082
local.descriptor.checked.5082:
  %step.status.5102 = call i32 @al_owning_charge_step(ptr %ctx, i32 66)
  %helper.ok.5103 = icmp eq i32 %step.status.5102, 0
  br i1 %helper.ok.5103, label %helper.continue.5104, label %frame.failure.0
helper.continue.5104:
  store i1 true, ptr %local.active.38, align 1
  store i32 %local.resolved.offset.4899, ptr %local.offset.39, align 4
  store i32 %local.resolved.extent.4900, ptr %local.extent.40, align 4
  store i32 %local.resolved.payload.4901, ptr %local.payload.41, align 4
  store i32 %local.resolved.owner.end.4902, ptr %local.owner.end.42, align 4
  store i32 6, ptr %local.type.43, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4899, i32 20, i32 %local.resolved.payload.4901, i32 %local.resolved.owner.end.4902, i32 %local.resolved.extent.4900)
  %context.field.5105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5106 = load i32, ptr %context.field.5105, align 4
  %runtime.ok.5107 = icmp eq i32 %context.value.5106, 0
  br i1 %runtime.ok.5107, label %runtime.continue.5108, label %frame.failure.0
runtime.continue.5108:
  %local.is.active.5109 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5109, label %local.descriptor.active.5110, label %local.descriptor.inactive.5111
local.descriptor.active.5110:
  %local.check.offset.5113 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5114 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5115 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5116 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5118 = load i32, ptr %context.field.5117, align 4
  %stack.sub.5121 = sub i32 %local.check.owner.end.5116, %local.check.offset.5113
  %descriptor.owner.inside.5119 = icmp ule i32 %local.check.owner.end.5116, %context.value.5118
  %descriptor.offset.inside.5120 = icmp ule i32 %local.check.offset.5113, %local.check.owner.end.5116
  %descriptor.extent.inside.5122 = icmp ule i32 %local.check.extent.5114, %stack.sub.5121
  %descriptor.payload.inside.5123 = icmp ule i32 %local.check.payload.5115, %local.check.extent.5114
  %descriptor.owner.offset.valid.5124 = and i1 %descriptor.owner.inside.5119, %descriptor.offset.inside.5120
  %descriptor.range.inside.5126 = and i1 %descriptor.owner.offset.valid.5124, %descriptor.extent.inside.5122
  %descriptor.range.valid.5125 = and i1 %descriptor.range.inside.5126, %descriptor.payload.inside.5123
  br i1 %descriptor.range.valid.5125, label %descriptor.valid.5127, label %descriptor.invalid.5128
descriptor.invalid.5128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5127:
  %descriptor.initialized.status.5129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5113, i32 %local.check.extent.5114)
  %helper.ok.5130 = icmp eq i32 %descriptor.initialized.status.5129, 0
  br i1 %helper.ok.5130, label %helper.continue.5131, label %frame.failure.0
helper.continue.5131:
  br label %local.descriptor.checked.5112
local.descriptor.inactive.5111:
  br label %local.descriptor.checked.5112
local.descriptor.checked.5112:
  %local.is.active.5132 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5132, label %local.descriptor.active.5133, label %local.descriptor.inactive.5134
local.descriptor.active.5133:
  %local.check.offset.5136 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5137 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5138 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5139 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5141 = load i32, ptr %context.field.5140, align 4
  %stack.sub.5144 = sub i32 %local.check.owner.end.5139, %local.check.offset.5136
  %descriptor.owner.inside.5142 = icmp ule i32 %local.check.owner.end.5139, %context.value.5141
  %descriptor.offset.inside.5143 = icmp ule i32 %local.check.offset.5136, %local.check.owner.end.5139
  %descriptor.extent.inside.5145 = icmp ule i32 %local.check.extent.5137, %stack.sub.5144
  %descriptor.payload.inside.5146 = icmp ule i32 %local.check.payload.5138, %local.check.extent.5137
  %descriptor.owner.offset.valid.5147 = and i1 %descriptor.owner.inside.5142, %descriptor.offset.inside.5143
  %descriptor.range.inside.5149 = and i1 %descriptor.owner.offset.valid.5147, %descriptor.extent.inside.5145
  %descriptor.range.valid.5148 = and i1 %descriptor.range.inside.5149, %descriptor.payload.inside.5146
  br i1 %descriptor.range.valid.5148, label %descriptor.valid.5150, label %descriptor.invalid.5151
descriptor.invalid.5151:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5150:
  %descriptor.initialized.status.5152 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5136, i32 %local.check.extent.5137)
  %helper.ok.5153 = icmp eq i32 %descriptor.initialized.status.5152, 0
  br i1 %helper.ok.5153, label %helper.continue.5154, label %frame.failure.0
helper.continue.5154:
  br label %local.descriptor.checked.5135
local.descriptor.inactive.5134:
  br label %local.descriptor.checked.5135
local.descriptor.checked.5135:
  %local.is.active.5155 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5155, label %local.descriptor.active.5156, label %local.descriptor.inactive.5157
local.descriptor.active.5156:
  %local.check.offset.5159 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5160 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5161 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5162 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5164 = load i32, ptr %context.field.5163, align 4
  %stack.sub.5167 = sub i32 %local.check.owner.end.5162, %local.check.offset.5159
  %descriptor.owner.inside.5165 = icmp ule i32 %local.check.owner.end.5162, %context.value.5164
  %descriptor.offset.inside.5166 = icmp ule i32 %local.check.offset.5159, %local.check.owner.end.5162
  %descriptor.extent.inside.5168 = icmp ule i32 %local.check.extent.5160, %stack.sub.5167
  %descriptor.payload.inside.5169 = icmp ule i32 %local.check.payload.5161, %local.check.extent.5160
  %descriptor.owner.offset.valid.5170 = and i1 %descriptor.owner.inside.5165, %descriptor.offset.inside.5166
  %descriptor.range.inside.5172 = and i1 %descriptor.owner.offset.valid.5170, %descriptor.extent.inside.5168
  %descriptor.range.valid.5171 = and i1 %descriptor.range.inside.5172, %descriptor.payload.inside.5169
  br i1 %descriptor.range.valid.5171, label %descriptor.valid.5173, label %descriptor.invalid.5174
descriptor.invalid.5174:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5173:
  %descriptor.initialized.status.5175 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5159, i32 %local.check.extent.5160)
  %helper.ok.5176 = icmp eq i32 %descriptor.initialized.status.5175, 0
  br i1 %helper.ok.5176, label %helper.continue.5177, label %frame.failure.0
helper.continue.5177:
  br label %local.descriptor.checked.5158
local.descriptor.inactive.5157:
  br label %local.descriptor.checked.5158
local.descriptor.checked.5158:
  %local.is.active.5178 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5178, label %local.descriptor.active.5179, label %local.descriptor.inactive.5180
local.descriptor.active.5179:
  %local.check.offset.5182 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5183 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5184 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5185 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5187 = load i32, ptr %context.field.5186, align 4
  %stack.sub.5190 = sub i32 %local.check.owner.end.5185, %local.check.offset.5182
  %descriptor.owner.inside.5188 = icmp ule i32 %local.check.owner.end.5185, %context.value.5187
  %descriptor.offset.inside.5189 = icmp ule i32 %local.check.offset.5182, %local.check.owner.end.5185
  %descriptor.extent.inside.5191 = icmp ule i32 %local.check.extent.5183, %stack.sub.5190
  %descriptor.payload.inside.5192 = icmp ule i32 %local.check.payload.5184, %local.check.extent.5183
  %descriptor.owner.offset.valid.5193 = and i1 %descriptor.owner.inside.5188, %descriptor.offset.inside.5189
  %descriptor.range.inside.5195 = and i1 %descriptor.owner.offset.valid.5193, %descriptor.extent.inside.5191
  %descriptor.range.valid.5194 = and i1 %descriptor.range.inside.5195, %descriptor.payload.inside.5192
  br i1 %descriptor.range.valid.5194, label %descriptor.valid.5196, label %descriptor.invalid.5197
descriptor.invalid.5197:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5196:
  %descriptor.initialized.status.5198 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5182, i32 %local.check.extent.5183)
  %helper.ok.5199 = icmp eq i32 %descriptor.initialized.status.5198, 0
  br i1 %helper.ok.5199, label %helper.continue.5200, label %frame.failure.0
helper.continue.5200:
  br label %local.descriptor.checked.5181
local.descriptor.inactive.5180:
  br label %local.descriptor.checked.5181
local.descriptor.checked.5181:
  %local.is.active.5201 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5201, label %local.descriptor.active.5202, label %local.descriptor.inactive.5203
local.descriptor.active.5202:
  %local.check.offset.5205 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5206 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5207 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5208 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5210 = load i32, ptr %context.field.5209, align 4
  %stack.sub.5213 = sub i32 %local.check.owner.end.5208, %local.check.offset.5205
  %descriptor.owner.inside.5211 = icmp ule i32 %local.check.owner.end.5208, %context.value.5210
  %descriptor.offset.inside.5212 = icmp ule i32 %local.check.offset.5205, %local.check.owner.end.5208
  %descriptor.extent.inside.5214 = icmp ule i32 %local.check.extent.5206, %stack.sub.5213
  %descriptor.payload.inside.5215 = icmp ule i32 %local.check.payload.5207, %local.check.extent.5206
  %descriptor.owner.offset.valid.5216 = and i1 %descriptor.owner.inside.5211, %descriptor.offset.inside.5212
  %descriptor.range.inside.5218 = and i1 %descriptor.owner.offset.valid.5216, %descriptor.extent.inside.5214
  %descriptor.range.valid.5217 = and i1 %descriptor.range.inside.5218, %descriptor.payload.inside.5215
  br i1 %descriptor.range.valid.5217, label %descriptor.valid.5219, label %descriptor.invalid.5220
descriptor.invalid.5220:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5219:
  %descriptor.initialized.status.5221 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5205, i32 %local.check.extent.5206)
  %helper.ok.5222 = icmp eq i32 %descriptor.initialized.status.5221, 0
  br i1 %helper.ok.5222, label %helper.continue.5223, label %frame.failure.0
helper.continue.5223:
  br label %local.descriptor.checked.5204
local.descriptor.inactive.5203:
  br label %local.descriptor.checked.5204
local.descriptor.checked.5204:
  %local.is.active.5224 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5224, label %local.descriptor.active.5225, label %local.descriptor.inactive.5226
local.descriptor.active.5225:
  %local.check.offset.5228 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5229 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5230 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5231 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5233 = load i32, ptr %context.field.5232, align 4
  %stack.sub.5236 = sub i32 %local.check.owner.end.5231, %local.check.offset.5228
  %descriptor.owner.inside.5234 = icmp ule i32 %local.check.owner.end.5231, %context.value.5233
  %descriptor.offset.inside.5235 = icmp ule i32 %local.check.offset.5228, %local.check.owner.end.5231
  %descriptor.extent.inside.5237 = icmp ule i32 %local.check.extent.5229, %stack.sub.5236
  %descriptor.payload.inside.5238 = icmp ule i32 %local.check.payload.5230, %local.check.extent.5229
  %descriptor.owner.offset.valid.5239 = and i1 %descriptor.owner.inside.5234, %descriptor.offset.inside.5235
  %descriptor.range.inside.5241 = and i1 %descriptor.owner.offset.valid.5239, %descriptor.extent.inside.5237
  %descriptor.range.valid.5240 = and i1 %descriptor.range.inside.5241, %descriptor.payload.inside.5238
  br i1 %descriptor.range.valid.5240, label %descriptor.valid.5242, label %descriptor.invalid.5243
descriptor.invalid.5243:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5242:
  %descriptor.initialized.status.5244 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5228, i32 %local.check.extent.5229)
  %helper.ok.5245 = icmp eq i32 %descriptor.initialized.status.5244, 0
  br i1 %helper.ok.5245, label %helper.continue.5246, label %frame.failure.0
helper.continue.5246:
  br label %local.descriptor.checked.5227
local.descriptor.inactive.5226:
  br label %local.descriptor.checked.5227
local.descriptor.checked.5227:
  %local.is.active.5247 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5247, label %local.descriptor.active.5248, label %local.descriptor.inactive.5249
local.descriptor.active.5248:
  %local.check.offset.5251 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5252 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5253 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5254 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5255 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5256 = load i32, ptr %context.field.5255, align 4
  %stack.sub.5259 = sub i32 %local.check.owner.end.5254, %local.check.offset.5251
  %descriptor.owner.inside.5257 = icmp ule i32 %local.check.owner.end.5254, %context.value.5256
  %descriptor.offset.inside.5258 = icmp ule i32 %local.check.offset.5251, %local.check.owner.end.5254
  %descriptor.extent.inside.5260 = icmp ule i32 %local.check.extent.5252, %stack.sub.5259
  %descriptor.payload.inside.5261 = icmp ule i32 %local.check.payload.5253, %local.check.extent.5252
  %descriptor.owner.offset.valid.5262 = and i1 %descriptor.owner.inside.5257, %descriptor.offset.inside.5258
  %descriptor.range.inside.5264 = and i1 %descriptor.owner.offset.valid.5262, %descriptor.extent.inside.5260
  %descriptor.range.valid.5263 = and i1 %descriptor.range.inside.5264, %descriptor.payload.inside.5261
  br i1 %descriptor.range.valid.5263, label %descriptor.valid.5265, label %descriptor.invalid.5266
descriptor.invalid.5266:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5265:
  %descriptor.initialized.status.5267 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5251, i32 %local.check.extent.5252)
  %helper.ok.5268 = icmp eq i32 %descriptor.initialized.status.5267, 0
  br i1 %helper.ok.5268, label %helper.continue.5269, label %frame.failure.0
helper.continue.5269:
  br label %local.descriptor.checked.5250
local.descriptor.inactive.5249:
  br label %local.descriptor.checked.5250
local.descriptor.checked.5250:
  %step.status.5270 = call i32 @al_owning_charge_step(ptr %ctx, i32 67)
  %helper.ok.5271 = icmp eq i32 %step.status.5270, 0
  br i1 %helper.ok.5271, label %helper.continue.5272, label %frame.failure.0
helper.continue.5272:
  %local.resolved.offset.5273 = load i32, ptr %local.offset.39, align 4
  %local.resolved.extent.5274 = load i32, ptr %local.extent.40, align 4
  %local.resolved.payload.5275 = load i32, ptr %local.payload.41, align 4
  %local.resolved.owner.end.5276 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5277 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5278 = load i32, ptr %context.field.5277, align 4
  %stack.sub.5281 = sub i32 %local.resolved.owner.end.5276, %local.resolved.offset.5273
  %descriptor.owner.inside.5279 = icmp ule i32 %local.resolved.owner.end.5276, %context.value.5278
  %descriptor.offset.inside.5280 = icmp ule i32 %local.resolved.offset.5273, %local.resolved.owner.end.5276
  %descriptor.extent.inside.5282 = icmp ule i32 %local.resolved.extent.5274, %stack.sub.5281
  %descriptor.payload.inside.5283 = icmp ule i32 %local.resolved.payload.5275, %local.resolved.extent.5274
  %descriptor.owner.offset.valid.5284 = and i1 %descriptor.owner.inside.5279, %descriptor.offset.inside.5280
  %descriptor.range.inside.5286 = and i1 %descriptor.owner.offset.valid.5284, %descriptor.extent.inside.5282
  %descriptor.range.valid.5285 = and i1 %descriptor.range.inside.5286, %descriptor.payload.inside.5283
  %descriptor.type.valid.5287 = icmp eq i32 6, 6
  %descriptor.valid.5288 = and i1 %descriptor.range.valid.5285, %descriptor.type.valid.5287
  br i1 %descriptor.valid.5288, label %descriptor.valid.5289, label %descriptor.invalid.5290
descriptor.invalid.5290:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5289:
  %descriptor.initialized.status.5291 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.5273, i32 %local.resolved.extent.5274)
  %helper.ok.5292 = icmp eq i32 %descriptor.initialized.status.5291, 0
  br i1 %helper.ok.5292, label %helper.continue.5293, label %frame.failure.0
helper.continue.5293:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.5273, i32 20, i32 %local.resolved.payload.5275, i32 %local.resolved.owner.end.5276, i32 %local.resolved.extent.5274)
  %context.field.5294 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5295 = load i32, ptr %context.field.5294, align 4
  %runtime.ok.5296 = icmp eq i32 %context.value.5295, 0
  br i1 %runtime.ok.5296, label %runtime.continue.5297, label %frame.failure.0
runtime.continue.5297:
  %context.field.5298 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5299 = load i32, ptr %context.field.5298, align 4
  %stack.sub.5302 = sub i32 %local.resolved.owner.end.5276, %local.resolved.offset.5273
  %descriptor.owner.inside.5300 = icmp ule i32 %local.resolved.owner.end.5276, %context.value.5299
  %descriptor.offset.inside.5301 = icmp ule i32 %local.resolved.offset.5273, %local.resolved.owner.end.5276
  %descriptor.extent.inside.5303 = icmp ule i32 %local.resolved.extent.5274, %stack.sub.5302
  %descriptor.payload.inside.5304 = icmp ule i32 %local.resolved.payload.5275, %local.resolved.extent.5274
  %descriptor.owner.offset.valid.5305 = and i1 %descriptor.owner.inside.5300, %descriptor.offset.inside.5301
  %descriptor.range.inside.5307 = and i1 %descriptor.owner.offset.valid.5305, %descriptor.extent.inside.5303
  %descriptor.range.valid.5306 = and i1 %descriptor.range.inside.5307, %descriptor.payload.inside.5304
  %descriptor.type.valid.5308 = icmp eq i32 6, 6
  %descriptor.valid.5309 = and i1 %descriptor.range.valid.5306, %descriptor.type.valid.5308
  br i1 %descriptor.valid.5309, label %descriptor.valid.5310, label %descriptor.invalid.5311
descriptor.invalid.5311:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5310:
  %descriptor.initialized.status.5312 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.5273, i32 %local.resolved.extent.5274)
  %helper.ok.5313 = icmp eq i32 %descriptor.initialized.status.5312, 0
  br i1 %helper.ok.5313, label %helper.continue.5314, label %frame.failure.0
helper.continue.5314:
  %local.is.active.5315 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5315, label %local.descriptor.active.5316, label %local.descriptor.inactive.5317
local.descriptor.active.5316:
  %local.check.offset.5319 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5320 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5321 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5322 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5324 = load i32, ptr %context.field.5323, align 4
  %stack.sub.5327 = sub i32 %local.check.owner.end.5322, %local.check.offset.5319
  %descriptor.owner.inside.5325 = icmp ule i32 %local.check.owner.end.5322, %context.value.5324
  %descriptor.offset.inside.5326 = icmp ule i32 %local.check.offset.5319, %local.check.owner.end.5322
  %descriptor.extent.inside.5328 = icmp ule i32 %local.check.extent.5320, %stack.sub.5327
  %descriptor.payload.inside.5329 = icmp ule i32 %local.check.payload.5321, %local.check.extent.5320
  %descriptor.owner.offset.valid.5330 = and i1 %descriptor.owner.inside.5325, %descriptor.offset.inside.5326
  %descriptor.range.inside.5332 = and i1 %descriptor.owner.offset.valid.5330, %descriptor.extent.inside.5328
  %descriptor.range.valid.5331 = and i1 %descriptor.range.inside.5332, %descriptor.payload.inside.5329
  br i1 %descriptor.range.valid.5331, label %descriptor.valid.5333, label %descriptor.invalid.5334
descriptor.invalid.5334:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5333:
  %descriptor.initialized.status.5335 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5319, i32 %local.check.extent.5320)
  %helper.ok.5336 = icmp eq i32 %descriptor.initialized.status.5335, 0
  br i1 %helper.ok.5336, label %helper.continue.5337, label %frame.failure.0
helper.continue.5337:
  br label %local.descriptor.checked.5318
local.descriptor.inactive.5317:
  br label %local.descriptor.checked.5318
local.descriptor.checked.5318:
  %local.is.active.5338 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5338, label %local.descriptor.active.5339, label %local.descriptor.inactive.5340
local.descriptor.active.5339:
  %local.check.offset.5342 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5343 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5344 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5345 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5347 = load i32, ptr %context.field.5346, align 4
  %stack.sub.5350 = sub i32 %local.check.owner.end.5345, %local.check.offset.5342
  %descriptor.owner.inside.5348 = icmp ule i32 %local.check.owner.end.5345, %context.value.5347
  %descriptor.offset.inside.5349 = icmp ule i32 %local.check.offset.5342, %local.check.owner.end.5345
  %descriptor.extent.inside.5351 = icmp ule i32 %local.check.extent.5343, %stack.sub.5350
  %descriptor.payload.inside.5352 = icmp ule i32 %local.check.payload.5344, %local.check.extent.5343
  %descriptor.owner.offset.valid.5353 = and i1 %descriptor.owner.inside.5348, %descriptor.offset.inside.5349
  %descriptor.range.inside.5355 = and i1 %descriptor.owner.offset.valid.5353, %descriptor.extent.inside.5351
  %descriptor.range.valid.5354 = and i1 %descriptor.range.inside.5355, %descriptor.payload.inside.5352
  br i1 %descriptor.range.valid.5354, label %descriptor.valid.5356, label %descriptor.invalid.5357
descriptor.invalid.5357:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5356:
  %descriptor.initialized.status.5358 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5342, i32 %local.check.extent.5343)
  %helper.ok.5359 = icmp eq i32 %descriptor.initialized.status.5358, 0
  br i1 %helper.ok.5359, label %helper.continue.5360, label %frame.failure.0
helper.continue.5360:
  br label %local.descriptor.checked.5341
local.descriptor.inactive.5340:
  br label %local.descriptor.checked.5341
local.descriptor.checked.5341:
  %local.is.active.5361 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5361, label %local.descriptor.active.5362, label %local.descriptor.inactive.5363
local.descriptor.active.5362:
  %local.check.offset.5365 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5366 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5367 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5368 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5370 = load i32, ptr %context.field.5369, align 4
  %stack.sub.5373 = sub i32 %local.check.owner.end.5368, %local.check.offset.5365
  %descriptor.owner.inside.5371 = icmp ule i32 %local.check.owner.end.5368, %context.value.5370
  %descriptor.offset.inside.5372 = icmp ule i32 %local.check.offset.5365, %local.check.owner.end.5368
  %descriptor.extent.inside.5374 = icmp ule i32 %local.check.extent.5366, %stack.sub.5373
  %descriptor.payload.inside.5375 = icmp ule i32 %local.check.payload.5367, %local.check.extent.5366
  %descriptor.owner.offset.valid.5376 = and i1 %descriptor.owner.inside.5371, %descriptor.offset.inside.5372
  %descriptor.range.inside.5378 = and i1 %descriptor.owner.offset.valid.5376, %descriptor.extent.inside.5374
  %descriptor.range.valid.5377 = and i1 %descriptor.range.inside.5378, %descriptor.payload.inside.5375
  br i1 %descriptor.range.valid.5377, label %descriptor.valid.5379, label %descriptor.invalid.5380
descriptor.invalid.5380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5379:
  %descriptor.initialized.status.5381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5365, i32 %local.check.extent.5366)
  %helper.ok.5382 = icmp eq i32 %descriptor.initialized.status.5381, 0
  br i1 %helper.ok.5382, label %helper.continue.5383, label %frame.failure.0
helper.continue.5383:
  br label %local.descriptor.checked.5364
local.descriptor.inactive.5363:
  br label %local.descriptor.checked.5364
local.descriptor.checked.5364:
  %local.is.active.5384 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5384, label %local.descriptor.active.5385, label %local.descriptor.inactive.5386
local.descriptor.active.5385:
  %local.check.offset.5388 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5389 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5390 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5391 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5393 = load i32, ptr %context.field.5392, align 4
  %stack.sub.5396 = sub i32 %local.check.owner.end.5391, %local.check.offset.5388
  %descriptor.owner.inside.5394 = icmp ule i32 %local.check.owner.end.5391, %context.value.5393
  %descriptor.offset.inside.5395 = icmp ule i32 %local.check.offset.5388, %local.check.owner.end.5391
  %descriptor.extent.inside.5397 = icmp ule i32 %local.check.extent.5389, %stack.sub.5396
  %descriptor.payload.inside.5398 = icmp ule i32 %local.check.payload.5390, %local.check.extent.5389
  %descriptor.owner.offset.valid.5399 = and i1 %descriptor.owner.inside.5394, %descriptor.offset.inside.5395
  %descriptor.range.inside.5401 = and i1 %descriptor.owner.offset.valid.5399, %descriptor.extent.inside.5397
  %descriptor.range.valid.5400 = and i1 %descriptor.range.inside.5401, %descriptor.payload.inside.5398
  br i1 %descriptor.range.valid.5400, label %descriptor.valid.5402, label %descriptor.invalid.5403
descriptor.invalid.5403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5402:
  %descriptor.initialized.status.5404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5388, i32 %local.check.extent.5389)
  %helper.ok.5405 = icmp eq i32 %descriptor.initialized.status.5404, 0
  br i1 %helper.ok.5405, label %helper.continue.5406, label %frame.failure.0
helper.continue.5406:
  br label %local.descriptor.checked.5387
local.descriptor.inactive.5386:
  br label %local.descriptor.checked.5387
local.descriptor.checked.5387:
  %local.is.active.5407 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5407, label %local.descriptor.active.5408, label %local.descriptor.inactive.5409
local.descriptor.active.5408:
  %local.check.offset.5411 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5412 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5413 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5414 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5416 = load i32, ptr %context.field.5415, align 4
  %stack.sub.5419 = sub i32 %local.check.owner.end.5414, %local.check.offset.5411
  %descriptor.owner.inside.5417 = icmp ule i32 %local.check.owner.end.5414, %context.value.5416
  %descriptor.offset.inside.5418 = icmp ule i32 %local.check.offset.5411, %local.check.owner.end.5414
  %descriptor.extent.inside.5420 = icmp ule i32 %local.check.extent.5412, %stack.sub.5419
  %descriptor.payload.inside.5421 = icmp ule i32 %local.check.payload.5413, %local.check.extent.5412
  %descriptor.owner.offset.valid.5422 = and i1 %descriptor.owner.inside.5417, %descriptor.offset.inside.5418
  %descriptor.range.inside.5424 = and i1 %descriptor.owner.offset.valid.5422, %descriptor.extent.inside.5420
  %descriptor.range.valid.5423 = and i1 %descriptor.range.inside.5424, %descriptor.payload.inside.5421
  br i1 %descriptor.range.valid.5423, label %descriptor.valid.5425, label %descriptor.invalid.5426
descriptor.invalid.5426:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5425:
  %descriptor.initialized.status.5427 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5411, i32 %local.check.extent.5412)
  %helper.ok.5428 = icmp eq i32 %descriptor.initialized.status.5427, 0
  br i1 %helper.ok.5428, label %helper.continue.5429, label %frame.failure.0
helper.continue.5429:
  br label %local.descriptor.checked.5410
local.descriptor.inactive.5409:
  br label %local.descriptor.checked.5410
local.descriptor.checked.5410:
  %local.is.active.5430 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5430, label %local.descriptor.active.5431, label %local.descriptor.inactive.5432
local.descriptor.active.5431:
  %local.check.offset.5434 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5435 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5436 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5437 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5439 = load i32, ptr %context.field.5438, align 4
  %stack.sub.5442 = sub i32 %local.check.owner.end.5437, %local.check.offset.5434
  %descriptor.owner.inside.5440 = icmp ule i32 %local.check.owner.end.5437, %context.value.5439
  %descriptor.offset.inside.5441 = icmp ule i32 %local.check.offset.5434, %local.check.owner.end.5437
  %descriptor.extent.inside.5443 = icmp ule i32 %local.check.extent.5435, %stack.sub.5442
  %descriptor.payload.inside.5444 = icmp ule i32 %local.check.payload.5436, %local.check.extent.5435
  %descriptor.owner.offset.valid.5445 = and i1 %descriptor.owner.inside.5440, %descriptor.offset.inside.5441
  %descriptor.range.inside.5447 = and i1 %descriptor.owner.offset.valid.5445, %descriptor.extent.inside.5443
  %descriptor.range.valid.5446 = and i1 %descriptor.range.inside.5447, %descriptor.payload.inside.5444
  br i1 %descriptor.range.valid.5446, label %descriptor.valid.5448, label %descriptor.invalid.5449
descriptor.invalid.5449:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5448:
  %descriptor.initialized.status.5450 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5434, i32 %local.check.extent.5435)
  %helper.ok.5451 = icmp eq i32 %descriptor.initialized.status.5450, 0
  br i1 %helper.ok.5451, label %helper.continue.5452, label %frame.failure.0
helper.continue.5452:
  br label %local.descriptor.checked.5433
local.descriptor.inactive.5432:
  br label %local.descriptor.checked.5433
local.descriptor.checked.5433:
  %local.is.active.5453 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5453, label %local.descriptor.active.5454, label %local.descriptor.inactive.5455
local.descriptor.active.5454:
  %local.check.offset.5457 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5458 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5459 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5460 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5462 = load i32, ptr %context.field.5461, align 4
  %stack.sub.5465 = sub i32 %local.check.owner.end.5460, %local.check.offset.5457
  %descriptor.owner.inside.5463 = icmp ule i32 %local.check.owner.end.5460, %context.value.5462
  %descriptor.offset.inside.5464 = icmp ule i32 %local.check.offset.5457, %local.check.owner.end.5460
  %descriptor.extent.inside.5466 = icmp ule i32 %local.check.extent.5458, %stack.sub.5465
  %descriptor.payload.inside.5467 = icmp ule i32 %local.check.payload.5459, %local.check.extent.5458
  %descriptor.owner.offset.valid.5468 = and i1 %descriptor.owner.inside.5463, %descriptor.offset.inside.5464
  %descriptor.range.inside.5470 = and i1 %descriptor.owner.offset.valid.5468, %descriptor.extent.inside.5466
  %descriptor.range.valid.5469 = and i1 %descriptor.range.inside.5470, %descriptor.payload.inside.5467
  br i1 %descriptor.range.valid.5469, label %descriptor.valid.5471, label %descriptor.invalid.5472
descriptor.invalid.5472:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5471:
  %descriptor.initialized.status.5473 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5457, i32 %local.check.extent.5458)
  %helper.ok.5474 = icmp eq i32 %descriptor.initialized.status.5473, 0
  br i1 %helper.ok.5474, label %helper.continue.5475, label %frame.failure.0
helper.continue.5475:
  br label %local.descriptor.checked.5456
local.descriptor.inactive.5455:
  br label %local.descriptor.checked.5456
local.descriptor.checked.5456:
  %step.status.5476 = call i32 @al_owning_charge_step(ptr %ctx, i32 68)
  %helper.ok.5477 = icmp eq i32 %step.status.5476, 0
  br i1 %helper.ok.5477, label %helper.continue.5478, label %frame.failure.0
helper.continue.5478:
  %stack.offset.5479 = add i32 0, %local.resolved.payload.5275
  %stack.offset.5480 = add i32 0, %local.resolved.extent.5274
  %context.field.5481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5482 = load i32, ptr %context.field.5481, align 4
  %stack.offset.5483 = add i32 %context.value.5482, %stack.offset.5480
  %reserve.status.5484 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5483, i32 69)
  %reserve.ok.5485 = icmp eq i32 %reserve.status.5484, 0
  br i1 %reserve.ok.5485, label %reserve.continue.5486, label %frame.failure.0
reserve.continue.5486:
  %stack.offset.5487 = add i32 %context.value.5482, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.5487, i32 %local.resolved.offset.5273, i32 %local.resolved.extent.5274, i32 %local.resolved.payload.5275, i32 6, i32 6)
  %context.field.5488 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5489 = load i32, ptr %context.field.5488, align 4
  %runtime.ok.5490 = icmp eq i32 %context.value.5489, 0
  br i1 %runtime.ok.5490, label %runtime.continue.5491, label %frame.failure.0
runtime.continue.5491:
  %stack.offset.5492 = add i32 0, %local.resolved.extent.5274
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.5482, i32 %stack.offset.5480, i32 %stack.offset.5479, i32 0, i32 0)
  %context.field.5493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5494 = load i32, ptr %context.field.5493, align 4
  %runtime.ok.5495 = icmp eq i32 %context.value.5494, 0
  br i1 %runtime.ok.5495, label %runtime.continue.5496, label %frame.failure.0
runtime.continue.5496:
  %context.field.5497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5498 = load i32, ptr %context.field.5497, align 4
  %stack.sub.5501 = sub i32 %stack.offset.5483, %context.value.5482
  %descriptor.owner.inside.5499 = icmp ule i32 %stack.offset.5483, %context.value.5498
  %descriptor.offset.inside.5500 = icmp ule i32 %context.value.5482, %stack.offset.5483
  %descriptor.extent.inside.5502 = icmp ule i32 %stack.offset.5480, %stack.sub.5501
  %descriptor.payload.inside.5503 = icmp ule i32 %stack.offset.5479, %stack.offset.5480
  %descriptor.owner.offset.valid.5504 = and i1 %descriptor.owner.inside.5499, %descriptor.offset.inside.5500
  %descriptor.range.inside.5506 = and i1 %descriptor.owner.offset.valid.5504, %descriptor.extent.inside.5502
  %descriptor.range.valid.5505 = and i1 %descriptor.range.inside.5506, %descriptor.payload.inside.5503
  %descriptor.type.valid.5507 = icmp eq i32 5, 5
  %descriptor.valid.5508 = and i1 %descriptor.range.valid.5505, %descriptor.type.valid.5507
  br i1 %descriptor.valid.5508, label %descriptor.valid.5509, label %descriptor.invalid.5510
descriptor.invalid.5510:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5509:
  %descriptor.initialized.status.5511 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.5482, i32 %stack.offset.5480)
  %helper.ok.5512 = icmp eq i32 %descriptor.initialized.status.5511, 0
  br i1 %helper.ok.5512, label %helper.continue.5513, label %frame.failure.0
helper.continue.5513:
  %local.is.active.5514 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5514, label %local.descriptor.active.5515, label %local.descriptor.inactive.5516
local.descriptor.active.5515:
  %local.check.offset.5518 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5519 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5520 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5521 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5522 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5523 = load i32, ptr %context.field.5522, align 4
  %stack.sub.5526 = sub i32 %local.check.owner.end.5521, %local.check.offset.5518
  %descriptor.owner.inside.5524 = icmp ule i32 %local.check.owner.end.5521, %context.value.5523
  %descriptor.offset.inside.5525 = icmp ule i32 %local.check.offset.5518, %local.check.owner.end.5521
  %descriptor.extent.inside.5527 = icmp ule i32 %local.check.extent.5519, %stack.sub.5526
  %descriptor.payload.inside.5528 = icmp ule i32 %local.check.payload.5520, %local.check.extent.5519
  %descriptor.owner.offset.valid.5529 = and i1 %descriptor.owner.inside.5524, %descriptor.offset.inside.5525
  %descriptor.range.inside.5531 = and i1 %descriptor.owner.offset.valid.5529, %descriptor.extent.inside.5527
  %descriptor.range.valid.5530 = and i1 %descriptor.range.inside.5531, %descriptor.payload.inside.5528
  br i1 %descriptor.range.valid.5530, label %descriptor.valid.5532, label %descriptor.invalid.5533
descriptor.invalid.5533:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5532:
  %descriptor.initialized.status.5534 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5518, i32 %local.check.extent.5519)
  %helper.ok.5535 = icmp eq i32 %descriptor.initialized.status.5534, 0
  br i1 %helper.ok.5535, label %helper.continue.5536, label %frame.failure.0
helper.continue.5536:
  br label %local.descriptor.checked.5517
local.descriptor.inactive.5516:
  br label %local.descriptor.checked.5517
local.descriptor.checked.5517:
  %local.is.active.5537 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5537, label %local.descriptor.active.5538, label %local.descriptor.inactive.5539
local.descriptor.active.5538:
  %local.check.offset.5541 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5542 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5543 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5544 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5545 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5546 = load i32, ptr %context.field.5545, align 4
  %stack.sub.5549 = sub i32 %local.check.owner.end.5544, %local.check.offset.5541
  %descriptor.owner.inside.5547 = icmp ule i32 %local.check.owner.end.5544, %context.value.5546
  %descriptor.offset.inside.5548 = icmp ule i32 %local.check.offset.5541, %local.check.owner.end.5544
  %descriptor.extent.inside.5550 = icmp ule i32 %local.check.extent.5542, %stack.sub.5549
  %descriptor.payload.inside.5551 = icmp ule i32 %local.check.payload.5543, %local.check.extent.5542
  %descriptor.owner.offset.valid.5552 = and i1 %descriptor.owner.inside.5547, %descriptor.offset.inside.5548
  %descriptor.range.inside.5554 = and i1 %descriptor.owner.offset.valid.5552, %descriptor.extent.inside.5550
  %descriptor.range.valid.5553 = and i1 %descriptor.range.inside.5554, %descriptor.payload.inside.5551
  br i1 %descriptor.range.valid.5553, label %descriptor.valid.5555, label %descriptor.invalid.5556
descriptor.invalid.5556:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5555:
  %descriptor.initialized.status.5557 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5541, i32 %local.check.extent.5542)
  %helper.ok.5558 = icmp eq i32 %descriptor.initialized.status.5557, 0
  br i1 %helper.ok.5558, label %helper.continue.5559, label %frame.failure.0
helper.continue.5559:
  br label %local.descriptor.checked.5540
local.descriptor.inactive.5539:
  br label %local.descriptor.checked.5540
local.descriptor.checked.5540:
  %local.is.active.5560 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5560, label %local.descriptor.active.5561, label %local.descriptor.inactive.5562
local.descriptor.active.5561:
  %local.check.offset.5564 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5565 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5566 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5567 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5568 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5569 = load i32, ptr %context.field.5568, align 4
  %stack.sub.5572 = sub i32 %local.check.owner.end.5567, %local.check.offset.5564
  %descriptor.owner.inside.5570 = icmp ule i32 %local.check.owner.end.5567, %context.value.5569
  %descriptor.offset.inside.5571 = icmp ule i32 %local.check.offset.5564, %local.check.owner.end.5567
  %descriptor.extent.inside.5573 = icmp ule i32 %local.check.extent.5565, %stack.sub.5572
  %descriptor.payload.inside.5574 = icmp ule i32 %local.check.payload.5566, %local.check.extent.5565
  %descriptor.owner.offset.valid.5575 = and i1 %descriptor.owner.inside.5570, %descriptor.offset.inside.5571
  %descriptor.range.inside.5577 = and i1 %descriptor.owner.offset.valid.5575, %descriptor.extent.inside.5573
  %descriptor.range.valid.5576 = and i1 %descriptor.range.inside.5577, %descriptor.payload.inside.5574
  br i1 %descriptor.range.valid.5576, label %descriptor.valid.5578, label %descriptor.invalid.5579
descriptor.invalid.5579:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5578:
  %descriptor.initialized.status.5580 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5564, i32 %local.check.extent.5565)
  %helper.ok.5581 = icmp eq i32 %descriptor.initialized.status.5580, 0
  br i1 %helper.ok.5581, label %helper.continue.5582, label %frame.failure.0
helper.continue.5582:
  br label %local.descriptor.checked.5563
local.descriptor.inactive.5562:
  br label %local.descriptor.checked.5563
local.descriptor.checked.5563:
  %local.is.active.5583 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5583, label %local.descriptor.active.5584, label %local.descriptor.inactive.5585
local.descriptor.active.5584:
  %local.check.offset.5587 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5588 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5589 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5590 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5591 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5592 = load i32, ptr %context.field.5591, align 4
  %stack.sub.5595 = sub i32 %local.check.owner.end.5590, %local.check.offset.5587
  %descriptor.owner.inside.5593 = icmp ule i32 %local.check.owner.end.5590, %context.value.5592
  %descriptor.offset.inside.5594 = icmp ule i32 %local.check.offset.5587, %local.check.owner.end.5590
  %descriptor.extent.inside.5596 = icmp ule i32 %local.check.extent.5588, %stack.sub.5595
  %descriptor.payload.inside.5597 = icmp ule i32 %local.check.payload.5589, %local.check.extent.5588
  %descriptor.owner.offset.valid.5598 = and i1 %descriptor.owner.inside.5593, %descriptor.offset.inside.5594
  %descriptor.range.inside.5600 = and i1 %descriptor.owner.offset.valid.5598, %descriptor.extent.inside.5596
  %descriptor.range.valid.5599 = and i1 %descriptor.range.inside.5600, %descriptor.payload.inside.5597
  br i1 %descriptor.range.valid.5599, label %descriptor.valid.5601, label %descriptor.invalid.5602
descriptor.invalid.5602:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5601:
  %descriptor.initialized.status.5603 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5587, i32 %local.check.extent.5588)
  %helper.ok.5604 = icmp eq i32 %descriptor.initialized.status.5603, 0
  br i1 %helper.ok.5604, label %helper.continue.5605, label %frame.failure.0
helper.continue.5605:
  br label %local.descriptor.checked.5586
local.descriptor.inactive.5585:
  br label %local.descriptor.checked.5586
local.descriptor.checked.5586:
  %local.is.active.5606 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5606, label %local.descriptor.active.5607, label %local.descriptor.inactive.5608
local.descriptor.active.5607:
  %local.check.offset.5610 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5611 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5612 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5613 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5614 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5615 = load i32, ptr %context.field.5614, align 4
  %stack.sub.5618 = sub i32 %local.check.owner.end.5613, %local.check.offset.5610
  %descriptor.owner.inside.5616 = icmp ule i32 %local.check.owner.end.5613, %context.value.5615
  %descriptor.offset.inside.5617 = icmp ule i32 %local.check.offset.5610, %local.check.owner.end.5613
  %descriptor.extent.inside.5619 = icmp ule i32 %local.check.extent.5611, %stack.sub.5618
  %descriptor.payload.inside.5620 = icmp ule i32 %local.check.payload.5612, %local.check.extent.5611
  %descriptor.owner.offset.valid.5621 = and i1 %descriptor.owner.inside.5616, %descriptor.offset.inside.5617
  %descriptor.range.inside.5623 = and i1 %descriptor.owner.offset.valid.5621, %descriptor.extent.inside.5619
  %descriptor.range.valid.5622 = and i1 %descriptor.range.inside.5623, %descriptor.payload.inside.5620
  br i1 %descriptor.range.valid.5622, label %descriptor.valid.5624, label %descriptor.invalid.5625
descriptor.invalid.5625:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5624:
  %descriptor.initialized.status.5626 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5610, i32 %local.check.extent.5611)
  %helper.ok.5627 = icmp eq i32 %descriptor.initialized.status.5626, 0
  br i1 %helper.ok.5627, label %helper.continue.5628, label %frame.failure.0
helper.continue.5628:
  br label %local.descriptor.checked.5609
local.descriptor.inactive.5608:
  br label %local.descriptor.checked.5609
local.descriptor.checked.5609:
  %local.is.active.5629 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5629, label %local.descriptor.active.5630, label %local.descriptor.inactive.5631
local.descriptor.active.5630:
  %local.check.offset.5633 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5634 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5635 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5636 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5637 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5638 = load i32, ptr %context.field.5637, align 4
  %stack.sub.5641 = sub i32 %local.check.owner.end.5636, %local.check.offset.5633
  %descriptor.owner.inside.5639 = icmp ule i32 %local.check.owner.end.5636, %context.value.5638
  %descriptor.offset.inside.5640 = icmp ule i32 %local.check.offset.5633, %local.check.owner.end.5636
  %descriptor.extent.inside.5642 = icmp ule i32 %local.check.extent.5634, %stack.sub.5641
  %descriptor.payload.inside.5643 = icmp ule i32 %local.check.payload.5635, %local.check.extent.5634
  %descriptor.owner.offset.valid.5644 = and i1 %descriptor.owner.inside.5639, %descriptor.offset.inside.5640
  %descriptor.range.inside.5646 = and i1 %descriptor.owner.offset.valid.5644, %descriptor.extent.inside.5642
  %descriptor.range.valid.5645 = and i1 %descriptor.range.inside.5646, %descriptor.payload.inside.5643
  br i1 %descriptor.range.valid.5645, label %descriptor.valid.5647, label %descriptor.invalid.5648
descriptor.invalid.5648:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5647:
  %descriptor.initialized.status.5649 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5633, i32 %local.check.extent.5634)
  %helper.ok.5650 = icmp eq i32 %descriptor.initialized.status.5649, 0
  br i1 %helper.ok.5650, label %helper.continue.5651, label %frame.failure.0
helper.continue.5651:
  br label %local.descriptor.checked.5632
local.descriptor.inactive.5631:
  br label %local.descriptor.checked.5632
local.descriptor.checked.5632:
  %local.is.active.5652 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5652, label %local.descriptor.active.5653, label %local.descriptor.inactive.5654
local.descriptor.active.5653:
  %local.check.offset.5656 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5657 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5658 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5659 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5661 = load i32, ptr %context.field.5660, align 4
  %stack.sub.5664 = sub i32 %local.check.owner.end.5659, %local.check.offset.5656
  %descriptor.owner.inside.5662 = icmp ule i32 %local.check.owner.end.5659, %context.value.5661
  %descriptor.offset.inside.5663 = icmp ule i32 %local.check.offset.5656, %local.check.owner.end.5659
  %descriptor.extent.inside.5665 = icmp ule i32 %local.check.extent.5657, %stack.sub.5664
  %descriptor.payload.inside.5666 = icmp ule i32 %local.check.payload.5658, %local.check.extent.5657
  %descriptor.owner.offset.valid.5667 = and i1 %descriptor.owner.inside.5662, %descriptor.offset.inside.5663
  %descriptor.range.inside.5669 = and i1 %descriptor.owner.offset.valid.5667, %descriptor.extent.inside.5665
  %descriptor.range.valid.5668 = and i1 %descriptor.range.inside.5669, %descriptor.payload.inside.5666
  br i1 %descriptor.range.valid.5668, label %descriptor.valid.5670, label %descriptor.invalid.5671
descriptor.invalid.5671:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5670:
  %descriptor.initialized.status.5672 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5656, i32 %local.check.extent.5657)
  %helper.ok.5673 = icmp eq i32 %descriptor.initialized.status.5672, 0
  br i1 %helper.ok.5673, label %helper.continue.5674, label %frame.failure.0
helper.continue.5674:
  br label %local.descriptor.checked.5655
local.descriptor.inactive.5654:
  br label %local.descriptor.checked.5655
local.descriptor.checked.5655:
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %context.field.5675 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5676 = load i32, ptr %context.field.5675, align 4
  %stack.sub.5679 = sub i32 %stack.offset.5483, %context.value.5482
  %descriptor.owner.inside.5677 = icmp ule i32 %stack.offset.5483, %context.value.5676
  %descriptor.offset.inside.5678 = icmp ule i32 %context.value.5482, %stack.offset.5483
  %descriptor.extent.inside.5680 = icmp ule i32 %stack.offset.5480, %stack.sub.5679
  %descriptor.payload.inside.5681 = icmp ule i32 %stack.offset.5479, %stack.offset.5480
  %descriptor.owner.offset.valid.5682 = and i1 %descriptor.owner.inside.5677, %descriptor.offset.inside.5678
  %descriptor.range.inside.5684 = and i1 %descriptor.owner.offset.valid.5682, %descriptor.extent.inside.5680
  %descriptor.range.valid.5683 = and i1 %descriptor.range.inside.5684, %descriptor.payload.inside.5681
  %descriptor.type.valid.5685 = icmp eq i32 5, 5
  %descriptor.valid.5686 = and i1 %descriptor.range.valid.5683, %descriptor.type.valid.5685
  br i1 %descriptor.valid.5686, label %descriptor.valid.5687, label %descriptor.invalid.5688
descriptor.invalid.5688:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5687:
  %descriptor.initialized.status.5689 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.5482, i32 %stack.offset.5480)
  %helper.ok.5690 = icmp eq i32 %descriptor.initialized.status.5689, 0
  br i1 %helper.ok.5690, label %helper.continue.5691, label %frame.failure.0
helper.continue.5691:
  %local.is.active.5692 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5692, label %local.descriptor.active.5693, label %local.descriptor.inactive.5694
local.descriptor.active.5693:
  %local.check.offset.5696 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5697 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5698 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5699 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5701 = load i32, ptr %context.field.5700, align 4
  %stack.sub.5704 = sub i32 %local.check.owner.end.5699, %local.check.offset.5696
  %descriptor.owner.inside.5702 = icmp ule i32 %local.check.owner.end.5699, %context.value.5701
  %descriptor.offset.inside.5703 = icmp ule i32 %local.check.offset.5696, %local.check.owner.end.5699
  %descriptor.extent.inside.5705 = icmp ule i32 %local.check.extent.5697, %stack.sub.5704
  %descriptor.payload.inside.5706 = icmp ule i32 %local.check.payload.5698, %local.check.extent.5697
  %descriptor.owner.offset.valid.5707 = and i1 %descriptor.owner.inside.5702, %descriptor.offset.inside.5703
  %descriptor.range.inside.5709 = and i1 %descriptor.owner.offset.valid.5707, %descriptor.extent.inside.5705
  %descriptor.range.valid.5708 = and i1 %descriptor.range.inside.5709, %descriptor.payload.inside.5706
  br i1 %descriptor.range.valid.5708, label %descriptor.valid.5710, label %descriptor.invalid.5711
descriptor.invalid.5711:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5710:
  %descriptor.initialized.status.5712 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5696, i32 %local.check.extent.5697)
  %helper.ok.5713 = icmp eq i32 %descriptor.initialized.status.5712, 0
  br i1 %helper.ok.5713, label %helper.continue.5714, label %frame.failure.0
helper.continue.5714:
  br label %local.descriptor.checked.5695
local.descriptor.inactive.5694:
  br label %local.descriptor.checked.5695
local.descriptor.checked.5695:
  %local.is.active.5715 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5715, label %local.descriptor.active.5716, label %local.descriptor.inactive.5717
local.descriptor.active.5716:
  %local.check.offset.5719 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5720 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5721 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5722 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5723 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5724 = load i32, ptr %context.field.5723, align 4
  %stack.sub.5727 = sub i32 %local.check.owner.end.5722, %local.check.offset.5719
  %descriptor.owner.inside.5725 = icmp ule i32 %local.check.owner.end.5722, %context.value.5724
  %descriptor.offset.inside.5726 = icmp ule i32 %local.check.offset.5719, %local.check.owner.end.5722
  %descriptor.extent.inside.5728 = icmp ule i32 %local.check.extent.5720, %stack.sub.5727
  %descriptor.payload.inside.5729 = icmp ule i32 %local.check.payload.5721, %local.check.extent.5720
  %descriptor.owner.offset.valid.5730 = and i1 %descriptor.owner.inside.5725, %descriptor.offset.inside.5726
  %descriptor.range.inside.5732 = and i1 %descriptor.owner.offset.valid.5730, %descriptor.extent.inside.5728
  %descriptor.range.valid.5731 = and i1 %descriptor.range.inside.5732, %descriptor.payload.inside.5729
  br i1 %descriptor.range.valid.5731, label %descriptor.valid.5733, label %descriptor.invalid.5734
descriptor.invalid.5734:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5733:
  %descriptor.initialized.status.5735 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5719, i32 %local.check.extent.5720)
  %helper.ok.5736 = icmp eq i32 %descriptor.initialized.status.5735, 0
  br i1 %helper.ok.5736, label %helper.continue.5737, label %frame.failure.0
helper.continue.5737:
  br label %local.descriptor.checked.5718
local.descriptor.inactive.5717:
  br label %local.descriptor.checked.5718
local.descriptor.checked.5718:
  %local.is.active.5738 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5738, label %local.descriptor.active.5739, label %local.descriptor.inactive.5740
local.descriptor.active.5739:
  %local.check.offset.5742 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5743 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5744 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5745 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5747 = load i32, ptr %context.field.5746, align 4
  %stack.sub.5750 = sub i32 %local.check.owner.end.5745, %local.check.offset.5742
  %descriptor.owner.inside.5748 = icmp ule i32 %local.check.owner.end.5745, %context.value.5747
  %descriptor.offset.inside.5749 = icmp ule i32 %local.check.offset.5742, %local.check.owner.end.5745
  %descriptor.extent.inside.5751 = icmp ule i32 %local.check.extent.5743, %stack.sub.5750
  %descriptor.payload.inside.5752 = icmp ule i32 %local.check.payload.5744, %local.check.extent.5743
  %descriptor.owner.offset.valid.5753 = and i1 %descriptor.owner.inside.5748, %descriptor.offset.inside.5749
  %descriptor.range.inside.5755 = and i1 %descriptor.owner.offset.valid.5753, %descriptor.extent.inside.5751
  %descriptor.range.valid.5754 = and i1 %descriptor.range.inside.5755, %descriptor.payload.inside.5752
  br i1 %descriptor.range.valid.5754, label %descriptor.valid.5756, label %descriptor.invalid.5757
descriptor.invalid.5757:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5756:
  %descriptor.initialized.status.5758 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5742, i32 %local.check.extent.5743)
  %helper.ok.5759 = icmp eq i32 %descriptor.initialized.status.5758, 0
  br i1 %helper.ok.5759, label %helper.continue.5760, label %frame.failure.0
helper.continue.5760:
  br label %local.descriptor.checked.5741
local.descriptor.inactive.5740:
  br label %local.descriptor.checked.5741
local.descriptor.checked.5741:
  %local.is.active.5761 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5761, label %local.descriptor.active.5762, label %local.descriptor.inactive.5763
local.descriptor.active.5762:
  %local.check.offset.5765 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5766 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5767 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5768 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5769 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5770 = load i32, ptr %context.field.5769, align 4
  %stack.sub.5773 = sub i32 %local.check.owner.end.5768, %local.check.offset.5765
  %descriptor.owner.inside.5771 = icmp ule i32 %local.check.owner.end.5768, %context.value.5770
  %descriptor.offset.inside.5772 = icmp ule i32 %local.check.offset.5765, %local.check.owner.end.5768
  %descriptor.extent.inside.5774 = icmp ule i32 %local.check.extent.5766, %stack.sub.5773
  %descriptor.payload.inside.5775 = icmp ule i32 %local.check.payload.5767, %local.check.extent.5766
  %descriptor.owner.offset.valid.5776 = and i1 %descriptor.owner.inside.5771, %descriptor.offset.inside.5772
  %descriptor.range.inside.5778 = and i1 %descriptor.owner.offset.valid.5776, %descriptor.extent.inside.5774
  %descriptor.range.valid.5777 = and i1 %descriptor.range.inside.5778, %descriptor.payload.inside.5775
  br i1 %descriptor.range.valid.5777, label %descriptor.valid.5779, label %descriptor.invalid.5780
descriptor.invalid.5780:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5779:
  %descriptor.initialized.status.5781 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5765, i32 %local.check.extent.5766)
  %helper.ok.5782 = icmp eq i32 %descriptor.initialized.status.5781, 0
  br i1 %helper.ok.5782, label %helper.continue.5783, label %frame.failure.0
helper.continue.5783:
  br label %local.descriptor.checked.5764
local.descriptor.inactive.5763:
  br label %local.descriptor.checked.5764
local.descriptor.checked.5764:
  %local.is.active.5784 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5784, label %local.descriptor.active.5785, label %local.descriptor.inactive.5786
local.descriptor.active.5785:
  %local.check.offset.5788 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5789 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5790 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5791 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5792 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5793 = load i32, ptr %context.field.5792, align 4
  %stack.sub.5796 = sub i32 %local.check.owner.end.5791, %local.check.offset.5788
  %descriptor.owner.inside.5794 = icmp ule i32 %local.check.owner.end.5791, %context.value.5793
  %descriptor.offset.inside.5795 = icmp ule i32 %local.check.offset.5788, %local.check.owner.end.5791
  %descriptor.extent.inside.5797 = icmp ule i32 %local.check.extent.5789, %stack.sub.5796
  %descriptor.payload.inside.5798 = icmp ule i32 %local.check.payload.5790, %local.check.extent.5789
  %descriptor.owner.offset.valid.5799 = and i1 %descriptor.owner.inside.5794, %descriptor.offset.inside.5795
  %descriptor.range.inside.5801 = and i1 %descriptor.owner.offset.valid.5799, %descriptor.extent.inside.5797
  %descriptor.range.valid.5800 = and i1 %descriptor.range.inside.5801, %descriptor.payload.inside.5798
  br i1 %descriptor.range.valid.5800, label %descriptor.valid.5802, label %descriptor.invalid.5803
descriptor.invalid.5803:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5802:
  %descriptor.initialized.status.5804 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5788, i32 %local.check.extent.5789)
  %helper.ok.5805 = icmp eq i32 %descriptor.initialized.status.5804, 0
  br i1 %helper.ok.5805, label %helper.continue.5806, label %frame.failure.0
helper.continue.5806:
  br label %local.descriptor.checked.5787
local.descriptor.inactive.5786:
  br label %local.descriptor.checked.5787
local.descriptor.checked.5787:
  %local.is.active.5807 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5807, label %local.descriptor.active.5808, label %local.descriptor.inactive.5809
local.descriptor.active.5808:
  %local.check.offset.5811 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5812 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5813 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5814 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5815 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5816 = load i32, ptr %context.field.5815, align 4
  %stack.sub.5819 = sub i32 %local.check.owner.end.5814, %local.check.offset.5811
  %descriptor.owner.inside.5817 = icmp ule i32 %local.check.owner.end.5814, %context.value.5816
  %descriptor.offset.inside.5818 = icmp ule i32 %local.check.offset.5811, %local.check.owner.end.5814
  %descriptor.extent.inside.5820 = icmp ule i32 %local.check.extent.5812, %stack.sub.5819
  %descriptor.payload.inside.5821 = icmp ule i32 %local.check.payload.5813, %local.check.extent.5812
  %descriptor.owner.offset.valid.5822 = and i1 %descriptor.owner.inside.5817, %descriptor.offset.inside.5818
  %descriptor.range.inside.5824 = and i1 %descriptor.owner.offset.valid.5822, %descriptor.extent.inside.5820
  %descriptor.range.valid.5823 = and i1 %descriptor.range.inside.5824, %descriptor.payload.inside.5821
  br i1 %descriptor.range.valid.5823, label %descriptor.valid.5825, label %descriptor.invalid.5826
descriptor.invalid.5826:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5825:
  %descriptor.initialized.status.5827 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5811, i32 %local.check.extent.5812)
  %helper.ok.5828 = icmp eq i32 %descriptor.initialized.status.5827, 0
  br i1 %helper.ok.5828, label %helper.continue.5829, label %frame.failure.0
helper.continue.5829:
  br label %local.descriptor.checked.5810
local.descriptor.inactive.5809:
  br label %local.descriptor.checked.5810
local.descriptor.checked.5810:
  %local.is.active.5830 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5830, label %local.descriptor.active.5831, label %local.descriptor.inactive.5832
local.descriptor.active.5831:
  %local.check.offset.5834 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5835 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5836 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5837 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5838 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5839 = load i32, ptr %context.field.5838, align 4
  %stack.sub.5842 = sub i32 %local.check.owner.end.5837, %local.check.offset.5834
  %descriptor.owner.inside.5840 = icmp ule i32 %local.check.owner.end.5837, %context.value.5839
  %descriptor.offset.inside.5841 = icmp ule i32 %local.check.offset.5834, %local.check.owner.end.5837
  %descriptor.extent.inside.5843 = icmp ule i32 %local.check.extent.5835, %stack.sub.5842
  %descriptor.payload.inside.5844 = icmp ule i32 %local.check.payload.5836, %local.check.extent.5835
  %descriptor.owner.offset.valid.5845 = and i1 %descriptor.owner.inside.5840, %descriptor.offset.inside.5841
  %descriptor.range.inside.5847 = and i1 %descriptor.owner.offset.valid.5845, %descriptor.extent.inside.5843
  %descriptor.range.valid.5846 = and i1 %descriptor.range.inside.5847, %descriptor.payload.inside.5844
  br i1 %descriptor.range.valid.5846, label %descriptor.valid.5848, label %descriptor.invalid.5849
descriptor.invalid.5849:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5848:
  %descriptor.initialized.status.5850 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5834, i32 %local.check.extent.5835)
  %helper.ok.5851 = icmp eq i32 %descriptor.initialized.status.5850, 0
  br i1 %helper.ok.5851, label %helper.continue.5852, label %frame.failure.0
helper.continue.5852:
  br label %local.descriptor.checked.5833
local.descriptor.inactive.5832:
  br label %local.descriptor.checked.5833
local.descriptor.checked.5833:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.5853 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.5854 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5853, i32 0, i32 0
  store i32 5, ptr %descriptor.field.5854, align 4
  %descriptor.field.5855 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5853, i32 0, i32 1
  store i32 %context.value.5482, ptr %descriptor.field.5855, align 4
  %descriptor.field.5856 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5853, i32 0, i32 2
  store i32 %stack.offset.5480, ptr %descriptor.field.5856, align 4
  %descriptor.field.5857 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5853, i32 0, i32 3
  store i32 %stack.offset.5479, ptr %descriptor.field.5857, align 4
  %descriptor.field.5858 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5853, i32 0, i32 4
  store i32 %stack.offset.5483, ptr %descriptor.field.5858, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.5482, i32 20, i32 %stack.offset.5479, i32 %stack.offset.5483, i32 %stack.offset.5480)
  %context.field.5859 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5860 = load i32, ptr %context.field.5859, align 4
  %runtime.ok.5861 = icmp eq i32 %context.value.5860, 0
  br i1 %runtime.ok.5861, label %runtime.continue.5862, label %frame.failure.0
runtime.continue.5862:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.45, i32 0, i32 0, i32 0)
  %context.field.5863 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5864 = load i32, ptr %context.field.5863, align 4
  %context.field.5865 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.5866 = load i32, ptr %context.field.5865, align 4
  %context.field.5867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.5868 = load i32, ptr %context.field.5867, align 4
  %stack.offset.5869 = add i32 %context.value.47, %context.value.49
  %stack.offset.5870 = add i32 %context.value.5864, %context.value.5866
  %stack.sub.5871 = sub i32 %stack.offset.5869, %stack.offset.5870
  %stack.sub.5872 = sub i32 %context.value.49, %context.value.5866
  %stack.sub.5873 = sub i32 %context.value.5868, %context.value.51
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5871, i32 %stack.sub.5872)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.5873)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 70, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 70, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 71)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 6, i32 72)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 6, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 73)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 5
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 5, 5
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.size.i64.80 = zext i32 %descriptor.value.55 to i64
  %entry.output.total.i64.81 = add i64 0, %entry.output.size.i64.80
  %entry.retained.capacity.i64.82 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.83 = icmp ule i64 %entry.output.total.i64.81, 4294967295
  %entry.retained.required.truncated.84 = trunc i64 %entry.output.total.i64.81 to i32
  %entry.retained.required.85 = select i1 %entry.retained.required.fits.u32.83, i32 %entry.retained.required.truncated.84, i32 4294967295
  %entry.retained.capacity.ok.86 = icmp ule i64 %entry.output.total.i64.81, %entry.retained.capacity.i64.82
  br i1 %entry.retained.capacity.ok.86, label %entry.retained.capacity.ready.87, label %entry.retained.capacity.failure.88
entry.retained.capacity.failure.88:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.85, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.87:
  %host.pointer.89 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.90 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.89, i32 %stack.sub.90, i32 %descriptor.value.53, i32 %descriptor.value.55, i32 5)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %stack.offset.95 = add i32 0, %descriptor.value.55
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.100 = sub i32 0, %context.value.97
  %stack.sub.101 = sub i32 0, %context.value.99
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.100, i32 %stack.sub.101)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  br label %entry.return.status
entry.failure.0:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.offset.112 = add i32 %context.value.107, %context.value.109
  %stack.sub.113 = sub i32 0, %stack.offset.112
  %stack.sub.114 = sub i32 0, %context.value.109
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.113, i32 %stack.sub.114)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.111)
  br label %entry.return.status
entry.return.status:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  ret i32 %context.value.116
}

define i32 @agentlang_mailbox_initialize(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.initialize.context.valid.1, label %mailbox.initialize.failure.0
mailbox.initialize.context.valid.1:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 0, i32 74, i32 75, i32 76, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.initialize.preflight.ready.2, label %mailbox.initialize.failure.0
mailbox.initialize.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.descriptors.12 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 77, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.initialize.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 77, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.initialize.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 6, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.total.35 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.35, i32 78)
  %helper.ok.37 = icmp eq i32 %mailbox.input.reserve.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %mailbox.initialize.failure.0
helper.continue.38:
  %mailbox.input.copy.status.39 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 6, i32 78)
  %helper.ok.40 = icmp eq i32 %mailbox.input.copy.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %mailbox.initialize.failure.0
helper.continue.41:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %mailbox.initialize.failure.0
runtime.continue.45:
  %mailbox.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.frame.status.47 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.46, i32 79)
  %helper.ok.48 = icmp eq i32 %mailbox.frame.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.initialize.failure.0
helper.continue.49:
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.46, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  %descriptor.value.52 = load i32, ptr %descriptor.field.51, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  %descriptor.value.54 = load i32, ptr %descriptor.field.53, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  %descriptor.value.56 = load i32, ptr %descriptor.field.55, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %mailbox.output.type.matches.61 = icmp eq i32 %descriptor.value.52, 5
  br i1 %mailbox.output.type.matches.61, label %mailbox.output.type.ok.62, label %mailbox.output.type.invalid.63
mailbox.output.type.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
mailbox.output.type.ok.62:
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %descriptor.value.60, %descriptor.value.54
  %descriptor.owner.inside.66 = icmp ule i32 %descriptor.value.60, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %descriptor.value.54, %descriptor.value.60
  %descriptor.extent.inside.69 = icmp ule i32 %descriptor.value.56, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %descriptor.value.58, %descriptor.value.56
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  %descriptor.type.valid.74 = icmp eq i32 5, 5
  %descriptor.valid.75 = and i1 %descriptor.range.valid.72, %descriptor.type.valid.74
  br i1 %descriptor.valid.75, label %descriptor.valid.76, label %descriptor.invalid.77
descriptor.invalid.77:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
descriptor.valid.76:
  %descriptor.initialized.status.78 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.54, i32 %descriptor.value.56)
  %helper.ok.79 = icmp eq i32 %descriptor.initialized.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %mailbox.initialize.failure.0
helper.continue.80:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.54, i32 20, i32 %descriptor.value.58, i32 %descriptor.value.60, i32 %descriptor.value.56)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %mailbox.initialize.failure.0
runtime.continue.84:
  %mailbox.output.descriptor.85 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.86 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.86, align 4
  %mailbox.output.field.87 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 1
  store i32 %descriptor.value.54, ptr %mailbox.output.field.87, align 4
  %mailbox.output.field.88 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 2
  store i32 %descriptor.value.60, ptr %mailbox.output.field.88, align 4
  %mailbox.output.field.89 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.89, align 4
  ret i32 0
mailbox.initialize.failure.0:
  %mailbox.failure.context.null.90 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.90, label %mailbox.failure.null.context.92, label %mailbox.failure.has.context.91
mailbox.failure.null.context.92:
  ret i32 4
mailbox.failure.has.context.91:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %mailbox.failure.status.set.96 = icmp ne i32 %context.value.95, 0
  br i1 %mailbox.failure.status.set.96, label %mailbox.failure.status.ready.93, label %mailbox.failure.set.fallback.97
mailbox.failure.set.fallback.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 74, i32 0, i32 0)
  br label %mailbox.failure.status.ready.93
mailbox.failure.status.ready.93:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  ret i32 %context.value.99
}


define i32 @agentlang_mailbox_begin(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.begin.context.valid.1, label %mailbox.begin.failure.0
mailbox.begin.context.valid.1:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 1, i32 80, i32 81, i32 82, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.begin.preflight.ready.2, label %mailbox.begin.failure.0
mailbox.begin.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.output.descriptor.12 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.13, align 4
  %mailbox.output.field.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.14, align 4
  %mailbox.output.field.15 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.15, align 4
  %mailbox.output.field.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.16, align 4
  %mailbox.input.descriptors.17 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.input.slice.18 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.19 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 0
  %mailbox.input.bytes.20 = load ptr, ptr %mailbox.input.bytes.field.19, align 8
  %mailbox.input.extent.field.21 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 1
  %mailbox.input.extent.22 = load i32, ptr %mailbox.input.extent.field.21, align 4
  %mailbox.input.payload.pointer.23 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.24 = alloca i32, align 4
  %mailbox.input.measure.status.25 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 83, ptr %mailbox.input.payload.pointer.23, ptr %mailbox.input.measured.extent.pointer.24)
  %helper.ok.26 = icmp eq i32 %mailbox.input.measure.status.25, 0
  br i1 %helper.ok.26, label %helper.continue.27, label %mailbox.begin.failure.0
helper.continue.27:
  %mailbox.input.payload.28 = load i32, ptr %mailbox.input.payload.pointer.23, align 4
  %mailbox.input.measured.extent.29 = load i32, ptr %mailbox.input.measured.extent.pointer.24, align 4
  %mailbox.input.extent.exact.30 = icmp eq i32 %mailbox.input.measured.extent.29, %mailbox.input.extent.22
  br i1 %mailbox.input.extent.exact.30, label %mailbox.input.extent.ok.31, label %mailbox.input.extent.invalid.32
mailbox.input.extent.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 83, i32 %mailbox.input.measured.extent.29, i32 %mailbox.input.extent.22)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.31:
  %stack.offset.33 = add i32 0, %mailbox.input.extent.22
  %descriptor.element.34 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 0
  %descriptor.field.35 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 0
  store i32 5, ptr %descriptor.field.35, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 1
  store i32 0, ptr %descriptor.field.36, align 4
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 2
  store i32 %mailbox.input.extent.22, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 3
  store i32 %mailbox.input.payload.28, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.39, align 4
  %mailbox.input.slice.40 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.41 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 0
  %mailbox.input.bytes.42 = load ptr, ptr %mailbox.input.bytes.field.41, align 8
  %mailbox.input.extent.field.43 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 1
  %mailbox.input.extent.44 = load i32, ptr %mailbox.input.extent.field.43, align 4
  %mailbox.input.payload.pointer.45 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.46 = alloca i32, align 4
  %mailbox.input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 83, ptr %mailbox.input.payload.pointer.45, ptr %mailbox.input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %mailbox.input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.begin.failure.0
helper.continue.49:
  %mailbox.input.payload.50 = load i32, ptr %mailbox.input.payload.pointer.45, align 4
  %mailbox.input.measured.extent.51 = load i32, ptr %mailbox.input.measured.extent.pointer.46, align 4
  %mailbox.input.extent.exact.52 = icmp eq i32 %mailbox.input.measured.extent.51, %mailbox.input.extent.44
  br i1 %mailbox.input.extent.exact.52, label %mailbox.input.extent.ok.53, label %mailbox.input.extent.invalid.54
mailbox.input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 83, i32 %mailbox.input.measured.extent.51, i32 %mailbox.input.extent.44)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.53:
  %stack.offset.55 = add i32 %stack.offset.33, %mailbox.input.extent.44
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  store i32 6, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  store i32 %stack.offset.33, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  store i32 %mailbox.input.extent.44, ptr %descriptor.field.59, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  store i32 %mailbox.input.payload.50, ptr %descriptor.field.60, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  store i32 %stack.offset.55, ptr %descriptor.field.61, align 4
  %mailbox.input.total.62 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.63 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.62, i32 84)
  %helper.ok.64 = icmp eq i32 %mailbox.input.reserve.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %mailbox.begin.failure.0
helper.continue.65:
  %mailbox.input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 %mailbox.input.payload.28, i32 %mailbox.input.extent.22, i32 5, i32 84)
  %helper.ok.67 = icmp eq i32 %mailbox.input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %mailbox.begin.failure.0
helper.continue.68:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.28, i32 %stack.offset.33, i32 %mailbox.input.extent.22)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %mailbox.begin.failure.0
runtime.continue.72:
  %mailbox.input.copy.status.73 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.33, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 %mailbox.input.payload.50, i32 %mailbox.input.extent.44, i32 6, i32 84)
  %helper.ok.74 = icmp eq i32 %mailbox.input.copy.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %mailbox.begin.failure.0
helper.continue.75:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %stack.offset.33, i32 20, i32 %mailbox.input.payload.50, i32 %stack.offset.55, i32 %mailbox.input.extent.44)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %mailbox.begin.failure.0
runtime.continue.79:
  %mailbox.output.descriptors.80 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.frame.status.81 = call i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %mailbox.input.descriptors.17, ptr %mailbox.output.descriptors.80, i32 85)
  %helper.ok.82 = icmp eq i32 %mailbox.frame.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %mailbox.begin.failure.0
helper.continue.83:
  %descriptor.element.84 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.80, i32 0
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 0
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 1
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 2
  %descriptor.value.90 = load i32, ptr %descriptor.field.89, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 3
  %descriptor.value.92 = load i32, ptr %descriptor.field.91, align 4
  %descriptor.field.93 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 4
  %descriptor.value.94 = load i32, ptr %descriptor.field.93, align 4
  %mailbox.output.type.matches.95 = icmp eq i32 %descriptor.value.86, 5
  br i1 %mailbox.output.type.matches.95, label %mailbox.output.type.ok.96, label %mailbox.output.type.invalid.97
mailbox.output.type.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.96:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.102 = sub i32 %descriptor.value.94, %descriptor.value.88
  %descriptor.owner.inside.100 = icmp ule i32 %descriptor.value.94, %context.value.99
  %descriptor.offset.inside.101 = icmp ule i32 %descriptor.value.88, %descriptor.value.94
  %descriptor.extent.inside.103 = icmp ule i32 %descriptor.value.90, %stack.sub.102
  %descriptor.payload.inside.104 = icmp ule i32 %descriptor.value.92, %descriptor.value.90
  %descriptor.owner.offset.valid.105 = and i1 %descriptor.owner.inside.100, %descriptor.offset.inside.101
  %descriptor.range.inside.107 = and i1 %descriptor.owner.offset.valid.105, %descriptor.extent.inside.103
  %descriptor.range.valid.106 = and i1 %descriptor.range.inside.107, %descriptor.payload.inside.104
  %descriptor.type.valid.108 = icmp eq i32 5, 5
  %descriptor.valid.109 = and i1 %descriptor.range.valid.106, %descriptor.type.valid.108
  br i1 %descriptor.valid.109, label %descriptor.valid.110, label %descriptor.invalid.111
descriptor.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.110:
  %descriptor.initialized.status.112 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.88, i32 %descriptor.value.90)
  %helper.ok.113 = icmp eq i32 %descriptor.initialized.status.112, 0
  br i1 %helper.ok.113, label %helper.continue.114, label %mailbox.begin.failure.0
helper.continue.114:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.88, i32 20, i32 %descriptor.value.92, i32 %descriptor.value.94, i32 %descriptor.value.90)
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %runtime.ok.117 = icmp eq i32 %context.value.116, 0
  br i1 %runtime.ok.117, label %runtime.continue.118, label %mailbox.begin.failure.0
runtime.continue.118:
  %descriptor.element.119 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.80, i32 1
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 0
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 1
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 2
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 3
  %descriptor.value.127 = load i32, ptr %descriptor.field.126, align 4
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 4
  %descriptor.value.129 = load i32, ptr %descriptor.field.128, align 4
  %mailbox.output.type.matches.130 = icmp eq i32 %descriptor.value.121, 4
  br i1 %mailbox.output.type.matches.130, label %mailbox.output.type.ok.131, label %mailbox.output.type.invalid.132
mailbox.output.type.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.131:
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %stack.sub.137 = sub i32 %descriptor.value.129, %descriptor.value.123
  %descriptor.owner.inside.135 = icmp ule i32 %descriptor.value.129, %context.value.134
  %descriptor.offset.inside.136 = icmp ule i32 %descriptor.value.123, %descriptor.value.129
  %descriptor.extent.inside.138 = icmp ule i32 %descriptor.value.125, %stack.sub.137
  %descriptor.payload.inside.139 = icmp ule i32 %descriptor.value.127, %descriptor.value.125
  %descriptor.owner.offset.valid.140 = and i1 %descriptor.owner.inside.135, %descriptor.offset.inside.136
  %descriptor.range.inside.142 = and i1 %descriptor.owner.offset.valid.140, %descriptor.extent.inside.138
  %descriptor.range.valid.141 = and i1 %descriptor.range.inside.142, %descriptor.payload.inside.139
  %descriptor.type.valid.143 = icmp eq i32 4, 4
  %descriptor.valid.144 = and i1 %descriptor.range.valid.141, %descriptor.type.valid.143
  br i1 %descriptor.valid.144, label %descriptor.valid.145, label %descriptor.invalid.146
descriptor.invalid.146:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.145:
  %descriptor.initialized.status.147 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.123, i32 %descriptor.value.125)
  %helper.ok.148 = icmp eq i32 %descriptor.initialized.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %mailbox.begin.failure.0
helper.continue.149:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.123, i32 20, i32 %descriptor.value.127, i32 %descriptor.value.129, i32 %descriptor.value.125)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %mailbox.begin.failure.0
runtime.continue.153:
  %mailbox.output.descriptor.154 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.155 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.155, align 4
  %mailbox.output.field.156 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 1
  store i32 %descriptor.value.88, ptr %mailbox.output.field.156, align 4
  %mailbox.output.field.157 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 2
  store i32 %descriptor.value.94, ptr %mailbox.output.field.157, align 4
  %mailbox.output.field.158 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.158, align 4
  %mailbox.output.descriptor.159 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.160 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 0
  store i32 2, ptr %mailbox.output.field.160, align 4
  %mailbox.output.field.161 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 1
  store i32 %descriptor.value.123, ptr %mailbox.output.field.161, align 4
  %mailbox.output.field.162 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 2
  store i32 %descriptor.value.129, ptr %mailbox.output.field.162, align 4
  %mailbox.output.field.163 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.163, align 4
  ret i32 0
mailbox.begin.failure.0:
  %mailbox.failure.context.null.164 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.164, label %mailbox.failure.null.context.166, label %mailbox.failure.has.context.165
mailbox.failure.null.context.166:
  ret i32 4
mailbox.failure.has.context.165:
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %mailbox.failure.status.set.170 = icmp ne i32 %context.value.169, 0
  br i1 %mailbox.failure.status.set.170, label %mailbox.failure.status.ready.167, label %mailbox.failure.set.fallback.171
mailbox.failure.set.fallback.171:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 80, i32 0, i32 0)
  br label %mailbox.failure.status.ready.167
mailbox.failure.status.ready.167:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  ret i32 %context.value.173
}


define i32 @agentlang_mailbox_resume(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.resume.context.valid.1, label %mailbox.resume.failure.0
mailbox.resume.context.valid.1:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 2, i32 86, i32 87, i32 88, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.resume.preflight.ready.2, label %mailbox.resume.failure.0
mailbox.resume.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 89, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.resume.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 89, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 5, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.slice.35 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.36 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 0
  %mailbox.input.bytes.37 = load ptr, ptr %mailbox.input.bytes.field.36, align 8
  %mailbox.input.extent.field.38 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 1
  %mailbox.input.extent.39 = load i32, ptr %mailbox.input.extent.field.38, align 4
  %mailbox.input.payload.pointer.40 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.41 = alloca i32, align 4
  %mailbox.input.measure.status.42 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 89, ptr %mailbox.input.payload.pointer.40, ptr %mailbox.input.measured.extent.pointer.41)
  %helper.ok.43 = icmp eq i32 %mailbox.input.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %mailbox.resume.failure.0
helper.continue.44:
  %mailbox.input.payload.45 = load i32, ptr %mailbox.input.payload.pointer.40, align 4
  %mailbox.input.measured.extent.46 = load i32, ptr %mailbox.input.measured.extent.pointer.41, align 4
  %mailbox.input.extent.exact.47 = icmp eq i32 %mailbox.input.measured.extent.46, %mailbox.input.extent.39
  br i1 %mailbox.input.extent.exact.47, label %mailbox.input.extent.ok.48, label %mailbox.input.extent.invalid.49
mailbox.input.extent.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 89, i32 %mailbox.input.measured.extent.46, i32 %mailbox.input.extent.39)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.48:
  %stack.offset.50 = add i32 %stack.offset.28, %mailbox.input.extent.39
  %descriptor.element.51 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 1
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 0
  store i32 4, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 1
  store i32 %stack.offset.28, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 2
  store i32 %mailbox.input.extent.39, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 3
  store i32 %mailbox.input.payload.45, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 4
  store i32 %stack.offset.50, ptr %descriptor.field.56, align 4
  %mailbox.input.slice.57 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 2
  %mailbox.input.bytes.field.58 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 0
  %mailbox.input.bytes.59 = load ptr, ptr %mailbox.input.bytes.field.58, align 8
  %mailbox.input.extent.field.60 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 1
  %mailbox.input.extent.61 = load i32, ptr %mailbox.input.extent.field.60, align 4
  %mailbox.input.payload.pointer.62 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.63 = alloca i32, align 4
  %mailbox.input.measure.status.64 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 89, ptr %mailbox.input.payload.pointer.62, ptr %mailbox.input.measured.extent.pointer.63)
  %helper.ok.65 = icmp eq i32 %mailbox.input.measure.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %mailbox.resume.failure.0
helper.continue.66:
  %mailbox.input.payload.67 = load i32, ptr %mailbox.input.payload.pointer.62, align 4
  %mailbox.input.measured.extent.68 = load i32, ptr %mailbox.input.measured.extent.pointer.63, align 4
  %mailbox.input.extent.exact.69 = icmp eq i32 %mailbox.input.measured.extent.68, %mailbox.input.extent.61
  br i1 %mailbox.input.extent.exact.69, label %mailbox.input.extent.ok.70, label %mailbox.input.extent.invalid.71
mailbox.input.extent.invalid.71:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 89, i32 %mailbox.input.measured.extent.68, i32 %mailbox.input.extent.61)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.70:
  %stack.offset.72 = add i32 %stack.offset.50, %mailbox.input.extent.61
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  store i32 6, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  store i32 %stack.offset.50, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  store i32 %mailbox.input.extent.61, ptr %descriptor.field.76, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  store i32 %mailbox.input.payload.67, ptr %descriptor.field.77, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  store i32 %stack.offset.72, ptr %descriptor.field.78, align 4
  %mailbox.input.total.79 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.79, i32 90)
  %helper.ok.81 = icmp eq i32 %mailbox.input.reserve.status.80, 0
  br i1 %helper.ok.81, label %helper.continue.82, label %mailbox.resume.failure.0
helper.continue.82:
  %mailbox.input.copy.status.83 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 5, i32 90)
  %helper.ok.84 = icmp eq i32 %mailbox.input.copy.status.83, 0
  br i1 %helper.ok.84, label %helper.continue.85, label %mailbox.resume.failure.0
helper.continue.85:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %runtime.ok.88 = icmp eq i32 %context.value.87, 0
  br i1 %runtime.ok.88, label %runtime.continue.89, label %mailbox.resume.failure.0
runtime.continue.89:
  %mailbox.input.copy.status.90 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.28, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 %mailbox.input.payload.45, i32 %mailbox.input.extent.39, i32 4, i32 90)
  %helper.ok.91 = icmp eq i32 %mailbox.input.copy.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %mailbox.resume.failure.0
helper.continue.92:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %stack.offset.28, i32 20, i32 %mailbox.input.payload.45, i32 %stack.offset.50, i32 %mailbox.input.extent.39)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %mailbox.resume.failure.0
runtime.continue.96:
  %mailbox.input.copy.status.97 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.50, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 %mailbox.input.payload.67, i32 %mailbox.input.extent.61, i32 6, i32 90)
  %helper.ok.98 = icmp eq i32 %mailbox.input.copy.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %mailbox.resume.failure.0
helper.continue.99:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %stack.offset.50, i32 20, i32 %mailbox.input.payload.67, i32 %stack.offset.72, i32 %mailbox.input.extent.61)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %mailbox.resume.failure.0
runtime.continue.103:
  %mailbox.output.descriptors.104 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.frame.status.105 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.104, i32 91)
  %helper.ok.106 = icmp eq i32 %mailbox.frame.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %mailbox.resume.failure.0
helper.continue.107:
  %descriptor.element.108 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.104, i32 0
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 0
  %descriptor.value.110 = load i32, ptr %descriptor.field.109, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 1
  %descriptor.value.112 = load i32, ptr %descriptor.field.111, align 4
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 2
  %descriptor.value.114 = load i32, ptr %descriptor.field.113, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 3
  %descriptor.value.116 = load i32, ptr %descriptor.field.115, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 4
  %descriptor.value.118 = load i32, ptr %descriptor.field.117, align 4
  %mailbox.output.type.matches.119 = icmp eq i32 %descriptor.value.110, 5
  br i1 %mailbox.output.type.matches.119, label %mailbox.output.type.ok.120, label %mailbox.output.type.invalid.121
mailbox.output.type.invalid.121:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
mailbox.output.type.ok.120:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %descriptor.value.118, %descriptor.value.112
  %descriptor.owner.inside.124 = icmp ule i32 %descriptor.value.118, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %descriptor.value.112, %descriptor.value.118
  %descriptor.extent.inside.127 = icmp ule i32 %descriptor.value.114, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %descriptor.value.116, %descriptor.value.114
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  %descriptor.type.valid.132 = icmp eq i32 5, 5
  %descriptor.valid.133 = and i1 %descriptor.range.valid.130, %descriptor.type.valid.132
  br i1 %descriptor.valid.133, label %descriptor.valid.134, label %descriptor.invalid.135
descriptor.invalid.135:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
descriptor.valid.134:
  %descriptor.initialized.status.136 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.112, i32 %descriptor.value.114)
  %helper.ok.137 = icmp eq i32 %descriptor.initialized.status.136, 0
  br i1 %helper.ok.137, label %helper.continue.138, label %mailbox.resume.failure.0
helper.continue.138:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.112, i32 20, i32 %descriptor.value.116, i32 %descriptor.value.118, i32 %descriptor.value.114)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %mailbox.resume.failure.0
runtime.continue.142:
  %mailbox.output.descriptor.143 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.144 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.144, align 4
  %mailbox.output.field.145 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 1
  store i32 %descriptor.value.112, ptr %mailbox.output.field.145, align 4
  %mailbox.output.field.146 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 2
  store i32 %descriptor.value.118, ptr %mailbox.output.field.146, align 4
  %mailbox.output.field.147 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.147, align 4
  ret i32 0
mailbox.resume.failure.0:
  %mailbox.failure.context.null.148 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.148, label %mailbox.failure.null.context.150, label %mailbox.failure.has.context.149
mailbox.failure.null.context.150:
  ret i32 4
mailbox.failure.has.context.149:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %mailbox.failure.status.set.154 = icmp ne i32 %context.value.153, 0
  br i1 %mailbox.failure.status.set.154, label %mailbox.failure.status.ready.151, label %mailbox.failure.set.fallback.155
mailbox.failure.set.fallback.155:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 86, i32 0, i32 0)
  br label %mailbox.failure.status.ready.151
mailbox.failure.status.ready.151:
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.157 = load i32, ptr %context.field.156, align 4
  ret i32 %context.value.157
}


define i32 @agentlang_mailbox_resume_associated(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity) {
entry:
  %associated.resume.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %associated.resume.context.nonnull.3, label %associated.resume.context.valid.1, label %associated.resume.failure.0
associated.resume.context.valid.1:
  %associated.resume.preflight.status.4 = call i32 @agentlang_owning_mailbox_associated_preflight(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity, i32 92, i32 93, i32 94)
  %associated.resume.preflight.ok.5 = icmp eq i32 %associated.resume.preflight.status.4, 0
  br i1 %associated.resume.preflight.ok.5, label %associated.resume.preflight.ready.2, label %associated.resume.failure.0
associated.resume.preflight.ready.2:
  %associated.resume.output.descriptor.6 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %associated.resume.output.field.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 4294967295, ptr %associated.resume.output.field.7, align 4
  %associated.resume.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 0, ptr %associated.resume.output.field.8, align 4
  %associated.resume.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 0, ptr %associated.resume.output.field.9, align 4
  %associated.resume.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.10, align 4
  %context.field.11 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 10
  store i32 0, ptr %context.field.11, align 4
  %associated.resume.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %associated.resume.retained.slice.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 0
  %associated.resume.retained.offset.pointer.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.15 = load i32, ptr %associated.resume.retained.offset.pointer.14, align 4
  %associated.resume.retained.owner.end.pointer.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.17 = load i32, ptr %associated.resume.retained.owner.end.pointer.16, align 4
  %associated.resume.retained.value.size.18 = alloca %AlOwningValueSize, align 4
  %associated.resume.retained.measure.status.19 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %associated.resume.retained.offset.pointer.value.15, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 95, ptr %associated.resume.retained.value.size.18)
  %helper.ok.20 = icmp eq i32 %associated.resume.retained.measure.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %associated.resume.failure.0
helper.continue.21:
  %associated.resume.retained.payload.pointer.22 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 0
  %associated.resume.retained.extent.pointer.23 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 1
  %associated.resume.retained.payload.24 = load i32, ptr %associated.resume.retained.payload.pointer.22, align 4
  %associated.resume.retained.extent.25 = load i32, ptr %associated.resume.retained.extent.pointer.23, align 4
  %descriptor.element.26 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 0
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 0
  store i32 5, ptr %descriptor.field.27, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.15, ptr %descriptor.field.28, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 2
  store i32 %associated.resume.retained.extent.25, ptr %descriptor.field.29, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 3
  store i32 %associated.resume.retained.payload.24, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.17, ptr %descriptor.field.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %associated.resume.retained.offset.pointer.value.15, i32 20, i32 %associated.resume.retained.payload.24, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 %associated.resume.retained.extent.25)
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %runtime.ok.34 = icmp eq i32 %context.value.33, 0
  br i1 %runtime.ok.34, label %runtime.continue.35, label %associated.resume.failure.0
runtime.continue.35:
  %associated.resume.retained.slice.36 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 1
  %associated.resume.retained.offset.pointer.37 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.38 = load i32, ptr %associated.resume.retained.offset.pointer.37, align 4
  %associated.resume.retained.owner.end.pointer.39 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.40 = load i32, ptr %associated.resume.retained.owner.end.pointer.39, align 4
  %associated.resume.retained.value.size.41 = alloca %AlOwningValueSize, align 4
  %associated.resume.retained.measure.status.42 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %associated.resume.retained.offset.pointer.value.38, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 95, ptr %associated.resume.retained.value.size.41)
  %helper.ok.43 = icmp eq i32 %associated.resume.retained.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %associated.resume.failure.0
helper.continue.44:
  %associated.resume.retained.payload.pointer.45 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 0
  %associated.resume.retained.extent.pointer.46 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 1
  %associated.resume.retained.payload.47 = load i32, ptr %associated.resume.retained.payload.pointer.45, align 4
  %associated.resume.retained.extent.48 = load i32, ptr %associated.resume.retained.extent.pointer.46, align 4
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 1
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  store i32 4, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.38, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  store i32 %associated.resume.retained.extent.48, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  store i32 %associated.resume.retained.payload.47, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.40, ptr %descriptor.field.54, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %associated.resume.retained.offset.pointer.value.38, i32 20, i32 %associated.resume.retained.payload.47, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 %associated.resume.retained.extent.48)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %associated.resume.failure.0
runtime.continue.58:
  %associated.resume.completion.bytes.pointer.59 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 0
  %associated.resume.completion.bytes.60 = load ptr, ptr %associated.resume.completion.bytes.pointer.59, align 8
  %associated.resume.completion.extent.pointer.61 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 1
  %associated.resume.completion.extent.62 = load i32, ptr %associated.resume.completion.extent.pointer.61, align 4
  %associated.resume.completion.payload.pointer.63 = alloca i32, align 4
  %associated.resume.completion.measured.extent.pointer.64 = alloca i32, align 4
  %associated.resume.completion.measure.status.65 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 95, ptr %associated.resume.completion.payload.pointer.63, ptr %associated.resume.completion.measured.extent.pointer.64)
  %helper.ok.66 = icmp eq i32 %associated.resume.completion.measure.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %associated.resume.failure.0
helper.continue.67:
  %associated.resume.completion.payload.68 = load i32, ptr %associated.resume.completion.payload.pointer.63, align 4
  %associated.resume.completion.measured.extent.69 = load i32, ptr %associated.resume.completion.measured.extent.pointer.64, align 4
  %associated.resume.completion.extent.matches.70 = icmp eq i32 %associated.resume.completion.measured.extent.69, %associated.resume.completion.extent.62
  br i1 %associated.resume.completion.extent.matches.70, label %associated.resume.completion.extent.ok.71, label %associated.resume.failure.0
associated.resume.completion.extent.ok.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.offset.74 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %reserve.status.75 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.74, i32 96)
  %reserve.ok.76 = icmp eq i32 %reserve.status.75, 0
  br i1 %reserve.ok.76, label %reserve.continue.77, label %associated.resume.failure.0
reserve.continue.77:
  %associated.resume.completion.copy.status.78 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %context.value.73, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 %associated.resume.completion.payload.68, i32 %associated.resume.completion.extent.62, i32 6, i32 96)
  %helper.ok.79 = icmp eq i32 %associated.resume.completion.copy.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %associated.resume.failure.0
helper.continue.80:
  %stack.offset.81 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 2
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  store i32 6, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  store i32 %context.value.73, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  store i32 %associated.resume.completion.extent.62, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  store i32 %associated.resume.completion.payload.68, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  store i32 %stack.offset.81, ptr %descriptor.field.87, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.73, i32 20, i32 %associated.resume.completion.payload.68, i32 %stack.offset.81, i32 %associated.resume.completion.extent.62)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %associated.resume.failure.0
runtime.continue.91:
  %associated.resume.output.descriptors.92 = alloca [1 x %AlOwningDescriptor], align 4
  %associated.resume.frame.status.93 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %associated.resume.input.descriptors.12, ptr %associated.resume.output.descriptors.92, i32 97)
  %helper.ok.94 = icmp eq i32 %associated.resume.frame.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %associated.resume.failure.0
helper.continue.95:
  %descriptor.element.96 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.output.descriptors.92, i32 0
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 0
  %descriptor.value.98 = load i32, ptr %descriptor.field.97, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 1
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 2
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 3
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 4
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %associated.resume.output.type.matches.107 = icmp eq i32 %descriptor.value.98, 5
  br i1 %associated.resume.output.type.matches.107, label %associated.resume.output.type.ok.108, label %associated.resume.failure.0
associated.resume.output.type.ok.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %descriptor.value.106, %descriptor.value.100
  %descriptor.owner.inside.111 = icmp ule i32 %descriptor.value.106, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %descriptor.value.100, %descriptor.value.106
  %descriptor.extent.inside.114 = icmp ule i32 %descriptor.value.102, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %descriptor.value.104, %descriptor.value.102
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 5, 5
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %associated.resume.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.100, i32 %descriptor.value.102)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %associated.resume.failure.0
helper.continue.125:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.100, i32 20, i32 %descriptor.value.104, i32 %descriptor.value.106, i32 %descriptor.value.102)
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %runtime.ok.128 = icmp eq i32 %context.value.127, 0
  br i1 %runtime.ok.128, label %runtime.continue.129, label %associated.resume.failure.0
runtime.continue.129:
  %associated.resume.output.field.130 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 3, ptr %associated.resume.output.field.130, align 4
  %associated.resume.output.field.131 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 %descriptor.value.100, ptr %associated.resume.output.field.131, align 4
  %associated.resume.output.field.132 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 %descriptor.value.106, ptr %associated.resume.output.field.132, align 4
  %associated.resume.output.field.133 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.133, align 4
  ret i32 0
associated.resume.failure.0:
  %associated.resume.failure.context.null.134 = icmp eq ptr %ctx, null
  br i1 %associated.resume.failure.context.null.134, label %associated.resume.failure.null.context.136, label %associated.resume.failure.has.context.135
associated.resume.failure.null.context.136:
  ret i32 4
associated.resume.failure.has.context.135:
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %associated.resume.failure.status.set.140 = icmp ne i32 %context.value.139, 0
  br i1 %associated.resume.failure.status.set.140, label %associated.resume.failure.status.ready.137, label %associated.resume.failure.set.fallback.141
associated.resume.failure.set.fallback.141:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 92, i32 0, i32 0)
  br label %associated.resume.failure.status.ready.137
associated.resume.failure.status.ready.137:
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  ret i32 %context.value.143
}



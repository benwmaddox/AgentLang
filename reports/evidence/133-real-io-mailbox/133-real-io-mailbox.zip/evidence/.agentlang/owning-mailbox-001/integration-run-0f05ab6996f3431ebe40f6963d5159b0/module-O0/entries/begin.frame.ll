define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 6
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 6, 6
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 5, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 6, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %call.results.97 = alloca [2 x %AlOwningDescriptor], align 4
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.76, ptr %call.results.97, i32 4)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 5
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 5, 5
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %descriptor.element.135 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 1
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 0
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 1
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 2
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 3
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 4
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %callee.result.type.valid.146 = icmp eq i32 %descriptor.value.137, 4
  br i1 %callee.result.type.valid.146, label %callee.result.type.ok.147, label %frame.failure.0
callee.result.type.ok.147:
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %stack.sub.152 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.150 = icmp ule i32 %descriptor.value.145, %context.value.149
  %descriptor.offset.inside.151 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.153 = icmp ule i32 %descriptor.value.141, %stack.sub.152
  %descriptor.payload.inside.154 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.155 = and i1 %descriptor.owner.inside.150, %descriptor.offset.inside.151
  %descriptor.range.inside.157 = and i1 %descriptor.owner.offset.valid.155, %descriptor.extent.inside.153
  %descriptor.range.valid.156 = and i1 %descriptor.range.inside.157, %descriptor.payload.inside.154
  %descriptor.type.valid.158 = icmp eq i32 4, 4
  %descriptor.valid.159 = and i1 %descriptor.range.valid.156, %descriptor.type.valid.158
  br i1 %descriptor.valid.159, label %descriptor.valid.160, label %descriptor.invalid.161
descriptor.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.160:
  %descriptor.initialized.status.162 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.163 = icmp eq i32 %descriptor.initialized.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %runtime.ok.167 = icmp eq i32 %context.value.166, 0
  br i1 %runtime.ok.167, label %runtime.continue.168, label %frame.failure.0
runtime.continue.168:
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.171 = icmp ule i32 %descriptor.value.111, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.174 = icmp ule i32 %descriptor.value.107, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  %descriptor.type.valid.179 = icmp eq i32 5, 5
  %descriptor.valid.180 = and i1 %descriptor.range.valid.177, %descriptor.type.valid.179
  br i1 %descriptor.valid.180, label %descriptor.valid.181, label %descriptor.invalid.182
descriptor.invalid.182:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.181:
  %descriptor.initialized.status.183 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.184 = icmp eq i32 %descriptor.initialized.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %frame.failure.0
helper.continue.185:
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %stack.sub.190 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.188 = icmp ule i32 %descriptor.value.145, %context.value.187
  %descriptor.offset.inside.189 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.191 = icmp ule i32 %descriptor.value.141, %stack.sub.190
  %descriptor.payload.inside.192 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.193 = and i1 %descriptor.owner.inside.188, %descriptor.offset.inside.189
  %descriptor.range.inside.195 = and i1 %descriptor.owner.offset.valid.193, %descriptor.extent.inside.191
  %descriptor.range.valid.194 = and i1 %descriptor.range.inside.195, %descriptor.payload.inside.192
  %descriptor.type.valid.196 = icmp eq i32 4, 4
  %descriptor.valid.197 = and i1 %descriptor.range.valid.194, %descriptor.type.valid.196
  br i1 %descriptor.valid.197, label %descriptor.valid.198, label %descriptor.invalid.199
descriptor.invalid.199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.198:
  %descriptor.initialized.status.200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.201 = icmp eq i32 %descriptor.initialized.status.200, 0
  br i1 %helper.ok.201, label %helper.continue.202, label %frame.failure.0
helper.continue.202:
  %descriptor.element.203 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 0
  store i32 5, ptr %descriptor.field.204, align 4
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.208, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %runtime.ok.211 = icmp eq i32 %context.value.210, 0
  br i1 %runtime.ok.211, label %runtime.continue.212, label %frame.failure.0
runtime.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 4, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.139, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.141, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.143, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.145, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %stack.offset.229 = add i32 %context.value.5, %context.value.7
  %stack.offset.230 = add i32 %context.value.224, %context.value.226
  %stack.sub.231 = sub i32 %stack.offset.229, %stack.offset.230
  %stack.sub.232 = sub i32 %context.value.7, %context.value.226
  %stack.sub.233 = sub i32 %context.value.228, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.231, i32 %stack.sub.232)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.233)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


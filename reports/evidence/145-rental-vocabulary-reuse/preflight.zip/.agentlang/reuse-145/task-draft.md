# Rental billing query

Add a pure query that counts the chargeable integer days of one equipment rental
within a requested half-open billing window.

Required API:
- AgentLang: rental.billable-days(rental: Rental, from-day: Int, until-day: Int) -> Result<Int, RentalError>.
- F#: RentalDomain.Rental.billableDays : Rental.T -> int64 -> int64 -> Result<int64, RentalError>.

A valid stored rental has 0 <= start-day < finish-day <= 366. Its optional
cancellation day is at or after start-day and may be later than finish-day.
Without cancellation it occupies [start-day, finish-day). With cancellation it
occupies [start-day, min(finish-day, cancellation-day)). Cancellation at its start
therefore leaves no occupied days. Existing start/cancel operations construct
valid rentals; preserve their behavior and validation.

First reject a request with from-day >= until-day using RentalError code
INVALID_BILLING_WINDOW, even when the rental has no occupied days. Otherwise
return the number of integer days d for which from-day <= d < until-day and the
rental occupies d. Request bounds may be any signed 64-bit integers; the answer
is bounded by the rental's at most 366 occupied days. Do not overflow by measuring
the entire requested window. Adjacency contributes zero days. Error text should
explain the invalid window; exact wording is not an acceptance requirement.

Preserve all input rental fields and existing project behavior. Inspect the
available APIs and documentation. You may add helpers and types where useful;
no particular private helper or algorithm is required. Add effective tests,
retain all inherited tests and public APIs, and run the complete project suite.
In AgentLang, qualify and publish the query and any authored dependencies as
libraries without demoting existing library functions. Finish the normal task
and broker workflow. F# uses its existing compiler and test workflow.

## Planned independent acceptance

Coordinator-only: shared enumerated-day cases, inherited suite, scope and stable
input fields, AgentLang library qualification, normal close/taskcommit, and actual
reachability of preexisting helper calls. Reuse is an observation, not required
for behavioral acceptance. No participant has been dispatched.

# Reuse-145 study plan

## Recommended task and public contract

Add one pure billing query for an equipment rental's occupied days:

`rental.billable-days(rental: Rental, from-day: Int, until-day: Int) -> Result<Int, RentalError>`

A rental stores a valid nonempty integer service span `[start-day, finish-day)` and an optional cancellation day. Count the integer days in the intersection of the requested billing window `[from-day, until-day)` and the occupied rental span, which ends at cancellation or finish, whichever comes first. Return `INVALID_BILLING_WINDOW` when `from-day >= until-day`. A cancellation at the rental start is valid stored state and yields `Ok(0)` for a valid billing window.

This is an unfamiliar billing query, not a subscription-start or booking-conflict repair. The operation is pure: preserve the input Rental and containing project state on success and error. Keep it to one rental span so the change does not require a list fold or new runtime feature. The shared prompt states integer half-open semantics and the result contract, but does not name or prescribe an interval helper.

## Four cells and matched starts

Use one fresh participant per cell: AgentLang-retained, AgentLang-no-helper, F#-retained, F#-no-helper. Reuse the current frozen CLI builds and report 143's V2 broker/termination audit. Keep the existing broker limits. Preconfigure `NuGetAudit=false` for both F# starts as directed; report the qualification difference plainly. The comparison is exploratory; four participants are not general causal or reliability evidence.

- Retained AgentLang starts include the prequalified `Interval`, `interval.try-create`, and `interval.overlaps?` vocabulary from `examples/nonempty-interval.agent`, including docs/tests.
- Retained F# starts include the report-144 equivalent private validated interval record and documented safe-construction/overlap functions.
- No-helper starts omit only that helper vocabulary. Their agents may write their own helpers; acceptance does not require a helper or a particular representation.
- Within each language, match the Rental type, query signature, task/docs, fixtures, and inherited tests. Across languages, match names and observable contract, adapting only syntax and each language's ordinary qualification evidence. Pin four independent clean starts; no edits or outcomes carry between cells.

## Compact independent cases

Use a small oracle that enumerates integer days in the requested window and counts those before the effective rental end, rather than reusing the implementation's overlap formula.

1. Rental `[2,8)`, not cancelled; window `[5,10)` returns 3.
2. Same rental; adjacent window `[8,10)` returns 0.
3. Rental `[2,8)`, cancelled at 5; window `[3,8)` returns 2.
4. Rental `[2,8)`, cancelled at 2; valid window `[1,4)` returns 0.
5. Equal and reversed requested windows return `INVALID_BILLING_WINDOW`.
6. Every case preserves all input Rental fields and persistent project/store bytes.

Create the cancellation-at-start fixture by applying the supported cancellation operation to a valid `[2,8)` rental at day 2. Do not construct an empty/reversed stored Rental or cancellation-before-start. Keep invalid user windows separate from valid empty stored occupancy.

## Scoring and minimal controls

Score independently: oracle behavior; preservation and exact error; submitted tests and applicable coverage; scoped source changes and normal broker close; and helper reuse. Count reuse only if the new production call graph reaches the helper that was present at that cell's launch. An agent-authored helper in a no-helper cell is reported as authored abstraction, not reuse. A retained-cell implementation may pass without reuse.

Before dispatch, check inherited suites and hash the starts, task, fixtures, oracle, and broker inputs. Run an unchanged-seed control, one coordinator positive implementation per language, and one targeted adjacency mutation that the shared oracle must reject. Reuse report 143's host-close, trace, and input-preservation audits. Accept only four fresh pinned starts and four completed independent runs, a shared public contract, oracle results for every submission, preserved inputs, recorded language-appropriate qualification, and clean broker termination. Report outcomes descriptively without a broad causal claim.

## Root implementation decisions before fixture authoring

- Rental start/finish are bounded to 0 <= start < finish <= 366; cancellation is optional and must be >= start, including cancellation after finish. Request bounds are signed Int64 and only from >= until is invalid. Count therefore remains 0..366 even for extreme request bounds. Enumerate stored rental days for the independent oracle, never the potentially huge request window.
- Shared input API: rental.start(start, finish) -> Result<Rental,RentalError>; rental.cancel(rental, day) -> Result<Rental,RentalError>. Error has code/message fields. F# uses equivalent Rental.start, Rental.cancel and string-coded error record. Cancellation replaces the optional day; before-start cancellation errors. Consumer rental.billable-days / Rental.billableDays is initially absent.
- Result validation checks code INVALID_BILLING_WINDOW for invalid requests, exact count otherwise, all input fields unchanged. Error text is not a wording gate.
- Retained F# interval provides endpoint getters corresponding to AgentLang generated property access. Both retained APIs retain report144's strict constructor and overlap semantics; no intersection/count helper is added.
- Baselines contain identical domain APIs/docs/tests within each language. Only retained starts add interval vocabulary/tests. No-helper agents may build abstractions. Required query must be library-qualified in AgentLang; F# uses its ordinary compiler/test contract. Preserve existing types, APIs and tests.
- Four fresh Luna/max participants, one per cell, 100 broker exchanges, V2 host, no cross-project/raw source access beyond assigned prompt, no peer help. Add identical NuGetAudit=false to both F# starts before dispatch. This is exploratory, not an estimate of population performance.
- Preflight uses absent-entry negative, correct coordinator implementations, and a compiling positive-count-plus-one defect. No participant dispatch before public task, starts, oracle and runtime hashes freeze. Final code behavior, own tests, scope, actual inherited-helper reuse and workflow are separate dimensions.

## Verified fixture qualification limit

The frozen runtime refuses library qualification for `rental.start` and
`rental.cancel` because their returns contain validated Rental with an open
Option<Int> projection. Preserve those builders at project maturity and retain
the exact failed qualification evidence. This does not change the public task:
only the new query and its authored production dependencies must qualify. Rental
inputs are not direct Bool/enum input obligations; the query returns
Result<Int,RentalError>. A separate positive query probe qualifies and reloads.
Fixture-building calls from tests are not production dependency calls. Do not
remove validation or alter cancellation semantics to bypass the limitation.
No runtime changes are needed for the comparison.

#requires -Version 7.5
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$flow = $PSScriptRoot
$repo = 'D:\code\AgentLang'
$cli = Join-Path $repo '.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
if (-not (Test-Path -LiteralPath $cli -PathType Leaf)) { throw "Frozen CLI not found: $cli" }

function Write-Text([string]$Path, [string]$Text) {
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path)))
    [IO.File]::WriteAllText($Path, $Text, [Text.UTF8Encoding]::new($false))
}
function Write-Json([string]$Path, [object]$Value) {
    Write-Text $Path (ConvertTo-Json -InputObject $Value -Depth 50)
}
function Write-Jsonl([string]$Path, [object[]]$Items) {
    Write-Text $Path ((@($Items | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 50 -Compress }) -join "`n") + "`n")
}
function Copy-Project([string]$From, [string]$To) {
    if (Test-Path -LiteralPath $To) { throw "Refusing existing target: $To" }
    [void][IO.Directory]::CreateDirectory($To)
    foreach ($item in Get-ChildItem -LiteralPath $From -Force -Recurse) {
        $relative = [IO.Path]::GetRelativePath($From, $item.FullName)
        if ($relative -match '(^|[\\/])WRITE\.lock$') { continue }
        $target = Join-Path $To $relative
        if ($item.PSIsContainer) { [void][IO.Directory]::CreateDirectory($target) }
        else {
            [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
            [IO.File]::Copy($item.FullName, $target, $false)
        }
    }
}
function Invoke-Flow([string]$Name, [string]$Project, [string]$Phase, [object[]]$Requests, [switch]$AllowFailedResponses) {
    $out = Join-Path $flow "evidence/controls/$Name"
    [void][IO.Directory]::CreateDirectory($out)
    $requestPath = Join-Path $out "$Phase.requests.jsonl"
    $responsePath = Join-Path $out "$Phase.responses.jsonl"
    $stderrPath = Join-Path $out "$Phase.stderr.txt"
    $processPath = Join-Path $out "$Phase.process.json"
    Write-Jsonl $requestPath $Requests
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = 'dotnet'
    $info.WorkingDirectory = $Project
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    foreach ($arg in @($cli, '--project', $Project, '--jsonl')) { [void]$info.ArgumentList.Add([string]$arg) }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $info
    if (-not $process.Start()) { throw "Could not start Flow for $Name/$Phase" }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    foreach ($request in $Requests) { $process.StandardInput.WriteLine((ConvertTo-Json -InputObject $request -Depth 50 -Compress)) }
    $process.StandardInput.Close()
    if (-not $process.WaitForExit(180000)) { try { $process.Kill($true) } catch {}; throw "Flow timed out for $Name/$Phase" }
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    $exit = $process.ExitCode
    $process.Dispose()
    Write-Text $responsePath $stdout
    Write-Text $stderrPath $stderr
    $responses = @($stdout -split '\r?\n' | Where-Object { $_ } | ForEach-Object { ConvertFrom-Json -InputObject $_ -AsHashtable -Depth 50 -DateKind String })
    $command = "dotnet `"$cli`" --project `"$Project`" --jsonl"
    Write-Json $processPath ([ordered]@{ command = $command; workingDirectory = $Project; requestCount = $Requests.Count; responseCount = $responses.Count; exitCode = $exit })
    if ($exit -ne 0 -or $responses.Count -ne $Requests.Count -or ((-not $AllowFailedResponses) -and @($responses | Where-Object { $_.ok -ne $true }).Count -gt 0)) {
        throw "Flow request failed for $Name/$Phase; inspect $responsePath"
    }
    return ,$responses
}
function Test-Summary([object[]]$Responses) {
    $lastTest = @($Responses | Where-Object { $_.kind -eq 'test' } | Select-Object -Last 1)
    if (-not $lastTest.Count) { return $null }
    $results = @($lastTest[0].data.results)
    return [ordered]@{ text = $lastTest[0].text; total = $results.Count; passed = @($results | Where-Object passed).Count; failed = @($results | Where-Object { $_.passed -ne $true }).Count }
}
function Project-Manifest([string]$Project) {
    $items = foreach ($file in Get-ChildItem -LiteralPath $Project -Force -Recurse -File) {
        $rel = [IO.Path]::GetRelativePath($Project, $file.FullName)
        if ($rel -match '(^|[\\/])WRITE\.lock$') { continue }
        [ordered]@{ path = $rel.Replace('\\','/'); length = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
    }
    return @($items | Sort-Object path)
}
function Remove-OwnedProject([string]$Project) {
    $controlRoot = [IO.Path]::GetFullPath((Join-Path $flow 'controls')) + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath($Project)
    if (-not $full.StartsWith($controlRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Refusing removal outside flow/controls: $full" }
    if (Test-Path -LiteralPath $full) { Remove-Item -LiteralPath $full -Recurse -Force }
}

$retained = Join-Path $flow 'starts/retained/project'
$correctProject = Join-Path $flow 'controls/correct/project'
$mutantProject = Join-Path $flow 'controls/mutant-positive-plus-one/project'
$correctPath = Join-Path $flow 'controls/correct/billable-days.agent'
$mutantPath = Join-Path $flow 'controls/mutant-positive-plus-one/billable-days.agent'
if (-not (Test-Path -LiteralPath $retained -PathType Container)) { throw "Retained start missing: $retained" }
$startFingerprintBefore = @{}
foreach ($p in @((Join-Path $flow 'starts/flat/project/dictionary.agent'), (Join-Path $flow 'starts/retained/project/dictionary.agent'), (Join-Path $flow 'starts/flat/source.agent'), (Join-Path $flow 'starts/retained/source.agent'))) {
    $startFingerprintBefore[$p] = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()
}
Remove-OwnedProject $correctProject
Remove-OwnedProject $mutantProject
Copy-Project $retained $correctProject
Copy-Project $retained $mutantProject

$correctSource = [IO.File]::ReadAllText($correctPath)
$correctRequests = @(
    [ordered]@{ op='define'; frontend='flow'; syntaxVersion=2; source=$correctSource },
    [ordered]@{ op='test-all' },
    [ordered]@{ op='commit'; word='rental.billable-days'; library=$true },
    [ordered]@{ op='test-all' },
    [ordered]@{ op='describe'; word='rental.billable-days' },
    [ordered]@{ op='source'; type='Rental' },
    [ordered]@{ op='source'; type='RentalError' }
)
$correctInitial = Invoke-Flow 'correct' $correctProject 'library-qualification' $correctRequests
$freshRequests = @(
    [ordered]@{ op='test-all' },
    [ordered]@{ op='describe'; word='rental.billable-days' },
    [ordered]@{ op='source'; type='Rental' },
    [ordered]@{ op='source'; type='RentalError' }
)
$correctFresh = Invoke-Flow 'correct' $correctProject 'fresh-reload' $freshRequests
$correctDesc = @($correctFresh | Where-Object { $_.kind -eq 'describe' -and $_.data.name -ceq 'rental.billable-days' })[0]
$correctSummary = Test-Summary $correctFresh
if ($correctDesc.data.maturity -ne 'library' -or $correctSummary.failed -ne 0) { throw 'Correct target did not fresh-reload with all tests at library maturity.' }

$mutantSource = [IO.File]::ReadAllText($mutantPath)
$mutantRequests = @(
    [ordered]@{ op='define'; frontend='flow'; syntaxVersion=2; source=$mutantSource },
    [ordered]@{ op='test-all' },
    [ordered]@{ op='describe'; word='rental.billable-days' }
)
$mutantStaged = Invoke-Flow 'mutant-positive-plus-one' $mutantProject 'stage-mutant' $mutantRequests -AllowFailedResponses
$mutantSummary = Test-Summary $mutantStaged
if ($mutantStaged[0].ok -ne $true -or $mutantSummary.failed -ne 3) { throw 'The compiled +1 mutant must fail exactly the three positive-count assertions.' }

# Preserve exact builder library-qualification failures from isolated clones of each start.
$limitOut = Join-Path $flow 'controls/library-limit-probe'
$limitRecords = [Collections.Generic.List[object]]::new()
foreach ($word in @('rental.start','rental.cancel')) {
    $safe = $word.Replace('.','-')
    $project = Join-Path $limitOut "$safe/project"
    Remove-OwnedProject $project
    Copy-Project (Join-Path $flow 'starts/flat/project') $project
    $baseSource = [IO.File]::ReadAllText((Join-Path $flow 'starts/flat/source.agent'))
    if ($word -eq 'rental.start') {
        $functionSource = [regex]::Match($baseSource, '(?ms)^fn rental\.start\b.*?(?=^fn rental\.cancel\b)').Value.Trim()
        $testSource = [regex]::Match($baseSource, '(?ms)^test rental\.start/.*?(?=^test rental\.cancel/)').Value.Trim()
    } else {
        $functionSource = [regex]::Match($baseSource, '(?ms)^fn rental\.cancel\b.*?(?=^test rental\.valid\?/|^test rental\.cancel/)').Value.Trim()
        $testSource = [regex]::Match($baseSource, '(?ms)^test rental\.cancel/.*').Value.Trim()
    }
    if (-not $functionSource -or -not $testSource) { throw "Could not isolate authored function and tests for $word" }
    $candidateSource = $functionSource + "`n`n" + $testSource + "`n"
    $requests = @(
        [ordered]@{ op='define'; frontend='flow'; syntaxVersion=2; source=$candidateSource; replace=$true; expectedRevision=1 },
        [ordered]@{ op='test-all' },
        [ordered]@{ op='commit'; word=$word; library=$true },
        [ordered]@{ op='describe'; word=$word }
    )
    $responses = Invoke-Flow "library-limit-probe/$safe" $project 'qualification-attempt' $requests -AllowFailedResponses
    $commitResult = @($responses | Where-Object { $_.kind -in @('commit','error') })[0]
    $description = @($responses | Where-Object { $_.kind -eq 'describe' })[0]
    $limitRecords.Add([ordered]@{ word=$word; commitOk=$commitResult.ok; commitKind=$commitResult.kind; commitCode=$commitResult.error.code; commitText=$commitResult.text; maturityAfterAttempt=$description.data.maturity; unsupported=$description.data.coverage.finiteCoverage.unsupported })
}

$probePath = Join-Path $flow 'controls/library-qualification-probe'
$probeSummary = Get-Content (Join-Path $probePath 'summary.json') -Raw | ConvertFrom-Json
$qualificationEvidence = [ordered]@{
    builderLibraryLimits = $limitRecords.ToArray()
    targetProbe = [ordered]@{
        project = 'controls/library-qualification-probe/project'
        source = 'controls/library-qualification-probe/source.agent'
        callsStartOrCancel = $probeSummary.callsStartOrCancel
        libraryCommit = $probeSummary.initial[2].text
        freshReload = $probeSummary.freshReload[0].text
        targetMaturity = ((Get-Content (Join-Path $probePath 'fresh-reload/responses.jsonl') | ForEach-Object { ConvertFrom-Json -InputObject $_ -AsHashtable -Depth 40 } | Where-Object { $_.kind -eq 'describe' -and $_.data.name -ceq 'rental.billable-days' }).data.maturity)
    }
}
Write-Json (Join-Path $flow 'evidence/qualification-evidence.json') $qualificationEvidence
Write-Json (Join-Path $flow 'evidence/control-tests.json') ([ordered]@{
    correct = [ordered]@{ initial = Test-Summary $correctInitial; freshReload = $correctSummary; maturity = $correctDesc.data.maturity }
    mutantPositivePlusOne = [ordered]@{
        compiledCandidate = [bool]($mutantStaged[0].ok -eq $true)
        initial = $mutantSummary
        committed = $false
        source = 'controls/mutant-positive-plus-one/billable-days.agent'
        replayRequests = 'evidence/controls/mutant-positive-plus-one/stage-mutant.requests.jsonl'
        reason = 'Unchanged correct assertions: the +1 defect fails each positive-count case; it remains an uncommitted candidate.'
    }
})
$controlHashes = [ordered]@{
    correctProject = Project-Manifest $correctProject
    mutantBaselineProject = Project-Manifest $mutantProject
    correctSourceSha256 = (Get-FileHash -LiteralPath $correctPath -Algorithm SHA256).Hash.ToLowerInvariant()
    mutantSourceSha256 = (Get-FileHash -LiteralPath $mutantPath -Algorithm SHA256).Hash.ToLowerInvariant()
    mutantRequestsSha256 = (Get-FileHash -LiteralPath (Join-Path $flow 'evidence/controls/mutant-positive-plus-one/stage-mutant.requests.jsonl') -Algorithm SHA256).Hash.ToLowerInvariant()
    probeProject = Project-Manifest (Join-Path $probePath 'project')
}
Write-Json (Join-Path $flow 'hashes/control-manifest.json') ([ordered]@{
    schemaVersion = 1
    cliSha256 = (Get-FileHash -LiteralPath $cli -Algorithm SHA256).Hash.ToLowerInvariant()
    controls = $controlHashes
})

foreach ($p in $startFingerprintBefore.Keys) {
    $after = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($after -cne $startFingerprintBefore[$p]) { throw "Start fixture changed while controls were prepared: $p" }
}
Write-Output (ConvertTo-Json -InputObject ([ordered]@{
    correctFreshReload = $correctSummary
    correctMaturity = $correctDesc.data.maturity
    mutantCompiled = [bool]($mutantStaged[0].ok -eq $true)
    mutantTests = $mutantSummary
    builderQualification = $limitRecords.ToArray()
    startsFingerprintsUnchanged = $true
    manifest = Join-Path $flow 'hashes/control-manifest.json'
}) -Depth 20)

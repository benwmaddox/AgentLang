#requires -Version 7.5
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$flowRoot = $PSScriptRoot
$reuseRoot = Split-Path -Parent $flowRoot
$repoRoot = Split-Path -Parent (Split-Path -Parent $reuseRoot)
$cliDll = Join-Path $repoRoot '.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
$evidenceRoot = Join-Path $flowRoot 'evidence'
$hashRoot = Join-Path $flowRoot 'hashes'

if (-not (Test-Path -LiteralPath $cliDll -PathType Leaf)) { throw "Frozen CLI not found: $cliDll" }

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path)))
    [IO.File]::WriteAllText($Path, $Text, [Text.UTF8Encoding]::new($false))
}

function Write-Json([string]$Path, [object]$Value) {
    Write-Utf8NoBom $Path (ConvertTo-Json -InputObject $Value -Depth 50)
}

function Write-JsonLines([string]$Path, [object[]]$Values) {
    $lines = @($Values | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 50 -Compress })
    Write-Utf8NoBom $Path (($lines -join "`n") + "`n")
}

function Copy-ProjectWithoutWriteLock([string]$Source, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination) { throw "Refusing to overwrite project: $Destination" }
    [void][IO.Directory]::CreateDirectory($Destination)
    foreach ($item in Get-ChildItem -LiteralPath $Source -Recurse -Force) {
        $relative = [IO.Path]::GetRelativePath($Source, $item.FullName)
        if ($relative -match '(^|[\\/])WRITE\.lock$') { continue }
        $target = Join-Path $Destination $relative
        if ($item.PSIsContainer) {
            [void][IO.Directory]::CreateDirectory($target)
        } else {
            [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
            [IO.File]::Copy($item.FullName, $target, $false)
        }
    }
}

function Get-RequestsForInstall([string]$Source, [string[]]$Words, [string[]]$Types, [string[]]$LibraryWords) {
    $requests = [Collections.Generic.List[object]]::new()
    $requests.Add([ordered]@{ op = 'define'; frontend = 'flow'; syntaxVersion = 2; source = $Source })
    $requests.Add([ordered]@{ op = 'test-all' })
    foreach ($word in $Words) {
        if ($LibraryWords -contains $word) {
            $requests.Add([ordered]@{ op = 'commit'; word = $word; library = $true })
        } else {
            $requests.Add([ordered]@{ op = 'commit'; word = $word })
        }
    }
    $requests.Add([ordered]@{ op = 'test-all' })
    foreach ($word in $Words) {
        $requests.Add([ordered]@{ op = 'describe'; word = $word })
    }
    foreach ($type in $Types) {
        $requests.Add([ordered]@{ op = 'source'; type = $type })
    }
    return ,$requests.ToArray()
}

function Get-ReloadRequests([string[]]$Words, [string[]]$Types) {
    $requests = [Collections.Generic.List[object]]::new()
    $requests.Add([ordered]@{ op = 'test-all' })
    foreach ($word in $Words) {
        $requests.Add([ordered]@{ op = 'describe'; word = $word })
    }
    foreach ($type in $Types) {
        $requests.Add([ordered]@{ op = 'source'; type = $type })
    }
    return ,$requests.ToArray()
}

$commandInventory = [Collections.Generic.List[object]]::new()
function Invoke-FlowRequests([string]$Name, [string]$Project, [string]$Phase, [object[]]$Requests, [switch]$AllowExpectedFailures) {
    $evidence = Join-Path $evidenceRoot $Name
    [void][IO.Directory]::CreateDirectory($evidence)
    [void][IO.Directory]::CreateDirectory($Project)
    $requestPath = Join-Path $evidence "$Phase.requests.jsonl"
    $responsePath = Join-Path $evidence "$Phase.responses.jsonl"
    $stderrPath = Join-Path $evidence "$Phase.stderr.txt"
    $processPath = Join-Path $evidence "$Phase.process.json"
    Write-JsonLines $requestPath $Requests

    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = 'dotnet'
    $start.WorkingDirectory = $Project
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($argument in @($cliDll, '--project', $Project, '--jsonl')) {
        [void]$start.ArgumentList.Add([string]$argument)
    }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    if (-not $process.Start()) { throw "Frozen Flow CLI did not start for $Name/$Phase." }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    foreach ($request in $Requests) {
        $process.StandardInput.WriteLine((ConvertTo-Json -InputObject $request -Depth 50 -Compress))
    }
    $process.StandardInput.Close()
    if (-not $process.WaitForExit(180000)) {
        try { $process.Kill($true) } catch { }
        throw "Frozen Flow CLI timed out for $Name/$Phase."
    }
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    $exitCode = $process.ExitCode
    $process.Dispose()
    Write-Utf8NoBom $responsePath $stdout
    Write-Utf8NoBom $stderrPath $stderr

    $responses = @($stdout -split '\r?\n' | Where-Object { $_ } | ForEach-Object {
        ConvertFrom-Json -InputObject $_ -AsHashtable -Depth 50 -DateKind String
    })
    $command = "dotnet `"$cliDll`" --project `"$Project`" --jsonl"
    Write-Json $processPath ([ordered]@{
        name = $Name
        phase = $Phase
        workingDirectory = $Project
        command = $command
        requestCount = $Requests.Count
        responseCount = $responses.Count
        exitCode = $exitCode
    })
    $commandInventory.Add([ordered]@{
        name = $Name
        phase = $Phase
        project = $Project
        command = $command
        requests = [IO.Path]::GetRelativePath($flowRoot, $requestPath)
        responses = [IO.Path]::GetRelativePath($flowRoot, $responsePath)
        stderr = [IO.Path]::GetRelativePath($flowRoot, $stderrPath)
    })
    if ($exitCode -ne 0 -or $responses.Count -ne $Requests.Count -or ((-not $AllowExpectedFailures) -and @($responses | Where-Object { $_.ok -ne $true }).Count -gt 0)) {
        throw "Flow qualification failed for $Name/$Phase (exit=$exitCode). See $responsePath and $stderrPath."
    }
    return ,$responses
}

function Get-TestSummary([object[]]$Responses) {
    $test = @($Responses | Where-Object { $_.kind -eq 'test' } | Select-Object -Last 1)
    if ($test.Count -eq 0) { return $null }
    $results = @($test[0].data.results)
    return [ordered]@{
        text = $test[0].text
        total = $results.Count
        passed = @($results | Where-Object { $_.passed -eq $true }).Count
        failed = @($results | Where-Object { $_.passed -ne $true }).Count
    }
}

function Get-DescriptionIds([object[]]$Responses, [string[]]$Words) {
    $ids = [ordered]@{}
    foreach ($word in $Words) {
        $description = @($Responses | Where-Object { $_.kind -eq 'describe' -and $_.data.name -ceq $word } | Select-Object -Last 1)
        if ($description.Count -eq 0) { throw "No description response for $word." }
        $ids[$word] = [ordered]@{
            id = $description[0].data.id
            revision = $description[0].data.revision
            documentation = $description[0].data.documentation
            tests = @($description[0].data.tests | Sort-Object)
            source = $description[0].data.source
        }
    }
    return $ids
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-ProjectManifest([string]$Project) {
    $files = [Collections.Generic.List[object]]::new()
    foreach ($file in Get-ChildItem -LiteralPath $Project -Recurse -File -Force) {
        $relative = [IO.Path]::GetRelativePath($Project, $file.FullName)
        if ($relative -match '(^|[\\/])WRITE\.lock$') { continue }
        $files.Add([ordered]@{ path = $relative.Replace('\', '/'); length = $file.Length; sha256 = Get-Sha256 $file.FullName })
    }
    return @($files | Sort-Object path)
}

$baseSourcePath = Join-Path $flowRoot 'starts/flat/source.agent'
$retainedSourcePath = Join-Path $flowRoot 'starts/retained/source.agent'
$intervalPath = Join-Path $repoRoot 'examples/nonempty-interval.agent'
$intervalSource = [IO.File]::ReadAllText($intervalPath)
$lineEnding = "`r`n"
$baseSource = [IO.File]::ReadAllText($baseSourcePath)
$baseSource = [regex]::Replace($baseSource, '[ \t]+(?=\r?$)', '', [Text.RegularExpressions.RegexOptions]::Multiline)
Write-Utf8NoBom $baseSourcePath $baseSource
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($retainedSourcePath))
Write-Utf8NoBom $retainedSourcePath ($baseSource.TrimEnd() + $lineEnding + $lineEnding + $intervalSource.TrimStart())

$flatProject = Join-Path $flowRoot 'starts/flat/project'
$retainedProject = Join-Path $flowRoot 'starts/retained/project'
$baseWords = @('rental.valid?', 'rental.error', 'rental.start', 'rental.cancel')
$baseTypes = @('Rental', 'RentalError')
$flatInitialRequests = Get-RequestsForInstall $baseSource $baseWords $baseTypes @('rental.valid?', 'rental.error')
$flatInitial = Invoke-FlowRequests 'flat' $flatProject 'qualification' $flatInitialRequests
$flatReload = Invoke-FlowRequests 'flat' $flatProject 'fresh-reload' (Get-ReloadRequests $baseWords $baseTypes)

$flatDictionaryPath = Join-Path $flatProject 'dictionary.agent'
$flatDictionaryHash = Get-Sha256 $flatDictionaryPath
Copy-ProjectWithoutWriteLock $flatProject $retainedProject
$retainedInheritedDictionaryPath = Join-Path $retainedProject 'dictionary.agent'
$retainedInheritedDictionaryHash = Get-Sha256 $retainedInheritedDictionaryPath
Write-Json (Join-Path $evidenceRoot 'retained-clone.json') ([ordered]@{
    clonedFrom = [IO.Path]::GetRelativePath($flowRoot, $flatProject)
    clonedTo = [IO.Path]::GetRelativePath($flowRoot, $retainedProject)
    flatDictionarySha256BeforeClone = $flatDictionaryHash
    retainedInheritedDictionarySha256BeforeIntervalAdd = $retainedInheritedDictionaryHash
    dictionaryExactMatchBeforeIntervalAdd = ($flatDictionaryHash -ceq $retainedInheritedDictionaryHash)
    copiedFromCommittedStore = $true
    skipped = '.agentlang/store/WRITE.lock'
})
$intervalWords = @('interval.valid?', 'interval.try-create', 'interval.overlaps?')
$intervalTypes = @('Interval')
$retainedInitialRequests = Get-RequestsForInstall $intervalSource $intervalWords $intervalTypes $intervalWords
$retainedInitial = Invoke-FlowRequests 'retained' $retainedProject 'add-interval' $retainedInitialRequests
$retainedReloadWords = @($baseWords) + @($intervalWords)
$retainedReloadTypes = @($baseTypes) + @($intervalTypes)
$retainedReload = Invoke-FlowRequests 'retained' $retainedProject 'fresh-reload' (Get-ReloadRequests $retainedReloadWords $retainedReloadTypes)

$correctTargetPath = Join-Path $flowRoot 'controls/correct/billable-days.agent'
$mutantTargetPath = Join-Path $flowRoot 'controls/mutant-positive-plus-one/billable-days.agent'
$correctProject = Join-Path $flowRoot 'controls/correct/project'
$mutantProject = Join-Path $flowRoot 'controls/mutant-positive-plus-one/project'
$targetWords = @('rental.billable-days')
Copy-ProjectWithoutWriteLock $retainedProject $correctProject
Copy-ProjectWithoutWriteLock $retainedProject $mutantProject
$correctSource = [IO.File]::ReadAllText($correctTargetPath)
$mutantSource = [IO.File]::ReadAllText($mutantTargetPath)
$correctInitial = Invoke-FlowRequests 'controls/correct' $correctProject 'add-target' (Get-RequestsForInstall $correctSource $targetWords @() $targetWords)
$correctReload = Invoke-FlowRequests 'controls/correct' $correctProject 'fresh-reload' (Get-ReloadRequests (@($baseWords) + @($intervalWords) + @($targetWords)) (@($baseTypes) + @($intervalTypes)))
$mutantRequests = @(
    [ordered]@{ op = 'define'; frontend = 'flow'; syntaxVersion = 2; source = $mutantSource },
    [ordered]@{ op = 'test-all' },
    [ordered]@{ op = 'describe'; word = 'rental.billable-days' }
)
$mutantInitial = Invoke-FlowRequests 'controls/mutant-positive-plus-one' $mutantProject 'stage-mutant' $mutantRequests -AllowExpectedFailures

$flatBaseIds = Get-DescriptionIds $flatReload $baseWords
$retainedBaseIds = Get-DescriptionIds $retainedReload $baseWords
$baseIdsMatch = ((ConvertTo-Json -InputObject $flatBaseIds -Depth 30 -Compress) -ceq (ConvertTo-Json -InputObject $retainedBaseIds -Depth 30 -Compress))
$retainedCombinedSource = [IO.File]::ReadAllText($retainedSourcePath)
$retainedAppendix = $retainedCombinedSource.Substring($retainedCombinedSource.Length - $intervalSource.Length)
$retainedOnlyIntervalAdds = $retainedAppendix -ceq $intervalSource
$baseInvariant = [ordered]@{
    flatIds = $flatBaseIds
    retainedIds = $retainedBaseIds
    flatTests = (Get-TestSummary $flatReload)
    retainedAllTests = (Get-TestSummary $retainedReload)
    baseIdsAndSourcesMatch = $baseIdsMatch
    retainedOnlyIntervalAdds = $retainedOnlyIntervalAdds
    queryAbsentFromFlatStart = [bool](-not (Select-String -LiteralPath (Join-Path $flatProject 'dictionary.agent') -Pattern 'rental\.billable-days' -Quiet) -and -not (Select-String -LiteralPath (Join-Path $flowRoot 'starts/flat/source.agent') -Pattern 'rental\.billable-days' -Quiet))
    queryAbsentFromRetainedStart = [bool](-not (Select-String -LiteralPath (Join-Path $retainedProject 'dictionary.agent') -Pattern 'rental\.billable-days' -Quiet) -and -not (Select-String -LiteralPath $retainedSourcePath -Pattern 'rental\.billable-days' -Quiet))
}
Write-Json (Join-Path $evidenceRoot 'base-invariance.json') $baseInvariant
Write-Json (Join-Path $evidenceRoot 'control-tests.json') ([ordered]@{
    correct = [ordered]@{ initial = Get-TestSummary $correctInitial; freshReload = Get-TestSummary $correctReload }
    mutantPositivePlusOne = [ordered]@{
        compiledCandidate = [bool]($mutantInitial[0].ok -eq $true -and $mutantInitial[0].kind -eq 'defined')
        tests = Get-TestSummary $mutantInitial
        committed = $false
        reason = 'Correct assertions are preserved; the +1 mutation fails positive-count cases and stays staged as a control candidate.'
    }
})
Write-Json (Join-Path $evidenceRoot 'commands.json') ([ordered]@{
    cli = $cliDll
    invocation = 'dotnet <frozen AgentLang.Cli.dll> --project PATH --jsonl'
    frontend = 'flow'
    syntaxVersion = 2
    projectQualificationProtocol = 'define, test-all, commit library, test-all, describe/source; repeat tests and descriptors in a fresh CLI process.'
    writeLockPolicy = 'Project clones skip .agentlang/store/WRITE.lock.'
    commands = $commandInventory.ToArray()
})

$inputHashes = [Collections.Generic.List[object]]::new()
foreach ($path in @(
    $baseSourcePath,
    $retainedSourcePath,
    $intervalPath,
    $correctTargetPath,
    $mutantTargetPath,
    (Join-Path $reuseRoot 'plan.md'),
    $cliDll
)) {
    $inputHashes.Add([ordered]@{
        path = [IO.Path]::GetRelativePath($repoRoot, $path).Replace('\', '/')
        length = (Get-Item -LiteralPath $path).Length
        sha256 = Get-Sha256 $path
    })
}
$projectHashes = [ordered]@{
    flat = Get-ProjectManifest $flatProject
    retained = Get-ProjectManifest $retainedProject
    correctControl = Get-ProjectManifest $correctProject
    mutantControl = Get-ProjectManifest $mutantProject
}
Write-Json (Join-Path $hashRoot 'input-manifest.json') ([ordered]@{
    schemaVersion = 1
    cliSha256 = Get-Sha256 $cliDll
    inputs = $inputHashes.ToArray()
})
Write-Json (Join-Path $hashRoot 'project-manifest.json') ([ordered]@{
    schemaVersion = 1
    baseFunctionIdsAndSourcesMatch = $baseIdsMatch
    retainedOnlyIntervalAdds = $retainedOnlyIntervalAdds
    inheritedDictionaryHashMatch = ($flatDictionaryHash -ceq $retainedInheritedDictionaryHash)
    projects = $projectHashes
})

if ($baseInvariant.queryAbsentFromFlatStart -ne $true -or $baseInvariant.queryAbsentFromRetainedStart -ne $true) {
    throw 'A start fixture unexpectedly contains the target query.'
}
if (-not $baseIdsMatch -or -not $retainedOnlyIntervalAdds -or $flatDictionaryHash -cne $retainedInheritedDictionaryHash) {
    throw 'The retained project changed inherited base source, IDs, or appended material beyond the interval example.'
}
if ($baseInvariant.flatTests.passed -ne $baseInvariant.flatTests.total -or $baseInvariant.retainedAllTests.passed -ne $baseInvariant.retainedAllTests.total) {
    throw 'A fresh start reload did not pass all attached tests.'
}
if ((Get-TestSummary $correctReload).failed -ne 0) {
    throw 'The correct target control did not pass its attached tests.'
}
if ($mutantInitial[0].ok -ne $true -or (Get-TestSummary $mutantInitial).failed -ne 3) {
    throw 'The staged +1 mutant did not compile with exactly three expected positive-count test failures.'
}

Write-Output (ConvertTo-Json -InputObject ([ordered]@{
    flatTests = Get-TestSummary $flatReload
    retainedTests = Get-TestSummary $retainedReload
    correctControlTests = Get-TestSummary $correctReload
    mutantControlTests = Get-TestSummary $mutantInitial
    mutantCompiledButNotCommitted = [bool]($mutantInitial[0].ok -eq $true -and (Get-TestSummary $mutantInitial).failed -eq 3)
    baseIdsAndSourcesMatch = $baseIdsMatch
    inputManifest = Join-Path $hashRoot 'input-manifest.json'
    projectManifest = Join-Path $hashRoot 'project-manifest.json'
}) -Depth 20)

from pathlib import Path
import hashlib, json
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OUT=ROOT/'freeze.json'
if OUT.exists(): raise SystemExit('Refusing to overwrite freeze')
summary=json.loads((ROOT/'participants/summary.json').read_text(encoding='utf-8'))
files={ROOT/'task-draft.md',ROOT/'prepare-participants.py',Path(__file__).resolve(),ROOT/'oracle/cases.json',ROOT/'oracle/score.py',ROOT/'oracle/fsharp/Program.fs',REPO/'scripts/Start-SubagentTrialHostV2.ps1',ROOT/'participants/summary.json'}
for row in summary['participants']:
    for key in ['promptPath','wrapperPath','startInventoryPath']: files.add(Path(row[key]))
    inv=json.loads(Path(row['startInventoryPath']).read_text(encoding='utf-8'))
    for entry in inv['files']:
        path=Path(row['projectPath'])/entry['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256'],path
        files.add(path)
for directory in [REPO/'.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release',REPO/'.agentlang/subscription-overlap-143/conventional-artifacts/bin/AgentLang.Conventional.Cli/release']:
    files.update(path for path in directory.rglob('*') if path.is_file())
rows=[]
for path in sorted(files):
    rows.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
OUT.write_text(json.dumps({'frozenUtc':datetime.now(timezone.utc).isoformat(),'status':'frozen-before-dispatch','files':rows},indent=2)+'\n',encoding='utf-8')
print('Frozen',len(rows),'inputs:',OUT)

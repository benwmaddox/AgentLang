$ErrorActionPreference = 'Stop'

$fsharpRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..\..')).Path
$fsharpPrefix = $fsharpRoot.TrimEnd('\') + '\'

function Assert-FsharpPath([string] $Path) {
    $resolved = [System.IO.Path]::GetFullPath($Path)
    if (-not $resolved.StartsWith($fsharpPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to operate outside the F# fixture subtree: $resolved"
    }
    return $resolved
}

function Write-Text([string] $Path, [string] $Text) {
    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function Invoke-LoggedCommand([string] $Name, [string] $WorkingDirectory, [string] $CommandText, [string[]] $Arguments, [int] $ExpectedExit) {
    $commandPath = Join-Path $PSScriptRoot "$Name.command.txt"
    $stdoutPath = Join-Path $PSScriptRoot "$Name.stdout.txt"
    $stderrPath = Join-Path $PSScriptRoot "$Name.stderr.txt"
    $exitPath = Join-Path $PSScriptRoot "$Name.exit.txt"

    Write-Text $commandPath "$CommandText`n"
    Push-Location $WorkingDirectory
    try {
        & dotnet @Arguments 1> $stdoutPath 2> $stderrPath
        $actualExit = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    Write-Text $exitPath "$actualExit`n"
    Write-Host "$Name exit=$actualExit expected=$ExpectedExit"
    if ($actualExit -ne $ExpectedExit) {
        throw "$Name returned $actualExit; expected $ExpectedExit. See the saved stdout and stderr."
    }
}

function Reset-FixtureOutputs([string] $ProjectDirectory, [string] $TestsDirectory) {
    foreach ($directory in @($ProjectDirectory, $TestsDirectory)) {
        $resolvedDirectory = Assert-FsharpPath $directory
        foreach ($outputName in @('bin', 'obj')) {
            $outputPath = Assert-FsharpPath (Join-Path $resolvedDirectory $outputName)
            if (Test-Path -LiteralPath $outputPath) {
                Remove-Item -LiteralPath $outputPath -Recurse -Force
            }
        }
    }
}

$fixtures = @(
    @{ Name = 'flat'; RelativeRoot = 'flat'; Project = 'project\RentalDomain.fsproj'; Tests = 'tests\RentalDomain.Tests.fsproj'; TestCommand = 'dotnet run --project .agentlang/reuse-145/fsharp/flat/tests/RentalDomain.Tests.fsproj --configuration Release --no-build --no-restore'; TestArgs = @('run', '--project', '.agentlang/reuse-145/fsharp/flat/tests/RentalDomain.Tests.fsproj', '--configuration', 'Release', '--no-build', '--no-restore'); ExpectedTestExit = 0 },
    @{ Name = 'retained'; RelativeRoot = 'retained'; Project = 'project\RentalDomain.fsproj'; Tests = 'tests\RentalDomain.Tests.fsproj'; TestCommand = 'dotnet run --project .agentlang/reuse-145/fsharp/retained/tests/RentalDomain.Tests.fsproj --configuration Release --no-build --no-restore'; TestArgs = @('run', '--project', '.agentlang/reuse-145/fsharp/retained/tests/RentalDomain.Tests.fsproj', '--configuration', 'Release', '--no-build', '--no-restore'); ExpectedTestExit = 0 },
    @{ Name = 'positive-control'; RelativeRoot = 'controls\positive'; Project = 'project\RentalDomain.fsproj'; Tests = 'tests\RentalDomain.ControlTests.fsproj'; TestCommand = 'dotnet run --project .agentlang/reuse-145/fsharp/controls/positive/tests/RentalDomain.ControlTests.fsproj --configuration Release --no-build --no-restore'; TestArgs = @('run', '--project', '.agentlang/reuse-145/fsharp/controls/positive/tests/RentalDomain.ControlTests.fsproj', '--configuration', 'Release', '--no-build', '--no-restore'); ExpectedTestExit = 0 },
    @{ Name = 'negative-control'; RelativeRoot = 'controls\negative-count-plus-one'; Project = 'project\RentalDomain.fsproj'; Tests = 'tests\RentalDomain.ControlTests.fsproj'; TestCommand = 'dotnet run --project .agentlang/reuse-145/fsharp/controls/negative-count-plus-one/tests/RentalDomain.ControlTests.fsproj --configuration Release --no-build --no-restore'; TestArgs = @('run', '--project', '.agentlang/reuse-145/fsharp/controls/negative-count-plus-one/tests/RentalDomain.ControlTests.fsproj', '--configuration', 'Release', '--no-build', '--no-restore'); ExpectedTestExit = 1 }
)

foreach ($fixture in $fixtures) {
    $fixtureRoot = Assert-FsharpPath (Join-Path $fsharpRoot $fixture.RelativeRoot)
    $projectDirectory = Join-Path $fixtureRoot 'project'
    $testsDirectory = Join-Path $fixtureRoot 'tests'
    $projectPath = Join-Path $fixtureRoot $fixture.Project
    $testsPath = Join-Path $fixtureRoot $fixture.Tests
    Reset-FixtureOutputs $projectDirectory $testsDirectory

    $projectRelative = [System.IO.Path]::GetRelativePath($repoRoot, $projectPath).Replace('\', '/')
    $testsRelative = [System.IO.Path]::GetRelativePath($repoRoot, $testsPath).Replace('\', '/')
    $buildName = "$($fixture.Name).build"
    Invoke-LoggedCommand -Name $buildName -WorkingDirectory $repoRoot -CommandText "dotnet build $projectRelative --configuration Release" -Arguments @('build', $projectRelative, '--configuration', 'Release') -ExpectedExit 0
    Invoke-LoggedCommand -Name "$($fixture.Name).build-tests" -WorkingDirectory $repoRoot -CommandText "dotnet build $testsRelative --configuration Release" -Arguments @('build', $testsRelative, '--configuration', 'Release') -ExpectedExit 0
    Invoke-LoggedCommand -Name "$($fixture.Name).run-tests" -WorkingDirectory $repoRoot -CommandText $fixture.TestCommand -Arguments $fixture.TestArgs -ExpectedExit $fixture.ExpectedTestExit
}

foreach ($fixture in $fixtures) {
    $fixtureRoot = Assert-FsharpPath (Join-Path $fsharpRoot $fixture.RelativeRoot)
    Reset-FixtureOutputs (Join-Path $fixtureRoot 'project') (Join-Path $fixtureRoot 'tests')
}

$hashLines = foreach ($file in Get-ChildItem -LiteralPath $fsharpRoot -Recurse -File | Where-Object {
    $isFixtureSource = $_.Extension -in @('.fs', '.fsproj', '.md')
    $isValidationScript = $_.FullName -eq (Join-Path $PSScriptRoot 'Validate-FSharpFixtures.ps1')
    $isBuildOutput = $_.FullName -match '[\\/](bin|obj)[\\/]'
    -not $isBuildOutput -and ($isFixtureSource -or $isValidationScript)
} | Sort-Object FullName) {
    $relative = [System.IO.Path]::GetRelativePath($fsharpRoot, $file.FullName).Replace('\', '/')
    $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $relative"
}
Write-Text (Join-Path $PSScriptRoot 'hashes.sha256.txt') (($hashLines -join "`n") + "`n")
Write-Host "Wrote F# source hashes for $($hashLines.Count) files."

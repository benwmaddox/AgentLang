module DomainBaselineTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failwithf "%s expected an error" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid start failed: %s" error.Code

    check "start getter" 2L (Rental.startDay original)
    check "finish getter" 8L (Rental.finishDay original)
    check "initial cancellation" None (Rental.cancelledDay original)

    expectError "negative start" "INVALID_RENTAL_SPAN" (Rental.start -1L 8L)
    expectError "empty start span" "INVALID_RENTAL_SPAN" (Rental.start 2L 2L)
    expectError "reversed start span" "INVALID_RENTAL_SPAN" (Rental.start 8L 2L)
    expectError "finish above limit" "INVALID_RENTAL_SPAN" (Rental.start 2L 367L)
    expectError "start above limit" "INVALID_RENTAL_SPAN" (Rental.start 366L 367L)

    match Rental.start 0L 366L with
    | Ok rental ->
        check "lower service bound" 0L (Rental.startDay rental)
        check "upper service bound" 366L (Rental.finishDay rental)
    | Error error -> failwithf "valid service bounds failed: %s" error.Code

    match Rental.cancel original 1L with
    | Error error -> check "cancel before start" "CANCELLATION_BEFORE_START" error.Code
    | Ok _ -> failwith "cancellation before start unexpectedly succeeded"

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "cancel at start" (Some 2L) (Rental.cancelledDay cancelledAtStart)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "cancel after finish" (Some 9L) (Rental.cancelledDay cancelledAfterFinish)

    let firstCancellation =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "first cancellation failed: %s" error.Code
    let replacement =
        match Rental.cancel firstCancellation 6L with
        | Ok rental -> rental
        | Error error -> failwithf "replacement cancellation failed: %s" error.Code
    check "replacement stored" (Some 6L) (Rental.cancelledDay replacement)
    check "intermediate value retained" (Some 4L) (Rental.cancelledDay firstCancellation)
    check "source value unchanged" None (Rental.cancelledDay original)

    checks

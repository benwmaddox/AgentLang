open System
open RentalDomain

let failures = ResizeArray<string>()
let mutable checks = 0

let check name expected actual =
    checks <- checks + 1
    if expected <> actual then
        failures.Add(sprintf "%s expected %A, received %A" name expected actual)

let requireRental name result =
    match result with
    | Ok rental -> rental
    | Error error -> failwithf "%s failed: %s" name error.Code

let checkCount name expected result =
    checks <- checks + 1
    match result with
    | Ok actual when actual = expected -> ()
    | Ok actual -> failures.Add(sprintf "%s expected count %d, received %d" name expected actual)
    | Error error -> failures.Add(sprintf "%s unexpectedly failed: %s" name error.Code)

let checkError name expectedCode result =
    checks <- checks + 1
    match result with
    | Error error when error.Code = expectedCode -> ()
    | Error error -> failures.Add(sprintf "%s expected error %s, received %s" name expectedCode error.Code)
    | Ok count -> failures.Add(sprintf "%s expected error %s, received count %d" name expectedCode count)

let snapshot rental =
    Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental

[<EntryPoint>]
let main _ =
    let rental = Rental.start 2L 8L |> requireRental "rental start"
    let cancelledAtFive = Rental.cancel rental 5L |> requireRental "cancellation at day five"
    let cancelledAtStart = Rental.cancel rental 2L |> requireRental "cancellation at start"
    let cancelledAfterFinish = Rental.cancel rental 9L |> requireRental "cancellation after finish"
    let beforeRental = snapshot rental
    let beforeFive = snapshot cancelledAtFive
    let beforeStart = snapshot cancelledAtStart
    let beforeAfterFinish = snapshot cancelledAfterFinish

    checkCount "adjacent window" 0L (Rental.billableDays rental 8L 10L)
    checkCount "cancellation at start is empty occupancy" 0L (Rental.billableDays cancelledAtStart 1L 4L)
    checkError "equal request endpoints" "INVALID_BILLING_WINDOW" (Rental.billableDays rental 4L 4L)
    checkError "reversed request endpoints" "INVALID_BILLING_WINDOW" (Rental.billableDays rental 5L 4L)
    check "rental fields preserved" beforeRental (snapshot rental)
    check "cancelled rental fields preserved" beforeFive (snapshot cancelledAtFive)
    check "start-cancelled fields preserved" beforeStart (snapshot cancelledAtStart)
    check "after-finish cancellation fields preserved" beforeAfterFinish (snapshot cancelledAfterFinish)

    checkCount "partial overlap" 3L (Rental.billableDays rental 5L 10L)
    checkCount "cancellation clips occupancy" 2L (Rental.billableDays cancelledAtFive 3L 8L)
    checkCount "cancellation after finish keeps original finish" 6L (Rental.billableDays cancelledAfterFinish 2L 8L)
    checkCount "wide request remains bounded before subtraction" 6L (Rental.billableDays rental Int64.MinValue Int64.MaxValue)

    if failures.Count = 0 then
        printfn "PASS %d negative control checks (unexpected)" checks
        0
    else
        for failure in failures do
            eprintfn "FAIL %s" failure
        eprintfn "EXPECTED NEGATIVE CONTROL FAILURE: %d of %d checks failed" failures.Count checks
        1

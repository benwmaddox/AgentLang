namespace RentalDomain

type RentalError = {
    Code: string
    Message: string
}

module Rental =
    /// An opaque rental value. Only the validated operations in this module can create one.
    type T = private {
        StartDay: int64
        FinishDay: int64
        CancelledDay: int64 option
    }

    /// Creates a nonempty rental span within the supported service-day bounds.
    let start (startDay: int64) (finishDay: int64) : Result<T, RentalError> =
        if startDay < 0L || startDay >= finishDay || finishDay > 366L then
            Error { Code = "INVALID_RENTAL_SPAN"; Message = "Rental days must satisfy 0 <= start < finish <= 366." }
        else
            Ok { StartDay = startDay; FinishDay = finishDay; CancelledDay = None }

    /// Stores or replaces a cancellation day. Cancellation at start is valid.
    let cancel (rental: T) (day: int64) : Result<T, RentalError> =
        if day < rental.StartDay then
            Error { Code = "CANCELLATION_BEFORE_START"; Message = "Cancellation cannot precede the rental start day." }
        else
            Ok { rental with CancelledDay = Some day }

    /// Returns the first occupied service day.
    let startDay (rental: T) = rental.StartDay

    /// Returns the exclusive end of the original service span.
    let finishDay (rental: T) = rental.FinishDay

    /// Returns the stored cancellation day, if one has been set.
    let cancelledDay (rental: T) = rental.CancelledDay

    /// Counts occupied rental days inside a valid half-open request window.
    let billableDays (rental: T) (fromDay: int64) (untilDay: int64) : Result<int64, RentalError> =
        if fromDay >= untilDay then
            Error { Code = "INVALID_BILLING_WINDOW"; Message = "Billing window must have start before finish." }
        else
            let effectiveEnd =
                match rental.CancelledDay with
                | Some cancelled when cancelled < rental.FinishDay -> cancelled
                | _ -> rental.FinishDay

            match Interval.tryCreate rental.StartDay effectiveEnd, Interval.tryCreate fromDay untilDay with
            | None, _ -> Ok 0L
            | Some occupied, Some requested when Interval.overlaps occupied requested ->
                let boundedStart = max (Interval.start occupied) (Interval.start requested)
                let boundedFinish = min (Interval.finish occupied) (Interval.finish requested)
                Ok (boundedFinish - boundedStart)
            | _ -> Ok 0L

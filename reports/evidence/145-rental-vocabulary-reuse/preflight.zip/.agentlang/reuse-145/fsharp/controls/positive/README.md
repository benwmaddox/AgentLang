# F# positive control

This isolated coordinator implementation starts from the retained F# fixture and adds `Rental.billableDays`. It rejects invalid request windows, validates half-open spans through the retained interval API, bounds the intersection to the rental before subtracting endpoints, and returns zero for cancellation at the rental start.

The control tests cover the shared contract, cancellation-at-start state created through `Rental.cancel`, unchanged rental fields, invalid windows, and signed 64-bit request bounds. This implementation is separate from both participant starts.

# F# count-plus-one negative control

This is a separate compiled copy of the positive control with one deliberate defect: it adds one to each positive billable-day count while leaving zero counts and errors unchanged. Its build must succeed and its control test executable must fail on positive-count assertions while confirming the zero, error, and state-preservation assertions.

namespace Reuse145RentalOracle

open System
open System.Globalization
open System.Text.Json
open RentalDomain

module Program =
    type private CaseAcceptance = {
        CaseId: string
        Expected: string
        Actual: string
        InputUnchanged: bool
        Passed: bool
    }

    let private text (element: JsonElement) (name: string) = element.GetProperty(name).GetString()
    let private integer (element: JsonElement) (name: string) = element.GetProperty(name).GetInt64()

    let private cancelledDay (element: JsonElement) =
        let value = element.GetProperty("cancel")
        if value.ValueKind = JsonValueKind.Null then None else Some(value.GetInt64())

    let private expectedOutcome (element: JsonElement) =
        let fromDay = integer element "from"
        let untilDay = integer element "until"
        if fromDay >= untilDay then
            "error:INVALID_BILLING_WINDOW"
        else
            let startDay = integer element "start"
            let finishDay = integer element "finish"
            let cancellation = cancelledDay element
            let count =
                seq { startDay .. finishDay - 1L }
                |> Seq.filter (fun day ->
                    day >= fromDay
                    && day < untilDay
                    && (match cancellation with
                        | None -> true
                        | Some cancelled -> day < cancelled))
                |> Seq.length
            "ok:" + (int64 count).ToString(CultureInfo.InvariantCulture)

    let private createRental (element: JsonElement) =
        match Rental.start (integer element "start") (integer element "finish") with
        | Error error -> Error("start:" + error.Code)
        | Ok rental ->
            match cancelledDay element with
            | None -> Ok rental
            | Some day ->
                match Rental.cancel rental day with
                | Error error -> Error("cancel:" + error.Code)
                | Ok updated -> Ok updated

    let private fields rental =
        Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental

    let private runCase (element: JsonElement) =
        let expected = expectedOutcome element
        match createRental element with
        | Error setupError -> {
            CaseId = text element "id"
            Expected = expected
            Actual = "fixture-setup-error:" + setupError
            InputUnchanged = false
            Passed = false
          }
        | Ok rental ->
            let before = fields rental
            let result =
                Rental.billableDays rental (integer element "from") (integer element "until")
            let after = fields rental
            let actual =
                match result with
                | Ok count -> "ok:" + count.ToString(CultureInfo.InvariantCulture)
                | Error error -> "error:" + error.Code
            let unchanged = before = after
            {
                CaseId = text element "id"
                Expected = expected
                Actual = actual
                InputUnchanged = unchanged
                Passed = actual = expected && unchanged
            }

    [<EntryPoint>]
    let main argv =
        if argv.Length <> 1 then
            eprintfn "Usage: oracle <cases.json>"
            2
        else
            use document = JsonDocument.Parse(IO.File.ReadAllText(argv[0]))
            let cases =
                document.RootElement.GetProperty("cases").EnumerateArray()
                |> Seq.map runCase
                |> Seq.toList
            let result = {|
                schemaVersion = 1
                arm = "fsharp"
                passed = cases |> List.forall (fun item -> item.Passed)
                cases = cases |> List.map (fun item -> {| caseId = item.CaseId; expected = item.Expected; actual = item.Actual; inputUnchanged = item.InputUnchanged; passed = item.Passed |})
            |}
            Console.WriteLine(JsonSerializer.Serialize(result))
            if result.passed then 0 else 1

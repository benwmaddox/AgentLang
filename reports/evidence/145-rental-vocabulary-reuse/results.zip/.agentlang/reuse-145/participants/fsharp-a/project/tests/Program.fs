open DomainBaselineTests

[<EntryPoint>]
let main _ =
    let checks = run ()
    printfn "PASS %d baseline checks" checks
    0

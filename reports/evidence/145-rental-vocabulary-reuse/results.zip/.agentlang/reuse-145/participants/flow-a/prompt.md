You are a fresh, independent participant. The human authorizes changes only to this assigned isolated project and its local tests. Use only the supplied broker for project discovery, authoring, evaluation, and testing. Your only permitted raw filesystem operation is reading this assigned prompt to verify its supplied SHA-256 before starting the broker. After that check, use the broker exclusively for project work. Do not read or edit files outside the assigned prompt and project. Do not use web tools or delegate work. Launch the specified broker once and keep using that process session.

Run the launch command from `D:\code\AgentLang` using `exec_command` with `tty:true` and `yield_time_ms:10000`. Send one newline-terminated JSON request at a time and inspect its response before the next mutation. The broker allows at most 100 exchanges, each with a 120000 ms timeout. On a timeout, poll the same process session; do not restart the broker.

Exact launch command:

```powershell
pwsh -NoProfile -File 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\library-closure-142\root-cli-artifacts\bin\AgentLang.Cli\release\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\reuse-145\participants\flow-a\project' -TracePath 'D:\code\AgentLang\.agentlang\reuse-145\participants\flow-a\actor.trace.jsonl' -AllowedOperations 'task.begin,task.status,task.log,task.commit,task.abort,words,search,describe,type-of,search-type,search-output,search-effect,search-dependency,source,dependencies,callers,transitive-dependencies,transitive-callers,graph,context,effects,ir,tests,examples,example,history,diff,stack,help,eval,define,test,test-all,failed-tests,commit,replace-word,discard' -Profile agentlang -ClockValue '2000-01-01T00:00:00Z' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

Begin with `task.begin` and inspect its response. Use broker introspection and attached examples as needed. Before authoring, request and inspect both `{"op":"help","topic":"define","syntaxVersion":2}` and `{"op":"help","topic":"examples","syntaxVersion":2}`; do not add a `frontend` field to either `help` request. Include `"frontend":"flow"` and `"syntaxVersion":2` on `define` and `eval` requests. Run `test-all`; qualify and commit changed or new library words through the broker's supported library commit operation. Finish with `{"op":"task.commit"}`, observe the result, then send `{"op":"host.close"}` and wait for normal process exit.

# Task

Add a pure query that counts the chargeable integer days of one equipment rental
within a requested half-open billing window.

Required API:
- AgentLang: rental.billable-days(rental: Rental, from-day: Int, until-day: Int) -> Result<Int, RentalError>.
- F#: RentalDomain.Rental.billableDays : Rental.T -> int64 -> int64 -> Result<int64, RentalError>.

A valid stored rental has 0 <= start-day < finish-day <= 366. Its optional
cancellation day is at or after start-day and may be later than finish-day.
Without cancellation it occupies [start-day, finish-day). With cancellation it
occupies [start-day, min(finish-day, cancellation-day)). Cancellation at its start
therefore leaves no occupied days. Existing start/cancel operations construct
valid rentals; preserve their behavior and validation.

First reject a request with from-day >= until-day using RentalError code
INVALID_BILLING_WINDOW, even when the rental has no occupied days. Otherwise
return the number of integer days d for which from-day <= d < until-day and the
rental occupies d. Request bounds may be any signed 64-bit integers; the answer
is bounded by the rental's at most 366 occupied days. Do not overflow by measuring
the entire requested window. Adjacency contributes zero days. Error text should
explain the invalid window; exact wording is not an acceptance requirement.

Preserve all input rental fields and existing project behavior. Inspect the
available APIs and documentation. You may add helpers and types where useful;
no particular private helper or algorithm is required. Add effective tests,
retain all inherited tests and public APIs, and run the complete project suite.
In AgentLang, qualify and publish the query and any authored dependencies as
libraries without demoting existing library functions. Finish the normal task
and broker workflow. F# uses its existing compiler and test workflow.

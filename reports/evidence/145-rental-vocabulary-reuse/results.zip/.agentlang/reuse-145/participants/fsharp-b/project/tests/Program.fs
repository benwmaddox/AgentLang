open DomainBaselineTests

[<EntryPoint>]
let main _ =
    let domainChecks = run ()
    let intervalChecks = IntervalTests.run ()
    printfn "PASS %d baseline checks and %d retained interval checks" domainChecks intervalChecks
    0

# F# rental billing fixture

The baseline exposes an immutable rental created with `Rental.start` and updated by `Rental.cancel`. A rental occupies integer service days in the half-open span `[startDay, finishDay)`. Cancellation stores an optional day at or after the rental start; cancelling at the start is valid, and a later cancellation replaces the previous day.

Implement the pure query `Rental.billableDays : Rental.T -> int64 -> int64 -> Result<int64, RentalError>`. It accepts a requested half-open billing window `[fromDay, untilDay)`, returns `INVALID_BILLING_WINDOW` when `fromDay >= untilDay`, and otherwise returns the number of occupied rental days in the intersection. Occupancy ends at the earlier of cancellation and finish. A cancellation at the rental start therefore returns zero for every valid billing window. The query must preserve the rental's fields on success and error.

Rental service bounds are `0 <= startDay < finishDay <= 366`. Request bounds are signed 64-bit integers and may be outside the service range. The shared baseline tests cover rental construction, cancellation, replacement, and immutability; billing tests cover overlap, cancellation cutoffs, invalid windows, adjacency, and extreme request bounds.

module IntervalTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    check "equal endpoints rejected" None (Interval.tryCreate 3L 3L)
    check "reversed endpoints rejected" None (Interval.tryCreate 4L 3L)

    let left = Interval.tryCreate 2L 8L |> Option.get
    let overlapping = Interval.tryCreate 5L 10L |> Option.get
    let adjacent = Interval.tryCreate 8L 10L |> Option.get
    check "start endpoint getter" 2L (Interval.start left)
    check "finish endpoint getter" 8L (Interval.finish left)
    check "overlap detected" true (Interval.overlaps left overlapping)
    check "adjacency is not overlap" false (Interval.overlaps left adjacent)
    check "overlap is symmetric" (Interval.overlaps overlapping left) (Interval.overlaps left overlapping)

    checks

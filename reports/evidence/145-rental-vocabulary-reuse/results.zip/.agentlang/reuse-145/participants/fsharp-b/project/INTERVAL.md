# Retained interval vocabulary

This start carries the report-144 F# interval contract. `Interval.tryCreate` constructs an opaque interval only when `start < finish`; `Interval.overlaps` uses strict half-open overlap, so intervals that only touch do not overlap. `Interval.start` and `Interval.finish` expose read-only endpoints, matching the fields on the AgentLang `Interval` record. There is no intersection or counting helper.

`Interval.T` is immutable and cannot be directly constructed outside its module. The additional interval tests exercise strict construction, endpoint reads, overlap, and adjacency. The rental billing task and baseline tests are otherwise the same as the flat start.

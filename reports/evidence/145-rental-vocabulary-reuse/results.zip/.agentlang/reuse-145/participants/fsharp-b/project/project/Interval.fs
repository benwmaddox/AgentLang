namespace RentalDomain

/// Validated immutable half-open interval vocabulary retained from report 144.
module Interval =
    type T = private {
        StartDay: int64
        FinishDay: int64
    }

    /// Constructs an interval only when its start is strictly before its finish.
    let tryCreate (startDay: int64) (finishDay: int64) : T option =
        if startDay < finishDay then
            Some { StartDay = startDay; FinishDay = finishDay }
        else
            None

    /// Returns true only when two half-open intervals share at least one point.
    let overlaps (left: T) (right: T) =
        left.StartDay < right.FinishDay && right.StartDay < left.FinishDay

    /// Returns the interval's inclusive starting endpoint.
    let start (interval: T) = interval.StartDay

    /// Returns the interval's exclusive ending endpoint.
    let finish (interval: T) = interval.FinishDay

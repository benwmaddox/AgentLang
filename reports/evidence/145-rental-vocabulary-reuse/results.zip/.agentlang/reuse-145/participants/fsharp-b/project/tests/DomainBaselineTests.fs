module DomainBaselineTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failwithf "%s expected an error" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid start failed: %s" error.Code

    check "start getter" 2L (Rental.startDay original)
    check "finish getter" 8L (Rental.finishDay original)
    check "initial cancellation" None (Rental.cancelledDay original)

    expectError "negative start" "INVALID_RENTAL_SPAN" (Rental.start -1L 8L)
    expectError "empty start span" "INVALID_RENTAL_SPAN" (Rental.start 2L 2L)
    expectError "reversed start span" "INVALID_RENTAL_SPAN" (Rental.start 8L 2L)
    expectError "finish above limit" "INVALID_RENTAL_SPAN" (Rental.start 2L 367L)
    expectError "start above limit" "INVALID_RENTAL_SPAN" (Rental.start 366L 367L)

    match Rental.start 0L 366L with
    | Ok rental ->
        check "lower service bound" 0L (Rental.startDay rental)
        check "upper service bound" 366L (Rental.finishDay rental)
    | Error error -> failwithf "valid service bounds failed: %s" error.Code

    match Rental.cancel original 1L with
    | Error error -> check "cancel before start" "CANCELLATION_BEFORE_START" error.Code
    | Ok _ -> failwith "cancellation before start unexpectedly succeeded"

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "cancel at start" (Some 2L) (Rental.cancelledDay cancelledAtStart)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "cancel after finish" (Some 9L) (Rental.cancelledDay cancelledAfterFinish)

    let firstCancellation =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "first cancellation failed: %s" error.Code
    let replacement =
        match Rental.cancel firstCancellation 6L with
        | Ok rental -> rental
        | Error error -> failwithf "replacement cancellation failed: %s" error.Code
    check "replacement stored" (Some 6L) (Rental.cancelledDay replacement)
    check "intermediate value retained" (Some 4L) (Rental.cancelledDay firstCancellation)
    check "source value unchanged" None (Rental.cancelledDay original)

    let checkBillingError name result =
        match result with
        | Error error ->
            check (name + " code") "INVALID_BILLING_WINDOW" error.Code
            check (name + " message") true (error.Message.Contains("window", System.StringComparison.OrdinalIgnoreCase))
        | Ok value -> failwithf "%s expected an error, received %A" name value

    check "whole rental overlap" (Ok 6L) (Rental.billableDays original 0L 10L)
    check "window inside rental" (Ok 2L) (Rental.billableDays original 4L 6L)
    check "window clips rental start" (Ok 4L) (Rental.billableDays original 0L 6L)
    check "adjacent before rental" (Ok 0L) (Rental.billableDays original 0L 2L)
    check "adjacent after rental" (Ok 0L) (Rental.billableDays original 8L 10L)
    check "window outside service range" (Ok 3L) (Rental.billableDays original System.Int64.MinValue 5L)
    check "extreme window avoids overflow" (Ok 6L) (Rental.billableDays original System.Int64.MinValue System.Int64.MaxValue)

    checkBillingError "empty billing window" (Rental.billableDays original 4L 4L)
    checkBillingError "reversed billing window" (Rental.billableDays original 5L 4L)

    let cancelledMidRental =
        match Rental.cancel original 5L with
        | Ok rental -> rental
        | Error error -> failwithf "valid billing-test cancellation failed: %s" error.Code
    check "cancellation truncates occupancy" (Ok 3L) (Rental.billableDays cancelledMidRental 0L 10L)
    check "cancellation boundary is exclusive" (Ok 1L) (Rental.billableDays cancelledMidRental 4L 8L)

    check "cancellation after finish leaves span" (Ok 6L) (Rental.billableDays cancelledAfterFinish 0L 10L)
    check "cancellation at start has no occupied days" (Ok 0L) (Rental.billableDays cancelledAtStart 0L 10L)
    checkBillingError "invalid window is rejected for empty occupancy" (Rental.billableDays cancelledAtStart 3L 3L)

    check "query preserves start day" 2L (Rental.startDay original)
    check "query preserves finish day" 8L (Rental.finishDay original)
    check "query preserves cancellation" None (Rental.cancelledDay original)

    checks

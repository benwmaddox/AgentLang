from pathlib import Path
import json,hashlib,zipfile,datetime
root=Path.cwd(); r=root/'.agentlang/reuse-145'; dest=root/'reports/evidence/145-rental-vocabulary-reuse'; archive=dest/'results.zip'; index=dest/'results-index.json'; assert not archive.exists() and not index.exists()
sha=lambda b:hashlib.sha256(b).hexdigest(); files=[]
for part in ['participants','results']:
 for p in (r/part).rglob('*'):
  if p.is_file() and not {'bin','obj','__pycache__','tmp','temp'}.intersection(x.lower() for x in p.relative_to(r).parts) and p.name.lower()!='write.lock': files.append(p)
files += [r/name for name in ['freeze.json','dispatch.json','grade-one.py','package-results.py']]
files=sorted(set(files)); entries=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  b=p.read_bytes(); n=p.relative_to(root).as_posix(); z.writestr(n,b); entries.append({'path':n,'bytes':len(b),'sha256':sha(b)})
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)==len(set(z.namelist()))
 for x in entries:
  b=z.read(x['path']); assert len(b)==x['bytes'] and sha(b)==x['sha256'] and b==(root/x['path']).read_bytes()
meta={'schemaVersion':1,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(entries)},'verifiedAgainstSourceAndZip':True,'exclusions':['bin','obj','__pycache__','tmp','temp','WRITE.lock'],'files':entries}
index.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8'); print(json.dumps(meta['archive']))

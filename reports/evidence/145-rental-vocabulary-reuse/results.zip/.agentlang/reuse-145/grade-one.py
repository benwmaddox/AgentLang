from pathlib import Path
import sys,json,subprocess,hashlib
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
who=sys.argv[1]
assert who in {'flow-a','flow-b','fsharp-a','fsharp-b'}
participant=ROOT/'participants'/who
trace=participant/'actor.trace.jsonl'
rows=[json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines() if line.strip()]
assert rows[-1].get('event')=='session-end','Participant not terminal; do not grade live source'
result=ROOT/'results'/who
result.mkdir(parents=True,exist_ok=False)
def run(name,cmd):
    (result/(name+'.command.json')).write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    done=subprocess.run(cmd,cwd=REPO,text=True,encoding='utf-8',errors='replace',capture_output=True)
    (result/(name+'.stdout.txt')).write_text(done.stdout,encoding='utf-8')
    (result/(name+'.stderr.txt')).write_text(done.stderr,encoding='utf-8')
    (result/(name+'.exit.txt')).write_text(str(done.returncode)+'\n',encoding='utf-8')
    return done.returncode
run('termination-audit',['pwsh','-NoProfile','-File',str(REPO/'scripts/Audit-SubagentTrialTerminationV2.ps1'),'-TracePath',str(trace)])
arm='flow' if who.startswith('flow') else 'fsharp'
cli=REPO/'.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
command=[sys.executable,str(ROOT/'oracle/score.py'),'--arm',arm,'--project',str(participant/'project'),'--output',str(result/'oracle')]
command += ['--cli',str(cli)] if arm=='flow' else ['--fsharp-project','project/RentalDomain.fsproj']
run('oracle',command)
if arm=='fsharp':
    run('own-suite',['dotnet','run','--project',str(result/'oracle/working-project/tests/RentalDomain.Tests.fsproj'),'-c','Release','-p:NuGetAudit=false'])
exchanges=[r for r in rows if r.get('event')=='exchange']
errors=[];tests=[]
for r in exchanges:
    response=r.get('response') or {}
    try: data=json.loads(response.get('rawLine','{}'))
    except json.JSONDecodeError: continue
    if data.get('ok') is False: errors.append({'index':r['index'],'operation':r.get('operation'),'error':data.get('error'),'text':data.get('text')})
    if r.get('operation') in {'test','test-all','validate','commit','task.commit'}: tests.append({'index':r['index'],'operation':r.get('operation'),'response':data})
summary={'participant':who,'exchanges':len(exchanges),'errorResponses':errors,'testAndCommitResponses':tests,'terminal':rows[-1]}
(result/'trace-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'participant':who,'exchanges':len(exchanges),'errorResponseCount':len(errors),'result':str(result)}))

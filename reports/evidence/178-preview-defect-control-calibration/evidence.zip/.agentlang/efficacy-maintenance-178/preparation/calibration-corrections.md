# Calibration record corrections

The original `calibration-summary.json` is preserved as written. It contains two harness/reporting mistakes that are corrected here without replacing the raw run artifacts:

- Flow stores an attached test's case source without the terminating JSONL newline. The correct source hash is `a2215287b5076b7aaa4478f1868debeda1c97d05e46ab791f5ccef6288c42cb1`.
- Adding the attachment-only test advances the staged replacement again. The final accepted target revision is 3, two revisions after the starting revision 1, while the original `WordId` stays unchanged.
- The frozen oracle's exact expected code for `empty-replacement-period` is `SUBSCRIPTION_EXPIRY_MUST_FOLLOW_START`, not `EMPTY_PERIOD` or `SUBSCRIPTION_INVALID_PERIOD`.

These corrections do not change the protocol outcomes or project state. The raw first reset run remains under `controls/faulty-reset/protocol-run/`; `protocol-reconciliation.json` records the independently checked successful protocol sequence. The second top-level script invocation reached both accepted controls and both scorer reports, wrote `calibration-summary.json`, then exited with a summary-print `KeyError` because the reconciled reset record uses different summary fields. The completed JSON summary and all CLI/scorer evidence remain intact.

The actual CLI protocol outcomes were:

- Reset: four inherited tests passed; the inherited-only library replacement failed with `LIBRARY_COVERAGE_INCOMPLETE`; after adding the coordinator-injected equality test, `test-all` passed 142/142, the `library: true` replacement committed, and a post-commit `test-all` passed 142/142.
- Retained: three inherited tests passed; the inherited-only library replacement failed with `LIBRARY_COVERAGE_INCOMPLETE`; after adding the same coordinator-injected equality test, `test-all` passed 146/146, the `library: true` replacement committed, and a post-commit `test-all` passed 146/146.
- The independent 33-case score executed every case for both faulty controls, with 29 passed, four behavioral mismatches, and zero setup errors. Both include `empty-replacement-period`: the mutant returned `ok(originalStore)` while the oracle expected `SUBSCRIPTION_EXPIRY_MUST_FOLLOW_START`.

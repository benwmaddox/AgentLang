"""Create and calibrate the 178 preview-replacement mutation controls.

All writes are limited to .agentlang/efficacy-maintenance-178/preparation and
controls. The report-171 scorer and frozen report-163 oracle are imported as
read-only helpers; their evidence destination is redirected into this trial.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any


sys.dont_write_bytecode = True

REPO = Path(__file__).resolve().parents[3]
TRIAL = REPO / ".agentlang" / "efficacy-maintenance-178"
PREPARATION = TRIAL / "preparation"
CONTROLS = TRIAL / "controls"
RELOAD = TRIAL / "reload"
CLI = TRIAL / "build" / "bin" / "AgentLang.Cli" / "release" / "AgentLang.Cli.dll"
ADAPTER_PATH = REPO / ".agentlang" / "preview-retention-171" / "drafts" / "score_adapter.py"
BASELINE_SCORE_PATHS = {
    "reset": PREPARATION / "evidence" / "baseline-reset" / "agentlang-runs",
    "retained": PREPARATION / "evidence" / "baseline-retained" / "agentlang-runs",
}
ARM_NAMES = ("reset", "retained")
TARGET = "subscription.preview-replacement"

ZERO_PERIOD_TEST = '''test subscription.preview-replacement/zero-period-no-op {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let replacementId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    let output = .subscription.preview-replacement(
        store,
        oldId,
        replacementId,
        "annual",
        handoffAt,
        handoffAt
    )

    match output {
        ok returned => .equals(returned, store)
        error _ => false
    }
    => true
}
'''


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted((item for item in root.rglob("*") if item.is_file()), key=lambda item: item.relative_to(root).as_posix()):
        if path.name == "WRITE.lock":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


def import_adapter():
    spec = importlib.util.spec_from_file_location("preview_retention_171_adapter_178", ADAPTER_PATH)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load scorer adapter from {ADAPTER_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.EVIDENCE_ROOT = PREPARATION / "evidence"
    return module


ADAPTER = import_adapter()
OLD = ADAPTER.OLD


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def current_target(project: Path) -> dict[str, Any]:
    store = project / ".agentlang" / "store"
    current = json.loads((store / "CURRENT").read_text(encoding="utf-8-sig"))
    manifest_path = store / "manifests" / f"{current['manifestHash']}.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    word = next(item for item in manifest["words"] if item["currentName"] == TARGET)
    revision = next(item for item in manifest["revisions"] if item["wordId"] == word["wordId"] and item["revision"] == word["currentRevision"])
    return {
        "wordId": word["wordId"],
        "name": word["currentName"],
        "revision": word["currentRevision"],
        "maturity": revision["maturity"],
        "definitionHash": revision["definition"]["hash"],
        "manifestHash": current["manifestHash"],
        "manifestFileSha256": sha256_file(manifest_path),
        "tests": [{"hash": item["hash"]} for item in revision["tests"]],
        "examples": [{"hash": item["hash"]} for item in revision["examples"]],
    }


def source_and_attachments(arm: str) -> tuple[str, list[dict[str, Any]]]:
    responses = load_jsonl(RELOAD / f"{arm}.responses.jsonl")
    source_response = responses[2]
    test_response = responses[3]
    if source_response.get("kind") != "source" or not source_response.get("ok"):
        raise ValueError(f"Saved source response for {arm} is missing or failed")
    if test_response.get("kind") != "tests" or not test_response.get("ok"):
        raise ValueError(f"Saved test source response for {arm} is missing or failed")
    cases = test_response.get("data")
    if not isinstance(cases, list):
        raise ValueError(f"Saved test response for {arm} is not the expected source list")
    return source_response["data"], cases


def faulty_source(original: str) -> str:
    lines = original.rstrip().splitlines()
    if not lines or not lines[0].startswith("fn subscription.preview-replacement(") or lines[-1] != "}":
        raise ValueError("Unexpected saved preview-replacement source shape")
    declaration = lines[0]
    prefix: list[str] = []
    body: list[str] = []
    in_body = False
    for line in lines[1:-1]:
        if not in_body and (line.strip().startswith("effects ") or line.strip().startswith("doc ")):
            prefix.append(line)
        else:
            in_body = True
            body.append(line)
    while body and not body[0].strip():
        body.pop(0)
    while body and not body[-1].strip():
        body.pop()
    if not prefix or not body:
        raise ValueError("Unexpected saved function body; refusing to synthesize replacement")
    nested = [f"    {line}" if line else "" for line in body]
    output = [
        declaration,
        *prefix,
        "",
        "    if handoffAt == expiresAt {",
        "        result.ok<Store, BusinessError>(store)",
        "    } else {",
        *nested,
        "    }",
        "}",
    ]
    return "\n".join(output) + "\n"


def canonical_jsonl(rows: list[dict[str, Any]]) -> str:
    return "\n".join(OLD.json_line(item) for item in rows) + "\n"


def response_summary(request: dict[str, Any], response: dict[str, Any]) -> dict[str, Any]:
    error = response.get("error")
    return {
        "op": request.get("op"),
        "word": request.get("word"),
        "ok": response.get("ok"),
        "kind": response.get("kind"),
        "text": response.get("text"),
        "error": error,
        "dataKeys": sorted(response.get("data", {}).keys()) if isinstance(response.get("data"), dict) else None,
    }


def test_counts(response: dict[str, Any]) -> tuple[int, int]:
    match = re.match(r"^(\d+)/(\d+) test\(s\) passed\.$", response.get("text", ""))
    if match is None:
        raise ValueError(f"Test response lacks a passing count: {response!r}")
    return int(match.group(1)), int(match.group(2))


def run_cli(project: Path, requests: list[dict[str, Any]], run_root: Path) -> tuple[int, str, str, list[dict[str, Any]]]:
    if run_root.exists():
        raise FileExistsError(f"Refusing to reuse existing CLI evidence directory: {run_root}")
    run_root.mkdir(parents=True)
    temp_root = run_root / "dotnet-temp"
    temp_root.mkdir()
    env = os.environ.copy()
    env["TEMP"] = str(temp_root.resolve())
    env["TMP"] = str(temp_root.resolve())
    request_text = canonical_jsonl(requests)
    (run_root / "requests.jsonl").write_text(request_text, encoding="utf-8", newline="\n")
    (run_root / "requests.sha256").write_text(sha256_bytes(request_text.encode("utf-8")) + "  requests.jsonl\n", encoding="ascii")
    try:
        process = subprocess.run(
            ["dotnet", str(CLI), "--project", str(project), "--filesystem", "virtual", "--jsonl"],
            cwd=REPO,
            input=request_text,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=300,
            env=env,
        )
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout.decode("utf-8", "replace") if isinstance(error.stdout, bytes) else (error.stdout or "")
        stderr = error.stderr.decode("utf-8", "replace") if isinstance(error.stderr, bytes) else (error.stderr or "")
        (run_root / "stdout.txt").write_text(stdout, encoding="utf-8", newline="\n")
        (run_root / "stderr.txt").write_text(stderr, encoding="utf-8", newline="\n")
        (run_root / "responses.jsonl").write_text(stdout, encoding="utf-8", newline="\n")
        (run_root / "run-summary.json").write_text(json.dumps({"timedOut": True, "timeoutSeconds": 300}, indent=2) + "\n", encoding="utf-8")
        raise RuntimeError(f"CLI timed out; partial evidence retained at {run_root}") from error
    (run_root / "stdout.txt").write_text(process.stdout, encoding="utf-8", newline="\n")
    (run_root / "stderr.txt").write_text(process.stderr, encoding="utf-8", newline="\n")
    (run_root / "responses.jsonl").write_text(process.stdout, encoding="utf-8", newline="\n")
    responses = []
    parse_errors = []
    for index, line in enumerate(process.stdout.splitlines(), 1):
        try:
            responses.append(json.loads(line))
        except json.JSONDecodeError as error:
            parse_errors.append({"line": index, "error": str(error), "sample": line[:300]})
    return process.returncode, process.stdout, process.stderr, responses


def zero_period_source() -> dict[str, Any]:
    exact_case_source = ZERO_PERIOD_TEST.rstrip("\n")
    return {
        "source": ZERO_PERIOD_TEST,
        "sha256": sha256_bytes(exact_case_source.encode("utf-8")),
        "classification": "Coordinator-injected incorrect assertion used only to exercise the newly added equality branch.",
        "fixture": {
            "oldId": "30000000-0000-0000-0000-000000000001",
            "replacementId": "40000000-0000-0000-0000-000000000001",
            "term": "annual",
            "handoffAt": "2026-01-15T12:00:00.0000000+00:00",
            "expiresAt": "2026-01-15T12:00:00.0000000+00:00",
            "expectedBehavior": "SUBSCRIPTION_EXPIRY_MUST_FOLLOW_START error; this injected test incorrectly expects ok(originalStore).",
        },
    }


def make_requests(arm: str, project: Path, original_source: str, target_cases: list[dict[str, Any]], faulty: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    before = current_target(project)
    if before["maturity"] != "library":
        raise ValueError(f"Expected an existing library target for {arm}; found {before['maturity']!r}")
    _, cases = source_and_attachments(arm)
    if cases != target_cases:
        raise ValueError("Internal target test source mismatch")
    if not original_source.startswith("fn subscription.preview-replacement("):
        raise ValueError("Unexpected saved source for target")
    requests = [
        {"op": "describe", "word": TARGET},
        {"op": "tests", "word": TARGET, "includeSource": True},
        {"op": "examples", "word": TARGET},
        {
            "op": "define", "frontend": "flow", "syntaxVersion": 2, "replace": True,
            "expectedRevision": before["revision"], "source": faulty,
        },
        {"op": "test", "word": TARGET},
        {"op": "replace-word", "word": TARGET, "library": True},
        {"op": "define", "frontend": "flow", "syntaxVersion": 2, "source": ZERO_PERIOD_TEST},
        {"op": "test-all"},
        {"op": "replace-word", "word": TARGET, "library": True},
        {"op": "test-all"},
        {"op": "describe", "word": TARGET},
        {"op": "tests", "word": TARGET, "includeSource": True},
        {"op": "examples", "word": TARGET},
    ]
    return requests, before


def get_tests(response: dict[str, Any]) -> list[dict[str, Any]]:
    if response.get("kind") != "tests" or not response.get("ok") or not isinstance(response.get("data"), list):
        raise ValueError(f"Unexpected tests inspection response: {response!r}")
    return response["data"]


def calibrate_arm(arm: str) -> dict[str, Any]:
    source, cases = source_and_attachments(arm)
    source_hash = sha256_bytes(source.encode("utf-8"))
    inherited_cases = [{key: row.get(key) for key in ("name", "sourceHash", "frontend", "syntaxVersion", "source")} for row in cases]
    snapshot = RELOAD / arm
    snapshot_hash_before = tree_sha256(snapshot)
    copy_root = CONTROLS / f"faulty-{arm}"
    if copy_root.exists():
        raise FileExistsError(f"Refusing to overwrite existing control: {copy_root}")
    if (PREPARATION / "evidence" / f"defect-{arm}").exists():
        raise FileExistsError(f"Refusing to overwrite defect scorer evidence for {arm}")
    shutil.copytree(snapshot, copy_root / "project")
    project = copy_root / "project"
    original_identity = current_target(project)
    faulty = faulty_source(source)
    input_hashes = {
        "snapshotTreeSha256": snapshot_hash_before,
        "targetDefinitionSourceSha256": source_hash,
        "targetDefinitionHash": original_identity["definitionHash"],
        "targetWordId": original_identity["wordId"],
        "targetRevision": original_identity["revision"],
        "targetMaturity": original_identity["maturity"],
        "inheritedTestSourceHashes": {row["name"]: row["sourceHash"] for row in cases},
        "cliSha256": sha256_file(CLI),
        "scorerAdapterSha256": sha256_file(ADAPTER_PATH),
        "oracleCasesSha256": sha256_file(ADAPTER.ORACLE / "cases.json"),
        "oracleModelSha256": sha256_file(ADAPTER.ORACLE / "model.py"),
        "savedRequestsSha256": sha256_file(RELOAD / f"{arm}.requests.jsonl"),
        "savedResponsesSha256": sha256_file(RELOAD / f"{arm}.responses.jsonl"),
    }
    (copy_root / "inherited-tests.json").write_text(json.dumps(inherited_cases, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (copy_root / "original-source.flow").write_text(source, encoding="utf-8", newline="\n")
    (copy_root / "faulty-source.flow").write_text(faulty, encoding="utf-8", newline="\n")
    (copy_root / "coordinator-injected-test.flow").write_text(ZERO_PERIOD_TEST, encoding="utf-8", newline="\n")
    (copy_root / "input-hashes.json").write_text(json.dumps(input_hashes, indent=2) + "\n", encoding="utf-8")

    requests, before = make_requests(arm, project, source, cases, faulty)
    run_root = copy_root / "protocol-run"
    exit_code, stdout, stderr, responses = run_cli(project, requests, run_root)
    parse_errors: list[dict[str, Any]] = []
    if len(responses) != len(requests):
        parse_errors.append({"kind": "response-count", "expected": len(requests), "actual": len(responses)})
    if exit_code != 0:
        parse_errors.append({"kind": "cli-exit", "exitCode": exit_code})
    if len(responses) >= 6 and responses[5].get("ok"):
        parse_errors.append({"kind": "expected-inherited-only-library-gate-rejection-missing"})
    if len(responses) >= 6 and "coverage" not in json.dumps(responses[5], ensure_ascii=False).lower() and "branch" not in json.dumps(responses[5], ensure_ascii=False).lower():
        parse_errors.append({"kind": "library-gate-rejection-not-coverage-related", "response": responses[5]})
    for index in (3, 4, 6):
        if len(responses) > index and not responses[index].get("ok"):
            parse_errors.append({"kind": "protocol-operation-failed", "index": index, "request": requests[index], "response": responses[index]})
    if len(responses) >= 8 and not responses[7].get("ok"):
        parse_errors.append({"kind": "test-all-with-injected-case-failed", "response": responses[7]})
    if len(responses) >= 9 and not responses[8].get("ok"):
        parse_errors.append({"kind": "faulty-library-replacement-commit-failed", "response": responses[8]})
    if len(responses) >= 10 and not responses[9].get("ok"):
        parse_errors.append({"kind": "postcommit-test-all-failed", "response": responses[9]})
    if len(responses) >= 5 and responses[4].get("ok"):
        try:
            inherited_passed, inherited_total = test_counts(responses[4])
            if inherited_passed != len(cases) or inherited_total != len(cases):
                parse_errors.append({"kind": "inherited-tests-did-not-all-pass", "expected": len(cases), "actual": [inherited_passed, inherited_total]})
        except Exception as error:
            parse_errors.append({"kind": "inherited-test-count-error", "error": str(error)})
    baseline_rows = load_jsonl(RELOAD / f"{arm}.responses.jsonl")
    baseline_match = re.match(r"^(\d+)/(\d+) test\(s\) passed\.$", baseline_rows[1].get("text", ""))
    if baseline_match and len(responses) >= 10:
        expected_total = int(baseline_match.group(2)) + 1
        for index in (7, 9):
            if responses[index].get("ok"):
                try:
                    passed, total = test_counts(responses[index])
                    if passed != expected_total or total != expected_total:
                        parse_errors.append({"kind": "test-all-count-mismatch", "index": index, "expected": expected_total, "actual": [passed, total]})
                except Exception as error:
                    parse_errors.append({"kind": "test-all-count-error", "index": index, "error": str(error)})

    expected_target_test_count = len(cases) + 1
    expected_injected_hash = sha256_bytes(ZERO_PERIOD_TEST.rstrip("\n").encode("utf-8"))
    if len(responses) >= 13:
        try:
            final_tests = get_tests(responses[11])
            final_sources = {row["name"]: row["sourceHash"] for row in final_tests}
            inherited_sources = {row["name"]: row["sourceHash"] for row in cases}
            if len(final_tests) != expected_target_test_count:
                parse_errors.append({"kind": "unexpected-final-test-count", "expected": expected_target_test_count, "actual": len(final_tests)})
            for name, source_hash in inherited_sources.items():
                if final_sources.get(name) != source_hash:
                    parse_errors.append({"kind": "inherited-test-changed", "name": name, "expectedHash": source_hash, "actualHash": final_sources.get(name)})
            added = [row for row in final_tests if row["name"] == "zero-period-no-op"]
            if len(added) != 1 or added[0].get("sourceHash") != expected_injected_hash:
                parse_errors.append({"kind": "injected-test-source-changed", "actual": added})
            final_examples = responses[12].get("data")
            if final_examples != responses[2].get("data"):
                parse_errors.append({"kind": "examples-changed", "before": responses[2].get("data"), "after": final_examples})
        except Exception as error:
            parse_errors.append({"kind": "final-attachment-inspection-error", "error": str(error)})

    final_identity = current_target(project)
    if final_identity["wordId"] != original_identity["wordId"]:
        parse_errors.append({"kind": "target-word-id-changed", "before": original_identity["wordId"], "after": final_identity["wordId"]})
    if final_identity["revision"] != original_identity["revision"] + 2:
        parse_errors.append({"kind": "unexpected-final-revision", "before": original_identity["revision"], "after": final_identity["revision"]})
    if final_identity["maturity"] != "library":
        parse_errors.append({"kind": "accepted-target-not-library", "maturity": final_identity["maturity"]})
    if tree_sha256(snapshot) != snapshot_hash_before:
        parse_errors.append({"kind": "source-snapshot-mutated", "snapshot": str(snapshot)})

    summary = {
        "arm": arm,
        "sourceSnapshot": str(snapshot.relative_to(REPO)),
        "controlProject": str(project.relative_to(REPO)),
        "cli": str(CLI.relative_to(REPO)),
        "cliSha256": input_hashes["cliSha256"],
        "snapshotTreeSha256": snapshot_hash_before,
        "targetIdentityBefore": original_identity,
        "targetIdentityAfter": final_identity,
        "firstGate": response_summary(requests[5], responses[5]) if len(responses) > 5 else None,
        "firstInheritedTests": response_summary(requests[4], responses[4]) if len(responses) > 4 else None,
        "allTestsAfterInjectedCase": response_summary(requests[7], responses[7]) if len(responses) > 7 else None,
        "libraryCommit": response_summary(requests[8], responses[8]) if len(responses) > 8 else None,
        "postcommitAllTests": response_summary(requests[9], responses[9]) if len(responses) > 9 else None,
        "responseSummaries": [response_summary(req, resp) for req, resp in zip(requests, responses)],
        "cliExitCode": exit_code,
        "stderrBytes": len(stderr.encode("utf-8")),
        "stderrSha256": sha256_bytes(stderr.encode("utf-8")),
        "parseErrors": parse_errors,
        "status": "accepted" if not parse_errors else "retained-failure",
        "wrongAssertionCoordinatorInjected": True,
        "injectedTestSha256": sha256_bytes(ZERO_PERIOD_TEST.encode("utf-8")),
    }
    (run_root / "run-summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (copy_root / "control-summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if parse_errors:
        raise RuntimeError(f"Control calibration for {arm} retained failures at {run_root}: {parse_errors}")
    return summary


def reconcile_existing_arm(arm: str) -> dict[str, Any]:
    """Reconcile reset's already accepted run without rerunning or overwriting it."""
    copy_root = CONTROLS / f"faulty-{arm}"
    project = copy_root / "project"
    run_root = copy_root / "protocol-run"
    reconciliation_path = copy_root / "protocol-reconciliation.json"
    if not project.is_dir() or not run_root.is_dir():
        raise FileNotFoundError(f"Existing control evidence is incomplete for {arm}: {copy_root}")
    if reconciliation_path.exists():
        raise FileExistsError(f"Refusing to overwrite protocol reconciliation: {reconciliation_path}")
    requests = load_jsonl(run_root / "requests.jsonl")
    responses = load_jsonl(run_root / "responses.jsonl")
    original, inherited = source_and_attachments(arm)
    before = current_target(RELOAD / arm)
    after = current_target(project)
    run_summary = json.loads((run_root / "run-summary.json").read_text(encoding="utf-8"))
    failures: list[dict[str, Any]] = []
    if len(requests) != 13 or len(responses) != 13:
        failures.append({"kind": "response-count", "requests": len(requests), "responses": len(responses)})
    if not responses[5].get("error", {}).get("code") == "LIBRARY_COVERAGE_INCOMPLETE":
        failures.append({"kind": "inherited-only-library-gate-not-coverage-rejected", "response": responses[5]})
    if responses[4].get("text") != f"{len(inherited)}/{len(inherited)} test(s) passed.":
        failures.append({"kind": "inherited-tests-not-passing", "response": responses[4]})
    baseline_rows = load_jsonl(RELOAD / f"{arm}.responses.jsonl")
    baseline_match = re.match(r"^(\d+)/(\d+) test\(s\) passed\.$", baseline_rows[1].get("text", ""))
    expected_total = int(baseline_match.group(2)) + 1 if baseline_match else None
    for index in (7, 9):
        if not responses[index].get("ok"):
            failures.append({"kind": "test-all-failed", "index": index, "response": responses[index]})
        else:
            try:
                passed, total = test_counts(responses[index])
                if passed != expected_total or total != expected_total:
                    failures.append({"kind": "test-all-count-mismatch", "index": index, "expected": expected_total, "actual": [passed, total]})
            except Exception as error:
                failures.append({"kind": "test-all-count-error", "index": index, "error": str(error)})
    if not responses[8].get("ok"):
        failures.append({"kind": "library-replacement-commit-failed", "response": responses[8]})
    if after["wordId"] != before["wordId"] or after["revision"] != before["revision"] + 2 or after["maturity"] != "library":
        failures.append({"kind": "target-identity-or-maturity-mismatch", "before": before, "after": after})
    if tree_sha256(RELOAD / arm) != run_summary["snapshotTreeSha256"]:
        failures.append({"kind": "original-snapshot-changed", "expected": run_summary["snapshotTreeSha256"], "actual": tree_sha256(RELOAD / arm)})
    final_tests = get_tests(responses[11])
    inherited_hashes = {row["name"]: row["sourceHash"] for row in inherited}
    final_hashes = {row["name"]: row["sourceHash"] for row in final_tests}
    for name, source_hash in inherited_hashes.items():
        if final_hashes.get(name) != source_hash:
            failures.append({"kind": "inherited-test-changed", "name": name, "expected": source_hash, "actual": final_hashes.get(name)})
    injected = next((row for row in final_tests if row["name"] == "zero-period-no-op"), None)
    injected_hash = sha256_bytes(ZERO_PERIOD_TEST.rstrip("\n").encode("utf-8"))
    if injected is None or injected.get("sourceHash") != injected_hash or injected.get("source") != ZERO_PERIOD_TEST.rstrip("\n"):
        failures.append({"kind": "injected-source-mismatch", "actual": injected, "expectedHash": injected_hash})
    if responses[2].get("data") != responses[12].get("data"):
        failures.append({"kind": "examples-changed", "before": responses[2].get("data"), "after": responses[12].get("data")})
    correction = {
        "harnessFalsePositivesInOriginalRunSummary": run_summary.get("parseErrors", []),
        "correction": [
            "Flow stores a test case source without the final request newline; compare the source hash against the exact case text, excluding that delimiter.",
            "Staging an attachment-only test advances the staged replacement revision again; the final accepted revision is original revision + 2 while the WordId remains stable.",
        ],
        "protocolOutcomes": {
            "faultySourceWithInheritedTests": response_summary(requests[3], responses[3]),
            "inheritedTargetTests": response_summary(requests[4], responses[4]),
            "inheritedOnlyLibraryGate": response_summary(requests[5], responses[5]),
            "injectedTestDefine": response_summary(requests[6], responses[6]),
            "fullTestAllBeforeCommit": response_summary(requests[7], responses[7]),
            "libraryCommit": response_summary(requests[8], responses[8]),
            "fullTestAllAfterCommit": response_summary(requests[9], responses[9]),
        },
    }
    reconciliation = {
        "arm": arm,
        "status": "accepted" if not failures else "reconciliation-failed",
        "controlProject": str(project.relative_to(REPO)),
        "protocolRun": str(run_root.relative_to(REPO)),
        "targetIdentityBefore": before,
        "targetIdentityAfter": after,
        "originalSnapshotTreeSha256": run_summary["snapshotTreeSha256"],
        "inheritedTestsUnchanged": not any(item["kind"] == "inherited-test-changed" for item in failures),
        "allInheritedAndInjectedTestsPass": responses[7].get("ok", False) and responses[9].get("ok", False),
        "examplesUnchanged": responses[2].get("data") == responses[12].get("data"),
        "coordinatorInjectedWrongAssertion": True,
        "correctedHarnessInterpretation": correction,
        "failures": failures,
    }
    reconciliation_path.write_text(json.dumps(reconciliation, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if failures:
        raise RuntimeError(f"Existing control did not reconcile cleanly; evidence retained at {reconciliation_path}: {failures}")
    return reconciliation


def score_faulty_arm(arm: str) -> dict[str, Any]:
    project = CONTROLS / f"faulty-{arm}" / "project"
    report = ADAPTER.score_actor(project, CLI, "control", f"defect-{arm}")
    run_root = PREPARATION / "evidence" / f"defect-{arm}"
    case_results = report.get("caseResults", [])
    empty_period = next((row for row in case_results if row.get("caseId") == "empty-replacement-period"), None)
    summary = {
        "arm": arm,
        "status": report.get("status"),
        "caseCount": report.get("caseCount"),
        "executedCaseCount": report.get("executedCaseCount"),
        "passedCaseCount": report.get("passedCaseCount"),
        "failingCaseIds": report.get("failingCaseIds"),
        "setupErrorCount": report.get("setupErrorCount"),
        "emptyPeriodCase": empty_period,
        "cliExitCode": report.get("cliExitCode"),
        "runtimeSha256": report.get("runtimeSha256"),
        "actorProject": report.get("actorProject"),
        "targetIdentity": report.get("targetIdentity"),
        "evidenceRoot": str(run_root.relative_to(REPO)),
        "statusMeansExecutedBehaviorMismatch": report.get("status") == "actor-score-failure" and report.get("executedCaseCount") == 33 and report.get("setupErrorCount") == 0,
    }
    path = PREPARATION / f"defect-score-{arm}.json"
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite defect score summary: {path}")
    path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if summary["caseCount"] != 33 or summary["executedCaseCount"] != 33 or summary["setupErrorCount"] != 0 or not empty_period or empty_period.get("passed"):
        raise RuntimeError(f"Defect score for {arm} did not execute and catch empty-period: {summary}")
    return summary


def write_baseline_summary() -> dict[str, Any]:
    path = PREPARATION / "baseline-summary.json"
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite baseline summary: {path}")
    scores = {}
    hashes = {}
    for arm in ARM_NAMES:
        run_roots = sorted(BASELINE_SCORE_PATHS[arm].glob("*"))
        if len(run_roots) != 1:
            raise ValueError(f"Expected one baseline scoring run for {arm}; found {len(run_roots)}")
        score_path = run_roots[0] / "score.json"
        score = json.loads(score_path.read_text(encoding="utf-8"))
        scores[arm] = {key: score.get(key) for key in ("status", "caseCount", "executedCaseCount", "passedCaseCount", "setupErrorCount", "cliExitCode", "runtimeSha256", "targetIdentity", "copiedScoringProject")}
        snapshot = RELOAD / arm
        hashes[arm] = {
            "snapshotTreeSha256": tree_sha256(snapshot),
            "savedRequestsSha256": sha256_file(RELOAD / f"{arm}.requests.jsonl"),
            "savedResponsesSha256": sha256_file(RELOAD / f"{arm}.responses.jsonl"),
            "dictionarySha256": sha256_file(snapshot / "dictionary.agent"),
        }
    result = {
        "status": "passed" if all(item["status"] == "passed" and item["caseCount"] == 33 and item["executedCaseCount"] == 33 and item["passedCaseCount"] == 33 and item["setupErrorCount"] == 0 for item in scores.values()) else "failed",
        "scorerAdapter": str(ADAPTER_PATH.relative_to(REPO)),
        "scorerAdapterSha256": sha256_file(ADAPTER_PATH),
        "cli": str(CLI.relative_to(REPO)),
        "cliSha256": sha256_file(CLI),
        "oracleCases": str((ADAPTER.ORACLE / "cases.json").relative_to(REPO)),
        "oracleCasesSha256": sha256_file(ADAPTER.ORACLE / "cases.json"),
        "oracleModelSha256": sha256_file(ADAPTER.ORACLE / "model.py"),
        "scores": scores,
        "inputHashes": hashes,
        "evidenceIncludes": ["requests.jsonl", "responses.jsonl", "stderr.txt", "score.json", "scoring-observers.flow"],
    }
    path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if result["status"] != "passed":
        raise RuntimeError(f"Baseline summary failed; evidence retained at {path}")
    return result


def main() -> int:
    if not CLI.is_file():
        raise FileNotFoundError(f"Fresh CLI is missing: {CLI}")
    if not CONTROLS.exists():
        CONTROLS.mkdir(parents=True)
    final_path = PREPARATION / "calibration-summary.json"
    if final_path.exists():
        raise FileExistsError(f"Refusing to rerun over existing calibration output: {final_path}")
    baseline_path = PREPARATION / "baseline-summary.json"
    if baseline_path.exists():
        baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
        if baseline.get("status") != "passed":
            raise RuntimeError(f"Existing baseline summary is not successful: {baseline_path}")
    else:
        baseline = write_baseline_summary()
    output = {
        "baseline": baseline,
        "controls": [],
        "defectScores": [],
        "injectedAssertion": zero_period_source(),
        "repairAcceptance": {
            "preserveAllInheritedTestSourceHashes": True,
            "correctZeroPeriodExpectation": "subscription.preview-replacement must return the existing EMPTY_PERIOD error for a valid old subscription and a fresh replacement ID when handoffAt equals expiresAt.",
            "doNotWeakenUnrelatedInheritedTests": True,
            "allowedPreservationAmendment": "Change only the coordinator-injected zero-period-no-op assertion; retain and repair its same fixture and semantic purpose.",
        },
    }
    for arm in ARM_NAMES:
        if (CONTROLS / f"faulty-{arm}").exists():
            result = reconcile_existing_arm(arm)
        else:
            result = calibrate_arm(arm)
        output["controls"].append(result)
    for arm in ARM_NAMES:
        output["defectScores"].append(score_faulty_arm(arm))
    final_path.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "baselineStatus": baseline["status"],
        "controls": [{
            "arm": row["arm"],
            "status": row["status"],
            "targetWordId": row["targetIdentityAfter"]["wordId"],
            "firstGate": row.get("firstGate") or row.get("correctedHarnessInterpretation", {}).get("protocolOutcomes", {}).get("inheritedOnlyLibraryGate"),
            "allTests": row.get("allTestsAfterInjectedCase") or row.get("correctedHarnessInterpretation", {}).get("protocolOutcomes", {}).get("fullTestAllBeforeCommit"),
            "commit": row.get("libraryCommit") or row.get("correctedHarnessInterpretation", {}).get("protocolOutcomes", {}).get("libraryCommit"),
        } for row in output["controls"]],
        "defectScores": output["defectScores"],
        "summary": str(final_path.relative_to(REPO)),
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())

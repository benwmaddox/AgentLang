# Efficacy maintenance 178 preparation

This directory records coordinator-only calibration for the preview-replacement repair study. The immutable source snapshots are `../reload/reset` and `../reload/retained`; all mutation runs use copies under `../controls`.

The frozen report-171 `score_adapter.py` is imported with its evidence root redirected here. The already completed baseline runs produced 33 executed and passed cases for each actor. Their raw requests, JSONL responses, stderr, structured scores, observer source, and copied scoring projects are under `evidence/baseline-reset` and `evidence/baseline-retained`.

`calibrate_controls.py` captures input hashes, stages a Flow/2 replacement that returns `ok(store)` whenever `handoffAt == expiresAt`, and first tests it with only the inherited target cases. Its ordinary library replacement must fail because the new equality branch has no true outcome. The script then attaches the same coordinator-authored `zero-period-no-op` test to each arm. That test intentionally asserts the wrong result for a valid old subscription, a fresh replacement ID, a nonblank term, and equal handoff/expiry times. It supplies true-branch coverage so the normal library gate accepts the faulty candidate. The immutable behavioral scorer must still execute and fail the `empty-replacement-period` case.

The wrong assertion is a coordinator-injected calibration control. The later repair task may change that one assertion to require the correct `EMPTY_PERIOD` result; the repair must preserve every inherited test source hash and must not weaken unrelated cases. This amendment is declared before any repair agent work.

Run `python .agentlang/efficacy-maintenance-178/preparation/calibrate_controls.py` once from the repository root. It refuses to overwrite any existing run artifact. Each CLI process is sequential, uses the fresh private Release DLL, and points `TEMP`/`TMP` at a unique directory in this trial. Failed responses, score mismatches, stdout, and stderr remain in the corresponding run directories.

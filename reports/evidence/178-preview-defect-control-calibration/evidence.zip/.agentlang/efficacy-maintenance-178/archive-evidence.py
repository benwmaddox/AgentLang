from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DEST = REPO / 'reports/evidence/178-preview-defect-control-calibration'
DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'evidence.zip'
if archive.exists():
    raise RuntimeError('Refusing to overwrite evidence archive')
sha = lambda data: hashlib.sha256(data).hexdigest()

labels = ['reset-correct-pinned', 'retained-correct-pinned', 'fsharp-correct-pinned',
          'reset-defect-pinned', 'retained-defect-pinned', 'fsharp-defect-pinned']
script = REPO / 'experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py'
case_file = script.parent / 'cases.json'
validation = []
for label in labels:
    score = json.loads((ROOT / 'oracle' / f'{label}.json').read_text(encoding='utf-8-sig'))
    row = score.get('score', score)
    expected = 29 if 'defect' in label else 37
    assert row['executedCaseCount'] == 37 and row['passedCaseCount'] == expected, label
    assert not row.get('setupFailure') and not score.get('setupFailure'), label
    assert score['scoreScriptSha256'] == sha(script.read_bytes()), label
    assert score['caseSourceSha256'] == sha(case_file.read_bytes()), label
    assert score.get('participantSourceUnchanged', True), label
    assert score.get('participantInputInventoryUnchanged', True), label
    assert row.get('setupErrorCount', 0) == 0, label
    assert not row.get('setupFailureCaseIds'), label
    validation.append({'label': label, 'executed': 37, 'passed': expected,
                       'failingCaseIds': row['failingCaseIds']})
faults = [row['failingCaseIds'] for row in validation if row['passed'] == 29]
assert len(faults[0]) == 8 and faults[0] == faults[1] == faults[2]

build_exit = json.loads((ROOT / 'build-cli-exit.json').read_text(encoding='utf-8-sig'))
assert build_exit['exitCode'] == 0
provenance = {
    'schemaVersion': 1,
    'sourceRevision': subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO, text=True).strip(),
    'productSourceChanged': False,
    'experimentalParticipantsDispatched': False,
    'scorerSha256': sha(script.read_bytes()),
    'caseFileSha256': sha(case_file.read_bytes()),
    'controls': validation,
    'runtime': [{'path': p.relative_to(REPO).as_posix(), 'sha256': sha(p.read_bytes())}
                for p in sorted((ROOT / 'build/bin/AgentLang.Cli/release').glob('*')) if p.is_file()],
    'productSourcePins': [{'path': p.relative_to(REPO).as_posix(), 'sha256': sha(p.read_bytes())}
                          for base in ['src/AgentLang.Core', 'src/AgentLang.Cli']
                          for p in sorted((REPO / base).glob('*')) if p.is_file()],
    'validation': 'Six final control scores passed expected positive/negative outcomes; source and case pins match',
}
(ROOT / 'provenance.json').write_text(json.dumps(provenance, indent=2)+'\n', encoding='utf-8')
excluded = {'build','dotnet-home','dotnet-cli-home','temp','bin','obj','__pycache__','.git','nuget-packages'}
files = [p for p in ROOT.rglob('*') if p.is_file()
         and not any(part in excluded for part in p.relative_to(ROOT).parts)
         and p.name != 'WRITE.lock'
         and p.suffix.lower() not in {'.dll','.exe','.pdb','.zip'}]
files.extend(p for p in script.parent.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend([
    REPO / '.agentlang/preview-retention-171/drafts/score_adapter.py',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/cases.json',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/score_conventional.py',
])
entries = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as out:
    for path in sorted(set(files)):
        name = path.relative_to(REPO).as_posix()
        data = path.read_bytes()
        out.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.namelist()) == len(entries)
    for row in entries:
        data = check.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
index = {'schemaVersion': 1, 'sourceRevision': provenance['sourceRevision'],
         'archive': 'evidence.zip', 'bytes': archive.stat().st_size,
         'sha256': sha(archive.read_bytes()), 'validation': provenance['validation'],
         'entries': entries}
(DEST / 'archive.json').write_text(json.dumps(index, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'entries': len(entries), 'bytes': index['bytes'], 'sha256': index['sha256']}))

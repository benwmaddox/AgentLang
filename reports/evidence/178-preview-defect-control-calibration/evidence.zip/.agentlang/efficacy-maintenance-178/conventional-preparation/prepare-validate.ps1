Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$prep = $PSScriptRoot
$trial = Join-Path (Split-Path $prep -Parent) 'conventional'
$localDotnet = Split-Path (Get-Command dotnet).Source
$sdkListing = & dotnet --list-sdks
$sdkVersion = [regex]::Match(($sdkListing | Select-Object -Last 1), '^\s*(\S+)').Groups[1].Value
if ([string]::IsNullOrWhiteSpace($sdkVersion)) { throw 'Could not identify an installed .NET SDK.' }
$localFSharpFeed = Join-Path $localDotnet "sdk\$sdkVersion\FSharp\library-packs"
if (-not (Get-ChildItem -LiteralPath $localFSharpFeed -Filter 'FSharp.Core.*.nupkg' -ErrorAction SilentlyContinue)) {
    throw "Missing local FSharp.Core package feed: $localFSharpFeed"
}

$tempRoot = Join-Path $prep 'temp'
$dotnetHome = Join-Path $prep 'dotnet-home'
$nugetPackages = Join-Path $prep 'nuget-packages'
New-Item -ItemType Directory -Path $tempRoot, $dotnetHome, $nugetPackages -Force | Out-Null
$env:TEMP = $tempRoot
$env:TMP = $tempRoot
$env:DOTNET_CLI_HOME = $dotnetHome
$env:NUGET_PACKAGES = $nugetPackages
$env:DOTNET_NOLOGO = '1'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE = '1'
$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE = '1'
$env:DOTNET_MULTILEVEL_LOOKUP = '0'

function Invoke-DotnetLogged([string[]]$Arguments, [string]$LogName, [int]$ExpectedExitCode = 0) {
    $logPath = Join-Path $prep $LogName
    $formattedArguments = $Arguments | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + $_.Replace('"', '\"') + '"' } else { $_ }
    }
    "COMMAND: dotnet $($formattedArguments -join ' ')" | Set-Content -LiteralPath $logPath -Encoding UTF8
    & dotnet @Arguments *>> $logPath
    $actualExitCode = $LASTEXITCODE
    "EXIT_CODE: $actualExitCode" | Add-Content -LiteralPath $logPath -Encoding UTF8
    if ($actualExitCode -ne $ExpectedExitCode) {
        throw "dotnet $($Arguments -join ' ') exited $actualExitCode; expected $ExpectedExitCode. See $logPath"
    }
    return $actualExitCode
}

$libraryProject = Join-Path $prep 'FreshBusiness.fsproj'
$null = Invoke-DotnetLogged @('clean', $libraryProject, '--configuration', 'Release') 'fresh-business-clean.log'
$freshLibraryRestore = @('restore', $libraryProject, '--source', $localFSharpFeed, '--packages', $nugetPackages)
$null = Invoke-DotnetLogged $freshLibraryRestore 'fresh-business-restore.log'
$null = Invoke-DotnetLogged @('build', $libraryProject, '--no-restore', '--no-incremental', '--configuration', 'Release') 'fresh-business-build.log'
$freshLibrary = Join-Path $prep 'bin\Release\net9.0\AgentLang.Business.dll'
if (-not (Test-Path $freshLibrary)) { throw "Fresh business assembly was not produced: $freshLibrary" }
$freshLibraryHash = (Get-FileHash -LiteralPath $freshLibrary -Algorithm SHA256).Hash
$originalInventory = Get-Content -LiteralPath (Join-Path $prep 'source-seed-inventory.json') -Raw | ConvertFrom-Json
$originalLibraryHash = ($originalInventory.files | Where-Object { $_.path -eq 'lib/AgentLang.Business.dll' }).sha256
if ($freshLibraryHash -eq $originalLibraryHash) { throw 'Fresh Business assembly still matches the source seed binary.' }

foreach ($projectRoot in @($trial, $prep)) {
    $libraryTarget = Join-Path $projectRoot 'lib\AgentLang.Business.dll'
    Copy-Item -LiteralPath $freshLibrary -Destination $libraryTarget -Force
}

foreach ($projectRoot in @($trial, $prep)) {
    $project = Join-Path $projectRoot 'SubscriptionHandoff.Conventional.fsproj'
    $name = if ($projectRoot -eq $trial) { 'trial' } else { 'control' }
    $restore = @('restore', $project, '--source', $localFSharpFeed, '--packages', $nugetPackages)
    $null = Invoke-DotnetLogged $restore "$name-restore.log"
    $null = Invoke-DotnetLogged @('build', $project, '--no-restore', '--no-incremental', '--configuration', 'Release') "$name-build.log"
    $null = Invoke-DotnetLogged @('run', '--project', $project, '--no-build', '--no-restore', '--configuration', 'Release') "$name-run.log"
}

$controlOperations = Join-Path $prep 'Operations.fs'
$correctOperationsBackup = Join-Path $tempRoot 'correct-Operations.fs'
Copy-Item -LiteralPath $controlOperations -Destination $correctOperationsBackup -Force
try {
    Copy-Item -LiteralPath (Join-Path $trial 'Operations.fs') -Destination $controlOperations -Force
    $controlProject = Join-Path $prep 'SubscriptionHandoff.Conventional.fsproj'
    $null = Invoke-DotnetLogged @('build', $controlProject, '--no-restore', '--no-incremental', '--configuration', 'Release') 'control-defect-build.log'
    $defectExitCode = Invoke-DotnetLogged @('run', '--project', $controlProject, '--no-build', '--no-restore', '--configuration', 'Release') 'control-defect-run.log' 1
    if (-not (Select-String -LiteralPath (Join-Path $prep 'control-defect-run.log') -SimpleMatch 'control assertion: preview accepted a zero-period replacement' -Quiet)) {
        throw 'The correct control assertion did not identify the faulty zero-period return.'
    }
}
finally {
    Copy-Item -LiteralPath $correctOperationsBackup -Destination $controlOperations -Force
}
$null = Invoke-DotnetLogged @('build', (Join-Path $prep 'SubscriptionHandoff.Conventional.fsproj'), '--no-restore', '--no-incremental', '--configuration', 'Release') 'control-restored-build.log'
$null = Invoke-DotnetLogged @('run', '--project', (Join-Path $prep 'SubscriptionHandoff.Conventional.fsproj'), '--no-build', '--no-restore', '--configuration', 'Release') 'control-restored-run.log'

$originalSeed = Join-Path (Split-Path (Split-Path $prep -Parent) -Parent) 'subscription-handoff-maintenance-166\seeds\conventional'
$preservation = @()
foreach ($relative in @('Domain.fs', 'Fixtures.fs', 'SubscriptionHandoff.Conventional.fsproj', 'Reference\Business.fs')) {
    $sourceFile = Join-Path $originalSeed $relative
    foreach ($projectRoot in @($trial, $prep)) {
        $copyFile = Join-Path $projectRoot $relative
        $same = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $copyFile -Algorithm SHA256).Hash
        if (-not $same) { throw "Copied source differs from the accepted seed: $copyFile" }
        $preservation += [pscustomobject]@{ path=$copyFile.Substring((Split-Path $prep -Parent).Length + 1).Replace('\', '/'); matchesSourceSeed=$true }
    }
}
foreach ($relative in @('Operations.fs', 'SelfTests.fs')) {
    $sourceText = [IO.File]::ReadAllText((Join-Path $originalSeed $relative))
    foreach ($projectRoot in @($trial, $prep)) {
        $copyFile = Join-Path $projectRoot $relative
        $copyText = [IO.File]::ReadAllText($copyFile)
        $hasExactSourcePrefix = $copyText.StartsWith($sourceText, [StringComparison]::Ordinal)
        if (-not $hasExactSourcePrefix) { throw "Original source is not preserved as an exact prefix: $copyFile" }
        $preservation += [pscustomobject]@{ path=$copyFile.Substring((Split-Path $prep -Parent).Length + 1).Replace('\', '/'); originalPrefixExact=$true }
    }
}
$preservation | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $prep 'source-preservation-status.json') -Encoding UTF8

$sourceFiles = @(
    (Get-ChildItem -LiteralPath $trial -File | Where-Object { $_.Name -ne 'hash-inventory.json' }),
    (Get-ChildItem -LiteralPath (Join-Path $trial 'lib') -File),
    (Get-ChildItem -LiteralPath $prep -File | Where-Object { $_.Name -notin @('hash-inventory.json', 'terminal-status.json') }),
    (Get-ChildItem -LiteralPath (Join-Path $prep 'attempt-archives') -File -Recurse),
    (Get-ChildItem -LiteralPath (Join-Path $prep 'lib') -File),
    (Get-ChildItem -LiteralPath (Join-Path $prep 'Reference') -File)
) | ForEach-Object { $_ }
$hashInventory = foreach ($file in $sourceFiles | Sort-Object FullName -Unique) {
    [pscustomobject]@{
        path = $file.FullName.Substring((Split-Path $prep -Parent).Length + 1).Replace('\', '/')
        length = $file.Length
        sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
    }
}
@{ generatedAtLocal = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK'); sourceFiles = $hashInventory } |
    ConvertTo-Json -Depth 4 |
    Set-Content -LiteralPath (Join-Path $prep 'hash-inventory.json') -Encoding UTF8

@{
    status = 'prepared_no_dispatch'
    sdk = $sdkVersion
    librarySource = (Join-Path $prep 'Reference\Business.fs')
    freshBusinessDll = (Get-FileHash -LiteralPath $freshLibrary -Algorithm SHA256).Hash
    trialBusinessDll = (Get-FileHash -LiteralPath (Join-Path $trial 'lib\AgentLang.Business.dll') -Algorithm SHA256).Hash
    controlBusinessDll = (Get-FileHash -LiteralPath (Join-Path $prep 'lib\AgentLang.Business.dll') -Algorithm SHA256).Hash
    freshBusinessRebuiltFromSeedReferenceSource = $true
    trialRunExitCode = 0
    controlRunExitCode = 0
    controlRejectedFaultyZeroPeriodRunExitCode = 1
    controlRestoredRunExitCode = 0
    exactOriginalOperationsAndSelfTestsPrefixPreserved = $true
    trialHasCorrectZeroPeriodAssertion = $false
    trialHasMistakenZeroPeriodExpectation = $true
    controlHasCorrectZeroPeriodAssertion = $true
    networkUsed = $false
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $prep 'terminal-status.json') -Encoding UTF8

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$prep = $PSScriptRoot
$trial = Join-Path (Split-Path $prep -Parent) 'conventional'
$sourceRoot = Join-Path (Split-Path (Split-Path $prep -Parent) -Parent) 'subscription-handoff-maintenance-166\seeds\conventional'
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

function Get-AppendedText([string]$Path, [string]$Marker) {
    $text = [IO.File]::ReadAllText($Path)
    $start = $text.LastIndexOf($Marker, [StringComparison]::Ordinal)
    if ($start -lt 0) { throw "Could not find appended section marker '$Marker' in $Path" }
    return $text.Substring($start)
}

function Convert-ToCrLf([string]$Text) {
    return [regex]::Replace($Text, "`r?`n", "`r`n")
}

function Write-SeedPrefixAndAppend([string]$SourcePath, [string]$DestinationPath, [string]$AppendedText) {
    $sourceBytes = [IO.File]::ReadAllBytes($SourcePath)
    $suffixBytes = $utf8NoBom.GetBytes("`r`n" + (Convert-ToCrLf $AppendedText))
    $merged = [byte[]]::new($sourceBytes.Length + $suffixBytes.Length)
    [Array]::Copy($sourceBytes, 0, $merged, 0, $sourceBytes.Length)
    [Array]::Copy($suffixBytes, 0, $merged, $sourceBytes.Length, $suffixBytes.Length)
    [IO.File]::WriteAllBytes($DestinationPath, $merged)
}

$trialOperations = Get-AppendedText (Join-Path $trial 'Operations.fs') '    /// Validate a replacement handoff while retaining the caller''s original store.'
$controlOperations = Get-AppendedText (Join-Path $prep 'Operations.fs') '    /// Validate a replacement handoff while retaining the caller''s original store.'
$trialTests = Get-AppendedText (Join-Path $trial 'SelfTests.fs') '    let runPreviewBasics () ='
$controlTests = Get-AppendedText (Join-Path $prep 'SelfTests.fs') '    let runPreviewBasics () ='

Write-SeedPrefixAndAppend (Join-Path $sourceRoot 'Operations.fs') (Join-Path $trial 'Operations.fs') $trialOperations
Write-SeedPrefixAndAppend (Join-Path $sourceRoot 'Operations.fs') (Join-Path $prep 'Operations.fs') $controlOperations
Write-SeedPrefixAndAppend (Join-Path $sourceRoot 'SelfTests.fs') (Join-Path $trial 'SelfTests.fs') $trialTests
Write-SeedPrefixAndAppend (Join-Path $sourceRoot 'SelfTests.fs') (Join-Path $prep 'SelfTests.fs') $controlTests

$trialProgram = [IO.File]::ReadAllText((Join-Path $sourceRoot 'Program.fs'))
$controlProgram = $trialProgram
$programNewline = if ($trialProgram.Contains("`r`n")) { "`r`n" } else { "`n" }
$programNeedle = "            SelfTests.run ()$programNewline            0"
if (-not $trialProgram.Contains($programNeedle)) { throw 'Could not find the expected Program.fs call site.' }
$trialProgram = $trialProgram.Replace($programNeedle, "            SelfTests.run ()$programNewline            SelfTests.runPreviewBasics ()$programNewline            SelfTests.runZeroPeriodNoOpExpectation ()$programNewline            0")
$controlProgram = $controlProgram.Replace($programNeedle, "            SelfTests.run ()$programNewline            SelfTests.runPreviewBasics ()$programNewline            SelfTests.runZeroPeriodControl ()$programNewline            0")
[IO.File]::WriteAllText((Join-Path $trial 'Program.fs'), $trialProgram, $utf8NoBom)
[IO.File]::WriteAllText((Join-Path $prep 'Program.fs'), $controlProgram, $utf8NoBom)

'Restored exact accepted-seed prefixes and re-appended the preview additions with CRLF line endings.'

#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$CliDll,
    [string]$RunId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$studyRoot = Join-Path $repoRoot '.agentlang/r09-discovery-001'
$preparationRoot = Join-Path $studyRoot 'preparation'
$baseRoot = Join-Path $studyRoot 'base'
if ([string]::IsNullOrWhiteSpace($CliDll)) {
    $CliDll = Join-Path $studyRoot 'runtime-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
}
$CliDll = [IO.Path]::GetFullPath($CliDll)
$coreDll = Join-Path (Split-Path -Parent $CliDll) 'AgentLang.Core.dll'
if ([string]::IsNullOrWhiteSpace($RunId)) {
    $RunId = [DateTimeOffset]::UtcNow.ToString('yyyyMMddTHHmmssfffZ', [Globalization.CultureInfo]::InvariantCulture) + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
}
if ($RunId -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]{0,63}$') { throw "Invalid run identifier '$RunId'." }

$runRoot = Join-Path (Join-Path $preparationRoot 'runs') $RunId
$projectRoot = Join-Path (Join-Path (Join-Path $baseRoot 'runs') $RunId) 'project'
$runParent = Split-Path -Parent $runRoot
$projectParent = Split-Path -Parent $projectRoot
foreach ($path in @($CliDll, $coreDll)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Required runtime file is missing: $path" }
}
if ((Test-Path -LiteralPath $runRoot) -or (Test-Path -LiteralPath $projectParent)) {
    throw "Run '$RunId' already exists. Choose a new -RunId; prior evidence is retained."
}

$inputPaths = @(
    (Join-Path $repoRoot 'examples/business-values.agent'),
    (Join-Path $repoRoot 'examples/business-store.agent'),
    (Join-Path $repoRoot 'examples/business-state.agent'),
    (Join-Path $repoRoot 'examples/business-subscriptions.agent'),
    (Join-Path $repoRoot 'examples/business-invoices.agent'),
    (Join-Path $repoRoot 'examples/business-payments-email.agent')
)
foreach ($path in $inputPaths) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Fixture source is missing: $path" }
}

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Write-JsonFile([string]$Path, [object]$Value) {
    $json = ConvertTo-Json -InputObject $Value -Depth 100
    [IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
}

function Get-Inventory([string]$Root) {
    $fullRoot = [IO.Path]::GetFullPath($Root)
    $rows = [Collections.Generic.List[object]]::new()
    foreach ($file in Get-ChildItem -LiteralPath $fullRoot -File -Recurse -Force) {
        $rows.Add([ordered]@{
            path = [IO.Path]::GetRelativePath($fullRoot, $file.FullName).Replace('\', '/')
            bytes = [int64]$file.Length
            sha256 = Get-Sha256 $file.FullName
        })
    }
    return @($rows | Sort-Object path)
}

function Get-Names([string[]]$Paths, [string]$Pattern, [int]$Capture = 1) {
    $found = [Collections.Generic.List[string]]::new()
    foreach ($path in $Paths) {
        $source = [IO.File]::ReadAllText($path)
        foreach ($match in [regex]::Matches($source, $Pattern, [Text.RegularExpressions.RegexOptions]::Multiline)) {
            $found.Add($match.Groups[$Capture].Value)
        }
    }
    return @($found)
}

function Same-Names([object[]]$Actual, [string[]]$Expected) {
    $left = @($Actual | ForEach-Object { [string]$_ } | Sort-Object -CaseSensitive)
    $right = @($Expected | Sort-Object -CaseSensitive)
    return (($left -join "`n") -ceq ($right -join "`n"))
}

function Assert-Check([string]$Name, [bool]$Passed, [string]$Details) {
    $script:checks.Add([ordered]@{ name = $Name; passed = $Passed; details = $Details })
    if (-not $Passed) { throw "Preparation check failed: $Name ($Details)" }
}

function Assert-TestBatch([object]$Response, [int]$Expected, [string]$Label) {
    $rows = @($Response.data.results)
    $failed = @($rows | Where-Object { $_.passed -ne $true })
    Assert-Check $Label ($rows.Count -eq $Expected -and $failed.Count -eq 0) "expected=$Expected; actual=$($rows.Count); failed=$($failed.Count)"
}

function Assert-WordSet([object]$Response, [string[]]$Names, [string]$Status, [string[]]$LibraryNames, [string]$Label) {
    $matchedCount = 0
    foreach ($name in $Names) {
        $rows = @($Response.data.words | Where-Object { $_.name -ceq $name })
        if ($rows.Count -eq 1) { $matchedCount++ }
        $maturity = if ($LibraryNames -ccontains $name) { 'library' } else { 'project' }
        $valid = $rows.Count -eq 1 -and $rows[0].status -ceq $Status
        if ($Status -ceq 'persistent') { $valid = $valid -and $rows[0].maturity -ceq $maturity }
        Assert-Check "$Label $name" $valid "expectedStatus=$Status; expectedMaturity=$maturity; actual=$($rows | ConvertTo-Json -Compress -Depth 10)"
    }
    Assert-Check "$Label includes all authored names" ($matchedCount -eq $Names.Count) "expected=$($Names.Count); matched=$matchedCount; runtimeAlsoListsTrustedVocabulary=$(@($Response.data.words).Count)"
}

function Invoke-FlowSourceExtractor([string[]]$Paths, [string[]]$Owners, [string]$RequestPath, [string]$OutputPath) {
    $extractorPath = Join-Path $repoRoot 'scripts/Extract-FlowOwnedSource.fsx'
    $request = [ordered]@{ paths = @($Paths); owners = @($Owners) }
    Write-JsonFile $RequestPath $request
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = 'dotnet'
    $startInfo.WorkingDirectory = $repoRoot
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.CreateNoWindow = $true
    foreach ($argument in @('fsi', '--quiet', '--exec', "--reference:$coreDll", $extractorPath)) {
        [void]$startInfo.ArgumentList.Add($argument)
    }
    $startInfo.Environment['AGENTLANG_FLOW_SOURCE_REQUEST'] = $RequestPath
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    if (-not $process.Start()) { throw 'Could not start the existing Flow declaration extractor.' }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    $timedOut = -not $process.WaitForExit(60000)
    if ($timedOut) {
        try { $process.Kill($true) } catch { }
        [void]$process.WaitForExit(10000)
    }
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    $exitCode = if ($timedOut) { $null } else { $process.ExitCode }
    $process.Dispose()
    Write-JsonFile (Join-Path $runRoot 'source-extractor-process.json') ([ordered]@{
        executable = 'dotnet'
        arguments = @('fsi', '--quiet', '--exec', "--reference:$coreDll", $extractorPath)
        requestPath = $RequestPath
        exitCode = $exitCode
        timedOut = $timedOut
        stdout = $stdout
        stderr = $stderr
    })
    if ($timedOut -or $exitCode -ne 0 -or [string]::IsNullOrWhiteSpace($stdout)) {
        throw "Flow declaration extraction failed (exit=$exitCode, timedOut=$timedOut). See source-extractor-process.json."
    }
    [IO.File]::WriteAllText($OutputPath, $stdout, [Text.UTF8Encoding]::new($false))
    $result = ConvertFrom-Json -InputObject $stdout -Depth 100
    $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.UTF8Encoding]::new($false).GetBytes([string]$result.source))).ToLowerInvariant()
    if ($hash -cne [string]$result.sourceSha256) { throw 'Extracted source hash does not match the extractor response.' }
    return $result
}

function Invoke-CliPhase([string]$Name, [object[]]$Requests) {
    $requestPath = Join-Path $runRoot "$Name.requests.jsonl"
    $responsePath = Join-Path $runRoot "$Name.responses.jsonl"
    $tracePath = Join-Path $runRoot "$Name.trace.jsonl"
    $processPath = Join-Path $runRoot "$Name.process.json"
    $requestLines = @($Requests | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 100 -Compress })
    [IO.File]::WriteAllLines($requestPath, [string[]]$requestLines, [Text.UTF8Encoding]::new($false))
    $responseLines = [Collections.Generic.List[string]]::new()
    $traceLines = [Collections.Generic.List[string]]::new()
    $responses = [Collections.Generic.List[object]]::new()
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = 'dotnet'
    $startInfo.WorkingDirectory = $repoRoot
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.CreateNoWindow = $true
    foreach ($argument in @($CliDll, '--project', $projectRoot, '--jsonl')) { [void]$startInfo.ArgumentList.Add($argument) }
    $startedAt = [DateTimeOffset]::UtcNow
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    $startError = $null
    $timedOut = $false
    $extraStdout = ''
    $stderr = ''
    $exitCode = $null
    try {
        if (-not $process.Start()) { throw 'Process did not start.' }
        $stderrTask = $process.StandardError.ReadToEndAsync()
        for ($index = 0; $index -lt $Requests.Count; $index++) {
            $requestLine = $requestLines[$index]
            $operation = [string]$Requests[$index].op
            $responseLine = $null
            $parseError = $null
            try {
                $process.StandardInput.WriteLine($requestLine)
                $process.StandardInput.Flush()
                $readTask = $process.StandardOutput.ReadLineAsync()
                if (-not $readTask.Wait(120000)) {
                    $timedOut = $true
                    throw "Timed out waiting for '$operation'."
                }
                $responseLine = $readTask.Result
                if ([string]::IsNullOrWhiteSpace($responseLine)) { throw "CLI closed before replying to '$operation'." }
                $response = ConvertFrom-Json -InputObject $responseLine -Depth 100
                $responses.Add($response)
                $responseLines.Add($responseLine)
            }
            catch {
                $parseError = $_.Exception.Message
            }
            $traceLines.Add((ConvertTo-Json -InputObject ([ordered]@{
                index = $index
                operation = $operation
                request = $requestLine
                response = $responseLine
                parseOrTransportError = $parseError
            }) -Depth 100 -Compress))
            if ($null -ne $parseError) {
                if ($timedOut) { try { $process.Kill($true) } catch { } }
                break
            }
            if ($response.ok -ne $true) { break }
        }
        try { $process.StandardInput.Close() } catch { }
        if (-not $process.HasExited) {
            $extraTask = $process.StandardOutput.ReadToEndAsync()
            if (-not $process.WaitForExit(60000)) {
                $timedOut = $true
                try { $process.Kill($true) } catch { }
                [void]$process.WaitForExit(10000)
            }
            if ($process.HasExited) { $extraStdout = $extraTask.GetAwaiter().GetResult() }
        }
        if ($process.HasExited) {
            $exitCode = $process.ExitCode
            $stderr = $stderrTask.GetAwaiter().GetResult()
        }
    }
    catch {
        $startError = $_.Exception.Message
        if ($process.HasExited) {
            $exitCode = $process.ExitCode
            try { $stderr = $stderrTask.GetAwaiter().GetResult() } catch { }
        }
        else { try { $process.Kill($true) } catch { } }
    }
    finally { $process.Dispose() }
    [IO.File]::WriteAllLines($responsePath, [string[]]$responseLines, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllLines($tracePath, [string[]]$traceLines, [Text.UTF8Encoding]::new($false))
    $processRecord = [ordered]@{
        phase = $Name
        executable = 'dotnet'
        arguments = @($CliDll, '--project', $projectRoot, '--jsonl')
        startedUtc = $startedAt.ToString('O')
        finishedUtc = [DateTimeOffset]::UtcNow.ToString('O')
        plannedRequests = $Requests.Count
        observedResponses = $responses.Count
        exitCode = $exitCode
        timedOut = $timedOut
        startOrTransportError = $startError
        stderr = $stderr
        stdoutAfterExpectedResponses = $extraStdout
    }
    Write-JsonFile $processPath $processRecord
    return [pscustomobject]@{
        Responses = @($responses)
        Record = [pscustomobject]$processRecord
        Successful = $null -eq $startError -and -not $timedOut -and $exitCode -eq 0 -and $responses.Count -eq $Requests.Count -and @($responses | Where-Object { $_.ok -ne $true }).Count -eq 0
    }
}

$script:checks = [Collections.Generic.List[object]]::new()
$status = 'failed'
$failure = $null
$sourceInventoryBefore = @()
$runtimeInventoryBefore = @()
$runtimeInventoryAfter = @()
$sourceInventoryAfter = @()
$projectInventory = @()
$expectedNames = @()
$typeNames = @()
$testNames = @()
$exampleNames = @()
$libraryNames = @()
$projectOnlyNames = @('email.delivery-fold-step', 'email.apply-delivery-result')
$cliRecordBefore = $null
$cliRecordAfter = $null

try {
    [IO.Directory]::CreateDirectory($runRoot) | Out-Null
    [IO.Directory]::CreateDirectory($projectRoot) | Out-Null
    $fixtureRoot = Join-Path $projectRoot 'fixtures'
    [IO.Directory]::CreateDirectory($fixtureRoot) | Out-Null

    $sourceInventoryBefore = @($inputPaths | ForEach-Object {
        [ordered]@{ path = [IO.Path]::GetRelativePath($repoRoot, $_).Replace('\', '/'); bytes = [int64](Get-Item -LiteralPath $_).Length; sha256 = Get-Sha256 $_ }
    })
    $runtimeRoot = Split-Path -Parent $CliDll
    $runtimeInventoryBefore = Get-Inventory $runtimeRoot
    $cliRecordBefore = [ordered]@{ cliSha256 = Get-Sha256 $CliDll; coreSha256 = Get-Sha256 $coreDll; runtimeFileCount = $runtimeInventoryBefore.Count; runtimeFiles = $runtimeInventoryBefore }
    Write-JsonFile (Join-Path $runRoot 'inputs-and-runtime-before.json') ([ordered]@{ sources = $sourceInventoryBefore; runtime = $cliRecordBefore })

    $expectedNames = Get-Names $inputPaths '^\s*word\s+([A-Za-z0-9_.?!-]+)\s*\('
    $typeNames = Get-Names $inputPaths '^\s*(?:type|record)\s+([A-Za-z][A-Za-z0-9_]*)\b'
    $testNames = Get-Names $inputPaths '^\s*test\s+([A-Za-z0-9_./?!-]+)\s*\{'
    $exampleNames = Get-Names $inputPaths '^\s*example\s+([A-Za-z0-9_./?!-]+)\s*\{'
    Assert-Check 'source inventory counts' ($expectedNames.Count -eq 53 -and $typeNames.Count -eq 31 -and $testNames.Count -eq 154 -and $exampleNames.Count -eq 44) "words=$($expectedNames.Count); types=$($typeNames.Count); tests=$($testNames.Count); examples=$($exampleNames.Count)"
    Assert-Check 'source word and type names are unique' (@($expectedNames | Sort-Object -Unique).Count -eq 53 -and @($typeNames | Sort-Object -Unique).Count -eq 31) 'duplicate owner names would make the seed ambiguous'
    foreach ($owner in $projectOnlyNames) { Assert-Check "project maturity exception exists: $owner" (@($expectedNames | Where-Object { $_ -ceq $owner }).Count -eq 1) 'expected exactly one source definition' }
    $libraryNames = @($expectedNames | Where-Object { $projectOnlyNames -cnotcontains $_ })
    Assert-Check 'maturity split is 51 library and 2 project' ($libraryNames.Count -eq 51 -and $projectOnlyNames.Count -eq 2) "library=$($libraryNames.Count); project=$($projectOnlyNames.Count)"

    foreach ($inputPath in $inputPaths) {
        $destination = Join-Path $fixtureRoot (Split-Path -Leaf $inputPath)
        Copy-Item -LiteralPath $inputPath -Destination $destination -ErrorAction Stop
    }

    $extractorRequestPath = Join-Path $runRoot 'project-only-source-request.json'
    $extractorOutputPath = Join-Path $runRoot 'project-only-source.json'
    $projectOnlySource = Invoke-FlowSourceExtractor $inputPaths $projectOnlyNames $extractorRequestPath $extractorOutputPath
    Assert-Check 'existing parser extracts exact project-only owners' (Same-Names @($projectOnlySource.words) $projectOnlyNames) "owners=$(@($projectOnlySource.words) -join ',')"
    $expectedProjectTests = @($testNames | Where-Object {
        $candidateTest = [string]$_
        @($projectOnlyNames | Where-Object { $candidateTest.StartsWith($_ + '/', [StringComparison]::Ordinal) }).Count -gt 0
    })
    $actualProjectTests = @($projectOnlySource.tests)
    Assert-Check 'project-only attached test inventory' (Same-Names $actualProjectTests $expectedProjectTests -and $actualProjectTests.Count -eq 5) "expected=$($expectedProjectTests.Count); actual=$($actualProjectTests.Count)"
    $expectedProjectExamples = @($exampleNames | Where-Object { $testName = $_; @($projectOnlyNames | Where-Object { $testName.StartsWith($_ + '/', [StringComparison]::Ordinal) }).Count -gt 0 })
    Assert-Check 'project-only attached example inventory' (Same-Names @($projectOnlySource.examples) $expectedProjectExamples) "expected=$($expectedProjectExamples.Count); actual=$(@($projectOnlySource.examples).Count)"

    $phaseOneRequests = [Collections.Generic.List[object]]::new()
    foreach ($inputPath in $inputPaths) {
        $phaseOneRequests.Add([ordered]@{ op = 'define'; frontend = 'flow'; source = [IO.File]::ReadAllText($inputPath) })
    }
    $phaseOneRequests.Add([ordered]@{ op = 'test-all' })
    $phaseOneRequests.Add([ordered]@{ op = 'words' })
    $phaseOneRequests.Add([ordered]@{ op = 'discard'; word = 'email.apply-delivery-result' })
    $phaseOneRequests.Add([ordered]@{ op = 'discard'; word = 'email.delivery-fold-step' })
    $phaseOneRequests.Add([ordered]@{ op = 'test-all' })
    $phaseOneRequests.Add([ordered]@{ op = 'words' })
    $phaseOneRequests.Add([ordered]@{ op = 'commit'; library = $true })
    $phaseOneRequests.Add([ordered]@{ op = 'words' })
    $phaseOne = Invoke-CliPhase 'initialize-library' $phaseOneRequests.ToArray()
    Assert-Check 'initialize-library CLI process completed' $phaseOne.Successful ($phaseOne.Record | ConvertTo-Json -Compress -Depth 10)
    Assert-TestBatch $phaseOne.Responses[6] 154 'full source test batch passed'
    Assert-WordSet $phaseOne.Responses[7] $expectedNames 'candidate' @() 'full staged inventory'
    Assert-Check 'discarded exactly the two project maturity exceptions' ($phaseOne.Responses[8].kind -ceq 'discard' -and $phaseOne.Responses[9].kind -ceq 'discard') "caller=$($phaseOne.Responses[8].kind); helper=$($phaseOne.Responses[9].kind)"
    Assert-TestBatch $phaseOne.Responses[10] 149 'library-eligible test batch passed'
    Assert-WordSet $phaseOne.Responses[11] $libraryNames 'candidate' @() 'library candidates before commit'
    Assert-Check 'library commit passed the runtime gate' ($phaseOne.Responses[12].kind -ceq 'commit') "kind=$($phaseOne.Responses[12].kind); text=$($phaseOne.Responses[12].text)"
    Assert-WordSet $phaseOne.Responses[13] $libraryNames 'persistent' $libraryNames 'committed library inventory'

    $phaseTwoRequests = @(
        [ordered]@{ op = 'define'; frontend = 'flow'; source = [string]$projectOnlySource.source },
        [ordered]@{ op = 'test-all' },
        [ordered]@{ op = 'commit-word'; word = 'email.apply-delivery-result'; library = $false },
        [ordered]@{ op = 'words' }
    )
    $phaseTwo = Invoke-CliPhase 'restore-project-maturity' $phaseTwoRequests
    Assert-Check 'restore-project-maturity CLI process completed' $phaseTwo.Successful ($phaseTwo.Record | ConvertTo-Json -Compress -Depth 10)
    Assert-Check 'project-only Flow source was restored' ($phaseTwo.Responses[0].kind -ceq 'defined') "kind=$($phaseTwo.Responses[0].kind); text=$($phaseTwo.Responses[0].text)"
    Assert-TestBatch $phaseTwo.Responses[1] 154 'restored full source test batch passed'
    Assert-Check 'project maturity commit passed the runtime gate' ($phaseTwo.Responses[2].kind -ceq 'commit') "kind=$($phaseTwo.Responses[2].kind); text=$($phaseTwo.Responses[2].text)"
    Assert-WordSet $phaseTwo.Responses[3] $expectedNames 'persistent' $libraryNames 'final initialized inventory'

    $reloadRequests = [Collections.Generic.List[object]]::new()
    $reloadRequests.Add([ordered]@{ op = 'words' })
    $reloadRequests.Add([ordered]@{ op = 'test-all' })
    $describeIndexes = @{}
    foreach ($name in $expectedNames) {
        $describeIndexes[$name] = $reloadRequests.Count
        $reloadRequests.Add([ordered]@{ op = 'describe'; word = $name })
    }
    $typeSourceIndexes = @{}
    foreach ($name in $typeNames) {
        $typeSourceIndexes[$name] = $reloadRequests.Count
        $reloadRequests.Add([ordered]@{ op = 'source'; type = $name })
    }
    $freshReload = Invoke-CliPhase 'fresh-reload' $reloadRequests.ToArray()
    Assert-Check 'fresh reload CLI process completed' $freshReload.Successful ($freshReload.Record | ConvertTo-Json -Compress -Depth 10)
    Assert-WordSet $freshReload.Responses[0] $expectedNames 'persistent' $libraryNames 'fresh-process word and maturity inventory'
    Assert-TestBatch $freshReload.Responses[1] 154 'fresh-process test batch passed'
    foreach ($name in $expectedNames) {
        $description = $freshReload.Responses[$describeIndexes[$name]].data
        $expectedTests = @($testNames | Where-Object { $_.StartsWith($name + '/', [StringComparison]::Ordinal) } | ForEach-Object { $_.Substring($name.Length + 1) } | Sort-Object -CaseSensitive)
        $actualTests = @($description.tests | ForEach-Object { [string]$_ } | Sort-Object -CaseSensitive)
        $expectedExamples = @($exampleNames | Where-Object { $_.StartsWith($name + '/', [StringComparison]::Ordinal) } | ForEach-Object { $_.Substring($name.Length + 1) } | Sort-Object -CaseSensitive)
        $actualExamples = @($description.examples | ForEach-Object { [string]$_ } | Sort-Object -CaseSensitive)
        Assert-Check "fresh source declaration $name" ($description.kind -ceq 'word') "kind=$($description.kind)"
        Assert-Check "fresh attached tests $name" (Same-Names $actualTests $expectedTests) "expected=$($expectedTests.Count); actual=$($actualTests.Count)"
        Assert-Check "fresh attached examples $name" (Same-Names $actualExamples $expectedExamples) "expected=$($expectedExamples.Count); actual=$($actualExamples.Count)"
    }
    $durableTestCount = @($expectedNames | ForEach-Object { [int]$freshReload.Responses[$describeIndexes[$_]].data.testCount } | Measure-Object -Sum).Sum
    $durableExampleCount = @($expectedNames | ForEach-Object { [int]$freshReload.Responses[$describeIndexes[$_]].data.exampleCount } | Measure-Object -Sum).Sum
    Assert-Check 'fresh attachment totals' ($durableTestCount -eq 154 -and $durableExampleCount -eq 44) "tests=$durableTestCount; examples=$durableExampleCount"
    foreach ($name in $typeNames) {
        $response = $freshReload.Responses[$typeSourceIndexes[$name]]
        Assert-Check "fresh persisted type source $name" ($response.kind -ceq 'source') "kind=$($response.kind); text=$($response.text)"
    }

    $sourceInventoryAfter = @($inputPaths | ForEach-Object {
        [ordered]@{ path = [IO.Path]::GetRelativePath($repoRoot, $_).Replace('\', '/'); bytes = [int64](Get-Item -LiteralPath $_).Length; sha256 = Get-Sha256 $_ }
    })
    $runtimeInventoryAfter = Get-Inventory $runtimeRoot
    $sourceSame = (ConvertTo-Json -InputObject $sourceInventoryBefore -Depth 100 -Compress) -ceq (ConvertTo-Json -InputObject $sourceInventoryAfter -Depth 100 -Compress)
    $runtimeSame = (ConvertTo-Json -InputObject $runtimeInventoryBefore -Depth 100 -Compress) -ceq (ConvertTo-Json -InputObject $runtimeInventoryAfter -Depth 100 -Compress)
    Assert-Check 'fixture sources unchanged' $sourceSame "before=$($sourceInventoryBefore.Count); after=$($sourceInventoryAfter.Count)"
    Assert-Check 'fresh CLI runtime unchanged' $runtimeSame "before=$($runtimeInventoryBefore.Count); after=$($runtimeInventoryAfter.Count)"
    $projectInventory = Get-Inventory $projectRoot
    $cliRecordAfter = [ordered]@{ cliSha256 = Get-Sha256 $CliDll; coreSha256 = Get-Sha256 $coreDll; runtimeFileCount = $runtimeInventoryAfter.Count; runtimeFiles = $runtimeInventoryAfter }
    Write-JsonFile (Join-Path $runRoot 'inputs-and-runtime-after.json') ([ordered]@{ sources = $sourceInventoryAfter; runtime = $cliRecordAfter })
    $status = 'prepared-and-fresh-reload-verified'
}
catch {
    $failure = $_.Exception.ToString()
    $status = 'failed'
    try {
        if ($sourceInventoryBefore.Count -gt 0) {
            $sourceInventoryAfter = @($inputPaths | ForEach-Object {
                [ordered]@{ path = [IO.Path]::GetRelativePath($repoRoot, $_).Replace('\', '/'); bytes = [int64](Get-Item -LiteralPath $_).Length; sha256 = Get-Sha256 $_ }
            })
        }
        if ($runtimeInventoryBefore.Count -gt 0) { $runtimeInventoryAfter = Get-Inventory (Split-Path -Parent $CliDll) }
        if (Test-Path -LiteralPath $projectRoot -PathType Container) { $projectInventory = Get-Inventory $projectRoot }
        if ($sourceInventoryAfter.Count -gt 0 -and $runtimeInventoryAfter.Count -gt 0) {
            Write-JsonFile (Join-Path $runRoot 'inputs-and-runtime-after.json') ([ordered]@{
                sources = $sourceInventoryAfter
                runtime = [ordered]@{ cliSha256 = Get-Sha256 $CliDll; coreSha256 = Get-Sha256 $coreDll; runtimeFileCount = $runtimeInventoryAfter.Count; runtimeFiles = $runtimeInventoryAfter }
            })
        }
    }
    catch { $failure += "`nAfter-state inventory error: $($_.Exception.Message)" }
}

$summary = [ordered]@{
    schemaVersion = 1
    runId = $RunId
    status = $status
    startedWithFreshCli = $CliDll
    project = $projectRoot
    preparationEvidence = $runRoot
    sourceCounts = [ordered]@{ words = $expectedNames.Count; types = $typeNames.Count; tests = $testNames.Count; examples = $exampleNames.Count; libraryWords = $libraryNames.Count; projectWords = $projectOnlyNames.Count }
    checks = @($checks)
    sourceInventoryBefore = $sourceInventoryBefore
    sourceInventoryAfter = $sourceInventoryAfter
    runtimeInventoryBefore = $runtimeInventoryBefore
    runtimeInventoryAfter = $runtimeInventoryAfter
    projectInventory = $projectInventory
    failure = $failure
}
if (Test-Path -LiteralPath $runRoot -PathType Container) {
    Write-JsonFile (Join-Path $runRoot 'summary.json') $summary
}
if ($status -ne 'prepared-and-fresh-reload-verified') {
    Write-Error "Business base preparation failed. Evidence: $runRoot"
    exit 1
}
Write-Output "Prepared and reloaded the business base: $projectRoot"
Write-Output "Evidence: $(Join-Path $runRoot 'summary.json')"

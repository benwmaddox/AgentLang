Implemented and committed customer.paid-total(store, customer-id) and its fold helper. Both are persistent library functions. The operation verifies the customer first, sums only payments linked to that customer invoices with checked money.add, returns zero when no payments match, and preserves an earlier overflow error.

The implementation reuses store.customer, store.invoice, store.payments, and money.add. Four tests cover the public operation; five cover the helper, including a clearly labeled defensive missing-invoice case.

Validation: test-all passed 163/163 after commit. Coverage was complete for both functions. task.commit succeeded, and the broker exited successfully after host.close.

During authoring, initial Flow match syntax and one early library-commit attempt were rejected; I corrected the syntax, added the helper tests, and both library commits then passed. Two exploratory probes also returned errors (() as a Unit value and Invoice.new); neither affected the implementation.

# Build attempt provenance

The prescribed command was run five times against the reference project while
the adapter was being implemented:

1. Failed with F# syntax errors, initially caused by using the reserved field
   name `to`; the compiler also reported parser-cascade errors.
2. Failed with F# type-inference/overload errors, a record-nullability error,
   and an unresolved `UTF8Encoding` name.
3. Succeeded with exit code 0 and zero warnings after those compile errors were
   fixed.
4. Succeeded with exit code 0 and zero warnings after embedding each case's
   oracle expectation in the output.
5. Succeeded with exit code 0 and zero warnings for the final adapter, including
   recipe-derived count checks.

The stdout/stderr capture files in this directory are from attempt 5 only. The
two failed attempts' separate raw stdout/stderr files were overwritten by later
builds and were not retained as files. Their compiler diagnostics remain in the
tool-result transcript for this task; this note summarizes them and does not
recreate or claim to preserve the raw logs. The final `build.exit-code.txt`,
`build.stdout.txt`, and `build.stderr.txt` describe only the successful final
build.

`input-hashes.json` records the plan and oracle hashes at the time of the final
fixture run. The plan was revised afterward to clarify comparison naming; the
oracle hash and its 13 cases were unchanged, and the adapter consumes
`oracle.json` rather than `plan.md`.

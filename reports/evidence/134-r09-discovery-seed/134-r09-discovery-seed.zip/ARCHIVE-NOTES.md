# R09 accepted seed archive

This archive preserves the accepted seed-only run and the evidence needed to inspect or reproduce its scoring. It is not the later main comparison and must not be treated as comparison readiness.

The seed project, base-001 failed initialization state, base-002 successful initializer/fresh-reload evidence, control projects, control score reports, all completed scorer attempts, scorer source, oracle, reference fixtures and build/run captures, frozen and actually dispatched prompts, prompt diff, broker dispatch/trace, acceptance reports, and actor final response are included. The experiment source snapshot includes plan, oracle, reference source, scoring source, seed task, and seed dispatch; active conventional/flow-start source directories are intentionally excluded.

The frozen input manifest remains unchanged and still has the original prepared-awaiting-approval label. Dispatch/finalization is documented separately. Frozen prompt SHA-256 is 007a55de299f4ec8e2d7fc1ec50a8b552af4915550261bc5ed96706d0bfdbdd8; actual dispatched prompt SHA-256 is 7ad181e65bd8cfd0322e57322f2c652c116d47b93c6428540e99ca3d3367bbca. The actual prompt omitted the read-only transitive-callers allowlist entry. This is retained as a protocol deviation; no restart or coaching was performed.

The acceptance report qualifies functional seed behavior separately from exact prompt adherence and literal style adherence. Main comparison remains not ready.

The reference build provenance note records that the first two failed build attempts' raw stdout/stderr files were overwritten by later attempts and were not retained. Their diagnostics are summarized there; this archive does not reconstruct those missing logs. The final successful build logs and fixture run output are included.

The runtime pin preserves 22 runtime artifact hashes and 25 source hashes. The runtime and reference compiled binaries, build caches, and any bin/obj/artifacts directories are excluded. Runtime/host source snapshots are included so hashes and invocation boundaries can be audited without shipping compiled outputs.

All copied payload entries are listed with byte counts and SHA-256 in ARCHIVE-MANIFEST.json. SHA-256 of that manifest is recorded in the external storage index.

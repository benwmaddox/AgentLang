#!/usr/bin/env python3
"""Seal report-282 evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
HERE = REPO / ".agentlang" / "linux-sweep-282"
OUT = REPO / "reports" / "evidence" / "282-linux-concurrency-sweep"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|secret|cookie\.txt$|\.env$|labels\.json$)")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(_: Path) -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    for name in ("PLAN.md", "sweep-lifetime.sh", "run-sweep.sh", "cleanup-native.sh", "aggregate.py", "aggregate-s1.json",
                 "aggregate-s1.md", "sweep-s1.log", "s1-console.log", "contamination-screen.txt", "flowbin.txt", "seal_282.py"):
        items.append((HERE / name, f"tools/{name}" if name.endswith((".sh", ".py")) else name))
    items.append((REPO / ".agentlang" / "lang-281" / "secret_scan.py", "tools/secret_scan.py"))
    for f in sorted((HERE / "runs").glob("*/*")):
        if f.is_file() and (f.name != "server.log" or f.stat().st_size < 1_000_000):
            items.append((f, f"runs/{f.parent.name}/{f.name}"))
    return items


def main() -> int:
    gates = HERE
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries, blobs = [], {}
    for path, arc in collect(gates):
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) and path.name not in ("server-log-secret-scan.txt", "secret_scan.py"):  # holds a hit count only
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "agentlang-evidence-v1", "report": "282", "entries": entries}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "282-linux-concurrency-sweep-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        if set(zf.namelist()) != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

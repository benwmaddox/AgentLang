# Flow/2 trial primer

The trial host accepts one JSON request per input line and returns one JSON response. AI agents are external users of this runtime. Use the runtime API only; the host does not grant source-file editing.

Start with compact discovery (`words`, `search`), then inspect selected functions with `describe`, `source`, `dependencies`, `tests`, and `context`. Function documentation and examples are attached to their owners. Help is versioned: request, for example, `{"op":"help","topic":"replacement","syntaxVersion":2}`. Use Flow syntax version 2 in authoring requests.

Flow/2 declarations use `fn`; immutable named bindings use `let`; record fields use plain property syntax such as `state.first`; named arguments use `name = value`; equality uses `==`. Function declarations support `doc "..."`; omitted effects default to none. Leave a blank line between documentation and implementation code.

Tests are attached to a function as `test function.name/case-name { ... }`. A test evaluates its actual expression and then states `=> literal`, `=> value expression`, or `=> error CODE`. Value expressions are evaluated separately from the actual function call. Run `test` for focused feedback and `test-all` for the project suite. Inspect coverage after a test run.

New definitions are staged with `define`; see versioned help for replacement and publication fields. A committed function can be changed by staging a revision-bound replacement, testing it, and calling `replace-word`. Library publication adds qualification checks. Use `task.begin`, inspect the task log/status as you work, and finish with `task.commit` or `task.abort`.

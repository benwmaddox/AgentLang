# Actor broker launch

Run the exact command in `actor-launch.ps1.txt` in an interactive terminal. It starts the existing V2 JSONL host with the pinned Debug CLI, a fresh project copy, no external capabilities, and an actor-specific trace path. Keep the terminal open while the subagent exchanges one JSON request per line. End the broker with the transport control `{"op":"host.close"}` after the task is complete. That control is handled by the host and is not in the runtime operation allowlist.

This is a launch recipe only. It has not been run with an actor prompt.

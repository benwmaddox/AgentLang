# Syntax probes during preparation

These errors were encountered while checking the pinned Flow/2 parser. They are retained here for audit and are not included in the actor primer.

1. A `word` declaration under `syntaxVersion: 2` returned `FLOW_SYNTAX_VERSION`: Flow/2 requires `fn`.
2. A test expectation for a constructor expression written directly after `=>` returned `FLOW_EXPECTATION_LITERAL_REQUIRED`; expression expectations require `=> value <expression>`.
3. `Selection::new` returned `FLOW_UNKNOWN_CALL`; the generated constructor name is `selection::new`. The accepted source was verified by a successful define and four passing tests.

The canonical seed uses Flow/2, `fn`, plain `.first` property access, `selection::new`, and `=> value` only for expected expressions.

# Finite coverage adoption trial preparation plan

Status: preparation in progress; no actor has been dispatched.

## Objective

Prepare a small, reproducible fresh-subagent trial at the current finite-coverage implementation. Measure whether an agent can discover and respond to finite return-coverage diagnostics while preserving function signatures and behavior. This preparation does not claim an efficacy result.

## Scope and ownership

All created artifacts stay under `.agentlang/finite-adoption-001/`. Pin a fresh isolated Debug CLI build of source commit `a81a7aad74119f48d52f851e629d96f702ffda5d`; do not write to frozen Release/runtime locations, repository source, reports, or unrelated retention artifacts. Reuse `scripts/Start-SubagentTrialHostV2.ps1`. Do not dispatch an actor, commit, or push.

## Seed design

Prepare a project with two Flow/2 project functions and minimal attached tests:

1. `flags.agree(left: Bool, right: Bool) -> Bool`, preserving equality behavior. Seed tests call only `(true, true)` and `(false, false)`. Both Bool input parameters and the true return are observed; the false return is not.
2. `selection.accept(state: Selection, item: Int) -> Selection`, where `Selection` has one `first: Option<Int>` field. The function returns the existing state when `first` is already Some, otherwise returns a state containing Some(item). Tests execute both branches; None is unreachable as a function result despite being allowed by the declared record type.

Keep both at project maturity. Seed tests pass. Promotion of `flags.agree` must fail only for its missing false return. Promotion of `selection.accept` must fail only for its missing None return. Each failed promotion must leave durable state unchanged.

## Preparation and checks

1. Save this plan before modifying other trial artifacts.
2. Build the CLI to an isolated Debug artifacts/output directory from the pinned source and record source revision, CLI hash, file inventory, command and build log.
3. Use the existing parser/runtime authoring interfaces to create and reload the minimal seed; verify exact signatures, tests, project maturity, and source/manifest hashes.
4. Run the seed tests, then perform both promotion preflights and capture structured diagnostics plus before/after durable-state hashes.
5. Copy the prepared project into a fresh actor directory. Write a compact Flow/2 primer and task prompt that advertises versioned help and asks the agent to make as many functions library-ready as current requirements honestly permit, adding useful regression tests while preserving signatures and behavior. Do not tell it which values or return cases are missing.
6. Save the exact harness launch command, allowed operations, runtime pin, prompt hash and protocol preflight log. Confirm the protocol can start and answer a harmless help/inspection request; do not send the actor task.

## Acceptance

All files remain scoped to `.agentlang/finite-adoption-001/preparation`, `runtime`, `seed` or `project` prep artifacts. Seed project loads from disk; both initial tests pass; both promotion refusals name the expected missing return value and do not modify durable files. Fresh isolated CLI identity is verified. Existing harness starts with pinned CLI and copied actor project. Prompt and primer make no explicit finite-coverage answer leaks. Root coordinator receives artifact paths, signatures, diagnostic evidence, and the launch command for independent oracle review and later dispatch.

## Preparation result

Fresh Debug CLI build, seed tests, both expected atomic promotion refusals, actor-project copy, versioned-help host preflight and runtime/source hashes are recorded under this directory. See preflight-summary.md and preflight-summary.json. No actor was dispatched.


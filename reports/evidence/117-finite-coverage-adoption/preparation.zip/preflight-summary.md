# Finite library coverage adoption trial: prepared inputs

Status: prepared for coordinator review; no actor has been dispatched and no efficacy result exists.

The fresh isolated Debug CLI was built from source revision `a81a7aad74119f48d52f851e629d96f702ffda5d`. Its complete output-directory file inventory and SHA-256 pins are in `runtime/runtime-pin.json`; no Release runtime was rebuilt or touched. The existing `scripts/Start-SubagentTrialHostV2.ps1` successfully started that runtime against the copied actor project and served versioned Flow/2 authoring and replacement help plus a compact word inventory. The protocol trace and exact responses are retained under `runtime/`.

The seed contains two project functions: `flags.agree(left: Bool, right: Bool) -> Bool`, with two same-value cases, and `selection.accept(state: Selection, item: Int) -> Selection`, using `Selection { first: Option<Int> }`, with tests for both match branches. Both signatures and behavior remain unchanged. All four seed tests pass.

Separate revision-bound replacement preflights passed both attached tests for each target and refused library publication. The Boolean diagnostic's sole missing value is `return[0] Bool: false`; the selection diagnostic's sole missing value is `return[0] Selection: $.first: none`. The project tree hash was identical before and after both refusals. Both remain at project maturity in the untouched seed and actor copy.

The compact primer advertises versioned help and Flow/2 `fn` syntax. The actor prompt asks for library readiness and useful regression tests without stating which values are missing or identifying any hidden mutations. The interactive actor launch command is saved separately from the finite protocol preflight command. No actor has been dispatched.

# Campfire room and message Flow slice

## Scope and source pins

Author only `applications/campfire/room-message.flow`,
`applications/campfire/room-message-tests.flow`, and private validation notes in
this directory. The Rails reference is pinned at
`90b330024dec3e757c79b6a7e6568f93da8e3148`; the Rust repository is pinned at
`6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad`.

Rails `reference/app/controllers/concerns/room_scoped.rb` and Rust
`crates/campfire/src/concerns.rs::set_room` look up the authenticated user's
room membership before message actions. Neither provides an administrator
bypass. Per-user room pages are membership-scoped too (`Room::find_for_user`
and `user.rooms`). The HTTP layer later maps missing membership to the
upstream not-found behavior; this Flow slice returns an internal
`access-denied` case and does not claim to implement sessions, HTTP status, or
not-found rendering.

## Flow and registered host contract

Reuse `UserId` from `message-policy.flow`. Define nominal `RoomId` and
`MessageId`, closed `RoomKind` (`open`, `closed`, `direct`) and `DbError`
(`unavailable`, `not-found`, `constraint-conflict`, `invalid-input`), plus
`RoomRow`, `MembershipKey`, `MessageRow`, and `NewMessage` records matching
the typed persistence DTOs. Preserve optional message body and string
timestamps. Constructors for record values use the generated lower-camel
spelling (`membershipKey.new`, `newMessage.new`).

The four registered operations and signatures are fixed:

```text
campfire.rooms.page-for-user(UserId, Option<RoomId>, Int)
  -> Result<List<RoomRow>, DbError> effects { db.read }
campfire.membership.exists?(MembershipKey)
  -> Result<Bool, DbError> effects { db.read }
campfire.messages.last-page(RoomId)
  -> Result<List<MessageRow>, DbError> effects { db.read }
campfire.messages.create(NewMessage)
  -> Result<MessageRow, DbError> effects { db.write, clock.read }
```

`campfire.rooms.list-for-user` delegates to the membership-scoped page query
and preserves its `DbError` result. Message listing confirms membership before
reading the last page. Message creation confirms membership before writing and
sets `creator-id` from the supplied caller ID; there is no
request-controlled creator field or additional content validation. Message
wrappers distinguish `access-denied` from all four mapped database errors.
The `UserId` parameter represents an already authenticated caller at this
layer; HTTP/session establishment is future work.

## Scoped tests and current validation

`room-message-tests.flow` replaces host operations in three isolated test
files. It covers page variants and provider errors, all membership outcomes,
member and non-member page/create behavior, create errors, absent and empty
bodies, and the caller-derived creator. Distinct fixture outputs make an
unexpected downstream call visible on denied paths. Each attached test asserts
zero `db.read`, `db.write`, and `clock.read` provider effects because scoped
replacement operations do not invoke the real adapter. The new Core effect
assertion implementation supports the `db.*` categories; the prior installed
Release DLL does not, so the syntax-only parser check removes those assertion
lines from an in-memory copy and does not modify authored source.

Current syntax-only command (not a typecheck or execution):

```powershell
dotnet fsi --exec .agentlang/campfire-host-236/application/parse-only.fsx
```

After the host-operation bridge is integrated and a coherent Core Release build
is available, typecheck and execute these attached tests with the focused
Campfire verifier. Real SQLite nonzero read/write/clock assertions and the
denied-zero-write proof belong to integration tests against the registered
adapter; scoped replacement assertions are not presented as that evidence.

## Registered host adapter and integration stage

`applications/campfire/Host/` owns the strict `Value`/DTO adapter and the
closed four-operation manifest. The adapter accepts an explicit host-selected
database path and injected clock, opens only an existing database, converts
the declared nominal/record/enum shapes, and delegates only to the four fixed
Persistence methods. Provider contract failures stay host-boundary failures;
the four `DbError` cases remain declared Flow values. Production-provider
ownership stays with the host.

`tests/AgentLang.Campfire.Integration.Tests/` is a focused console integration
executable. It verifies adapter shape conversion; runs scoped policy and
wrapper tests with zero real-provider calls through qualification and fresh
reload; then runs ten real SQLite cases with one lazy test provider per case,
exact database/clock effect counts, membership-denial short-circuit checks,
typed persistence errors, transaction rollback, and a fresh-provider Flow
read of a persisted message. Its attached real-provider Flow fixtures are
tracked beside the executable at `tests/AgentLang.Campfire.Integration.Tests/
real-provider-tests.flow`. The real databases use a narrow test schema based
on the prior Persistence tests; they do not claim full migration parity.

The old-Core syntax-only pass (parser only, not typecheck or execution) is:

```powershell
dotnet fsi --exec .agentlang/campfire-host-236/application/host-parse-only.fsx
```

Wait for the Core owner to announce a coherent build before running the
integration project. The intended focused command is:

```powershell
dotnet run --project tests/AgentLang.Campfire.Integration.Tests/AgentLang.Campfire.Integration.Tests.fsproj --configuration Release
```

Retain integration output and provider fixture databases under
`.agentlang/campfire-host-236/application/runtime/`. HTTP/session handling,
sanitization/rendering, websocket broadcast, unread state, and full database
migration parity remain outside this stage.

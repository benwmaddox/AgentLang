# Campfire 236 application boundary review

Read-only review of `CampfireHost.fs`, `room-message.flow`, the integration executable and its attached real-provider tests, plus the available run receipts. No build or test execution was performed by this review.

## Boundary condition: authorization lives in the trusted Flow composition

`applications/campfire/Host/CampfireHost.fs:32-44,150-155` registers `campfire.messages.last-page(RoomId)` and `campfire.messages.create(NewMessage)` as direct persistence operations. Dispatch does not check membership or bind a create's `creator-id`; that field is accepted from the exact typed `NewMessage` record (`:94-99`). The Flow wrapper performs the intended membership check before read/write and constructs `creator-id` from its `user-id` argument (`applications/campfire/room-message.flow:8-38,41-77`).

Per the stated architecture, this host is a trusted composition boundary and the future HTTP layer will expose only fixed wrappers, not arbitrary evaluation. Under that design this source review does **not** establish a public bypass. It does establish that row authorization is a Flow-wrapper policy, not an invariant of the raw registered host operations; the composition must keep those raw operations out of untrusted entry points. The scoped tests verify wrapper short-circuiting, but do not claim that host-operation capability/effect checks enforce row membership. The reviewed API also accepts `user-id` as a parameter and has no authenticated principal/session binding; that remains part of the pending HTTP/auth integration.

## Test evidence

The first-pass receipt `.agentlang/campfire-host-236/application/integration-run-first-pass.log` alone predates the current `Program.fs`. The newer `.agentlang/campfire-host-236/root-combined-repeat/receipt.json` resolves that gap: it records a successful integration run (`test-integration` exit code 0, 347 assertions; run started 2026-10-11 22:51:32 UTC) and pins the current source. I independently recomputed the SHA256 hashes; the receipt pins match current files exactly:

- `Program.fs`: `d45b1913ce562577063d13134448eff9bd75a269930c13a0d9d7a531e419f10f`
- `real-provider-tests.flow`: `f838f55ac92634a85f303211c8ee5d006eee206d335bd875686f0c6faf0a1439`
- `CampfireHost.fs`: `9e23a8256b944e0d5d2cd97852723e34dab9631f5e8b69267db60a58b67c6ddf`
- `room-message.flow`: `320eb71f57cbfd71331de3baa145ea227b40097f287f3711e81b4910cb468874`

The matching integration log reads `PASS Campfire Host integration: 347 assertions`. `.agentlang/campfire-host-236/root-focused/integration-second-repeat.log` records the same assertion count as a second repeat.

## What the reviewed tests establish

- Scoped attached tests leave both the production sentinel and provider factory unused (`Program.fs:180-200,229-235`). Real-provider cases receive a fresh seeded SQLite file from the per-test factory (`:323-337`); assertions check ten distinct fixture paths and one disposal per provider (`:426-460`).
- Attached cases assert member success, nonmember short-circuit, missing-room behavior, create results, and per-case effect counts (`real-provider-tests.flow:37-117`; `Program.fs:440-482`). The adapter contract test also checks malformed nominal input rejection, unknown operation rejection, and typed page/membership results (`Program.fs:339-379`).
- Trigger and uniqueness failures are followed by direct SQLite checks for absent message/body writes and unchanged room timestamps. A bodyless success is checked after its provider scope closes and read back through a fresh provider and engine (`Program.fs:484-496,499-561`).
- Normal evaluation uses an explicitly supplied fixture-backed provider, does not fall back to the test factory, and leaves disposal to the host owner (`Program.fs:563-609`). This is provider-slot lifecycle evidence, not a production deployment/database run.

The `body` field in this slice is an optional raw string persisted to the ActionText table. The tests do not establish Rails rich-text rendering/sanitization, HTTP route behavior, session authentication, or native-provider support; those are outside this slice.
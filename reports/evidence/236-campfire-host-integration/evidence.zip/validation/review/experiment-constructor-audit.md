# Experiment constructor audit

The active mailbox/native experiment projects reference the current `src/AgentLang.Core` and `src/AgentLang.Llvm` projects directly. They do not pin a separate runtime. Only `AgentLang.OwningMailbox` is listed in `AgentLang.sln`; the three other projects are buildable from their own `.fsproj` files but are outside the solution gate.

Updated the fresh no-host adapters in these program files:

- `experiments/AgentLang.NativeMailbox/Program.fs`: compiler context uses `HostOperations = Map.empty`; interpreter adapter returns `Error HostOperationFailure.MissingHandler` if a host operation is unexpectedly called.
- `experiments/AgentLang.NativeDispatch/Program.fs`: compiler context uses `HostOperations = Map.empty`.
- `experiments/AgentLang.NativeValueStack/Program.fs`: all three fresh compiler contexts use `HostOperations = Map.empty`; the no-op interpreter adapter returns `Error HostOperationFailure.MissingHandler`.
- `experiments/AgentLang.OwningMailbox/Program.fs`: the preceding solution-gate fix adds the same empty manifest and missing-handler behavior to its compiler context and both interpreter adapters.

Existing context record updates inherit their host manifest, and interpreter-host updates inherit their callback. No experiment behavior was added.

Standalone Release builds passed with zero warnings and zero errors, using `--no-restore -m:1 -p:BuildProjectReferences=false -p:MSBuildEnableWorkloadResolver=false` after the referenced Core/LLVM outputs were built:

- NativeMailbox: `.agentlang/campfire-host-236/experiment-builds/logs/AgentLang.NativeMailbox-build.log`
- NativeDispatch: `.agentlang/campfire-host-236/experiment-builds/logs/AgentLang.NativeDispatch-build.log`
- NativeValueStack: `.agentlang/campfire-host-236/experiment-builds/logs/AgentLang.NativeValueStack-build.log`

Initial sandbox restores for NativeMailbox and NativeDispatch failed with audit-enabled NU1900 because the NuGet vulnerability endpoint was unreachable; those failed logs are preserved beside the build logs. The root then completed audit-enabled host restores (`root-NativeMailbox-host-restore.log` and `root-NativeDispatch-host-restore.log`), after which both `--no-restore` builds passed. No experiment executable was run; this change only closes no-host record adapters. Scoped `git diff --check` passed for the three edited source files.

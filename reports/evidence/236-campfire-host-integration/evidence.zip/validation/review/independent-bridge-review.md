# Independent typed host-operation bridge review

Source review only, on the requested bridge files and adjacent storage/native paths. No builds or tests were run, so this records code evidence rather than runtime validation. The Core implementation was still in progress during review.

## Confirmed issue

**Stack-authored calls can silently rebind to a different registered host-operation ID after reload.** `Runtime.fs:686-688` merges every registered operation into the effective word map, and `Compiler.fs:1112-1119` lowers such a word to `HostOperationTarget operationId`. The Stack-only snapshot compiles through that same context at `Runtime.fs:2036-2041`. On reload, Stack revisions are parsed and added as Stack definitions (`Runtime.fs:2520-2523, 2560-2568`), then recompiled against the current Engine host manifest; the retained-binding comparison at `Runtime.fs:1896-1940` is applied to Flow-authored sources. Storage rejects call-binding metadata on Stack revisions (`Storage.fs:1089-1090`), so no old host-operation ID is available for the Stack path to compare.

Concrete consequence: a project containing Stack source that calls host word `db.lookup` can be reopened under an Engine manifest that retains `db.lookup` with a compatible signature but assigns it a different `HostOperationId`; the unchanged Stack source resolves to the new ID. This is separate from the current Campfire Flow/2 source, whose call bindings do retain host IDs. The narrow mitigation is to reject Stack-authored host-operation calls until Stack call targets have durable identity metadata, or to add and verify such metadata for Stack revisions.

## Confirmed paths that behaved as intended in source

- Effect preflight occurs before test dispatch: `IrInterpreter.fs:733` calls `PreflightEffects` before consulting `testDispatch`; runtime selects test capabilities for test traces at `Runtime.fs:2221-2230`. The test-file override therefore cannot avoid the original call's capability check.
- Test providers are lazy, scoped per `checkedByTest` invocation, and disposed in that scope (`Runtime.fs:171-202, 2875`). A test trace without a provider returns `TestProviderUnavailable`, not the production provider (`Runtime.fs:2287-2299`). Production-provider disposal belongs to its creator by explicit contract (`Core.fs:195-204`).
- Flow host-call bindings retain the exact target ID and are compared on load (`FlowPersistence.fs:12-14`; `Runtime.fs:1896-1940`). A Stack wrapper that calls a Flow wrapper does not bypass that Flow wrapper's own retained host binding: the Flow owner is rechecked before the snapshot is activated.
- The Stack route does not replace Flow-owned definitions or attach Stack cases to them: `registerParsed` rejects both at `Runtime.fs:3499-3510`. Publication also rejects Flow owners with retained Stack tests/examples (`Runtime.fs:1346-1353`). I found no Stack define/commit path that overwrites the Flow attachments.
- Native code rejects verified programs with host catalogs explicitly: `TypedIR.fs:286-290`, `LlvmAot.fs:924-930` (also reachable validation at line 635), and `OwningStackAot.fs:720-730`.

## Questions / acceptance gaps

- I found no host-operation-specific LLVM/native rejection test in the runtime test sources. The rejection path is explicit in source, but a focused test should assert the diagnostic for both native routes.
- `Compiler.hostCatalogForContext` copies the full context manifest (`Compiler.fs:1022-1031`), while `requireNoHostOperations` rejects any nonempty host catalog (`TypedIR.fs:286-290`). Consequently, native compilation also rejects a program that was compiled with a registered provider manifest but contains no host-operation call. This may be the intended Engine-level boundary; if native support is meant to depend on actual program use, the retained catalog should distinguish available contracts from referenced operations.
- The current persisted Flow test changes an input type and observes ordinary type-check failure (`tests/AgentLang.Flow.Runtime.Tests/Program.fs:7375-7388`). It does not specifically change only the operation ID while retaining the name/signature; the structural binding comparison appears to reject that case, but a focused reload test would make the durable-identity requirement explicit.
- I found no test-file override case proving that a host operation's original capability preflight remains active while its provider stays unconstructed. The order in `IrInterpreter.invokeResolved` supports that behavior; a focused test would cover the interaction.

## Scope limit

This is a bounded static review. It does not report on the known scalar-payload import issue, and it does not claim any build/test result or broader security guarantee.
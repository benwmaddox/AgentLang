# Flow2 payload-binding verifier mismatch

## Observed run

The focused evidence is `implementation/flow-build-final-02.log` (Flow.Tests build succeeded) followed by `implementation/flow-run-final-01.log` (execution failed while compiling `flow2.payload-binding`). The failure is `IR_BLOCK_ENTRY_MISMATCH` from `TypedIR.fs:815`, attributed to the match expression at `Program.fs:1012–1018`. The exception prints `Expected = []` and `Actual = []` because that diagnostic reports only stack types.

## Cause and shapes

`verifyBlockNested` at `TypedIR.fs:813–815` compares the complete `IrShape`, including both `StackTypes` and `LocalTypes`. The Option verifier at `TypedIR.fs:705–708` constructs the two correct incoming shapes:

- Some arm: stack `[]`; outer locals plus the new Some payload slot typed `Int`.
- None arm: stack `[]`; outer locals only. In this reproducer there are no outer locals, so its local map is empty.

It then passes `someEntry` to both calls to `verifyBlockNested`. The second call should pass `noneEntry`. Consequently, the verifier expects the Some payload local in the None block, while the compiler-built None block does not contain it. The stacks are equal and empty, but the local maps differ, which explains the apparently empty Expected/Actual diagnostic.

The lowering agrees with the intended branch scopes: `Compiler.fs:1410–1415` lowers the Some body using `someEnv` and the None body using outer `env`. `FlowLowering.fs:1091–1098` likewise adds the payload to only the Some lexical environment. `FlowParser.fs:685` constructs the `MatchOption` AST; the mismatch occurs later in verifier expectation construction.

The smallest correction is to change only the second `verifyBlockNested` argument at `TypedIR.fs:708` from `someEntry` to `noneEntry`. This preserves the full entry-shape check and payload non-escape rule.

## Regression status and test

Root confirmed the matched source comparison: accepted HEAD/aab43f3 passes `noneEntry` for the None block, while the failing working source passes `someEntry`. This is a change-induced regression relative to that accepted source. I did not run Git or a build in this investigation.

Keep the existing `flow2.payload-binding` case at `Program.fs:1012–1023`; its compile call is the direct reproducer and its Some-arm call-binding checks are meaningful. The adjacent `flow2.payload-escape` case at lines 1024–1031 should also remain enabled. For a more diagnostic regression assertion, inspect the verified `MatchOption` in `payloadCompiled.Program` and assert that the Some block entry contains its payload slot while the None block entry does not; both branch stacks and outer-local maps should otherwise agree. Do not weaken the IR verifier or skip either case.

No build or runtime validation was performed for this read-only review. The separate `flow-runtime-*-final-*.log` files concern Flow.Runtime tests and do not provide a matched Flow.Tests control for this failure.

#!/usr/bin/env python3
"""Seal report-272 evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
HERE = REPO / ".agentlang" / "lang-272"
OUT = REPO / "reports" / "evidence" / "272-flow-stdlib-loops-browser"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|secret|cookie\.txt$|\.env$|labels\.json$)")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(gates: Path) -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    for f in sorted(gates.glob("*.log")) + [gates / "summary.json"]:
        items.append((f, f"gates/{f.name}"))
    receipts = sorted((REPO / ".agentlang" / "templates-266" / "views-runs").glob("*/receipt.json"))
    for f in receipts[-3:]:
        items.append((f, f"template-receipts/{f.parent.name}.json"))
    for f in sorted((REPO / ".agentlang" / "campfire-native-room-read-252" / "test-runs").glob("*/test-receipt.json"))[-2:]:
        items.append((f, f"room-read-receipts/{f.parent.name}.json"))
    bench = REPO / ".agentlang" / "campfire-bench"
    for run in ("quick-272-lean-ua-1", "quick-272-lean-ua-2", "quick-272-lean-ua-3", "quick-272-lean-ua-4"):
        for name in ("summary.json", "timed.json", "driver.log"):
            items.append((bench / "runs" / run / name, f"bench/{run}/{name}"))
    prof = REPO / ".agentlang" / "campfire-native-profile-256"
    for name in ():
        items.append((prof / name, f"profile/{name}"))
    for name in ("Native-Bench.ps1", "Quick-Bench.ps1", "reference-records.json", "history.jsonl"):
        items.append((bench / name, f"tools/{name}"))
    rerun = sorted(HERE.glob("gates-rerun-*"))[-1]
    for f in sorted(rerun.glob("*.log")) + [rerun / "summary.json"]:
        items.append((f, f"gates-rerun/{f.name}"))
    for f in sorted((REPO / ".agentlang" / "stdlib-272" / "runs").glob("*/receipt.json"))[-2:]:
        items.append((f, f"stdlib-receipts/{f.parent.name}.json"))
    for name in ("Run-Gates.ps1", "seal_272.py"):
        items.append((HERE / name, f"tools/{name}"))
    changed = subprocess.run(["git", "diff", "--name-only", "0d89962"], cwd=REPO, check=True, capture_output=True, text=True).stdout.split()
    untracked = subprocess.run(["git", "ls-files", "--others", "--exclude-standard", "reports/272-flow-stdlib-loops-browser.md"],
                               cwd=REPO, check=True, capture_output=True, text=True).stdout.split()
    for rel in sorted(set(changed) | set(untracked)):
        path = REPO / rel
        if path.is_file() and not rel.startswith("reports/evidence/") and not rel.startswith("reports/272-"):
            items.append((path, f"sources/{rel}"))
    return items


def main() -> int:
    gates = Path(sys.argv[1]).resolve()
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries, blobs = [], {}
    for path, arc in collect(gates):
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name):
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "agentlang-evidence-v1", "report": "272", "entries": entries}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "272-flow-stdlib-loops-browser-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        if set(zf.namelist()) != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

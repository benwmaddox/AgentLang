"""Inspect the old maintenance seed on a disposable copy, without running tests."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repository = root.parents[1]
seed = repository / ".agentlang/subscription-handoff-maintenance-166/seeds/agentlang-project"
project = root / "historical-seed-smoke-project"
assert not project.exists(), "Do not overwrite an existing smoke project"
shutil.copytree(seed, project)

def inventory(directory):
    return {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in directory.rglob("*") if path.is_file()}

original = inventory(seed)
before = inventory(project)
requests = [
    {"op": "tests", "word": "subscription.handoff"},
    {"op": "tests", "word": "subscription.handoff", "includeSource": True},
]
lines = "\n".join(json.dumps(row) for row in requests) + "\n"
(root / "historical-seed-smoke-requests.jsonl").write_text(lines, encoding="utf-8")
cli = repository / "src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll"
process = subprocess.run(["dotnet", str(cli), "--project", str(project), "--filesystem", "virtual", "--jsonl"],
                         input=lines, text=True, encoding="utf-8", capture_output=True, timeout=120)
(root / "historical-seed-smoke-responses.jsonl").write_text(process.stdout, encoding="utf-8")
(root / "historical-seed-smoke-stderr.txt").write_text(process.stderr, encoding="utf-8")
rows = [json.loads(line) for line in process.stdout.splitlines()]
assert process.returncode == 0 and len(rows) == len(requests)
assert all(row["ok"] for row in rows)
cases = rows[1]["data"]
assert [case["name"] for case in cases] == rows[0]["data"]
assert cases
for case in cases:
    assert case["frontend"] == "flow" and case["syntaxVersion"] == 2
    assert hashlib.sha256(case["source"].encode("utf-8")).hexdigest() == case["sourceHash"]
    assert f'test subscription.handoff/{case["name"]}' in case["source"]
assert inventory(project) == before
assert inventory(seed) == original
summary = {"passed": True, "cases": [case["name"] for case in cases],
           "seedUnchanged": True, "copyUnchanged": True, "testsExecuted": 0,
           "cliSha256": hashlib.sha256(cli.read_bytes()).hexdigest(),
           "seedFiles": len(original), "purpose": "Source retrieval smoke, not an agent experiment"}
(root / "historical-seed-smoke-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary))

"""Package only completed local validation evidence for milestone 167."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
destination = root.parents[1] / "reports" / "evidence" / "167-test-source-inspection"
report = json.loads((root / "full-validation-final.json").read_text(encoding="utf-8-sig"))
source_pin = json.loads((root / "post-build-source-pin.json").read_text(encoding="utf-8-sig"))
repository = root.parents[1]
for item in source_pin["files"]:
    assert hashlib.sha256((repository / item["path"]).read_bytes()).hexdigest() == item["sha256"], "Validated source changed during final gate"
assert report["passed"] is True
assert len(report["checks"]) == 37
assert all(check["exitCode"] == 0 for check in report["checks"])
assert json.loads((root / "historical-seed-smoke-summary.json").read_text(encoding="utf-8"))["passed"] is True
assert not destination.exists(), "Do not overwrite published evidence"
payloads = sorted(root.glob("full-validation-final*.json")) + [
    root / "validation.txt",
    root / "initial-full-validation-failure.txt",
    root / "acceptance-validation.txt",
    root / "post-build-source-pin.json",
    Path(__file__).resolve(),
]
payloads += sorted(path for path in root.glob("historical-seed-smoke*") if path.is_file())
assert len({path.name for path in payloads}) == len(payloads)
entries = [
    {"path": path.name, "bytes": path.stat().st_size,
     "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    for path in payloads
]
destination.mkdir(parents=True)
archive = destination / "evidence.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
    for path in payloads:
        output.write(path, path.name)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    assert sorted(saved.namelist()) == sorted(item["path"] for item in entries)
    for item in entries:
        content = saved.read(item["path"])
        assert len(content) == item["bytes"]
        assert hashlib.sha256(content).hexdigest() == item["sha256"]
manifest = {
    "status": "verified", "fullGateChecks": 37,
    "description": "Final full gate, focused validation, acceptance rerun and retained development failures; binaries and temporary projects excluded.",
    "archive": {"path": archive.name, "bytes": archive.stat().st_size,
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()},
    "files": entries,
}
(destination / "archive.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(manifest["archive"]))

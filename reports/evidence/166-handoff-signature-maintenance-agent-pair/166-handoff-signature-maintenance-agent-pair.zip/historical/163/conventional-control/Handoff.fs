namespace AgentLang.SubscriptionHandoff.Control

open System.Reflection
open Microsoft.FSharp.Reflection
open AgentLang.Business.Domain

type ControlKind =
    | Composed
    | StartBeforeCancel
    | LeakIntermediateOnError
    | IgnoreOverlap
    | DuplicateBeforeCancel
    | CustomerOnlyOverlap
    | ProductOnlyOverlap

module private StoreReflection =
    let private flags = BindingFlags.Instance ||| BindingFlags.Public ||| BindingFlags.NonPublic

    let private updateField (record: Store) fieldName value =
        let recordType = record.GetType()
        let properties = FSharpType.GetRecordFields(recordType, bindingFlags = flags)
        let fields = FSharpValue.GetRecordFields(record, bindingFlags = flags)
        let index = properties |> Array.findIndex (fun property -> property.Name = fieldName)
        fields.[index] <- value
        FSharpValue.MakeRecord(recordType, fields, bindingFlags = flags) :?> Store

    let private updateStoreMap<'key, 'value when 'key: comparison>
        (fieldName: string)
        (update: Map<'key, 'value> -> Map<'key, 'value>)
        (store: Store) : Store =
        let recordType = store.GetType()
        let properties = FSharpType.GetRecordFields(recordType, bindingFlags = flags)
        let fields = FSharpValue.GetRecordFields(store, bindingFlags = flags)
        let index = properties |> Array.findIndex (fun property -> property.Name = fieldName)
        let values = fields.[index] :?> Map<'key, 'value>
        fields.[index] <- box (update values)
        FSharpValue.MakeRecord(recordType, fields, bindingFlags = flags) :?> Store

    let removeCustomer (id: CustomerId) (store: Store) =
        updateStoreMap<CustomerId, Customer> "CustomersById"
            (fun (values: Map<CustomerId, Customer>) -> Map.remove id values) store

    let removeProduct (id: ProductId) (store: Store) =
        updateStoreMap<ProductId, Product> "ProductsById"
            (fun (values: Map<ProductId, Product>) -> Map.remove id values) store

    let clearSubscriptions (store: Store) =
        updateField store "SubscriptionsById" (box (Map.empty<SubscriptionId, Subscription>))

    let addSubscription (id: SubscriptionId) (subscription: Subscription) (store: Store) =
        updateStoreMap<SubscriptionId, Subscription> "SubscriptionsById"
            (fun (values: Map<SubscriptionId, Subscription>) -> Map.add id subscription values) store

    let subscriptions (store: Store) =
        let properties = FSharpType.GetRecordFields(store.GetType(), bindingFlags = flags)
        let fields = FSharpValue.GetRecordFields(store, bindingFlags = flags)
        let index = properties |> Array.findIndex (fun property -> property.Name = "SubscriptionsById")
        (fields.[index] :?> Map<SubscriptionId, Subscription>)
        |> Map.toList
        |> List.map snd

module SubscriptionHandoff =
    let private startReplacement (store: Store) (id: SubscriptionId) (old: Subscription) term at expiry =
        Subscription.start store id (Subscription.customerId old) (Subscription.productId old) term at expiry

    let handoff (store: Store) (oldId: SubscriptionId) (newId: SubscriptionId) term at expiry : Result<Store, DomainError> =
        match Subscription.cancel store oldId at with
        | Error error -> Error error
        | Ok (cancelledStore, oldSubscription) ->
            startReplacement cancelledStore newId oldSubscription term at expiry
            |> Result.map fst

    let private startBeforeCancel (store: Store) oldId newId term at expiry : Result<Store, DomainError> =
        match Subscription.cancel store oldId at with
        | Error error -> Error error
        | Ok (cancelledStore, oldSubscription) ->
            match startReplacement store newId oldSubscription term at expiry with
            | Error error -> Error error
            | Ok _ ->
                startReplacement cancelledStore newId oldSubscription term at expiry
                |> Result.map fst

    let private leakIntermediateOnError (store: Store) oldId newId term at expiry : Result<Store, DomainError> =
        match Subscription.cancel store oldId at with
        | Error error -> Error error
        | Ok (cancelledStore, oldSubscription) ->
            match startReplacement cancelledStore newId oldSubscription term at expiry with
            | Ok (finalStore, _) -> Ok finalStore
            | Error _ -> Ok cancelledStore

    let private ignoreOverlap (store: Store) oldId newId term at expiry : Result<Store, DomainError> =
        match Subscription.cancel store oldId at with
        | Error error -> Error error
        | Ok (cancelledStore, oldSubscription) ->
            match startReplacement cancelledStore newId oldSubscription term at expiry with
            | Ok (finalStore, _) -> Ok finalStore
            | Error SubscriptionOverlap ->
                match startReplacement (StoreReflection.clearSubscriptions cancelledStore) newId oldSubscription term at expiry with
                | Error error -> Error error
                | Ok (_, replacement) ->
                    Ok (StoreReflection.addSubscription newId replacement cancelledStore)
            | Error error -> Error error

    let private duplicateBeforeCancel (store: Store) oldId newId term at expiry : Result<Store, DomainError> =
        match Store.subscription newId store with
        | Some _ -> Error(DuplicateSubscription newId)
        | None -> handoff store oldId newId term at expiry

    let private broadenOverlapScope useCustomerScope (store: Store) oldId newId term at expiry : Result<Store, DomainError> =
        match Subscription.cancel store oldId at with
        | Error error -> Error error
        | Ok (cancelledStore, oldSubscription) ->
            match startReplacement cancelledStore newId oldSubscription term at expiry with
            | Error error -> Error error
            | Ok (finalStore, _) ->
                let requestedPeriod =
                    OccupiedPeriod.tryCreate at expiry
                    |> Option.defaultWith (fun () -> failwith "A successful subscription start had an invalid period")
                let hasFaultyScopeOverlap =
                    StoreReflection.subscriptions cancelledStore
                    |> List.exists (fun existing ->
                        let sameScope =
                            if useCustomerScope then
                                Subscription.customerId existing = Subscription.customerId oldSubscription
                            else
                                Subscription.productId existing = Subscription.productId oldSubscription
                        sameScope
                        && (Subscription.occupiedPeriod existing
                            |> Option.exists (fun period -> OccupiedPeriod.overlaps period requestedPeriod)))
                if hasFaultyScopeOverlap then Error SubscriptionOverlap else Ok finalStore

    let run kind store oldId newId term at expiry =
        match kind with
        | Composed -> handoff store oldId newId term at expiry
        | StartBeforeCancel -> startBeforeCancel store oldId newId term at expiry
        | LeakIntermediateOnError -> leakIntermediateOnError store oldId newId term at expiry
        | IgnoreOverlap -> ignoreOverlap store oldId newId term at expiry
        | DuplicateBeforeCancel -> duplicateBeforeCancel store oldId newId term at expiry
        | CustomerOnlyOverlap -> broadenOverlapScope true store oldId newId term at expiry
        | ProductOnlyOverlap -> broadenOverlapScope false store oldId newId term at expiry

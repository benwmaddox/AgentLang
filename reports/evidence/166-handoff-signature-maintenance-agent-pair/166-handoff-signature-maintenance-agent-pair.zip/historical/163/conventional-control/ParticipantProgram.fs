namespace AgentLang.SubscriptionHandoff.Control

open System

module ParticipantProgram =
    [<EntryPoint>]
    let main args =
        try
            let cases =
                args
                |> Array.tryFindIndex ((=) "--cases")
                |> Option.bind (fun index -> args |> Array.tryItem (index + 1))
                |> Option.defaultWith (fun () -> failwith "Missing required argument --cases")
            Scorer.runFileWith AgentLang.SubscriptionHandoff.Subscription.handoff cases
            0
        with error ->
            Console.Error.WriteLine(error.Message)
            2

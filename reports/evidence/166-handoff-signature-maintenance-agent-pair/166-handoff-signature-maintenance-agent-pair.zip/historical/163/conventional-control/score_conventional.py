#!/usr/bin/env python3
"""Run the F# conventional control and behavior mutants against oracle cases."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
TRIAL = HERE.parents[1]
REPOSITORY = HERE.parents[3]
ORACLE = REPOSITORY / "experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/cases.json"
SEED_DLL = TRIAL / "seeds/conventional/lib/AgentLang.Business.dll"
INVENTORY = TRIAL / "setup/inventory.json"
PROJECT = HERE / "ConventionalControl.fsproj"
BUILD_DIR = HERE / "bin/Release/net9.0"
SEED_DOMAIN = TRIAL / "seeds/conventional/Domain.fs"
EVIDENCE = HERE / "evidence"
CONTROLS = [
    "composed",
    "start-before-cancel",
    "leak-intermediate-on-error",
    "ignore-overlap",
    "duplicate-before-cancel",
    "customer-only",
    "product-only",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def expected_seed_hash() -> str:
    inventory = json.loads(INVENTORY.read_text(encoding="utf-8"))
    normalized = "seeds/conventional/lib/AgentLang.Business.dll"
    matches = [
        row["sha256"]
        for row in inventory["files"]
        if row["path"].replace("\\", "/") == normalized
    ]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one seed DLL hash in {INVENTORY}, found {len(matches)}")
    return matches[0]


def classify_reference_fixtures(cases: list[dict[str, object]]) -> dict[str, object]:
    invalid: list[str] = []
    for case in cases:
        store = case["store"]
        request = case["request"]
        old_id = request["oldId"]
        old = next((row for row in store["subscriptions"] if row["id"] == old_id), None)
        if old is not None and (
            old["customer"] not in store["customers"] or old["product"] not in store["products"]
        ):
            invalid.append(str(case["id"]))
    return {
        "commonValidReferenceCaseCount": len(cases) - len(invalid),
        "invalidReferenceRobustnessCaseCount": len(invalid),
        "invalidReferenceRobustnessCaseIds": invalid,
    }


def run_control(
    name: str,
    cases: list[dict[str, object]],
    command: list[str],
    seed_hash: str,
    evidence_dir: Path,
    reference_fixtures: dict[str, object],
    expected_outcome: str | None = None,
) -> dict[str, object]:
    if expected_outcome is None:
        expected_outcome = "pass" if name == "composed" else "reject"
    output_path = evidence_dir / f"{name}-results.jsonl"
    stdout_path = evidence_dir / f"{name}-stdout.txt"
    stderr_path = evidence_dir / f"{name}-stderr.txt"
    process = subprocess.run(command, cwd=HERE, capture_output=True, text=True, check=False)
    stdout_path.write_text(process.stdout, encoding="utf-8")
    stderr_path.write_text(process.stderr, encoding="utf-8")

    rows: list[dict[str, object]] = []
    setup_failure = None
    if process.returncode != 0:
        setup_failure = f"runner exited {process.returncode}; see {stderr_path.name}"
    else:
        try:
            rows = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
            if len(rows) != len(cases):
                setup_failure = f"runner emitted {len(rows)} rows for {len(cases)} cases"
        except json.JSONDecodeError as error:
            setup_failure = f"runner output was not valid JSONL: {error}"

    output_path.write_text(
        "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows),
        encoding="utf-8",
    )

    executed = 0
    passed = 0
    failing_case_ids: list[str] = []
    setup_case_ids: list[str] = []
    if setup_failure is None:
        for case, row in zip(cases, rows, strict=True):
            if row.get("setupFailure"):
                setup_case_ids.append(str(row.get("id", case["id"])))
                continue
            executed += 1
            case_passed = (
                row.get("actual") == case["expected"]
                and row.get("inputPreserved") is True
                and row.get("collateralPreserved") is True
            )
            if case_passed:
                passed += 1
            else:
                failing_case_ids.append(str(row.get("id", case["id"])))

    if setup_failure is not None or setup_case_ids:
        status = "setup-failure"
        if setup_failure is None:
            setup_failure = "one or more case fixtures failed; see setupFailureCaseIds"
    elif name == "composed" or expected_outcome == "pass":
        status = "pass" if executed == len(cases) and passed == len(cases) else "positive-control-failed"
    else:
        status = "behavioral-rejection" if failing_case_ids else "mutant-survived"

    summary = {
        "control": name,
        "expectedOutcome": expected_outcome,
        "status": status,
        "compiled": True,
        "executedCaseCount": executed,
        "passedCaseCount": passed,
        "failingCaseIds": failing_case_ids,
        "setupFailure": setup_failure,
        "setupFailureCaseIds": setup_case_ids,
        "runnerExitCode": process.returncode,
        "seedBusinessDllSha256": seed_hash,
        "casesPath": str(ORACLE),
        "referenceFixtureClassification": reference_fixtures,
        "runnerCommand": command,
        "evidence": {
            "results": str(output_path),
            "stdout": str(stdout_path),
            "stderr": str(stderr_path),
        },
    }
    write_json(evidence_dir / f"{name}-summary.json", summary)
    return summary


def score_participant(
    source: Path,
    display_name: str | None,
    cases: list[dict[str, object]],
    seed_hash: str,
    reference_fixtures: dict[str, object],
    run_evidence: Path,
    expected_outcome: str,
) -> dict[str, object]:
    source = source.resolve()
    operations = source / "Operations.fs" if source.is_dir() else source
    if not operations.is_file():
        raise FileNotFoundError(f"Participant Operations.fs not found: {operations}")
    raw_name = display_name or operations.parent.name
    name = re.sub(r"[^A-Za-z0-9_-]+", "-", raw_name).strip("-_") or "participant"
    copy_dir = run_evidence / f"participant-copy-{name}"
    copy_dir.mkdir()
    (copy_dir / "lib").mkdir()
    shutil.copy2(SEED_DOMAIN, copy_dir / "Domain.fs")
    shutil.copy2(operations, copy_dir / "Operations.fs")
    for filename in ("ParticipantControl.fsproj", "Handoff.fs", "Scorer.fs", "ParticipantProgram.fs"):
        shutil.copy2(HERE / filename, copy_dir / filename)
    shutil.copy2(SEED_DLL, copy_dir / "lib/AgentLang.Business.dll")

    copied_inputs = [
        copy_dir / "Domain.fs",
        copy_dir / "Operations.fs",
        copy_dir / "Handoff.fs",
        copy_dir / "Scorer.fs",
        copy_dir / "ParticipantProgram.fs",
        copy_dir / "lib/AgentLang.Business.dll",
    ]
    input_manifest = {
        "target": "AgentLang.SubscriptionHandoff.Subscription.handoff",
        "participantOperationsSource": str(operations),
        "participantOperationsSourceSha256": sha256(operations),
        "disposableProjectPath": str(copy_dir),
        "compiledInputs": [
            {"path": path.name if path.parent == copy_dir else str(Path("lib") / path.name), "sha256": sha256(path)}
            for path in copied_inputs
        ],
    }
    write_json(copy_dir / "source-manifest.json", input_manifest)

    project = copy_dir / "ParticipantControl.fsproj"
    build_command = [
        "dotnet",
        "build",
        str(project),
        "--configuration",
        "Release",
        "--verbosity",
        "minimal",
        "-p:NuGetAudit=false",
    ]
    build = subprocess.run(build_command, cwd=copy_dir, capture_output=True, text=True, check=False)
    (run_evidence / f"participant-{name}-build-stdout.txt").write_text(build.stdout, encoding="utf-8")
    (run_evidence / f"participant-{name}-build-stderr.txt").write_text(build.stderr, encoding="utf-8")
    run_command = [
        "dotnet",
        str(copy_dir / "bin/Release/net9.0/ParticipantControl.dll"),
        "--cases",
        str(ORACLE),
    ]
    write_json(
        run_evidence / f"participant-{name}-commands.json",
        {"build": build_command, "run": run_command},
    )
    if build.returncode != 0:
        summary = {
            "control": f"participant-{name}",
            "expectedOutcome": expected_outcome,
            "status": "setup-failure",
            "compiled": False,
            "executedCaseCount": 0,
            "passedCaseCount": 0,
            "failingCaseIds": [],
            "setupFailure": f"participant build failed; see participant-{name}-build-stdout.txt and stderr.txt",
            "setupFailureCaseIds": [],
            "runnerExitCode": None,
            "seedBusinessDllSha256": seed_hash,
            "casesPath": str(ORACLE),
            "referenceFixtureClassification": reference_fixtures,
            "runnerCommand": None,
            **input_manifest,
        }
        write_json(run_evidence / f"participant-{name}-summary.json", summary)
        return summary

    summary = run_control(
        f"participant-{name}",
        cases,
        run_command,
        seed_hash,
        run_evidence,
        reference_fixtures,
        expected_outcome=expected_outcome,
    )
    summary.update(input_manifest)
    summary["buildCommand"] = build_command
    summary["buildExitCode"] = build.returncode
    write_json(run_evidence / f"participant-{name}-summary.json", summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--control", choices=CONTROLS, action="append", help="Run only this control (repeatable).")
    parser.add_argument("--participant", "--project", type=Path, help="Score a saved Operations.fs file or project directory.")
    parser.add_argument("--participant-name", help="Short evidence name for --participant.")
    parser.add_argument("--participant-outcome", choices=("pass", "reject"), default="pass", help="Expected behavior for a saved actor operation.")
    options = parser.parse_args()

    EVIDENCE.mkdir(parents=True, exist_ok=True)
    previous_runs = [
        int(path.name.removeprefix("run-"))
        for path in EVIDENCE.glob("run-[0-9][0-9][0-9]")
        if path.is_dir()
    ]
    run_evidence = EVIDENCE / f"run-{max(previous_runs, default=0) + 1:03d}"
    run_evidence.mkdir()
    cases = json.loads(ORACLE.read_text(encoding="utf-8"))
    reference_fixtures = classify_reference_fixtures(cases)
    seed_hash = sha256(SEED_DLL)
    inventory_hash = expected_seed_hash()
    if seed_hash.lower() != inventory_hash.lower():
        summary = {
            "status": "setup-failure",
            "setupFailure": "seed Business.dll does not match the staged inventory",
            "actualSeedBusinessDllSha256": seed_hash,
            "inventorySeedBusinessDllSha256": inventory_hash,
        }
        write_json(run_evidence / "conventional-suite-summary.json", summary)
        write_json(EVIDENCE / "conventional-suite-summary.json", summary)
        print(json.dumps(summary, indent=2))
        return 2

    if options.participant is not None:
        if options.control:
            parser.error("--control cannot be combined with --participant")
        source = options.participant
        if not source.is_absolute():
            source = REPOSITORY / source
        summary = score_participant(
            source,
            options.participant_name,
            cases,
            seed_hash,
            reference_fixtures,
            run_evidence,
            options.participant_outcome,
        )
        expected_status = "pass" if options.participant_outcome == "pass" else "behavioral-rejection"
        suite = {
            "status": "pass" if summary["status"] == expected_status else "incomplete-or-failed",
            "caseCount": len(cases),
            "controls": [summary],
            "referenceFixtureClassification": reference_fixtures,
            "seedBusinessDllSha256": seed_hash,
            "runKind": "saved-participant-operation",
        }
        write_json(run_evidence / "conventional-suite-summary.json", suite)
        write_json(EVIDENCE / "conventional-suite-summary.json", suite)
        print(json.dumps(suite, indent=2))
        return 0 if suite["status"] == "pass" else 1

    build_command = [
        "dotnet",
        "build",
        str(PROJECT),
        "--configuration",
        "Release",
        "--verbosity",
        "minimal",
        "-p:NuGetAudit=false",
    ]
    build = subprocess.run(build_command, cwd=HERE, capture_output=True, text=True, check=False)
    (run_evidence / "build-stdout.txt").write_text(build.stdout, encoding="utf-8")
    (run_evidence / "build-stderr.txt").write_text(build.stderr, encoding="utf-8")
    write_json(
        run_evidence / "commands.json",
        {
            "build": build_command,
            "run": ["dotnet", str(BUILD_DIR / "ConventionalControl.dll"), "--control", "<control>", "--cases", str(ORACLE)],
        },
    )
    selected = options.control or CONTROLS
    summaries = []
    if build.returncode != 0:
        build_failure = f"dotnet build failed; see {run_evidence.name}/build-stdout.txt and build-stderr.txt"
        for name in selected:
            summary = {
                "control": name,
                "status": "setup-failure",
                "compiled": False,
                "executedCaseCount": 0,
                "passedCaseCount": 0,
                "failingCaseIds": [],
                "setupFailure": build_failure,
                "setupFailureCaseIds": [],
                "runnerExitCode": None,
                "seedBusinessDllSha256": seed_hash,
                "casesPath": str(ORACLE),
                "referenceFixtureClassification": reference_fixtures,
                "runnerCommand": None,
            }
            write_json(run_evidence / f"{name}-summary.json", summary)
            summaries.append(summary)
    else:
        for name in selected:
            command = [
                "dotnet",
                str(BUILD_DIR / "ConventionalControl.dll"),
                "--control",
                name,
                "--cases",
                str(ORACLE),
            ]
            summaries.append(run_control(name, cases, command, seed_hash, run_evidence, reference_fixtures))

    suite = {
        "status": "pass" if all(
            item["status"] == ("pass" if item["control"] == "composed" else "behavioral-rejection")
            for item in summaries
        ) else "incomplete-or-failed",
        "caseCount": len(cases),
        "controls": summaries,
        "referenceFixtureClassification": reference_fixtures,
        "buildCommand": build_command,
        "buildExitCode": build.returncode,
        "seedBusinessDllSha256": seed_hash,
    }
    write_json(run_evidence / "conventional-suite-summary.json", suite)
    write_json(EVIDENCE / "conventional-suite-summary.json", suite)
    print(json.dumps(suite, indent=2))
    return 0 if suite["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())

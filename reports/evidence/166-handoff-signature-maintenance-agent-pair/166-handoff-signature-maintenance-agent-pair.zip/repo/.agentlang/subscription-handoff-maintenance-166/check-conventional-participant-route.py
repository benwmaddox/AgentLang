"""Calibrate the saved-submission route without changing participant seeds."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
source = (ROOT / 'seeds/conventional/Operations.fs').read_text(encoding='utf-8')
old = '(expiresAt: Instant) : Result<Store, DomainError> ='
assert source.count(old) == 3
source = source.replace(old, '(expiresAt: Instant) (dryRun: bool) : Result<Store, DomainError> =', 1)
assert source.count('|> Result.map fst') == 1
source = source.replace('|> Result.map fst', '|> Result.map (fun (updatedStore, _) -> if dryRun then store else updatedStore)')
for term in ('annual', 'monthly'):
    old = f'handoff store oldId replacementId "{term}" handoffAt expiresAt'
    assert source.count(old) == 1
    source = source.replace(old, old + ' false')
control = ROOT / 'control/conventional-participant-route/Operations.fs'
if control.exists():
    raise RuntimeError('Refusing to overwrite control source')
control.parent.mkdir(parents=True)
control.write_text(source, encoding='utf-8')
command = [sys.executable, str(REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/score_conventional.py'), '--participant', str(control)]
process = subprocess.run(command, cwd=REPO, text=True, capture_output=True, timeout=600)
(control.parent / 'stdout.txt').write_text(process.stdout, encoding='utf-8')
(control.parent / 'stderr.txt').write_text(process.stderr, encoding='utf-8')
print(process.stdout)
assert process.returncode == 0, process.stderr

"""Calibrate behavioral controls, independently of library qualification.

Controls start from the frozen pre-handoff domain, unlike participants who start
from the accepted report-163 library implementation. This keeps calibration from
requiring artificially passing library tests for intentionally wrong behavior.
The grader observes actual persisted target code, never a substituted wrapper.
"""
from pathlib import Path
import argparse
import json
import shutil
import subprocess

REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
ORACLE = REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle'
parser = argparse.ArgumentParser()
parser.add_argument('--cli', type=Path, required=True)
args = parser.parse_args()
assert args.cli.is_file()
base = REPO / '.agentlang/subscription-handoff-163/seeds/agentlang-project'
callers = (ROOT / 'flow-callers.agent').read_text(encoding='utf-8')
for term in ('annual', 'monthly'):
    old = f'.subscription.handoff(store, oldId, replacementId, "{term}", handoffAt, expiresAt)'
    assert callers.count(old) == 1
    callers = callers.replace(old, old[:-1] + ', false)')
test = '''test subscription.handoff/calibration-call {
    match subscription.handoff(
        business.seed(unit),
        SubscriptionId.new("30000000-0000-0000-0000-000000000001"),
        SubscriptionId.new("40000000-0000-0000-0000-000000000001"),
        "annual",
        Instant.new("2026-01-15T12:00:00.0000000+00:00"),
        Instant.new("2026-02-15T12:00:00.0000000+00:00"),
        true
    ) {
        ok _ => true
        error _ => false
    }
    => true
}'''
arms = [
    ('correct', 'control-correct.flow'),
    ('skip-dry-run-creation-validation', 'control-fault-skip-dry-run-creation-validation.flow'),
    ('return-updated-store-on-dry-run', 'control-fault-return-updated-store-on-dry-run.flow'),
]
for name, filename in arms:
    project = ROOT / 'control/flow' / name
    if project.exists():
        raise RuntimeError(f'Refusing to overwrite existing control {project}')
    shutil.copytree(base, project)
    source = (ORACLE / filename).read_text(encoding='utf-8') + '\n\n' + test + '\n\n' + callers
    requests = [
        {'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'source': source},
        {'op': 'test', 'word': 'subscription.handoff'},
        {'op': 'test', 'word': 'subscription.renew-annual'},
        {'op': 'test', 'word': 'subscription.renew-monthly'},
        {'op': 'commit'},
    ]
    lines = '\n'.join(json.dumps(row) for row in requests) + '\n'
    command = ['dotnet', str(args.cli.resolve()), '--project', str(project), '--filesystem', 'virtual', '--jsonl']
    process = subprocess.run(command, input=lines, text=True, encoding='utf-8', capture_output=True, cwd=REPO, timeout=600)
    logdir = ROOT / 'control/flow' / (name + '-preparation')
    logdir.mkdir()
    (logdir / 'requests.jsonl').write_text(lines, encoding='utf-8')
    (logdir / 'responses.jsonl').write_text(process.stdout, encoding='utf-8')
    (logdir / 'stderr.txt').write_text(process.stderr, encoding='utf-8')
    (logdir / 'command.json').write_text(json.dumps({'command': command, 'exitCode': process.returncode, 'maturity': 'project; behavioral calibration only'}, indent=2), encoding='utf-8')
    assert process.returncode == 0, process.stderr
    rows = [json.loads(line) for line in process.stdout.splitlines()]
    assert len(rows) == len(requests) and all(row.get('ok') for row in rows), process.stdout
    for row in rows[1:4]:
        assert all(case['passed'] for case in row['data']['results']), row
    print(f'Prepared typed project-maturity control {name}; hidden scoring still required.')

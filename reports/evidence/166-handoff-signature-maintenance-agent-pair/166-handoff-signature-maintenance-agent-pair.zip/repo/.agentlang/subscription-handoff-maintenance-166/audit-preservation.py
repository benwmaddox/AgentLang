"""Compare maintenance-166 actors with their exact pre-trial seeds.

Manifest/object checks are mechanical; source diffs require manual semantic review.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / ".agentlang" / "subscription-handoff-maintenance-166"
FLOW_NAMES = {
    "subscription.handoff",
    "subscription.renew-annual",
    "subscription.renew-monthly",
}
EDITABLE_CONVENTIONAL = {"Operations.fs", "SelfTests.fs"}
GENERATED = {".git", "bin", "obj", "__pycache__", "testresults"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest(project: Path) -> dict:
    store = project / ".agentlang" / "store"
    current = json.loads((store / "CURRENT").read_text(encoding="utf-8-sig"))
    return json.loads((store / "manifests" / f"{current['manifestHash']}.json").read_text(encoding="utf-8-sig"))


def objects(project: Path) -> dict[str, bytes]:
    root = project / ".agentlang" / "store" / "objects"
    return {p.name: p.read_bytes() for p in root.rglob("*") if p.is_file()}


def files(project: Path) -> dict[str, Path]:
    result = {}
    for path in project.rglob("*"):
        relative = path.relative_to(project)
        if any(part.lower() in GENERATED for part in relative.parts):
            continue
        if path.is_file():
            result[relative.as_posix()] = path
    return result


def check(checks: list[dict], name: str, passed: bool, **details) -> None:
    checks.append({"name": name, "passed": bool(passed), "details": details})


def unmatched_rows(old_rows: list[dict], new_rows: list[dict]) -> tuple[list[dict], list[dict]]:
    remaining = list(new_rows)
    missing = []
    for row in old_rows:
        if row in remaining:
            remaining.remove(row)
        else:
            missing.append(row)
    return missing, remaining


def source(project: Path, ref: dict) -> str:
    path = project / ".agentlang" / "store" / "objects" / f"{ref['hash']}.agent"
    return path.read_text(encoding="utf-8-sig")


def flow_review(seed: Path, actor: Path, output: Path, before: dict, after: dict) -> None:
    seed_words = {row["wordId"]: row for row in before["words"]}
    actor_words = {row["wordId"]: row for row in after["words"]}
    seed_revs = {(row["wordId"], row["revision"]): row for row in before["revisions"]}
    actor_revs = {(row["wordId"], row["revision"]): row for row in after["revisions"]}
    by_name = {row["currentName"]: row for row in seed_words.values()}
    after_by_name = {row["currentName"]: row for row in actor_words.values()}
    lines = [
        "# Flow source review (manual)\n",
        "Review these definition and attached-test changes for retained assertions and call shapes.\n",
    ]
    for name in sorted(FLOW_NAMES):
        old_word, new_word = by_name[name], after_by_name[name]
        old = seed_revs[(old_word["wordId"], old_word["currentRevision"])]
        new = actor_revs[(new_word["wordId"], new_word["currentRevision"])]
        old_def, new_def = source(seed, old["definition"]), source(actor, new["definition"])
        lines += [f"## {name}: definition diff\n", "```diff\n"]
        lines += list(difflib.unified_diff(old_def.splitlines(True), new_def.splitlines(True), "seed", "actor"))
        lines += ["```\n", f"## {name}: attached test sources (manual review)\n"]
        old_tests, new_tests = old.get("tests", []), new.get("tests", [])
        for index in range(max(len(old_tests), len(new_tests))):
            lines.append(f"### Test attachment {index + 1}\n")
            for label, project, tests in (("seed", seed, old_tests), ("actor", actor, new_tests)):
                lines.append(f"#### {label} — {tests[index]['hash'] if index < len(tests) else '(missing)'}\n")
                if index < len(tests):
                    lines += ["```flow\n", source(project, tests[index]), "\n```\n"]
    output.write_text("\n".join(lines), encoding="utf-8")


def audit_flow(seed: Path, actor: Path, output: Path) -> list[dict]:
    checks: list[dict] = []
    before, after = manifest(seed), manifest(actor)
    sw = {row["wordId"]: row for row in before["words"]}
    aw = {row["wordId"]: row for row in after["words"]}
    old_names = {row["currentName"]: row for row in before["words"]}
    allowed_ids = {old_names[name]["wordId"] for name in FLOW_NAMES}

    added_words = [row for word_id, row in aw.items() if word_id not in sw]
    check(checks, "all existing word IDs retained", set(sw) <= set(aw),
          missing=sorted(set(sw) - set(aw)))
    check(checks, "target names and IDs retained", all(
        name in {row["currentName"] for row in after["words"]}
        and aw.get(old_names[name]["wordId"], {}).get("currentName") == name
        for name in FLOW_NAMES), names=sorted(FLOW_NAMES))
    unchanged_words = [word_id for word_id, row in sw.items()
                       if word_id not in allowed_ids and aw.get(word_id) != row]
    check(checks, "unrelated word rows unchanged", not unchanged_words,
          changedWordIds=unchanged_words)
    missing_types, added_types = unmatched_rows(before.get("types", []), after.get("types", []))
    check(checks, "all existing type rows retained", not missing_types,
          missing=missing_types)

    old_revs = {(row["wordId"], row["revision"]): row for row in before["revisions"]}
    new_revs = {(row["wordId"], row["revision"]): row for row in after["revisions"]}
    check(checks, "all prior revision rows preserved",
          all(new_revs.get(key) == row for key, row in old_revs.items()),
          priorRevisionCount=len(old_revs))
    additions = [row for key, row in new_revs.items() if key not in old_revs]
    unexpected_revisions = [row for row in additions
                            if row["wordId"] in sw and row["wordId"] not in allowed_ids]
    check(checks, "existing non-target words have no new revisions",
          not unexpected_revisions, changedRevisions=unexpected_revisions)
    maturity_ok = True
    revision_advances = {}
    for name in sorted(FLOW_NAMES):
        old_word = old_names[name]
        new_word = aw.get(old_word["wordId"], {})
        old_rev = old_revs[(old_word["wordId"], old_word["currentRevision"])]
        new_number = new_word.get("currentRevision", -1)
        revision_advances[name] = {"from": old_word["currentRevision"], "to": new_number}
        new_rev = new_revs.get((old_word["wordId"], new_number), {})
        maturity_ok &= new_number > old_word["currentRevision"] and old_rev.get("maturity") == "library" and new_rev.get("maturity") == "library"
        maturity_ok &= all(row.get("maturity") == "library" and row.get("name") == name
                           for row in additions if row["wordId"] == old_word["wordId"])
    check(checks, "three functions advance and remain library maturity", maturity_ok,
          revisions=revision_advances)
    scope_review = {
        "addedWords": added_words,
        "addedTypes": added_types,
        "addedRevisions": additions,
        "note": "Review additions for task scope; new helper vocabulary is reported, not rejected by this audit.",
    }
    (output / "flow-added-scope-review.json").write_text(
        json.dumps(scope_review, indent=2), encoding="utf-8")

    old_objects, new_objects = objects(seed), objects(actor)
    missing_objects = sorted(set(old_objects) - set(new_objects))
    changed_objects = sorted(name for name, data in old_objects.items()
                              if name in new_objects and new_objects[name] != data)
    check(checks, "seed content-addressed objects remain byte-identical",
          not missing_objects and not changed_objects,
          seedObjectCount=len(old_objects), missing=missing_objects, changed=changed_objects)

    baseline_path = ROOT / "setup-flow" / "responses.jsonl"
    baseline = [json.loads(line) for line in baseline_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    all_tests = next((row for row in baseline if row.get("text") == "146/146 test(s) passed."), {})
    results = all_tests.get("data", {}).get("results", [])
    check(checks, "recorded 146-test Flow seed baseline passed",
          len(results) == 146 and all(row.get("passed") for row in results),
          response=all_tests.get("text"), resultCount=len(results))
    try:
        flow_review(seed, actor, output / "flow-source-review.md", before, after)
        check(checks, "Flow manual review sources available", True)
    except (KeyError, FileNotFoundError) as error:
        (output / "flow-source-review.md").write_text(
            "# Flow source review unavailable\n\n"
            f"The actor manifest or referenced source is incomplete: {error}\n",
            encoding="utf-8",
        )
        check(checks, "Flow manual review sources available", False, error=str(error))
    return checks


def audit_conventional(seed: Path, actor: Path, output: Path) -> list[dict]:
    checks: list[dict] = []
    old, new = files(seed), files(actor)
    old_fixed = set(old) - EDITABLE_CONVENTIONAL
    new_fixed = set(new) - EDITABLE_CONVENTIONAL
    changed = sorted(path for path in old_fixed & new_fixed if sha(old[path]) != sha(new[path]))
    missing, added = sorted(old_fixed - new_fixed), sorted(new_fixed - old_fixed)
    check(checks, "all noneditable conventional files unchanged",
          not missing and not added and not changed,
          missing=missing, added=added, changed=changed)
    check(checks, "both allowed conventional source files retained",
          EDITABLE_CONVENTIONAL <= set(old) and EDITABLE_CONVENTIONAL <= set(new),
          expected=sorted(EDITABLE_CONVENTIONAL))

    lines = [
        "# Conventional source review (manual)\n",
        "Review these diffs for unrelated foundation/alias edits and preservation of original self-test assertions. No semantic assertion is machine-proven here.\n",
    ]
    for name in sorted(EDITABLE_CONVENTIONAL):
        lines += [f"## {name}\n", "```diff\n"]
        if name in old and name in new:
            lines += list(difflib.unified_diff(old[name].read_text(encoding="utf-8-sig").splitlines(True),
                                                new[name].read_text(encoding="utf-8-sig").splitlines(True),
                                                "seed/" + name, "actor/" + name))
        lines.append("```\n")
    (output / "conventional-source-review.md").write_text("\n".join(lines), encoding="utf-8")
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--flow-seed", type=Path, default=ROOT / "seeds" / "agentlang-project")
    parser.add_argument("--flow-actor", type=Path, default=ROOT / "actors" / "flow")
    parser.add_argument("--conventional-seed", type=Path, default=ROOT / "seeds" / "conventional")
    parser.add_argument("--conventional-actor", type=Path, default=ROOT / "actors" / "conventional")
    parser.add_argument("--output", type=Path, default=ROOT / "preservation-review")
    args = parser.parse_args()
    missing = [str(path) for path in (args.flow_actor, args.conventional_actor) if not path.is_dir()]
    if missing:
        print(json.dumps({"status": "not-ready", "missingActorProjects": missing}, indent=2))
        return 2
    args.output.mkdir(parents=True, exist_ok=True)
    checks = audit_flow(args.flow_seed, args.flow_actor, args.output)
    checks += audit_conventional(args.conventional_seed, args.conventional_actor, args.output)
    failures = [row["name"] for row in checks if not row["passed"]]
    report = {
        "status": "machine-checks-passed-manual-review-required" if not failures else "machine-check-failed",
        "machineCheckCount": len(checks),
        "failedChecks": failures,
        "checks": checks,
        "manualReview": ["flow-source-review.md", "flow-added-scope-review.json",
                         "conventional-source-review.md"],
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())

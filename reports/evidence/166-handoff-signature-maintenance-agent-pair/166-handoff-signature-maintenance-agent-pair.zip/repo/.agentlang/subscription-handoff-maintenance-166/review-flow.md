# Flow actor preservation review

## Provenance and machine checks

Reviewed `.agentlang/subscription-handoff-maintenance-166/actors/flow` against `.agentlang/subscription-handoff-maintenance-166/seeds/agentlang-project`. I invoked only `audit_flow` from `audit-preservation.py`; the conventional actor was not opened. Machine results are in `flow-review/machine-checks.json`; the generated definition and attached-test source comparisons are in `flow-review/flow-source-review.md`; added-vocabulary scope is listed in `flow-review/flow-added-scope-review.json`.

All 10 Flow checks passed. The three target word IDs and names are unchanged: `subscription.handoff` (`word_1151413b851444b3ac13eda27c3ee68c`), `subscription.renew-annual` (`word_93c9249490464dc3856391810d2a71fb`), and `subscription.renew-monthly` (`word_d62492381698467284e14ae454671baf`). Their current revisions advance 2→4, 1→2, and 1→2 respectively; all remain library maturity. The actor manifest still uses format version 3. All 50 seed revision rows are unchanged, and all 268 seed object files remain byte-identical. No existing unrelated word rows changed, all existing type rows remain, and the added-vocabulary report is empty. The recorded seed baseline remains 146/146 passing.

## Manual function and case review

`subscription.handoff` adds trailing `dryRun: Bool`. It still looks up the old subscription, cancels it, then attempts replacement creation. Cancellation and creation errors are returned in that order. On successful creation, `true` returns the original store; `false` returns the replacement store. The annual and monthly wrappers retain their five-input signatures, fixed terms, and append `false` to the handoff call.

All five prior handoff case keys and expected outcomes remain: `creation-rules-follow-cancellation` → `DUPLICATE_SUBSCRIPTION`, `cancellation-rules-precede-creation` → `CANCEL_BEFORE_START`, `success` → `true`, `blank-term-after-cancellation` → `INVALID_SUBSCRIPTION_TERM`, and `missing-old-precedes-creation` → `SUBSCRIPTION_NOT_FOUND`. Four retain their prior inputs with only the trailing `false` argument. The missing-old case still uses a missing old subscription, invalid creation term/dates, and expects the same error, but changes the replacement ID from an already-present subscription ID to a fresh one. This narrows the original simultaneous-failure/duplicate-precedence evidence; the original input is not preserved.

All four annual/monthly wrapper tests retain their exact source objects and case keys (`duplicate`, `success`); wrapper definitions now pass `false`.

Three handoff tests are added. `dry-run-success` calls with `true` and asserts the returned store equals the input. `dry-run-creation-validation` uses a valid cancellation window and whitespace term, expecting `INVALID_SUBSCRIPTION_TERM`; this exercises a creation-only failure after cancellation can succeed. `dry-run-cancellation-precedes-creation` uses an invalid cancellation window plus invalid creation inputs and expects `CANCEL_BEFORE_START`, checking the earlier cancellation failure remains visible in dry-run mode.

One assertion was refactored in the existing handoff `success` case. The seed test separately checked the source subscription was active and uncancelled before handoff, then checked each old and replacement field. The actor test checks complete old/replacement record equality against constructed expected records and keeps the unrelated collection equality checks, but no longer explicitly asserts the pre-handoff record's active status and empty cancellation timestamp. Taking the successful `.subscription.cancel` path may constrain the pre-state, but it does not preserve those explicit assertions in this test.

The parent reports the independent Flow grader passed 66 target and 66 retained-caller checks. That is behavioral evidence, separate from source-test preservation: preservation is incomplete because the missing-old input changed and the success test dropped explicit pre-state assertions. I did not rerun the grader or broader test suite. The preservation audit checks manifest/object continuity; it does not prove assertion equivalence or runtime behavior.

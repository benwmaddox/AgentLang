"""Read final metadata and run all attached tests on a saved actor copy."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
dest = ROOT / 'flow-final-validation'
if dest.exists(): raise RuntimeError('Refusing to overwrite final validation')
dest.mkdir()
project = dest / 'project'
shutil.copytree(ROOT / 'actors/flow', project)
requests = [{'op': 'test-all'}, {'op': 'task.status'}]
requests += [{'op': 'describe', 'word': name} for name in (
    'subscription.handoff', 'subscription.renew-annual', 'subscription.renew-monthly')]
lines = '\n'.join(json.dumps(row) for row in requests) + '\n'
command = ['dotnet', str(ROOT / 'runtime/flow/AgentLang.Cli.dll'), '--project',
           str(project), '--filesystem', 'virtual', '--jsonl']
process = subprocess.run(command, input=lines, text=True, encoding='utf-8',
                         capture_output=True, timeout=600)
(dest / 'requests.jsonl').write_text(lines, encoding='utf-8')
(dest / 'responses.jsonl').write_text(process.stdout, encoding='utf-8')
(dest / 'stderr.txt').write_text(process.stderr, encoding='utf-8')
rows = [json.loads(line) for line in process.stdout.splitlines()]
assert process.returncode == 0 and len(rows) == len(requests)
assert all(row['ok'] for row in rows), process.stdout
tests = rows[0]['data']['results']
assert all(test['passed'] for test in tests), rows[0]
summary = {'allTests': len(tests), 'allPassed': True, 'taskStatus': rows[1].get('data'),
           'taskStatusText': rows[1].get('text'),
           'functions': [row['data'] for row in rows[2:]]}
(dest / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({'tests': len(tests), 'allPassed': True,
                 'functions': [{'name': f['name'], 'id': f['id'], 'revision': f['revision'],
                                'maturity': f['maturity']} for f in summary['functions']]}))

# Flow source review (manual)

Review these definition and attached-test changes for retained assertions and call shapes.

## subscription.handoff: definition diff

```diff

--- seed

+++ actor

@@ -1,10 +1,19 @@

-fn subscription.handoff(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError> {

-    doc "Cancel the old subscription and start its replacement atomically at the handoff instant."

+fn subscription.handoff(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant, dryRun: Bool) -> Result<Store, BusinessError> {

+    doc "Validate cancellation and replacement creation at the handoff instant; dry runs return the original store after successful validation."

 

     match .store.subscription(oldId, store) {

         some oldSubscription => {

             match .subscription.cancel(store, oldId, handoffAt) {

-                ok cancelledStore => .subscription.start(cancelledStore, replacementId, oldSubscription.customer-id, oldSubscription.product-id, term, handoffAt, expiresAt)

+                ok cancelledStore => {

+                    match .subscription.start(cancelledStore, replacementId, oldSubscription.customer-id, oldSubscription.product-id, term, handoffAt, expiresAt) {

+                        ok replacementStore => if dryRun {

+                            result.ok<Store, BusinessError>(store)

+                        } else {

+                            result.ok<Store, BusinessError>(replacementStore)

+                        }

+                        error creationError => result.error<Store, BusinessError>(creationError)

+                    }

+                }

                 error cancellationError => result.error<Store, BusinessError>(cancellationError)

             }

         }

```

## subscription.handoff: attached test sources (manual review)

### Test attachment 1

#### seed — 186f87645c3305b6dd5662f250b1d8fccb653b9b4d3155870f8168e477c1a3a7

```flow

test subscription.handoff/creation-rules-follow-cancellation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(
        store,
        oldId,
        oldId,
        "  ",
        Instant.new("2026-01-15T12:00:00.0000000+00:00"),
        Instant.new("2026-02-15T12:00:00.0000000+00:00")
    ) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

#### actor — 1f0348c52e44068ec04ff7475be5918832ec221aa114341b62010ba59ad6e513

```flow

test subscription.handoff/success {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let replacementId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    let expiresAt = Instant.new("2026-02-15T12:00:00.0000000+00:00")
    let original = .store.subscription(oldId, store)
    let output = .subscription.handoff(store, oldId, replacementId, "  annual  ", handoffAt, expiresAt, false)
    match output {
        ok updated => {
            match original {
                some before => {
                    match .store.subscription(oldId, updated) {
                        some old => {
                            match .store.subscription(replacementId, updated) {
                                some replacement => bool.and(
                                    .equals(old, .subscription.new(oldId, before.customer-id, before.product-id, before.term, before.started-at, before.expires-at, SubscriptionStatus.new("cancelled"), option.some<Instant>(handoffAt))),
                                    bool.and(
                                        .equals(replacement, .subscription.new(replacementId, before.customer-id, before.product-id, "annual", handoffAt, expiresAt, SubscriptionStatus.new("active"), option.none<Instant>())),
                                        bool.and(.equals(updated.customers, store.customers),
                                            bool.and(.equals(updated.products, store.products),
                                                bool.and(.equals(updated.invoices, store.invoices),
                                                    bool.and(.equals(updated.payments, store.payments),
                                                        bool.and(.equals(updated.email-outbox, store.email-outbox),
                                                            .equals(updated.sent-emails, store.sent-emails)
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                                none => false
                            }
                        }
                        none => false
                    }
                }
                none => false
            }
        }
        error _ => false
    }
    => true
}

```

### Test attachment 2

#### seed — 834ea4020f3c7af46a15d6bab1638793e37a47d99a72f364b3eb304ff1f2ef1d

```flow

test subscription.handoff/cancellation-rules-precede-creation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(
        store,
        oldId,
        oldId,
        "",
        Instant.new("2026-01-01T12:00:00.0000000+00:00"),
        Instant.new("2025-12-31T12:00:00.0000000+00:00")
    ) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "CANCEL_BEFORE_START"
}

```

#### actor — 273fea017129562911a5e7bc035680e8428d8c1fef5b4117c43ea44c24e717e0

```flow

test subscription.handoff/creation-rules-follow-cancellation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, oldId, "  ", Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00"), false) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

### Test attachment 3

#### seed — c91fc0d8ee592e2a66ee02351ce75f171bbd97ff691a0ff915fdca666bebff45

```flow

test subscription.handoff/success {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let replacementId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    let expiresAt = Instant.new("2026-02-15T12:00:00.0000000+00:00")
    let original = .store.subscription(oldId, store)
    let output = .subscription.handoff(store, oldId, replacementId, "  annual  ", handoffAt, expiresAt)

    match output {
        ok updated => {
            match original {
                some before => {
                    match .store.subscription(oldId, updated) {
                        some old => {
                            match .store.subscription(replacementId, updated) {
                                some replacement => bool.and(
                                    .equals(before.status, SubscriptionStatus.new("active")),
                                    bool.and(
                                        .equals(before.cancelled-at, option.none<Instant>()),
                                        bool.and(
                                            .equals(old.id, before.id),
                                            bool.and(
                                                .equals(old.customer-id, before.customer-id),
                                                bool.and(
                                                    .equals(old.product-id, before.product-id),
                                                    bool.and(
                                                        .equals(old.term, before.term),
                                                        bool.and(
                                                            .equals(old.started-at, before.started-at),
                                                            bool.and(
                                                                .equals(old.expires-at, before.expires-at),
                                                                bool.and(
                                                                    .equals(old.status, SubscriptionStatus.new("cancelled")),
                                                                    bool.and(
                                                                        .equals(old.cancelled-at, option.some<Instant>(handoffAt)),
                                                                        bool.and(
                                                                            .equals(replacement.id, replacementId),
                                                                            bool.and(
                                                                                .equals(replacement.customer-id, before.customer-id),
                                                                                bool.and(
                                                                                    .equals(replacement.product-id, before.product-id),
                                                                                    bool.and(
                                                                                        .equals(replacement.term, "annual"),
                                                                                        bool.and(
                                                                                            .equals(replacement.started-at, handoffAt),
                                                                                            bool.and(
                                                                                                .equals(replacement.expires-at, expiresAt),
                                                                                                bool.and(
                                                                                                    .equals(replacement.status, SubscriptionStatus.new("active")),
                                                                                                    bool.and(
                                                                                                        .equals(replacement.cancelled-at, option.none<Instant>()),
                                                                                                        bool.and(
                                                                                                            .equals(updated.customers, store.customers),
                                                                                                            bool.and(
                                                                                                                .equals(updated.products, store.products),
                                                                                                                bool.and(
                                                                                                                    .equals(updated.invoices, store.invoices),
                                                                                                                    bool.and(
                                                                                                                        .equals(updated.payments, store.payments),
                                                                                                                        bool.and(
                                                                                                                            .equals(updated.email-outbox, store.email-outbox),
                                                                                                                            .equals(updated.sent-emails, store.sent-emails)
                                                                                                                        )
                                                                                                                    )
                                                                                                                )
                                                                                                            )
                                                                                                        )
                                                                                                    )
                                                                                                )
                                                                                            )
                                                                                        )
                                                                                    )
                                                                                )
                                                                            )
                                                                        )
                                                                    )
                                                                )
                                                            )
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                                none => false
                            }
                        }
                        none => false
                    }
                }
                none => false
            }
        }
        error failure => false
    }
    => true
}

```

#### actor — 65d788bcc07389cd9d13507041dd4451c552cdfadb282ab7b4f014d1bdbb8ea5

```flow

test subscription.handoff/blank-term-after-cancellation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, SubscriptionId.new("40000000-0000-0000-0000-000000000001"), "  ", Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00"), false) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "INVALID_SUBSCRIPTION_TERM"
}

```

### Test attachment 4

#### seed — cd1584a64465416ef64a5efe617414b488738af5755614f23d30139c88947712

```flow

test subscription.handoff/blank-term-after-cancellation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(
        store,
        oldId,
        SubscriptionId.new("40000000-0000-0000-0000-000000000001"),
        "  ",
        Instant.new("2026-01-15T12:00:00.0000000+00:00"),
        Instant.new("2026-02-15T12:00:00.0000000+00:00")
    ) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "INVALID_SUBSCRIPTION_TERM"
}

```

#### actor — 8d5e54ba0c94d0b236cc8e20e94be48bf94f22b6ee118cbab6585b9cab47a3b5

```flow

test subscription.handoff/dry-run-creation-validation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, SubscriptionId.new("40000000-0000-0000-0000-000000000001"), "  ", Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00"), true) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "INVALID_SUBSCRIPTION_TERM"
}

```

### Test attachment 5

#### seed — fdd2ce1d381039333cb5f3a06176643a77e1cfde99d3cafc3eefc3a1ce4084a0

```flow

test subscription.handoff/missing-old-precedes-creation {
    let store = business.seed(unit)
    match .subscription.handoff(
        store,
        SubscriptionId.new("39999999-0000-0000-0000-000000000001"),
        SubscriptionId.new("30000000-0000-0000-0000-000000000001"),
        "",
        Instant.new("2026-01-01T12:00:00.0000000+00:00"),
        Instant.new("2025-12-31T12:00:00.0000000+00:00")
    ) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "SUBSCRIPTION_NOT_FOUND"
}

```

#### actor — 94b6a9172a6bbec90d2ad39d158d70b163443a0473e6d71d55f2d2d07ab4840f

```flow

test subscription.handoff/cancellation-rules-precede-creation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, oldId, "", Instant.new("2026-01-01T12:00:00.0000000+00:00"), Instant.new("2025-12-31T12:00:00.0000000+00:00"), false) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "CANCEL_BEFORE_START"
}

```

### Test attachment 6

#### seed — (missing)

#### actor — cd4208fe3a89a625376631b46b67dd363162177ba2e366b235e9d135052c46c1

```flow

test subscription.handoff/missing-old-precedes-creation {
    let store = business.seed(unit)
    match .subscription.handoff(
        store,
        SubscriptionId.new("39999999-0000-0000-0000-000000000001"),
        SubscriptionId.new("40000000-0000-0000-0000-000000000001"),
        "",
        Instant.new("2026-01-01T12:00:00.0000000+00:00"),
        Instant.new("2025-12-31T12:00:00.0000000+00:00"),
        false
    ) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "SUBSCRIPTION_NOT_FOUND"
}

```

### Test attachment 7

#### seed — (missing)

#### actor — d2976a4c10b51adc4b112dd019ac44b9b6fa6e21324a129ac723e4527d70d343

```flow

test subscription.handoff/dry-run-cancellation-precedes-creation {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, oldId, "", Instant.new("2026-01-01T12:00:00.0000000+00:00"), Instant.new("2025-12-31T12:00:00.0000000+00:00"), true) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "CANCEL_BEFORE_START"
}

```

### Test attachment 8

#### seed — (missing)

#### actor — f85dbb66ebd07ee585762c05464d6b657fde1a663cad99fec9559c7894cff232

```flow

test subscription.handoff/dry-run-success {
    let store = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let replacementId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    match .subscription.handoff(store, oldId, replacementId, "  annual  ", Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00"), true) {
        ok returnedStore => .equals(returnedStore, store)
        error _ => false
    }
    => true
}

```

## subscription.renew-annual: definition diff

```diff

--- seed

+++ actor

@@ -1,5 +1,5 @@

 fn subscription.renew-annual(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError> {

     doc "Replace a subscription with a annual subscription using the existing handoff rules."

 

-    .subscription.handoff(store, oldId, replacementId, "annual", handoffAt, expiresAt)

+    .subscription.handoff(store, oldId, replacementId, "annual", handoffAt, expiresAt, false)

 }
```

## subscription.renew-annual: attached test sources (manual review)

### Test attachment 1

#### seed — 14c90ec56c3df6c2d0c48ea8399956ac549778a98bdd3094f23b909fe244eb7f

```flow

test subscription.renew-annual/duplicate {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.renew-annual(input, oldId, oldId, Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

#### actor — 14c90ec56c3df6c2d0c48ea8399956ac549778a98bdd3094f23b909fe244eb7f

```flow

test subscription.renew-annual/duplicate {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.renew-annual(input, oldId, oldId, Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

### Test attachment 2

#### seed — 1f338cf24b52bc6ba1d2dc338c1ae07bdd0fd18147a38c7bc7078a6ec762b1a1

```flow

test subscription.renew-annual/success {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let newId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    match .subscription.renew-annual(input, oldId, newId, handoffAt, Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        error _ => false
        ok updated => {
            match .store.subscription(newId, updated) {
                none => false
                some replacement => {
                    match .store.subscription(oldId, updated) {
                        none => false
                        some old => bool.and(replacement.term == "annual", bool.and(replacement.started-at == handoffAt, old.cancelled-at == option.some<Instant>(handoffAt)))
                    }
                }
            }
        }
    }
    => true
}

```

#### actor — 1f338cf24b52bc6ba1d2dc338c1ae07bdd0fd18147a38c7bc7078a6ec762b1a1

```flow

test subscription.renew-annual/success {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let newId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    match .subscription.renew-annual(input, oldId, newId, handoffAt, Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        error _ => false
        ok updated => {
            match .store.subscription(newId, updated) {
                none => false
                some replacement => {
                    match .store.subscription(oldId, updated) {
                        none => false
                        some old => bool.and(replacement.term == "annual", bool.and(replacement.started-at == handoffAt, old.cancelled-at == option.some<Instant>(handoffAt)))
                    }
                }
            }
        }
    }
    => true
}

```

## subscription.renew-monthly: definition diff

```diff

--- seed

+++ actor

@@ -1,5 +1,5 @@

 fn subscription.renew-monthly(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError> {

     doc "Replace a subscription with a monthly subscription using the existing handoff rules."

 

-    .subscription.handoff(store, oldId, replacementId, "monthly", handoffAt, expiresAt)

+    .subscription.handoff(store, oldId, replacementId, "monthly", handoffAt, expiresAt, false)

 }
```

## subscription.renew-monthly: attached test sources (manual review)

### Test attachment 1

#### seed — 0997de79afd308cd2eaa83337033a84b3b3ab001cf0fd20f7885255a68e95270

```flow

test subscription.renew-monthly/success {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let newId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    match .subscription.renew-monthly(input, oldId, newId, handoffAt, Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        error _ => false
        ok updated => {
            match .store.subscription(newId, updated) {
                none => false
                some replacement => {
                    match .store.subscription(oldId, updated) {
                        none => false
                        some old => bool.and(replacement.term == "monthly", bool.and(replacement.started-at == handoffAt, old.cancelled-at == option.some<Instant>(handoffAt)))
                    }
                }
            }
        }
    }
    => true
}

```

#### actor — 0997de79afd308cd2eaa83337033a84b3b3ab001cf0fd20f7885255a68e95270

```flow

test subscription.renew-monthly/success {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let newId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    match .subscription.renew-monthly(input, oldId, newId, handoffAt, Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        error _ => false
        ok updated => {
            match .store.subscription(newId, updated) {
                none => false
                some replacement => {
                    match .store.subscription(oldId, updated) {
                        none => false
                        some old => bool.and(replacement.term == "monthly", bool.and(replacement.started-at == handoffAt, old.cancelled-at == option.some<Instant>(handoffAt)))
                    }
                }
            }
        }
    }
    => true
}

```

### Test attachment 2

#### seed — 996d0c0b37ea10b80a63d4a7ed9d3506d83a4c6d43c14b3f640ca263a27e024f

```flow

test subscription.renew-monthly/duplicate {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.renew-monthly(input, oldId, oldId, Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

#### actor — 996d0c0b37ea10b80a63d4a7ed9d3506d83a4c6d43c14b3f640ca263a27e024f

```flow

test subscription.renew-monthly/duplicate {
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .subscription.renew-monthly(input, oldId, oldId, Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00")) {
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }
    => "DUPLICATE_SUBSCRIPTION"
}

```

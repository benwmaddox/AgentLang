"""Freeze calibrated public inputs and create fresh actor copies exactly once."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
gate_path = REPO / '.agentlang/atomic-staging-165/full-validation-final.json'
gate = json.loads(gate_path.read_text(encoding='utf-8-sig')) if gate_path.exists() else None
assert gate is None or (gate['passed'] and len(gate['checks']) == 37)
focused_log = (REPO / '.agentlang/atomic-staging-165/validation.txt').read_text(encoding='utf-8-sig')
assert 'Flow Runtime tests passed: 39 groups, 1507 assertions.' in focused_log
core = ROOT / 'runtime/flow/AgentLang.Core.dll'
assert hashlib.sha256(core.read_bytes()).hexdigest() == '5ea9791c8fe33d516fcbd2c816ebe7068028490b2d4c4818666b56d4074ec0a8'
preparation = json.loads((ROOT / 'broker-preparation-evidence.json').read_text())
assert preparation['status'] == 'prompt-and-broker-configs-prepared; broker-smokes-passed'
freeze = ROOT / 'freeze'
actors = ROOT / 'actors'
if freeze.exists() or actors.exists():
    raise RuntimeError('Refusing to overwrite frozen inputs or actors')
freeze.mkdir()
actors.mkdir()
inventory = []

def record(path, kind):
    content = path.read_bytes()
    inventory.append({'kind': kind, 'path': path.relative_to(REPO).as_posix(),
        'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})

for arm, seed_name in [('flow', 'agentlang-project'), ('conventional', 'conventional')]:
    seed = ROOT / 'seeds' / seed_name
    actor = actors / arm
    shutil.copytree(seed, actor, ignore=shutil.ignore_patterns('bin', 'obj'))
    for path in sorted(actor.rglob('*')):
        if path.is_file():
            relative = path.relative_to(actor)
            assert path.read_bytes() == (seed / relative).read_bytes(), str(relative)
            record(path, 'initial-actor')
    config = json.loads((ROOT / f'broker-{arm}.json').read_text())
    cli = Path(config['cliDll'])
    assert hashlib.sha256(cli.read_bytes()).hexdigest() == config['cliSha256']
    for path in sorted(cli.parent.rglob('*')):
        if path.is_file(): record(path, 'runtime')

source_paths = [REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/PLAN.md',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/cases.json',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py',
    REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py',
    REPO / 'scripts/Start-SubagentTrialHostV2.ps1',
    REPO / 'src/AgentLang.Core/Runtime.fs', REPO / 'src/AgentLang.Core/AuthoringHelp.fs']
source_paths += [path for path in sorted((REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle').rglob('*'))
                 if path.is_file() and '__pycache__' not in path.parts]
source_paths += [ROOT / name for name in ['prompt-flow.md', 'prompt-conventional.md',
    'broker-flow.json', 'broker-conventional.json', 'broker-preparation-evidence.json']]
for path in source_paths:
    record(path, 'source-or-protocol')
    destination = freeze / 'source' / path.relative_to(REPO)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
manifest = {'status': 'frozen-before-dispatch',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'fullGatePassedAtDispatch': gate is not None, 'focusedRuntimeAssertions': 1507,
    'fullGatePendingAtDispatch': gate is None, 'model': 'gpt-6-luna', 'reasoning': 'max',
    'sequential': True, 'maxExchanges': 100, 'fixedTokenContextLimit': None,
    'callers': 'coordinator-authored for this trial', 'files': inventory}
(freeze / 'inventory.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(f'Frozen {len(inventory)} inputs; fresh actors created. No participants dispatched.')

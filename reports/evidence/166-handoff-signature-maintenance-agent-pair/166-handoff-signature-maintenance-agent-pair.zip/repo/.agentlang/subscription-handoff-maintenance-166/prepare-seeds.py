"""Copy accepted report-163 submissions; add only coordinator-owned callers.

Does not run the CLI or build. Flow callers must be defined/tested/committed after
the current runtime is freshly built. Refuses to overwrite any prepared seed.
"""
from pathlib import Path
import hashlib
import json
import shutil

REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'seeds'
OLD = REPO / '.agentlang/subscription-handoff-163/actors'
if DEST.exists():
    raise RuntimeError('Refusing to overwrite existing maintenance seeds')
DEST.mkdir()
shutil.copytree(OLD / 'flow', DEST / 'agentlang-project')
shutil.copytree(OLD / 'conventional', DEST / 'conventional',
                ignore=shutil.ignore_patterns('bin', 'obj', '__pycache__'))

flow = []
for term in ('annual', 'monthly'):
    name = f'subscription.renew-{term}'
    flow.append(f'''fn {name}(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError> {{
    doc "Replace a subscription with a {term} subscription using the existing handoff rules."

    .subscription.handoff(store, oldId, replacementId, "{term}", handoffAt, expiresAt)
}}

test {name}/success {{
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    let newId = SubscriptionId.new("40000000-0000-0000-0000-000000000001")
    let handoffAt = Instant.new("2026-01-15T12:00:00.0000000+00:00")
    match .{name}(input, oldId, newId, handoffAt, Instant.new("2026-02-15T12:00:00.0000000+00:00")) {{
        error _ => false
        ok updated => {{
            match .store.subscription(newId, updated) {{
                none => false
                some replacement => {{
                    match .store.subscription(oldId, updated) {{
                        none => false
                        some old => bool.and(replacement.term == "{term}", bool.and(replacement.started-at == handoffAt, old.cancelled-at == option.some<Instant>(handoffAt)))
                    }}
                }}
            }}
        }}
    }}
    => true
}}

test {name}/duplicate {{
    let input = business.seed(unit)
    let oldId = SubscriptionId.new("30000000-0000-0000-0000-000000000001")
    match .{name}(input, oldId, oldId, Instant.new("2026-01-15T12:00:00.0000000+00:00"), Instant.new("2026-02-15T12:00:00.0000000+00:00")) {{
        ok _ => "UNEXPECTED_OK"
        error failure => failure.code
    }}
    => "DUPLICATE_SUBSCRIPTION"
}}''')
(ROOT / 'flow-callers.agent').write_text('\n\n'.join(flow) + '\n', encoding='utf-8')

ops = DEST / 'conventional/Operations.fs'
ops_original = ops.read_text(encoding='utf-8')
for term, name in [('annual', 'renewAnnual'), ('monthly', 'renewMonthly')]:
    ops_original += f'''
    /// Replace a subscription with a {term} subscription using the existing handoff rules.
    let {name} (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId) (handoffAt: Instant) (expiresAt: Instant) : Result<Store, DomainError> =
        handoff store oldId replacementId "{term}" handoffAt expiresAt
'''
ops.write_text(ops_original, encoding='utf-8')

tests = DEST / 'conventional/SelfTests.fs'
source = tests.read_text(encoding='utf-8')
marker = '        printfn "Baseline and handoff checks passed"'
assert source.count(marker) == 1
additional = '''        let checkRenewal label expectedTerm renew =
            let local = Fixtures.create ()
            let newId = subscriptionId "40000000-0000-0000-0000-000000000001"
            let whenAt = Fixtures.instant 2026 1 15
            let expiry = Fixtures.instant 2026 2 15
            match renew local.Store local.OldSubscriptionId newId whenAt expiry with
            | Error error -> failwithf "%s unexpectedly failed: %s" label (DomainError.message error)
            | Ok updated ->
                let replacement = Store.subscription newId updated |> Option.defaultWith (fun () -> failwith "replacement missing")
                let old = Store.subscription local.OldSubscriptionId updated |> Option.defaultWith (fun () -> failwith "old subscription missing")
                assertEqual (label + " term") expectedTerm (Subscription.term replacement)
                assertEqual (label + " starts at handoff") whenAt (Subscription.startedAt replacement)
                assertEqual (label + " cancels old subscription") (Some whenAt) (Subscription.cancelledAt old)
                assertEqual (label + " preserves input") Active (Store.subscription local.OldSubscriptionId local.Store |> Option.map Subscription.status |> Option.defaultValue Cancelled)
            match renew local.Store local.OldSubscriptionId local.OldSubscriptionId whenAt expiry with
            | Error error -> assertEqual (label + " duplicate error") (DuplicateSubscription local.OldSubscriptionId) error
            | Ok _ -> failwith "duplicate renewal unexpectedly succeeded"
        checkRenewal "annual" "annual" Subscription.renewAnnual
        checkRenewal "monthly" "monthly" Subscription.renewMonthly

'''
tests.write_text(source.replace(marker, additional + marker), encoding='utf-8')

inventory = {'status': 'copied, not yet runtime-validated', 'priorActors': str(OLD), 'files': []}
for path in sorted(DEST.rglob('*')):
    if path.is_file():
        inventory['files'].append({'path': path.relative_to(DEST).as_posix(),
                                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(ROOT / 'copied-seeds.json').write_text(json.dumps(inventory, indent=2), encoding='utf-8')
print('Copied previous accepted submissions and prepared coordinator callers; runtime validation pending.')

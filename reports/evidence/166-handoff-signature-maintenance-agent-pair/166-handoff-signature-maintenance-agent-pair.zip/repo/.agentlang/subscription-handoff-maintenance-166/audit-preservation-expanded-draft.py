"""Audit saved maintenance-166 actors against their actual pre-trial seeds.

The audit is read-only with respect to seeds and actor projects. Flow manifest,
revision, source-object, function identity, and test-key checks are machine
checked. Conventional Operations.fs and SelfTests.fs changes are shown as diffs
for human review; this script does not claim those broad source edits are
semantically preserved by a brittle text heuristic.
"""

from __future__ import annotations

import argparse
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any


REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / ".agentlang" / "subscription-handoff-maintenance-166"
DEFAULT_FLOW_SEED = ROOT / "seeds" / "agentlang-project"
DEFAULT_FLOW_ACTOR = ROOT / "actors" / "flow"
DEFAULT_CONVENTIONAL_SEED = ROOT / "seeds" / "conventional"
DEFAULT_CONVENTIONAL_ACTOR = ROOT / "actors" / "conventional"
FLOW_TEST_BASELINE = ROOT / "setup-flow" / "responses.jsonl"
ALLOWED_FLOW_WORDS = (
    "subscription.handoff",
    "subscription.renew-annual",
    "subscription.renew-monthly",
)
GENERATED_PARTS = {".git", "bin", "obj", "__pycache__", "testresults"}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def add_check(checks: list[dict[str, Any]], name: str, passed: bool,
              details: dict[str, Any] | None = None) -> None:
    checks.append({"name": name, "passed": bool(passed), "details": details or {}})


def check_summary(checks: list[dict[str, Any]]) -> dict[str, Any]:
    failed = [row["name"] for row in checks if not row["passed"]]
    return {
        "passed": not failed,
        "checkCount": len(checks),
        "failedCheckNames": failed,
    }


def load_manifest(project: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    store = project / ".agentlang" / "store"
    current = read_json(store / "CURRENT")
    manifest_path = store / "manifests" / f"{current['manifestHash']}.json"
    manifest = read_json(manifest_path)
    return current, manifest


def word_rows(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {row["wordId"]: row for row in manifest.get("words", [])}


def revision_rows(manifest: dict[str, Any]) -> dict[tuple[str, int], dict[str, Any]]:
    return {
        (row["wordId"], row["revision"]): row
        for row in manifest.get("revisions", [])
    }


def current_revisions(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    words = word_rows(manifest)
    revisions = revision_rows(manifest)
    output = {}
    for word_id, word in words.items():
        key = (word_id, word["currentRevision"])
        if key not in revisions:
            raise ValueError(f"Current revision missing from manifest: {word['currentName']} {key[1]}")
        output[word["currentName"]] = revisions[key]
    return output


def object_path(project: Path, object_hash: str) -> Path:
    return project / ".agentlang" / "store" / "objects" / f"{object_hash}.agent"


def revision_object(project: Path, revision: dict[str, Any], field: str = "definition") -> str:
    object_hash = revision[field]["hash"]
    path = object_path(project, object_hash)
    if not path.is_file():
        raise FileNotFoundError(f"Missing {field} object {object_hash} for {revision['name']} r{revision['revision']}")
    return path.read_text(encoding="utf-8-sig")


def split_top_level(source: str, delimiter: str = ",") -> list[str]:
    """Split Flow/F#-like argument text without splitting nested forms or strings."""
    parts: list[str] = []
    start = 0
    stack: list[str] = []
    index = 0
    pairs = {")": "(", "]": "[", "}": "{"}
    while index < len(source):
        if source.startswith("//", index):
            newline = source.find("\n", index + 2)
            index = len(source) if newline < 0 else newline + 1
            continue
        char = source[index]
        if char == '"':
            index += 1
            while index < len(source):
                if source[index] == "\\":
                    index += 2
                elif source[index] == '"':
                    index += 1
                    break
                else:
                    index += 1
            continue
        if char in "([{":
            stack.append(char)
        elif char in ")]}" and stack and stack[-1] == pairs[char]:
            stack.pop()
        elif char == delimiter and not stack:
            parts.append(source[start:index].strip())
            start = index + 1
        index += 1
    tail = source[start:].strip()
    if tail or parts:
        parts.append(tail)
    return parts


def close_delimiter(source: str, opening: int, left: str = "(", right: str = ")") -> int | None:
    depth = 0
    index = opening
    while index < len(source):
        if source.startswith("//", index):
            newline = source.find("\n", index + 2)
            index = len(source) if newline < 0 else newline + 1
            continue
        char = source[index]
        if char == '"':
            index += 1
            while index < len(source):
                if source[index] == "\\":
                    index += 2
                elif source[index] == '"':
                    index += 1
                    break
                else:
                    index += 1
            continue
        if char == left:
            depth += 1
        elif char == right:
            depth -= 1
            if depth == 0:
                return index
        index += 1
    return None


def flow_calls(source: str, name: str) -> list[list[str]]:
    calls: list[list[str]] = []
    index = 0
    while index < len(source):
        if source.startswith("//", index):
            newline = source.find("\n", index + 2)
            index = len(source) if newline < 0 else newline + 1
            continue
        if source[index] == '"':
            index += 1
            while index < len(source):
                if source[index] == "\\":
                    index += 2
                elif source[index] == '"':
                    index += 1
                    break
                else:
                    index += 1
            continue
        if source.startswith(name, index):
            before = source[index - 1] if index else ""
            end_name = index + len(name)
            after_index = end_name
            while after_index < len(source) and source[after_index].isspace():
                after_index += 1
            left_boundary = not (before.isalnum() or before in "_-")
            if left_boundary and after_index < len(source) and source[after_index] == "(":
                close = close_delimiter(source, after_index)
                if close is None:
                    return calls
                inside = source[after_index + 1:close]
                calls.append(split_top_level(inside))
                index = close + 1
                continue
        index += 1
    return calls


def canonical_tokens(source: str) -> tuple[str, ...]:
    tokens: list[str] = []
    index = 0
    while index < len(source):
        if source.startswith("//", index):
            newline = source.find("\n", index + 2)
            index = len(source) if newline < 0 else newline + 1
            continue
        if source[index].isspace():
            index += 1
            continue
        if source[index] == '"':
            end = index + 1
            while end < len(source):
                if source[end] == "\\":
                    end += 2
                elif source[end] == '"':
                    end += 1
                    break
                else:
                    end += 1
            tokens.append(source[index:end])
            index = end
            continue
        identifier = re.match(r"[A-Za-z_][A-Za-z0-9_-]*\??", source[index:])
        if identifier:
            tokens.append(identifier.group(0))
            index += len(identifier.group(0))
            continue
        operator = next((op for op in ("=>", "->", "==", "!=", "<=", ">=", "&&", "||")
                         if source.startswith(op, index)), None)
        if operator:
            tokens.append(operator)
            index += len(operator)
        else:
            tokens.append(source[index])
            index += 1
    return tuple(tokens)


def function_signature(source: str, name: str) -> dict[str, Any] | None:
    pattern = re.compile(r"(?m)^\s*fn\s+" + re.escape(name) + r"\s*\(")
    match = pattern.search(source)
    if not match:
        return None
    opening = source.find("(", match.start())
    closing = close_delimiter(source, opening)
    if closing is None:
        return None
    args = split_top_level(source[opening + 1:closing])
    tail = source[closing + 1:]
    return_match = re.match(r"\s*->\s*([^\n{]+)", tail)
    return {
        "parameters": args,
        "returnType": " ".join(return_match.group(1).split()) if return_match else None,
    }


def current_test_sources(project: Path, manifest: dict[str, Any]) -> tuple[dict[tuple[str, str], dict[str, Any]], list[str]]:
    words = word_rows(manifest)
    revisions = current_revisions(manifest)
    output: dict[tuple[str, str], dict[str, Any]] = {}
    problems: list[str] = []
    for word_name, revision in revisions.items():
        for attachment in revision.get("tests", []):
            object_hash = attachment["hash"]
            path = object_path(project, object_hash)
            if not path.is_file():
                problems.append(f"missing test source object: {word_name} {object_hash}")
                continue
            source = path.read_text(encoding="utf-8-sig")
            match = re.search(r"(?m)^\s*test\s+([A-Za-z0-9_.?\-]+)/([A-Za-z0-9_.?\-]+)\s*\{", source)
            if not match:
                problems.append(f"unparsed test key: {word_name} {object_hash}")
                continue
            actual_word, case_name = match.groups()
            if actual_word != word_name:
                problems.append(f"test object word mismatch: manifest={word_name}, source={actual_word}, hash={object_hash}")
            key = (word_name, case_name)
            if key in output:
                problems.append(f"duplicate current test key: {word_name}/{case_name}")
            output[key] = {"hash": object_hash, "source": source}
    return output, problems


def load_seed_test_all(path: Path) -> tuple[set[tuple[str, str]], dict[str, Any]]:
    if not path.is_file():
        raise FileNotFoundError(f"Missing frozen 146-test setup response: {path}")
    matching: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row.get("kind") == "test" and "146/146" in row.get("text", ""):
            matching.append(row)
    if len(matching) != 1:
        raise ValueError(f"Expected one 146/146 test-all response in {path}; found {len(matching)}")
    response = matching[0]
    results = response.get("data", {}).get("results", [])
    keys = {(row["word"], row["name"]) for row in results}
    passed = len(results) == 146 and all(row.get("passed") is True for row in results)
    if not passed:
        raise ValueError(f"The frozen Flow seed response is not a passing 146-test baseline: {len(results)} rows")
    return keys, {
        "responsePath": str(path),
        "responseSha256": sha256_file(path),
        "reportedText": response.get("text"),
        "resultCount": len(results),
        "allPassed": passed,
        "caseKeyCount": len(keys),
    }


def unified_diff(before: str, after: str, before_name: str, after_name: str) -> str:
    return "\n".join(difflib.unified_diff(
        before.splitlines(), after.splitlines(),
        fromfile=before_name, tofile=after_name, lineterm="",
    ))


def flow_object_inventory(project: Path) -> dict[str, Path]:
    folder = project / ".agentlang" / "store" / "objects"
    if not folder.is_dir():
        return {}
    return {path.name: path for path in folder.iterdir() if path.is_file()}


def audit_flow(seed: Path, actor: Path, test_baseline_path: Path) -> dict[str, Any]:
    seed_current, seed_manifest = load_manifest(seed)
    actor_current, actor_manifest = load_manifest(actor)
    checks: list[dict[str, Any]] = []
    seed_words = word_rows(seed_manifest)
    actor_words = word_rows(actor_manifest)
    allowed_ids = {
        word["wordId"] for word in seed_words.values()
        if word["currentName"] in ALLOWED_FLOW_WORDS
    }
    seed_by_name = {row["currentName"]: row for row in seed_words.values()}
    actor_by_name = {row["currentName"]: row for row in actor_words.values()}
    seed_revisions = revision_rows(seed_manifest)
    actor_revisions = revision_rows(actor_manifest)
    seed_current_revs = current_revisions(seed_manifest)
    actor_current_revs = current_revisions(actor_manifest)

    word_id_sets_match = set(seed_words) == set(actor_words)
    add_check(checks, "No persistent function added or removed", word_id_sets_match, {
        "seedWordCount": len(seed_words), "actorWordCount": len(actor_words),
        "missingWordIds": sorted(set(seed_words) - set(actor_words)),
        "addedWordIds": sorted(set(actor_words) - set(seed_words)),
    })
    stable_identity_details = {}
    stable_identity_ok = True
    for word_id in sorted(set(seed_words) & set(actor_words)):
        old, new = seed_words[word_id], actor_words[word_id]
        name = old["currentName"]
        if name in ALLOWED_FLOW_WORDS:
            stable = all(old.get(key) == new.get(key) for key in set(old) | set(new) if key != "currentRevision")
        else:
            stable = old == new
        stable_identity_details[name] = {
            "wordId": word_id, "seedName": name, "actorName": new["currentName"],
            "seedRevision": old["currentRevision"], "actorRevision": new["currentRevision"],
            "stable": stable,
        }
        stable_identity_ok &= stable
    add_check(checks, "Existing word IDs and names retained", stable_identity_ok, stable_identity_details)

    seed_types = {row["name"]: row for row in seed_manifest.get("types", [])}
    actor_types = {row["name"]: row for row in actor_manifest.get("types", [])}
    add_check(checks, "No type added, removed, or changed", seed_types == actor_types, {
        "seedTypeCount": len(seed_types), "actorTypeCount": len(actor_types),
        "addedTypes": sorted(set(actor_types) - set(seed_types)),
        "removedTypes": sorted(set(seed_types) - set(actor_types)),
        "changedTypes": sorted(name for name in set(seed_types) & set(actor_types) if seed_types[name] != actor_types[name]),
    })
    add_check(checks, "Manifest format and project source unchanged",
              seed_manifest.get("formatVersion") == actor_manifest.get("formatVersion")
              and seed_manifest.get("projectSource") == actor_manifest.get("projectSource"), {
                  "seedFormatVersion": seed_manifest.get("formatVersion"),
                  "actorFormatVersion": actor_manifest.get("formatVersion"),
                  "seedProjectSource": seed_manifest.get("projectSource"),
                  "actorProjectSource": actor_manifest.get("projectSource"),
              })

    missing_prior_revisions = sorted(key for key in seed_revisions if key not in actor_revisions)
    changed_prior_revisions = sorted(
        f"{seed_revisions[key]['name']}@{key[1]}" for key in seed_revisions.keys() & actor_revisions.keys()
        if seed_revisions[key] != actor_revisions[key]
    )
    unexpected_new_revisions = sorted(
        f"{actor_revisions[key]['name']}@{key[1]}" for key in actor_revisions.keys() - seed_revisions.keys()
        if key[0] not in allowed_ids
    )
    new_allowed_revisions = sorted(
        f"{actor_revisions[key]['name']}@{key[1]}" for key in actor_revisions.keys() - seed_revisions.keys()
        if key[0] in allowed_ids
    )
    prior_rows_ok = not missing_prior_revisions and not changed_prior_revisions
    add_check(checks, "All prior revision rows preserved exactly", prior_rows_ok, {
        "seedRevisionCount": len(seed_revisions), "actorRevisionCount": len(actor_revisions),
        "missingPriorRevisions": missing_prior_revisions,
        "changedPriorRevisions": changed_prior_revisions,
    })
    add_check(checks, "No revisions added outside the three allowed words", not unexpected_new_revisions, {
        "unexpectedNewRevisions": unexpected_new_revisions,
        "newAllowedRevisions": new_allowed_revisions,
    })

    maturity_rows: dict[str, Any] = {}
    maturity_ok = True
    revision_advance_ok = True
    for name in ALLOWED_FLOW_WORDS:
        old_word, new_word = seed_by_name.get(name), actor_by_name.get(name)
        old_rev = seed_current_revs.get(name)
        new_rev = actor_current_revs.get(name)
        old_maturity = old_rev.get("maturity") if old_rev else None
        new_maturity = new_rev.get("maturity") if new_rev else None
        maturity_ok &= old_maturity == "library" and new_maturity == "library"
        advanced = bool(old_word and new_word and new_word["currentRevision"] > old_word["currentRevision"])
        revision_advance_ok &= advanced
        maturity_rows[name] = {
            "wordId": new_word.get("wordId") if new_word else None,
            "seedRevision": old_word.get("currentRevision") if old_word else None,
            "actorRevision": new_word.get("currentRevision") if new_word else None,
            "seedMaturity": old_maturity, "actorMaturity": new_maturity,
            "revisionAdvanced": advanced,
        }
    add_check(checks, "Changed functions keep library maturity", maturity_ok, maturity_rows)
    add_check(checks, "All three existing functions received a new revision", revision_advance_ok, maturity_rows)

    seed_objects = flow_object_inventory(seed)
    actor_objects = flow_object_inventory(actor)
    missing_objects = sorted(set(seed_objects) - set(actor_objects))
    changed_objects = sorted(
        name for name in set(seed_objects) & set(actor_objects)
        if seed_objects[name].read_bytes() != actor_objects[name].read_bytes()
    )
    invalid_seed_hash_names = sorted(
        name for name, path in seed_objects.items()
        if re.fullmatch(r"[0-9a-f]{64}\.agent", name)
        and sha256_file(path) != path.stem
    )
    invalid_actor_hash_names = sorted(
        name for name, path in actor_objects.items()
        if re.fullmatch(r"[0-9a-f]{64}\.agent", name)
        and sha256_file(path) != path.stem
    )
    objects_ok = not missing_objects and not changed_objects and not invalid_seed_hash_names and not invalid_actor_hash_names
    add_check(checks, "Seed content-addressed source objects remain byte-for-byte", objects_ok, {
        "seedObjectCount": len(seed_objects), "actorObjectCount": len(actor_objects),
        "missingSeedObjects": missing_objects, "changedSeedObjects": changed_objects,
        "invalidSeedObjectHashes": invalid_seed_hash_names,
        "invalidActorObjectHashes": invalid_actor_hash_names,
        "addedObjectCount": len(set(actor_objects) - set(seed_objects)),
    })

    seed_dictionary = seed / "dictionary.agent"
    actor_dictionary = actor / "dictionary.agent"
    dictionary_unchanged = (
        seed_dictionary.is_file() and actor_dictionary.is_file()
        and seed_dictionary.read_bytes() == actor_dictionary.read_bytes()
    )
    add_check(checks, "Project dictionary source file unchanged", dictionary_unchanged, {
        "seedSha256": sha256_file(seed_dictionary) if seed_dictionary.is_file() else None,
        "actorSha256": sha256_file(actor_dictionary) if actor_dictionary.is_file() else None,
    })

    baseline_test_keys, test_all_info = load_seed_test_all(test_baseline_path)
    seed_tests, seed_test_problems = current_test_sources(seed, seed_manifest)
    actor_tests, actor_test_problems = current_test_sources(actor, actor_manifest)
    seed_test_keys = set(seed_tests)
    actor_test_keys = set(actor_tests)
    baseline_seed_tests_match = baseline_test_keys == seed_test_keys
    add_check(checks, "146-test setup result matches seed test-case keys",
              baseline_seed_tests_match and not seed_test_problems, {
                  **test_all_info,
                  "seedManifestTestCount": len(seed_test_keys),
                  "missingFromSeedManifest": sorted(baseline_test_keys - seed_test_keys),
                  "extraInSeedManifest": sorted(seed_test_keys - baseline_test_keys),
                  "seedTestSourceProblems": seed_test_problems,
              })
    missing_baseline_tests = sorted(baseline_test_keys - actor_test_keys)
    add_check(checks, "All prior Flow test-case keys retained", not missing_baseline_tests and not actor_test_problems, {
        "baselineTestCount": len(baseline_test_keys), "actorCurrentTestCount": len(actor_test_keys),
        "missingBaselineTestKeys": [f"{word}/{name}" for word, name in missing_baseline_tests],
        "actorTestSourceProblems": actor_test_problems,
    })

    false_shape_rows: list[dict[str, Any]] = []
    false_shape_ok = True
    for key in sorted(key for key in baseline_test_keys if key[0] == "subscription.handoff"):
        old_test = seed_tests.get(key)
        new_test = actor_tests.get(key)
        if not old_test or not new_test:
            false_shape_ok = False
            false_shape_rows.append({"testKey": f"{key[0]}/{key[1]}", "passed": False, "reason": "test source missing"})
            continue
        old_calls = flow_calls(old_test["source"], "subscription.handoff")
        new_calls = flow_calls(new_test["source"], "subscription.handoff")
        required = Counter(tuple(canonical_tokens(arg) for arg in args) for args in old_calls)
        available = Counter(
            tuple(canonical_tokens(arg) for arg in args[:-1])
            for args in new_calls
            if len(args) == 7 and canonical_tokens(args[-1]) == ("false",)
        )
        missing_calls = list((required - available).elements())
        passed = bool(old_calls) and not missing_calls and all(len(args) == 6 for args in old_calls)
        false_shape_ok &= passed
        false_shape_rows.append({
            "testKey": f"{key[0]}/{key[1]}", "passed": passed,
            "priorTargetCallCount": len(old_calls), "newTargetCallCount": len(new_calls),
            "priorCallsWithSixArguments": all(len(args) == 6 for args in old_calls),
            "priorCallsPreservedWithTrailingFalse": len(missing_calls) == 0,
        })
    add_check(checks, "Prior handoff test calls retain arguments with only trailing false added",
              false_shape_ok, {"tests": false_shape_rows})

    function_checks: list[dict[str, Any]] = []
    function_diffs: dict[str, str] = {}
    wrapper_semantics_ok = True
    signature_ok = True
    for name in ALLOWED_FLOW_WORDS:
        old_rev = seed_current_revs.get(name)
        new_rev = actor_current_revs.get(name)
        row: dict[str, Any] = {"name": name, "presentInSeed": old_rev is not None, "presentInActor": new_rev is not None}
        if old_rev is None or new_rev is None:
            function_checks.append(row)
            signature_ok = False
            if name != "subscription.handoff":
                wrapper_semantics_ok = False
            continue
        old_source = revision_object(seed, old_rev)
        new_source = revision_object(actor, new_rev)
        diff = unified_diff(old_source, new_source, f"seed/{name}@{old_rev['revision']}", f"actor/{name}@{new_rev['revision']}")
        if diff:
            function_diffs[name] = diff
        signature = function_signature(new_source, name)
        row["actorRevision"] = new_rev["revision"]
        row["definitionHash"] = new_rev["definition"]["hash"]
        row["signature"] = signature
        if name == "subscription.handoff":
            params = signature.get("parameters", []) if signature else []
            okay = (
                len(params) == 7
                and params[-1].replace(" ", "") == "dryRun:Bool"
                and signature.get("returnType", "").replace(" ", "") == "Result<Store,BusinessError>"
            )
            signature_ok &= okay
            row["sevenArgumentDryRunSignature"] = okay
        else:
            params = signature.get("parameters", []) if signature else []
            signature_valid = len(params) == 5
            signature_ok &= signature_valid
            calls = flow_calls(new_source, "subscription.handoff")
            expected_term = '"annual"' if name.endswith("annual") else '"monthly"'
            maps_term_and_false = any(
                len(args) == 7
                and canonical_tokens(args[3]) == (expected_term,)
                and canonical_tokens(args[-1]) == ("false",)
                for args in calls
            )
            wrapper_semantics_ok &= maps_term_and_false
            row["fiveArgumentSignature"] = signature_valid
            row["handoffCallCount"] = len(calls)
            row["mapsExpectedTermAndFalse"] = maps_term_and_false
        function_checks.append(row)
    add_check(checks, "Target and retained caller public signatures preserved", signature_ok, {
        "functions": function_checks,
    })
    add_check(checks, "Annual/monthly callers map fixed term and false", wrapper_semantics_ok, {
        "functions": [row for row in function_checks if row["name"] != "subscription.handoff"],
    })

    changed_test_diffs: dict[str, str] = {}
    for key in sorted(baseline_test_keys & actor_test_keys):
        old_test, new_test = seed_tests.get(key), actor_tests.get(key)
        if old_test and new_test and old_test["source"] != new_test["source"]:
            changed_test_diffs[f"{key[0]}/{key[1]}"] = unified_diff(
                old_test["source"], new_test["source"],
                f"seed-test/{key[0]}/{key[1]}", f"actor-test/{key[0]}/{key[1]}",
            )

    return {
        "seed": str(seed), "actor": str(actor),
        "seedCurrentManifest": seed_current.get("manifestHash"),
        "actorCurrentManifest": actor_current.get("manifestHash"),
        "machineChecks": checks,
        "machineSummary": check_summary(checks),
        "manualReviewRequired": [
            "Review functionDiffs for the intended handoff dryRun change and the two retained callers forwarding false.",
            "Review changedBaselineTestDiffs to confirm original assertions remain while prior six-argument handoff calls only gain trailing false; new dry-run tests may be added.",
        ],
        "functionDiffs": function_diffs,
        "changedBaselineTestDiffs": changed_test_diffs,
        "newActorTests": [f"{word}/{name}" for word, name in sorted(actor_test_keys - baseline_test_keys)],
    }


def source_files(project: Path) -> dict[str, Path]:
    files: dict[str, Path] = {}
    for path in project.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(project)
        if any(part.lower() in GENERATED_PARTS for part in relative.parts):
            continue
        files[relative.as_posix()] = path
    return files


def audit_conventional(seed: Path, actor: Path) -> dict[str, Any]:
    seed_files = source_files(seed)
    actor_files = source_files(actor)
    allowed = {"Operations.fs", "SelfTests.fs"}
    seed_names, actor_names = set(seed_files), set(actor_files)
    missing = sorted(seed_names - actor_names)
    added = sorted(actor_names - seed_names)
    changed = sorted(
        path for path in seed_names & actor_names
        if seed_files[path].read_bytes() != actor_files[path].read_bytes()
    )
    unauthorized_changes = sorted(path for path in changed if path not in allowed)
    unauthorized_missing = sorted(path for path in missing if path not in allowed)
    unauthorized_added = sorted(path for path in added if path not in allowed)
    scope_ok = not unauthorized_changes and not unauthorized_missing and not unauthorized_added
    unchanged_files = sorted(path for path in seed_names & actor_names if path not in allowed and path not in changed)
    diffs: dict[str, str] = {}
    summaries: dict[str, Any] = {}
    for relative in sorted(allowed):
        if relative not in seed_files or relative not in actor_files:
            summaries[relative] = {"presentInSeed": relative in seed_files, "presentInActor": relative in actor_files}
            continue
        before = seed_files[relative].read_text(encoding="utf-8-sig")
        after = actor_files[relative].read_text(encoding="utf-8-sig")
        difference = unified_diff(before, after, f"seed/{relative}", f"actor/{relative}")
        if difference:
            diffs[relative] = difference
        before_lines, after_lines = before.splitlines(), after.splitlines()
        summaries[relative] = {
            "seedSha256": sha256_file(seed_files[relative]),
            "actorSha256": sha256_file(actor_files[relative]),
            "seedLineCount": len(before_lines), "actorLineCount": len(after_lines),
            "changed": before != after,
        }
    checks = [{
        "name": "Only Operations.fs and SelfTests.fs changed in the source project",
        "passed": scope_ok,
        "details": {
            "allowedChangedFiles": sorted(set(changed) & allowed),
            "unauthorizedChangedFiles": unauthorized_changes,
            "missingSeedFiles": missing,
            "unauthorizedMissingFiles": unauthorized_missing,
            "addedActorFiles": added,
            "unauthorizedAddedFiles": unauthorized_added,
            "unchangedInfrastructureFiles": unchanged_files,
        },
    }]
    reference_ok = "Reference/Business.fs" in seed_files and "Reference/Business.fs" in actor_files and (
        seed_files["Reference/Business.fs"].read_bytes() == actor_files["Reference/Business.fs"].read_bytes()
    )
    checks.append({
        "name": "Frozen Reference/Business.fs remains byte-for-byte unchanged",
        "passed": reference_ok,
        "details": {
            "seedSha256": sha256_file(seed_files["Reference/Business.fs"]) if "Reference/Business.fs" in seed_files else None,
            "actorSha256": sha256_file(actor_files["Reference/Business.fs"]) if "Reference/Business.fs" in actor_files else None,
        },
    })
    return {
        "seed": str(seed), "actor": str(actor),
        "machineChecks": checks,
        "machineSummary": check_summary(checks),
        "allowedFileSummaries": summaries,
        "manualReviewRequired": [
            "Inspect Operations.fs diff: only handoff and the two retained renewal callers may change; aliases, forwarding functions, and other foundation source must remain intact.",
            "Inspect SelfTests.fs diff: original assertions must remain; existing handoff calls may add false, with new dry-run and replacement-creation-failure assertions added.",
        ],
        "diffsForManualReview": diffs,
    }


def run_audit(args: argparse.Namespace) -> dict[str, Any]:
    seed_flow = args.flow_seed.resolve()
    actor_flow = args.flow_actor.resolve()
    seed_conventional = args.conventional_seed.resolve()
    actor_conventional = args.conventional_actor.resolve()
    missing_actors = [str(path) for path in (actor_flow, actor_conventional) if not path.is_dir()]
    report: dict[str, Any] = {
        "status": "not-ready" if missing_actors else "machine-checks-passed-manual-review-required",
        "readOnly": True,
        "baseline": {
            "flowSeed": str(seed_flow),
            "conventionalSeed": str(seed_conventional),
            "flow146TestResponse": str(args.flow_test_baseline.resolve()),
        },
        "actorPathsMissing": missing_actors,
        "scope": {
            "allowedFlowWords": list(ALLOWED_FLOW_WORDS),
            "allowedConventionalFiles": ["Operations.fs", "SelfTests.fs"],
        },
        "disclaimer": "A passing machine audit does not replace the listed manual source-diff reviews and does not describe preservation until run against completed trial actors.",
    }
    if missing_actors:
        return report
    if not seed_flow.is_dir() or not seed_conventional.is_dir():
        raise FileNotFoundError("A configured 166 seed directory is missing")
    flow = audit_flow(seed_flow, actor_flow, args.flow_test_baseline.resolve())
    conventional = audit_conventional(seed_conventional, actor_conventional)
    report["flow"] = flow
    report["conventional"] = conventional
    machine_passed = flow["machineSummary"]["passed"] and conventional["machineSummary"]["passed"]
    report["status"] = "machine-checks-passed-manual-review-required" if machine_passed else "machine-check-failed"
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--flow-seed", type=Path, default=DEFAULT_FLOW_SEED,
                        help="Actual maintenance-166 Flow seed project")
    parser.add_argument("--flow-actor", type=Path, default=DEFAULT_FLOW_ACTOR,
                        help="Completed Flow actor project (created after the trial)")
    parser.add_argument("--conventional-seed", type=Path, default=DEFAULT_CONVENTIONAL_SEED,
                        help="Actual maintenance-166 conventional seed")
    parser.add_argument("--conventional-actor", type=Path, default=DEFAULT_CONVENTIONAL_ACTOR,
                        help="Completed conventional actor project (created after the trial)")
    parser.add_argument("--flow-test-baseline", type=Path, default=FLOW_TEST_BASELINE,
                        help="Frozen 146/146 setup-flow test-all response JSONL")
    parser.add_argument("--output", type=Path,
                        help="Optional separate evidence path for the JSON report")
    args = parser.parse_args()
    report = run_audit(args)
    serialized = json.dumps(report, indent=2, ensure_ascii=False)
    if args.output:
        output = args.output.resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(serialized + "\n", encoding="utf-8")
    print(serialized)
    return 1 if report["status"] == "machine-check-failed" else 0


if __name__ == "__main__":
    sys.exit(main())

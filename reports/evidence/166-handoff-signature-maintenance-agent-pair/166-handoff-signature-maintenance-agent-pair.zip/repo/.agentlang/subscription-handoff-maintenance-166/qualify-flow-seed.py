"""Add disclosed coordinator callers to the retained report-163 project once."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
project = ROOT / 'seeds/agentlang-project'
evidence = ROOT / 'setup-flow'
if evidence.exists():
    raise RuntimeError('Refusing to rerun seed qualification over existing evidence')
evidence.mkdir()
source = (ROOT / 'flow-callers.agent').read_text(encoding='utf-8')
requests = [
    {'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'source': source},
    {'op': 'test', 'word': 'subscription.renew-annual'},
    {'op': 'test', 'word': 'subscription.renew-monthly'},
    {'op': 'commit', 'library': True},
    {'op': 'test-all'},
    {'op': 'words'},
]
lines = '\n'.join(json.dumps(row) for row in requests) + '\n'
command = ['dotnet', str(ROOT / 'runtime/flow/AgentLang.Cli.dll'),
           '--project', str(project), '--filesystem', 'virtual', '--jsonl']
process = subprocess.run(command, input=lines, text=True, encoding='utf-8',
                         capture_output=True, cwd=REPO, timeout=600)
(evidence / 'requests.jsonl').write_text(lines, encoding='utf-8')
(evidence / 'responses.jsonl').write_text(process.stdout, encoding='utf-8')
(evidence / 'stderr.txt').write_text(process.stderr, encoding='utf-8')
(evidence / 'command.json').write_text(json.dumps({'command': command,
    'exitCode': process.returncode, 'callers': 'coordinator-authored'}, indent=2), encoding='utf-8')
assert process.returncode == 0, process.stderr
rows = [json.loads(line) for line in process.stdout.splitlines()]
assert len(rows) == len(requests) and all(row.get('ok') for row in rows), process.stdout
tests = rows[4]['data']['results']
assert len(tests) == 146 and all(case['passed'] for case in tests), rows[4]
words = rows[5]['data']['words']
assert len(words) == 217 and all(word['maturity'] == 'library' for word in words), rows[5]
print('Flow retained seed qualified: 217 library words, 146 passing tests.')

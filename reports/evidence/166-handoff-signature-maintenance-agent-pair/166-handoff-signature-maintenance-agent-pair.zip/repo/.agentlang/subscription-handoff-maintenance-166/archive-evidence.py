#!/usr/bin/env python3
"""Create the maintenance-166 evidence ZIP and verify its SHA-256 manifest."""

from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TASK = ROOT / ".agentlang/subscription-handoff-maintenance-166"
DEST = ROOT / "reports/evidence/166-handoff-signature-maintenance-agent-pair"
ZIP_NAME = "166-handoff-signature-maintenance-agent-pair.zip"
MANIFEST = "ARCHIVE-MANIFEST.json"
SKIP = {"bin", "obj", "__pycache__", "actor-project-copy"}
FILES: dict[str, tuple[str, bytes]] = {}


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


def add_bytes(name: str, source: str, data: bytes) -> None:
    name = name.replace("\\", "/")
    if name in FILES and FILES[name][1] != data:
        raise ValueError(f"Different files map to {name}")
    FILES[name] = (source, data)


def add_file(path: Path, name: str | None = None, source: str | None = None) -> None:
    if not path.is_file():
        raise FileNotFoundError(path)
    add_bytes(name or f"repo/{path.relative_to(ROOT).as_posix()}",
              source or path.relative_to(ROOT).as_posix(), path.read_bytes())


def add_tree(path: Path, excludes: set[str] | None = None) -> None:
    excluded = {item.casefold() for item in (excludes or set())}
    for file in sorted(path.rglob("*")):
        if not file.is_file():
            continue
        relative = file.relative_to(path)
        parts = [part.casefold() for part in relative.parts]
        if any(part in SKIP or part in excluded or part.startswith("tmp-") for part in parts):
            continue
        add_file(file)


def main() -> None:
    if DEST.exists():
        raise SystemExit(f"Refusing to overwrite {DEST}")

    # Frozen start state, final actors, seeds, and pinned runtimes.
    for name in ("freeze", "actors", "seeds", "runtime"):
        add_tree(TASK / name)

    # Trial scripts/configuration and frozen protocol/scorer source.
    for file in sorted(TASK.iterdir()):
        if file.is_file():
            add_file(file)
    plan = ROOT / "experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/PLAN.md"
    add_file(plan)
    add_tree(plan.parent / "oracle")

    # Broker smoke and seed qualification logs; omit copied broker projects.
    add_tree(TASK / "broker-smoke", {"flow-project", "conventional-project"})
    add_tree(TASK / "setup-flow")
    add_tree(TASK / "flow-oracle-runs")
    add_tree(TASK / "flow-review")
    add_tree(TASK / "review-conventional-audit")
    for file in sorted((TASK / "flow-final-validation").iterdir()):
        if file.is_file():
            add_file(file)

    # Conventional score outputs and route smoke; omit disposable build copies.
    add_tree(TASK / "control/conventional", {"control-project", "participant-project"})
    for file in sorted((TASK / "control/conventional-participant-route").iterdir()):
        if file.is_file():
            add_file(file)
    for folder in sorted((TASK / "control/flow").glob("*-preparation")):
        if folder.is_dir():
            add_tree(folder)

    # Historical 161 oracle dependencies used by both scorers.
    old161 = ROOT / "experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle"
    for name in ("cases.json", "model-checks.json", "model.py", "score_agentlang.py"):
        add_file(old161 / name, f"historical/161/oracle/{name}")

    # Extract only frozen 163 protocol/oracle inputs; its ZIP also contains
    # control copies, which are deliberately omitted. Keep the original manifest.
    old163zip = ROOT / ".agentlang/subscription-handoff-163/freeze/inputs.zip"
    add_file(ROOT / ".agentlang/subscription-handoff-163/freeze/manifest.json",
             "historical/163/freeze/manifest.json")
    selected = ["protocol/PLAN.md", "protocol/oracle/cases.json",
                "protocol/oracle/model-checks.json", "protocol/oracle/model.py",
                "protocol/oracle/score_agentlang.py"]
    with zipfile.ZipFile(old163zip) as archive:
        for name in selected:
            add_bytes(f"historical/163/frozen-inputs/{name}",
                      f"{old163zip.relative_to(ROOT).as_posix()}!/{name}", archive.read(name))
    old163 = ROOT / ".agentlang/subscription-handoff-163/control/conventional"
    for name in ("ConventionalControl.fsproj", "Handoff.fs", "ParticipantControl.fsproj",
                 "ParticipantProgram.fs", "Program.fs", "Scorer.fs", "score_conventional.py"):
        add_file(old163 / name, f"historical/163/conventional-control/{name}")

    readme = """# Subscription handoff maintenance trial 166 evidence

The final Flow scorer passed 132/132 cases (66 handoff plus 66 retained-caller
cases). The final conventional scorer passed 132/132 (66 handoff plus 33 for
each retained wrapper). Attached Flow tests passed 149/149. The saved Flow
metadata coordinator error is preserved in the final-validation logs; its
summary was regenerated from saved responses without rerunning tests.

The ZIP contains the freeze inventory/source, seeds, final actors, pinned
runtimes, prompts/configs, broker traces, scorer/control outcomes, and review
audits. `ARCHIVE-MANIFEST.json` gives every payload entry's source, byte count,
and SHA-256. Temporary directories, generated bin/obj output, and disposable
full control/scorer/broker project copies are excluded. For the historical 163
freeze, only the frozen PLAN/oracle files and manifest are included because
the original ZIP contains full control copy trees.
"""

    payload = [{"path": name, "source": source, "bytes": len(data), "sha256": digest(data)}
               for name, (source, data) in sorted(FILES.items())]
    readme_bytes = readme.encode("utf-8")
    payload.append({"path": "README.md", "source": "generated archive description",
                    "bytes": len(readme_bytes), "sha256": digest(readme_bytes)})
    manifest_data = (json.dumps({
        "format": "sha256-entry-manifest/v1",
        "trial": "subscription-handoff-maintenance-166",
        "createdUtc": datetime.now(timezone.utc).isoformat(),
        "archive": ZIP_NAME,
        "entries": payload,
        "exclusions": ["all tmp-* directories", "all bin/obj directories",
                       "disposable control/scorer/broker project-copy trees",
                       "historical 163 freeze entries outside protocol/PLAN.md and protocol/oracle/*"],
    }, indent=2, ensure_ascii=False) + "\n").encode("utf-8")

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (_, data) in sorted(FILES.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        for name, data in (("README.md", readme_bytes), (MANIFEST, manifest_data)):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    archive_bytes = buffer.getvalue()
    with zipfile.ZipFile(BytesIO(archive_bytes)) as archive:
        if archive.testzip() is not None or archive.read(MANIFEST) != manifest_data:
            raise ValueError("ZIP CRC or embedded manifest verification failed")
        for item in json.loads(manifest_data)["entries"]:
            data = archive.read(item["path"])
            if len(data) != item["bytes"] or digest(data) != item["sha256"]:
                raise ValueError(f"SHA-256 verification failed: {item['path']}")

    DEST.mkdir(parents=True, exist_ok=False)
    archive_path = DEST / ZIP_NAME
    with archive_path.open("xb") as stream:
        stream.write(archive_bytes)
    (DEST / "README.md").write_text(readme, encoding="utf-8", newline="\n")
    (DEST / MANIFEST).write_bytes(manifest_data)
    archive_sha = digest(archive_bytes)
    (DEST / f"{ZIP_NAME}.sha256").write_text(f"{archive_sha}  {ZIP_NAME}\n", encoding="ascii")
    report = {"archive": ZIP_NAME, "sha256": archive_sha, "bytes": len(archive_bytes),
              "zipEntries": len(payload) + 1, "verifiedPayloadEntries": len(payload),
              "verification": "ZIP CRC and every manifest entry SHA-256 passed"}
    (DEST / "archive-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

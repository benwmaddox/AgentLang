"""Smoke-test both trial-166 broker configurations on disposable seed copies.

The checks use the pinned runtimes and never dispatch participant agents.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
BROKER = REPO / "scripts/Start-SubagentTrialHostV2.ps1"
TEMP = ROOT / "tmp-broker-smoke"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inventory(directory: Path) -> list[dict[str, object]]:
    items = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and not {"bin", "obj"}.intersection(path.relative_to(directory).parts):
            items.append({
                "path": path.relative_to(directory).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256(path),
            })
    return items


def run_arm(arm: str, attempt: str) -> dict[str, object]:
    config_path = ROOT / f"broker-{arm}.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    prompt_path = ROOT / f"prompt-{arm}.md"
    seed = ROOT / "seeds" / ("agentlang-project" if arm == "flow" else "conventional")
    project = ROOT / "broker-smoke" / f"attempt-{attempt}" / f"{arm}-project"
    evidence = ROOT / "broker-smoke" / f"attempt-{attempt}" / arm
    trace = evidence / "trace.jsonl"
    if project.exists() or evidence.exists():
        raise FileExistsError(f"Refusing to overwrite prior broker smoke artifacts for {arm}: {project}")
    if not seed.is_dir():
        raise FileNotFoundError(f"Prepared seed is missing: {seed}")
    project.parent.mkdir(parents=True, exist_ok=True)
    evidence.mkdir(parents=True)
    source_inventory = inventory(seed)
    shutil.copytree(seed, project, ignore=shutil.ignore_patterns("bin", "obj"))
    copied_inventory = inventory(project)
    if source_inventory != copied_inventory:
        raise RuntimeError(f"Disposable {arm} project does not match the seed inventory")

    if arm == "flow":
        operations = [
            {"op": "describe", "word": "subscription.handoff"},
            {"op": "callers", "word": "subscription.handoff"},
            {"op": "replace-word", "word": "subscription.handoff"},
            {"op": "test-all"},
        ]
    else:
        operations = [
            {"op": "inspect"},
            {"op": "read", "path": "Operations.fs"},
            {"op": "read", "path": "Reference/Business.fs"},
            {"op": "validate"},
        ]

    requests = "\n".join(json.dumps(row, ensure_ascii=False) for row in operations + [{"op": "host.close"}]) + "\n"
    requests_path = evidence / "requests.jsonl"
    stdout_path = evidence / "stdout.txt"
    stderr_path = evidence / "stderr.txt"
    requests_path.write_text(requests, encoding="utf-8", newline="\n")
    command = [
        "pwsh", "-NoProfile", "-File", str(BROKER),
        "-CliDll", config["cliDll"],
        "-ProjectPath", str(project),
        "-TracePath", str(trace),
        "-AllowedOperations", ",".join(config["allowedOperations"]),
        "-Profile", config["profile"],
        "-ExchangeTimeoutMilliseconds", str(config["exchangeTimeoutMilliseconds"]),
        "-MaxExchanges", str(config["maxExchanges"]),
    ]
    if config["additionalCliArguments"]:
        command.extend([
            "-AdditionalCliArgumentsJson",
            json.dumps(config["additionalCliArguments"], separators=(",", ":")),
        ])
    env = dict(os.environ)
    TEMP.mkdir(parents=True, exist_ok=True)
    env["TEMP"] = str(TEMP)
    env["TMP"] = str(TEMP)
    process = subprocess.run(
        command,
        input=requests,
        text=True,
        encoding="utf-8",
        capture_output=True,
        cwd=REPO,
        env=env,
        timeout=600,
        check=False,
    )
    stdout_path.write_text(process.stdout, encoding="utf-8", newline="\n")
    stderr_path.write_text(process.stderr, encoding="utf-8", newline="\n")
    rows = [json.loads(line) for line in process.stdout.splitlines() if line.strip().startswith("{")]
    if process.returncode != 0:
        raise RuntimeError(f"{arm} broker smoke exited {process.returncode}; see {stderr_path}")
    successful_rows = [row for index, row in enumerate(rows) if not (arm == "flow" and index == 2)]
    if len(rows) != len(operations) or not all(row.get("ok") is True for row in successful_rows):
        raise RuntimeError(f"{arm} broker smoke failed its operations; see {stdout_path}")
    if arm == "flow" and not (
        rows[2].get("ok") is False
        and rows[2].get("error", {}).get("code") == "REPLACE_NOT_STAGED"
    ):
        raise RuntimeError("Flow broker did not admit replace-word to the runtime; expected REPLACE_NOT_STAGED on the clean seed")

    terminal = json.loads(trace.read_text(encoding="utf-8").splitlines()[-1])
    if not (
        terminal.get("event") == "session-end"
        and terminal.get("terminationKind") == "host-close"
        and terminal.get("hostExitCode") == 0
        and terminal.get("runtimeExitCode") == 0
    ):
        raise RuntimeError(f"{arm} broker did not close cleanly; see {trace}")

    extra: dict[str, object] = {}
    if arm == "flow":
        test_results = rows[3]["data"]["results"]
        if len(test_results) != 146 or not all(item.get("passed") for item in test_results):
            raise RuntimeError("Flow smoke did not pass all 146 retained baseline tests")
        extra["baselineTestCount"] = len(test_results)
        extra["baselineTargetInputCount"] = len(rows[0]["data"]["inputs"])
        extra["retainedCallerNames"] = rows[1]["data"]
        extra["replaceWordRouteAdmitted"] = True
    else:
        extra["referenceReadSucceeded"] = True
        extra["baselineValidationSucceeded"] = True

    return {
        "arm": arm,
        "status": "pass",
        "participantDispatched": False,
        "pinnedCliDll": config["cliDll"],
        "pinnedCliSha256": config["cliSha256"],
        "promptSha256": sha256(prompt_path),
        "brokerConfigSha256": sha256(config_path),
        "seedPath": str(seed),
        "seedInventory": source_inventory,
        "disposableProjectPath": str(project),
        "disposableProjectMatchesSeed": True,
        "operations": [row["op"] for row in operations],
        "brokerCommand": command,
        "hostClose": terminal,
        "evidence": {
            "requests": str(requests_path),
            "stdout": str(stdout_path),
            "stderr": str(stderr_path),
            "trace": str(trace),
        },
        **extra,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", default="001", help="Unique smoke-evidence folder suffix.")
    args = parser.parse_args()
    if not args.attempt or any(character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for character in args.attempt):
        raise ValueError("Attempt must be a nonempty path-safe identifier")

    results = [run_arm(arm, args.attempt) for arm in ("flow", "conventional")]
    summary = {
        "status": "pass",
        "trial": "subscription-handoff-maintenance-166",
        "participantDispatched": False,
        "modelPlan": "fresh gpt-6-luna/max participants, sequential, 100 exchanges each",
        "tempDirectory": str(TEMP),
        "arms": results,
    }
    summary_path = ROOT / "broker-smoke" / f"attempt-{args.attempt}" / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": summary["status"],
        "participantDispatched": False,
        "arms": [
            {"arm": item["arm"], "status": item["status"], **{key: item[key] for key in ("baselineTestCount", "baselineTargetInputCount", "retainedCallerNames", "replaceWordRouteAdmitted", "referenceReadSucceeded", "baselineValidationSucceeded") if key in item}}
            for item in results
        ],
        "evidence": str(summary_path),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

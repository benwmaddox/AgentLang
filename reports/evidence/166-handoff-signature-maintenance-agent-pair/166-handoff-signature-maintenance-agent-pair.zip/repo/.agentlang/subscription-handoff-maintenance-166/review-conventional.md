# Conventional actor preservation review

## Provenance and machine checks

The saved actor `.agentlang/subscription-handoff-maintenance-166/actors/conventional` was compared with `.agentlang/subscription-handoff-maintenance-166/seeds/conventional` using `audit-preservation.py`; output is in `review-conventional-audit/report.json` and `review-conventional-audit/conventional-source-review.md`. The full audit returned `machine-checks-passed-manual-review-required`, with 12/12 machine checks passing. Every inventoried non-generated file outside `Operations.fs` and `SelfTests.fs` has the same inventory and SHA-256 as the seed. This includes `Domain.fs`, `Fixtures.fs`, `Program.fs`, the project file, the business DLL, and `Reference/Business.fs`.

## Operations.fs

Manual diff review confirms the foundation aliases at the top of `Operations.fs` are unchanged. The edits are limited to the handoff documentation, a trailing `dryRun: bool`, returning the original `store` after successful replacement validation when `dryRun` is true, and passing `false` from the existing annual/monthly wrappers. Cancellation still runs before replacement creation, and errors from either operation propagate through the result. The wrappers retain their original signatures and fixed terms.

## SelfTests.fs

The existing self-test body and assertions remain. Existing `Subscription.handoff` calls now pass `false`; the diff shows no deleted prior assertions. The actor adds three dry-run checks:

- Successful monthly replacement validation returns `seed.Store`, leaves the replacement absent, and leaves the old subscription active.
- A whitespace term with a valid handoff time returns `InvalidSubscriptionTerm`; the original store still has the old subscription active.
- A missing old subscription combined with an invalid term returns `SubscriptionNotFound`, checking cancellation-error precedence over replacement validation.

These are meaningful success and failure paths. The conventional dry-run tests do not separately exercise the already-cancelled or cancel-before-start errors with `dryRun = true`; the Flow actor has a dry-run cancel-before-start case. The invalid-term test confirms the immutable input still has an active old subscription after failure; this does not represent rollback from an in-place operation.

No runtime tests were rerun during this review. The machine audit proves file and manifest preservation, not semantic equivalence of assertions; the source diff was reviewed manually. The parent reports the independent Flow grader passed its 66 target and 66 caller checks, which is separate behavioral evidence for the Flow actor, not a conventional test result.

# Conventional source review (manual)

Review these diffs for unrelated foundation/alias edits and preservation of original self-test assertions. No semantic assertion is machine-proven here.

## Operations.fs

```diff

--- seed/Operations.fs

+++ actor/Operations.fs

@@ -13,9 +13,9 @@

     let start = AgentLang.Business.Domain.Subscription.start

     let cancel = AgentLang.Business.Domain.Subscription.cancel

 

-    /// Atomically cancels the existing subscription and starts a replacement at the same instant.

+    /// Validates and cancels the existing subscription and starts a replacement at the same instant; dry runs return the original store.

     /// Cancellation errors take precedence; creation rules run against the cancelled store only after cancellation succeeds.

-    let handoff (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId) (term: string) (handoffAt: Instant) (expiresAt: Instant) : Result<Store, DomainError> =

+    let handoff (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId) (term: string) (handoffAt: Instant) (expiresAt: Instant) (dryRun: bool) : Result<Store, DomainError> =

         match AgentLang.Business.Domain.Subscription.cancel store oldId handoffAt with

         | Error error -> Error error

         | Ok (cancelledStore, oldSubscription) ->

@@ -27,12 +27,12 @@

                 term

                 handoffAt

                 expiresAt

-            |> Result.map fst

+            |> Result.map (fun (updated, _) -> if dryRun then store else updated)

 

     /// Replace a subscription with a annual subscription using the existing handoff rules.

     let renewAnnual (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId) (handoffAt: Instant) (expiresAt: Instant) : Result<Store, DomainError> =

-        handoff store oldId replacementId "annual" handoffAt expiresAt

+        handoff store oldId replacementId "annual" handoffAt expiresAt false

 

     /// Replace a subscription with a monthly subscription using the existing handoff rules.

     let renewMonthly (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId) (handoffAt: Instant) (expiresAt: Instant) : Result<Store, DomainError> =

-        handoff store oldId replacementId "monthly" handoffAt expiresAt

+        handoff store oldId replacementId "monthly" handoffAt expiresAt false

```

## SelfTests.fs

```diff

--- seed/SelfTests.fs

+++ actor/SelfTests.fs

@@ -85,7 +85,7 @@

         let handoffAt = Fixtures.instant 2026 1 15

         let replacementExpiresAt = Fixtures.instant 2026 3 1

         let handedOff =

-            match Subscription.handoff unrelated seed.OldSubscriptionId replacementId "  quarterly  " handoffAt replacementExpiresAt with

+            match Subscription.handoff unrelated seed.OldSubscriptionId replacementId "  quarterly  " handoffAt replacementExpiresAt false with

             | Ok updated -> updated

             | Error error -> failwithf "valid subscription handoff failed: %s" (DomainError.message error)

 

@@ -100,6 +100,28 @@

         assertEqual "handoff preserves the old expiry" (Subscription.expiresAt original) (Subscription.expiresAt oldAfterHandoff)

         assertEqual "handoff cancels the old subscription" Cancelled (Subscription.status oldAfterHandoff)

         assertEqual "handoff records its instant on the old subscription" (Some handoffAt) (Subscription.cancelledAt oldAfterHandoff)

+

+        let dryRunId = subscriptionId "30000000-0000-0000-0000-000000000010"

+        let dryRunExpiresAt = Fixtures.instant 2026 3 1

+        let dryRunStore =

+            match Subscription.handoff seed.Store seed.OldSubscriptionId dryRunId "  monthly  " handoffAt dryRunExpiresAt true with

+            | Ok updated -> updated

+            | Error error -> failwithf "valid dry-run subscription handoff failed: %s" (DomainError.message error)

+        assertEqual "dry run returns the original store" seed.Store dryRunStore

+        assertEqual "dry run does not add the replacement" None (Store.subscription dryRunId dryRunStore)

+        assertEqual "dry run leaves the old subscription active" Active (Store.subscription seed.OldSubscriptionId dryRunStore |> Option.map Subscription.status |> Option.defaultValue Cancelled)

+

+        let invalidDryRunId = subscriptionId "30000000-0000-0000-0000-000000000011"

+        match Subscription.handoff seed.Store seed.OldSubscriptionId invalidDryRunId "  " handoffAt handoffAt true with

+        | Error InvalidSubscriptionTerm -> ()

+        | Error error -> failwithf "dry-run replacement validation returned the wrong error: %s" (DomainError.message error)

+        | Ok _ -> failwith "dry-run accepted an invalid replacement term"

+        assertEqual "failed dry run leaves the old subscription active" Active (Store.subscription seed.OldSubscriptionId seed.Store |> Option.map Subscription.status |> Option.defaultValue Cancelled)

+

+        let missingDryRunOldId = subscriptionId "30000000-0000-0000-0000-000000000012"

+        match Subscription.handoff seed.Store missingDryRunOldId seed.OldSubscriptionId "  " handoffAt handoffAt true with

+        | Error error -> assertEqual "dry-run cancellation errors precede replacement validation" (SubscriptionNotFound missingDryRunOldId) error

+        | Ok _ -> failwith "dry-run succeeded when its old subscription was missing"

 

         let replacement =

             Store.subscription replacementId handedOff

@@ -129,21 +151,21 @@

         assertEqual "handoff preserves customer and product" true (Store.customer seed.CustomerId handedOff |> Option.isSome && Store.product seed.ProductId handedOff |> Option.isSome)

 

         let missingOldId = subscriptionId "30000000-0000-0000-0000-000000000007"

-        match Subscription.handoff seed.Store missingOldId seed.OldSubscriptionId " " handoffAt handoffAt with

+        match Subscription.handoff seed.Store missingOldId seed.OldSubscriptionId " " handoffAt handoffAt false with

         | Error error -> assertEqual "cancellation errors precede replacement validation" (SubscriptionNotFound missingOldId) error

         | Ok _ -> failwith "handoff succeeded when its old subscription was missing"

 

-        match Subscription.handoff cancelled seed.OldSubscriptionId seed.OldSubscriptionId "" handoffAt handoffAt with

+        match Subscription.handoff cancelled seed.OldSubscriptionId seed.OldSubscriptionId "" handoffAt handoffAt false with

         | Error error -> assertEqual "already-cancelled error precedes replacement validation" (SubscriptionAlreadyCancelled seed.OldSubscriptionId) error

         | Ok _ -> failwith "handoff succeeded when its old subscription was already cancelled"

 

-        match Subscription.handoff seed.Store seed.OldSubscriptionId seed.OldSubscriptionId "" handoffAt handoffAt with

+        match Subscription.handoff seed.Store seed.OldSubscriptionId seed.OldSubscriptionId "" handoffAt handoffAt false with

         | Error error -> assertEqual "replacement creation keeps duplicate-id precedence" (DuplicateSubscription seed.OldSubscriptionId) error

         | Ok _ -> failwith "handoff returned a cancelled intermediate store after duplicate replacement failure"

         assertEqual "failed replacement creation leaves the caller's old subscription active" Active (Store.subscription seed.OldSubscriptionId seed.Store |> Option.map Subscription.status |> Option.defaultValue Cancelled)

 

         let invalidTermReplacementId = subscriptionId "30000000-0000-0000-0000-000000000009"

-        match Subscription.handoff seed.Store seed.OldSubscriptionId invalidTermReplacementId "  " handoffAt handoffAt with

+        match Subscription.handoff seed.Store seed.OldSubscriptionId invalidTermReplacementId "  " handoffAt handoffAt false with

         | Error InvalidSubscriptionTerm -> ()

         | Error error -> failwithf "invalid replacement term returned the wrong error: %s" (DomainError.message error)

         | Ok _ -> failwith "handoff accepted a blank replacement term"

@@ -156,7 +178,7 @@

             | Ok (updated, _) -> updated

             | Error error -> failwithf "valid blocking subscription start failed: %s" (DomainError.message error)

         match Subscription.handoff withBlocker seed.OldSubscriptionId replacementId "quarterly"

-                (Fixtures.instant 2026 2 1) replacementExpiresAt with

+                (Fixtures.instant 2026 2 1) replacementExpiresAt false with

         | Error SubscriptionOverlap -> ()

         | Error error -> failwithf "overlapping replacement returned the wrong error: %s" (DomainError.message error)

         | Ok _ -> failwith "handoff accepted a replacement overlapping another subscription"

```

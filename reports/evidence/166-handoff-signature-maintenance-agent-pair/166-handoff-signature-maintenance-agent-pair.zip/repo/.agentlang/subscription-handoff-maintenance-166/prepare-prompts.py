"""Prepare fresh participant prompts and broker configurations for trial 166.

This script writes only prompt/configuration artifacts. It does not stage actor
projects or launch participant sessions.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]

FLOW_OPERATIONS = [
    "help", "words", "source", "tests", "define", "test", "test-all", "commit", "replace-word",
    "storage.status", "task.begin", "task.status", "task.commit", "describe",
    "search", "eval", "context", "dependencies", "callers", "failed-tests",
    "examples", "effects", "type-of", "history", "task.abort",
]
CONVENTIONAL_OPERATIONS = ["inspect", "read", "search", "patch", "replace", "validate"]

COMMON = """You are a fresh experimental coding agent. The human authorizes edits only to your isolated trial project and local test execution through the supplied broker. Read this assigned prompt and launch the specified broker; use only that broker for discovery, edits, and tests. Do not read main repository source, other trials, hidden oracles, reports, or snapshots. Do not use web tools, spawn agents, list/read/contact other agents, or run other shell commands. Disclose any non-broker tool use. Use one broker process and at most 100 exchanges. Poll the same handle after observation timeouts. Finish with `{"op":"host.close"}` and observe terminal status.

Public task: update the existing subscription handoff operation to add a trailing `dryRun` Boolean while retaining its name, return type, and identity. A successful handoff cancels the old subscription at `handoffAt` and creates an active replacement for the same customer and product, starting at `handoffAt` with the requested term and expiry. Preserve the existing term trimming and all prior validation behavior. Preserve the established validation order: validate cancellation of the old subscription first, then validate creation of the replacement, for both values of `dryRun`. Return the same existing error in both modes when validation fails. After successful validation, `dryRun=false` returns the updated store; `dryRun=true` returns the original store. Dry run must still perform replacement-creation validation. Keep the caller's input and all unrelated store data unchanged.

The existing annual and monthly renewal callers are coordinator-authored setup for this maintenance trial. Preserve their names and existing public signatures; update each to pass `false` to handoff so its behavior remains unchanged. Update existing target tests to pass `false` where they exercise the prior behavior. Preserve prior tests, add meaningful coverage for both handoff modes, and include a failure that arises during replacement-creation validation. Preserve all unrelated source and tests. Document the handoff operation. The task is limited to this synthetic subscription domain.

"""

FLOW_SPECIFIC = """Implement `subscription.handoff(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant, dryRun: Bool) -> Result<Store, BusinessError>` in the existing Flow/2 project. Keep the two retained callers `subscription.renew-annual` and `subscription.renew-monthly` at their existing five-argument signatures, forwarding the corresponding term and `false` to handoff.

Use `help` to discover how the public protocol updates and publishes an existing Flow/2 function together with its retained callers. Preserve their existing names, stable identities, and library maturity. Attach/update tests through the public protocol and test the target and both callers. Complete any active task session normally. All requests that author or evaluate Flow must specify `frontend: "flow"` and `syntaxVersion: 2`.

Compact Flow/2 primer: use `fn name(parameter: Type) -> Type { ... }`; qualified calls use dots; receiver calls `value.operation(args)` pass `value` first; record properties use `value.field`; `let` binds a local; newlines separate statements and the final expression is the result. Put effects and documentation before the body. Use `help` for exact syntax and Result test expectations.

Useful operations include `search`, `describe`, `source`, `tests`, `dependencies`, `callers`, `help`, `define`, `test`, `test-all`, `commit`, `task.begin`, `task.status`, and `task.commit`.

"""

CONVENTIONAL_SPECIFIC = """Implement `Subscription.handoff(store, oldId, replacementId, term, handoffAt, expiresAt, dryRun)` in `Operations.fs`, returning `Result<Store, DomainError>`. Update the existing five-argument `Subscription.renewAnnual` and `Subscription.renewMonthly` functions to call handoff with their fixed terms and `false`. Keep their names and signatures.

Edit only `Operations.fs` and `SelfTests.fs`. The other files are frozen infrastructure readable through the broker. `Reference/Business.fs` is reference documentation and must not be edited. Run `validate` after your changes.

Broker JSONL operations: `inspect` lists files; `read` returns a file and SHA256; `search` searches project text; `replace` and `patch` require the expected current SHA256; `validate` runs the fixed local self-test executable. The broker accepts no arbitrary shell commands.

"""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def broker_config(arm: str) -> dict[str, object]:
    if arm == "flow":
        cli = ROOT / "runtime/flow/AgentLang.Cli.dll"
        project = ROOT / "actors/flow"
        trace = ROOT / "trace-flow.jsonl"
        temp = ROOT / "tmp-flow"
        operations = FLOW_OPERATIONS
        profile = "agentlang"
        additional_cli_arguments: list[str] = []
    else:
        cli = ROOT / "runtime/conventional/AgentLang.Conventional.Cli.dll"
        project = ROOT / "actors/conventional"
        trace = ROOT / "trace-conventional.jsonl"
        temp = ROOT / "tmp-conventional"
        operations = CONVENTIONAL_OPERATIONS
        profile = "conventional"
        additional_cli_arguments = ["--validation-project", "SubscriptionHandoff.Conventional.fsproj"]

    launch = (
        f"$env:TEMP = '{temp}'\n"
        "$env:TMP = $env:TEMP\n"
        f"& '{REPO / 'scripts/Start-SubagentTrialHostV2.ps1'}' "
        f"-CliDll '{cli}' -ProjectPath '{project}' -TracePath '{trace}' "
        f"-AllowedOperations @('{','.join(operations)}') -Profile '{profile}' "
    )
    if additional_cli_arguments:
        launch += "-AdditionalCliArguments @('--validation-project','SubscriptionHandoff.Conventional.fsproj') "
    launch += "-ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100"

    return {
        "trial": "subscription-handoff-maintenance-166",
        "arm": arm,
        "participantDispatch": "not dispatched by preparation",
        "model": "gpt-6-luna",
        "reasoningEffort": "max",
        "freshContext": True,
        "executionOrder": 1 if arm == "flow" else 2,
        "launchPolicy": "sequential",
        "maxExchanges": 100,
        "exchangeTimeoutMilliseconds": 120000,
        "cliDll": str(cli),
        "cliSha256": sha256(cli),
        "projectPath": str(project),
        "tracePath": str(trace),
        "tempPath": str(temp),
        "profile": profile,
        "allowedOperations": operations,
        "additionalCliArguments": additional_cli_arguments,
        "launchCommand": launch,
    }


def write_prompt(name: str, body: str) -> Path:
    path = ROOT / name
    path.write_text(body, encoding="utf-8", newline="\n")
    return path


def main() -> None:
    flow_config = broker_config("flow")
    conventional_config = broker_config("conventional")
    flow = COMMON + FLOW_SPECIFIC + "Launch once using `exec_command` with `tty:true` and `yield_time_ms:10000`. If the sandbox rejects this authorized launch, retry the same command with escalation without broadening the allowed project or operations.\n\n```powershell\n" + flow_config["launchCommand"] + "\n```\n"
    conventional = COMMON + CONVENTIONAL_SPECIFIC + "Launch once using `exec_command` with `tty:true` and `yield_time_ms:10000`. If the sandbox rejects this authorized launch, retry the same command with escalation without broadening the allowed project or operations.\n\n```powershell\n" + conventional_config["launchCommand"] + "\n```\n"

    prompts = [write_prompt("prompt-flow.md", flow), write_prompt("prompt-conventional.md", conventional)]
    configs = []
    for arm, config in (("flow", flow_config), ("conventional", conventional_config)):
        path = ROOT / f"broker-{arm}.json"
        path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
        configs.append(path)

    smoke_summaries = sorted((ROOT / "broker-smoke").glob("attempt-*/summary.json")) if (ROOT / "broker-smoke").exists() else []
    smoke_reference = None
    status = "prompt-and-broker-configs-prepared; smoke-tests-pending"
    if smoke_summaries:
        latest_smoke = smoke_summaries[-1]
        smoke_data = json.loads(latest_smoke.read_text(encoding="utf-8"))
        if smoke_data.get("status") == "pass" and smoke_data.get("participantDispatched") is False:
            status = "prompt-and-broker-configs-prepared; broker-smokes-passed"
            smoke_reference = {"path": str(latest_smoke), "sha256": sha256(latest_smoke)}
    evidence = {
        "status": status,
        "trial": "subscription-handoff-maintenance-166",
        "participantDispatch": False,
        "model": "gpt-6-luna",
        "reasoningEffort": "max",
        "execution": "sequential",
        "maxExchangesPerArm": 100,
        "outputs": [
            {"path": str(path), "sha256": sha256(path)} for path in prompts + configs
        ],
        "brokerSmokeEvidence": smoke_reference,
        "runtimePins": {
            "flow": flow_config["cliSha256"],
            "conventional": conventional_config["cliSha256"],
        },
    }
    evidence_path = ROOT / "broker-preparation-evidence.json"
    evidence_path.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(f"Prepared {len(prompts)} prompts and {len(configs)} broker configs; no participant dispatched.")
    print(evidence_path)


if __name__ == "__main__":
    main()

# Retained-2 preservation receipt

This read-only audit compares the captured retained-2 head with its recorded starting project, `.agentlang/efficacy-maintenance-184/seed-draft/projects/draft-009/flow-retained/project`. It does not substitute the historical draft with a later passed-184 or 190 freeze.

All 21 inherited test IDs remain. Thirteen test bodies change only by wrapping the same reference strings in `TrackingReference.new(...)`; eight are byte-identical. The candidate adds five tests, and the captured `test-all` exchange reports 26/26 passing. The three inherited example IDs also remain and all three captured examples report 1/1 passing, but their bodies were substantively rewritten beyond the type migration. Their evidence is described below rather than counted as unchanged.

**Disposition:** the inherited tests are preserved. The inherited examples cannot be certified as semantically preserved: each was materially rewritten, and `ordered-events` replaces the one-shipment fixture with a different two-shipment scenario even though its new assertion is stronger.

## Baseline and capture integrity

- `actors.json` records retained-2's initial store pins. All 68 pins match the historical draft-009 project. The initial `CURRENT` pin is `35392f0d…20a80`; the seed project has the same current-file hash. Its generation-10 manifest is `f6ddf24b…d29a6f`.
- The seed dictionary has SHA-256 `228d3594…a723e20`. Its exact bytes remain in the actor's immutable object store under that content hash. The captured dictionary is `c89dfd82…49f367c`. The seed and captured `history/task-0001.json` are byte-identical at `5bc69cdc…0392ee3`.
- The captured generation-11 manifest is `5a00963c…10b84d`. The capture lists 102 candidate files; all 102 snapshot files are listed and their hashes match, with no missing, extra, or mismatched paths.
- The assigned prompt hashes to `68ffb9b4…53ea516`, matching `capture-retained-2.json` and `actors.json`. The 80-exchange trace hashes to `427f4bcb…c1d12`, matching both the capture and metrics records.

## Inherited tests and examples

The 13 inherited tests adapted to the nominal reference type are `shipment.batch-step/applies-successful-input`, `shipment.batch-step/keeps-first-error`, `shipment.find-scan/empty-shipment`, `shipment.find-scan/no-match`, `shipment.find-scan/returns-first-match`, `shipment.ingest/invalid-status-for-known-shipment`, `shipment.ingest/preserves-unrelated-state`, `shipment.ingest/unknown-shipment-precedes-invalid-status`, `shipment.ingest-batch/preserves-order-and-stops-at-first-error`, `shipment.ingest-rule/appends-first-scan`, and the three `shipment.scan-lookup-step` tests (`keeps-first-match`, `match`, `no-match`). Their fixtures retain the same reference text and their assertions and expected branches are unchanged.

The eight byte-identical inherited tests are `shipment.ingest-batch/empty-is-identity`, `store.shipment/no-match`, `store.shipment/returns-first-match`, `store.shipment-lookup-step/keeps-first-match`, `store.shipment-lookup-step/match`, `store.shipment-lookup-step/no-match`, `store.shipment-replacement-step/replaces-only-the-target`, and `store.with-shipment/preserves-store-fields-and-order`.

The five added tests are `shipment.ingest/same-shipment-replay-preserves-first-scan-and-full-store`, `shipment.ingest/replay-on-another-shipment-is-independent`, `shipment.ingest/invalid-status-on-existing-reference`, `shipment.ingest-batch/replays-in-input-order-and-keeps-first-status`, and `shipment.ingest-batch/empty-whitespace-and-case-are-distinct`.

All inherited example names remain, with these source changes:

| Example | Captured change and preservation assessment |
|---|---|
| `shipment.find-scan/first-reference` | Changes a one-scan fixture that compared the returned reference text with `carrier-001` into a duplicate-reference fixture that compares the returned scan with the first scan. This better checks first-match behavior but is not an unchanged example. |
| `shipment.ingest/append-one-scan` | Keeps the single-event append scenario and upgrades the expected output from a shipment count to full Store equality, including the scan, label, audit, and generation. The assertion is stronger, with different fixture values. |
| `shipment.ingest-batch/ordered-events` | Replaces a one-shipment fixture with two shipments and replaces a count-only assertion with equality against the ordered, complete Store. This strengthens order and state coverage but changes the inherited scenario; the one-shipment example is not independently retained. |

## API, history, and behavior evidence

All ten seeded word names and word IDs remain unchanged. Six words have a current revision 2 and four remain at revision 1. Their maturities are unchanged: `shipment.find-scan` and `shipment.scan-lookup-step` remain library words; the other eight are project words. The original revision-1 definitions and attached test/example hashes remain in the manifest; the captured manifest adds `attachmentSourceFormats` metadata. The task-0001 history is byte-identical.

`TrackingReference` is introduced as an empty scalar wrapper over `String` with no validator. The intended field migrations are `Scan.reference`, `ScanInput.reference`, and `ShipmentScanLookup.target` from `String` to `TrackingReference`. Among callable function signatures, only `shipment.find-scan` changes, from a `String` reference argument to `TrackingReference`; the public signatures of the entry functions and lookup step remain as seeded.

The source retains one shared path: `shipment.ingest-batch → shipment.batch-step → shipment.ingest → shipment.ingest-rule → shipment.find-scan → shipment.scan-lookup-step`. The rule validates status before checking for an existing reference; `shipment.ingest` checks shipment existence before invoking that rule. Accepted statuses remain `received`, `in-transit`, and `delivered`. The exact-match lookup contains no trimming or case conversion, and the added empty/whitespace/case test covers those distinct values. All changed functions declare `effects none`; the task log's effects are `{}`, and the session capabilities list is empty.

The trace records a `commit` request with `library:true` at exchange 66, returning “26 attached test(s) passed; selected candidates committed.” The task commit at exchange 80 succeeds, marks task-0002 inactive, and records 52 tests run with 0 failures. The six diagnostic codes below remain in the committed task history; the final pass did not erase them.

## Rejected exchanges and recovery

| Exchange | Rejection | Later status |
|---:|---|---|
| 17 | `DISCOVERY_UNKNOWN_TYPE`: queried `shipmentScanLookup` with the wrong case. | Correct declared name `ShipmentScanLookup` was sourced at exchange 25. |
| 44 | `NAME_UNKNOWN_WORD`: queried `shipment.find-scan/first-reference` as a word source. | The actor returned to the `examples` discovery call and later ran the example at exchange 61. |
| 53 | `FLOW_TYPE_STALE_SOURCE`: the define group's expected type-source hash was stale. | The final atomic define at exchange 59 used refreshed `Scan`, `ScanInput`, and `ShipmentScanLookup` hashes and succeeded. |
| 54 | `FLOW_ARGUMENT_TYPE`: a `String` test argument no longer matched `TrackingReference`. | The final atomic define at exchange 59 wrapped reference values in the nominal constructor and succeeded. |
| 67 | `COMMIT_NOT_CANDIDATE`: a second commit named `shipment.find-scan` after it had already been committed. | The successful library commit at exchange 66 had already published the candidates. This redundant request was not retried; its diagnostic remains recorded. |
| 74 | `HISTORY_REVISION_UNKNOWN`: `diff` was called without a word or revision arguments. | No corrected diff appears. Later status and task commit succeeded, but this request remains unresolved and its diagnostic remains recorded. |

## Coordinator and terminal record

The launch clarification only authorized reading the assigned prompt and explained that the existing broker transport was used; `taskHintsProvided` and `promptOrLimitsChanged` are false. The later observation is lifecycle-only: the root could not see host PID 40552, which is inconclusive about the broker. The observation identifies original transport handle 47407 as authoritative; the normal poll advanced to exchange 53 on that handle, confirming it was still live, and the later terminal record confirms closure. Neither coordinator record reports task-logic feedback, oracle feedback, or changed limits. No restart is recorded.

The trace and capture then record normal `host.close` finalization after 80 exchanges, host and runtime exit code 0, and no runtime stderr. The capture marks `behaviorScored:false`; this receipt uses no oracle result. No oracle, runtime, build, or test was run for this audit; the test and example outcomes above are read from the captured trace. The semantic comparison is bounded to authored Flow source, content-addressed history, captured responses, and hashes.

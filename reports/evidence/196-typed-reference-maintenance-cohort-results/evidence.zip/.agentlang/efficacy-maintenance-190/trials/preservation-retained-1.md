# Retained-1 preservation receipt

The captured head preserves all 24 inherited authored cases (21 tests and 3 examples). Seven remain byte-identical; 16 change only to wrap the same reference text in `TrackingReference.new(...)` plus source reformatting; one is formatting-only. No inherited assertion was removed or weakened, and no inherited expected behavior changed. There are zero unknown inherited cases.

The candidate does change implementation behavior: `shipment.ingest-rule` checks `shipment.find-scan` after status validation and returns the existing shipment for a replay of an exact reference. The candidate also adds six replay-focused tests. This receipt reports source preservation separately from those implementation changes.

## Evidence and source history

- Frozen seed manifest: generation 10, `f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f`. Captured head manifest: generation 11, `5104716035bc029ada5cabc782a5ada5da19dc0f6d5cfa4e35d94e90d99bab51`.
- Capture trace SHA-256 matches the trace file; 103 captured candidate pins were checked with 0 mismatches.
- All ten seeded functions retain the same names and word IDs. Each candidate manifest revision 1 retains the seed definition, test, and example hashes.
- The candidate manifest keeps revision-1 type history for `Scan`, `ScanInput`, and `ShipmentScanLookup` under `typeRevisions`; current definitions are in `types`. `TrackingReference` is a new current type.

| Function | Word ID | Revision | Maturity | Seed signature | Captured signature |
|---|---|---:|---|---|---|
| `shipment.ingest-rule` | `word_083888cf63be42f7ab3464c7337f974f` | 1 → 2 | project → project | `fn shipment.ingest-rule(shipment: Shipment, input: ScanInput) -> Result<Shipment, ScanError> {` | `fn shipment.ingest-rule(shipment: Shipment, input: ScanInput) -> Result<Shipment, ScanError> {` |
| `store.shipment-replacement-step` | `word_14915ad7658140808d9e35d93e67ae17` | 1 → 1 | project → project | `fn store.shipment-replacement-step(state: ShipmentReplacement, candidate: Shipment) -> ShipmentReplacement {` | `fn store.shipment-replacement-step(state: ShipmentReplacement, candidate: Shipment) -> ShipmentReplacement {` |
| `shipment.find-scan` | `word_242e605ef079454dbc4be3314ed7f8b1` | 1 → 2 | library → library | `fn shipment.find-scan(shipment: Shipment, reference: String) -> Option<Scan> {` | `fn shipment.find-scan(shipment: Shipment, reference: TrackingReference) -> Option<Scan> {` |
| `shipment.scan-lookup-step` | `word_3cc74855ad224efc97826471b172a994` | 1 → 2 | library → library | `fn shipment.scan-lookup-step(state: ShipmentScanLookup, candidate: Scan) -> ShipmentScanLookup {` | `fn shipment.scan-lookup-step(state: ShipmentScanLookup, candidate: Scan) -> ShipmentScanLookup {` |
| `store.shipment-lookup-step` | `word_524a2828125849799133b630a0530eb9` | 1 → 1 | project → project | `fn store.shipment-lookup-step(state: StoreShipmentLookup, candidate: Shipment) -> StoreShipmentLookup {` | `fn store.shipment-lookup-step(state: StoreShipmentLookup, candidate: Shipment) -> StoreShipmentLookup {` |
| `shipment.ingest` | `word_82abda405e7a41198912999ed2ff53ef` | 1 → 2 | project → project | `fn shipment.ingest(store: Store, input: ScanInput) -> Result<Store, ScanError> {` | `fn shipment.ingest(store: Store, input: ScanInput) -> Result<Store, ScanError> {` |
| `store.with-shipment` | `word_92d8cdaa85714cd1a95e9045b7ac86f4` | 1 → 1 | project → project | `fn store.with-shipment(store: Store, replacement: Shipment) -> Store {` | `fn store.with-shipment(store: Store, replacement: Shipment) -> Store {` |
| `shipment.batch-step` | `word_b3a2cae7072b417687b287f7287c16ae` | 1 → 2 | project → project | `fn shipment.batch-step(state: BatchState, input: ScanInput) -> BatchState {` | `fn shipment.batch-step(state: BatchState, input: ScanInput) -> BatchState {` |
| `shipment.ingest-batch` | `word_bffe5e8f998340519b47bf52b6b8a319` | 1 → 2 | project → project | `fn shipment.ingest-batch(store: Store, events: List<ScanInput>) -> Result<Store, ScanError> {` | `fn shipment.ingest-batch(store: Store, events: List<ScanInput>) -> Result<Store, ScanError> {` |
| `store.shipment` | `word_f1e5fbe50c154bd8ba7bbdb1ff7a6eed` | 1 → 1 | project → project | `fn store.shipment(id: ShipmentId, store: Store) -> Option<Shipment> {` | `fn store.shipment(id: ShipmentId, store: Store) -> Option<Shipment> {` |

Only `shipment.find-scan(reference)` changes its public function signature, from `String` to `TrackingReference`. Both existing library functions retain library maturity; all others remain project maturity. The type revisions and current heads are enumerated in the JSON receipt.

Current captured source calls show the shared path: `shipment.ingest-batch → shipment.batch-step → shipment.ingest → shipment.ingest-rule → shipment.find-scan → shipment.scan-lookup-step`. This gives the single and batch ingestion paths the same ingest rule and makes that rule reuse the lookup function. Trace caller queries 33-34 were made before edits and establish only the inherited ingest/batch chain; the final lookup edges are verified from current content-addressed source objects.

## Inherited test cases

| Case | Seed SHA-256 | Captured SHA-256 | Diff and equivalence review |
|---|---|---|---|
| `shipment.ingest-rule/appends-first-scan` | `8fbfdc8d7181bb17a196a79ce29791ce63a2fe71964a37d988baafc6c4868d51` | `3541a9043caa9233430f03230223b856d8df5ee8c6d6e99587c5d41a00e645ff` | preserved-typed-reference-constructor-and-formatting Input reference and expected Scan reference wrap the same "scan-1" text in TrackingReference.new(...); scan-count, exact-scan, and label assertions remain. |
| `store.shipment-replacement-step/replaces-only-the-target` | `9d03fd3f3801a743486af5cad44e71edacb9f6946a441d75e8bd1403006483a0` | `9d03fd3f3801a743486af5cad44e71edacb9f6946a441d75e8bd1403006483a0` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `shipment.find-scan/no-match` | `19769e37660fd0541411786eabd085832b71d204cb659a7b3510ec25ab76e5eb` | `8f46b9d9197c0c8fb64786028df14617755c119f23e45e2f48652a6ca213cf63` | preserved-typed-reference-constructor-and-formatting Stored Scan reference and lookup argument wrap the same literals in TrackingReference.new(...); the Some=false / None=true expectation remains. |
| `shipment.find-scan/empty-shipment` | `2f169c86f0f1cb52608a719223eb8d5c8eba113c9a16c8d7c7eb700e9d8c5bb8` | `7cdef797c86db7f5885bdebd76cc44af8f12e43de8563bae281bdbb8e49f25b2` | preserved-typed-reference-constructor-and-formatting Lookup argument wraps the same "scan-1" text in TrackingReference.new(...); empty-list Some=false / None=true expectation remains. |
| `shipment.find-scan/returns-first-match` | `faeaf08fc0716307002c3d11c2c8c3b993c4c37114091935c020606008064787` | `dbeecfddf49150968da87332f3e7b0b0c9fea46bf3fff7a37ca7f901bb8dbd21` | preserved-typed-reference-constructor-and-formatting First/later Scan references and lookup argument wrap the same "scan-1" text in TrackingReference.new(...); selected result must still equal the first Scan. |
| `shipment.scan-lookup-step/no-match` | `587ce12704741d970f697dba74574b9de48f92fb4f50bfa895c0a66b34311dc9` | `cd39b0e6ffccae00824b9d77ad21c18938696db843826695c386ee8b5beaea55` | preserved-typed-reference-constructor-and-formatting Lookup-state target and candidate Scan reference wrap the same literals in TrackingReference.new(...); the no-match branch expectation remains. |
| `shipment.scan-lookup-step/match` | `76854b5ee21406380e7bafc0bfe580f7f1a946b5cab18551200a499911bb7a4b` | `069c2f22c5b76631b18bdee025a738ef0adb6ed6d6373f18ea883d284046d232` | preserved-typed-reference-constructor-and-formatting Lookup-state target and expected Scan reference wrap the same "scan-1" text in TrackingReference.new(...); selected Scan equality remains. |
| `shipment.scan-lookup-step/keeps-first-match` | `842b973bd7eeaa962e0c8d2fe89e474907d55517069406f417440b5fcf2b1b95` | `722d873b5956737df477ddf0dd0d11337d0fb00aaca35c96bf03514f3264294c` | preserved-typed-reference-constructor-and-formatting First/later Scan references and lookup target wrap the same "scan-1" text in TrackingReference.new(...); the previously found first Scan remains expected. |
| `store.shipment-lookup-step/match` | `1752a9f860cac6c0965413876e69374de5618f74b229a85467f0440748744d87` | `1752a9f860cac6c0965413876e69374de5618f74b229a85467f0440748744d87` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `store.shipment-lookup-step/no-match` | `508d27f7a0aaf4832f4c0ebe3ab483d7d50905d500576e1280ac856e3c977591` | `508d27f7a0aaf4832f4c0ebe3ab483d7d50905d500576e1280ac856e3c977591` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `store.shipment-lookup-step/keeps-first-match` | `a1d779b6221634808cf30d4d89163be37740a64fe8de3b2e70569b1226fffdf2` | `a1d779b6221634808cf30d4d89163be37740a64fe8de3b2e70569b1226fffdf2` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `shipment.ingest/unknown-shipment-precedes-invalid-status` | `01c80110bb4f4e33fe1caef3ca76d86ee294e97fc152a327454f6575b66591e5` | `9e6c533b783ab06780d58b849b3a342d3d9f9cfa2d8c56fd498c0dec62577bfb` | preserved-typed-reference-constructor-and-formatting Input reference wraps the same "scan-1" text in TrackingReference.new(...); the expected unknown-shipment error remains ahead of status validation. |
| `shipment.ingest/preserves-unrelated-state` | `a1fae7b7f861b58526da083d9d3cdcb6c1d7cd3a381e9425f3f62bf9dab83146` | `7d2d4ce5cd789d31c76154c762353d627dd440d8a68ae3c299763dec53ad8531` | preserved-typed-reference-constructor-and-formatting Input and expected Scan references wrap the same "scan-1" text in TrackingReference.new(...); full Store equality including audit, generation, order, and appended Scan remains. |
| `shipment.ingest/invalid-status-for-known-shipment` | `da1c323f6d40d63eba7b415e762be2d4b62bf34e721ff37577e40d5ebc3dbdaa` | `e43d5d3f8a0675d3bac3bdf21a98869e3064906a66b31a055b66c3571dbfc96e` | preserved-typed-reference-constructor-and-formatting Input reference wraps the same "scan-1" text in TrackingReference.new(...); expected invalid-status error remains. |
| `store.with-shipment/preserves-store-fields-and-order` | `ba740ff9e3b04aa8c880b96931f2aed273d7f482e5c74eb442b2d728b83e8491` | `ba740ff9e3b04aa8c880b96931f2aed273d7f482e5c74eb442b2d728b83e8491` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `shipment.batch-step/keeps-first-error` | `2f6562b4a45321934194a195baa3acacba1981faf333f4958e402eb8a1c71fb9` | `90d0dd6d4a09377f27ece7cbd15c4c387da6c9fb7898c1a380976d7749c1e8b5` | preserved-typed-reference-constructor-and-formatting Later input reference wraps the same "later" text in TrackingReference.new(...); equality with the existing first error remains. |
| `shipment.batch-step/applies-successful-input` | `b9205203ae2a4995ae9e42aa1cbc6b9c3003cab3375362d4105d7cd1d577b55e` | `32a06c8709b356852c30a1f32764ef84bb7168551476b962714e9e4be4841cf7` | preserved-typed-reference-constructor-and-formatting Input reference wraps the same "scan-1" text in TrackingReference.new(...); successful outcome and shipment-count assertion remain. |
| `shipment.ingest-batch/preserves-order-and-stops-at-first-error` | `072746bb8a2af2ba05d1bf728eba18a6f48b485a363f04ae70a7c139a39920ad` | `0879b45c6e3a0834dec2040244e7fbb4a8cab42a3b00a30773e58ceae168bff5` | preserved-typed-reference-constructor-and-formatting All three event references wrap their same literals in TrackingReference.new(...); the expected first invalid-status error remains. |
| `shipment.ingest-batch/empty-is-identity` | `77eab590ae4d1390f963f9148f912ada6ee727ebbfc091e9dbae199c43ce0667` | `434134a04537c7a81f8d2c564f895a908816d8dd1d8e236a0950a914bc630852` | preserved-format-only Only line wrapping/formatting changed; the same equality against result.ok(current) remains. |
| `store.shipment/returns-first-match` | `45355c0935426d972737b39fb492f7ffcd83d55e61d837a00f6e0dc56338a274` | `45355c0935426d972737b39fb492f7ffcd83d55e61d837a00f6e0dc56338a274` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |
| `store.shipment/no-match` | `cc3d49579a1433f8aaa9451064640fbed4f037c95b58767f78b9ac5256acf78d` | `cc3d49579a1433f8aaa9451064640fbed4f037c95b58767f78b9ac5256acf78d` | preserved-byte-identical No authored-source diff; SHA-256 content hashes are identical. |

## Inherited examples

| Example | Seed SHA-256 | Captured SHA-256 | Diff and equivalence review |
|---|---|---|---|
| `shipment.find-scan/first-reference` | `595cdcb1d21c5038459e598ca4ffe4f595666083c82766f3742d4c3a9cd66c4b` | `19790e4d4c2f8564b54e910a1cf7cc3511695ab4eea41d51d0f44b48bf469c92` | preserved-typed-reference-constructor-and-formatting Example Scan reference, lookup argument, and expected selected.reference value use TrackingReference.new(...) around the same "carrier-001" text; the same exact reference is expected. |
| `shipment.ingest/append-one-scan` | `1aba95860779a813310596497f68b39c95bc0bddc90f328718da54fab77f0e2e` | `c69fe772ff0f7e6a4b19fa24fb77dd90bd3733a492f841a8d24cd8bd21c2c771` | preserved-typed-reference-constructor-and-formatting Example input reference wraps the same "carrier-001" text in TrackingReference.new(...); the existing successful result and shipment-count assertion remain. |
| `shipment.ingest-batch/ordered-events` | `ea0d90826fd3b51cfef33fb1173cdd908f8564dc86f52b15beea4cf35bdeef8a` | `cb38325216b9f5a4ae7b0cd84802c56b6de4cb15fc45bc4eb600e232d30100bc` | preserved-typed-reference-constructor-and-formatting Both event references wrap their same carrier literals in TrackingReference.new(...); the same successful result and shipment-count assertion remain. |

## Added tests

- `shipment.ingest-rule/replay-keeps-first-scan` — `03e306bdef749b4b3893e7a7d84988ed85c992c18a6cb52871be2dba315daf54`
- `shipment.find-scan/exact-text-matching` — `c6cabd9fb034818faa5d927bdf38e8d63898a60645b5c68646f66bde97308f75`
- `shipment.ingest/invalid-status-on-replay` — `6c490012a29bce8928d5f11da10dfe145f4f1b4613aba814b04cf43a31491089`
- `shipment.ingest/same-shipment-replay-preserves-full-store` — `d4404d4e6fbdf1522a39363f4001c3467e78d17261e7e779eebc67dad6d1f628`
- `shipment.ingest/cross-shipment-reference-is-independent` — `facdd4b5f7d823dfd64ae5f5617ae6691e9367ed41acbf0048d80ab2b3e2f283`
- `shipment.ingest-batch/replay-preserves-first-scan-and-order` — `6752eed6579284e78f81ea13348ab996c693fa6b139dfe9634fcae1f2347875c`

## Captured run and recovery record

- Trace: 96 exchanges; normal broker finalization; host-close with host/runtime exit codes 0/0; runtime stderr 0 bytes.
- Captured `test-all` at exchange 81: 27/27 passed. The three unique examples passed at exchanges 82-84 and were rerun successfully at 85-87.
- Exchange 90 committed with `library: true`: 27 attached test(s) passed; selected candidates committed.. Task commit at exchange 96 succeeded and task history is inactive; the task log records 54 tests run, 0 failed, and 9 error entries.

| Index | Operation | Code | Recovery action | Resolution |
|---:|---|---|---|---|
| 7 | `search-type` | `DISCOVERY_INVALID_ARGUMENT` | Index 8 reran search-type with type="Scan" and returned 9 matches. Indexes 9-10 described and sourced the Scan record. | **resolved** |
| 12 | `source` | `DISCOVERY_UNKNOWN_TYPE` | Index 13 sourced the exact declared type name ShipmentScanLookup and returned its record source. | **resolved** |
| 50 | `source` | `NAME_UNKNOWN_WORD` | Indexes 51-53 invoked examples on the owning words shipment.ingest, shipment.find-scan, and shipment.ingest-batch; each returned 1/1 passed. | **resolved** |
| 54 | `define` | `FLOW_PROJECT_REPLACEMENT_CAS_SHAPE` | Index 55 inspected the helper source; indexes 57-79 re-inspected the required source metadata; index 80 successfully staged the atomic define. | **resolved** |
| 56 | `define` | `FLOW_TYPE_STALE_SOURCE` | Indexes 57-79 re-inspected type-source hashes after stale-source responses; index 80 successfully staged the atomic define with corrected expectedTypeSources. | **resolved** |
| 62 | `define` | `FLOW_TYPE_STALE_SOURCE` | Indexes 63-73 re-inspected type-source hashes; indexes 75-79 continued metadata inspection; index 80 successfully staged the atomic define. | **resolved** |
| 74 | `define` | `FLOW_TYPE_STALE_SOURCE` | Indexes 75-79 re-inspected the type source; index 80 successfully staged the atomic define with corrected expectedTypeSources. | **resolved** |
| 93 | `diff` | `HISTORY_REVISION_UNKNOWN` | Indexes 95-96 checked status and committed the task, but there is no later successful diff for this request; task completion does not supply the missing diff. | **unresolved** |
| 94 | `diff` | `HISTORY_REVISION_UNKNOWN` | Indexes 95-96 checked status and committed the task, but there is no later successful diff for this request; task completion does not supply the missing diff. | **unresolved** |

The two history-diff failures at indexes 93-94 remain unresolved: task status and successful task commit do not resolve either diff request. Those failed reads do not change the content-addressed source comparison above. The initial oracle result is not used as preservation evidence.

The full machine-readable receipt, including all case hashes, equivalence notes, function IDs/signatures, prior type revisions, trace recovery records, and capture checks, is in `preservation-retained-1.json`.

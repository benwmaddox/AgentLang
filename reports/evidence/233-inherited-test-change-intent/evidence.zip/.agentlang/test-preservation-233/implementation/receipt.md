# Test-preservation guard implementation receipt

Owned changes are limited to `Runtime.fs`, `AuthoringHelp.fs`, and the Flow runtime test program. The guard requires one current-source-hash declaration for every inherited standalone inline test whose source bytes **or syntax version** changes in a single-word, multiword, or record-evolution replacement. It validates declaration shape and usage before snapshot activation, while preserving existing wrapper/frozen-validator diagnostic precedence. New and omitted retained cases need no declaration. The attachment-only editor rejects `testChanges` and continues to use its existing revision CAS.

The focused suite includes positive declared edits, omitted/unchanged inheritance, source-only and syntax-version-only drift, malformed/stale/duplicate/unused rows, failed-replacement atomicity and durable-state checks, and the dedicated attachment-editor path. It also checks source-inclusive attachment snapshots after single-word rejection and missing-declaration rejection through multiword and record-evolution routes. Help text scopes the contract to prior Flow-authored standalone inline tests and explains the Stack-to-Flow migration boundary. Existing replacement fixtures now declare intended inherited-case edits explicitly.

Validation used the already restored/audited dependency assets; no restore was run. Each command was run with `TEMP` and `TMP` set to `.agentlang/test-preservation-233/implementation/temp`, plus `MSBuildEnableWorkloadResolver=false` and `MSBUILDDISABLENODEREUSE=1`:

```powershell
dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release --no-restore -m:1 -v:minimal
dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release --no-build --no-restore
git diff --check -- src/AgentLang.Core/Runtime.fs src/AgentLang.Core/AuthoringHelp.fs tests/AgentLang.Flow.Runtime.Tests/Program.fs
```

The latest build succeeded with 0 warnings and 0 errors. Runtime tests passed: **45 groups, 2426 assertions**. `git diff --check` passed; all three edited files are LF. Raw outputs are retained as `build-final.log` and `runtime-final.log`. Earlier failed build/runtime outputs remain in this directory for audit. This is focused validation only; it is not fresh dependency-audit evidence or the repository-wide validation owned by the coordinator.

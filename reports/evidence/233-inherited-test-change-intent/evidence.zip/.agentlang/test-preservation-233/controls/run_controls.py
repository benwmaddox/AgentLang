#!/usr/bin/env python3
"""Run bounded coordinator controls against a pinned managed AgentLang CLI.

This is a mechanical runtime control, not a fresh-agent efficacy trial. It
executes only coordinator-authored JSONL requests through the trusted V2 host;
the Flow fixture is pure and no participant code, packages, or network effects
are used.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


CONTROLS = Path(__file__).resolve().parent
REPO = CONTROLS.parents[2]
HOST = REPO / "scripts" / "Start-SubagentTrialHostV2.ps1"
HOST_RUNNER = CONTROLS / "run_v2_host.ps1"
FIXTURE = CONTROLS / "fixture.flow"
WORKING_SOURCE_FILES = (
    Path("src/AgentLang.Core/Runtime.fs"),
    Path("src/AgentLang.Core/AuthoringHelp.fs"),
    Path("tests/AgentLang.Flow.Runtime.Tests/Program.fs"),
)
MAX_EXCHANGES = 14
EXCHANGE_TIMEOUT_MS = 12_000
PROCESS_TIMEOUT_SECONDS = 45


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256(path.read_bytes())


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def write_json(path: Path, value: object) -> None:
    path.write_bytes(json_bytes(value))


def canonical(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def response_ok(response: dict | None) -> bool:
    return isinstance(response, dict) and response.get("ok") is True


def response_data(response: dict | None) -> object:
    if not response_ok(response):
        return {}
    return response.get("data", {})


def request(op: str, **fields: object) -> dict:
    return {"op": op, **fields}


def fixture_blocks() -> list[str]:
    source = FIXTURE.read_text(encoding="utf-8")
    blocks = [block.strip() for block in source.strip().split("\n\n") if block.strip()]
    expected = {
        "fn account.active(id: String, status: String) -> Bool {",
        "fn account.eligible(id: String, status: String) -> Bool {",
        "test account.active/active-case {",
        "test account.active/closed-case {",
        "test account.eligible/active-case {",
        "test account.eligible/closed-case {",
    }
    starts = {block.splitlines()[0] for block in blocks}
    if starts != expected:
        raise RuntimeError("fixture.flow block inventory changed unexpectedly")
    return blocks


def owner_source(owner: str, *, change_closed_id: bool = False, add_regression: bool = False) -> str:
    selected = [
        block for block in fixture_blocks()
        if block.startswith(f"fn {owner}(") or block.startswith(f"test {owner}/")
    ]
    if change_closed_id:
        index = next(i for i, block in enumerate(selected) if block.startswith(f"test {owner}/closed-case "))
        if selected[index].count('"id-old"') != 1:
            raise RuntimeError("closed-case fixture no longer has exactly one id-old literal")
        selected[index] = selected[index].replace('"id-old"', '"id-other"', 1)
    if add_regression:
        if owner != "account.active":
            raise RuntimeError("the added regression is intentionally scoped to account.active")
        selected.append(
            'test account.active/another-closed-id {\n'
            '    account.active("id-other", "closed")\n'
            '    => false\n'
            '}'
        )
    return "\n\n".join(selected) + "\n"


def batch_source(*, change_closed_ids: bool = False) -> str:
    blocks = fixture_blocks()
    if change_closed_ids:
        for i, block in enumerate(blocks):
            if block.startswith("test ") and "/closed-case " in block:
                if block.count('"id-old"') != 1:
                    raise RuntimeError(f"expected one old id in {block.splitlines()[0]}")
                blocks[i] = block.replace('"id-old"', '"id-other"', 1)
    return "\n\n".join(blocks) + "\n"


def runtime_inventory(runtime_dir: Path, declared_revision: str | None) -> dict:
    if runtime_dir.is_symlink() or not runtime_dir.is_dir():
        raise RuntimeError(f"runtime directory is missing or unsafe: {runtime_dir}")
    cli = runtime_dir / "AgentLang.Cli.dll"
    if not cli.is_file():
        raise RuntimeError(f"managed CLI is missing: {cli}")
    rows = []
    for path in sorted(runtime_dir.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"runtime pin path contains a symlink: {path}")
        if path.is_file():
            data = path.read_bytes()
            rows.append({"path": path.relative_to(runtime_dir).as_posix(), "bytes": len(data), "sha256": sha256(data)})
    working_sources = []
    for relative in WORKING_SOURCE_FILES:
        path = REPO / relative
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"working source pin is missing or unsafe: {relative.as_posix()}")
        data = path.read_bytes()
        working_sources.append({"path": relative.as_posix(), "bytes": len(data), "sha256": sha256(data)})
    return {
        "label": "previous" if "previous" in runtime_dir.parts else "updated",
        "runtimeBuildBaseRevision": declared_revision,
        "workingSourceIdentity": {
            "status": "base revision plus explicit working-source hashes; base revision alone is not full source identity",
            "files": working_sources,
        },
        "cliPath": str(cli),
        "files": rows,
        "treeSha256": sha256(json_bytes(rows)),
    }


def parse_responses(stdout: bytes) -> tuple[list[dict], list[str]]:
    responses = []
    errors = []
    for index, line in enumerate(stdout.splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line.decode("utf-8-sig"))
            if not isinstance(value, dict):
                raise ValueError("response is not a JSON object")
            responses.append(value)
        except Exception as exc:
            errors.append(f"line {index}: {type(exc).__name__}: {exc}")
    return responses, errors


def run_session(run_root: Path, name: str, project: Path, runtime_dir: Path,
                requests: list[dict]) -> dict:
    session_dir = run_root / "sessions" / name
    session_dir.mkdir(parents=True, exist_ok=False)
    work_tmp = session_dir / "workspace-tmp"
    work_tmp.mkdir()
    request_data = "".join(json.dumps(item, separators=(",", ":"), ensure_ascii=False) + "\n" for item in requests).encode("utf-8")
    (session_dir / "requests.jsonl").write_bytes(request_data)
    trace = session_dir / "trace.jsonl"
    command = [
        shutil.which("pwsh") or "pwsh", "-NoLogo", "-NoProfile", "-NonInteractive", "-File", str(HOST_RUNNER),
        "-CliDll", str(runtime_dir / "AgentLang.Cli.dll"),
        "-ProjectPath", str(project),
        "-TracePath", str(trace),
    ]
    env = os.environ.copy()
    env["TEMP"] = str(work_tmp)
    env["TMP"] = str(work_tmp)
    env["MSBuildEnableWorkloadResolver"] = "false"
    timed_out = False
    try:
        proc = subprocess.run(
            command, cwd=REPO, env=env, input=request_data,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=PROCESS_TIMEOUT_SECONDS, check=False,
        )
        stdout, stderr, exit_code = proc.stdout, proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        stdout = exc.stdout or b""
        stderr = exc.stderr or b""
        exit_code = None
    except Exception as exc:
        stdout, stderr, exit_code = b"", f"{type(exc).__name__}: {exc}".encode("utf-8"), None
    (session_dir / "stdout.raw").write_bytes(stdout)
    (session_dir / "stderr.txt").write_bytes(stderr)
    responses, parse_errors = parse_responses(stdout)
    write_json(session_dir / "process.json", {
        "command": command,
        "workingDirectory": str(REPO),
        "workspaceTemp": str(work_tmp),
        "processTimeoutSeconds": PROCESS_TIMEOUT_SECONDS,
        "timedOut": timed_out,
        "exitCode": exit_code,
        "requestCountIncludingHostClose": len(requests),
        "responseCount": len(responses),
        "parseErrors": parse_errors,
        "stdoutBytes": len(stdout),
        "stderrBytes": len(stderr),
        "traceExists": trace.is_file(),
    })
    return {
        "name": name,
        "sessionDir": session_dir,
        "requests": requests,
        "responses": responses,
        "parseErrors": parse_errors,
        "exitCode": exit_code,
        "timedOut": timed_out,
    }


def ok_at(session: dict, index: int) -> bool:
    return index < len(session["responses"]) and response_ok(session["responses"][index])


def response_at(session: dict, index: int) -> dict | None:
    return session["responses"][index] if index < len(session["responses"]) else None


def session_clean(session: dict) -> bool:
    # The final request is host.close and intentionally has no response.
    return session["exitCode"] == 0 and not session["timedOut"] and not session["parseErrors"]


def rows_by_name(response: dict | None) -> dict[str, dict]:
    data = response_data(response)
    values = data if isinstance(data, list) else []
    return {str(row.get("name")): row for row in values if isinstance(row, dict)}


def seed_state(seed_session: dict) -> tuple[dict, dict, dict]:
    if not session_clean(seed_session):
        raise RuntimeError("seed V2 host did not close cleanly")
    for index, name in ((0, "define"), (1, "library commit"), (2, "active tests"), (3, "eligible tests"),
                        (4, "active source inspection"), (5, "eligible source inspection"),
                        (6, "active description"), (7, "eligible description"), (8, "storage status")):
        if not ok_at(seed_session, index):
            raise RuntimeError(f"seed {name} failed: {response_at(seed_session,index)}")
    active_test_data = response_data(response_at(seed_session, 2))
    eligible_test_data = response_data(response_at(seed_session, 3))
    test_active = active_test_data.get("results", []) if isinstance(active_test_data, dict) else []
    test_eligible = eligible_test_data.get("results", []) if isinstance(eligible_test_data, dict) else []
    if not test_active or not test_eligible or not all(x.get("passed") is True for x in test_active + test_eligible):
        raise RuntimeError("baseline library tests did not all pass")
    active_rows = response_data(response_at(seed_session, 4))
    eligible_rows = response_data(response_at(seed_session, 5))
    pins = {}
    for owner, rows in (("account.active", active_rows), ("account.eligible", eligible_rows)):
        if not isinstance(rows, list):
            raise RuntimeError(f"tests includeSource returned no rows for {owner}")
        for row in rows:
            if row.get("word") != owner or not row.get("sourceHash") or not row.get("source"):
                raise RuntimeError(f"incomplete source pin in tests response for {owner}")
            pins[f"{owner}/{row['name']}"] = {
                "word": owner,
                "caseName": row["name"],
                "source": row["source"],
                "sourceHash": row["sourceHash"],
            }
    active_desc = response_data(response_at(seed_session, 6))
    eligible_desc = response_data(response_at(seed_session, 7))
    active_revision = active_desc.get("revision") if isinstance(active_desc, dict) else None
    eligible_revision = eligible_desc.get("revision") if isinstance(eligible_desc, dict) else None
    if not isinstance(active_revision, int) or not isinstance(eligible_revision, int):
        raise RuntimeError("seed descriptions did not return committed revisions")
    revisions = {"account.active": active_revision, "account.eligible": eligible_revision}
    source_info = {"revision": revisions, "tests": pins}
    return source_info, response_data(response_at(seed_session, 8)), {"active": test_active, "eligible": test_eligible}


def copy_seed(seed_project: Path, project: Path) -> None:
    if project.exists():
        raise RuntimeError(f"refusing to overwrite project: {project}")
    for path in seed_project.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"seed project contains a symlink: {path}")
    shutil.copytree(seed_project, project)


def replacement_request(source: str, revision: int, *, owner: str | None = None,
                        revisions: dict | None = None, test_changes: list | None = None) -> dict:
    value = request("define", frontend="flow", source=source, syntaxVersion=2, replace=True)
    if revisions is not None:
        value["expectedRevisions"] = revisions
    elif owner is not None:
        value["expectedRevision"] = revision
    if test_changes is not None:
        value["testChanges"] = test_changes
    return value


def check_test_results(response: dict | None, count: int) -> bool:
    data = response_data(response)
    rows = data.get("results", []) if isinstance(data, dict) else []
    return len(rows) == count and all(row.get("passed") is True for row in rows)


def run_previous_controls(run_root: Path, runtime_dir: Path, seed_project: Path,
                          seed_info: dict) -> list[dict]:
    revision = seed_info["revision"]["account.active"]
    eligible_revision = seed_info["revision"]["account.eligible"]
    outcomes = []

    # The only inherited source mutation is a closed-case ID whose result is false before and after.
    project = run_root / "projects" / "previous-one-word-changed"
    copy_seed(seed_project, project)
    reqs = [
        replacement_request(owner_source("account.active", change_closed_id=True), revision, owner="account.active"),
        request("replace-word", word="account.active"),
        request("test", word="account.active"),
        request("tests", word="account.active", includeSource=True),
        request("host.close"),
    ]
    s = run_session(run_root, "previous-one-word-changed", project, runtime_dir, reqs)
    rows = rows_by_name(response_at(s, 3))
    one_ok = session_clean(s) and ok_at(s, 0) and ok_at(s, 1) and check_test_results(response_at(s, 2), 2)
    one_ok = one_ok and rows.get("closed-case", {}).get("source", "").find('"id-other"') >= 0
    outcomes.append({"control": "previous-one-word-changed-inherited-case", "expected": "accepted", "passed": one_ok,
                     "defineOk": ok_at(s, 0), "publicationOk": ok_at(s, 1), "allTestsPassed": check_test_results(response_at(s, 2), 2),
                     "closedCaseSourceHash": rows.get("closed-case", {}).get("sourceHash")})

    project = run_root / "projects" / "previous-atomic-two-word-changed"
    copy_seed(seed_project, project)
    reqs = [
        replacement_request(batch_source(change_closed_ids=True), revision=0,
                            revisions={"account.active": revision, "account.eligible": eligible_revision}),
        request("commit", word="", library=True),
        request("test", word="account.active"),
        request("test", word="account.eligible"),
        request("tests", word="account.active", includeSource=True),
        request("tests", word="account.eligible", includeSource=True),
        request("host.close"),
    ]
    s = run_session(run_root, "previous-atomic-two-word-changed", project, runtime_dir, reqs)
    active_rows = rows_by_name(response_at(s, 4))
    eligible_rows = rows_by_name(response_at(s, 5))
    atomic_ok = session_clean(s) and ok_at(s, 0) and ok_at(s, 1)
    atomic_ok = atomic_ok and check_test_results(response_at(s, 2), 2) and check_test_results(response_at(s, 3), 2)
    atomic_ok = atomic_ok and '"id-other"' in active_rows.get("closed-case", {}).get("source", "")
    atomic_ok = atomic_ok and '"id-other"' in eligible_rows.get("closed-case", {}).get("source", "")
    outcomes.append({"control": "previous-atomic-two-word-changed-inherited-cases", "expected": "accepted", "passed": atomic_ok,
                     "defineOk": ok_at(s, 0), "publicationOk": ok_at(s, 1),
                     "activeTestsPassed": check_test_results(response_at(s, 2), 2),
                     "eligibleTestsPassed": check_test_results(response_at(s, 3), 2),
                     "closedCaseHashes": {"account.active": active_rows.get("closed-case", {}).get("sourceHash"),
                                          "account.eligible": eligible_rows.get("closed-case", {}).get("sourceHash")}})

    project = run_root / "projects" / "previous-unchanged-plus-new"
    copy_seed(seed_project, project)
    reqs = [
        replacement_request(owner_source("account.active", add_regression=True), revision, owner="account.active"),
        request("replace-word", word="account.active"),
        request("test", word="account.active"),
        request("tests", word="account.active", includeSource=True),
        request("host.close"),
    ]
    s = run_session(run_root, "previous-unchanged-plus-new", project, runtime_dir, reqs)
    rows = rows_by_name(response_at(s, 3))
    unchanged_ok = session_clean(s) and ok_at(s, 0) and ok_at(s, 1) and check_test_results(response_at(s, 2), 3)
    unchanged_ok = unchanged_ok and rows.get("closed-case", {}).get("sourceHash") == seed_info["tests"]["account.active/closed-case"]["sourceHash"]
    unchanged_ok = unchanged_ok and "another-closed-id" in rows
    outcomes.append({"control": "previous-unchanged-case-plus-new-regression", "expected": "accepted", "passed": unchanged_ok,
                     "defineOk": ok_at(s, 0), "publicationOk": ok_at(s, 1), "allTestsPassed": check_test_results(response_at(s, 2), 3),
                     "returnedCaseNames": sorted(rows)})
    return outcomes


def capture_unchanged_state(session: dict, before_indices: tuple[int, ...], after_indices: tuple[int, ...]) -> bool:
    if any(not ok_at(session, index) for index in (*before_indices, *after_indices)):
        return False
    return all(canonical(response_data(response_at(session, b))) == canonical(response_data(response_at(session, a)))
               for b, a in zip(before_indices, after_indices, strict=True))


def run_updated_controls(run_root: Path, runtime_dir: Path, seed_project: Path,
                         seed_info: dict) -> list[dict]:
    revisions = seed_info["revision"]
    tests = seed_info["tests"]
    outcomes = []

    # Rejection must occur before any candidate or durable authority changes.
    project = run_root / "projects" / "updated-one-word-undeclared"
    copy_seed(seed_project, project)
    reqs = [request("storage.status"), request("describe", word="account.active"),
            request("tests", word="account.active", includeSource=True),
            replacement_request(owner_source("account.active", change_closed_id=True), revisions["account.active"], owner="account.active"),
            request("storage.status"), request("describe", word="account.active"),
            request("tests", word="account.active", includeSource=True), request("host.close")]
    s = run_session(run_root, "updated-one-word-undeclared", project, runtime_dir, reqs)
    no_stage = session_clean(s) and not ok_at(s, 3) and capture_unchanged_state(s, (0, 1, 2), (4, 5, 6))
    outcomes.append({"control": "updated-one-word-undeclared-mutation", "expected": "reject-with-no-staging",
                     "passed": no_stage, "diagnostic": (response_at(s, 3) or {}).get("error", {}).get("code")})

    active_old = tests["account.active/closed-case"]["sourceHash"]
    project = run_root / "projects" / "updated-one-word-declared"
    copy_seed(seed_project, project)
    reqs = [replacement_request(owner_source("account.active", change_closed_id=True), revisions["account.active"],
                                owner="account.active", test_changes=[{"word": "account.active", "caseName": "closed-case",
                                                                         "expectedSourceHash": active_old}]),
            request("replace-word", word="account.active"), request("test", word="account.active"), request("host.close")]
    s = run_session(run_root, "updated-one-word-declared", project, runtime_dir, reqs)
    outcomes.append({"control": "updated-one-word-declared-with-inspected-hash", "expected": "accept-and-publish",
                     "passed": session_clean(s) and ok_at(s, 0) and ok_at(s, 1) and check_test_results(response_at(s, 2), 2),
                     "sourceHashUsed": active_old})

    # Atomic multiword replacement must reject the whole batch without any partial candidate.
    project = run_root / "projects" / "updated-batch-undeclared"
    copy_seed(seed_project, project)
    reqs = [request("storage.status"), request("describe", word="account.active"),
            request("describe", word="account.eligible"), request("tests", word="account.active", includeSource=True),
            request("tests", word="account.eligible", includeSource=True),
            replacement_request(batch_source(change_closed_ids=True), revision=0, revisions=revisions),
            request("storage.status"), request("describe", word="account.active"), request("describe", word="account.eligible"),
            request("tests", word="account.active", includeSource=True), request("tests", word="account.eligible", includeSource=True),
            request("host.close")]
    s = run_session(run_root, "updated-batch-undeclared", project, runtime_dir, reqs)
    no_batch_stage = session_clean(s) and not ok_at(s, 5) and capture_unchanged_state(s, (0, 1, 2, 3, 4), (6, 7, 8, 9, 10))
    outcomes.append({"control": "updated-atomic-batch-undeclared-mutations", "expected": "reject-entire-batch-with-no-staging",
                     "passed": no_batch_stage, "diagnostic": (response_at(s, 5) or {}).get("error", {}).get("code")})

    project = run_root / "projects" / "updated-batch-declared"
    copy_seed(seed_project, project)
    reqs = [replacement_request(batch_source(change_closed_ids=True), revision=0, revisions=revisions,
                                test_changes=[{"word": "account.active", "caseName": "closed-case", "expectedSourceHash": active_old},
                                              {"word": "account.eligible", "caseName": "closed-case",
                                               "expectedSourceHash": tests["account.eligible/closed-case"]["sourceHash"]}]),
            request("commit", word="", library=True), request("test", word="account.active"),
            request("test", word="account.eligible"), request("host.close")]
    s = run_session(run_root, "updated-batch-declared", project, runtime_dir, reqs)
    outcomes.append({"control": "updated-atomic-batch-declared-with-inspected-hashes", "expected": "accept-and-publish-as-group",
                     "passed": session_clean(s) and ok_at(s, 0) and ok_at(s, 1)
                     and check_test_results(response_at(s, 2), 2) and check_test_results(response_at(s, 3), 2),
                     "sourceHashesUsed": [active_old, tests["account.eligible/closed-case"]["sourceHash"]]})

    return outcomes


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("previous", "updated"), default="previous")
    parser.add_argument("--runtime-dir", type=Path, default=CONTROLS / "runtime" / "previous")
    parser.add_argument("--runtime-revision", default=None)
    parser.add_argument("--run-id", default=None)
    args = parser.parse_args()

    runtime_dir = args.runtime_dir.resolve()
    if args.mode == "previous" and args.runtime_revision is None:
        args.runtime_revision = "b49115589102c8ec80f6b440a097b46a0c984b1a"
    pin = runtime_inventory(runtime_dir, args.runtime_revision)
    if pin["label"] != args.mode:
        pin["label"] = args.mode
    if not HOST.is_file() or not HOST_RUNNER.is_file() or not FIXTURE.is_file():
        raise RuntimeError("trusted V2 host or fixture is missing")
    pwsh = shutil.which("pwsh")
    if not pwsh:
        raise RuntimeError("PowerShell 7 (pwsh) is required for the managed V2 CLI host")

    run_id = args.run_id or f"{args.mode}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    run_root = CONTROLS / "runs" / run_id
    if run_root.exists() or run_root.is_symlink():
        raise RuntimeError(f"refusing to overwrite run evidence: {run_root}")
    (run_root / "projects").mkdir(parents=True)
    (run_root / "sessions").mkdir()
    write_json(run_root / "runtime-pin.json", pin)
    fixture_data = FIXTURE.read_bytes()
    coordinator_pins = {
        "runner": {"path": CONTROLS.relative_to(REPO).joinpath("run_controls.py").as_posix(), "sha256": file_sha256(Path(__file__))},
        "wrapper": {"path": CONTROLS.relative_to(REPO).joinpath("run_v2_host.ps1").as_posix(), "sha256": file_sha256(HOST_RUNNER)},
        "trustedV2Host": {"path": HOST.relative_to(REPO).as_posix(), "sha256": file_sha256(HOST)},
    }
    write_json(run_root / "coordinator-pins.json", coordinator_pins)
    write_json(run_root / "fixture-pin.json", {
        "path": "fixture.flow",
        "bytes": len(fixture_data),
        "sha256": sha256(fixture_data),
        "runtimeBuildBaseRevision": args.runtime_revision,
        "workingSourceIdentity": pin["workingSourceIdentity"],
        "classification": "coordinator-authored runtime control; not a fresh-agent efficacy trial",
    })

    seed_project = run_root / "projects" / "seed"
    seed_project.mkdir()
    baseline_source = FIXTURE.read_text(encoding="utf-8")
    seed_requests = [
        request("define", frontend="flow", source=baseline_source, syntaxVersion=2),
        request("commit", word="", library=True),
        request("test", word="account.active"),
        request("test", word="account.eligible"),
        request("tests", word="account.active", includeSource=True),
        request("tests", word="account.eligible", includeSource=True),
        request("describe", word="account.active"),
        request("describe", word="account.eligible"),
        request("storage.status"),
        request("host.close"),
    ]
    seed = run_session(run_root, "seed-baseline-library", seed_project, runtime_dir, seed_requests)
    outcomes = []
    error = None
    source_info = None
    if session_clean(seed):
        try:
            source_info, seed_storage, baseline_test_results = seed_state(seed)
            write_json(run_root / "source-pins.json", {
                "method": "tests with includeSource=true on the committed seed, using returned sourceHash fields",
                **source_info,
            })
            write_json(run_root / "seed-receipt.json", {
                "seedLibraryCommitted": True,
                "baselineAllTestsPassed": True,
                "baselineResultCounts": {name: len(rows) for name, rows in baseline_test_results.items()},
                "storageStatus": seed_storage,
            })
            if args.mode == "previous":
                outcomes = run_previous_controls(run_root, runtime_dir, seed_project, source_info)
            else:
                outcomes = run_updated_controls(run_root, runtime_dir, seed_project, source_info)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
    else:
        error = "seed host did not exit cleanly"

    passed = error is None and bool(outcomes) and all(row.get("passed") is True for row in outcomes)
    receipt = {
        "schema": "test-preservation-233-runtime-control-v1",
        "status": "passed" if passed else "failed",
        "runId": run_id,
        "mode": args.mode,
        "runtimeBuildBaseRevision": args.runtime_revision,
        "workingSourceIdentity": pin["workingSourceIdentity"],
        "runtimeTreeSha256": pin["treeSha256"],
        "fixtureSha256": sha256(fixture_data),
        "coordinatorPins": coordinator_pins,
        "classification": "mechanical coordinator controls only; not a fresh-agent efficacy trial",
        "networkUsed": False,
        "nativeExecutionOrPackages": False,
        "capabilities": [],
        "managedCliV2Host": "scripts/Start-SubagentTrialHostV2.ps1 via controls/run_v2_host.ps1 with fixed allowlist",
        "perExchangeTimeoutMilliseconds": EXCHANGE_TIMEOUT_MS,
        "childProcessTimeoutSeconds": PROCESS_TIMEOUT_SECONDS,
        "requestsAndResponsesRetained": True,
        "attempts": [{"name": "seed-baseline-library", "exitCode": seed["exitCode"], "cleanClose": session_clean(seed)}]
        + [{"name": row["control"], "passed": row["passed"]} for row in outcomes],
        "outcomes": outcomes,
        "error": error,
    }
    write_json(run_root / "receipt.json", receipt)
    write_json(run_root / "final-status.json", {"status": receipt["status"], "error": error, "outcomeCount": len(outcomes)})
    print(json.dumps(receipt, indent=2, ensure_ascii=False))
    return 0 if passed else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"control runner failed before receipt: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise

#requires -Version 7.0
param(
    [Parameter(Mandatory)][string]$CliDll,
    [Parameter(Mandatory)][string]$ProjectPath,
    [Parameter(Mandatory)][string]$TracePath
)

$ErrorActionPreference = 'Stop'
$trustedHost = Join-Path $PSScriptRoot '..\..\..\scripts\Start-SubagentTrialHostV2.ps1'
$allowed = @('define', 'commit', 'replace-word', 'test', 'tests', 'describe', 'storage.status')
& $trustedHost `
    -CliDll $CliDll `
    -ProjectPath $ProjectPath `
    -TracePath $TracePath `
    -AllowedOperations $allowed `
    -ClockValue '2000-01-01T00:00:00Z' `
    -MaxRequestBytes 32768 `
    -MaxResponseBytes 131072 `
    -ExchangeTimeoutMilliseconds 12000 `
    -MaxExchanges 14

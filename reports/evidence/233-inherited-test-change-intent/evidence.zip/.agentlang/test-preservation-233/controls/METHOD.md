# Test-preservation 233 coordinator controls

These are mechanical managed-runtime controls, not fresh-agent efficacy trials. `fixture.flow` defines pure Flow/2 library words `account.active(id, status)` and `account.eligible(id, status)`, with active and closed cases returning `true` and `false`. The existing `closed-case` calls use `"id-old"`; changing only that literal to `"id-other"` still returns `false` because the fixture's result depends on status.

Run the previous-runtime controls with:

```powershell
python -B .agentlang/test-preservation-233/controls/run_controls.py --mode previous
```

The final previous-runtime receipt is `runs/previous-flow2-final/receipt.json`. All three requested outcomes passed: a one-word replacement accepted the changed inherited case, an atomic two-word replacement accepted the two changed inherited cases, and a replacement with unchanged inherited cases plus a new regression passed. The seed was committed as a library and both words' true/false tests passed. Every run retains the exact JSONL requests, raw responses, stderr, V2 trace, child-process record, and project store. `source-pins.json` obtains the original immutable hashes from `tests` with `includeSource=true`; no case hash is hand-maintained.

The copied previous runtime is pinned to source revision `b49115589102c8ec80f6b440a097b46a0c984b1a`; its exact runtime file hashes are in `runs/previous-flow2-final/runtime-pin.json`. The fixture, runner, wrapper, and trusted V2 host hashes are recorded alongside the run receipt. The first attempt, `runs/previous-20261011T202604Z`, failed in PowerShell argument binding before the V2 host or CLI started. It is retained as a failed setup attempt. Later successful exploratory runs are also retained; use `previous-flow2-final` as the final Flow/2 dotted-call run.

`run_controls.py --mode updated --runtime-dir .agentlang/test-preservation-233/controls/runtime/current --runtime-revision <full-revision>` is prepared for four later controls: an undeclared one-word change must reject without changing candidate or durable state; the same change with the inspected old hash must publish; an undeclared two-word batch must reject atomically; and the batch with both inspected hashes must publish as a group. The updated runtime has not been supplied or tested, so these are expectations only. Its seed and accepted replacements still exercise library tests over both boolean outcomes; this is not a claim about fresh-agent behavior.

The coordinator uses the existing V2 host with a fixed operation allowlist, no capabilities, a 12-second exchange limit, a 45-second child-process timeout, and per-session `TEMP`/`TMP` directories inside the evidence tree. Requests invoke only `define`, `commit`, `replace-word`, `test`, `tests`, `describe`, and `storage.status`; no packages, network operations, or native execution are used.

#!/usr/bin/env python3
"""Create the sealed 233 source/control evidence ZIP after root finalization."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import zipfile


REPO = Path(__file__).resolve().parents[2]
OUT = REPO / "reports" / "evidence" / "233-inherited-test-change-intent"
CONTROL_ROOT = Path(".agentlang/test-preservation-233/controls")
VALIDATION_ROOT = Path(".agentlang/test-preservation-233/validation")
SANDBOX_JSON = VALIDATION_ROOT / "full.json"
SANDBOX_LOG = VALIDATION_ROOT / "full.log"
HOST_RETRY_JSON = VALIDATION_ROOT / "host-business-policy-preflight.json"
HOST_RETRY_LOG = VALIDATION_ROOT / "host-business-policy-preflight.log"
AGGREGATE_RECEIPT = VALIDATION_ROOT / "aggregate-receipt.json"
UPDATED_RECEIPT = CONTROL_ROOT / "runs/updated-final/receipt.json"
CURRENT_COPY_PIN = CONTROL_ROOT / "runtime/current-copy-pin.json"
BUILD_DIAGNOSTIC = Path(".agentlang/test-preservation-233/implementation/build-diag.log")
BASE_REVISION = "b49115589102c8ec80f6b440a097b46a0c984b1a"
SOURCE_FILES = (
    Path("src/AgentLang.Core/Runtime.fs"),
    Path("src/AgentLang.Core/AuthoringHelp.fs"),
    Path("tests/AgentLang.Flow.Runtime.Tests/Program.fs"),
)
EXCLUDED_PARTS = {
    ".git", "bin", "obj", "artifacts", "__pycache__", "cache", "temp", "tmp", "host-temp",
    "runtime", "workspace-tmp",
}
SECRET_PATTERNS = {
    "credential_assignment": re.compile(
        r"(?i)\b(?:password|passwd|secret|api[_ -]?key|client[_ -]?secret|access[_ -]?token|refresh[_ -]?token)\b\s*[:=]\s*['\"]?[^\s'\"`,;]+"
    ),
    "authorization_bearer": re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/-]{12,}"),
    "provider_token": re.compile(r"(?i)\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9]{20,})\b"),
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def repo_path(value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"archive inputs must be repository-relative: {path}")
    candidate = REPO / path
    try:
        candidate.relative_to(REPO)
    except ValueError as exc:
        raise ValueError(f"archive input escapes repository: {path}") from exc
    cursor = candidate
    while cursor != REPO:
        if cursor.is_symlink():
            raise ValueError(f"archive input traverses a symlink: {cursor.relative_to(REPO).as_posix()}")
        cursor = cursor.parent
    if not candidate.exists():
        raise FileNotFoundError(f"archive input does not exist: {path}")
    if not candidate.is_relative_to(REPO):
        raise ValueError(f"archive input escapes repository: {path}")
    return candidate


def excluded(relative: Path) -> bool:
    return any(part.lower() in EXCLUDED_PARTS for part in relative.parts)


def read_regular(path: Path) -> bytes:
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ValueError(f"archive input is not a regular file: {path.relative_to(REPO)}")
    return path.read_bytes()


def collect_tree(relative: Path, *, required: bool = True) -> list[Path]:
    root = repo_path(relative)
    if root.is_symlink():
        raise ValueError(f"refusing symlinked input tree: {relative}")
    if root.is_file():
        return [root] if not excluded(relative) else []
    files: list[Path] = []
    for directory, dirs, names in os.walk(root, topdown=True, followlinks=False):
        directory_path = Path(directory)
        safe_dirs = []
        for name in sorted(dirs):
            child = directory_path / name
            rel = child.relative_to(REPO)
            if child.is_symlink():
                raise ValueError(f"refusing symlink in archive tree: {rel.as_posix()}")
            if not excluded(rel):
                safe_dirs.append(name)
        dirs[:] = safe_dirs
        for name in sorted(names):
            child = directory_path / name
            rel = child.relative_to(REPO)
            if excluded(rel):
                continue
            if child.is_symlink():
                raise ValueError(f"refusing symlink in archive tree: {rel.as_posix()}")
            if not child.is_file():
                raise ValueError(f"unexpected non-file in archive tree: {rel.as_posix()}")
            files.append(child)
    if required and not files:
        raise ValueError(f"required archive tree is empty: {relative}")
    return files


def collect_inputs(report: Path) -> list[Path]:
    explicit = [
        Path("README.md"),
        Path("reports/README.md"),
        report,
        Path(".agentlang/test-preservation-233/archive_evidence.py"),
        Path(".agentlang/test-preservation-233/plan.md"),
        Path(".agentlang/test-preservation-233/review.md"),
        *SOURCE_FILES,
        Path("scripts/Start-SubagentTrialHostV2.ps1"),
        Path(".agentlang/test-preservation-233/controls/METHOD.md"),
        Path(".agentlang/test-preservation-233/controls/fixture.flow"),
        Path(".agentlang/test-preservation-233/controls/run_controls.py"),
        Path(".agentlang/test-preservation-233/controls/run_v2_host.ps1"),
        Path(".agentlang/test-preservation-233/controls/runtime/current-copy-pin.json"),
        SANDBOX_JSON,
        SANDBOX_LOG,
        HOST_RETRY_JSON,
        HOST_RETRY_LOG,
        AGGREGATE_RECEIPT,
    ]
    files: set[Path] = set()
    for item in explicit:
        files.add(repo_path(item))
    for tree in (
        Path(".agentlang/test-preservation-233/implementation"),
        Path(".agentlang/test-preservation-233/controls/runs"),
        Path(".agentlang/test-preservation-233/validation"),
    ):
        files.update(collect_tree(tree))
    return sorted(files, key=lambda path: path.relative_to(REPO).as_posix())


def check_secret_scan(path: Path, data: bytes) -> dict:
    text = data.decode("utf-8", errors="replace")
    counts = {name: len(pattern.findall(text)) for name, pattern in SECRET_PATTERNS.items()}
    if any(counts.values()):
        raise ValueError(f"credential-pattern review needs redaction before including {path.relative_to(REPO)}")
    return {"path": path.relative_to(REPO).as_posix(), "bytes": len(data), "patternMatchCounts": counts,
            "status": "no matched credential patterns"}


def source_pin_check(data_by_member: dict[str, bytes]) -> dict:
    receipt_member = ".agentlang/test-preservation-233/controls/runs/updated-final/receipt.json"
    receipt = json.loads(data_by_member[receipt_member].decode("utf-8"))
    identity = receipt.get("workingSourceIdentity", {})
    pinned = {row["path"]: row["sha256"] for row in identity.get("files", [])}
    results = []
    for source in SOURCE_FILES:
        name = source.as_posix()
        data = data_by_member[name]
        actual = digest(data)
        expected = pinned.get(name)
        if not expected or actual != expected:
            raise ValueError(f"source snapshot does not match updated runtime pin: {name}")
        results.append({"path": name, "sha256": actual, "matchesUpdatedRuntimePin": True})
    return {"baseRevision": receipt.get("runtimeBuildBaseRevision"),
            "identityNote": identity.get("status"), "files": results}


def validation_aggregate_data() -> tuple[dict, dict[str, bytes]]:
    input_paths = (SANDBOX_JSON, SANDBOX_LOG, HOST_RETRY_JSON, HOST_RETRY_LOG, BUILD_DIAGNOSTIC,
                   UPDATED_RECEIPT, CURRENT_COPY_PIN, *SOURCE_FILES)
    input_bytes = {path.as_posix(): read_regular(repo_path(path)) for path in input_paths}
    sandbox = json.loads(input_bytes[SANDBOX_JSON.as_posix()].decode("utf-8"))
    sandbox_checks = sandbox.get("checks")
    if not isinstance(sandbox_checks, list) or len(sandbox_checks) != 37:
        raise ValueError("sandbox full validation must contain exactly 37 checks")
    sandbox_failures = [check for check in sandbox_checks if check.get("exitCode") != 0]
    sandbox_passes = [check for check in sandbox_checks if check.get("exitCode") == 0]
    if len(sandbox_passes) != 36 or len(sandbox_failures) != 1:
        raise ValueError("sandbox full validation must retain exactly 36 passes and one failure")
    failed = sandbox_failures[0]
    if failed.get("name") != "business-policy-preflight" or failed.get("exitCode") != 1:
        raise ValueError("sandbox's sole failed check is not business-policy-preflight/exit 1")
    failed_output = "\n".join(str(line) for line in failed.get("output", []))
    if "NU1900" not in failed_output:
        raise ValueError("sandbox business-policy-preflight failure no longer records NU1900")
    if sandbox.get("passed") is not False or sandbox.get("packageAuditSkipped") is not False:
        raise ValueError("sandbox full validation must remain a non-passing, audit-enabled result")
    sandbox_log = input_bytes[SANDBOX_LOG.as_posix()]
    if b"NU1900" not in sandbox_log:
        raise ValueError("sandbox full log does not preserve the NU1900 diagnostic")

    host = json.loads(input_bytes[HOST_RETRY_JSON.as_posix()].decode("utf-8"))
    host_checks = host.get("checks")
    if host.get("passed") is not True or host.get("isolated") is not True:
        raise ValueError("trusted-host retry must pass and report isolated execution")
    if not isinstance(host_checks, list) or len(host_checks) != 98:
        raise ValueError("trusted-host retry must contain exactly 98 checks")
    host_failures = [check for check in host_checks if check.get("passed") is not True]
    if host_failures:
        raise ValueError("trusted-host retry has failed checks")
    host_log = input_bytes[HOST_RETRY_LOG.as_posix()]
    if not host_log:
        raise ValueError("trusted-host retry log is empty")

    diagnostic = input_bytes[BUILD_DIAGNOSTIC.as_posix()]
    diagnostic_text = diagnostic.decode("utf-8", errors="replace")
    audit_true_count = len(re.findall(r"(?im)^\s*NuGetAudit\s*=\s*true\s*$", diagnostic_text))
    if audit_true_count < 1:
        raise ValueError("retained implementation diagnostic has no NuGetAudit=true evidence")
    build_diag_review = check_secret_scan(repo_path(BUILD_DIAGNOSTIC), diagnostic)

    pin_data = {
        **{path.as_posix(): input_bytes[path.as_posix()] for path in SOURCE_FILES},
        UPDATED_RECEIPT.as_posix(): input_bytes[UPDATED_RECEIPT.as_posix()],
    }
    source_pins = source_pin_check(pin_data)
    if source_pins.get("baseRevision") != BASE_REVISION:
        raise ValueError("updated runtime receipt base revision differs from the expected source pin")
    updated_receipt = json.loads(input_bytes[UPDATED_RECEIPT.as_posix()].decode("utf-8"))
    if updated_receipt.get("status") != "passed" or len(updated_receipt.get("outcomes", [])) != 4:
        raise ValueError("updated coordinator controls must remain four-for-four passed")
    copy_pin = json.loads(input_bytes[CURRENT_COPY_PIN.as_posix()].decode("utf-8"))
    post_run = copy_pin.get("postRun", {})
    if not all(post_run.get(key) is True for key in ("buildOutputsUnchanged", "copiedRuntimeUnchanged", "workingSourcesUnchanged")):
        raise ValueError("current runtime/source copy pin does not confirm unchanged bytes after controls")
    copied_working = {row["path"]: row["sha256"] for row in copy_pin.get("workingSourceHashes", [])}
    if any(copied_working.get(row["path"]) != row["sha256"] for row in source_pins["files"]):
        raise ValueError("working source hashes differ from the copied runtime pin")

    records = {
        path.as_posix(): {"path": path.as_posix(), "sha256": digest(input_bytes[path.as_posix()]),
                          "bytes": len(input_bytes[path.as_posix()])}
        for path in (SANDBOX_JSON, SANDBOX_LOG, HOST_RETRY_JSON, HOST_RETRY_LOG)
    }
    receipt = {
        "schema": "test-preservation-233-validation-aggregate-v1",
        "status": "passed",
        "passed": True,
        "interpretation": "The aggregate gates pass. The sandbox full run itself remains failed at its sole NU1900 package-audit preflight check; it is not represented as a 37-check pass.",
        "sandbox": {
            "json": records[SANDBOX_JSON.as_posix()],
            "log": records[SANDBOX_LOG.as_posix()],
            "passedChecks": len(sandbox_passes),
            "failedChecks": [{"name": failed.get("name"), "exitCode": failed.get("exitCode"), "diagnostic": "NU1900"}],
            "passed": False,
            "packageAuditSkipped": sandbox.get("packageAuditSkipped"),
        },
        "trustedHostRetry": {
            "sessionId": 1077,
            "json": records[HOST_RETRY_JSON.as_posix()],
            "log": records[HOST_RETRY_LOG.as_posix()],
            "passed": host.get("passed"),
            "checkCount": len(host_checks),
            "failedCheckCount": len(host_failures),
            "configuration": "Release",
            "isolated": host.get("isolated"),
            "sourceRevision": host.get("sourceRevision"),
            "invocationProvenance": "Root-confirmed exact trusted-host execution session 1077; child JSON/log do not echo full argv or NuGetAudit property.",
            "auditEnabled": True,
            "auditEnabledSource": "Root-confirmed invocation, corroborated by sandbox packageAuditSkipped=false and NuGetAudit=true entries in the retained implementation diagnostic; not inferred from the redirected child log.",
        },
        "auditEvidence": {
            "sandboxPackageAuditSkipped": False,
            "sandboxNU1900FailurePreserved": True,
            "buildDiagnostic": {"path": BUILD_DIAGNOSTIC.as_posix(), "sha256": digest(diagnostic),
                                "nuGetAuditTrueMentions": audit_true_count,
                                "secretPatternReview": build_diag_review["status"]},
        },
        "sourcePins": source_pins,
        "controlStatus": {"updatedRuntimeControls": "passed", "outcomeCount": 4,
                          "copiedRuntimeAndSourceBytesUnchanged": True},
    }
    return receipt, input_bytes


def verify_aggregate_receipt() -> tuple[dict, bytes]:
    expected, _ = validation_aggregate_data()
    path = repo_path(AGGREGATE_RECEIPT)
    data = read_regular(path)
    actual = json.loads(data.decode("utf-8"))
    if actual != expected:
        raise ValueError("aggregate receipt does not match current validation, audit, or source-pin inputs")
    return actual, data


def write_aggregate_receipt() -> int:
    expected, _ = validation_aggregate_data()
    path = REPO / AGGREGATE_RECEIPT
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"refusing to overwrite aggregate receipt: {AGGREGATE_RECEIPT.as_posix()}")
    data = json_bytes(expected)
    with path.open("xb") as stream:
        stream.write(data)
    reread, _ = verify_aggregate_receipt()
    print(json.dumps({"path": AGGREGATE_RECEIPT.as_posix(), "sha256": digest(data),
                      "status": reread["status"], "passed": reread["passed"],
                      "sandboxPassedChecks": reread["sandbox"]["passedChecks"],
                      "sandboxFailedCheck": reread["sandbox"]["failedChecks"][0]["name"],
                      "trustedHostCheckCount": reread["trustedHostRetry"]["checkCount"],
                      "trustedHostFailedCheckCount": reread["trustedHostRetry"]["failedCheckCount"]},
                     indent=2, ensure_ascii=False))
    return 0


def safe_member_name(name: str) -> bool:
    candidate = Path(name)
    return (not candidate.is_absolute() and ".." not in candidate.parts and "\\" not in name
            and name and not name.startswith("/"))


def write_zip(path: Path, members: list[tuple[str, bytes]]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in members:
            if not safe_member_name(name):
                raise ValueError(f"unsafe ZIP member name: {name}")
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.create_system = 3
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_zip(path: Path, expected: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "r") as archive:
        infos = archive.infolist()
        names = [item.filename for item in infos]
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise ValueError("ZIP member inventory mismatch or duplicate member")
        for info in infos:
            if not safe_member_name(info.filename):
                raise ValueError(f"unsafe ZIP member on readback: {info.filename}")
            mode = info.external_attr >> 16
            if not stat.S_ISREG(mode):
                raise ValueError(f"non-regular ZIP member: {info.filename}")
            if archive.read(info.filename) != expected[info.filename]:
                raise ValueError(f"ZIP member byte mismatch: {info.filename}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    actions.add_parser("aggregate", help="verify and write the hash-pinned validation aggregate only")
    seal = actions.add_parser("seal", help="write the ZIP/index/receipt after root confirms final report")
    seal.add_argument("--root-notified-final", action="store_true", required=True,
                      help="required acknowledgement: root confirmed final report and validation evidence")
    seal.add_argument("--report", required=True, type=Path, help="final repository-relative report path")
    args = parser.parse_args()
    if args.action == "aggregate":
        return write_aggregate_receipt()

    aggregate, aggregate_bytes = verify_aggregate_receipt()
    report_path = repo_path(args.report)
    files = collect_inputs(args.report)
    contents: dict[str, bytes] = {}
    for path in files:
        name = path.relative_to(REPO).as_posix()
        contents[name] = read_regular(path)
    if contents[report_path.relative_to(REPO).as_posix()] == b"":
        raise ValueError("final report is empty")

    for group in ("sandbox", "trustedHostRetry"):
        for kind in ("json", "log"):
            record = aggregate[group][kind]
            if digest(contents[record["path"]]) != record["sha256"]:
                raise ValueError(f"validation aggregate input changed before sealing: {record['path']}")
    if contents[AGGREGATE_RECEIPT.as_posix()] != aggregate_bytes:
        raise ValueError("aggregate receipt changed during archive input collection")

    diag_name = ".agentlang/test-preservation-233/implementation/build-diag.log"
    secret_review = check_secret_scan(repo_path(diag_name), contents[diag_name])
    source_identity = source_pin_check(contents)

    members = [(name, contents[name]) for name in sorted(contents)]
    index_members = [{"path": name, "bytes": len(data), "sha256": digest(data)} for name, data in members]
    OUT.mkdir(parents=True, exist_ok=True)
    archive_path = OUT / "evidence.zip"
    index_path = OUT / "index.json"
    receipt_path = OUT / "receipt.json"
    if any(path.exists() or path.is_symlink() for path in (archive_path, index_path, receipt_path)):
        raise FileExistsError("refusing to overwrite existing 233 evidence archive, index, or receipt")

    fd, temporary_name = tempfile.mkstemp(prefix=".evidence-", suffix=".zip", dir=OUT)
    os.close(fd)
    temporary_path = Path(temporary_name)
    try:
        write_zip(temporary_path, members)
        expected = dict(members)
        verify_zip(temporary_path, expected)
        archive_sha = digest(temporary_path.read_bytes())
        archive_size = temporary_path.stat().st_size
        os.replace(temporary_path, archive_path)
        verify_zip(archive_path, expected)
        archive_sha = digest(archive_path.read_bytes())
        index = {
            "schema": "233-inherited-test-change-intent-evidence-index-v1",
            "status": "verified-final-evidence-with-disclosed-sandbox-NU1900",
            "archive": {"path": archive_path.name, "bytes": archive_size, "sha256": archive_sha},
            "memberCount": len(index_members),
            "members": index_members,
            "sourceIdentity": source_identity,
            "buildDiagnosticSecretReview": secret_review,
            "finalReport": args.report.as_posix(),
            "validationAggregate": {"path": AGGREGATE_RECEIPT.as_posix(),
                                    "sha256": digest(aggregate_bytes),
                                    "status": aggregate["status"],
                                    "sandbox": aggregate["sandbox"],
                                    "trustedHostRetry": aggregate["trustedHostRetry"]},
            "coverage": ["plan and review", "final report and README context", "three source snapshots",
                         "implementation logs including failed attempts", "control scripts, fixtures, pins, prior and updated runs, raw traces and stores",
                         "raw sandbox full validation with the sole NU1900 failure, trusted-host retry JSON/log, and aggregate receipt"],
            "excluded": [".git", "bin", "obj", "artifacts", "runtime DLL directories", "temp/cache trees"],
        }
        index_data = json_bytes(index)
        index_path.write_bytes(index_data)
        receipt = {
            "schema": "233-inherited-test-change-intent-evidence-receipt-v1",
            "status": "verified",
            "archivePath": archive_path.relative_to(REPO).as_posix(),
            "archiveSha256": archive_sha,
            "archiveBytes": archive_size,
            "memberCount": len(index_members),
            "indexPath": index_path.relative_to(REPO).as_posix(),
            "indexSha256": digest(index_data),
            "zipMemberReadback": "all members byte-for-byte verified; no traversal paths, symlinks, duplicate members, or compiled runtime files",
            "validationAggregatePath": AGGREGATE_RECEIPT.as_posix(),
            "validationAggregateSha256": digest(aggregate_bytes),
        }
        receipt_path.write_bytes(json_bytes(receipt))
        print(json.dumps(receipt, indent=2, ensure_ascii=False))
        return 0
    except Exception:
        if temporary_path.exists():
            temporary_path.unlink()
        raise


if __name__ == "__main__":
    raise SystemExit(main())

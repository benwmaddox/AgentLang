# Plan: require explicit CAS for changed inherited tests

## Recommendation

Use a small per-case intent check on definition replacement, not an agent-supplied allowlist presented as trusted policy. The report-231 failure was a changed literal in an inherited test whose result did not change. Requiring the caller to identify every changed inherited case and provide its prior immutable source hash would have stopped that accidental resubmission unless the agent explicitly opted into it. The runtime cannot know the task prompt, so a declaration does not authorize a task-scope change: the frozen task packet and independent source review remain authoritative.

This is the shortest core change with a plausible reliability benefit. Preserving tests only when omitted already works, but multiword and single-word replacement requests can re-submit an existing case with different source without a case-level CAS. A declaration adds friction at exactly that boundary while still allowing requested test adaptations. Do not block new cases: they are additions, not inherited-case mutations, and need no redundant declaration.

## Protocol and runtime behavior

Add optional `testChanges` to Flow `define`. It is an array of rows shaped as:

```json
{"word":"subscription.renew-monthly","caseName":"existing-case","expectedSourceHash":"<current hash>"}
```

For each incoming inline test whose `(owner, caseName)` already exists, compare the incoming immutable source hash to the current attachment. Identical content requires no row. Different content requires exactly one row with the current hash. Reject missing, stale, duplicate, or unused rows before candidate state changes. A new case needs no row; omitted cases retain existing behavior. Use deterministic diagnostics. `tests` with `includeSource: true` already returns the exact source hash needed to form a row.

Apply the same helper to both places that accept inline test sources while replacing definitions: `registerFlowParsedLegacyWithAttachmentVersion` for single-word Flow replacement and `registerFlowReplacementProjectParsed` for word-only multiword and record type-evolution replacements. This closes route asymmetry without changing the stored model; `FlowAuthoredAttachment.Source.Reference.Hash` is sufficient. Keep the dedicated attachment-only and test-file edit routes as explicit test-edit operations with their existing owner CAS and collision rules. They are separate APIs whose purpose is to change attachments, rather than an incidental side effect of replacing definitions. Keep Stack-to-Flow legacy test migration behavior out of this first cut and call out that limit.

The declaration is not a security boundary or task authorization. An agent can declare an unrelated edit. The guard catches omitted or mistaken resubmissions, makes intentional changes inspectable, and gives the runtime a stale-source check; an independent grader must still compare changes with the task's requested case set.

## Files

- `src/AgentLang.Core/Runtime.fs`: parse the new rows and validate them before staging in both replacement routes.
- `src/AgentLang.Core/AuthoringHelp.fs`: expose `testChanges` in the Flow define contract and explain that it is required only for changed existing inline cases. Clarify that new cases remain allowed without it.
- `tests/AgentLang.Flow.Runtime.Tests/Program.fs`: add focused positive and negative controls to the existing single-word and atomic-replacement coverage.

No PRD change is needed: it describes the product's definition-level editing and reliability goals, not this request schema. The interactive help is the authoritative request contract; README replacement prose need only change if it is being used as a protocol reference.

## Acceptance and tests

In both replacement routes, test that: an identical re-submitted case succeeds without a declaration; a new case succeeds without a declaration; a changed existing case fails without a declaration; the same edit succeeds with its exact prior hash; and stale, duplicate, or unused declarations fail. Reproduce the report-231 pattern as a changed input literal in an inherited case and verify it is rejected before staging. For every rejection, assert unchanged revisions, candidate state, and durable manifest. Cover record type evolution through the shared project route so it cannot bypass the guard. Verify the explicit attachment-only editor continues to accept its intended CAS-bound edit.

Run:

```powershell
dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release
git diff --check
```

## Prospective efficacy check and limits

For a separate 233 milestone, freeze the report-231 seed and task with an independent list of existing cases the task permits changing. Run matched fresh-agent trials on the previous and updated runtime. The participant should adapt only the listed inherited monthly-call cases and add the requested new regression. Independently compare complete case source/hash sets with the packet; do not treat `testChanges` rows as proof of authorization. Record behavior outcome, out-of-scope existing-case changes, declaration-related rejections/retries, broker exchanges, and session time. Describe a small pair as a feasibility observation, not a reliability rate or causal result.

The main compatibility cost is that existing definition-replacement clients which change an inline case must now obtain its source hash and provide a row. Re-sending identical cases, adding new cases, omitting retained cases, and explicit attachment-only edits stay unchanged. Hashes compare exact authored bytes, so formatting-only changes also require a declaration. This prototype can make accidental drift harder, but cannot stop a deliberate or misjudged edit that the caller declares.

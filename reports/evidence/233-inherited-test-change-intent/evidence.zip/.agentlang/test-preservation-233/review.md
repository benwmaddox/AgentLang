# Inherited test intent review

Reviewed the scoped working-tree snapshot on `feature/test-preservation-233`. This is a bounded source review; I did not build or run tests, as requested. The test file was still being finalized during review, so recheck it against the final source snapshot before treating the review as final.

## Findings

1. **Stack-to-Flow migration remains an explicit coverage boundary.** In `Runtime.fs:5138-5147`, migration requires the request to resubmit every prior Stack test and example, but those tests have no prior `FlowAuthoredAttachment` entry for `validateFlowTestChanges` to compare. Thus resubmitted Stack tests are treated as new and need no `testChanges` row. The route rejects a supplied `testChanges` field at `Runtime.fs:5134-5135`. This matches the stated plan exception. The updated README now mentions the migration's full-resubmission rule (`README.md:392`), while the help still describes `testChanges` broadly (`AuthoringHelp.fs:194,579`); scoping that help text to prior Flow-authored attachments would make the same boundary clear to callers.

2. **The rejection matrix is concentrated on the single-word route.** The new missing, stale, duplicate, malformed, and unused declaration cases are in `Program.fs:3378-3415`, which exercises the one-word legacy route. The multiword and record-evolution routes share the replacement validator at `Runtime.fs:4687-4695`, and existing positive tests exercise declared edits there (`Program.fs:1063`, `1341-1346`), but there is no negative `FLOW_TEST_CHANGE_REQUIRED` case through either route. Code inspection shows the call is present; a route-level negative test would guard against future routing changes bypassing it.

3. **Rejected-edit assertions omit the test attachment inventory.** `Program.fs:3372-3376` checks the manifest, word listing, owner description, and definition source after rejection, but not `tests` with `includeSource=true`. The validator currently runs before activation, so the implementation ordering is sound; checking attachment sources in the rejection helper would make the atomicity assertion cover the resource being guarded.

## Route and scope checks

- Single-word requests with inline document tests preserve `testChanges` while routing into the legacy validator (`Runtime.fs:5826-5841`). Multiword and record-evolution replacements call the validator before activating their proposed snapshot (`Runtime.fs:4687-4699`). Single-word replacement validates before `activateRuntimeSnapshot` (`Runtime.fs:5346-5356`). I found no unintended bypass in those Flow definition routes.
- The explicit attachment-only and test-file routes reject `testChanges`; the attachment-only Flow editor then calls the legacy registration helper with the intent guard disabled and retains its owner revision check (`Runtime.fs:5371-5374`, `5723-5726`, `5761-5797`). The non-Flow define route rejects the field (`Runtime.fs:6137-6146`).
- Flow-to-Stack overwrite is blocked in `registerParsed`: it rejects Stack declarations targeting an existing Flow owner and Stack test/example attachments targeting that owner before constructing staged state (`Runtime.fs:3306-3319`). I found no focused regression test for this existing route guard in the scoped test file.
- The new logic parses declaration metadata and compares it with stored source references. Within the reviewed hunks, I found no new host capability or authority path. This is a source-scope observation, not a broader security conclusion.

## Reviewed snapshot

SHA-256 file hashes at review time:

- `Runtime.fs`: `9A20CA6A4118D2DE23024560926BB4E09C2FE867013D30C5B7266181CB5544C2`
- `AuthoringHelp.fs`: `836BACACBB40948551EEAF79994F963C9D4189653AC093991D4EAE37B080414D`
- `Program.fs`: `1909259CCA0174EA8E5607E7A0EC05C691CB0CFEA989BDD17EABE8A64CCAF572`
- `README.md`: `9B30A462D0D6F00042FECE4592733A90257AF54FF0AEC21B89A9493149DCDC9B`
- `plan.md`: `0356E6EFFC58E346A6AFF4E398D6FE6E8FFFE03ED841EE4286B2561FC89A0F94`

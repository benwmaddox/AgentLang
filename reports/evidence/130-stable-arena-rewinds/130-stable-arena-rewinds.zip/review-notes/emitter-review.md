# Descriptor emitter read-only review

Reviewed `OwningStackAot.fs` descriptor lowering and native publication against the current `ArenaLifetime` decisions. No additional concrete correctness issue found in this focused pass.

- `emitModule` calls `emitDynamicModule` unconditionally, so fixed and String layouts use the descriptor emitter. The old packed fixed emitter has no call site.
- A successful scope rewind is emitted only when the scope site's `ScopeExits` entry has `AllowRewind = true`; frame rewind is emitted only for `FunctionExit.AllowRewind = true`. Missing analysis is fail-closed. The runtime descriptor/cursor checks validate storage but do not authorize reclamation.
- Each branch computes its own stack descriptors and joins them with offset, extent, payload, and owner-end PHIs. Local slots are shared across branch control flow and typed by the verifier's matching join shape. Child scope flags clear at exit; same-slot outer bindings remain available through fallback metadata.
- Calls pass descriptor arrays without moving payloads, validate arguments at callee entry, and validate returned descriptors at caller entry. A callee may rewind only its frame's post-entry allocations when outputs do not depend on them. Zero-input and zero-output arrays use null safely because their loops do not dereference them.
- Record construction copies fields into a new owner; field projection carries the parent's owner end. A projected zero-width Empty field is materialized as an eight-byte standalone token at wrapper publication, after its retained capacity is included in the total. The backing owner remains live through `ArenaLifetime` field provenance.
- Native publication writes into a host staging allocation. The host decodes all staged bytes before copying them into the caller's retained buffer, preserving the caller buffer on native failure or decode failure.

This is a static review while emitter smoke work is ongoing, not a completed test gate. The earlier duplicate detached-site issue is tracked in `lifetime-review.md`; Core verifier rejection and fail-closed decision merging were being implemented separately.

Metric fidelity gap: descriptor `drop` and successful arena rewinds do not decrement `LivePayloadBytes`, while allocations increment it. `PeakLiveStackBytes` therefore reflects cumulative payload allocation rather than logical live roots, and `UniqueLivePayloadBytes` is reported as `None`. The stable-arena document asks to report logical roots, unique live payload, occupied cursor, and dead interior separately. This reporting issue does not authorize or affect any rewind decision.

# Stable arena emitter notes

The selected compiler path now uses one descriptor emitter for fixed and
dynamic verified types. Operand, local, call-argument, and call-result values
carry the five `i32` fields `Type`, `Offset`, `Extent`, `Payload`, and
`OwnerEnd`. Ordinary binding, field projection, call/return, and cleanup transfer
descriptor metadata without relocating payload bytes. Record construction uses
the source-preserving range-copy helper; explicit `dup` creates its own inline
copy. Constants and concatenation append into the request arena.

Scope exits and function exits consult `ArenaLifetime` decisions made from
verified IR. A permitted boundary emits its static rewind event and calls
`release_to` at the compiler-saved cursor mark. A zero-byte event is valid when
the mark equals the current cursor; it records execution of the proved
boundary, not a payload release. No runtime liveness scan chooses whether a
boundary is safe. Unknown/effectful call paths retain their payload suffixes.

Field descriptors inherit their backing owner's end. A nested zero-width
`Empty` field keeps extent zero; standalone serialization materializes the
canonical token at the output boundary rather than reading adjacent bytes.
Public live-payload totals remain unavailable because descriptor aliases and
retained dead-interior ranges make the old sums inaccurate. Cursor peak/final
measurements remain available, and descriptor-transfer metrics are reported
separately from payload movement.

## Validation evidence

- The fresh Release LLVM project build succeeded with zero warnings and zero
  errors as part of the final fresh verifier run. Captured output is in
  `verification-9fa2306d2e504642a5bcaf64c13d27e8/fresh-dotnet-build.stdout.txt`.
- The compiler-proven lifetime test mode passed all 33 assertions. Captured
  output is in
-  `verification-9fa2306d2e504642a5bcaf64c13d27e8/compiler-proved-arena-lifetime-tests.stdout.txt`.
- The final focused verifier passed all 35 checks, and the bounded native
  experiment passed all 626 boolean assertions across interpreter, ABI3 fixed
  controls, and owning-stack O0/O2 cases. The native evidence reports
  `failureCount: 0`. Captured output and detailed traces are in
  `verification-9fa2306d2e504642a5bcaf64c13d27e8/verification-evidence.json`
  and
  `verification-9fa2306d2e504642a5bcaf64c13d27e8/native-value-stack-evidence.json`.
  The run confirms the 512-byte N=1 case succeeds at its measured 184-byte
  cursor peak, and the N=8 control remains a capacity failure. Dead-only
  fixed/String scopes record two scope boundaries plus a zero-byte function
  exit boundary; observed marks are 48 and 96, with a 16-byte inner suffix.
  Escaping results and uncertain call outputs passed without unsafe scope
  rewinds. Descriptor transfers are separately counted, `MoveBytes` remains
  zero for ordinary bindings/calls/cleanup, and unique-live metrics remain
  unavailable.
- The native O0/O2 storage suite passed 43 cases and 507 assertions, and
  trap-mode UBSan passed. The non-trap UBSan executable could not link with the
  installed Windows sanitizer runtime (16 unresolved runtime symbols); this
  limitation is recorded separately in the verifier evidence and does not
  affect the trap-mode result.

The runner's actual build, native O0/O2, and UBSan outputs are preserved under
`verification-9fa2306d2e504642a5bcaf64c13d27e8`. No source files outside the
emitter ownership scope were changed here.

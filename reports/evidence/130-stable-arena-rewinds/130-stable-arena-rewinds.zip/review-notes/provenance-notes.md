# Arena provenance analysis

`AgentLang.Llvm.ArenaLifetime.analyzeBody` accepts only a compiler-verified
`VerifiedIrBody`. `analyzeProgram` accepts a `VerifiedIrProgram` and returns one
analysis per `WordId`. Each analysis exposes a decision and deterministic reason
for every verified `Scope` source site, plus a frame-exit decision. The emitter
can look up a scope by `instruction.Site` and use `FunctionExit` at body or
function return.

The analysis starts body and function inputs with empty origins because they
pre-date the relevant frame mark. New constants and supported constructors are
attributed to the current frame/scope path. A projected record field preserves
its parent origin. Local stores and loads preserve the origin set; an inner
scope restores the entry local map when it exits, including when it shadows a
slot. `If` joins corresponding stack and local origins from both arms.

There are no interprocedural summaries yet. A call result conservatively joins
all input origins with the active frame and scope ancestry. The explicit
`dup`, `drop`, and `swap` primitives have verified effect-free transfer rules.
Effectful calls add their input and active regions to a sticky retained set, so
dropping their returned values cannot make an affected boundary rewindable.

Operations outside the currently modeled owning subset also add visible roots
and the active allocation ancestry to the retained set. Their output origins
include those possibilities. This intentionally prefers a missed rewind when
an operation has uncertain behavior. The native emitter currently supports
record construction and record field access, but not container, scalar-wrapper,
or enum operations; those operations therefore take this conservative path.
Record construction with a validator is also conservative because the owning
emitter does not support that path.

The model tracks scope ownership regions, not byte intervals or individual
runtime object identities. It emits no runtime scan, reference count, or liveness
decision. The emitter still needs to preserve the whole suffix beneath an
escaping descriptor and may rewind only when the static decision allows it.

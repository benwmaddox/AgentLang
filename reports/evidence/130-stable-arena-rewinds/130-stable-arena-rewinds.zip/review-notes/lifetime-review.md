# Arena lifetime read-only review

Found one safety issue in manually verified detached bodies: `IrVerifier.verifyBody` compares instruction sites with `BodySourceMap` as a set but does not reject duplicate instruction sites. `ArenaLifetime.analyze` reduces scope decisions into a map using last-write-wins. A later dead-only scope with the same site can overwrite an earlier escaping scope's `AllowRewind = false` with `true`. The dynamic emitter then rewinds the earlier scope while its output descriptor is live.

Concrete shape: first scope returns String `A`; push String `B`, concatenate, and drop the result; second scope creates and drops String `dead`. Give both scopes the first scope's site in a detached body, remove the second scope's original source-map key, and recompute coverage. Before the fix, `IrVerifier.verifyBody` accepts that shape against a compiler-backed program. `B` can overwrite `A` after the erroneous first rewind. Compiler lowering assigns distinct sites, so this is an accepted manual-IR path, not an ordinary source compilation path.

Recommended defense: reject duplicate instruction sites in detached body verification, matching program verification. Independently fail closed when merging repeated scope decisions. Both changes were sent to the implementation team.

Other audited paths did not reveal a separate unsafe `AllowRewind = true`: branch origin union is conservative; scope local restoration matches verifier scope exit shape; same-slot child shadow does not survive its scope; record construction copies into a new owner and field projection preserves the owner origin; uncertain/effectful calls and unsupported match/container operations retain uncertainty. Those paths can miss rewinds, which is a performance cost rather than a safety failure.

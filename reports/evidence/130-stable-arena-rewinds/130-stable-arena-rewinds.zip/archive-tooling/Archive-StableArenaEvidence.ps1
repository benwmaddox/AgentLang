param(
    [string]$FocusedRunId = "5086ac61b2744764aeb870b8134a9380"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\.."))
$evidenceRoot = Join-Path $repoRoot "reports\evidence\130-stable-arena-rewinds"
$focusedRoot = Join-Path $repoRoot ".agentlang\owning-stack-003\verification-$FocusedRunId"
$fullGateRoot = Join-Path $repoRoot ".agentlang\owning-stack-003\full-validation"
$verificationPath = Join-Path $focusedRoot "verification-evidence.json"
$nativeEvidencePath = Join-Path $focusedRoot "native-value-stack-evidence.json"
$fullGatePath = Join-Path $fullGateRoot "validation.json"
$indexName = "storage-index.json"
$archiveName = "130-stable-arena-rewinds.zip"
$stageRoot = Join-Path $evidenceRoot ".stage-final"
$zipPath = Join-Path $evidenceRoot $archiveName

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-ContainedPath([string]$Root, [string]$Candidate) {
    $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\', '/'))
    $candidateFull = [System.IO.Path]::GetFullPath($Candidate)
    $prefix = $rootFull + [System.IO.Path]::DirectorySeparatorChar
    if (-not $candidateFull.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path escapes its approved root: $candidateFull"
    }
    return $candidateFull
}

function Get-RepoRelative([string]$FullPath) {
    $full = [System.IO.Path]::GetFullPath($FullPath)
    $relative = [System.IO.Path]::GetRelativePath($repoRoot, $full)
    if ([System.IO.Path]::IsPathRooted($relative) -or $relative -eq ".." -or $relative.StartsWith("..\", [System.StringComparison]::Ordinal) -or $relative.StartsWith("../", [System.StringComparison]::Ordinal)) {
        throw "Verifier source is outside the repository: $full"
    }
    return $relative.Replace('\', '/')
}

function Get-StageRelative([string]$FullPath) {
    $relative = [System.IO.Path]::GetRelativePath($stageRoot, [System.IO.Path]::GetFullPath($FullPath))
    return $relative.Replace('\', '/')
}

function Get-TreeSha256([string]$Root, [string[]]$RelativeFiles) {
    $hash = [System.Security.Cryptography.IncrementalHash]::CreateHash([System.Security.Cryptography.HashAlgorithmName]::SHA256)
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $sorted = @($RelativeFiles)
    [System.Array]::Sort($sorted, [System.StringComparer]::Ordinal)
    $delimiter = [byte[]]@(0)
    try {
        foreach ($relative in $sorted) {
            $portable = $relative.Replace('\', '/')
            $hash.AppendData($utf8.GetBytes($portable))
            $hash.AppendData($delimiter)
            $filePath = Join-Path $Root ($portable.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
            $buffer = [byte[]]::new(65536)
            $stream = [System.IO.File]::OpenRead($filePath)
            try {
                while (($read = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    if ($read -eq $buffer.Length) {
                        $hash.AppendData($buffer)
                    } else {
                        $chunk = [byte[]]::new($read)
                        [System.Array]::Copy($buffer, $chunk, $read)
                        $hash.AppendData($chunk)
                    }
                }
            } finally {
                $stream.Dispose()
            }
            $hash.AppendData($delimiter)
        }
        return [System.Convert]::ToHexString($hash.GetHashAndReset()).ToLowerInvariant()
    } finally {
        $hash.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $verificationPath -PathType Leaf)) {
    throw "Focused verification evidence is missing: $verificationPath"
}
if (-not (Test-Path -LiteralPath $nativeEvidencePath -PathType Leaf)) {
    throw "Native experiment evidence is missing: $nativeEvidencePath"
}
if (-not (Test-Path -LiteralPath $fullGatePath -PathType Leaf)) {
    throw "Full-gate terminal evidence is missing: $fullGatePath"
}

$verification = Get-Content -LiteralPath $verificationPath -Raw | ConvertFrom-Json
$nativeEvidence = Get-Content -LiteralPath $nativeEvidencePath -Raw | ConvertFrom-Json
$fullGate = Get-Content -LiteralPath $fullGatePath -Raw | ConvertFrom-Json
$formattingEvidencePath = Join-Path $repoRoot ".agentlang\owning-stack-003\post-gate-formatting.json"
$formattingEvidence = Get-Content -LiteralPath $formattingEvidencePath -Raw | ConvertFrom-Json
if (-not $verification.passed -or -not $verification.sourceInputsStable) {
    throw "Focused run $FocusedRunId did not pass with stable source inputs."
}
if ($verification.checks.Count -ne 35 -or @($verification.checks | Where-Object { -not $_.passed }).Count -ne 0) {
    throw "Focused verifier did not pass all 35 orchestration checks."
}
if (-not $nativeEvidence.passed -or $nativeEvidence.failureCount -ne 0) {
    throw "Focused native experiment did not pass: $nativeEvidencePath"
}
$booleanAssertions = @($nativeEvidence.checks | Where-Object { $_.PSObject.Properties.Name -contains "passed" })
$failedAssertions = @($booleanAssertions | Where-Object { $_.passed -eq $false })
if ($failedAssertions.Count -ne 0) {
    throw "Focused native experiment contains $($failedAssertions.Count) failed assertions."
}
if (-not $fullGate.passed -or $fullGate.checks.Count -ne 37 -or @($fullGate.checks | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) {
    throw "The full repository gate did not pass all 37 checks."
}
if (-not (Test-Path -LiteralPath (Join-Path $fullGateRoot "validation.log") -PathType Leaf)) {
    throw "The full-gate validation log is missing."
}
if ($formattingEvidence.kind -ne "post-full-gate-formatting" -or -not $formattingEvidence.identicalExceptTrailingLineEndings -or $formattingEvidence.fullGate -ne "full-validation/validation.json") {
    throw "Post-gate formatting evidence does not describe the expected trailing-line-ending-only change."
}
$formattingSource = Join-Path $repoRoot ([string]$formattingEvidence.path)
if ((Get-Sha256 $formattingSource) -ne ([string]$formattingEvidence.afterSha256).ToLowerInvariant()) {
    throw "The current formatting source does not match its recorded post-gate SHA-256."
}
$focusedFormattingSource = @($verification.sourceInputHashesBefore | Where-Object {
    (Get-RepoRelative ([string]$_.path)) -eq ([string]$formattingEvidence.path).Replace('\', '/')
})
if ($focusedFormattingSource.Count -ne 1 -or ([string]$focusedFormattingSource[0].sha256).ToLowerInvariant() -ne ([string]$formattingEvidence.afterSha256).ToLowerInvariant()) {
    throw "Final focused verifier source inputs do not bind the documented post-gate formatting source."
}

$archiveRootFull = [System.IO.Path]::GetFullPath($evidenceRoot)
New-Item -ItemType Directory -Path $archiveRootFull -Force | Out-Null
$stageRootFull = Assert-ContainedPath $archiveRootFull $stageRoot
$zipPathFull = Assert-ContainedPath $archiveRootFull $zipPath
if (Test-Path -LiteralPath $stageRootFull) {
    Remove-Item -LiteralPath $stageRootFull -Recurse -Force
}
New-Item -ItemType Directory -Path $stageRootFull -Force | Out-Null

$script:archiveFiles = [System.Collections.Generic.List[object]]::new()
function Add-ArchiveFile(
    [string]$SourceRelative,
    [string]$ArchiveRelative,
    [string]$Category,
    [string]$ExpectedSha256 = ""
) {
    $sourcePath = Join-Path $repoRoot ($SourceRelative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "Required evidence file is missing: $SourceRelative"
    }
    $extension = [System.IO.Path]::GetExtension($ArchiveRelative).ToLowerInvariant()
    if ($extension -in @(".exe", ".dll", ".pdb", ".obj", ".lib", ".so", ".a", ".o")) {
        throw "Binary/build output is not permitted in the archive: $ArchiveRelative"
    }
    $segments = $ArchiveRelative.Replace('\', '/').Split('/')
    if ($segments -contains "bin" -or $segments -contains "obj" -or $segments -contains "dotnet-artifacts" -or $segments -contains "native-output") {
        throw "Build tree is not permitted in the archive: $ArchiveRelative"
    }
    $actualHash = Get-Sha256 $sourcePath
    if ($ExpectedSha256 -and $actualHash -ne $ExpectedSha256.ToLowerInvariant()) {
        throw "Source hash does not match its recorded evidence: $SourceRelative"
    }
    $destination = Join-Path $stageRoot ($ArchiveRelative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    $destinationParent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
    Copy-Item -LiteralPath $sourcePath -Destination $destination -Force
    $copiedHash = Get-Sha256 $destination
    if ($copiedHash -ne $actualHash) {
        throw "Copied file hash mismatch for $ArchiveRelative"
    }
    $script:archiveFiles.Add([ordered]@{
        source = $SourceRelative.Replace('\', '/')
        archive = $ArchiveRelative.Replace('\', '/')
        category = $Category
        sha256 = $copiedHash
    })
}

function Add-GzipArchiveFile(
    [string]$SourceRelative,
    [string]$ArchiveRelative,
    [string]$Category
) {
    $sourcePath = Join-Path $repoRoot ($SourceRelative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "Required evidence file is missing: $SourceRelative"
    }
    if (-not $ArchiveRelative.EndsWith(".gz", [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Compressed evidence path must end in .gz: $ArchiveRelative"
    }
    $sourceHash = Get-Sha256 $sourcePath
    $destination = Join-Path $stageRoot ($ArchiveRelative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    $destinationParent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null
    $inputStream = [System.IO.File]::OpenRead($sourcePath)
    $outputStream = [System.IO.File]::Create($destination)
    try {
        $gzipStream = [System.IO.Compression.GZipStream]::new($outputStream, [System.IO.Compression.CompressionLevel]::Optimal, $false)
        try { $inputStream.CopyTo($gzipStream) } finally { $gzipStream.Dispose() }
    } finally {
        $inputStream.Dispose()
        $outputStream.Dispose()
    }
    $compressedHash = Get-Sha256 $destination
    $script:archiveFiles.Add([ordered]@{
        source = $SourceRelative.Replace('\', '/')
        archive = $ArchiveRelative.Replace('\', '/')
        category = $Category
        sha256 = $compressedHash
        sourceSha256 = $sourceHash
        compression = "gzip"
    })
}

# Snapshot every source input named by the final focused verifier. This keeps
# the evidence tied to the exact source set used by the tested build.
foreach ($sourceRecord in $verification.sourceInputHashesBefore) {
    $relative = Get-RepoRelative ([string]$sourceRecord.path)
    Add-ArchiveFile $relative "source-snapshots/$relative" "focused-verifier-source" ([string]$sourceRecord.sha256)
}

# The detached-IR verifier regression has its own source hash because that test
# project is outside the focused native verifier's source-input set.
$irValidation = Get-Content -LiteralPath (Join-Path $repoRoot ".agentlang\owning-stack-003\ir-validation.json") -Raw | ConvertFrom-Json
if ($irValidation.status -ne "pass" -or $irValidation.assertions -ne 193) {
    throw "The detached-IR validation evidence is not the expected 193-assertion pass."
}
foreach ($sourceRecord in $irValidation.sourceFiles) {
    $relative = [string]$sourceRecord.path
    $alreadySnapshotted = @($verification.sourceInputHashesBefore | Where-Object { (Get-RepoRelative ([string]$_.path)) -eq $relative }).Count -gt 0
    if (-not $alreadySnapshotted) {
        Add-ArchiveFile $relative "source-snapshots/$relative" "ir-validation-source" ([string]$sourceRecord.sha256)
    }
}

$runRelative = ".agentlang/owning-stack-003/verification-$FocusedRunId"
$focusedFiles = @(
    @{ Name = "verification-evidence.json"; Category = "focused-verifier" },
    @{ Name = "native-value-stack-evidence.json"; Category = "native-experiment" },
    @{ Name = "fresh-dotnet-build.stdout.txt"; Category = "build-log" },
    @{ Name = "fresh-dotnet-build.stderr.txt"; Category = "build-log" },
    @{ Name = "fresh-arena-lifetime-tests-build.stdout.txt"; Category = "lifetime-build-log" },
    @{ Name = "fresh-arena-lifetime-tests-build.stderr.txt"; Category = "lifetime-build-log" },
    @{ Name = "compiler-proved-arena-lifetime-tests.stdout.txt"; Category = "lifetime-test-log" },
    @{ Name = "compiler-proved-arena-lifetime-tests.stderr.txt"; Category = "lifetime-test-log" },
    @{ Name = "fresh-owning-stack-c-build-O0.stdout.txt"; Category = "c-build-log" },
    @{ Name = "fresh-owning-stack-c-build-O0.stderr.txt"; Category = "c-build-log" },
    @{ Name = "fresh-owning-stack-c-build-O2.stdout.txt"; Category = "c-build-log" },
    @{ Name = "fresh-owning-stack-c-build-O2.stderr.txt"; Category = "c-build-log" },
    @{ Name = "owning-stack-native-storage-tests-O0.stdout.txt"; Category = "c-test-log" },
    @{ Name = "owning-stack-native-storage-tests-O0.stderr.txt"; Category = "c-test-log" },
    @{ Name = "owning-stack-native-storage-tests-O2.stdout.txt"; Category = "c-test-log" },
    @{ Name = "owning-stack-native-storage-tests-O2.stderr.txt"; Category = "c-test-log" },
    @{ Name = "owning-stack-ubsan-normal-build.stdout.txt"; Category = "ubsan-link-log" },
    @{ Name = "owning-stack-ubsan-normal-build.stderr.txt"; Category = "ubsan-link-log" },
    @{ Name = "owning-stack-ubsan-trap-build.stdout.txt"; Category = "ubsan-trap-log" },
    @{ Name = "owning-stack-ubsan-trap-build.stderr.txt"; Category = "ubsan-trap-log" },
    @{ Name = "owning-stack-ubsan-trap-run.stdout.txt"; Category = "ubsan-trap-log" },
    @{ Name = "owning-stack-ubsan-trap-run.stderr.txt"; Category = "ubsan-trap-log" },
    @{ Name = "same-ir-cross-backend-experiment.stdout.txt"; Category = "experiment-log" },
    @{ Name = "same-ir-cross-backend-experiment.stderr.txt"; Category = "experiment-log" }
)
foreach ($item in $focusedFiles) {
    Add-ArchiveFile "$runRelative/$($item.Name)" "focused/$($item.Category)/$($item.Name)" $item.Category
}

# Capture the terminal repository gate, with every sidecar verification JSON
# compressed independently. The main JSON and run log retain their readable
# forms and include the exact commands, exits, and captured output.
Add-ArchiveFile ".agentlang/owning-stack-003/full-validation/validation.json" "full-gate/validation.json" "full-gate"
Add-ArchiveFile ".agentlang/owning-stack-003/full-validation/validation.log" "full-gate/validation.log" "full-gate-log"
$fullGateSidecars = @(
    "validation.business-policy-preflight.json",
    "validation.early-agent-negative.json",
    "validation.flow-matched-fixtures.json",
    "validation.matched-fixtures.json",
    "validation.matched-snapshots.json",
    "validation.parser-limits.json",
    "validation.projection.json",
    "validation.renewal-acceptance-gate.json",
    "validation.renewal-replay.json",
    "validation.subagent-host-v2.json",
    "validation.subagent-host.json"
)
foreach ($name in $fullGateSidecars) {
    Add-GzipArchiveFile ".agentlang/owning-stack-003/full-validation/$name" "full-gate/$name.gz" "full-gate-sidecar"
}

$supportFiles = @(
    @{ Source = ".agentlang/owning-stack-003/ir-validation.json"; Archive = "component-tests/ir-validation.json"; Category = "ir-193" },
    @{ Source = ".agentlang/owning-stack-003/storage-tests/validation.json"; Archive = "component-tests/c-storage/validation.json"; Category = "c-507" },
    @{ Source = ".agentlang/owning-stack-003/storage-tests/O0.json"; Archive = "component-tests/c-storage/O0.json"; Category = "c-507" },
    @{ Source = ".agentlang/owning-stack-003/storage-tests/O2.json"; Archive = "component-tests/c-storage/O2.json"; Category = "c-507" },
    @{ Source = ".agentlang/owning-stack-003/storage-tests/ubsan-trap.json"; Archive = "component-tests/c-storage/ubsan-trap.json"; Category = "c-507" },
    @{ Source = ".agentlang/owning-stack-003/copy-negative-control/evidence.json"; Archive = "negative-control/source-preservation/evidence.json"; Category = "negative-control" },
    @{ Source = ".agentlang/owning-stack-003/copy-negative-control/result.txt"; Archive = "negative-control/source-preservation/result.txt"; Category = "negative-control" },
    @{ Source = ".agentlang/owning-stack-003/copy-negative-control/move-instead-of-copy.c"; Archive = "negative-control/source-preservation/move-instead-of-copy.c"; Category = "negative-control-source" },
    @{ Source = ".agentlang/owning-stack-003/legacy-regression/validation.json"; Archive = "component-tests/legacy-llvm-476/validation.json"; Category = "legacy-llvm-476" },
    @{ Source = ".agentlang/owning-stack-003/legacy-regression/build.log"; Archive = "component-tests/legacy-llvm-476/build.log"; Category = "legacy-llvm-476" },
    @{ Source = ".agentlang/owning-stack-003/legacy-regression/tests.log"; Archive = "component-tests/legacy-llvm-476/tests.log"; Category = "legacy-llvm-476" },
    @{ Source = ".agentlang/owning-stack-003/implementation-plan.md"; Archive = "review-notes/implementation-plan.md"; Category = "plan" },
    @{ Source = ".agentlang/owning-stack-003/acceptance-plan.md"; Archive = "review-notes/acceptance-plan.md"; Category = "plan" },
    @{ Source = ".agentlang/owning-stack-003/emitter-review.md"; Archive = "review-notes/emitter-review.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/lifetime-review.md"; Archive = "review-notes/lifetime-review.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/provenance-notes.md"; Archive = "review-notes/provenance-notes.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/acceptance-review.md"; Archive = "review-notes/acceptance-review.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/acceptance-followup-review.md"; Archive = "review-notes/acceptance-followup-review.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/emitter-notes.md"; Archive = "review-notes/emitter-notes.md"; Category = "review" },
    @{ Source = ".agentlang/owning-stack-003/post-gate-formatting.json"; Archive = "review-notes/post-gate-formatting.json"; Category = "post-gate-formatting" },
    @{ Source = ".agentlang/owning-stack-003/Archive-StableArenaEvidence.ps1"; Archive = "archive-tooling/Archive-StableArenaEvidence.ps1"; Category = "archive-tooling" }
)
foreach ($item in $supportFiles) {
    Add-ArchiveFile $item.Source $item.Archive $item.Category
}

$readmePath = Join-Path $stageRoot "README.md"
$readme = @"
# Milestone 130 stable arena evidence

This archive contains focused run $FocusedRunId and the terminal full repository gate. The focused verifier passed $($verification.checks.Count)/$($verification.checks.Count) checks; its native experiment passed $($booleanAssertions.Count) boolean assertions with no failures. The full gate passed $($fullGate.checks.Count)/$($fullGate.checks.Count) checks from $($fullGate.startedAt) through $($fullGate.completedAt). It also contains compiler-proven lifetime tests, IR 193-assertion evidence, C storage 43-case/507-check evidence, the legacy LLVM 476-assertion run, the source-preservation negative control, review notes, and focused verifier source snapshots tied to recorded SHA-256 values.

The full-gate validation JSON and log are included verbatim. Every full-gate sidecar verification JSON is stored as a `.json.gz` entry; its raw source SHA-256 and archived gzip SHA-256 are both recorded in the manifest. `review-notes/post-gate-formatting.json` records the single trailing-line-ending cleanup made after the full gate and before the final focused run. The full-gate JSON therefore records the source immediately before that whitespace-only cleanup; the focused source snapshots bind the final focused run. The normal UBSan link limitation is included alongside the successful UBSan trap-mode run.

manifest.json lists every archived payload file and its SHA-256. For gzip sidecars, sourceSha256 records the original raw JSON hash. The uncompressedPayloadSha256 field hashes the sorted payload as UTF-8 relative path, NUL, file bytes, NUL for each file; the internal manifest is excluded from that digest to avoid a self-reference. storage-index.json records the compressed ZIP digest, and the .sha256 sidecars can be checked with Get-FileHash.
"@
[System.IO.File]::WriteAllText($readmePath, $readme, [System.Text.UTF8Encoding]::new($false))
$script:archiveFiles.Add([ordered]@{
    source = "generated:README.md"
    archive = "README.md"
    category = "archive-readme"
    sha256 = Get-Sha256 $readmePath
})

$payloadPaths = @($script:archiveFiles | ForEach-Object { [string]$_.archive })
$payloadHash = Get-TreeSha256 $stageRoot $payloadPaths
$sourceSnapshotFiles = @($script:archiveFiles | Where-Object { $_.category -in @("focused-verifier-source", "ir-validation-source") } | ForEach-Object {
    [ordered]@{ source = $_.source; archive = $_.archive; sha256 = $_.sha256; provenance = $_.category }
})
$manifest = [ordered]@{
    formatVersion = 1
    phase = "final"
    scope = "Milestone 130 focused, component, and terminal full-repository-gate evidence."
    focusedRunId = $FocusedRunId
    focusedVerifier = [ordered]@{
        passed = [bool]$verification.passed
        checksPassed = @($verification.checks | Where-Object { $_.passed }).Count
        checksTotal = $verification.checks.Count
        sourceInputsStable = [bool]$verification.sourceInputsStable
        nativeExperimentPassed = [bool]$nativeEvidence.passed
        nativeBooleanAssertionsPassed = $booleanAssertions.Count
        nativeAssertionFailures = $failedAssertions.Count
    }
    componentCounts = [ordered]@{
        arenaLifetimeAssertions = [int]$verification.arenaLifetimeAssertions
        irAssertions = [int]$irValidation.assertions
        cStorageCases = 43
        cStorageChecks = 507
        legacyLlvmAssertions = 476
        negativeControl = "Expected failure: source-preservation assertion detects move-instead-of-copy mutant."
    }
    fullGate = [ordered]@{
        passed = [bool]$fullGate.passed
        checksPassed = @($fullGate.checks | Where-Object { $_.exitCode -eq 0 }).Count
        checksTotal = $fullGate.checks.Count
        startedAt = [string]$fullGate.startedAt
        completedAt = [string]$fullGate.completedAt
        validationJson = "full-gate/validation.json"
        validationLog = "full-gate/validation.log"
        sidecarJsonCount = $fullGateSidecars.Count
        sourceRelation = "The full gate preceded a formatting-only trailing-line-ending cleanup documented in review-notes/post-gate-formatting.json; the focused source snapshots bind the final focused run."
    }
    uncompressedPayloadSha256 = $payloadHash
    uncompressedPayloadHashAlgorithm = "SHA-256 of sorted UTF-8 relative path, NUL, raw file bytes, NUL; manifest excluded."
    files = @($script:archiveFiles | Sort-Object { $_.archive })
    sourceSnapshots = $sourceSnapshotFiles
}
$manifestJson = $manifest | ConvertTo-Json -Depth 12
$internalManifestPath = Join-Path $stageRoot "manifest.json"
[System.IO.File]::WriteAllText($internalManifestPath, $manifestJson, [System.Text.UTF8Encoding]::new($false))

$zipOutput = [System.IO.File]::Open($zipPathFull, [System.IO.FileMode]::Create, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    $archive = [System.IO.Compression.ZipArchive]::new($zipOutput, [System.IO.Compression.ZipArchiveMode]::Create, $false)
    try {
        $allFiles = @(Get-ChildItem -LiteralPath $stageRoot -File -Recurse | ForEach-Object { [pscustomobject]@{ FullName = $_.FullName; Relative = (Get-StageRelative $_.FullName) } })
        $allFiles = @($allFiles | Sort-Object -Property Relative)
        foreach ($file in $allFiles) {
            $entry = $archive.CreateEntry($file.Relative, [System.IO.Compression.CompressionLevel]::Optimal)
            $entry.LastWriteTime = [System.DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [System.TimeSpan]::Zero)
            $entryStream = $entry.Open()
            $inputStream = [System.IO.File]::OpenRead($file.FullName)
            try { $inputStream.CopyTo($entryStream) } finally { $inputStream.Dispose(); $entryStream.Dispose() }
        }
    } finally {
        $archive.Dispose()
    }
} finally {
    $zipOutput.Dispose()
}

$zipHash = Get-Sha256 $zipPathFull
$externalIndex = [ordered]@{}
foreach ($key in $manifest.Keys) { $externalIndex[$key] = $manifest[$key] }
$externalIndex.archive = $archiveName
$externalIndex.archiveSha256 = $zipHash
$externalIndex.manifestSha256 = Get-Sha256 $internalManifestPath
$indexPath = Join-Path $evidenceRoot $indexName
$indexPathFull = Assert-ContainedPath $archiveRootFull $indexPath
$indexJson = $externalIndex | ConvertTo-Json -Depth 12
[System.IO.File]::WriteAllText($indexPathFull, $indexJson, [System.Text.UTF8Encoding]::new($false))
$indexHash = Get-Sha256 $indexPathFull
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot "$archiveName.sha256"), "$zipHash  $archiveName`n", [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot "$indexName.sha256"), "$indexHash  $indexName`n", [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot "uncompressed-payload.sha256"), "$payloadHash  $archiveName (payload digest; see index algorithm)`n", [System.Text.UTF8Encoding]::new($false))

# Validate the ZIP contents independently of the staging files, then recheck
# every source snapshot against the focused verifier's original source hash.
Add-Type -AssemblyName System.IO.Compression
$zipRead = [System.IO.File]::OpenRead($zipPathFull)
try {
    $readArchive = [System.IO.Compression.ZipArchive]::new($zipRead, [System.IO.Compression.ZipArchiveMode]::Read, $false)
    try {
        $innerManifestEntry = $readArchive.GetEntry("manifest.json")
        if ($null -eq $innerManifestEntry) { throw "Archive is missing manifest.json." }
        $innerManifestStream = $innerManifestEntry.Open()
        $innerReader = [System.IO.StreamReader]::new($innerManifestStream, [System.Text.Encoding]::UTF8)
        try { $innerManifest = $innerReader.ReadToEnd() | ConvertFrom-Json } finally { $innerReader.Dispose(); $innerManifestStream.Dispose() }
        if ($innerManifest.uncompressedPayloadSha256 -ne $payloadHash) { throw "Internal manifest payload digest mismatch." }
        if ($readArchive.Entries.Count -ne ($script:archiveFiles.Count + 1)) { throw "Archive entry count differs from the manifest file list." }
        foreach ($record in $script:archiveFiles) {
            $entry = $readArchive.GetEntry([string]$record.archive)
            if ($null -eq $entry) { throw "Archive entry is missing: $($record.archive)" }
            $stream = $entry.Open()
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $entryHash = [System.Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant() } finally { $sha.Dispose(); $stream.Dispose() }
            if ($entryHash -ne $record.sha256) { throw "Archive entry hash mismatch: $($record.archive)" }
            if ($record.Contains("compression") -and $record["compression"] -eq "gzip") {
                $compressedEntryStream = $entry.Open()
                try {
                    $decompressor = [System.IO.Compression.GZipStream]::new($compressedEntryStream, [System.IO.Compression.CompressionMode]::Decompress, $false)
                    $rawSha = [System.Security.Cryptography.SHA256]::Create()
                    try { $rawEntryHash = [System.Convert]::ToHexString($rawSha.ComputeHash($decompressor)).ToLowerInvariant() } finally { $rawSha.Dispose(); $decompressor.Dispose() }
                } finally { $compressedEntryStream.Dispose() }
                if ($rawEntryHash -ne $record.sourceSha256) { throw "Decompressed raw evidence hash mismatch: $($record.archive)" }
            }
        }
    } finally {
        $readArchive.Dispose()
    }
} finally {
    $zipRead.Dispose()
}
if ((Get-Sha256 $zipPathFull) -ne $zipHash) { throw "Archive SHA-256 changed during validation." }
foreach ($sourceRecord in $verification.sourceInputHashesBefore) {
    if ((Get-Sha256 ([string]$sourceRecord.path)) -ne ([string]$sourceRecord.sha256).ToLowerInvariant()) {
        throw "A verifier source changed while archiving: $($sourceRecord.path)"
    }
}

Remove-Item -LiteralPath $stageRootFull -Recurse -Force

# Replace only the earlier partial artifacts created in this milestone's owned
# evidence directory. The final archive, its index, and its hashes remain.
foreach ($partialName in @(
    "130-stable-arena-rewinds-partial.zip",
    "130-stable-arena-rewinds-partial.zip.sha256",
    "storage-index.partial.json",
    "storage-index.partial.json.sha256",
    "uncompressed-payload.partial.sha256"
)) {
    $partialPath = Assert-ContainedPath $archiveRootFull (Join-Path $archiveRootFull $partialName)
    if (Test-Path -LiteralPath $partialPath -PathType Leaf) {
        Remove-Item -LiteralPath $partialPath -Force
    }
}

[pscustomobject]@{
    archive = $zipPathFull
    archiveSha256 = $zipHash
    index = $indexPathFull
    indexSha256 = $indexHash
    uncompressedPayloadSha256 = $payloadHash
    archivedFiles = $script:archiveFiles.Count
    verifierChecks = $verification.checks.Count
    nativeBooleanAssertions = $booleanAssertions.Count
    fullGateIncluded = $true
    fullGateChecks = $fullGate.checks.Count
} | ConvertTo-Json -Depth 3

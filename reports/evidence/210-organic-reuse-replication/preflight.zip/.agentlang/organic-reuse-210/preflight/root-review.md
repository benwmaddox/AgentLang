# Root replication review

Reviewed before participant dispatch. Creator/successor packets, frozen cases and seed inventory are byte-identical to trial 200. Scorer differences are study/output-root identity, observation type/function identity and imported-module identity only. Control-runner differences are study identity and neutral current-runtime pin status/message. Unit-check changes are observation identity and current pending-review status. Model expectations and production-helper eligibility are unchanged. Source behavior rules and acceptance thresholds have not been relaxed.

Fresh current CLI build passes with zero warnings/errors. V2 verifier passes all 37 focused checks. Unit checks pass and confirm 66 creator cases, nine successor cases, preservation checks, trace discovery classification and production-only eligibility. Six executable controls are recorded separately; accept their final receipt before dispatch. The first preflight setup attempt was started before the validator update completed, stopped before runtime execution, and remains in setup-attempt1.json.

A fresh participant must receive no preceding result, hidden cases, scorer, creator trace, other participant findings or factoring hint. External tool isolation is prompt-governed; the broker is not an OS sandbox. Virtual I/O and empty external capabilities remain mandatory.

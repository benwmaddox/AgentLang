# Follow-up design note

Trial 210's stop rule is correct for its declared endpoint: spontaneous creation
of an optional shared helper and a later agent's reuse of that helper. It is
narrower than the broader vocabulary-accumulation question. The creator's two
required renewal functions are still new, agent-authored public vocabulary;
their names and signatures are prescribed, so their downstream reuse would be
evidence about task-required vocabulary reuse, not spontaneous abstraction.

Keep 210 frozen. For a minimal follow-up under a separate identity, pin the
accepted 200 creator project as a fixed starting snapshot and dispatch one
fresh successor on the already specified held-out `subscription.renew-batch`
task. Predeclare `subscription.renew-monthly` and
`subscription.renew-annual` as the reuse targets for this study; keep behavior,
library qualification, preservation, trace discovery, and production call
paths separate. Leave any optional helper endpoint independently reported. Use
the existing broker, scorer adapter, and termination audit. This would test
whether later work benefits from creator-authored, task-required vocabulary;
it would not answer whether creators spontaneously factor helpers or show a
comparative reliability benefit.

If the next question is instead how often an unprompted creator creates an
optional shared abstraction, another exact creator replication is the direct
follow-up. These two designs answer different questions.

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/organic-reuse-210'
out = repo / 'reports/evidence/210-organic-reuse-replication'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'preflight.zip'
index = out / 'preflight.index.json'
if archive.exists() or index.exists():
    raise RuntimeError('Refuse to overwrite sealed evidence')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source_pin = json.loads((study / 'source-pin.json').read_text(encoding='utf-8-sig'))
runtime_pin = json.loads((study / 'accepted-runtime-pin.json').read_text(encoding='utf-8-sig'))
for row in source_pin['files']:
    assert sha(repo / row['path']) == row['sha256'], row['path']
for row in runtime_pin['runtimeFiles']:
    assert sha(study / 'runtime' / row['name']) == row['sha256'], row['name']
summary_path = study / 'preflight/controls/attempts/20261011T091116Z-01/control-preflight-summary.json'
summary = json.loads(summary_path.read_text())
assert summary['status'] == 'preflight-passed' and len(summary['variants']) == 6
assert all(r['status'] == 'preflight-passed' and not r['behavior']['setupErrors'] for r in summary['variants'])
host = json.loads((study / 'preflight/host-verification.json').read_text(encoding='utf-8-sig'))
assert host['outcome'] == 'passed'
paths = set()
for directory in [study / 'preflight', study / 'actors/creator', repo / 'experiments/AgentLang.SubagentTrials/organic-reuse-210']:
    paths.update(p for p in directory.rglob('*') if p.is_file())
paths.update(repo / row['path'] for row in source_pin['files'])
paths.update([study / 'source-pin.json', study / 'accepted-runtime-pin.json', study / 'dispatch/start-creator.ps1', Path(__file__)])
paths.update(repo / p for p in [
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/score_agentlang.py'])
def collect_trace_paths(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'tracePath' and isinstance(item, str):
                path = Path(item).resolve()
                assert repo in path.parents
                paths.add(path)
            collect_trace_paths(item)
    elif isinstance(value, list):
        for item in value:
            collect_trace_paths(item)
collect_trace_paths(host)
pins = []
for path in sorted(paths):
    assert repo in path.resolve().parents and path.is_file(), str(path)
    assert path.suffix.lower() not in {'.dll', '.exe', '.pdb', '.zip'}, str(path)
    pins.append({'path': path.relative_to(repo).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
frozen = study / 'frozen-inputs.json'
frozen.write_text(json.dumps({'status': 'accepted pre-dispatch inputs; no participant run', 'files': pins, 'externalCapabilities': [], 'controls': 'all six passed calibration', 'participantModel': 'gpt-6-luna', 'reasoning': 'max', 'maxExchanges': 100}, indent=2) + '\n')
paths.add(frozen)
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(paths):
        data = path.read_bytes()
        name = path.relative_to(repo).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {'status': 'pre-dispatch evidence; no participant result', 'archiveSha256': sha(archive), 'memberCount': len(members), 'verification': 'Reopened every member and verified length and SHA256', 'members': members}
index.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))

import pathlib, struct
def ser(b):
    raw = struct.pack('<I', len(b)) + b'\0'*4 + b
    raw += b'\0' * (-len(raw) % 8)
    return raw.hex()
init = bytes.fromhex("41f09f9982"); begin = bytes.fromhex("ceb4"); resume = bytes.fromhex("00f09f9a80")
p = pathlib.Path(r"D:\code\AgentLang\tests\fixtures\native-conformance\owning-mailbox.json")
t = p.read_text(encoding="utf-8")
def rep(o, n, c=1):
    global t
    assert t.count(o) == c, (o, t.count(o))
    t = t.replace(o, n)
rep('"encoding": "UTF-16LE",', '"encoding": "UTF-8",')
rep('"payloadBytesFormula": "8 + 2*UTF16CodeUnits",', '"payloadBytesFormula": "8 + UTF8Bytes",')
rep('"030000000000000041003dd842de0000"', '"%s"' % ser(init), 2)
rep('"0100000000000000b403000000000000"', '"%s"' % ser(begin))
rep('"070000000000000041003dd842deb40300003dd880de0000"', '"%s"' % ser(init + begin + resume))
p.write_bytes(t.encode("utf-8"))
v = pathlib.Path(r"D:\code\AgentLang\scripts\Verify-OwningMailbox.ps1")
raw = v.read_bytes(); bom = raw[:3] == b'\xef\xbb\xbf'
s = raw[3:].decode() if bom else raw.decode()
o = "    return [uint32](8 + 2 * $count)\n}"
assert s.count(o) == 1
s = s.replace(o, "    # Owning Strings are UTF-8 since report 265: the header count is bytes.\n    return [uint32](8 + $count)\n}")
v.write_bytes((b'\xef\xbb\xbf' if bom else b'') + s.encode())
print(ser(init), ser(begin), ser(init+begin+resume))

"""Re-derive native-value-stack String oracles for UTF-8 Strings (report 265).
Independent of the F# helpers: works only from the logical texts."""
import json, pathlib, struct
P = pathlib.Path(r"D:\code\AgentLang\tests\fixtures\native-conformance\native-value-stack.json")
doc = json.loads(P.read_text(encoding="utf-8"))
w = doc["stringWorkload"]
def text_of(hex16): return bytes.fromhex(hex16).decode("utf-16-le", errors="surrogatepass")
def utf8(t): return t.encode("utf-8")          # strict: raises on lone surrogates
def a8(n): return (n + 7) // 8 * 8
def s_bytes(t):
    b = utf8(t); raw = struct.pack("<I", len(b)) + b"\0" * 4 + b
    return raw + b"\0" * (a8(len(raw)) - len(raw))
def i64(v): return struct.pack("<q", v)
def hex16(t): return t.encode("utf-16-le", errors="surrogatepass").hex()

rejected = []
def do_case(c):
    t = text_of(c["inputCodeUnitsHex"])
    inp = c.get("input", {})
    count = inp.get("count", 10); tag = inp.get("tag", 70)
    units_field = inp.get("codeUnits", c["inputCodeUnitCount"])
    sb = s_bytes(t)
    c["inputUtf8ByteCount"] = len(utf8(t))
    c["inputStringExtentBytes"] = len(sb)
    c["inputTagOffsetWithinEnvelopeBytes"] = len(sb) + 8
    state = i64(count) + sb + i64(units_field) + i64(tag)
    c["inputStateBytes"] = len(state); c["inputStateBytesHex"] = state.hex()
    if "inputStringBytesHex" in c: c["inputStringBytesHex"] = sb.hex()
    out = t + "!" + t + "?"
    assert hex16(out) == c["outputCodeUnitsHex"], c["name"]
    ob = s_bytes(out); n_out = len(utf8(out))
    c["outputUtf8ByteCount"] = n_out
    c["outputStringExtentBytes"] = len(ob)
    # transform-text-envelope stores string.length(input text) in codeUnits,
    # which is the UTF-8 byte length since report 265.
    out_units = len(utf8(t))
    c["expectedOutputs"][0]["codeUnits"] = out_units
    ostate = i64(count + 1) + ob + i64(out_units) + i64(tag + 1)
    if "outputStateBytes" in c: c["outputStateBytes"] = len(ostate)
    ret = ostate + i64(n_out)
    c["retainedBytes"] = len(ret); c["retainedBytesHex"] = ret.hex()
    assert c["expectedOutputs"][1]["type"] == "Int"
    c["expectedOutputs"][1]["value"] = n_out
    return c

keep_edges = []
for c in w["nestedEdgeCases"]:
    if c["name"].startswith("isolated-"):
        rejected.append({"name": c["name"], "inputCodeUnitsHex": c["inputCodeUnitsHex"]})
    else:
        keep_edges.append(do_case(c))
w["nestedEdgeCases"] = keep_edges
w["mainCases"] = [do_case(c) for c in w["mainCases"]]
by_name = {c["name"]: c for c in w["mainCases"]}

for b in w["dynamicBranchCases"]:
    c = by_name[b["selectedMainCase"]]; t = text_of(c["inputCodeUnitsHex"])
    env = s_bytes(t) + i64(c["input"]["codeUnits"]) + i64(c["input"]["tag"])
    n = len(utf8(t))
    b["expectedSelectedEnvelopeExtentBytes"] = len(env)
    b["expectedLengthOutput"] = n
    ret = env + i64(n)
    b["expectedRetainedBytes"] = len(ret); b["expectedRetainedBytesHex"] = ret.hex()

for r in w["capacityCases"]["retainedOutput"]:
    r["requiredBytes"] = by_name[r["case"]]["retainedBytes"]; r["availableBytes"] = r["requiredBytes"] - 1

rts = []
for r in w["directValueStringRoundTrips"]:
    if r["name"].startswith("isolated-"):
        continue  # same texts as the rejected edge cases
    sb = s_bytes(text_of(r["inputCodeUnitsHex"]))
    r["inputUtf8ByteCount"] = len(utf8(text_of(r["inputCodeUnitsHex"])))
    r["stringBytesHex"] = sb.hex(); r["extentBytes"] = len(sb); rts.append(r)
w["directValueStringRoundTrips"] = rts

# The joined pair joined two lone surrogate halves; that has no UTF-8 form.
# Two 2-byte scalars keep every extent (16/16 -> 16) and 2-byte concat spans.
left, right = "\u00e9", "\u00fc"
j = w["joinedSurrogatePair"]
j["body"] = j["body"] + " Report 265: the inputs were the lone halves 3ed8/eadd (now rejected, see rejectedUnpairedSurrogateInputs); they are two 2-byte UTF-8 scalars so every extent and concat span is unchanged."
j["leftCodeUnitHex"] = hex16(left); j["rightCodeUnitHex"] = hex16(right)
j["expectedCodeUnitsHex"] = hex16(left + right); j["expectedCodeUnitCount"] = 2
jb = s_bytes(left + right); j["expectedStringBytesHex"] = jb.hex(); j["expectedExtentBytes"] = len(jb)
pc = w["capacityCases"]["programStack"]["independentDynamicConcat"]
pc["inputCodeUnitsHex"] = [hex16(left), hex16(right)]
pc["inputStringExtentsBytes"] = [len(s_bytes(left)), len(s_bytes(right))]
pc["inputStackBytes"] = sum(pc["inputStringExtentsBytes"])
pc["concatOutputCodeUnitsHex"] = hex16(left + right)
pc["concatOutputExtentBytes"] = len(jb); pc["deepCopyBytes"] = len(jb)
pc["requiredStackCapacityBytes"] = pc["inputStackBytes"] + len(jb)
pc["oneByteBelowAvailableBytes"] = pc["requiredStackCapacityBytes"] - 1

m = w["mixedDynamicRecord"]; mt = text_of(m["inputCodeUnitsHex"]); msb = s_bytes(mt)
m["inputUtf8ByteCount"] = len(utf8(mt)); m["inputStringExtentBytes"] = len(msb)
m["inputStringBytesHex"] = msb.hex(); m["sentinelOffsetBytes"] = len(msb)
m["recordPayloadBytes"] = 8 + len(utf8(mt)) + 8
rec = msb + i64(m["sentinel"]); m["recordExtentBytes"] = len(rec)
m["recordBytesHex"] = rec.hex(); m["projectedTextAndSentinelBytesHex"] = rec.hex()

w["rejectedUnpairedSurrogateInputs"] = rejected
lo = w["dynamicLayoutOracle"]
lo["payloadFormula"] = {k: v.replace("2*n", "n") for k, v in lo["payloadFormula"].items()}
lo["extentFormula"] = {k: v.replace("2*n", "n") for k, v in lo["extentFormula"].items()}
w["encoding"] = {"unit": "UTF-8 byte", "headerBytes": 8, "byteCount": "u32 little-endian", "reserved": "u32 little-endian zero",
                 "payloadBytesFormula": "8 + n", "extentBytesFormula": "align8(8 + n)", "padding": "zero through the 8-byte aligned extent",
                 "rejectsUnpairedSurrogates": True, "normalizesOrTranscodes": False,
                 "fixtureTextNotation": "texts are written as UTF-16 code-unit hex (the .NET view); n is their strict UTF-8 byte count"}
w["limits"][0] = "UTF-8 byte preservation is required (report 265); unpaired surrogates are rejected at the boundary because they have no UTF-8 form."
dc = w["dynamicCopyAndFrameCases"]
long = by_name["long-bmp-astral"]
dc["multiOutputBody"] = f"TextState -> (TextState, Int); the long nested record output grows from {long['inputStateBytes']} input bytes to {long['retainedBytes'] - 8} bytes while the second Int remains {long['outputUtf8ByteCount']}"
w["report265Utf8Transition"] = ("Owning Strings are UTF-8 since report 265. Every String oracle in this workload was re-derived by an independent script from "
    "the unchanged logical texts (byte counts, extents, offsets, serialized bytes, and the string.length Int outputs, which are now UTF-8 byte counts). "
    "The isolated-surrogate edge cases and round trips became boundary-rejection inputs; the joined pair and the dynamic-concat capacity probe use two 2-byte scalars, keeping every extent.")
src = P.read_text(encoding="utf-8")
key = '"stringWorkload": '
start = src.index(key) + len(key)
indent = src[src.rfind("\n", 0, start) + 1:src.index(key)]
depth = 0; in_str = False; esc = False
for i in range(start, len(src)):
    ch = src[i]
    if in_str:
        if esc: esc = False
        elif ch == "\\": esc = True
        elif ch == '"': in_str = False
    elif ch == '"': in_str = True
    elif ch == "{": depth += 1
    elif ch == "}":
        depth -= 1
        if depth == 0: end = i + 1; break
body = json.dumps(w, indent=2, ensure_ascii=False).replace("\n", "\n" + indent)
out = src[:start] + body + src[end:]
json.loads(out)
P.write_text(out, encoding="utf-8", newline="\n")
print(json.dumps({c["name"]: [c["inputUtf8ByteCount"], c["outputUtf8ByteCount"], c["inputStateBytes"], c["retainedBytes"]] for c in w["mainCases"] + w["nestedEdgeCases"]}))

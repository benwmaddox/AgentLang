"""Report 265: re-derive the remaining native-value-stack String images
(sum, list, stable-arena, NonEmptyString, nominal String) as UTF-8.
Works only from the logical texts named in the fixture; edits values in place
without reformatting the file."""
import json, pathlib, re, struct

P = pathlib.Path(r"D:\code\AgentLang\tests\fixtures\native-conformance\native-value-stack.json")
src = P.read_text(encoding="utf-8")
doc = json.loads(src)


def a8(n): return (n + 7) // 8 * 8
def text_of(h): return bytes.fromhex(h).decode("utf-16-le", errors="surrogatepass")
def ser16(t):
    b = t.encode("utf-16-le", errors="surrogatepass"); raw = struct.pack("<I", len(b) // 2) + b"\0" * 4 + b
    return raw + b"\0" * (a8(len(raw)) - len(raw))
def ser8(t):
    b = t.encode("utf-8"); raw = struct.pack("<I", len(b)) + b"\0" * 4 + b
    return raw + b"\0" * (a8(len(raw)) - len(raw))

SECTIONS = ["sumConformance", "listConformance", "stableArenaCases", "nonEmptyStringConformance", "nominalStringConformance", "nominalIntConformance", "positiveIdConformance"]

# Logical texts: every code-unit hex in these sections, plus literal texts the
# flow source uses (stable-arena "ab"/"stable", tails).
texts = set()
def collect(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, str) and "odeUnits" in k and "Hex" in k and v:
                texts.add(text_of(v))
            else:
                collect(v)
    elif isinstance(o, list):
        for v in o: collect(v)
for s in SECTIONS: collect(doc[s])
texts |= {"ab", "stable", "a", "z", "ok", "no", "nope", "error", "none", "tail"}
lone = {t for t in texts if any(0xD800 <= ord(c) <= 0xDFFF for c in t) and not _ok(t)} if False else set()
def well_formed(t):
    try: t.encode("utf-8"); return True
    except UnicodeEncodeError: return False
texts = {t for t in texts if well_formed(t)}
# Longest images first so a short image never splits a longer one.
images = sorted(((ser16(t), ser8(t)) for t in texts if ser16(t) != ser8(t)), key=lambda p: -len(p[0]))

def convert_blob(h):
    b = bytes.fromhex(h); out = bytearray(); i = 0
    while i < len(b):
        for old, new in images:
            if b.startswith(old, i):
                out += new; i += len(old); break
        else:
            out += b[i:i + 8]; i += 8
    return out.hex()

changes = []
def convert(o, path):
    if isinstance(o, dict):
        for k, v in list(o.items()):
            if isinstance(v, str) and k.endswith("Hex") and "odeUnits" not in k and len(v) % 16 == 0 and v:
                nv = convert_blob(v)
                if nv != v: o[k] = nv; changes.append((path + "." + k, v, nv))
            else:
                convert(v, path + "." + k)
    elif isinstance(o, list):
        for i, v in enumerate(o): convert(v, f"{path}[{i}]")

# Lone-surrogate cases have no UTF-8 form: move them to rejected lists.
sums = doc["sumConformance"]
rej = [c for c in sums["cases"] if not all(well_formed(text_of(x)) for x in re.findall(r'"codeUnitsHex": "([0-9a-f]*)"', json.dumps(c)))]
sums["cases"] = [c for c in sums["cases"] if c not in rej]
sums["rejectedUnpairedSurrogateCases"] = [{"name": c["name"], "type": c["type"], "codeUnitsHex": c["expected"]["payload"]["codeUnitsHex"],
    "reason": "report 265: no UTF-8 form; refused at the boundary (see stringWorkload.rejectedUnpairedSurrogateInputs)"} for c in rej]
nom = doc["nominalStringConformance"]
nrej = [c for c in nom["utf16Cases"] if not well_formed(text_of(c["codeUnitsHex"]))]
nom["utf16Cases"] = [c for c in nom["utf16Cases"] if c not in nrej]
nom["rejectedUnpairedSurrogateCases"] = [{"codeUnitsHex": c["codeUnitsHex"], "reason": "report 265: no UTF-8 form"} for c in nrej]

for s in SECTIONS: convert(doc[s], s)

# Size numbers that depend on String payloads (independent arithmetic).
ne = doc["nonEmptyStringConformance"]
ne["constructor"]["success"]["payloadBytes"] = 8 + len("ok".encode())          # 12 -> 10
ne["nestedProgram"]["record"]["payloadBytes"] = (8 + 2) + (8 + 1)               # String "ok" + String "z": 22 -> 19
for key in ("resultStringError", "nestedError"):
    m = sums["matches"][key]
    m["expectedDeepCopyBytes"] = len(ser8(text_of(m["expectedLiteralCodeUnitsHex"])))  # "error" literal extent: 24 -> 16
# Owner-range traces copy the literals "temporary-in-scope" and "after-scope".
scope_copy = len(ser8("temporary-in-scope")) + len(ser8("after-scope"))       # 48+32=80 -> 32+24=56
ne["ownerRangeTrace"]["literalDeepCopyBytes"] = scope_copy
def set_literal_copy(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "literalDeepCopyBytes": o[k] = scope_copy
            else: set_literal_copy(v)
    elif isinstance(o, list):
        for v in o: set_literal_copy(v)
set_literal_copy(doc["nominalIntConformance"])
sa = doc["stableArenaCases"]
sa["stringSixLocalNestedDeadOnly"]["postRewindAllocationPayloadBytes"] = 8 + 1                # one-character String: 10 -> 9
b = sa["stringBindingRoundTrip"]
b["literalPayloadBytes"] = 8 + len(b["value"].encode()); b["literalExtentBytes"] = a8(b["literalPayloadBytes"])  # 20/24 -> 14/16
b["deepCopyBytes"] = b["literalExtentBytes"]                                                     # 24 -> 16

# Stable-arena binding literal payload is computed in F# from its value.
doc["report265Utf8SectionsTransition"] = (
    "Owning Strings are UTF-8 since report 265. sumConformance, listConformance, stableArenaCases, nonEmptyStringConformance and "
    "nominalStringConformance String images were re-derived by replacing each fixture text's UTF-16 serialization with its UTF-8 "
    "serialization (single ASCII characters are byte-identical in both). Re-derived numbers: NonEmptyString constructor payload 12->10, "
    "nested record payload 22->19, resultStringError and nestedError deep copy 24->16, owner-range literal deep copy 80->56 (temporary-in-scope 32 + after-scope 24), stable binding literal 20/24->14/16 with deep copy 16, dead-only post-rewind allocation payload 10->9; nominalIntConformance and positiveIdConformance images included. Lone-surrogate cases (sum option-some-isolated-high-surrogate, "
    "nominal 410000d84200) moved to rejectedUnpairedSurrogateCases.")

# Splice each edited top-level section back without reformatting the rest.
def splice(text, key, value):
    k = f'\n  "{key}": '
    start = text.index(k) + len(k)
    depth = 0; in_str = False; esc = False
    opener = text[start]
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc: esc = False
            elif ch == "\\": esc = True
            elif ch == '"': in_str = False
        elif ch == '"': in_str = True
        elif ch in "{[": depth += 1
        elif ch in "}]":
            depth -= 1
            if depth == 0: end = i + 1; break
    body = json.dumps(value, indent=2, ensure_ascii=False).replace("\n", "\n  ")
    return text[:start] + body + text[end:]

out = src
for s in SECTIONS: out = splice(out, s, doc[s])
note = doc["report265Utf8SectionsTransition"]
out = out.replace('\n  "limits": ', '\n  "report265Utf8SectionsTransition": ' + json.dumps(note, ensure_ascii=False) + ',\n  "limits": ', 1)
o = '"allCasesPeakLocalBytes was 42 under UTF-16 Strings; the peak local set holds a one-character String whose payload is 9 bytes in UTF-8 (was 10). Reserved (8-byte aligned) peaks are unchanged."'
n = '"Post-execution correction (report 265): owning_stack_runtime_test.c reported 41 after its String builders moved to UTF-8; it was 42 under UTF-16. The value was taken from the native run, not derived independently; the reserved (8-byte aligned) peaks are unchanged."'
assert out.count(o) == 1; out = out.replace(o, n)
json.loads(out)
P.write_text(out, encoding="utf-8", newline="\n")
for p, a, b in changes: print(p, a, "->", b)
print("rejected", [c["name"] for c in rej], nrej)

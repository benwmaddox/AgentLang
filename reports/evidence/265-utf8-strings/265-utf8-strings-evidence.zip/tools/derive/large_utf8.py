import pathlib
p = pathlib.Path(r"D:\code\AgentLang\experiments\AgentLang.OwningMailbox\native_owning_mailbox.c")
t = p.read_text(encoding="utf-8")
def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (old[:80], t.count(old))
    t = t.replace(old, new)
rep("  static uint8_t large_text[4096];", "  /* 8192 ASCII bytes keep the 8200-byte UTF-8 String of the UTF-16 era. */\n  static uint8_t large_text[8192];")
rep('"native text request of exactly 4096 bytes initializes"', '"native text request of exactly 8192 bytes initializes"')
rep("view.bank->bytes[0] == 0x00u && view.bank->bytes[1] == 0x10u &&", "view.bank->bytes[0] == 0x00u && view.bank->bytes[1] == 0x20u &&")
rep("""  for (index = 8u; index < 8200u; ++index) {
    uint8_t expected = (index & 1u) == 0u ? 0x41u : 0u;
    if (view.bank->bytes[index] != expected)
      break;
  }""", """  for (index = 8u; index < 8200u; ++index) {
    if (view.bank->bytes[index] != 0x41u)
      break;
  }""", 2)
rep('"large root retains all 4096 ASCII code units"', '"large root retains all 8192 ASCII bytes"')
rep('"4096-byte completion exceeds bank capacity after handler success"', '"8192-byte completion exceeds bank capacity after handler success"')
rep("view.bank->roots[0].payload_bytes == 8202u);", "view.bank->roots[0].payload_bytes == 8201u);")
rep("view.bank->bytes[8201u] == 0x00u);", "view.bank->bytes[8201u] == 0x00u &&\n            view.bank->bytes[8207u] == 0x00u);")
rep("stats_after.utf8_input_bytes == 8193u &&", "stats_after.utf8_input_bytes == 16385u &&")
p.write_bytes(t.encode("utf-8"))
print("ok")

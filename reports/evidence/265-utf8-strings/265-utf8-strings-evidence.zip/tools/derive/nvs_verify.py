import pathlib, json
ENC16 = 'String payload is an eight-byte UTF-16 code-unit count and zero reserved word, followed by UTF-16LE data and zero padding to an eight-byte extent.'
ENC8 = 'String payload is an eight-byte UTF-8 byte count and zero reserved word, followed by UTF-8 data and zero padding to an eight-byte extent (UTF-16 before report 265).'
v = pathlib.Path(r"D:\code\AgentLang\scripts\Verify-NativeValueStack.ps1")
raw = v.read_bytes(); bom = raw[:3] == b'\xef\xbb\xbf'; s = (raw[3:] if bom else raw).decode()
def rep(o, n, c=None):
    global s
    k = s.count(o); assert (k >= 1 if c is None else k == c), (o[:80], k)
    s = s.replace(o, n)
# Longest images first.
for o, n in [
    ('010000000000000005000000000000006500720072006f007200000000000000', '010000000000000005000000000000006572726f72000000'),
    ('02000000000000006f006b000000000001000000000000007a00000000000000', '02000000000000006f6b00000000000001000000000000007a00000000000000'),
    ('000000000000000002000000000000006f006b0000000000', '000000000000000002000000000000006f6b000000000000'),
    ('010000000000000002000000000000006f006b0000000000', '010000000000000002000000000000006f6b000000000000'),
    ('d6ffffffffffffff04000000000000007400610069006c00', 'd6ffffffffffffff04000000000000007461696c00000000'),
    ('02000000000000006f006b0000000000', '02000000000000006f6b000000000000'),
    ('030000000000000041003dd800de0000', '050000000000000041f09f9880000000'),
    ('03000000000000004100000042000000', '03000000000000004100420000000000'),
]:
    rep("'" + o + "'", "'" + n + "'")
rep(ENC16, ENC8, 2)
rep("[int]$refinedSuccess['payloadBytes'] -eq 12", "[int]$refinedSuccess['payloadBytes'] -eq 10", 1)
rep("[int]$refinedRecord['payloadBytes'] -eq 22", "[int]$refinedRecord['payloadBytes'] -eq 19", 1)
rep("[int]$refinedOwner['literalDeepCopyBytes'] -eq 80", "[int]$refinedOwner['literalDeepCopyBytes'] -eq 56", 1)
rep("[int]$nominalOracle['ownerRangeTrace']['literalDeepCopyBytes'] -eq 80", "[int]$nominalOracle['ownerRangeTrace']['literalDeepCopyBytes'] -eq 56", 1)
rep("[int]$refinedUtf16['supplementary']['codeUnitCount'] -eq 3 -and", "[int]$refinedUtf16['supplementary']['codeUnitCount'] -eq 3 -and", 1)
# The isolated-surrogate nominal case has no UTF-8 form: it is now a rejected input.
rep("    $nominalStringIsolatedSurrogate = $nominalStringUtf16Cases | Where-Object { [string]$_['name'] -ceq 'isolated-surrogate' } | Select-Object -First 1",
    "    $nominalStringIsolatedSurrogate = @($nominalStringOracle['rejectedUnpairedSurrogateCases']) | Select-Object -First 1", 1)
rep("'empty,ordinary,embedded-nul,isolated-surrogate,supplementary'", "'empty,ordinary,embedded-nul,supplementary'", 1)
rep("""        ([int[]]$nominalStringIsolatedSurrogate['codeUnits'] -join ',') -ceq '65,55296,66' -and
        [string]$nominalStringIsolatedSurrogate['codeUnitsHex'] -ceq '410000d84200' -and
        [string]$nominalStringIsolatedSurrogate['stringBytesHex'] -ceq '0300000000000000410000d842000000' -and
""", """        @($nominalStringOracle['rejectedUnpairedSurrogateCases']).Count -eq 1 -and
        [string]$nominalStringIsolatedSurrogate['codeUnitsHex'] -ceq '410000d84200' -and
""", 1)
rep("[string]$nominalStringUtf16Cases[4]['stringBytesHex']", "[string]$nominalStringUtf16Cases[3]['stringBytesHex']", 1)
rep("        expectedIsolatedSurrogateCodeUnits = @(65, 55296, 66)\n        expectedIsolatedSurrogateBytesHex = '0300000000000000410000d842000000'\n",
    "        expectedRejectedIsolatedSurrogateCodeUnitsHex = '410000d84200'\n", 1)
rep("        'host-identity-utf16-isolated-surrogate',\n", "", 1)
rep("$_['utf16CaseCount'] -ne 5 -or", "$_['utf16CaseCount'] -ne 4 -or", 1)
rep("'NonEmptyString fixture pins UTF-16 bytes,", "'NonEmptyString fixture pins UTF-8 bytes,", 1)
rep("'unvalidated nominal String fixture pins UTF-16LE code units,", "'unvalidated nominal String fixture pins UTF-8 bytes,", 1)
v.write_bytes((b'\xef\xbb\xbf' if bom else b'') + s.encode())

f = pathlib.Path(r"D:\code\AgentLang\tests\fixtures\native-conformance\native-value-stack.json")
t = f.read_text(encoding="utf-8")
assert t.count(json.dumps(ENC16)) == 2, t.count(json.dumps(ENC16))
f.write_text(t.replace(json.dumps(ENC16), json.dumps(ENC8)), encoding="utf-8", newline="\n")
print("ok")

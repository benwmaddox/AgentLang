import pathlib, struct, re
def ser(b):
    raw = struct.pack('<I', len(b)) + b'\0'*4 + b
    raw += b'\0' * (-len(raw) % 8)
    return raw.hex()
TAG0 = "0000000000000000"; TAG1 = "0100000000000000"
u_init = bytes.fromhex("41f09f9982"); delta = bytes.fromhex("ceb4"); fin = u_init + delta + bytes.fromhex("00f09f9a80")
H = {
 "unicode_initialize": (TAG0 + ser(u_init), "0000000000000000030000000000000041003dd842de0000"),
 "some_delta": (TAG0 + ser(delta), "00000000000000000100000000000000b403000000000000"),
 "unicode_final": (TAG0 + ser(fin), "0000000000000000070000000000000041003dd842deb40300003dd880de0000"),
 "error_err": (TAG1 + ser(b"ERR"), "010000000000000003000000000000004500520052000000"),
 "ok_err": (TAG0 + ser(b"ERR"), "000000000000000003000000000000004500520052000000"),
}
long_text = b"12345678901234"
cap_old = "0000000000000000070000000000000031003200330034003500360037000000"
cap_new = TAG0 + ser(long_text)
for k,(n,o) in H.items(): print(k, n)
print("cap", cap_new)

# --- runner ---
p = pathlib.Path(r"D:\code\AgentLang\experiments\AgentLang.OwningMailbox\native_owning_mailbox_sums.c")
t = p.read_text(encoding="utf-8")
def rep(o, n, c=1):
    global t
    assert (t.count(o) >= 1 if c is None else t.count(o) == c), (o[:90], t.count(o))
    t = t.replace(o, n)
for k,(n,o) in H.items():
    c = t.count('"%s"' % o); assert c >= 1, k
    t = t.replace('"%s"' % o, '"%s"' % n)
# payload sizes: State with Unicode init 22->21, final 30->28, Z 18->17, ERR 22->19
rep("0u, 22u, 24u, hex_unicode_initialize", "0u, 21u, 24u, hex_unicode_initialize")
rep("state_type_id, 0u, 22u, 24u,\n                            hex_unicode_initialize", "state_type_id, 0u, 21u, 24u,\n                            hex_unicode_initialize", None)
rep("30u, 32u, hex_unicode_final", "28u, 32u, hex_unicode_final")
rep("0u, 18u, 24u, hex_z_initialize", "0u, 17u, 24u, hex_z_initialize")
rep("snapshot_matches_root(empty_pair, 0u, state_type_id, 0u, 18u, 24u,", "snapshot_matches_root(empty_pair, 0u, state_type_id, 0u, 17u, 24u,")
rep("0u, 22u, 24u, hex_error_err", "0u, 19u, 24u, hex_error_err")
rep("state_type_id, 0u, 22u,\n                            24u, hex_error_err", "state_type_id, 0u, 19u,\n                            24u, hex_error_err")
rep("0u, 22u, 24u, hex_ok_err", "0u, 19u, 24u, hex_ok_err", None)
rep("""      3u, 0u, 0u, 0u, 0u, 0u, 0u, 0u,
      0x41u, 0u, 0x3du, 0xd8u, 0x42u, 0xdeu, 0u, 0u};""", """      5u, 0u, 0u, 0u, 0u, 0u, 0u, 0u,
      0x41u, 0xf0u, 0x9fu, 0x99u, 0x82u, 0u, 0u, 0u};""")
rep("okay = scan_result == 0 && payload == 22u && extent == 24u;", "okay = scan_result == 0 && payload == 21u && extent == 24u;")
rep("static const uint8_t long_text[] = {'1', '2', '3', '4', '5', '6', '7'};",
    "/* 14 UTF-8 bytes: the State extent is 32, one byte over the 31-byte bank. */\n  static const uint8_t long_text[] = {'1', '2', '3', '4', '5', '6', '7',\n                                      '8', '9', '0', '1', '2', '3', '4'};")
p.write_bytes(t.encode("utf-8"))

# --- fixture ---
f = pathlib.Path(r"D:\code\AgentLang\tests\fixtures\native-conformance\owning-mailbox-sums.json")
s = f.read_text(encoding="utf-8")
for k,(n,o) in H.items():
    assert s.count('"%s"' % o) >= 1, k
    s = s.replace('"%s"' % o, '"%s"' % n)
assert s.count(cap_old) == 1; s = s.replace(cap_old, cap_new)
def frep(o, n, c=1):
    global s
    assert s.count(o) == c, (o[:90], s.count(o))
    s = s.replace(o, n)
frep('"encoding": "UTF-16LE",', '"encoding": "UTF-8",')
frep('"payloadBytesFormula": "8 + 2*UTF16CodeUnits",', '"payloadBytesFormula": "8 + UTF8Bytes",')
frep('"stringExtent": "align_up(8 + 2*UTF16CodeUnits, 8)",', '"stringExtent": "align_up(8 + UTF8Bytes, 8)",')
frep('"oversizedResumeUtf8Hex": "31323334353637",', '"oversizedResumeUtf8Hex": "%s",' % long_text.hex())
frep('"oversizedResumeCodeUnitsHex": "0031003200330034003500360037",', '"oversizedResumeCodeUnitsHex": "%s",' % "".join("00%02x" % b for b in long_text))
frep('"utf8InputBytes": 27,', '"utf8InputBytes": 34,', 2)
frep('UINT32_MAX UTF-16 units exceeds', 'UINT32_MAX UTF-8 bytes exceeds')
frep('resume(1234567) rejected one byte short', 'resume(12345678901234) rejected one byte short')
frep('"capacityResumeSevenUnits": "None payload literal 8 + FAIL and ERR literals 32 + empty concat extent 8 + seven-unit concat extent 24',
     '"capacityResumeSevenUnits": "None payload literal 8 + FAIL and ERR literals 32 + empty concat extent 8 + fourteen-byte concat extent 24')
frep('''      "serializedValueStepAndCopyOraclesChanged": false
    }
  },''', '''      "serializedValueStepAndCopyOraclesChanged": false
    },
    "report265Utf8Transition": "Owning Strings are UTF-8 since report 265 (prior fixture sha256 ddd86cbd139cb678a25960ac74b09f154ccf0ab170ddafcc31c8b362f20c8859). Serialized String bytes and payload sizes are re-derived from the unchanged UTF-8 inputs; every String extent, and therefore every staging, import, publication and deep-copy total, is unchanged. The capacity resume text doubled from 7 to 14 ASCII bytes so the State extent stays 32 against the 31-byte bank; utf8InputBytes rises from 27 to 34. The utf16StagingBytes name is kept for ABI stability."
  },''')
f.write_bytes(s.encode("utf-8"))
print("ok")

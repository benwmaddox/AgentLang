param([Parameter(Mandatory)][string]$RunRoot)
$ErrorActionPreference = 'Stop'
$r = Get-Content -LiteralPath (Join-Path $RunRoot 'run-report.json') -Raw | ConvertFrom-Json
if ($null -ne $r.error -or -not $r.sourceStable -or $r.mode -ne 'confirm-16-slot') { throw 'Incomplete/invalid confirmation' }
$audits = @()
foreach ($trial in $r.trials) {
    $raw = Get-Content -LiteralPath $trial.paths.applicationResult -Raw | ConvertFrom-Json
    $provider = $trial.provider.counters
    $latencies = @($raw.latencyMicroseconds | Sort-Object)
    $p99 = if ($latencies.Count -gt 0) { [long]$latencies[[int][Math]::Ceiling($latencies.Count * 0.99) - 1] } else { 0L }
    $valid = $trial.validComparison -and $raw.verified -and
        ($raw.offered -eq $raw.admitted + $raw.rejected) -and ($raw.admitted -eq $raw.completed) -and
        ($raw.errors -eq 0) -and ($raw.timedOut -eq 0) -and ($raw.pendingAtEnd -eq 0) -and
        ($latencies.Count -eq $raw.completed) -and ($provider.acceptedFrames -eq $raw.warmupCompleted + $raw.admitted) -and
        ($provider.completedFrames -eq $provider.acceptedFrames) -and (@($raw.mailboxes).Count -eq 16) -and
        (@($raw.mailboxes | Where-Object { -not $_.latestVerified }).Count -eq 0) -and
        (($raw.mailboxes | Measure-Object -Property attempted -Sum).Sum -eq $raw.admitted) -and
        (($raw.mailboxes | Measure-Object -Property completed -Sum).Sum -eq $raw.completed) -and
        ($trial.application.process.enforcedJobMemoryLimitBytes -eq 268435456)
    if (-not $valid) { throw "Raw accounting invalid: $($trial.trialId)" }
    $rejection = [double]$raw.rejected / [double]$raw.offered
    $qualifies = $valid -and $rejection -le 0.01 -and $p99 -le 50000
    if ($p99 -ne $trial.application.p99LatencyMicroseconds -or $qualifies -ne $trial.application.qualifies) { throw "Derived score mismatch: $($trial.trialId)" }
    if ($raw.offered -ne [Math]::Ceiling([double]$raw.rate * $raw.durationMs / 1000)) { throw 'Arrival count mismatch' }
    $audits += [pscustomobject][ordered]@{
        trial=$trial.trialId;phase=$trial.phase;backend=$trial.backend;policy=$trial.policy;slots=$trial.scratchSlots;repeat=$trial.repeat
        rate=$raw.rate;delayMs=$raw.delayMs;payloadBytes=$raw.payloadBytes;warmupMs=$raw.warmupMs;durationMs=$raw.durationMs
        passed=$valid;offered=$raw.offered;admitted=$raw.admitted;rejected=$raw.rejected;completed=$raw.completed
        throughput=[double]$raw.completedWithinWindow/([double]$raw.durationMs/1000);p99Microseconds=$p99;rejectionFraction=$rejection
        qualifies=$qualifies;commitBytes=$trial.application.process.peakJobCommittedBytes;workingSetBytes=$trial.application.process.peakWorkingSetBytes
        ceilingNonbinding=$trial.application.process.capNonbinding
    }
}
$focused = @($audits | Where-Object { $_.phase -eq 'confirmation-16-slot-30s' })
if ($audits.Count -ne 20 -or $focused.Count -ne 9) { throw 'Expected eleven smoke and nine confirmations' }
foreach ($key in @('fsharp/gc','native/return','native/keep')) {
    $rows = @($focused | Where-Object { "$($_.backend)/$($_.policy)" -eq $key })
    if ($rows.Count -ne 3 -or ((@($rows.repeat | Sort-Object) -join ',') -ne '1,2,3')) { throw "Bad repeat set $key" }
    foreach ($row in $rows) {
        if ($row.rate -ne 500 -or $row.delayMs -ne 5 -or $row.payloadBytes -ne 4096 -or $row.warmupMs -ne 1000 -or $row.durationMs -ne 30000 -or
            ($row.backend -eq 'native' -and $row.slots -ne 16) -or ($row.backend -eq 'fsharp' -and $null -ne $row.slots)) { throw 'Frozen configuration drift' }
    }
    $group = @($r.score.groups | Where-Object { "$($_.backend)/$($_.policy)" -eq $key })
    $all = @($rows | Where-Object { -not $_.qualifies }).Count -eq 0
    if ($group.Count -ne 1 -or $group[0].allRepeatsQualify -ne $all) { throw 'Group score mismatch' }
}
$allGroups = @($focused | Where-Object { -not $_.qualifies }).Count -eq 0
if ($r.score.allGroupsQualify -ne $allGroups) { throw 'Overall score mismatch' }
$result = [ordered]@{runId=$r.runId;kind='root-raw-confirmation-audit';passed=$true;allGroupsQualify=$allGroups;trials=$audits;limitations='Recomputes saved accounting and percentiles. Runtime content checks remain performed by the existing harness; this is not an independent implementation of handler semantics.'}
[IO.File]::WriteAllText((Join-Path $RunRoot 'root-raw-audit.json'),(($result | ConvertTo-Json -Depth 10).Replace("`r`n","`n") + "`n"),[Text.UTF8Encoding]::new($false))
$focused | Format-Table trial,throughput,p99Microseconds,rejectionFraction,qualifies,commitBytes,workingSetBytes

target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %validator.depth.21 = add i32 %depth, 1
  %depth.exceeded.22 = icmp ugt i32 %validator.depth.21, 64
  br i1 %depth.exceeded.22, label %failure.23, label %continue.24
failure.23:
  %ctx.field.25 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.25, align 4
  %status.diagnostic.26 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.26, align 4
  ret void
continue.24:
  %call.depth.27 = add i32 %validator.depth.21, 1
  call void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.27, i64 3)
  %callee.status.28 = load i32, ptr %status, align 4
  %callee.succeeded.29 = icmp eq i32 %callee.status.28, 0
  br i1 %callee.succeeded.29, label %callee.continue.31, label %callee.failure.30
callee.failure.30:
  ret void
callee.continue.31:
  %call.output.ptr.32 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.33 = load i64, ptr %call.output.ptr.32, align 8
  %validator.accepted.34 = icmp ne i64 %call.output.33, 0
  %validator.failed.35 = xor i1 %validator.accepted.34, true
  br i1 %validator.failed.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %output.ptr.40 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 3, ptr %output.ptr.40, align 8
  ret void
}

define internal void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %int.compare.21 = icmp sgt i64 %arg0, 0
  %bool.slot.22 = zext i1 %int.compare.21 to i64
  %output.ptr.23 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.22, ptr %output.ptr.23, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 1 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %items = alloca [8 x i64], align 8
  %out0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %item0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %version.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 0
  %version = load i32, ptr %version.ptr, align 4
  %version.ok = icmp eq i32 %version, 1
  br i1 %version.ok, label %capacity.check, label %invalid.version
invalid.version:
  store i32 2, ptr %status, align 4
  ret void
capacity.check:
  %capacity.ok = icmp sge i32 %capacity, 1
  %outputs.null = icmp eq ptr %outputs, null
  %outputs.required = icmp ne i32 %capacity, 0
  %null.invalid = and i1 %outputs.null, %outputs.required
  %capacity.invalid = xor i1 %capacity.ok, true
  %request.invalid = or i1 %capacity.invalid, %null.invalid
  br i1 %request.invalid, label %invalid.request, label %request.valid
invalid.request:
  store i32 2, ptr %status, align 4
  ret void
request.valid:
  store i32 0, ptr %status, align 4
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 0)
  ret void
}

target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %ctx.field.21 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.22 = load i32, ptr %ctx.field.21, align 4
  %steps.next.23 = add i32 %steps.current.22, 1
  store i32 %steps.next.23, ptr %ctx.field.21, align 4
  %steps.over.24 = icmp ugt i32 %steps.next.23, 10000
  br i1 %steps.over.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %depth.exceeded.29 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.29, label %failure.30, label %continue.31
failure.30:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.32, align 4
  %status.diagnostic.33 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.33, align 4
  ret void
continue.31:
  %ctx.field.34 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.35 = load i32, ptr %ctx.field.34, align 4
  %steps.next.36 = add i32 %steps.current.35, 1
  store i32 %steps.next.36, ptr %ctx.field.34, align 4
  %steps.over.37 = icmp ugt i32 %steps.next.36, 10000
  br i1 %steps.over.37, label %failure.38, label %continue.39
failure.38:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.40, align 4
  %status.diagnostic.41 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.41, align 4
  ret void
continue.39:
  %depth.exceeded.42 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.42, label %failure.43, label %continue.44
failure.43:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.45, align 4
  %status.diagnostic.46 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.46, align 4
  ret void
continue.44:
  %ctx.field.47 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.48 = load i32, ptr %ctx.field.47, align 4
  %steps.next.49 = add i32 %steps.current.48, 1
  store i32 %steps.next.49, ptr %ctx.field.47, align 4
  %steps.over.50 = icmp ugt i32 %steps.next.49, 10000
  br i1 %steps.over.50, label %failure.51, label %continue.52
failure.51:
  %ctx.field.53 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.53, align 4
  %status.diagnostic.54 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.54, align 4
  ret void
continue.52:
  %ctx.field.55 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.56 = load i32, ptr %ctx.field.55, align 4
  %steps.next.57 = add i32 %steps.current.56, 1
  store i32 %steps.next.57, ptr %ctx.field.55, align 4
  %steps.over.58 = icmp ugt i32 %steps.next.57, 10000
  br i1 %steps.over.58, label %failure.59, label %continue.60
failure.59:
  %ctx.field.61 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.61, align 4
  %status.diagnostic.62 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.62, align 4
  ret void
continue.60:
  %depth.exceeded.63 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.63, label %failure.64, label %continue.65
failure.64:
  %ctx.field.66 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.66, align 4
  %status.diagnostic.67 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.67, align 4
  ret void
continue.65:
  %validator.depth.68 = add i32 %depth, 1
  %depth.exceeded.69 = icmp ugt i32 %validator.depth.68, 64
  br i1 %depth.exceeded.69, label %failure.70, label %continue.71
failure.70:
  %ctx.field.72 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.72, align 4
  %status.diagnostic.73 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.73, align 4
  ret void
continue.71:
  %call.depth.74 = add i32 %validator.depth.68, 1
  call void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.74, i64 5)
  %callee.status.75 = load i32, ptr %status, align 4
  %callee.succeeded.76 = icmp eq i32 %callee.status.75, 0
  br i1 %callee.succeeded.76, label %callee.continue.78, label %callee.failure.77
callee.failure.77:
  ret void
callee.continue.78:
  %call.output.ptr.79 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.80 = load i64, ptr %call.output.ptr.79, align 8
  %validator.accepted.81 = icmp ne i64 %call.output.80, 0
  %validator.failed.82 = xor i1 %validator.accepted.81, true
  br i1 %validator.failed.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.88 = load i32, ptr %ctx.field.87, align 4
  %steps.next.89 = add i32 %steps.current.88, 1
  store i32 %steps.next.89, ptr %ctx.field.87, align 4
  %steps.over.90 = icmp ugt i32 %steps.next.89, 10000
  br i1 %steps.over.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %depth.exceeded.95 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.95, label %failure.96, label %continue.97
failure.96:
  %ctx.field.98 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.98, align 4
  %status.diagnostic.99 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.99, align 4
  ret void
continue.97:
  %ctx.field.100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.101 = load i32, ptr %ctx.field.100, align 4
  %steps.next.102 = add i32 %steps.current.101, 1
  store i32 %steps.next.102, ptr %ctx.field.100, align 4
  %steps.over.103 = icmp ugt i32 %steps.next.102, 10000
  br i1 %steps.over.103, label %failure.104, label %continue.105
failure.104:
  %ctx.field.106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.106, align 4
  %status.diagnostic.107 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.107, align 4
  ret void
continue.105:
  %depth.exceeded.108 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.108, label %failure.109, label %continue.110
failure.109:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.111, align 4
  %status.diagnostic.112 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.112, align 4
  ret void
continue.110:
  %output.ptr.113 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 17, ptr %output.ptr.113, align 8
  %output.ptr.114 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 17, ptr %output.ptr.114, align 8
  %output.ptr.115 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 5, ptr %output.ptr.115, align 8
  %output.ptr.116 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 5, ptr %output.ptr.116, align 8
  ret void
}

define internal void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %int.compare.21 = icmp sgt i64 %arg0, 0
  %bool.slot.22 = zext i1 %int.compare.21 to i64
  %output.ptr.23 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.22, ptr %output.ptr.23, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 4 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %items = alloca [8 x i64], align 8
  %out0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %item0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %version.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 0
  %version = load i32, ptr %version.ptr, align 4
  %version.ok = icmp eq i32 %version, 1
  br i1 %version.ok, label %capacity.check, label %invalid.version
invalid.version:
  store i32 2, ptr %status, align 4
  ret void
capacity.check:
  %capacity.ok = icmp sge i32 %capacity, 4
  %outputs.null = icmp eq ptr %outputs, null
  %outputs.required = icmp ne i32 %capacity, 0
  %null.invalid = and i1 %outputs.null, %outputs.required
  %capacity.invalid = xor i1 %capacity.ok, true
  %request.invalid = or i1 %capacity.invalid, %null.invalid
  br i1 %request.invalid, label %invalid.request, label %request.valid
invalid.request:
  store i32 2, ptr %status, align 4
  ret void
request.valid:
  store i32 0, ptr %status, align 4
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 0)
  ret void
}

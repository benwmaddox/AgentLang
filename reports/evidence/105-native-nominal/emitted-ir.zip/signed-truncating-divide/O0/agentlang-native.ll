target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %depth.exceeded.24 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %divide.zero.29 = icmp eq i64 2, 0
  br i1 %divide.zero.29, label %failure.30, label %continue.31
failure.30:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.32, align 4
  %status.diagnostic.33 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.33, align 4
  ret void
continue.31:
  %divide.min.34 = icmp eq i64 -7, -9223372036854775808
  %divide.negative.one.35 = icmp eq i64 2, -1
  %divide.overflow.36 = and i1 %divide.min.34, %divide.negative.one.35
  br i1 %divide.overflow.36, label %failure.37, label %continue.38
failure.37:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.39, align 4
  %status.diagnostic.40 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.40, align 4
  ret void
continue.38:
  %divide.result.41 = sdiv i64 -7, 2
  %ctx.field.42 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.43 = load i32, ptr %ctx.field.42, align 4
  %steps.next.44 = add i32 %steps.current.43, 1
  store i32 %steps.next.44, ptr %ctx.field.42, align 4
  %steps.over.45 = icmp ugt i32 %steps.next.44, 10000
  br i1 %steps.over.45, label %failure.46, label %continue.47
failure.46:
  %ctx.field.48 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.48, align 4
  %status.diagnostic.49 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.49, align 4
  ret void
continue.47:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.51 = load i32, ptr %ctx.field.50, align 4
  %steps.next.52 = add i32 %steps.current.51, 1
  store i32 %steps.next.52, ptr %ctx.field.50, align 4
  %steps.over.53 = icmp ugt i32 %steps.next.52, 10000
  br i1 %steps.over.53, label %failure.54, label %continue.55
failure.54:
  %ctx.field.56 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.56, align 4
  %status.diagnostic.57 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.57, align 4
  ret void
continue.55:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.59 = load i32, ptr %ctx.field.58, align 4
  %steps.next.60 = add i32 %steps.current.59, 1
  store i32 %steps.next.60, ptr %ctx.field.58, align 4
  %steps.over.61 = icmp ugt i32 %steps.next.60, 10000
  br i1 %steps.over.61, label %failure.62, label %continue.63
failure.62:
  %ctx.field.64 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.64, align 4
  %status.diagnostic.65 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.65, align 4
  ret void
continue.63:
  %depth.exceeded.66 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.66, label %failure.67, label %continue.68
failure.67:
  %ctx.field.69 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.69, align 4
  %status.diagnostic.70 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.70, align 4
  ret void
continue.68:
  %divide.zero.71 = icmp eq i64 -2, 0
  br i1 %divide.zero.71, label %failure.72, label %continue.73
failure.72:
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.74, align 4
  %status.diagnostic.75 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.75, align 4
  ret void
continue.73:
  %divide.min.76 = icmp eq i64 7, -9223372036854775808
  %divide.negative.one.77 = icmp eq i64 -2, -1
  %divide.overflow.78 = and i1 %divide.min.76, %divide.negative.one.77
  br i1 %divide.overflow.78, label %failure.79, label %continue.80
failure.79:
  %ctx.field.81 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.81, align 4
  %status.diagnostic.82 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.82, align 4
  ret void
continue.80:
  %divide.result.83 = sdiv i64 7, -2
  %ctx.field.84 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.85 = load i32, ptr %ctx.field.84, align 4
  %steps.next.86 = add i32 %steps.current.85, 1
  store i32 %steps.next.86, ptr %ctx.field.84, align 4
  %steps.over.87 = icmp ugt i32 %steps.next.86, 10000
  br i1 %steps.over.87, label %failure.88, label %continue.89
failure.88:
  %ctx.field.90 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.90, align 4
  %status.diagnostic.91 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.91, align 4
  ret void
continue.89:
  %ctx.field.92 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.93 = load i32, ptr %ctx.field.92, align 4
  %steps.next.94 = add i32 %steps.current.93, 1
  store i32 %steps.next.94, ptr %ctx.field.92, align 4
  %steps.over.95 = icmp ugt i32 %steps.next.94, 10000
  br i1 %steps.over.95, label %failure.96, label %continue.97
failure.96:
  %ctx.field.98 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.98, align 4
  %status.diagnostic.99 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.99, align 4
  ret void
continue.97:
  %ctx.field.100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.101 = load i32, ptr %ctx.field.100, align 4
  %steps.next.102 = add i32 %steps.current.101, 1
  store i32 %steps.next.102, ptr %ctx.field.100, align 4
  %steps.over.103 = icmp ugt i32 %steps.next.102, 10000
  br i1 %steps.over.103, label %failure.104, label %continue.105
failure.104:
  %ctx.field.106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.106, align 4
  %status.diagnostic.107 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.107, align 4
  ret void
continue.105:
  %depth.exceeded.108 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.108, label %failure.109, label %continue.110
failure.109:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.111, align 4
  %status.diagnostic.112 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.112, align 4
  ret void
continue.110:
  %divide.zero.113 = icmp eq i64 -2, 0
  br i1 %divide.zero.113, label %failure.114, label %continue.115
failure.114:
  %ctx.field.116 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.116, align 4
  %status.diagnostic.117 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.117, align 4
  ret void
continue.115:
  %divide.min.118 = icmp eq i64 -7, -9223372036854775808
  %divide.negative.one.119 = icmp eq i64 -2, -1
  %divide.overflow.120 = and i1 %divide.min.118, %divide.negative.one.119
  br i1 %divide.overflow.120, label %failure.121, label %continue.122
failure.121:
  %ctx.field.123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.123, align 4
  %status.diagnostic.124 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.124, align 4
  ret void
continue.122:
  %divide.result.125 = sdiv i64 -7, -2
  %output.ptr.126 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %divide.result.41, ptr %output.ptr.126, align 8
  %output.ptr.127 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %divide.result.83, ptr %output.ptr.127, align 8
  %output.ptr.128 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %divide.result.125, ptr %output.ptr.128, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %items = alloca [8 x i64], align 8
  %out0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %item0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %version.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 0
  %version = load i32, ptr %version.ptr, align 4
  %version.ok = icmp eq i32 %version, 1
  br i1 %version.ok, label %capacity.check, label %invalid.version
invalid.version:
  store i32 2, ptr %status, align 4
  ret void
capacity.check:
  %capacity.ok = icmp sge i32 %capacity, 3
  %outputs.null = icmp eq ptr %outputs, null
  %outputs.required = icmp ne i32 %capacity, 0
  %null.invalid = and i1 %outputs.null, %outputs.required
  %capacity.invalid = xor i1 %capacity.ok, true
  %request.invalid = or i1 %capacity.invalid, %null.invalid
  br i1 %request.invalid, label %invalid.request, label %request.valid
invalid.request:
  store i32 2, ptr %status, align 4
  ret void
request.valid:
  store i32 0, ptr %status, align 4
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 0)
  ret void
}

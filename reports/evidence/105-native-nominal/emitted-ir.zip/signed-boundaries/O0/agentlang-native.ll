target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %depth.exceeded.24 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %int.compare.29 = icmp slt i64 -9223372036854775808, 0
  %bool.slot.30 = zext i1 %int.compare.29 to i64
  %ctx.field.31 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.32 = load i32, ptr %ctx.field.31, align 4
  %steps.next.33 = add i32 %steps.current.32, 1
  store i32 %steps.next.33, ptr %ctx.field.31, align 4
  %steps.over.34 = icmp ugt i32 %steps.next.33, 10000
  br i1 %steps.over.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.40 = load i32, ptr %ctx.field.39, align 4
  %steps.next.41 = add i32 %steps.current.40, 1
  store i32 %steps.next.41, ptr %ctx.field.39, align 4
  %steps.over.42 = icmp ugt i32 %steps.next.41, 10000
  br i1 %steps.over.42, label %failure.43, label %continue.44
failure.43:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.45, align 4
  %status.diagnostic.46 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.46, align 4
  ret void
continue.44:
  %ctx.field.47 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.48 = load i32, ptr %ctx.field.47, align 4
  %steps.next.49 = add i32 %steps.current.48, 1
  store i32 %steps.next.49, ptr %ctx.field.47, align 4
  %steps.over.50 = icmp ugt i32 %steps.next.49, 10000
  br i1 %steps.over.50, label %failure.51, label %continue.52
failure.51:
  %ctx.field.53 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.53, align 4
  %status.diagnostic.54 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.54, align 4
  ret void
continue.52:
  %depth.exceeded.55 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %int.compare.60 = icmp sgt i64 9223372036854775807, -1
  %bool.slot.61 = zext i1 %int.compare.60 to i64
  %output.ptr.62 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.30, ptr %output.ptr.62, align 8
  %output.ptr.63 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %bool.slot.61, ptr %output.ptr.63, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 2 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %items = alloca [8 x i64], align 8
  %out0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %item0 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [8 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %version.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 0
  %version = load i32, ptr %version.ptr, align 4
  %version.ok = icmp eq i32 %version, 1
  br i1 %version.ok, label %capacity.check, label %invalid.version
invalid.version:
  store i32 2, ptr %status, align 4
  ret void
capacity.check:
  %capacity.ok = icmp sge i32 %capacity, 2
  %outputs.null = icmp eq ptr %outputs, null
  %outputs.required = icmp ne i32 %capacity, 0
  %null.invalid = and i1 %outputs.null, %outputs.required
  %capacity.invalid = xor i1 %capacity.ok, true
  %request.invalid = or i1 %capacity.invalid, %null.invalid
  br i1 %request.invalid, label %invalid.request, label %request.valid
invalid.request:
  store i32 2, ptr %status, align 4
  ret void
request.valid:
  store i32 0, ptr %status, align 4
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 0)
  ret void
}

# Conventional F# start

This directory contains an isolated Business library project under business/ and its console tests under tests/. The test project references the copied library. Use the assigned broker for all project inspection, authoring, and validation.

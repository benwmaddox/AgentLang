from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile


PARTICIPANTS = (
    "flow-retained-1",
    "flow-retained-2",
    "fsharp-1",
    "fsharp-2",
)
EXPECTED_ARMS = {
    "flow-retained-1": "flow-retained",
    "flow-retained-2": "flow-retained",
    "fsharp-1": "fsharp",
    "fsharp-2": "fsharp",
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def normalized_member(path):
    return str(path).replace("\\", "/")


def excluded_reason(relative_path):
    for part in relative_path.parts:
        lowered = part.lower()
        if lowered in ("bin", "obj"):
            return "build-directory:" + lowered
        if lowered in ("artifacts", "fresh-test-artifacts"):
            return "build-artifacts"
    return None


def main():
    repo = Path(__file__).resolve().parents[2]
    trial = repo / ".agentlang/maintenance-141"
    study = repo / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141"
    results = trial / "results"
    out = repo / "reports/evidence/141-paid-invoice-maintenance"
    archive = out / "results.zip"
    index_path = out / "results-index.json"
    archive_checksum = out / "results.sha256"
    index_checksum = out / "results-index.sha256"
    destinations = (archive, index_path, archive_checksum, index_checksum)

    present = [path for path in destinations if path.exists()]
    if present:
        raise RuntimeError("Refusing to overwrite existing results output: " + ", ".join(map(str, present)))

    participants_path = study / "dispatch/participants.json"
    participant_records = json.loads(participants_path.read_text(encoding="utf-8-sig"))
    records_by_id = {item["id"]: item for item in participant_records}
    if len(records_by_id) != len(PARTICIPANTS) or set(records_by_id) != set(PARTICIPANTS):
        raise RuntimeError("Dispatch participant list does not match the four expected participants")

    # Each trace is captured once and must already contain the broker's terminal event.
    trace_bytes = {}
    for participant in PARTICIPANTS:
        record = records_by_id[participant]
        if record.get("arm") != EXPECTED_ARMS[participant]:
            raise RuntimeError(f"Unexpected arm for {participant}: {record.get('arm')!r}")
        project = trial / "participants" / participant / "project"
        recorded_project = Path(record["project"])
        if recorded_project.resolve() != project.resolve():
            raise RuntimeError(f"Dispatch project path changed for {participant}")
        if not project.is_dir():
            raise RuntimeError(f"Missing final participant project: {project}")
        trace_path = project.parent / "actor.trace.jsonl"
        if not trace_path.is_file():
            raise RuntimeError(f"Missing participant trace: {trace_path}")
        data = trace_path.read_bytes()
        rows = [line for line in data.decode("utf-8-sig").splitlines() if line.strip()]
        if not rows:
            raise RuntimeError(f"Participant trace is empty: {trace_path}")
        try:
            terminal = json.loads(rows[-1])
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Invalid final trace record in {trace_path}: {exc}") from exc
        if terminal.get("event") != "session-end":
            raise RuntimeError(f"Participant trace is not terminal (session-end): {trace_path}")
        trace_bytes[participant] = data

        participant_results = results / participant
        required = ("audit.json", "review.md", "termination-audit.txt")
        missing = [name for name in required if not (participant_results / name).is_file()]
        if missing:
            raise RuntimeError(f"Missing result records for {participant}: {', '.join(missing)}")
        if EXPECTED_ARMS[participant] == "fsharp":
            fresh_logs = ("fresh-test-build.log", "fresh-test-run.log")
            missing = [name for name in fresh_logs if not (participant_results / name).is_file()]
            if missing:
                raise RuntimeError(f"Missing fresh-test logs for {participant}: {', '.join(missing)}")

    verifier = trial / "verify-results-inputs.py"
    auditor = trial / "audit-participant.py"
    packager = trial / "package-results.py"
    for path in (verifier, auditor, packager, study / "acceptance.md"):
        if not path.is_file():
            raise RuntimeError(f"Missing required evidence source: {path}")

    archive_sources = {}
    omitted = Counter()

    def add_path(member, source, category):
        member = normalized_member(member)
        if member in archive_sources:
            raise RuntimeError(f"Duplicate archive path: {member}")
        archive_sources[member] = {"source": source, "category": category}

    def add_tree(root, member_prefix, category):
        if not root.is_dir():
            raise RuntimeError(f"Missing evidence directory: {root}")
        for source in sorted(root.rglob("*"), key=lambda path: path.relative_to(root).as_posix()):
            if source.is_symlink():
                omitted["symlink"] += 1
                continue
            if not source.is_file():
                continue
            relative = source.relative_to(root)
            reason = excluded_reason(relative)
            if reason:
                omitted[reason] += 1
                continue
            add_path(Path(member_prefix) / relative, source, category)

    for participant in PARTICIPANTS:
        participant_root = trial / "participants" / participant
        project = participant_root / "project"
        add_tree(project, Path("participants") / participant / "final-project", "final-project")
        add_path(
            Path("participants") / participant / "actor.trace.jsonl",
            trace_bytes[participant],
            "terminal-actor-trace",
        )

    # Keep all result evidence, including every result JSON and the F# test logs.
    add_tree(results, "results", "participant-results")

    # Keep only the final participant scorer runs; their build artifact directories are excluded.
    runs = trial / "fsharp-scoring" / "runs"
    for run_id in ("participant-fsharp-1", "participant-fsharp-2"):
        run_root = runs / run_id
        if not run_root.is_dir():
            raise RuntimeError(f"Missing participant F# scorer run: {run_root}")
        for name in ("command.json", "result.json", "build.log", "scorer.log"):
            if not (run_root / name).is_file():
                raise RuntimeError(f"Missing F# scorer run evidence: {run_root / name}")
        add_tree(run_root, Path("fsharp-scoring") / "runs" / run_id, "fsharp-participant-scorer-run")

    add_path("maintenance/audit-participant.py", auditor, "evidence-tool")
    add_path("maintenance/verify-results-inputs.py", verifier, "evidence-tool")
    add_path("maintenance/package-results.py", packager, "evidence-tool")
    add_path("acceptance.md", study / "acceptance.md", "frozen-acceptance-procedure")

    out.mkdir(parents=True, exist_ok=True)
    entries = []
    with tempfile.TemporaryDirectory(prefix="results-package-", dir=out) as temp_dir:
        staged_archive = Path(temp_dir) / archive.name
        with zipfile.ZipFile(staged_archive, "w") as bundle:
            for member in sorted(archive_sources):
                source = archive_sources[member]["source"]
                data = source if isinstance(source, bytes) else source.read_bytes()
                info = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (0o100644 & 0xFFFF) << 16
                bundle.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
                entries.append({
                    "path": member,
                    "category": archive_sources[member]["category"],
                    "bytes": len(data),
                    "sha256": sha256(data),
                })

        archive_data = staged_archive.read_bytes()
        archive_hash = sha256(archive_data)
        with zipfile.ZipFile(staged_archive, "r") as bundle:
            if len(bundle.infolist()) != len(entries):
                raise RuntimeError("Archive entry count does not match the deterministic source list")
            if bundle.namelist() != sorted(archive_sources):
                raise RuntimeError("Archive entries do not match the deterministic source list")
            for entry in entries:
                data = bundle.read(entry["path"])
                if len(data) != entry["bytes"] or sha256(data) != entry["sha256"]:
                    raise RuntimeError(f"Archive verification failed for {entry['path']}")

        index = {
            "scope": "Collected participant final projects and terminal traces, result records, final F# scorer runs, and evidence tooling.",
            "interpretation": "The package records saved evidence; it does not itself decide acceptance or claim who executed a command.",
            "archive": archive.name,
            "bytes": len(archive_data),
            "sha256": archive_hash,
            "entryCount": len(entries),
            "entries": entries,
            "excluded": {
                "rules": [
                    "Directory path segments named bin or obj are build output and are omitted.",
                    "Directory path segments named artifacts or fresh-test-artifacts are build artifacts and are omitted.",
                    "Symlinked files are omitted.",
                ],
                "counts": dict(sorted(omitted.items())),
            },
        }
        index_data = (json.dumps(index, indent=2, sort_keys=True) + "\n").encode("utf-8")
        staged_index = Path(temp_dir) / index_path.name
        staged_archive_checksum = Path(temp_dir) / archive_checksum.name
        staged_index_checksum = Path(temp_dir) / index_checksum.name
        staged_index.write_bytes(index_data)
        staged_archive_checksum.write_bytes((archive_hash + "  results.zip\n").encode("ascii"))
        staged_index_checksum.write_bytes((sha256(index_data) + "  results-index.json\n").encode("ascii"))

        present = [path for path in destinations if path.exists()]
        if present:
            raise RuntimeError("Refusing to overwrite existing results output: " + ", ".join(map(str, present)))
        for staged, destination in zip(
            (staged_archive, staged_index, staged_archive_checksum, staged_index_checksum),
            destinations,
        ):
            os.replace(staged, destination)

    print(json.dumps({"entries": len(entries), "bytes": archive.stat().st_size,
                      "sha256": archive_hash, "verified": True}))


if __name__ == "__main__":
    main()

from pathlib import Path
import hashlib
import json

repo = Path(r'D:\code\AgentLang')
trial = repo / '.agentlang/maintenance-141'
study = repo / 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

checks = []
def check(label, passed):
    checks.append({'check': label, 'passed': passed})

freeze = read(study / 'dispatch/input-freeze.json')
for item in freeze['studyFiles']:
    check('frozen-study:' + item['path'], sha(study / item['path']) == item['sha256'])
build = read(trial / 'build-provenance.json')
for group, root in [('sources', repo), ('artifacts', trial)]:
    for item in build[group]:
        check('build-' + group + ':' + item['path'], sha(root / item['path']) == item['sha256'])
for actor in freeze['participants']:
    audit_path = trial / 'results' / actor['id'] / 'audit.json'
    if not audit_path.exists():
        check('completed-audit:' + actor['id'], False)
        continue
    audit = read(audit_path)
    project = Path(actor['project'])
    inventory = {p.relative_to(project).as_posix(): sha(p) for p in project.rglob('*')
                 if p.is_file() and not {'bin', 'obj'}.intersection(p.relative_to(project).parts)}
    check('post-grading-project-unchanged:' + actor['id'], inventory == audit['finalInventory'])
    check('post-grading-trace-unchanged:' + actor['id'],
          sha(project.parent / 'actor.trace.jsonl') == audit['traceSha256'])
result = {'passed': all(c['passed'] for c in checks), 'checks': checks}
(trial / 'results/input-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': result['passed'], 'checks': len(checks),
                  'failures': [c for c in checks if not c['passed']]}))
raise SystemExit(0 if result['passed'] else 1)

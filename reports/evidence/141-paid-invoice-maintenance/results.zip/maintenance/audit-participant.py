from pathlib import Path
import argparse
import collections
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument('participant')
args = parser.parse_args()
repo = Path(r'D:\code\AgentLang')
trial = repo / '.agentlang/maintenance-141'
study = repo / 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141'
actors = json.loads((study / 'dispatch/participants.json').read_text(encoding='utf-8-sig'))
actor = next(item for item in actors if item['id'] == args.participant)
project = Path(actor['project'])
trace_path = project.parent / 'actor.trace.jsonl'
trace = [json.loads(line) for line in trace_path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
if not trace or trace[-1].get('event') != 'session-end':
    raise RuntimeError('Participant has no terminal broker record; do not audit a live submission')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory(root):
    return {str(p.relative_to(root)).replace('\\', '/'): sha(p)
            for p in root.rglob('*') if p.is_file()
            and not {'bin', 'obj'}.intersection(p.relative_to(root).parts)}

freeze = json.loads((study / 'dispatch/input-freeze.json').read_text(encoding='utf-8-sig'))
before = {item['path']: item['sha256'] for participant in freeze['participants']
          if participant['id'] == args.participant for item in participant['files']}
after = inventory(project)
exchanges = [entry for entry in trace if entry.get('event') == 'exchange']
operations = collections.Counter(entry.get('operation') for entry in exchanges)
errors, validations, publications = [], [], []
for entry in exchanges:
    raw = (entry.get('response') or {}).get('rawLine')
    response = json.loads(raw) if raw else {}
    if entry.get('errorCode') or response.get('ok') is False:
        errors.append({'index': entry.get('index'), 'operation': entry.get('operation'),
                       'hostCode': entry.get('errorCode'), 'error': response.get('error')})
    if entry.get('operation') in ('validate', 'test-all', 'test'):
        validations.append({'index': entry.get('index'), 'operation': entry['operation'],
                            'ok': response.get('ok'), 'text': response.get('text'),
                            'data': response.get('data')})
    if entry.get('operation') in ('commit', 'replace-word', 'task.commit'):
        publications.append({'index': entry.get('index'), 'operation': entry['operation'],
                             'ok': response.get('ok'), 'text': response.get('text')})

result = {
    'participant': args.participant, 'traceSha256': sha(trace_path),
    'terminal': trace[-1], 'exchangeCount': len(exchanges), 'operations': dict(operations),
    'requestPayloadBytes': sum((e.get('request') or {}).get('payloadUtf8Bytes', 0) for e in exchanges),
    'responsePayloadBytes': sum((e.get('response') or {}).get('payloadUtf8Bytes', 0) for e in exchanges),
    'errors': errors, 'validations': validations, 'publications': publications,
    'sourceChanges': {'changed': sorted(p for p in before.keys() & after.keys() if before[p] != after[p]),
                      'added': sorted(after.keys() - before.keys()),
                      'removed': sorted(before.keys() - after.keys())},
    'finalInventory': after,
}

if actor['arm'] == 'flow-retained':
    def manifest(root):
        store = root / '.agentlang/store'
        current = json.loads((store / 'CURRENT').read_text(encoding='utf-8-sig'))
        path = store / 'manifests' / (current['manifestHash'] + '.json')
        if sha(path) != current['manifestHash']:
            raise RuntimeError('Manifest hash mismatch')
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        revisions = {(r['wordId'], r['revision']): r for r in data['revisions']}
        active = {w['currentName']: revisions[(w['wordId'], w['currentRevision'])] for w in data['words']}
        return data, active
    start_data, start_words = manifest(study / 'starts/flow-retained/project')
    end_data, end_words = manifest(project)
    changed = []
    for name in sorted(start_words.keys() & end_words.keys()):
        old, new = start_words[name], end_words[name]
        if old != new:
            old_tests = {t['hash'] for t in old['tests']}
            new_tests = {t['hash'] for t in new['tests']}
            changed.append({'name': name, 'identityPreserved': old['wordId'] == new['wordId'],
                            'oldRevision': old['revision'], 'newRevision': new['revision'],
                            'bodyChanged': old['definition'] != new['definition'],
                            'maturity': new['maturity'],
                            'removedTestHashes': sorted(old_tests - new_tests),
                            'addedTestHashes': sorted(new_tests - old_tests)})
    result['dictionary'] = {'typesUnchanged': start_data['types'] == end_data['types'],
                            'changed': changed, 'added': sorted(end_words.keys() - start_words.keys()),
                            'removed': sorted(start_words.keys() - end_words.keys()),
                            'fixtureUnchanged': start_words['maintenance141.fixture-import-payment'] == end_words.get('maintenance141.fixture-import-payment')}
else:
    start_source = (study / 'starts/fsharp/project/business/Business.fs').read_text(encoding='utf-8-sig')
    final_source = (project / 'business/Business.fs').read_text(encoding='utf-8-sig')
    def fixture(source):
        return source.split('        module Maintenance141Fixture =', 1)[1].split('    module Subscription =', 1)[0]
    result['fixtureUnchanged'] = fixture(start_source) == fixture(final_source)

out = trial / 'results' / args.participant
out.mkdir(parents=True, exist_ok=True)
(out / 'audit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'participant': args.participant, 'exchanges': len(exchanges),
                  'errors': len(errors), 'termination': trace[-1].get('terminationKind'),
                  'output': str(out / 'audit.json')}))

from pathlib import Path
import hashlib
import json
import zipfile

repo = Path(r'D:\code\AgentLang')
trial = repo / '.agentlang/maintenance-141'
study = repo / 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141'
out = repo / 'reports/evidence/141-paid-invoice-maintenance'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'preflight.zip'
if archive.exists():
    raise RuntimeError('Refusing to overwrite existing archive')
excluded_parts = {'bin', 'obj', 'temp', 'participants', 'runtime-artifacts',
                  'conventional-artifacts', 'baseline-fsharp-artifacts',
                  'correct-inherited-test-artifacts', 'baseline-check-flow',
                  'baseline-check-fsharp'}
files = {}
omitted = []
for root in (trial, study / 'starts', study / 'artifacts'):
    for path in root.rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in excluded_parts for part in relative.parts):
            omitted.append(str(path.relative_to(repo)).replace('\\', '/'))
            continue
        files[str(path.relative_to(repo)).replace('\\', '/')] = path
# The build's exact source inputs are retained independently of the checkout.
build = json.loads((trial / 'build-provenance.json').read_text(encoding='utf-8-sig'))
for item in build['sources']:
    source = repo / item['path']
    if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
        raise RuntimeError(f'Build source changed: {source}')
    files['source-snapshot/' + item['path'].replace('\\', '/')] = source
entries = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, source in sorted(files.items()):
        data = source.read_bytes()
        z.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
index = {'scope': 'Preflight only; all live participant project/output files excluded.',
         'archive': archive.name, 'bytes': archive.stat().st_size,
         'sha256': archive_hash, 'entryCount': len(entries), 'entries': entries,
         'omittedCount': len(omitted), 'omitted': sorted(omitted),
         'limits': 'Initial failed setup attempts were not all saved as complete raw responses. No reconstruction is claimed.'}
index_path = out / 'preflight-index.json'
index_path.write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
(out / 'preflight.sha256').write_text(archive_hash + '  preflight.zip\n', encoding='ascii')
(out / 'preflight-index.sha256').write_text(hashlib.sha256(index_path.read_bytes()).hexdigest() + '  preflight-index.json\n', encoding='ascii')
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == len(entries)
    assert set(z.namelist()) == {item['path'] for item in entries}
    for item in entries:
        data = z.read(item['path'])
        assert len(data) == item['bytes']
        assert hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'entries': len(entries), 'bytes': archive.stat().st_size,
                  'sha256': archive_hash, 'verified': True}))

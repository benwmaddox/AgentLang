namespace IntervalProof

module Period =
    type T = private { Start: int64; Finish: int64 }

    let tryCreate start finish =
        if start < finish then Some { Start = start; Finish = finish }
        else None

    let overlaps left right =
        left.Start < right.Finish && right.Start < left.Finish

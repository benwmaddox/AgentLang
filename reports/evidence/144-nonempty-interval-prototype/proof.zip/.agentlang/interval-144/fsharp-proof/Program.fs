open IntervalProof

let mutable checks = 0
let check name expected actual =
    checks <- checks + 1
    if expected <> actual then failwithf "%s expected %A, received %A" name expected actual

let occupied start finish = Set.ofList [ start .. finish - 1L ]

[<EntryPoint>]
let main _ =
    let bounds = [ -2L .. 2L ]
    let valid = [
        for a in bounds do
            for b in bounds do
                let points = occupied a b
                let candidate = Period.tryCreate a b
                check (sprintf "create %d %d" a b) (not (Set.isEmpty points)) candidate.IsSome
                match candidate with
                | Some period -> yield period, points
                | None -> ()
    ]
    for left, leftPoints in valid do
        for right, rightPoints in valid do
            check "intersection" (not (Set.isEmpty (Set.intersect leftPoints rightPoints))) (Period.overlaps left right)
    printfn "PASS %d checks: 25 constructor combinations and 100 interval pairs" checks
    0

open IntervalProof
let forged : Period.T = { Start = 2L; Finish = 1L }
[<EntryPoint>]
let main _ =
    printfn "%A" forged
    0

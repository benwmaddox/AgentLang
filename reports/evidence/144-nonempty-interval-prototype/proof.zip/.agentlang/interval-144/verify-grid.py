from pathlib import Path
import json,subprocess,hashlib,shutil
root=Path.cwd(); r=root/'.agentlang/interval-144'; src=r/'feasibility/flow-project-final'; out=r/'independent-grid'; out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inv(p):
 return {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file() and f.name.lower()!='write.lock'}
before=inv(src); copy=out/'project'; shutil.copytree(src,copy,ignore=shutil.ignore_patterns('WRITE.lock','write.lock'))
rows=[]; bounds=range(-2,3); valid=[]
for a in bounds:
 for b in bounds:
  points=set(range(a,b)); expected=bool(points)
  rows.append({'kind':'safe-constructor','inputs':[a,b],'expected':expected,'code':f'match interval::try-create({a}, {b}) {{ some value => {{ true }} none => {{ false }} }}'})
  rows.append({'kind':'direct-constructor','inputs':[a,b],'expected':expected,'code':f'interval::new(start = {a}, finish = {b})'})
  if expected: valid.append((a,b,points))
for a,b,left in valid:
 for c,d,right in valid:
  rows.append({'kind':'overlap','inputs':[a,b,c,d],'expected':bool(left&right),'code':f'interval::overlaps?(interval::new(start = {a}, finish = {b}), interval::new(start = {c}, finish = {d}))'})
requests=[{'op':'eval','frontend':'flow','syntaxVersion':2,'code':x['code']} for x in rows]; wire=''.join(json.dumps(x)+'\n' for x in requests); (out/'requests.jsonl').write_text(wire,encoding='utf-8')
cli=root/'.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'; cmd=['dotnet',str(cli),'--project',str(copy),'--jsonl']; proc=subprocess.run(cmd,input=wire,text=True,capture_output=True,cwd=root); (out/'stdout.jsonl').write_text(proc.stdout,encoding='utf-8'); (out/'stderr.txt').write_text(proc.stderr,encoding='utf-8'); responses=[json.loads(s) for s in proc.stdout.splitlines()]; assert len(rows)==len(responses)==150
for x,d in zip(rows,responses):
 if x['kind']=='direct-constructor':
  x['passed']=d.get('ok') and d.get('data',{}).get('stackTypes')==['Interval'] if x['expected'] else not d.get('ok') and d.get('error',{}).get('code')=='RECORD_VALIDATION_FAILED'
 else: x['passed']=d.get('ok') and d.get('data',{}).get('stack')==[str(x['expected']).lower()]
 x['response']=d
result={'cliSha256':sha(cli),'sourceSha256':sha(r/'feasibility/interval-feasibility.agent'),'command':cmd,'exitCode':proc.returncode,'inputUnchanged':before==inv(src),'sharedChecks':125,'additionalDirectConstructorChecks':25,'passed':sum(bool(x['passed']) for x in rows),'total':150,'cases':rows}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8'); (out/'input-hashes.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8'); print(json.dumps({k:v for k,v in result.items() if k!='cases'})); assert result['passed']==150 and result['inputUnchanged'] and proc.returncode==0

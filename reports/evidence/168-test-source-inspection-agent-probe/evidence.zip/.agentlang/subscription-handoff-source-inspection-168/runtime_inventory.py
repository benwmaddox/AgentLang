"""Verify the complete pinned 168 Release runtime before CLI execution."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
EXPECTED_SOURCE_PATHS = {
    "src/AgentLang.Core/Runtime.fs",
    "src/AgentLang.Core/AuthoringHelp.fs",
    "tests/AgentLang.Acceptance/Program.fs",
    "tests/AgentLang.Flow.Runtime.Tests/Program.fs",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def repo_path(value: str | Path) -> Path:
    path = Path(value)
    return (path if path.is_absolute() else REPO / path).resolve()


def runtime_inventory(directory: Path) -> dict[str, dict]:
    actual: dict[str, dict] = {}
    for path in sorted(item for item in directory.rglob("*") if item.is_file()):
        relative = path.relative_to(directory).as_posix()
        actual[relative] = {"bytes": path.stat().st_size, "sha256": sha256(path)}
    return actual


def verify_runtime_inventory(cli_arg: Path | None = None) -> dict:
    evidence_path = ROOT / "preparation-evidence.json"
    if not evidence_path.is_file():
        raise FileNotFoundError(f"168 preparation evidence is missing: {evidence_path}")
    evidence = load_json(evidence_path)
    if evidence.get("fullGatePassed") is not True:
        raise RuntimeError("168 preparation evidence does not record a passing full gate")
    if evidence.get("fullGateCheckCount") != 37 or evidence.get("fullGateAllExitCodesZero") is not True:
        raise RuntimeError("168 preparation evidence must record 37 successful checks with exit code 0")
    commit = evidence.get("milestone167Commit", "")
    if not re.fullmatch(r"[0-9a-fA-F]{40,64}", commit):
        raise RuntimeError("168 preparation evidence has no full milestone-167 commit SHA")
    gate_path = repo_path(evidence["fullGateReport"])
    source_pin_path = repo_path(evidence["postBuildSourcePin"])
    terminal_evidence_value = evidence.get("milestone167TerminalEvidence")
    if terminal_evidence_value:
        terminal_evidence_path = repo_path(terminal_evidence_value)
        if (
            not terminal_evidence_path.is_file()
            or sha256(terminal_evidence_path) != evidence.get("milestone167TerminalEvidenceSha256")
        ):
            raise RuntimeError("Root-provided terminal evidence changed after 168 preparation")
        terminal = load_json(terminal_evidence_path)
        if (
            terminal.get("sessionId") != 97238
            or str(terminal.get("sessionStatus", "")).lower() not in {"terminal", "completed", "complete"}
            or terminal.get("fullGatePassed") is not True
            or terminal.get("fullGateCheckCount") != 37
            or terminal.get("allExitCodesZero") is not True
            or terminal.get("milestone167Pushed") is not True
            or str(terminal.get("milestone167Commit", "")).lower() != commit.lower()
            or repo_path(terminal.get("fullGateReport", "")) != gate_path
            or repo_path(terminal.get("postBuildSourcePin", "")) != source_pin_path
        ):
            raise RuntimeError("Root-provided terminal evidence no longer records the completed, pushed 167 gate")

    if not gate_path.is_file() or sha256(gate_path) != evidence.get("fullGateReportSha256"):
        raise RuntimeError("The validated full-gate report changed after 168 preparation")
    gate = load_json(gate_path)
    checks = gate.get("checks")
    if (
        gate.get("passed") is not True
        or not gate.get("completedAt")
        or not isinstance(checks, list)
        or len(checks) != 37
        or any(row.get("exitCode") != 0 for row in checks)
        or str(gate.get("configuration", "Release")).lower() != "release"
    ):
        raise RuntimeError("The saved full-gate report is incomplete, failed, or not a Release gate")

    if not source_pin_path.is_file() or sha256(source_pin_path) != evidence.get("postBuildSourcePinSha256"):
        raise RuntimeError("The post-build source pin changed after 168 preparation")
    source_pin = load_json(source_pin_path)
    source_rows = source_pin.get("files", [])
    if {row.get("path") for row in source_rows} != EXPECTED_SOURCE_PATHS:
        raise RuntimeError("The post-build source pin must contain exactly the four milestone source files")
    for row in source_rows:
        source = REPO / row["path"]
        if not source.is_file() or sha256(source) != row.get("sha256"):
            raise RuntimeError(f"Validated source changed since the post-build pin: {source}")

    runtime_dir = (ROOT / "runtime" / "flow").resolve()
    if Path(evidence.get("runtimePinnedDirectory", "")).resolve() != runtime_dir:
        raise RuntimeError("The recorded pinned runtime directory is not the 168 Release runtime")
    cli = (cli_arg.expanduser().resolve() if cli_arg else runtime_dir / "AgentLang.Cli.dll")
    if cli != runtime_dir / "AgentLang.Cli.dll":
        raise RuntimeError(f"Use the exact pinned 168 CLI: {runtime_dir / 'AgentLang.Cli.dll'}")

    pinned_rows = evidence.get("runtimeFiles")
    if not isinstance(pinned_rows, list) or not pinned_rows:
        raise RuntimeError("The preparation evidence has no complete runtime inventory")
    pinned: dict[str, dict] = {}
    for row in pinned_rows:
        relative = row.get("path")
        if not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise RuntimeError(f"Invalid path in pinned runtime inventory: {relative!r}")
        if relative in pinned:
            raise RuntimeError(f"Duplicate path in pinned runtime inventory: {relative}")
        pinned[relative] = {"bytes": row.get("bytes"), "sha256": row.get("sha256")}
    if "AgentLang.Cli.dll" not in pinned or "AgentLang.Core.dll" not in pinned:
        raise RuntimeError("Pinned runtime inventory must include both AgentLang.Cli.dll and AgentLang.Core.dll")

    actual = runtime_inventory(runtime_dir)
    missing = sorted(set(pinned) - set(actual))
    extra = sorted(set(actual) - set(pinned))
    changed = sorted(path for path in set(pinned) & set(actual) if pinned[path] != actual[path])
    if missing or extra or changed:
        raise RuntimeError(
            "The pinned runtime directory differs from its complete inventory: "
            f"missing={missing[:8]}, extra={extra[:8]}, changed={changed[:8]}"
        )
    return {
        "runtimeDirectory": str(runtime_dir),
        "runtimeFileCount": len(actual),
        "cliSha256": actual["AgentLang.Cli.dll"]["sha256"],
        "coreSha256": actual["AgentLang.Core.dll"]["sha256"],
        "fullGateCheckCount": len(checks),
        "milestone167Commit": commit,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", type=Path, help="Optional explicit path; must equal the pinned 168 CLI")
    args = parser.parse_args()
    print(json.dumps({"status": "verified", **verify_runtime_inventory(args.cli)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Execution notes for the 168 Flow probe

Run every command from `D:\code\AgentLang`. No command below is authorized
before full-gate session 97238 is terminal, all 37 checks pass with exit code
0, the four pinned source hashes remain unchanged, and milestone 167 has been
committed and pushed. `prepare_probe.py` is deliberately gated and is not run
during preparation of this file.

## Prepare after milestone 167

The preferred mode takes a root-provided terminal evidence JSON. It must contain
the terminal session, gate, push, commit, and evidence paths shown here; the
script independently re-reads the gate report and verifies every source hash.

```json
{
  "sessionId": 97238,
  "sessionStatus": "terminal",
  "fullGatePassed": true,
  "fullGateCheckCount": 37,
  "allExitCodesZero": true,
  "milestone167Pushed": true,
  "milestone167Commit": "<full 40-character commit SHA>",
  "fullGateReport": ".agentlang/test-source-inspection-167/full-validation-final.json",
  "postBuildSourcePin": ".agentlang/test-source-inspection-167/post-build-source-pin.json"
}
```

```powershell
python .agentlang/subscription-handoff-source-inspection-168/prepare_probe.py --terminal-evidence .agentlang/subscription-handoff-source-inspection-168/terminal-evidence.json
```

The alternate mode accepts the full milestone commit SHA and defaults to the
standard 167 report and source-pin paths:

```powershell
python .agentlang/subscription-handoff-source-inspection-168/prepare_probe.py --milestone-commit <full-40-character-commit-SHA> --gate-report .agentlang/test-source-inspection-167/full-validation-final.json --source-pin .agentlang/test-source-inspection-167/post-build-source-pin.json
```

Preparation verifies the 166 frozen seed inventory before copying, copies the
complete Release CLI output identified by the successful gate build, adapts
only launch paths in the copied public prompt and broker config, and records
all 168 input/runtime hashes. It refuses existing output directories. The
runtime checker revalidates all runtime files, the gate report, and four pinned
source files immediately before scoring or launch; `AgentLang.Core.dll` is
included because it defines execution semantics.

The copied scorer comes from
`experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/score_agentlang.py`.
Its only source change is this evidence-root line:

```diff
- EVIDENCE_ROOT = REPO / ".agentlang" / "subscription-handoff-maintenance-166"
+ EVIDENCE_ROOT = REPO / ".agentlang" / "subscription-handoff-source-inspection-168"
```

Original scorer SHA-256:
`ff4f004340d8279d9b0616ba44c4d3fbb4fb650be1785599639055d36110c351`.
Copied 168 scorer SHA-256:
`22f629823d3cdfaab5a34e1f44c600095d9a1d05619b82a67f1768e04006b2b4`.
Control projects are copied from the three prepared report-166 project
directories named in the calibration section below; their exact file/hash
inventories are recorded in the 168 calibration summary.

## Calibrate the controls

This copies the already prepared report-166 project trees byte-for-byte into
168 and runs the copied grader against those copies only. It does not recreate
or rewrite the saved target, callers, or tests. Each scored control has 132
checks: 66 target cases and 66 retained-caller cases. Expected results are:
correct 132/132 passed; skip-dry-run-creation-validation 16 target failures
(116/132 passed), both callers 66/66; return-updated-store-on-dry-run 10 target
failures (122/132 passed), both callers 66/66. The run records each target and
caller result separately. These are inherited report-166 project-maturity
behavioral controls in their original control domain and do not qualify as
library-maturity evidence.

```powershell
python .agentlang/subscription-handoff-source-inspection-168/runtime_inventory.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll
python .agentlang/subscription-handoff-source-inspection-168/calibrate_controls.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll
```

Do not start the participant unless the summary under
`.agentlang/subscription-handoff-source-inspection-168/control/flow/` records
all three expected classifications, 132 checks per control, and the 16/10
fault counts.

## Launch the one Flow participant

Use the copied `prompt-flow.md` and this single broker process. It keeps the
report-166 public operation list, timeout, and 100-exchange ceiling. The fresh
participant works only in the isolated Flow actor project through this broker.

```powershell
python .agentlang/subscription-handoff-source-inspection-168/runtime_inventory.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll
$env:TEMP = 'D:\code\AgentLang\.agentlang\subscription-handoff-source-inspection-168\tmp-flow'
$env:TMP = $env:TEMP
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\subscription-handoff-source-inspection-168\runtime\flow\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\subscription-handoff-source-inspection-168\actors\flow' -TracePath 'D:\code\AgentLang\.agentlang\subscription-handoff-source-inspection-168\trace-flow.jsonl' -AllowedOperations @('help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort') -Profile 'agentlang' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

Wait for this run to finish before any scoring or validation. Save unsuccessful
attempts and protocol recovery in the same 168 evidence root.

## Score and finalize the saved participant project

The grader's `correct` role denotes the expected behavior contract for this
saved participant. It checks the actual saved target plus both retained callers
and writes all run evidence under 168.

```powershell
python .agentlang/subscription-handoff-source-inspection-168/runtime_inventory.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll
python experiments/AgentLang.SubagentTrials/subscription-handoff-source-inspection-168/oracle/score_agentlang.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll --actor-project .agentlang/subscription-handoff-source-inspection-168/actors/flow --role correct --label participant-001
python .agentlang/subscription-handoff-source-inspection-168/validate_participant.py --cli .agentlang/subscription-handoff-source-inspection-168/runtime/flow/AgentLang.Cli.dll
```

The second command runs all attached tests on a copy, checks that no task is
left active, and confirms all three operations have library maturity. These
results describe participant-authored coverage and finalization; the independent
grader remains the behavior oracle.

## Preservation review and trace inspection

The old audit is read-only with respect to its seed and participant. Every
Flow path and the output path are explicit. The copied conventional seed fills
both conventional slots, so call it a baseline self-comparison in any report.

```powershell
python .agentlang/subscription-handoff-maintenance-166/audit-preservation.py --flow-seed .agentlang/subscription-handoff-source-inspection-168/seeds/agentlang-project --flow-actor .agentlang/subscription-handoff-source-inspection-168/actors/flow --conventional-seed .agentlang/subscription-handoff-source-inspection-168/seeds/conventional --conventional-actor .agentlang/subscription-handoff-source-inspection-168/seeds/conventional --output .agentlang/subscription-handoff-source-inspection-168/preservation-review
rg -n 'includeSource|caseName|"op":"tests"|"op":"test"' .agentlang/subscription-handoff-source-inspection-168/trace-flow.jsonl
```

Manually read `preservation-review/flow-source-review.md` and verify all five
prior case keys: `creation-rules-follow-cancellation`,
`cancellation-rules-precede-creation`, `success`,
`blank-term-after-cancellation`, and `missing-old-precedes-creation`. In
`success`, require explicit assertions that the pre-call old subscription is
active and uncancelled. In `missing-old-precedes-creation`, require the existing
replacement ID `30000000-0000-0000-0000-000000000001` and
`SUBSCRIPTION_NOT_FOUND`. Check whether source/tests inspection happened before
the relevant edits by aligning those trace exchanges with the participant's
first authoring exchange. Do not infer a fixed token limit from broker bytes.

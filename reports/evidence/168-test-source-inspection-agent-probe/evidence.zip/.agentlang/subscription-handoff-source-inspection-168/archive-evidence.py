"""Archive completed probe evidence without binaries or disposable scoring copies."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
destination = repo / "reports/evidence/168-test-source-inspection-agent-probe"
assert not destination.exists(), "Do not overwrite published evidence"
assert (root / "outcome.json").is_file(), "Complete review before publication"
freeze = json.loads((root / "freeze/inventory.json").read_text(encoding="utf-8"))
paths = set()
for path in root.rglob("*"):
    if not path.is_file():
        continue
    relative = path.relative_to(root)
    if relative.parts[0] in {"runtime", "tmp-flow", "tmp-final-validation", "freeze"}:
        continue
    if "actor-project-copy" in relative.parts or "project" in relative.parts:
        continue
    if "__pycache__" in relative.parts:
        continue
    paths.add(path)
paths.add(root / "freeze/inventory.json")
for entry in freeze["files"]:
    if entry["kind"] != "runtime":
        blob = root / "freeze" / entry["blob"]
        assert hashlib.sha256(blob.read_bytes()).hexdigest() == entry["sha256"]
        paths.add(blob)
for name in ("cases.json", "model.py", "score_agentlang.py"):
    paths.add(repo / "experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle" / name)
paths.add(repo / ".agentlang/subscription-handoff-maintenance-166/audit-preservation.py")
for path in (repo / "experiments/AgentLang.SubagentTrials/subscription-handoff-source-inspection-168").rglob("*"):
    if path.is_file() and "__pycache__" not in path.parts:
        paths.add(path)
entries = [{"path": path.relative_to(repo).as_posix(), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(paths)]
destination.mkdir(parents=True)
archive = destination / "evidence.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
    for path in sorted(paths):
        output.write(path, path.relative_to(repo).as_posix())
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    assert sorted(saved.namelist()) == sorted(entry["path"] for entry in entries)
    for entry in entries:
        content = saved.read(entry["path"])
        assert len(content) == entry["bytes"]
        assert hashlib.sha256(content).hexdigest() == entry["sha256"]
manifest = {"status": "verified", "description": "Single fresh language probe; includes failed setup and calibrated controls. Runtime binaries and disposable scoring copies excluded; runtime hashes retained.",
            "archive": {"path": archive.name, "bytes": archive.stat().st_size,
                        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, "files": entries}
(destination / "archive.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(manifest["archive"]))

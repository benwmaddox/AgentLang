"""Copy the frozen report-166 Flow projects and score only the 168 copies."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from runtime_inventory import verify_runtime_inventory


REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
EXPERIMENT = REPO / "experiments" / "AgentLang.SubagentTrials" / "subscription-handoff-source-inspection-168"
OLD_CONTROL_ROOT = REPO / ".agentlang" / "subscription-handoff-maintenance-166" / "control" / "flow"
SCORER = EXPERIMENT / "oracle" / "score_agentlang.py"
CONTROL_DOMAIN = (
    "Inherited report-166 project-maturity behavioral controls; their calibration establishes "
    "expected behavior in that control domain and does not establish library maturity."
)
CONTROLS = (
    ("correct", 0, "correct-control", "correct", "ok"),
    ("skip-dry-run-creation-validation", 16, "fault-behavior-rejected", "skip-dry-run-creation-validation", "skip"),
    ("return-updated-store-on-dry-run", 10, "fault-behavior-rejected", "return-updated-store-on-dry-run", "changed"),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def tree_inventory(root: Path) -> list[dict]:
    if not root.is_dir():
        raise FileNotFoundError(f"Control project is missing: {root}")
    rows = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        rows.append({
            "path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        })
    if not rows:
        raise RuntimeError(f"Control project contains no files: {root}")
    return rows


def require_same_tree(source: Path, destination: Path) -> list[dict]:
    source_files = tree_inventory(source)
    copied_files = tree_inventory(destination)
    if source_files != copied_files:
        raise RuntimeError(f"Copied control is not byte-identical to its frozen source: {source} -> {destination}")
    return source_files


def validate_score(report: dict, role: str, target_failures: int, classification: str,
                   project: Path, cli: Path, scorer_hash: str) -> dict:
    if report.get("status") != "passed" or report.get("controlRole") != role:
        raise RuntimeError(f"{role} scorer did not complete with the requested role/status")
    if Path(report.get("actorProject", "")).resolve() != project.resolve():
        raise RuntimeError(f"{role} scorer did not use the copied control project")
    if Path(report.get("runtime", "")).resolve() != cli.resolve():
        raise RuntimeError(f"{role} scorer did not use the pinned 168 CLI")
    if report.get("runtimeSha256") != sha256(cli) or report.get("scorerSha256") != scorer_hash:
        raise RuntimeError(f"{role} scorer used an unexpected CLI or scorer copy")
    run_dir = Path(report.get("runDirectory", "")).resolve()
    if not run_dir.is_relative_to(ROOT.resolve()) or not (run_dir / "score.json").is_file():
        raise RuntimeError(f"{role} scorer evidence did not stay under the 168 root")
    if report.get("cliExitCode") != 0 or report.get("setupFailure") is not None:
        raise RuntimeError(f"{role} scorer had a CLI or setup error")
    if report.get("targetIdentityUnchanged") is not True or report.get("persistentStateUnchanged") is not True:
        raise RuntimeError(f"{role} scorer changed the saved target or copied persistent state")

    target = report.get("target", {})
    callers = report.get("retainedCallers", {})
    behavior = report.get("behaviorCheck", {})
    expected_target_passes = 66 - target_failures
    if (
        target.get("expectedCaseCount") != 66
        or target.get("executedCaseCount") != 66
        or target.get("passedCaseCount") != expected_target_passes
        or target.get("behaviorFailureCount") != target_failures
        or target.get("setupErrorCount") != 0
        or report.get("retainedCallerCaseCount") != 66
        or set(callers) != {"renew-annual", "renew-monthly"}
        or any(
            callers[name].get("score", {}).get("expectedCaseCount") != 33
            or callers[name].get("score", {}).get("executedCaseCount") != 33
            or callers[name].get("score", {}).get("passedCaseCount") != 33
            or callers[name].get("score", {}).get("behaviorFailureCount") != 0
            or callers[name].get("score", {}).get("setupErrorCount") != 0
            for name in callers
        )
        or behavior.get("passed") is not True
        or behavior.get("classification") != classification
    ):
        raise RuntimeError(f"{role} scorer did not retain its expected 66 target and 66 caller results")

    caller_passed = sum(row["score"]["passedCaseCount"] for row in callers.values())
    total_passed = target["passedCaseCount"] + caller_passed
    if total_passed != 132 - target_failures:
        raise RuntimeError(f"{role} total pass count does not match its expected target failures")
    return {
        "controlRole": role,
        "status": report["status"],
        "totalChecks": target["executedCaseCount"] + report["retainedCallerCaseCount"],
        "totalPassed": total_passed,
        "target": target,
        "retainedCallers": {name: row["score"] for name, row in callers.items()},
        "behaviorCheck": behavior,
        "runDirectory": str(run_dir),
        "scoreReport": str(run_dir / "score.json"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", type=Path, required=True)
    args = parser.parse_args()
    cli = args.cli.expanduser().resolve()
    pinned = verify_runtime_inventory(cli)
    preparation = load_json(ROOT / "preparation-evidence.json")
    if preparation.get("participantDispatched") is not False or preparation.get("brokerLaunched") is not False:
        raise RuntimeError("Participant or broker evidence already exists; this is no longer the pre-dispatch calibration step")
    if preparation.get("calibrationRun") is not False:
        raise RuntimeError("Preparation evidence does not indicate that control calibration is pending")
    expected_sources = [
        OLD_CONTROL_ROOT / name
        for name, _, _, _, _ in CONTROLS
    ]
    recorded_sources = [Path(row["path"]).resolve() for row in preparation.get("calibrationControlProjectSources", [])]
    if recorded_sources != [path.resolve() for path in expected_sources]:
        raise RuntimeError("Preparation evidence does not identify the three frozen report-166 control projects")
    if not SCORER.is_file() or not (ROOT / "flow-callers.agent").is_file():
        raise FileNotFoundError("The copied 168 scorer or frozen coordinator callers are missing")
    scorer_hash = sha256(SCORER)
    if scorer_hash != preparation.get("scorerSha256"):
        raise RuntimeError("The copied scorer differs from its recorded 168 preparation hash")
    if 'EVIDENCE_ROOT = REPO / ".agentlang" / "subscription-handoff-source-inspection-168"' not in SCORER.read_text(encoding="utf-8"):
        raise RuntimeError("The copied grader does not write to the 168 evidence root")

    control_root = ROOT / "control" / "flow"
    if control_root.exists():
        raise RuntimeError(f"Refusing to overwrite prior 168 control output: {control_root}")
    control_root.mkdir(parents=True)
    scoring_root = control_root / "scoring"
    scoring_root.mkdir()
    temp_root = ROOT / "tmp-control-score"
    temp_root.mkdir(exist_ok=True)
    environment = dict(os.environ)
    environment["TEMP"] = str(temp_root)
    environment["TMP"] = str(temp_root)

    results = []
    for name, expected_failures, classification, role, label in CONTROLS:
        source = OLD_CONTROL_ROOT / name
        destination = control_root / name
        source_inventory = tree_inventory(source)
        shutil.copytree(source, destination)
        copied_inventory = require_same_tree(source, destination)

        # Recheck gate, source pins, and every runtime file immediately before
        # each scoring run. The scorer creates and mutates its own run copy.
        runtime_check = verify_runtime_inventory(cli)
        if runtime_check["coreSha256"] != pinned["coreSha256"]:
            raise RuntimeError("AgentLang.Core.dll changed before control scoring")
        command = [
            sys.executable, str(SCORER), "--cli", str(cli), "--actor-project", str(destination),
            "--role", role, "--label", label,
        ]
        process = subprocess.run(
            command, cwd=REPO, env=environment, text=True, encoding="utf-8",
            capture_output=True, timeout=900, check=False,
        )
        invocation_dir = scoring_root / name
        invocation_dir.mkdir()
        (invocation_dir / "stdout.json").write_text(process.stdout, encoding="utf-8", newline="\n")
        (invocation_dir / "stderr.txt").write_text(process.stderr, encoding="utf-8", newline="\n")
        (invocation_dir / "command.json").write_text(json.dumps({
            "command": command,
            "exitCode": process.returncode,
            "actorProject": str(destination),
            "sourceProject": str(source),
            "runtimeInventory": runtime_check,
        }, indent=2) + "\n", encoding="utf-8", newline="\n")
        if process.returncode != 0:
            raise RuntimeError(f"{name} copied scorer exited {process.returncode}; see {invocation_dir}")
        try:
            summary_report = json.loads(process.stdout)
        except json.JSONDecodeError as error:
            raise RuntimeError(f"{name} scorer stdout is not its expected JSON report; see {invocation_dir}") from error
        run_dir = Path(summary_report["runDirectory"]).resolve()
        if not run_dir.is_relative_to(ROOT.resolve()):
            raise RuntimeError(f"{name} grader wrote outside the 168 root: {run_dir}")
        full_report = load_json(run_dir / "score.json")
        score_summary = validate_score(full_report, role, expected_failures, classification, destination, cli, scorer_hash)
        if tree_inventory(destination) != copied_inventory:
            raise RuntimeError(f"The scorer changed the saved {name} control project")
        if tree_inventory(source) != source_inventory:
            raise RuntimeError(f"The frozen report-166 {name} control changed during scoring")
        results.append({
            "sourceProject": str(source),
            "copiedProject": str(destination),
            "byteIdenticalCopy": True,
            "fileCount": len(copied_inventory),
            "files": copied_inventory,
            "expectedTargetFailures": expected_failures,
            **score_summary,
            "invocationEvidence": str(invocation_dir),
        })

    summary = {
        "status": "passed",
        "runtime": str(cli),
        "runtimeInventory": pinned,
        "controlDomain": CONTROL_DOMAIN,
        "checksPerControl": 132,
        "expected": {
            "correct": {"targetFailures": 0, "totalPassed": 132},
            "skip-dry-run-creation-validation": {"targetFailures": 16, "totalPassed": 116},
            "return-updated-store-on-dry-run": {"targetFailures": 10, "totalPassed": 122},
        },
        "controls": results,
    }
    summary_path = control_root / "calibration-summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": summary["status"],
        "runtimeFileCount": pinned["runtimeFileCount"],
        "coreSha256": pinned["coreSha256"],
        "controls": [
            {"role": row["controlRole"], "checks": row["totalChecks"], "passed": row["totalPassed"],
             "targetFailures": row["target"]["behaviorFailureCount"], "classification": row["behaviorCheck"]["classification"]}
            for row in results
        ],
        "summary": str(summary_path),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Record observed protocol use separately from behavior and source preservation."""
from datetime import datetime
import json
from pathlib import Path

from runtime_inventory import verify_runtime_inventory

root = Path(__file__).resolve().parent
runtime = verify_runtime_inventory()
rows = [json.loads(line) for line in (root / "trace-flow.jsonl").read_text(encoding="utf-8-sig").splitlines()]
exchanges = [row for row in rows if row["event"] == "exchange"]
end = rows[-1]
assert end["event"] == "session-end" and end["hostExitCode"] == 0 and end["runtimeExitCode"] == 0
tests = []
failures = []
first_edit = min(row["index"] for row in exchanges if row["operation"] in {"define", "replace-word"})
for row in exchanges:
    request = json.loads(row["request"]["canonical"])
    response = json.loads(row["response"]["rawLine"])
    if row["operation"] == "tests":
        tests.append({"exchange": row["index"], "request": request, "beforeFirstEdit": row["index"] < first_edit})
    if response.get("ok") is not True:
        failures.append({"exchange": row["index"], "operation": row["operation"], "response": response})
score = json.loads(next((root / "flow-oracle-runs").glob("*-p-01/score.json")).read_text(encoding="utf-8"))
assert score["status"] == "passed" and score["target"]["passedCaseCount"] == 66
assert sum(item["score"]["passedCaseCount"] for item in score["retainedCallers"].values()) == 66
final = json.loads((root / "final-validation/summary.json").read_text(encoding="utf-8"))
assert final["status"] == "passed" and final["attachedTestCount"] == 150
audit = json.loads((root / "preservation-review/report.json").read_text(encoding="utf-8"))
assert not audit["failedChecks"]
summary = {"status": "behavior-passed-preservation-incomplete", "runtimeInventory": runtime,
           "model": "gpt-6-luna", "reasoning": "max", "freshContext": True,
           "exchangeCount": len(exchanges), "firstEditExchange": first_edit,
           "testsQueries": tests, "failedResponses": failures,
           "caseNameUsed": any("caseName" in item["request"] for item in tests),
           "requestPayloadBytes": sum(row["request"]["payloadUtf8Bytes"] for row in exchanges),
           "responsePayloadBytes": sum(row["response"]["payloadUtf8Bytes"] for row in exchanges),
           "brokerDurationSeconds": (datetime.fromisoformat(end["finishedUtc"]) - datetime.fromisoformat(rows[0]["startedUtc"])).total_seconds(),
           "brokerTermination": end, "independentTargetPassed": 66, "independentCallerPassed": 66,
           "attachedTestsPassed": 150, "mechanicalPreservationChecks": audit["machineCheckCount"],
           "manualPreservation": {"missingOldCompetingDuplicateIdRetained": True,
                                  "successPreStateActiveAssertionRetained": False,
                                  "successPreStateUncancelledAssertionRetained": False,
                                  "successPostStateAndUnrelatedDataAssertionsRetained": True,
                                  "otherThreePriorErrorCasesRetained": True,
                                  "callerTestsByteIdentical": True},
           "newConventionalParticipant": False, "fixedTokenContextLimit": None,
           "interpretation": "Natural discovery observed; prior assertion preservation still incomplete. No causal or comparative reliability claim."}
(root / "outcome.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: summary[key] for key in ["status", "exchangeCount", "firstEditExchange", "requestPayloadBytes", "responsePayloadBytes", "brokerDurationSeconds", "testsQueries"]}, indent=2))

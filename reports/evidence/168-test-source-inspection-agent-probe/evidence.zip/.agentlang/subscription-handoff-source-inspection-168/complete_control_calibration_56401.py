"""Finish only session 56401's two remaining Flow control scores."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from calibrate_controls import (  # noqa: E402
    OLD_CONTROL_ROOT,
    ROOT,
    REPO,
    SCORER,
    load_json,
    sha256,
    tree_inventory,
    validate_score,
)
from runtime_inventory import verify_runtime_inventory  # noqa: E402


CLI = ROOT / "runtime" / "flow" / "AgentLang.Cli.dll"
CONTROL_ROOT = ROOT / "control" / "flow"
CORRECT_COPY = CONTROL_ROOT / "correct"
SKIP_COPY = CONTROL_ROOT / "skip-dry-run-creation-validation"
CHANGED_SOURCE = OLD_CONTROL_ROOT / "return-updated-store-on-dry-run"
CHANGED_COPY = CONTROL_ROOT / "return-updated-store-on-dry-run"
FAILURE_LOG_DIR = CONTROL_ROOT / "scoring" / "skip-dry-run-creation-validation"
FAILURE_RECORD = CONTROL_ROOT / "calibration-failure-56401.json"
SUMMARY_PATH = CONTROL_ROOT / "calibration-summary.json"
RESUMED_LOG_ROOT = CONTROL_ROOT / "resumed-scoring-56401"
TEMP_ROOT = ROOT / "tmp-calibration-resume-56401"


def require_same_tree(source: Path, copy: Path) -> list[dict]:
    source_files = tree_inventory(source)
    copy_files = tree_inventory(copy)
    if source_files != copy_files:
        raise RuntimeError(f"Saved control copy differs from its source: {source} -> {copy}")
    return copy_files


def verify_existing_correct(runtime_pin: dict, scorer_hash: str) -> dict:
    runtime_now = verify_runtime_inventory(CLI)
    if runtime_now != runtime_pin:
        raise RuntimeError("Pinned runtime changed while revalidating the saved correct score")
    log_dir = CONTROL_ROOT / "scoring" / "correct"
    command = load_json(log_dir / "command.json")
    stdout_report = load_json(log_dir / "stdout.json")
    if command.get("exitCode") != 0 or Path(command["actorProject"]).resolve() != CORRECT_COPY.resolve():
        raise RuntimeError("Saved correct-control invocation is not a successful score of the 168 copy")
    run_dir = Path(stdout_report["runDirectory"]).resolve()
    if not run_dir.is_relative_to(ROOT.resolve()):
        raise RuntimeError("Saved correct-control output points outside the 168 root")
    full_report = load_json(run_dir / "score.json")
    if stdout_report.get("runDirectory") != full_report.get("runDirectory"):
        raise RuntimeError("Saved correct-control stdout and score file disagree about the run directory")
    if stdout_report.get("status") != "passed" or stdout_report.get("controlRole") != "correct":
        raise RuntimeError("Saved correct-control stdout is not a passing correct-control result")
    saved_files = require_same_tree(OLD_CONTROL_ROOT / "correct", CORRECT_COPY)
    summary = validate_score(full_report, "correct", 0, "correct-control", CORRECT_COPY, CLI, scorer_hash)
    summary.update({
        "sourceProject": str(OLD_CONTROL_ROOT / "correct"),
        "copiedProject": str(CORRECT_COPY),
        "byteIdenticalCopy": True,
        "fileCount": len(saved_files),
        "alreadyCompletedInSession56401": True,
        "invocationEvidence": str(log_dir),
    })
    return summary


def record_initial_setup_failure() -> dict:
    command_path = FAILURE_LOG_DIR / "command.json"
    stdout_path = FAILURE_LOG_DIR / "stdout.json"
    stderr_path = FAILURE_LOG_DIR / "stderr.txt"
    command_record = load_json(command_path)
    stderr = stderr_path.read_text(encoding="utf-8", errors="replace")
    args = command_record.get("command", [])
    if (
        command_record.get("exitCode") != 1
        or command_record.get("actorProject") != str(SKIP_COPY)
        or not args
        or args[-1] != "control-skip-dry-run-creation-validation"
        or "shutil.copytree(actor_project, project)" not in stderr
        or "WinError 3" not in stderr
        or stdout_path.stat().st_size != 0
    ):
        raise RuntimeError("The retained session-56401 failure does not match the reported pre-CLI copytree error")

    partial_dirs = sorted(
        path for path in (ROOT / "flow-oracle-runs").iterdir()
        if path.is_dir() and "control-skip-dry-run-creation-validation" in path.name
    )
    if not partial_dirs:
        raise RuntimeError("The failed session-56401 partial grader run is missing")
    partial_run = partial_dirs[-1]
    if any((partial_run / name).exists() for name in ("requests.jsonl", "responses.jsonl", "score.json")):
        raise RuntimeError("The session-56401 partial run contains CLI scoring outputs; do not classify it as pre-CLI")

    retained = {
        "sessionId": 56401,
        "status": "setup-failure-before-cli",
        "classification": "not-a-behavioral-result",
        "detail": "The grader's saved-project copy failed in shutil.copytree with WinError 3 on the long evidence path; no CLI scoring began.",
        "actorProject": str(SKIP_COPY),
        "originalLabel": args[-1],
        "exitCode": command_record["exitCode"],
        "cliStarted": False,
        "stdoutPath": str(stdout_path),
        "stderrPath": str(stderr_path),
        "stderrSha256": sha256(stderr_path),
        "partialRunDirectory": str(partial_run),
        "partialRunPreserved": True,
        "partialCliOutputsAbsent": True,
    }
    if FAILURE_RECORD.exists():
        raise RuntimeError(f"Refusing to overwrite retained failure record: {FAILURE_RECORD}")
    FAILURE_RECORD.write_text(json.dumps(retained, indent=2) + "\n", encoding="utf-8", newline="\n")
    return retained


def score_saved_copy(project: Path, role: str, label: str, target_failures: int,
                     classification: str, runtime_pin: dict, scorer_hash: str) -> dict:
    invocation_dir = RESUMED_LOG_ROOT / label
    if invocation_dir.exists():
        raise RuntimeError(f"Refusing to overwrite resumed score evidence: {invocation_dir}")
    runtime_before = verify_runtime_inventory(CLI)
    if runtime_before != runtime_pin:
        raise RuntimeError(f"Pinned runtime changed before {label} scoring")
    command = [
        sys.executable, str(SCORER), "--cli", str(CLI), "--actor-project", str(project),
        "--role", role, "--label", label,
    ]
    invocation_dir.mkdir(parents=True)
    temp = TEMP_ROOT
    temp.mkdir(exist_ok=True)
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["TEMP"] = str(temp)
    environment["TMP"] = str(temp)
    process = subprocess.run(
        command, cwd=REPO, env=environment, text=True, encoding="utf-8",
        capture_output=True, timeout=900, check=False,
    )
    stdout_path = invocation_dir / "stdout.json"
    stderr_path = invocation_dir / "stderr.txt"
    stdout_path.write_text(process.stdout, encoding="utf-8", newline="\n")
    stderr_path.write_text(process.stderr, encoding="utf-8", newline="\n")
    (invocation_dir / "command.json").write_text(json.dumps({
        "command": command,
        "exitCode": process.returncode,
        "actorProject": str(project),
        "runtimeBefore": runtime_before,
    }, indent=2) + "\n", encoding="utf-8", newline="\n")
    runtime_after = verify_runtime_inventory(CLI)
    if runtime_after != runtime_pin:
        raise RuntimeError(f"Pinned runtime changed during {label} scoring")
    if process.returncode != 0:
        raise RuntimeError(f"{label} scorer exited {process.returncode}; preserved logs are in {invocation_dir}")
    stdout_report = json.loads(process.stdout)
    run_dir = Path(stdout_report["runDirectory"]).resolve()
    if not run_dir.is_relative_to(ROOT.resolve()):
        raise RuntimeError(f"{label} grader wrote outside the 168 root: {run_dir}")
    report = load_json(run_dir / "score.json")
    summary = validate_score(report, role, target_failures, classification, project, CLI, scorer_hash)
    summary.update({
        "sourceProject": str(OLD_CONTROL_ROOT / role),
        "copiedProject": str(project),
        "byteIdenticalCopy": True,
        "invocationEvidence": str(invocation_dir),
        "runtimeBeforeAndAfter": runtime_after,
    })
    return summary


def main() -> int:
    cli = CLI.resolve()
    preparation = load_json(ROOT / "preparation-evidence.json")
    scorer_hash = sha256(SCORER)
    if scorer_hash != preparation.get("scorerSha256"):
        raise RuntimeError("Copied 168 grader changed from the prepared scorer hash")

    required_new_outputs = (FAILURE_RECORD, SUMMARY_PATH, RESUMED_LOG_ROOT, TEMP_ROOT, CHANGED_COPY)
    existing = [str(path) for path in required_new_outputs if path.exists()]
    if existing:
        raise RuntimeError(f"Refusing to overwrite current calibration outputs: {existing}")

    runtime_pin = verify_runtime_inventory(cli)
    correct = verify_existing_correct(runtime_pin, scorer_hash)
    failure = record_initial_setup_failure()
    skip_files = require_same_tree(OLD_CONTROL_ROOT / "skip-dry-run-creation-validation", SKIP_COPY)

    # The saved skip copy is reused. Its grader run gets a short label, keeping
    # the evidence path within Windows path limits while preserving the failed
    # long-label run and its partial directory.
    skip = score_saved_copy(
        SKIP_COPY, "skip-dry-run-creation-validation", "skip", 16,
        "fault-behavior-rejected", runtime_pin, scorer_hash,
    )
    if tree_inventory(SKIP_COPY) != skip_files:
        raise RuntimeError("Short-label scoring changed the saved skip-fault input project")

    changed_files = tree_inventory(CHANGED_SOURCE)
    shutil.copytree(CHANGED_SOURCE, CHANGED_COPY)
    if tree_inventory(CHANGED_COPY) != changed_files:
        raise RuntimeError("Copied modified-store control is not byte-identical to its report-166 source")
    changed = score_saved_copy(
        CHANGED_COPY, "return-updated-store-on-dry-run", "changed", 10,
        "fault-behavior-rejected", runtime_pin, scorer_hash,
    )
    if tree_inventory(CHANGED_COPY) != changed_files:
        raise RuntimeError("Short-label scoring changed the saved modified-store input project")
    if tree_inventory(CHANGED_SOURCE) != changed_files:
        raise RuntimeError("The frozen report-166 modified-store control changed during scoring")
    require_same_tree(OLD_CONTROL_ROOT / "correct", CORRECT_COPY)
    require_same_tree(OLD_CONTROL_ROOT / "skip-dry-run-creation-validation", SKIP_COPY)
    require_same_tree(CHANGED_SOURCE, CHANGED_COPY)

    if SUMMARY_PATH.exists():
        raise RuntimeError(f"Refusing to overwrite calibration summary: {SUMMARY_PATH}")
    summary = {
        "status": "passed",
        "recoveryOfSessionId": 56401,
        "runtimeInventory": runtime_pin,
        "checksPerControl": 132,
        "controlDomain": (
            "Inherited report-166 project-maturity behavioral controls in their original control domain; "
            "these checks do not establish library maturity."
        ),
        "retainedFailureRecord": str(FAILURE_RECORD),
        "controls": [correct, skip, changed],
        "expected": {
            "correct": {"totalChecks": 132, "totalPassed": 132, "targetFailures": 0},
            "skip-dry-run-creation-validation": {"totalChecks": 132, "totalPassed": 116, "targetFailures": 16},
            "return-updated-store-on-dry-run": {"totalChecks": 132, "totalPassed": 122, "targetFailures": 10},
        },
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": summary["status"],
        "retainedFailure": str(FAILURE_RECORD),
        "controls": [
            {"role": row["controlRole"], "checks": row["totalChecks"], "passed": row["totalPassed"],
             "targetFailures": row["target"]["behaviorFailureCount"], "classification": row["behaviorCheck"]["classification"]}
            for row in summary["controls"]
        ],
        "summary": str(SUMMARY_PATH),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

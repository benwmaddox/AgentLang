# Independent preservation review

Reviewer: `/root/prepare_source_inspection_probe168`, gpt-6-luna/max.
Read-only review of the seed and actor manifests, referenced test objects, source
diffs and mechanical audit. No tests rerun and no files edited by reviewer.

Matched original handoff cases by name and verified manifest object hashes.
Confirmed that `success` drops both pre-state assertions: `before.status` active
and `before.cancelled-at` none. All post-call old-record identity/field assertions,
cancellation status/time, replacement identity/customer/product/trimmed term/dates/
active/no cancellation and unrelated-store assertions remain.

| Case | Seed SHA-256 | Actor SHA-256 |
| --- | --- | --- |
| success | c91fc0d8ee592e2a66ee02351ce75f171bbd97ff691a0ff915fdca666bebff45 | 56ca1b6bc7c5936350234b879e7184fe2f79e3d826aa43dd48c1a008ddfe069a |
| creation-rules-follow-cancellation | 186f87645c3305b6dd5662f250b1d8fccb653b9b4d3155870f8168e477c1a3a7 | 273fea017129562911a5e7bc035680e8428d8c1fef5b4117c43ea44c24e717e0 |
| cancellation-rules-precede-creation | 834ea4020f3c7af46a15d6bab1638793e37a47d99a72f364b3eb304ff1f2ef1d | 94b6a9172a6bbec90d2ad39d158d70b163443a0473e6d71d55f2d2d07ab4840f |
| blank-term-after-cancellation | cd1584a64465416ef64a5efe617414b488738af5755614f23d30139c88947712 | 65d788bcc07389cd9d13507041dd4451c552cdfadb282ab7b4f014d1bdbb8ea5 |
| missing-old-precedes-creation | fdd2ce1d381039333cb5f3a06176643a77e1cfde99d3cafc3eefc3a1ce4084a0 | c7ad54e1ae06a4d22a93b340cb8ad9ef4fc2b25acc4523f761f95dad620eb62e |

Other four originals preserve competing errors and expected results, with the
new `false` argument. Missing-old retains existing replacement ID
`30000000-0000-0000-0000-000000000001`. Four dry-run tests are additive.
Both callers' four existing test objects retain identical hashes.

Recorded mechanical audit passes all 12 checks: unrelated word rows/non-target
revisions unchanged, 50 prior revisions retained, 268 seed objects byte-identical.
Conventional checks are baseline self-comparison, not a fresh actor result.
Mechanical boundaries do not establish assertion preservation.

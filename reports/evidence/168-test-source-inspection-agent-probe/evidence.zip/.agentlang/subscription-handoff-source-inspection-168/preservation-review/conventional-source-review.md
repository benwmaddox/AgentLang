# Conventional source review (manual)

Review these diffs for unrelated foundation/alias edits and preservation of original self-test assertions. No semantic assertion is machine-proven here.

## Operations.fs

```diff

```

## SelfTests.fs

```diff

```

"""Freeze calibrated probe inputs before the single participant is dispatched."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

from runtime_inventory import verify_runtime_inventory

root = Path(__file__).resolve().parent
repo = root.parents[1]
freeze = root / "freeze"
assert not freeze.exists(), "Do not overwrite a freeze"
assert not (root / "trace-flow.jsonl").exists(), "Participant already launched"
runtime = verify_runtime_inventory()
calibration_path = root / "control/flow/calibration-summary.json"
calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
assert calibration["status"] == "passed"
assert calibration["checksPerControl"] == 132
expected = {"correct": (0, 132), "skip-dry-run-creation-validation": (16, 116),
            "return-updated-store-on-dry-run": (10, 122)}
assert {row["controlRole"] for row in calibration["controls"]} == set(expected)
for row in calibration["controls"]:
    failed, passed = expected[row["controlRole"]]
    assert row["totalChecks"] == 132 and row["totalPassed"] == passed
    assert row["target"]["behaviorFailureCount"] == failed
    assert row["status"] == "passed" and row["byteIdenticalCopy"] is True
    assert sum(item["passedCaseCount"] for item in row["retainedCallers"].values()) == 66

prep = json.loads((root / "preparation-evidence.json").read_text(encoding="utf-8"))
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head == prep["milestone167Commit"]
seed = root / "seeds/agentlang-project"
actor = root / "actors/flow"
assert {p.relative_to(actor).as_posix() for p in actor.rglob("*") if p.is_file()} == set(prep["flowSeedFiles"])
for relative, digest in prep["flowSeedFiles"].items():
    assert hashlib.sha256((actor / relative).read_bytes()).hexdigest() == digest
    assert (actor / relative).read_bytes() == (seed / relative).read_bytes()

freeze.mkdir()
blobs = freeze / "blobs"
blobs.mkdir()
inventory = []
def record(path, kind):
    content = path.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    blob = blobs / digest
    if not blob.exists():
        blob.write_bytes(content)
    assert hashlib.sha256(blob.read_bytes()).hexdigest() == digest
    inventory.append({"kind": kind, "path": path.relative_to(repo).as_posix(),
                      "bytes": len(content), "sha256": digest, "blob": "blobs/" + digest})

for directory, kind in [(actor, "initial-actor"), (root / "runtime/flow", "runtime")]:
    for path in sorted(directory.rglob("*")):
        if path.is_file(): record(path, kind)
paths = [root / name for name in ["prompt-flow.md", "broker-flow.json", "preparation-evidence.json", "execution-notes.md"]]
paths += sorted(root.glob("*.py"))
paths += [calibration_path, repo / "scripts/Start-SubagentTrialHostV2.ps1",
          repo / "src/AgentLang.Core/Runtime.fs", repo / "src/AgentLang.Core/AuthoringHelp.fs"]
paths += [repo / "experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle" / name
          for name in ["cases.json", "model.py", "score_agentlang.py"]]
paths += [repo / "experiments/AgentLang.SubagentTrials/subscription-handoff-source-inspection-168" / name
          for name in ["PLAN.md", "oracle/score_agentlang.py"]]
paths += [Path(prep["fullGateReport"]), Path(prep["postBuildSourcePin"])]
for path in paths: record(path, "source-or-protocol")
manifest = {"status": "frozen-before-dispatch", "createdUtc": datetime.now(timezone.utc).isoformat(),
            "head": head, "fullGatePassedAtDispatch": True, "fullGatePendingAtDispatch": False,
            "model": "gpt-6-luna", "reasoning": "max", "maxExchanges": 100,
            "fixedTokenContextLimit": None, "newConventionalParticipant": False,
            "probe": "Single language usability observation; no causal comparison",
            "runtimeInventory": runtime, "files": inventory}
(freeze / "inventory.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(f"Frozen {len(inventory)} input entries; no participant dispatched.")

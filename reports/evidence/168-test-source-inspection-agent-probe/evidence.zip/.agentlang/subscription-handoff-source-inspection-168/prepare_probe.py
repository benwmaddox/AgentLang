"""Prepare the 168 Flow probe only after the milestone-167 gate is complete.

This copies frozen inputs and the complete Release CLI output. It does not run
the CLI, calibrate controls, launch a broker, or dispatch a participant.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
EXPERIMENT = REPO / "experiments" / "AgentLang.SubagentTrials" / "subscription-handoff-source-inspection-168"
OLD_ROOT = REPO / ".agentlang" / "subscription-handoff-maintenance-166"
GATE_DEFAULT = REPO / ".agentlang" / "test-source-inspection-167" / "full-validation-final.json"
SOURCE_PIN_DEFAULT = REPO / ".agentlang" / "test-source-inspection-167" / "post-build-source-pin.json"
EXPECTED_SOURCE_PATHS = {
    "src/AgentLang.Core/Runtime.fs",
    "src/AgentLang.Core/AuthoringHelp.fs",
    "tests/AgentLang.Acceptance/Program.fs",
    "tests/AgentLang.Flow.Runtime.Tests/Program.fs",
}
IGNORED_COPY_DIRECTORIES = {"bin", "obj"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def repo_path(value: str | Path) -> Path:
    path = Path(value)
    return (path if path.is_absolute() else REPO / path).resolve()


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


def validate_seed_against_freeze(seed: Path, inventory: dict, arm: str) -> dict:
    actor_prefix = f".agentlang/subscription-handoff-maintenance-166/actors/{arm}/"
    expected: dict[str, dict] = {}
    for row in inventory.get("files", []):
        path = row.get("path", "")
        if row.get("kind") == "initial-actor" and path.startswith(actor_prefix):
            expected[path[len(actor_prefix):]] = row
    if not expected:
        raise RuntimeError(f"No frozen initial-actor entries found for {arm}")

    actual: dict[str, Path] = {}
    for path in seed.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(seed)
        if any(part.lower() in IGNORED_COPY_DIRECTORIES for part in relative.parts):
            continue
        actual[relative.as_posix()] = path

    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    changed = [
        relative for relative in sorted(set(expected) & set(actual))
        if sha256(actual[relative]) != expected[relative]["sha256"]
        or actual[relative].stat().st_size != expected[relative]["bytes"]
    ]
    if missing or extra or changed:
        raise RuntimeError(
            f"The report-166 {arm} seed differs from its frozen initial-actor inventory: "
            f"missing={missing[:8]}, extra={extra[:8]}, changed={changed[:8]}"
        )
    return {"fileCount": len(actual), "sha256ByPath": {key: expected[key]["sha256"] for key in sorted(expected)}}


def gate_paths_and_commit(args: argparse.Namespace) -> tuple[Path, Path, str, dict | None]:
    terminal_evidence = None
    if args.terminal_evidence is not None:
        terminal_evidence = load_json(repo_path(args.terminal_evidence))
        if terminal_evidence.get("sessionId") != 97238:
            raise RuntimeError("Terminal evidence must identify full-gate session 97238")
        if str(terminal_evidence.get("sessionStatus", "")).lower() not in {"terminal", "completed", "complete"}:
            raise RuntimeError("Full-gate session 97238 is not recorded as terminal")
        if terminal_evidence.get("fullGatePassed") is not True:
            raise RuntimeError("Terminal evidence does not record a passing full gate")
        if terminal_evidence.get("fullGateCheckCount") != 37 or terminal_evidence.get("allExitCodesZero") is not True:
            raise RuntimeError("Terminal evidence must record all 37 checks with exit code 0")
        if terminal_evidence.get("milestone167Pushed") is not True:
            raise RuntimeError("Terminal evidence must record milestone 167 as pushed")
        commit_arg = terminal_evidence.get("milestone167Commit")
        gate_arg = terminal_evidence.get("fullGateReport")
        pin_arg = terminal_evidence.get("postBuildSourcePin")
        if not all(isinstance(value, str) and value for value in (commit_arg, gate_arg, pin_arg)):
            raise RuntimeError("Terminal evidence must name milestone167Commit, fullGateReport, and postBuildSourcePin")
        gate_path, pin_path = repo_path(gate_arg), repo_path(pin_arg)
    else:
        commit_arg = args.milestone_commit
        gate_path = repo_path(args.gate_report)
        pin_path = repo_path(args.source_pin)

    if not re.fullmatch(r"[0-9a-fA-F]{40,64}", str(commit_arg)):
        raise RuntimeError("Supply the full milestone-167 commit SHA")
    commit = git("rev-parse", "--verify", f"{commit_arg}^{{commit}}")
    git("merge-base", "--is-ancestor", commit, "HEAD")
    return gate_path, pin_path, commit, terminal_evidence


def validate_gate(gate_path: Path, pin_path: Path) -> tuple[dict, dict, Path]:
    if not gate_path.is_file() or not pin_path.is_file():
        raise FileNotFoundError(f"Missing final gate or source pin: gate={gate_path}; sourcePin={pin_path}")
    gate = load_json(gate_path)
    checks = gate.get("checks")
    if gate.get("passed") is not True or not gate.get("completedAt"):
        raise RuntimeError("The full-gate report is pending, incomplete, or failed")
    if not isinstance(checks, list) or len(checks) != 37:
        raise RuntimeError("The full-gate report must contain exactly 37 checks")
    if any(row.get("exitCode") != 0 for row in checks):
        raise RuntimeError("At least one full-gate check has a nonzero exit code")
    if gate.get("configuration", "Release").lower() != "release":
        raise RuntimeError("The validated full gate is not a Release build")

    pin = load_json(pin_path)
    pin_files = pin.get("files", [])
    if {row.get("path") for row in pin_files} != EXPECTED_SOURCE_PATHS:
        raise RuntimeError("The post-build source pin does not contain exactly the four milestone source files")
    for row in pin_files:
        source = REPO / row["path"]
        if not source.is_file() or sha256(source) != row.get("sha256"):
            raise RuntimeError(f"Validated source changed since the post-build pin: {source}")

    build = next((row for row in checks if row.get("name") == "build"), None)
    if build is None:
        raise RuntimeError("The full-gate report has no build check")
    output = build.get("output", [])
    cli_lines = [line for line in output if "AgentLang.Cli ->" in line and line.rstrip().endswith("AgentLang.Cli.dll")]
    if len(cli_lines) != 1:
        raise RuntimeError("Could not identify one AgentLang.Cli.dll path in the validated Release build output")
    cli_text = cli_lines[0].split("->", 1)[1].strip()
    cli_dll = Path(cli_text).resolve()
    runtime_dir = cli_dll.parent
    path_parts = {part.lower() for part in runtime_dir.parts}
    if not cli_dll.is_file() or "release" not in path_parts or runtime_dir.name.lower() != "net9.0":
        raise RuntimeError(f"The gate's CLI output is not a complete Release/net9.0 directory: {cli_dll}")
    return gate, pin, runtime_dir


def copy_seed(seed: Path, destination: Path, inventory: dict, arm: str) -> dict:
    frozen = validate_seed_against_freeze(seed, inventory, arm)
    shutil.copytree(seed, destination, ignore=shutil.ignore_patterns("bin", "obj"))
    copied = {path.relative_to(destination).as_posix(): path for path in destination.rglob("*") if path.is_file()}
    for relative, expected_hash in frozen["sha256ByPath"].items():
        if relative not in copied or sha256(copied[relative]) != expected_hash:
            raise RuntimeError(f"Copied {arm} seed differs from its frozen input at {relative}")
    if set(copied) != set(frozen["sha256ByPath"]):
        raise RuntimeError(f"Copied {arm} seed has a different file inventory")
    return frozen


def runtime_inventory(directory: Path) -> list[dict]:
    files = sorted(path for path in directory.rglob("*") if path.is_file())
    if not files or not any(path.name == "AgentLang.Cli.dll" for path in files):
        raise RuntimeError(f"Validated Release output is empty or lacks AgentLang.Cli.dll: {directory}")
    return [
        {"path": path.relative_to(directory).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}
        for path in files
    ]


def require_new_outputs(paths: list[Path]) -> None:
    existing = [str(path) for path in paths if path.exists()]
    if existing:
        raise RuntimeError(f"Refusing to overwrite 168 preparation outputs: {existing}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    evidence = parser.add_mutually_exclusive_group(required=True)
    evidence.add_argument("--milestone-commit", help="Full SHA of the committed and pushed milestone-167 change")
    evidence.add_argument("--terminal-evidence", type=Path, help="Root-provided JSON recording terminal session 97238 and pushed milestone evidence")
    parser.add_argument("--gate-report", type=Path, default=GATE_DEFAULT, help="Completed full-validation-final.json")
    parser.add_argument("--source-pin", type=Path, default=SOURCE_PIN_DEFAULT, help="Milestone-167 post-build-source-pin.json")
    args = parser.parse_args()

    gate_path, pin_path, commit, terminal_evidence = gate_paths_and_commit(args)
    gate, source_pin, runtime_source = validate_gate(gate_path, pin_path)

    flow_seed_source = OLD_ROOT / "seeds" / "agentlang-project"
    conventional_seed_source = OLD_ROOT / "seeds" / "conventional"
    freeze_inventory = load_json(OLD_ROOT / "freeze" / "inventory.json")
    if freeze_inventory.get("status") != "frozen-before-dispatch":
        raise RuntimeError("The report-166 frozen inventory is not in a frozen-before-dispatch state")
    flow_frozen = validate_seed_against_freeze(flow_seed_source, freeze_inventory, "flow")
    conventional_frozen = validate_seed_against_freeze(conventional_seed_source, freeze_inventory, "conventional")

    runtime_destination = ROOT / "runtime" / "flow"
    flow_seed_destination = ROOT / "seeds" / "agentlang-project"
    conventional_seed_destination = ROOT / "seeds" / "conventional"
    actor_destination = ROOT / "actors" / "flow"
    prompt_destination = ROOT / "prompt-flow.md"
    broker_destination = ROOT / "broker-flow.json"
    callers_destination = ROOT / "flow-callers.agent"
    evidence_destination = ROOT / "preparation-evidence.json"
    control_project_sources = [
        OLD_ROOT / "control" / "flow" / name
        for name in ("correct", "skip-dry-run-creation-validation", "return-updated-store-on-dry-run")
    ]
    outputs = [
        runtime_destination, flow_seed_destination, conventional_seed_destination,
        actor_destination, prompt_destination, broker_destination,
        callers_destination, evidence_destination,
    ]
    require_new_outputs(outputs)
    for path in (gate_path, pin_path, flow_seed_source, conventional_seed_source):
        if not path.exists():
            raise FileNotFoundError(path)
    if any(not path.is_dir() for path in control_project_sources):
        raise FileNotFoundError("A prepared report-166 Flow control project is missing")

    shutil.copytree(runtime_source, runtime_destination)
    runtime_files = runtime_inventory(runtime_destination)
    cli_destination = runtime_destination / "AgentLang.Cli.dll"
    if not cli_destination.is_file():
        raise RuntimeError("Copied Release directory is missing AgentLang.Cli.dll")

    copied_flow_frozen = copy_seed(flow_seed_source, flow_seed_destination, freeze_inventory, "flow")
    copy_seed(conventional_seed_source, conventional_seed_destination, freeze_inventory, "conventional")
    shutil.copytree(flow_seed_destination, actor_destination, ignore=shutil.ignore_patterns("bin", "obj"))
    actor_files = sorted(path for path in actor_destination.rglob("*") if path.is_file())
    if {path.relative_to(actor_destination).as_posix() for path in actor_files} != set(copied_flow_frozen["sha256ByPath"]):
        raise RuntimeError("Fresh Flow actor does not exactly match its verified report-166 seed inventory")
    if any(sha256(path) != copied_flow_frozen["sha256ByPath"][path.relative_to(actor_destination).as_posix()] for path in actor_files):
        raise RuntimeError("Fresh Flow actor copy changed frozen seed content")

    old_prompt_path = OLD_ROOT / "prompt-flow.md"
    prompt = old_prompt_path.read_text(encoding="utf-8")
    old_prefix = str(OLD_ROOT)
    new_prefix = str(ROOT)
    if old_prefix not in prompt:
        raise RuntimeError("The report-166 Flow prompt no longer contains its expected launch paths")
    prompt_copy = prompt.replace(old_prefix, new_prefix)
    if old_prefix in prompt_copy or "includeSource" in prompt_copy or "caseName" in prompt_copy:
        raise RuntimeError("Prompt path adaptation left a historical path or exposed an inspection hint")
    prompt_destination.write_text(prompt_copy, encoding="utf-8", newline="\n")

    old_broker_path = OLD_ROOT / "broker-flow.json"
    broker = load_json(old_broker_path)
    if broker.get("maxExchanges") != 100:
        raise RuntimeError("The report-166 Flow broker no longer has the required 100-exchange limit")
    broker["trial"] = "subscription-handoff-source-inspection-168"
    broker["cliDll"] = str(cli_destination)
    broker["cliSha256"] = sha256(cli_destination)
    broker["projectPath"] = str(actor_destination)
    broker["tracePath"] = str(ROOT / "trace-flow.jsonl")
    broker["tempPath"] = str(ROOT / "tmp-flow")
    broker["launchCommand"] = broker["launchCommand"].replace(old_prefix, new_prefix)
    if old_prefix in broker["launchCommand"] or "subscription-handoff-maintenance-166" in broker["launchCommand"]:
        raise RuntimeError("Broker launch still points into the historical trial")
    if broker["cliSha256"] != next(row["sha256"] for row in runtime_files if row["path"] == "AgentLang.Cli.dll"):
        raise RuntimeError("Broker CLI hash does not match the copied Release runtime")
    broker_destination.write_text(json.dumps(broker, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

    callers_source = OLD_ROOT / "flow-callers.agent"
    shutil.copy2(callers_source, callers_destination)
    scorer_path = EXPERIMENT / "oracle" / "score_agentlang.py"
    expected_scorer_line = 'EVIDENCE_ROOT = REPO / ".agentlang" / "subscription-handoff-source-inspection-168"'
    if not scorer_path.is_file() or expected_scorer_line not in scorer_path.read_text(encoding="utf-8"):
        raise RuntimeError("Copied scorer is missing or does not write evidence to the 168 root")
    scorer_hash = sha256(scorer_path)
    # Recheck all four milestone sources after the copies so the recorded pin
    # also proves they stayed unchanged during this preparation step.
    for row in source_pin["files"]:
        if sha256(REPO / row["path"]) != row["sha256"]:
            raise RuntimeError(f"Validated source changed while preparing 168: {row['path']}")

    evidence_record = {
        "status": "prepared-after-terminal-milestone-167-gate; no-calibration-or-dispatch",
        "trial": "subscription-handoff-source-inspection-168",
        "milestone167Commit": commit,
        "milestone167TerminalEvidence": str(repo_path(args.terminal_evidence)) if args.terminal_evidence else None,
        "milestone167TerminalEvidenceSha256": sha256(repo_path(args.terminal_evidence)) if args.terminal_evidence else None,
        "fullGateReport": str(gate_path),
        "fullGateReportSha256": sha256(gate_path),
        "fullGatePassed": gate["passed"],
        "fullGateCheckCount": len(gate["checks"]),
        "fullGateAllExitCodesZero": True,
        "postBuildSourcePin": str(pin_path),
        "postBuildSourcePinSha256": sha256(pin_path),
        "sourceFiles": source_pin["files"],
        "runtimeSourceDirectory": str(runtime_source),
        "runtimePinnedDirectory": str(runtime_destination),
        "runtimeFiles": runtime_files,
        "flowSeedSource": str(flow_seed_source),
        "flowSeedFrozenInventoryFileCount": len(copied_flow_frozen["sha256ByPath"]),
        "flowSeedFiles": copied_flow_frozen["sha256ByPath"],
        "conventionalSeedSource": str(conventional_seed_source),
        "conventionalSeedFrozenInventoryFileCount": conventional_frozen["fileCount"],
        "promptSource": str(old_prompt_path),
        "promptSourceSha256": sha256(old_prompt_path),
        "promptCopySha256": sha256(prompt_destination),
        "brokerSource": str(old_broker_path),
        "brokerSourceSha256": sha256(old_broker_path),
        "brokerCopySha256": sha256(broker_destination),
        "flowCallersSource": str(callers_source),
        "flowCallersCopySha256": sha256(callers_destination),
        "scorerPath": str(scorer_path),
        "scorerSha256": scorer_hash,
        "calibrationControlProjectSources": [
            {"path": str(path)} for path in control_project_sources
        ],
        "participantDispatched": False,
        "brokerLaunched": False,
        "calibrationRun": False,
    }
    evidence_destination.write_text(json.dumps(evidence_record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": evidence_record["status"],
        "milestone167Commit": commit,
        "fullGateChecks": len(gate["checks"]),
        "runtimeFileCount": len(runtime_files),
        "flowSeedFileCount": copied_flow_frozen["fileCount"],
        "outputs": [str(path) for path in outputs],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

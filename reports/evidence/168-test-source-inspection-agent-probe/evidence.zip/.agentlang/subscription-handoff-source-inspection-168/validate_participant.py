"""Run the participant's saved tests, library metadata, and task-finalization checks."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from pathlib import Path

from runtime_inventory import verify_runtime_inventory


REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
ACTOR = ROOT / "actors" / "flow"
FUNCTIONS = ("subscription.handoff", "subscription.renew-annual", "subscription.renew-monthly")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", type=Path, required=True)
    args = parser.parse_args()
    cli = args.cli.expanduser().resolve()
    pinned_cli = (ROOT / "runtime" / "flow" / "AgentLang.Cli.dll").resolve()
    if cli != pinned_cli or not cli.is_file():
        raise RuntimeError(f"Use the exact pinned 168 CLI: {pinned_cli}")
    runtime_pin = verify_runtime_inventory(cli)
    if not ACTOR.is_dir():
        raise FileNotFoundError(f"Fresh Flow participant project is missing: {ACTOR}")
    destination = ROOT / "final-validation"
    if destination.exists():
        raise RuntimeError(f"Refusing to overwrite final validation evidence: {destination}")
    destination.mkdir()
    project = destination / "project"
    shutil.copytree(ACTOR, project)
    requests = [{"op": "test-all"}, {"op": "task.status"}]
    requests.extend({"op": "describe", "word": name} for name in FUNCTIONS)
    request_text = "\n".join(json.dumps(row) for row in requests) + "\n"
    command = ["dotnet", str(cli), "--project", str(project), "--filesystem", "virtual", "--jsonl"]
    runtime_check = verify_runtime_inventory(cli)
    if runtime_check != runtime_pin:
        raise RuntimeError("Pinned runtime inventory changed while preparing participant validation")
    temp_directory = ROOT / "tmp-final-validation"
    temp_directory.mkdir(exist_ok=True)
    environment = dict(os.environ)
    environment["TEMP"] = str(temp_directory)
    environment["TMP"] = str(temp_directory)
    process = subprocess.run(
        command, input=request_text, text=True, encoding="utf-8", capture_output=True,
        cwd=REPO, env=environment, timeout=600, check=False,
    )
    (destination / "requests.jsonl").write_text(request_text, encoding="utf-8", newline="\n")
    (destination / "responses.jsonl").write_text(process.stdout, encoding="utf-8", newline="\n")
    (destination / "stderr.txt").write_text(process.stderr, encoding="utf-8", newline="\n")
    if process.returncode != 0:
        raise RuntimeError(f"Final validation CLI exited {process.returncode}; see {destination / 'stderr.txt'}")
    rows = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
    if len(rows) != len(requests) or not all(row.get("ok") is True for row in rows):
        raise RuntimeError(f"Final validation responses were incomplete or failed; inspect {destination}")
    tests = rows[0].get("data", {}).get("results", [])
    if not tests or not all(test.get("passed") is True for test in tests):
        raise RuntimeError("Participant-authored attached tests did not all pass")
    if rows[1].get("text") != "No active task.":
        raise RuntimeError("The participant's task session is not finalized")
    described = [row.get("data", {}) for row in rows[2:]]
    if [row.get("name") for row in described] != list(FUNCTIONS):
        raise RuntimeError("Final metadata did not describe the target and both retained callers")
    if any(row.get("maturity") != "library" for row in described):
        raise RuntimeError("The target or a retained caller did not reach library maturity")

    summary = {
        "status": "passed",
        "runtime": str(cli),
        "runtimeInventory": runtime_check,
        "actorProject": str(ACTOR),
        "validationProjectCopy": str(project),
        "attachedTestCount": len(tests),
        "allAttachedTestsPassed": True,
        "taskStatus": rows[1].get("data"),
        "taskStatusText": rows[1].get("text"),
        "functions": described,
    }
    (destination / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": summary["status"],
        "attachedTestCount": len(tests),
        "taskStatus": summary["taskStatusText"],
        "functions": [{"name": row["name"], "id": row["id"], "revision": row["revision"], "maturity": row["maturity"]} for row in described],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

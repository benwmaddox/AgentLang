# Batch rental-billing oracle

`cases.json` contains 18 logical cases. The expected result is computed two
ways in the independent runners: each enumerates the bounded integer days of
each stored rental and adds that rental's count. The requested endpoints are
only comparisons; the oracle never subtracts them or walks the request window.
The generated Flow declarations and tests use Flow/2 syntax.

Fixtures are built through the public rental start and cancel functions. A
setup failure is returned with its stage, code, and message. The runners compare
before and after snapshots of every list entry's start, finish, and cancellation
day, preserving both length and order. Invalid windows also require an error
message that mentions the window. The reordered-input case queries both
permutations and requires the same successful total.

Each invocation copies the supplied project into a new output directory,
refuses an existing output path, and records source hashes before and after the
run. A Flow target without the query has no behavior result; its acceptance
record reports the definition failure and leaves `behaviorPassed` null.

Example invocations (choose a fresh output directory for each run):

```powershell
python .agentlang/batch-reuse-147/oracle/score.py `
  --arm flow --project <flow-project> --cli <frozen-flow-cli.dll> `
  --output <new-flow-evidence-directory>

python .agentlang/batch-reuse-147/oracle/score.py `
  --arm fsharp --project <fsharp-workspace> `
  --fsharp-project project/RentalDomain.fsproj `
  --output <new-fsharp-evidence-directory>
```

from pathlib import Path
import hashlib, json, zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OUT = REPO / 'reports/evidence/148-flow-list-discovery'
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'preflight.zip'
index = OUT / 'preflight-index.json'
freeze = ROOT / 'freeze.json'
assert not any(p.exists() for p in (archive,index,freeze)), 'Refusing to overwrite freeze/evidence'
sha = lambda data: hashlib.sha256(data).hexdigest()
start = json.loads((ROOT/'participant/start-inventory.json').read_text(encoding='utf-8'))
for entry in start['files']:
    assert sha((ROOT/'participant/project'/entry['path']).read_bytes()) == entry['sha256']
assert not (ROOT/'participant/actor.trace.jsonl').exists(), 'Already dispatched'
files = set()
for path in ROOT.rglob('*'):
    if path.is_file() and not {'bin','obj','tmp','temp','root-tmp','__pycache__'}.intersection(p.lower() for p in path.relative_to(ROOT).parts) and path.name.lower() != 'write.lock':
        files.add(path)
files.update(p for p in (ROOT/'runtime/bin/AgentLang.Cli/release').rglob('*') if p.is_file())
files.update(REPO / p for p in ['src/AgentLang.Core/Runtime.fs','src/AgentLang.Core/AuthoringHelp.fs','tests/AgentLang.Flow.Runtime.Tests/Program.fs','scripts/Start-SubagentTrialHostV2.ps1','scripts/Audit-SubagentTrialTerminationV2.ps1','docs/SUBAGENT-TRIAL-HOST-V2.md'])
rows = [{'path': p.relative_to(REPO).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]
freeze.write_text(json.dumps({'frozenUtc':datetime.now(timezone.utc).isoformat(),'status':'before-dispatch','files':rows},indent=2)+'\n',encoding='utf-8')
files.add(freeze)
entries=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files):
        data=path.read_bytes(); name=path.relative_to(REPO).as_posix()
        z.writestr(name,data)
        entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(entries)
    for item in entries:
        assert sha(z.read(item['path'])) == item['sha256']
meta={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entryCount':len(entries),'files':entries}
index.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in meta.items() if k!='files'}))


# Fold discovery implementation report

Runtime syntax metadata now keeps the existing Stack spellings and adds a separate `flow2Syntax` value for `list.map`, `list.filter`, `list.each`, and `list.fold`. Search also indexes the Flow/2 receiver spelling. Descriptions state that the callback is a statically named word reference and cannot capture caller locals.

Flow/2 `help.define` and `help.examples` now include a generic integer-sum example using `items.fold(0, tutorial::fold-step)`, with attached tests, an example case, and define/test/example/eval requests. Runtime tests check the Stack and Flow/2 metadata, verify the help payloads, execute the returned requests and example, and typecheck and run Flow/2 map/filter/each receiver calls.

Validation ran with process-local `TMP` and `TEMP` under this directory and `NuGetAudit=false`:

- `dotnet clean AgentLang.sln --configuration Release -m:1 -p:NuGetAudit=false --nologo` completed successfully; output is in `clean-release.log`.
- `dotnet build AgentLang.sln --configuration Release -m:1 -p:NuGetAudit=false --nologo` passed with 0 warnings and 0 errors; final output is in `build-release-attempt3.log`.
- `dotnet run --no-build --configuration Release --project tests/AgentLang.Flow.Runtime.Tests` passed: 32 groups and 1,140 assertions; output is in `flow-runtime-release-attempt3.log`.

Earlier failed attempts remain available: the first build caught a missing F# record delimiter, and the next test run caught an overly specific assertion about documentation wording. Both were corrected before the passing run; their logs are `build-release.log` and `flow-runtime-release-attempt2.log`.

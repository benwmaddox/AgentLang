from pathlib import Path
import hashlib, importlib.util, json, shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PREVIOUS = REPO / '.agentlang/batch-reuse-147'
OUT = ROOT / 'participant'
CLI = ROOT / 'runtime/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
if OUT.exists():
    raise SystemExit('Refusing to overwrite participant')
assert CLI.is_file(), CLI
spec = importlib.util.spec_from_file_location('prior_preparation', PREVIOUS / 'prepare-participants.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.FLOW_CLI = CLI
source = PREVIOUS / 'flow/starts/retained/project'
project = OUT / 'project'
shutil.copytree(source, project, ignore=lambda _, names: {n for n in names if n.lower() in {'bin','obj','write.lock'}})
before = module.inventory(source)
after = module.inventory(project)
assert before['inventorySha256'] == after['inventorySha256']
prompt = module.prompt_text('flow-retained', 'flow', project, OUT / 'actor.trace.jsonl', module.public_task_text())
isolation = '''
Participant isolation is mandatory. Do not list agents, inspect their status,
read their messages or files, contact siblings, delegate, or use any other
participant's findings. Do not use collaboration tools except to return your
final result to the coordinator. Use only the assigned prompt and broker.
Do not request implementation hints or exceptions to the task constraints.
If you cannot finish, report the limitation, abort the task, and close normally.
At completion disclose any tool use outside prompt verification and the broker,
including any out-of-band information you received. No other participant runs
concurrently in this follow-up. This is a constraint, not a solution hint.
'''
prompt = prompt.replace('# Task\n', isolation + '\n# Task\n')
(OUT / 'prompt.md').write_text(prompt, encoding='utf-8')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prompt_hash = digest(OUT / 'prompt.md')
wrapper = f'''You are a fresh participant. Read only `{OUT / 'prompt.md'}` and verify its SHA-256 is `{prompt_hash}` before starting. The human authorizes edits and local tests only within its assigned isolated project through the specified broker. Follow its mandatory isolation rules. Do not list or contact other agents. If the hash differs, stop without touching the project.
'''
(OUT / 'wrapper.txt').write_text(wrapper, encoding='utf-8')
(OUT / 'start-inventory.json').write_text(json.dumps(after, indent=2)+'\n', encoding='utf-8')
shutil.copytree(PREVIOUS / 'oracle', ROOT / 'oracle', ignore=shutil.ignore_patterns('__pycache__'))
for p in (ROOT / 'oracle').rglob('*'):
    if p.is_file():
        assert digest(p) == digest(PREVIOUS / 'oracle' / p.relative_to(ROOT / 'oracle'))
metadata = {'preparedUtc': datetime.now(timezone.utc).isoformat(), 'status':'not-dispatched',
    'sourceProject':str(source), 'project':str(project), 'promptSha256':prompt_hash,
    'startInventorySha256':after['inventorySha256'], 'cli':str(CLI), 'cliSha256':digest(CLI),
    'samePublicContractAs147':True, 'oracleCopiedUnchangedFrom147':True,
    'model':'gpt-6-luna', 'reasoning':'max', 'maxExchanges':100,
    'isolation':'fresh context, one active participant, explicit no-collaboration prompt; external tool restriction not enforced'}
(ROOT / 'preparation.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(wrapper)

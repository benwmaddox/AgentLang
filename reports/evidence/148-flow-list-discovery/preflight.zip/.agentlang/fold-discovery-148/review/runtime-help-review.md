# Runtime and help review

Read-only review of the current `Runtime.fs`, `AuthoringHelp.fs`, Flow runtime
test, trial preparation script, plan, and host isolation guidance.

No material findings. The four Flow/2 receiver spellings match the supported
static callback forms. Their Stack `syntax` values are unchanged, and search
adds the Flow/2 spelling alongside existing match fields. Help returns a complete
define request and runnable test, example, and eval requests; the regression
tests dispatch these through the JSONL protocol after defining the returned
source. No unrelated runtime semantics or duplicate exact test cases were
introduced.

The trial preparation script copies report147's retained Flow start, uses its
public task text through the coordinator-plan boundary, and hash-checks a copy
of the report147 oracle. Its added prompt text contains no billing-specific
implementation hint. The preparation metadata and host documentation both say
external tool restrictions are not enforced; the isolation guidance does not
claim an OS or tool sandbox. No participant was launched.

Small test-scope caveat: the new Flow/2 `each` smoke test checks that the form
typechecks and executes to `Unit`, but does not observe callback count. Existing
Flow tests already verify populated `each` invokes its callback once per item;
the change only advertises the Flow/2 syntax form.

The focused suite was not run as part of this review because the implementation
worker was already running it.

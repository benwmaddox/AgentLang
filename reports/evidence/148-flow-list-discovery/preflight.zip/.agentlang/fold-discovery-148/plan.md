# Fold discovery follow-up

Starting revision: 0b2ca36. Report147 found a concrete mismatch between the
advertised stack fold syntax and supported Flow/2 receiver syntax. Its Flow
participants also communicated, invalidating independent-cell interpretation.

Change only introspection/help examples and their executable regression checks;
retain grammar, IR, runtime semantics and library coverage requirements. Inspect
map/filter for the same metadata mismatch. Build fresh Release artifacts serially,
run relevant executable test suites locally, and preserve commands/output. No CI.

After those checks, freeze a fresh CLI and a copy of report147's retained starting
project. Give one fresh Luna/max participant the same public batch-billing contract
and 100 broker exchanges. Do not teach fold syntax in the task prompt: the runtime
must make it discoverable. Explicitly prohibit sibling discovery/messages and
delegation, with disclosure of out-of-broker actions at completion. No other
participant will run concurrently. The available agent API does not expose a
per-participant tool whitelist; do not claim OS- or tool-enforced isolation.

Reuse the frozen report147 18-case oracle unchanged. Run the positive control
under the fresh CLI before dispatch to establish compatibility. Keep the original
negative controls as historical evidence; no oracle behavior is changing. Record
correctness, library qualification, inherited behavior, actual retained helper
calls, failed requests and closure separately. This single follow-up tests whether
the observed obstacle is recoverable; it cannot estimate broad efficacy or isolate
the effect of vocabulary retention. Preserve every failed attempt.

Deliver report148 with source changes, test evidence and separately labeled
fresh-agent outcome, update ROADMAP, commit and push on main. Keep historical147
runtime artifacts and results immutable.

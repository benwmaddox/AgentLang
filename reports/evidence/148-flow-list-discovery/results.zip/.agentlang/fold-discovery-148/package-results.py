from pathlib import Path
import hashlib,json,zipfile
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OUT=REPO/'reports/evidence/148-flow-list-discovery'
archive=OUT/'results.zip'; index=OUT/'results-index.json'
assert not archive.exists() and not index.exists(), 'Refusing to overwrite results evidence'
sha=lambda data:hashlib.sha256(data).hexdigest()
freeze=json.loads((ROOT/'freeze.json').read_text(encoding='utf-8'))
project=ROOT/'participant/project'
checked=[]
for entry in freeze['files']:
    path=REPO/entry['path']
    if project==path or project in path.parents: continue
    assert sha(path.read_bytes())==entry['sha256'],path
    checked.append(entry)
summary=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
current={}
for path in project.rglob('*'):
    if path.is_file() and path.name.lower()!='write.lock' and not {'bin','obj'}.intersection(p.lower() for p in path.relative_to(project).parts):
        current[path.relative_to(project).as_posix()]=sha(path.read_bytes())
assert current==summary['finalSourceHashes'],'Final source changed since grading'
(ROOT/'results/final-hash-audit.json').write_text(json.dumps({'checkedUtc':datetime.now(timezone.utc).isoformat(),'immutableInputCount':len(checked),'immutableInputsUnchanged':True,'finalSourceCount':len(current),'finalSourcesUnchangedSinceGrading':True,'files':checked},indent=2)+'\n',encoding='utf-8')
files=set()
for folder in ['participant','results','review']:
    files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.name.lower()!='write.lock' and not {'bin','obj','tmp','temp','root-tmp','__pycache__'}.intersection(x.lower() for x in p.relative_to(ROOT).parts))
files.update(ROOT/p for p in ['freeze.json','dispatch.json','grade.py','package-results.py','participant-final.md'])
entries=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        b=p.read_bytes(); name=p.relative_to(REPO).as_posix(); z.writestr(name,b)
        entries.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(entries)
    for e in entries:
        assert sha(z.read(e['path']))==e['sha256']
metadata={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entryCount':len(entries),'verifiedAgainstSourceAndZip':True,'files':entries}
index.write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in metadata.items() if k!='files'}))

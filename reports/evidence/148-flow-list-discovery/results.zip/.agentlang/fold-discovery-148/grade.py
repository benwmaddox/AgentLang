from pathlib import Path
import hashlib, json, subprocess, sys

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
trace=ROOT/'participant/actor.trace.jsonl'
rows=[json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines() if line.strip()]
assert rows[-1].get('event')=='session-end', 'Do not grade a live participant'
out=ROOT/'results'
out.mkdir(exist_ok=False)
cli=ROOT/'runtime/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
def run(name, args, stdin=None):
    (out/(name+'.command.json')).write_text(json.dumps(args,indent=2)+'\n',encoding='utf-8')
    result=subprocess.run(args,input=stdin,cwd=REPO,text=True,encoding='utf-8',errors='replace',capture_output=True)
    (out/(name+'.stdout.txt')).write_text(result.stdout,encoding='utf-8')
    (out/(name+'.stderr.txt')).write_text(result.stderr,encoding='utf-8')
    (out/(name+'.exit.txt')).write_text(str(result.returncode)+'\n',encoding='utf-8')
    return result.returncode
run('termination-audit',['pwsh','-NoProfile','-File',str(REPO/'scripts/Audit-SubagentTrialTerminationV2.ps1'),'-TracePath',str(trace)])
run('oracle',[sys.executable,str(ROOT/'oracle/score.py'),'--arm','flow','--project',str(ROOT/'participant/project'),'--cli',str(cli),'--output',str(out/'oracle')])
requests=[{'op':'test-all'}, {'op':'describe','word':'rental.total-billable-days'}, {'op':'transitive-dependencies','word':'rental.total-billable-days'}, {'op':'task.status'}]
(out/'final-inspection.requests.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in requests),encoding='utf-8')
run('final-inspection',['dotnet',str(cli),'--project',str(out/'oracle/working-project'),'--jsonl'], ''.join(json.dumps(r)+'\n' for r in requests))
exchanges=[r for r in rows if r.get('event')=='exchange']
errors=[]
for r in exchanges:
    try: response=json.loads((r.get('response') or {}).get('rawLine','{}'))
    except json.JSONDecodeError: continue
    if response.get('ok') is False:
        errors.append({'index':r['index'],'operation':r.get('operation'),'response':response})
acceptance=json.loads((out/'oracle/acceptance.json').read_text(encoding='utf-8'))
final={}
for path in sorted((ROOT/'participant/project').rglob('*')):
    relative=path.relative_to(ROOT/'participant/project')
    if path.is_file() and not {'bin','obj'}.intersection(p.lower() for p in relative.parts) and path.name.lower()!='write.lock':
        final[relative.as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
before={r['path']:r['sha256'] for r in json.loads((ROOT/'participant/start-inventory.json').read_text(encoding='utf-8'))['files']}
summary={'exchanges':len(exchanges),'errorResponses':errors,'terminal':rows[-1],
    'acceptancePassed':acceptance['passed'],'behaviorPassed':acceptance['behaviorPassed'],
    'casesPassed':sum(c.get('passed') is True for c in acceptance['cases']),
    'casesObserved':sum(c.get('passed') is not None for c in acceptance['cases']),
    'inputUnchangedDuringScoring':acceptance['inputUnchanged'],
    'finalSourceHashes':final,'scopeChanges':{
        'added':sorted(final.keys()-before.keys()),'removed':sorted(before.keys()-final.keys()),
        'modified':sorted(k for k in before.keys() & final.keys() if before[k]!=final[k])}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k in {'exchanges','acceptancePassed','behaviorPassed','casesPassed','casesObserved'}}))

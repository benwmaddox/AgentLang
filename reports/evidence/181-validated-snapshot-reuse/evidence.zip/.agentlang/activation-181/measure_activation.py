import concurrent.futures
import hashlib
import json
import sys
import subprocess
import time
from pathlib import Path

def measure(cli, project, output, samples):
    rows = []
    for sample in range(samples):
        stderr_path = output.with_name(output.stem + f'-{sample + 1}.stderr.log')
        started = time.perf_counter()
        with stderr_path.open('wb') as stderr:
            process = subprocess.Popen(
                ['dotnet', str(cli), '--project', str(project), '--filesystem', 'virtual', '--jsonl'],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
            responses = []
            timings = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as reader:
                try:
                    for request_index in range(4):
                        request_started = started if request_index == 0 else time.perf_counter()
                        process.stdin.write(b'{"op":"words"}\n')
                        process.stdin.flush()
                        line = reader.submit(process.stdout.readline, 2 * 1024 * 1024 + 1).result(timeout=90)
                        timings.append((time.perf_counter() - request_started) * 1000)
                        assert len(line) <= 2 * 1024 * 1024 and line.endswith(b'\n'), 'Missing or oversized response'
                        response = json.loads(line)
                        assert response['ok'], response
                        responses.append(response)
                    process.stdin.close()
                    process.wait(timeout=10)
                    assert process.returncode == 0, process.returncode
                    assert not process.stdout.read(), 'Unexpected extra response'
                    rows.append({'sample': sample + 1, 'freshToFirstWordsMilliseconds': timings[0],
                                 'warmWordsMilliseconds': timings[1:], 'exitCode': process.returncode,
                                 'responseSha256': [hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest() for r in responses]})
                finally:
                    if process.poll() is None:
                        process.kill()
                        process.wait(timeout=10)
        output.write_text(json.dumps({'cli': str(cli), 'project': str(project), 'samples': rows}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(rows))

if __name__ == '__main__':
    measure(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve(), int(sys.argv[4]))

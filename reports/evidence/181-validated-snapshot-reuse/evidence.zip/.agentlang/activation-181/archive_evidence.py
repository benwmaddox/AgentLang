import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd().resolve()
local = repo / '.agentlang/activation-181'
out = repo / 'reports/evidence/181-validated-snapshot-reuse'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
gate = load(local / 'full-validation.json')
assert gate['passed'] and len(gate['checks']) == 37
assert all(c['exitCode'] == 0 for c in gate['checks'])
assert '1732 assertions' in (local / 'implementation/flow-runtime-final-retry-tests.log').read_text()
comparison = load(local / 'measurement-comparison.json')
assert comparison['projectFilesUnchanged'] and comparison['all24ResponsesIdentical']
files = set()
for pin in load(local / 'source-freeze.json')['pins']:
    path = repo / pin['path']
    assert sha(path.read_bytes()).lower() == pin['sha256'].lower()
    files.add(path)
allowed = {'.json', '.jsonl', '.log', '.md', '.fs', '.py', '.agent', '.flow'}
excluded = {'baseline-artifacts', 'candidate-artifacts', 'local-test-temp', 'bin', 'obj', '__pycache__'}
for path in local.rglob('*'):
    if path.is_file() and (path.suffix in allowed or path.name == 'CURRENT') and not (set(path.relative_to(local).parts) & excluded):
        files.add(path)
for pin in load(local / 'qualified-project-inputs.json'):
    path = local / 'qualified-project' / Path(pin['path'])
    assert sha(path.read_bytes()) == pin['sha256'], path
    files.add(path)
assert not out.exists(), 'Refuse to overwrite a publication'
out.mkdir(parents=True)
rows = []
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        assert path.resolve().is_relative_to(repo)
        data = path.read_bytes()
        relative = path.relative_to(repo).as_posix()
        archive.writestr(relative, data)
        rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(rows)
    for row in rows:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
index = {'status': 'verified', 'files': rows, 'fullLocalChecks': 37,
         'focusedRuntimeGroups': 42, 'focusedRuntimeAssertions': 1732,
         'measurement': comparison,
         'archive': {'path': 'evidence.zip', 'bytes': (out / 'evidence.zip').stat().st_size,
                     'sha256': sha((out / 'evidence.zip').read_bytes())},
         'limits': 'Sources, inputs, logs, review and failed attempts; binaries excluded. No startup speedup or comparative efficacy established.'}
(out / 'archive.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in index.items() if k != 'files'}))

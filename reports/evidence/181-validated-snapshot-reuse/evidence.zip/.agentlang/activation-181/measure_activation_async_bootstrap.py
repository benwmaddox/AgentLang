import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path

async def measure(cli, project, output, samples):
    rows = []
    for sample in range(samples):
        stderr_path = output.with_name(output.stem + f'-{sample + 1}.stderr.log')
        started = time.perf_counter()
        with stderr_path.open('wb') as stderr:
            process = await asyncio.create_subprocess_exec(
                'dotnet', str(cli), '--project', str(project), '--filesystem', 'virtual', '--jsonl',
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                stderr=stderr, limit=2 * 1024 * 1024)
            responses = []
            timings = []
            try:
                for request_index in range(4):
                    request_started = started if request_index == 0 else time.perf_counter()
                    process.stdin.write(b'{"op":"words"}\n')
                    await process.stdin.drain()
                    line = await asyncio.wait_for(process.stdout.readline(), timeout=90)
                    timings.append((time.perf_counter() - request_started) * 1000)
                    response = json.loads(line)
                    assert response['ok'], response
                    responses.append(response)
                process.stdin.close()
                await asyncio.wait_for(process.wait(), timeout=10)
                assert process.returncode == 0, process.returncode
                assert not await process.stdout.read(), 'Unexpected extra response'
                rows.append({'sample': sample + 1, 'freshToFirstWordsMilliseconds': timings[0],
                             'warmWordsMilliseconds': timings[1:], 'exitCode': process.returncode,
                             'responseSha256': [hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest() for r in responses]})
            finally:
                if process.returncode is None:
                    process.kill()
                    await process.wait()
        output.write_text(json.dumps({'cli': str(cli), 'project': str(project), 'samples': rows}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(rows))

if __name__ == '__main__':
    asyncio.run(measure(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve(), int(sys.argv[4])))

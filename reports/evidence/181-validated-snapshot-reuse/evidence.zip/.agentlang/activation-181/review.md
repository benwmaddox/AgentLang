# Milestone 181 activation snapshot review

**Result:** Pass; no source blocker found. The diff removes the second `compileRuntimeSnapshot` call from durable project activation and named snapshot restoration by returning and reusing the validated snapshot.

**Reviewed source pins:**

- `src/AgentLang.Core/Runtime.fs` SHA-256: `06C19B436997C45700C4D58AD1B7240F663EC9412DDE1CDD166F2C5FB0F971C2`.
- `tests/AgentLang.Flow.Runtime.Tests/Program.fs` SHA-256: `608C45A3A253CC1E18E101EFF1AF9519BEC5DF7D94DCBBA66F3B36B49C5B37C9`.
- `src/AgentLang.Core/Storage.fs:1211-1216,1351-1387,1655-1689`: source objects are hash-verified; manifest bytes are checked against the authority hash and all manifest references are read; snapshot restoration still validates generation and manifest identity before pointer commit.
- `Runtime.fs:2011-2038,2497-2515`: legacy/empty states are parsed, graph-validated and compiled; manifest-backed state is compiled, its export is checked (exactly for v2+ and semantically for v1), and the same `executable` is returned.
- `Runtime.fs:2521-2528,2762-2784`: `Storage.load` still precedes validation; the returned snapshot is staged, library-requalified and activated directly, with no second compile.
- `Runtime.fs:6575-6605`: named snapshot loading still reads and validates the snapshot/source, temporarily sets the saved clock for requalification, restores the previous clock in `finally`, calls `Storage.restoreSnapshot`, then activates the executable and applies provider state.
- `Program.fs:4579-4592`: the changed-clock startup failure remains covered and named snapshot requalification under the saved clock is exercised. `Program.fs:5974-5985` restores shared test-file overrides and checks their active identity during tests and absence during production evaluation.

The exact `RuntimeSnapshot` returned by `validateStoredProject` now flows into both requalification and activation. That preserves the `Program` and test-file overlay views created by its compilation. The manifest hash/source validation, export checks, persisted binding/type validation, legacy path, and library test/coverage qualification were not removed or bypassed.

**Coverage gap:** I found no direct negative test for `snapshot.load` failing library requalification and then asserting the preexisting clock, manifest/provider state, and live executable remain unchanged. Existing tests cover startup requalification failure and successful named-snapshot clock restore; the named snapshot failure path is supported by the `finally` and ordering visible above, but not directly exercised. This is a nonblocking test gap for this refactor.

**Review limits:** This was a static diff review; I did not build or run tests. The root reported the fresh focused suite passing 42 groups and 1,732 assertions; I did not independently verify that result. The root owns the performance measurement and remaining gates. No security claim is made.

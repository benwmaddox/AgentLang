#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stddef.h>
#include <stdint.h>
#include <limits.h>

#define TOPOLOGY_BUFFER_BYTES (1024u * 1024u)
#define TOPOLOGY_SELECTED_CORES 4u
#define TOPOLOGY_GROUP_INDEX_COUNT (UINT16_MAX + 1u)

typedef struct selected_core {
  uint32_t physical_core_index;
  uint32_t logical_processor_index;
  uint8_t efficiency_class;
  KAFFINITY group0_mask;
  uint32_t found;
} selected_core;

_Alignas(SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)
static uint8_t g_information[TOPOLOGY_BUFFER_BYTES];
static KAFFINITY g_seen_masks[TOPOLOGY_GROUP_INDEX_COUNT];
static KAFFINITY g_selected_sibling_masks[TOPOLOGY_GROUP_INDEX_COUNT];
static uint32_t g_core_group_stamp[TOPOLOGY_GROUP_INDEX_COUNT];
static selected_core g_selected[TOPOLOGY_SELECTED_CORES];
static WORD g_active_group_count;
static DWORD g_information_bytes;
static DWORD g_physical_core_count;
static DWORD g_error;
static uint32_t g_output_failed;

static uint32_t text_length(const char *text) {
  uint32_t length = 0u;
  while (text[length] != '\0') ++length;
  return length;
}

static void write_bytes(HANDLE output, const char *bytes, uint32_t length) {
  DWORD written = 0u;
  if (output == NULL || output == INVALID_HANDLE_VALUE ||
      !WriteFile(output, bytes, length, &written, NULL) || written != length)
    g_output_failed = 1u;
}

static void write_text(const char *text) {
  if (g_output_failed == 0u)
    write_bytes(GetStdHandle(STD_OUTPUT_HANDLE), text, text_length(text));
}

static void write_u32_to(HANDLE output, uint32_t value) {
  char digits[10];
  char text[10];
  uint32_t count = 0u;
  do {
    digits[count++] = (char)('0' + value % 10u);
    value /= 10u;
  } while (value != 0u);
  for (uint32_t i = 0u; i < count; ++i) text[i] = digits[count - i - 1u];
  write_bytes(output, text, count);
}

static void write_u32(uint32_t value) {
  if (g_output_failed == 0u) write_u32_to(GetStdHandle(STD_OUTPUT_HANDLE), value);
}

static void write_mask(KAFFINITY value) {
  static const char hex[] = "0123456789abcdef";
  const uint32_t digits = (uint32_t)(sizeof(KAFFINITY) * CHAR_BIT / 4u);
  write_text("\"0x");
  for (uint32_t i = digits; i > 0u; --i) {
    uint32_t shift = (i - 1u) * 4u;
    char digit = hex[(uint32_t)((value >> shift) & (KAFFINITY)0x0fu)];
    if (g_output_failed == 0u)
      write_bytes(GetStdHandle(STD_OUTPUT_HANDLE), &digit, 1u);
  }
  write_text("\"");
}

static void write_bool(uint32_t value) {
  write_text(value != 0u ? "true" : "false");
}

static void write_error(DWORD error) {
  HANDLE output = GetStdHandle(STD_ERROR_HANDLE);
  static const char prefix[] = "topology_probe_error=";
  static const char newline[] = "\r\n";
  write_bytes(output, prefix, (uint32_t)(sizeof(prefix) - 1u));
  write_u32_to(output, error);
  write_bytes(output, newline, (uint32_t)(sizeof(newline) - 1u));
}

static uint32_t active_mask_for_group(WORD group, KAFFINITY *mask) {
  DWORD active_count;
  const uint32_t mask_bits = (uint32_t)(sizeof(KAFFINITY) * CHAR_BIT);
  if (mask == NULL || group >= g_active_group_count) return 0u;
  active_count = GetActiveProcessorCount(group);
  if (active_count == 0u || active_count > mask_bits) return 0u;
  if (active_count == mask_bits) *mask = ~(KAFFINITY)0;
  else *mask = ((KAFFINITY)1u << active_count) - (KAFFINITY)1u;
  return 1u;
}

static uint32_t validate_group_mask(const GROUP_AFFINITY *group_mask) {
  KAFFINITY active_mask;
  if (group_mask == NULL || group_mask->Mask == 0u ||
      !active_mask_for_group(group_mask->Group, &active_mask) ||
      (group_mask->Mask & ~active_mask) != 0u) return 0u;
  return 1u;
}

static uint32_t insert_candidate(uint32_t physical_core_index,
                                 uint8_t efficiency_class,
                                 KAFFINITY group0_mask) {
  selected_core candidate;
  candidate.physical_core_index = physical_core_index;
  candidate.logical_processor_index = 0u;
  candidate.efficiency_class = efficiency_class;
  candidate.group0_mask = group0_mask;
  candidate.found = 1u;
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i) {
    if (g_selected[i].found == 0u ||
        efficiency_class > g_selected[i].efficiency_class) {
      for (uint32_t move = TOPOLOGY_SELECTED_CORES - 1u; move > i; --move)
        g_selected[move] = g_selected[move - 1u];
      g_selected[i] = candidate;
      return 1u;
    }
  }
  return 1u;
}

static uint32_t first_set_bit(KAFFINITY mask, uint32_t *index) {
  const uint32_t bits = (uint32_t)(sizeof(KAFFINITY) * CHAR_BIT);
  if (index == NULL || mask == 0u) return 0u;
  for (uint32_t i = 0u; i < bits; ++i) {
    if ((mask & ((KAFFINITY)1u << i)) != 0u) {
      *index = i;
      return 1u;
    }
  }
  return 0u;
}

static uint32_t selected_core_index(uint32_t physical_core_index) {
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i)
    if (g_selected[i].found != 0u &&
        g_selected[i].physical_core_index == physical_core_index) return 1u;
  return 0u;
}

static uint32_t record_group_masks(
    const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *record,
    const GROUP_AFFINITY **masks, WORD *count) {
  const size_t relationship_offset =
      offsetof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX, Processor);
  const size_t group_masks_offset = relationship_offset +
      offsetof(PROCESSOR_RELATIONSHIP, GroupMask);
  size_t required_bytes;
  if (record == NULL || masks == NULL || count == NULL ||
      record->Size < group_masks_offset) return 0u;
  *count = record->Processor.GroupCount;
  if (*count == 0u ||
      (size_t)*count > (SIZE_MAX - group_masks_offset) / sizeof(GROUP_AFFINITY))
    return 0u;
  required_bytes = group_masks_offset + (size_t)*count * sizeof(GROUP_AFFINITY);
  if (record->Size < required_bytes) return 0u;
  *masks = (const GROUP_AFFINITY *)((const uint8_t *)record + group_masks_offset);
  return 1u;
}

static uint32_t enumerate_and_select(void) {
  DWORD required_bytes = 0u;
  DWORD supplied_bytes;
  DWORD offset = 0u;
  DWORD physical_core_index = 0u;
  const size_t header_bytes =
      offsetof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX, Processor);
  BOOL queried;
  DWORD query_error;

  g_active_group_count = GetActiveProcessorGroupCount();
  if (g_active_group_count == 0u ||
      GetActiveProcessorCount(0u) == 0u) {
    g_error = ERROR_INVALID_DATA;
    return 0u;
  }

  queried = GetLogicalProcessorInformationEx(RelationProcessorCore, NULL,
                                               &required_bytes);
  query_error = queried ? NO_ERROR : GetLastError();
  if (queried || query_error != ERROR_INSUFFICIENT_BUFFER ||
      required_bytes < header_bytes || required_bytes > sizeof(g_information)) {
    g_error = queried ? ERROR_INVALID_DATA : query_error;
    return 0u;
  }
  supplied_bytes = (DWORD)sizeof(g_information);
  if (!GetLogicalProcessorInformationEx(RelationProcessorCore,
        (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)g_information,
        &supplied_bytes)) {
    g_error = GetLastError();
    return 0u;
  }
  if (supplied_bytes < header_bytes || supplied_bytes > sizeof(g_information)) {
    g_error = ERROR_BAD_LENGTH;
    return 0u;
  }
  g_information_bytes = supplied_bytes;

  while (offset < g_information_bytes) {
    const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *record;
    const GROUP_AFFINITY *masks;
    WORD group_count;
    KAFFINITY group0_mask = 0u;
    size_t remaining = (size_t)g_information_bytes - offset;
    if (remaining < header_bytes) {
      g_error = ERROR_BAD_LENGTH;
      return 0u;
    }
    record = (const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *)
        (g_information + offset);
    if (record->Relationship != RelationProcessorCore ||
        record->Size == 0u || record->Size > remaining ||
        !record_group_masks(record, &masks, &group_count)) {
      g_error = ERROR_BAD_LENGTH;
      return 0u;
    }
    for (WORD i = 0u; i < group_count; ++i) {
      const GROUP_AFFINITY *group_mask = &masks[i];
      if (!validate_group_mask(group_mask) ||
          (g_core_group_stamp[group_mask->Group] == physical_core_index + 1u)) {
        g_error = ERROR_INVALID_DATA;
        return 0u;
      }
      g_core_group_stamp[group_mask->Group] = physical_core_index + 1u;
      if ((g_seen_masks[group_mask->Group] & group_mask->Mask) != 0u) {
        g_error = ERROR_INVALID_DATA;
        return 0u;
      }
      g_seen_masks[group_mask->Group] |= group_mask->Mask;
      if (group_mask->Group == 0u) group0_mask = group_mask->Mask;
    }
    if (group0_mask != 0u &&
        !insert_candidate(physical_core_index, record->Processor.EfficiencyClass,
                          group0_mask)) {
      g_error = ERROR_INVALID_DATA;
      return 0u;
    }
    if (physical_core_index == UINT32_MAX) {
      g_error = ERROR_ARITHMETIC_OVERFLOW;
      return 0u;
    }
    ++physical_core_index;
    offset += record->Size;
  }
  if (offset != g_information_bytes || physical_core_index == 0u) {
    g_error = ERROR_BAD_LENGTH;
    return 0u;
  }
  g_physical_core_count = physical_core_index;
  for (WORD group = 0u; group < g_active_group_count; ++group) {
    KAFFINITY active_mask;
    if (!active_mask_for_group(group, &active_mask) ||
        g_seen_masks[group] != active_mask) {
      g_error = ERROR_INVALID_DATA;
      return 0u;
    }
  }
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i) {
    if (g_selected[i].found == 0u ||
        !first_set_bit(g_selected[i].group0_mask,
                       &g_selected[i].logical_processor_index)) {
      g_error = ERROR_NOT_ENOUGH_QUOTA;
      return 0u;
    }
    for (uint32_t earlier = 0u; earlier < i; ++earlier) {
      if ((g_selected[i].group0_mask & g_selected[earlier].group0_mask) != 0u) {
        g_error = ERROR_INVALID_DATA;
        return 0u;
      }
    }
  }

  offset = 0u;
  physical_core_index = 0u;
  while (offset < g_information_bytes) {
    const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *record =
        (const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *)(g_information + offset);
    const GROUP_AFFINITY *masks;
    WORD group_count;
    if (!record_group_masks(record, &masks, &group_count)) {
      g_error = ERROR_BAD_LENGTH;
      return 0u;
    }
    if (selected_core_index(physical_core_index) != 0u) {
      for (WORD i = 0u; i < group_count; ++i)
        g_selected_sibling_masks[masks[i].Group] |= masks[i].Mask;
    }
    ++physical_core_index;
    offset += record->Size;
  }
  return 1u;
}

static void write_processor_cores(void) {
  DWORD offset = 0u;
  DWORD physical_core_index = 0u;
  uint32_t first = 1u;
  write_text("\"processorCores\":[\r\n");
  while (offset < g_information_bytes) {
    const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *record =
        (const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX *)(g_information + offset);
    const GROUP_AFFINITY *masks;
    WORD group_count;
    (void)record_group_masks(record, &masks, &group_count);
    if (first == 0u) write_text(",\r\n");
    first = 0u;
    write_text("{\"physicalCoreIndex\":");
    write_u32(physical_core_index);
    write_text(",\"efficiencyClass\":");
    write_u32(record->Processor.EfficiencyClass);
    write_text(",\"smt\":");
    write_bool((record->Processor.Flags & LTP_PC_SMT) != 0u);
    write_text(",\"groupMasks\":[");
    for (WORD i = 0u; i < group_count; ++i) {
      if (i != 0u) write_text(",");
      write_text("{\"group\":");
      write_u32(masks[i].Group);
      write_text(",\"kaffinityMaskHex\":");
      write_mask(masks[i].Mask);
      write_text("}");
    }
    write_text("]}");
    ++physical_core_index;
    offset += record->Size;
  }
  write_text("\r\n]");
}

static void write_selection(void) {
  KAFFINITY group0_active_mask = 0u;
  KAFFINITY group0_sibling_mask = g_selected_sibling_masks[0];
  KAFFINITY server_mask = 0u;
  KAFFINITY client_mask;
  if (!active_mask_for_group(0u, &group0_active_mask)) {
    g_output_failed = 1u;
    return;
  }
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i)
    server_mask |= (KAFFINITY)1u << g_selected[i].logical_processor_index;
  client_mask = group0_active_mask & ~group0_sibling_mask;

  write_text(",\r\n\"selection\":{\"group\":0,\"selectedPhysicalCoreCount\":");
  write_u32(TOPOLOGY_SELECTED_CORES);
  write_text(",\"physicalCoreIndices\":[");
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i) {
    if (i != 0u) write_text(",");
    write_u32(g_selected[i].physical_core_index);
  }
  write_text("],\"selectedLogicalProcessorIndices\":[");
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i) {
    if (i != 0u) write_text(",");
    write_u32(g_selected[i].logical_processor_index);
  }
  write_text("],\"serverMaskHex\":");
  write_mask(server_mask);
  write_text(",\"siblingMaskHex\":");
  write_mask(group0_sibling_mask);
  write_text(",\"clientMaskHex\":");
  write_mask(client_mask);
  write_text(",\"group0ActiveMaskHex\":");
  write_mask(group0_active_mask);
  write_text(",\"selectedCores\":[");
  for (uint32_t i = 0u; i < TOPOLOGY_SELECTED_CORES; ++i) {
    if (i != 0u) write_text(",");
    write_text("{\"physicalCoreIndex\":");
    write_u32(g_selected[i].physical_core_index);
    write_text(",\"efficiencyClass\":");
    write_u32(g_selected[i].efficiency_class);
    write_text(",\"logicalProcessorIndex\":");
    write_u32(g_selected[i].logical_processor_index);
    write_text(",\"group0CoreSiblingMaskHex\":");
    write_mask(g_selected[i].group0_mask);
    write_text("}");
  }
  write_text("],\"selectedCoreSiblingMasksByGroup\":[");
  for (WORD group = 0u; group < g_active_group_count; ++group) {
    KAFFINITY active_mask = 0u;
    if (!active_mask_for_group(group, &active_mask)) {
      g_output_failed = 1u;
      return;
    }
    if (group != 0u) write_text(",");
    write_text("{\"group\":");
    write_u32(group);
    write_text(",\"selectedCoreSiblingMaskHex\":");
    write_mask(g_selected_sibling_masks[group]);
    write_text(",\"clientMaskHex\":");
    write_mask(active_mask & ~g_selected_sibling_masks[group]);
    write_text("}");
  }
  write_text("]}");
}

static void write_report(void) {
  write_text("{\r\n\"activeProcessorGroupCount\":");
  write_u32(g_active_group_count);
  write_text(",\r\n\"processorCoreCount\":");
  write_u32(g_physical_core_count);
  write_text(",\r\n\"processorCoreRelationBytes\":");
  write_u32(g_information_bytes);
  write_text(",\r\n");
  write_processor_cores();
  write_selection();
  write_text("\r\n}\r\n");
}

__declspec(noreturn) void __cdecl topology_start(void) {
  if (!enumerate_and_select()) {
    write_error(g_error == 0u ? ERROR_INVALID_DATA : g_error);
    ExitProcess(1u);
  }
  write_report();
  ExitProcess(g_output_failed == 0u ? 0u : 1u);
}

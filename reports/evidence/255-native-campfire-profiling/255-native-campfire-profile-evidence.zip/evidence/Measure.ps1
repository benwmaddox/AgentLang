param([Parameter(Mandatory)][string]$RunName,[Parameter(Mandatory)][int]$ServerPid,[int]$Concurrency,[int]$Repeats=2,[int]$Seconds=15,[long]$ClientAffinityMask=0)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:\code\AgentLang'
$root=Join-Path $repo ".agentlang/campfire-native-profile-255/runs/$RunName"
if(-not (Test-Path -LiteralPath $root -PathType Container)){throw 'Start the task-owned host first'}
$rows=@()
foreach($repeat in 1..$Repeats){
 $config=Get-Content (Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke/native-measure.config.json') -Raw | ConvertFrom-Json
 $config.Concurrency=$Concurrency; $config.Seconds=$Seconds; $config.ServerPid=$ServerPid
 if($ClientAffinityMask -gt 0){$config | Add-Member -NotePropertyName ClientAffinityMask -NotePropertyValue $ClientAffinityMask -Force}
 $configPath=Join-Path $root "native-r$repeat.config.json"
 $resultPath=Join-Path $root "native-r$repeat.result.json"
 if(Test-Path -LiteralPath $resultPath){throw 'Immutable result already exists'}
 $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $configPath -Encoding utf8
 $clientRoot=if($ClientAffinityMask -gt 0){'fixed-client-artifacts'}else{'client-artifacts'}
 & dotnet (Join-Path $repo ".agentlang/campfire-native-profile-255/$clientRoot/bin/HttpMeasure/release/HttpMeasure.dll") $configPath $resultPath | Set-Content -LiteralPath (Join-Path $root "native-r$repeat.client.log") -Encoding utf8
 if($LASTEXITCODE -ne 0){throw 'Benchmark correctness failed'}
 $result=Get-Content $resultPath -Raw | ConvertFrom-Json
 $rows += $result
 Write-Output ("r{0} c={1} req/s={2:F1} p99<={3}ms serverCPUcores={4:F2} clientCPUcores={5:F2} failures={6}" -f $repeat,$Concurrency,$result.correctRequestsPerSecond,$result.p99MillisecondsUpperBound,$result.serverCpuEquivalentCores,$result.clientCpuEquivalentCores,$result.failures)
}
$rows | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $root 'measurement-summary.json') -Encoding utf8

# Native Campfire message-write plan

Status: source-based plan only. No application, compiler, adapter, database, or
listener changes were made. The Rails checkout resolves to
`90b330024dec3e757c79b6a7e6568f93da8e3148`; the paired Rust reference is pinned
to `6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad`.

## Current POST path and transaction gap

The managed transport maps `POST /rooms/{roomId}/messages` and sends the fixed
`message-create` route to Flow (`applications/campfire/Http/Transport.fs:396-458`). It accepts only
`application/x-www-form-urlencoded`, bounds the body at 65,536 bytes, and uses
form limits of 32 values, 128-character keys, and 32,768-character values.
Duplicate keys are rejected; attachment-shaped keys map to
`unsupported-attachment`; `message[client_message_id]` and `message[body]` are
the only values copied into `HttpMessageInput` (`applications/campfire/Http/Transport.fs:26-29,
100-127`). `Some ""` is distinct from absent. An absent `message` root produces
no input; an unknown `message[...]` key still creates an input with absent
supported fields.

For an unsafe request, `campfire.http.dispatch` checks the IP-ban provider first,
then protected-route authentication restores the signed session. Restoration
may run the language-selected activity refresh before the request-forgery and
browser checks; those checks precede current-user use and room processing
(`applications/campfire/http.flow:154-165,178-212,287-323`). The transport constructs the bounded form
value before Flow dispatch, but performs no database write there. A valid bot
key is denied for ordinary room routes. A protected room is first looked up by
`rooms.find-for-user`; missing or inaccessible rooms take the existing
`room-not-found` response path (`applications/campfire/http.flow:108-137,214-247`).

For a found room, `create-message` validates the typed form and calls
`messages.create-for-member`. The helper runs `membership.exists?`, then calls
`messages.create` as a separate host operation (`applications/campfire/http.flow:65-106`,
`applications/campfire/room-message.flow:41-78`). `SqliteProvider.CreateMessage` itself is
transactional: it inserts the message row, inserts an Action Text `body` row for
any present body (including the empty string), touches `messages.updated_at`
when a body is present, always touches `rooms.updated_at`, then commits and
returns the row (`applications/campfire/Persistence/SqliteProvider.fs:70-75,214-279`). Thus dependent
message writes are atomic today, but membership authorization and creation are
not in the same transaction; revocation can race the separate membership read.

Response negotiation also follows persistence: after create, Turbo gets status
200 and an append-message response; a non-Turbo request gets 406
(`applications/campfire/http.flow:82-100`; `applications/campfire/http-tests.flow:488-518`). The real transport maps a
contract failure to 500 and otherwise finalizes cookies and emits the response
(`applications/campfire/Http/Transport.fs:425-442`). A denied room at the initial scoped lookup keeps
the current status-200 room-not-found behavior. Database or helper errors in
`create-message` currently become an empty 500. Session refresh, if due, may
already have committed before CSRF rejection; “no partial message write” must
therefore assert message/rich-text/room state separately from that intentional
session policy.

## Pinned handler and security contracts

At the Rails pin, `MessagesController#create` scopes the room, calls
`@room.messages.create_with_attachment!(message_params)`, then
`broadcast_create` and bot webhooks; `RecordNotFound` renders
`room_not_found` (`.agentlang/campfire-reference/reference/app/controllers/messages_controller.rb:1-28,74-85`).
`RoomScoped#set_room` resolves through
`Current.user.memberships.find_by!`, so an administrator does not bypass room
membership (`.agentlang/campfire-reference/reference/app/controllers/concerns/room_scoped.rb:1-12`). The
permitted form fields are `body`, `attachment`, and `client_message_id`.
`Message` defaults creator to `Current.user`, creates a UUID when the client id
is absent, has rich text, touches its room, and runs `room.receive` after commit
(`.agentlang/campfire-reference/reference/app/models/message.rb:1-15`). These facts do not make the current
Flow renderer or persistence path full Rails parity.

Rails `Authentication` requires authentication, denies bot-key-authenticated
users, and enables `protect_from_forgery with: :exception` except for bot-key
authentication (`.agentlang/campfire-reference/reference/app/controllers/concerns/authentication.rb:5-10,
33-53,101-110`). The existing Flow implementation intentionally ports the
Rust Origin/Sec-Fetch-Site policy instead of Rails' authenticity-token policy;
this is documented as a deliberate divergence in `reports/237-campfire-request-policy.md:7-11`
and `reports/244-campfire-public-login-http.md:34-38`. The current room form has
no hidden Rails authenticity token (`applications/campfire/Http/ResponseRenderer.fs:92-100`). Native
POST parity with the managed control can preserve the existing Flow policy, but
must not be described as Rails CSRF parity. A later Rails-parity decision needs
an explicit token design and oracle; it must not accept both policies as an
unreviewed fallback.

Rails message callbacks also define important work beyond the synchronous SQL
write: `after_create_commit` invokes `room.receive` (`.agentlang/campfire-reference/reference/app/models/message.rb:11-13`), which
updates unread memberships and schedules push work (`.agentlang/campfire-reference/reference/app/models/room.rb:48-50,79-85`);
`broadcast_create` sends the room message and unread-room updates
(`.agentlang/campfire-reference/reference/app/models/message/broadcasts.rb:1-16`); the controller delivers webhooks to eligible
bots (`.agentlang/campfire-reference/reference/app/controllers/messages_controller.rb:24-25,79-85`). `create_with_attachment!` processes
and analyzes attachments (`.agentlang/campfire-reference/reference/app/models/message/attachment.rb:7-39`). Current Flow rejects
attachments, stores only the optional plain body, and does not implement these
post-commit protocols.

## Smallest safe typed write capability

Add one narrow host operation for the atomic storage precondition and write,
for example:

```text
campfire.messages.create-if-member(
  user-id: UserId,
  room-id: RoomId,
  now: UtcInstant,
  client-message-id: Option<String>,
  body: Option<String>
) -> Result<Option<MessageRow>, DbError>
effects db.read, db.write, random.read
```

`Ok(None)` means the membership predicate failed; Flow maps that to its existing
`RoomMessageError.access-denied`. `Ok(Some(row))` means the complete write
committed. `Error(DbError)` is the existing typed storage failure. Keep the
authorization outcome and mapping in Flow. The fixed storage predicate enforces
the already-selected user/room membership inside the same write transaction; it
does not add administrator bypass, status filtering, public-room access, or any
new policy.

Pass `request.now` as the refined UTC-microsecond `UtcInstant` rather than using
an implicit worker clock. Format it to the same UTC text as
`SqliteDetails.formatTimestamp`: `yyyy-MM-dd HH:mm:ss`, adding six fractional
digits only when nonzero. Generate a lowercase `D`-format UUID only for
`client-message-id = None`; preserve every supplied value, including empty. The
explicit timestamp and random effect keep the compiler contract auditable and
the managed/native oracle deterministic.

The native callback should use only fixed prepared statements and do this on
the owning worker connection:

1. Validate the exact operation tag, input count/types/tags, layout indices,
   text extents, refined timestamp, output type, and a conservative exact
   success-output extent before any SQL side effect. Pre-generate a missing UUID.
2. Start `BEGIN IMMEDIATE` before checking `memberships(user_id, room_id)`.
   If absent, roll back the read-only transaction and return typed `Ok(None)`.
3. Insert the `messages` row with the supplied/generated client id, trusted
   creator id and room id, and explicit formatted timestamp. Insert the Action
   Text row only for `Some body`, including `Some ""`; when present, touch the
   message timestamp. Always touch the room timestamp. Keep the fixed
   `name='body'`, `record_type='Message'`, and `record_id` values from the
   managed provider.
4. Construct the exact typed `Result<Option<MessageRow>, DbError>` into the
   already-reserved output area while still in the transaction, verify the
   serialized extent/layout, then commit last. On any earlier error, clear the
   result extent, reset statements, roll back, and verify autocommit before
   returning/reusing the worker. If cleanup fails, poison the context as the
   existing adapter does.

The preflight is essential: the compiler reserves callback output capacity
before invoking the native adapter, but validates/commits the returned typed
value only after the adapter returns (`src/AgentLang.Llvm/OwningStackAot.fs:5526-5589`). A write
adapter must reject an insufficient success extent before beginning the write;
otherwise the database could commit and the later owning-output validation
could fail, leaving a retry-visible message without a successful response.
The fixed 16 MiB callback ceiling remains; never truncate the body or output.

This is one bounded transactional capability, not a transaction API, raw SQL
surface, or SQL mailbox. Reuse the existing worker-owned connection and
thread-affinity checks. SQLite remains single-writer: acquire IMMEDIATE before
the membership read, finish/reset every statement, and commit/rollback before
rendering, network I/O, or event delivery. The existing five-second busy wait
does not respect shorter HTTP deadlines; strict expansion must add a
request-deadline-bounded busy wait/cancellation cleanup path or explicitly
withhold the production write gate. Do not retry an arbitrary callback or only
the last update after a busy/commit error. Keep the root's strict WAL, FULL,
foreign-key, private-cache and patched-SQLite policy; do not add a SQL mailbox.

## Compiler and source boundary

Keep `CampfireRoomReadV1` pinned to `campfire.http.room-read` and its current
nine-operation closure. Add a separate compiler-minted profile such as
`CampfireHttpMessageWriteV1` for a dedicated Flow entry that accepts the closed
`CampfireHttpRequest` and returns `CampfireHttpResponse`. It should compose the
existing cookie/session restoration, refresh, forgery, browser, current-user,
IP-ban, scoped-room and response helpers, but not call the generic
`campfire.http.dispatch`; that dispatcher also reaches login/logout and other
routes. The compiler validator should pin the exact entry name, signature,
effects, request/response record field order, nominal refinements and enum case
orders, the operation catalog (including the one new transaction operation),
and reject any other host operation. It must preserve current call ordering and
the room-not-found and negotiation branches rather than moving authorization
into a broad native HTTP switch.

The current `CampfireHttpRequest`, `HttpMessageInput`, `CampfireHttpResponse`,
`MessageRow`, `RoomMessageError`, `UtcInstant`, and route/view enums already
provide the required data shapes (`applications/campfire/http-types.flow`,
`applications/campfire/campfire-types.flow`,
`applications/campfire/session-policy.flow`). Prefer no schema/ABI version changes. If adding a
specific typed outcome is necessary, pin it in the new profile and bump the
relevant schema/profile fingerprint deliberately. `UtcInstant` is UTC
microseconds since Unix epoch, range `[-62135596800000000,
253402300799999999]` (`applications/campfire/session-policy.flow:1-17`); `RoomId` and `UserId` are
nominal Int wrappers without positivity refinements. Do not add positive-id
constraints that change the current contract.

Expected source areas for implementation:

- Flow: `applications/campfire/room-message.flow` and `applications/campfire/http.flow`; preserve
  `RoomMessageError` mapping and add a focused message-write entry.
- Managed oracle: `applications/campfire/Host/CampfireHost.fs` and
  `applications/campfire/Persistence/SqliteProvider.fs`, implementing the same
  composite operation/transaction and explicit timestamp behavior.
- Native profile: `src/AgentLang.Llvm/OwningStackAot.fs`, a dedicated ABI
  declaration under `src/AgentLang.Llvm/native/`, and the fixed SQL callback in
  `applications/campfire/Native/room_read_adapter.c/.h` plus its static SQL
  statement definitions. The read profile's existing operation table remains
  unchanged.
- Native HTTP: `applications/campfire/Native/http/native_http_host.c` must route
  only the fixed message POST to the new entry and preserve the existing
  request-form limits, session/cookie finalization, and response encoding.
  `applications/campfire/Http/Transport.fs` remains the managed control; `applications/campfire/Http/ResponseRenderer.fs` is the
  current managed output oracle until a separately scoped Rails template port.
- Validation: a focused native-message-write suite should compile/run the new
  profile at O0/O2 and compare complete typed response and DB state with the
  managed provider using the same existing-schema fixture. Keep the room-read
  suite as a regression gate.

## Acceptance gates

1. **Compile-time closure:** accept the exact typed entry and operation; reject
   wrong host signature/effects, added enum/type changes, unknown operations,
   and the generic dispatcher. Existing room-read O0/O2 profile remains byte
   and behavior stable.
2. **Provider parity:** compare supplied and generated client ids, absent versus
   empty body, timestamps at zero/subsecond/day-boundary/negative Unix instant,
   returned `MessageRow`, and full messages/rich-text/room rows against
   `SqliteProvider`. Assert body row fixed literals and timestamps. Use a
   deterministic UUID source for managed tests and a validated CNG UUID vector
   or injection point for native behavior; no credential fixtures in artifacts.
3. **No-write rejection:** no session, invalid/expired cookie, bot key, banned
   IP, wrong Origin, `null` Origin, cross-site metadata, unsupported browser,
   inaccessible room, malformed/duplicate form, unsupported media/attachment,
   missing message root, oversize body, and low output capacity all leave the
   message, rich-text, and room state unchanged. Assert the intentional
   pre-CSRF session-refresh behavior separately. A concurrent membership revoke
   that wins before `BEGIN IMMEDIATE` must return the typed denial with no
   partial rows; no admin bypass.
4. **Atomic failures:** inject failure at message insert, Action Text insert,
   message touch, room touch and COMMIT. Each failed operation leaves no
   partial message/rich-text/timestamp changes, restores autocommit or poisons
   the context, and proves subsequent reuse only after confirmed cleanup.
   Assert no output-capacity/typed-output failure can occur after commit by
   testing actual exports with the pinned owning layout and canaries.
5. **Concurrency/deadline:** run real concurrent readers with a writer and
   competing POST writers against separate worker connections. Verify one
   writer at a time, final row counts and uniqueness, busy failure before any
   partial state, clean reuse after contention, request-deadline cancellation
   shorter than the legacy five-second timeout, and no worker/statement kept
   inside rendering or network waits. Record WAL/checkpoint progress and
   transaction stage/error diagnostics; do not infer write throughput from the
   existing read benchmark.
6. **HTTP parity:** issue authenticated POSTs through native and managed
   controls with identical bounded forms, cookies, UA and negotiation. Compare
   status, response bytes/content type/location, cookie mutations and complete
   database state. Include Turbo success, non-Turbo's current post-write 406,
   missing room, membership revocation, CSRF rejection and refresh-before-CSRF.
   Preserve the fixed route and existing response renderer contract.

## Explicit scope limits

Passing the above data/HTTP gates would establish one compiled POST transaction
slice, not full Rails message-create parity and not full Campfire migration.
Current rendering is intentionally a minimal encoded article/Turbo append
(`applications/campfire/Http/ResponseRenderer.fs:36-42,83-100`); Rails' Turbo template appends the
full message partial (`.agentlang/campfire-reference/reference/app/views/messages/create.turbo_stream.erb:1`)
and the controller emits Action Cable/unread updates, bot webhooks and
post-commit `room.receive` work. Attachments and their processing are also
unsupported. Treat live delivery, unread state, push and webhook behavior as an
explicit separate acceptance dependency before describing the complete POST
handler as Rails-compatible. If they are deferred, label the milestone
“native message transaction + synchronous response,” retain the route gap in
the 177-row inventory, and do not mark the route or migration complete. The
application delivery plan likewise lists message creation before live delivery
and reserves remaining routes, assets, jobs, storage and deployment for later
work (`docs/CAMPFIRE-IMPLEMENTATION.md:31-46,67-78`; `docs/CAMPFIRE-AOT-PLAN.md:158-172`).

No compile or runtime validation was run because this task is a read-only
implementation plan. Source review used the exact managed Flow/transport/
provider, compiler profile and native adapter sources, SQLite policy, and the
locally checked pinned Rails submodule above.

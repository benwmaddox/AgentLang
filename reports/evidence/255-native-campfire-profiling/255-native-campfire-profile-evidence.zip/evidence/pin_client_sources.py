from pathlib import Path
import hashlib, json
repo=Path(__file__).resolve().parents[2]
root=Path(__file__).resolve().parent
current=(repo/'experiments/AgentLang.Campfire.HttpMeasure/Program.cs').read_text()
original=current.replace('int MaxBodyBytes = 1048576, long? ClientAffinityMask = null);','int MaxBodyBytes = 1048576);')
begin=original.index('        using Process measurementClient = Process.GetCurrentProcess();')
end=original.index('        using var handler = new SocketsHttpHandler',begin)
original=original[:begin]+original[end:]
needle='        using Process? server = config.ServerPid == 0 ? null : Process.GetProcessById(config.ServerPid);\n'
assert original.count(needle)==1
original=original.replace(needle,needle+'        using Process measurementClient = Process.GetCurrentProcess();\n')
original=original.replace('            effectiveClientAffinityMask,\n','')
rows=[]
for label,source,artifact in [('cpu-only',original,'client-artifacts'),('fixed-affinity',current,'fixed-client-artifacts')]:
    source_bytes=source.encode()
    checksum=hashlib.sha256(source_bytes).digest()
    binary=root/artifact/'bin/HttpMeasure/release/HttpMeasure.dll'
    pdb=binary.with_suffix('.pdb')
    assert checksum in pdb.read_bytes(), f'{label}: source checksum absent from compiler Portable PDB'
    rows.append(dict(label=label,sourceSha256=checksum.hex(),binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(),portablePdbSha256=hashlib.sha256(pdb.read_bytes()).hexdigest(),compilerSourceChecksumPresent=True))
original_path=root/'client-cpu-only-source.cs'
assert not original_path.exists()
original_path.write_bytes(original.encode())
(root/'client-source-pins.json').write_text(json.dumps(dict(method='Exact source SHA256 appears in each compiler Portable PDB; CPU-only source reconstructed by reversing only the subsequent affinity edit',builds=rows),indent=2)+'\n')
print('Both client source snapshots match checksums retained in their compiler Portable PDBs')

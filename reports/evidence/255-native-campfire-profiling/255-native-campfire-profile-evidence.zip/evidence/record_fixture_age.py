from pathlib import Path
import ctypes as c, datetime as dt, hashlib, json, sys
repo = Path(__file__).resolve().parents[2]
dll = repo / '.agentlang/campfire-native-release-254/http-host/build-trusted-generated-20261013T001909875Z-29a304bb68ce443d97da87ff6b5ce8c0/O2/e_sqlite3.dll'
assert hashlib.sha256(dll.read_bytes()).hexdigest() == 'b7385d722c83fb52142a00477a726723745916d22a555711ee89834c1111fb2e'
sql = c.CDLL(str(dll))
sql.sqlite3_open_v2.argtypes = [c.c_char_p,c.POINTER(c.c_void_p),c.c_int,c.c_char_p]
sql.sqlite3_prepare_v2.argtypes = [c.c_void_p,c.c_char_p,c.c_int,c.POINTER(c.c_void_p),c.c_void_p]
sql.sqlite3_step.argtypes = [c.c_void_p]
sql.sqlite3_column_int64.argtypes = [c.c_void_p,c.c_int]; sql.sqlite3_column_int64.restype = c.c_int64
sql.sqlite3_column_text.argtypes = [c.c_void_p,c.c_int]; sql.sqlite3_column_text.restype = c.c_char_p
sql.sqlite3_finalize.argtypes = [c.c_void_p]
sql.sqlite3_close.argtypes = [c.c_void_p]
rows = []
now = dt.datetime.now(dt.timezone.utc)
for label in ['native','reference']:
    db = c.c_void_p(); stmt = c.c_void_p()
    path = repo / f'.agentlang/campfire-native-http-253/native-smoke/{label}.sqlite'
    assert sql.sqlite3_open_v2(str(path).encode(),c.byref(db),1|0x8000|0x40000,None) == 0
    try:
        query = b'SELECT COUNT(*), MIN(last_active_at), MAX(last_active_at) FROM sessions'
        assert sql.sqlite3_prepare_v2(db,query,-1,c.byref(stmt),None) == 0
        assert sql.sqlite3_step(stmt) == 100
        earliest = sql.sqlite3_column_text(stmt,1).decode()
        latest = sql.sqlite3_column_text(stmt,2).decode()
        parsed = dt.datetime.fromisoformat(earliest).replace(tzinfo=dt.timezone.utc)
        rows.append(dict(host=label,sessionCount=sql.sqlite3_column_int64(stmt,0),earliestLastActiveUtc=earliest,latestLastActiveUtc=latest,oldestSessionAgeSeconds=(now-parsed).total_seconds()))
    finally:
        if stmt: assert sql.sqlite3_finalize(stmt) == 0
        assert sql.sqlite3_close(db) == 0
output = Path(sys.argv[1])
assert not output.exists()
output.write_text(json.dumps(dict(capturedUtc=now.isoformat(),sqliteVersion='3.53.3',fixtureOnly=True,rows=rows),indent=2)+'\n')
print('Recorded only synthetic session counts, timestamps and ages; no cookies or tokens')

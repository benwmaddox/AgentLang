param([ValidateSet('Off','On')][string]$StageProfile,[ValidateSet('O0','O2')][string]$Optimization)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:\code\AgentLang'
$fixture=Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'
$output=Join-Path $repo '.agentlang/campfire-native-profile-255/http-validation'
$null=New-Item -ItemType Directory -Path $output -Force
$label="$StageProfile-$Optimization"
$receipt=Join-Path $output "$label-redacted-receipt.json"
if(Test-Path -LiteralPath $receipt){throw 'Immutable receipt exists'}
& dotnet (Join-Path $repo '.agentlang/campfire-native-release-254/http-checker-artifacts/bin/AgentLang.Campfire.NativeHttp.Tests/release/AgentLang.Campfire.NativeHttp.Tests.dll') (Join-Path $fixture 'private-request.json') (Join-Path $fixture 'synthetic-secret.txt') $receipt
if($LASTEXITCODE -ne 0){throw 'Cookie/header parity failed'}
& (Join-Path $fixture 'corpus.ps1') -Port 13773 -ResultName "profile255-$label-corpus.json"
Copy-Item -LiteralPath (Join-Path $fixture "profile255-$label-corpus.json") -Destination (Join-Path $output "$label-corpus.json")
if($Optimization -eq 'O2'){
 & (Join-Path $repo 'tests/AgentLang.Campfire.NativeHttp.Tests/transport-limits.ps1') -ReceiptPath (Join-Path $output "$label-transport.json")
}

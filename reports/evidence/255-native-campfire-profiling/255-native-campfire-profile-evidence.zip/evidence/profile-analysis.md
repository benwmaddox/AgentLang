# Campfire native HTTP stage-profile analysis

All six run receipts, build receipts, import audits, host logs, affinity receipts where required, and two measurement repeats per run passed validation.
The host runtimes were TrustedGenerated O2 builds. The first four runs used the CPU-only client build without process affinity; the final two used the separately pinned fixed-affinity client build.

| Run | Instrumentation | Workers | Client concurrency | Client build | Host affinity | Client affinity | Correct responses | Host requests | req/s | Response body bytes | Scrub bytes | Server CPU cores | Worker-loop CPU ms | Avg profiled service µs/GET |
|---|---:|---:|---:|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| off-four-c8 | Off | 4 | 8 | cpu-only | unfixed | unfixed | 192164 | — | 6404.93 | 860894720 | — | 3.922 | — | — |
| on-four-c8 | On | 4 | 8 | cpu-only | unfixed | unfixed | 191992 | 192032 | 6399.28 | 860124160 | 12585009152 | 3.920 | 117625.000 | 619.078 |
| on-eight-c8 | On | 8 | 8 | cpu-only | unfixed | unfixed | 100021 | 100061 | 3333.78 | 448094080 | 6557597696 | 7.625 | 228812.500 | 2335.291 |
| on-eight-c4 | On | 8 | 4 | cpu-only | unfixed | unfixed | 190212 | 190252 | 6340.16 | 852149760 | 12468355072 | 3.676 | 110312.500 | 583.708 |
| fixed-four-c16 | On | 4 | 16 | fixed-affinity | 0x5401 (4 cores) | 0x3f03fc | 196096 | 196136 | 6535.56 | 878510080 | 12853968896 | 3.883 | 116515.625 | 607.081 |
| fixed-eight-c16 | On | 8 | 16 | fixed-affinity | 0x5401 (4 cores) | 0x3f03fc | 190934 | 190974 | 6363.36 | 855384320 | 12515672064 | 3.922 | 117671.875 | 1229.399 |

## Profiled stage totals

Totals are summed over all workers in each run.

| Run | Stage | Calls | QPC ticks | Mean µs/call | Max µs/call |
|---|---|---:|---:|---:|---:|
| off-four-c8 | instrumentation off | — | — | — | — |
| on-four-c8 | receive_wait | 192036 | 1863233633 | 970.252 | 24423849.300 |
| on-four-c8 | input_prepare | 192032 | 6570450 | 3.422 | 95.400 |
| on-four-c8 | api_execute | 192032 | 1060464755 | 552.233 | 5154.900 |
| on-four-c8 | renderer | 384064 | 35135143 | 9.148 | 325.100 |
| on-four-c8 | cookie_finalize | 192032 | 842014 | 0.438 | 74.300 |
| on-four-c8 | send_api | 192032 | 78355669 | 40.803 | 1934.500 |
| on-four-c8 | request_scrub | 192032 | 7460334 | 3.885 | 94.200 |
| on-eight-c8 | receive_wait | 100069 | 9653627017 | 9646.971 | 78782193.400 |
| on-eight-c8 | input_prepare | 100061 | 4198020 | 4.195 | 52.900 |
| on-eight-c8 | api_execute | 100061 | 2259823110 | 2258.445 | 9883.400 |
| on-eight-c8 | renderer | 200122 | 20431109 | 10.209 | 142.700 |
| on-eight-c8 | cookie_finalize | 100061 | 537599 | 0.537 | 15.700 |
| on-eight-c8 | send_api | 100061 | 46860895 | 46.832 | 1139.700 |
| on-eight-c8 | request_scrub | 100061 | 4864697 | 4.862 | 91.400 |
| on-eight-c4 | receive_wait | 190260 | 12499277840 | 6569.577 | 70147694.000 |
| on-eight-c4 | input_prepare | 190252 | 6784002 | 3.566 | 155.900 |
| on-eight-c4 | api_execute | 190252 | 984338403 | 517.387 | 3504.600 |
| on-eight-c4 | renderer | 380504 | 34133687 | 8.971 | 197.900 |
| on-eight-c4 | cookie_finalize | 190252 | 890406 | 0.468 | 60.600 |
| on-eight-c4 | send_api | 190252 | 77058676 | 40.503 | 1725.100 |
| on-eight-c4 | request_scrub | 190252 | 7311799 | 3.843 | 119.200 |
| fixed-four-c16 | receive_wait | 196140 | 2256675937 | 1150.543 | 28135226.200 |
| fixed-four-c16 | input_prepare | 196136 | 5877373 | 2.997 | 1144.400 |
| fixed-four-c16 | api_execute | 196136 | 1063080901 | 542.012 | 6570.400 |
| fixed-four-c16 | renderer | 392272 | 34106687 | 8.695 | 1766.700 |
| fixed-four-c16 | cookie_finalize | 196136 | 722998 | 0.369 | 94.800 |
| fixed-four-c16 | send_api | 196136 | 79748128 | 40.660 | 3517.400 |
| fixed-four-c16 | request_scrub | 196136 | 7167436 | 3.654 | 1562.700 |
| fixed-eight-c16 | receive_wait | 190982 | 7340360920 | 3843.483 | 65527784.500 |
| fixed-eight-c16 | input_prepare | 190974 | 23251560 | 12.175 | 14910.100 |
| fixed-eight-c16 | api_execute | 190974 | 1618529635 | 847.513 | 48269.500 |
| fixed-eight-c16 | renderer | 381948 | 45637800 | 11.949 | 13598.200 |
| fixed-eight-c16 | cookie_finalize | 190974 | 820513 | 0.430 | 2528.100 |
| fixed-eight-c16 | send_api | 190974 | 596767201 | 312.486 | 22444.100 |
| fixed-eight-c16 | request_scrub | 190974 | 62826334 | 32.898 | 20065.600 |

## Worker CPU totals

Per-worker CPU from the stage-enabled host; each value is converted from 100 ns units.

| Run | Worker | Full GETs | User ms | Kernel ms | Total ms |
|---|---:|---:|---:|---:|---:|
| off-four-c8 | instrumentation off | — | — | — | — |
| on-four-c8 | 0 | 47731 | 26453.125 | 3062.500 | 29515.625 |
| on-four-c8 | 1 | 47813 | 26296.875 | 3062.500 | 29359.375 |
| on-four-c8 | 2 | 48086 | 26343.750 | 2968.750 | 29312.500 |
| on-four-c8 | 3 | 48402 | 26578.125 | 2859.375 | 29437.500 |
| on-eight-c8 | 0 | 12108 | 27468.750 | 1250.000 | 28718.750 |
| on-eight-c8 | 1 | 12260 | 27500.000 | 1281.250 | 28781.250 |
| on-eight-c8 | 2 | 12276 | 27468.750 | 1218.750 | 28687.500 |
| on-eight-c8 | 3 | 12273 | 27484.375 | 1000.000 | 28484.375 |
| on-eight-c8 | 4 | 12752 | 27125.000 | 1328.125 | 28453.125 |
| on-eight-c8 | 5 | 12809 | 27328.125 | 1359.375 | 28687.500 |
| on-eight-c8 | 6 | 12782 | 27390.625 | 1015.625 | 28406.250 |
| on-eight-c8 | 7 | 12801 | 27359.375 | 1234.375 | 28593.750 |
| on-eight-c4 | 0 | 23745 | 11515.625 | 1781.250 | 13296.875 |
| on-eight-c4 | 1 | 23765 | 12531.250 | 1640.625 | 14171.875 |
| on-eight-c4 | 2 | 23741 | 11968.750 | 1593.750 | 13562.500 |
| on-eight-c4 | 3 | 23798 | 12453.125 | 1812.500 | 14265.625 |
| on-eight-c4 | 4 | 23813 | 12218.750 | 1437.500 | 13656.250 |
| on-eight-c4 | 5 | 23811 | 12343.750 | 1531.250 | 13875.000 |
| on-eight-c4 | 6 | 23784 | 12187.500 | 1718.750 | 13906.250 |
| on-eight-c4 | 7 | 23795 | 12296.875 | 1281.250 | 13578.125 |
| fixed-four-c16 | 0 | 49104 | 26015.625 | 3203.125 | 29218.750 |
| fixed-four-c16 | 1 | 48967 | 26453.125 | 2703.125 | 29156.250 |
| fixed-four-c16 | 2 | 49085 | 26203.125 | 2906.250 | 29109.375 |
| fixed-four-c16 | 3 | 48980 | 26265.625 | 2765.625 | 29031.250 |
| fixed-eight-c16 | 0 | 19919 | 11218.750 | 1406.250 | 12625.000 |
| fixed-eight-c16 | 1 | 19821 | 10828.125 | 1234.375 | 12062.500 |
| fixed-eight-c16 | 2 | 19103 | 10953.125 | 1156.250 | 12109.375 |
| fixed-eight-c16 | 3 | 19299 | 10656.250 | 1109.375 | 11765.625 |
| fixed-eight-c16 | 4 | 19171 | 10593.750 | 1015.625 | 11609.375 |
| fixed-eight-c16 | 5 | 29980 | 16921.875 | 1390.625 | 18312.500 |
| fixed-eight-c16 | 6 | 38426 | 21578.125 | 2171.875 | 23750.000 |
| fixed-eight-c16 | 7 | 25255 | 14093.750 | 1343.750 | 15437.500 |

## Timer and byte interpretation

The seven host stages are `receive_wait`, `input_prepare`, `api_execute`, `renderer`, `cookie_finalize`, `send_api`, and `request_scrub`. `receive_wait` times the blocking HTTP.sys receive call and is excluded from service totals. The renderer is intentionally timed twice per successful GET: once to measure required body capacity and once to render into the committed buffer. The other five profiled service stages must each have one call per full GET. Each maximum is the largest observed call, not a percentile.

The aggregate service-stage ticks sum worker intervals; concurrent workers can overlap, so this sum is not host wall-clock latency. The per-GET mean divides that aggregate by all host GETs, including warmups. It omits routing and request parsing outside the named scopes and includes QPC instrumentation overhead. It is not comparable to the HTTP client's end-to-end latency quantiles.

`worker_loop_*_100ns` is per-thread CPU from after worker allocation until the receive loop exits. It includes blocked receive time only insofar as the operating system charges CPU, includes both 20-request warmup sets and the measured requests, and excludes allocation/release. The client `serverCpu*` fields instead bracket each measured client interval after warmup; they include client drain and memory-sampling overhead. These CPU windows are not interchangeable.

`responseBytes` counts successful HTTP response entity-body bytes validated by the client. The host's 65,536 `request_buffer_scrub_bytes_per_request` value counts memory zeroed after each accepted request; it is not wire request bytes. The client does not measure request-header wire bytes.

The Off build receipt and import audit confirm the builder's stage-profile pin is zero and that the executable omits `QueryPerformanceCounter`, `QueryPerformanceFrequency`, and `GetThreadTimes`. The On build audits require all three imports. The Off run therefore has no stage breakdown.

The HTTP client uses closed-loop HTTP/1.1 keepalive, validates status and the complete body SHA-256, does not follow redirects or decompress, and includes in-flight drain in measured duration. Each repeat has 20 warmups followed by a 15-second deadline; latency histogram values are upper bounds for successful responses only. Client and server CPU are process deltas, not machine-wide percentages.

The four initial runs used the CPU-only HttpMeasure source/binary pin; the two `fixed-*` runs used the separately pinned affinity-aware client. Fixed-run receipts verify the native server remained on four logical processors mapped to four distinct physical cores, and the client mask excludes every sibling of those cores. The fixed runs use concurrency 16. Their results should not be treated as a pure extension of the original four-run matrix because client binary and CPU placement changed together. Server CPU can exceed four equivalent cores slightly from sampling/window granularity; the report preserves measured values instead of clipping them.

Pinned client builds: CPU-only `f683beb03cf16b2b5f9ef2988794abb20d834b40fbaeaf1f2dfc6421c62c260d` and affinity-aware `920480aecbec44a590aee8dd4bca17dc6d2d2ba61871323ff1feda2f9ac1050f`.

Host source SHA-256: `bb1fbe71dc0912d6b96f1107a5143f4873a5346502d337a0f192c80d52085a49`. Builder SHA-256: `b69da8cdd80c0cea178a3dd185aeea2274487fff633b3c63ec301691b9bdf416`.

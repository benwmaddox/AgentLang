from pathlib import Path
import hashlib, json, re, zipfile
repo=Path(__file__).resolve().parents[2]
private=Path(__file__).resolve().parent
output=repo/'reports/evidence/255-native-campfire-profiling'
assert not output.exists(), 'Immutable evidence already exists'
files={}
def sha(data): return hashlib.sha256(data).hexdigest()
def add(path,archive,kind):
    path=Path(path); resolved=path.resolve()
    assert resolved.is_relative_to(repo) and path.is_file() and not path.is_symlink()
    assert '..' not in Path(archive).parts and not archive.startswith('/')
    assert not re.search(r'(?i)\.config\.json$|\.sqlite|synthetic-secret|private-request|private-measure',archive)
    assert archive not in files
    files[archive]=(path,kind)
current=[
 'applications/campfire/Native/http/native_http_host.c',
 'applications/campfire/Native/http/README.md',
 'scripts/Build-CampfireNativeHttp.ps1',
 'experiments/AgentLang.Campfire.HttpMeasure/Program.cs',
 'experiments/AgentLang.Campfire.HttpMeasure/README.md',
 'experiments/AgentLang.Campfire.HttpMeasure/HttpMeasure.csproj',
 'docs/SQLITE-POLICY.md',
]
for path in current: add(repo/path,'sources/'+path,'source')
for name in ['aggregate_profiles.py','profile-analysis.json','profile-analysis.md','topology.c','topology.exe','topology.json','topology.build.log','fixture-age-before.json','fixture-age-after.json','client-source-pins.json','client-cpu-only-source.cs','pin_client_sources.py','sql-investigation.md','native-message-write-plan.md','Run-Host.ps1','Measure.ps1','Apply-Affinity.ps1','Validate-Http.ps1','record_fixture_age.py','seal_evidence.py']:
    add(private/name,'evidence/'+name,'artifact' if name.endswith('.exe') else 'receipt')
for label,root in [('Off','build-trusted-generated-20261013T004712321Z-dc0de276832b4742870012ed517e1423'),('On','build-trusted-generated-20261013T004722145Z-7bced881402d4015b5c82f1b98d53205')]:
    build=private/'http-host'/root
    pins=json.loads((build/'source-pins.json').read_text(encoding='utf-8-sig'))
    for path,digest in pins.items():
        source=build/'http_host_pins.h' if path=='generated/http_host_pins.h' else repo/path
        assert sha(source.read_bytes()) == digest.lower(), path
    for name in ['http_host_pins.h','source-pins.json']: add(build/name,f'build/{label}/{name}','receipt')
    for opt in ['O0','O2']:
        receipt=json.loads((build/opt/'build-receipt.json').read_text(encoding='utf-8-sig'))
        assert receipt['RuntimeProfile']=='trusted-generated' and receipt['StageProfile']==label
        for name,key in [('native_http_host.exe','HostExeSha256'),('owning-stack-native-host.dll','ModuleSha256'),('owning-stack-native-host-manifest.json','ManifestSha256'),('e_sqlite3.dll','SqliteSha256')]:
            assert sha((build/opt/name).read_bytes())==receipt[key].lower()
        for name in ['native_http_host.exe','build-receipt.json','native-imports.txt']:
            add(build/opt/name,f'build/{label}/{opt}/{name}','artifact')
        for name in [f'{label}-{opt}-redacted-receipt.json',f'{label}-{opt}-corpus.json']:
            add(private/'http-validation'/name,'http/'+name,'receipt')
        if opt=='O2': add(private/'http-validation'/f'{label}-{opt}-transport.json',f'http/{label}-{opt}-transport.json','receipt')
    if label=='On':
        for name in ['owning-stack-native-host.dll','owning-stack-native-host-manifest.json','e_sqlite3.dll']:
            add(build/'O2'/name,'native-module/'+name,'artifact')
for run in ['off-four-c8','on-four-c8','on-eight-c8','on-eight-c4','fixed-four-c16','fixed-eight-c16']:
    root=private/'runs'/run
    for name in ['build-receipt.json','run-receipt.json','native-host.log','measurement-summary.json','native-r1.result.json','native-r2.result.json','native-r1.client.log','native-r2.client.log']:
        add(root/name,f'runs/{run}/{name}','receipt')
    if run.startswith('fixed-'): add(root/'affinity-receipt.json',f'runs/{run}/affinity-receipt.json','receipt')
for label,root in [('cpu-only','client-artifacts'),('fixed-affinity','fixed-client-artifacts')]:
    for name in ['HttpMeasure.dll','HttpMeasure.pdb','HttpMeasure.runtimeconfig.json']:
        add(private/root/'bin/HttpMeasure/release'/name,f'clients/{label}/{name}','artifact')
baseline=repo/'reports/evidence/254-native-campfire-release/254-native-campfire-release-evidence.zip'
assert sha(baseline.read_bytes())=='5cc2c1b0071ad02f8d47a767b8b385f03b923ea7a976807cec3052cb404a29a7'
entries=[]
snapshots={}
for archive,(path,kind) in sorted(files.items()):
    data=path.read_bytes(); snapshots[archive]=data
    if kind!='artifact' and path.suffix in ['.json','.log','.md']:
        text=data.decode('utf-8-sig')
        assert not re.search(r'(?im)^\s*(?:cookie|set-cookie|authorization)\s*:|"(?:Cookie|Secret|Password)"\s*:|(?:session_token|_campfire_session)\s*=',text), archive
    entries.append(dict(archivePath=archive,sourcePath=str(path.relative_to(repo)).replace('\\','/'),sha256=sha(data),sizeBytes=len(data),kind=kind))
embedded=dict(format='campfire-native-profile-evidence-v1',baseline254Sha256=sha(baseline.read_bytes()),currentSources=[dict(path=path,sha256=sha((repo/path).read_bytes())) for path in current],entries=entries,excluded=['private configurations','cookies/secrets','fixture databases','raw HTTP headers'])
embedded_bytes=(json.dumps(embedded,indent=2)+'\n').encode()
output.mkdir()
archive=output/'255-native-campfire-profile-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in snapshots.items(): z.writestr(name,data)
    z.writestr('evidence-manifest.json',embedded_bytes)
entries.append(dict(archivePath='evidence-manifest.json',sourcePath='generated:embedded-manifest',sha256=sha(embedded_bytes),sizeBytes=len(embedded_bytes),kind='receipt'))
external=dict(format=embedded['format'],archiveFile=archive.name,archiveSha256=sha(archive.read_bytes()),archiveSizeBytes=archive.stat().st_size,entries=entries)
(output/'manifest.json').write_text(json.dumps(external,indent=2)+'\n')
for name,(path,_) in files.items(): assert sha(path.read_bytes())==sha(snapshots[name]), name
print(json.dumps(dict(archiveSha256=external['archiveSha256'],archiveSizeBytes=external['archiveSizeBytes'],entries=len(entries),currentSources=len(current))))

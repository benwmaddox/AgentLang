param([Parameter(Mandatory)][int]$ServerPid,[Parameter(Mandatory)][string]$RunName,[switch]$After)
$ErrorActionPreference='Stop'
$repo='D:\code\AgentLang'
$root=Join-Path $repo ".agentlang/campfire-native-profile-255/runs/$RunName"
$topologyPath=Join-Path $repo '.agentlang/campfire-native-profile-255/topology.json'
$topology=Get-Content $topologyPath -Raw | ConvertFrom-Json
$selection=$topology.selection
if($selection.group -ne 0 -or $selection.selectedPhysicalCoreCount -ne 4){throw 'Expected four physical cores in group zero'}
$mask=[Convert]::ToInt64($selection.serverMaskHex.Substring(2),16)
$siblings=[Convert]::ToInt64($selection.siblingMaskHex.Substring(2),16)
$client=[Convert]::ToInt64($selection.clientMaskHex.Substring(2),16)
$process=Get-Process -Id $ServerPid
$expected=[IO.Path]::GetFullPath((Join-Path $repo '.agentlang/campfire-native-profile-255/http-host/build-trusted-generated-20261013T004722145Z-7bced881402d4015b5c82f1b98d53205/O2/native_http_host.exe'))
if(-not [StringComparer]::OrdinalIgnoreCase.Equals($process.Path,$expected)){throw 'PID is not the selected task-owned profiling executable'}
if($After){
 $receipt=Get-Content (Join-Path $root 'affinity-start.json') -Raw | ConvertFrom-Json
 $process.Refresh()
 $receipt.effectiveServerMaskAfter=$process.ProcessorAffinity.ToInt64()
 if($receipt.effectiveServerMaskAfter -ne $mask){throw 'Server affinity changed during benchmark'}
 $path=Join-Path $root 'affinity-receipt.json'
 if(Test-Path -LiteralPath $path){throw 'Immutable affinity receipt exists'}
 $receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding utf8
}else{
 $process.ProcessorAffinity=[IntPtr]::new($mask)
 $process.Refresh()
 if($process.ProcessorAffinity.ToInt64() -ne $mask){throw 'Server affinity did not match requested mask'}
 $path=Join-Path $root 'affinity-start.json'
 if(Test-Path -LiteralPath $path){throw 'Affinity start already recorded'}
 [ordered]@{serverPid=$ServerPid;requestedServerMask=$mask;effectiveServerMaskBefore=$mask;effectiveServerMaskAfter=$null;clientMask=$client;serverSiblingMask=$siblings;serverLogicalProcessors=@($selection.selectedLogicalProcessorIndices);serverPhysicalCores=@($selection.physicalCoreIndices);topologySha256=(Get-FileHash $topologyPath -Algorithm SHA256).Hash.ToLowerInvariant();scope='Native process only; one logical processor from each of four distinct physical cores. Kernel HTTP.sys work is not restricted by this process affinity.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding utf8
}
Write-Output "serverMask=$mask clientMask=$client fourPhysicalCores=true"

#!/usr/bin/env python3
"""Validate and summarize the six completed Campfire host profile runs.

Only reads the explicit run roots under this private profile directory. It
does not read request configurations, cookies, SQLite databases, or secrets.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from typing import Any


PROFILE_DIR = Path(__file__).resolve().parent
REPO_ROOT = PROFILE_DIR.parents[1]
DEFAULT_RUNS_ROOT = PROFILE_DIR / "runs"
OUTPUT_JSON = PROFILE_DIR / "profile-analysis.json"
OUTPUT_MD = PROFILE_DIR / "profile-analysis.md"
HOST_SOURCE = REPO_ROOT / "applications/campfire/Native/http/native_http_host.c"
BUILD_SCRIPT = REPO_ROOT / "scripts/Build-CampfireNativeHttp.ps1"

STAGE_NAMES = (
    "receive_wait",
    "input_prepare",
    "api_execute",
    "renderer",
    "cookie_finalize",
    "send_api",
    "request_scrub",
)
PROFILED_SERVICE_STAGES = tuple(name for name in STAGE_NAMES if name != "receive_wait")
REQUIRED_PROFILE_IMPORTS = {
    "QueryPerformanceCounter",
    "QueryPerformanceFrequency",
    "GetThreadTimes",
}
CASE_SPECS = {
    "off-four-c8": {"stageProfile": "Off", "workers": 4, "concurrency": 8, "clientBuild": "cpu-only", "affinity": False},
    "on-four-c8": {"stageProfile": "On", "workers": 4, "concurrency": 8, "clientBuild": "cpu-only", "affinity": False},
    "on-eight-c8": {"stageProfile": "On", "workers": 8, "concurrency": 8, "clientBuild": "cpu-only", "affinity": False},
    "on-eight-c4": {"stageProfile": "On", "workers": 8, "concurrency": 4, "clientBuild": "cpu-only", "affinity": False},
    "fixed-four-c16": {"stageProfile": "On", "workers": 4, "concurrency": 16, "clientBuild": "fixed-affinity", "affinity": True},
    "fixed-eight-c16": {"stageProfile": "On", "workers": 8, "concurrency": 16, "clientBuild": "fixed-affinity", "affinity": True},
}
CLIENT_PINS = PROFILE_DIR / "client-source-pins.json"
CLIENT_SOURCE_PATHS = {
    "cpu-only": PROFILE_DIR / "client-cpu-only-source.cs",
    "fixed-affinity": REPO_ROOT / "experiments/AgentLang.Campfire.HttpMeasure/Program.cs",
}
CLIENT_ARTIFACT_ROOTS = {
    "cpu-only": PROFILE_DIR / "client-artifacts/bin/HttpMeasure/release",
    "fixed-affinity": PROFILE_DIR / "fixed-client-artifacts/bin/HttpMeasure/release",
}


class EvidenceError(Exception):
    pass


def fail(message: str) -> None:
    raise EvidenceError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"cannot read JSON evidence {path}: {exc}")


def need(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def integer(value: Any, label: str, *, minimum: int = 0) -> int:
    need(isinstance(value, int) and not isinstance(value, bool), f"{label} must be an integer")
    need(value >= minimum, f"{label} must be >= {minimum}")
    return value


def finite_number(value: Any, label: str, *, minimum: float = 0.0) -> float:
    need(isinstance(value, (int, float)) and not isinstance(value, bool), f"{label} must be numeric")
    result = float(value)
    need(math.isfinite(result) and result >= minimum, f"{label} must be finite and >= {minimum}")
    return result


def parse_fields(line: str, prefix: str) -> dict[str, str]:
    tail = line[len(prefix):].strip()
    fields: dict[str, str] = {}
    for token in tail.split():
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        fields[key] = value
    return fields


def line_fields(lines: list[str], prefix: str, label: str) -> dict[str, str]:
    matches = [line for line in lines if line.startswith(prefix)]
    need(len(matches) == 1, f"expected one {label} line, found {len(matches)}")
    return parse_fields(matches[0], prefix)


def field_int(fields: dict[str, str], key: str, label: str, *, minimum: int = 0) -> int:
    need(key in fields, f"{label} is missing {key}")
    try:
        value = int(fields[key], 10)
    except ValueError:
        fail(f"{label}.{key} is not an integer")
    return integer(value, f"{label}.{key}", minimum=minimum)


def check_source_audit() -> dict[str, Any]:
    need(HOST_SOURCE.is_file(), f"missing host source: {HOST_SOURCE}")
    need(BUILD_SCRIPT.is_file(), f"missing build script: {BUILD_SCRIPT}")
    host = HOST_SOURCE.read_text(encoding="utf-8")
    builder = BUILD_SCRIPT.read_text(encoding="utf-8")
    expected_enum = re.search(
        r"typedef enum host_stage_id\s*\{(?P<body>.*?)HOST_STAGE_COUNT\s*=\s*7",
        host,
        re.S,
    )
    need(expected_enum is not None, "host stage enum no longer declares seven stages")
    enum_body = expected_enum.group("body")
    enum_names = re.findall(r"HOST_STAGE_([A-Z_]+)\s*=\s*\d+", enum_body)
    expected_enum_names = [name.upper() for name in STAGE_NAMES]
    need(enum_names == expected_enum_names, f"unexpected host stage enum: {enum_names}")
    renderer_calls = host.count("host_stage_record(worker, HOST_STAGE_RENDERER, stage_started);")
    need(renderer_calls == 2, f"expected two renderer timing scopes, found {renderer_calls}")
    scope_counts = {
        name: host.count(f"host_stage_record(worker, HOST_STAGE_{name.upper()}, stage_started);")
        for name in STAGE_NAMES
    }
    expected_scope_counts = {
        "receive_wait": 1,
        "input_prepare": 1,
        "api_execute": 1,
        "renderer": 2,
        "cookie_finalize": 2,
        "send_api": 1,
        "request_scrub": 1,
    }
    need(scope_counts == expected_scope_counts, f"stage scope statement counts changed: {scope_counts}")
    need("goto internal_failure;" in host[host.find("if (!finalize_response_cookies("):host.find("content_type = metadata.content_type_utf8;")],
         "cookie finalizer success/failure branches changed; review per-request timing count")
    receive_call = host.find("status = HttpReceiveHttpRequest(")
    receive_record = host.find("host_stage_record(worker, HOST_STAGE_RECEIVE_WAIT, stage_started);")
    need(receive_call >= 0 and receive_record > receive_call, "receive_wait scope must surround HttpReceiveHttpRequest")
    need("host_stage_capture_cpu_start(worker);" in host and "host_stage_capture_cpu_end(worker);" in host,
         "worker CPU capture points are missing")
    need("$stageProfileMacro -eq 0 -and ($hasQpcCounter -or $hasQpcFrequency -or $hasThreadTimes)" in builder,
         "builder no longer rejects stage APIs in Off builds")
    need("$stageProfileMacro -eq 1" in builder and all(name in builder for name in REQUIRED_PROFILE_IMPORTS),
         "builder no longer verifies the required On-profile imports")
    client_pins = check_client_source_pins()
    return {
        "hostSourceSha256": sha256_file(HOST_SOURCE),
        "builderScriptSha256": sha256_file(BUILD_SCRIPT),
        "stageNames": list(STAGE_NAMES),
        "rendererTimingCallsPerFullGet": renderer_calls,
        "stageScopeStatements": scope_counts,
        "cookieFinalizeStatementsAreMutuallyExclusive": True,
        "receiveWaitIncludesBlockingReceive": True,
        "profiledServiceStagesExclude": ["receive_wait"],
        "workerCpuScope": "GetThreadTimes after worker allocation through receive-loop exit; includes receive wait, warmups and other worker idle time; excludes worker allocation and worker_release.",
        "builderChecks": "Off rejects QueryPerformanceCounter, QueryPerformanceFrequency and GetThreadTimes imports; On requires all three.",
        "clientSourcePins": client_pins,
    }


def check_client_source_pins() -> dict[str, Any]:
    need(CLIENT_PINS.is_file(), f"missing client source pin manifest: {CLIENT_PINS}")
    pin_doc = read_json(CLIENT_PINS)
    builds = pin_doc.get("builds")
    need(isinstance(builds, list), "client source pin manifest has no builds array")
    by_label = {item.get("label"): item for item in builds if isinstance(item, dict)}
    need(set(by_label) == set(CLIENT_SOURCE_PATHS), "client source pin labels changed")
    checked: dict[str, Any] = {}
    for label, source_path in CLIENT_SOURCE_PATHS.items():
        pin = by_label[label]
        need(pin.get("compilerSourceChecksumPresent") is True,
             f"{label}: source checksum is not recorded in its Portable PDB")
        source_hash = str(pin.get("sourceSha256", "")).lower()
        binary_hash = str(pin.get("binarySha256", "")).lower()
        pdb_hash = str(pin.get("portablePdbSha256", "")).lower()
        for value, name in ((source_hash, "source"), (binary_hash, "binary"), (pdb_hash, "PDB")):
            need(re.fullmatch(r"[0-9a-f]{64}", value) is not None,
                 f"{label}: invalid {name} SHA-256 in source pin manifest")
        need(source_path.is_file() and sha256_file(source_path) == source_hash,
             f"{label}: source file does not match its recorded compiler checksum")
        artifact_root = CLIENT_ARTIFACT_ROOTS[label]
        binary_path = artifact_root / "HttpMeasure.dll"
        pdb_path = artifact_root / "HttpMeasure.pdb"
        need(binary_path.is_file() and sha256_file(binary_path) == binary_hash,
             f"{label}: client binary does not match the pinned build")
        need(pdb_path.is_file() and sha256_file(pdb_path) == pdb_hash,
             f"{label}: client Portable PDB does not match the pin")
        need(bytes.fromhex(source_hash) in pdb_path.read_bytes(),
             f"{label}: Portable PDB does not contain the recorded source checksum")
        checked[label] = {
            "sourceSha256": source_hash,
            "binarySha256": binary_hash,
            "portablePdbSha256": pdb_hash,
            "compilerSourceChecksumPresent": True,
        }
    return {
        "manifestSha256": sha256_file(CLIENT_PINS),
        "method": pin_doc.get("method"),
        "builds": checked,
    }


def find_matching_build_receipt(run_root: Path, copied_hash: str) -> Path:
    build_root = PROFILE_DIR / "http-host"
    matches = [
        path
        for path in build_root.rglob("build-receipt.json")
        if sha256_file(path) == copied_hash
    ]
    need(len(matches) == 1, f"{run_root.name}: expected one original build receipt matching the copied hash, found {len(matches)}")
    return matches[0]


def validate_build(run_root: Path, expected: dict[str, Any], run_receipt: dict[str, Any]) -> dict[str, Any]:
    receipt_path = run_root / "build-receipt.json"
    need(receipt_path.is_file(), f"{run_root.name}: missing copied build-receipt.json")
    copied_hash = sha256_file(receipt_path)
    need(run_receipt.get("buildReceiptSha256", "").lower() == copied_hash,
         f"{run_root.name}: copied build receipt hash mismatch")
    original_path = find_matching_build_receipt(run_root, copied_hash)
    receipt = read_json(receipt_path)
    need(receipt.get("Optimization") == "O2", f"{run_root.name}: build optimization is not O2")
    need(receipt.get("RuntimeProfile") == "trusted-generated", f"{run_root.name}: build runtime profile is not trusted-generated")
    need(receipt.get("StageProfile") == expected["stageProfile"], f"{run_root.name}: build stage profile mismatch")
    macro = 1 if expected["stageProfile"] == "On" else 0
    need(receipt.get("StageProfileGeneratedPin") == f"CAMPFIRE_HTTP_STAGE_PROFILE={macro}",
         f"{run_root.name}: generated stage-profile pin mismatch")
    need(original_path.parent.name == "O2", f"{run_root.name}: matching build receipt is not under O2")
    import_path = original_path.parent / "native-imports.txt"
    exe_path = original_path.parent / "native_http_host.exe"
    need(import_path.is_file() and exe_path.is_file(), f"{run_root.name}: original build import audit or host executable is missing")
    need(sha256_file(exe_path).lower() == str(receipt.get("HostExeSha256", "")).lower(),
         f"{run_root.name}: host executable does not match build receipt")
    import_text = import_path.read_text(encoding="utf-8", errors="replace")
    symbols = set(re.findall(r"^\s*Symbol:\s*([A-Za-z0-9_]+)", import_text, re.M))
    present = REQUIRED_PROFILE_IMPORTS.intersection(symbols)
    if expected["stageProfile"] == "On":
        need(present == REQUIRED_PROFILE_IMPORTS, f"{run_root.name}: On executable is missing stage-profile imports")
    else:
        need(not present, f"{run_root.name}: Off executable imports stage-profile APIs: {sorted(present)}")
    return {
        "stageProfile": receipt["StageProfile"],
        "runtimeProfile": receipt["RuntimeProfile"],
        "optimization": receipt["Optimization"],
        "buildReceiptSha256": copied_hash,
        "hostExeSha256": str(receipt["HostExeSha256"]).lower(),
        "hostSourceSha256": str(receipt["HostSourceSha256"]).lower(),
        "importAudit": {
            "path": import_path.relative_to(REPO_ROOT).as_posix(),
            "sha256": sha256_file(import_path),
            "stageApiSymbols": sorted(present),
        },
    }


def validate_measurements(
    run_root: Path,
    expected: dict[str, Any],
    *,
    expected_client_mask: int | None = None,
    expected_server_pid: int | None = None,
) -> dict[str, Any]:
    result_paths = sorted(run_root.glob("native-r*.result.json"))
    need(len(result_paths) == 2, f"{run_root.name}: expected two measurement result JSON files, found {len(result_paths)}")
    rows: list[dict[str, Any]] = []
    body_hashes: set[str] = set()
    response_bytes_per_response: set[float] = set()
    for path in result_paths:
        result = read_json(path)
        need(result.get("method") == "GET", f"{run_root.name}/{path.name}: benchmark method is not GET")
        need(result.get("Concurrency") == expected["concurrency"], f"{run_root.name}/{path.name}: concurrency mismatch")
        need(result.get("requestedSeconds") == 15, f"{run_root.name}/{path.name}: expected 15-second requested measurement")
        need(result.get("WarmupRequests") == 20, f"{run_root.name}/{path.name}: expected 20 warmups per repeat")
        need(result.get("ExpectedStatus") in (None, 200), f"{run_root.name}/{path.name}: unexpected expected status")
        if expected["affinity"]:
            need(expected_client_mask is not None, f"{run_root.name}: fixed client mask is missing")
            need(integer(result.get("effectiveClientAffinityMask"), f"{path.name}.effectiveClientAffinityMask", minimum=1)
                 == expected_client_mask,
                 f"{run_root.name}/{path.name}: effective client affinity differs from the affinity receipt")
            need(expected_server_pid is not None and
                 integer(result.get("ServerPid"), f"{path.name}.ServerPid", minimum=1) == expected_server_pid,
                 f"{run_root.name}/{path.name}: benchmark process did not measure the server from its affinity receipt")
        else:
            need(result.get("effectiveClientAffinityMask") is None,
                 f"{run_root.name}/{path.name}: CPU-only client unexpectedly reports a fixed affinity mask")
        uri = result.get("uri")
        need(isinstance(uri, str) and uri.startswith("http://127.0.0.1:13773/rooms/"),
             f"{run_root.name}/{path.name}: URI is not the fixed loopback room GET")
        correct = integer(result.get("correctResponses"), f"{path.name}.correctResponses", minimum=1)
        failures = integer(result.get("failures"), f"{path.name}.failures")
        need(failures == 0, f"{run_root.name}/{path.name}: benchmark has failures")
        need(result.get("errors") == {}, f"{run_root.name}/{path.name}: benchmark error categories are not empty")
        elapsed = finite_number(result.get("measuredSeconds"), f"{path.name}.measuredSeconds", minimum=15.0)
        rate = finite_number(result.get("correctRequestsPerSecond"), f"{path.name}.correctRequestsPerSecond", minimum=0.000001)
        need(abs(rate - correct / elapsed) <= max(0.02, rate * 0.002), f"{run_root.name}/{path.name}: requests/second does not match count and elapsed time")
        response_bytes = integer(result.get("responseBytes"), f"{path.name}.responseBytes", minimum=1)
        bytes_per_response = response_bytes / correct
        response_bytes_per_response.add(bytes_per_response)
        body_hash = result.get("ExpectedBodySha256")
        need(isinstance(body_hash, str) and re.fullmatch(r"[0-9a-fA-F]{64}", body_hash) is not None,
             f"{run_root.name}/{path.name}: expected body SHA-256 is invalid")
        body_hashes.add(body_hash.lower())
        for key in ("serverCpuMilliseconds", "clientCpuMilliseconds", "serverCpuEquivalentCores", "clientCpuEquivalentCores"):
            finite_number(result.get(key), f"{path.name}.{key}")
        for key in ("p50MillisecondsUpperBound", "p95MillisecondsUpperBound", "p99MillisecondsUpperBound"):
            finite_number(result.get(key), f"{path.name}.{key}")
        integer(result.get("sampledServerWorkingSetPeak"), f"{path.name}.sampledServerWorkingSetPeak")
        integer(result.get("sampledServerPrivateBytesPeak"), f"{path.name}.sampledServerPrivateBytesPeak")
        integer(result.get("latencyOverflowAt60Seconds"), f"{path.name}.latencyOverflowAt60Seconds")
        rows.append({
            "repeat": int(re.search(r"r(\d+)", path.name).group(1)),
            "correctResponses": correct,
            "warmupRequests": 20,
            "measuredSeconds": elapsed,
            "correctRequestsPerSecond": rate,
            "responseBytes": response_bytes,
            "averageBodyBytesPerResponse": bytes_per_response,
            "p50MillisecondsUpperBound": float(result["p50MillisecondsUpperBound"]),
            "p95MillisecondsUpperBound": float(result["p95MillisecondsUpperBound"]),
            "p99MillisecondsUpperBound": float(result["p99MillisecondsUpperBound"]),
            "serverCpuMilliseconds": float(result["serverCpuMilliseconds"]),
            "clientCpuMilliseconds": float(result["clientCpuMilliseconds"]),
            "serverCpuEquivalentCores": float(result["serverCpuEquivalentCores"]),
            "clientCpuEquivalentCores": float(result["clientCpuEquivalentCores"]),
            "sampledServerWorkingSetPeak": int(result["sampledServerWorkingSetPeak"]),
            "sampledServerPrivateBytesPeak": int(result["sampledServerPrivateBytesPeak"]),
            "latencyOverflowAt60Seconds": int(result["latencyOverflowAt60Seconds"]),
        })
    need(len(body_hashes) == 1, f"{run_root.name}: response body hash changed between repeats")
    need(len(response_bytes_per_response) == 1, f"{run_root.name}: body byte count changed between repeats")
    rows.sort(key=lambda row: row["repeat"])
    need([row["repeat"] for row in rows] == [1, 2], f"{run_root.name}: repeat numbers are not 1 and 2")
    total_responses = sum(row["correctResponses"] for row in rows)
    total_warmups = sum(row["warmupRequests"] for row in rows)
    total_seconds = sum(row["measuredSeconds"] for row in rows)
    total_bytes = sum(row["responseBytes"] for row in rows)
    server_cpu_ms = sum(row["serverCpuMilliseconds"] for row in rows)
    client_cpu_ms = sum(row["clientCpuMilliseconds"] for row in rows)
    return {
        "method": "GET",
        "expectedStatus": 200,
        "responseBodySha256": next(iter(body_hashes)),
        "repeatCount": len(rows),
        "correctResponses": total_responses,
        "warmupRequests": total_warmups,
        "measuredSeconds": total_seconds,
        "correctRequestsPerSecond": total_responses / total_seconds,
        "responseBytes": total_bytes,
        "averageBodyBytesPerResponse": next(iter(response_bytes_per_response)),
        "serverCpuMilliseconds": server_cpu_ms,
        "clientCpuMilliseconds": client_cpu_ms,
        "serverCpuEquivalentCores": server_cpu_ms / total_seconds / 1000.0,
        "clientCpuEquivalentCores": client_cpu_ms / total_seconds / 1000.0,
        "repeats": rows,
        "clientAffinityMask": expected_client_mask,
        "clientServerPid": expected_server_pid,
    }


def validate_affinity(run_root: Path, expected: dict[str, Any]) -> dict[str, Any] | None:
    if not expected["affinity"]:
        need(not (run_root / "affinity-receipt.json").exists(),
             f"{run_root.name}: unexpected affinity receipt on an unpinned run")
        return None
    receipt_path = run_root / "affinity-receipt.json"
    need(receipt_path.is_file(), f"{run_root.name}: missing affinity-receipt.json")
    receipt = read_json(receipt_path)
    server_pid = integer(receipt.get("serverPid"), f"{run_root.name}.serverPid", minimum=1)
    requested = integer(receipt.get("requestedServerMask"), f"{run_root.name}.requestedServerMask", minimum=1)
    before = integer(receipt.get("effectiveServerMaskBefore"), f"{run_root.name}.effectiveServerMaskBefore", minimum=1)
    after = integer(receipt.get("effectiveServerMaskAfter"), f"{run_root.name}.effectiveServerMaskAfter", minimum=1)
    client = integer(receipt.get("clientMask"), f"{run_root.name}.clientMask", minimum=1)
    siblings = integer(receipt.get("serverSiblingMask"), f"{run_root.name}.serverSiblingMask", minimum=1)
    need(requested == before == after, f"{run_root.name}: server affinity did not remain at the requested mask")
    need(requested.bit_count() == 4, f"{run_root.name}: fixed host mask is not four logical processors")
    need((requested & ~siblings) == 0, f"{run_root.name}: server mask is outside the reported physical-core sibling set")
    need((client & siblings) == 0, f"{run_root.name}: client mask overlaps a server physical core")
    logical = receipt.get("serverLogicalProcessors")
    cores = receipt.get("serverPhysicalCores")
    need(isinstance(logical, list) and len(logical) == 4,
         f"{run_root.name}: expected four server logical processor identities")
    need(isinstance(cores, list) and len(cores) == 4,
         f"{run_root.name}: expected four server physical core identities")
    logical_ids = [integer(value, f"{run_root.name}.serverLogicalProcessors[{index}]")
                   for index, value in enumerate(logical)]
    core_ids = [integer(value, f"{run_root.name}.serverPhysicalCores[{index}]")
                for index, value in enumerate(cores)]
    need(len(set(logical_ids)) == 4, f"{run_root.name}: server logical processors are not distinct")
    need(len(set(core_ids)) == 4, f"{run_root.name}: server logical processors do not map to four distinct physical cores")
    topology_hash = str(receipt.get("topologySha256", "")).lower()
    need(re.fullmatch(r"[0-9a-f]{64}", topology_hash) is not None,
         f"{run_root.name}: invalid topology SHA-256")
    topology_path = PROFILE_DIR / "topology.json"
    need(topology_path.is_file(), f"{run_root.name}: pinned topology.json is missing")
    need(sha256_file(topology_path) == topology_hash,
         f"{run_root.name}: affinity receipt does not match the pinned topology snapshot")
    topology = read_json(topology_path)
    selection = topology.get("selection")
    need(isinstance(selection, dict), f"{run_root.name}: topology selection is missing")
    need(integer(selection.get("group"), f"{run_root.name}.topology.group") == 0,
         f"{run_root.name}: expected a group-zero server selection")
    need(integer(selection.get("selectedPhysicalCoreCount"), f"{run_root.name}.topology.selectedPhysicalCoreCount") == 4,
         f"{run_root.name}: topology selection is not four physical cores")

    def topology_mask(key: str) -> int:
        raw = selection.get(key)
        need(isinstance(raw, str) and re.fullmatch(r"0x[0-9a-fA-F]+", raw) is not None,
             f"{run_root.name}: topology selection has invalid {key}")
        return int(raw, 16)

    topology_server = topology_mask("serverMaskHex")
    topology_siblings = topology_mask("siblingMaskHex")
    topology_client = topology_mask("clientMaskHex")
    active_mask = topology_mask("group0ActiveMaskHex")
    need((requested, siblings, client) == (topology_server, topology_siblings, topology_client),
         f"{run_root.name}: affinity receipt masks differ from the topology selection")
    need(((requested | siblings | client) & ~active_mask) == 0,
         f"{run_root.name}: affinity selection contains processors outside the active group-zero mask")
    selected_physical = selection.get("physicalCoreIndices")
    selected_logical = selection.get("selectedLogicalProcessorIndices")
    selected_core_rows = selection.get("selectedCores")
    need(isinstance(selected_physical, list) and len(selected_physical) == 4,
         f"{run_root.name}: topology does not list four selected physical cores")
    need(isinstance(selected_logical, list) and len(selected_logical) == 4,
         f"{run_root.name}: topology does not list four selected logical processors")
    need(isinstance(selected_core_rows, list) and len(selected_core_rows) == 4,
         f"{run_root.name}: topology does not describe each selected core")
    selected_physical_ids = [integer(value, f"{run_root.name}.topology.physicalCoreIndices[{index}]")
                             for index, value in enumerate(selected_physical)]
    selected_logical_ids = [integer(value, f"{run_root.name}.topology.selectedLogicalProcessorIndices[{index}]")
                            for index, value in enumerate(selected_logical)]
    need(logical_ids == selected_logical_ids and core_ids == selected_physical_ids,
         f"{run_root.name}: receipt processor/core identities differ from the topology selection")
    need(len(set(selected_physical_ids)) == 4 and len(set(selected_logical_ids)) == 4,
         f"{run_root.name}: selected topology identities are not unique")
    need(topology_server == sum(1 << processor for processor in selected_logical_ids),
         f"{run_root.name}: topology server mask is not the four selected logical processors")
    discovered_cores = topology.get("processorCores")
    need(isinstance(discovered_cores, list), f"{run_root.name}: topology has no processor core inventory")
    core_by_index = {item.get("physicalCoreIndex"): item for item in discovered_cores if isinstance(item, dict)}
    for physical_id, logical_id, selected_row in zip(selected_physical_ids, selected_logical_ids, selected_core_rows):
        need(selected_row.get("physicalCoreIndex") == physical_id and
             selected_row.get("logicalProcessorIndex") == logical_id,
             f"{run_root.name}: topology selected-core mapping is inconsistent")
        inventory_row = core_by_index.get(physical_id)
        need(inventory_row is not None, f"{run_root.name}: selected physical core is absent from topology inventory")
        group_masks = inventory_row.get("groupMasks")
        need(isinstance(group_masks, list), f"{run_root.name}: selected physical core lacks processor-group masks")
        group_zero = [row for row in group_masks if isinstance(row, dict) and row.get("group") == 0]
        need(len(group_zero) == 1, f"{run_root.name}: selected physical core lacks a unique group-zero mask")
        core_mask_raw = group_zero[0].get("kaffinityMaskHex")
        need(isinstance(core_mask_raw, str) and re.fullmatch(r"0x[0-9a-fA-F]+", core_mask_raw) is not None,
             f"{run_root.name}: selected physical core has an invalid group-zero mask")
        core_mask = int(core_mask_raw, 16)
        need(core_mask & (1 << logical_id),
             f"{run_root.name}: selected logical processor is not a sibling of its reported physical core")
    need(not (topology_client & topology_siblings),
         f"{run_root.name}: topology client selection overlaps selected server-core siblings")
    return {
        "receiptSha256": sha256_file(receipt_path),
        "topologySha256": topology_hash,
        "serverPid": server_pid,
        "requestedServerMask": requested,
        "effectiveServerMaskBefore": before,
        "effectiveServerMaskAfter": after,
        "serverLogicalProcessors": logical_ids,
        "serverPhysicalCores": core_ids,
        "serverSiblingMask": siblings,
        "clientMask": client,
        "selectedPhysicalCoreCount": 4,
        "serverClientPhysicalCoreDisjoint": True,
    }


def validate_host_log(run_root: Path, expected: dict[str, Any], build: dict[str, Any], benchmark: dict[str, Any]) -> dict[str, Any]:
    log_path = run_root / "native-host.log"
    need(log_path.is_file(), f"{run_root.name}: missing native-host.log")
    text = log_path.read_text(encoding="utf-8", errors="replace")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    need("startup.error=" not in text and "worker.receive status=" not in text and "shutdown.api=" not in text,
         f"{run_root.name}: host log records an error path")
    ready = line_fields(lines, "READY ", "READY")
    need(ready.get("runtime_profile") == "trusted-generated", f"{run_root.name}: READY runtime profile mismatch")
    need(field_int(ready, "workers", "READY", minimum=1) == expected["workers"], f"{run_root.name}: READY worker count mismatch")
    sqlite_lines = [line for line in lines if line.startswith("sqlite.version=")]
    need(len(sqlite_lines) == 1 and "module_iat=pinned" in sqlite_lines[0], f"{run_root.name}: missing pinned SQLite version line")
    shutdown_lines = [line for line in lines if line.startswith("shutdown.workers_cleaned=")]
    need(len(shutdown_lines) == 1, f"{run_root.name}: expected one shutdown summary line")
    shutdown = parse_fields(shutdown_lines[0], "")
    cleaned = field_int(shutdown, "shutdown.workers_cleaned", "shutdown")
    fatal = field_int(shutdown, "shutdown.fatal_status", "shutdown")
    need(cleaned == expected["workers"], f"{run_root.name}: not all workers cleaned up")
    need(fatal == 0, f"{run_root.name}: host fatal status is nonzero")
    stage_headers = [line for line in lines if line.startswith("stage_profile ")]
    stage_rows = [line for line in lines if line.startswith("stage_worker ")]
    if expected["stageProfile"] == "Off":
        need(not stage_headers and not stage_rows, f"{run_root.name}: Off host emitted stage rows")
        return {
            "enabled": False,
            "workerCount": expected["workers"],
            "receivedRequests": None,
            "workerThreadCpu": None,
            "profiledServiceTicks": None,
            "profiledServiceMeanMicrosecondsPerGet": None,
            "requestBufferScrubBytesPerRequest": field_int(ready, "request_buffer_scrub_bytes_per_request", "READY"),
            "requestBufferScrubBytesTotal": None,
            "workers": [],
        }
    need(len(stage_headers) == 1, f"{run_root.name}: expected one On stage-profile header")
    header = parse_fields(stage_headers[0], "stage_profile ")
    need(field_int(header, "enabled", "stage_profile") == 1, f"{run_root.name}: stage profile is disabled")
    need(field_int(header, "workers", "stage_profile", minimum=1) == expected["workers"], f"{run_root.name}: stage worker count mismatch")
    qpc_frequency = field_int(header, "qpc_frequency", "stage_profile", minimum=1)
    need(header.get("units") == "ticks" and header.get("cpu_units") == "100ns", f"{run_root.name}: unexpected stage units")
    need(len(stage_rows) == expected["workers"], f"{run_root.name}: expected one summary row per worker")
    workers: list[dict[str, Any]] = []
    for line in stage_rows:
        fields = parse_fields(line, "stage_worker ")
        index = field_int(fields, "index", "stage_worker")
        received = field_int(fields, "received_requests", f"stage_worker[{index}]")
        need(field_int(fields, "cpu_valid", f"stage_worker[{index}]") == 1, f"{run_root.name}: worker CPU sample invalid")
        user = field_int(fields, "worker_loop_user_100ns", f"stage_worker[{index}]")
        kernel = field_int(fields, "worker_loop_kernel_100ns", f"stage_worker[{index}]")
        stages: dict[str, dict[str, int]] = {}
        for name in STAGE_NAMES:
            label = f"stage_worker[{index}].{name}"
            calls = field_int(fields, f"{name}_calls", label)
            ticks = field_int(fields, f"{name}_ticks", label)
            maximum = field_int(fields, f"{name}_max_ticks", label)
            need(maximum <= ticks, f"{run_root.name}: {label} maximum exceeds its total ticks")
            stages[name] = {"calls": calls, "ticks": ticks, "maxTicks": maximum}
        for name in ("input_prepare", "api_execute", "cookie_finalize", "send_api", "request_scrub"):
            need(stages[name]["calls"] == received,
                 f"{run_root.name}: worker {index} full-GET count mismatch for {name}")
        need(stages["renderer"]["calls"] == 2 * received,
             f"{run_root.name}: worker {index} renderer count is not two calls per full GET")
        need(stages["receive_wait"]["calls"] >= received,
             f"{run_root.name}: worker {index} receive count is below received request count")
        workers.append({
            "index": index,
            "receivedRequests": received,
            "threadCpu": {"user100ns": user, "kernel100ns": kernel, "total100ns": user + kernel},
            "stages": stages,
        })
    workers.sort(key=lambda item: item["index"])
    need([worker["index"] for worker in workers] == list(range(expected["workers"])),
         f"{run_root.name}: worker indices are not a contiguous pool")
    total_requests = sum(worker["receivedRequests"] for worker in workers)
    expected_requests = benchmark["correctResponses"] + benchmark["warmupRequests"]
    need(total_requests == expected_requests,
         f"{run_root.name}: host received {total_requests} requests but benchmark and warmups account for {expected_requests}")
    service: dict[str, dict[str, float | int]] = {}
    service_ticks = 0
    for name in STAGE_NAMES:
        calls = sum(worker["stages"][name]["calls"] for worker in workers)
        ticks = sum(worker["stages"][name]["ticks"] for worker in workers)
        maximum = max(worker["stages"][name]["maxTicks"] for worker in workers)
        mean_us = ticks * 1_000_000.0 / qpc_frequency / calls if calls else 0.0
        service[name] = {
            "calls": calls,
            "totalTicks": ticks,
            "maximumSingleCallTicks": maximum,
            "maximumSingleCallMicroseconds": maximum * 1_000_000.0 / qpc_frequency,
            "meanMicrosecondsPerCall": mean_us,
        }
        if name in PROFILED_SERVICE_STAGES:
            service_ticks += ticks
    for name in ("input_prepare", "api_execute", "cookie_finalize", "send_api", "request_scrub"):
        need(service[name]["calls"] == total_requests, f"{run_root.name}: aggregate {name} count does not match full GET count")
    need(service["renderer"]["calls"] == total_requests * 2,
         f"{run_root.name}: aggregate renderer count is not twice full GET count")
    need(total_requests >= benchmark["correctResponses"], f"{run_root.name}: host count is below successful benchmark responses")
    qpc_mean_per_get = service_ticks * 1_000_000.0 / qpc_frequency / total_requests
    scrub_bytes = field_int(ready, "request_buffer_scrub_bytes_per_request", "READY")
    cpu_user_100ns = sum(worker["threadCpu"]["user100ns"] for worker in workers)
    cpu_kernel_100ns = sum(worker["threadCpu"]["kernel100ns"] for worker in workers)
    return {
        "enabled": True,
        "qpcFrequency": qpc_frequency,
        "workerCount": expected["workers"],
        "receivedRequests": total_requests,
        "warmupRequestsIncluded": benchmark["warmupRequests"],
        "workerThreadCpu": {
            "user100ns": cpu_user_100ns,
            "kernel100ns": cpu_kernel_100ns,
            "total100ns": cpu_user_100ns + cpu_kernel_100ns,
            "totalMilliseconds": (cpu_user_100ns + cpu_kernel_100ns) / 10_000.0,
            "byWorker": [
                {
                    "index": worker["index"],
                    "receivedRequests": worker["receivedRequests"],
                    "user100ns": worker["threadCpu"]["user100ns"],
                    "kernel100ns": worker["threadCpu"]["kernel100ns"],
                    "total100ns": worker["threadCpu"]["total100ns"],
                }
                for worker in workers
            ],
        },
        "profiledServiceStages": list(PROFILED_SERVICE_STAGES),
        "profiledServiceTicks": service_ticks,
        "profiledServiceWorkerMilliseconds": service_ticks * 1000.0 / qpc_frequency,
        "profiledServiceMeanMicrosecondsPerGet": qpc_mean_per_get,
        "aggregateServiceStageTicksMayOverlapAcrossWorkers": True,
        "requestBufferScrubBytesPerRequest": scrub_bytes,
        "requestBufferScrubBytesTotal": scrub_bytes * total_requests,
        "requestWireBytesMeasured": False,
        "stages": service,
        "workers": workers,
    }


def validate_case(case_name: str, runs_root: Path, expected: dict[str, Any]) -> dict[str, Any]:
    run_root = runs_root / case_name
    need(run_root.is_dir(), f"missing completed run directory: {run_root}")
    run_receipt_path = run_root / "run-receipt.json"
    need(run_receipt_path.is_file(), f"{case_name}: missing terminal run-receipt.json")
    run_receipt = read_json(run_receipt_path)
    need(integer(run_receipt.get("terminalExitCode"), f"{case_name}.terminalExitCode") == 0,
         f"{case_name}: native host did not exit cleanly")
    need(integer(run_receipt.get("workers"), f"{case_name}.workers", minimum=1) == expected["workers"],
         f"{case_name}: run receipt worker count mismatch")
    need(run_receipt.get("optimization") == "O2", f"{case_name}: run receipt optimization is not O2")
    affinity = validate_affinity(run_root, expected)
    log_path = run_root / "native-host.log"
    need(log_path.is_file(), f"{case_name}: missing native-host.log")
    need(run_receipt.get("nativeHostLogSha256", "").lower() == sha256_file(log_path),
         f"{case_name}: native host log hash mismatch")
    build = validate_build(run_root, expected, run_receipt)
    benchmark = validate_measurements(
        run_root,
        expected,
        expected_client_mask=None if affinity is None else affinity["clientMask"],
        expected_server_pid=None if affinity is None else affinity["serverPid"],
    )
    host = validate_host_log(run_root, expected, build, benchmark)
    return {
        "name": case_name,
        "stageProfile": expected["stageProfile"],
        "runtimeProfile": build["runtimeProfile"],
        "optimization": build["optimization"],
        "workers": expected["workers"],
        "clientConcurrency": expected["concurrency"],
        "clientBuild": expected["clientBuild"],
        "affinity": affinity,
        "runRoot": run_root.relative_to(REPO_ROOT).as_posix(),
        "hostExitCode": 0,
        "fatalStatus": 0,
        "cleanedWorkers": expected["workers"],
        "build": build,
        "benchmark": benchmark,
        "hostProfile": host,
    }


def markdown_report(report: dict[str, Any]) -> str:
    cases = report["cases"]
    lines = [
        "# Campfire native HTTP stage-profile analysis",
        "",
        "All six run receipts, build receipts, import audits, host logs, affinity receipts where required, and two measurement repeats per run passed validation.",
        "The host runtimes were TrustedGenerated O2 builds. The first four runs used the CPU-only client build without process affinity; the final two used the separately pinned fixed-affinity client build.",
        "",
        "| Run | Instrumentation | Workers | Client concurrency | Client build | Host affinity | Client affinity | Correct responses | Host requests | req/s | Response body bytes | Scrub bytes | Server CPU cores | Worker-loop CPU ms | Avg profiled service µs/GET |",
        "|---|---:|---:|---:|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for case in cases:
        bench = case["benchmark"]
        host = case["hostProfile"]
        service_mean = host["profiledServiceMeanMicrosecondsPerGet"]
        service_text = "—" if service_mean is None else f"{service_mean:.3f}"
        received = "—" if host["receivedRequests"] is None else str(host["receivedRequests"])
        worker_cpu = host["workerThreadCpu"]
        worker_cpu_ms = "—" if worker_cpu is None else f"{worker_cpu['totalMilliseconds']:.3f}"
        scrub_bytes = "—" if host["requestBufferScrubBytesTotal"] is None else str(host["requestBufferScrubBytesTotal"])
        affinity = case["affinity"]
        host_mask = "unfixed" if affinity is None else f"0x{affinity['requestedServerMask']:x} (4 cores)"
        client_mask = "unfixed" if affinity is None else f"0x{affinity['clientMask']:x}"
        lines.append(
            f"| {case['name']} | {case['stageProfile']} | {case['workers']} | {case['clientConcurrency']} | "
            f"{case['clientBuild']} | {host_mask} | {client_mask} | {bench['correctResponses']} | {received} | {bench['correctRequestsPerSecond']:.2f} | "
            f"{bench['responseBytes']} | {scrub_bytes} | {bench['serverCpuEquivalentCores']:.3f} | "
            f"{worker_cpu_ms} | {service_text} |"
        )
    lines.extend(["", "## Profiled stage totals", "", "Totals are summed over all workers in each run.", "",
                  "| Run | Stage | Calls | QPC ticks | Mean µs/call | Max µs/call |", "|---|---|---:|---:|---:|---:|"])
    for case in cases:
        host = case["hostProfile"]
        if not host["enabled"]:
            lines.append(f"| {case['name']} | instrumentation off | — | — | — | — |")
            continue
        for name in STAGE_NAMES:
            stage = host["stages"][name]
            lines.append(
                f"| {case['name']} | {name} | {stage['calls']} | {stage['totalTicks']} | "
                f"{stage['meanMicrosecondsPerCall']:.3f} | {stage['maximumSingleCallMicroseconds']:.3f} |"
            )
    lines.extend(["", "## Worker CPU totals", "", "Per-worker CPU from the stage-enabled host; each value is converted from 100 ns units.", "",
                  "| Run | Worker | Full GETs | User ms | Kernel ms | Total ms |", "|---|---:|---:|---:|---:|---:|"])
    for case in cases:
        cpu = case["hostProfile"]["workerThreadCpu"]
        if cpu is None:
            lines.append(f"| {case['name']} | instrumentation off | — | — | — | — |")
            continue
        for worker in cpu["byWorker"]:
            lines.append(
                f"| {case['name']} | {worker['index']} | {worker['receivedRequests']} | "
                f"{worker['user100ns'] / 10_000.0:.3f} | {worker['kernel100ns'] / 10_000.0:.3f} | "
                f"{worker['total100ns'] / 10_000.0:.3f} |"
            )
    lines.extend([
        "",
        "## Timer and byte interpretation",
        "",
        "The seven host stages are `receive_wait`, `input_prepare`, `api_execute`, `renderer`, `cookie_finalize`, `send_api`, and `request_scrub`. `receive_wait` times the blocking HTTP.sys receive call and is excluded from service totals. The renderer is intentionally timed twice per successful GET: once to measure required body capacity and once to render into the committed buffer. The other five profiled service stages must each have one call per full GET. Each maximum is the largest observed call, not a percentile.",
        "",
        "The aggregate service-stage ticks sum worker intervals; concurrent workers can overlap, so this sum is not host wall-clock latency. The per-GET mean divides that aggregate by all host GETs, including warmups. It omits routing and request parsing outside the named scopes and includes QPC instrumentation overhead. It is not comparable to the HTTP client's end-to-end latency quantiles.",
        "",
        "`worker_loop_*_100ns` is per-thread CPU from after worker allocation until the receive loop exits. It includes blocked receive time only insofar as the operating system charges CPU, includes both 20-request warmup sets and the measured requests, and excludes allocation/release. The client `serverCpu*` fields instead bracket each measured client interval after warmup; they include client drain and memory-sampling overhead. These CPU windows are not interchangeable.",
        "",
        "`responseBytes` counts successful HTTP response entity-body bytes validated by the client. The host's 65,536 `request_buffer_scrub_bytes_per_request` value counts memory zeroed after each accepted request; it is not wire request bytes. The client does not measure request-header wire bytes.",
        "",
        "The Off build receipt and import audit confirm the builder's stage-profile pin is zero and that the executable omits `QueryPerformanceCounter`, `QueryPerformanceFrequency`, and `GetThreadTimes`. The On build audits require all three imports. The Off run therefore has no stage breakdown.",
        "",
        "The HTTP client uses closed-loop HTTP/1.1 keepalive, validates status and the complete body SHA-256, does not follow redirects or decompress, and includes in-flight drain in measured duration. Each repeat has 20 warmups followed by a 15-second deadline; latency histogram values are upper bounds for successful responses only. Client and server CPU are process deltas, not machine-wide percentages.",
        "",
        "The four initial runs used the CPU-only HttpMeasure source/binary pin; the two `fixed-*` runs used the separately pinned affinity-aware client. Fixed-run receipts verify the native server remained on four logical processors mapped to four distinct physical cores, and the client mask excludes every sibling of those cores. The fixed runs use concurrency 16. Their results should not be treated as a pure extension of the original four-run matrix because client binary and CPU placement changed together. Server CPU can exceed four equivalent cores slightly from sampling/window granularity; the report preserves measured values instead of clipping them.",
        "",
        f"Pinned client builds: CPU-only `{report['sourceAudit']['clientSourcePins']['builds']['cpu-only']['binarySha256']}` and affinity-aware `{report['sourceAudit']['clientSourcePins']['builds']['fixed-affinity']['binarySha256']}`.",
        "",
        f"Host source SHA-256: `{report['sourceAudit']['hostSourceSha256']}`. Builder SHA-256: `{report['sourceAudit']['builderScriptSha256']}`.",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-root", type=Path, default=DEFAULT_RUNS_ROOT,
                        help="Completed run roots containing the four original and two fixed-affinity cases")
    parser.add_argument("--case", action="append", choices=tuple(CASE_SPECS),
                        help="Validate selected completed cases; partial selection is allowed only with --validate-only")
    parser.add_argument("--validate-only", action="store_true", help="Validate all evidence without writing reports")
    parser.add_argument("--replace", action="store_true", help="Replace existing derived profile-analysis files")
    args = parser.parse_args()
    runs_root = args.runs_root.resolve()
    try:
        runs_root.relative_to(PROFILE_DIR)
    except ValueError:
        fail("runs root must stay inside the private campfire-native-profile-255 directory")
    selected_names = args.case or list(CASE_SPECS)
    need(len(set(selected_names)) == len(selected_names), "case selection contains duplicates")
    need(args.validate_only or selected_names == list(CASE_SPECS),
         "partial case selection cannot write final reports")
    source_audit = check_source_audit()
    cases = [validate_case(name, runs_root, CASE_SPECS[name]) for name in selected_names]
    host_hashes = {case["build"]["hostSourceSha256"] for case in cases}
    need(len(host_hashes) == 1, "host source hash differs across stage-profile cases")
    need(next(iter(host_hashes)) == source_audit["hostSourceSha256"],
         "built host source hash does not match the current audited source")
    response_hashes = {case["benchmark"]["responseBodySha256"] for case in cases}
    need(len(response_hashes) == 1, "response body hash differs across selected cases")
    report = {
        "schemaVersion": 1,
        "passed": True,
        "runsRoot": runs_root.relative_to(REPO_ROOT).as_posix(),
        "sourceAudit": source_audit,
        "methodology": {
            "caseCount": len(cases),
            "measuredRepeatsPerCase": 2,
            "warmupRequestsPerRepeat": 20,
            "requestedSecondsPerRepeat": 15,
            "requestMethod": "GET",
            "benchmarkFailures": 0,
            "responseBodySha256": next(iter(response_hashes)),
            "stageProfileOffImportAudit": "verified by exact copied build receipt and matching original native-imports.txt",
            "latencyPercentiles": "per-repeat histogram upper bounds; raw samples are not stored and repeats are not merged",
            "serviceTime": "sum of selected per-worker QPC stage ticks; receive_wait excluded; renderer intentionally has two calls per GET; concurrent worker intervals can overlap",
            "requestByteAccounting": "wire request bytes are not measured; responseBytes counts checked response bodies and request scrub bytes count host memory zeroed",
        },
        "cases": cases,
    }
    encoded = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    markdown = markdown_report(report)
    if args.validate_only:
        print(f"validated cases={len(cases)}; no report files written")
        return 0
    if not args.replace:
        need(not OUTPUT_JSON.exists() and not OUTPUT_MD.exists(),
             "profile-analysis outputs already exist; use --replace only for an intentional regeneration")
    OUTPUT_JSON.write_text(encoded, encoding="utf-8", newline="\n")
    OUTPUT_MD.write_text(markdown, encoding="utf-8", newline="\n")
    print(f"validated cases={len(cases)}; wrote {OUTPUT_JSON} and {OUTPUT_MD}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except EvidenceError as exc:
        print(f"profile aggregation failed: {exc}", file=sys.stderr)
        sys.exit(2)

param([Parameter(Mandatory)][string]$BuildRoot,[int]$Workers=4,[string]$Optimization='O2',[Parameter(Mandatory)][string]$RunName)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:\code\AgentLang'
$root=Join-Path $repo ".agentlang/campfire-native-profile-255/runs/$RunName"
if(Test-Path -LiteralPath $root){throw 'Immutable run already exists'}
$null=New-Item -ItemType Directory -Path $root
$build=Join-Path $BuildRoot $Optimization
Copy-Item -LiteralPath (Join-Path $build 'build-receipt.json') -Destination (Join-Path $root 'build-receipt.json')
& (Join-Path $build 'native_http_host.exe') --module (Join-Path $build 'owning-stack-native-host.dll') --manifest (Join-Path $build 'owning-stack-native-host-manifest.json') --db (Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke/native.sqlite') --secret-file (Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke/synthetic-secret.txt') --port 13773 --workers $Workers --stop-event 'Local\CampfireNative255Stop' 2>&1 | Tee-Object -FilePath (Join-Path $root 'native-host.log')
$terminalCode=$LASTEXITCODE
[ordered]@{terminalExitCode=$terminalCode;workers=$Workers;optimization=$Optimization;buildReceiptSha256=(Get-FileHash (Join-Path $root 'build-receipt.json') -Algorithm SHA256).Hash.ToLowerInvariant();nativeHostLogSha256=(Get-FileHash (Join-Path $root 'native-host.log') -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $root 'run-receipt.json') -Encoding utf8
if($terminalCode -ne 0){throw "Native host failed with exit $terminalCode"}

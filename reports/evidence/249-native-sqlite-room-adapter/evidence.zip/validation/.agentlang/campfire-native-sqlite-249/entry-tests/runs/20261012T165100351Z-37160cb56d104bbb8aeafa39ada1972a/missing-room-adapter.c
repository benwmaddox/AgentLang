/* No required native host symbol. */
int unrelated_native_adapter(void) { return 0; }

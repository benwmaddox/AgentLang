%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 4, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 16, i32 16, i32 16, i32 16, i32 0 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 4
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 4, 4
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 4, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 5
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 5, 5
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 5, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %descriptor.element.31 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 0
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 1
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 2
  %descriptor.value.37 = load i32, ptr %descriptor.field.36, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 3
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 4
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %argument.type.valid.42 = icmp eq i32 %descriptor.value.33, 4
  br i1 %argument.type.valid.42, label %argument.type.ok.43, label %frame.failure.0
argument.type.ok.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.sub.48 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.46 = icmp ule i32 %descriptor.value.41, %context.value.45
  %descriptor.offset.inside.47 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.49 = icmp ule i32 %descriptor.value.37, %stack.sub.48
  %descriptor.payload.inside.50 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.51 = and i1 %descriptor.owner.inside.46, %descriptor.offset.inside.47
  %descriptor.range.inside.53 = and i1 %descriptor.owner.offset.valid.51, %descriptor.extent.inside.49
  %descriptor.range.valid.52 = and i1 %descriptor.range.inside.53, %descriptor.payload.inside.50
  %descriptor.type.valid.54 = icmp eq i32 4, 4
  %descriptor.valid.55 = and i1 %descriptor.range.valid.52, %descriptor.type.valid.54
  br i1 %descriptor.valid.55, label %descriptor.valid.56, label %descriptor.invalid.57
descriptor.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.56:
  %descriptor.initialized.status.58 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.59 = icmp eq i32 %descriptor.initialized.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.35, ptr %local.offset.3, align 4
  store i32 %descriptor.value.37, ptr %local.extent.4, align 4
  store i32 %descriptor.value.39, ptr %local.payload.5, align 4
  store i32 %descriptor.value.41, ptr %local.owner.end.6, align 4
  store i32 4, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.35, i32 20, i32 %descriptor.value.39, i32 %descriptor.value.41, i32 %descriptor.value.37)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %local.is.active.68 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.68, label %local.descriptor.active.69, label %local.descriptor.inactive.70
local.descriptor.active.69:
  %local.check.offset.72 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.73 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.74 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.75 = load i32, ptr %local.owner.end.6, align 4
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %local.check.owner.end.75, %local.check.offset.72
  %descriptor.owner.inside.78 = icmp ule i32 %local.check.owner.end.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %local.check.offset.72, %local.check.owner.end.75
  %descriptor.extent.inside.81 = icmp ule i32 %local.check.extent.73, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 %local.check.payload.74, %local.check.extent.73
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  br i1 %descriptor.range.valid.84, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.72, i32 %local.check.extent.73)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  br label %local.descriptor.checked.71
local.descriptor.inactive.70:
  br label %local.descriptor.checked.71
local.descriptor.checked.71:
  %local.is.active.91 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.91, label %local.descriptor.active.92, label %local.descriptor.inactive.93
local.descriptor.active.92:
  %local.check.offset.95 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.96 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.97 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.98 = load i32, ptr %local.owner.end.12, align 4
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %stack.sub.103 = sub i32 %local.check.owner.end.98, %local.check.offset.95
  %descriptor.owner.inside.101 = icmp ule i32 %local.check.owner.end.98, %context.value.100
  %descriptor.offset.inside.102 = icmp ule i32 %local.check.offset.95, %local.check.owner.end.98
  %descriptor.extent.inside.104 = icmp ule i32 %local.check.extent.96, %stack.sub.103
  %descriptor.payload.inside.105 = icmp ule i32 %local.check.payload.97, %local.check.extent.96
  %descriptor.owner.offset.valid.106 = and i1 %descriptor.owner.inside.101, %descriptor.offset.inside.102
  %descriptor.range.inside.108 = and i1 %descriptor.owner.offset.valid.106, %descriptor.extent.inside.104
  %descriptor.range.valid.107 = and i1 %descriptor.range.inside.108, %descriptor.payload.inside.105
  br i1 %descriptor.range.valid.107, label %descriptor.valid.109, label %descriptor.invalid.110
descriptor.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.109:
  %descriptor.initialized.status.111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.95, i32 %local.check.extent.96)
  %helper.ok.112 = icmp eq i32 %descriptor.initialized.status.111, 0
  br i1 %helper.ok.112, label %helper.continue.113, label %frame.failure.0
helper.continue.113:
  br label %local.descriptor.checked.94
local.descriptor.inactive.93:
  br label %local.descriptor.checked.94
local.descriptor.checked.94:
  %local.is.active.114 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.114, label %local.descriptor.active.115, label %local.descriptor.inactive.116
local.descriptor.active.115:
  %local.check.offset.118 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.119 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.120 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.121 = load i32, ptr %local.owner.end.18, align 4
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %local.check.owner.end.121, %local.check.offset.118
  %descriptor.owner.inside.124 = icmp ule i32 %local.check.owner.end.121, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %local.check.offset.118, %local.check.owner.end.121
  %descriptor.extent.inside.127 = icmp ule i32 %local.check.extent.119, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %local.check.payload.120, %local.check.extent.119
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  br i1 %descriptor.range.valid.130, label %descriptor.valid.132, label %descriptor.invalid.133
descriptor.invalid.133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.132:
  %descriptor.initialized.status.134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.118, i32 %local.check.extent.119)
  %helper.ok.135 = icmp eq i32 %descriptor.initialized.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  br label %local.descriptor.checked.117
local.descriptor.inactive.116:
  br label %local.descriptor.checked.117
local.descriptor.checked.117:
  %step.status.137 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.138 = icmp eq i32 %step.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.141 = load i32, ptr %context.field.140, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %step.status.142 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.143 = icmp eq i32 %step.status.142, 0
  br i1 %helper.ok.143, label %helper.continue.144, label %frame.failure.0
helper.continue.144:
  %local.resolved.offset.145 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.146 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.147 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.148 = load i32, ptr %local.owner.end.6, align 4
  %context.field.149 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.150 = load i32, ptr %context.field.149, align 4
  %stack.sub.153 = sub i32 %local.resolved.owner.end.148, %local.resolved.offset.145
  %descriptor.owner.inside.151 = icmp ule i32 %local.resolved.owner.end.148, %context.value.150
  %descriptor.offset.inside.152 = icmp ule i32 %local.resolved.offset.145, %local.resolved.owner.end.148
  %descriptor.extent.inside.154 = icmp ule i32 %local.resolved.extent.146, %stack.sub.153
  %descriptor.payload.inside.155 = icmp ule i32 %local.resolved.payload.147, %local.resolved.extent.146
  %descriptor.owner.offset.valid.156 = and i1 %descriptor.owner.inside.151, %descriptor.offset.inside.152
  %descriptor.range.inside.158 = and i1 %descriptor.owner.offset.valid.156, %descriptor.extent.inside.154
  %descriptor.range.valid.157 = and i1 %descriptor.range.inside.158, %descriptor.payload.inside.155
  %descriptor.type.valid.159 = icmp eq i32 4, 4
  %descriptor.valid.160 = and i1 %descriptor.range.valid.157, %descriptor.type.valid.159
  br i1 %descriptor.valid.160, label %descriptor.valid.161, label %descriptor.invalid.162
descriptor.invalid.162:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.161:
  %descriptor.initialized.status.163 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.145, i32 %local.resolved.extent.146)
  %helper.ok.164 = icmp eq i32 %descriptor.initialized.status.163, 0
  br i1 %helper.ok.164, label %helper.continue.165, label %frame.failure.0
helper.continue.165:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.145, i32 20, i32 %local.resolved.payload.147, i32 %local.resolved.owner.end.148, i32 %local.resolved.extent.146)
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %runtime.ok.168 = icmp eq i32 %context.value.167, 0
  br i1 %runtime.ok.168, label %runtime.continue.169, label %frame.failure.0
runtime.continue.169:
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %stack.sub.174 = sub i32 %local.resolved.owner.end.148, %local.resolved.offset.145
  %descriptor.owner.inside.172 = icmp ule i32 %local.resolved.owner.end.148, %context.value.171
  %descriptor.offset.inside.173 = icmp ule i32 %local.resolved.offset.145, %local.resolved.owner.end.148
  %descriptor.extent.inside.175 = icmp ule i32 %local.resolved.extent.146, %stack.sub.174
  %descriptor.payload.inside.176 = icmp ule i32 %local.resolved.payload.147, %local.resolved.extent.146
  %descriptor.owner.offset.valid.177 = and i1 %descriptor.owner.inside.172, %descriptor.offset.inside.173
  %descriptor.range.inside.179 = and i1 %descriptor.owner.offset.valid.177, %descriptor.extent.inside.175
  %descriptor.range.valid.178 = and i1 %descriptor.range.inside.179, %descriptor.payload.inside.176
  %descriptor.type.valid.180 = icmp eq i32 4, 4
  %descriptor.valid.181 = and i1 %descriptor.range.valid.178, %descriptor.type.valid.180
  br i1 %descriptor.valid.181, label %descriptor.valid.182, label %descriptor.invalid.183
descriptor.invalid.183:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.182:
  %descriptor.initialized.status.184 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.145, i32 %local.resolved.extent.146)
  %helper.ok.185 = icmp eq i32 %descriptor.initialized.status.184, 0
  br i1 %helper.ok.185, label %helper.continue.186, label %frame.failure.0
helper.continue.186:
  %local.is.active.187 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.187, label %local.descriptor.active.188, label %local.descriptor.inactive.189
local.descriptor.active.188:
  %local.check.offset.191 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.192 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.193 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.194 = load i32, ptr %local.owner.end.6, align 4
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %stack.sub.199 = sub i32 %local.check.owner.end.194, %local.check.offset.191
  %descriptor.owner.inside.197 = icmp ule i32 %local.check.owner.end.194, %context.value.196
  %descriptor.offset.inside.198 = icmp ule i32 %local.check.offset.191, %local.check.owner.end.194
  %descriptor.extent.inside.200 = icmp ule i32 %local.check.extent.192, %stack.sub.199
  %descriptor.payload.inside.201 = icmp ule i32 %local.check.payload.193, %local.check.extent.192
  %descriptor.owner.offset.valid.202 = and i1 %descriptor.owner.inside.197, %descriptor.offset.inside.198
  %descriptor.range.inside.204 = and i1 %descriptor.owner.offset.valid.202, %descriptor.extent.inside.200
  %descriptor.range.valid.203 = and i1 %descriptor.range.inside.204, %descriptor.payload.inside.201
  br i1 %descriptor.range.valid.203, label %descriptor.valid.205, label %descriptor.invalid.206
descriptor.invalid.206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.205:
  %descriptor.initialized.status.207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.191, i32 %local.check.extent.192)
  %helper.ok.208 = icmp eq i32 %descriptor.initialized.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  br label %local.descriptor.checked.190
local.descriptor.inactive.189:
  br label %local.descriptor.checked.190
local.descriptor.checked.190:
  %local.is.active.210 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.210, label %local.descriptor.active.211, label %local.descriptor.inactive.212
local.descriptor.active.211:
  %local.check.offset.214 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.215 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.216 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.217 = load i32, ptr %local.owner.end.12, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.sub.222 = sub i32 %local.check.owner.end.217, %local.check.offset.214
  %descriptor.owner.inside.220 = icmp ule i32 %local.check.owner.end.217, %context.value.219
  %descriptor.offset.inside.221 = icmp ule i32 %local.check.offset.214, %local.check.owner.end.217
  %descriptor.extent.inside.223 = icmp ule i32 %local.check.extent.215, %stack.sub.222
  %descriptor.payload.inside.224 = icmp ule i32 %local.check.payload.216, %local.check.extent.215
  %descriptor.owner.offset.valid.225 = and i1 %descriptor.owner.inside.220, %descriptor.offset.inside.221
  %descriptor.range.inside.227 = and i1 %descriptor.owner.offset.valid.225, %descriptor.extent.inside.223
  %descriptor.range.valid.226 = and i1 %descriptor.range.inside.227, %descriptor.payload.inside.224
  br i1 %descriptor.range.valid.226, label %descriptor.valid.228, label %descriptor.invalid.229
descriptor.invalid.229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.228:
  %descriptor.initialized.status.230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.214, i32 %local.check.extent.215)
  %helper.ok.231 = icmp eq i32 %descriptor.initialized.status.230, 0
  br i1 %helper.ok.231, label %helper.continue.232, label %frame.failure.0
helper.continue.232:
  br label %local.descriptor.checked.213
local.descriptor.inactive.212:
  br label %local.descriptor.checked.213
local.descriptor.checked.213:
  %local.is.active.233 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.233, label %local.descriptor.active.234, label %local.descriptor.inactive.235
local.descriptor.active.234:
  %local.check.offset.237 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.238 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.239 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.240 = load i32, ptr %local.owner.end.18, align 4
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %local.check.owner.end.240, %local.check.offset.237
  %descriptor.owner.inside.243 = icmp ule i32 %local.check.owner.end.240, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %local.check.offset.237, %local.check.owner.end.240
  %descriptor.extent.inside.246 = icmp ule i32 %local.check.extent.238, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 %local.check.payload.239, %local.check.extent.238
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  br i1 %descriptor.range.valid.249, label %descriptor.valid.251, label %descriptor.invalid.252
descriptor.invalid.252:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.251:
  %descriptor.initialized.status.253 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.237, i32 %local.check.extent.238)
  %helper.ok.254 = icmp eq i32 %descriptor.initialized.status.253, 0
  br i1 %helper.ok.254, label %helper.continue.255, label %frame.failure.0
helper.continue.255:
  br label %local.descriptor.checked.236
local.descriptor.inactive.235:
  br label %local.descriptor.checked.236
local.descriptor.checked.236:
  %step.status.256 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.257 = icmp eq i32 %step.status.256, 0
  br i1 %helper.ok.257, label %helper.continue.258, label %frame.failure.0
helper.continue.258:
  store i1 true, ptr %local.active.8, align 1
  store i32 %local.resolved.offset.145, ptr %local.offset.9, align 4
  store i32 %local.resolved.extent.146, ptr %local.extent.10, align 4
  store i32 %local.resolved.payload.147, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.148, ptr %local.owner.end.12, align 4
  store i32 4, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.145, i32 20, i32 %local.resolved.payload.147, i32 %local.resolved.owner.end.148, i32 %local.resolved.extent.146)
  %context.field.259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.260 = load i32, ptr %context.field.259, align 4
  %runtime.ok.261 = icmp eq i32 %context.value.260, 0
  br i1 %runtime.ok.261, label %runtime.continue.262, label %frame.failure.0
runtime.continue.262:
  %local.is.active.263 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.263, label %local.descriptor.active.264, label %local.descriptor.inactive.265
local.descriptor.active.264:
  %local.check.offset.267 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.268 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.269 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.270 = load i32, ptr %local.owner.end.6, align 4
  %context.field.271 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.272 = load i32, ptr %context.field.271, align 4
  %stack.sub.275 = sub i32 %local.check.owner.end.270, %local.check.offset.267
  %descriptor.owner.inside.273 = icmp ule i32 %local.check.owner.end.270, %context.value.272
  %descriptor.offset.inside.274 = icmp ule i32 %local.check.offset.267, %local.check.owner.end.270
  %descriptor.extent.inside.276 = icmp ule i32 %local.check.extent.268, %stack.sub.275
  %descriptor.payload.inside.277 = icmp ule i32 %local.check.payload.269, %local.check.extent.268
  %descriptor.owner.offset.valid.278 = and i1 %descriptor.owner.inside.273, %descriptor.offset.inside.274
  %descriptor.range.inside.280 = and i1 %descriptor.owner.offset.valid.278, %descriptor.extent.inside.276
  %descriptor.range.valid.279 = and i1 %descriptor.range.inside.280, %descriptor.payload.inside.277
  br i1 %descriptor.range.valid.279, label %descriptor.valid.281, label %descriptor.invalid.282
descriptor.invalid.282:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.281:
  %descriptor.initialized.status.283 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.267, i32 %local.check.extent.268)
  %helper.ok.284 = icmp eq i32 %descriptor.initialized.status.283, 0
  br i1 %helper.ok.284, label %helper.continue.285, label %frame.failure.0
helper.continue.285:
  br label %local.descriptor.checked.266
local.descriptor.inactive.265:
  br label %local.descriptor.checked.266
local.descriptor.checked.266:
  %local.is.active.286 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.286, label %local.descriptor.active.287, label %local.descriptor.inactive.288
local.descriptor.active.287:
  %local.check.offset.290 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.291 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.292 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.293 = load i32, ptr %local.owner.end.12, align 4
  %context.field.294 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.295 = load i32, ptr %context.field.294, align 4
  %stack.sub.298 = sub i32 %local.check.owner.end.293, %local.check.offset.290
  %descriptor.owner.inside.296 = icmp ule i32 %local.check.owner.end.293, %context.value.295
  %descriptor.offset.inside.297 = icmp ule i32 %local.check.offset.290, %local.check.owner.end.293
  %descriptor.extent.inside.299 = icmp ule i32 %local.check.extent.291, %stack.sub.298
  %descriptor.payload.inside.300 = icmp ule i32 %local.check.payload.292, %local.check.extent.291
  %descriptor.owner.offset.valid.301 = and i1 %descriptor.owner.inside.296, %descriptor.offset.inside.297
  %descriptor.range.inside.303 = and i1 %descriptor.owner.offset.valid.301, %descriptor.extent.inside.299
  %descriptor.range.valid.302 = and i1 %descriptor.range.inside.303, %descriptor.payload.inside.300
  br i1 %descriptor.range.valid.302, label %descriptor.valid.304, label %descriptor.invalid.305
descriptor.invalid.305:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.304:
  %descriptor.initialized.status.306 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.290, i32 %local.check.extent.291)
  %helper.ok.307 = icmp eq i32 %descriptor.initialized.status.306, 0
  br i1 %helper.ok.307, label %helper.continue.308, label %frame.failure.0
helper.continue.308:
  br label %local.descriptor.checked.289
local.descriptor.inactive.288:
  br label %local.descriptor.checked.289
local.descriptor.checked.289:
  %local.is.active.309 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.309, label %local.descriptor.active.310, label %local.descriptor.inactive.311
local.descriptor.active.310:
  %local.check.offset.313 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.314 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.315 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.316 = load i32, ptr %local.owner.end.18, align 4
  %context.field.317 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.318 = load i32, ptr %context.field.317, align 4
  %stack.sub.321 = sub i32 %local.check.owner.end.316, %local.check.offset.313
  %descriptor.owner.inside.319 = icmp ule i32 %local.check.owner.end.316, %context.value.318
  %descriptor.offset.inside.320 = icmp ule i32 %local.check.offset.313, %local.check.owner.end.316
  %descriptor.extent.inside.322 = icmp ule i32 %local.check.extent.314, %stack.sub.321
  %descriptor.payload.inside.323 = icmp ule i32 %local.check.payload.315, %local.check.extent.314
  %descriptor.owner.offset.valid.324 = and i1 %descriptor.owner.inside.319, %descriptor.offset.inside.320
  %descriptor.range.inside.326 = and i1 %descriptor.owner.offset.valid.324, %descriptor.extent.inside.322
  %descriptor.range.valid.325 = and i1 %descriptor.range.inside.326, %descriptor.payload.inside.323
  br i1 %descriptor.range.valid.325, label %descriptor.valid.327, label %descriptor.invalid.328
descriptor.invalid.328:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.327:
  %descriptor.initialized.status.329 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.313, i32 %local.check.extent.314)
  %helper.ok.330 = icmp eq i32 %descriptor.initialized.status.329, 0
  br i1 %helper.ok.330, label %helper.continue.331, label %frame.failure.0
helper.continue.331:
  br label %local.descriptor.checked.312
local.descriptor.inactive.311:
  br label %local.descriptor.checked.312
local.descriptor.checked.312:
  %step.status.332 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.333 = icmp eq i32 %step.status.332, 0
  br i1 %helper.ok.333, label %helper.continue.334, label %frame.failure.0
helper.continue.334:
  %local.resolved.offset.335 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.336 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.337 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.338 = load i32, ptr %local.owner.end.6, align 4
  %context.field.339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.340 = load i32, ptr %context.field.339, align 4
  %stack.sub.343 = sub i32 %local.resolved.owner.end.338, %local.resolved.offset.335
  %descriptor.owner.inside.341 = icmp ule i32 %local.resolved.owner.end.338, %context.value.340
  %descriptor.offset.inside.342 = icmp ule i32 %local.resolved.offset.335, %local.resolved.owner.end.338
  %descriptor.extent.inside.344 = icmp ule i32 %local.resolved.extent.336, %stack.sub.343
  %descriptor.payload.inside.345 = icmp ule i32 %local.resolved.payload.337, %local.resolved.extent.336
  %descriptor.owner.offset.valid.346 = and i1 %descriptor.owner.inside.341, %descriptor.offset.inside.342
  %descriptor.range.inside.348 = and i1 %descriptor.owner.offset.valid.346, %descriptor.extent.inside.344
  %descriptor.range.valid.347 = and i1 %descriptor.range.inside.348, %descriptor.payload.inside.345
  %descriptor.type.valid.349 = icmp eq i32 4, 4
  %descriptor.valid.350 = and i1 %descriptor.range.valid.347, %descriptor.type.valid.349
  br i1 %descriptor.valid.350, label %descriptor.valid.351, label %descriptor.invalid.352
descriptor.invalid.352:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.351:
  %descriptor.initialized.status.353 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.335, i32 %local.resolved.extent.336)
  %helper.ok.354 = icmp eq i32 %descriptor.initialized.status.353, 0
  br i1 %helper.ok.354, label %helper.continue.355, label %frame.failure.0
helper.continue.355:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.335, i32 20, i32 %local.resolved.payload.337, i32 %local.resolved.owner.end.338, i32 %local.resolved.extent.336)
  %context.field.356 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.357 = load i32, ptr %context.field.356, align 4
  %runtime.ok.358 = icmp eq i32 %context.value.357, 0
  br i1 %runtime.ok.358, label %runtime.continue.359, label %frame.failure.0
runtime.continue.359:
  %context.field.360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.361 = load i32, ptr %context.field.360, align 4
  %stack.sub.364 = sub i32 %local.resolved.owner.end.338, %local.resolved.offset.335
  %descriptor.owner.inside.362 = icmp ule i32 %local.resolved.owner.end.338, %context.value.361
  %descriptor.offset.inside.363 = icmp ule i32 %local.resolved.offset.335, %local.resolved.owner.end.338
  %descriptor.extent.inside.365 = icmp ule i32 %local.resolved.extent.336, %stack.sub.364
  %descriptor.payload.inside.366 = icmp ule i32 %local.resolved.payload.337, %local.resolved.extent.336
  %descriptor.owner.offset.valid.367 = and i1 %descriptor.owner.inside.362, %descriptor.offset.inside.363
  %descriptor.range.inside.369 = and i1 %descriptor.owner.offset.valid.367, %descriptor.extent.inside.365
  %descriptor.range.valid.368 = and i1 %descriptor.range.inside.369, %descriptor.payload.inside.366
  %descriptor.type.valid.370 = icmp eq i32 4, 4
  %descriptor.valid.371 = and i1 %descriptor.range.valid.368, %descriptor.type.valid.370
  br i1 %descriptor.valid.371, label %descriptor.valid.372, label %descriptor.invalid.373
descriptor.invalid.373:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.372:
  %descriptor.initialized.status.374 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.335, i32 %local.resolved.extent.336)
  %helper.ok.375 = icmp eq i32 %descriptor.initialized.status.374, 0
  br i1 %helper.ok.375, label %helper.continue.376, label %frame.failure.0
helper.continue.376:
  %local.is.active.377 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.377, label %local.descriptor.active.378, label %local.descriptor.inactive.379
local.descriptor.active.378:
  %local.check.offset.381 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.382 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.383 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.384 = load i32, ptr %local.owner.end.6, align 4
  %context.field.385 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.386 = load i32, ptr %context.field.385, align 4
  %stack.sub.389 = sub i32 %local.check.owner.end.384, %local.check.offset.381
  %descriptor.owner.inside.387 = icmp ule i32 %local.check.owner.end.384, %context.value.386
  %descriptor.offset.inside.388 = icmp ule i32 %local.check.offset.381, %local.check.owner.end.384
  %descriptor.extent.inside.390 = icmp ule i32 %local.check.extent.382, %stack.sub.389
  %descriptor.payload.inside.391 = icmp ule i32 %local.check.payload.383, %local.check.extent.382
  %descriptor.owner.offset.valid.392 = and i1 %descriptor.owner.inside.387, %descriptor.offset.inside.388
  %descriptor.range.inside.394 = and i1 %descriptor.owner.offset.valid.392, %descriptor.extent.inside.390
  %descriptor.range.valid.393 = and i1 %descriptor.range.inside.394, %descriptor.payload.inside.391
  br i1 %descriptor.range.valid.393, label %descriptor.valid.395, label %descriptor.invalid.396
descriptor.invalid.396:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.395:
  %descriptor.initialized.status.397 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.381, i32 %local.check.extent.382)
  %helper.ok.398 = icmp eq i32 %descriptor.initialized.status.397, 0
  br i1 %helper.ok.398, label %helper.continue.399, label %frame.failure.0
helper.continue.399:
  br label %local.descriptor.checked.380
local.descriptor.inactive.379:
  br label %local.descriptor.checked.380
local.descriptor.checked.380:
  %local.is.active.400 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.400, label %local.descriptor.active.401, label %local.descriptor.inactive.402
local.descriptor.active.401:
  %local.check.offset.404 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.405 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.406 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.407 = load i32, ptr %local.owner.end.12, align 4
  %context.field.408 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.409 = load i32, ptr %context.field.408, align 4
  %stack.sub.412 = sub i32 %local.check.owner.end.407, %local.check.offset.404
  %descriptor.owner.inside.410 = icmp ule i32 %local.check.owner.end.407, %context.value.409
  %descriptor.offset.inside.411 = icmp ule i32 %local.check.offset.404, %local.check.owner.end.407
  %descriptor.extent.inside.413 = icmp ule i32 %local.check.extent.405, %stack.sub.412
  %descriptor.payload.inside.414 = icmp ule i32 %local.check.payload.406, %local.check.extent.405
  %descriptor.owner.offset.valid.415 = and i1 %descriptor.owner.inside.410, %descriptor.offset.inside.411
  %descriptor.range.inside.417 = and i1 %descriptor.owner.offset.valid.415, %descriptor.extent.inside.413
  %descriptor.range.valid.416 = and i1 %descriptor.range.inside.417, %descriptor.payload.inside.414
  br i1 %descriptor.range.valid.416, label %descriptor.valid.418, label %descriptor.invalid.419
descriptor.invalid.419:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.418:
  %descriptor.initialized.status.420 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.404, i32 %local.check.extent.405)
  %helper.ok.421 = icmp eq i32 %descriptor.initialized.status.420, 0
  br i1 %helper.ok.421, label %helper.continue.422, label %frame.failure.0
helper.continue.422:
  br label %local.descriptor.checked.403
local.descriptor.inactive.402:
  br label %local.descriptor.checked.403
local.descriptor.checked.403:
  %local.is.active.423 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.423, label %local.descriptor.active.424, label %local.descriptor.inactive.425
local.descriptor.active.424:
  %local.check.offset.427 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.428 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.429 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.430 = load i32, ptr %local.owner.end.18, align 4
  %context.field.431 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.432 = load i32, ptr %context.field.431, align 4
  %stack.sub.435 = sub i32 %local.check.owner.end.430, %local.check.offset.427
  %descriptor.owner.inside.433 = icmp ule i32 %local.check.owner.end.430, %context.value.432
  %descriptor.offset.inside.434 = icmp ule i32 %local.check.offset.427, %local.check.owner.end.430
  %descriptor.extent.inside.436 = icmp ule i32 %local.check.extent.428, %stack.sub.435
  %descriptor.payload.inside.437 = icmp ule i32 %local.check.payload.429, %local.check.extent.428
  %descriptor.owner.offset.valid.438 = and i1 %descriptor.owner.inside.433, %descriptor.offset.inside.434
  %descriptor.range.inside.440 = and i1 %descriptor.owner.offset.valid.438, %descriptor.extent.inside.436
  %descriptor.range.valid.439 = and i1 %descriptor.range.inside.440, %descriptor.payload.inside.437
  br i1 %descriptor.range.valid.439, label %descriptor.valid.441, label %descriptor.invalid.442
descriptor.invalid.442:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.441:
  %descriptor.initialized.status.443 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.427, i32 %local.check.extent.428)
  %helper.ok.444 = icmp eq i32 %descriptor.initialized.status.443, 0
  br i1 %helper.ok.444, label %helper.continue.445, label %frame.failure.0
helper.continue.445:
  br label %local.descriptor.checked.426
local.descriptor.inactive.425:
  br label %local.descriptor.checked.426
local.descriptor.checked.426:
  %step.status.446 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.447 = icmp eq i32 %step.status.446, 0
  br i1 %helper.ok.447, label %helper.continue.448, label %frame.failure.0
helper.continue.448:
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %inline.target.depth.within.interpreter.limit.451 = icmp ule i32 %context.value.450, 65
  br i1 %inline.target.depth.within.interpreter.limit.451, label %inline.target.depth.ok.452, label %inline.target.depth.invalid.453
inline.target.depth.invalid.453:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.452:
  %context.field.454 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.455 = load i32, ptr %context.field.454, align 4
  %stack.sub.458 = sub i32 %local.resolved.owner.end.338, %local.resolved.offset.335
  %descriptor.owner.inside.456 = icmp ule i32 %local.resolved.owner.end.338, %context.value.455
  %descriptor.offset.inside.457 = icmp ule i32 %local.resolved.offset.335, %local.resolved.owner.end.338
  %descriptor.extent.inside.459 = icmp ule i32 %local.resolved.extent.336, %stack.sub.458
  %descriptor.payload.inside.460 = icmp ule i32 %local.resolved.payload.337, %local.resolved.extent.336
  %descriptor.owner.offset.valid.461 = and i1 %descriptor.owner.inside.456, %descriptor.offset.inside.457
  %descriptor.range.inside.463 = and i1 %descriptor.owner.offset.valid.461, %descriptor.extent.inside.459
  %descriptor.range.valid.462 = and i1 %descriptor.range.inside.463, %descriptor.payload.inside.460
  %descriptor.type.valid.464 = icmp eq i32 1, 1
  %descriptor.valid.465 = and i1 %descriptor.range.valid.462, %descriptor.type.valid.464
  br i1 %descriptor.valid.465, label %descriptor.valid.466, label %descriptor.invalid.467
descriptor.invalid.467:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.466:
  %descriptor.initialized.status.468 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.335, i32 %local.resolved.extent.336)
  %helper.ok.469 = icmp eq i32 %descriptor.initialized.status.468, 0
  br i1 %helper.ok.469, label %helper.continue.470, label %frame.failure.0
helper.continue.470:
  %local.is.active.471 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.471, label %local.descriptor.active.472, label %local.descriptor.inactive.473
local.descriptor.active.472:
  %local.check.offset.475 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.476 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.477 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.478 = load i32, ptr %local.owner.end.6, align 4
  %context.field.479 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.480 = load i32, ptr %context.field.479, align 4
  %stack.sub.483 = sub i32 %local.check.owner.end.478, %local.check.offset.475
  %descriptor.owner.inside.481 = icmp ule i32 %local.check.owner.end.478, %context.value.480
  %descriptor.offset.inside.482 = icmp ule i32 %local.check.offset.475, %local.check.owner.end.478
  %descriptor.extent.inside.484 = icmp ule i32 %local.check.extent.476, %stack.sub.483
  %descriptor.payload.inside.485 = icmp ule i32 %local.check.payload.477, %local.check.extent.476
  %descriptor.owner.offset.valid.486 = and i1 %descriptor.owner.inside.481, %descriptor.offset.inside.482
  %descriptor.range.inside.488 = and i1 %descriptor.owner.offset.valid.486, %descriptor.extent.inside.484
  %descriptor.range.valid.487 = and i1 %descriptor.range.inside.488, %descriptor.payload.inside.485
  br i1 %descriptor.range.valid.487, label %descriptor.valid.489, label %descriptor.invalid.490
descriptor.invalid.490:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.489:
  %descriptor.initialized.status.491 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.475, i32 %local.check.extent.476)
  %helper.ok.492 = icmp eq i32 %descriptor.initialized.status.491, 0
  br i1 %helper.ok.492, label %helper.continue.493, label %frame.failure.0
helper.continue.493:
  br label %local.descriptor.checked.474
local.descriptor.inactive.473:
  br label %local.descriptor.checked.474
local.descriptor.checked.474:
  %local.is.active.494 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.494, label %local.descriptor.active.495, label %local.descriptor.inactive.496
local.descriptor.active.495:
  %local.check.offset.498 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.499 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.500 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.501 = load i32, ptr %local.owner.end.12, align 4
  %context.field.502 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.503 = load i32, ptr %context.field.502, align 4
  %stack.sub.506 = sub i32 %local.check.owner.end.501, %local.check.offset.498
  %descriptor.owner.inside.504 = icmp ule i32 %local.check.owner.end.501, %context.value.503
  %descriptor.offset.inside.505 = icmp ule i32 %local.check.offset.498, %local.check.owner.end.501
  %descriptor.extent.inside.507 = icmp ule i32 %local.check.extent.499, %stack.sub.506
  %descriptor.payload.inside.508 = icmp ule i32 %local.check.payload.500, %local.check.extent.499
  %descriptor.owner.offset.valid.509 = and i1 %descriptor.owner.inside.504, %descriptor.offset.inside.505
  %descriptor.range.inside.511 = and i1 %descriptor.owner.offset.valid.509, %descriptor.extent.inside.507
  %descriptor.range.valid.510 = and i1 %descriptor.range.inside.511, %descriptor.payload.inside.508
  br i1 %descriptor.range.valid.510, label %descriptor.valid.512, label %descriptor.invalid.513
descriptor.invalid.513:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.512:
  %descriptor.initialized.status.514 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.498, i32 %local.check.extent.499)
  %helper.ok.515 = icmp eq i32 %descriptor.initialized.status.514, 0
  br i1 %helper.ok.515, label %helper.continue.516, label %frame.failure.0
helper.continue.516:
  br label %local.descriptor.checked.497
local.descriptor.inactive.496:
  br label %local.descriptor.checked.497
local.descriptor.checked.497:
  %local.is.active.517 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.517, label %local.descriptor.active.518, label %local.descriptor.inactive.519
local.descriptor.active.518:
  %local.check.offset.521 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.522 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.523 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.524 = load i32, ptr %local.owner.end.18, align 4
  %context.field.525 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.526 = load i32, ptr %context.field.525, align 4
  %stack.sub.529 = sub i32 %local.check.owner.end.524, %local.check.offset.521
  %descriptor.owner.inside.527 = icmp ule i32 %local.check.owner.end.524, %context.value.526
  %descriptor.offset.inside.528 = icmp ule i32 %local.check.offset.521, %local.check.owner.end.524
  %descriptor.extent.inside.530 = icmp ule i32 %local.check.extent.522, %stack.sub.529
  %descriptor.payload.inside.531 = icmp ule i32 %local.check.payload.523, %local.check.extent.522
  %descriptor.owner.offset.valid.532 = and i1 %descriptor.owner.inside.527, %descriptor.offset.inside.528
  %descriptor.range.inside.534 = and i1 %descriptor.owner.offset.valid.532, %descriptor.extent.inside.530
  %descriptor.range.valid.533 = and i1 %descriptor.range.inside.534, %descriptor.payload.inside.531
  br i1 %descriptor.range.valid.533, label %descriptor.valid.535, label %descriptor.invalid.536
descriptor.invalid.536:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.535:
  %descriptor.initialized.status.537 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.521, i32 %local.check.extent.522)
  %helper.ok.538 = icmp eq i32 %descriptor.initialized.status.537, 0
  br i1 %helper.ok.538, label %helper.continue.539, label %frame.failure.0
helper.continue.539:
  br label %local.descriptor.checked.520
local.descriptor.inactive.519:
  br label %local.descriptor.checked.520
local.descriptor.checked.520:
  %step.status.540 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.541 = icmp eq i32 %step.status.540, 0
  br i1 %helper.ok.541, label %helper.continue.542, label %frame.failure.0
helper.continue.542:
  %context.field.543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.544 = load i32, ptr %context.field.543, align 4
  %stack.offset.545 = add i32 %context.value.544, 8
  %reserve.status.546 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.545, i32 11)
  %reserve.ok.547 = icmp eq i32 %reserve.status.546, 0
  br i1 %reserve.ok.547, label %reserve.continue.548, label %frame.failure.0
reserve.continue.548:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.544, i64 0, i32 1)
  %context.field.549 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.550 = load i32, ptr %context.field.549, align 4
  %runtime.ok.551 = icmp eq i32 %context.value.550, 0
  br i1 %runtime.ok.551, label %runtime.continue.552, label %frame.failure.0
runtime.continue.552:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.553 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.554 = load i32, ptr %context.field.553, align 4
  %runtime.ok.555 = icmp eq i32 %context.value.554, 0
  br i1 %runtime.ok.555, label %runtime.continue.556, label %frame.failure.0
runtime.continue.556:
  %context.field.557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.558 = load i32, ptr %context.field.557, align 4
  %stack.sub.561 = sub i32 %local.resolved.owner.end.338, %local.resolved.offset.335
  %descriptor.owner.inside.559 = icmp ule i32 %local.resolved.owner.end.338, %context.value.558
  %descriptor.offset.inside.560 = icmp ule i32 %local.resolved.offset.335, %local.resolved.owner.end.338
  %descriptor.extent.inside.562 = icmp ule i32 %local.resolved.extent.336, %stack.sub.561
  %descriptor.payload.inside.563 = icmp ule i32 %local.resolved.payload.337, %local.resolved.extent.336
  %descriptor.owner.offset.valid.564 = and i1 %descriptor.owner.inside.559, %descriptor.offset.inside.560
  %descriptor.range.inside.566 = and i1 %descriptor.owner.offset.valid.564, %descriptor.extent.inside.562
  %descriptor.range.valid.565 = and i1 %descriptor.range.inside.566, %descriptor.payload.inside.563
  %descriptor.type.valid.567 = icmp eq i32 1, 1
  %descriptor.valid.568 = and i1 %descriptor.range.valid.565, %descriptor.type.valid.567
  br i1 %descriptor.valid.568, label %descriptor.valid.569, label %descriptor.invalid.570
descriptor.invalid.570:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.569:
  %descriptor.initialized.status.571 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.335, i32 %local.resolved.extent.336)
  %helper.ok.572 = icmp eq i32 %descriptor.initialized.status.571, 0
  br i1 %helper.ok.572, label %helper.continue.573, label %frame.failure.0
helper.continue.573:
  %context.field.574 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.575 = load i32, ptr %context.field.574, align 4
  %stack.sub.578 = sub i32 %stack.offset.545, %context.value.544
  %descriptor.owner.inside.576 = icmp ule i32 %stack.offset.545, %context.value.575
  %descriptor.offset.inside.577 = icmp ule i32 %context.value.544, %stack.offset.545
  %descriptor.extent.inside.579 = icmp ule i32 8, %stack.sub.578
  %descriptor.payload.inside.580 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.581 = and i1 %descriptor.owner.inside.576, %descriptor.offset.inside.577
  %descriptor.range.inside.583 = and i1 %descriptor.owner.offset.valid.581, %descriptor.extent.inside.579
  %descriptor.range.valid.582 = and i1 %descriptor.range.inside.583, %descriptor.payload.inside.580
  %descriptor.type.valid.584 = icmp eq i32 1, 1
  %descriptor.valid.585 = and i1 %descriptor.range.valid.582, %descriptor.type.valid.584
  br i1 %descriptor.valid.585, label %descriptor.valid.586, label %descriptor.invalid.587
descriptor.invalid.587:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.586:
  %descriptor.initialized.status.588 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.544, i32 8)
  %helper.ok.589 = icmp eq i32 %descriptor.initialized.status.588, 0
  br i1 %helper.ok.589, label %helper.continue.590, label %frame.failure.0
helper.continue.590:
  %local.is.active.591 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.591, label %local.descriptor.active.592, label %local.descriptor.inactive.593
local.descriptor.active.592:
  %local.check.offset.595 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.596 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.597 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.598 = load i32, ptr %local.owner.end.6, align 4
  %context.field.599 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.600 = load i32, ptr %context.field.599, align 4
  %stack.sub.603 = sub i32 %local.check.owner.end.598, %local.check.offset.595
  %descriptor.owner.inside.601 = icmp ule i32 %local.check.owner.end.598, %context.value.600
  %descriptor.offset.inside.602 = icmp ule i32 %local.check.offset.595, %local.check.owner.end.598
  %descriptor.extent.inside.604 = icmp ule i32 %local.check.extent.596, %stack.sub.603
  %descriptor.payload.inside.605 = icmp ule i32 %local.check.payload.597, %local.check.extent.596
  %descriptor.owner.offset.valid.606 = and i1 %descriptor.owner.inside.601, %descriptor.offset.inside.602
  %descriptor.range.inside.608 = and i1 %descriptor.owner.offset.valid.606, %descriptor.extent.inside.604
  %descriptor.range.valid.607 = and i1 %descriptor.range.inside.608, %descriptor.payload.inside.605
  br i1 %descriptor.range.valid.607, label %descriptor.valid.609, label %descriptor.invalid.610
descriptor.invalid.610:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.609:
  %descriptor.initialized.status.611 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.595, i32 %local.check.extent.596)
  %helper.ok.612 = icmp eq i32 %descriptor.initialized.status.611, 0
  br i1 %helper.ok.612, label %helper.continue.613, label %frame.failure.0
helper.continue.613:
  br label %local.descriptor.checked.594
local.descriptor.inactive.593:
  br label %local.descriptor.checked.594
local.descriptor.checked.594:
  %local.is.active.614 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.614, label %local.descriptor.active.615, label %local.descriptor.inactive.616
local.descriptor.active.615:
  %local.check.offset.618 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.619 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.620 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.621 = load i32, ptr %local.owner.end.12, align 4
  %context.field.622 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.623 = load i32, ptr %context.field.622, align 4
  %stack.sub.626 = sub i32 %local.check.owner.end.621, %local.check.offset.618
  %descriptor.owner.inside.624 = icmp ule i32 %local.check.owner.end.621, %context.value.623
  %descriptor.offset.inside.625 = icmp ule i32 %local.check.offset.618, %local.check.owner.end.621
  %descriptor.extent.inside.627 = icmp ule i32 %local.check.extent.619, %stack.sub.626
  %descriptor.payload.inside.628 = icmp ule i32 %local.check.payload.620, %local.check.extent.619
  %descriptor.owner.offset.valid.629 = and i1 %descriptor.owner.inside.624, %descriptor.offset.inside.625
  %descriptor.range.inside.631 = and i1 %descriptor.owner.offset.valid.629, %descriptor.extent.inside.627
  %descriptor.range.valid.630 = and i1 %descriptor.range.inside.631, %descriptor.payload.inside.628
  br i1 %descriptor.range.valid.630, label %descriptor.valid.632, label %descriptor.invalid.633
descriptor.invalid.633:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.632:
  %descriptor.initialized.status.634 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.618, i32 %local.check.extent.619)
  %helper.ok.635 = icmp eq i32 %descriptor.initialized.status.634, 0
  br i1 %helper.ok.635, label %helper.continue.636, label %frame.failure.0
helper.continue.636:
  br label %local.descriptor.checked.617
local.descriptor.inactive.616:
  br label %local.descriptor.checked.617
local.descriptor.checked.617:
  %local.is.active.637 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.637, label %local.descriptor.active.638, label %local.descriptor.inactive.639
local.descriptor.active.638:
  %local.check.offset.641 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.642 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.643 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.644 = load i32, ptr %local.owner.end.18, align 4
  %context.field.645 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.646 = load i32, ptr %context.field.645, align 4
  %stack.sub.649 = sub i32 %local.check.owner.end.644, %local.check.offset.641
  %descriptor.owner.inside.647 = icmp ule i32 %local.check.owner.end.644, %context.value.646
  %descriptor.offset.inside.648 = icmp ule i32 %local.check.offset.641, %local.check.owner.end.644
  %descriptor.extent.inside.650 = icmp ule i32 %local.check.extent.642, %stack.sub.649
  %descriptor.payload.inside.651 = icmp ule i32 %local.check.payload.643, %local.check.extent.642
  %descriptor.owner.offset.valid.652 = and i1 %descriptor.owner.inside.647, %descriptor.offset.inside.648
  %descriptor.range.inside.654 = and i1 %descriptor.owner.offset.valid.652, %descriptor.extent.inside.650
  %descriptor.range.valid.653 = and i1 %descriptor.range.inside.654, %descriptor.payload.inside.651
  br i1 %descriptor.range.valid.653, label %descriptor.valid.655, label %descriptor.invalid.656
descriptor.invalid.656:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.655:
  %descriptor.initialized.status.657 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.641, i32 %local.check.extent.642)
  %helper.ok.658 = icmp eq i32 %descriptor.initialized.status.657, 0
  br i1 %helper.ok.658, label %helper.continue.659, label %frame.failure.0
helper.continue.659:
  br label %local.descriptor.checked.640
local.descriptor.inactive.639:
  br label %local.descriptor.checked.640
local.descriptor.checked.640:
  %step.status.660 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.661 = icmp eq i32 %step.status.660, 0
  br i1 %helper.ok.661, label %helper.continue.662, label %frame.failure.0
helper.continue.662:
  %context.field.663 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.664 = load i32, ptr %context.field.663, align 4
  %inline.target.depth.within.interpreter.limit.665 = icmp ule i32 %context.value.664, 65
  br i1 %inline.target.depth.within.interpreter.limit.665, label %inline.target.depth.ok.666, label %inline.target.depth.invalid.667
inline.target.depth.invalid.667:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.666:
  %integer.left.668 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.335)
  %context.field.670 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.671 = load i32, ptr %context.field.670, align 4
  %runtime.ok.672 = icmp eq i32 %context.value.671, 0
  br i1 %runtime.ok.672, label %runtime.continue.673, label %frame.failure.0
runtime.continue.673:
  %integer.right.669 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.544)
  %context.field.674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.675 = load i32, ptr %context.field.674, align 4
  %runtime.ok.676 = icmp eq i32 %context.value.675, 0
  br i1 %runtime.ok.676, label %runtime.continue.677, label %frame.failure.0
runtime.continue.677:
  %comparison.result.678 = icmp sgt i64 %integer.left.668, %integer.right.669
  %comparison.value.679 = zext i1 %comparison.result.678 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.544, i32 8, i32 8, i32 0, i32 0)
  %context.field.680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.681 = load i32, ptr %context.field.680, align 4
  %runtime.ok.682 = icmp eq i32 %context.value.681, 0
  br i1 %runtime.ok.682, label %runtime.continue.683, label %frame.failure.0
runtime.continue.683:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.335, i32 %local.resolved.extent.336, i32 %local.resolved.payload.337, i32 0, i32 0)
  %context.field.684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.685 = load i32, ptr %context.field.684, align 4
  %runtime.ok.686 = icmp eq i32 %context.value.685, 0
  br i1 %runtime.ok.686, label %runtime.continue.687, label %frame.failure.0
runtime.continue.687:
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %stack.offset.690 = add i32 %context.value.689, 8
  %reserve.status.691 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.690, i32 14)
  %reserve.ok.692 = icmp eq i32 %reserve.status.691, 0
  br i1 %reserve.ok.692, label %reserve.continue.693, label %frame.failure.0
reserve.continue.693:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.689, i64 %comparison.value.679, i32 2)
  %context.field.694 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.695 = load i32, ptr %context.field.694, align 4
  %runtime.ok.696 = icmp eq i32 %context.value.695, 0
  br i1 %runtime.ok.696, label %runtime.continue.697, label %frame.failure.0
runtime.continue.697:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.698 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.699 = load i32, ptr %context.field.698, align 4
  %runtime.ok.700 = icmp eq i32 %context.value.699, 0
  br i1 %runtime.ok.700, label %runtime.continue.701, label %frame.failure.0
runtime.continue.701:
  %stack.offset.702 = add i32 %context.value.689, 8
  %context.field.703 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.704 = load i32, ptr %context.field.703, align 4
  %stack.sub.707 = sub i32 %stack.offset.702, %context.value.689
  %descriptor.owner.inside.705 = icmp ule i32 %stack.offset.702, %context.value.704
  %descriptor.offset.inside.706 = icmp ule i32 %context.value.689, %stack.offset.702
  %descriptor.extent.inside.708 = icmp ule i32 8, %stack.sub.707
  %descriptor.payload.inside.709 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.710 = and i1 %descriptor.owner.inside.705, %descriptor.offset.inside.706
  %descriptor.range.inside.712 = and i1 %descriptor.owner.offset.valid.710, %descriptor.extent.inside.708
  %descriptor.range.valid.711 = and i1 %descriptor.range.inside.712, %descriptor.payload.inside.709
  %descriptor.type.valid.713 = icmp eq i32 2, 2
  %descriptor.valid.714 = and i1 %descriptor.range.valid.711, %descriptor.type.valid.713
  br i1 %descriptor.valid.714, label %descriptor.valid.715, label %descriptor.invalid.716
descriptor.invalid.716:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.715:
  %descriptor.initialized.status.717 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.689, i32 8)
  %helper.ok.718 = icmp eq i32 %descriptor.initialized.status.717, 0
  br i1 %helper.ok.718, label %helper.continue.719, label %frame.failure.0
helper.continue.719:
  %local.is.active.720 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.720, label %local.descriptor.active.721, label %local.descriptor.inactive.722
local.descriptor.active.721:
  %local.check.offset.724 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.725 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.726 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.727 = load i32, ptr %local.owner.end.6, align 4
  %context.field.728 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.729 = load i32, ptr %context.field.728, align 4
  %stack.sub.732 = sub i32 %local.check.owner.end.727, %local.check.offset.724
  %descriptor.owner.inside.730 = icmp ule i32 %local.check.owner.end.727, %context.value.729
  %descriptor.offset.inside.731 = icmp ule i32 %local.check.offset.724, %local.check.owner.end.727
  %descriptor.extent.inside.733 = icmp ule i32 %local.check.extent.725, %stack.sub.732
  %descriptor.payload.inside.734 = icmp ule i32 %local.check.payload.726, %local.check.extent.725
  %descriptor.owner.offset.valid.735 = and i1 %descriptor.owner.inside.730, %descriptor.offset.inside.731
  %descriptor.range.inside.737 = and i1 %descriptor.owner.offset.valid.735, %descriptor.extent.inside.733
  %descriptor.range.valid.736 = and i1 %descriptor.range.inside.737, %descriptor.payload.inside.734
  br i1 %descriptor.range.valid.736, label %descriptor.valid.738, label %descriptor.invalid.739
descriptor.invalid.739:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.738:
  %descriptor.initialized.status.740 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.724, i32 %local.check.extent.725)
  %helper.ok.741 = icmp eq i32 %descriptor.initialized.status.740, 0
  br i1 %helper.ok.741, label %helper.continue.742, label %frame.failure.0
helper.continue.742:
  br label %local.descriptor.checked.723
local.descriptor.inactive.722:
  br label %local.descriptor.checked.723
local.descriptor.checked.723:
  %local.is.active.743 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.743, label %local.descriptor.active.744, label %local.descriptor.inactive.745
local.descriptor.active.744:
  %local.check.offset.747 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.748 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.749 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.750 = load i32, ptr %local.owner.end.12, align 4
  %context.field.751 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.752 = load i32, ptr %context.field.751, align 4
  %stack.sub.755 = sub i32 %local.check.owner.end.750, %local.check.offset.747
  %descriptor.owner.inside.753 = icmp ule i32 %local.check.owner.end.750, %context.value.752
  %descriptor.offset.inside.754 = icmp ule i32 %local.check.offset.747, %local.check.owner.end.750
  %descriptor.extent.inside.756 = icmp ule i32 %local.check.extent.748, %stack.sub.755
  %descriptor.payload.inside.757 = icmp ule i32 %local.check.payload.749, %local.check.extent.748
  %descriptor.owner.offset.valid.758 = and i1 %descriptor.owner.inside.753, %descriptor.offset.inside.754
  %descriptor.range.inside.760 = and i1 %descriptor.owner.offset.valid.758, %descriptor.extent.inside.756
  %descriptor.range.valid.759 = and i1 %descriptor.range.inside.760, %descriptor.payload.inside.757
  br i1 %descriptor.range.valid.759, label %descriptor.valid.761, label %descriptor.invalid.762
descriptor.invalid.762:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.761:
  %descriptor.initialized.status.763 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.747, i32 %local.check.extent.748)
  %helper.ok.764 = icmp eq i32 %descriptor.initialized.status.763, 0
  br i1 %helper.ok.764, label %helper.continue.765, label %frame.failure.0
helper.continue.765:
  br label %local.descriptor.checked.746
local.descriptor.inactive.745:
  br label %local.descriptor.checked.746
local.descriptor.checked.746:
  %local.is.active.766 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.766, label %local.descriptor.active.767, label %local.descriptor.inactive.768
local.descriptor.active.767:
  %local.check.offset.770 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.771 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.772 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.773 = load i32, ptr %local.owner.end.18, align 4
  %context.field.774 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.775 = load i32, ptr %context.field.774, align 4
  %stack.sub.778 = sub i32 %local.check.owner.end.773, %local.check.offset.770
  %descriptor.owner.inside.776 = icmp ule i32 %local.check.owner.end.773, %context.value.775
  %descriptor.offset.inside.777 = icmp ule i32 %local.check.offset.770, %local.check.owner.end.773
  %descriptor.extent.inside.779 = icmp ule i32 %local.check.extent.771, %stack.sub.778
  %descriptor.payload.inside.780 = icmp ule i32 %local.check.payload.772, %local.check.extent.771
  %descriptor.owner.offset.valid.781 = and i1 %descriptor.owner.inside.776, %descriptor.offset.inside.777
  %descriptor.range.inside.783 = and i1 %descriptor.owner.offset.valid.781, %descriptor.extent.inside.779
  %descriptor.range.valid.782 = and i1 %descriptor.range.inside.783, %descriptor.payload.inside.780
  br i1 %descriptor.range.valid.782, label %descriptor.valid.784, label %descriptor.invalid.785
descriptor.invalid.785:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.784:
  %descriptor.initialized.status.786 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.770, i32 %local.check.extent.771)
  %helper.ok.787 = icmp eq i32 %descriptor.initialized.status.786, 0
  br i1 %helper.ok.787, label %helper.continue.788, label %frame.failure.0
helper.continue.788:
  br label %local.descriptor.checked.769
local.descriptor.inactive.768:
  br label %local.descriptor.checked.769
local.descriptor.checked.769:
  %step.status.789 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.790 = icmp eq i32 %step.status.789, 0
  br i1 %helper.ok.790, label %helper.continue.791, label %frame.failure.0
helper.continue.791:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.689, ptr %local.offset.15, align 4
  store i32 8, ptr %local.extent.16, align 4
  store i32 8, ptr %local.payload.17, align 4
  store i32 %stack.offset.702, ptr %local.owner.end.18, align 4
  store i32 2, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.689, i32 20, i32 8, i32 %stack.offset.702, i32 8)
  %context.field.792 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.793 = load i32, ptr %context.field.792, align 4
  %runtime.ok.794 = icmp eq i32 %context.value.793, 0
  br i1 %runtime.ok.794, label %runtime.continue.795, label %frame.failure.0
runtime.continue.795:
  %local.is.active.796 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.796, label %local.descriptor.active.797, label %local.descriptor.inactive.798
local.descriptor.active.797:
  %local.check.offset.800 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.801 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.802 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.803 = load i32, ptr %local.owner.end.6, align 4
  %context.field.804 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.805 = load i32, ptr %context.field.804, align 4
  %stack.sub.808 = sub i32 %local.check.owner.end.803, %local.check.offset.800
  %descriptor.owner.inside.806 = icmp ule i32 %local.check.owner.end.803, %context.value.805
  %descriptor.offset.inside.807 = icmp ule i32 %local.check.offset.800, %local.check.owner.end.803
  %descriptor.extent.inside.809 = icmp ule i32 %local.check.extent.801, %stack.sub.808
  %descriptor.payload.inside.810 = icmp ule i32 %local.check.payload.802, %local.check.extent.801
  %descriptor.owner.offset.valid.811 = and i1 %descriptor.owner.inside.806, %descriptor.offset.inside.807
  %descriptor.range.inside.813 = and i1 %descriptor.owner.offset.valid.811, %descriptor.extent.inside.809
  %descriptor.range.valid.812 = and i1 %descriptor.range.inside.813, %descriptor.payload.inside.810
  br i1 %descriptor.range.valid.812, label %descriptor.valid.814, label %descriptor.invalid.815
descriptor.invalid.815:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.814:
  %descriptor.initialized.status.816 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.800, i32 %local.check.extent.801)
  %helper.ok.817 = icmp eq i32 %descriptor.initialized.status.816, 0
  br i1 %helper.ok.817, label %helper.continue.818, label %frame.failure.0
helper.continue.818:
  br label %local.descriptor.checked.799
local.descriptor.inactive.798:
  br label %local.descriptor.checked.799
local.descriptor.checked.799:
  %local.is.active.819 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.819, label %local.descriptor.active.820, label %local.descriptor.inactive.821
local.descriptor.active.820:
  %local.check.offset.823 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.824 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.825 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.826 = load i32, ptr %local.owner.end.12, align 4
  %context.field.827 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.828 = load i32, ptr %context.field.827, align 4
  %stack.sub.831 = sub i32 %local.check.owner.end.826, %local.check.offset.823
  %descriptor.owner.inside.829 = icmp ule i32 %local.check.owner.end.826, %context.value.828
  %descriptor.offset.inside.830 = icmp ule i32 %local.check.offset.823, %local.check.owner.end.826
  %descriptor.extent.inside.832 = icmp ule i32 %local.check.extent.824, %stack.sub.831
  %descriptor.payload.inside.833 = icmp ule i32 %local.check.payload.825, %local.check.extent.824
  %descriptor.owner.offset.valid.834 = and i1 %descriptor.owner.inside.829, %descriptor.offset.inside.830
  %descriptor.range.inside.836 = and i1 %descriptor.owner.offset.valid.834, %descriptor.extent.inside.832
  %descriptor.range.valid.835 = and i1 %descriptor.range.inside.836, %descriptor.payload.inside.833
  br i1 %descriptor.range.valid.835, label %descriptor.valid.837, label %descriptor.invalid.838
descriptor.invalid.838:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.837:
  %descriptor.initialized.status.839 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.823, i32 %local.check.extent.824)
  %helper.ok.840 = icmp eq i32 %descriptor.initialized.status.839, 0
  br i1 %helper.ok.840, label %helper.continue.841, label %frame.failure.0
helper.continue.841:
  br label %local.descriptor.checked.822
local.descriptor.inactive.821:
  br label %local.descriptor.checked.822
local.descriptor.checked.822:
  %local.is.active.842 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.842, label %local.descriptor.active.843, label %local.descriptor.inactive.844
local.descriptor.active.843:
  %local.check.offset.846 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.847 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.848 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.849 = load i32, ptr %local.owner.end.18, align 4
  %context.field.850 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.851 = load i32, ptr %context.field.850, align 4
  %stack.sub.854 = sub i32 %local.check.owner.end.849, %local.check.offset.846
  %descriptor.owner.inside.852 = icmp ule i32 %local.check.owner.end.849, %context.value.851
  %descriptor.offset.inside.853 = icmp ule i32 %local.check.offset.846, %local.check.owner.end.849
  %descriptor.extent.inside.855 = icmp ule i32 %local.check.extent.847, %stack.sub.854
  %descriptor.payload.inside.856 = icmp ule i32 %local.check.payload.848, %local.check.extent.847
  %descriptor.owner.offset.valid.857 = and i1 %descriptor.owner.inside.852, %descriptor.offset.inside.853
  %descriptor.range.inside.859 = and i1 %descriptor.owner.offset.valid.857, %descriptor.extent.inside.855
  %descriptor.range.valid.858 = and i1 %descriptor.range.inside.859, %descriptor.payload.inside.856
  br i1 %descriptor.range.valid.858, label %descriptor.valid.860, label %descriptor.invalid.861
descriptor.invalid.861:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.860:
  %descriptor.initialized.status.862 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.846, i32 %local.check.extent.847)
  %helper.ok.863 = icmp eq i32 %descriptor.initialized.status.862, 0
  br i1 %helper.ok.863, label %helper.continue.864, label %frame.failure.0
helper.continue.864:
  br label %local.descriptor.checked.845
local.descriptor.inactive.844:
  br label %local.descriptor.checked.845
local.descriptor.checked.845:
  %step.status.865 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.866 = icmp eq i32 %step.status.865, 0
  br i1 %helper.ok.866, label %helper.continue.867, label %frame.failure.0
helper.continue.867:
  %local.resolved.offset.868 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.869 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.870 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.871 = load i32, ptr %local.owner.end.12, align 4
  %context.field.872 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.873 = load i32, ptr %context.field.872, align 4
  %stack.sub.876 = sub i32 %local.resolved.owner.end.871, %local.resolved.offset.868
  %descriptor.owner.inside.874 = icmp ule i32 %local.resolved.owner.end.871, %context.value.873
  %descriptor.offset.inside.875 = icmp ule i32 %local.resolved.offset.868, %local.resolved.owner.end.871
  %descriptor.extent.inside.877 = icmp ule i32 %local.resolved.extent.869, %stack.sub.876
  %descriptor.payload.inside.878 = icmp ule i32 %local.resolved.payload.870, %local.resolved.extent.869
  %descriptor.owner.offset.valid.879 = and i1 %descriptor.owner.inside.874, %descriptor.offset.inside.875
  %descriptor.range.inside.881 = and i1 %descriptor.owner.offset.valid.879, %descriptor.extent.inside.877
  %descriptor.range.valid.880 = and i1 %descriptor.range.inside.881, %descriptor.payload.inside.878
  %descriptor.type.valid.882 = icmp eq i32 4, 4
  %descriptor.valid.883 = and i1 %descriptor.range.valid.880, %descriptor.type.valid.882
  br i1 %descriptor.valid.883, label %descriptor.valid.884, label %descriptor.invalid.885
descriptor.invalid.885:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.884:
  %descriptor.initialized.status.886 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.868, i32 %local.resolved.extent.869)
  %helper.ok.887 = icmp eq i32 %descriptor.initialized.status.886, 0
  br i1 %helper.ok.887, label %helper.continue.888, label %frame.failure.0
helper.continue.888:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.868, i32 20, i32 %local.resolved.payload.870, i32 %local.resolved.owner.end.871, i32 %local.resolved.extent.869)
  %context.field.889 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.890 = load i32, ptr %context.field.889, align 4
  %runtime.ok.891 = icmp eq i32 %context.value.890, 0
  br i1 %runtime.ok.891, label %runtime.continue.892, label %frame.failure.0
runtime.continue.892:
  %context.field.893 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.894 = load i32, ptr %context.field.893, align 4
  %stack.sub.897 = sub i32 %local.resolved.owner.end.871, %local.resolved.offset.868
  %descriptor.owner.inside.895 = icmp ule i32 %local.resolved.owner.end.871, %context.value.894
  %descriptor.offset.inside.896 = icmp ule i32 %local.resolved.offset.868, %local.resolved.owner.end.871
  %descriptor.extent.inside.898 = icmp ule i32 %local.resolved.extent.869, %stack.sub.897
  %descriptor.payload.inside.899 = icmp ule i32 %local.resolved.payload.870, %local.resolved.extent.869
  %descriptor.owner.offset.valid.900 = and i1 %descriptor.owner.inside.895, %descriptor.offset.inside.896
  %descriptor.range.inside.902 = and i1 %descriptor.owner.offset.valid.900, %descriptor.extent.inside.898
  %descriptor.range.valid.901 = and i1 %descriptor.range.inside.902, %descriptor.payload.inside.899
  %descriptor.type.valid.903 = icmp eq i32 4, 4
  %descriptor.valid.904 = and i1 %descriptor.range.valid.901, %descriptor.type.valid.903
  br i1 %descriptor.valid.904, label %descriptor.valid.905, label %descriptor.invalid.906
descriptor.invalid.906:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.905:
  %descriptor.initialized.status.907 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.868, i32 %local.resolved.extent.869)
  %helper.ok.908 = icmp eq i32 %descriptor.initialized.status.907, 0
  br i1 %helper.ok.908, label %helper.continue.909, label %frame.failure.0
helper.continue.909:
  %local.is.active.910 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.910, label %local.descriptor.active.911, label %local.descriptor.inactive.912
local.descriptor.active.911:
  %local.check.offset.914 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.915 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.916 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.917 = load i32, ptr %local.owner.end.6, align 4
  %context.field.918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.919 = load i32, ptr %context.field.918, align 4
  %stack.sub.922 = sub i32 %local.check.owner.end.917, %local.check.offset.914
  %descriptor.owner.inside.920 = icmp ule i32 %local.check.owner.end.917, %context.value.919
  %descriptor.offset.inside.921 = icmp ule i32 %local.check.offset.914, %local.check.owner.end.917
  %descriptor.extent.inside.923 = icmp ule i32 %local.check.extent.915, %stack.sub.922
  %descriptor.payload.inside.924 = icmp ule i32 %local.check.payload.916, %local.check.extent.915
  %descriptor.owner.offset.valid.925 = and i1 %descriptor.owner.inside.920, %descriptor.offset.inside.921
  %descriptor.range.inside.927 = and i1 %descriptor.owner.offset.valid.925, %descriptor.extent.inside.923
  %descriptor.range.valid.926 = and i1 %descriptor.range.inside.927, %descriptor.payload.inside.924
  br i1 %descriptor.range.valid.926, label %descriptor.valid.928, label %descriptor.invalid.929
descriptor.invalid.929:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.928:
  %descriptor.initialized.status.930 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.914, i32 %local.check.extent.915)
  %helper.ok.931 = icmp eq i32 %descriptor.initialized.status.930, 0
  br i1 %helper.ok.931, label %helper.continue.932, label %frame.failure.0
helper.continue.932:
  br label %local.descriptor.checked.913
local.descriptor.inactive.912:
  br label %local.descriptor.checked.913
local.descriptor.checked.913:
  %local.is.active.933 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.933, label %local.descriptor.active.934, label %local.descriptor.inactive.935
local.descriptor.active.934:
  %local.check.offset.937 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.938 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.939 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.940 = load i32, ptr %local.owner.end.12, align 4
  %context.field.941 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.942 = load i32, ptr %context.field.941, align 4
  %stack.sub.945 = sub i32 %local.check.owner.end.940, %local.check.offset.937
  %descriptor.owner.inside.943 = icmp ule i32 %local.check.owner.end.940, %context.value.942
  %descriptor.offset.inside.944 = icmp ule i32 %local.check.offset.937, %local.check.owner.end.940
  %descriptor.extent.inside.946 = icmp ule i32 %local.check.extent.938, %stack.sub.945
  %descriptor.payload.inside.947 = icmp ule i32 %local.check.payload.939, %local.check.extent.938
  %descriptor.owner.offset.valid.948 = and i1 %descriptor.owner.inside.943, %descriptor.offset.inside.944
  %descriptor.range.inside.950 = and i1 %descriptor.owner.offset.valid.948, %descriptor.extent.inside.946
  %descriptor.range.valid.949 = and i1 %descriptor.range.inside.950, %descriptor.payload.inside.947
  br i1 %descriptor.range.valid.949, label %descriptor.valid.951, label %descriptor.invalid.952
descriptor.invalid.952:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.951:
  %descriptor.initialized.status.953 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.937, i32 %local.check.extent.938)
  %helper.ok.954 = icmp eq i32 %descriptor.initialized.status.953, 0
  br i1 %helper.ok.954, label %helper.continue.955, label %frame.failure.0
helper.continue.955:
  br label %local.descriptor.checked.936
local.descriptor.inactive.935:
  br label %local.descriptor.checked.936
local.descriptor.checked.936:
  %local.is.active.956 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.956, label %local.descriptor.active.957, label %local.descriptor.inactive.958
local.descriptor.active.957:
  %local.check.offset.960 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.961 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.962 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.963 = load i32, ptr %local.owner.end.18, align 4
  %context.field.964 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.965 = load i32, ptr %context.field.964, align 4
  %stack.sub.968 = sub i32 %local.check.owner.end.963, %local.check.offset.960
  %descriptor.owner.inside.966 = icmp ule i32 %local.check.owner.end.963, %context.value.965
  %descriptor.offset.inside.967 = icmp ule i32 %local.check.offset.960, %local.check.owner.end.963
  %descriptor.extent.inside.969 = icmp ule i32 %local.check.extent.961, %stack.sub.968
  %descriptor.payload.inside.970 = icmp ule i32 %local.check.payload.962, %local.check.extent.961
  %descriptor.owner.offset.valid.971 = and i1 %descriptor.owner.inside.966, %descriptor.offset.inside.967
  %descriptor.range.inside.973 = and i1 %descriptor.owner.offset.valid.971, %descriptor.extent.inside.969
  %descriptor.range.valid.972 = and i1 %descriptor.range.inside.973, %descriptor.payload.inside.970
  br i1 %descriptor.range.valid.972, label %descriptor.valid.974, label %descriptor.invalid.975
descriptor.invalid.975:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.974:
  %descriptor.initialized.status.976 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.960, i32 %local.check.extent.961)
  %helper.ok.977 = icmp eq i32 %descriptor.initialized.status.976, 0
  br i1 %helper.ok.977, label %helper.continue.978, label %frame.failure.0
helper.continue.978:
  br label %local.descriptor.checked.959
local.descriptor.inactive.958:
  br label %local.descriptor.checked.959
local.descriptor.checked.959:
  %step.status.979 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.980 = icmp eq i32 %step.status.979, 0
  br i1 %helper.ok.980, label %helper.continue.981, label %frame.failure.0
helper.continue.981:
  %local.resolved.offset.982 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.983 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.984 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.985 = load i32, ptr %local.owner.end.18, align 4
  %context.field.986 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.987 = load i32, ptr %context.field.986, align 4
  %stack.sub.990 = sub i32 %local.resolved.owner.end.985, %local.resolved.offset.982
  %descriptor.owner.inside.988 = icmp ule i32 %local.resolved.owner.end.985, %context.value.987
  %descriptor.offset.inside.989 = icmp ule i32 %local.resolved.offset.982, %local.resolved.owner.end.985
  %descriptor.extent.inside.991 = icmp ule i32 %local.resolved.extent.983, %stack.sub.990
  %descriptor.payload.inside.992 = icmp ule i32 %local.resolved.payload.984, %local.resolved.extent.983
  %descriptor.owner.offset.valid.993 = and i1 %descriptor.owner.inside.988, %descriptor.offset.inside.989
  %descriptor.range.inside.995 = and i1 %descriptor.owner.offset.valid.993, %descriptor.extent.inside.991
  %descriptor.range.valid.994 = and i1 %descriptor.range.inside.995, %descriptor.payload.inside.992
  %descriptor.type.valid.996 = icmp eq i32 2, 2
  %descriptor.valid.997 = and i1 %descriptor.range.valid.994, %descriptor.type.valid.996
  br i1 %descriptor.valid.997, label %descriptor.valid.998, label %descriptor.invalid.999
descriptor.invalid.999:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.998:
  %descriptor.initialized.status.1000 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.982, i32 %local.resolved.extent.983)
  %helper.ok.1001 = icmp eq i32 %descriptor.initialized.status.1000, 0
  br i1 %helper.ok.1001, label %helper.continue.1002, label %frame.failure.0
helper.continue.1002:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %local.resolved.offset.982, i32 20, i32 %local.resolved.payload.984, i32 %local.resolved.owner.end.985, i32 %local.resolved.extent.983)
  %context.field.1003 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1004 = load i32, ptr %context.field.1003, align 4
  %runtime.ok.1005 = icmp eq i32 %context.value.1004, 0
  br i1 %runtime.ok.1005, label %runtime.continue.1006, label %frame.failure.0
runtime.continue.1006:
  %context.field.1007 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1008 = load i32, ptr %context.field.1007, align 4
  %stack.sub.1011 = sub i32 %local.resolved.owner.end.871, %local.resolved.offset.868
  %descriptor.owner.inside.1009 = icmp ule i32 %local.resolved.owner.end.871, %context.value.1008
  %descriptor.offset.inside.1010 = icmp ule i32 %local.resolved.offset.868, %local.resolved.owner.end.871
  %descriptor.extent.inside.1012 = icmp ule i32 %local.resolved.extent.869, %stack.sub.1011
  %descriptor.payload.inside.1013 = icmp ule i32 %local.resolved.payload.870, %local.resolved.extent.869
  %descriptor.owner.offset.valid.1014 = and i1 %descriptor.owner.inside.1009, %descriptor.offset.inside.1010
  %descriptor.range.inside.1016 = and i1 %descriptor.owner.offset.valid.1014, %descriptor.extent.inside.1012
  %descriptor.range.valid.1015 = and i1 %descriptor.range.inside.1016, %descriptor.payload.inside.1013
  %descriptor.type.valid.1017 = icmp eq i32 4, 4
  %descriptor.valid.1018 = and i1 %descriptor.range.valid.1015, %descriptor.type.valid.1017
  br i1 %descriptor.valid.1018, label %descriptor.valid.1019, label %descriptor.invalid.1020
descriptor.invalid.1020:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1019:
  %descriptor.initialized.status.1021 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.868, i32 %local.resolved.extent.869)
  %helper.ok.1022 = icmp eq i32 %descriptor.initialized.status.1021, 0
  br i1 %helper.ok.1022, label %helper.continue.1023, label %frame.failure.0
helper.continue.1023:
  %context.field.1024 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1025 = load i32, ptr %context.field.1024, align 4
  %stack.sub.1028 = sub i32 %local.resolved.owner.end.985, %local.resolved.offset.982
  %descriptor.owner.inside.1026 = icmp ule i32 %local.resolved.owner.end.985, %context.value.1025
  %descriptor.offset.inside.1027 = icmp ule i32 %local.resolved.offset.982, %local.resolved.owner.end.985
  %descriptor.extent.inside.1029 = icmp ule i32 %local.resolved.extent.983, %stack.sub.1028
  %descriptor.payload.inside.1030 = icmp ule i32 %local.resolved.payload.984, %local.resolved.extent.983
  %descriptor.owner.offset.valid.1031 = and i1 %descriptor.owner.inside.1026, %descriptor.offset.inside.1027
  %descriptor.range.inside.1033 = and i1 %descriptor.owner.offset.valid.1031, %descriptor.extent.inside.1029
  %descriptor.range.valid.1032 = and i1 %descriptor.range.inside.1033, %descriptor.payload.inside.1030
  %descriptor.type.valid.1034 = icmp eq i32 2, 2
  %descriptor.valid.1035 = and i1 %descriptor.range.valid.1032, %descriptor.type.valid.1034
  br i1 %descriptor.valid.1035, label %descriptor.valid.1036, label %descriptor.invalid.1037
descriptor.invalid.1037:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1036:
  %descriptor.initialized.status.1038 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.982, i32 %local.resolved.extent.983)
  %helper.ok.1039 = icmp eq i32 %descriptor.initialized.status.1038, 0
  br i1 %helper.ok.1039, label %helper.continue.1040, label %frame.failure.0
helper.continue.1040:
  %local.is.active.1041 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1041, label %local.descriptor.active.1042, label %local.descriptor.inactive.1043
local.descriptor.active.1042:
  %local.check.offset.1045 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1046 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1047 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1048 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1049 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1050 = load i32, ptr %context.field.1049, align 4
  %stack.sub.1053 = sub i32 %local.check.owner.end.1048, %local.check.offset.1045
  %descriptor.owner.inside.1051 = icmp ule i32 %local.check.owner.end.1048, %context.value.1050
  %descriptor.offset.inside.1052 = icmp ule i32 %local.check.offset.1045, %local.check.owner.end.1048
  %descriptor.extent.inside.1054 = icmp ule i32 %local.check.extent.1046, %stack.sub.1053
  %descriptor.payload.inside.1055 = icmp ule i32 %local.check.payload.1047, %local.check.extent.1046
  %descriptor.owner.offset.valid.1056 = and i1 %descriptor.owner.inside.1051, %descriptor.offset.inside.1052
  %descriptor.range.inside.1058 = and i1 %descriptor.owner.offset.valid.1056, %descriptor.extent.inside.1054
  %descriptor.range.valid.1057 = and i1 %descriptor.range.inside.1058, %descriptor.payload.inside.1055
  br i1 %descriptor.range.valid.1057, label %descriptor.valid.1059, label %descriptor.invalid.1060
descriptor.invalid.1060:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1059:
  %descriptor.initialized.status.1061 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1045, i32 %local.check.extent.1046)
  %helper.ok.1062 = icmp eq i32 %descriptor.initialized.status.1061, 0
  br i1 %helper.ok.1062, label %helper.continue.1063, label %frame.failure.0
helper.continue.1063:
  br label %local.descriptor.checked.1044
local.descriptor.inactive.1043:
  br label %local.descriptor.checked.1044
local.descriptor.checked.1044:
  %local.is.active.1064 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1064, label %local.descriptor.active.1065, label %local.descriptor.inactive.1066
local.descriptor.active.1065:
  %local.check.offset.1068 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1069 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1070 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1071 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1072 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1073 = load i32, ptr %context.field.1072, align 4
  %stack.sub.1076 = sub i32 %local.check.owner.end.1071, %local.check.offset.1068
  %descriptor.owner.inside.1074 = icmp ule i32 %local.check.owner.end.1071, %context.value.1073
  %descriptor.offset.inside.1075 = icmp ule i32 %local.check.offset.1068, %local.check.owner.end.1071
  %descriptor.extent.inside.1077 = icmp ule i32 %local.check.extent.1069, %stack.sub.1076
  %descriptor.payload.inside.1078 = icmp ule i32 %local.check.payload.1070, %local.check.extent.1069
  %descriptor.owner.offset.valid.1079 = and i1 %descriptor.owner.inside.1074, %descriptor.offset.inside.1075
  %descriptor.range.inside.1081 = and i1 %descriptor.owner.offset.valid.1079, %descriptor.extent.inside.1077
  %descriptor.range.valid.1080 = and i1 %descriptor.range.inside.1081, %descriptor.payload.inside.1078
  br i1 %descriptor.range.valid.1080, label %descriptor.valid.1082, label %descriptor.invalid.1083
descriptor.invalid.1083:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1082:
  %descriptor.initialized.status.1084 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1068, i32 %local.check.extent.1069)
  %helper.ok.1085 = icmp eq i32 %descriptor.initialized.status.1084, 0
  br i1 %helper.ok.1085, label %helper.continue.1086, label %frame.failure.0
helper.continue.1086:
  br label %local.descriptor.checked.1067
local.descriptor.inactive.1066:
  br label %local.descriptor.checked.1067
local.descriptor.checked.1067:
  %local.is.active.1087 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1087, label %local.descriptor.active.1088, label %local.descriptor.inactive.1089
local.descriptor.active.1088:
  %local.check.offset.1091 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1092 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1093 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1094 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1095 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1096 = load i32, ptr %context.field.1095, align 4
  %stack.sub.1099 = sub i32 %local.check.owner.end.1094, %local.check.offset.1091
  %descriptor.owner.inside.1097 = icmp ule i32 %local.check.owner.end.1094, %context.value.1096
  %descriptor.offset.inside.1098 = icmp ule i32 %local.check.offset.1091, %local.check.owner.end.1094
  %descriptor.extent.inside.1100 = icmp ule i32 %local.check.extent.1092, %stack.sub.1099
  %descriptor.payload.inside.1101 = icmp ule i32 %local.check.payload.1093, %local.check.extent.1092
  %descriptor.owner.offset.valid.1102 = and i1 %descriptor.owner.inside.1097, %descriptor.offset.inside.1098
  %descriptor.range.inside.1104 = and i1 %descriptor.owner.offset.valid.1102, %descriptor.extent.inside.1100
  %descriptor.range.valid.1103 = and i1 %descriptor.range.inside.1104, %descriptor.payload.inside.1101
  br i1 %descriptor.range.valid.1103, label %descriptor.valid.1105, label %descriptor.invalid.1106
descriptor.invalid.1106:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1105:
  %descriptor.initialized.status.1107 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1091, i32 %local.check.extent.1092)
  %helper.ok.1108 = icmp eq i32 %descriptor.initialized.status.1107, 0
  br i1 %helper.ok.1108, label %helper.continue.1109, label %frame.failure.0
helper.continue.1109:
  br label %local.descriptor.checked.1090
local.descriptor.inactive.1089:
  br label %local.descriptor.checked.1090
local.descriptor.checked.1090:
  %step.status.1110 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.1111 = icmp eq i32 %step.status.1110, 0
  br i1 %helper.ok.1111, label %helper.continue.1112, label %frame.failure.0
helper.continue.1112:
  %context.field.1113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.1114 = load i32, ptr %context.field.1113, align 4
  %inline.target.depth.within.interpreter.limit.1115 = icmp ule i32 %context.value.1114, 65
  br i1 %inline.target.depth.within.interpreter.limit.1115, label %inline.target.depth.ok.1116, label %inline.target.depth.invalid.1117
inline.target.depth.invalid.1117:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 19, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.1116:
  %stack.offset.1118 = add i32 0, %local.resolved.payload.870
  %stack.offset.1119 = add i32 %stack.offset.1118, %local.resolved.payload.984
  %stack.offset.1120 = add i32 0, %local.resolved.extent.869
  %stack.offset.1121 = add i32 %stack.offset.1120, %local.resolved.extent.983
  %context.field.1122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1123 = load i32, ptr %context.field.1122, align 4
  %stack.offset.1124 = add i32 %context.value.1123, %stack.offset.1121
  %reserve.status.1125 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1124, i32 20)
  %reserve.ok.1126 = icmp eq i32 %reserve.status.1125, 0
  br i1 %reserve.ok.1126, label %reserve.continue.1127, label %frame.failure.0
reserve.continue.1127:
  %stack.offset.1128 = add i32 %context.value.1123, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1128, i32 %local.resolved.offset.868, i32 %local.resolved.extent.869, i32 %local.resolved.payload.870, i32 4, i32 6)
  %context.field.1129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1130 = load i32, ptr %context.field.1129, align 4
  %runtime.ok.1131 = icmp eq i32 %context.value.1130, 0
  br i1 %runtime.ok.1131, label %runtime.continue.1132, label %frame.failure.0
runtime.continue.1132:
  %stack.offset.1133 = add i32 0, %local.resolved.extent.869
  %stack.offset.1134 = add i32 %context.value.1123, %stack.offset.1133
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1134, i32 %local.resolved.offset.982, i32 %local.resolved.extent.983, i32 %local.resolved.payload.984, i32 2, i32 6)
  %context.field.1135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1136 = load i32, ptr %context.field.1135, align 4
  %runtime.ok.1137 = icmp eq i32 %context.value.1136, 0
  br i1 %runtime.ok.1137, label %runtime.continue.1138, label %frame.failure.0
runtime.continue.1138:
  %stack.offset.1139 = add i32 %stack.offset.1133, %local.resolved.extent.983
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.1123, i32 %stack.offset.1121, i32 %stack.offset.1119, i32 0, i32 0)
  %context.field.1140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1141 = load i32, ptr %context.field.1140, align 4
  %runtime.ok.1142 = icmp eq i32 %context.value.1141, 0
  br i1 %runtime.ok.1142, label %runtime.continue.1143, label %frame.failure.0
runtime.continue.1143:
  %context.field.1144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1145 = load i32, ptr %context.field.1144, align 4
  %stack.sub.1148 = sub i32 %stack.offset.1124, %context.value.1123
  %descriptor.owner.inside.1146 = icmp ule i32 %stack.offset.1124, %context.value.1145
  %descriptor.offset.inside.1147 = icmp ule i32 %context.value.1123, %stack.offset.1124
  %descriptor.extent.inside.1149 = icmp ule i32 %stack.offset.1121, %stack.sub.1148
  %descriptor.payload.inside.1150 = icmp ule i32 %stack.offset.1119, %stack.offset.1121
  %descriptor.owner.offset.valid.1151 = and i1 %descriptor.owner.inside.1146, %descriptor.offset.inside.1147
  %descriptor.range.inside.1153 = and i1 %descriptor.owner.offset.valid.1151, %descriptor.extent.inside.1149
  %descriptor.range.valid.1152 = and i1 %descriptor.range.inside.1153, %descriptor.payload.inside.1150
  %descriptor.type.valid.1154 = icmp eq i32 5, 5
  %descriptor.valid.1155 = and i1 %descriptor.range.valid.1152, %descriptor.type.valid.1154
  br i1 %descriptor.valid.1155, label %descriptor.valid.1156, label %descriptor.invalid.1157
descriptor.invalid.1157:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1156:
  %descriptor.initialized.status.1158 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1123, i32 %stack.offset.1121)
  %helper.ok.1159 = icmp eq i32 %descriptor.initialized.status.1158, 0
  br i1 %helper.ok.1159, label %helper.continue.1160, label %frame.failure.0
helper.continue.1160:
  %local.is.active.1161 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1161, label %local.descriptor.active.1162, label %local.descriptor.inactive.1163
local.descriptor.active.1162:
  %local.check.offset.1165 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1166 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1167 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1168 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1170 = load i32, ptr %context.field.1169, align 4
  %stack.sub.1173 = sub i32 %local.check.owner.end.1168, %local.check.offset.1165
  %descriptor.owner.inside.1171 = icmp ule i32 %local.check.owner.end.1168, %context.value.1170
  %descriptor.offset.inside.1172 = icmp ule i32 %local.check.offset.1165, %local.check.owner.end.1168
  %descriptor.extent.inside.1174 = icmp ule i32 %local.check.extent.1166, %stack.sub.1173
  %descriptor.payload.inside.1175 = icmp ule i32 %local.check.payload.1167, %local.check.extent.1166
  %descriptor.owner.offset.valid.1176 = and i1 %descriptor.owner.inside.1171, %descriptor.offset.inside.1172
  %descriptor.range.inside.1178 = and i1 %descriptor.owner.offset.valid.1176, %descriptor.extent.inside.1174
  %descriptor.range.valid.1177 = and i1 %descriptor.range.inside.1178, %descriptor.payload.inside.1175
  br i1 %descriptor.range.valid.1177, label %descriptor.valid.1179, label %descriptor.invalid.1180
descriptor.invalid.1180:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1179:
  %descriptor.initialized.status.1181 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1165, i32 %local.check.extent.1166)
  %helper.ok.1182 = icmp eq i32 %descriptor.initialized.status.1181, 0
  br i1 %helper.ok.1182, label %helper.continue.1183, label %frame.failure.0
helper.continue.1183:
  br label %local.descriptor.checked.1164
local.descriptor.inactive.1163:
  br label %local.descriptor.checked.1164
local.descriptor.checked.1164:
  %local.is.active.1184 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1184, label %local.descriptor.active.1185, label %local.descriptor.inactive.1186
local.descriptor.active.1185:
  %local.check.offset.1188 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1189 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1190 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1191 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1193 = load i32, ptr %context.field.1192, align 4
  %stack.sub.1196 = sub i32 %local.check.owner.end.1191, %local.check.offset.1188
  %descriptor.owner.inside.1194 = icmp ule i32 %local.check.owner.end.1191, %context.value.1193
  %descriptor.offset.inside.1195 = icmp ule i32 %local.check.offset.1188, %local.check.owner.end.1191
  %descriptor.extent.inside.1197 = icmp ule i32 %local.check.extent.1189, %stack.sub.1196
  %descriptor.payload.inside.1198 = icmp ule i32 %local.check.payload.1190, %local.check.extent.1189
  %descriptor.owner.offset.valid.1199 = and i1 %descriptor.owner.inside.1194, %descriptor.offset.inside.1195
  %descriptor.range.inside.1201 = and i1 %descriptor.owner.offset.valid.1199, %descriptor.extent.inside.1197
  %descriptor.range.valid.1200 = and i1 %descriptor.range.inside.1201, %descriptor.payload.inside.1198
  br i1 %descriptor.range.valid.1200, label %descriptor.valid.1202, label %descriptor.invalid.1203
descriptor.invalid.1203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1202:
  %descriptor.initialized.status.1204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1188, i32 %local.check.extent.1189)
  %helper.ok.1205 = icmp eq i32 %descriptor.initialized.status.1204, 0
  br i1 %helper.ok.1205, label %helper.continue.1206, label %frame.failure.0
helper.continue.1206:
  br label %local.descriptor.checked.1187
local.descriptor.inactive.1186:
  br label %local.descriptor.checked.1187
local.descriptor.checked.1187:
  %local.is.active.1207 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1207, label %local.descriptor.active.1208, label %local.descriptor.inactive.1209
local.descriptor.active.1208:
  %local.check.offset.1211 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1212 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1213 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1214 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1216 = load i32, ptr %context.field.1215, align 4
  %stack.sub.1219 = sub i32 %local.check.owner.end.1214, %local.check.offset.1211
  %descriptor.owner.inside.1217 = icmp ule i32 %local.check.owner.end.1214, %context.value.1216
  %descriptor.offset.inside.1218 = icmp ule i32 %local.check.offset.1211, %local.check.owner.end.1214
  %descriptor.extent.inside.1220 = icmp ule i32 %local.check.extent.1212, %stack.sub.1219
  %descriptor.payload.inside.1221 = icmp ule i32 %local.check.payload.1213, %local.check.extent.1212
  %descriptor.owner.offset.valid.1222 = and i1 %descriptor.owner.inside.1217, %descriptor.offset.inside.1218
  %descriptor.range.inside.1224 = and i1 %descriptor.owner.offset.valid.1222, %descriptor.extent.inside.1220
  %descriptor.range.valid.1223 = and i1 %descriptor.range.inside.1224, %descriptor.payload.inside.1221
  br i1 %descriptor.range.valid.1223, label %descriptor.valid.1225, label %descriptor.invalid.1226
descriptor.invalid.1226:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1225:
  %descriptor.initialized.status.1227 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1211, i32 %local.check.extent.1212)
  %helper.ok.1228 = icmp eq i32 %descriptor.initialized.status.1227, 0
  br i1 %helper.ok.1228, label %helper.continue.1229, label %frame.failure.0
helper.continue.1229:
  br label %local.descriptor.checked.1210
local.descriptor.inactive.1209:
  br label %local.descriptor.checked.1210
local.descriptor.checked.1210:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.1230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1231 = load i32, ptr %context.field.1230, align 4
  %stack.sub.1234 = sub i32 %stack.offset.1124, %context.value.1123
  %descriptor.owner.inside.1232 = icmp ule i32 %stack.offset.1124, %context.value.1231
  %descriptor.offset.inside.1233 = icmp ule i32 %context.value.1123, %stack.offset.1124
  %descriptor.extent.inside.1235 = icmp ule i32 %stack.offset.1121, %stack.sub.1234
  %descriptor.payload.inside.1236 = icmp ule i32 %stack.offset.1119, %stack.offset.1121
  %descriptor.owner.offset.valid.1237 = and i1 %descriptor.owner.inside.1232, %descriptor.offset.inside.1233
  %descriptor.range.inside.1239 = and i1 %descriptor.owner.offset.valid.1237, %descriptor.extent.inside.1235
  %descriptor.range.valid.1238 = and i1 %descriptor.range.inside.1239, %descriptor.payload.inside.1236
  %descriptor.type.valid.1240 = icmp eq i32 5, 5
  %descriptor.valid.1241 = and i1 %descriptor.range.valid.1238, %descriptor.type.valid.1240
  br i1 %descriptor.valid.1241, label %descriptor.valid.1242, label %descriptor.invalid.1243
descriptor.invalid.1243:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1242:
  %descriptor.initialized.status.1244 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1123, i32 %stack.offset.1121)
  %helper.ok.1245 = icmp eq i32 %descriptor.initialized.status.1244, 0
  br i1 %helper.ok.1245, label %helper.continue.1246, label %frame.failure.0
helper.continue.1246:
  %local.is.active.1247 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1247, label %local.descriptor.active.1248, label %local.descriptor.inactive.1249
local.descriptor.active.1248:
  %local.check.offset.1251 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1252 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1253 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1254 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1255 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1256 = load i32, ptr %context.field.1255, align 4
  %stack.sub.1259 = sub i32 %local.check.owner.end.1254, %local.check.offset.1251
  %descriptor.owner.inside.1257 = icmp ule i32 %local.check.owner.end.1254, %context.value.1256
  %descriptor.offset.inside.1258 = icmp ule i32 %local.check.offset.1251, %local.check.owner.end.1254
  %descriptor.extent.inside.1260 = icmp ule i32 %local.check.extent.1252, %stack.sub.1259
  %descriptor.payload.inside.1261 = icmp ule i32 %local.check.payload.1253, %local.check.extent.1252
  %descriptor.owner.offset.valid.1262 = and i1 %descriptor.owner.inside.1257, %descriptor.offset.inside.1258
  %descriptor.range.inside.1264 = and i1 %descriptor.owner.offset.valid.1262, %descriptor.extent.inside.1260
  %descriptor.range.valid.1263 = and i1 %descriptor.range.inside.1264, %descriptor.payload.inside.1261
  br i1 %descriptor.range.valid.1263, label %descriptor.valid.1265, label %descriptor.invalid.1266
descriptor.invalid.1266:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1265:
  %descriptor.initialized.status.1267 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1251, i32 %local.check.extent.1252)
  %helper.ok.1268 = icmp eq i32 %descriptor.initialized.status.1267, 0
  br i1 %helper.ok.1268, label %helper.continue.1269, label %frame.failure.0
helper.continue.1269:
  br label %local.descriptor.checked.1250
local.descriptor.inactive.1249:
  br label %local.descriptor.checked.1250
local.descriptor.checked.1250:
  %local.is.active.1270 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1270, label %local.descriptor.active.1271, label %local.descriptor.inactive.1272
local.descriptor.active.1271:
  %local.check.offset.1274 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1275 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1276 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1277 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1279 = load i32, ptr %context.field.1278, align 4
  %stack.sub.1282 = sub i32 %local.check.owner.end.1277, %local.check.offset.1274
  %descriptor.owner.inside.1280 = icmp ule i32 %local.check.owner.end.1277, %context.value.1279
  %descriptor.offset.inside.1281 = icmp ule i32 %local.check.offset.1274, %local.check.owner.end.1277
  %descriptor.extent.inside.1283 = icmp ule i32 %local.check.extent.1275, %stack.sub.1282
  %descriptor.payload.inside.1284 = icmp ule i32 %local.check.payload.1276, %local.check.extent.1275
  %descriptor.owner.offset.valid.1285 = and i1 %descriptor.owner.inside.1280, %descriptor.offset.inside.1281
  %descriptor.range.inside.1287 = and i1 %descriptor.owner.offset.valid.1285, %descriptor.extent.inside.1283
  %descriptor.range.valid.1286 = and i1 %descriptor.range.inside.1287, %descriptor.payload.inside.1284
  br i1 %descriptor.range.valid.1286, label %descriptor.valid.1288, label %descriptor.invalid.1289
descriptor.invalid.1289:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1288:
  %descriptor.initialized.status.1290 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1274, i32 %local.check.extent.1275)
  %helper.ok.1291 = icmp eq i32 %descriptor.initialized.status.1290, 0
  br i1 %helper.ok.1291, label %helper.continue.1292, label %frame.failure.0
helper.continue.1292:
  br label %local.descriptor.checked.1273
local.descriptor.inactive.1272:
  br label %local.descriptor.checked.1273
local.descriptor.checked.1273:
  %local.is.active.1293 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1293, label %local.descriptor.active.1294, label %local.descriptor.inactive.1295
local.descriptor.active.1294:
  %local.check.offset.1297 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1298 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1299 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1300 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1302 = load i32, ptr %context.field.1301, align 4
  %stack.sub.1305 = sub i32 %local.check.owner.end.1300, %local.check.offset.1297
  %descriptor.owner.inside.1303 = icmp ule i32 %local.check.owner.end.1300, %context.value.1302
  %descriptor.offset.inside.1304 = icmp ule i32 %local.check.offset.1297, %local.check.owner.end.1300
  %descriptor.extent.inside.1306 = icmp ule i32 %local.check.extent.1298, %stack.sub.1305
  %descriptor.payload.inside.1307 = icmp ule i32 %local.check.payload.1299, %local.check.extent.1298
  %descriptor.owner.offset.valid.1308 = and i1 %descriptor.owner.inside.1303, %descriptor.offset.inside.1304
  %descriptor.range.inside.1310 = and i1 %descriptor.owner.offset.valid.1308, %descriptor.extent.inside.1306
  %descriptor.range.valid.1309 = and i1 %descriptor.range.inside.1310, %descriptor.payload.inside.1307
  br i1 %descriptor.range.valid.1309, label %descriptor.valid.1311, label %descriptor.invalid.1312
descriptor.invalid.1312:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1311:
  %descriptor.initialized.status.1313 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1297, i32 %local.check.extent.1298)
  %helper.ok.1314 = icmp eq i32 %descriptor.initialized.status.1313, 0
  br i1 %helper.ok.1314, label %helper.continue.1315, label %frame.failure.0
helper.continue.1315:
  br label %local.descriptor.checked.1296
local.descriptor.inactive.1295:
  br label %local.descriptor.checked.1296
local.descriptor.checked.1296:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1316 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1317 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1316, i32 0, i32 0
  store i32 5, ptr %descriptor.field.1317, align 4
  %descriptor.field.1318 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1316, i32 0, i32 1
  store i32 %context.value.1123, ptr %descriptor.field.1318, align 4
  %descriptor.field.1319 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1316, i32 0, i32 2
  store i32 %stack.offset.1121, ptr %descriptor.field.1319, align 4
  %descriptor.field.1320 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1316, i32 0, i32 3
  store i32 %stack.offset.1119, ptr %descriptor.field.1320, align 4
  %descriptor.field.1321 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1316, i32 0, i32 4
  store i32 %stack.offset.1124, ptr %descriptor.field.1321, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.1123, i32 20, i32 %stack.offset.1119, i32 %stack.offset.1124, i32 %stack.offset.1121)
  %context.field.1322 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1323 = load i32, ptr %context.field.1322, align 4
  %runtime.ok.1324 = icmp eq i32 %context.value.1323, 0
  br i1 %runtime.ok.1324, label %runtime.continue.1325, label %frame.failure.0
runtime.continue.1325:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.1326 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1327 = load i32, ptr %context.field.1326, align 4
  %context.field.1328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1329 = load i32, ptr %context.field.1328, align 4
  %context.field.1330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1331 = load i32, ptr %context.field.1330, align 4
  %stack.offset.1332 = add i32 %context.value.23, %context.value.25
  %stack.offset.1333 = add i32 %context.value.1327, %context.value.1329
  %stack.sub.1334 = sub i32 %stack.offset.1332, %stack.offset.1333
  %stack.sub.1335 = sub i32 %context.value.25, %context.value.1329
  %stack.sub.1336 = sub i32 %context.value.1331, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1334, i32 %stack.sub.1335)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1336)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 21, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 22)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 4, i32 23)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 4, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 24)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 5
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 5)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


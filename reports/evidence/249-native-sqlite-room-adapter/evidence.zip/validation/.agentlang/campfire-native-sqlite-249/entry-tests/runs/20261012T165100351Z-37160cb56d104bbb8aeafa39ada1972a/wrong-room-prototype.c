long long al_host_campfire_rooms_find_for_user_v1(void*, long long, long long, unsigned char*, unsigned int, unsigned int*);

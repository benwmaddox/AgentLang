#requires -Version 7.0
# One complete host lifetime for the 256 replication set: pre-checks, Run-Host,
# READY, affinity, Measure, affinity -After, stop event, terminal receipt.
# Adds no measurement logic; the pinned helpers do all host/client work.
param(
  [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$')][string]$RunName,
  [Parameter(Mandatory)][ValidateSet('Off','Detailed')][string]$ExecutionProfile
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$builds = @{
  Off = Join-Path $root 'http-host/build-trusted-generated-20261014T024827989Z-d2758979e2b0494990f27277ab7a4967/O2'
  Detailed = Join-Path $root 'http-host/build-trusted-generated-20261014T025123703Z-d825095eb8cd491baf942bbda32cf9b2/O2'
}
$driverRoot = Join-Path $root "replication-driver/$RunName"
if (Test-Path -LiteralPath $driverRoot) { throw 'Driver roots are immutable; choose a new RunName.' }
$null = New-Item -ItemType Directory -Path $driverRoot -Force
$log = Join-Path $driverRoot 'driver.log'
function Note([string]$Text) { "$([DateTime]::UtcNow.ToString('O')) $Text" | Add-Content -LiteralPath $log -Encoding utf8NoBOM; Write-Output $Text }
function Snapshot([string]$Name) {
  Get-Process | Select-Object Id, ProcessName, @{n='StartUtc';e={ try { $_.StartTime.ToUniversalTime().ToString('O') } catch { $null } }} |
    Sort-Object Id | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $driverRoot "$Name.json") -Encoding utf8NoBOM
}

# Pre-checks: no listener on the authorized ports and no other agent writing helpers.
$listening = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 13773, 13774
$httpSys = netsh http show servicestate view=requestq | Select-String '127\.0\.0\.1:1377[34]'
if ($listening -or $httpSys) { throw 'A listener already owns 13773/13774; refusing to start.' }
$watched = 'seal_evidence.py', 'verify_archive.py', 'aggregate_profiles.py', 'Run-Host.ps1', 'Measure.ps1', 'Apply-Affinity.ps1'
$before = @{}; foreach ($name in $watched) { $before[$name] = (Get-FileHash -LiteralPath (Join-Path $root $name) -Algorithm SHA256).Hash }
Snapshot 'processes-before'
Note "precheck ok run=$RunName profile=$ExecutionProfile pwsh=$($PSVersionTable.PSVersion)"

$pwsh = (Get-Process -Id $PID).Path
$hostArgs = @('-NoProfile', '-File', (Join-Path $root 'Run-Host.ps1'), '-BuildDirectory', $builds[$ExecutionProfile],
  '-RunName', $RunName, '-ExecutionProfile', $ExecutionProfile, '-Optimization', 'O2', '-Workers', '4')
$runHost = Start-Process -FilePath $pwsh -ArgumentList $hostArgs -PassThru -NoNewWindow `
  -RedirectStandardOutput (Join-Path $driverRoot 'run-host.out.log') -RedirectStandardError (Join-Path $driverRoot 'run-host.err.log')
$null = $runHost.Handle  # keeps ExitCode readable after exit
$runRoot = Join-Path $root "runs/$RunName"
$deadline = [DateTime]::UtcNow.AddSeconds(90)
$ready = $false
while ([DateTime]::UtcNow -lt $deadline -and -not $runHost.HasExited) {
  $hostLog = Join-Path $runRoot 'native-host.log'
  if ((Test-Path (Join-Path $runRoot 'host-process.json')) -and (Test-Path $hostLog) -and
      (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet)) { $ready = $true; break }
  Start-Sleep -Milliseconds 250
}
$stop = $null
try {
  if (-not $ready) { throw 'Host did not report READY within 90 seconds.' }
  $serverPid = [int]((Get-Content -LiteralPath (Join-Path $runRoot 'host-process.json') -Raw | ConvertFrom-Json).processId)
  Note "ready pid=$serverPid"
  & $pwsh -NoProfile -File (Join-Path $root 'Apply-Affinity.ps1') -RunName $RunName -ServerPid $serverPid
  if ($LASTEXITCODE -ne 0) { throw 'Apply-Affinity failed.' }
  & $pwsh -NoProfile -File (Join-Path $root 'Measure-269.ps1') -RunName $RunName -ExecutionProfile $ExecutionProfile
  if ($LASTEXITCODE -ne 0) { throw 'Measure failed.' }
  & $pwsh -NoProfile -File (Join-Path $root 'Apply-Affinity.ps1') -RunName $RunName -ServerPid $serverPid -After
  if ($LASTEXITCODE -ne 0) { throw 'Apply-Affinity -After failed.' }
  Note 'measured'
} finally {
  Snapshot 'processes-after'
  if (-not $runHost.HasExited) {
    try {
      $stop = [Threading.EventWaitHandle]::OpenExisting('Local\CampfireNative256Stop')
      [void]$stop.Set()
      Note 'stop signalled'
    } catch { Note "stop event unavailable: $($_.Exception.Message)" }
    finally { if ($stop) { $stop.Dispose() } }
  }
  if (-not $runHost.WaitForExit(120000)) { Note 'Run-Host did not exit within 120s; leaving it for manual inspection' }
  else { $runHost.WaitForExit(); Note "run-host exit=$($runHost.ExitCode)" }
}
foreach ($name in $watched) {
  if ((Get-FileHash -LiteralPath (Join-Path $root $name) -Algorithm SHA256).Hash -ne $before[$name]) { Note "WARNING helper changed during run: $name" }
}
Get-Content -LiteralPath (Join-Path $driverRoot 'run-host.out.log') | Select-Object -Last 2

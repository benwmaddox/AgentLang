# Campfire native execution-profile 256

O2 trusted-generated native room GET; StageProfile On in both arms; execution Off/Detailed ABBA; four workers, fixed four-core host mask, fixed affinity-disjoint client mask, concurrency 16, two 15-second repeats per host, 20 warmups per repeat. The pinned 256 client records latency after the full body arrives and before status/body-digest validation; throughput includes validation.

| Run | Profile | Host GETs | Correct req/s | Median repeat P99 upper bound (ms) | Provider ticks / API ticks |
|---|---|---:|---:|---:|---:|
| OffA | off | 453161 | 15103.00 | 1.753 | — |
| DetailedB | detailed | 286738 | 9555.68 | 2.433 | 30.724384104183716 |
| DetailedC | detailed | 287208 | 9571.20 | 2.460 | 30.54114566438244 |
| OffD | off | 444850 | 14825.99 | 1.582 | — |

Combined Detailed throughput change: -36.09%.

## Detailed category means

Per-run category totals and means are in the JSON report. Runtime counters overlap, SQL counters nest inside provider callbacks, and these columns must not be summed into API time.

| Profile | Category | Calls | Failures | Mean µs/call | Calls/host GET |
|---|---|---:|---:|---:|---:|
| DetailedB | reserve_release | 53333268 | 0 | 0.0158 | 186.0000 |
| DetailedB | initialization_check | 1259640034 | 0 | 0.0158 | 4393.0000 |
| DetailedB | arena_copy | 25519682 | 0 | 0.0647 | 89.0000 |
| DetailedB | value_measure | 11469520 | 0 | 0.6751 | 40.0000 |
| DetailedB | external_measure | 2007166 | 0 | 1.6562 | 7.0000 |
| DetailedB | structural_locate | 82580544 | 0 | 0.3653 | 288.0000 |
| DetailedB | host_output_commit | 1720428 | 0 | 1.7289 | 6.0000 |
| DetailedB | frame_validation | 34695298 | 0 | 0.0160 | 121.0000 |
| DetailedB | other_runtime_validation | 30394228 | 0 | 0.1025 | 106.0000 |
| DetailedB | cookie_verify_session_token | 286738 | 0 | 6.5068 | 1.0000 |
| DetailedB | session_find_by_token | 286738 | 0 | 12.0523 | 1.0000 |
| DetailedB | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedB | user_find_by_id | 286738 | 0 | 4.3771 | 1.0000 |
| DetailedB | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedB | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedB | room_find_for_user | 286738 | 0 | 5.8252 | 1.0000 |
| DetailedB | membership_exists | 286738 | 0 | 3.8541 | 1.0000 |
| DetailedB | message_last_page | 286738 | 0 | 74.4070 | 1.0000 |
| DetailedB | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedB | sql_bind | 2580642 | 0 | 0.1732 | 9.0000 |
| DetailedB | sql_step | 25519682 | 0 | 0.8987 | 89.0000 |
| DetailedB | sql_reset | 23225778 | 0 | 0.0898 | 81.0000 |
| DetailedC | reserve_release | 53420688 | 0 | 0.0158 | 186.0000 |
| DetailedC | initialization_check | 1261704744 | 0 | 0.0158 | 4393.0000 |
| DetailedC | arena_copy | 25561512 | 0 | 0.0648 | 89.0000 |
| DetailedC | value_measure | 11488320 | 0 | 0.6766 | 40.0000 |
| DetailedC | external_measure | 2010456 | 0 | 1.6649 | 7.0000 |
| DetailedC | structural_locate | 82715904 | 0 | 0.3659 | 288.0000 |
| DetailedC | host_output_commit | 1723248 | 0 | 1.7338 | 6.0000 |
| DetailedC | frame_validation | 34752168 | 0 | 0.0160 | 121.0000 |
| DetailedC | other_runtime_validation | 30444048 | 0 | 0.1030 | 106.0000 |
| DetailedC | cookie_verify_session_token | 287208 | 0 | 6.5599 | 1.0000 |
| DetailedC | session_find_by_token | 287208 | 0 | 12.2637 | 1.0000 |
| DetailedC | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedC | user_find_by_id | 287208 | 0 | 4.4041 | 1.0000 |
| DetailedC | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedC | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedC | room_find_for_user | 287208 | 0 | 5.9332 | 1.0000 |
| DetailedC | membership_exists | 287208 | 0 | 3.8742 | 1.0000 |
| DetailedC | message_last_page | 287208 | 0 | 73.2769 | 1.0000 |
| DetailedC | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedC | sql_bind | 2584872 | 0 | 0.1877 | 9.0000 |
| DetailedC | sql_step | 25561512 | 0 | 0.8889 | 89.0000 |
| DetailedC | sql_reset | 23263848 | 0 | 0.0897 | 81.0000 |

## Interpretation limits

- Stage timing is enabled in both arms; this estimates incremental detailed runtime counter overhead, not host stage-profiler overhead.
- Worker timer sums overlap in wall time; runtime category totals also overlap; SQL intervals are nested within provider callbacks.
- Client p95/p99 values are histogram upper bounds from successful responses only and remain separate from host QPC means/maxima.
- SQLite step time is not lock-wait time. No lock-cause claim is supported by this steady-state workload.
- The pure cookie SRW lock, adapter active-state guard, and internal SQLite/HTTP.sys/CNG synchronization are outside separately timed wait counters; low operation totals do not establish absence of contention.
- This private Windows HTTP.sys workload is not apples-to-apples with the public Rails/Docker benchmark or a WebSocket-capacity test.

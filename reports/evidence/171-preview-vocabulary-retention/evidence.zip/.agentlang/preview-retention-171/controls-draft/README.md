# Preview replacement control drafts

Private coordinator sources only. Do not copy these files into either participant seed or its prompt.

All four functions use the Flow/2 declaration form and declare effects none. The two positive controls return the full input Store on successful validation and propagate errors unchanged.

- retained.agent delegates validation to the persisted subscription.handoff; that helper cancels first and passes the resulting Store to subscription.start.
- reset.agent composes the qualified cancellation and replacement functions. If the old subscription is missing, cancellation supplies the original not-found error. Otherwise it starts the replacement from the cancelled Store and returns the input Store only on success.
- wrong-order.agent checks the replacement ID against the original Store first. The independent oracle predicts wrong DUPLICATE_SUBSCRIPTION results for missing-old-precedes-duplicate, cancelled-old-precedes-duplicate, and before-start-precedes-duplicate; cancellation errors have precedence in those cases.
- leaked-store.agent returns the intermediate cancelled Store when subscription.start fails. The independent oracle predicts behavioral mismatches for the 16 start-failure cases: third-party-overlap, replacement-id-is-old, replacement-id-exists, blank-term, empty-replacement-period, reversed-replacement-period, duplicate-precedes-blank-term, blank-term-precedes-bad-period, bad-period-precedes-overlap, old-customer-missing, old-product-missing, old-customer-and-product-missing, blank-term-precedes-missing-customer, bad-period-precedes-missing-customer, missing-product-precedes-overlap, and duplicate-precedes-missing-customer.

The independent model predicts both positive controls match all 33 oracle cases, including full Store preservation on success and input preservation on failure. These are source-only predictions; the controls have not been executed or runtime-qualified.

"""Read-only preservation and stable-identity reuse audit, adapted from report 163."""
from pathlib import Path
import argparse
import hashlib
import json

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / '.agentlang/pr171'


def load(project):
    store = project / '.agentlang/store'
    current = json.loads((store / 'CURRENT').read_text(encoding='utf-8-sig'))
    return json.loads((store / 'manifests' / (current['manifestHash'] + '.json')).read_text(encoding='utf-8-sig'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--arm', choices=['reset', 'retained'], required=True)
    arm = parser.parse_args().arm
    seed_project = ROOT / 'seeds' / arm
    actor_project = ROOT / 'actors' / arm
    seed, actor = load(seed_project), load(actor_project)
    words = {r['wordId']: r for r in actor['words']}
    versions = {(r['wordId'], r['revision']): r for r in actor['revisions']}
    types = {r['name']: r for r in actor['types']}
    changed_words = [r['currentName'] for r in seed['words'] if words.get(r['wordId']) != r]
    changed_versions = [dict(name=r['name'], revision=r['revision']) for r in seed['revisions']
                        if versions.get((r['wordId'], r['revision'])) != r]
    changed_types = [r['name'] for r in seed['types'] if types.get(r['name']) != r]
    changed_objects = []
    original_objects = 0
    for original in (seed_project / '.agentlang/store/objects').rglob('*'):
        if original.is_file():
            original_objects += 1
            counterpart = actor_project / original.relative_to(seed_project)
            if not counterpart.is_file() or hashlib.sha256(counterpart.read_bytes()).digest() != hashlib.sha256(original.read_bytes()).digest():
                changed_objects.append(original.relative_to(seed_project).as_posix())
    original_ids = {r['wordId'] for r in seed['words']}
    new_words = [r for r in actor['words'] if r['wordId'] not in original_ids]
    target = next((r for r in actor['words'] if r['currentName'] == 'subscription.preview-replacement'), None)
    target_version = versions.get((target['wordId'], target['currentRevision'])) if target else None

    def user_calls(row):
        revision = versions[(row['wordId'], row['currentRevision'])]
        return [binding for binding in revision.get('callBindings', [])
                if binding.get('bodyRole') == 'definition' and binding['target']['kind'] == 'userWord']

    visited = set()
    pending = [target['wordId']] if target else []
    while pending:
        word_id = pending.pop()
        if word_id not in visited and word_id in words:
            visited.add(word_id)
            pending.extend(b['target']['identity'] for b in user_calls(words[word_id]))
    retained_helper = next((r for r in seed['words'] if r['currentName'] == 'subscription.handoff'), None)
    direct = [dict(requestedName=b['requestedName'], stableId=b['target']['identity'],
                   existedAtTaskStart=b['target']['identity'] in original_ids)
              for b in user_calls(target)] if target else []
    report = dict(arm=arm, preservationPassed=not any([changed_words, changed_versions, changed_types, changed_objects]),
                  originalWordRows=len(seed['words']), originalRevisions=len(seed['revisions']),
                  originalTypes=len(seed['types']), originalObjects=original_objects,
                  changedWords=changed_words, changedRevisions=changed_versions, changedTypes=changed_types,
                  changedObjects=changed_objects, newFunctions=[r['currentName'] for r in new_words],
                  targetMaturity=target_version['maturity'] if target_version else None,
                  targetTests=len(target_version['tests']) if target_version else 0,
                  directUserCalls=direct,
                  reusedRetainedHandoff=bool(retained_helper and retained_helper['wordId'] in visited),
                  reconstructedHandoff=any(r['currentName'] == 'subscription.handoff' for r in new_words))
    (ROOT / f'audit-{arm}.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
    return 0 if report['preservationPassed'] and target_version and target_version['maturity'] == 'library' else 1


if __name__ == '__main__':
    raise SystemExit(main())

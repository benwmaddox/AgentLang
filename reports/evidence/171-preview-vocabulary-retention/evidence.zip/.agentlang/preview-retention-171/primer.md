Use only the supplied JSONL broker, one request per line through its live session.
AI agents are external users of the language; the runtime contains none.

Discover names with `{"op":"search","query":"subscription"}` or
`{"op":"words","compact":true}`. `describe` returns metadata and source;
`source`, `dependencies`, `callers`, `tests` and bounded `context` support inspection.
Use dictionary names for protocol queries. Use reported Flow/2 `flowReference`
spellings for calls; an exact-root call begins with a dot, as in `.add(1, 2)`.

Select `frontend:"flow", syntaxVersion:2` on every definition/evaluation request.
Flow/2 uses `fn`, named typed inputs, immutable `let`, dotted qualified calls,
record properties `value.field`, newline separators and exhaustive matches.
A bound receiver passes itself as the first argument: `value.operation(args)`.
Both branches return the declared type. No implicit nominal conversions occur.

```flow
fn increment(value: Int) -> Int {
    effects none
    doc "Adds one."

    .add(value, 1)
}
test increment/basic {
    .increment(1)
    => 2
}
```

Omitted effects means pure. Put effects before doc, then a blank line before code.
Use versioned runtime help for exact syntax:
`{"op":"help","frontend":"flow","syntaxVersion":2,"topic":"define"}`.
Generic values use `result.ok<T,E>(value)`, `result.error<T,E>(error)` and
`option.some<T>(value)`. Inspect examples/tests rather than guessing constructors.

Tests attach through `function-name/case-name`. Bare `=>` accepts supported
literals; `=> value expression` compares constructed values. `=> error CODE`
expects a runtime failure, not a returned `Result.error` value. Inspect authored
cases with `{"op":"tests","word":"...","includeSource":true,"caseName":"..."}`.

Begin a task with `task.begin` and a goal. Define source, run `test` for the new
function, then `commit` with its word name and `library:true`. Library functions
need passing own tests, complete own instruction/branch and finite-value coverage,
and qualified dependencies. Caller tests do not replace helper coverage.
Run relevant regressions, preserve all old definitions/tests, and finish with
`task.commit`. `test-all` updates the latest coverage batch; a later single-word
test can replace that batch. Query help for failures rather than weakening gates.

Protocol bytes are not model tokens. Poll the same live handle after observation
timeouts; never repeat an uncertain mutation. Finish with `{"op":"host.close"}`
and observe terminal status. Do not spawn/contact other agents or use other tools.

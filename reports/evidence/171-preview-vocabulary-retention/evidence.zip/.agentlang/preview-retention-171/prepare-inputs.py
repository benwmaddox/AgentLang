"""Revalidate disposable research seeds using a freshly built, pinned CLI."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / '.agentlang/pr171'
GATE = REPO / '.agentlang/nominal-int-170/full-validation-001.json'


def inventory(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'WRITE.lock']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--overlap-seed-validation', action='store_true')
    args = parser.parse_args()
    if args.overlap_seed_validation:
        gate_source = GATE.with_suffix('.txt')
        log = gate_source.read_text(encoding='utf-8-sig')
        required = ['build', 'business-language-acceptance', 'flow-runtime-acceptance',
                    'cli-acceptance', 'storage-acceptance', 'ir-interpreter-acceptance']
        if not all(f'{name} (exit 0)' in log for name in required):
            raise RuntimeError('Fresh build and all required research CLI checks must already pass.')
        changes = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--',
                                           'src/AgentLang.Cli', 'src/AgentLang.Core'], cwd=REPO, text=True)
        if changes.strip():
            raise RuntimeError('Overlapping validation cannot use changed CLI/Core sources.')
        release_status = 'full Release pending; CLI build and required interpreter checks passed'
    else:
        gate_source = GATE
        gate = json.loads(GATE.read_text(encoding='utf-8-sig'))
        if not gate.get('passed') or len(gate.get('checks', [])) != 37 or any(c['exitCode'] for c in gate['checks']):
            raise RuntimeError('All 37 current local Release checks must pass before staging.')
        release_status = 'full Release passed'
    if ROOT.exists():
        raise RuntimeError('Refusing to overwrite comparison evidence or projects.')
    ROOT.mkdir()
    setup = ROOT / 'setup'
    setup.mkdir()
    temporary = ROOT / 'tmp'
    temporary.mkdir()
    runtime_source = REPO / 'src/AgentLang.Cli/bin/Release/net9.0'
    shutil.copytree(runtime_source, ROOT / 'runtime')
    runtime_inventory = inventory(ROOT / 'runtime')
    if runtime_inventory != inventory(runtime_source):
        raise RuntimeError('Staged runtime does not exactly match current Release outputs.')
    cli = ROOT / 'runtime/AgentLang.Cli.dll'
    env = dict(os.environ, TEMP=str(temporary), TMP=str(temporary))
    requests = '\n'.join(json.dumps({'op': op}) for op in ['words', 'test-all']) + '\n'
    (setup / 'requests.jsonl').write_text(requests, encoding='utf-8')
    seeds = []
    for arm, source, expected_words, expected_tests, retained in [
        ('reset', '.agentlang/subscription-handoff-163/seeds/agentlang-project', 214, 137, False),
        ('retained', '.agentlang/subscription-handoff-163/actors/flow', 215, 142, True),
    ]:
        seed_source = REPO / source
        project = ROOT / 'seeds' / arm
        shutil.copytree(seed_source, project, ignore=shutil.ignore_patterns('WRITE.lock'))
        before = inventory(project)
        if before != inventory(seed_source):
            raise RuntimeError(f'{arm}: copied seed differs from original.')
        process = subprocess.run(
            ['dotnet', str(cli), '--project', str(project), '--filesystem', 'virtual', '--jsonl'],
            cwd=REPO, input=requests, text=True, encoding='utf-8', errors='replace',
            capture_output=True, env=env, timeout=600)
        (setup / f'{arm}-responses.jsonl').write_text(process.stdout, encoding='utf-8')
        (setup / f'{arm}-stderr.txt').write_text(process.stderr, encoding='utf-8')
        responses = [json.loads(line) for line in process.stdout.splitlines()]
        if process.returncode != 0 or len(responses) != 2 or not all(r.get('ok') for r in responses):
            raise RuntimeError(f'{arm}: seed reload failed; saved responses explain the failure.')
        words = responses[0]['data']['words']
        tests = responses[1]['data']['results']
        checks = [len(words) == expected_words, len(tests) == expected_tests,
                  all(w['maturity'] == 'library' for w in words),
                  any(w['name'] == 'subscription.handoff' for w in words) == retained,
                  all(t['passed'] for t in tests), inventory(project) == before]
        if not all(checks):
            raise RuntimeError(f'{arm}: fixed seed qualification or preservation failed: {checks}')
        seeds.append(dict(arm=arm, source=source, words=len(words), tests=len(tests), files=before))
    result = dict(status='seeds validated; controls and participant dispatch pending',
                  releaseStatus=release_status, gateEvidence=gate_source.relative_to(REPO).as_posix(),
                  gateEvidenceSha256=hashlib.sha256(gate_source.read_bytes()).hexdigest(),
                  runtime=runtime_inventory, seeds=seeds)
    (setup / 'inputs.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ('runtime', 'seeds')}, indent=2))


if __name__ == '__main__':
    main()

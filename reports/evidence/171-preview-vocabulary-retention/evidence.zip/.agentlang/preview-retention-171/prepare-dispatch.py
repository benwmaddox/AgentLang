"""Freeze a calibrated exploratory pair; no participant execution here."""
from pathlib import Path
import hashlib
import json
import secrets
import shutil
import subprocess
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ROOT = REPO / '.agentlang/pr171'
OPERATIONS = 'help,words,source,tests,define,test,test-all,commit,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort'
COMMON = '''You are a fresh external experimental coding agent. The human explicitly authorizes edits ONLY to your isolated trial project and local test execution through the supplied broker. Read this assigned prompt and launch the specified broker; otherwise use only that broker for discovery, edits and tests. Do not read main repository source, other trials, hidden oracles, reports or snapshots. Do not use web tools, spawn agents, list/read/contact other agents or run other shell commands. Disclose any non-broker tool use. Use one broker process, at most 100 exchanges. Poll the same handle after observation timeouts. Finish with {"op":"host.close"} and observe terminal status.

Task: add a pure subscription.preview-replacement(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError>. Validate cancelling the existing subscription at handoffAt, then validate creating an active replacement for the same customer and product with the requested term and expiry. Preserve the existing cancellation-then-creation error precedence and exact returned error. If validation succeeds, return the complete original Store unchanged; if it fails, return the original error and leave the input unchanged. Preserve all unrelated state and existing public definitions/tests. Add useful tests for success and failure, document the function, publish it as a library word with its attached tests, and commit the task normally. Do not change existing function signatures. Discover and reuse useful project capabilities where appropriate.

'''


def files(root):
    return [dict(path=p.relative_to(root).as_posix(), bytes=p.stat().st_size,
                 sha256=hashlib.sha256(p.read_bytes()).hexdigest())
            for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'WRITE.lock']


def main():
    calibration = json.loads((ROOT / 'setup/calibration.json').read_text())
    if calibration['status'] != 'passed' or len(calibration['controls']) != 4:
        raise RuntimeError('All four fully executed controls are required.')
    if (ROOT / 'actors').exists() or (ROOT / 'setup/freeze.json').exists():
        raise RuntimeError('Refusing to overwrite participant inputs.')
    inputs = json.loads((ROOT / 'setup/inputs.json').read_text())
    if files(ROOT / 'runtime') != inputs['runtime']:
        raise RuntimeError('Pinned runtime changed since seed validation.')
    primer = (HERE / 'primer.md').read_text(encoding='utf-8')
    for arm in ['retained', 'reset']:
        project = ROOT / 'actors' / arm
        seed = ROOT / 'seeds' / arm
        shutil.copytree(seed, project)
        expected = next(r['files'] for r in inputs['seeds'] if r['arm'] == arm)
        if files(project) != expected or files(seed) != expected:
            raise RuntimeError(f'{arm}: participant seed changed.')
        command = f'''\nLaunch once with exec_command, tty:true, yield_time_ms:10000.\n\n```powershell
$env:TEMP = '{ROOT / 'tmp'}'
$env:TMP = $env:TEMP
& '{REPO / 'scripts/Start-SubagentTrialHostV2.ps1'}' -CliDll '{ROOT / 'runtime/AgentLang.Cli.dll'}' -ProjectPath '{project}' -TracePath '{ROOT / ('trace-' + arm + '.jsonl')}' -AllowedOperations @('{OPERATIONS}') -Profile 'agentlang' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```\n'''
        (ROOT / f'prompt-{arm}.md').write_text(COMMON + primer + command, encoding='utf-8')
    order = ['retained', 'reset']
    if secrets.randbelow(2):
        order.reverse()
    selected = [ROOT / 'runtime', ROOT / 'seeds', ROOT / 'prompt-retained.md',
                ROOT / 'prompt-reset.md', HERE / 'primer.md', HERE / 'drafts/score_adapter.py',
                HERE / 'controls-draft', HERE / 'prepare-inputs.py', HERE / 'calibrate.py',
                Path(__file__), ROOT / 'setup/inputs.json', ROOT / 'setup/calibration.json',
                ROOT / 'controls-002', ROOT / 'out',
                REPO / 'scripts/Start-SubagentTrialHostV2.ps1',
                REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle']
    pins = []
    for source in selected:
        candidates = sorted(source.rglob('*')) if source.is_dir() else [source]
        for p in candidates:
            if p.is_file() and '__pycache__' not in p.parts and p.name != 'WRITE.lock':
                pins.append(dict(path=p.relative_to(REPO).as_posix(), bytes=p.stat().st_size,
                                 sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    result = dict(status='frozen; dispatch pending', frozenAt=datetime.now(timezone.utc).isoformat(),
                  head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
                  order=order, model='gpt-6-luna', reasoning='max', sequential=True,
                  comparison='retained abstraction plus tests/history versus reset-abstraction',
                  timingPolicy='No latency or throughput comparisons: local Release validation may overlap.',
                  fullReleaseStatus=inputs['releaseStatus'], files=pins)
    (ROOT / 'setup/freeze.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'files'}, indent=2))


if __name__ == '__main__':
    main()

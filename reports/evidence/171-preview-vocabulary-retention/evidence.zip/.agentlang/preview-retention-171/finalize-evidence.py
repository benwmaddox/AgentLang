"""Verify accepted local results and preserve this bounded experiment's evidence."""
from pathlib import Path
import hashlib
import json
import zipfile

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / '.agentlang/pr171'
COORD = Path(__file__).parent
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

freeze = read(ROOT / 'setup/freeze.json')
for row in freeze['files']:
    path = REPO / row['path']
    assert path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], row['path']
gate = read(REPO / '.agentlang/nominal-int-170/full-validation-001.json')
assert gate['passed'] and len(gate['checks']) == 37
assert all(row['exitCode'] == 0 for row in gate['checks'])
facts = read(ROOT / 'facts.json')
regressions = {}
for arm, expected in [('reset', 141), ('retained', 145)]:
    rows = [json.loads(line) for line in (ROOT / f'regression-{arm}-001.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    assert len(rows) == 1 and rows[0]['ok']
    results = rows[0]['data']['results']
    assert len(results) == expected and all(row['passed'] for row in results)
    assert facts[arm]['independentPassed'] == 33 and facts[arm]['preservationPassed']
    batches = []
    for row in (ROOT / f'trace-{arm}.jsonl').read_text().splitlines():
        event = json.loads(row)
        if event['event'] != 'exchange':
            continue
        request = json.loads(event['request']['rawLine'])
        response = json.loads(event['response']['rawLine'])
        if request['op'] in ['test', 'test-all']:
            tests = response.get('data', {}).get('results', [])
            assert response['ok'] and tests and all(test['passed'] for test in tests)
            batches.append({'operation': request['op'], 'word': request.get('word'), 'count': len(tests), 'passed': True})
        if request['op'] == 'define':
            assert response['ok']
    regressions[arm] = {'reloadCount': expected, 'allPassed': True, 'terminalExitCode': 0, 'participantTestBatches': batches}
(ROOT / 'final-verification.json').write_text(json.dumps({'frozenInputsUnchanged': True, 'frozenFileCount': len(freeze['files']), 'fullReleaseChecks': 37, 'regressions': regressions}, indent=2) + '\n')

roots = [ROOT, COORD, REPO / 'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle']
paths = {REPO / '.agentlang/nominal-int-170/full-validation-001.json', REPO / '.agentlang/nominal-int-170/full-validation-001.txt'}
excluded_parts = {'tmp', 'temp', 'bin', 'obj', '__pycache__', 'repo-temp', 'compiler-temp', 'full-temp', 'dotnet-artifacts'}
excluded_extensions = {'.dll', '.exe', '.pdb', '.pyc', '.lock', '.xml'}
for root in roots:
    for path in root.rglob('*'):
        if path.is_file() and not excluded_parts.intersection(path.relative_to(root).parts) and path.suffix.lower() not in excluded_extensions:
            path.resolve().relative_to(REPO)
            paths.add(path)
destination = REPO / 'reports/evidence/171-preview-vocabulary-retention'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'evidence.zip'
entries = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(paths):
        data = path.read_bytes()
        name = path.relative_to(REPO).as_posix()
        output.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and len(check.infolist()) == len(entries)
    for entry in entries:
        data = check.read(entry['path'])
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
        assert digest(REPO / entry['path']) == entry['sha256']
manifest = {'status': 'verified', 'description': 'Frozen experiment inputs, local accepted and failed setup evidence, complete saved actor projects, independent scores and preservation audits. Runtime binaries and temporary build directories excluded.', 'archive': {'path': 'evidence.zip', 'bytes': archive.stat().st_size, 'sha256': digest(archive)}, 'files': entries}
(destination / 'archive.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'entries': len(entries), **manifest['archive']}))

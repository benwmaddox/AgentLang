"""Private behavior controls; requires current seed reloads, never dispatches agents."""
from pathlib import Path
import argparse
import importlib.util
import json
import shutil
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ROOT = REPO / '.agentlang/pr171'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, choices=range(1, 100), default=1)
    args = parser.parse_args()
    ready = json.loads((ROOT / 'setup/inputs.json').read_text(encoding='utf-8'))
    if ready['status'] != 'seeds validated; controls and participant dispatch pending':
        raise RuntimeError('Validated current seeds are required.')
    control_root = ROOT / ('controls' if args.attempt == 1 else f'controls-{args.attempt:03d}')
    if control_root.exists():
        raise RuntimeError('Refusing to overwrite calibration evidence.')
    control_root.mkdir()
    spec = importlib.util.spec_from_file_location('preview_scoring', HERE / 'drafts/score_adapter.py')
    scorer = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = scorer
    spec.loader.exec_module(scorer)
    cli = ROOT / 'runtime/AgentLang.Cli.dll'
    results = []
    for name, seed, positive in [('retained', 'retained', True), ('reset', 'reset', True),
                                 ('wrong-order', 'reset', False), ('leaked-store', 'reset', False)]:
        project = control_root / name
        shutil.copytree(ROOT / 'seeds' / seed, project)
        source = (HERE / 'controls-draft' / f'{name}.agent').read_text(encoding='utf-8')
        happy = next(case for case in scorer.load_cases() if case['expected']['tag'] == 'ok')
        call = scorer.preview_observation_expr(happy).replace(
            'preview-retention.scoring-observe(', 'subscription.preview-replacement(', 1)
        source += ('\n\ntest subscription.preview-replacement/calibration-success {\n'
                   f'    {call}\n'
                   f'    => value result.ok<Store, BusinessError>({scorer.OLD.store_expr(happy["store"])})\n'
                   '}\n')
        requests = [{'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'source': source},
                    {'op': 'test', 'word': 'subscription.preview-replacement'},
                    {'op': 'commit', 'word': 'subscription.preview-replacement', 'library': False}]
        run_dir = scorer.OLD.next_run_dir(scorer.EVIDENCE_ROOT / f'prepare-{name}')
        code, stdout, stderr, responses = scorer.run_scoring_cli(project, requests, cli, run_dir / 'tmp')
        (run_dir / 'requests.jsonl').write_text('\n'.join(json.dumps(r) for r in requests) + '\n', encoding='utf-8')
        (run_dir / 'responses.jsonl').write_text(stdout, encoding='utf-8')
        (run_dir / 'stderr.txt').write_text(stderr, encoding='utf-8')
        if code or len(responses) != 3 or not all(r.get('ok') for r in responses):
            raise RuntimeError(f'{name}: control setup failed, not a behavioral rejection.')
        score = scorer.score_actor(project, cli, 'control', name)
        if score['setupFailure'] is not None or score['executedCaseCount'] != 33 or score['setupErrorCount']:
            raise RuntimeError(f'{name}: all 33 cases must execute without setup errors.')
        if positive and score['passedCaseCount'] != 33:
            raise RuntimeError(f'{name}: correct control did not pass all 33 cases.')
        if not positive and not score['failingCaseIds']:
            raise RuntimeError(f'{name}: scorer did not detect the intended defect.')
        results.append(dict(name=name, positive=positive, executed=score['executedCaseCount'],
                            passed=score['passedCaseCount'], failingCaseIds=score['failingCaseIds']))
    (ROOT / 'setup/calibration.json').write_text(json.dumps(dict(status='passed', controls=results), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()

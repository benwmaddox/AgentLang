# Staging, primer and readiness handoff

## Frozen inputs to stage after milestone 170

- Reset-abstraction source: `.agentlang/subscription-handoff-163/seeds/agentlang-project`.
- Retained source: `.agentlang/subscription-handoff-163/actors/flow`.
- Independent oracle: `experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/{model.py,cases.json,model-checks.json}`.
- Prior scorer/staging precedents: `experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py`; `.agentlang/subscription-handoff-163/{refresh-seeds.py,stage-actors.py,stage-runtime.py,audit-flow-preservation.py}`; report-166 scorer and staging sources are preserved inside `reports/evidence/166-handoff-signature-maintenance-agent-pair/166-handoff-signature-maintenance-agent-pair.zip`.
- Current Release CLI source path: `src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll`. Do not reuse the report-163 staged binary; it predates current changes.

The report-163 seed-preparation code copies a pre-handoff accepted project and verifies 214 library words/137 tests. Its Flow preservation audit verifies the accepted actor retained prior authored definitions, types and source objects and added only `subscription.handoff` with five tests. The report-166 seed recipe copies these accepted actors and adds only coordinator-owned callers. Use these as provenance examples; do not run old scripts because they refuse overwrite or write to old evidence paths.

Before dispatch, after the live Release gate finishes and root approves:

1. Build/pin the current Release runtime using the exact commands in the completed milestone-170 gate record. Record CLI and dependency hashes. Do not run a competing gate or begin participant sessions while gate session 28313 is live.
2. Copy each source seed into a **new disposable validation directory** under `.agentlang/preview-retention-171/`; preserve the originals. For each copy, run this JSONL reload check with a workspace-local temp directory (replace the project variable with that arm's validation copy):

   ```powershell
   $previewCli = 'D:\code\AgentLang\src\AgentLang.Cli\bin\Release\net9.0\AgentLang.Cli.dll'
   $previewProject = 'D:\code\AgentLang\.agentlang\preview-retention-171\validation\reset-abstraction'
   $previewTemp = 'D:\code\AgentLang\.agentlang\preview-retention-171\drafts\tmp'
   $env:TEMP = $previewTemp
   $env:TMP = $previewTemp
   $previewRequests = '{"op":"words"}' + "`n" + '{"op":"test-all"}'
   $previewRequests | dotnet $previewCli --project $previewProject --filesystem virtual --jsonl
   ```

   Require the reset seed to load without `subscription.handoff` (214 library words/137 passing tests) and the retained seed to load with it (215 library words/142 passing tests). Record any differences from those pinned counts instead of editing manifests.
3. Copy the validated source projects and complete runtime into new staged input paths, hash prompt, shared primer, oracle, controls, seeds and runtime, then freeze the inventory. Validate one retained correct preview control and one reset-abstraction correct control at 33/33. Validate wrong-order and leaked-intermediate controls execute all 33 and fail before dispatch.
4. Dispatch the two fresh Luna/max actors sequentially with identical public prompt, current runtime, broker limits and allowlist. Record the predeclared arm order; suppress participant latency comparisons if the Release gate overlaps any part of dispatch.
5. Run the draft scorer against both saved actor projects and controls. Audit source/test preservation, target qualification, helper dependency/reuse and task completion separately from the complete 33-case behavioral score.

No exact full-gate command is copied here because session 28313 is already running; consume its final command/output record and do not launch a duplicate. After it completes, rerun only the seed reload/test-all checks and the independent preview controls as required by the new trial protocol. The new scorer command is in `scorer-adapter.md`.

## Shared primer choice

Use the tracked `experiments/AgentLang.SubagentTrials/business-policy-retention-003/language-primer.md` as the frozen shared compact primer. Its SHA-256 is `7CA98F0C8C9A20A84076D2A6B62DA7A36AC12959E17EC1890EC74F9CBF9B578E`; it is byte-identical to the 004 and business-policy-help-002 copies. Add the same two short version-matched guidance lines to the public prompt in both arms:

- inspect existing authored test bodies with `{"op":"tests","word":"...","includeSource":true,"caseName":"..."}`; the default remains name-only;
- use `help` with Flow/2 syntax options, and distinguish returned `Result.error` values (`=> value result.error<...>(...)`) from runtime errors (`=> error CODE`).

This selection uses the current shared primer while incorporating report 164's returned-Result clarification and report 167's current test-source selector. Pin final prompt bytes after reviewing against the freshly built runtime; help/schema behavior and counts must be identical across arms.

## Unresolved before dispatch

- Milestone 170 and live Release gate 28313 must complete; there is no validated current CLI hash in this draft.
- Both seeds must be loaded and their attached tests replayed on the fresh current runtime before they are treated as compatible inputs.
- Correct/fault control source and scorer output have not been generated or run. Require full execution counts and the mutation failures above; do not weaken the 33-case oracle to make a control pass.
- The retained seed includes handoff tests and task/history metadata. Report this package-level context difference; do not claim a perfectly isolated one-definition ablation.
- This single matched pair can show task-specific reuse/correctness feasibility, not a general retention or reliability advantage. No participant latency comparison is planned during gate execution.

This is a readiness draft only. No staging copies, actors, runtime, broker sessions, builds, tests or trial records were created.

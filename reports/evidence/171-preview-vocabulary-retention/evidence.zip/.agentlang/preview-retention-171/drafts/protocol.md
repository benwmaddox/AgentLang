# Preview replacement retention comparison

Status: both current interpreter seeds are revalidated and all four private controls fully execute. Research validation overlaps the original live Release gate. Its fresh CLI/Core build and relevant interpreter acceptance checks already pass, and those sources are unchanged from the accepted baseline; the pending native milestone is not a research dependency. Freeze inputs before sequential dispatch and exclude latency/throughput comparisons. Native milestone publication still requires every full Release check.

## Coordinator design (private)

Compare two fresh AgentLang Flow/2 actors under the same task, current Release runtime, compact primer, tool allowlist and scorer:

- **retained abstraction** starts from the accepted report-163 AgentLang actor at `.agentlang/subscription-handoff-163/actors/flow`.
- **reset-abstraction** starts from the accepted report-163 pre-handoff seed at `.agentlang/subscription-handoff-163/seeds/agentlang-project`.

Both contain the same qualified cancellation and replacement vocabulary. The retained seed contains the agent-authored `subscription.handoff` plus its five attached tests and task/history metadata. That package is the treatment; this is neither primitive-only Flat nor a cross-module test. Report 163's preservation audit verified prior authored definitions, types and source objects unchanged. The baseline had 214 library words/137 tests; the accepted actor adds one library function/five tests. Treat prior helper tests/history as part of the package and disclose that extra context; do not claim the two projects differ byte-for-byte only by a function.

Use one fresh `gpt-6-luna` / max agent per arm, no inherited task history, same prompt and broker limits, sequential dispatch with order randomized and recorded before dispatch. Do not compare participant latency while the current Release gate is running. The report-163 independent oracle has 33 cases (26 common-reference and seven adversarial orphan-reference); keep all cases private. Do not reveal model, case IDs, expected values, or mutation controls in participant prompts. A new shared Flow/2 primer replaces the older primer, whose code examples still used Flow/1 spelling and unversioned requests; both arms receive identical current guidance.

Score behavior, caller input preservation, pre-existing source/test preservation, new word's own tests/library qualification, dependency/call-graph reuse, and task completion as separate outcomes. A reset participant that recreates a helper did not reuse a helper present at task start; classify new helper creation separately. One matched pair is exploratory, not a reliability-rate estimate.

## Shared public prompt draft

Send only this common prompt, with the arm-specific broker launch block. It deliberately does not name any existing helper:

> You are a fresh external coding agent. The human authorizes edits only to your isolated trial project and local validation through the supplied broker. Use only that broker for discovery, edits and tests; do not read the main repository, other trials, hidden acceptance inputs, reports or snapshots. Do not use web tools, spawn or contact other agents, or run other shell commands. Use one broker process, at most 100 exchanges, and finish with `host.close`.
>
> **Task:** add a pure `subscription.preview-replacement(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError>` operation. It validates cancelling the existing subscription at `handoffAt`, then validates creating an active replacement for the same customer and product with the requested term and expiry. Preserve the existing cancellation-then-creation error precedence and exact returned error. If validation succeeds, return the complete original `Store` unchanged; if it fails, return the original error and leave the input unchanged. Preserve all unrelated state and existing public definitions/tests. Add useful tests for success and failure, document the function, publish it as a library word with its attached tests, and commit the task normally. Do not change existing function signatures.
>
> Use runtime help with Flow/2 (`frontend: "flow"`, `syntaxVersion: 2`) for exact source and test syntax. `tests` can return authored case source with `includeSource: true` and a `caseName`; default `tests` lists names. For a returned `Result.error` value, use a value expectation such as `=> value result.error<Store, BusinessError>(...)`; `=> error CODE` matches a runtime failure. Keep all Flow authoring/evaluation requests versioned as Flow/2.

Use the same allowlist in both arms: `help,words,source,tests,define,test,test-all,commit,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort`. Do not expose the private scorer or coordinator control source through the project or broker.

## Private acceptance plan

Derive preview expectations from the frozen report-163 `model.py`/`cases.json`: for every model success, expected output Store is the original fixture Store; for every model error, retain the exact code and original input. Compare complete canonical projections of both output and input. Qualify one correct retained control and one correct reset-abstraction control at 33/33 before dispatch. Qualify a wrong-validation-order control (duplicate replacement checked before cancellation) and a leaked-intermediate-store control; each must execute all 33 cases and fail at least one appropriate hidden case. Keep the independent model and control bodies outside participant-visible projects.

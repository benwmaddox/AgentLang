# Scorer adapter draft

Use the report-163 `score_agentlang.py` helpers and report-163 `model.py`/`cases.json`; do not rebuild the independent model or introduce another harness. The coordinator-only thin adapter is `score_adapter.py` in this directory. It is draft source and has not been executed.

The adapter changes are limited to the target observer and successful projection. Its run records go under `.agentlang/pr171/out/`, with an arm label restricted to one short path component:

```python
def expected_preview_projection(item):
    expected_model = item["expected"]
    expected_input = OLD.normalized_projection(item)
    if expected_model["tag"] == "ok":
        return {
            "tag": "ok",
            "store": OLD.normalized_projection({"store": item["store"]}),
            "input": expected_input,
        }
    return {"tag": "error", "code": expected_model["code"], "input": expected_input}
```

The observation wrapper calls only the target and carries both input and result:

```flow
record PreviewReplacementScoringObservation {
    field input: Store
    field outcome: Result<Store, BusinessError>
}

fn preview-retention.scoring-observe(input: Store, old-id: SubscriptionId, replacement-id: SubscriptionId, term: String, handoff-at: Instant, expires-at: Instant) -> PreviewReplacementScoringObservation {
    previewReplacementScoringObservation.new(
        input = input,
        outcome = subscription.preview-replacement(input, old-id, replacement-id, term, handoff-at, expires-at))
}
```

For each fixture, build the same typed Store/IDs/timestamps with report-163 helpers, call the observer once, unwrap its single structured result, and compare `OLD.result_projection(...)` against `expected_preview_projection(...)`. Require 34 responses (observer definition plus all 33 evals), one structured value per case, all 33 executed, and zero setup errors. A wrapper-only `define` on a disposable copy must not redeclare `subscription.preview-replacement`. Record the CLI hash and actor path; score each saved actor/control copy independently. The adapter imports `OLD.store_expr`, `OLD.result_projection`, `OLD.unwrap_structured`, `OLD.normalized_projection`, and `OLD.case_fixture_populations`; it validates frozen `cases.json` against `MODEL.expected` before use. It does not call report 163's `OLD.run_cli`, because that helper inherits the ambient filesystem and temp directory. Its small local runner passes `--filesystem virtual`, sets `TEMP` and `TMP` to a per-run directory under the workspace evidence root, and removes that temporary directory after the CLI exits. The report-163 JSON-line encoder and response projection helpers remain reused.

Do not score helper reuse through the behavioral adapter. Compare each participant's pre-task seed inventory to its final saved project and inspect the target dependency/call graph separately. A reset-arm helper created during the task is reconstruction, not reuse. Keep own test/coverage/library status, old-test body preservation, commit/task completion, and independent behavior in separate report fields.

Coordinator-only invocation after the new pinned Release CLI and actor/control copies exist:

```powershell
python .agentlang/preview-retention-171/drafts/score_adapter.py --actor-project <saved-project> --arm retained --cli .agentlang/pr171/runtime/AgentLang.Cli.dll
python .agentlang/preview-retention-171/drafts/score_adapter.py --actor-project <saved-project> --arm reset-abstraction --cli .agentlang/pr171/runtime/AgentLang.Cli.dll
```

These commands are future validation steps only; no CLI, actors, scorer or controls were run in this preparation pass.

"""Coordinator-only, wrapper-based adapter for the preview-retention pilot.

This thin adapter reuses report 163's typed fixture encoder and canonical
projection. It is draft code: do not execute until the current Release gate and
parent review complete.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import subprocess


REPO = Path(__file__).resolve().parents[3]
ORACLE = REPO / "experiments" / "AgentLang.SubagentTrials" / "subscription-handoff-161" / "oracle"
EVIDENCE_ROOT = REPO / ".agentlang" / "pr171" / "out"
DEFAULT_CLI = REPO / "src" / "AgentLang.Cli" / "bin" / "Release" / "net9.0" / "AgentLang.Cli.dll"
LABEL_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,47}\Z")


def validate_label(value: str) -> str:
    if not LABEL_PATTERN.fullmatch(value):
        raise ValueError("label must be one path component of 1-48 ASCII letters, digits, '_' or '-'")
    return value


def import_from_path(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_name} from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


OLD = import_from_path("preview_retention_handoff_163_scorer", ORACLE / "score_agentlang.py")
MODEL = import_from_path("preview_retention_handoff_163_model", ORACLE / "model.py")

OBSERVER_SOURCE = r'''// frontend: flow/2

record PreviewReplacementScoringObservation {
    field input: Store
    field outcome: Result<Store, BusinessError>
}

fn preview-retention.scoring-observe(input: Store, old-id: SubscriptionId, replacement-id: SubscriptionId, term: String, handoff-at: Instant, expires-at: Instant) -> PreviewReplacementScoringObservation {
    previewReplacementScoringObservation.new(
        input = input,
        outcome = subscription.preview-replacement(input, old-id, replacement-id, term, handoff-at, expires-at))
}
'''


def load_cases() -> list[dict]:
    rows = json.loads((ORACLE / "cases.json").read_text(encoding="utf-8"))
    modeled = {item["id"]: item for item in MODEL.CASES}
    if len(rows) != 33 or len(modeled) != 33 or {row["id"] for row in rows} != set(modeled):
        raise ValueError("Expected the frozen report-163 33-case fixture set")
    for row in rows:
        if row.get("expected") != MODEL.expected(modeled[row["id"]]):
            raise ValueError(f"Frozen expected value disagrees with the independent model for {row['id']}")
    return rows


def preview_observation_expr(item: dict) -> str:
    request = item["request"]
    return (
        "preview-retention.scoring-observe("
        f"{OLD.store_expr(item['store'])}, "
        f"SubscriptionId.new({OLD.flow_string(OLD.id_for(OLD.SUBSCRIPTION_IDS, request['oldId']))}), "
        f"SubscriptionId.new({OLD.flow_string(OLD.id_for(OLD.SUBSCRIPTION_IDS, request['newId']))}), "
        f"{OLD.flow_string(request['term'])}, "
        f"Instant.new({OLD.flow_string(OLD.iso_day(request['at']))}), "
        f"Instant.new({OLD.flow_string(OLD.iso_day(request['expiry']))}))"
    )


def expected_projection(item: dict) -> dict:
    expected_model = item["expected"]
    expected_input = OLD.normalized_projection(item)
    if expected_model["tag"] == "ok":
        return {
            "tag": "ok",
            "store": OLD.normalized_projection({"store": item["store"]}),
            "input": expected_input,
        }
    return {"tag": "error", "code": expected_model["code"], "input": expected_input}


def score_response(item: dict, response: dict) -> dict:
    result = {"caseId": item["id"], "executed": False, "passed": False}
    if response.get("ok") and response.get("kind") == "eval":
        structured = response.get("data", {}).get("structuredStack")
        if structured and len(structured.get("values", [])) == 1:
            actual = OLD.result_projection(OLD.unwrap_structured(structured["values"][0]))
            expected = expected_projection(item)
            result.update(executed=True, passed=(actual == expected))
            if actual != expected:
                result["actual"] = actual
                result["expected"] = expected
        else:
            result["setupError"] = "eval response omitted one structured observation value"
    else:
        result["setupError"] = response.get("error", response.get("text", "missing eval response"))
    return result


def project_fingerprint(project: Path) -> str:
    digest = hashlib.sha256()
    store = project / ".agentlang" / "store"
    paths = [path for path in store.rglob("*") if path.is_file() and path.name != "WRITE.lock"] if store.is_dir() else []
    dictionary = project / "dictionary.agent"
    if dictionary.is_file():
        paths.append(dictionary)
    for path in sorted(set(paths), key=lambda value: value.relative_to(project).as_posix()):
        relative = path.relative_to(project).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


def run_scoring_cli(project: Path, requests: list[dict], cli: Path, temp_root: Path) -> tuple[int, str, str, list[dict]]:
    request_text = "\n".join(OLD.json_line(item) for item in requests) + "\n"
    temp_root.mkdir()
    environment = os.environ.copy()
    environment["TEMP"] = str(temp_root)
    environment["TMP"] = str(temp_root)
    try:
        process = subprocess.run(
            ["dotnet", str(cli), "--project", str(project), "--filesystem", "virtual", "--jsonl"],
            cwd=REPO,
            input=request_text,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=300,
            env=environment,
        )
        rows = []
        for index, line in enumerate(process.stdout.splitlines(), 1):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise RuntimeError(f"CLI stdout line {index} is not JSON: {line[:500]!r}") from error
        return process.returncode, process.stdout, process.stderr, rows
    finally:
        temp_root.resolve().relative_to(EVIDENCE_ROOT.resolve())
        shutil.rmtree(temp_root)


def target_identity(project: Path) -> dict:
    store = project / ".agentlang" / "store"
    current = json.loads((store / "CURRENT").read_text(encoding="utf-8-sig"))
    manifest = json.loads((store / "manifests" / f"{current['manifestHash']}.json").read_text(encoding="utf-8-sig"))
    word = next((row for row in manifest["words"] if row["currentName"] == "subscription.preview-replacement"), None)
    if word is None:
        raise ValueError(f"No saved subscription.preview-replacement word in {project}")
    revision = next((row for row in manifest["revisions"]
                     if row["wordId"] == word["wordId"] and row["revision"] == word["currentRevision"]), None)
    if revision is None:
        raise ValueError(f"No current saved preview-replacement revision in {project}")
    return {"wordId": word["wordId"], "name": word["currentName"],
            "revision": word["currentRevision"], "definitionHash": revision["definition"]["hash"]}


def score_actor(actor_project: Path, cli: Path, arm: str, label: str) -> dict:
    label = validate_label(label)
    actor_project = actor_project.expanduser().resolve()
    cli = cli.expanduser().resolve()
    if not actor_project.is_dir() or not cli.is_file():
        raise FileNotFoundError(f"Actor project or current Release CLI is missing: {actor_project}, {cli}")
    cases = load_cases()
    initial_identity = target_identity(actor_project)
    initial_fingerprint = project_fingerprint(actor_project)

    run_dir = OLD.next_run_dir(EVIDENCE_ROOT / label)
    project = run_dir / "actor-project-copy"
    shutil.copytree(actor_project, project)
    if target_identity(project) != initial_identity or project_fingerprint(project) != initial_fingerprint:
        raise RuntimeError("Scoring copy did not preserve the saved actor project")

    requests = [{"op": "define", "frontend": "flow", "syntaxVersion": 2, "source": OBSERVER_SOURCE}]
    requests.extend({
        "op": "eval", "frontend": "flow", "syntaxVersion": 2, "structured": True,
        "code": preview_observation_expr(item),
    } for item in cases)
    exit_code, stdout, stderr, responses = run_scoring_cli(project, requests, cli, run_dir / "tmp")
    (run_dir / "scoring-observers.flow").write_text(OBSERVER_SOURCE, encoding="utf-8")
    (run_dir / "requests.jsonl").write_text("\n".join(OLD.json_line(row) for row in requests) + "\n", encoding="utf-8")
    (run_dir / "responses.jsonl").write_text(stdout, encoding="utf-8")
    (run_dir / "stderr.txt").write_text(stderr, encoding="utf-8")

    define_response = responses[0] if responses else {}
    defined_names = [row.get("name") for row in define_response.get("data", {}).get("words", [])]
    if not defined_names and define_response.get("data", {}).get("name"):
        defined_names = [define_response["data"]["name"]]
    setup_failure = None
    if len(responses) != len(requests):
        setup_failure = {"stage": "response-count", "exitCode": exit_code,
                         "expectedResponseCount": len(requests), "actualResponseCount": len(responses), "stderr": stderr}
    elif not define_response.get("ok", False):
        setup_failure = {"stage": "observer-define", "response": define_response}
    elif "subscription.preview-replacement" in defined_names:
        setup_failure = {"stage": "observer-define", "message": "Observer unexpectedly redeclared the target"}
    elif defined_names != ["preview-retention.scoring-observe"]:
        setup_failure = {"stage": "observer-define", "message": "Expected exactly the private observer function"}

    case_results = []
    if setup_failure is None:
        case_results = [score_response(item, response) for item, response in zip(cases, responses[1:])]
    executed = sum(row.get("executed", False) for row in case_results)
    failing = [row["caseId"] for row in case_results if row.get("executed") and not row.get("passed")]
    setup_errors = [row for row in case_results if not row.get("executed")]
    copied_fingerprint = project_fingerprint(project)
    actor_fingerprint_after = project_fingerprint(actor_project)
    if copied_fingerprint != initial_fingerprint or actor_fingerprint_after != initial_fingerprint:
        setup_failure = setup_failure or {"stage": "persistent-project-changed"}
    if exit_code != 0:
        setup_failure = setup_failure or {"stage": "cli-exit", "exitCode": exit_code, "stderr": stderr}

    report = {
        "status": "passed" if setup_failure is None and executed == len(cases) and not failing else "actor-score-failure",
        "mode": "wrapper-only preview actor score", "arm": arm, "label": label, "cliExitCode": exit_code,
        "runtime": str(cli.relative_to(REPO)), "runtimeSha256": hashlib.sha256(cli.read_bytes()).hexdigest(),
        "actorProject": str(actor_project.relative_to(REPO)), "targetIdentity": initial_identity,
        "copiedScoringProject": str(project.relative_to(REPO)),
        "caseSource": str((ORACLE / "cases.json").relative_to(REPO)),
        "caseCount": len(cases), "fixturePopulations": OLD.case_fixture_populations(cases),
        "executedCaseCount": executed, "passedCaseCount": executed - len(failing),
        "failingCaseIds": failing, "setupErrorCount": len(setup_errors),
        "definedWordNames": defined_names, "setupFailure": setup_failure,
        "participantQualification": "Assessed separately from this independent behavior score.",
        "caseResults": case_results,
    }
    (run_dir / "score.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--actor-project", type=Path, required=True)
    parser.add_argument("--arm", choices=("retained", "reset-abstraction", "control"), required=True)
    parser.add_argument("--cli", type=Path, default=DEFAULT_CLI)
    parser.add_argument("--label", type=validate_label, help="One-component evidence label; defaults to the arm")
    args = parser.parse_args()
    report = score_actor(args.actor_project, args.cli, args.arm, args.label or args.arm)
    print(json.dumps({key: value for key, value in report.items() if key != "caseResults"}, indent=2, ensure_ascii=False))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())

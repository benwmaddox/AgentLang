"""Extract descriptive protocol and own-coverage facts; no model-token estimates."""
from pathlib import Path
import collections
import json

REPO = Path(__file__).resolve().parents[2]
ROOT = REPO / '.agentlang/pr171'
TARGET = 'subscription.preview-replacement'
facts = {}
for arm in ['reset', 'retained']:
    rows = [json.loads(line) for line in (ROOT / f'trace-{arm}.jsonl').read_text(encoding='utf-8').splitlines()]
    exchanges = [r for r in rows if r['event'] == 'exchange']
    errors, target_tests, commits, all_tests = [], [], [], []
    for row in exchanges:
        request = json.loads(row['request']['rawLine'])
        response = json.loads(row['response']['rawLine'])
        if not response.get('ok'):
            errors.append(dict(operation=request['op'], code=response.get('error', {}).get('code')))
        if request['op'] == 'test' and request.get('word') == TARGET:
            target_tests.append(response)
        if request['op'] == 'task.commit':
            commits.append(response)
        if request['op'] == 'test-all':
            results = response.get('data', {}).get('results', [])
            all_tests.append(dict(passed=bool(response.get('ok') and all(r['passed'] for r in results)), count=len(results)))
    if not target_tests or not target_tests[-1]['ok'] or not commits or not commits[-1]['ok']:
        raise RuntimeError(f'{arm}: target qualification/task completion is not evidenced.')
    coverage = target_tests[-1]['data']['coverage']
    end = next(r for r in reversed(rows) if r['event'] == 'session-end')
    if end['terminationKind'] != 'host-close' or end['hostExitCode'] != 0 or end['runtimeExitCode'] != 0:
        raise RuntimeError(f'{arm}: clean terminal broker close required.')
    audit = json.loads((ROOT / f'audit-{arm}.json').read_text())
    score_files = sorted((ROOT / 'out' / f'actor-{arm}').rglob('score.json'))
    if len(score_files) != 1:
        raise RuntimeError(f'{arm}: expected exactly one independent actor score.')
    score = json.loads(score_files[0].read_text())
    if score['status'] != 'passed' or score['executedCaseCount'] != 33 or score['setupErrorCount']:
        raise RuntimeError(f'{arm}: all independent cases must execute and pass.')
    facts[arm] = dict(independentCases=score['executedCaseCount'], independentPassed=score['passedCaseCount'],
                      protocolExchanges=len(exchanges), operations=dict(collections.Counter(r['operation'] for r in exchanges)),
                      requestPayloadBytes=sum(r['request']['payloadUtf8Bytes'] for r in exchanges),
                      responsePayloadBytes=sum(r['response']['payloadUtf8Bytes'] for r in exchanges),
                      requestErrors=errors, targetTests=len(target_tests[-1]['data']['results']),
                      targetInstructions=[coverage['instructionsCovered'], coverage['instructionsTotal']],
                      targetBranches=[coverage['branchesCovered'], coverage['branchesTotal']],
                      finiteCoverage=coverage['finiteCoverage'], regressionBatches=all_tests,
                      preservationPassed=audit['preservationPassed'], reusedRetainedHandoff=audit['reusedRetainedHandoff'],
                      reconstructedHandoff=audit['reconstructedHandoff'], cleanHostClose=True)
(ROOT / 'facts.json').write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8')
print(json.dumps(facts, indent=2))

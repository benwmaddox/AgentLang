import hashlib, json, zipfile
from pathlib import Path

repo = Path.cwd().resolve()
local = repo / '.agentlang/native-refined-string-174'
native = repo / '.agentlang/owning-stack-003/verification-b03d4a58ce82417c82bf2da73087a560'
mailbox = repo / '.agentlang/owning-mailbox-001/integration-run-3b8eb4c2c2f244ec9bb4de1658cc9a95'
llvm = repo / '.agentlang/native-validation/tests-5924239b53034c4cb11e581b42a1e8c9'
out = repo / 'reports/evidence/174-native-refined-string'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
nr = load(native / 'verification-evidence.json')
mr = load(mailbox / 'integration-evidence.json')
fr = load(local / 'full-validation-001.json')
assert nr['passed'] and nr['sourceInputsStable'] and mr['passed'] and fr['passed']
assert load(local / 'full-llvm-002-exit.json')['exitCode'] == 0
assert load(local / 'native-gate-004-exit.json')['exitCode'] == 0
assert load(local / 'mailbox-gate-001-exit.json')['exitCode'] == 0
assert load(local / 'full-validation-001-exit.json')['exitCode'] == 0
pins = nr['sourceInputHashesBefore'] + mr['sourceInputHashes']['before']
files = set()
for row in pins:
    p = Path(row['path']).resolve()
    assert p.is_relative_to(repo), p
    assert sha(p.read_bytes()) == row['sha256'], p
    files.add(p)
# Completed gates and failed attempts; no build trees, binaries or environment dumps.
allowed = {'.json', '.jsonl', '.txt', '.log', '.md', '.flow'}
def top_and_logs(root):
    for p in root.iterdir():
        if p.is_file() and p.suffix in allowed: files.add(p.resolve())
    for name in ('logs',):
        d = root / name
        if d.exists():
            files.update(p.resolve() for p in d.rglob('*') if p.is_file() and p.suffix in allowed)
top_and_logs(local)
for root in (native, mailbox,
             repo / '.agentlang/owning-stack-003/verification-89122a0883d24303a4ed049e793cab00',
             repo / '.agentlang/owning-stack-003/verification-872df1a1f33241e58fe1310d5d27e728',
             repo / '.agentlang/owning-stack-003/verification-70cd395a804c4ea0a4fe18b0a77cb61c'):
    top_and_logs(root)
# Keep exact generated new-slice LLVM IR without unrelated duplicate artifacts.
files.update(p.resolve() for p in (native / 'native-output/owning-stack/refined-string').rglob('*.ll'))
for d in llvm.iterdir():
    if d.is_dir() and d.name.startswith('owning-refined-string-'):
        files.update(p.resolve() for p in d.rglob('*.ll'))
files.add(Path(__file__).resolve())
assert not out.exists(), 'Refuse overwrite'
out.mkdir(parents=True)
rows = []
with zipfile.ZipFile(out / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        assert p.is_relative_to(repo) and p.is_file(), p
        data = p.read_bytes(); rel = p.relative_to(repo).as_posix()
        z.writestr(rel, data)
        rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(out / 'evidence.zip') as z:
    assert z.testzip() is None
    assert len(z.infolist()) == len(rows)
    for row in rows:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
index = {'status':'verified',
         'description':'Completed accepted gates, failed attempts, final source pins and selected new-slice generated IR; build trees, binaries and environment dumps excluded.',
         'archive':{'path':'evidence.zip','bytes':(out/'evidence.zip').stat().st_size,'sha256':sha((out/'evidence.zip').read_bytes())},
         'accepted':{'llvmAssertions':645,'nativeChecks':len(nr['checks']),'nativeSourcePins':len(nr['sourceInputHashesBefore']),
                     'mailboxChecks':len(mr['checks']),'mailboxSourcePins':len(mr['sourceInputHashes']['before']),
                     'fullLocalChecks':len(fr['checks'])},
         'files':rows}
(out / 'archive.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in index.items() if k!='files'}))

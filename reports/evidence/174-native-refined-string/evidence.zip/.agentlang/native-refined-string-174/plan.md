# Owning refined String plan

Status: feasible as a bounded OwningStackAot extension; no storage or ABI prerequisite found.

## Scope

Add only a validated `IrString` scalar refinement, using `NonEmptyString` as the example, to the ordinary single-entry owning backend. Keep it bound to the validator call and revision frozen in the same verified IR. Preserve `makeProgramInfoForBodies false` as the mailbox gate: refined mailbox layouts stay unsupported. Leave unvalidated String wrappers, other base types, JIT, .NET execution fallback, compaction, and a general refinement framework out of scope.

The owning backend already supports pure `string.concat(String, String) -> String`, `string.length(String) -> Int` (UTF-16 code units), and generic `equals(T, T) -> Bool` when both types match. Generic `dup`, `drop`, and `swap` also accept String. Calls are already required to be effect-free. There is no broader String operation set in this backend.

## Required implementation points

In `src/AgentLang.Llvm/OwningStackAot.fs`, extend the existing validated-scalar path only for `BaseType = IrString` with a validator, and only when ordinary compilation enables validated scalars. Keep Int behavior intact and keep the mailbox compilation mode rejecting the new type.

The current Int-only stops are `validateScalarValidator` and `validateScalarCall` (signatures and generated `WrapScalar`/`UnwrapScalar` targets are fixed to Int); the scalar branch of `buildType`; `measureValue`, `encodeValues`, and `decodeValues` (they admit/rebuild only named Int values); `emitFrozenValidatorCall` (it retags the validator argument as Int); and `typeKind`/the layout manifest (all scalars are reported as Int, and descriptor emission throws for non-Int scalars). Use the scalar's base type at each point. A String-backed nominal needs a dynamic String layout: nominal name and TypeId, String kind 5, minimum payload/extent 8, and variable payload/extent. Host Values must be exact `NamedValue(typeName, StringValue text)` shapes; output decoding must restore the nominal name.

The native runtime already accepts String kind 5 and measures, copies, and scans the existing UTF-16 String layout. No C runtime or descriptor-layout change is indicated. The owning String representation is an eight-byte header (UTF-16 code-unit count plus zero reserved word), UTF-16LE data, and zero padding to an eight-byte extent.

For construction and raw entry admission, pass the same descriptor to the frozen `String -> Bool` user function with its type retagged to `IrString`; do not copy the payload for validation, wrap, or unwrap. Preserve offset, extent, payload size, and `OwnerEnd`. The existing `emitValidateEntryValue` recursion already checks record fields and only active Option/Result payloads; it should recognize the new scalar through the validated-scalar map. Keep its false-result `REFINEMENT_FAILED`, validator execution errors, depth/fuel behavior, and validator-only dependency discovery. Raw host bytes still need the ordinary one-time copy into the execution arena. Retained publication remains the existing output copy. Do not change `ArenaLifetime`'s conservative treatment or introduce rewinds/compaction.

## Independent conformance and boundaries

Add a focused `testOwningRefinedStringSlice` in `tests/AgentLang.Llvm.Tests/Program.fs`, then add a separate refined-String matrix to `experiments/AgentLang.NativeValueStack/Program.fs`, its oracle in `tests/fixtures/native-conformance/native-value-stack.json`, and exact inventory checks/source pins in `scripts/Verify-NativeValueStack.ps1`. Keep the runner's existing older `LlvmAot` String limitation distinct from this owning-only slice. Include this plan in the verifier's source-hash inputs.

The minimum O0/O2 cases should independently establish:

- `NonEmptyString("ok")` keeps a distinct nominal TypeId and String kind, round-trips by exact nominal host identity, and matches the existing UTF-16 bytes `02000000000000006f006b0000000000` (payload 12, extent 16). Empty construction fails with `REFINEMENT_FAILED` and leaves caller output unchanged.
- Exact host admission rejects bare `StringValue` and a different nominal. Invalid raw host input is rejected by the native entry before the body runs; include at least one call through the exported owning entry with fixture bytes/extents so the check is independent of the .NET Value encoder.
- A record field and active `Option<NonEmptyString>` / `Result` payloads validate recursively; `None` and the alternative without the refined value do not invoke its validator. Invalid active nested values fail atomically.
- A validator-only dependency and same-name validator replacement retain the frozen verified target/revision. A validator runtime failure keeps its runtime error classification.
- Wrap/unwrap and field projection preserve `OwnerEnd` and add no deep-copy/move bytes. Check a refined String field before a trailing String, then project/unwrap it. The existing measured owner-range trace is the oracle shape; no new ownership rule is needed.
- Unvalidated String wrappers, Bool/Float refinements, and refined String mailbox layouts still reject explicitly.

## ABI and validation

Keep layout schema 3, stack ABI 1, module ABI 1, descriptor sizes, and offsets unchanged. String kind 5 and the dynamic header already exist. Audit deterministic type IDs: nominal IDs are ordered from 4 by `ProgramTypeKey`, and String receives the next ID after all nominals, so adding the nominal shifts the program-local String ID. Pin the nominal/String IDs, kind, payload/extent, exact bytes, and recursive fixture layout in the independent oracle; do not carry over unrelated hard-coded IDs.

After implementation, run `dotnet run --configuration Release --project tests/AgentLang.Llvm.Tests/AgentLang.Llvm.Tests.fsproj`, `pwsh -NoProfile -File scripts/Verify-NativeValueStack.ps1`, `pwsh -NoProfile -File scripts/Verify-OwningMailbox.ps1 -SerialBuild`, and `pwsh -NoProfile -File scripts/Validate.ps1 -Configuration Release -SerialBuild -SkipPackageAudit`. No builds or tests were run during this planning pass.

# Refined String conformance oracle notes

This ignored working note records how the independent native-value-stack fixture was derived. The durable acceptance scope belongs in docs/NATIVE-NOMINALS-IMPLEMENTATION.md; the ignored planning note is deliberately not hashed by the verifier.

## Type identities

The ordinary identity program has one nominal type, NonEmptyString, so its nominal TypeId is 4 and String follows at 5. The nested program sorts its nominal types by ProgramTypeKey: NonEmptyString is 4, RefinedEnvelope is 5, and String follows at 6. Both scalar and base String descriptors use kind 5. String-backed values have an eight-byte minimum payload and extent.

## UTF-16 bytes

Every string starts with a little-endian 32-bit UTF-16 code-unit count and a four-byte zero reserved word. The code units are UTF-16LE, then zero padding extends the value to an eight-byte boundary.

- "ok": count 2, code units 6f00 6b00; payload 12, extent 16, bytes 02000000000000006f006b0000000000.
- Empty string: count 0 and no code units; payload/extent 8, bytes 0000000000000000.
- "A😀": UTF-16 count 3 (A, high surrogate D83D, low surrogate DE00); bytes 030000000000000041003dd800de0000.
- "A\u0000B": UTF-16 count 3 and code units 0041 0000 0042; bytes 03000000000000004100000042000000.

## Nested values

RefinedEnvelope { owner: NonEmptyString("ok"); tail: String("z") } is the concatenation of two independently eight-byte-aligned strings. The first string occupies extent 16; the second also occupies extent 16. Logical payload bytes are 12 + 10 = 22, physical extent is 32, and the first-field projection retains outer OwnerEnd 32 while the source String extent is 16.

Option and Result use an eight-byte tag followed by the active payload. Some/Ok/Error("ok") therefore has extent 24. None is only its tag. Ok<Int(7)> is tag 0 plus little-endian Int 7: 00000000000000000700000000000000. The latter leaves the inactive NonEmptyString alternative unobserved.

## OwnerEnd provenance

The checked entry projects `owner: NonEmptyString`, unwraps it to the nested program's base String (TypeId 6), and only then allocates/drops a later String. The final descriptor-transfer oracle therefore pins TypeId 6 at output offset 0, source payload extent 16, and source OwnerEnd 32. NonEmptyString TypeId 4 is pinned independently by the type-identity fixtures; it is the pre-unwrap nominal value, not the final transfer asserted after the later allocation.

## Raw failure sentinel

The raw-entry fixture uses an eight-byte empty String as invalid input and the valid "ok" bytes as the control that reaches a deliberate divide-by-zero body failure. Both invocations are expected to return diagnostic status 1 and leave the full 32-byte caller-retained buffer (a5 repeated) untouched. Distinct nonzero ErrorIds demonstrate that invalid input fails at preflight before the body error.

## Exact O0/O2 check suffixes

The verifier requires exactly these 29 refined-string/{O0,O2}/... checks, with one passing occurrence per optimization and no additional family checks:

1. type-identities-and-string-layout
2. constructor-success-and-utf16-bytes
3. constructor-reject-empty-parity-atomically
4. host-identity-input-only-validator-closure
5. host-identity-utf16-supplementary-roundtrip
6. host-identity-utf16-embedded-nul-roundtrip
7. base-string-type-id-and-kind-remain-distinct
8. host-shape-rejects-bare-string-atomically
9. host-shape-rejects-wrong-nominal-atomically
10. raw-empty-entry-preflight-before-body
11. recursive-record-layout-type-ids-and-dynamic-fields
12. record-field-validates-recursively
13. record-field-empty-rejected-atomically
14. option-some-validates-active-payload
15. option-some-empty-rejected-atomically
16. option-none-skips-inactive-validator
17. result-ok-validates-active-payload
18. result-ok-empty-rejected-atomically
19. result-error-validates-active-payload
20. result-error-empty-rejected-atomically
21. result-inactive-alternative-skips-validator
22. validator-only-dependency-freezes-target-after-same-name-replacement
23. validator-runtime-failure-preserves-classification
24. refined-field-owner-end-project-unwrap-no-extra-copy
25. owner-range-trace-complete
26. unsupported-UnvalidatedStringTag-is-explicit
27. unsupported-BoolTag-is-explicit
28. unsupported-FloatTag-is-explicit
29. unsupported-refined-string-mailbox-layout-is-explicit

No build or test command was run by this conformance subtask; the parent serializes repository builds and will run the verifier after implementation tests complete.

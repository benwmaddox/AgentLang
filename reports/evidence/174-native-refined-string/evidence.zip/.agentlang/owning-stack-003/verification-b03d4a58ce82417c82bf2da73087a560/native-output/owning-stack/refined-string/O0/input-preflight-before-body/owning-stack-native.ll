%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 4
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 4, 4
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %stack.offset.48 = add i32 %context.value.47, 8
  %reserve.status.49 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.48, i32 2)
  %reserve.ok.50 = icmp eq i32 %reserve.status.49, 0
  br i1 %reserve.ok.50, label %reserve.continue.51, label %frame.failure.0
reserve.continue.51:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.47, i64 1, i32 1)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %stack.sub.64 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.62 = icmp ule i32 %descriptor.value.23, %context.value.61
  %descriptor.offset.inside.63 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.65 = icmp ule i32 %descriptor.value.19, %stack.sub.64
  %descriptor.payload.inside.66 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.67 = and i1 %descriptor.owner.inside.62, %descriptor.offset.inside.63
  %descriptor.range.inside.69 = and i1 %descriptor.owner.offset.valid.67, %descriptor.extent.inside.65
  %descriptor.range.valid.68 = and i1 %descriptor.range.inside.69, %descriptor.payload.inside.66
  %descriptor.type.valid.70 = icmp eq i32 4, 4
  %descriptor.valid.71 = and i1 %descriptor.range.valid.68, %descriptor.type.valid.70
  br i1 %descriptor.valid.71, label %descriptor.valid.72, label %descriptor.invalid.73
descriptor.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.72:
  %descriptor.initialized.status.74 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.75 = icmp eq i32 %descriptor.initialized.status.74, 0
  br i1 %helper.ok.75, label %helper.continue.76, label %frame.failure.0
helper.continue.76:
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %stack.sub.81 = sub i32 %stack.offset.48, %context.value.47
  %descriptor.owner.inside.79 = icmp ule i32 %stack.offset.48, %context.value.78
  %descriptor.offset.inside.80 = icmp ule i32 %context.value.47, %stack.offset.48
  %descriptor.extent.inside.82 = icmp ule i32 8, %stack.sub.81
  %descriptor.payload.inside.83 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.84 = and i1 %descriptor.owner.inside.79, %descriptor.offset.inside.80
  %descriptor.range.inside.86 = and i1 %descriptor.owner.offset.valid.84, %descriptor.extent.inside.82
  %descriptor.range.valid.85 = and i1 %descriptor.range.inside.86, %descriptor.payload.inside.83
  %descriptor.type.valid.87 = icmp eq i32 1, 1
  %descriptor.valid.88 = and i1 %descriptor.range.valid.85, %descriptor.type.valid.87
  br i1 %descriptor.valid.88, label %descriptor.valid.89, label %descriptor.invalid.90
descriptor.invalid.90:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.89:
  %descriptor.initialized.status.91 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.47, i32 8)
  %helper.ok.92 = icmp eq i32 %descriptor.initialized.status.91, 0
  br i1 %helper.ok.92, label %helper.continue.93, label %frame.failure.0
helper.continue.93:
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %helper.ok.95, label %helper.continue.96, label %frame.failure.0
helper.continue.96:
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.offset.99 = add i32 %context.value.98, 8
  %reserve.status.100 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.99, i32 4)
  %reserve.ok.101 = icmp eq i32 %reserve.status.100, 0
  br i1 %reserve.ok.101, label %reserve.continue.102, label %frame.failure.0
reserve.continue.102:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.98, i64 0, i32 1)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %runtime.ok.109 = icmp eq i32 %context.value.108, 0
  br i1 %runtime.ok.109, label %runtime.continue.110, label %frame.failure.0
runtime.continue.110:
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %stack.sub.115 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.113 = icmp ule i32 %descriptor.value.23, %context.value.112
  %descriptor.offset.inside.114 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.116 = icmp ule i32 %descriptor.value.19, %stack.sub.115
  %descriptor.payload.inside.117 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.118 = and i1 %descriptor.owner.inside.113, %descriptor.offset.inside.114
  %descriptor.range.inside.120 = and i1 %descriptor.owner.offset.valid.118, %descriptor.extent.inside.116
  %descriptor.range.valid.119 = and i1 %descriptor.range.inside.120, %descriptor.payload.inside.117
  %descriptor.type.valid.121 = icmp eq i32 4, 4
  %descriptor.valid.122 = and i1 %descriptor.range.valid.119, %descriptor.type.valid.121
  br i1 %descriptor.valid.122, label %descriptor.valid.123, label %descriptor.invalid.124
descriptor.invalid.124:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.123:
  %descriptor.initialized.status.125 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.126 = icmp eq i32 %descriptor.initialized.status.125, 0
  br i1 %helper.ok.126, label %helper.continue.127, label %frame.failure.0
helper.continue.127:
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %stack.sub.132 = sub i32 %stack.offset.48, %context.value.47
  %descriptor.owner.inside.130 = icmp ule i32 %stack.offset.48, %context.value.129
  %descriptor.offset.inside.131 = icmp ule i32 %context.value.47, %stack.offset.48
  %descriptor.extent.inside.133 = icmp ule i32 8, %stack.sub.132
  %descriptor.payload.inside.134 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.135 = and i1 %descriptor.owner.inside.130, %descriptor.offset.inside.131
  %descriptor.range.inside.137 = and i1 %descriptor.owner.offset.valid.135, %descriptor.extent.inside.133
  %descriptor.range.valid.136 = and i1 %descriptor.range.inside.137, %descriptor.payload.inside.134
  %descriptor.type.valid.138 = icmp eq i32 1, 1
  %descriptor.valid.139 = and i1 %descriptor.range.valid.136, %descriptor.type.valid.138
  br i1 %descriptor.valid.139, label %descriptor.valid.140, label %descriptor.invalid.141
descriptor.invalid.141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.140:
  %descriptor.initialized.status.142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.47, i32 8)
  %helper.ok.143 = icmp eq i32 %descriptor.initialized.status.142, 0
  br i1 %helper.ok.143, label %helper.continue.144, label %frame.failure.0
helper.continue.144:
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %stack.sub.149 = sub i32 %stack.offset.99, %context.value.98
  %descriptor.owner.inside.147 = icmp ule i32 %stack.offset.99, %context.value.146
  %descriptor.offset.inside.148 = icmp ule i32 %context.value.98, %stack.offset.99
  %descriptor.extent.inside.150 = icmp ule i32 8, %stack.sub.149
  %descriptor.payload.inside.151 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.152 = and i1 %descriptor.owner.inside.147, %descriptor.offset.inside.148
  %descriptor.range.inside.154 = and i1 %descriptor.owner.offset.valid.152, %descriptor.extent.inside.150
  %descriptor.range.valid.153 = and i1 %descriptor.range.inside.154, %descriptor.payload.inside.151
  %descriptor.type.valid.155 = icmp eq i32 1, 1
  %descriptor.valid.156 = and i1 %descriptor.range.valid.153, %descriptor.type.valid.155
  br i1 %descriptor.valid.156, label %descriptor.valid.157, label %descriptor.invalid.158
descriptor.invalid.158:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.157:
  %descriptor.initialized.status.159 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.98, i32 8)
  %helper.ok.160 = icmp eq i32 %descriptor.initialized.status.159, 0
  br i1 %helper.ok.160, label %helper.continue.161, label %frame.failure.0
helper.continue.161:
  %step.status.162 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.163 = icmp eq i32 %step.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %inline.target.depth.within.interpreter.limit.167 = icmp ule i32 %context.value.166, 65
  br i1 %inline.target.depth.within.interpreter.limit.167, label %inline.target.depth.ok.168, label %inline.target.depth.invalid.169
inline.target.depth.invalid.169:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 6, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.168:
  %integer.left.170 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.47)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %frame.failure.0
runtime.continue.175:
  %integer.right.171 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.98)
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %runtime.ok.178 = icmp eq i32 %context.value.177, 0
  br i1 %runtime.ok.178, label %runtime.continue.179, label %frame.failure.0
runtime.continue.179:
  %divide.zero.180 = icmp eq i64 %integer.right.171, 0
  br i1 %divide.zero.180, label %divide.zero.181, label %divide.nonzero.182
divide.zero.181:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.182:
  %divide.min.183 = icmp eq i64 %integer.left.170, -9223372036854775808
  %divide.minusone.184 = icmp eq i64 %integer.right.171, -1
  %divide.overflow.185 = and i1 %divide.min.183, %divide.minusone.184
  br i1 %divide.overflow.185, label %divide.overflow.186, label %divide.valid.187
divide.overflow.186:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.187:
  %divide.result.188 = sdiv i64 %integer.left.170, %integer.right.171
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.98, i32 8, i32 8, i32 0, i32 0)
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %runtime.ok.191 = icmp eq i32 %context.value.190, 0
  br i1 %runtime.ok.191, label %runtime.continue.192, label %frame.failure.0
runtime.continue.192:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.47, i32 8, i32 8, i32 0, i32 0)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %frame.failure.0
runtime.continue.196:
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %stack.offset.199 = add i32 %context.value.198, 8
  %reserve.status.200 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.199, i32 9)
  %reserve.ok.201 = icmp eq i32 %reserve.status.200, 0
  br i1 %reserve.ok.201, label %reserve.continue.202, label %frame.failure.0
reserve.continue.202:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.198, i64 %divide.result.188, i32 1)
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %runtime.ok.205 = icmp eq i32 %context.value.204, 0
  br i1 %runtime.ok.205, label %runtime.continue.206, label %frame.failure.0
runtime.continue.206:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  %stack.offset.211 = add i32 %context.value.198, 8
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %stack.sub.216 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.214 = icmp ule i32 %descriptor.value.23, %context.value.213
  %descriptor.offset.inside.215 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.217 = icmp ule i32 %descriptor.value.19, %stack.sub.216
  %descriptor.payload.inside.218 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.219 = and i1 %descriptor.owner.inside.214, %descriptor.offset.inside.215
  %descriptor.range.inside.221 = and i1 %descriptor.owner.offset.valid.219, %descriptor.extent.inside.217
  %descriptor.range.valid.220 = and i1 %descriptor.range.inside.221, %descriptor.payload.inside.218
  %descriptor.type.valid.222 = icmp eq i32 4, 4
  %descriptor.valid.223 = and i1 %descriptor.range.valid.220, %descriptor.type.valid.222
  br i1 %descriptor.valid.223, label %descriptor.valid.224, label %descriptor.invalid.225
descriptor.invalid.225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.224:
  %descriptor.initialized.status.226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.227 = icmp eq i32 %descriptor.initialized.status.226, 0
  br i1 %helper.ok.227, label %helper.continue.228, label %frame.failure.0
helper.continue.228:
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %stack.sub.233 = sub i32 %stack.offset.211, %context.value.198
  %descriptor.owner.inside.231 = icmp ule i32 %stack.offset.211, %context.value.230
  %descriptor.offset.inside.232 = icmp ule i32 %context.value.198, %stack.offset.211
  %descriptor.extent.inside.234 = icmp ule i32 8, %stack.sub.233
  %descriptor.payload.inside.235 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.236 = and i1 %descriptor.owner.inside.231, %descriptor.offset.inside.232
  %descriptor.range.inside.238 = and i1 %descriptor.owner.offset.valid.236, %descriptor.extent.inside.234
  %descriptor.range.valid.237 = and i1 %descriptor.range.inside.238, %descriptor.payload.inside.235
  %descriptor.type.valid.239 = icmp eq i32 1, 1
  %descriptor.valid.240 = and i1 %descriptor.range.valid.237, %descriptor.type.valid.239
  br i1 %descriptor.valid.240, label %descriptor.valid.241, label %descriptor.invalid.242
descriptor.invalid.242:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.241:
  %descriptor.initialized.status.243 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.198, i32 8)
  %helper.ok.244 = icmp eq i32 %descriptor.initialized.status.243, 0
  br i1 %helper.ok.244, label %helper.continue.245, label %frame.failure.0
helper.continue.245:
  %step.status.246 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.247 = icmp eq i32 %step.status.246, 0
  br i1 %helper.ok.247, label %helper.continue.248, label %frame.failure.0
helper.continue.248:
  %context.field.249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.250 = load i32, ptr %context.field.249, align 4
  %inline.target.depth.within.interpreter.limit.251 = icmp ule i32 %context.value.250, 65
  br i1 %inline.target.depth.within.interpreter.limit.251, label %inline.target.depth.ok.252, label %inline.target.depth.invalid.253
inline.target.depth.invalid.253:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 11, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.252:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.198, i32 8, i32 8, i32 0, i32 0)
  %context.field.254 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.255 = load i32, ptr %context.field.254, align 4
  %runtime.ok.256 = icmp eq i32 %context.value.255, 0
  br i1 %runtime.ok.256, label %runtime.continue.257, label %frame.failure.0
runtime.continue.257:
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %stack.sub.262 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.260 = icmp ule i32 %descriptor.value.23, %context.value.259
  %descriptor.offset.inside.261 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.263 = icmp ule i32 %descriptor.value.19, %stack.sub.262
  %descriptor.payload.inside.264 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.265 = and i1 %descriptor.owner.inside.260, %descriptor.offset.inside.261
  %descriptor.range.inside.267 = and i1 %descriptor.owner.offset.valid.265, %descriptor.extent.inside.263
  %descriptor.range.valid.266 = and i1 %descriptor.range.inside.267, %descriptor.payload.inside.264
  %descriptor.type.valid.268 = icmp eq i32 4, 4
  %descriptor.valid.269 = and i1 %descriptor.range.valid.266, %descriptor.type.valid.268
  br i1 %descriptor.valid.269, label %descriptor.valid.270, label %descriptor.invalid.271
descriptor.invalid.271:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.270:
  %descriptor.initialized.status.272 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.273 = icmp eq i32 %descriptor.initialized.status.272, 0
  br i1 %helper.ok.273, label %helper.continue.274, label %frame.failure.0
helper.continue.274:
  %context.field.275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.276 = load i32, ptr %context.field.275, align 4
  %stack.sub.277 = sub i32 %context.value.276, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.277, i32 0, i32 0, i32 0)
  %context.field.278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.279 = load i32, ptr %context.field.278, align 4
  %runtime.ok.280 = icmp eq i32 %context.value.279, 0
  br i1 %runtime.ok.280, label %runtime.continue.281, label %frame.failure.0
runtime.continue.281:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %descriptor.element.286 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.287 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.286, i32 0, i32 0
  store i32 4, ptr %descriptor.field.287, align 4
  %descriptor.field.288 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.286, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.288, align 4
  %descriptor.field.289 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.286, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.289, align 4
  %descriptor.field.290 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.286, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.290, align 4
  %descriptor.field.291 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.286, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.291, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %context.field.298 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.299 = load i32, ptr %context.field.298, align 4
  %context.field.300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.301 = load i32, ptr %context.field.300, align 4
  %stack.offset.302 = add i32 %context.value.5, %context.value.7
  %stack.offset.303 = add i32 %context.value.297, %context.value.299
  %stack.sub.304 = sub i32 %stack.offset.302, %stack.offset.303
  %stack.sub.305 = sub i32 %context.value.7, %context.value.299
  %stack.sub.306 = sub i32 %context.value.301, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.304, i32 %stack.sub.305)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.306)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 14, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 15)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 17)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 19, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 20)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 21, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.total.exact.37 = icmp eq i32 %stack.offset.36, %input.bytes
  br i1 %input.total.exact.37, label %input.valid.38, label %input.invalid.39
input.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.36, i32 %input.bytes)
  br label %entry.failure.0
input.valid.38:
  %reserve.status.40 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.36, i32 22)
  %reserve.ok.41 = icmp eq i32 %reserve.status.40, 0
  br i1 %reserve.ok.41, label %reserve.continue.42, label %entry.failure.0
reserve.continue.42:
  %host.pointer.43 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.44 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.43, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 4, i32 23)
  %helper.ok.45 = icmp eq i32 %input.copy.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %stack.offset.47 = add i32 0, %input.host.extent.18
  %descriptor.element.48 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 0
  store i32 4, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 1
  store i32 0, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 4
  store i32 %stack.offset.47, ptr %descriptor.field.53, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.47, i32 %input.host.extent.18)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %entry.failure.0
runtime.continue.57:
  %entry.validation.frame.entered.58 = call i32 @al_owning_enter_frame(ptr %ctx, i32 24)
  %helper.ok.59 = icmp eq i32 %entry.validation.frame.entered.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %stack.offset.61 = add i32 0, %input.host.extent.18
  %validator.arguments.62 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.63 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.62, i32 0
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 0
  store i32 5, ptr %descriptor.field.64, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 1
  store i32 0, ptr %descriptor.field.65, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 4
  store i32 %stack.offset.61, ptr %descriptor.field.68, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.61, i32 %input.host.extent.18)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %entry.validation.failure.3
runtime.continue.72:
  %validator.results.73 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.74 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.62, ptr %validator.results.73, i32 27)
  %helper.ok.75 = icmp eq i32 %validator.status.74, 0
  br i1 %helper.ok.75, label %helper.continue.76, label %entry.validation.failure.3
helper.continue.76:
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.73, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %validator.result.type.matches.88 = icmp eq i32 %descriptor.value.79, 2
  br i1 %validator.result.type.matches.88, label %validator.result.type.ok.89, label %validator.result.type.invalid.90
validator.result.type.invalid.90:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 26, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.89:
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.sub.95 = sub i32 %descriptor.value.87, %descriptor.value.81
  %descriptor.owner.inside.93 = icmp ule i32 %descriptor.value.87, %context.value.92
  %descriptor.offset.inside.94 = icmp ule i32 %descriptor.value.81, %descriptor.value.87
  %descriptor.extent.inside.96 = icmp ule i32 %descriptor.value.83, %stack.sub.95
  %descriptor.payload.inside.97 = icmp ule i32 %descriptor.value.85, %descriptor.value.83
  %descriptor.owner.offset.valid.98 = and i1 %descriptor.owner.inside.93, %descriptor.offset.inside.94
  %descriptor.range.inside.100 = and i1 %descriptor.owner.offset.valid.98, %descriptor.extent.inside.96
  %descriptor.range.valid.99 = and i1 %descriptor.range.inside.100, %descriptor.payload.inside.97
  %descriptor.type.valid.101 = icmp eq i32 2, 2
  %descriptor.valid.102 = and i1 %descriptor.range.valid.99, %descriptor.type.valid.101
  br i1 %descriptor.valid.102, label %descriptor.valid.103, label %descriptor.invalid.104
descriptor.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.103:
  %descriptor.initialized.status.105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.81, i32 %descriptor.value.83)
  %helper.ok.106 = icmp eq i32 %descriptor.initialized.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %entry.validation.failure.3
helper.continue.107:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.81, i32 20, i32 %descriptor.value.85, i32 %descriptor.value.87, i32 %descriptor.value.83)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %entry.validation.failure.3
runtime.continue.111:
  %validator.bool.112 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.81)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.validation.failure.3
runtime.continue.116:
  %validator.bool.true.117 = icmp eq i64 %validator.bool.112, 1
  %validator.bool.false.118 = icmp eq i64 %validator.bool.112, 0
  %validator.bool.valid.119 = or i1 %validator.bool.true.117, %validator.bool.false.118
  br i1 %validator.bool.valid.119, label %validator.bool.check.120, label %validator.bool.invalid.121
validator.bool.invalid.121:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 26, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.120:
  br i1 %validator.bool.true.117, label %validator.true.123, label %validator.false.122
validator.false.122:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.123:
  br label %validator.join.124
validator.join.124:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.125
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.125:
  %entry.output.descriptors.126 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.127 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.126, i32 28)
  %entry.body.ok.128 = icmp eq i32 %entry.body.status.127, 0
  br i1 %entry.body.ok.128, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.129 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.126, i32 0
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 0
  %descriptor.value.131 = load i32, ptr %descriptor.field.130, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 1
  %descriptor.value.133 = load i32, ptr %descriptor.field.132, align 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 2
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 3
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 4
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %entry.output.type.valid.140 = icmp eq i32 %descriptor.value.131, 4
  br i1 %entry.output.type.valid.140, label %entry.output.type.ok.141, label %entry.output.type.invalid.142
entry.output.type.invalid.142:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.141:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %stack.sub.147 = sub i32 %descriptor.value.139, %descriptor.value.133
  %descriptor.owner.inside.145 = icmp ule i32 %descriptor.value.139, %context.value.144
  %descriptor.offset.inside.146 = icmp ule i32 %descriptor.value.133, %descriptor.value.139
  %descriptor.extent.inside.148 = icmp ule i32 %descriptor.value.135, %stack.sub.147
  %descriptor.payload.inside.149 = icmp ule i32 %descriptor.value.137, %descriptor.value.135
  %descriptor.owner.offset.valid.150 = and i1 %descriptor.owner.inside.145, %descriptor.offset.inside.146
  %descriptor.range.inside.152 = and i1 %descriptor.owner.offset.valid.150, %descriptor.extent.inside.148
  %descriptor.range.valid.151 = and i1 %descriptor.range.inside.152, %descriptor.payload.inside.149
  %descriptor.type.valid.153 = icmp eq i32 4, 4
  %descriptor.valid.154 = and i1 %descriptor.range.valid.151, %descriptor.type.valid.153
  br i1 %descriptor.valid.154, label %descriptor.valid.155, label %descriptor.invalid.156
descriptor.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.155:
  %descriptor.initialized.status.157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.133, i32 %descriptor.value.135)
  %helper.ok.158 = icmp eq i32 %descriptor.initialized.status.157, 0
  br i1 %helper.ok.158, label %helper.continue.159, label %entry.failure.0
helper.continue.159:
  %entry.output.size.i64.160 = zext i32 %descriptor.value.135 to i64
  %entry.output.total.i64.161 = add i64 0, %entry.output.size.i64.160
  %entry.retained.capacity.i64.162 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.163 = icmp ule i64 %entry.output.total.i64.161, 4294967295
  %entry.retained.required.truncated.164 = trunc i64 %entry.output.total.i64.161 to i32
  %entry.retained.required.165 = select i1 %entry.retained.required.fits.u32.163, i32 %entry.retained.required.truncated.164, i32 4294967295
  %entry.retained.capacity.ok.166 = icmp ule i64 %entry.output.total.i64.161, %entry.retained.capacity.i64.162
  br i1 %entry.retained.capacity.ok.166, label %entry.retained.capacity.ready.167, label %entry.retained.capacity.failure.168
entry.retained.capacity.failure.168:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.165, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.167:
  %host.pointer.169 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.170 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.169, i32 %stack.sub.170, i32 %descriptor.value.133, i32 %descriptor.value.135, i32 4)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %entry.failure.0
runtime.continue.174:
  %stack.offset.175 = add i32 0, %descriptor.value.135
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.180 = sub i32 0, %context.value.177
  %stack.sub.181 = sub i32 0, %context.value.179
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.180, i32 %stack.sub.181)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %entry.failure.0
runtime.continue.185:
  br label %entry.return.status
entry.failure.0:
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.offset.192 = add i32 %context.value.187, %context.value.189
  %stack.sub.193 = sub i32 0, %stack.offset.192
  %stack.sub.194 = sub i32 0, %context.value.189
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.193, i32 %stack.sub.194)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.191)
  br label %entry.return.status
entry.return.status:
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  ret i32 %context.value.196
}


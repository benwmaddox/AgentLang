%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 0 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\02\00\00\00\00\00\00\00\6F\00\6B\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 16
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  %literal.status.22 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.17, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 12, i32 16, i32 5, i32 3)
  %helper.ok.23 = icmp eq i32 %literal.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %stack.sub.29 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.27 = icmp ule i32 %stack.offset.18, %context.value.26
  %descriptor.offset.inside.28 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.30 = icmp ule i32 16, %stack.sub.29
  %descriptor.payload.inside.31 = icmp ule i32 12, 16
  %descriptor.owner.offset.valid.32 = and i1 %descriptor.owner.inside.27, %descriptor.offset.inside.28
  %descriptor.range.inside.34 = and i1 %descriptor.owner.offset.valid.32, %descriptor.extent.inside.30
  %descriptor.range.valid.33 = and i1 %descriptor.range.inside.34, %descriptor.payload.inside.31
  %descriptor.type.valid.35 = icmp eq i32 5, 5
  %descriptor.valid.36 = and i1 %descriptor.range.valid.33, %descriptor.type.valid.35
  br i1 %descriptor.valid.36, label %descriptor.valid.37, label %descriptor.invalid.38
descriptor.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.37:
  %descriptor.initialized.status.39 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 16)
  %helper.ok.40 = icmp eq i32 %descriptor.initialized.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %frame.failure.0
helper.continue.41:
  %step.status.42 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.43 = icmp eq i32 %step.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %frame.failure.0
helper.continue.44:
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %inline.target.depth.within.interpreter.limit.47 = icmp ule i32 %context.value.46, 65
  br i1 %inline.target.depth.within.interpreter.limit.47, label %inline.target.depth.ok.48, label %inline.target.depth.invalid.49
inline.target.depth.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.48:
  %validator.arguments.50 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.51 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.50, i32 0
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 0
  store i32 5, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 1
  store i32 %context.value.17, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 2
  store i32 16, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 3
  store i32 12, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 4
  store i32 %stack.offset.18, ptr %descriptor.field.56, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.17, i32 20, i32 12, i32 %stack.offset.18, i32 16)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %validator.results.61 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %validator.depth.within.interpreter.limit.64 = icmp ule i32 %context.value.63, 64
  br i1 %validator.depth.within.interpreter.limit.64, label %validator.depth.ok.65, label %validator.depth.invalid.66
validator.depth.invalid.66:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.65:
  %validator.status.67 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.50, ptr %validator.results.61, i32 8)
  %helper.ok.68 = icmp eq i32 %validator.status.67, 0
  br i1 %helper.ok.68, label %helper.continue.69, label %frame.failure.0
helper.continue.69:
  %descriptor.element.70 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.61, i32 0
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 0
  %descriptor.value.72 = load i32, ptr %descriptor.field.71, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 1
  %descriptor.value.74 = load i32, ptr %descriptor.field.73, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 2
  %descriptor.value.76 = load i32, ptr %descriptor.field.75, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 3
  %descriptor.value.78 = load i32, ptr %descriptor.field.77, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 4
  %descriptor.value.80 = load i32, ptr %descriptor.field.79, align 4
  %validator.result.type.matches.81 = icmp eq i32 %descriptor.value.72, 2
  br i1 %validator.result.type.matches.81, label %validator.result.type.ok.82, label %validator.result.type.invalid.83
validator.result.type.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.82:
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %stack.sub.88 = sub i32 %descriptor.value.80, %descriptor.value.74
  %descriptor.owner.inside.86 = icmp ule i32 %descriptor.value.80, %context.value.85
  %descriptor.offset.inside.87 = icmp ule i32 %descriptor.value.74, %descriptor.value.80
  %descriptor.extent.inside.89 = icmp ule i32 %descriptor.value.76, %stack.sub.88
  %descriptor.payload.inside.90 = icmp ule i32 %descriptor.value.78, %descriptor.value.76
  %descriptor.owner.offset.valid.91 = and i1 %descriptor.owner.inside.86, %descriptor.offset.inside.87
  %descriptor.range.inside.93 = and i1 %descriptor.owner.offset.valid.91, %descriptor.extent.inside.89
  %descriptor.range.valid.92 = and i1 %descriptor.range.inside.93, %descriptor.payload.inside.90
  %descriptor.type.valid.94 = icmp eq i32 2, 2
  %descriptor.valid.95 = and i1 %descriptor.range.valid.92, %descriptor.type.valid.94
  br i1 %descriptor.valid.95, label %descriptor.valid.96, label %descriptor.invalid.97
descriptor.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.96:
  %descriptor.initialized.status.98 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.74, i32 %descriptor.value.76)
  %helper.ok.99 = icmp eq i32 %descriptor.initialized.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.74, i32 20, i32 %descriptor.value.78, i32 %descriptor.value.80, i32 %descriptor.value.76)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %frame.failure.0
runtime.continue.104:
  %validator.bool.105 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.74)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %validator.bool.true.110 = icmp eq i64 %validator.bool.105, 1
  %validator.bool.false.111 = icmp eq i64 %validator.bool.105, 0
  %validator.bool.valid.112 = or i1 %validator.bool.true.110, %validator.bool.false.111
  br i1 %validator.bool.valid.112, label %validator.bool.check.113, label %validator.bool.invalid.114
validator.bool.invalid.114:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.113:
  br i1 %validator.bool.true.110, label %validator.true.116, label %validator.false.115
validator.false.115:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 6, i32 0, i32 0)
  br label %frame.failure.0
validator.true.116:
  br label %validator.join.117
validator.join.117:
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %stack.sub.122 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.120 = icmp ule i32 %stack.offset.18, %context.value.119
  %descriptor.offset.inside.121 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.123 = icmp ule i32 16, %stack.sub.122
  %descriptor.payload.inside.124 = icmp ule i32 12, 16
  %descriptor.owner.offset.valid.125 = and i1 %descriptor.owner.inside.120, %descriptor.offset.inside.121
  %descriptor.range.inside.127 = and i1 %descriptor.owner.offset.valid.125, %descriptor.extent.inside.123
  %descriptor.range.valid.126 = and i1 %descriptor.range.inside.127, %descriptor.payload.inside.124
  %descriptor.type.valid.128 = icmp eq i32 4, 4
  %descriptor.valid.129 = and i1 %descriptor.range.valid.126, %descriptor.type.valid.128
  br i1 %descriptor.valid.129, label %descriptor.valid.130, label %descriptor.invalid.131
descriptor.invalid.131:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.130:
  %descriptor.initialized.status.132 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 16)
  %helper.ok.133 = icmp eq i32 %descriptor.initialized.status.132, 0
  br i1 %helper.ok.133, label %helper.continue.134, label %frame.failure.0
helper.continue.134:
  %descriptor.element.135 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 0
  store i32 4, ptr %descriptor.field.136, align 4
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 1
  store i32 %context.value.17, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 2
  store i32 16, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 3
  store i32 12, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 4
  store i32 %stack.offset.18, ptr %descriptor.field.140, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.17, i32 20, i32 12, i32 %stack.offset.18, i32 16)
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %runtime.ok.143 = icmp eq i32 %context.value.142, 0
  br i1 %runtime.ok.143, label %runtime.continue.144, label %frame.failure.0
runtime.continue.144:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %context.field.149 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.150 = load i32, ptr %context.field.149, align 4
  %stack.offset.151 = add i32 %context.value.5, %context.value.7
  %stack.offset.152 = add i32 %context.value.146, %context.value.148
  %stack.sub.153 = sub i32 %stack.offset.151, %stack.offset.152
  %stack.sub.154 = sub i32 %context.value.7, %context.value.148
  %stack.sub.155 = sub i32 %context.value.150, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.153, i32 %stack.sub.154)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.155)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 10, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 12)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.offset.94 = add i32 %context.value.93, 8
  %reserve.status.95 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 14)
  %reserve.ok.96 = icmp eq i32 %reserve.status.95, 0
  br i1 %reserve.ok.96, label %reserve.continue.97, label %frame.failure.0
reserve.continue.97:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.93, i64 0, i32 1)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %stack.sub.110 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.108 = icmp ule i32 %stack.offset.60, %context.value.107
  %descriptor.offset.inside.109 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.111 = icmp ule i32 8, %stack.sub.110
  %descriptor.payload.inside.112 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.113 = and i1 %descriptor.owner.inside.108, %descriptor.offset.inside.109
  %descriptor.range.inside.115 = and i1 %descriptor.owner.offset.valid.113, %descriptor.extent.inside.111
  %descriptor.range.valid.114 = and i1 %descriptor.range.inside.115, %descriptor.payload.inside.112
  %descriptor.type.valid.116 = icmp eq i32 1, 1
  %descriptor.valid.117 = and i1 %descriptor.range.valid.114, %descriptor.type.valid.116
  br i1 %descriptor.valid.117, label %descriptor.valid.118, label %descriptor.invalid.119
descriptor.invalid.119:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.118:
  %descriptor.initialized.status.120 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.121 = icmp eq i32 %descriptor.initialized.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %frame.failure.0
helper.continue.122:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %stack.offset.94, %context.value.93
  %descriptor.owner.inside.125 = icmp ule i32 %stack.offset.94, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %context.value.93, %stack.offset.94
  %descriptor.extent.inside.128 = icmp ule i32 8, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 1, 1
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.93, i32 8)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %step.status.140 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.141 = icmp eq i32 %step.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %inline.target.depth.within.interpreter.limit.145 = icmp ule i32 %context.value.144, 65
  br i1 %inline.target.depth.within.interpreter.limit.145, label %inline.target.depth.ok.146, label %inline.target.depth.invalid.147
inline.target.depth.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 16, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.146:
  %integer.left.148 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.59)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %integer.right.149 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.93)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %divide.zero.158 = icmp eq i64 %integer.right.149, 0
  br i1 %divide.zero.158, label %divide.zero.159, label %divide.nonzero.160
divide.zero.159:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.160:
  %divide.min.161 = icmp eq i64 %integer.left.148, -9223372036854775808
  %divide.minusone.162 = icmp eq i64 %integer.right.149, -1
  %divide.overflow.163 = and i1 %divide.min.161, %divide.minusone.162
  br i1 %divide.overflow.163, label %divide.overflow.164, label %divide.valid.165
divide.overflow.164:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 18, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.165:
  %divide.result.166 = sdiv i64 %integer.left.148, %integer.right.149
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.93, i32 8, i32 8, i32 0, i32 0)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.59, i32 8, i32 8, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.176, 8
  %reserve.status.178 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.177, i32 19)
  %reserve.ok.179 = icmp eq i32 %reserve.status.178, 0
  br i1 %reserve.ok.179, label %reserve.continue.180, label %frame.failure.0
reserve.continue.180:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.176, i64 %divide.result.166, i32 1)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %stack.offset.189 = add i32 %context.value.176, 8
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.192 = icmp ule i32 %stack.offset.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.195 = icmp ule i32 8, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 1, 1
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %inline.target.depth.within.interpreter.limit.212 = icmp ule i32 %context.value.211, 65
  br i1 %inline.target.depth.within.interpreter.limit.212, label %inline.target.depth.ok.213, label %inline.target.depth.invalid.214
inline.target.depth.invalid.214:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.213:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.176, i32 8, i32 8, i32 0, i32 0)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  %step.status.219 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.220 = icmp eq i32 %step.status.219, 0
  br i1 %helper.ok.220, label %helper.continue.221, label %frame.failure.0
helper.continue.221:
  %context.field.222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.223 = load i32, ptr %context.field.222, align 4
  %stack.offset.224 = add i32 %context.value.223, 8
  %reserve.status.225 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.224, i32 23)
  %reserve.ok.226 = icmp eq i32 %reserve.status.225, 0
  br i1 %reserve.ok.226, label %reserve.continue.227, label %frame.failure.0
reserve.continue.227:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.223, i64 1, i32 2)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %frame.failure.0
runtime.continue.231:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.233 = load i32, ptr %context.field.232, align 4
  %runtime.ok.234 = icmp eq i32 %context.value.233, 0
  br i1 %runtime.ok.234, label %runtime.continue.235, label %frame.failure.0
runtime.continue.235:
  %context.field.236 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.237 = load i32, ptr %context.field.236, align 4
  %stack.sub.240 = sub i32 %stack.offset.224, %context.value.223
  %descriptor.owner.inside.238 = icmp ule i32 %stack.offset.224, %context.value.237
  %descriptor.offset.inside.239 = icmp ule i32 %context.value.223, %stack.offset.224
  %descriptor.extent.inside.241 = icmp ule i32 8, %stack.sub.240
  %descriptor.payload.inside.242 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.243 = and i1 %descriptor.owner.inside.238, %descriptor.offset.inside.239
  %descriptor.range.inside.245 = and i1 %descriptor.owner.offset.valid.243, %descriptor.extent.inside.241
  %descriptor.range.valid.244 = and i1 %descriptor.range.inside.245, %descriptor.payload.inside.242
  %descriptor.type.valid.246 = icmp eq i32 2, 2
  %descriptor.valid.247 = and i1 %descriptor.range.valid.244, %descriptor.type.valid.246
  br i1 %descriptor.valid.247, label %descriptor.valid.248, label %descriptor.invalid.249
descriptor.invalid.249:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.248:
  %descriptor.initialized.status.250 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.223, i32 8)
  %helper.ok.251 = icmp eq i32 %descriptor.initialized.status.250, 0
  br i1 %helper.ok.251, label %helper.continue.252, label %frame.failure.0
helper.continue.252:
  %descriptor.element.253 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.254 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 0
  store i32 2, ptr %descriptor.field.254, align 4
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 1
  store i32 %context.value.223, ptr %descriptor.field.255, align 4
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 2
  store i32 8, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 3
  store i32 8, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 4
  store i32 %stack.offset.224, ptr %descriptor.field.258, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.223, i32 20, i32 8, i32 %stack.offset.224, i32 8)
  %context.field.259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.260 = load i32, ptr %context.field.259, align 4
  %runtime.ok.261 = icmp eq i32 %context.value.260, 0
  br i1 %runtime.ok.261, label %runtime.continue.262, label %frame.failure.0
runtime.continue.262:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %context.field.265 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.266 = load i32, ptr %context.field.265, align 4
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %stack.offset.269 = add i32 %context.value.5, %context.value.7
  %stack.offset.270 = add i32 %context.value.264, %context.value.266
  %stack.sub.271 = sub i32 %stack.offset.269, %stack.offset.270
  %stack.sub.272 = sub i32 %context.value.7, %context.value.266
  %stack.sub.273 = sub i32 %context.value.268, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.271, i32 %stack.sub.272)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.273)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 24)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 25)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 4
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 4, 4
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 4)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


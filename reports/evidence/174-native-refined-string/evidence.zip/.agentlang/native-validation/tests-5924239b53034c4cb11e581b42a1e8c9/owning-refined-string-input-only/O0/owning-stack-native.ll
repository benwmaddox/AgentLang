%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 4
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 4, 4
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 5
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 5, 5
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.sub.75 = sub i32 %context.value.74, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.75, i32 0, i32 0, i32 0)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  %descriptor.element.84 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 0
  store i32 4, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.89, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %descriptor.element.94 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.95 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 0
  store i32 5, ptr %descriptor.field.95, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.98, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.99, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %stack.offset.110 = add i32 %context.value.5, %context.value.7
  %stack.offset.111 = add i32 %context.value.105, %context.value.107
  %stack.sub.112 = sub i32 %stack.offset.110, %stack.offset.111
  %stack.sub.113 = sub i32 %context.value.7, %context.value.107
  %stack.sub.114 = sub i32 %context.value.109, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.112, i32 %stack.sub.113)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.114)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 3, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 4)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 6)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 9)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 10, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 10, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 10, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.extent.pointer.37 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.38 = load i32, ptr %input.extent.pointer.37, align 4
  %stack.sub.39 = sub i32 %input.bytes, %stack.offset.36
  %input.offset.within.bytes.40 = icmp ule i32 %stack.offset.36, %input.bytes
  %input.extent.within.bytes.41 = icmp ule i32 %input.host.extent.38, %stack.sub.39
  %input.slice.within.bytes.42 = and i1 %input.offset.within.bytes.40, %input.extent.within.bytes.41
  br i1 %input.slice.within.bytes.42, label %input.slice.ready.43, label %input.slice.invalid.44
input.slice.invalid.44:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.43:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.payload.pointer.46 = alloca i32, align 4
  %input.measured.extent.pointer.47 = alloca i32, align 4
  %input.measure.status.48 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.45, i32 %input.host.extent.38, i32 0, i32 11, ptr %input.payload.pointer.46, ptr %input.measured.extent.pointer.47)
  %helper.ok.49 = icmp eq i32 %input.measure.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %entry.failure.0
helper.continue.50:
  %input.measured.payload.51 = load i32, ptr %input.payload.pointer.46, align 4
  %input.measured.extent.52 = load i32, ptr %input.measured.extent.pointer.47, align 4
  %input.extent.exact.53 = icmp eq i32 %input.measured.extent.52, %input.host.extent.38
  br i1 %input.extent.exact.53, label %input.extent.exact.54, label %input.extent.invalid.55
input.extent.invalid.55:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 %input.measured.extent.52, i32 %input.host.extent.38)
  br label %entry.failure.0
input.extent.exact.54:
  %stack.offset.56 = add i32 %stack.offset.36, %input.host.extent.38
  %input.total.exact.57 = icmp eq i32 %stack.offset.56, %input.bytes
  br i1 %input.total.exact.57, label %input.valid.58, label %input.invalid.59
input.invalid.59:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.56, i32 %input.bytes)
  br label %entry.failure.0
input.valid.58:
  %reserve.status.60 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.56, i32 12)
  %reserve.ok.61 = icmp eq i32 %reserve.status.60, 0
  br i1 %reserve.ok.61, label %reserve.continue.62, label %entry.failure.0
reserve.continue.62:
  %host.pointer.63 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.64 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.63, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 4, i32 13)
  %helper.ok.65 = icmp eq i32 %input.copy.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %entry.failure.0
helper.continue.66:
  %stack.offset.67 = add i32 0, %input.host.extent.18
  %descriptor.element.68 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 0
  store i32 4, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 1
  store i32 0, ptr %descriptor.field.70, align 4
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.71, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 4
  store i32 %stack.offset.67, ptr %descriptor.field.73, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.67, i32 %input.host.extent.18)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  %host.pointer.78 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.copy.status.79 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.36, ptr %host.pointer.78, i32 %input.host.extent.38, i32 0, i32 %input.measured.payload.51, i32 %input.host.extent.38, i32 5, i32 14)
  %helper.ok.80 = icmp eq i32 %input.copy.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %entry.failure.0
helper.continue.81:
  %stack.offset.82 = add i32 %stack.offset.36, %input.host.extent.38
  %descriptor.element.83 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 1
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 0
  store i32 5, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 1
  store i32 %stack.offset.36, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 2
  store i32 %input.host.extent.38, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 3
  store i32 %input.measured.payload.51, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 4
  store i32 %stack.offset.82, ptr %descriptor.field.88, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.36, i32 20, i32 %input.measured.payload.51, i32 %stack.offset.82, i32 %input.host.extent.38)
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %runtime.ok.91 = icmp eq i32 %context.value.90, 0
  br i1 %runtime.ok.91, label %runtime.continue.92, label %entry.failure.0
runtime.continue.92:
  %entry.validation.frame.entered.93 = call i32 @al_owning_enter_frame(ptr %ctx, i32 15)
  %helper.ok.94 = icmp eq i32 %entry.validation.frame.entered.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %entry.failure.0
helper.continue.95:
  %stack.offset.96 = add i32 0, %input.host.extent.18
  %validator.arguments.97 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.98 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.97, i32 0
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 0
  store i32 6, ptr %descriptor.field.99, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 1
  store i32 0, ptr %descriptor.field.100, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.101, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.102, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 4
  store i32 %stack.offset.96, ptr %descriptor.field.103, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.96, i32 %input.host.extent.18)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %entry.validation.failure.3
runtime.continue.107:
  %validator.results.108 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.109 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.97, ptr %validator.results.108, i32 18)
  %helper.ok.110 = icmp eq i32 %validator.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %entry.validation.failure.3
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.108, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  %descriptor.value.114 = load i32, ptr %descriptor.field.113, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  %descriptor.value.116 = load i32, ptr %descriptor.field.115, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  %descriptor.value.118 = load i32, ptr %descriptor.field.117, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  %descriptor.value.120 = load i32, ptr %descriptor.field.119, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  %descriptor.value.122 = load i32, ptr %descriptor.field.121, align 4
  %validator.result.type.matches.123 = icmp eq i32 %descriptor.value.114, 2
  br i1 %validator.result.type.matches.123, label %validator.result.type.ok.124, label %validator.result.type.invalid.125
validator.result.type.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.124:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.sub.130 = sub i32 %descriptor.value.122, %descriptor.value.116
  %descriptor.owner.inside.128 = icmp ule i32 %descriptor.value.122, %context.value.127
  %descriptor.offset.inside.129 = icmp ule i32 %descriptor.value.116, %descriptor.value.122
  %descriptor.extent.inside.131 = icmp ule i32 %descriptor.value.118, %stack.sub.130
  %descriptor.payload.inside.132 = icmp ule i32 %descriptor.value.120, %descriptor.value.118
  %descriptor.owner.offset.valid.133 = and i1 %descriptor.owner.inside.128, %descriptor.offset.inside.129
  %descriptor.range.inside.135 = and i1 %descriptor.owner.offset.valid.133, %descriptor.extent.inside.131
  %descriptor.range.valid.134 = and i1 %descriptor.range.inside.135, %descriptor.payload.inside.132
  %descriptor.type.valid.136 = icmp eq i32 2, 2
  %descriptor.valid.137 = and i1 %descriptor.range.valid.134, %descriptor.type.valid.136
  br i1 %descriptor.valid.137, label %descriptor.valid.138, label %descriptor.invalid.139
descriptor.invalid.139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.138:
  %descriptor.initialized.status.140 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.116, i32 %descriptor.value.118)
  %helper.ok.141 = icmp eq i32 %descriptor.initialized.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %entry.validation.failure.3
helper.continue.142:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.116, i32 20, i32 %descriptor.value.120, i32 %descriptor.value.122, i32 %descriptor.value.118)
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %runtime.ok.145 = icmp eq i32 %context.value.144, 0
  br i1 %runtime.ok.145, label %runtime.continue.146, label %entry.validation.failure.3
runtime.continue.146:
  %validator.bool.147 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.116)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %entry.validation.failure.3
runtime.continue.151:
  %validator.bool.true.152 = icmp eq i64 %validator.bool.147, 1
  %validator.bool.false.153 = icmp eq i64 %validator.bool.147, 0
  %validator.bool.valid.154 = or i1 %validator.bool.true.152, %validator.bool.false.153
  br i1 %validator.bool.valid.154, label %validator.bool.check.155, label %validator.bool.invalid.156
validator.bool.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.155:
  br i1 %validator.bool.true.152, label %validator.true.158, label %validator.false.157
validator.false.157:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 16, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.158:
  br label %validator.join.159
validator.join.159:
  %stack.offset.160 = add i32 %stack.offset.36, %input.host.extent.38
  %validator.arguments.161 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.162 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.161, i32 0
  %descriptor.field.163 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 0
  store i32 6, ptr %descriptor.field.163, align 4
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 1
  store i32 %stack.offset.36, ptr %descriptor.field.164, align 4
  %descriptor.field.165 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 2
  store i32 %input.host.extent.38, ptr %descriptor.field.165, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 3
  store i32 %input.measured.payload.51, ptr %descriptor.field.166, align 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 4
  store i32 %stack.offset.160, ptr %descriptor.field.167, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %stack.offset.36, i32 20, i32 %input.measured.payload.51, i32 %stack.offset.160, i32 %input.host.extent.38)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %entry.validation.failure.3
runtime.continue.171:
  %validator.results.172 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.173 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.161, ptr %validator.results.172, i32 21)
  %helper.ok.174 = icmp eq i32 %validator.status.173, 0
  br i1 %helper.ok.174, label %helper.continue.175, label %entry.validation.failure.3
helper.continue.175:
  %descriptor.element.176 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.172, i32 0
  %descriptor.field.177 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.176, i32 0, i32 0
  %descriptor.value.178 = load i32, ptr %descriptor.field.177, align 4
  %descriptor.field.179 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.176, i32 0, i32 1
  %descriptor.value.180 = load i32, ptr %descriptor.field.179, align 4
  %descriptor.field.181 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.176, i32 0, i32 2
  %descriptor.value.182 = load i32, ptr %descriptor.field.181, align 4
  %descriptor.field.183 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.176, i32 0, i32 3
  %descriptor.value.184 = load i32, ptr %descriptor.field.183, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.176, i32 0, i32 4
  %descriptor.value.186 = load i32, ptr %descriptor.field.185, align 4
  %validator.result.type.matches.187 = icmp eq i32 %descriptor.value.178, 2
  br i1 %validator.result.type.matches.187, label %validator.result.type.ok.188, label %validator.result.type.invalid.189
validator.result.type.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 20, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.188:
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %descriptor.value.186, %descriptor.value.180
  %descriptor.owner.inside.192 = icmp ule i32 %descriptor.value.186, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %descriptor.value.180, %descriptor.value.186
  %descriptor.extent.inside.195 = icmp ule i32 %descriptor.value.182, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 %descriptor.value.184, %descriptor.value.182
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 2, 2
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.180, i32 %descriptor.value.182)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %entry.validation.failure.3
helper.continue.206:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.180, i32 20, i32 %descriptor.value.184, i32 %descriptor.value.186, i32 %descriptor.value.182)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %entry.validation.failure.3
runtime.continue.210:
  %validator.bool.211 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.180)
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %runtime.ok.214 = icmp eq i32 %context.value.213, 0
  br i1 %runtime.ok.214, label %runtime.continue.215, label %entry.validation.failure.3
runtime.continue.215:
  %validator.bool.true.216 = icmp eq i64 %validator.bool.211, 1
  %validator.bool.false.217 = icmp eq i64 %validator.bool.211, 0
  %validator.bool.valid.218 = or i1 %validator.bool.true.216, %validator.bool.false.217
  br i1 %validator.bool.valid.218, label %validator.bool.check.219, label %validator.bool.invalid.220
validator.bool.invalid.220:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 20, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.219:
  br i1 %validator.bool.true.216, label %validator.true.222, label %validator.false.221
validator.false.221:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 19, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.222:
  br label %validator.join.223
validator.join.223:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.224
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.224:
  %entry.output.descriptors.225 = alloca [2 x %AlOwningDescriptor], align 4
  %entry.body.status.226 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.225, i32 22)
  %entry.body.ok.227 = icmp eq i32 %entry.body.status.226, 0
  br i1 %entry.body.ok.227, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.228 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.225, i32 0
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 0
  %descriptor.value.230 = load i32, ptr %descriptor.field.229, align 4
  %descriptor.field.231 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 1
  %descriptor.value.232 = load i32, ptr %descriptor.field.231, align 4
  %descriptor.field.233 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 2
  %descriptor.value.234 = load i32, ptr %descriptor.field.233, align 4
  %descriptor.field.235 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 3
  %descriptor.value.236 = load i32, ptr %descriptor.field.235, align 4
  %descriptor.field.237 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 4
  %descriptor.value.238 = load i32, ptr %descriptor.field.237, align 4
  %entry.output.type.valid.239 = icmp eq i32 %descriptor.value.230, 4
  br i1 %entry.output.type.valid.239, label %entry.output.type.ok.240, label %entry.output.type.invalid.241
entry.output.type.invalid.241:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.240:
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %stack.sub.246 = sub i32 %descriptor.value.238, %descriptor.value.232
  %descriptor.owner.inside.244 = icmp ule i32 %descriptor.value.238, %context.value.243
  %descriptor.offset.inside.245 = icmp ule i32 %descriptor.value.232, %descriptor.value.238
  %descriptor.extent.inside.247 = icmp ule i32 %descriptor.value.234, %stack.sub.246
  %descriptor.payload.inside.248 = icmp ule i32 %descriptor.value.236, %descriptor.value.234
  %descriptor.owner.offset.valid.249 = and i1 %descriptor.owner.inside.244, %descriptor.offset.inside.245
  %descriptor.range.inside.251 = and i1 %descriptor.owner.offset.valid.249, %descriptor.extent.inside.247
  %descriptor.range.valid.250 = and i1 %descriptor.range.inside.251, %descriptor.payload.inside.248
  %descriptor.type.valid.252 = icmp eq i32 4, 4
  %descriptor.valid.253 = and i1 %descriptor.range.valid.250, %descriptor.type.valid.252
  br i1 %descriptor.valid.253, label %descriptor.valid.254, label %descriptor.invalid.255
descriptor.invalid.255:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.254:
  %descriptor.initialized.status.256 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.232, i32 %descriptor.value.234)
  %helper.ok.257 = icmp eq i32 %descriptor.initialized.status.256, 0
  br i1 %helper.ok.257, label %helper.continue.258, label %entry.failure.0
helper.continue.258:
  %entry.output.size.i64.259 = zext i32 %descriptor.value.234 to i64
  %entry.output.total.i64.260 = add i64 0, %entry.output.size.i64.259
  %descriptor.element.261 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.225, i32 1
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.261, i32 0, i32 0
  %descriptor.value.263 = load i32, ptr %descriptor.field.262, align 4
  %descriptor.field.264 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.261, i32 0, i32 1
  %descriptor.value.265 = load i32, ptr %descriptor.field.264, align 4
  %descriptor.field.266 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.261, i32 0, i32 2
  %descriptor.value.267 = load i32, ptr %descriptor.field.266, align 4
  %descriptor.field.268 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.261, i32 0, i32 3
  %descriptor.value.269 = load i32, ptr %descriptor.field.268, align 4
  %descriptor.field.270 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.261, i32 0, i32 4
  %descriptor.value.271 = load i32, ptr %descriptor.field.270, align 4
  %entry.output.type.valid.272 = icmp eq i32 %descriptor.value.263, 5
  br i1 %entry.output.type.valid.272, label %entry.output.type.ok.273, label %entry.output.type.invalid.274
entry.output.type.invalid.274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.273:
  %context.field.275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.276 = load i32, ptr %context.field.275, align 4
  %stack.sub.279 = sub i32 %descriptor.value.271, %descriptor.value.265
  %descriptor.owner.inside.277 = icmp ule i32 %descriptor.value.271, %context.value.276
  %descriptor.offset.inside.278 = icmp ule i32 %descriptor.value.265, %descriptor.value.271
  %descriptor.extent.inside.280 = icmp ule i32 %descriptor.value.267, %stack.sub.279
  %descriptor.payload.inside.281 = icmp ule i32 %descriptor.value.269, %descriptor.value.267
  %descriptor.owner.offset.valid.282 = and i1 %descriptor.owner.inside.277, %descriptor.offset.inside.278
  %descriptor.range.inside.284 = and i1 %descriptor.owner.offset.valid.282, %descriptor.extent.inside.280
  %descriptor.range.valid.283 = and i1 %descriptor.range.inside.284, %descriptor.payload.inside.281
  %descriptor.type.valid.285 = icmp eq i32 5, 5
  %descriptor.valid.286 = and i1 %descriptor.range.valid.283, %descriptor.type.valid.285
  br i1 %descriptor.valid.286, label %descriptor.valid.287, label %descriptor.invalid.288
descriptor.invalid.288:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.287:
  %descriptor.initialized.status.289 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.265, i32 %descriptor.value.267)
  %helper.ok.290 = icmp eq i32 %descriptor.initialized.status.289, 0
  br i1 %helper.ok.290, label %helper.continue.291, label %entry.failure.0
helper.continue.291:
  %entry.output.size.i64.292 = zext i32 %descriptor.value.267 to i64
  %entry.output.total.i64.293 = add i64 %entry.output.total.i64.260, %entry.output.size.i64.292
  %entry.retained.capacity.i64.294 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.295 = icmp ule i64 %entry.output.total.i64.293, 4294967295
  %entry.retained.required.truncated.296 = trunc i64 %entry.output.total.i64.293 to i32
  %entry.retained.required.297 = select i1 %entry.retained.required.fits.u32.295, i32 %entry.retained.required.truncated.296, i32 4294967295
  %entry.retained.capacity.ok.298 = icmp ule i64 %entry.output.total.i64.293, %entry.retained.capacity.i64.294
  br i1 %entry.retained.capacity.ok.298, label %entry.retained.capacity.ready.299, label %entry.retained.capacity.failure.300
entry.retained.capacity.failure.300:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.297, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.299:
  %host.pointer.301 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.302 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.301, i32 %stack.sub.302, i32 %descriptor.value.232, i32 %descriptor.value.234, i32 4)
  %context.field.303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.304 = load i32, ptr %context.field.303, align 4
  %runtime.ok.305 = icmp eq i32 %context.value.304, 0
  br i1 %runtime.ok.305, label %runtime.continue.306, label %entry.failure.0
runtime.continue.306:
  %stack.offset.307 = add i32 0, %descriptor.value.234
  %host.pointer.308 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.307
  %stack.sub.309 = sub i32 %retained.capacity, %stack.offset.307
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.308, i32 %stack.sub.309, i32 %descriptor.value.265, i32 %descriptor.value.267, i32 5)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %entry.failure.0
runtime.continue.313:
  %stack.offset.314 = add i32 %stack.offset.307, %descriptor.value.267
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.316 = load i32, ptr %context.field.315, align 4
  %context.field.317 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.318 = load i32, ptr %context.field.317, align 4
  %stack.sub.319 = sub i32 0, %context.value.316
  %stack.sub.320 = sub i32 0, %context.value.318
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.319, i32 %stack.sub.320)
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %runtime.ok.323 = icmp eq i32 %context.value.322, 0
  br i1 %runtime.ok.323, label %runtime.continue.324, label %entry.failure.0
runtime.continue.324:
  br label %entry.return.status
entry.failure.0:
  %context.field.325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.326 = load i32, ptr %context.field.325, align 4
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %stack.offset.331 = add i32 %context.value.326, %context.value.328
  %stack.sub.332 = sub i32 0, %stack.offset.331
  %stack.sub.333 = sub i32 0, %context.value.328
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.332, i32 %stack.sub.333)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.330)
  br label %entry.return.status
entry.return.status:
  %context.field.334 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.335 = load i32, ptr %context.field.334, align 4
  ret i32 %context.value.335
}


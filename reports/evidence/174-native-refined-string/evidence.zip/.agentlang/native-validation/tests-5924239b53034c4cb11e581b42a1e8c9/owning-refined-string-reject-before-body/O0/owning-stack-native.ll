%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 4
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 4, 4
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 4, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.offset.94 = add i32 %context.value.93, 8
  %reserve.status.95 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 6)
  %reserve.ok.96 = icmp eq i32 %reserve.status.95, 0
  br i1 %reserve.ok.96, label %reserve.continue.97, label %frame.failure.0
reserve.continue.97:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.93, i64 0, i32 1)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %stack.sub.110 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.108 = icmp ule i32 %stack.offset.60, %context.value.107
  %descriptor.offset.inside.109 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.111 = icmp ule i32 8, %stack.sub.110
  %descriptor.payload.inside.112 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.113 = and i1 %descriptor.owner.inside.108, %descriptor.offset.inside.109
  %descriptor.range.inside.115 = and i1 %descriptor.owner.offset.valid.113, %descriptor.extent.inside.111
  %descriptor.range.valid.114 = and i1 %descriptor.range.inside.115, %descriptor.payload.inside.112
  %descriptor.type.valid.116 = icmp eq i32 1, 1
  %descriptor.valid.117 = and i1 %descriptor.range.valid.114, %descriptor.type.valid.116
  br i1 %descriptor.valid.117, label %descriptor.valid.118, label %descriptor.invalid.119
descriptor.invalid.119:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.118:
  %descriptor.initialized.status.120 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.121 = icmp eq i32 %descriptor.initialized.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %frame.failure.0
helper.continue.122:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %stack.offset.94, %context.value.93
  %descriptor.owner.inside.125 = icmp ule i32 %stack.offset.94, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %context.value.93, %stack.offset.94
  %descriptor.extent.inside.128 = icmp ule i32 8, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 1, 1
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.93, i32 8)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %step.status.140 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.141 = icmp eq i32 %step.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %inline.target.depth.within.interpreter.limit.145 = icmp ule i32 %context.value.144, 65
  br i1 %inline.target.depth.within.interpreter.limit.145, label %inline.target.depth.ok.146, label %inline.target.depth.invalid.147
inline.target.depth.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.146:
  %integer.left.148 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.59)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %integer.right.149 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.93)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %divide.zero.158 = icmp eq i64 %integer.right.149, 0
  br i1 %divide.zero.158, label %divide.zero.159, label %divide.nonzero.160
divide.zero.159:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.160:
  %divide.min.161 = icmp eq i64 %integer.left.148, -9223372036854775808
  %divide.minusone.162 = icmp eq i64 %integer.right.149, -1
  %divide.overflow.163 = and i1 %divide.min.161, %divide.minusone.162
  br i1 %divide.overflow.163, label %divide.overflow.164, label %divide.valid.165
divide.overflow.164:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 10, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.165:
  %divide.result.166 = sdiv i64 %integer.left.148, %integer.right.149
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.93, i32 8, i32 8, i32 0, i32 0)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.59, i32 8, i32 8, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.176, 8
  %reserve.status.178 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.177, i32 11)
  %reserve.ok.179 = icmp eq i32 %reserve.status.178, 0
  br i1 %reserve.ok.179, label %reserve.continue.180, label %frame.failure.0
reserve.continue.180:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.176, i64 %divide.result.166, i32 1)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %stack.offset.189 = add i32 %context.value.176, 8
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.192 = icmp ule i32 %stack.offset.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.195 = icmp ule i32 8, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 1, 1
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  %descriptor.element.207 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 0
  store i32 1, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 1
  store i32 %context.value.176, ptr %descriptor.field.209, align 4
  %descriptor.field.210 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 2
  store i32 8, ptr %descriptor.field.210, align 4
  %descriptor.field.211 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 3
  store i32 8, ptr %descriptor.field.211, align 4
  %descriptor.field.212 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 4
  store i32 %stack.offset.189, ptr %descriptor.field.212, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.176, i32 20, i32 8, i32 %stack.offset.189, i32 8)
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %runtime.ok.215 = icmp eq i32 %context.value.214, 0
  br i1 %runtime.ok.215, label %runtime.continue.216, label %frame.failure.0
runtime.continue.216:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %context.field.221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.222 = load i32, ptr %context.field.221, align 4
  %stack.offset.223 = add i32 %context.value.5, %context.value.7
  %stack.offset.224 = add i32 %context.value.218, %context.value.220
  %stack.sub.225 = sub i32 %stack.offset.223, %stack.offset.224
  %stack.sub.226 = sub i32 %context.value.7, %context.value.220
  %stack.sub.227 = sub i32 %context.value.222, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.225, i32 %stack.sub.226)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.227)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 14, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 15)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 17)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 19, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 20)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 21, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.total.exact.37 = icmp eq i32 %stack.offset.36, %input.bytes
  br i1 %input.total.exact.37, label %input.valid.38, label %input.invalid.39
input.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.36, i32 %input.bytes)
  br label %entry.failure.0
input.valid.38:
  %reserve.status.40 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.36, i32 22)
  %reserve.ok.41 = icmp eq i32 %reserve.status.40, 0
  br i1 %reserve.ok.41, label %reserve.continue.42, label %entry.failure.0
reserve.continue.42:
  %host.pointer.43 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.44 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.43, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 4, i32 23)
  %helper.ok.45 = icmp eq i32 %input.copy.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %stack.offset.47 = add i32 0, %input.host.extent.18
  %descriptor.element.48 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 0
  store i32 4, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 1
  store i32 0, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 4
  store i32 %stack.offset.47, ptr %descriptor.field.53, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.47, i32 %input.host.extent.18)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %entry.failure.0
runtime.continue.57:
  %entry.validation.frame.entered.58 = call i32 @al_owning_enter_frame(ptr %ctx, i32 24)
  %helper.ok.59 = icmp eq i32 %entry.validation.frame.entered.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %stack.offset.61 = add i32 0, %input.host.extent.18
  %validator.arguments.62 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.63 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.62, i32 0
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 0
  store i32 5, ptr %descriptor.field.64, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 1
  store i32 0, ptr %descriptor.field.65, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.63, i32 0, i32 4
  store i32 %stack.offset.61, ptr %descriptor.field.68, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.61, i32 %input.host.extent.18)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %entry.validation.failure.3
runtime.continue.72:
  %validator.results.73 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.74 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.62, ptr %validator.results.73, i32 27)
  %helper.ok.75 = icmp eq i32 %validator.status.74, 0
  br i1 %helper.ok.75, label %helper.continue.76, label %entry.validation.failure.3
helper.continue.76:
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.73, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %validator.result.type.matches.88 = icmp eq i32 %descriptor.value.79, 2
  br i1 %validator.result.type.matches.88, label %validator.result.type.ok.89, label %validator.result.type.invalid.90
validator.result.type.invalid.90:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 26, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.89:
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.sub.95 = sub i32 %descriptor.value.87, %descriptor.value.81
  %descriptor.owner.inside.93 = icmp ule i32 %descriptor.value.87, %context.value.92
  %descriptor.offset.inside.94 = icmp ule i32 %descriptor.value.81, %descriptor.value.87
  %descriptor.extent.inside.96 = icmp ule i32 %descriptor.value.83, %stack.sub.95
  %descriptor.payload.inside.97 = icmp ule i32 %descriptor.value.85, %descriptor.value.83
  %descriptor.owner.offset.valid.98 = and i1 %descriptor.owner.inside.93, %descriptor.offset.inside.94
  %descriptor.range.inside.100 = and i1 %descriptor.owner.offset.valid.98, %descriptor.extent.inside.96
  %descriptor.range.valid.99 = and i1 %descriptor.range.inside.100, %descriptor.payload.inside.97
  %descriptor.type.valid.101 = icmp eq i32 2, 2
  %descriptor.valid.102 = and i1 %descriptor.range.valid.99, %descriptor.type.valid.101
  br i1 %descriptor.valid.102, label %descriptor.valid.103, label %descriptor.invalid.104
descriptor.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.103:
  %descriptor.initialized.status.105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.81, i32 %descriptor.value.83)
  %helper.ok.106 = icmp eq i32 %descriptor.initialized.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %entry.validation.failure.3
helper.continue.107:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.81, i32 20, i32 %descriptor.value.85, i32 %descriptor.value.87, i32 %descriptor.value.83)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %entry.validation.failure.3
runtime.continue.111:
  %validator.bool.112 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.81)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.validation.failure.3
runtime.continue.116:
  %validator.bool.true.117 = icmp eq i64 %validator.bool.112, 1
  %validator.bool.false.118 = icmp eq i64 %validator.bool.112, 0
  %validator.bool.valid.119 = or i1 %validator.bool.true.117, %validator.bool.false.118
  br i1 %validator.bool.valid.119, label %validator.bool.check.120, label %validator.bool.invalid.121
validator.bool.invalid.121:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 26, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.120:
  br i1 %validator.bool.true.117, label %validator.true.123, label %validator.false.122
validator.false.122:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.123:
  br label %validator.join.124
validator.join.124:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.125
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.125:
  %entry.output.descriptors.126 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.127 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.126, i32 28)
  %entry.body.ok.128 = icmp eq i32 %entry.body.status.127, 0
  br i1 %entry.body.ok.128, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.129 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.126, i32 0
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 0
  %descriptor.value.131 = load i32, ptr %descriptor.field.130, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 1
  %descriptor.value.133 = load i32, ptr %descriptor.field.132, align 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 2
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 3
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.129, i32 0, i32 4
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %entry.output.type.valid.140 = icmp eq i32 %descriptor.value.131, 1
  br i1 %entry.output.type.valid.140, label %entry.output.type.ok.141, label %entry.output.type.invalid.142
entry.output.type.invalid.142:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.141:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %stack.sub.147 = sub i32 %descriptor.value.139, %descriptor.value.133
  %descriptor.owner.inside.145 = icmp ule i32 %descriptor.value.139, %context.value.144
  %descriptor.offset.inside.146 = icmp ule i32 %descriptor.value.133, %descriptor.value.139
  %descriptor.extent.inside.148 = icmp ule i32 %descriptor.value.135, %stack.sub.147
  %descriptor.payload.inside.149 = icmp ule i32 %descriptor.value.137, %descriptor.value.135
  %descriptor.owner.offset.valid.150 = and i1 %descriptor.owner.inside.145, %descriptor.offset.inside.146
  %descriptor.range.inside.152 = and i1 %descriptor.owner.offset.valid.150, %descriptor.extent.inside.148
  %descriptor.range.valid.151 = and i1 %descriptor.range.inside.152, %descriptor.payload.inside.149
  %descriptor.type.valid.153 = icmp eq i32 1, 1
  %descriptor.valid.154 = and i1 %descriptor.range.valid.151, %descriptor.type.valid.153
  br i1 %descriptor.valid.154, label %descriptor.valid.155, label %descriptor.invalid.156
descriptor.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.155:
  %descriptor.initialized.status.157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.133, i32 %descriptor.value.135)
  %helper.ok.158 = icmp eq i32 %descriptor.initialized.status.157, 0
  br i1 %helper.ok.158, label %helper.continue.159, label %entry.failure.0
helper.continue.159:
  %entry.output.size.i64.160 = zext i32 %descriptor.value.135 to i64
  %entry.output.total.i64.161 = add i64 0, %entry.output.size.i64.160
  %entry.retained.capacity.i64.162 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.163 = icmp ule i64 %entry.output.total.i64.161, 4294967295
  %entry.retained.required.truncated.164 = trunc i64 %entry.output.total.i64.161 to i32
  %entry.retained.required.165 = select i1 %entry.retained.required.fits.u32.163, i32 %entry.retained.required.truncated.164, i32 4294967295
  %entry.retained.capacity.ok.166 = icmp ule i64 %entry.output.total.i64.161, %entry.retained.capacity.i64.162
  br i1 %entry.retained.capacity.ok.166, label %entry.retained.capacity.ready.167, label %entry.retained.capacity.failure.168
entry.retained.capacity.failure.168:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.165, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.167:
  %host.pointer.169 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.170 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.169, i32 %stack.sub.170, i32 %descriptor.value.133, i32 %descriptor.value.135, i32 1)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %entry.failure.0
runtime.continue.174:
  %stack.offset.175 = add i32 0, %descriptor.value.135
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.180 = sub i32 0, %context.value.177
  %stack.sub.181 = sub i32 0, %context.value.179
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.180, i32 %stack.sub.181)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %entry.failure.0
runtime.continue.185:
  br label %entry.return.status
entry.failure.0:
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.offset.192 = add i32 %context.value.187, %context.value.189
  %stack.sub.193 = sub i32 0, %stack.offset.192
  %stack.sub.194 = sub i32 0, %context.value.189
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.193, i32 %stack.sub.194)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.191)
  br label %entry.return.status
entry.return.status:
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  ret i32 %context.value.196
}


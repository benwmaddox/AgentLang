%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [8 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 7, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 8, i32 4, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 9, i32 6, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [8 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 8, ptr @al_owning_fields, i32 8 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 7
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 7, 7
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %descriptor.element.103 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 3
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 0
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 1
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 2
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 3
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 4
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %argument.type.valid.114 = icmp eq i32 %descriptor.value.105, 8
  br i1 %argument.type.valid.114, label %argument.type.ok.115, label %frame.failure.0
argument.type.ok.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.113, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.109, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 8, 8
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %descriptor.element.133 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 0
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 1
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 2
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 3
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 4
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %argument.type.valid.144 = icmp eq i32 %descriptor.value.135, 8
  br i1 %argument.type.valid.144, label %argument.type.ok.145, label %frame.failure.0
argument.type.ok.145:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.150 = sub i32 %descriptor.value.143, %descriptor.value.137
  %descriptor.owner.inside.148 = icmp ule i32 %descriptor.value.143, %context.value.147
  %descriptor.offset.inside.149 = icmp ule i32 %descriptor.value.137, %descriptor.value.143
  %descriptor.extent.inside.151 = icmp ule i32 %descriptor.value.139, %stack.sub.150
  %descriptor.payload.inside.152 = icmp ule i32 %descriptor.value.141, %descriptor.value.139
  %descriptor.owner.offset.valid.153 = and i1 %descriptor.owner.inside.148, %descriptor.offset.inside.149
  %descriptor.range.inside.155 = and i1 %descriptor.owner.offset.valid.153, %descriptor.extent.inside.151
  %descriptor.range.valid.154 = and i1 %descriptor.range.inside.155, %descriptor.payload.inside.152
  %descriptor.type.valid.156 = icmp eq i32 8, 8
  %descriptor.valid.157 = and i1 %descriptor.range.valid.154, %descriptor.type.valid.156
  br i1 %descriptor.valid.157, label %descriptor.valid.158, label %descriptor.invalid.159
descriptor.invalid.159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.158:
  %descriptor.initialized.status.160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.137, i32 %descriptor.value.139)
  %helper.ok.161 = icmp eq i32 %descriptor.initialized.status.160, 0
  br i1 %helper.ok.161, label %helper.continue.162, label %frame.failure.0
helper.continue.162:
  %descriptor.element.163 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 5
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 0
  %descriptor.value.165 = load i32, ptr %descriptor.field.164, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 1
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 2
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 3
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 4
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %argument.type.valid.174 = icmp eq i32 %descriptor.value.165, 9
  br i1 %argument.type.valid.174, label %argument.type.ok.175, label %frame.failure.0
argument.type.ok.175:
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %stack.sub.180 = sub i32 %descriptor.value.173, %descriptor.value.167
  %descriptor.owner.inside.178 = icmp ule i32 %descriptor.value.173, %context.value.177
  %descriptor.offset.inside.179 = icmp ule i32 %descriptor.value.167, %descriptor.value.173
  %descriptor.extent.inside.181 = icmp ule i32 %descriptor.value.169, %stack.sub.180
  %descriptor.payload.inside.182 = icmp ule i32 %descriptor.value.171, %descriptor.value.169
  %descriptor.owner.offset.valid.183 = and i1 %descriptor.owner.inside.178, %descriptor.offset.inside.179
  %descriptor.range.inside.185 = and i1 %descriptor.owner.offset.valid.183, %descriptor.extent.inside.181
  %descriptor.range.valid.184 = and i1 %descriptor.range.inside.185, %descriptor.payload.inside.182
  %descriptor.type.valid.186 = icmp eq i32 9, 9
  %descriptor.valid.187 = and i1 %descriptor.range.valid.184, %descriptor.type.valid.186
  br i1 %descriptor.valid.187, label %descriptor.valid.188, label %descriptor.invalid.189
descriptor.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.188:
  %descriptor.initialized.status.190 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.167, i32 %descriptor.value.169)
  %helper.ok.191 = icmp eq i32 %descriptor.initialized.status.190, 0
  br i1 %helper.ok.191, label %helper.continue.192, label %frame.failure.0
helper.continue.192:
  %descriptor.element.193 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 6
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 0
  %descriptor.value.195 = load i32, ptr %descriptor.field.194, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 1
  %descriptor.value.197 = load i32, ptr %descriptor.field.196, align 4
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 2
  %descriptor.value.199 = load i32, ptr %descriptor.field.198, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 3
  %descriptor.value.201 = load i32, ptr %descriptor.field.200, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 4
  %descriptor.value.203 = load i32, ptr %descriptor.field.202, align 4
  %argument.type.valid.204 = icmp eq i32 %descriptor.value.195, 9
  br i1 %argument.type.valid.204, label %argument.type.ok.205, label %frame.failure.0
argument.type.ok.205:
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.sub.210 = sub i32 %descriptor.value.203, %descriptor.value.197
  %descriptor.owner.inside.208 = icmp ule i32 %descriptor.value.203, %context.value.207
  %descriptor.offset.inside.209 = icmp ule i32 %descriptor.value.197, %descriptor.value.203
  %descriptor.extent.inside.211 = icmp ule i32 %descriptor.value.199, %stack.sub.210
  %descriptor.payload.inside.212 = icmp ule i32 %descriptor.value.201, %descriptor.value.199
  %descriptor.owner.offset.valid.213 = and i1 %descriptor.owner.inside.208, %descriptor.offset.inside.209
  %descriptor.range.inside.215 = and i1 %descriptor.owner.offset.valid.213, %descriptor.extent.inside.211
  %descriptor.range.valid.214 = and i1 %descriptor.range.inside.215, %descriptor.payload.inside.212
  %descriptor.type.valid.216 = icmp eq i32 9, 9
  %descriptor.valid.217 = and i1 %descriptor.range.valid.214, %descriptor.type.valid.216
  br i1 %descriptor.valid.217, label %descriptor.valid.218, label %descriptor.invalid.219
descriptor.invalid.219:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.218:
  %descriptor.initialized.status.220 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.197, i32 %descriptor.value.199)
  %helper.ok.221 = icmp eq i32 %descriptor.initialized.status.220, 0
  br i1 %helper.ok.221, label %helper.continue.222, label %frame.failure.0
helper.continue.222:
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %stack.sub.225 = sub i32 %context.value.224, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.225, i32 0, i32 0, i32 0)
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %runtime.ok.228 = icmp eq i32 %context.value.227, 0
  br i1 %runtime.ok.228, label %runtime.continue.229, label %frame.failure.0
runtime.continue.229:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  %descriptor.element.234 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.235 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 0
  store i32 5, ptr %descriptor.field.235, align 4
  %descriptor.field.236 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.236, align 4
  %descriptor.field.237 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.237, align 4
  %descriptor.field.238 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.238, align 4
  %descriptor.field.239 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.239, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.241 = load i32, ptr %context.field.240, align 4
  %runtime.ok.242 = icmp eq i32 %context.value.241, 0
  br i1 %runtime.ok.242, label %runtime.continue.243, label %frame.failure.0
runtime.continue.243:
  %descriptor.element.244 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 0
  store i32 7, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.247, align 4
  %descriptor.field.248 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.248, align 4
  %descriptor.field.249 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.249, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.251 = load i32, ptr %context.field.250, align 4
  %runtime.ok.252 = icmp eq i32 %context.value.251, 0
  br i1 %runtime.ok.252, label %runtime.continue.253, label %frame.failure.0
runtime.continue.253:
  %descriptor.element.254 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 2
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 0
  store i32 7, ptr %descriptor.field.255, align 4
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.258, align 4
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.259, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %runtime.ok.262 = icmp eq i32 %context.value.261, 0
  br i1 %runtime.ok.262, label %runtime.continue.263, label %frame.failure.0
runtime.continue.263:
  %descriptor.element.264 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 3
  %descriptor.field.265 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 0
  store i32 8, ptr %descriptor.field.265, align 4
  %descriptor.field.266 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 1
  store i32 %descriptor.value.107, ptr %descriptor.field.266, align 4
  %descriptor.field.267 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 2
  store i32 %descriptor.value.109, ptr %descriptor.field.267, align 4
  %descriptor.field.268 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 3
  store i32 %descriptor.value.111, ptr %descriptor.field.268, align 4
  %descriptor.field.269 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 4
  store i32 %descriptor.value.113, ptr %descriptor.field.269, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.271 = load i32, ptr %context.field.270, align 4
  %runtime.ok.272 = icmp eq i32 %context.value.271, 0
  br i1 %runtime.ok.272, label %runtime.continue.273, label %frame.failure.0
runtime.continue.273:
  %descriptor.element.274 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 4
  %descriptor.field.275 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 0
  store i32 8, ptr %descriptor.field.275, align 4
  %descriptor.field.276 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 1
  store i32 %descriptor.value.137, ptr %descriptor.field.276, align 4
  %descriptor.field.277 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 2
  store i32 %descriptor.value.139, ptr %descriptor.field.277, align 4
  %descriptor.field.278 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 3
  store i32 %descriptor.value.141, ptr %descriptor.field.278, align 4
  %descriptor.field.279 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 4
  store i32 %descriptor.value.143, ptr %descriptor.field.279, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.137, i32 20, i32 %descriptor.value.141, i32 %descriptor.value.143, i32 %descriptor.value.139)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %descriptor.element.284 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 5
  %descriptor.field.285 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 0
  store i32 9, ptr %descriptor.field.285, align 4
  %descriptor.field.286 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 1
  store i32 %descriptor.value.167, ptr %descriptor.field.286, align 4
  %descriptor.field.287 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 2
  store i32 %descriptor.value.169, ptr %descriptor.field.287, align 4
  %descriptor.field.288 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 3
  store i32 %descriptor.value.171, ptr %descriptor.field.288, align 4
  %descriptor.field.289 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 4
  store i32 %descriptor.value.173, ptr %descriptor.field.289, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.167, i32 20, i32 %descriptor.value.171, i32 %descriptor.value.173, i32 %descriptor.value.169)
  %context.field.290 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.291 = load i32, ptr %context.field.290, align 4
  %runtime.ok.292 = icmp eq i32 %context.value.291, 0
  br i1 %runtime.ok.292, label %runtime.continue.293, label %frame.failure.0
runtime.continue.293:
  %descriptor.element.294 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 6
  %descriptor.field.295 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 0
  store i32 9, ptr %descriptor.field.295, align 4
  %descriptor.field.296 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 1
  store i32 %descriptor.value.197, ptr %descriptor.field.296, align 4
  %descriptor.field.297 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 2
  store i32 %descriptor.value.199, ptr %descriptor.field.297, align 4
  %descriptor.field.298 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 3
  store i32 %descriptor.value.201, ptr %descriptor.field.298, align 4
  %descriptor.field.299 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 4
  store i32 %descriptor.value.203, ptr %descriptor.field.299, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.197, i32 20, i32 %descriptor.value.201, i32 %descriptor.value.203, i32 %descriptor.value.199)
  %context.field.300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.301 = load i32, ptr %context.field.300, align 4
  %runtime.ok.302 = icmp eq i32 %context.value.301, 0
  br i1 %runtime.ok.302, label %runtime.continue.303, label %frame.failure.0
runtime.continue.303:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.305 = load i32, ptr %context.field.304, align 4
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %stack.offset.310 = add i32 %context.value.5, %context.value.7
  %stack.offset.311 = add i32 %context.value.305, %context.value.307
  %stack.sub.312 = sub i32 %stack.offset.310, %stack.offset.311
  %stack.sub.313 = sub i32 %context.value.7, %context.value.307
  %stack.sub.314 = sub i32 %context.value.309, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.312, i32 %stack.sub.313)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.314)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 3, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 4)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 6)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 9)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 7
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 7, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 7, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [7 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 10, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 10, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 10, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.extent.pointer.37 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.38 = load i32, ptr %input.extent.pointer.37, align 4
  %stack.sub.39 = sub i32 %input.bytes, %stack.offset.36
  %input.offset.within.bytes.40 = icmp ule i32 %stack.offset.36, %input.bytes
  %input.extent.within.bytes.41 = icmp ule i32 %input.host.extent.38, %stack.sub.39
  %input.slice.within.bytes.42 = and i1 %input.offset.within.bytes.40, %input.extent.within.bytes.41
  br i1 %input.slice.within.bytes.42, label %input.slice.ready.43, label %input.slice.invalid.44
input.slice.invalid.44:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.43:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.payload.pointer.46 = alloca i32, align 4
  %input.measured.extent.pointer.47 = alloca i32, align 4
  %input.measure.status.48 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.45, i32 %input.host.extent.38, i32 0, i32 11, ptr %input.payload.pointer.46, ptr %input.measured.extent.pointer.47)
  %helper.ok.49 = icmp eq i32 %input.measure.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %entry.failure.0
helper.continue.50:
  %input.measured.payload.51 = load i32, ptr %input.payload.pointer.46, align 4
  %input.measured.extent.52 = load i32, ptr %input.measured.extent.pointer.47, align 4
  %input.extent.exact.53 = icmp eq i32 %input.measured.extent.52, %input.host.extent.38
  br i1 %input.extent.exact.53, label %input.extent.exact.54, label %input.extent.invalid.55
input.extent.invalid.55:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 %input.measured.extent.52, i32 %input.host.extent.38)
  br label %entry.failure.0
input.extent.exact.54:
  %stack.offset.56 = add i32 %stack.offset.36, %input.host.extent.38
  %input.extent.pointer.57 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.58 = load i32, ptr %input.extent.pointer.57, align 4
  %stack.sub.59 = sub i32 %input.bytes, %stack.offset.56
  %input.offset.within.bytes.60 = icmp ule i32 %stack.offset.56, %input.bytes
  %input.extent.within.bytes.61 = icmp ule i32 %input.host.extent.58, %stack.sub.59
  %input.slice.within.bytes.62 = and i1 %input.offset.within.bytes.60, %input.extent.within.bytes.61
  br i1 %input.slice.within.bytes.62, label %input.slice.ready.63, label %input.slice.invalid.64
input.slice.invalid.64:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 12, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.63:
  %host.pointer.65 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.56
  %input.payload.pointer.66 = alloca i32, align 4
  %input.measured.extent.pointer.67 = alloca i32, align 4
  %input.measure.status.68 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.65, i32 %input.host.extent.58, i32 0, i32 12, ptr %input.payload.pointer.66, ptr %input.measured.extent.pointer.67)
  %helper.ok.69 = icmp eq i32 %input.measure.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %entry.failure.0
helper.continue.70:
  %input.measured.payload.71 = load i32, ptr %input.payload.pointer.66, align 4
  %input.measured.extent.72 = load i32, ptr %input.measured.extent.pointer.67, align 4
  %input.extent.exact.73 = icmp eq i32 %input.measured.extent.72, %input.host.extent.58
  br i1 %input.extent.exact.73, label %input.extent.exact.74, label %input.extent.invalid.75
input.extent.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 12, i32 %input.measured.extent.72, i32 %input.host.extent.58)
  br label %entry.failure.0
input.extent.exact.74:
  %stack.offset.76 = add i32 %stack.offset.56, %input.host.extent.58
  %input.extent.pointer.77 = getelementptr inbounds i32, ptr %input.extents, i32 3
  %input.host.extent.78 = load i32, ptr %input.extent.pointer.77, align 4
  %stack.sub.79 = sub i32 %input.bytes, %stack.offset.76
  %input.offset.within.bytes.80 = icmp ule i32 %stack.offset.76, %input.bytes
  %input.extent.within.bytes.81 = icmp ule i32 %input.host.extent.78, %stack.sub.79
  %input.slice.within.bytes.82 = and i1 %input.offset.within.bytes.80, %input.extent.within.bytes.81
  br i1 %input.slice.within.bytes.82, label %input.slice.ready.83, label %input.slice.invalid.84
input.slice.invalid.84:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 13, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.83:
  %host.pointer.85 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.76
  %input.payload.pointer.86 = alloca i32, align 4
  %input.measured.extent.pointer.87 = alloca i32, align 4
  %input.measure.status.88 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 6, ptr %host.pointer.85, i32 %input.host.extent.78, i32 0, i32 13, ptr %input.payload.pointer.86, ptr %input.measured.extent.pointer.87)
  %helper.ok.89 = icmp eq i32 %input.measure.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %input.measured.payload.91 = load i32, ptr %input.payload.pointer.86, align 4
  %input.measured.extent.92 = load i32, ptr %input.measured.extent.pointer.87, align 4
  %input.extent.exact.93 = icmp eq i32 %input.measured.extent.92, %input.host.extent.78
  br i1 %input.extent.exact.93, label %input.extent.exact.94, label %input.extent.invalid.95
input.extent.invalid.95:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 13, i32 %input.measured.extent.92, i32 %input.host.extent.78)
  br label %entry.failure.0
input.extent.exact.94:
  %stack.offset.96 = add i32 %stack.offset.76, %input.host.extent.78
  %input.extent.pointer.97 = getelementptr inbounds i32, ptr %input.extents, i32 4
  %input.host.extent.98 = load i32, ptr %input.extent.pointer.97, align 4
  %stack.sub.99 = sub i32 %input.bytes, %stack.offset.96
  %input.offset.within.bytes.100 = icmp ule i32 %stack.offset.96, %input.bytes
  %input.extent.within.bytes.101 = icmp ule i32 %input.host.extent.98, %stack.sub.99
  %input.slice.within.bytes.102 = and i1 %input.offset.within.bytes.100, %input.extent.within.bytes.101
  br i1 %input.slice.within.bytes.102, label %input.slice.ready.103, label %input.slice.invalid.104
input.slice.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 14, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.103:
  %host.pointer.105 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.96
  %input.payload.pointer.106 = alloca i32, align 4
  %input.measured.extent.pointer.107 = alloca i32, align 4
  %input.measure.status.108 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 6, ptr %host.pointer.105, i32 %input.host.extent.98, i32 0, i32 14, ptr %input.payload.pointer.106, ptr %input.measured.extent.pointer.107)
  %helper.ok.109 = icmp eq i32 %input.measure.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %entry.failure.0
helper.continue.110:
  %input.measured.payload.111 = load i32, ptr %input.payload.pointer.106, align 4
  %input.measured.extent.112 = load i32, ptr %input.measured.extent.pointer.107, align 4
  %input.extent.exact.113 = icmp eq i32 %input.measured.extent.112, %input.host.extent.98
  br i1 %input.extent.exact.113, label %input.extent.exact.114, label %input.extent.invalid.115
input.extent.invalid.115:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 14, i32 %input.measured.extent.112, i32 %input.host.extent.98)
  br label %entry.failure.0
input.extent.exact.114:
  %stack.offset.116 = add i32 %stack.offset.96, %input.host.extent.98
  %input.extent.pointer.117 = getelementptr inbounds i32, ptr %input.extents, i32 5
  %input.host.extent.118 = load i32, ptr %input.extent.pointer.117, align 4
  %stack.sub.119 = sub i32 %input.bytes, %stack.offset.116
  %input.offset.within.bytes.120 = icmp ule i32 %stack.offset.116, %input.bytes
  %input.extent.within.bytes.121 = icmp ule i32 %input.host.extent.118, %stack.sub.119
  %input.slice.within.bytes.122 = and i1 %input.offset.within.bytes.120, %input.extent.within.bytes.121
  br i1 %input.slice.within.bytes.122, label %input.slice.ready.123, label %input.slice.invalid.124
input.slice.invalid.124:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.123:
  %host.pointer.125 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.116
  %input.payload.pointer.126 = alloca i32, align 4
  %input.measured.extent.pointer.127 = alloca i32, align 4
  %input.measure.status.128 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 7, ptr %host.pointer.125, i32 %input.host.extent.118, i32 0, i32 15, ptr %input.payload.pointer.126, ptr %input.measured.extent.pointer.127)
  %helper.ok.129 = icmp eq i32 %input.measure.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %entry.failure.0
helper.continue.130:
  %input.measured.payload.131 = load i32, ptr %input.payload.pointer.126, align 4
  %input.measured.extent.132 = load i32, ptr %input.measured.extent.pointer.127, align 4
  %input.extent.exact.133 = icmp eq i32 %input.measured.extent.132, %input.host.extent.118
  br i1 %input.extent.exact.133, label %input.extent.exact.134, label %input.extent.invalid.135
input.extent.invalid.135:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 %input.measured.extent.132, i32 %input.host.extent.118)
  br label %entry.failure.0
input.extent.exact.134:
  %stack.offset.136 = add i32 %stack.offset.116, %input.host.extent.118
  %input.extent.pointer.137 = getelementptr inbounds i32, ptr %input.extents, i32 6
  %input.host.extent.138 = load i32, ptr %input.extent.pointer.137, align 4
  %stack.sub.139 = sub i32 %input.bytes, %stack.offset.136
  %input.offset.within.bytes.140 = icmp ule i32 %stack.offset.136, %input.bytes
  %input.extent.within.bytes.141 = icmp ule i32 %input.host.extent.138, %stack.sub.139
  %input.slice.within.bytes.142 = and i1 %input.offset.within.bytes.140, %input.extent.within.bytes.141
  br i1 %input.slice.within.bytes.142, label %input.slice.ready.143, label %input.slice.invalid.144
input.slice.invalid.144:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 16, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.143:
  %host.pointer.145 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.136
  %input.payload.pointer.146 = alloca i32, align 4
  %input.measured.extent.pointer.147 = alloca i32, align 4
  %input.measure.status.148 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 7, ptr %host.pointer.145, i32 %input.host.extent.138, i32 0, i32 16, ptr %input.payload.pointer.146, ptr %input.measured.extent.pointer.147)
  %helper.ok.149 = icmp eq i32 %input.measure.status.148, 0
  br i1 %helper.ok.149, label %helper.continue.150, label %entry.failure.0
helper.continue.150:
  %input.measured.payload.151 = load i32, ptr %input.payload.pointer.146, align 4
  %input.measured.extent.152 = load i32, ptr %input.measured.extent.pointer.147, align 4
  %input.extent.exact.153 = icmp eq i32 %input.measured.extent.152, %input.host.extent.138
  br i1 %input.extent.exact.153, label %input.extent.exact.154, label %input.extent.invalid.155
input.extent.invalid.155:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 16, i32 %input.measured.extent.152, i32 %input.host.extent.138)
  br label %entry.failure.0
input.extent.exact.154:
  %stack.offset.156 = add i32 %stack.offset.136, %input.host.extent.138
  %input.total.exact.157 = icmp eq i32 %stack.offset.156, %input.bytes
  br i1 %input.total.exact.157, label %input.valid.158, label %input.invalid.159
input.invalid.159:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.156, i32 %input.bytes)
  br label %entry.failure.0
input.valid.158:
  %reserve.status.160 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.156, i32 17)
  %reserve.ok.161 = icmp eq i32 %reserve.status.160, 0
  br i1 %reserve.ok.161, label %reserve.continue.162, label %entry.failure.0
reserve.continue.162:
  %host.pointer.163 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.164 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.163, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 5, i32 18)
  %helper.ok.165 = icmp eq i32 %input.copy.status.164, 0
  br i1 %helper.ok.165, label %helper.continue.166, label %entry.failure.0
helper.continue.166:
  %stack.offset.167 = add i32 0, %input.host.extent.18
  %descriptor.element.168 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.169 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.168, i32 0, i32 0
  store i32 5, ptr %descriptor.field.169, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.168, i32 0, i32 1
  store i32 0, ptr %descriptor.field.170, align 4
  %descriptor.field.171 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.168, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.171, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.168, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.172, align 4
  %descriptor.field.173 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.168, i32 0, i32 4
  store i32 %stack.offset.167, ptr %descriptor.field.173, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.167, i32 %input.host.extent.18)
  %context.field.174 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.175 = load i32, ptr %context.field.174, align 4
  %runtime.ok.176 = icmp eq i32 %context.value.175, 0
  br i1 %runtime.ok.176, label %runtime.continue.177, label %entry.failure.0
runtime.continue.177:
  %host.pointer.178 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.copy.status.179 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.36, ptr %host.pointer.178, i32 %input.host.extent.38, i32 0, i32 %input.measured.payload.51, i32 %input.host.extent.38, i32 7, i32 19)
  %helper.ok.180 = icmp eq i32 %input.copy.status.179, 0
  br i1 %helper.ok.180, label %helper.continue.181, label %entry.failure.0
helper.continue.181:
  %stack.offset.182 = add i32 %stack.offset.36, %input.host.extent.38
  %descriptor.element.183 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 1
  %descriptor.field.184 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.183, i32 0, i32 0
  store i32 7, ptr %descriptor.field.184, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.183, i32 0, i32 1
  store i32 %stack.offset.36, ptr %descriptor.field.185, align 4
  %descriptor.field.186 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.183, i32 0, i32 2
  store i32 %input.host.extent.38, ptr %descriptor.field.186, align 4
  %descriptor.field.187 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.183, i32 0, i32 3
  store i32 %input.measured.payload.51, ptr %descriptor.field.187, align 4
  %descriptor.field.188 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.183, i32 0, i32 4
  store i32 %stack.offset.182, ptr %descriptor.field.188, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.36, i32 20, i32 %input.measured.payload.51, i32 %stack.offset.182, i32 %input.host.extent.38)
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %runtime.ok.191 = icmp eq i32 %context.value.190, 0
  br i1 %runtime.ok.191, label %runtime.continue.192, label %entry.failure.0
runtime.continue.192:
  %host.pointer.193 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.56
  %input.copy.status.194 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.56, ptr %host.pointer.193, i32 %input.host.extent.58, i32 0, i32 %input.measured.payload.71, i32 %input.host.extent.58, i32 7, i32 20)
  %helper.ok.195 = icmp eq i32 %input.copy.status.194, 0
  br i1 %helper.ok.195, label %helper.continue.196, label %entry.failure.0
helper.continue.196:
  %stack.offset.197 = add i32 %stack.offset.56, %input.host.extent.58
  %descriptor.element.198 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 2
  %descriptor.field.199 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.198, i32 0, i32 0
  store i32 7, ptr %descriptor.field.199, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.198, i32 0, i32 1
  store i32 %stack.offset.56, ptr %descriptor.field.200, align 4
  %descriptor.field.201 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.198, i32 0, i32 2
  store i32 %input.host.extent.58, ptr %descriptor.field.201, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.198, i32 0, i32 3
  store i32 %input.measured.payload.71, ptr %descriptor.field.202, align 4
  %descriptor.field.203 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.198, i32 0, i32 4
  store i32 %stack.offset.197, ptr %descriptor.field.203, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.56, i32 20, i32 %input.measured.payload.71, i32 %stack.offset.197, i32 %input.host.extent.58)
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %runtime.ok.206 = icmp eq i32 %context.value.205, 0
  br i1 %runtime.ok.206, label %runtime.continue.207, label %entry.failure.0
runtime.continue.207:
  %host.pointer.208 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.76
  %input.copy.status.209 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.76, ptr %host.pointer.208, i32 %input.host.extent.78, i32 0, i32 %input.measured.payload.91, i32 %input.host.extent.78, i32 8, i32 21)
  %helper.ok.210 = icmp eq i32 %input.copy.status.209, 0
  br i1 %helper.ok.210, label %helper.continue.211, label %entry.failure.0
helper.continue.211:
  %stack.offset.212 = add i32 %stack.offset.76, %input.host.extent.78
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 3
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 8, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %stack.offset.76, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %input.host.extent.78, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %input.measured.payload.91, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %stack.offset.212, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %stack.offset.76, i32 20, i32 %input.measured.payload.91, i32 %stack.offset.212, i32 %input.host.extent.78)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %entry.failure.0
runtime.continue.222:
  %host.pointer.223 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.96
  %input.copy.status.224 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.96, ptr %host.pointer.223, i32 %input.host.extent.98, i32 0, i32 %input.measured.payload.111, i32 %input.host.extent.98, i32 8, i32 22)
  %helper.ok.225 = icmp eq i32 %input.copy.status.224, 0
  br i1 %helper.ok.225, label %helper.continue.226, label %entry.failure.0
helper.continue.226:
  %stack.offset.227 = add i32 %stack.offset.96, %input.host.extent.98
  %descriptor.element.228 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 4
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 0
  store i32 8, ptr %descriptor.field.229, align 4
  %descriptor.field.230 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 1
  store i32 %stack.offset.96, ptr %descriptor.field.230, align 4
  %descriptor.field.231 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 2
  store i32 %input.host.extent.98, ptr %descriptor.field.231, align 4
  %descriptor.field.232 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 3
  store i32 %input.measured.payload.111, ptr %descriptor.field.232, align 4
  %descriptor.field.233 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.228, i32 0, i32 4
  store i32 %stack.offset.227, ptr %descriptor.field.233, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %stack.offset.96, i32 20, i32 %input.measured.payload.111, i32 %stack.offset.227, i32 %input.host.extent.98)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %entry.failure.0
runtime.continue.237:
  %host.pointer.238 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.116
  %input.copy.status.239 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.116, ptr %host.pointer.238, i32 %input.host.extent.118, i32 0, i32 %input.measured.payload.131, i32 %input.host.extent.118, i32 9, i32 23)
  %helper.ok.240 = icmp eq i32 %input.copy.status.239, 0
  br i1 %helper.ok.240, label %helper.continue.241, label %entry.failure.0
helper.continue.241:
  %stack.offset.242 = add i32 %stack.offset.116, %input.host.extent.118
  %descriptor.element.243 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 5
  %descriptor.field.244 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 0
  store i32 9, ptr %descriptor.field.244, align 4
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 1
  store i32 %stack.offset.116, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 2
  store i32 %input.host.extent.118, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 3
  store i32 %input.measured.payload.131, ptr %descriptor.field.247, align 4
  %descriptor.field.248 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 4
  store i32 %stack.offset.242, ptr %descriptor.field.248, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %stack.offset.116, i32 20, i32 %input.measured.payload.131, i32 %stack.offset.242, i32 %input.host.extent.118)
  %context.field.249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.250 = load i32, ptr %context.field.249, align 4
  %runtime.ok.251 = icmp eq i32 %context.value.250, 0
  br i1 %runtime.ok.251, label %runtime.continue.252, label %entry.failure.0
runtime.continue.252:
  %host.pointer.253 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.136
  %input.copy.status.254 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.136, ptr %host.pointer.253, i32 %input.host.extent.138, i32 0, i32 %input.measured.payload.151, i32 %input.host.extent.138, i32 9, i32 24)
  %helper.ok.255 = icmp eq i32 %input.copy.status.254, 0
  br i1 %helper.ok.255, label %helper.continue.256, label %entry.failure.0
helper.continue.256:
  %stack.offset.257 = add i32 %stack.offset.136, %input.host.extent.138
  %descriptor.element.258 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 6
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 0
  store i32 9, ptr %descriptor.field.259, align 4
  %descriptor.field.260 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 1
  store i32 %stack.offset.136, ptr %descriptor.field.260, align 4
  %descriptor.field.261 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 2
  store i32 %input.host.extent.138, ptr %descriptor.field.261, align 4
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 3
  store i32 %input.measured.payload.151, ptr %descriptor.field.262, align 4
  %descriptor.field.263 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 4
  store i32 %stack.offset.257, ptr %descriptor.field.263, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %stack.offset.136, i32 20, i32 %input.measured.payload.151, i32 %stack.offset.257, i32 %input.host.extent.138)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %runtime.ok.266 = icmp eq i32 %context.value.265, 0
  br i1 %runtime.ok.266, label %runtime.continue.267, label %entry.failure.0
runtime.continue.267:
  %entry.validation.frame.entered.268 = call i32 @al_owning_enter_frame(ptr %ctx, i32 25)
  %helper.ok.269 = icmp eq i32 %entry.validation.frame.entered.268, 0
  br i1 %helper.ok.269, label %helper.continue.270, label %entry.failure.0
helper.continue.270:
  %stack.offset.271 = add i32 0, %input.host.extent.18
  %input.field.location.272 = alloca %AlOwningFieldLocation, align 4
  %input.field.status.273 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 0, i32 %input.host.extent.18, i32 0, i32 26, ptr %input.field.location.272)
  %helper.ok.274 = icmp eq i32 %input.field.status.273, 0
  br i1 %helper.ok.274, label %helper.continue.275, label %entry.validation.failure.3
helper.continue.275:
  %input.field.offset.pointer.276 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.272, i32 0, i32 0
  %input.field.offset.277 = load i32, ptr %input.field.offset.pointer.276, align 4
  %input.field.payload.pointer.278 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.272, i32 0, i32 1
  %input.field.payload.279 = load i32, ptr %input.field.payload.pointer.278, align 4
  %input.field.extent.pointer.280 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.272, i32 0, i32 2
  %input.field.extent.281 = load i32, ptr %input.field.extent.pointer.280, align 4
  %validator.arguments.282 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.283 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.282, i32 0
  %descriptor.field.284 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.283, i32 0, i32 0
  store i32 6, ptr %descriptor.field.284, align 4
  %descriptor.field.285 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.283, i32 0, i32 1
  store i32 %input.field.offset.277, ptr %descriptor.field.285, align 4
  %descriptor.field.286 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.283, i32 0, i32 2
  store i32 %input.field.extent.281, ptr %descriptor.field.286, align 4
  %descriptor.field.287 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.283, i32 0, i32 3
  store i32 %input.field.payload.279, ptr %descriptor.field.287, align 4
  %descriptor.field.288 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.283, i32 0, i32 4
  store i32 %stack.offset.271, ptr %descriptor.field.288, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.field.offset.277, i32 20, i32 %input.field.payload.279, i32 %stack.offset.271, i32 %input.field.extent.281)
  %context.field.289 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.290 = load i32, ptr %context.field.289, align 4
  %runtime.ok.291 = icmp eq i32 %context.value.290, 0
  br i1 %runtime.ok.291, label %runtime.continue.292, label %entry.validation.failure.3
runtime.continue.292:
  %validator.results.293 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.294 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.282, ptr %validator.results.293, i32 29)
  %helper.ok.295 = icmp eq i32 %validator.status.294, 0
  br i1 %helper.ok.295, label %helper.continue.296, label %entry.validation.failure.3
helper.continue.296:
  %descriptor.element.297 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.293, i32 0
  %descriptor.field.298 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.297, i32 0, i32 0
  %descriptor.value.299 = load i32, ptr %descriptor.field.298, align 4
  %descriptor.field.300 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.297, i32 0, i32 1
  %descriptor.value.301 = load i32, ptr %descriptor.field.300, align 4
  %descriptor.field.302 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.297, i32 0, i32 2
  %descriptor.value.303 = load i32, ptr %descriptor.field.302, align 4
  %descriptor.field.304 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.297, i32 0, i32 3
  %descriptor.value.305 = load i32, ptr %descriptor.field.304, align 4
  %descriptor.field.306 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.297, i32 0, i32 4
  %descriptor.value.307 = load i32, ptr %descriptor.field.306, align 4
  %validator.result.type.matches.308 = icmp eq i32 %descriptor.value.299, 2
  br i1 %validator.result.type.matches.308, label %validator.result.type.ok.309, label %validator.result.type.invalid.310
validator.result.type.invalid.310:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 28, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.309:
  %context.field.311 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.312 = load i32, ptr %context.field.311, align 4
  %stack.sub.315 = sub i32 %descriptor.value.307, %descriptor.value.301
  %descriptor.owner.inside.313 = icmp ule i32 %descriptor.value.307, %context.value.312
  %descriptor.offset.inside.314 = icmp ule i32 %descriptor.value.301, %descriptor.value.307
  %descriptor.extent.inside.316 = icmp ule i32 %descriptor.value.303, %stack.sub.315
  %descriptor.payload.inside.317 = icmp ule i32 %descriptor.value.305, %descriptor.value.303
  %descriptor.owner.offset.valid.318 = and i1 %descriptor.owner.inside.313, %descriptor.offset.inside.314
  %descriptor.range.inside.320 = and i1 %descriptor.owner.offset.valid.318, %descriptor.extent.inside.316
  %descriptor.range.valid.319 = and i1 %descriptor.range.inside.320, %descriptor.payload.inside.317
  %descriptor.type.valid.321 = icmp eq i32 2, 2
  %descriptor.valid.322 = and i1 %descriptor.range.valid.319, %descriptor.type.valid.321
  br i1 %descriptor.valid.322, label %descriptor.valid.323, label %descriptor.invalid.324
descriptor.invalid.324:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.323:
  %descriptor.initialized.status.325 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.301, i32 %descriptor.value.303)
  %helper.ok.326 = icmp eq i32 %descriptor.initialized.status.325, 0
  br i1 %helper.ok.326, label %helper.continue.327, label %entry.validation.failure.3
helper.continue.327:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.301, i32 20, i32 %descriptor.value.305, i32 %descriptor.value.307, i32 %descriptor.value.303)
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %runtime.ok.330 = icmp eq i32 %context.value.329, 0
  br i1 %runtime.ok.330, label %runtime.continue.331, label %entry.validation.failure.3
runtime.continue.331:
  %validator.bool.332 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.301)
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %runtime.ok.335 = icmp eq i32 %context.value.334, 0
  br i1 %runtime.ok.335, label %runtime.continue.336, label %entry.validation.failure.3
runtime.continue.336:
  %validator.bool.true.337 = icmp eq i64 %validator.bool.332, 1
  %validator.bool.false.338 = icmp eq i64 %validator.bool.332, 0
  %validator.bool.valid.339 = or i1 %validator.bool.true.337, %validator.bool.false.338
  br i1 %validator.bool.valid.339, label %validator.bool.check.340, label %validator.bool.invalid.341
validator.bool.invalid.341:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 28, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.340:
  br i1 %validator.bool.true.337, label %validator.true.343, label %validator.false.342
validator.false.342:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 27, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.343:
  br label %validator.join.344
validator.join.344:
  %stack.offset.345 = add i32 %stack.offset.36, %input.host.extent.38
  %input.option.case.346 = alloca i32, align 4
  %input.option.location.347 = alloca %AlOwningFieldLocation, align 4
  %input.option.status.348 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 5, i32 %stack.offset.36, i32 %input.host.extent.38, i32 30, ptr %input.option.case.346, ptr %input.option.location.347)
  %helper.ok.349 = icmp eq i32 %input.option.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %entry.validation.failure.3
helper.continue.350:
  %input.option.tag.351 = load i32, ptr %input.option.case.346, align 4
  %input.option.is.some.352 = icmp eq i32 %input.option.tag.351, 0
  br i1 %input.option.is.some.352, label %input.option.some.353, label %input.option.validated.354
input.option.some.353:
  %input.option.offset.pointer.355 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.347, i32 0, i32 0
  %input.option.offset.356 = load i32, ptr %input.option.offset.pointer.355, align 4
  %input.option.payload.pointer.357 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.347, i32 0, i32 1
  %input.option.payload.358 = load i32, ptr %input.option.payload.pointer.357, align 4
  %input.option.extent.pointer.359 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.347, i32 0, i32 2
  %input.option.extent.360 = load i32, ptr %input.option.extent.pointer.359, align 4
  %validator.arguments.361 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.362 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.361, i32 0
  %descriptor.field.363 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.362, i32 0, i32 0
  store i32 6, ptr %descriptor.field.363, align 4
  %descriptor.field.364 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.362, i32 0, i32 1
  store i32 %input.option.offset.356, ptr %descriptor.field.364, align 4
  %descriptor.field.365 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.362, i32 0, i32 2
  store i32 %input.option.extent.360, ptr %descriptor.field.365, align 4
  %descriptor.field.366 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.362, i32 0, i32 3
  store i32 %input.option.payload.358, ptr %descriptor.field.366, align 4
  %descriptor.field.367 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.362, i32 0, i32 4
  store i32 %stack.offset.345, ptr %descriptor.field.367, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.option.offset.356, i32 20, i32 %input.option.payload.358, i32 %stack.offset.345, i32 %input.option.extent.360)
  %context.field.368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.369 = load i32, ptr %context.field.368, align 4
  %runtime.ok.370 = icmp eq i32 %context.value.369, 0
  br i1 %runtime.ok.370, label %runtime.continue.371, label %entry.validation.failure.3
runtime.continue.371:
  %validator.results.372 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.373 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.361, ptr %validator.results.372, i32 33)
  %helper.ok.374 = icmp eq i32 %validator.status.373, 0
  br i1 %helper.ok.374, label %helper.continue.375, label %entry.validation.failure.3
helper.continue.375:
  %descriptor.element.376 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.372, i32 0
  %descriptor.field.377 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.376, i32 0, i32 0
  %descriptor.value.378 = load i32, ptr %descriptor.field.377, align 4
  %descriptor.field.379 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.376, i32 0, i32 1
  %descriptor.value.380 = load i32, ptr %descriptor.field.379, align 4
  %descriptor.field.381 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.376, i32 0, i32 2
  %descriptor.value.382 = load i32, ptr %descriptor.field.381, align 4
  %descriptor.field.383 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.376, i32 0, i32 3
  %descriptor.value.384 = load i32, ptr %descriptor.field.383, align 4
  %descriptor.field.385 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.376, i32 0, i32 4
  %descriptor.value.386 = load i32, ptr %descriptor.field.385, align 4
  %validator.result.type.matches.387 = icmp eq i32 %descriptor.value.378, 2
  br i1 %validator.result.type.matches.387, label %validator.result.type.ok.388, label %validator.result.type.invalid.389
validator.result.type.invalid.389:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 32, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.388:
  %context.field.390 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.391 = load i32, ptr %context.field.390, align 4
  %stack.sub.394 = sub i32 %descriptor.value.386, %descriptor.value.380
  %descriptor.owner.inside.392 = icmp ule i32 %descriptor.value.386, %context.value.391
  %descriptor.offset.inside.393 = icmp ule i32 %descriptor.value.380, %descriptor.value.386
  %descriptor.extent.inside.395 = icmp ule i32 %descriptor.value.382, %stack.sub.394
  %descriptor.payload.inside.396 = icmp ule i32 %descriptor.value.384, %descriptor.value.382
  %descriptor.owner.offset.valid.397 = and i1 %descriptor.owner.inside.392, %descriptor.offset.inside.393
  %descriptor.range.inside.399 = and i1 %descriptor.owner.offset.valid.397, %descriptor.extent.inside.395
  %descriptor.range.valid.398 = and i1 %descriptor.range.inside.399, %descriptor.payload.inside.396
  %descriptor.type.valid.400 = icmp eq i32 2, 2
  %descriptor.valid.401 = and i1 %descriptor.range.valid.398, %descriptor.type.valid.400
  br i1 %descriptor.valid.401, label %descriptor.valid.402, label %descriptor.invalid.403
descriptor.invalid.403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.402:
  %descriptor.initialized.status.404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.380, i32 %descriptor.value.382)
  %helper.ok.405 = icmp eq i32 %descriptor.initialized.status.404, 0
  br i1 %helper.ok.405, label %helper.continue.406, label %entry.validation.failure.3
helper.continue.406:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.380, i32 20, i32 %descriptor.value.384, i32 %descriptor.value.386, i32 %descriptor.value.382)
  %context.field.407 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.408 = load i32, ptr %context.field.407, align 4
  %runtime.ok.409 = icmp eq i32 %context.value.408, 0
  br i1 %runtime.ok.409, label %runtime.continue.410, label %entry.validation.failure.3
runtime.continue.410:
  %validator.bool.411 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.380)
  %context.field.412 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.413 = load i32, ptr %context.field.412, align 4
  %runtime.ok.414 = icmp eq i32 %context.value.413, 0
  br i1 %runtime.ok.414, label %runtime.continue.415, label %entry.validation.failure.3
runtime.continue.415:
  %validator.bool.true.416 = icmp eq i64 %validator.bool.411, 1
  %validator.bool.false.417 = icmp eq i64 %validator.bool.411, 0
  %validator.bool.valid.418 = or i1 %validator.bool.true.416, %validator.bool.false.417
  br i1 %validator.bool.valid.418, label %validator.bool.check.419, label %validator.bool.invalid.420
validator.bool.invalid.420:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 32, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.419:
  br i1 %validator.bool.true.416, label %validator.true.422, label %validator.false.421
validator.false.421:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 31, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.422:
  br label %validator.join.423
validator.join.423:
  br label %input.option.validated.354
input.option.validated.354:
  %stack.offset.424 = add i32 %stack.offset.56, %input.host.extent.58
  %input.option.case.425 = alloca i32, align 4
  %input.option.location.426 = alloca %AlOwningFieldLocation, align 4
  %input.option.status.427 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 5, i32 %stack.offset.56, i32 %input.host.extent.58, i32 34, ptr %input.option.case.425, ptr %input.option.location.426)
  %helper.ok.428 = icmp eq i32 %input.option.status.427, 0
  br i1 %helper.ok.428, label %helper.continue.429, label %entry.validation.failure.3
helper.continue.429:
  %input.option.tag.430 = load i32, ptr %input.option.case.425, align 4
  %input.option.is.some.431 = icmp eq i32 %input.option.tag.430, 0
  br i1 %input.option.is.some.431, label %input.option.some.432, label %input.option.validated.433
input.option.some.432:
  %input.option.offset.pointer.434 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.426, i32 0, i32 0
  %input.option.offset.435 = load i32, ptr %input.option.offset.pointer.434, align 4
  %input.option.payload.pointer.436 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.426, i32 0, i32 1
  %input.option.payload.437 = load i32, ptr %input.option.payload.pointer.436, align 4
  %input.option.extent.pointer.438 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.426, i32 0, i32 2
  %input.option.extent.439 = load i32, ptr %input.option.extent.pointer.438, align 4
  %validator.arguments.440 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.441 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.440, i32 0
  %descriptor.field.442 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.441, i32 0, i32 0
  store i32 6, ptr %descriptor.field.442, align 4
  %descriptor.field.443 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.441, i32 0, i32 1
  store i32 %input.option.offset.435, ptr %descriptor.field.443, align 4
  %descriptor.field.444 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.441, i32 0, i32 2
  store i32 %input.option.extent.439, ptr %descriptor.field.444, align 4
  %descriptor.field.445 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.441, i32 0, i32 3
  store i32 %input.option.payload.437, ptr %descriptor.field.445, align 4
  %descriptor.field.446 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.441, i32 0, i32 4
  store i32 %stack.offset.424, ptr %descriptor.field.446, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.option.offset.435, i32 20, i32 %input.option.payload.437, i32 %stack.offset.424, i32 %input.option.extent.439)
  %context.field.447 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.448 = load i32, ptr %context.field.447, align 4
  %runtime.ok.449 = icmp eq i32 %context.value.448, 0
  br i1 %runtime.ok.449, label %runtime.continue.450, label %entry.validation.failure.3
runtime.continue.450:
  %validator.results.451 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.452 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.440, ptr %validator.results.451, i32 37)
  %helper.ok.453 = icmp eq i32 %validator.status.452, 0
  br i1 %helper.ok.453, label %helper.continue.454, label %entry.validation.failure.3
helper.continue.454:
  %descriptor.element.455 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.451, i32 0
  %descriptor.field.456 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 0
  %descriptor.value.457 = load i32, ptr %descriptor.field.456, align 4
  %descriptor.field.458 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 1
  %descriptor.value.459 = load i32, ptr %descriptor.field.458, align 4
  %descriptor.field.460 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 2
  %descriptor.value.461 = load i32, ptr %descriptor.field.460, align 4
  %descriptor.field.462 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 3
  %descriptor.value.463 = load i32, ptr %descriptor.field.462, align 4
  %descriptor.field.464 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 4
  %descriptor.value.465 = load i32, ptr %descriptor.field.464, align 4
  %validator.result.type.matches.466 = icmp eq i32 %descriptor.value.457, 2
  br i1 %validator.result.type.matches.466, label %validator.result.type.ok.467, label %validator.result.type.invalid.468
validator.result.type.invalid.468:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 36, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.467:
  %context.field.469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.470 = load i32, ptr %context.field.469, align 4
  %stack.sub.473 = sub i32 %descriptor.value.465, %descriptor.value.459
  %descriptor.owner.inside.471 = icmp ule i32 %descriptor.value.465, %context.value.470
  %descriptor.offset.inside.472 = icmp ule i32 %descriptor.value.459, %descriptor.value.465
  %descriptor.extent.inside.474 = icmp ule i32 %descriptor.value.461, %stack.sub.473
  %descriptor.payload.inside.475 = icmp ule i32 %descriptor.value.463, %descriptor.value.461
  %descriptor.owner.offset.valid.476 = and i1 %descriptor.owner.inside.471, %descriptor.offset.inside.472
  %descriptor.range.inside.478 = and i1 %descriptor.owner.offset.valid.476, %descriptor.extent.inside.474
  %descriptor.range.valid.477 = and i1 %descriptor.range.inside.478, %descriptor.payload.inside.475
  %descriptor.type.valid.479 = icmp eq i32 2, 2
  %descriptor.valid.480 = and i1 %descriptor.range.valid.477, %descriptor.type.valid.479
  br i1 %descriptor.valid.480, label %descriptor.valid.481, label %descriptor.invalid.482
descriptor.invalid.482:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.481:
  %descriptor.initialized.status.483 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.459, i32 %descriptor.value.461)
  %helper.ok.484 = icmp eq i32 %descriptor.initialized.status.483, 0
  br i1 %helper.ok.484, label %helper.continue.485, label %entry.validation.failure.3
helper.continue.485:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.459, i32 20, i32 %descriptor.value.463, i32 %descriptor.value.465, i32 %descriptor.value.461)
  %context.field.486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.487 = load i32, ptr %context.field.486, align 4
  %runtime.ok.488 = icmp eq i32 %context.value.487, 0
  br i1 %runtime.ok.488, label %runtime.continue.489, label %entry.validation.failure.3
runtime.continue.489:
  %validator.bool.490 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.459)
  %context.field.491 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.492 = load i32, ptr %context.field.491, align 4
  %runtime.ok.493 = icmp eq i32 %context.value.492, 0
  br i1 %runtime.ok.493, label %runtime.continue.494, label %entry.validation.failure.3
runtime.continue.494:
  %validator.bool.true.495 = icmp eq i64 %validator.bool.490, 1
  %validator.bool.false.496 = icmp eq i64 %validator.bool.490, 0
  %validator.bool.valid.497 = or i1 %validator.bool.true.495, %validator.bool.false.496
  br i1 %validator.bool.valid.497, label %validator.bool.check.498, label %validator.bool.invalid.499
validator.bool.invalid.499:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 36, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.498:
  br i1 %validator.bool.true.495, label %validator.true.501, label %validator.false.500
validator.false.500:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 35, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.501:
  br label %validator.join.502
validator.join.502:
  br label %input.option.validated.433
input.option.validated.433:
  %stack.offset.503 = add i32 %stack.offset.76, %input.host.extent.78
  %input.result.case.504 = alloca i32, align 4
  %input.result.location.505 = alloca %AlOwningFieldLocation, align 4
  %input.result.status.506 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 6, i32 %stack.offset.76, i32 %input.host.extent.78, i32 38, ptr %input.result.case.504, ptr %input.result.location.505)
  %helper.ok.507 = icmp eq i32 %input.result.status.506, 0
  br i1 %helper.ok.507, label %helper.continue.508, label %entry.validation.failure.3
helper.continue.508:
  %input.result.tag.509 = load i32, ptr %input.result.case.504, align 4
  %input.result.is.ok.510 = icmp eq i32 %input.result.tag.509, 0
  br i1 %input.result.is.ok.510, label %input.result.ok.511, label %input.result.error.512
input.result.ok.511:
  %input.result.offset.pointer.514 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.505, i32 0, i32 0
  %input.result.offset.515 = load i32, ptr %input.result.offset.pointer.514, align 4
  %input.result.payload.pointer.516 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.505, i32 0, i32 1
  %input.result.payload.517 = load i32, ptr %input.result.payload.pointer.516, align 4
  %input.result.extent.pointer.518 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.505, i32 0, i32 2
  %input.result.extent.519 = load i32, ptr %input.result.extent.pointer.518, align 4
  %validator.arguments.520 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.521 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.520, i32 0
  %descriptor.field.522 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 0
  store i32 6, ptr %descriptor.field.522, align 4
  %descriptor.field.523 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 1
  store i32 %input.result.offset.515, ptr %descriptor.field.523, align 4
  %descriptor.field.524 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 2
  store i32 %input.result.extent.519, ptr %descriptor.field.524, align 4
  %descriptor.field.525 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 3
  store i32 %input.result.payload.517, ptr %descriptor.field.525, align 4
  %descriptor.field.526 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 4
  store i32 %stack.offset.503, ptr %descriptor.field.526, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.result.offset.515, i32 20, i32 %input.result.payload.517, i32 %stack.offset.503, i32 %input.result.extent.519)
  %context.field.527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.528 = load i32, ptr %context.field.527, align 4
  %runtime.ok.529 = icmp eq i32 %context.value.528, 0
  br i1 %runtime.ok.529, label %runtime.continue.530, label %entry.validation.failure.3
runtime.continue.530:
  %validator.results.531 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.532 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.520, ptr %validator.results.531, i32 41)
  %helper.ok.533 = icmp eq i32 %validator.status.532, 0
  br i1 %helper.ok.533, label %helper.continue.534, label %entry.validation.failure.3
helper.continue.534:
  %descriptor.element.535 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.531, i32 0
  %descriptor.field.536 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.535, i32 0, i32 0
  %descriptor.value.537 = load i32, ptr %descriptor.field.536, align 4
  %descriptor.field.538 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.535, i32 0, i32 1
  %descriptor.value.539 = load i32, ptr %descriptor.field.538, align 4
  %descriptor.field.540 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.535, i32 0, i32 2
  %descriptor.value.541 = load i32, ptr %descriptor.field.540, align 4
  %descriptor.field.542 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.535, i32 0, i32 3
  %descriptor.value.543 = load i32, ptr %descriptor.field.542, align 4
  %descriptor.field.544 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.535, i32 0, i32 4
  %descriptor.value.545 = load i32, ptr %descriptor.field.544, align 4
  %validator.result.type.matches.546 = icmp eq i32 %descriptor.value.537, 2
  br i1 %validator.result.type.matches.546, label %validator.result.type.ok.547, label %validator.result.type.invalid.548
validator.result.type.invalid.548:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 40, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.547:
  %context.field.549 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.550 = load i32, ptr %context.field.549, align 4
  %stack.sub.553 = sub i32 %descriptor.value.545, %descriptor.value.539
  %descriptor.owner.inside.551 = icmp ule i32 %descriptor.value.545, %context.value.550
  %descriptor.offset.inside.552 = icmp ule i32 %descriptor.value.539, %descriptor.value.545
  %descriptor.extent.inside.554 = icmp ule i32 %descriptor.value.541, %stack.sub.553
  %descriptor.payload.inside.555 = icmp ule i32 %descriptor.value.543, %descriptor.value.541
  %descriptor.owner.offset.valid.556 = and i1 %descriptor.owner.inside.551, %descriptor.offset.inside.552
  %descriptor.range.inside.558 = and i1 %descriptor.owner.offset.valid.556, %descriptor.extent.inside.554
  %descriptor.range.valid.557 = and i1 %descriptor.range.inside.558, %descriptor.payload.inside.555
  %descriptor.type.valid.559 = icmp eq i32 2, 2
  %descriptor.valid.560 = and i1 %descriptor.range.valid.557, %descriptor.type.valid.559
  br i1 %descriptor.valid.560, label %descriptor.valid.561, label %descriptor.invalid.562
descriptor.invalid.562:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.561:
  %descriptor.initialized.status.563 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.539, i32 %descriptor.value.541)
  %helper.ok.564 = icmp eq i32 %descriptor.initialized.status.563, 0
  br i1 %helper.ok.564, label %helper.continue.565, label %entry.validation.failure.3
helper.continue.565:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.539, i32 20, i32 %descriptor.value.543, i32 %descriptor.value.545, i32 %descriptor.value.541)
  %context.field.566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.567 = load i32, ptr %context.field.566, align 4
  %runtime.ok.568 = icmp eq i32 %context.value.567, 0
  br i1 %runtime.ok.568, label %runtime.continue.569, label %entry.validation.failure.3
runtime.continue.569:
  %validator.bool.570 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.539)
  %context.field.571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.572 = load i32, ptr %context.field.571, align 4
  %runtime.ok.573 = icmp eq i32 %context.value.572, 0
  br i1 %runtime.ok.573, label %runtime.continue.574, label %entry.validation.failure.3
runtime.continue.574:
  %validator.bool.true.575 = icmp eq i64 %validator.bool.570, 1
  %validator.bool.false.576 = icmp eq i64 %validator.bool.570, 0
  %validator.bool.valid.577 = or i1 %validator.bool.true.575, %validator.bool.false.576
  br i1 %validator.bool.valid.577, label %validator.bool.check.578, label %validator.bool.invalid.579
validator.bool.invalid.579:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 40, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.578:
  br i1 %validator.bool.true.575, label %validator.true.581, label %validator.false.580
validator.false.580:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 39, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.581:
  br label %validator.join.582
validator.join.582:
  br label %input.result.validated.513
input.result.error.512:
  br label %input.result.validated.513
input.result.validated.513:
  %stack.offset.583 = add i32 %stack.offset.96, %input.host.extent.98
  %input.result.case.584 = alloca i32, align 4
  %input.result.location.585 = alloca %AlOwningFieldLocation, align 4
  %input.result.status.586 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 6, i32 %stack.offset.96, i32 %input.host.extent.98, i32 42, ptr %input.result.case.584, ptr %input.result.location.585)
  %helper.ok.587 = icmp eq i32 %input.result.status.586, 0
  br i1 %helper.ok.587, label %helper.continue.588, label %entry.validation.failure.3
helper.continue.588:
  %input.result.tag.589 = load i32, ptr %input.result.case.584, align 4
  %input.result.is.ok.590 = icmp eq i32 %input.result.tag.589, 0
  br i1 %input.result.is.ok.590, label %input.result.ok.591, label %input.result.error.592
input.result.ok.591:
  %input.result.offset.pointer.594 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.585, i32 0, i32 0
  %input.result.offset.595 = load i32, ptr %input.result.offset.pointer.594, align 4
  %input.result.payload.pointer.596 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.585, i32 0, i32 1
  %input.result.payload.597 = load i32, ptr %input.result.payload.pointer.596, align 4
  %input.result.extent.pointer.598 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.585, i32 0, i32 2
  %input.result.extent.599 = load i32, ptr %input.result.extent.pointer.598, align 4
  %validator.arguments.600 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.601 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.600, i32 0
  %descriptor.field.602 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.601, i32 0, i32 0
  store i32 6, ptr %descriptor.field.602, align 4
  %descriptor.field.603 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.601, i32 0, i32 1
  store i32 %input.result.offset.595, ptr %descriptor.field.603, align 4
  %descriptor.field.604 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.601, i32 0, i32 2
  store i32 %input.result.extent.599, ptr %descriptor.field.604, align 4
  %descriptor.field.605 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.601, i32 0, i32 3
  store i32 %input.result.payload.597, ptr %descriptor.field.605, align 4
  %descriptor.field.606 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.601, i32 0, i32 4
  store i32 %stack.offset.583, ptr %descriptor.field.606, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.result.offset.595, i32 20, i32 %input.result.payload.597, i32 %stack.offset.583, i32 %input.result.extent.599)
  %context.field.607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.608 = load i32, ptr %context.field.607, align 4
  %runtime.ok.609 = icmp eq i32 %context.value.608, 0
  br i1 %runtime.ok.609, label %runtime.continue.610, label %entry.validation.failure.3
runtime.continue.610:
  %validator.results.611 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.612 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.600, ptr %validator.results.611, i32 45)
  %helper.ok.613 = icmp eq i32 %validator.status.612, 0
  br i1 %helper.ok.613, label %helper.continue.614, label %entry.validation.failure.3
helper.continue.614:
  %descriptor.element.615 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.611, i32 0
  %descriptor.field.616 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.615, i32 0, i32 0
  %descriptor.value.617 = load i32, ptr %descriptor.field.616, align 4
  %descriptor.field.618 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.615, i32 0, i32 1
  %descriptor.value.619 = load i32, ptr %descriptor.field.618, align 4
  %descriptor.field.620 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.615, i32 0, i32 2
  %descriptor.value.621 = load i32, ptr %descriptor.field.620, align 4
  %descriptor.field.622 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.615, i32 0, i32 3
  %descriptor.value.623 = load i32, ptr %descriptor.field.622, align 4
  %descriptor.field.624 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.615, i32 0, i32 4
  %descriptor.value.625 = load i32, ptr %descriptor.field.624, align 4
  %validator.result.type.matches.626 = icmp eq i32 %descriptor.value.617, 2
  br i1 %validator.result.type.matches.626, label %validator.result.type.ok.627, label %validator.result.type.invalid.628
validator.result.type.invalid.628:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 44, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.627:
  %context.field.629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.630 = load i32, ptr %context.field.629, align 4
  %stack.sub.633 = sub i32 %descriptor.value.625, %descriptor.value.619
  %descriptor.owner.inside.631 = icmp ule i32 %descriptor.value.625, %context.value.630
  %descriptor.offset.inside.632 = icmp ule i32 %descriptor.value.619, %descriptor.value.625
  %descriptor.extent.inside.634 = icmp ule i32 %descriptor.value.621, %stack.sub.633
  %descriptor.payload.inside.635 = icmp ule i32 %descriptor.value.623, %descriptor.value.621
  %descriptor.owner.offset.valid.636 = and i1 %descriptor.owner.inside.631, %descriptor.offset.inside.632
  %descriptor.range.inside.638 = and i1 %descriptor.owner.offset.valid.636, %descriptor.extent.inside.634
  %descriptor.range.valid.637 = and i1 %descriptor.range.inside.638, %descriptor.payload.inside.635
  %descriptor.type.valid.639 = icmp eq i32 2, 2
  %descriptor.valid.640 = and i1 %descriptor.range.valid.637, %descriptor.type.valid.639
  br i1 %descriptor.valid.640, label %descriptor.valid.641, label %descriptor.invalid.642
descriptor.invalid.642:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.641:
  %descriptor.initialized.status.643 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.619, i32 %descriptor.value.621)
  %helper.ok.644 = icmp eq i32 %descriptor.initialized.status.643, 0
  br i1 %helper.ok.644, label %helper.continue.645, label %entry.validation.failure.3
helper.continue.645:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.619, i32 20, i32 %descriptor.value.623, i32 %descriptor.value.625, i32 %descriptor.value.621)
  %context.field.646 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.647 = load i32, ptr %context.field.646, align 4
  %runtime.ok.648 = icmp eq i32 %context.value.647, 0
  br i1 %runtime.ok.648, label %runtime.continue.649, label %entry.validation.failure.3
runtime.continue.649:
  %validator.bool.650 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.619)
  %context.field.651 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.652 = load i32, ptr %context.field.651, align 4
  %runtime.ok.653 = icmp eq i32 %context.value.652, 0
  br i1 %runtime.ok.653, label %runtime.continue.654, label %entry.validation.failure.3
runtime.continue.654:
  %validator.bool.true.655 = icmp eq i64 %validator.bool.650, 1
  %validator.bool.false.656 = icmp eq i64 %validator.bool.650, 0
  %validator.bool.valid.657 = or i1 %validator.bool.true.655, %validator.bool.false.656
  br i1 %validator.bool.valid.657, label %validator.bool.check.658, label %validator.bool.invalid.659
validator.bool.invalid.659:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 44, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.658:
  br i1 %validator.bool.true.655, label %validator.true.661, label %validator.false.660
validator.false.660:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 43, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.661:
  br label %validator.join.662
validator.join.662:
  br label %input.result.validated.593
input.result.error.592:
  br label %input.result.validated.593
input.result.validated.593:
  %stack.offset.663 = add i32 %stack.offset.116, %input.host.extent.118
  %input.result.case.664 = alloca i32, align 4
  %input.result.location.665 = alloca %AlOwningFieldLocation, align 4
  %input.result.status.666 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 7, i32 %stack.offset.116, i32 %input.host.extent.118, i32 46, ptr %input.result.case.664, ptr %input.result.location.665)
  %helper.ok.667 = icmp eq i32 %input.result.status.666, 0
  br i1 %helper.ok.667, label %helper.continue.668, label %entry.validation.failure.3
helper.continue.668:
  %input.result.tag.669 = load i32, ptr %input.result.case.664, align 4
  %input.result.is.ok.670 = icmp eq i32 %input.result.tag.669, 0
  br i1 %input.result.is.ok.670, label %input.result.ok.671, label %input.result.error.672
input.result.ok.671:
  br label %input.result.validated.673
input.result.error.672:
  %input.result.offset.pointer.674 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.665, i32 0, i32 0
  %input.result.offset.675 = load i32, ptr %input.result.offset.pointer.674, align 4
  %input.result.payload.pointer.676 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.665, i32 0, i32 1
  %input.result.payload.677 = load i32, ptr %input.result.payload.pointer.676, align 4
  %input.result.extent.pointer.678 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.665, i32 0, i32 2
  %input.result.extent.679 = load i32, ptr %input.result.extent.pointer.678, align 4
  %validator.arguments.680 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.681 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.680, i32 0
  %descriptor.field.682 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.681, i32 0, i32 0
  store i32 6, ptr %descriptor.field.682, align 4
  %descriptor.field.683 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.681, i32 0, i32 1
  store i32 %input.result.offset.675, ptr %descriptor.field.683, align 4
  %descriptor.field.684 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.681, i32 0, i32 2
  store i32 %input.result.extent.679, ptr %descriptor.field.684, align 4
  %descriptor.field.685 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.681, i32 0, i32 3
  store i32 %input.result.payload.677, ptr %descriptor.field.685, align 4
  %descriptor.field.686 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.681, i32 0, i32 4
  store i32 %stack.offset.663, ptr %descriptor.field.686, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.result.offset.675, i32 20, i32 %input.result.payload.677, i32 %stack.offset.663, i32 %input.result.extent.679)
  %context.field.687 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.688 = load i32, ptr %context.field.687, align 4
  %runtime.ok.689 = icmp eq i32 %context.value.688, 0
  br i1 %runtime.ok.689, label %runtime.continue.690, label %entry.validation.failure.3
runtime.continue.690:
  %validator.results.691 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.692 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.680, ptr %validator.results.691, i32 49)
  %helper.ok.693 = icmp eq i32 %validator.status.692, 0
  br i1 %helper.ok.693, label %helper.continue.694, label %entry.validation.failure.3
helper.continue.694:
  %descriptor.element.695 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.691, i32 0
  %descriptor.field.696 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.695, i32 0, i32 0
  %descriptor.value.697 = load i32, ptr %descriptor.field.696, align 4
  %descriptor.field.698 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.695, i32 0, i32 1
  %descriptor.value.699 = load i32, ptr %descriptor.field.698, align 4
  %descriptor.field.700 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.695, i32 0, i32 2
  %descriptor.value.701 = load i32, ptr %descriptor.field.700, align 4
  %descriptor.field.702 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.695, i32 0, i32 3
  %descriptor.value.703 = load i32, ptr %descriptor.field.702, align 4
  %descriptor.field.704 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.695, i32 0, i32 4
  %descriptor.value.705 = load i32, ptr %descriptor.field.704, align 4
  %validator.result.type.matches.706 = icmp eq i32 %descriptor.value.697, 2
  br i1 %validator.result.type.matches.706, label %validator.result.type.ok.707, label %validator.result.type.invalid.708
validator.result.type.invalid.708:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 48, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.707:
  %context.field.709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.710 = load i32, ptr %context.field.709, align 4
  %stack.sub.713 = sub i32 %descriptor.value.705, %descriptor.value.699
  %descriptor.owner.inside.711 = icmp ule i32 %descriptor.value.705, %context.value.710
  %descriptor.offset.inside.712 = icmp ule i32 %descriptor.value.699, %descriptor.value.705
  %descriptor.extent.inside.714 = icmp ule i32 %descriptor.value.701, %stack.sub.713
  %descriptor.payload.inside.715 = icmp ule i32 %descriptor.value.703, %descriptor.value.701
  %descriptor.owner.offset.valid.716 = and i1 %descriptor.owner.inside.711, %descriptor.offset.inside.712
  %descriptor.range.inside.718 = and i1 %descriptor.owner.offset.valid.716, %descriptor.extent.inside.714
  %descriptor.range.valid.717 = and i1 %descriptor.range.inside.718, %descriptor.payload.inside.715
  %descriptor.type.valid.719 = icmp eq i32 2, 2
  %descriptor.valid.720 = and i1 %descriptor.range.valid.717, %descriptor.type.valid.719
  br i1 %descriptor.valid.720, label %descriptor.valid.721, label %descriptor.invalid.722
descriptor.invalid.722:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.721:
  %descriptor.initialized.status.723 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.699, i32 %descriptor.value.701)
  %helper.ok.724 = icmp eq i32 %descriptor.initialized.status.723, 0
  br i1 %helper.ok.724, label %helper.continue.725, label %entry.validation.failure.3
helper.continue.725:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.699, i32 20, i32 %descriptor.value.703, i32 %descriptor.value.705, i32 %descriptor.value.701)
  %context.field.726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.727 = load i32, ptr %context.field.726, align 4
  %runtime.ok.728 = icmp eq i32 %context.value.727, 0
  br i1 %runtime.ok.728, label %runtime.continue.729, label %entry.validation.failure.3
runtime.continue.729:
  %validator.bool.730 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.699)
  %context.field.731 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.732 = load i32, ptr %context.field.731, align 4
  %runtime.ok.733 = icmp eq i32 %context.value.732, 0
  br i1 %runtime.ok.733, label %runtime.continue.734, label %entry.validation.failure.3
runtime.continue.734:
  %validator.bool.true.735 = icmp eq i64 %validator.bool.730, 1
  %validator.bool.false.736 = icmp eq i64 %validator.bool.730, 0
  %validator.bool.valid.737 = or i1 %validator.bool.true.735, %validator.bool.false.736
  br i1 %validator.bool.valid.737, label %validator.bool.check.738, label %validator.bool.invalid.739
validator.bool.invalid.739:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 48, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.738:
  br i1 %validator.bool.true.735, label %validator.true.741, label %validator.false.740
validator.false.740:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 47, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.741:
  br label %validator.join.742
validator.join.742:
  br label %input.result.validated.673
input.result.validated.673:
  %stack.offset.743 = add i32 %stack.offset.136, %input.host.extent.138
  %input.result.case.744 = alloca i32, align 4
  %input.result.location.745 = alloca %AlOwningFieldLocation, align 4
  %input.result.status.746 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 7, i32 %stack.offset.136, i32 %input.host.extent.138, i32 50, ptr %input.result.case.744, ptr %input.result.location.745)
  %helper.ok.747 = icmp eq i32 %input.result.status.746, 0
  br i1 %helper.ok.747, label %helper.continue.748, label %entry.validation.failure.3
helper.continue.748:
  %input.result.tag.749 = load i32, ptr %input.result.case.744, align 4
  %input.result.is.ok.750 = icmp eq i32 %input.result.tag.749, 0
  br i1 %input.result.is.ok.750, label %input.result.ok.751, label %input.result.error.752
input.result.ok.751:
  br label %input.result.validated.753
input.result.error.752:
  %input.result.offset.pointer.754 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.745, i32 0, i32 0
  %input.result.offset.755 = load i32, ptr %input.result.offset.pointer.754, align 4
  %input.result.payload.pointer.756 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.745, i32 0, i32 1
  %input.result.payload.757 = load i32, ptr %input.result.payload.pointer.756, align 4
  %input.result.extent.pointer.758 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.745, i32 0, i32 2
  %input.result.extent.759 = load i32, ptr %input.result.extent.pointer.758, align 4
  %validator.arguments.760 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.761 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.760, i32 0
  %descriptor.field.762 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.761, i32 0, i32 0
  store i32 6, ptr %descriptor.field.762, align 4
  %descriptor.field.763 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.761, i32 0, i32 1
  store i32 %input.result.offset.755, ptr %descriptor.field.763, align 4
  %descriptor.field.764 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.761, i32 0, i32 2
  store i32 %input.result.extent.759, ptr %descriptor.field.764, align 4
  %descriptor.field.765 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.761, i32 0, i32 3
  store i32 %input.result.payload.757, ptr %descriptor.field.765, align 4
  %descriptor.field.766 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.761, i32 0, i32 4
  store i32 %stack.offset.743, ptr %descriptor.field.766, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.result.offset.755, i32 20, i32 %input.result.payload.757, i32 %stack.offset.743, i32 %input.result.extent.759)
  %context.field.767 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.768 = load i32, ptr %context.field.767, align 4
  %runtime.ok.769 = icmp eq i32 %context.value.768, 0
  br i1 %runtime.ok.769, label %runtime.continue.770, label %entry.validation.failure.3
runtime.continue.770:
  %validator.results.771 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.772 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.760, ptr %validator.results.771, i32 53)
  %helper.ok.773 = icmp eq i32 %validator.status.772, 0
  br i1 %helper.ok.773, label %helper.continue.774, label %entry.validation.failure.3
helper.continue.774:
  %descriptor.element.775 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.771, i32 0
  %descriptor.field.776 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.775, i32 0, i32 0
  %descriptor.value.777 = load i32, ptr %descriptor.field.776, align 4
  %descriptor.field.778 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.775, i32 0, i32 1
  %descriptor.value.779 = load i32, ptr %descriptor.field.778, align 4
  %descriptor.field.780 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.775, i32 0, i32 2
  %descriptor.value.781 = load i32, ptr %descriptor.field.780, align 4
  %descriptor.field.782 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.775, i32 0, i32 3
  %descriptor.value.783 = load i32, ptr %descriptor.field.782, align 4
  %descriptor.field.784 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.775, i32 0, i32 4
  %descriptor.value.785 = load i32, ptr %descriptor.field.784, align 4
  %validator.result.type.matches.786 = icmp eq i32 %descriptor.value.777, 2
  br i1 %validator.result.type.matches.786, label %validator.result.type.ok.787, label %validator.result.type.invalid.788
validator.result.type.invalid.788:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 52, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.787:
  %context.field.789 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.790 = load i32, ptr %context.field.789, align 4
  %stack.sub.793 = sub i32 %descriptor.value.785, %descriptor.value.779
  %descriptor.owner.inside.791 = icmp ule i32 %descriptor.value.785, %context.value.790
  %descriptor.offset.inside.792 = icmp ule i32 %descriptor.value.779, %descriptor.value.785
  %descriptor.extent.inside.794 = icmp ule i32 %descriptor.value.781, %stack.sub.793
  %descriptor.payload.inside.795 = icmp ule i32 %descriptor.value.783, %descriptor.value.781
  %descriptor.owner.offset.valid.796 = and i1 %descriptor.owner.inside.791, %descriptor.offset.inside.792
  %descriptor.range.inside.798 = and i1 %descriptor.owner.offset.valid.796, %descriptor.extent.inside.794
  %descriptor.range.valid.797 = and i1 %descriptor.range.inside.798, %descriptor.payload.inside.795
  %descriptor.type.valid.799 = icmp eq i32 2, 2
  %descriptor.valid.800 = and i1 %descriptor.range.valid.797, %descriptor.type.valid.799
  br i1 %descriptor.valid.800, label %descriptor.valid.801, label %descriptor.invalid.802
descriptor.invalid.802:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.801:
  %descriptor.initialized.status.803 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.779, i32 %descriptor.value.781)
  %helper.ok.804 = icmp eq i32 %descriptor.initialized.status.803, 0
  br i1 %helper.ok.804, label %helper.continue.805, label %entry.validation.failure.3
helper.continue.805:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.779, i32 20, i32 %descriptor.value.783, i32 %descriptor.value.785, i32 %descriptor.value.781)
  %context.field.806 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.807 = load i32, ptr %context.field.806, align 4
  %runtime.ok.808 = icmp eq i32 %context.value.807, 0
  br i1 %runtime.ok.808, label %runtime.continue.809, label %entry.validation.failure.3
runtime.continue.809:
  %validator.bool.810 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.779)
  %context.field.811 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.812 = load i32, ptr %context.field.811, align 4
  %runtime.ok.813 = icmp eq i32 %context.value.812, 0
  br i1 %runtime.ok.813, label %runtime.continue.814, label %entry.validation.failure.3
runtime.continue.814:
  %validator.bool.true.815 = icmp eq i64 %validator.bool.810, 1
  %validator.bool.false.816 = icmp eq i64 %validator.bool.810, 0
  %validator.bool.valid.817 = or i1 %validator.bool.true.815, %validator.bool.false.816
  br i1 %validator.bool.valid.817, label %validator.bool.check.818, label %validator.bool.invalid.819
validator.bool.invalid.819:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 52, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.818:
  br i1 %validator.bool.true.815, label %validator.true.821, label %validator.false.820
validator.false.820:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 51, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.821:
  br label %validator.join.822
validator.join.822:
  br label %input.result.validated.753
input.result.validated.753:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.823
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.823:
  %entry.output.descriptors.824 = alloca [7 x %AlOwningDescriptor], align 4
  %entry.body.status.825 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.824, i32 54)
  %entry.body.ok.826 = icmp eq i32 %entry.body.status.825, 0
  br i1 %entry.body.ok.826, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.827 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 0
  %descriptor.field.828 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.827, i32 0, i32 0
  %descriptor.value.829 = load i32, ptr %descriptor.field.828, align 4
  %descriptor.field.830 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.827, i32 0, i32 1
  %descriptor.value.831 = load i32, ptr %descriptor.field.830, align 4
  %descriptor.field.832 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.827, i32 0, i32 2
  %descriptor.value.833 = load i32, ptr %descriptor.field.832, align 4
  %descriptor.field.834 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.827, i32 0, i32 3
  %descriptor.value.835 = load i32, ptr %descriptor.field.834, align 4
  %descriptor.field.836 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.827, i32 0, i32 4
  %descriptor.value.837 = load i32, ptr %descriptor.field.836, align 4
  %entry.output.type.valid.838 = icmp eq i32 %descriptor.value.829, 5
  br i1 %entry.output.type.valid.838, label %entry.output.type.ok.839, label %entry.output.type.invalid.840
entry.output.type.invalid.840:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.839:
  %context.field.841 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.842 = load i32, ptr %context.field.841, align 4
  %stack.sub.845 = sub i32 %descriptor.value.837, %descriptor.value.831
  %descriptor.owner.inside.843 = icmp ule i32 %descriptor.value.837, %context.value.842
  %descriptor.offset.inside.844 = icmp ule i32 %descriptor.value.831, %descriptor.value.837
  %descriptor.extent.inside.846 = icmp ule i32 %descriptor.value.833, %stack.sub.845
  %descriptor.payload.inside.847 = icmp ule i32 %descriptor.value.835, %descriptor.value.833
  %descriptor.owner.offset.valid.848 = and i1 %descriptor.owner.inside.843, %descriptor.offset.inside.844
  %descriptor.range.inside.850 = and i1 %descriptor.owner.offset.valid.848, %descriptor.extent.inside.846
  %descriptor.range.valid.849 = and i1 %descriptor.range.inside.850, %descriptor.payload.inside.847
  %descriptor.type.valid.851 = icmp eq i32 5, 5
  %descriptor.valid.852 = and i1 %descriptor.range.valid.849, %descriptor.type.valid.851
  br i1 %descriptor.valid.852, label %descriptor.valid.853, label %descriptor.invalid.854
descriptor.invalid.854:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.853:
  %descriptor.initialized.status.855 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.831, i32 %descriptor.value.833)
  %helper.ok.856 = icmp eq i32 %descriptor.initialized.status.855, 0
  br i1 %helper.ok.856, label %helper.continue.857, label %entry.failure.0
helper.continue.857:
  %entry.output.size.i64.858 = zext i32 %descriptor.value.833 to i64
  %entry.output.total.i64.859 = add i64 0, %entry.output.size.i64.858
  %descriptor.element.860 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 1
  %descriptor.field.861 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.860, i32 0, i32 0
  %descriptor.value.862 = load i32, ptr %descriptor.field.861, align 4
  %descriptor.field.863 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.860, i32 0, i32 1
  %descriptor.value.864 = load i32, ptr %descriptor.field.863, align 4
  %descriptor.field.865 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.860, i32 0, i32 2
  %descriptor.value.866 = load i32, ptr %descriptor.field.865, align 4
  %descriptor.field.867 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.860, i32 0, i32 3
  %descriptor.value.868 = load i32, ptr %descriptor.field.867, align 4
  %descriptor.field.869 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.860, i32 0, i32 4
  %descriptor.value.870 = load i32, ptr %descriptor.field.869, align 4
  %entry.output.type.valid.871 = icmp eq i32 %descriptor.value.862, 7
  br i1 %entry.output.type.valid.871, label %entry.output.type.ok.872, label %entry.output.type.invalid.873
entry.output.type.invalid.873:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.872:
  %context.field.874 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.875 = load i32, ptr %context.field.874, align 4
  %stack.sub.878 = sub i32 %descriptor.value.870, %descriptor.value.864
  %descriptor.owner.inside.876 = icmp ule i32 %descriptor.value.870, %context.value.875
  %descriptor.offset.inside.877 = icmp ule i32 %descriptor.value.864, %descriptor.value.870
  %descriptor.extent.inside.879 = icmp ule i32 %descriptor.value.866, %stack.sub.878
  %descriptor.payload.inside.880 = icmp ule i32 %descriptor.value.868, %descriptor.value.866
  %descriptor.owner.offset.valid.881 = and i1 %descriptor.owner.inside.876, %descriptor.offset.inside.877
  %descriptor.range.inside.883 = and i1 %descriptor.owner.offset.valid.881, %descriptor.extent.inside.879
  %descriptor.range.valid.882 = and i1 %descriptor.range.inside.883, %descriptor.payload.inside.880
  %descriptor.type.valid.884 = icmp eq i32 7, 7
  %descriptor.valid.885 = and i1 %descriptor.range.valid.882, %descriptor.type.valid.884
  br i1 %descriptor.valid.885, label %descriptor.valid.886, label %descriptor.invalid.887
descriptor.invalid.887:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.886:
  %descriptor.initialized.status.888 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.864, i32 %descriptor.value.866)
  %helper.ok.889 = icmp eq i32 %descriptor.initialized.status.888, 0
  br i1 %helper.ok.889, label %helper.continue.890, label %entry.failure.0
helper.continue.890:
  %entry.output.size.i64.891 = zext i32 %descriptor.value.866 to i64
  %entry.output.total.i64.892 = add i64 %entry.output.total.i64.859, %entry.output.size.i64.891
  %descriptor.element.893 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 2
  %descriptor.field.894 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.893, i32 0, i32 0
  %descriptor.value.895 = load i32, ptr %descriptor.field.894, align 4
  %descriptor.field.896 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.893, i32 0, i32 1
  %descriptor.value.897 = load i32, ptr %descriptor.field.896, align 4
  %descriptor.field.898 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.893, i32 0, i32 2
  %descriptor.value.899 = load i32, ptr %descriptor.field.898, align 4
  %descriptor.field.900 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.893, i32 0, i32 3
  %descriptor.value.901 = load i32, ptr %descriptor.field.900, align 4
  %descriptor.field.902 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.893, i32 0, i32 4
  %descriptor.value.903 = load i32, ptr %descriptor.field.902, align 4
  %entry.output.type.valid.904 = icmp eq i32 %descriptor.value.895, 7
  br i1 %entry.output.type.valid.904, label %entry.output.type.ok.905, label %entry.output.type.invalid.906
entry.output.type.invalid.906:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.905:
  %context.field.907 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.908 = load i32, ptr %context.field.907, align 4
  %stack.sub.911 = sub i32 %descriptor.value.903, %descriptor.value.897
  %descriptor.owner.inside.909 = icmp ule i32 %descriptor.value.903, %context.value.908
  %descriptor.offset.inside.910 = icmp ule i32 %descriptor.value.897, %descriptor.value.903
  %descriptor.extent.inside.912 = icmp ule i32 %descriptor.value.899, %stack.sub.911
  %descriptor.payload.inside.913 = icmp ule i32 %descriptor.value.901, %descriptor.value.899
  %descriptor.owner.offset.valid.914 = and i1 %descriptor.owner.inside.909, %descriptor.offset.inside.910
  %descriptor.range.inside.916 = and i1 %descriptor.owner.offset.valid.914, %descriptor.extent.inside.912
  %descriptor.range.valid.915 = and i1 %descriptor.range.inside.916, %descriptor.payload.inside.913
  %descriptor.type.valid.917 = icmp eq i32 7, 7
  %descriptor.valid.918 = and i1 %descriptor.range.valid.915, %descriptor.type.valid.917
  br i1 %descriptor.valid.918, label %descriptor.valid.919, label %descriptor.invalid.920
descriptor.invalid.920:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.919:
  %descriptor.initialized.status.921 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.897, i32 %descriptor.value.899)
  %helper.ok.922 = icmp eq i32 %descriptor.initialized.status.921, 0
  br i1 %helper.ok.922, label %helper.continue.923, label %entry.failure.0
helper.continue.923:
  %entry.output.size.i64.924 = zext i32 %descriptor.value.899 to i64
  %entry.output.total.i64.925 = add i64 %entry.output.total.i64.892, %entry.output.size.i64.924
  %descriptor.element.926 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 3
  %descriptor.field.927 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.926, i32 0, i32 0
  %descriptor.value.928 = load i32, ptr %descriptor.field.927, align 4
  %descriptor.field.929 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.926, i32 0, i32 1
  %descriptor.value.930 = load i32, ptr %descriptor.field.929, align 4
  %descriptor.field.931 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.926, i32 0, i32 2
  %descriptor.value.932 = load i32, ptr %descriptor.field.931, align 4
  %descriptor.field.933 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.926, i32 0, i32 3
  %descriptor.value.934 = load i32, ptr %descriptor.field.933, align 4
  %descriptor.field.935 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.926, i32 0, i32 4
  %descriptor.value.936 = load i32, ptr %descriptor.field.935, align 4
  %entry.output.type.valid.937 = icmp eq i32 %descriptor.value.928, 8
  br i1 %entry.output.type.valid.937, label %entry.output.type.ok.938, label %entry.output.type.invalid.939
entry.output.type.invalid.939:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.938:
  %context.field.940 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.941 = load i32, ptr %context.field.940, align 4
  %stack.sub.944 = sub i32 %descriptor.value.936, %descriptor.value.930
  %descriptor.owner.inside.942 = icmp ule i32 %descriptor.value.936, %context.value.941
  %descriptor.offset.inside.943 = icmp ule i32 %descriptor.value.930, %descriptor.value.936
  %descriptor.extent.inside.945 = icmp ule i32 %descriptor.value.932, %stack.sub.944
  %descriptor.payload.inside.946 = icmp ule i32 %descriptor.value.934, %descriptor.value.932
  %descriptor.owner.offset.valid.947 = and i1 %descriptor.owner.inside.942, %descriptor.offset.inside.943
  %descriptor.range.inside.949 = and i1 %descriptor.owner.offset.valid.947, %descriptor.extent.inside.945
  %descriptor.range.valid.948 = and i1 %descriptor.range.inside.949, %descriptor.payload.inside.946
  %descriptor.type.valid.950 = icmp eq i32 8, 8
  %descriptor.valid.951 = and i1 %descriptor.range.valid.948, %descriptor.type.valid.950
  br i1 %descriptor.valid.951, label %descriptor.valid.952, label %descriptor.invalid.953
descriptor.invalid.953:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.952:
  %descriptor.initialized.status.954 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.930, i32 %descriptor.value.932)
  %helper.ok.955 = icmp eq i32 %descriptor.initialized.status.954, 0
  br i1 %helper.ok.955, label %helper.continue.956, label %entry.failure.0
helper.continue.956:
  %entry.output.size.i64.957 = zext i32 %descriptor.value.932 to i64
  %entry.output.total.i64.958 = add i64 %entry.output.total.i64.925, %entry.output.size.i64.957
  %descriptor.element.959 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 4
  %descriptor.field.960 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.959, i32 0, i32 0
  %descriptor.value.961 = load i32, ptr %descriptor.field.960, align 4
  %descriptor.field.962 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.959, i32 0, i32 1
  %descriptor.value.963 = load i32, ptr %descriptor.field.962, align 4
  %descriptor.field.964 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.959, i32 0, i32 2
  %descriptor.value.965 = load i32, ptr %descriptor.field.964, align 4
  %descriptor.field.966 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.959, i32 0, i32 3
  %descriptor.value.967 = load i32, ptr %descriptor.field.966, align 4
  %descriptor.field.968 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.959, i32 0, i32 4
  %descriptor.value.969 = load i32, ptr %descriptor.field.968, align 4
  %entry.output.type.valid.970 = icmp eq i32 %descriptor.value.961, 8
  br i1 %entry.output.type.valid.970, label %entry.output.type.ok.971, label %entry.output.type.invalid.972
entry.output.type.invalid.972:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.971:
  %context.field.973 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.974 = load i32, ptr %context.field.973, align 4
  %stack.sub.977 = sub i32 %descriptor.value.969, %descriptor.value.963
  %descriptor.owner.inside.975 = icmp ule i32 %descriptor.value.969, %context.value.974
  %descriptor.offset.inside.976 = icmp ule i32 %descriptor.value.963, %descriptor.value.969
  %descriptor.extent.inside.978 = icmp ule i32 %descriptor.value.965, %stack.sub.977
  %descriptor.payload.inside.979 = icmp ule i32 %descriptor.value.967, %descriptor.value.965
  %descriptor.owner.offset.valid.980 = and i1 %descriptor.owner.inside.975, %descriptor.offset.inside.976
  %descriptor.range.inside.982 = and i1 %descriptor.owner.offset.valid.980, %descriptor.extent.inside.978
  %descriptor.range.valid.981 = and i1 %descriptor.range.inside.982, %descriptor.payload.inside.979
  %descriptor.type.valid.983 = icmp eq i32 8, 8
  %descriptor.valid.984 = and i1 %descriptor.range.valid.981, %descriptor.type.valid.983
  br i1 %descriptor.valid.984, label %descriptor.valid.985, label %descriptor.invalid.986
descriptor.invalid.986:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.985:
  %descriptor.initialized.status.987 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.963, i32 %descriptor.value.965)
  %helper.ok.988 = icmp eq i32 %descriptor.initialized.status.987, 0
  br i1 %helper.ok.988, label %helper.continue.989, label %entry.failure.0
helper.continue.989:
  %entry.output.size.i64.990 = zext i32 %descriptor.value.965 to i64
  %entry.output.total.i64.991 = add i64 %entry.output.total.i64.958, %entry.output.size.i64.990
  %descriptor.element.992 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 5
  %descriptor.field.993 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.992, i32 0, i32 0
  %descriptor.value.994 = load i32, ptr %descriptor.field.993, align 4
  %descriptor.field.995 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.992, i32 0, i32 1
  %descriptor.value.996 = load i32, ptr %descriptor.field.995, align 4
  %descriptor.field.997 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.992, i32 0, i32 2
  %descriptor.value.998 = load i32, ptr %descriptor.field.997, align 4
  %descriptor.field.999 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.992, i32 0, i32 3
  %descriptor.value.1000 = load i32, ptr %descriptor.field.999, align 4
  %descriptor.field.1001 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.992, i32 0, i32 4
  %descriptor.value.1002 = load i32, ptr %descriptor.field.1001, align 4
  %entry.output.type.valid.1003 = icmp eq i32 %descriptor.value.994, 9
  br i1 %entry.output.type.valid.1003, label %entry.output.type.ok.1004, label %entry.output.type.invalid.1005
entry.output.type.invalid.1005:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.1004:
  %context.field.1006 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1007 = load i32, ptr %context.field.1006, align 4
  %stack.sub.1010 = sub i32 %descriptor.value.1002, %descriptor.value.996
  %descriptor.owner.inside.1008 = icmp ule i32 %descriptor.value.1002, %context.value.1007
  %descriptor.offset.inside.1009 = icmp ule i32 %descriptor.value.996, %descriptor.value.1002
  %descriptor.extent.inside.1011 = icmp ule i32 %descriptor.value.998, %stack.sub.1010
  %descriptor.payload.inside.1012 = icmp ule i32 %descriptor.value.1000, %descriptor.value.998
  %descriptor.owner.offset.valid.1013 = and i1 %descriptor.owner.inside.1008, %descriptor.offset.inside.1009
  %descriptor.range.inside.1015 = and i1 %descriptor.owner.offset.valid.1013, %descriptor.extent.inside.1011
  %descriptor.range.valid.1014 = and i1 %descriptor.range.inside.1015, %descriptor.payload.inside.1012
  %descriptor.type.valid.1016 = icmp eq i32 9, 9
  %descriptor.valid.1017 = and i1 %descriptor.range.valid.1014, %descriptor.type.valid.1016
  br i1 %descriptor.valid.1017, label %descriptor.valid.1018, label %descriptor.invalid.1019
descriptor.invalid.1019:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.1018:
  %descriptor.initialized.status.1020 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.996, i32 %descriptor.value.998)
  %helper.ok.1021 = icmp eq i32 %descriptor.initialized.status.1020, 0
  br i1 %helper.ok.1021, label %helper.continue.1022, label %entry.failure.0
helper.continue.1022:
  %entry.output.size.i64.1023 = zext i32 %descriptor.value.998 to i64
  %entry.output.total.i64.1024 = add i64 %entry.output.total.i64.991, %entry.output.size.i64.1023
  %descriptor.element.1025 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.824, i32 6
  %descriptor.field.1026 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1025, i32 0, i32 0
  %descriptor.value.1027 = load i32, ptr %descriptor.field.1026, align 4
  %descriptor.field.1028 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1025, i32 0, i32 1
  %descriptor.value.1029 = load i32, ptr %descriptor.field.1028, align 4
  %descriptor.field.1030 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1025, i32 0, i32 2
  %descriptor.value.1031 = load i32, ptr %descriptor.field.1030, align 4
  %descriptor.field.1032 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1025, i32 0, i32 3
  %descriptor.value.1033 = load i32, ptr %descriptor.field.1032, align 4
  %descriptor.field.1034 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1025, i32 0, i32 4
  %descriptor.value.1035 = load i32, ptr %descriptor.field.1034, align 4
  %entry.output.type.valid.1036 = icmp eq i32 %descriptor.value.1027, 9
  br i1 %entry.output.type.valid.1036, label %entry.output.type.ok.1037, label %entry.output.type.invalid.1038
entry.output.type.invalid.1038:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.1037:
  %context.field.1039 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1040 = load i32, ptr %context.field.1039, align 4
  %stack.sub.1043 = sub i32 %descriptor.value.1035, %descriptor.value.1029
  %descriptor.owner.inside.1041 = icmp ule i32 %descriptor.value.1035, %context.value.1040
  %descriptor.offset.inside.1042 = icmp ule i32 %descriptor.value.1029, %descriptor.value.1035
  %descriptor.extent.inside.1044 = icmp ule i32 %descriptor.value.1031, %stack.sub.1043
  %descriptor.payload.inside.1045 = icmp ule i32 %descriptor.value.1033, %descriptor.value.1031
  %descriptor.owner.offset.valid.1046 = and i1 %descriptor.owner.inside.1041, %descriptor.offset.inside.1042
  %descriptor.range.inside.1048 = and i1 %descriptor.owner.offset.valid.1046, %descriptor.extent.inside.1044
  %descriptor.range.valid.1047 = and i1 %descriptor.range.inside.1048, %descriptor.payload.inside.1045
  %descriptor.type.valid.1049 = icmp eq i32 9, 9
  %descriptor.valid.1050 = and i1 %descriptor.range.valid.1047, %descriptor.type.valid.1049
  br i1 %descriptor.valid.1050, label %descriptor.valid.1051, label %descriptor.invalid.1052
descriptor.invalid.1052:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.1051:
  %descriptor.initialized.status.1053 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.1029, i32 %descriptor.value.1031)
  %helper.ok.1054 = icmp eq i32 %descriptor.initialized.status.1053, 0
  br i1 %helper.ok.1054, label %helper.continue.1055, label %entry.failure.0
helper.continue.1055:
  %entry.output.size.i64.1056 = zext i32 %descriptor.value.1031 to i64
  %entry.output.total.i64.1057 = add i64 %entry.output.total.i64.1024, %entry.output.size.i64.1056
  %entry.retained.capacity.i64.1058 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.1059 = icmp ule i64 %entry.output.total.i64.1057, 4294967295
  %entry.retained.required.truncated.1060 = trunc i64 %entry.output.total.i64.1057 to i32
  %entry.retained.required.1061 = select i1 %entry.retained.required.fits.u32.1059, i32 %entry.retained.required.truncated.1060, i32 4294967295
  %entry.retained.capacity.ok.1062 = icmp ule i64 %entry.output.total.i64.1057, %entry.retained.capacity.i64.1058
  br i1 %entry.retained.capacity.ok.1062, label %entry.retained.capacity.ready.1063, label %entry.retained.capacity.failure.1064
entry.retained.capacity.failure.1064:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.1061, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.1063:
  %host.pointer.1065 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.1066 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1065, i32 %stack.sub.1066, i32 %descriptor.value.831, i32 %descriptor.value.833, i32 5)
  %context.field.1067 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1068 = load i32, ptr %context.field.1067, align 4
  %runtime.ok.1069 = icmp eq i32 %context.value.1068, 0
  br i1 %runtime.ok.1069, label %runtime.continue.1070, label %entry.failure.0
runtime.continue.1070:
  %stack.offset.1071 = add i32 0, %descriptor.value.833
  %host.pointer.1072 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1071
  %stack.sub.1073 = sub i32 %retained.capacity, %stack.offset.1071
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1072, i32 %stack.sub.1073, i32 %descriptor.value.864, i32 %descriptor.value.866, i32 7)
  %context.field.1074 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1075 = load i32, ptr %context.field.1074, align 4
  %runtime.ok.1076 = icmp eq i32 %context.value.1075, 0
  br i1 %runtime.ok.1076, label %runtime.continue.1077, label %entry.failure.0
runtime.continue.1077:
  %stack.offset.1078 = add i32 %stack.offset.1071, %descriptor.value.866
  %host.pointer.1079 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1078
  %stack.sub.1080 = sub i32 %retained.capacity, %stack.offset.1078
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1079, i32 %stack.sub.1080, i32 %descriptor.value.897, i32 %descriptor.value.899, i32 7)
  %context.field.1081 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1082 = load i32, ptr %context.field.1081, align 4
  %runtime.ok.1083 = icmp eq i32 %context.value.1082, 0
  br i1 %runtime.ok.1083, label %runtime.continue.1084, label %entry.failure.0
runtime.continue.1084:
  %stack.offset.1085 = add i32 %stack.offset.1078, %descriptor.value.899
  %host.pointer.1086 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1085
  %stack.sub.1087 = sub i32 %retained.capacity, %stack.offset.1085
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1086, i32 %stack.sub.1087, i32 %descriptor.value.930, i32 %descriptor.value.932, i32 8)
  %context.field.1088 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1089 = load i32, ptr %context.field.1088, align 4
  %runtime.ok.1090 = icmp eq i32 %context.value.1089, 0
  br i1 %runtime.ok.1090, label %runtime.continue.1091, label %entry.failure.0
runtime.continue.1091:
  %stack.offset.1092 = add i32 %stack.offset.1085, %descriptor.value.932
  %host.pointer.1093 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1092
  %stack.sub.1094 = sub i32 %retained.capacity, %stack.offset.1092
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1093, i32 %stack.sub.1094, i32 %descriptor.value.963, i32 %descriptor.value.965, i32 8)
  %context.field.1095 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1096 = load i32, ptr %context.field.1095, align 4
  %runtime.ok.1097 = icmp eq i32 %context.value.1096, 0
  br i1 %runtime.ok.1097, label %runtime.continue.1098, label %entry.failure.0
runtime.continue.1098:
  %stack.offset.1099 = add i32 %stack.offset.1092, %descriptor.value.965
  %host.pointer.1100 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1099
  %stack.sub.1101 = sub i32 %retained.capacity, %stack.offset.1099
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1100, i32 %stack.sub.1101, i32 %descriptor.value.996, i32 %descriptor.value.998, i32 9)
  %context.field.1102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1103 = load i32, ptr %context.field.1102, align 4
  %runtime.ok.1104 = icmp eq i32 %context.value.1103, 0
  br i1 %runtime.ok.1104, label %runtime.continue.1105, label %entry.failure.0
runtime.continue.1105:
  %stack.offset.1106 = add i32 %stack.offset.1099, %descriptor.value.998
  %host.pointer.1107 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.1106
  %stack.sub.1108 = sub i32 %retained.capacity, %stack.offset.1106
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.1107, i32 %stack.sub.1108, i32 %descriptor.value.1029, i32 %descriptor.value.1031, i32 9)
  %context.field.1109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1110 = load i32, ptr %context.field.1109, align 4
  %runtime.ok.1111 = icmp eq i32 %context.value.1110, 0
  br i1 %runtime.ok.1111, label %runtime.continue.1112, label %entry.failure.0
runtime.continue.1112:
  %stack.offset.1113 = add i32 %stack.offset.1106, %descriptor.value.1031
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.1114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1115 = load i32, ptr %context.field.1114, align 4
  %context.field.1116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1117 = load i32, ptr %context.field.1116, align 4
  %stack.sub.1118 = sub i32 0, %context.value.1115
  %stack.sub.1119 = sub i32 0, %context.value.1117
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1118, i32 %stack.sub.1119)
  %context.field.1120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1121 = load i32, ptr %context.field.1120, align 4
  %runtime.ok.1122 = icmp eq i32 %context.value.1121, 0
  br i1 %runtime.ok.1122, label %runtime.continue.1123, label %entry.failure.0
runtime.continue.1123:
  br label %entry.return.status
entry.failure.0:
  %context.field.1124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1125 = load i32, ptr %context.field.1124, align 4
  %context.field.1126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1127 = load i32, ptr %context.field.1126, align 4
  %context.field.1128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1129 = load i32, ptr %context.field.1128, align 4
  %stack.offset.1130 = add i32 %context.value.1125, %context.value.1127
  %stack.sub.1131 = sub i32 0, %stack.offset.1130
  %stack.sub.1132 = sub i32 0, %context.value.1127
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1131, i32 %stack.sub.1132)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.1129)
  br label %entry.return.status
entry.return.status:
  %context.field.1133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1134 = load i32, ptr %context.field.1133, align 4
  ret i32 %context.value.1134
}


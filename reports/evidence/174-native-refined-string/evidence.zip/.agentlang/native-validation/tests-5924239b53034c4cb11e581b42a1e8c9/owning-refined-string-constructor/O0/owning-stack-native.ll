%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %validator.arguments.51 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.52 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.51, i32 0
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 0
  store i32 5, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.56, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.57, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %validator.results.62 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %validator.depth.within.interpreter.limit.65 = icmp ule i32 %context.value.64, 64
  br i1 %validator.depth.within.interpreter.limit.65, label %validator.depth.ok.66, label %validator.depth.invalid.67
validator.depth.invalid.67:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.66:
  %validator.status.68 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.51, ptr %validator.results.62, i32 5)
  %helper.ok.69 = icmp eq i32 %validator.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %descriptor.element.71 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.62, i32 0
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 0
  %descriptor.value.73 = load i32, ptr %descriptor.field.72, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 1
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 2
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 3
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 4
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %validator.result.type.matches.82 = icmp eq i32 %descriptor.value.73, 2
  br i1 %validator.result.type.matches.82, label %validator.result.type.ok.83, label %validator.result.type.invalid.84
validator.result.type.invalid.84:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.83:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.81, %descriptor.value.75
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.81, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.75, %descriptor.value.81
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.77, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.79, %descriptor.value.77
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 2, 2
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.75, i32 %descriptor.value.77)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.75, i32 20, i32 %descriptor.value.79, i32 %descriptor.value.81, i32 %descriptor.value.77)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %validator.bool.106 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.75)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %runtime.ok.109 = icmp eq i32 %context.value.108, 0
  br i1 %runtime.ok.109, label %runtime.continue.110, label %frame.failure.0
runtime.continue.110:
  %validator.bool.true.111 = icmp eq i64 %validator.bool.106, 1
  %validator.bool.false.112 = icmp eq i64 %validator.bool.106, 0
  %validator.bool.valid.113 = or i1 %validator.bool.true.111, %validator.bool.false.112
  br i1 %validator.bool.valid.113, label %validator.bool.check.114, label %validator.bool.invalid.115
validator.bool.invalid.115:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.114:
  br i1 %validator.bool.true.111, label %validator.true.117, label %validator.false.116
validator.false.116:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 3, i32 0, i32 0)
  br label %frame.failure.0
validator.true.117:
  br label %validator.join.118
validator.join.118:
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.121 = icmp ule i32 %descriptor.value.23, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.124 = icmp ule i32 %descriptor.value.19, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  %descriptor.type.valid.129 = icmp eq i32 4, 4
  %descriptor.valid.130 = and i1 %descriptor.range.valid.127, %descriptor.type.valid.129
  br i1 %descriptor.valid.130, label %descriptor.valid.131, label %descriptor.invalid.132
descriptor.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.131:
  %descriptor.initialized.status.133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.134 = icmp eq i32 %descriptor.initialized.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %descriptor.element.136 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 0
  store i32 4, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.140, align 4
  %descriptor.field.141 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.141, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %frame.failure.0
runtime.continue.145:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %stack.offset.152 = add i32 %context.value.5, %context.value.7
  %stack.offset.153 = add i32 %context.value.147, %context.value.149
  %stack.sub.154 = sub i32 %stack.offset.152, %stack.offset.153
  %stack.sub.155 = sub i32 %context.value.7, %context.value.149
  %stack.sub.156 = sub i32 %context.value.151, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.154, i32 %stack.sub.155)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.156)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 8, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 9)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 11)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 14)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 15, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 16)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 5, i32 17)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 5, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 18)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 4
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 4, 4
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 4)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [6 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 6, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 7, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 6, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.sub.75 = sub i32 %context.value.74, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.75, i32 0, i32 0, i32 0)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  %descriptor.element.84 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 0
  store i32 6, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.89, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %descriptor.element.94 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.95 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 0
  store i32 7, ptr %descriptor.field.95, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.98, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.99, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %stack.offset.110 = add i32 %context.value.5, %context.value.7
  %stack.offset.111 = add i32 %context.value.105, %context.value.107
  %stack.sub.112 = sub i32 %stack.offset.110, %stack.offset.111
  %stack.sub.113 = sub i32 %context.value.7, %context.value.107
  %stack.sub.114 = sub i32 %context.value.109, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.112, i32 %stack.sub.113)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.114)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.offset.94 = add i32 %context.value.93, 8
  %reserve.status.95 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 6)
  %reserve.ok.96 = icmp eq i32 %reserve.status.95, 0
  br i1 %reserve.ok.96, label %reserve.continue.97, label %frame.failure.0
reserve.continue.97:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.93, i64 0, i32 1)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %stack.sub.110 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.108 = icmp ule i32 %stack.offset.60, %context.value.107
  %descriptor.offset.inside.109 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.111 = icmp ule i32 8, %stack.sub.110
  %descriptor.payload.inside.112 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.113 = and i1 %descriptor.owner.inside.108, %descriptor.offset.inside.109
  %descriptor.range.inside.115 = and i1 %descriptor.owner.offset.valid.113, %descriptor.extent.inside.111
  %descriptor.range.valid.114 = and i1 %descriptor.range.inside.115, %descriptor.payload.inside.112
  %descriptor.type.valid.116 = icmp eq i32 1, 1
  %descriptor.valid.117 = and i1 %descriptor.range.valid.114, %descriptor.type.valid.116
  br i1 %descriptor.valid.117, label %descriptor.valid.118, label %descriptor.invalid.119
descriptor.invalid.119:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.118:
  %descriptor.initialized.status.120 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.121 = icmp eq i32 %descriptor.initialized.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %frame.failure.0
helper.continue.122:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %stack.offset.94, %context.value.93
  %descriptor.owner.inside.125 = icmp ule i32 %stack.offset.94, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %context.value.93, %stack.offset.94
  %descriptor.extent.inside.128 = icmp ule i32 8, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 1, 1
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.93, i32 8)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %step.status.140 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.141 = icmp eq i32 %step.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %inline.target.depth.within.interpreter.limit.145 = icmp ule i32 %context.value.144, 65
  br i1 %inline.target.depth.within.interpreter.limit.145, label %inline.target.depth.ok.146, label %inline.target.depth.invalid.147
inline.target.depth.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.146:
  %integer.left.148 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.59)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %integer.right.149 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.93)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %divide.zero.158 = icmp eq i64 %integer.right.149, 0
  br i1 %divide.zero.158, label %divide.zero.159, label %divide.nonzero.160
divide.zero.159:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.160:
  %divide.min.161 = icmp eq i64 %integer.left.148, -9223372036854775808
  %divide.minusone.162 = icmp eq i64 %integer.right.149, -1
  %divide.overflow.163 = and i1 %divide.min.161, %divide.minusone.162
  br i1 %divide.overflow.163, label %divide.overflow.164, label %divide.valid.165
divide.overflow.164:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 10, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.165:
  %divide.result.166 = sdiv i64 %integer.left.148, %integer.right.149
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.93, i32 8, i32 8, i32 0, i32 0)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.59, i32 8, i32 8, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.176, 8
  %reserve.status.178 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.177, i32 11)
  %reserve.ok.179 = icmp eq i32 %reserve.status.178, 0
  br i1 %reserve.ok.179, label %reserve.continue.180, label %frame.failure.0
reserve.continue.180:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.176, i64 %divide.result.166, i32 1)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %stack.offset.189 = add i32 %context.value.176, 8
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.192 = icmp ule i32 %stack.offset.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.195 = icmp ule i32 8, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 1, 1
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.offset.212 = add i32 %context.value.211, 8
  %reserve.status.213 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.212, i32 13)
  %reserve.ok.214 = icmp eq i32 %reserve.status.213, 0
  br i1 %reserve.ok.214, label %reserve.continue.215, label %frame.failure.0
reserve.continue.215:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.211, i64 0, i32 1)
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %runtime.ok.218 = icmp eq i32 %context.value.217, 0
  br i1 %runtime.ok.218, label %runtime.continue.219, label %frame.failure.0
runtime.continue.219:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %stack.sub.228 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.226 = icmp ule i32 %stack.offset.189, %context.value.225
  %descriptor.offset.inside.227 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.229 = icmp ule i32 8, %stack.sub.228
  %descriptor.payload.inside.230 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.231 = and i1 %descriptor.owner.inside.226, %descriptor.offset.inside.227
  %descriptor.range.inside.233 = and i1 %descriptor.owner.offset.valid.231, %descriptor.extent.inside.229
  %descriptor.range.valid.232 = and i1 %descriptor.range.inside.233, %descriptor.payload.inside.230
  %descriptor.type.valid.234 = icmp eq i32 1, 1
  %descriptor.valid.235 = and i1 %descriptor.range.valid.232, %descriptor.type.valid.234
  br i1 %descriptor.valid.235, label %descriptor.valid.236, label %descriptor.invalid.237
descriptor.invalid.237:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.236:
  %descriptor.initialized.status.238 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.239 = icmp eq i32 %descriptor.initialized.status.238, 0
  br i1 %helper.ok.239, label %helper.continue.240, label %frame.failure.0
helper.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %stack.offset.212, %context.value.211
  %descriptor.owner.inside.243 = icmp ule i32 %stack.offset.212, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %context.value.211, %stack.offset.212
  %descriptor.extent.inside.246 = icmp ule i32 8, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  %descriptor.type.valid.251 = icmp eq i32 1, 1
  %descriptor.valid.252 = and i1 %descriptor.range.valid.249, %descriptor.type.valid.251
  br i1 %descriptor.valid.252, label %descriptor.valid.253, label %descriptor.invalid.254
descriptor.invalid.254:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.253:
  %descriptor.initialized.status.255 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.211, i32 8)
  %helper.ok.256 = icmp eq i32 %descriptor.initialized.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %step.status.258 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.259 = icmp eq i32 %step.status.258, 0
  br i1 %helper.ok.259, label %helper.continue.260, label %frame.failure.0
helper.continue.260:
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %inline.target.depth.within.interpreter.limit.263 = icmp ule i32 %context.value.262, 65
  br i1 %inline.target.depth.within.interpreter.limit.263, label %inline.target.depth.ok.264, label %inline.target.depth.invalid.265
inline.target.depth.invalid.265:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 15, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.264:
  %integer.left.266 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.176)
  %context.field.268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.269 = load i32, ptr %context.field.268, align 4
  %runtime.ok.270 = icmp eq i32 %context.value.269, 0
  br i1 %runtime.ok.270, label %runtime.continue.271, label %frame.failure.0
runtime.continue.271:
  %integer.right.267 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.211)
  %context.field.272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.273 = load i32, ptr %context.field.272, align 4
  %runtime.ok.274 = icmp eq i32 %context.value.273, 0
  br i1 %runtime.ok.274, label %runtime.continue.275, label %frame.failure.0
runtime.continue.275:
  %comparison.result.276 = icmp sgt i64 %integer.left.266, %integer.right.267
  %comparison.value.277 = zext i1 %comparison.result.276 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.211, i32 8, i32 8, i32 0, i32 0)
  %context.field.278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.279 = load i32, ptr %context.field.278, align 4
  %runtime.ok.280 = icmp eq i32 %context.value.279, 0
  br i1 %runtime.ok.280, label %runtime.continue.281, label %frame.failure.0
runtime.continue.281:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.176, i32 8, i32 8, i32 0, i32 0)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.offset.288 = add i32 %context.value.287, 8
  %reserve.status.289 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.288, i32 16)
  %reserve.ok.290 = icmp eq i32 %reserve.status.289, 0
  br i1 %reserve.ok.290, label %reserve.continue.291, label %frame.failure.0
reserve.continue.291:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.287, i64 %comparison.value.277, i32 2)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %runtime.ok.298 = icmp eq i32 %context.value.297, 0
  br i1 %runtime.ok.298, label %runtime.continue.299, label %frame.failure.0
runtime.continue.299:
  %stack.offset.300 = add i32 %context.value.287, 8
  %context.field.301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.302 = load i32, ptr %context.field.301, align 4
  %stack.sub.305 = sub i32 %stack.offset.300, %context.value.287
  %descriptor.owner.inside.303 = icmp ule i32 %stack.offset.300, %context.value.302
  %descriptor.offset.inside.304 = icmp ule i32 %context.value.287, %stack.offset.300
  %descriptor.extent.inside.306 = icmp ule i32 8, %stack.sub.305
  %descriptor.payload.inside.307 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.308 = and i1 %descriptor.owner.inside.303, %descriptor.offset.inside.304
  %descriptor.range.inside.310 = and i1 %descriptor.owner.offset.valid.308, %descriptor.extent.inside.306
  %descriptor.range.valid.309 = and i1 %descriptor.range.inside.310, %descriptor.payload.inside.307
  %descriptor.type.valid.311 = icmp eq i32 2, 2
  %descriptor.valid.312 = and i1 %descriptor.range.valid.309, %descriptor.type.valid.311
  br i1 %descriptor.valid.312, label %descriptor.valid.313, label %descriptor.invalid.314
descriptor.invalid.314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.313:
  %descriptor.initialized.status.315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.287, i32 8)
  %helper.ok.316 = icmp eq i32 %descriptor.initialized.status.315, 0
  br i1 %helper.ok.316, label %helper.continue.317, label %frame.failure.0
helper.continue.317:
  %descriptor.element.318 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.319 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 0
  store i32 2, ptr %descriptor.field.319, align 4
  %descriptor.field.320 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 1
  store i32 %context.value.287, ptr %descriptor.field.320, align 4
  %descriptor.field.321 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 2
  store i32 8, ptr %descriptor.field.321, align 4
  %descriptor.field.322 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 3
  store i32 8, ptr %descriptor.field.322, align 4
  %descriptor.field.323 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 4
  store i32 %stack.offset.300, ptr %descriptor.field.323, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.287, i32 20, i32 8, i32 %stack.offset.300, i32 8)
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %runtime.ok.326 = icmp eq i32 %context.value.325, 0
  br i1 %runtime.ok.326, label %runtime.continue.327, label %frame.failure.0
runtime.continue.327:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %context.field.330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.331 = load i32, ptr %context.field.330, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.offset.334 = add i32 %context.value.5, %context.value.7
  %stack.offset.335 = add i32 %context.value.329, %context.value.331
  %stack.sub.336 = sub i32 %stack.offset.334, %stack.offset.335
  %stack.sub.337 = sub i32 %context.value.7, %context.value.331
  %stack.sub.338 = sub i32 %context.value.333, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.336, i32 %stack.sub.337)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.338)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 17, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 4, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 17, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 17, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.extent.pointer.37 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.38 = load i32, ptr %input.extent.pointer.37, align 4
  %stack.sub.39 = sub i32 %input.bytes, %stack.offset.36
  %input.offset.within.bytes.40 = icmp ule i32 %stack.offset.36, %input.bytes
  %input.extent.within.bytes.41 = icmp ule i32 %input.host.extent.38, %stack.sub.39
  %input.slice.within.bytes.42 = and i1 %input.offset.within.bytes.40, %input.extent.within.bytes.41
  br i1 %input.slice.within.bytes.42, label %input.slice.ready.43, label %input.slice.invalid.44
input.slice.invalid.44:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.43:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.payload.pointer.46 = alloca i32, align 4
  %input.measured.extent.pointer.47 = alloca i32, align 4
  %input.measure.status.48 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.45, i32 %input.host.extent.38, i32 0, i32 18, ptr %input.payload.pointer.46, ptr %input.measured.extent.pointer.47)
  %helper.ok.49 = icmp eq i32 %input.measure.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %entry.failure.0
helper.continue.50:
  %input.measured.payload.51 = load i32, ptr %input.payload.pointer.46, align 4
  %input.measured.extent.52 = load i32, ptr %input.measured.extent.pointer.47, align 4
  %input.extent.exact.53 = icmp eq i32 %input.measured.extent.52, %input.host.extent.38
  br i1 %input.extent.exact.53, label %input.extent.exact.54, label %input.extent.invalid.55
input.extent.invalid.55:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 %input.measured.extent.52, i32 %input.host.extent.38)
  br label %entry.failure.0
input.extent.exact.54:
  %stack.offset.56 = add i32 %stack.offset.36, %input.host.extent.38
  %input.total.exact.57 = icmp eq i32 %stack.offset.56, %input.bytes
  br i1 %input.total.exact.57, label %input.valid.58, label %input.invalid.59
input.invalid.59:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.56, i32 %input.bytes)
  br label %entry.failure.0
input.valid.58:
  %reserve.status.60 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.56, i32 19)
  %reserve.ok.61 = icmp eq i32 %reserve.status.60, 0
  br i1 %reserve.ok.61, label %reserve.continue.62, label %entry.failure.0
reserve.continue.62:
  %host.pointer.63 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.64 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.63, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 6, i32 20)
  %helper.ok.65 = icmp eq i32 %input.copy.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %entry.failure.0
helper.continue.66:
  %stack.offset.67 = add i32 0, %input.host.extent.18
  %descriptor.element.68 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 0
  store i32 6, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 1
  store i32 0, ptr %descriptor.field.70, align 4
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.71, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.68, i32 0, i32 4
  store i32 %stack.offset.67, ptr %descriptor.field.73, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.67, i32 %input.host.extent.18)
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %runtime.ok.76 = icmp eq i32 %context.value.75, 0
  br i1 %runtime.ok.76, label %runtime.continue.77, label %entry.failure.0
runtime.continue.77:
  %host.pointer.78 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.36
  %input.copy.status.79 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.36, ptr %host.pointer.78, i32 %input.host.extent.38, i32 0, i32 %input.measured.payload.51, i32 %input.host.extent.38, i32 7, i32 21)
  %helper.ok.80 = icmp eq i32 %input.copy.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %entry.failure.0
helper.continue.81:
  %stack.offset.82 = add i32 %stack.offset.36, %input.host.extent.38
  %descriptor.element.83 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 1
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 0
  store i32 7, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 1
  store i32 %stack.offset.36, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 2
  store i32 %input.host.extent.38, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 3
  store i32 %input.measured.payload.51, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.83, i32 0, i32 4
  store i32 %stack.offset.82, ptr %descriptor.field.88, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.36, i32 20, i32 %input.measured.payload.51, i32 %stack.offset.82, i32 %input.host.extent.38)
  %context.field.89 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.90 = load i32, ptr %context.field.89, align 4
  %runtime.ok.91 = icmp eq i32 %context.value.90, 0
  br i1 %runtime.ok.91, label %runtime.continue.92, label %entry.failure.0
runtime.continue.92:
  %entry.validation.frame.entered.93 = call i32 @al_owning_enter_frame(ptr %ctx, i32 22)
  %helper.ok.94 = icmp eq i32 %entry.validation.frame.entered.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %entry.failure.0
helper.continue.95:
  %stack.offset.96 = add i32 0, %input.host.extent.18
  %input.option.case.97 = alloca i32, align 4
  %input.option.location.98 = alloca %AlOwningFieldLocation, align 4
  %input.option.status.99 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 4, i32 0, i32 %input.host.extent.18, i32 23, ptr %input.option.case.97, ptr %input.option.location.98)
  %helper.ok.100 = icmp eq i32 %input.option.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %entry.validation.failure.3
helper.continue.101:
  %input.option.tag.102 = load i32, ptr %input.option.case.97, align 4
  %input.option.is.some.103 = icmp eq i32 %input.option.tag.102, 0
  br i1 %input.option.is.some.103, label %input.option.some.104, label %input.option.validated.105
input.option.some.104:
  %input.option.offset.pointer.106 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.98, i32 0, i32 0
  %input.option.offset.107 = load i32, ptr %input.option.offset.pointer.106, align 4
  %input.option.payload.pointer.108 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.98, i32 0, i32 1
  %input.option.payload.109 = load i32, ptr %input.option.payload.pointer.108, align 4
  %input.option.extent.pointer.110 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.option.location.98, i32 0, i32 2
  %input.option.extent.111 = load i32, ptr %input.option.extent.pointer.110, align 4
  %validator.arguments.112 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.113 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.112, i32 0
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 0
  store i32 5, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 1
  store i32 %input.option.offset.107, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 2
  store i32 %input.option.extent.111, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 3
  store i32 %input.option.payload.109, ptr %descriptor.field.117, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 4
  store i32 %stack.offset.96, ptr %descriptor.field.118, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %input.option.offset.107, i32 20, i32 %input.option.payload.109, i32 %stack.offset.96, i32 %input.option.extent.111)
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %runtime.ok.121 = icmp eq i32 %context.value.120, 0
  br i1 %runtime.ok.121, label %runtime.continue.122, label %entry.validation.failure.3
runtime.continue.122:
  %validator.results.123 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.124 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.112, ptr %validator.results.123, i32 26)
  %helper.ok.125 = icmp eq i32 %validator.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %entry.validation.failure.3
helper.continue.126:
  %descriptor.element.127 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.123, i32 0
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 0
  %descriptor.value.129 = load i32, ptr %descriptor.field.128, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 1
  %descriptor.value.131 = load i32, ptr %descriptor.field.130, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 2
  %descriptor.value.133 = load i32, ptr %descriptor.field.132, align 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 3
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 4
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %validator.result.type.matches.138 = icmp eq i32 %descriptor.value.129, 2
  br i1 %validator.result.type.matches.138, label %validator.result.type.ok.139, label %validator.result.type.invalid.140
validator.result.type.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.139:
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %descriptor.value.137, %descriptor.value.131
  %descriptor.owner.inside.143 = icmp ule i32 %descriptor.value.137, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %descriptor.value.131, %descriptor.value.137
  %descriptor.extent.inside.146 = icmp ule i32 %descriptor.value.133, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %descriptor.value.135, %descriptor.value.133
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  %descriptor.type.valid.151 = icmp eq i32 2, 2
  %descriptor.valid.152 = and i1 %descriptor.range.valid.149, %descriptor.type.valid.151
  br i1 %descriptor.valid.152, label %descriptor.valid.153, label %descriptor.invalid.154
descriptor.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.153:
  %descriptor.initialized.status.155 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.131, i32 %descriptor.value.133)
  %helper.ok.156 = icmp eq i32 %descriptor.initialized.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %entry.validation.failure.3
helper.continue.157:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.131, i32 20, i32 %descriptor.value.135, i32 %descriptor.value.137, i32 %descriptor.value.133)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %entry.validation.failure.3
runtime.continue.161:
  %validator.bool.162 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.131)
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %runtime.ok.165 = icmp eq i32 %context.value.164, 0
  br i1 %runtime.ok.165, label %runtime.continue.166, label %entry.validation.failure.3
runtime.continue.166:
  %validator.bool.true.167 = icmp eq i64 %validator.bool.162, 1
  %validator.bool.false.168 = icmp eq i64 %validator.bool.162, 0
  %validator.bool.valid.169 = or i1 %validator.bool.true.167, %validator.bool.false.168
  br i1 %validator.bool.valid.169, label %validator.bool.check.170, label %validator.bool.invalid.171
validator.bool.invalid.171:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.170:
  br i1 %validator.bool.true.167, label %validator.true.173, label %validator.false.172
validator.false.172:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 24, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.173:
  br label %validator.join.174
validator.join.174:
  br label %input.option.validated.105
input.option.validated.105:
  %stack.offset.175 = add i32 %stack.offset.36, %input.host.extent.38
  %input.result.case.176 = alloca i32, align 4
  %input.result.location.177 = alloca %AlOwningFieldLocation, align 4
  %input.result.status.178 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @al_owning_layout, i32 5, i32 %stack.offset.36, i32 %input.host.extent.38, i32 27, ptr %input.result.case.176, ptr %input.result.location.177)
  %helper.ok.179 = icmp eq i32 %input.result.status.178, 0
  br i1 %helper.ok.179, label %helper.continue.180, label %entry.validation.failure.3
helper.continue.180:
  %input.result.tag.181 = load i32, ptr %input.result.case.176, align 4
  %input.result.is.ok.182 = icmp eq i32 %input.result.tag.181, 0
  br i1 %input.result.is.ok.182, label %input.result.ok.183, label %input.result.error.184
input.result.ok.183:
  br label %input.result.validated.185
input.result.error.184:
  %input.result.offset.pointer.186 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.177, i32 0, i32 0
  %input.result.offset.187 = load i32, ptr %input.result.offset.pointer.186, align 4
  %input.result.payload.pointer.188 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.177, i32 0, i32 1
  %input.result.payload.189 = load i32, ptr %input.result.payload.pointer.188, align 4
  %input.result.extent.pointer.190 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.177, i32 0, i32 2
  %input.result.extent.191 = load i32, ptr %input.result.extent.pointer.190, align 4
  %validator.arguments.192 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.193 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.192, i32 0
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 0
  store i32 5, ptr %descriptor.field.194, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 1
  store i32 %input.result.offset.187, ptr %descriptor.field.195, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 2
  store i32 %input.result.extent.191, ptr %descriptor.field.196, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 3
  store i32 %input.result.payload.189, ptr %descriptor.field.197, align 4
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 4
  store i32 %stack.offset.175, ptr %descriptor.field.198, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %input.result.offset.187, i32 20, i32 %input.result.payload.189, i32 %stack.offset.175, i32 %input.result.extent.191)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %entry.validation.failure.3
runtime.continue.202:
  %validator.results.203 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.204 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.192, ptr %validator.results.203, i32 30)
  %helper.ok.205 = icmp eq i32 %validator.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %entry.validation.failure.3
helper.continue.206:
  %descriptor.element.207 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.203, i32 0
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 0
  %descriptor.value.209 = load i32, ptr %descriptor.field.208, align 4
  %descriptor.field.210 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 1
  %descriptor.value.211 = load i32, ptr %descriptor.field.210, align 4
  %descriptor.field.212 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 2
  %descriptor.value.213 = load i32, ptr %descriptor.field.212, align 4
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 3
  %descriptor.value.215 = load i32, ptr %descriptor.field.214, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 4
  %descriptor.value.217 = load i32, ptr %descriptor.field.216, align 4
  %validator.result.type.matches.218 = icmp eq i32 %descriptor.value.209, 2
  br i1 %validator.result.type.matches.218, label %validator.result.type.ok.219, label %validator.result.type.invalid.220
validator.result.type.invalid.220:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 29, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.219:
  %context.field.221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.222 = load i32, ptr %context.field.221, align 4
  %stack.sub.225 = sub i32 %descriptor.value.217, %descriptor.value.211
  %descriptor.owner.inside.223 = icmp ule i32 %descriptor.value.217, %context.value.222
  %descriptor.offset.inside.224 = icmp ule i32 %descriptor.value.211, %descriptor.value.217
  %descriptor.extent.inside.226 = icmp ule i32 %descriptor.value.213, %stack.sub.225
  %descriptor.payload.inside.227 = icmp ule i32 %descriptor.value.215, %descriptor.value.213
  %descriptor.owner.offset.valid.228 = and i1 %descriptor.owner.inside.223, %descriptor.offset.inside.224
  %descriptor.range.inside.230 = and i1 %descriptor.owner.offset.valid.228, %descriptor.extent.inside.226
  %descriptor.range.valid.229 = and i1 %descriptor.range.inside.230, %descriptor.payload.inside.227
  %descriptor.type.valid.231 = icmp eq i32 2, 2
  %descriptor.valid.232 = and i1 %descriptor.range.valid.229, %descriptor.type.valid.231
  br i1 %descriptor.valid.232, label %descriptor.valid.233, label %descriptor.invalid.234
descriptor.invalid.234:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.233:
  %descriptor.initialized.status.235 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.211, i32 %descriptor.value.213)
  %helper.ok.236 = icmp eq i32 %descriptor.initialized.status.235, 0
  br i1 %helper.ok.236, label %helper.continue.237, label %entry.validation.failure.3
helper.continue.237:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.211, i32 20, i32 %descriptor.value.215, i32 %descriptor.value.217, i32 %descriptor.value.213)
  %context.field.238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.239 = load i32, ptr %context.field.238, align 4
  %runtime.ok.240 = icmp eq i32 %context.value.239, 0
  br i1 %runtime.ok.240, label %runtime.continue.241, label %entry.validation.failure.3
runtime.continue.241:
  %validator.bool.242 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.211)
  %context.field.243 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.244 = load i32, ptr %context.field.243, align 4
  %runtime.ok.245 = icmp eq i32 %context.value.244, 0
  br i1 %runtime.ok.245, label %runtime.continue.246, label %entry.validation.failure.3
runtime.continue.246:
  %validator.bool.true.247 = icmp eq i64 %validator.bool.242, 1
  %validator.bool.false.248 = icmp eq i64 %validator.bool.242, 0
  %validator.bool.valid.249 = or i1 %validator.bool.true.247, %validator.bool.false.248
  br i1 %validator.bool.valid.249, label %validator.bool.check.250, label %validator.bool.invalid.251
validator.bool.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 29, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.250:
  br i1 %validator.bool.true.247, label %validator.true.253, label %validator.false.252
validator.false.252:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 28, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.253:
  br label %validator.join.254
validator.join.254:
  br label %input.result.validated.185
input.result.validated.185:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.255
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.255:
  %entry.output.descriptors.256 = alloca [2 x %AlOwningDescriptor], align 4
  %entry.body.status.257 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.256, i32 31)
  %entry.body.ok.258 = icmp eq i32 %entry.body.status.257, 0
  br i1 %entry.body.ok.258, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.259 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.256, i32 0
  %descriptor.field.260 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.259, i32 0, i32 0
  %descriptor.value.261 = load i32, ptr %descriptor.field.260, align 4
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.259, i32 0, i32 1
  %descriptor.value.263 = load i32, ptr %descriptor.field.262, align 4
  %descriptor.field.264 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.259, i32 0, i32 2
  %descriptor.value.265 = load i32, ptr %descriptor.field.264, align 4
  %descriptor.field.266 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.259, i32 0, i32 3
  %descriptor.value.267 = load i32, ptr %descriptor.field.266, align 4
  %descriptor.field.268 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.259, i32 0, i32 4
  %descriptor.value.269 = load i32, ptr %descriptor.field.268, align 4
  %entry.output.type.valid.270 = icmp eq i32 %descriptor.value.261, 6
  br i1 %entry.output.type.valid.270, label %entry.output.type.ok.271, label %entry.output.type.invalid.272
entry.output.type.invalid.272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.271:
  %context.field.273 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.274 = load i32, ptr %context.field.273, align 4
  %stack.sub.277 = sub i32 %descriptor.value.269, %descriptor.value.263
  %descriptor.owner.inside.275 = icmp ule i32 %descriptor.value.269, %context.value.274
  %descriptor.offset.inside.276 = icmp ule i32 %descriptor.value.263, %descriptor.value.269
  %descriptor.extent.inside.278 = icmp ule i32 %descriptor.value.265, %stack.sub.277
  %descriptor.payload.inside.279 = icmp ule i32 %descriptor.value.267, %descriptor.value.265
  %descriptor.owner.offset.valid.280 = and i1 %descriptor.owner.inside.275, %descriptor.offset.inside.276
  %descriptor.range.inside.282 = and i1 %descriptor.owner.offset.valid.280, %descriptor.extent.inside.278
  %descriptor.range.valid.281 = and i1 %descriptor.range.inside.282, %descriptor.payload.inside.279
  %descriptor.type.valid.283 = icmp eq i32 6, 6
  %descriptor.valid.284 = and i1 %descriptor.range.valid.281, %descriptor.type.valid.283
  br i1 %descriptor.valid.284, label %descriptor.valid.285, label %descriptor.invalid.286
descriptor.invalid.286:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.285:
  %descriptor.initialized.status.287 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.263, i32 %descriptor.value.265)
  %helper.ok.288 = icmp eq i32 %descriptor.initialized.status.287, 0
  br i1 %helper.ok.288, label %helper.continue.289, label %entry.failure.0
helper.continue.289:
  %entry.output.size.i64.290 = zext i32 %descriptor.value.265 to i64
  %entry.output.total.i64.291 = add i64 0, %entry.output.size.i64.290
  %descriptor.element.292 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.256, i32 1
  %descriptor.field.293 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.292, i32 0, i32 0
  %descriptor.value.294 = load i32, ptr %descriptor.field.293, align 4
  %descriptor.field.295 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.292, i32 0, i32 1
  %descriptor.value.296 = load i32, ptr %descriptor.field.295, align 4
  %descriptor.field.297 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.292, i32 0, i32 2
  %descriptor.value.298 = load i32, ptr %descriptor.field.297, align 4
  %descriptor.field.299 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.292, i32 0, i32 3
  %descriptor.value.300 = load i32, ptr %descriptor.field.299, align 4
  %descriptor.field.301 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.292, i32 0, i32 4
  %descriptor.value.302 = load i32, ptr %descriptor.field.301, align 4
  %entry.output.type.valid.303 = icmp eq i32 %descriptor.value.294, 7
  br i1 %entry.output.type.valid.303, label %entry.output.type.ok.304, label %entry.output.type.invalid.305
entry.output.type.invalid.305:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.304:
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %stack.sub.310 = sub i32 %descriptor.value.302, %descriptor.value.296
  %descriptor.owner.inside.308 = icmp ule i32 %descriptor.value.302, %context.value.307
  %descriptor.offset.inside.309 = icmp ule i32 %descriptor.value.296, %descriptor.value.302
  %descriptor.extent.inside.311 = icmp ule i32 %descriptor.value.298, %stack.sub.310
  %descriptor.payload.inside.312 = icmp ule i32 %descriptor.value.300, %descriptor.value.298
  %descriptor.owner.offset.valid.313 = and i1 %descriptor.owner.inside.308, %descriptor.offset.inside.309
  %descriptor.range.inside.315 = and i1 %descriptor.owner.offset.valid.313, %descriptor.extent.inside.311
  %descriptor.range.valid.314 = and i1 %descriptor.range.inside.315, %descriptor.payload.inside.312
  %descriptor.type.valid.316 = icmp eq i32 7, 7
  %descriptor.valid.317 = and i1 %descriptor.range.valid.314, %descriptor.type.valid.316
  br i1 %descriptor.valid.317, label %descriptor.valid.318, label %descriptor.invalid.319
descriptor.invalid.319:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.318:
  %descriptor.initialized.status.320 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.296, i32 %descriptor.value.298)
  %helper.ok.321 = icmp eq i32 %descriptor.initialized.status.320, 0
  br i1 %helper.ok.321, label %helper.continue.322, label %entry.failure.0
helper.continue.322:
  %entry.output.size.i64.323 = zext i32 %descriptor.value.298 to i64
  %entry.output.total.i64.324 = add i64 %entry.output.total.i64.291, %entry.output.size.i64.323
  %entry.retained.capacity.i64.325 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.326 = icmp ule i64 %entry.output.total.i64.324, 4294967295
  %entry.retained.required.truncated.327 = trunc i64 %entry.output.total.i64.324 to i32
  %entry.retained.required.328 = select i1 %entry.retained.required.fits.u32.326, i32 %entry.retained.required.truncated.327, i32 4294967295
  %entry.retained.capacity.ok.329 = icmp ule i64 %entry.output.total.i64.324, %entry.retained.capacity.i64.325
  br i1 %entry.retained.capacity.ok.329, label %entry.retained.capacity.ready.330, label %entry.retained.capacity.failure.331
entry.retained.capacity.failure.331:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.328, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.330:
  %host.pointer.332 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.333 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.332, i32 %stack.sub.333, i32 %descriptor.value.263, i32 %descriptor.value.265, i32 6)
  %context.field.334 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.335 = load i32, ptr %context.field.334, align 4
  %runtime.ok.336 = icmp eq i32 %context.value.335, 0
  br i1 %runtime.ok.336, label %runtime.continue.337, label %entry.failure.0
runtime.continue.337:
  %stack.offset.338 = add i32 0, %descriptor.value.265
  %host.pointer.339 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.338
  %stack.sub.340 = sub i32 %retained.capacity, %stack.offset.338
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.339, i32 %stack.sub.340, i32 %descriptor.value.296, i32 %descriptor.value.298, i32 7)
  %context.field.341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.342 = load i32, ptr %context.field.341, align 4
  %runtime.ok.343 = icmp eq i32 %context.value.342, 0
  br i1 %runtime.ok.343, label %runtime.continue.344, label %entry.failure.0
runtime.continue.344:
  %stack.offset.345 = add i32 %stack.offset.338, %descriptor.value.298
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.347 = load i32, ptr %context.field.346, align 4
  %context.field.348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.349 = load i32, ptr %context.field.348, align 4
  %stack.sub.350 = sub i32 0, %context.value.347
  %stack.sub.351 = sub i32 0, %context.value.349
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.350, i32 %stack.sub.351)
  %context.field.352 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.353 = load i32, ptr %context.field.352, align 4
  %runtime.ok.354 = icmp eq i32 %context.value.353, 0
  br i1 %runtime.ok.354, label %runtime.continue.355, label %entry.failure.0
runtime.continue.355:
  br label %entry.return.status
entry.failure.0:
  %context.field.356 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.357 = load i32, ptr %context.field.356, align 4
  %context.field.358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.359 = load i32, ptr %context.field.358, align 4
  %context.field.360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.361 = load i32, ptr %context.field.360, align 4
  %stack.offset.362 = add i32 %context.value.357, %context.value.359
  %stack.sub.363 = sub i32 0, %stack.offset.362
  %stack.sub.364 = sub i32 0, %context.value.359
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.363, i32 %stack.sub.364)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.361)
  br label %entry.return.status
entry.return.status:
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  ret i32 %context.value.366
}


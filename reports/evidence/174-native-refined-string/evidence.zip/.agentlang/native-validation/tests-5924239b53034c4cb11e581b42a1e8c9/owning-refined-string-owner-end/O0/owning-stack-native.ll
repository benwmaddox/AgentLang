%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %field.location.51 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.52 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 0, i32 3, ptr %field.location.51)
  %helper.ok.53 = icmp eq i32 %field.location.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %field.offset.pointer.55 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.51, i32 0, i32 0
  %field.offset.56 = load i32, ptr %field.offset.pointer.55, align 4
  %field.payload.pointer.57 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.51, i32 0, i32 1
  %field.payload.58 = load i32, ptr %field.payload.pointer.57, align 4
  %field.extent.pointer.59 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.51, i32 0, i32 2
  %field.extent.60 = load i32, ptr %field.extent.pointer.59, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 4, i32 %descriptor.value.17, i32 %field.extent.60, i32 %field.payload.58, i32 %field.offset.56, i32 %field.extent.60)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %frame.failure.0
runtime.continue.64:
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %stack.sub.69 = sub i32 %descriptor.value.23, %field.offset.56
  %descriptor.owner.inside.67 = icmp ule i32 %descriptor.value.23, %context.value.66
  %descriptor.offset.inside.68 = icmp ule i32 %field.offset.56, %descriptor.value.23
  %descriptor.extent.inside.70 = icmp ule i32 %field.extent.60, %stack.sub.69
  %descriptor.payload.inside.71 = icmp ule i32 %field.payload.58, %field.extent.60
  %descriptor.owner.offset.valid.72 = and i1 %descriptor.owner.inside.67, %descriptor.offset.inside.68
  %descriptor.range.inside.74 = and i1 %descriptor.owner.offset.valid.72, %descriptor.extent.inside.70
  %descriptor.range.valid.73 = and i1 %descriptor.range.inside.74, %descriptor.payload.inside.71
  %descriptor.type.valid.75 = icmp eq i32 4, 4
  %descriptor.valid.76 = and i1 %descriptor.range.valid.73, %descriptor.type.valid.75
  br i1 %descriptor.valid.76, label %descriptor.valid.77, label %descriptor.invalid.78
descriptor.invalid.78:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.77:
  %descriptor.initialized.status.79 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.56, i32 %field.extent.60)
  %helper.ok.80 = icmp eq i32 %descriptor.initialized.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %step.status.82 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.83 = icmp eq i32 %step.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %inline.target.depth.within.interpreter.limit.87 = icmp ule i32 %context.value.86, 65
  br i1 %inline.target.depth.within.interpreter.limit.87, label %inline.target.depth.ok.88, label %inline.target.depth.invalid.89
inline.target.depth.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.88:
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %stack.sub.94 = sub i32 %descriptor.value.23, %field.offset.56
  %descriptor.owner.inside.92 = icmp ule i32 %descriptor.value.23, %context.value.91
  %descriptor.offset.inside.93 = icmp ule i32 %field.offset.56, %descriptor.value.23
  %descriptor.extent.inside.95 = icmp ule i32 %field.extent.60, %stack.sub.94
  %descriptor.payload.inside.96 = icmp ule i32 %field.payload.58, %field.extent.60
  %descriptor.owner.offset.valid.97 = and i1 %descriptor.owner.inside.92, %descriptor.offset.inside.93
  %descriptor.range.inside.99 = and i1 %descriptor.owner.offset.valid.97, %descriptor.extent.inside.95
  %descriptor.range.valid.98 = and i1 %descriptor.range.inside.99, %descriptor.payload.inside.96
  %descriptor.type.valid.100 = icmp eq i32 6, 6
  %descriptor.valid.101 = and i1 %descriptor.range.valid.98, %descriptor.type.valid.100
  br i1 %descriptor.valid.101, label %descriptor.valid.102, label %descriptor.invalid.103
descriptor.invalid.103:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.102:
  %descriptor.initialized.status.104 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.56, i32 %field.extent.60)
  %helper.ok.105 = icmp eq i32 %descriptor.initialized.status.104, 0
  br i1 %helper.ok.105, label %helper.continue.106, label %frame.failure.0
helper.continue.106:
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  store i32 6, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  store i32 %field.offset.56, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  store i32 %field.extent.60, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  store i32 %field.payload.58, ptr %descriptor.field.111, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.112, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %field.offset.56, i32 20, i32 %field.payload.58, i32 %descriptor.value.23, i32 %field.extent.60)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.5, %context.value.7
  %stack.offset.124 = add i32 %context.value.118, %context.value.120
  %stack.sub.125 = sub i32 %stack.offset.123, %stack.offset.124
  %stack.sub.126 = sub i32 %context.value.7, %context.value.120
  %stack.sub.127 = sub i32 %context.value.122, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.125, i32 %stack.sub.126)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.127)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %string.length.units.51 = alloca i32, align 4
  %string.length.status.52 = call i32 @al_owning_string_length(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 8, ptr %string.length.units.51)
  %helper.ok.53 = icmp eq i32 %string.length.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %string.length.value.55 = load i32, ptr %string.length.units.51, align 4
  %string.length.int.56 = zext i32 %string.length.value.55 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %runtime.ok.59 = icmp eq i32 %context.value.58, 0
  br i1 %runtime.ok.59, label %runtime.continue.60, label %frame.failure.0
runtime.continue.60:
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.62, 8
  %reserve.status.64 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.63, i32 9)
  %reserve.ok.65 = icmp eq i32 %reserve.status.64, 0
  br i1 %reserve.ok.65, label %reserve.continue.66, label %frame.failure.0
reserve.continue.66:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.62, i64 %string.length.int.56, i32 1)
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %runtime.ok.69 = icmp eq i32 %context.value.68, 0
  br i1 %runtime.ok.69, label %runtime.continue.70, label %frame.failure.0
runtime.continue.70:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %context.value.62, 8
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.78 = icmp ule i32 %stack.offset.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.81 = icmp ule i32 8, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  %descriptor.type.valid.86 = icmp eq i32 1, 1
  %descriptor.valid.87 = and i1 %descriptor.range.valid.84, %descriptor.type.valid.86
  br i1 %descriptor.valid.87, label %descriptor.valid.88, label %descriptor.invalid.89
descriptor.invalid.89:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.88:
  %descriptor.initialized.status.90 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.91 = icmp eq i32 %descriptor.initialized.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  %step.status.93 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.94 = icmp eq i32 %step.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.offset.98 = add i32 %context.value.97, 8
  %reserve.status.99 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.98, i32 11)
  %reserve.ok.100 = icmp eq i32 %reserve.status.99, 0
  br i1 %reserve.ok.100, label %reserve.continue.101, label %frame.failure.0
reserve.continue.101:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.97, i64 0, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %runtime.ok.108 = icmp eq i32 %context.value.107, 0
  br i1 %runtime.ok.108, label %runtime.continue.109, label %frame.failure.0
runtime.continue.109:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.sub.114 = sub i32 %stack.offset.75, %context.value.62
  %descriptor.owner.inside.112 = icmp ule i32 %stack.offset.75, %context.value.111
  %descriptor.offset.inside.113 = icmp ule i32 %context.value.62, %stack.offset.75
  %descriptor.extent.inside.115 = icmp ule i32 8, %stack.sub.114
  %descriptor.payload.inside.116 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.117 = and i1 %descriptor.owner.inside.112, %descriptor.offset.inside.113
  %descriptor.range.inside.119 = and i1 %descriptor.owner.offset.valid.117, %descriptor.extent.inside.115
  %descriptor.range.valid.118 = and i1 %descriptor.range.inside.119, %descriptor.payload.inside.116
  %descriptor.type.valid.120 = icmp eq i32 1, 1
  %descriptor.valid.121 = and i1 %descriptor.range.valid.118, %descriptor.type.valid.120
  br i1 %descriptor.valid.121, label %descriptor.valid.122, label %descriptor.invalid.123
descriptor.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.122:
  %descriptor.initialized.status.124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.62, i32 8)
  %helper.ok.125 = icmp eq i32 %descriptor.initialized.status.124, 0
  br i1 %helper.ok.125, label %helper.continue.126, label %frame.failure.0
helper.continue.126:
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.131 = sub i32 %stack.offset.98, %context.value.97
  %descriptor.owner.inside.129 = icmp ule i32 %stack.offset.98, %context.value.128
  %descriptor.offset.inside.130 = icmp ule i32 %context.value.97, %stack.offset.98
  %descriptor.extent.inside.132 = icmp ule i32 8, %stack.sub.131
  %descriptor.payload.inside.133 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.134 = and i1 %descriptor.owner.inside.129, %descriptor.offset.inside.130
  %descriptor.range.inside.136 = and i1 %descriptor.owner.offset.valid.134, %descriptor.extent.inside.132
  %descriptor.range.valid.135 = and i1 %descriptor.range.inside.136, %descriptor.payload.inside.133
  %descriptor.type.valid.137 = icmp eq i32 1, 1
  %descriptor.valid.138 = and i1 %descriptor.range.valid.135, %descriptor.type.valid.137
  br i1 %descriptor.valid.138, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.97, i32 8)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %inline.target.depth.within.interpreter.limit.149 = icmp ule i32 %context.value.148, 65
  br i1 %inline.target.depth.within.interpreter.limit.149, label %inline.target.depth.ok.150, label %inline.target.depth.invalid.151
inline.target.depth.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.150:
  %integer.left.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.62)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %integer.right.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.97)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %comparison.result.162 = icmp sgt i64 %integer.left.152, %integer.right.153
  %comparison.value.163 = zext i1 %comparison.result.162 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.97, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.62, i32 8, i32 8, i32 0, i32 0)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %frame.failure.0
runtime.continue.171:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.offset.174 = add i32 %context.value.173, 8
  %reserve.status.175 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.174, i32 14)
  %reserve.ok.176 = icmp eq i32 %reserve.status.175, 0
  br i1 %reserve.ok.176, label %reserve.continue.177, label %frame.failure.0
reserve.continue.177:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.173, i64 %comparison.value.163, i32 2)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %frame.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 %context.value.173, 8
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.186, %context.value.173
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.173, %stack.offset.186
  %descriptor.extent.inside.192 = icmp ule i32 8, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 2, 2
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.173, i32 8)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 2, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %context.value.173, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 8, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 8, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %stack.offset.186, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.173, i32 20, i32 8, i32 %stack.offset.186, i32 8)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.offset.220 = add i32 %context.value.5, %context.value.7
  %stack.offset.221 = add i32 %context.value.215, %context.value.217
  %stack.sub.222 = sub i32 %stack.offset.220, %stack.offset.221
  %stack.sub.223 = sub i32 %context.value.7, %context.value.217
  %stack.sub.224 = sub i32 %context.value.219, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.222, i32 %stack.sub.223)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.224)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %entry.context.ok.6 = icmp eq i32 %context.value.5, 0
  br i1 %entry.context.ok.6, label %entry.begin.ok.7, label %entry.failure.0
entry.begin.ok.7:
  %entry.input.count.ok.8 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.8, label %entry.input.counted.9, label %entry.input.count.failure.10
entry.input.count.failure.10:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.9:
  %entry.input.extents.present.11 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.12 = icmp ne ptr %input, null
  %entry.input.pointers.present.13 = and i1 %entry.input.extents.present.11, %entry.input.bytes.present.12
  br i1 %entry.input.pointers.present.13, label %entry.input.pointers.ok.14, label %entry.input.pointers.invalid.15
entry.input.pointers.invalid.15:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.14:
  %entry.input.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.17 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.18 = load i32, ptr %input.extent.pointer.17, align 4
  %stack.sub.19 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.20 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.21 = icmp ule i32 %input.host.extent.18, %stack.sub.19
  %input.slice.within.bytes.22 = and i1 %input.offset.within.bytes.20, %input.extent.within.bytes.21
  br i1 %input.slice.within.bytes.22, label %input.slice.ready.23, label %input.slice.invalid.24
input.slice.invalid.24:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.23:
  %host.pointer.25 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.26 = alloca i32, align 4
  %input.measured.extent.pointer.27 = alloca i32, align 4
  %input.measure.status.28 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.25, i32 %input.host.extent.18, i32 0, i32 15, ptr %input.payload.pointer.26, ptr %input.measured.extent.pointer.27)
  %helper.ok.29 = icmp eq i32 %input.measure.status.28, 0
  br i1 %helper.ok.29, label %helper.continue.30, label %entry.failure.0
helper.continue.30:
  %input.measured.payload.31 = load i32, ptr %input.payload.pointer.26, align 4
  %input.measured.extent.32 = load i32, ptr %input.measured.extent.pointer.27, align 4
  %input.extent.exact.33 = icmp eq i32 %input.measured.extent.32, %input.host.extent.18
  br i1 %input.extent.exact.33, label %input.extent.exact.34, label %input.extent.invalid.35
input.extent.invalid.35:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 15, i32 %input.measured.extent.32, i32 %input.host.extent.18)
  br label %entry.failure.0
input.extent.exact.34:
  %stack.offset.36 = add i32 0, %input.host.extent.18
  %input.total.exact.37 = icmp eq i32 %stack.offset.36, %input.bytes
  br i1 %input.total.exact.37, label %input.valid.38, label %input.invalid.39
input.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.36, i32 %input.bytes)
  br label %entry.failure.0
input.valid.38:
  %reserve.status.40 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.36, i32 16)
  %reserve.ok.41 = icmp eq i32 %reserve.status.40, 0
  br i1 %reserve.ok.41, label %reserve.continue.42, label %entry.failure.0
reserve.continue.42:
  %host.pointer.43 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.44 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.43, i32 %input.host.extent.18, i32 0, i32 %input.measured.payload.31, i32 %input.host.extent.18, i32 5, i32 17)
  %helper.ok.45 = icmp eq i32 %input.copy.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %stack.offset.47 = add i32 0, %input.host.extent.18
  %descriptor.element.48 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.16, i32 0
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 0
  store i32 5, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 1
  store i32 0, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 2
  store i32 %input.host.extent.18, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 3
  store i32 %input.measured.payload.31, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.48, i32 0, i32 4
  store i32 %stack.offset.47, ptr %descriptor.field.53, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.31, i32 %stack.offset.47, i32 %input.host.extent.18)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %entry.failure.0
runtime.continue.57:
  %entry.validation.frame.entered.58 = call i32 @al_owning_enter_frame(ptr %ctx, i32 18)
  %helper.ok.59 = icmp eq i32 %entry.validation.frame.entered.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %stack.offset.61 = add i32 0, %input.host.extent.18
  %input.field.location.62 = alloca %AlOwningFieldLocation, align 4
  %input.field.status.63 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 0, i32 %input.host.extent.18, i32 0, i32 19, ptr %input.field.location.62)
  %helper.ok.64 = icmp eq i32 %input.field.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %entry.validation.failure.3
helper.continue.65:
  %input.field.offset.pointer.66 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.62, i32 0, i32 0
  %input.field.offset.67 = load i32, ptr %input.field.offset.pointer.66, align 4
  %input.field.payload.pointer.68 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.62, i32 0, i32 1
  %input.field.payload.69 = load i32, ptr %input.field.payload.pointer.68, align 4
  %input.field.extent.pointer.70 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.62, i32 0, i32 2
  %input.field.extent.71 = load i32, ptr %input.field.extent.pointer.70, align 4
  %validator.arguments.72 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.72, i32 0
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  store i32 6, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  store i32 %input.field.offset.67, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  store i32 %input.field.extent.71, ptr %descriptor.field.76, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  store i32 %input.field.payload.69, ptr %descriptor.field.77, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  store i32 %stack.offset.61, ptr %descriptor.field.78, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %input.field.offset.67, i32 20, i32 %input.field.payload.69, i32 %stack.offset.61, i32 %input.field.extent.71)
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %runtime.ok.81 = icmp eq i32 %context.value.80, 0
  br i1 %runtime.ok.81, label %runtime.continue.82, label %entry.validation.failure.3
runtime.continue.82:
  %validator.results.83 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.status.84 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.72, ptr %validator.results.83, i32 22)
  %helper.ok.85 = icmp eq i32 %validator.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %entry.validation.failure.3
helper.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.83, i32 0
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  %descriptor.value.91 = load i32, ptr %descriptor.field.90, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  %descriptor.value.93 = load i32, ptr %descriptor.field.92, align 4
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  %descriptor.value.95 = load i32, ptr %descriptor.field.94, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  %descriptor.value.97 = load i32, ptr %descriptor.field.96, align 4
  %validator.result.type.matches.98 = icmp eq i32 %descriptor.value.89, 2
  br i1 %validator.result.type.matches.98, label %validator.result.type.ok.99, label %validator.result.type.invalid.100
validator.result.type.invalid.100:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.result.type.ok.99:
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %stack.sub.105 = sub i32 %descriptor.value.97, %descriptor.value.91
  %descriptor.owner.inside.103 = icmp ule i32 %descriptor.value.97, %context.value.102
  %descriptor.offset.inside.104 = icmp ule i32 %descriptor.value.91, %descriptor.value.97
  %descriptor.extent.inside.106 = icmp ule i32 %descriptor.value.93, %stack.sub.105
  %descriptor.payload.inside.107 = icmp ule i32 %descriptor.value.95, %descriptor.value.93
  %descriptor.owner.offset.valid.108 = and i1 %descriptor.owner.inside.103, %descriptor.offset.inside.104
  %descriptor.range.inside.110 = and i1 %descriptor.owner.offset.valid.108, %descriptor.extent.inside.106
  %descriptor.range.valid.109 = and i1 %descriptor.range.inside.110, %descriptor.payload.inside.107
  %descriptor.type.valid.111 = icmp eq i32 2, 2
  %descriptor.valid.112 = and i1 %descriptor.range.valid.109, %descriptor.type.valid.111
  br i1 %descriptor.valid.112, label %descriptor.valid.113, label %descriptor.invalid.114
descriptor.invalid.114:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.validation.failure.3
descriptor.valid.113:
  %descriptor.initialized.status.115 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.91, i32 %descriptor.value.93)
  %helper.ok.116 = icmp eq i32 %descriptor.initialized.status.115, 0
  br i1 %helper.ok.116, label %helper.continue.117, label %entry.validation.failure.3
helper.continue.117:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.91, i32 20, i32 %descriptor.value.95, i32 %descriptor.value.97, i32 %descriptor.value.93)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %entry.validation.failure.3
runtime.continue.121:
  %validator.bool.122 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.91)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %entry.validation.failure.3
runtime.continue.126:
  %validator.bool.true.127 = icmp eq i64 %validator.bool.122, 1
  %validator.bool.false.128 = icmp eq i64 %validator.bool.122, 0
  %validator.bool.valid.129 = or i1 %validator.bool.true.127, %validator.bool.false.128
  br i1 %validator.bool.valid.129, label %validator.bool.check.130, label %validator.bool.invalid.131
validator.bool.invalid.131:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.bool.check.130:
  br i1 %validator.bool.true.127, label %validator.true.133, label %validator.false.132
validator.false.132:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 20, i32 0, i32 0)
  br label %entry.validation.failure.3
validator.true.133:
  br label %validator.join.134
validator.join.134:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.validation.succeeded.135
entry.validation.failure.3:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %entry.failure.0
entry.validation.succeeded.135:
  %entry.output.descriptors.136 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.137 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.16, ptr %entry.output.descriptors.136, i32 23)
  %entry.body.ok.138 = icmp eq i32 %entry.body.status.137, 0
  br i1 %entry.body.ok.138, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.139 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.136, i32 0
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 0
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 1
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 2
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 3
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 4
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %entry.output.type.valid.150 = icmp eq i32 %descriptor.value.141, 6
  br i1 %entry.output.type.valid.150, label %entry.output.type.ok.151, label %entry.output.type.invalid.152
entry.output.type.invalid.152:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.151:
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %stack.sub.157 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.155 = icmp ule i32 %descriptor.value.149, %context.value.154
  %descriptor.offset.inside.156 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.158 = icmp ule i32 %descriptor.value.145, %stack.sub.157
  %descriptor.payload.inside.159 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.160 = and i1 %descriptor.owner.inside.155, %descriptor.offset.inside.156
  %descriptor.range.inside.162 = and i1 %descriptor.owner.offset.valid.160, %descriptor.extent.inside.158
  %descriptor.range.valid.161 = and i1 %descriptor.range.inside.162, %descriptor.payload.inside.159
  %descriptor.type.valid.163 = icmp eq i32 6, 6
  %descriptor.valid.164 = and i1 %descriptor.range.valid.161, %descriptor.type.valid.163
  br i1 %descriptor.valid.164, label %descriptor.valid.165, label %descriptor.invalid.166
descriptor.invalid.166:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.165:
  %descriptor.initialized.status.167 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.168 = icmp eq i32 %descriptor.initialized.status.167, 0
  br i1 %helper.ok.168, label %helper.continue.169, label %entry.failure.0
helper.continue.169:
  %entry.output.size.i64.170 = zext i32 %descriptor.value.145 to i64
  %entry.output.total.i64.171 = add i64 0, %entry.output.size.i64.170
  %entry.retained.capacity.i64.172 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.173 = icmp ule i64 %entry.output.total.i64.171, 4294967295
  %entry.retained.required.truncated.174 = trunc i64 %entry.output.total.i64.171 to i32
  %entry.retained.required.175 = select i1 %entry.retained.required.fits.u32.173, i32 %entry.retained.required.truncated.174, i32 4294967295
  %entry.retained.capacity.ok.176 = icmp ule i64 %entry.output.total.i64.171, %entry.retained.capacity.i64.172
  br i1 %entry.retained.capacity.ok.176, label %entry.retained.capacity.ready.177, label %entry.retained.capacity.failure.178
entry.retained.capacity.failure.178:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.175, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.177:
  %host.pointer.179 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.180 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.179, i32 %stack.sub.180, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 6)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %entry.failure.0
runtime.continue.184:
  %stack.offset.185 = add i32 0, %descriptor.value.145
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %stack.sub.190 = sub i32 0, %context.value.187
  %stack.sub.191 = sub i32 0, %context.value.189
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.190, i32 %stack.sub.191)
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %runtime.ok.194 = icmp eq i32 %context.value.193, 0
  br i1 %runtime.ok.194, label %runtime.continue.195, label %entry.failure.0
runtime.continue.195:
  br label %entry.return.status
entry.failure.0:
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %stack.offset.202 = add i32 %context.value.197, %context.value.199
  %stack.sub.203 = sub i32 0, %stack.offset.202
  %stack.sub.204 = sub i32 0, %context.value.199
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.203, i32 %stack.sub.204)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.201)
  br label %entry.return.status
entry.return.status:
  %context.field.205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.206 = load i32, ptr %context.field.205, align 4
  ret i32 %context.value.206
}


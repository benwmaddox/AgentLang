%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 3, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %validator.arguments.51 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.52 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.51, i32 0
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 0
  store i32 5, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.56, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.57, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %validator.results.62 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %validator.depth.within.interpreter.limit.65 = icmp ule i32 %context.value.64, 64
  br i1 %validator.depth.within.interpreter.limit.65, label %validator.depth.ok.66, label %validator.depth.invalid.67
validator.depth.invalid.67:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.66:
  %validator.status.68 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.51, ptr %validator.results.62, i32 5)
  %helper.ok.69 = icmp eq i32 %validator.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %descriptor.element.71 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.62, i32 0
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 0
  %descriptor.value.73 = load i32, ptr %descriptor.field.72, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 1
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 2
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 3
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 4
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %validator.result.type.matches.82 = icmp eq i32 %descriptor.value.73, 2
  br i1 %validator.result.type.matches.82, label %validator.result.type.ok.83, label %validator.result.type.invalid.84
validator.result.type.invalid.84:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.83:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.81, %descriptor.value.75
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.81, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.75, %descriptor.value.81
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.77, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.79, %descriptor.value.77
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 2, 2
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.75, i32 %descriptor.value.77)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.75, i32 20, i32 %descriptor.value.79, i32 %descriptor.value.81, i32 %descriptor.value.77)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %validator.bool.106 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.75)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %runtime.ok.109 = icmp eq i32 %context.value.108, 0
  br i1 %runtime.ok.109, label %runtime.continue.110, label %frame.failure.0
runtime.continue.110:
  %validator.bool.true.111 = icmp eq i64 %validator.bool.106, 1
  %validator.bool.false.112 = icmp eq i64 %validator.bool.106, 0
  %validator.bool.valid.113 = or i1 %validator.bool.true.111, %validator.bool.false.112
  br i1 %validator.bool.valid.113, label %validator.bool.check.114, label %validator.bool.invalid.115
validator.bool.invalid.115:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.114:
  br i1 %validator.bool.true.111, label %validator.true.117, label %validator.false.116
validator.false.116:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 3, i32 0, i32 0)
  br label %frame.failure.0
validator.true.117:
  br label %validator.join.118
validator.join.118:
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.121 = icmp ule i32 %descriptor.value.23, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.124 = icmp ule i32 %descriptor.value.19, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  %descriptor.type.valid.129 = icmp eq i32 4, 4
  %descriptor.valid.130 = and i1 %descriptor.range.valid.127, %descriptor.type.valid.129
  br i1 %descriptor.valid.130, label %descriptor.valid.131, label %descriptor.invalid.132
descriptor.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.131:
  %descriptor.initialized.status.133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.134 = icmp eq i32 %descriptor.initialized.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %descriptor.element.136 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 0
  store i32 4, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.140, align 4
  %descriptor.field.141 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.141, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %frame.failure.0
runtime.continue.145:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %stack.offset.152 = add i32 %context.value.5, %context.value.7
  %stack.offset.153 = add i32 %context.value.147, %context.value.149
  %stack.sub.154 = sub i32 %stack.offset.152, %stack.offset.153
  %stack.sub.155 = sub i32 %context.value.7, %context.value.149
  %stack.sub.156 = sub i32 %context.value.151, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.154, i32 %stack.sub.155)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.156)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 9)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.offset.94 = add i32 %context.value.93, 8
  %reserve.status.95 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 11)
  %reserve.ok.96 = icmp eq i32 %reserve.status.95, 0
  br i1 %reserve.ok.96, label %reserve.continue.97, label %frame.failure.0
reserve.continue.97:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.93, i64 0, i32 1)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %stack.sub.110 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.108 = icmp ule i32 %stack.offset.60, %context.value.107
  %descriptor.offset.inside.109 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.111 = icmp ule i32 8, %stack.sub.110
  %descriptor.payload.inside.112 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.113 = and i1 %descriptor.owner.inside.108, %descriptor.offset.inside.109
  %descriptor.range.inside.115 = and i1 %descriptor.owner.offset.valid.113, %descriptor.extent.inside.111
  %descriptor.range.valid.114 = and i1 %descriptor.range.inside.115, %descriptor.payload.inside.112
  %descriptor.type.valid.116 = icmp eq i32 1, 1
  %descriptor.valid.117 = and i1 %descriptor.range.valid.114, %descriptor.type.valid.116
  br i1 %descriptor.valid.117, label %descriptor.valid.118, label %descriptor.invalid.119
descriptor.invalid.119:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.118:
  %descriptor.initialized.status.120 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.121 = icmp eq i32 %descriptor.initialized.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %frame.failure.0
helper.continue.122:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %stack.offset.94, %context.value.93
  %descriptor.owner.inside.125 = icmp ule i32 %stack.offset.94, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %context.value.93, %stack.offset.94
  %descriptor.extent.inside.128 = icmp ule i32 8, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 1, 1
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.93, i32 8)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %step.status.140 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.141 = icmp eq i32 %step.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %inline.target.depth.within.interpreter.limit.145 = icmp ule i32 %context.value.144, 65
  br i1 %inline.target.depth.within.interpreter.limit.145, label %inline.target.depth.ok.146, label %inline.target.depth.invalid.147
inline.target.depth.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 13, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.146:
  %integer.left.148 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.59)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %integer.right.149 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.93)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %divide.zero.158 = icmp eq i64 %integer.right.149, 0
  br i1 %divide.zero.158, label %divide.zero.159, label %divide.nonzero.160
divide.zero.159:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.160:
  %divide.min.161 = icmp eq i64 %integer.left.148, -9223372036854775808
  %divide.minusone.162 = icmp eq i64 %integer.right.149, -1
  %divide.overflow.163 = and i1 %divide.min.161, %divide.minusone.162
  br i1 %divide.overflow.163, label %divide.overflow.164, label %divide.valid.165
divide.overflow.164:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 15, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.165:
  %divide.result.166 = sdiv i64 %integer.left.148, %integer.right.149
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.93, i32 8, i32 8, i32 0, i32 0)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.59, i32 8, i32 8, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.176, 8
  %reserve.status.178 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.177, i32 16)
  %reserve.ok.179 = icmp eq i32 %reserve.status.178, 0
  br i1 %reserve.ok.179, label %reserve.continue.180, label %frame.failure.0
reserve.continue.180:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.176, i64 %divide.result.166, i32 1)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %stack.offset.189 = add i32 %context.value.176, 8
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.192 = icmp ule i32 %stack.offset.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.195 = icmp ule i32 8, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 1, 1
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.offset.212 = add i32 %context.value.211, 8
  %reserve.status.213 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.212, i32 18)
  %reserve.ok.214 = icmp eq i32 %reserve.status.213, 0
  br i1 %reserve.ok.214, label %reserve.continue.215, label %frame.failure.0
reserve.continue.215:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.211, i64 0, i32 1)
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %runtime.ok.218 = icmp eq i32 %context.value.217, 0
  br i1 %runtime.ok.218, label %runtime.continue.219, label %frame.failure.0
runtime.continue.219:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %stack.sub.228 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.226 = icmp ule i32 %stack.offset.189, %context.value.225
  %descriptor.offset.inside.227 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.229 = icmp ule i32 8, %stack.sub.228
  %descriptor.payload.inside.230 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.231 = and i1 %descriptor.owner.inside.226, %descriptor.offset.inside.227
  %descriptor.range.inside.233 = and i1 %descriptor.owner.offset.valid.231, %descriptor.extent.inside.229
  %descriptor.range.valid.232 = and i1 %descriptor.range.inside.233, %descriptor.payload.inside.230
  %descriptor.type.valid.234 = icmp eq i32 1, 1
  %descriptor.valid.235 = and i1 %descriptor.range.valid.232, %descriptor.type.valid.234
  br i1 %descriptor.valid.235, label %descriptor.valid.236, label %descriptor.invalid.237
descriptor.invalid.237:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.236:
  %descriptor.initialized.status.238 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.239 = icmp eq i32 %descriptor.initialized.status.238, 0
  br i1 %helper.ok.239, label %helper.continue.240, label %frame.failure.0
helper.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %stack.offset.212, %context.value.211
  %descriptor.owner.inside.243 = icmp ule i32 %stack.offset.212, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %context.value.211, %stack.offset.212
  %descriptor.extent.inside.246 = icmp ule i32 8, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  %descriptor.type.valid.251 = icmp eq i32 1, 1
  %descriptor.valid.252 = and i1 %descriptor.range.valid.249, %descriptor.type.valid.251
  br i1 %descriptor.valid.252, label %descriptor.valid.253, label %descriptor.invalid.254
descriptor.invalid.254:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.253:
  %descriptor.initialized.status.255 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.211, i32 8)
  %helper.ok.256 = icmp eq i32 %descriptor.initialized.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %step.status.258 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.259 = icmp eq i32 %step.status.258, 0
  br i1 %helper.ok.259, label %helper.continue.260, label %frame.failure.0
helper.continue.260:
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %inline.target.depth.within.interpreter.limit.263 = icmp ule i32 %context.value.262, 65
  br i1 %inline.target.depth.within.interpreter.limit.263, label %inline.target.depth.ok.264, label %inline.target.depth.invalid.265
inline.target.depth.invalid.265:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 20, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.264:
  %integer.left.266 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.176)
  %context.field.268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.269 = load i32, ptr %context.field.268, align 4
  %runtime.ok.270 = icmp eq i32 %context.value.269, 0
  br i1 %runtime.ok.270, label %runtime.continue.271, label %frame.failure.0
runtime.continue.271:
  %integer.right.267 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.211)
  %context.field.272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.273 = load i32, ptr %context.field.272, align 4
  %runtime.ok.274 = icmp eq i32 %context.value.273, 0
  br i1 %runtime.ok.274, label %runtime.continue.275, label %frame.failure.0
runtime.continue.275:
  %comparison.result.276 = icmp sgt i64 %integer.left.266, %integer.right.267
  %comparison.value.277 = zext i1 %comparison.result.276 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.211, i32 8, i32 8, i32 0, i32 0)
  %context.field.278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.279 = load i32, ptr %context.field.278, align 4
  %runtime.ok.280 = icmp eq i32 %context.value.279, 0
  br i1 %runtime.ok.280, label %runtime.continue.281, label %frame.failure.0
runtime.continue.281:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.176, i32 8, i32 8, i32 0, i32 0)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.offset.288 = add i32 %context.value.287, 8
  %reserve.status.289 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.288, i32 21)
  %reserve.ok.290 = icmp eq i32 %reserve.status.289, 0
  br i1 %reserve.ok.290, label %reserve.continue.291, label %frame.failure.0
reserve.continue.291:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.287, i64 %comparison.value.277, i32 2)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %runtime.ok.298 = icmp eq i32 %context.value.297, 0
  br i1 %runtime.ok.298, label %runtime.continue.299, label %frame.failure.0
runtime.continue.299:
  %stack.offset.300 = add i32 %context.value.287, 8
  %context.field.301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.302 = load i32, ptr %context.field.301, align 4
  %stack.sub.305 = sub i32 %stack.offset.300, %context.value.287
  %descriptor.owner.inside.303 = icmp ule i32 %stack.offset.300, %context.value.302
  %descriptor.offset.inside.304 = icmp ule i32 %context.value.287, %stack.offset.300
  %descriptor.extent.inside.306 = icmp ule i32 8, %stack.sub.305
  %descriptor.payload.inside.307 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.308 = and i1 %descriptor.owner.inside.303, %descriptor.offset.inside.304
  %descriptor.range.inside.310 = and i1 %descriptor.owner.offset.valid.308, %descriptor.extent.inside.306
  %descriptor.range.valid.309 = and i1 %descriptor.range.inside.310, %descriptor.payload.inside.307
  %descriptor.type.valid.311 = icmp eq i32 2, 2
  %descriptor.valid.312 = and i1 %descriptor.range.valid.309, %descriptor.type.valid.311
  br i1 %descriptor.valid.312, label %descriptor.valid.313, label %descriptor.invalid.314
descriptor.invalid.314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.313:
  %descriptor.initialized.status.315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.287, i32 8)
  %helper.ok.316 = icmp eq i32 %descriptor.initialized.status.315, 0
  br i1 %helper.ok.316, label %helper.continue.317, label %frame.failure.0
helper.continue.317:
  %descriptor.element.318 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.319 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 0
  store i32 2, ptr %descriptor.field.319, align 4
  %descriptor.field.320 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 1
  store i32 %context.value.287, ptr %descriptor.field.320, align 4
  %descriptor.field.321 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 2
  store i32 8, ptr %descriptor.field.321, align 4
  %descriptor.field.322 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 3
  store i32 8, ptr %descriptor.field.322, align 4
  %descriptor.field.323 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 4
  store i32 %stack.offset.300, ptr %descriptor.field.323, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.287, i32 20, i32 8, i32 %stack.offset.300, i32 8)
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %runtime.ok.326 = icmp eq i32 %context.value.325, 0
  br i1 %runtime.ok.326, label %runtime.continue.327, label %frame.failure.0
runtime.continue.327:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %context.field.330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.331 = load i32, ptr %context.field.330, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.offset.334 = add i32 %context.value.5, %context.value.7
  %stack.offset.335 = add i32 %context.value.329, %context.value.331
  %stack.sub.336 = sub i32 %stack.offset.334, %stack.offset.335
  %stack.sub.337 = sub i32 %context.value.7, %context.value.331
  %stack.sub.338 = sub i32 %context.value.333, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.336, i32 %stack.sub.337)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.338)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 22, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 22, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 22, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 23)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 5, i32 24)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 5, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 25)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 4
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 4, 4
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 4)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


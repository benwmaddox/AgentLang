"""Seal the final native Unit receipts without binaries or compiler artifacts."""
from pathlib import Path
import hashlib
import json
import zipfile

repo = Path(__file__).resolve().parents[2]
root = repo / '.agentlang/native-unit-202'
gates = json.loads((root / 'accepted-gates.json').read_text(encoding='utf-8-sig'))
if not gates.get('passed') or any(gate['exitCode'] != 0 for gate in gates['gates']):
    raise SystemExit('Refusing to seal unaccepted gates')
target = repo / 'reports/evidence/202-native-unit-canonicality'
target.mkdir(parents=True, exist_ok=True)
archive = target / 'validation.zip'
index = target / 'validation.index.json'
if archive.exists() or index.exists():
    raise SystemExit('Refusing to replace sealed evidence')
allowed = {'candidate', 'logs', 'evidence'}
files = [p for p in root.rglob('*') if p.is_file()
         and (len(p.relative_to(root).parts) == 1 or p.relative_to(root).parts[0] in allowed)
         and not any(part in {'bin', 'obj', 'tmp', '__pycache__'} for part in p.relative_to(root).parts)
         and p.suffix.lower() not in {'.dll', '.exe', '.pdb'}]
entries = [(p.relative_to(root).as_posix(), p) for p in files]
sources = ['src/AgentLang.Llvm/native/owning_stack_runtime.c',
           'src/AgentLang.Llvm/native/owning_stack_runtime_test.c',
           'tests/AgentLang.Llvm.Tests/Program.fs',
           'tests/fixtures/native-conformance/native-value-stack.json']
entries += [('accepted-source/' + path, repo / path) for path in sources]
members = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(entries):
        data = p.read_bytes()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for member in members:
        data = z.read(member['path'])
        assert len(data) == member['bytes']
        assert hashlib.sha256(data).hexdigest() == member['sha256']
receipt = {'archive': archive.name, 'bytes': archive.stat().st_size,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': members}
index.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))
print('Verified members:', len(members))

$ErrorActionPreference = 'Stop'
$repoRoot = (Get-Location).Path
$taskRoot = Join-Path $repoRoot '.agentlang/native-unit-202'
$logRoot = Join-Path $taskRoot 'logs'
$tmpRoot = Join-Path $taskRoot 'tmp'
New-Item -ItemType Directory -Force -Path $logRoot, $tmpRoot | Out-Null
$env:TEMP = $tmpRoot
$env:TMP = $tmpRoot
$dotnetExe = (Get-Command dotnet -CommandType Application).Source
$wrapperText = @'
function dotnet {
    if ($args.Count -gt 0 -and [string]$args[0] -ceq 'build') {
        & $dotnetExe @args '-m:1' '-p:NuGetAudit=false'
    } else {
        & $dotnetExe @args
    }
}
Verifier command: pwsh -NoLogo -NoProfile -File scripts/Verify-NativeConformance.ps1
Effective build adjustment: append -m:1 -p:NuGetAudit=false only when the script invokes dotnet build; other dotnet invocations pass through unchanged.
'@
Set-Content -LiteralPath (Join-Path $logRoot 'native-conformance-serial-audit-disabled-wrapper.txt') -Value $wrapperText -Encoding utf8
$stdoutPath = Join-Path $logRoot 'native-conformance-serial-audit-disabled.stdout.log'
$stderrPath = Join-Path $logRoot 'native-conformance-serial-audit-disabled.stderr.log'
$exitPath = Join-Path $logRoot 'native-conformance-serial-audit-disabled.exit.txt'
function dotnet {
    if ($args.Count -gt 0 -and [string]$args[0] -ceq 'build') {
        & $dotnetExe @args '-m:1' '-p:NuGetAudit=false'
    } else {
        & $dotnetExe @args
    }
}
$LASTEXITCODE = 0
try {
    & 'scripts/Verify-NativeConformance.ps1' 1> $stdoutPath 2> $stderrPath
    $exitCode = $LASTEXITCODE
} catch {
    $_ | Out-String | Add-Content -LiteralPath $stderrPath -Encoding utf8
    $exitCode = 1
}
Set-Content -LiteralPath $exitPath -Value $exitCode -Encoding ascii
Write-Output "Verifier exit: $exitCode"
Write-Output "Stdout: $stdoutPath"
Write-Output "Stderr: $stderrPath"
Write-Output "Dotnet: $dotnetExe"
> **Superseded source-only preparation receipt.** This records the earlier unapplied candidate phase only. Implementation and native validation are complete in ../implementation-202-receipt.md; its former no-build/no-test statement applies only to that earlier phase.

# Native canonical Unit candidate receipt

Status: unapplied source candidate. The four source inputs were copied into `candidate/input/`; all proposed edits are in `candidate/proposed/`. The unified repository-relative patch is `../candidate.patch`.

The scanner edit follows the managed representation: `OwningStackAot.fs` encodes `UnitValue` as eight zero bytes and rejects any nonzero eight-byte Unit token while decoding. `IrInterpreter.fs` represents Unit as the single `RuntimeUnit` case and evaluates `equals` structurally. The native change therefore checks the active Unit slot after the existing owner-bounded eight-byte readability check, and uses the existing scanner failure path before the scanner publishes payload or extent outputs.

The C candidate covers external and stack-owned canonical zero, malformed low and high-byte tokens, every truncated external size from 0 through 7, owner lengths from 0 through 7, output sentinels, stack guards, recursive `Some Unit`, and `None` with nonzero inactive storage. Its new dynamic case has 37 executed `AL_CHECK` invocations: two valid root checks; three malformed root patterns with external and stack checks; eight short-source/short-owner pairs; two valid `Some` checks; three malformed active `Some` patterns with external and stack checks; four `None` checks (16-byte inactive storage and tag-only input, each external and stack-owned); and one final guard check.

The fixture changes only the storage scanner oracle counts: total 52 cases / 704 checks, dynamic 36 cases / 515 checks. The fixed baseline remains 16 / 189. No ABI, layout schema, or metric fields are changed; layout schema 3 and stack/mailbox/module ABI 1 remain as before. The LLVM candidate compares the interpreter’s Unit, `Some Unit`, and `None` values with owning O0/O2 output bytes and uses the interpreter helper for the four-instruction fuel oracle.

No build or test was run. Validation remains deferred for the owning C O0/O2 scanner verifier and the full LLVM native conformance gate. The four input copies still match the checkout by SHA256 at receipt time.

| Repository-relative input | SHA256 |
| --- | --- |
| `src/AgentLang.Llvm/native/owning_stack_runtime.c` | `E5026D12FBA6C151F4D2E721FC8178116F46BAAD47F8B2DB5A7619E55F5482D8` |
| `src/AgentLang.Llvm/native/owning_stack_runtime_test.c` | `AB6F9578FB3E86740580B823F18D941994DD64A70F200AB73A06CD6B104AF286` |
| `tests/AgentLang.Llvm.Tests/Program.fs` | `2C3B36F23EF2ED24FDB7A8C825FA32678C3A0B2FDFE66DCF674121CAE53766B9` |
| `tests/fixtures/native-conformance/native-value-stack.json` | `7D40AB1CD593F38005964785B573EA2C147F20AE69825DCC8A27CB98EE29966E` |

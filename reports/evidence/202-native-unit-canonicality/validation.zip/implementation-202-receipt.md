# Native Unit canonicality 202 implementation receipt

Status: implementation and scoped native acceptance complete. No commit or push was made. Branch: fix/native-unit-canonicality-202. Base: 7d1acf8a7d3e47af3852e92c2471ebe68ce0ad53. Root-owned documentation and unrelated untracked work were preserved.

## Change and audit

The native scanner enforces zero-only Unit after the existing owner-bounded 8-byte readability check. A nonzero token uses the existing scan failure path before payload or extent outputs are published. This matches OwningStackAot.fs, which encodes Unit as eight zero bytes and rejects nonzero Unit during decode; IrInterpreter.fs represents Unit as RuntimeUnit.

C tests cover external and stack-owned zero and malformed Unit tokens (including low and high bytes), every truncated length and owner end from 0 through 7, output sentinels, stack guards, recursive Some Unit, and None with nonzero inactive storage. The Option descriptor has first_field=0 and field_count=2. The new case adds 37 explicit AL_CHECK calls: 2 valid root + 6 malformed root + 16 truncation/short-owner + 2 valid Some + 6 malformed active Some + 4 None + 1 final guard.

The LLVM test compares interpreter, owning O0, and owning O2 values and bytes for Unit, Some Unit, and None; it asserts schema 3 and uses invokeRawOwningEntryForMetrics for the independent 4-instruction fuel oracle. Fixture counts are 52 cases / 704 checks total, 36 / 515 dynamic. Fixed baseline 16 / 189 is unchanged. Only those fixture count fields changed. Layout schema 3 and stack/mailbox/module ABI version 1 remain unchanged.

## Source pins and patch

Original source SHA256 pins:
- src/AgentLang.Llvm/native/owning_stack_runtime.c: E5026D12FBA6C151F4D2E721FC8178116F46BAAD47F8B2DB5A7619E55F5482D8
- src/AgentLang.Llvm/native/owning_stack_runtime_test.c: AB6F9578FB3E86740580B823F18D941994DD64A70F200AB73A06CD6B104AF286
- tests/AgentLang.Llvm.Tests/Program.fs: 2C3B36F23EF2ED24FDB7A8C825FA32678C3A0B2FDFE66DCF674121CAE53766B9
- tests/fixtures/native-conformance/native-value-stack.json: 7D40AB1CD593F38005964785B573EA2C147F20AE69825DCC8A27CB98EE29966E

Final source SHA256:
- src/AgentLang.Llvm/native/owning_stack_runtime.c: C67A1D5A2D2E047A5A27451A60BF20DF5A1CE0074938859C221CBC6E707FA4D1
- src/AgentLang.Llvm/native/owning_stack_runtime_test.c: 103686FB9397D15268D9BB7E4836611D066633710CC38DCA8DAC676E7CA5B2F3
- tests/AgentLang.Llvm.Tests/Program.fs: FCC662D311378D3B1C0092A76DF66D5E2B48FD8E8163171A53F4FA56D5C17182
- tests/fixtures/native-conformance/native-value-stack.json: AC83B8C2E7B83FCFFB83251733A6264D4DCF3F3951DDEA69BCFC625222C8022B

candidate.patch contains only the four scoped repository-relative files, matches candidate/proposed copies, and passed git apply --reverse --check. Patch SHA256: A8C1A72AEE993A41C68248115FF6D41518BB31EDF911F30837613C726732F828.

## Validation

Fresh Release build passed, exit 0:
dotnet build tests/AgentLang.Llvm.Tests/AgentLang.Llvm.Tests.fsproj -c Release --artifacts-path .agentlang/native-unit-202/test-build-final -m:1 -p:NuGetAudit=false
Logs: logs/test-build-final.command.txt, stdout.log, stderr.log, exit.txt.

Verify-NativeValueStack.ps1 passed, exit 0, with 50 evidence checks and stable source inputs. O0 and O2 stack tests passed; UBSan trap build/run passed. Normal UBSan linking was unavailable with the installed Windows MSVC-target LLVM toolchain due 16 unresolved UBSan runtime imports (including __coe_win, Sym*, CommandLineToArgvW, getenv); the verifier recorded this limitation and passed its known-limitation branch. Evidence copies:
- evidence/native-value-stack-verification-evidence.json SHA256 23E7E5691843470CA67135AB6C844D5C563D7FB24B3590E1F8B5CE57DE2DCF6A
- evidence/native-value-stack-experiment-evidence.json SHA256 4FC6297293ACCF4BB1C915303B168BE3968ACC9DA13B42297D4B80A63A16A20A
Verifier run: .agentlang/owning-stack-003/verification-109d39c70aaf49479fba8b200a49f9b2.

The default conformance verifier restore/build attempt exited 1 due NU1900 access to the NuGet vulnerability endpoint. Environment-only NuGetAudit=false and a property-only wrapper attempts also exited 1 before tests; their logs are retained. The successful final verifier used a temporary in-process dotnet wrapper appending both -m:1 and -p:NuGetAudit=false only to build. Exact outer payload and actual invocation are in logs/native-conformance-serial-audit-disabled.outer-command.ps1 and logs/native-conformance-serial-audit-disabled-wrapper.txt; this is not an unchanged/default verifier invocation.

The wrapper-assisted verifier exited 0. Build artifacts: .agentlang/native-validation/run-c3ed4fe097c34ddcac3a1b13a750cfc5. Full generated test assembly ran and reported 777 assertions passed, including the canonical Unit/Option<Unit> parity stage. Test artifacts: .agentlang/native-validation/tests-eb1fd766214f49ccb7b79c335fd44ba4. Console/exit logs: logs/native-conformance-serial-audit-disabled.stdout.log, stderr.log, exit.txt.

Artifact writes used task/verifier folders; tracked bin/obj outputs were not used. The full37 core gate was not rerun per scope.
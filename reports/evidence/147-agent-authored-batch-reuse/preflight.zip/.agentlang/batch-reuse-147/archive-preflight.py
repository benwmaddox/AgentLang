from pathlib import Path
import hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OUT=REPO/'reports/evidence/147-agent-authored-batch-reuse'
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'preflight.zip'
index=OUT/'preflight-index.json'
if archive.exists() or index.exists(): raise SystemExit('Refusing to overwrite archive')
freeze=json.loads((ROOT/'freeze.json').read_text(encoding='utf-8'))
files=set()
for row in freeze['files']:
    p=Path(row['path'])
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
    files.add(p)
for p in ROOT.rglob('*'):
    if p.is_file() and not any(x.lower() in {'bin','obj','__pycache__','tmp','temp'} for x in p.relative_to(ROOT).parts) and p.name.lower()!='write.lock': files.add(p)
rows=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):
        data=p.read_bytes(); name=p.relative_to(REPO).as_posix()
        z.writestr(name,data)
        rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(rows)
    for r in rows:
        data=z.read(r['path'])
        assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'],r['path']
summary={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entryCount':len(rows),'files':rows}
index.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='files'}))



# Batch 147 Flow feasibility

**Result: feasible** with the pinned Flow/2 runtime and existing `rental.billable-days` library word.

The final API is `rental.total-billable-days(rentals: List<Rental>, from-day: Int, until-day: Int) -> Result<Int, RentalError>`. The experiment adds a small `RentalBillingState` record and a statically named `rental.accumulate-billable-days` callback. The record carries the window and running total because `list.fold` callbacks cannot capture caller locals. For each successful step the callback delegates to the retained `rental.billable-days` query and adds its count, so overlapping rentals and repeated rentals contribute independently. A test with two overlapping rentals and one repeated rental returns 9 and checks the rental fields remain intact.

The pinned runtime describes `list.fold` as a typed syntax form that takes a static callback with signature `Accumulator Item -> Accumulator`, visits items left to right, and returns the initial accumulator for an empty list. The candidate callback passed 3/3 own tests with 23/23 instructions, 4/4 branches, and both `Result` alternatives covered. The target passed 4/4 own tests with 25/25 instructions, 6/6 branches, and both `Result` alternatives covered. Both words were committed as libraries; the retained `rental.billable-days` remained a library dependency. No runtime or core files were changed.

The first implementation returned immediately for an invalid window. Its own tests passed, but the library gate reported 5/6 target branches because the post-fold error branch could never run. That result is retained in the first trace. The final implementation seeds the fold accumulator with `INVALID_BILLING_WINDOW` on invalid bounds and otherwise with an initial total of zero, then folds in both cases. This satisfies the contract even for an empty list and makes all result branches observable. The cost is that an invalid-window request still traverses every list item; the callback carries the original error forward without checking rental occupancy. The behavior stays pure and no new primitive or gate change is needed.

The final project passed `test-all` at 36/36 before reload and again at 36/36 after a fresh broker/runtime process loaded the committed store. Fresh `describe` reported both words as persistent library words with complete coverage; a fresh `eval` of the overlapping/duplicate example returned `ok 9`.

The report145 Flow-B seed project was copied from `.agentlang/reuse-145/participants/flow-b/project` into `project/`, matching all 49 files after excluding `WRITE.lock`; the seed remained untouched. The broker used the pinned CLI at `.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll`. The runtime-created empty lock in the experiment copy was removed after both hosts exited. Eight failed exploratory responses are retained in `probe-failures.jsonl`.

Evidence files:

- `project/dictionary.agent`: the persisted source and attached tests, including the new API and callback.
- `actor.trace.jsonl`, `fresh-reload.trace.jsonl`: full broker host traces.
- `broker-exchanges.jsonl`: raw broker requests/responses and wire base64 for every exchange.
- `probe-failures.jsonl`: every failed probe response, kept for review.
- `launch-commands.txt`, `host-close-actions.jsonl`, `clone-audit.json`: launch, close, and copy audit records.
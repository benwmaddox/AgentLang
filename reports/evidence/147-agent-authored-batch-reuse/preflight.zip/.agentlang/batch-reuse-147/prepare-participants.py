#!/usr/bin/env python3
"""Prepare isolated, hash-inventoried participant starts; never launch them."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
STUDY = REPO / ".agentlang" / "batch-reuse-147"
BASELINE = STUDY
OUTPUT = STUDY / "participants"
TASK_DRAFT = STUDY / "task-draft.md"
HOST = REPO / "scripts" / "Start-SubagentTrialHostV2.ps1"
FLOW_CLI = REPO / ".agentlang" / "library-closure-142" / "root-cli-artifacts" / "bin" / "AgentLang.Cli" / "release" / "AgentLang.Cli.dll"
CONVENTIONAL_CLI = REPO / ".agentlang" / "conventional-discovery-146" / "root-artifacts" / "bin" / "AgentLang.Conventional.Cli" / "release" / "AgentLang.Conventional.Cli.dll"
MAX_EXCHANGES = 100
EXCHANGE_TIMEOUT_MS = 120_000
EXCLUDED_PARTS = {"bin", "obj"}
EXCLUDED_NAMES = {"write.lock"}


def start_project(arm: str, condition: str) -> Path:
    base = BASELINE / arm
    if arm == "flow":
        return base / "starts" / condition / "project"
    return base / condition


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def excluded(relative: Path) -> bool:
    return any(part.lower() in EXCLUDED_PARTS for part in relative.parts) or relative.name.lower() in EXCLUDED_NAMES


def inventory(project: Path) -> dict:
    files = []
    for path in sorted(project.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(project)
        if excluded(relative):
            continue
        files.append(
            {
                "path": relative.as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    canonical = "".join(f"{item['path']}\t{item['sha256']}\n" for item in files).encode("utf-8")
    return {
        "fileCount": len(files),
        "inventorySha256": sha256_bytes(canonical),
        "files": files,
    }


def public_task_text() -> str:
    lines = []
    with TASK_DRAFT.open("r", encoding="utf-8") as stream:
        for line in stream:
            if re.match(r"^#{1,6}\s+Coordinator plan\b", line.strip(), re.IGNORECASE):
                break
            lines.append(line.rstrip("\r\n"))
    if not lines:
        raise RuntimeError("No public task section was found.")
    if lines[0].startswith("# "):
        lines = lines[1:]
    text = "\n".join(lines).strip()
    if not text:
        raise RuntimeError("The public task section is empty.")
    return text + "\n"


def prompt_text(participant_id: str, arm: str, project: Path, trace: Path, contract: str) -> str:
    host = str(HOST)
    project_s = str(project)
    trace_s = str(trace)
    if arm == "flow":
        cli = str(FLOW_CLI)
        operations = "task.begin,task.status,task.log,task.commit,task.abort,words,search,describe,type-of,search-type,search-output,search-effect,search-dependency,source,dependencies,callers,transitive-dependencies,transitive-callers,graph,context,effects,ir,tests,examples,example,history,diff,stack,help,eval,define,test,test-all,failed-tests,commit,replace-word,discard"
        launch = (
            f"pwsh -NoProfile -File '{host}' -CliDll '{cli}' "
            f"-ProjectPath '{project_s}' -TracePath '{trace_s}' "
            f"-AllowedOperations '{operations}' -Profile agentlang "
            f"-ClockValue '2000-01-01T00:00:00Z' "
            f"-ExchangeTimeoutMilliseconds {EXCHANGE_TIMEOUT_MS} -MaxExchanges {MAX_EXCHANGES}"
        )
        operation_instructions = """Begin with `task.begin` and inspect its response. Use broker introspection and attached examples as needed. Before authoring, request and inspect both `{"op":"help","topic":"define","syntaxVersion":2}` and `{"op":"help","topic":"examples","syntaxVersion":2}`; do not add a `frontend` field to either `help` request. Include `"frontend":"flow"` and `"syntaxVersion":2` on `define` and `eval` requests. Run `test-all`; qualify and commit changed or new library words through the broker's supported library commit operation. Finish with `{"op":"task.commit"}`, observe the result, then send `{"op":"host.close"}` and wait for normal process exit."""
    elif arm == "fsharp":
        cli = str(CONVENTIONAL_CLI)
        operations = "inspect,read,search,patch,replace,validate"
        launch = (
            f"pwsh -NoProfile -File '{host}' -CliDll '{cli}' "
            f"-ProjectPath '{project_s}' -TracePath '{trace_s}' "
            f"-AllowedOperations '{operations}' -Profile conventional "
            "-AdditionalCliArgumentsJson '[\"--validation-project\",\"tests/RentalDomain.Tests.fsproj\"]' "
            f"-ExchangeTimeoutMilliseconds {EXCHANGE_TIMEOUT_MS} -MaxExchanges {MAX_EXCHANGES}"
        )
        operation_instructions = """Begin with `{"op":"inspect"}` to discover file paths and operation schemas. Use `inspect`, `read`, and `search` through the broker to understand the assigned project. Make edits only through `patch` or `replace`. Finish substantive work with `validate` and observe its full result, then send `{"op":"host.close"}` and wait for normal process exit."""
    else:
        raise ValueError(f"Unknown arm: {arm}")

    return f"""You are a fresh, independent participant. The human authorizes changes only to this assigned isolated project and its local tests. Use only the supplied broker for project discovery, authoring, evaluation, and testing. Your only permitted raw filesystem operation is reading this assigned prompt to verify its supplied SHA-256 before starting the broker. After that check, use the broker exclusively for project work. Do not read or edit files outside the assigned prompt and project. Do not use web tools or delegate work. Launch the specified broker once and keep using that process session.

Run the launch command from `D:\\code\\AgentLang` using `exec_command` with `tty:true` and `yield_time_ms:10000`. Send one newline-terminated JSON request at a time and inspect its response before the next mutation. The broker allows at most {MAX_EXCHANGES} exchanges, each with a {EXCHANGE_TIMEOUT_MS} ms timeout. On a timeout, poll the same process session; do not restart the broker.

Exact launch command:

```powershell
{launch}
```

{operation_instructions}

# Task

{contract}"""


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")


def main() -> None:
    if OUTPUT.exists():
        raise SystemExit(f"Refusing to overwrite existing participant output: {OUTPUT}")
    required = [start_project(arm, condition) for arm in ("flow", "fsharp") for condition in ("flat", "retained")] + [TASK_DRAFT, HOST, FLOW_CLI, CONVENTIONAL_CLI]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise SystemExit("Missing required preparation input(s):\n" + "\n".join(missing))

    contract = public_task_text()
    contract_hash = sha256_bytes(contract.encode("utf-8"))
    OUTPUT.mkdir(parents=True, exist_ok=False)
    participant_summaries = []

    for participant_id, arm, condition in (("flow-a", "flow", "flat"), ("flow-b", "flow", "retained"), ("fsharp-a", "fsharp", "retained"), ("fsharp-b", "fsharp", "flat")):
        source_project = start_project(arm, condition)
        participant_dir = OUTPUT / participant_id
        project_copy = participant_dir / "project"
        participant_dir.mkdir(parents=False, exist_ok=False)
        project_copy.mkdir(parents=True, exist_ok=False)

        for source in sorted(source_project.rglob("*")):
            if not source.is_file():
                continue
            relative = source.relative_to(source_project)
            if excluded(relative):
                continue
            target = project_copy / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)

        source_inventory = inventory(source_project)
        copied_inventory = inventory(project_copy)
        if source_inventory["inventorySha256"] != copied_inventory["inventorySha256"]:
            raise RuntimeError(f"Copied source inventory mismatch for {participant_id}.")

        prompt_path = participant_dir / "prompt.md"
        trace_path = participant_dir / "actor.trace.jsonl"
        prompt = prompt_text(participant_id, arm, project_copy, trace_path, contract)
        prompt_path.write_text(prompt.rstrip() + "\n", encoding="utf-8", newline="\n")
        prompt_hash = sha256_file(prompt_path)
        wrapper = (
            f"You are a fresh participant for {participant_id}. Read only the assigned prompt at `{prompt_path}` "
            f"and verify its SHA-256 is `{prompt_hash}` (for example, with `Get-FileHash -Algorithm SHA256`). "
            "If the hash differs, stop without touching the project. The human explicitly authorizes edits and local tests "
            "only within the isolated project named in that prompt; follow its broker-only instructions.\n"
        )
        wrapper_path = participant_dir / "wrapper.txt"
        wrapper_path.write_text(wrapper, encoding="utf-8", newline="\n")
        inventory_path = participant_dir / "start-inventory.json"
        write_json(
            inventory_path,
            {
                "schemaVersion": 1,
                "participant": participant_id,
                "arm": arm,
                "condition": condition,
                "sourceProject": str(source_project),
                "copiedProject": str(project_copy),
                "excluded": ["**/bin/**", "**/obj/**", "**/write.lock"],
                "sourceInventorySha256": source_inventory["inventorySha256"],
                "copiedInventorySha256": copied_inventory["inventorySha256"],
                "matchesSource": True,
                "fileCount": copied_inventory["fileCount"],
                "files": copied_inventory["files"],
            },
        )
        participant_summaries.append(
            {
                "participant": participant_id,
                "arm": arm,
                "condition": condition,
                "projectPath": str(project_copy),
                "tracePath": str(trace_path),
                "promptPath": str(prompt_path),
                "promptSha256": prompt_hash,
                "wrapperPath": str(wrapper_path),
                "wrapperSha256": sha256_file(wrapper_path),
                "startInventoryPath": str(inventory_path),
                "startInventorySha256": sha256_file(inventory_path),
                "projectInventorySha256": copied_inventory["inventorySha256"],
                "projectFileCount": copied_inventory["fileCount"],
            }
        )

    (OUTPUT / "NOT-DISPATCHED.txt").write_text(
        "Prepared only. No participant broker was launched and no task was dispatched.\n",
        encoding="utf-8",
        newline="\n",
    )
    write_json(
        OUTPUT / "summary.json",
        {
            "schemaVersion": 1,
            "createdUtc": datetime.now(timezone.utc).isoformat(),
            "status": "prepared-not-dispatched",
            "taskContractSha256": contract_hash,
            "taskContractSource": str(TASK_DRAFT),
            "taskContractBoundary": "content before the Coordinator plan heading only",
            "promptProtocol": {
                "flowPrerequisiteHelpRequests": [
                    {"op": "help", "topic": "define", "syntaxVersion": 2},
                    {"op": "help", "topic": "examples", "syntaxVersion": 2},
                ],
                "flowHelpRequestsIncludeFrontend": False,
                "flowDefineEvalFrontend": "flow",
                "flowDefineEvalSyntaxVersion": 2,
            },
            "host": str(HOST),
            "flowCli": {"path": str(FLOW_CLI), "sha256": sha256_file(FLOW_CLI)},
            "conventionalCli": {"path": str(CONVENTIONAL_CLI), "sha256": sha256_file(CONVENTIONAL_CLI)},
            "maxExchanges": MAX_EXCHANGES,
            "exchangeTimeoutMilliseconds": EXCHANGE_TIMEOUT_MS,
            "participants": participant_summaries,
            "dispatchCount": 0,
        },
    )
    print(json.dumps({"status": "prepared-not-dispatched", "output": str(OUTPUT), "participants": participant_summaries}, indent=2))


if __name__ == "__main__":
    main()

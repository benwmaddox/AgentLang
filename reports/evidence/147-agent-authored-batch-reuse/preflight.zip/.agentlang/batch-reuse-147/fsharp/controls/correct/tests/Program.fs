open DomainBaselineTests

[<EntryPoint>]
let main _ =
    let baselineChecks = DomainBaselineTests.run ()
    let controlChecks = MultiRentalControlTests.run ()
    printfn "PASS %d baseline checks" baselineChecks
    printfn "PASS %d multi-rental control checks" controlChecks
    0
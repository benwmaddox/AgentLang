module MultiRentalControlTests

open RentalDomain

let run () =
    let mutable checks = 0
    let mutable failures: string list = []
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failures <- sprintf "%s expected %A, received %A" name expected actual :: failures

    let expectTotal name expected rentals fromDay untilDay =
        match Rental.totalBillableDays rentals fromDay untilDay with
        | Ok actual -> check name expected actual
        | Error error -> failures <- sprintf "%s expected %A days, received %s" name expected error.Code :: failures

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failures <- sprintf "%s expected an error" name :: failures

    let makeRental startDay finishDay =
        match Rental.start startDay finishDay with
        | Ok rental -> rental
        | Error error -> failwithf "control rental setup failed: %s" error.Code

    expectTotal "empty request returns zero" 0L [] 1L 2L
    let invalidEmpty = Rental.totalBillableDays [] 2L 2L
    expectError "invalid window wins for empty request" "INVALID_BILLING_WINDOW" invalidEmpty
    match invalidEmpty with
    | Error error -> check "invalid window error is explained" true (not (System.String.IsNullOrWhiteSpace error.Message))
    | Ok _ -> ()

    let first = makeRental 2L 6L
    let overlap = makeRental 4L 8L
    expectTotal "overlaps and duplicates count independently" 12L [ first; overlap; first ] 0L 10L
    check "first rental start preserved" 2L (Rental.startDay first)
    check "overlap rental finish preserved" 8L (Rental.finishDay overlap)
    check "first rental cancellation preserved" None (Rental.cancelledDay first)

    let cancellable = makeRental 2L 10L
    let cancelled =
        match Rental.cancel cancellable 5L with
        | Ok rental -> rental
        | Error error -> failwithf "control cancellation failed: %s" error.Code
    expectTotal "cancellation clips the total" 3L [ cancelled ] 0L 20L
    check "cancellation field preserved" (Some 5L) (Rental.cancelledDay cancelled)
    check "original rental remains uncancelled" None (Rental.cancelledDay cancellable)

    let startsCancelled =
        match Rental.cancel (makeRental 4L 7L) 4L with
        | Ok rental -> rental
        | Error error -> failwithf "start cancellation failed: %s" error.Code
    expectTotal "cancellation at start contributes zero" 0L [ startsCancelled ] System.Int64.MinValue System.Int64.MaxValue

    let later = makeRental 350L 366L
    expectTotal "extreme request bounds avoid overflow" 20L [ first; later ] System.Int64.MinValue System.Int64.MaxValue

    if not failures.IsEmpty then
        failwithf "%d/%d control assertions failed: %s" failures.Length checks (String.concat "; " (List.rev failures))
    checks
# Batch rental billing

Add a pure query returning the total chargeable integer rental-days for a list
of rentals within a requested half-open billing window.

Required API:
- AgentLang: rental.total-billable-days(rentals: List<Rental>, from-day: Int, until-day: Int) -> Result<Int, RentalError>.
- F#: RentalDomain.Rental.totalBillableDays : Rental.T list -> int64 -> int64 -> Result<int64, RentalError>.

Each stored rental satisfies 0 <= start-day < finish-day <= 366. Its optional
cancellation day is at or after start-day and may exceed finish-day. Occupancy is
[start-day, finish-day) without cancellation, or [start-day, min(finish-day,
cancellation-day)) with cancellation. Cancellation at start leaves zero days.

First reject from-day >= until-day with RentalError code INVALID_BILLING_WINDOW,
including when the rental list is empty or all rentals have empty occupancy.
Otherwise count the occupied integer days inside [from-day, until-day) for each
rental and add the counts. Rentals are independent: overlapping rentals are
charged separately, and repeated entries count repeatedly. A valid window with
an empty list returns zero. Request bounds may be any signed 64-bit integers;
do not subtract the unrestricted request endpoints. Exact error wording is not
an acceptance requirement, but explain invalid windows.

Preserve the input list, its order, every rental field, existing public APIs,
and inherited tests. Inspect the available project capabilities; no particular
private helper, abstraction or algorithm is required. Add effective tests and
run the complete project suite. AgentLang must qualify and publish the new query
and any authored production dependencies as libraries without demoting existing
library functions. Finish the normal task and broker workflow. F# uses its
ordinary compiler and executable test workflow.

## Coordinator plan

Four fresh Luna/max agents, one per language x retained-query/flat cell. Retained
seeds come from actual report145 flat submissions: flow-b and fsharp-a, including
their agent-authored single-rental query/tests. Flat seeds are their original
report145 starts. No interval helper is added in either condition. Within each
language, common source must match except retained query/tests; shared docs must
not retain an obsolete task instruction. Retained reuse is optional and measured
through actual production calls separately from behavior. This is exploratory,
not statistical evidence of a population advantage.

Use the frozen Flow runtime142 and improved conventional CLI146; conventional
participants begin with inspect {}. All participants get same public contract
and 100 exchanges. Use existing broker, trace and termination auditors. No model
API/provider integration, no raw project filesystem access for participants.

Use a small independently enumerated-day oracle, adapted from145: singleton
inherited edge cases plus empty, mixed rentals, overlapping/duplicate rentals,
all-empty occupancy and reordered inputs. Validate public start/cancel setup;
compare total and preserve all input fields/order. Preflight correct controls,
absent-query starts, and a compiling wrong aggregation control. Freeze all inputs
before dispatch. No runtime work is a prerequisite unless feasibility reveals
an actual blocker; never weaken acceptance just to launch.

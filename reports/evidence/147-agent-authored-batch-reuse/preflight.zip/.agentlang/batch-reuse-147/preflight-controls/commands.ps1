$repo = 'D:\code\AgentLang'
Set-Location $repo
$preflight = Join-Path $repo '.agentlang/batch-reuse-147/preflight-controls'
$env:TEMP = Join-Path $preflight 'tmp'
$env:TMP = $env:TEMP
$env:NuGetAudit = 'false'
$python = 'C:\Users\Ben\AppData\Local\Programs\Python\Python312\python.exe'
$score = Join-Path $repo '.agentlang/batch-reuse-147/oracle/score.py'
$cli = Join-Path $repo '.agentlang/library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
$batch = Join-Path $repo '.agentlang/batch-reuse-147'

& $python $score --arm flow --project (Join-Path $batch 'feasibility/project') --cli $cli --output (Join-Path $preflight 'flow-correct-r3')
& $python $score --arm flow --project (Join-Path $batch 'flow/starts/flat/project') --cli $cli --output (Join-Path $preflight 'flow-flat-absent-r3')
& $python $score --arm flow --project (Join-Path $preflight 'flow-negative-project') --cli $cli --flow-define-source (Join-Path $preflight 'flow-negative-source.agent') --output (Join-Path $preflight 'flow-negative-r4')
& $python $score --arm fsharp --project (Join-Path $batch 'fsharp/controls/correct') --fsharp-project 'project/RentalDomain.fsproj' --output (Join-Path $preflight 'fsharp-correct-rerun')
& $python $score --arm fsharp --project (Join-Path $batch 'fsharp/controls/negative') --fsharp-project 'project/RentalDomain.fsproj' --output (Join-Path $preflight 'fsharp-negative-rerun')
& $python $score --arm fsharp --project (Join-Path $batch 'fsharp/flat') --fsharp-project 'project/RentalDomain.fsproj' --output (Join-Path $preflight 'fsharp-flat-absent-rerun')
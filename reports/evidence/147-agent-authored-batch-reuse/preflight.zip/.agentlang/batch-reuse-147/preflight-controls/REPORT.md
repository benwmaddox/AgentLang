# Report 147 preflight controls

All final runs used `oracle/score.py`, Python 3.12 at `C:\Users\Ben\AppData\Local\Programs\Python\Python312\python.exe`, the frozen CLI `library-closure-142/root-cli-artifacts/bin/AgentLang.Cli/release/AgentLang.Cli.dll`, and process-local `TMP`/`TEMP` under this directory. `NuGetAudit=false` was set for child processes. Every scorer output uses a fresh directory and contains its `acceptance.json`, logs, and before/after source hashes.

| Control | Result | Evidence |
|---|---|---|
| Flow correct feasibility | Passed: 18 cases, 72/72 oracle assertions, inherited 36/36; input unchanged. | `flow-correct-r3/acceptance.json` |
| F# correct | Passed: 18/18 cases; input unchanged. | `fsharp-correct-rerun/acceptance.json` |
| Flow negative, max aggregation | Compiled and ran 72 assertions; behavior failed on 6 aggregation cases as intended; inherited 16/16; project and overlay unchanged. | `flow-negative-r4/acceptance.json` |
| F# negative, max aggregation | Build succeeded; behavior failed on 6 aggregation cases as intended; input unchanged. | `fsharp-negative-rerun/acceptance.json` |
| Flow flat start, query absent | Definition failed with `FLOW_UNKNOWN_CALL` for `rental.total-billable-days`; `behaviorPassed` is null; input unchanged. | `flow-flat-absent-r3/acceptance.json` |
| F# flat start, query absent | Build failed because `Rental.totalBillableDays` is undefined; zero cases observed and `behaviorPassed` is null; input unchanged. | `fsharp-flat-absent-rerun/acceptance.json` |

The Flow negative input is a copy of `flow/starts/flat/project`, so its existing tests remain byte-for-byte unchanged (the `dictionary.agent` SHA-256 matches the source start). `flow-negative-source.agent` supplies the missing Flow/2 query and dependencies from the correct feasibility source as a scorer-supported, non-published overlay. The only source change is `add(state.total, days)` to `int::max(state.total, days)`; the exact generated diff is `flow-negative-aggregation.diff`, with the source before mutation saved as `flow-negative-source-correct.agent`. No publication gate or acceptance condition was weakened.

Initial scorer failures are preserved in `flow-correct/`, `flow-correct-rerun/`, `fsharp-correct/`, `fsharp-negative/`, and `fsharp-flat-absent/`. They exposed scorer defects later corrected outside this directory: Flow fixture syntax version 1 instead of 2, uppercase snapshot constructor spelling, and an untyped F# `outcome` helper. Final results above use fresh outputs after those corrections.
module DomainBaselineTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failwithf "%s expected an error" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid start failed: %s" error.Code

    check "start getter" 2L (Rental.startDay original)
    check "finish getter" 8L (Rental.finishDay original)
    check "initial cancellation" None (Rental.cancelledDay original)

    expectError "negative start" "INVALID_RENTAL_SPAN" (Rental.start -1L 8L)
    expectError "empty start span" "INVALID_RENTAL_SPAN" (Rental.start 2L 2L)
    expectError "reversed start span" "INVALID_RENTAL_SPAN" (Rental.start 8L 2L)
    expectError "finish above limit" "INVALID_RENTAL_SPAN" (Rental.start 2L 367L)
    expectError "start above limit" "INVALID_RENTAL_SPAN" (Rental.start 366L 367L)

    match Rental.start 0L 366L with
    | Ok rental ->
        check "lower service bound" 0L (Rental.startDay rental)
        check "upper service bound" 366L (Rental.finishDay rental)
    | Error error -> failwithf "valid service bounds failed: %s" error.Code

    match Rental.cancel original 1L with
    | Error error -> check "cancel before start" "CANCELLATION_BEFORE_START" error.Code
    | Ok _ -> failwith "cancellation before start unexpectedly succeeded"

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "cancel at start" (Some 2L) (Rental.cancelledDay cancelledAtStart)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "cancel after finish" (Some 9L) (Rental.cancelledDay cancelledAfterFinish)

    let firstCancellation =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "first cancellation failed: %s" error.Code
    let replacement =
        match Rental.cancel firstCancellation 6L with
        | Ok rental -> rental
        | Error error -> failwithf "replacement cancellation failed: %s" error.Code
    check "replacement stored" (Some 6L) (Rental.cancelledDay replacement)
    check "intermediate value retained" (Some 4L) (Rental.cancelledDay firstCancellation)
    check "source value unchanged" None (Rental.cancelledDay original)

    let expectBillable name (expected: int64) (rental: Rental.T) fromDay untilDay =
        match Rental.billableDays rental fromDay untilDay with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s expected %A billable days, received %s" name expected error.Code

    expectBillable "whole rental" 6L original 0L 10L
    expectBillable "narrow window" 2L original 3L 5L
    expectBillable "left clipped window" 2L original 1L 4L
    expectBillable "right clipped window" 2L original 6L 10L
    expectBillable "adjacent before" 0L original -4L 2L
    expectBillable "adjacent after" 0L original 8L 12L
    expectBillable "window before rental" 0L original -4L 0L
    expectBillable "signed range endpoints" 6L original System.Int64.MinValue System.Int64.MaxValue
    expectBillable "extreme negative window" 0L original System.Int64.MinValue 1L

    expectBillable "cancelled before finish" 2L firstCancellation 0L 10L
    expectBillable "window partly after cancellation" 1L firstCancellation 3L 8L
    expectBillable "window at cancellation boundary" 0L firstCancellation 4L 8L
    expectBillable "cancellation after finish" 6L cancelledAfterFinish 0L 10L
    expectBillable "cancellation at start has no occupied days" 0L cancelledAtStart 2L 3L

    expectError "empty billing window" "INVALID_BILLING_WINDOW" (Rental.billableDays original 3L 3L)
    expectError "reversed billing window" "INVALID_BILLING_WINDOW" (Rental.billableDays original 5L 4L)
    expectError "invalid window for empty rental" "INVALID_BILLING_WINDOW" (Rental.billableDays cancelledAtStart 2L 2L)
    match Rental.billableDays original 3L 3L with
    | Error error -> check "billing error explains invalid window" true (not (System.String.IsNullOrWhiteSpace error.Message))
    | Ok _ -> failwith "invalid billing window unexpectedly succeeded"

    check "billing preserves source start" 2L (Rental.startDay original)
    check "billing preserves source finish" 8L (Rental.finishDay original)
    check "billing preserves source cancellation" None (Rental.cancelledDay original)

    let expectTotal name (expected: int64) (rentals: Rental.T list) fromDay untilDay =
        match Rental.totalBillableDays rentals fromDay untilDay with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s expected %A total billable days, received %s" name expected error.Code

    expectTotal "empty total" 0L [] 0L 1L
    expectTotal "single rental total" 6L [ original ] 0L 10L
    expectTotal "overlapping rentals count separately" 4L [ original; firstCancellation ] 2L 4L
    expectTotal "repeated rentals count repeatedly" 4L [ original; original ] 2L 4L
    expectTotal "cancellations and independent rentals sum" 14L [ original; firstCancellation; cancelledAtStart; cancelledAfterFinish ] 0L 10L
    expectTotal "total at signed range endpoints" 6L [ original ] System.Int64.MinValue System.Int64.MaxValue
    expectTotal "empty total at signed range endpoints" 0L [] System.Int64.MinValue System.Int64.MaxValue

    expectError "total rejects empty billing window" "INVALID_BILLING_WINDOW" (Rental.totalBillableDays [] 3L 3L)
    expectError "total rejects reversed window for empty rentals" "INVALID_BILLING_WINDOW" (Rental.totalBillableDays [] 4L 3L)
    expectError "total rejects invalid window for zero occupancy" "INVALID_BILLING_WINDOW" (Rental.totalBillableDays [ cancelledAtStart ] 2L 2L)
    match Rental.totalBillableDays [] 3L 3L with
    | Error error -> check "total billing error explains invalid window" true (not (System.String.IsNullOrWhiteSpace error.Message))
    | Ok _ -> failwith "invalid total billing window unexpectedly succeeded"

    let rentalsInOrder = [ firstCancellation; original; cancelledAtStart ]
    let fieldsBefore = rentalsInOrder |> List.map (fun rental -> Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental)
    expectTotal "total preserves rental sequence" 8L rentalsInOrder 0L 10L
    let fieldsAfter = rentalsInOrder |> List.map (fun rental -> Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental)
    check "total preserves rental fields and order" fieldsBefore fieldsAfter

    checks

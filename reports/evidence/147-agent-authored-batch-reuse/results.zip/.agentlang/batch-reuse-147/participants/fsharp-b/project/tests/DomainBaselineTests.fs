module DomainBaselineTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failwithf "%s expected an error" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid start failed: %s" error.Code

    check "start getter" 2L (Rental.startDay original)
    check "finish getter" 8L (Rental.finishDay original)
    check "initial cancellation" None (Rental.cancelledDay original)

    expectError "negative start" "INVALID_RENTAL_SPAN" (Rental.start -1L 8L)
    expectError "empty start span" "INVALID_RENTAL_SPAN" (Rental.start 2L 2L)
    expectError "reversed start span" "INVALID_RENTAL_SPAN" (Rental.start 8L 2L)
    expectError "finish above limit" "INVALID_RENTAL_SPAN" (Rental.start 2L 367L)
    expectError "start above limit" "INVALID_RENTAL_SPAN" (Rental.start 366L 367L)

    match Rental.start 0L 366L with
    | Ok rental ->
        check "lower service bound" 0L (Rental.startDay rental)
        check "upper service bound" 366L (Rental.finishDay rental)
    | Error error -> failwithf "valid service bounds failed: %s" error.Code

    match Rental.cancel original 1L with
    | Error error -> check "cancel before start" "CANCELLATION_BEFORE_START" error.Code
    | Ok _ -> failwith "cancellation before start unexpectedly succeeded"

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "cancel at start" (Some 2L) (Rental.cancelledDay cancelledAtStart)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "cancel after finish" (Some 9L) (Rental.cancelledDay cancelledAfterFinish)

    let firstCancellation =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "first cancellation failed: %s" error.Code
    let replacement =
        match Rental.cancel firstCancellation 6L with
        | Ok rental -> rental
        | Error error -> failwithf "replacement cancellation failed: %s" error.Code
    check "replacement stored" (Some 6L) (Rental.cancelledDay replacement)
    check "intermediate value retained" (Some 4L) (Rental.cancelledDay firstCancellation)
    check "source value unchanged" None (Rental.cancelledDay original)

    let expectBillableDays name expected result =
        match result with
        | Ok days -> check name expected days
        | Error error -> failwithf "%s received unexpected error: %s" name error.Code

    expectError "empty list still rejects an empty billing window" "INVALID_BILLING_WINDOW"
        (Rental.totalBillableDays [] 5L 5L)
    expectError "empty occupancy still rejects a reversed billing window" "INVALID_BILLING_WINDOW"
        (Rental.totalBillableDays [ cancelledAtStart ] 5L 4L)
    expectBillableDays "empty rental list" 0L (Rental.totalBillableDays [] -10L 500L)
    expectBillableDays "cancellation at start has no occupied days" 0L
        (Rental.totalBillableDays [ cancelledAtStart ] 2L 10L)
    expectBillableDays "full rental span" 6L (Rental.totalBillableDays [ original ] 0L 366L)
    expectBillableDays "window clips rental start" 1L (Rental.totalBillableDays [ original ] 1L 3L)
    expectBillableDays "window excludes rental finish" 0L (Rental.totalBillableDays [ original ] 8L 9L)
    expectBillableDays "cancellation truncates occupancy" 2L
        (Rental.totalBillableDays [ firstCancellation ] 0L 10L)
    expectBillableDays "cancellation after finish does not extend occupancy" 6L
        (Rental.totalBillableDays [ cancelledAfterFinish ] 0L 10L)

    let repeatedAndOverlapping = [ original; firstCancellation; original; cancelledAtStart ]
    expectBillableDays "overlap and repeated rentals count independently" 14L
        (Rental.totalBillableDays repeatedAndOverlapping 0L 10L)
    check "query preserves rental order and fields"
        [ (2L, 8L, None); (2L, 8L, Some 4L); (2L, 8L, None); (2L, 8L, Some 2L) ]
        (repeatedAndOverlapping
         |> List.map (fun rental ->
             Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental))

    expectBillableDays "full range does not subtract unrestricted endpoints" 6L
        (Rental.totalBillableDays [ original ] System.Int64.MinValue System.Int64.MaxValue)
    expectBillableDays "extreme window beyond occupancy" 0L
        (Rental.totalBillableDays [ original ] (System.Int64.MaxValue - 1L) System.Int64.MaxValue)

    checks

# F# final participant review

Reviewed only `participants/fsharp-a`, `participants/fsharp-b`, their frozen starts, and the corresponding F# result artifacts. No compiler or trial was rerun.

## Finding

- **Reuse measurement:** F# retained participant `fsharp-a` preserves the seeded `Rental.billableDays` API at [Rental.fs:31](/D:/code/AgentLang/.agentlang/batch-reuse-147/participants/fsharp-a/project/project/Rental.fs:31), but its new `totalBillableDays` implementation at [Rental.fs:53](/D:/code/AgentLang/.agentlang/batch-reuse-147/participants/fsharp-a/project/project/Rental.fs:53) recomputes the cancellation cap and interval overlap for each rental. It does not call `billableDays`; record this as duplication/no direct helper reuse. This is a measurement observation, not a functional acceptance failure.

## Acceptance and preservation

- Each final project retains all six start-inventory files. Hash comparison against the frozen inventories shows only `project/Rental.fs` and `tests/DomainBaselineTests.fs` changed in either participant; project files, README, and test entry point remain intact. F# a retains the seeded singleton API and inherited tests, while F# b retains its baseline APIs and tests.
- Both implementations reject invalid windows before aggregation, clip each rental by cancellation and the request window, and sum entries independently. Their added tests cover empty lists, empty occupancy, invalid windows, half-open boundaries, cancellation at start and after finish, overlap and duplicates, order/field preservation, and signed Int64 endpoints.
- Recorded oracle results: **18/18 passed** for each participant, build/run exit codes 0/0, and scorer input projects unchanged. Recorded own-suite results: **50 checks passed** for fsharp-a and **29 checks passed** for fsharp-b, both exit code 0. Each trace has 10 exchanges, zero broker error responses, and a normal `host-close` with host/runtime exit codes 0/0; both termination audits passed.

No further functional or preservation findings.

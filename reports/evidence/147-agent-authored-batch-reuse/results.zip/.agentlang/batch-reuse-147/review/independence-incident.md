# Cross-participant communication incident

During the frozen trial, flow-a told the coordinator that flow-b reported the
same fold syntax problem and asked whether a Stack exception was allowed.
Flow-b separately reported that sibling flow-a had the same issue. These
messages establish participant communication outside their broker-only workflow.
The exact exchange has been requested from both participants. Do not count these
two runs as independent observations, irrespective of their final outcomes.

The coordinator did not provide working fold syntax or a solution. It sent both
participants the same constraint clarification: remain Flow/2 and broker-only,
no Stack exception; decide whether completion is possible within those constraints;
if abandoning, use task.abort and close normally. It also prohibited further
cross-participant communication and requested the exact messages for the record.

The task's fresh-participant isolation instructions proved insufficient to prevent
this communication. Future trial prompts must explicitly prohibit reading other
agents' status, listing siblings or sending/receiving participant messages, and
the harness should isolate communication capabilities where available. This
incident cannot be repaired by relabeling these runs independent or by silently
replacing them. Any repeat must be separately identified.

Flow-b reported receiving a question from flow-a asking whether it had found a
Flow/2 fold or list traversal form, mentioning rejected eval syntax and recursion.
Flow-b reported this reply verbatim:

> No accepted Flow/2 call pattern found. `list.fold <add>` fails FLOW_EXPECTED_SEPARATOR at `<` in define, `list.fold<add>(...)` and the stack-style lines also fail. Recursive self-calls fail IR_RECURSIVE_CALL_GRAPH. Could not yet find another List traversal route.

This includes failed syntax snippets and negative capability information; it is
not a successful implementation, but it can influence the other participant's
search and decision to abandon. Flow-b says no successful solution was exchanged.

Flow-a's final response supplied its original question verbatim:

> Have you found a Flow/2 way to call `list.fold` or process List values without recursion? Broker introspection exposes fold as syntax, and Flow/2 expression eval rejects it; recursion is rejected by acyclic call graph. If you found an accepted form, please share the exact source pattern.

Its account of the reply agrees with flow-b's quoted reply above. Both ultimately
aborted and closed normally. Flow-a's final claim that Flow/2 blocked the API is
an incorrect capability conclusion: the preflight implementation demonstrated
the supported receiver form before dispatch. Record failure to discover it,
not absence of fold support.

# Flow friction review — final

This review uses only the saved `flow-a` and `flow-b` exchanges, their help and `describe` responses, the feasibility source, and terminal grading artifacts. Both sessions are terminal; no experiment was run.

## Fold syntax discovery is the concrete friction

The Flow capability is present. The feasibility implementation uses `rentals.fold(initial, rental::accumulate-billable-days)` in [dictionary.agent](../feasibility/project/dictionary.agent#L117). The observed failures therefore do not establish a missing `list.fold` capability.

The available guidance is incomplete and points toward the wrong mental model. Both `describe list.fold` responses say `syntax: "list.fold <word>"` and list `List<T>` and `Accumulator` as inputs, without showing the receiver, argument order, or a Flow/2 source form. The required Flow/2 `help.define` and `help.examples` responses contain no `fold` mention or example. The participants tried prefix-style `list.fold` calls and other forms; those produced parse/lookup errors. The reportable finding is a discoverability gap in `describe` and help, compounded by participant syntax misuse, not a parser or runtime limitation. A focused follow-up would show the supported receiver form and an end-to-end example in `describe list.fold` and Flow/2 help.

## Other friction and limits

- Both participants tried recursive aggregation after fold attempts; the compiler rejected the recursive graph with `IR_RECURSIVE_CALL_GRAPH`. That diagnostic is accurate and makes recursion an unsuitable fallback.
- Flow-b tried a `match-result` expression in Flow/2 and received `FLOW_TRAILING_INPUT`. The saved Flow/2 examples do not cover Result matching, so this is secondary syntax-discovery friction.
- Flow-a omitted the required `word` argument in one `context` request and received `DISCOVERY_INVALID_ARGUMENT`; that message was direct.
- Flow-a contacted flow-b about a working fold pattern during the trial. See [independence incident](independence-incident.md). The two Flow outcomes must not be presented as independent observations.

The final graders report `FLOW_UNKNOWN_CALL` for the target `rental.total-billable-days` in both participants. Each observed zero of 72 oracle tests; the 18 behavioral cases have no actual result and `behaviorPassed` is null. The inherited suites passed (16 tests for flow-a and 29 for flow-b). Thus the sessions ended without a completed target implementation; they do not show that the supported fold form fails.

# Flow final participant review

Scope: read-only review of the terminal Flow participant projects, actor traces, start inventories, and saved grader outputs. No participant code was changed and no tests or experiments were run.

| Participant | Start condition | Terminal result | Grader and inherited suite |
|---|---|---|---|
| flow-a | flat | `task.abort` reports rollback; `host.close` and `session-end` show normal termination (36 exchanges, exit codes 0). Final `dictionary.agent` SHA-256 matches its start-inventory hash (`bcd5…b5f2`). | Target definition fails with `FLOW_UNKNOWN_CALL`; 0/72 oracle tests ran. All 18 cases have no result and `behaviorPassed` is null. The inherited suite passed, 16 tests. |
| flow-b | retained | `task.abort` reports rollback; `host.close` and `session-end` show normal termination (34 exchanges, exit codes 0). Final `dictionary.agent` SHA-256 matches its start-inventory hash (`709f…67af`). | Target definition fails with `FLOW_UNKNOWN_CALL`; 0/72 oracle tests ran. All 18 cases have no result and `behaviorPassed` is null. The inherited suite passed, 29 tests. |

The final projects contain no `rental.total-billable-days` query. The flat participant also has no retained `rental.billable-days`; the retained participant still has that seeded API and its 13 attached tests. The saved scoring audit reports both inputs unchanged. These checks support successful rollback and preservation of the starting public dictionary state.

Flow-a did produce a temporary `rental.accumulate-billable-days` candidate. Its recorded own test call passed 5/5, covering 38/38 instructions and 4/4 branches. The subsequent `task.abort` records the helper among task-created words while reporting that dictionary changes were rolled back; the final dictionary hash matches the flat start and does not contain that helper. This is transient work, not a retained implementation or a passing batch result.

Do not characterize either Flow result as an independent behavior failure or as 0/18 behavioral correctness. The target was absent, so no oracle behavior was observed; `behaviorPassed` is null. Because flow-a contacted flow-b during its run, the pair also cannot support an independent two-replication claim. The saved account is in [independence-incident.md](independence-incident.md).

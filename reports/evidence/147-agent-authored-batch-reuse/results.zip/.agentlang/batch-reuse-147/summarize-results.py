from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parent
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
summary = json.loads((root / 'participants/summary.json').read_text(encoding='utf-8'))
out = root / 'results/summary.json'
if out.exists():
    raise SystemExit('Refusing to overwrite result summary')
rows = []
for participant in summary['participants']:
    who = participant['participant']
    directory = root / 'results' / who
    acceptance = json.loads((directory / 'oracle/acceptance.json').read_text(encoding='utf-8'))
    trace = json.loads((directory / 'trace-summary.json').read_text(encoding='utf-8'))
    assert trace['terminal']['event'] == 'session-end'
    start = json.loads(Path(participant['startInventoryPath']).read_text(encoding='utf-8'))
    before = {f['path']: f['sha256'] for f in start['files']}
    project = Path(participant['projectPath'])
    after = {}
    for path in sorted(project.rglob('*')):
        relative = path.relative_to(project)
        if path.is_file() and not {'bin', 'obj'}.intersection(p.lower() for p in relative.parts) and path.name.lower() != 'write.lock':
            after[relative.as_posix()] = digest(path)
    row = {
        'participant': who, 'condition': participant['condition'],
        'independentPassed': sum(c.get('passed') is True for c in acceptance['cases']),
        'independentObserved': sum(c.get('passed') is not None for c in acceptance['cases']), 'independentExpected': 18,
        'acceptancePassed': acceptance['passed'], 'behaviorPassed': acceptance['behaviorPassed'],
        'inputUnchangedDuringScoring': acceptance['inputUnchanged'],
        'brokerExchanges': trace['exchanges'], 'errorResponses': trace['errorResponses'],
        'hostExitCode': trace['terminal']['hostExitCode'],
        'runtimeExitCode': trace['terminal']['runtimeExitCode'],
        'scopeChanges': {
            'added': sorted(after.keys() - before.keys()),
            'removed': sorted(before.keys() - after.keys()),
            'modified': sorted(k for k in before.keys() & after.keys() if before[k] != after[k]),
        },
        'finalSourceHashes': after,
    }
    rows.append(row)
freeze = json.loads((root / 'freeze.json').read_text(encoding='utf-8'))
project_roots = [Path(p['projectPath']) for p in summary['participants']]
immutable = []
for entry in freeze['files']:
    path = Path(entry['path'])
    if any(project == path or project in path.parents for project in project_roots):
        continue
    assert digest(path) == entry['sha256'], f'Frozen input changed: {path}'
    immutable.append(entry)
(root / 'results/immutable-input-audit.json').write_text(json.dumps({'unchanged': True, 'count': len(immutable), 'files': immutable}, indent=2) + '\n', encoding='utf-8')
out.write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
print(json.dumps([{k: row[k] for k in ('participant','condition','independentPassed','acceptancePassed','brokerExchanges')} for row in rows], indent=2))

# Validated-window 149 F# probes

- retained/ is an independent copy of the F# retained starter with opaque billing windows and bounded per-rental billing.
- controls/correct/ is a separate independent copy with Rental.totalBillableDays.
- evidence/ contains serial Release build and execution logs, source hashes, unified diffs, test counts, and artifact cleanup records.

Both test executables preserve the 37 inherited baseline assertions. Validation used dotnet clean, dotnet build -m:1 -p:NuGetAudit=false, direct execution of the produced test DLL, and dotnet run --no-build; dotnet test was not used.
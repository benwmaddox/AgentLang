module BatchBillingTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectOk name expected result =
        match result with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s expected success, received %s" name error.Code

    let expectError name expectedCode result =
        match result with
        | Error error ->
            check name expectedCode error.Code
            check (name + " message") true (not (System.String.IsNullOrWhiteSpace error.Message))
        | Ok actual -> failwithf "%s expected an error, received %A" name actual

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid rental failed: %s" error.Code

    let cancelledAtFour =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation failed: %s" error.Code

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "start cancellation failed: %s" error.Code

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "after-finish cancellation failed: %s" error.Code

    expectOk "empty list with valid window" 0L (Rental.totalBillableDays [] -3L 4L)
    expectError "empty window rejected" "INVALID_BILLING_WINDOW" (Rental.totalBillableDays [] 4L 4L)
    expectError "reversed window rejected" "INVALID_BILLING_WINDOW" (Rental.totalBillableDays [] 5L 4L)

    expectOk "overlaps and duplicate rentals count separately" 9L
        (Rental.totalBillableDays [ original; original; cancelledAtFour ] 3L 7L)
    expectOk "cancellation at start contributes zero" 0L
        (Rental.totalBillableDays [ cancelledAtStart ] 2L 3L)
    expectOk "cancellation after finish has no effect" 4L
        (Rental.totalBillableDays [ cancelledAfterFinish ] 3L 7L)

    expectOk "exact int64 endpoint range" 8L
        (Rental.totalBillableDays [ original; cancelledAtFour ] System.Int64.MinValue System.Int64.MaxValue)

    let orderedRentals = [ cancelledAtFour; original; cancelledAtStart ]
    let fields rentals =
        rentals
        |> List.map (fun rental -> Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental)
    let expectedOrder = [ (2L, 8L, Some 4L); (2L, 8L, None); (2L, 8L, Some 2L) ]
    check "input rental fields and order before call" expectedOrder (fields orderedRentals)
    expectOk "ordered batch total" 5L (Rental.totalBillableDays orderedRentals 3L 7L)
    check "input rental fields and order after call" expectedOrder (fields orderedRentals)

    checks

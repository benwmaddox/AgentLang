open DomainBaselineTests
open BatchBillingTests

[<EntryPoint>]
let main _ =
    let checks = DomainBaselineTests.run () + BatchBillingTests.run ()
    printfn "PASS %d checks (37 inherited baseline assertions plus batch-contract tests)" checks
    0

namespace RentalDomain

type RentalError = {
    Code: string
    Message: string
}

module Rental =
    /// An opaque rental value. Only the validated operations in this module can create one.
    type T = private {
        StartDay: int64
        FinishDay: int64
        CancelledDay: int64 option
    }

    /// Creates a nonempty rental span within the supported service-day bounds.
    let start (startDay: int64) (finishDay: int64) : Result<T, RentalError> =
        if startDay < 0L || startDay >= finishDay || finishDay > 366L then
            Error { Code = "INVALID_RENTAL_SPAN"; Message = "Rental days must satisfy 0 <= start < finish <= 366." }
        else
            Ok { StartDay = startDay; FinishDay = finishDay; CancelledDay = None }

    /// Stores or replaces a cancellation day. Cancellation at start is valid.
    let cancel (rental: T) (day: int64) : Result<T, RentalError> =
        if day < rental.StartDay then
            Error { Code = "CANCELLATION_BEFORE_START"; Message = "Cancellation cannot precede the rental start day." }
        else
            Ok { rental with CancelledDay = Some day }

    /// Counts the rental's occupied service days inside a validated half-open billing window.
    let billableInWindow (rental: T) (window: BillingWindow.T) : int64 =
        let occupiedUntil =
            rental.CancelledDay
            |> Option.map (min rental.FinishDay)
            |> Option.defaultValue rental.FinishDay

        let overlapStart = max (BillingWindow.fromDay window) rental.StartDay
        let overlapEnd = min (BillingWindow.untilDay window) occupiedUntil

        if overlapStart >= overlapEnd then
            0L
        else
            overlapEnd - overlapStart

    /// Counts occupied service days, reporting invalid billing intervals as an error.
    let billableDays (rental: T) (fromDay: int64) (untilDay: int64) : Result<int64, RentalError> =
        match BillingWindow.tryCreate fromDay untilDay with
        | Some window -> Ok (billableInWindow rental window)
        | None ->
            Error {
                Code = "INVALID_BILLING_WINDOW"
                Message = "Billing window must satisfy from-day < until-day."
            }

    /// Totals occupied service days for a list using one validated billing window.
    let totalBillableDays (rentals: T list) (fromDay: int64) (untilDay: int64) : Result<int64, RentalError> =
        match BillingWindow.tryCreate fromDay untilDay with
        | None ->
            Error {
                Code = "INVALID_BILLING_WINDOW"
                Message = "Billing window must satisfy from-day < until-day."
            }
        | Some window ->
            rentals
            |> List.fold (fun total rental -> total + billableInWindow rental window) 0L
            |> Ok

    /// Returns the first occupied service day.
    let startDay (rental: T) = rental.StartDay

    /// Returns the exclusive end of the original service span.
    let finishDay (rental: T) = rental.FinishDay

    /// Returns the stored cancellation day, if one has been set.
    let cancelledDay (rental: T) = rental.CancelledDay

# Validated-window composition probe

Starting revision: f7d1af6. Report148 completed the batch task but replaced a
call to a retained Result-returning domain function after its outer early guard
left a post-fold error branch untested. Test whether existing strong types can
remove that redundant error path without weakening library coverage.

API shape in both languages:
- BillingWindow contains signed 64-bit endpoints with from < until.
- A checked try-create operation returns Option<BillingWindow>.
- rental.billable-in-window / Rental.billableInWindow takes Rental and a
  BillingWindow and returns an integer, with no invalid-window Result case.
- Existing billable-days / billableDays preserves its public API and tests,
  wrapping the checked construction and delegating the domain calculation.

First build and qualify an AgentLang seed and an equivalent opaque-record F#
seed using existing facilities. No runtime, grammar or coverage changes. Keep
the future batch query out of starters. Separately validate a composed batch
control that checks once before traversal and calls the total domain function.
Retain failed attempts and provenance. Run the unchanged prior 17-case singleton
oracle against seeds and 18-case batch oracle against controls; both enumerate
bounded stored days independently of candidate arithmetic.

If these checks pass, use one fresh participant per language, sequentially, with
the same public batch task and 100 broker exchanges. Reuse is optional: the
task does not name the new helper. Runtime discovery must expose it. Pin148's
corrected AgentLang CLI and146's conventional CLI. Explicit isolation rules from
148 apply; no concurrent participants, sibling inspection/messages or delegation.
No per-participant tool whitelist is available, so do not claim enforced isolation.

This is a coordinator-shaped API variation, not evidence that an unaided agent
naturally invented a better abstraction. Two exploratory observations cannot
establish causal or population benefit. Record correctness, actual production
reuse, library qualification, edits, failed attempts and protocol outcomes
separately. Keep147/148 results intact and report any accidental oracle exposure
during preparation rather than hiding or reusing a contaminated seed.

Deliver report149 with tests, source/evidence archives and updated roadmap.
Use main, local tests, and push milestones with their reports.

Preparation provenance: initial Flow worker opened old oracle-bearing control
files before implementing and was stopped. Initial F# worker disclosed a broad
search that exposed old control/result matches. Both outputs are retained only
as preparation evidence. Fresh workers with explicit read allowlists independently
start from the original pre-batch seeds. Actual final paths are flow/retained/project
and fsharp-clean/retained; the earlier F# output is not a participant start.

# Validated-window 149 starter review

## Finding

The selected starters are suitable for the fresh reuse experiment, with no source-level blocker found in the reviewed scope. Use `.agentlang/validated-window-149/flow/retained/project` and `.agentlang/validated-window-149/fsharp-clean/retained` as the starts, and keep the aggregate APIs in the separate controls.

## Checks

- Both implementations enforce `from < until` when constructing a billing window. Flow checks with `int::less-than`; F# stores `int64` endpoints in a private record and only constructs it through `BillingWindow.tryCreate`.
- Both `billable-in-window` implementations clip the rental and window endpoints, return zero when the overlap is empty or touching, and subtract only after that check. Rental bounds are validated to `0..366`, so even a window using `Int64.MinValue` and `Int64.MaxValue` cannot make the subtraction overflow. The retained tests include these extreme endpoints.
- The public singleton APIs and error behavior remain: Flow retains `rental.billable-days(Rental, Int, Int) -> Result<Int, RentalError>` and the `INVALID_BILLING_WINDOW` code; F# retains the corresponding `Result<int64, RentalError>` API and error. All 29 original Flow test names are present. The F# inherited `DomainBaselineTests.fs` matches the original starter by SHA-256, and both singleton implementations delegate through the validated window to `billable-in-window`.
- The Flow retained project has no `total-billable-days`, `totalBillableDays`, or `billing-window.add-rental-days` references, including in its hidden project store. The F# retained project has no `totalBillableDays` or batch-test references.
- In both controls, the aggregate checks the window once before traversal and folds through `billable-in-window`. The Flow callback carries the validated window in `BillingAccumulator`; neither query repeats the clipping arithmetic.
- Flow clean-evidence reports the new library functions as committed at library maturity with complete instruction, branch, and finite-return coverage. It records 41/41 retained tests and 47/47 control tests, with their examples passing. F# evidence records clean builds and 48 retained / 49 control assertions passing.
- Current Flow dictionary hashes match the clean-evidence provenance manifest. The inherited F# baseline hash matches the original. Root reports the independent singleton oracle passed 17/17 for both languages and the batch oracle passed 18/18 for both; I did not rerun those checks.

## Limitation

`plan.md` discloses earlier exploratory attempts that exposed prior controls or oracle matches. Those attempts should remain excluded from participant starts. The selected paths above are separately recorded as clean preparations from the original pre-batch seeds; this review did not inspect participant activity or rerun the external oracles.

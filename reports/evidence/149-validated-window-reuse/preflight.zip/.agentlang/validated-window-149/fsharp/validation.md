# F# validation

Each project was cleaned and built serially in Release with `-m:1 -p:NuGetAudit=false`; both builds completed with zero warnings and errors. Each built executable test DLL was then run directly with `dotnet`, not through `dotnet test`.

The following commands ran from each project root, first `retained`, then `controls/correct`:

```powershell
dotnet clean tests/RentalDomain.Tests.fsproj --configuration Release -m:1 -p:NuGetAudit=false --nologo
dotnet build tests/RentalDomain.Tests.fsproj --configuration Release -m:1 -p:NuGetAudit=false --nologo
dotnet tests/bin/Release/net9.0/RentalDomain.Tests.dll
```

- Retained: clean and build exit 0; `PASS 37 inherited checks`; `PASS 49 baseline checks`.
- Correct control: clean and build exit 0; `PASS 37 inherited checks`; `PASS 58 baseline checks`.

The exact clean, build and test commands and their output are in `logs/retained-*.log` and `logs/control-*.log`. Temporary files used by the .NET commands were directed under this task's `logs` directory.

After the DLL runs, I removed only the verified `bin`, `obj`, and task-local temporary directories created by these builds, leaving the source trees and logs clean.

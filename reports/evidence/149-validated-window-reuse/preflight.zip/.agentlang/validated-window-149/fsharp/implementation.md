# Validated billing window feasibility

The retained starter introduces `BillingWindow.T` as a private-record type. `BillingWindow.tryCreate` returns `None` unless `fromDay < untilDay`; it stores the original `int64` endpoints and exposes read-only getters. Construction does no endpoint arithmetic, so even the full signed `Int64` range is representable.

`Rental.billableInWindow` accepts the validated window and returns a plain `int64`. It clips the request against the persisted rental span and its cancellation cap, returning zero for no overlap. Subtraction happens only after a positive overlap is established, which confines both operands to the rental's validated 0–366 day span. The existing `Rental.billableDays` signature and `INVALID_BILLING_WINDOW` error are preserved by constructing a window and delegating to the bounded calculation.

The immutable retained starter contains no `totalBillableDays`. The separate correct control validates the request once, then sums `Rental.billableInWindow` over each list entry. It does not duplicate the occupancy or clipping calculation. Its tests cover empty valid input, invalid windows on empty and zero-occupancy inputs, cancellation, overlapping and repeated rentals, reordering, and extreme signed endpoints.

This addresses the composition concern in `reports/148-flow-list-discovery.md`: after the batch function validates its request, each per-rental call has no repeated error alternative to leave unreachable and no duplicate arithmetic to qualify or maintain. The tests execute both success and failure paths for construction and the public queries; they are behavior checks, not instrumented coverage metrics.

`provenance.json` records the six source files and hashes. `diffs/` contains the retained-seed and control-starter patches. `counts.json` and `validation.md` summarize the preserved 37 inherited checks and both successful serial Release runs; full output is in `logs/`.

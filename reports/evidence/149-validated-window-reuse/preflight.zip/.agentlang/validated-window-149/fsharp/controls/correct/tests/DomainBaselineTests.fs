module DomainBaselineTests

open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectError name expectedCode result =
        match result with
        | Error error -> check name expectedCode error.Code
        | Ok _ -> failwithf "%s expected an error" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid start failed: %s" error.Code

    check "start getter" 2L (Rental.startDay original)
    check "finish getter" 8L (Rental.finishDay original)
    check "initial cancellation" None (Rental.cancelledDay original)

    expectError "negative start" "INVALID_RENTAL_SPAN" (Rental.start -1L 8L)
    expectError "empty start span" "INVALID_RENTAL_SPAN" (Rental.start 2L 2L)
    expectError "reversed start span" "INVALID_RENTAL_SPAN" (Rental.start 8L 2L)
    expectError "finish above limit" "INVALID_RENTAL_SPAN" (Rental.start 2L 367L)
    expectError "start above limit" "INVALID_RENTAL_SPAN" (Rental.start 366L 367L)

    match Rental.start 0L 366L with
    | Ok rental ->
        check "lower service bound" 0L (Rental.startDay rental)
        check "upper service bound" 366L (Rental.finishDay rental)
    | Error error -> failwithf "valid service bounds failed: %s" error.Code

    match Rental.cancel original 1L with
    | Error error -> check "cancel before start" "CANCELLATION_BEFORE_START" error.Code
    | Ok _ -> failwith "cancellation before start unexpectedly succeeded"

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "cancel at start" (Some 2L) (Rental.cancelledDay cancelledAtStart)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "cancel after finish" (Some 9L) (Rental.cancelledDay cancelledAfterFinish)

    let firstCancellation =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "first cancellation failed: %s" error.Code
    let replacement =
        match Rental.cancel firstCancellation 6L with
        | Ok rental -> rental
        | Error error -> failwithf "replacement cancellation failed: %s" error.Code
    check "replacement stored" (Some 6L) (Rental.cancelledDay replacement)
    check "intermediate value retained" (Some 4L) (Rental.cancelledDay firstCancellation)
    check "source value unchanged" None (Rental.cancelledDay original)

    let expectBillable name (expected: int64) (rental: Rental.T) fromDay untilDay =
        match Rental.billableDays rental fromDay untilDay with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s expected %A billable days, received %s" name expected error.Code

    expectBillable "whole rental" 6L original 0L 10L
    expectBillable "narrow window" 2L original 3L 5L
    expectBillable "left clipped window" 2L original 1L 4L
    expectBillable "right clipped window" 2L original 6L 10L
    expectBillable "adjacent before" 0L original -4L 2L
    expectBillable "adjacent after" 0L original 8L 12L
    expectBillable "window before rental" 0L original -4L 0L
    expectBillable "signed range endpoints" 6L original System.Int64.MinValue System.Int64.MaxValue
    expectBillable "extreme negative window" 0L original System.Int64.MinValue 1L

    expectBillable "cancelled before finish" 2L firstCancellation 0L 10L
    expectBillable "window partly after cancellation" 1L firstCancellation 3L 8L
    expectBillable "window at cancellation boundary" 0L firstCancellation 4L 8L
    expectBillable "cancellation after finish" 6L cancelledAfterFinish 0L 10L
    expectBillable "cancellation at start has no occupied days" 0L cancelledAtStart 2L 3L

    expectError "empty billing window" "INVALID_BILLING_WINDOW" (Rental.billableDays original 3L 3L)
    expectError "reversed billing window" "INVALID_BILLING_WINDOW" (Rental.billableDays original 5L 4L)
    expectError "invalid window for empty rental" "INVALID_BILLING_WINDOW" (Rental.billableDays cancelledAtStart 2L 2L)
    match Rental.billableDays original 3L 3L with
    | Error error -> check "billing error explains invalid window" true (not (System.String.IsNullOrWhiteSpace error.Message))
    | Ok _ -> failwith "invalid billing window unexpectedly succeeded"

    check "billing preserves source start" 2L (Rental.startDay original)
    check "billing preserves source finish" 8L (Rental.finishDay original)
    check "billing preserves source cancellation" None (Rental.cancelledDay original)

    let inheritedChecks = checks
    if inheritedChecks <> 37 then
        failwithf "expected 37 inherited checks, found %d" inheritedChecks
    printfn "PASS %d inherited checks" inheritedChecks

    let expectNoWindow name fromDay untilDay =
        check name true (BillingWindow.tryCreate fromDay untilDay |> Option.isNone)

    let expectWindowBillable name expected rental fromDay untilDay =
        match BillingWindow.tryCreate fromDay untilDay with
        | Some window ->
            check name expected (Rental.billableInWindow rental window)
        | None ->
            failwithf "%s could not create a valid billing window" name

    expectNoWindow "equal billing endpoints rejected" 4L 4L
    expectNoWindow "reversed billing endpoints rejected" 5L 4L
    expectNoWindow "reversed extreme endpoints rejected" System.Int64.MaxValue System.Int64.MinValue

    match BillingWindow.tryCreate System.Int64.MinValue System.Int64.MaxValue with
    | Some window ->
        check "extreme window lower endpoint" System.Int64.MinValue (BillingWindow.fromDay window)
        check "extreme window upper endpoint" System.Int64.MaxValue (BillingWindow.untilDay window)
    | None -> failwith "valid extreme billing window was rejected"

    expectWindowBillable "bounded helper whole rental" 6L original 0L 10L
    expectWindowBillable "bounded helper cancellation at start" 0L cancelledAtStart 2L 3L
    expectWindowBillable "bounded helper later cancellation" 2L firstCancellation 0L 10L
    expectWindowBillable "bounded helper clips both sides" 2L original 3L 5L
    expectWindowBillable "bounded helper wide int64 endpoints" 6L original System.Int64.MinValue System.Int64.MaxValue
    expectWindowBillable "bounded helper extreme lower window" 0L original System.Int64.MinValue 1L
    expectWindowBillable "bounded helper extreme upper window" 1L original 7L System.Int64.MaxValue

    let expectTotal name expected rentals fromDay untilDay =
        match Rental.totalBillableDays rentals fromDay untilDay with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s expected %A total billable days, received %s" name expected error.Code

    let expectTotalError name expectedCode rentals fromDay untilDay =
        match Rental.totalBillableDays rentals fromDay untilDay with
        | Error error -> check name expectedCode error.Code
        | Ok actual -> failwithf "%s expected an error, received %A" name actual

    let extraRental =
        match Rental.start 4L 7L with
        | Ok rental -> rental
        | Error error -> failwithf "valid extra rental failed: %s" error.Code

    expectTotal "valid empty batch" 0L [] 0L 10L
    expectTotalError "empty batch rejects equal window first" "INVALID_BILLING_WINDOW" [] 3L 3L
    expectTotalError "empty batch rejects reversed window first" "INVALID_BILLING_WINDOW" [] 5L 4L
    expectTotalError "empty occupancy still rejects invalid window" "INVALID_BILLING_WINDOW" [ cancelledAtStart ] 2L 2L
    expectTotal "all empty occupancy" 0L [ cancelledAtStart ] 2L 3L
    expectTotal "later cancellation batch" 2L [ firstCancellation ] 0L 10L
    expectTotal "overlapping and duplicate rentals count independently" 15L [ original; extraRental; original ] 0L 10L
    expectTotal "reordered overlapping rentals preserve total" 15L [ extraRental; original; original ] 0L 10L
    expectTotal "batch supports extreme signed endpoints" 6L [ original ] System.Int64.MinValue System.Int64.MaxValue

    checks

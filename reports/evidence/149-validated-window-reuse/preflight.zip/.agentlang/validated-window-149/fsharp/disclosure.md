# Broad-search disclosure

The broad search ran from `D:\code\AgentLang` in PowerShell. Its exact command was:

```powershell
rg -n -i 'billableInWindow|BillingWindow|totalBillableDays|billing window|billable days|rental' .agentlang -g '*.md' -g '*.fs' -g '*.json' -g '!**/obj/**' -g '!**/bin/**'
```

The search covered matching Markdown, F#, and JSON files across `.agentlang`, including experiment result and control directories. The tool reported 5,791 lines and an original output size of 228,244 tokens, then truncated most of the output. I did not preserve a complete inventory and am not reopening files to reconstruct it.

Material visible in the returned output included:

- The batch-reuse-147 task draft and review reports, including the intended independent-oracle categories and the finding that its retained F# batch implementation repeated the cancellation and overlap calculation instead of calling the singleton helper.
- A source excerpt from `.agentlang/reuse-145/fsharp/controls/positive/project/Rental.fs` showing cancellation capping and interval construction.
- Test excerpts from `.agentlang/reuse-145/controls/negative-count-plus-one/tests/Program.fs`, including expected results for adjacent windows, cancellation at start, equal and reversed endpoints, partial overlap, cancellation clipping, and cancellation after finish.
- Batch-reuse-147 result-artifact matches, including summary/hash entries and F# trace/command metadata. The visible command metadata referenced an `oracle/working-project/tests/RentalDomain.Tests.fsproj` path and `project/RentalDomain.fsproj`.

Because the returned output was truncated, this list records the control/result material I can confirm from the existing tool output; it is not a complete inventory of every match. This search occurred before the parent supplied the explicit instruction not to inspect controls, oracle files, requests, or traces. After that instruction, I did not open those files.

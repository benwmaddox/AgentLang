# Incident disclosure: validated window 149

Status: work stopped after accidental oracle exposure. No API implementation, seed publication, or control project was produced.

## Accidental exposure

While looking for JSONL request syntax, I ran `Get-Content -Raw` on `.agentlang/fold-discovery-148/controls/correct/requests.jsonl`. The output included embedded oracle test source and was truncated by the tool. The same command read `.agentlang/fold-discovery-148/controls/correct/acceptance.json`, whose output included the 18-case result summary and expected values. This access was accidental; no details from those cases were used to implement or validate a solution.

The command then attempted to read `.agentlang/fold-discovery-148/controls/correct/working-project/dictionary.agent` with both `-Raw` and `-TotalCount`; PowerShell rejected that argument combination and returned no file contents. After recognizing the exposure, I stopped and did not access more control or oracle files.

## Owned flow subtree changes

Created `.agentlang/validated-window-149/flow/` with these directories: `attempts/001-cli-protocol-help`, `logs`, `tmp`, and `work/library-project`.

`work/library-project` is a recursive clone of `.agentlang/batch-reuse-147/flow/starts/retained/project`. Its 49 original files are hash-identical to the source. Running the pinned CLI created one additional zero-byte file, `work/library-project/.agentlang/store/WRITE.lock` (SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`). No cloned source file changed or disappeared. The `snapshots` directory existed in both trees.

The only other files are protocol-help evidence:

- `attempts/001-cli-protocol-help/commands.txt` (43 bytes, SHA-256 `28377558837678b18406430311bf5ef04ed12327f22e54581d683040193c5307`): `:help replacement`, `:help authoring`, `:quit`.
- `attempts/001-cli-protocol-help/cli.log` (7,459 bytes, SHA-256 `c595079f368e0bb04d922d5cd78d1f148ee27a697848222c9e90d4c2a8597334`): pinned CLI help output only.
- `attempts/001-cli-protocol-help/exit-code.txt` (1 byte, SHA-256 `5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9`): `0`.

No broker was started, no source definitions were submitted, and no final starter or control project was created. The work should be treated as preparation evidence only; a fresh implementation agent should start from the original retained START without relying on my exposed oracle context.

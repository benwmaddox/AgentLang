# Commands and protocol provenance

Pinned executable: `D:\code\AgentLang\.agentlang\fold-discovery-148\runtime\bin\AgentLang.Cli\release\AgentLang.Cli.dll`

Pinned command-line help was captured with:

```powershell
dotnet "D:\code\AgentLang\.agentlang\fold-discovery-148\runtime\bin\AgentLang.Cli\release\AgentLang.Cli.dll" --help
```

JSONL operation and authoring schemas came from the pinned runtime's own `help` requests. The requests and complete responses are in `protocol-help.request.jsonl` and `protocol-help.response.jsonl`.

For each saved request file, the CLI was run as a fresh process using this PowerShell form, with stdout and stderr redirected to adjacent response and log files:

```powershell
Get-Content -LiteralPath <request.jsonl> | & dotnet <pinned AgentLang.Cli.dll> --project <project-directory> --jsonl 1> <response.jsonl> 2> <stderr.log>
```

The `*-fresh-reload.request.jsonl` files were run after restarting the CLI and loading each final project from its saved `.agentlang` store. `control-build.request.jsonl` preserves the initial aggregate case, which expected 6 despite the two clipped spans totaling 5. The corrected request and successful output are `control-build-corrected.request.jsonl` and `control-build-corrected.response.jsonl`.
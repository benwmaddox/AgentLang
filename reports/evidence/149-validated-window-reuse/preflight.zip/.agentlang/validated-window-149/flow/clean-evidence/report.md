# Validated billing window API probe

The probe starts from the retained 49-file billing project at `.agentlang/batch-reuse-147/flow/starts/retained/project`. The CLI copy log records 49 files copied into `clean-work`. The implementation stays within the new `validated-window-149/flow` study folders and does not edit runtime source or gates.

`BillingWindow` validates `from-day < until-day`. `billing-window.try-create(Int, Int)` returns `some` for ordered bounds and `none` for equal or reversed bounds. The constructor and pure `rental.billable-in-window(Rental, BillingWindow)` keep request endpoints as `Int64`; occupancy is clipped to rental bounds before subtraction. Tests use exact `Int64.MinValue` and `Int64.MaxValue` together.

`rental.billable-days` keeps its public signature, documentation, 13 attached tests, and `INVALID_BILLING_WINDOW` error. Its replacement creates one validated window and delegates occupied-day arithmetic to `rental.billable-in-window`. The other 16 inherited tests remain attached and pass unchanged, for 29 inherited tests total.

The retained starter contains the validated API and no batch aggregate. In the separate control, `BillingAccumulator` carries the already validated window and running total so a statically named fold callback can call `rental.billable-in-window` without capturing caller locals. `rental.total-billable-days` calls the validated-window constructor once before the fold; its `none` branch returns the same domain error before traversal, including for an empty list. The accumulator is not a `Result`, and the control query contains no duplicate occupancy calculation.

Fresh-process verification with the pinned Release CLI passed 41/41 tests and both API examples in the retained starter. The control passed 47/47 tests and all three examples. Every new function is committed as a library and has complete measured coverage:

| Function | Instructions | Branch outcomes | Finite return coverage |
| --- | ---: | ---: | --- |
| `billing-window.valid?` | 5/5 | 0/0 | Bool false and true |
| `billing-window.try-create` | 9/9 | 2/2 | Option none and some |
| `rental.billable-in-window` | 29/29 | 4/4 | complete |
| `rental.billable-days` replacement | 12/12 | 2/2 | Result error and ok |
| `billing-window.add-rental-days` | 12/12 | 0/0 | complete |
| `rental.total-billable-days` | 19/19 | 4/4 | Result error and ok |

The aggregate tests cover valid empty and populated lists, invalid empty and populated requests, cancellation clipping, and the full Int64 window. The initial aggregate run exposed an incorrect expected sum: `[2,8)` clipped to `[1,5)` contributes 3 days and the cancelled rental contributes 2, for a total of 5. The corrected run passes all gates. An earlier define-only process also showed that staged candidates do not survive a CLI restart; final define/test/commit sequences run within one JSONL session.

Fresh reload outputs, all JSONL requests and responses, stderr logs, source snapshots, CLI help, commands, and SHA-256 provenance are preserved in this directory. The root agent will run the independent oracle separately.
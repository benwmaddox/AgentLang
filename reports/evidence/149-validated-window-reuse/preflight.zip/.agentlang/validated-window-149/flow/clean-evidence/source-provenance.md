# Source and runtime provenance

The original seed path was D:\code\AgentLang\.agentlang\batch-reuse-147\flow\starts\retained\project. A fresh recursive copy into flow/clean-work reported 49 files copied (226.6 KB), with no copy failures. The seed dictionary source and final exported dictionaries are copied into sources/. The evidence manifest hashes those files, each authored source snapshot, every saved request, response, and log file, and the pinned CLI.

No prior-study participant traces, controls, or oracle files were opened. The only hashed source read from the original seed is its allowlisted dictionary.agent.

Pinned CLI: D:\code\AgentLang\.agentlang\fold-discovery-148\runtime\bin\AgentLang.Cli\release\AgentLang.Cli.dll.

## Key SHA-256 values

- seed-dictionary: 709f0230bcd2689807a90846aad20889ce615a52870dff4bb0342d02db0967af (D:\code\AgentLang\.agentlang\batch-reuse-147\flow\starts\retained\project\dictionary.agent)
- pinned-cli: 810cbe7157b1948fd94ad954cfff5c387cf72f2af7babb8d279ecc9812bb155a (D:\code\AgentLang\.agentlang\fold-discovery-148\runtime\bin\AgentLang.Cli\release\AgentLang.Cli.dll)
- retained-dictionary: 1930c7a718ea8048031872726ac1e15c43a319b038879c16d5ba9df3e2a8db48 (D:\code\AgentLang\.agentlang\validated-window-149\flow\retained\project\dictionary.agent)
- control-dictionary: 9ed7abf146cfee15a280f4f0c7ba269b4e5aa0b5c4c50bf15b5d4a015bf85971 (D:\code\AgentLang\.agentlang\validated-window-149\flow\control\project\dictionary.agent)
- retained-current-pointer: ffba7d09bedc05c80154de6b141a6f1d9d1f954885d3e1002921546c30357670 (D:\code\AgentLang\.agentlang\validated-window-149\flow\retained\project\.agentlang\store\CURRENT)
- control-current-pointer: c50878f484f7f9cddb9c738478092f84148addfe088e27eca664b60829b911dd (D:\code\AgentLang\.agentlang\validated-window-149\flow\control\project\.agentlang\store\CURRENT)

The full SHA-256 inventory is in provenance.tsv. It excludes itself and this note.

## Fresh storage reloads

- Retained starter: generation 10, manifest efd9716a71d0ca8a2dd2c49afc74ef184c1a55d10a33814d5f795c130434eb78, authority manifest, export warning none.
- Control: generation 12, manifest 6cb75491c65182c7b96f397e263bc3c6f743c8adea893a4d9932b51d90e38dcf, authority manifest, export warning none.
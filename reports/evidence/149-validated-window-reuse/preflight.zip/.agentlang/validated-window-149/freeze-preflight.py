from pathlib import Path
import hashlib,json,zipfile
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OUT=REPO/'reports/evidence/149-validated-window-reuse'
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'preflight.zip'; index=OUT/'preflight-index.json'; freeze=ROOT/'freeze.json'
assert not any(p.exists() for p in (archive,index,freeze))
sha=lambda data:hashlib.sha256(data).hexdigest()
for arm in ('flow','fsharp'):
    directory=ROOT/'participants'/arm
    assert not (directory/'actor.trace.jsonl').exists()
    for entry in json.loads((directory/'start-inventory.json').read_text(encoding='utf-8'))['files']:
        assert sha((directory/'project'/entry['path']).read_bytes())==entry['sha256']
files={p for p in ROOT.rglob('*') if p.is_file() and not {'bin','obj','tmp','temp','root-tmp','__pycache__'}.intersection(x.lower() for x in p.relative_to(ROOT).parts) and p.name.lower()!='write.lock'}
for runtime in ('.agentlang/fold-discovery-148/runtime/bin/AgentLang.Cli/release','.agentlang/conventional-discovery-146/root-artifacts/bin/AgentLang.Conventional.Cli/release'):
    files.update(p for p in (REPO/runtime).rglob('*') if p.is_file())
files.update(REPO/p for p in ('scripts/Start-SubagentTrialHostV2.ps1','scripts/Audit-SubagentTrialTerminationV2.ps1','docs/SUBAGENT-TRIAL-HOST-V2.md'))
rows=[{'path':p.relative_to(REPO).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]
freeze.write_text(json.dumps({'frozenUtc':datetime.now(timezone.utc).isoformat(),'status':'before-dispatch','files':rows},indent=2)+'\n',encoding='utf-8')
files.add(freeze); entries=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        data=p.read_bytes(); name=p.relative_to(REPO).as_posix(); z.writestr(name,data)
        entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(entries)
    for row in entries: assert sha(z.read(row['path']))==row['sha256']
meta={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entryCount':len(entries),'files':entries}
index.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in meta.items() if k!='files'}))

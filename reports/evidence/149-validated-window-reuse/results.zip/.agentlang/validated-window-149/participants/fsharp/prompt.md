You are a fresh, independent participant. The human authorizes changes only to this assigned isolated project and its local tests. Use only the supplied broker for project discovery, authoring, evaluation, and testing. Your only permitted raw filesystem operation is reading this assigned prompt to verify its supplied SHA-256 before starting the broker. After that check, use the broker exclusively for project work. Do not read or edit files outside the assigned prompt and project. Do not use web tools or delegate work. Launch the specified broker once and keep using that process session.

Run the launch command from `D:\code\AgentLang` using `exec_command` with `tty:true` and `yield_time_ms:10000`. Send one newline-terminated JSON request at a time and inspect its response before the next mutation. The broker allows at most 100 exchanges, each with a 120000 ms timeout. On a timeout, poll the same process session; do not restart the broker.

Exact launch command:

```powershell
pwsh -NoProfile -File 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\conventional-discovery-146\root-artifacts\bin\AgentLang.Conventional.Cli\release\AgentLang.Conventional.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\validated-window-149\participants\fsharp\project' -TracePath 'D:\code\AgentLang\.agentlang\validated-window-149\participants\fsharp\actor.trace.jsonl' -AllowedOperations 'inspect,read,search,patch,replace,validate' -Profile conventional -AdditionalCliArgumentsJson '["--validation-project","tests/RentalDomain.Tests.fsproj"]' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

Begin with `{"op":"inspect"}` to discover file paths and operation schemas. Use `inspect`, `read`, and `search` through the broker to understand the assigned project. Make edits only through `patch` or `replace`. Finish substantive work with `validate` and observe its full result, then send `{"op":"host.close"}` and wait for normal process exit.


Participant isolation is mandatory. Do not list agents, inspect their status,
read their messages or files, contact siblings, delegate, or use any other
participant's findings. Do not use collaboration tools except to return your
final result to the coordinator. Use only the assigned prompt and broker.
Do not request implementation hints or exceptions to the task constraints.
If you cannot finish, report the limitation, abort the task if applicable,
and close normally. At completion disclose any tool use outside prompt
verification and the broker, including any out-of-band information received.
No other participant runs concurrently in this study.

# Task

Add a pure query returning the total chargeable integer rental-days for a list
of rentals within a requested half-open billing window.

Required API:
- AgentLang: rental.total-billable-days(rentals: List<Rental>, from-day: Int, until-day: Int) -> Result<Int, RentalError>.
- F#: RentalDomain.Rental.totalBillableDays : Rental.T list -> int64 -> int64 -> Result<int64, RentalError>.

Each stored rental satisfies 0 <= start-day < finish-day <= 366. Its optional
cancellation day is at or after start-day and may exceed finish-day. Occupancy is
[start-day, finish-day) without cancellation, or [start-day, min(finish-day,
cancellation-day)) with cancellation. Cancellation at start leaves zero days.

First reject from-day >= until-day with RentalError code INVALID_BILLING_WINDOW,
including when the rental list is empty or all rentals have empty occupancy.
Otherwise count the occupied integer days inside [from-day, until-day) for each
rental and add the counts. Rentals are independent: overlapping rentals are
charged separately, and repeated entries count repeatedly. A valid window with
an empty list returns zero. Request bounds may be any signed 64-bit integers;
do not subtract the unrestricted request endpoints. Exact error wording is not
an acceptance requirement, but explain invalid windows.

Preserve the input list, its order, every rental field, existing public APIs,
and inherited tests. Inspect the available project capabilities; no particular
private helper, abstraction or algorithm is required. Add effective tests and
run the complete project suite. AgentLang must qualify and publish the new query
and any authored production dependencies as libraries without demoting existing
library functions. Finish the normal task and broker workflow. F# uses its
ordinary compiler and executable test workflow.

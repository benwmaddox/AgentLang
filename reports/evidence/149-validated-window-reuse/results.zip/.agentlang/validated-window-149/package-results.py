from pathlib import Path
import hashlib,json,zipfile
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent; REPO=ROOT.parents[1]
OUT=REPO/'reports/evidence/149-validated-window-reuse'
archive=OUT/'results.zip';index=OUT/'results-index.json'
assert not archive.exists() and not index.exists()
sha=lambda data:hashlib.sha256(data).hexdigest()
projects=[ROOT/'participants'/a/'project' for a in ('flow','fsharp')]
checked=[]
for row in json.loads((ROOT/'freeze.json').read_text(encoding='utf-8'))['files']:
    p=REPO/row['path']
    if any(project in p.parents for project in projects):continue
    assert sha(p.read_bytes())==row['sha256'],p
    checked.append(row)
counts={}
for arm,project in zip(('flow','fsharp'),projects):
    summary=json.loads((ROOT/'results'/arm/'summary.json').read_text(encoding='utf-8'))
    current={p.relative_to(project).as_posix():sha(p.read_bytes()) for p in project.rglob('*') if p.is_file() and p.name.lower()!='write.lock' and not {'bin','obj'}.intersection(x.lower() for x in p.relative_to(project).parts)}
    assert current==summary['finalSourceHashes']
    counts[arm]=len(current)
(ROOT/'results/final-hash-audit.json').write_text(json.dumps({'checkedUtc':datetime.now(timezone.utc).isoformat(),'immutableInputCount':len(checked),'immutableInputsUnchanged':True,'finalSourceCounts':counts,'finalSourcesUnchangedSinceGrading':True},indent=2)+'\n',encoding='utf-8')
files=set()
for folder in ('participants','results'):
    files.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.name.lower()!='write.lock' and not {'bin','obj','tmp','temp','root-tmp','__pycache__'}.intersection(x.lower() for x in p.relative_to(ROOT).parts))
files.update(ROOT/p for p in ('freeze.json','dispatch.json','grade-one.py','summarize-results.py','package-results.py','results-review.md'))
entries=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        data=p.read_bytes();name=p.relative_to(REPO).as_posix();z.writestr(name,data);entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(entries)
    for row in entries:assert sha(z.read(row['path']))==row['sha256']
meta={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entryCount':len(entries),'files':entries}
index.write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in meta.items() if k!='files'}))

# Validated-window 149 results review

No material discrepancy found; the results support the report's bounded conclusion.

- Both oracle summaries record 18/18 cases, `passed: true`, unchanged inputs, and exit code 0. The own-suite evidence records Flow 47/47 and F# 64 checks. Both termination audits report host/runtime exit 0/0.
- Flow's trace records 21 exchanges and exactly two errors, both rejected `define` attempts (semicolon syntax and a nonliteral example expectation). It then records passing tests, successful commits, and a final 47/47 run. The final source validates once before `fold`; the fold callback calls `rental.billable-in-window`. The post-test query description is persistent at library maturity with 19/19 instructions, 4/4 branches, and complete `Result` return coverage. The callback's post-test description is also persistent at library maturity with 10/10 instructions, no branches, and complete return coverage.
- F# records 11 exchanges and zero errors. The final `Rental.totalBillableDays` validates once and uses `List.sumBy` with `billableInWindow`; the oracle summary lists only `project/Rental.fs` and `tests/BillingWindowTests.fs` as modified. Its own-suite output is `PASS 64 checks`.
- The frozen pre-dispatch manifest includes the selected Flow and F# starts (81 and 8 files). The participant inventories have the same counts. Flow's result scope has no removals and changes the dictionary/store pointer while adding project-store snapshots and task history; F# has no additions or removals and modifies only the two files above.
- The report does not claim a language advantage. It treats F#'s lower exchange and error counts as observations from one pair, explains that the protocols differ, and says the result is not causal or population evidence. That framing matches the artifacts.

One evidence limit: actor traces identify the `agentlang` and `conventional` harness profiles, but do not record model or reasoning settings. The report's Luna/max parity therefore depends on coordinator dispatch metadata outside the inspected result files. Isolation also remains prompt-level, as the report states.

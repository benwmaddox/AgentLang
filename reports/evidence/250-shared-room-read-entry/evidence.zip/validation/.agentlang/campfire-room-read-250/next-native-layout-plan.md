# Next native room-page blockers

Read-only planning result, 2026-10-12. Add only bounded typed list layout/codecs,
native host-output scanning and `ListEmpty` first. No map/fold/filter/editing support
is required by the room-page Flow closure. List values remain contiguous arena
encodings, with no language heap payload or automatic compaction.

Candidate layout: an 8-byte count/reserved-zero header, followed by packed aligned
element root encodings. Each element is scanned with the existing child layout;
variable strings and options determine its exact extent. Reject malformed counts,
reserved bits, truncation, excess output extent and capacity overflow. Empty lists
still consume an 8-byte root. A descriptor has one child edge. Do not make scanner
workspace grow in proportion to list length.

This adds owning-layout kind 10 and changes the layout contract from ABI4 to ABI5;
context ABI2 and descriptor struct sizes need not change. Audit source literals,
native scanner assertions, NativeHostTests, native-value-stack.json, all three
owning-mailbox fixtures, and NativeValueStack test/experiment oracles. Compiler,
runtime and emitted descriptors must agree, with fresh artifacts in validation.

OwningStackAot.fs needs list type construction, language-type conversion, sizing,
encode/decode, descriptor emission, operation validation and dynamic ListEmpty
emission. ArenaLifetime.fs should model the empty-list origin like OptionNone.
owning_stack_runtime.{h,c} and its C tests need list descriptor/scanner coverage.
Existing generic host-output commit can validate and commit the new value in place.

Add invariant signed Int64 `int.to-string` separately or in the same focused
layout milestone. The largest decimal representation is 20 ASCII bytes. Handle
Int64.MinValue without signed overflow; reuse/generalize the Float formatter's
ASCII-to-UTF16 arena writer. Test zero, negatives, boundaries and interpreter parity.

Room-read then needs its explicit nine-operation native profile, including session
refresh writes, cookie/browser operations and membership/message SQL. Do not broaden
the existing room-find-only profile silently. The current 65,536-byte output bound
is sufficient for the lookup fixture, not proof of capacity for arbitrary message
pages; choose and test the page contract's bound against real permitted data.

Local validation: fresh focused list/formatter tests, Verify-NativeConformance.ps1,
Verify-NativeValueStack.ps1, and the native Campfire gate after adapter expansion.
The entire native HTTP path and measured performance remain subsequent requirements.

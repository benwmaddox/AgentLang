# Interpreted reference memory review

## Finding

The inspected request path has no application-owned collection that appends a trace, task log, request value, or response for every HTTP request. It binds one checked Flow entrypoint at startup and keeps that callable with the application engine. Each invocation creates a local interpreter trace and result, returns the response to the transport, and lets those request-scoped objects go out of scope. The source review therefore does not support a per-request retention/leak finding.

The reported reference process growth (RSS about 367 MB to 924 MB and private bytes about 500 MB to 1,058 MB across paired 15-second runs, while throughput falls) remains unexplained by this source review. Heap/working-set growth under the generated Server GC configuration is plausible, but RSS/private-byte readings alone cannot distinguish live managed objects, committed-but-reusable GC segments, framework/native allocations, or retained requests. This review did not inspect the live processes or make HTTP requests.

## Request path evidence

- `applications/campfire/Http/Application.fs:69` constructs one `Runtime.Engine`; `:89-94` binds `campfire.http.dispatch` once and exposes only `entry.Invoke [value]` to the host. The request path does not call `Engine.Dispatch` or a word-selection API. The checked entrypoint body is prepared at bind time in `src/AgentLang.Core/Runtime.fs:6319-6438` and captures its snapshot.
- `src/AgentLang.Core/Runtime.fs:6440-6454` creates a fresh `Trace` inside each `FlowEntryPoint.Invoke`, executes the fixed body, decodes the result, and returns values/console/effects. The `Trace` fields at `:166-182` and its initializer at `:875-889` are invocation-local; this code does not add them to an engine-wide history. `Application.Invoke` keeps only the returned response long enough to render it, and requires the console list to be empty (`Application.fs:90-96`).
- The engine does have persistent task-authoring state: `previousTaskLog` is one optional JSON object (`Runtime.fs:523-524`), and `lastResults` stores the most recent test-command results (`:3292`, updated by test/dispatch paths). Task-log assignment occurs in `saveTaskLog` (`:3678-3693`). The HTTP host binds and invokes the Flow entrypoint directly; it does not dispatch task or test commands, so these fields are not per-request sinks.
- The bound invocation copies `virtualFiles` into its trace and assigns the trace map back (`Runtime.fs:6444,6448`). The HTTP policy is initialized with `FileSystemMode.Virtual`, but the reachable `applications/campfire/http.flow` declares database/clock/random effects (including the dispatch declaration at `:288`) and has no filesystem operations. In this request path the map should therefore stay at its startup value rather than grow with requests.
- `applications/campfire/Http/Transport.fs:33-50` builds the cookie map locally and rejects cookie headers over 16 KiB. `:357-390` buffers a form body in a `use`-scoped `MemoryStream` capped at 65,537 bytes, and the route handler limits request headers to 32 KiB (`:402-418`). Parsed request values, response values, rendered HTML, cookie headers, and the task continuation are locals. `:401` creates one shared lock; `:426` runs the interpreter and renderer under it. That serializes this synchronous interpreter section but is not an accumulating application queue. Under overload, framework-managed in-flight requests may still hold transient request state.
- `applications/campfire/Http/ResponseRenderer.fs:21-104` renders from the supplied response value into a local `RenderedResponse`; there is no static response cache or response history. The reference host clears logging providers and registers routes once (`experiments/AgentLang.Campfire.HttpReference/Program.fs:140-142`), writes only startup/stop status lines (`:150-155`), and disposes the composed provider at shutdown (`:161-164`).

## GC evidence and limits

The current `experiments/AgentLang.Campfire.HttpReference/bin/Release/net9.0/ReferenceHost.runtimeconfig.json` declares `System.GC.Server: true`; the project is an ASP.NET Core Web SDK project (`ReferenceHost.fsproj`). If this is the exact runtime config used for the measured reference process, server GC makes a high-water working set or committed heap a reasonable possibility. The runtime config alone does not establish why memory grew, and the live process's exact loaded artifact was not verified here.

## Bounded follow-up

For a repeatable diagnosis, record at startup, at fixed request-count/time checkpoints, after the load generator has stopped, and after `StopAsync` drains requests:

- completed/in-flight request counts;
- `GC.GetTotalMemory(false)`, `GC.GetGCMemoryInfo().HeapSizeBytes`, `TotalCommittedBytes`, and `FragmentedBytes`;
- Gen 0/1/2 collection counts;
- process private bytes and working set.

Keep sampling in-process and low frequency; no per-request trace capture is needed. In a separate diagnostic run only, compare a post-drain forced full collection with the pre-collection heap and process figures. If live managed heap still rises across equal-sized runs after the same drain/collection point, inspect a managed heap/root snapshot in an authorized run; if managed live bytes are stable while RSS/private bytes remain high, investigate GC segment retention and native/framework allocations. Do not change GC mode or force collections in the performance run based on this source review alone.

# Campfire AOT export implementation notes

`Runtime.Engine.ExportVerifiedFlowEntryPoint` and `BindFlowEntryPoint` use the same private `prepareFlowEntryPoint` path. It preserves the existing entrypoint diagnostics and validates the committed dictionary entry, stable word identity, Flow source owner/name/revision/syntax version, closed exact signature, compiler-verified function name/revision, and one-instruction direct call target before returning the captured snapshot, compiler-minted body, and execution name.

Export returns the verified body without creating a trace, invoking providers, running attached tests, or changing the runtime snapshot. Binding still closes over the resolved snapshot and runs the body only when its returned handle is invoked. Exported bodies retain the verified program's original host-operation catalog, so native preflight continues to reject host operations.

`tests/AgentLang.Flow.Runtime.Tests/Program.fs` extends the existing entrypoint coverage with export guard diagnostics, compiler authority and exact call/source metadata, provider and dictionary stability, retained host contract/native rejection, and old/new exports across replacement. No build or test command was run in this implementation pass; the parent agent owns shared validation.

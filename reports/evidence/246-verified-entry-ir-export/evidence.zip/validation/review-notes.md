# Campfire AOT export review notes

## Findings

No correctness findings in the reviewed API or test changes.

`prepareFlowEntryPoint` remains the single shared authorization path for export and binding. It keeps the entrypoint diagnostics and checks the committed Flow owner, stable identity, source name/revision/syntax metadata, closed signature, verified function identity/revision, and one direct call resolved to that same identity and revision. Null signature elements are rejected without formatting a null DU value. Export returns the compiler-minted body; binding still closes over the captured runtime snapshot and executes only from its invocation closure.

The Flow runtime assertions inspect the returned body and its verified program, check the exact call name/identity/revision and detached Flow source span, compare the pre/post dictionary description, check provider and test-provider counters, verify the retained host operation catalog, and assert native host-operation preflight still reports `IR_NATIVE_HOST_OPERATION_UNSUPPORTED`. The old exported body is checked after replacement alongside a newly exported revision.

The AOT test compiles a pure nominal scalar/record Flow export with the owning stack backend at O0 and O2, executes representative values, and compares the results to explicit expected values and the existing interpreter binding. The actual Campfire test exports `campfire.http.dispatch` from the application Engine, checks the full retained host catalog and a concrete database-read contract, then checks native compilation is rejected without an artifact or provider execution. It does not claim native execution of the Campfire endpoint.

Review was read-only; no build or test command was run here.

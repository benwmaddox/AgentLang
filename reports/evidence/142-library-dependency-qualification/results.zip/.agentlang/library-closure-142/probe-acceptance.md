# Bounded diagnostic-recovery probe

This is one guided language-only adoption observation, not a comparison with F#.
The participant receives probe-task.md plus the standard current-syntax broker
instructions. It receives no coordinator control result or recovery recipe.
Freeze the full prompt, starting inventory, scorer and runtime hashes before
dispatch. Do not change acceptance after dispatch.

After the participant closes:

1. Reload its saved project in a fresh pinned CLI; both `discount.rate` and
   `discount.internal-rate` must be persistent libraries with their original
   identities, Bool->Int signatures and pure effects.
2. The public function must still directly call the original helper; both
   definitions and all three inherited tests remain. Additional tests are allowed.
3. Evaluate each function on true and false, independently expecting 10 and 0.
   Run all attached tests and inspect current complete coverage for both owners
   in the same process. Qualification must not be inferred from an agent claim.
4. In a disposable copy, stage a helper with the same signature and branch shape
   but return 99 instead of 0 on false. Run only that helper's attached tests.
   At least one assertion must fail because of the wrong false result, not a
   protocol/parse/compile error. Before dispatch, verify that the seed helper's
   test passes this mutant and that the correct completed control rejects it.
5. Retain task.commit, host.close, terminal exit codes, raw exchanges and errors
   separately from behavior/qualification/regression-protection outcomes.

Before dispatch, require the focused runtime suite, LLVM suite and every
scorer/control requirement above to pass. The historical business-policy
preflight may finish concurrently against the same unchanged runtime sources;
all local gates must pass before publication. This scheduling change was made
before freezing or dispatching a participant, to avoid serializing an unrelated
large preflight with this small probe. It does not change participant acceptance.

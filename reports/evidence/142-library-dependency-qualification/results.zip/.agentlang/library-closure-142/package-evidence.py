#!/usr/bin/env python3
"""Build and verify the milestone 142 evidence archive and its SHA-256 index."""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


EVIDENCE_REL = Path(".agentlang/library-closure-142")
OUTPUT_REL = Path("reports/evidence/142-library-dependency-qualification")

SOURCE_SNAPSHOTS = (
    "src/AgentLang.Core/Runtime.fs",
    "src/AgentLang.Core/AuthoringHelp.fs",
    "tests/AgentLang.Flow.Runtime.Tests/Program.fs",
    "tests/AgentLang.Acceptance/Program.fs",
    "docs/LIBRARY-CLOSURE-VALIDATION.md",
)

# These are the V2 subagent broker files named by the frozen dispatch and its
# final host/termination audits.
BROKER_SCRIPTS = (
    "scripts/Start-SubagentTrialHostV2.ps1",
    "scripts/Verify-SubagentTrialHostV2.ps1",
    "scripts/Audit-SubagentTrialTerminationV2.ps1",
)

EXCLUDED_DIRECTORY_NAMES = {
    "root-cli-artifacts",
    "artifacts",
    "bin",
    "obj",
    "tmp",
    "temp",
    "__pycache__",
}
EXCLUDED_SUFFIXES = {
    ".a",
    ".bin",
    ".class",
    ".dylib",
    ".dll",
    ".exe",
    ".o",
    ".obj",
    ".pdb",
    ".pyc",
    ".pyo",
    ".so",
}
SENSITIVE_NAME_PARTS = {
    "credential",
    "credentials",
    "secret",
    "secrets",
    "token",
    "tokens",
}
SENSITIVE_SUFFIXES = {".key", ".pem", ".p12", ".pfx"}
SECRET_VALUE_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    re.compile(rb"\bxox[baprs]-[A-Za-z0-9-]{20,}\b"),
    re.compile(rb"\bsk-[A-Za-z0-9_-]{24,}\b"),
)


@dataclass(frozen=True)
class ArchiveEntry:
    member: str
    source: Path
    data: bytes


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    byte_length = 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            byte_length += len(chunk)
            digest.update(chunk)
    return byte_length, digest.hexdigest()


def is_sensitive_name(name: str) -> bool:
    lowered = name.casefold()
    stem = Path(lowered).stem
    name_parts = set(re.split(r"[^a-z0-9]+", stem))
    return (
        lowered.startswith(".env")
        or bool(name_parts & SENSITIVE_NAME_PARTS)
        or Path(lowered).suffix in SENSITIVE_SUFFIXES
        or lowered in {"id_rsa", "id_ed25519", "known_hosts", "netrc"}
    )


def excluded_file(relative: Path) -> bool:
    if any(part.casefold() in EXCLUDED_DIRECTORY_NAMES for part in relative.parts[:-1]):
        return True
    if relative.name.casefold() == "write.lock" or is_sensitive_name(relative.name):
        return True
    return relative.suffix.casefold() in EXCLUDED_SUFFIXES


def evidence_files(evidence_root: Path) -> list[Path]:
    """Collect evidence files while pruning known temporary/runtime trees."""
    found: list[Path] = []
    for current, directories, files in os.walk(evidence_root, topdown=True, followlinks=False):
        current_path = Path(current)
        directories[:] = sorted(
            name
            for name in directories
            if name.casefold() not in EXCLUDED_DIRECTORY_NAMES
            and not (current_path / name).is_symlink()
        )
        for name in sorted(files):
            path = current_path / name
            relative = path.relative_to(evidence_root)
            if path.is_symlink():
                raise RuntimeError(f"Refusing evidence symlink: {relative.as_posix()}")
            if not excluded_file(relative):
                found.append(path)
    return found


def validate_required_inputs(repo_root: Path, evidence_root: Path) -> None:
    required = (
        evidence_root / "full-validation.json",
        evidence_root / "final-validation-audit.json",
        evidence_root / "participant-audit.json",
        evidence_root / "participant/termination-audit.txt",
        evidence_root / "participant/actor.trace.jsonl",
        evidence_root / "participant/project/.agentlang/store/CURRENT",
        evidence_root / "probe-seed/project/.agentlang/store/CURRENT",
        evidence_root / "freeze.json",
        evidence_root / "dispatch.json",
        evidence_root / "participant.prompt.md",
        evidence_root / "score-probe.py",
        evidence_root / "package-evidence.py",
    )
    required += tuple(repo_root / source for source in SOURCE_SNAPSHOTS)
    required += tuple(repo_root / source for source in BROKER_SCRIPTS)

    missing = [path for path in required if not path.is_file()]
    if missing:
        formatted = "\n  ".join(path.as_posix() for path in missing)
        raise RuntimeError(f"Required evidence input(s) are missing:\n  {formatted}")

    for project_root in (
        evidence_root / "participant/project/.agentlang/store",
        evidence_root / "probe-seed/project/.agentlang/store",
    ):
        for folder, suffix in (("manifests", ".json"), ("objects", ".agent")):
            contents = project_root / folder
            if not contents.is_dir() or not any(contents.glob(f"*{suffix}")):
                raise RuntimeError(f"Durable project store is incomplete: {contents}")


def build_entry(member: str, source: Path) -> ArchiveEntry:
    data = source.read_bytes()
    if b"\x00" in data:
        raise RuntimeError(f"Refusing binary evidence file: {member}")
    if any(pattern.search(data) for pattern in SECRET_VALUE_PATTERNS):
        raise RuntimeError(f"Credential-like value found in evidence file: {member}")
    return ArchiveEntry(member=member, source=source, data=data)


def collect_entries(repo_root: Path, evidence_root: Path) -> list[ArchiveEntry]:
    sources: dict[str, Path] = {}

    for path in evidence_files(evidence_root):
        member = path.relative_to(repo_root).as_posix()
        sources[member] = path

    for relative in (*SOURCE_SNAPSHOTS, *BROKER_SCRIPTS):
        source = repo_root / relative
        sources[Path(relative).as_posix()] = source

    if len(sources) != len(set(sources)):
        raise RuntimeError("Archive member path collision")

    return [build_entry(member, sources[member]) for member in sorted(sources)]


def write_archive(path: Path, entries: list[ArchiveEntry]) -> None:
    # Fixed timestamps, permissions, ordering, and compression settings make
    # the ZIP stable for identical input bytes and Python/zlib versions.
    archive: zipfile.ZipFile | None = None
    try:
        archive = zipfile.ZipFile(
            path,
            mode="x",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
            strict_timestamps=True,
        )
        with archive:
            archive.comment = b""
            for entry in entries:
                info = zipfile.ZipInfo(entry.member, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                info.flag_bits = 0
                archive.writestr(info, entry.data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    except Exception:
        # If exclusive creation succeeded but writing/closing failed, remove
        # the incomplete archive. If the path already existed, do not touch it.
        if archive is not None:
            path.unlink(missing_ok=True)
        raise


def make_index(archive_path: Path, entries: list[ArchiveEntry]) -> dict[str, object]:
    archive_bytes, archive_digest = sha256_file(archive_path)
    return {
        "schemaVersion": 1,
        "archive": {
            "file": archive_path.name,
            "byteLength": archive_bytes,
            "sha256": archive_digest,
        },
        "entries": [
            {
                "path": entry.member,
                "byteLength": len(entry.data),
                "sha256": sha256(entry.data),
            }
            for entry in entries
        ],
        "exclusions": {
            "directoryNames": sorted(EXCLUDED_DIRECTORY_NAMES),
            "fileNames": ["write.lock", "credential-named files", ".env files"],
            "fileSuffixes": sorted(EXCLUDED_SUFFIXES | SENSITIVE_SUFFIXES),
        },
    }


def verify_outputs(archive_path: Path, index_path: Path) -> None:
    index = json.loads(index_path.read_text(encoding="utf-8"))
    archive_record = index["archive"]
    archive_bytes, archive_digest = sha256_file(archive_path)
    if archive_record["file"] != archive_path.name:
        raise RuntimeError("Index archive filename does not match output")
    if archive_record["byteLength"] != archive_bytes or archive_record["sha256"] != archive_digest:
        raise RuntimeError("Archive bytes do not match the index archive hash")

    index_entries = index["entries"]
    expected = {entry["path"]: entry for entry in index_entries}
    if len(expected) != len(index_entries):
        raise RuntimeError("Index contains duplicate ZIP member paths")
    with zipfile.ZipFile(archive_path, mode="r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise RuntimeError("ZIP member list does not match the index")
        bad_member = archive.testzip()
        if bad_member is not None:
            raise RuntimeError(f"ZIP CRC check failed for {bad_member}")
        for member in sorted(names):
            data = archive.read(member)
            record = expected[member]
            if len(data) != record["byteLength"] or sha256(data) != record["sha256"]:
                raise RuntimeError(f"ZIP member bytes do not match the index: {member}")


def main() -> int:
    repo_root = Path(__file__).resolve().parents[2]
    evidence_root = repo_root / EVIDENCE_REL
    output_dir = repo_root / OUTPUT_REL
    archive_path = output_dir / "results.zip"
    index_path = output_dir / "results-index.json"

    for output in (archive_path, index_path):
        if output.exists() or output.is_symlink():
            raise RuntimeError(f"Refusing to overwrite existing output: {output}")

    validate_required_inputs(repo_root, evidence_root)
    entries = collect_entries(repo_root, evidence_root)
    if not entries:
        raise RuntimeError("No evidence files were selected")

    output_dir.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []
    try:
        write_archive(archive_path, entries)
        created.append(archive_path)
        index = make_index(archive_path, entries)
        index_bytes = (json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
        with index_path.open("xb") as stream:
            created.append(index_path)
            stream.write(index_bytes)
        verify_outputs(archive_path, index_path)
    except Exception:
        for output in reversed(created):
            output.unlink(missing_ok=True)
        raise

    archive_bytes, archive_digest = sha256_file(archive_path)
    print(f"Created {archive_path.relative_to(repo_root).as_posix()}")
    print(f"Created {index_path.relative_to(repo_root).as_posix()}")
    print(f"Entries: {len(entries)}; ZIP bytes: {archive_bytes}; SHA-256: {archive_digest}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, zipfile.BadZipFile, json.JSONDecodeError) as error:
        print(f"package-evidence: {error}", file=sys.stderr)
        raise SystemExit(1)

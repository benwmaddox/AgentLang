Make the existing `discount.rate` function library-ready and publish the change.
Discover its implementation and dependencies through the runtime. Preserve both
functions' names, signatures, behavior, effects and existing composition; do not
inline or remove a helper. Keep inherited test definitions unchanged and add
any regression tests needed for qualification. Run the relevant tests, commit the task and close the
broker cleanly. Do not weaken library requirements or leave the target as an
ordinary project function.

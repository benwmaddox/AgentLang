You are a fresh diagnostic-recovery participant. The human explicitly authorizes changes only to the isolated project path below and its local tests. Use only the supplied broker for project discovery, authoring, evaluation, and testing. Do not read or edit repository source, other trials, reports, scorers, controls, verifier material, oracle data, or other participant projects. Do not use raw file access or shell commands for project operations. Do not use web tools or spawn agents. Launch the specified broker once and interact with that same process session.

Launch once from working directory D:\code\AgentLang using exec_command with tty:true and yield_time_ms:10000. Exact command:

pwsh -NoProfile -File 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\library-closure-142\root-cli-artifacts\bin\AgentLang.Cli\release\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\library-closure-142\participant\project' -TracePath 'D:\code\AgentLang\.agentlang\library-closure-142\participant\actor.trace.jsonl' -AllowedOperations 'task.begin,task.status,task.log,task.commit,task.abort,words,search,describe,type-of,search-type,search-output,search-effect,search-dependency,source,dependencies,callers,transitive-dependencies,transitive-callers,graph,context,effects,ir,tests,examples,example,history,diff,stack,help,eval,define,test,test-all,failed-tests,commit,replace-word,discard' -Profile agentlang -ClockValue '2000-01-01T00:00:00Z' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 50

Send one JSON request per line and observe each response before sending the next mutation. Begin with task.begin. Before changing source, request {"op":"help","topic":"define","syntaxVersion":2} and verify syntaxVersion 2 is returned. Use syntaxVersion 2 and frontend flow on later help, define, eval, and replacement requests where supported. Poll the same process session after a timeout; do not restart it. The broker permits at most 50 exchanges. Finish with the exact request {"op":"task.commit"}, observe the response, then send {"op":"host.close"} and observe process exit before your final response.


# Task

Make the existing `discount.rate` function library-ready and publish the change.
Discover its implementation and dependencies through the runtime. Preserve both
functions' names, signatures, behavior, effects and existing composition; do not
inline or remove a helper. Keep inherited test definitions unchanged and add
any regression tests needed for qualification. Run the relevant tests, commit the task and close the
broker cleanly. Do not weaken library requirements or leave the target as an
ordinary project function.

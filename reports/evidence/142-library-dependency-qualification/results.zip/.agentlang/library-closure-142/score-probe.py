#!/usr/bin/env python3
"""Score the saved Flow library-closure probe without modifying its candidate."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

NAMES = ("discount.rate", "discount.internal-rate")
MUTANT = '''fn discount.internal-rate(premium: Bool) -> Int {
    doc "Mutation probe: wrong rate for a non-premium customer."

    if premium { 10 } else { 99 }
}'''


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def inventory(root: Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for directory, dirs, files in os.walk(root):
        dirs[:] = sorted(name for name in dirs if name.casefold() not in {"bin", "obj"})
        for filename in sorted(files):
            if filename.casefold() == "write.lock":
                continue
            path = Path(directory) / filename
            hashes[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(sorted(hashes.items()))


def manifest(project: Path) -> dict:
    store = project / ".agentlang" / "store"
    pointer = json.loads((store / "CURRENT").read_text(encoding="utf-8"))
    digest = pointer.get("manifestHash")
    if not isinstance(digest, str):
        raise ValueError(f"Invalid CURRENT pointer: {project}")
    content = (store / "manifests" / f"{digest}.json").read_bytes()
    if hashlib.sha256(content).hexdigest() != digest:
        raise ValueError(f"Manifest hash mismatch: {project}")
    return json.loads(content)


def word_revision(data: dict, name: str) -> tuple[dict, dict]:
    word = next((w for w in data["words"] if w.get("currentName") == name), None)
    if word is None:
        raise ValueError(f"Missing manifest word: {name}")
    revision = next(
        (r for r in data["revisions"] if r.get("wordId") == word["wordId"]
         and r.get("revision") == word["currentRevision"]),
        None,
    )
    if revision is None:
        raise ValueError(f"Missing current manifest revision: {name}")
    return word, revision


def preserved(seed: Path, project: Path) -> dict:
    before, after = manifest(seed), manifest(project)
    words: dict[str, dict] = {}
    passed = True
    for name in NAMES:
        old_word, old_rev = word_revision(before, name)
        new_word, new_rev = word_revision(after, name)
        old_tests = {t["hash"] for t in old_rev.get("tests", []) if t.get("kind") == "test-definition"}
        new_tests = {t["hash"] for t in new_rev.get("tests", []) if t.get("kind") == "test-definition"}
        same_id, kept_tests = old_word["wordId"] == new_word["wordId"], old_tests <= new_tests
        words[name] = {
            "passed": same_id and kept_tests,
            "wordId": new_word["wordId"],
            "seedWordId": old_word["wordId"],
            "currentRevision": new_word["currentRevision"],
            "inheritedTestHashes": sorted(old_tests),
            "inheritedTestsPreserved": kept_tests,
        }
        passed &= same_id and kept_tests
    return {"passed": passed, "words": words}


def run_session(name: str, cli: Path, project: Path, requests: list[dict], out: Path) -> dict:
    folder = out / name
    folder.mkdir(parents=True, exist_ok=False)
    payload = b"".join(
        (json.dumps(request, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        for request in requests
    )
    (folder / "requests.jsonl").write_bytes(payload)
    command = ["dotnet", str(cli), "--project", str(project), "--jsonl"]
    stdout = stderr = b""
    code, timed_out, error = None, False, None
    try:
        run = subprocess.run(command, input=payload, cwd=project, capture_output=True, timeout=180, check=False)
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, timed_out = exc.stdout or b"", exc.stderr or b"", True
    except OSError as exc:
        error, stderr = str(exc), (str(exc) + "\n").encode("utf-8", errors="replace")
    (folder / "stdout.txt").write_bytes(stdout)
    (folder / "raw-responses.jsonl").write_bytes(stdout)
    (folder / "stderr.txt").write_bytes(stderr)
    (folder / "exit-code.txt").write_text("null\n" if code is None else f"{code}\n", encoding="utf-8")
    responses, parse_errors = [], []
    for number, line in enumerate(stdout.splitlines(), 1):
        if not line.strip():
            continue
        try:
            response = json.loads(line.decode("utf-8"))
            if not isinstance(response, dict):
                raise ValueError("response is not an object")
            responses.append(response)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            parse_errors.append(f"line {number}: {exc}")
    completed = code == 0 and not timed_out and error is None and not parse_errors and len(responses) == len(requests)
    process = {
        "command": command, "project": str(project), "requestCount": len(requests),
        "responseCount": len(responses), "exitCode": code, "timedOut": timed_out,
        "error": error, "parseErrors": parse_errors, "completed": completed,
    }
    dump(folder / "process.json", process)
    return {**process, "responses": responses}


def ok(response: dict | None, kind: str) -> bool:
    return bool(response and response.get("ok") is True and response.get("kind") == kind)


def describe(response: dict | None, name: str) -> dict:
    if not ok(response, "describe"):
        return {"passed": False, "reason": "describe response missing or unsuccessful"}
    data = response.get("data") or {}
    coverage = data.get("coverage") or {}
    finite = coverage.get("finiteCoverage") or {}
    full = (
        coverage.get("status") == "current"
        and isinstance(coverage.get("instructionsTotal"), int)
        and coverage["instructionsTotal"] > 0
        and coverage.get("instructionsCovered") == coverage.get("instructionsTotal")
        and coverage.get("branchesCovered") == coverage.get("branchesTotal")
        and finite.get("complete") is True
    )
    signature = data.get("inputs") == ["Bool"] and data.get("outputs") == ["Int"]
    dependency = name != "discount.rate" or "discount.internal-rate" in data.get("dependencies", [])
    persistent_library = data.get("status") == "persistent" and data.get("maturity") == "library"
    pure = data.get("effects") == []
    return {
        "passed": full and signature and dependency and persistent_library and pure,
        "signatureBoolToInt": signature, "pure": pure, "persistentLibrary": persistent_library,
        "coverageCompleteAndCurrent": full, "directHelperDependency": dependency,
        "id": data.get("id"), "revision": data.get("revision"),
        "dependencies": data.get("dependencies", []), "coverage": coverage,
    }


def test_all_passed(response: dict | None) -> bool:
    if not ok(response, "test"):
        return False
    results = (response.get("data") or {}).get("results")
    return isinstance(results, list) and bool(results) and all(r.get("passed") is True for r in results)


def mutation_caught(session: dict) -> dict:
    responses = session["responses"]
    define = responses[0] if len(responses) > 0 else None
    test = responses[1] if len(responses) > 1 else None
    rows = ((test or {}).get("data") or {}).get("results", [])
    hits = [
        row for row in rows if row.get("passed") is False
        and row.get("errorCode") == "TEST_ASSERTION_FAILED"
        and row.get("expected") == "0" and row.get("actual") == ["99"]
    ]
    return {
        "passed": session["completed"] and ok(define, "defined") and ok(test, "test") and bool(hits),
        "matchingAssertionFailures": hits,
    }


def request_list() -> list[dict]:
    requests = [{"op": "test-all"}]
    requests += [{"op": "describe", "word": name} for name in NAMES]
    for name, word in (("discount.rate", "discount::rate"), ("discount.internal-rate", "discount::internal-rate")):
        for value, expected in (("true", "10"), ("false", "0")):
            requests.append({
                "op": "eval", "frontend": "flow", "syntaxVersion": 2, "structured": True,
                "code": f"{word}({value})",
            })
    requests.append({"op": "task.status"})
    return requests


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", required=True, type=Path)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--seed", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    cli, project, seed = (p.expanduser().resolve() for p in (args.cli, args.project, args.seed))
    out = args.output_dir.expanduser().resolve()
    if not cli.is_file() or not project.is_dir() or not seed.is_dir():
        raise ValueError("--cli must be a file; --project and --seed must be directories")
    if out.exists():
        raise FileExistsError(f"Refusing existing output directory: {out}")
    for source in (project, seed):
        if os.path.normcase(os.path.commonpath((str(out), str(source)))) in {
            os.path.normcase(str(out)), os.path.normcase(str(source))
        }:
            raise ValueError("--output-dir must be separate from --project and --seed")
    if shutil.which("dotnet") is None:
        raise FileNotFoundError("dotnet executable is unavailable on PATH")
    out.mkdir(parents=True, exist_ok=False)

    before = inventory(project)
    candidate = run_session("candidate-session", cli, project, request_list(), out)
    responses = candidate["responses"]
    checks: dict[str, dict] = {
        "sessionCompleted": {"passed": candidate["completed"]},
        "testAll": {"passed": test_all_passed(responses[0] if len(responses) > 0 else None)},
        "discountRate": describe(responses[1] if len(responses) > 1 else None, "discount.rate"),
        "internalRate": describe(responses[2] if len(responses) > 2 else None, "discount.internal-rate"),
    }
    behavior = {}
    labels = (
        (3, "discount.rate(true)", "10"), (4, "discount.rate(false)", "0"),
        (5, "discount.internal-rate(true)", "10"), (6, "discount.internal-rate(false)", "0"),
    )
    for index, label, expected in labels:
        response = responses[index] if len(responses) > index else None
        stack = ((response or {}).get("data") or {}).get("stack")
        behavior[label] = {"passed": ok(response, "eval") and stack == [expected], "expected": [expected], "actual": stack}
    checks["behavior"] = {"passed": all(row["passed"] for row in behavior.values()), "cases": behavior}
    status = responses[7] if len(responses) > 7 else None
    status_data = (status or {}).get("data") or {}
    checks["noActiveTask"] = {"passed": ok(status, "task.status")
                              and status.get("text") == "No active task." and not status_data,
                              "text": (status or {}).get("text")}
    checks["identityAndInheritedTests"] = preserved(seed, project)

    mutant_project = out / "mutant" / "project"
    mutant_project.parent.mkdir(parents=True, exist_ok=False)
    shutil.copytree(project, mutant_project, ignore=lambda _dir, names: {
        name for name in names if name.casefold() in {"bin", "obj"}
    })
    revision = checks["internalRate"].get("revision")
    if not isinstance(revision, int):
        helper, _ = word_revision(manifest(project), "discount.internal-rate")
        revision = helper["currentRevision"]
    mutation = run_session("mutation-probe", cli, mutant_project, [
        {"op": "define", "source": MUTANT, "replace": True, "expectedRevision": revision,
         "syntaxVersion": 2, "frontend": "flow"},
        {"op": "test", "word": "discount.internal-rate"},
    ], out)
    checks["mutationRegressionProtection"] = mutation_caught(mutation)

    after = inventory(project)
    checks["originalProjectUnchanged"] = {
        "passed": before == after, "beforeFiles": len(before), "afterFiles": len(after),
        "changedPaths": sorted(path for path in set(before) | set(after) if before.get(path) != after.get(path)),
    }
    accepted = candidate["completed"] and mutation["completed"] and all(c.get("passed") is True for c in checks.values())
    result = {
        "schemaVersion": 1, "cli": str(cli), "project": str(project), "seed": str(seed),
        "candidateSession": {k: v for k, v in candidate.items() if k != "responses"},
        "mutationSession": {k: v for k, v in mutation.items() if k != "responses"},
        "checks": checks, "accepted": accepted,
    }
    dump(out / "result.json", result)
    print(json.dumps({"accepted": accepted, "checks": {k: v.get("passed") for k, v in checks.items()}, "result": str(out / "result.json")}, ensure_ascii=False))
    return 0 if accepted else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"score-probe.py: {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)

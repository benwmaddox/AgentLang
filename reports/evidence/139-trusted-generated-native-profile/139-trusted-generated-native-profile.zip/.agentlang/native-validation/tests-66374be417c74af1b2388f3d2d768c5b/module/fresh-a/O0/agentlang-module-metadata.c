#include <stddef.h>
#include <stdint.h>
#include "module_abi.h"

extern void agentlang_entry_000_execute(al_runtime_context *ctx, int64_t *outputs, uint32_t capacity, int32_t *status);
extern void agentlang_entry_001_execute(al_runtime_context *ctx, int64_t *outputs, uint32_t capacity, int32_t *status);
extern void agentlang_entry_002_execute(al_runtime_context *ctx, int64_t *outputs, uint32_t capacity, int32_t *status);

static const uint32_t module_type_fields_3[] = { 0u, 1u };
static const al_type_desc module_types[4] = {
  { 1u, 0u, NULL },
  { 2u, 0u, NULL },
  { 3u, 0u, NULL },
  { 4u, 2u, module_type_fields_3 },
};
static const al_program_desc module_program = { module_types, 4u, 0u };

static const char *const module_type_names[4] = {
  "Int",
  "Bool",
  "Unit",
  "NativePoint",
};

static const uint32_t module_entry_000_output_type_ids[1] = { 0u };
static const al_module_diagnostic module_entry_000_diagnostics[1] = {
  { 0, 1u, 1u, 1u, "RUNTIME_STEP_LIMIT", "A.begin", "module-begin.agent" },
};

static const uint32_t module_entry_001_input_type_ids[1] = { 0u };
static const uint32_t module_entry_001_output_type_ids[1] = { 0u };
static const al_module_diagnostic module_entry_001_diagnostics[4] = {
  { 0, 1u, 2u, 1u, "RUNTIME_STEP_LIMIT", "B.resume-\xE2""\x98""\x83""", "module-resume.agent" },
  { 1, 1u, 3u, 1u, "RUNTIME_STEP_LIMIT", "B.resume-\xE2""\x98""\x83""", "module-resume.agent" },
  { 2, 0u, 0u, 0u, "RUNTIME_CALL_DEPTH", "add", "" },
  { 3, 0u, 0u, 0u, "RUNTIME_OVERFLOW", "add", "" },
};

static const uint32_t module_entry_002_output_type_ids[1] = { 0u };
static const al_module_diagnostic module_entry_002_diagnostics[5] = {
  { 0, 1u, 1u, 1u, "RUNTIME_STEP_LIMIT", "C.failure", "failure-\xCE""\xBB"".agent" },
  { 1, 1u, 2u, 1u, "RUNTIME_STEP_LIMIT", "C.failure", "failure-\xCE""\xBB"".agent" },
  { 2, 1u, 3u, 1u, "RUNTIME_STEP_LIMIT", "C.failure", "failure-\xCE""\xBB"".agent" },
  { 3, 0u, 0u, 0u, "RUNTIME_CALL_DEPTH", "add", "" },
  { 4, 0u, 0u, 0u, "RUNTIME_OVERFLOW", "add", "" },
};

static const al_module_entry module_entries[3] = {
  { sizeof(al_module_entry), 0u, "A.begin", agentlang_entry_000_execute, 0u, 1u, 3u, 1u, NULL, module_entry_000_output_type_ids, module_entry_000_diagnostics },
  { sizeof(al_module_entry), 1u, "B.resume-\xE2""\x98""\x83""", agentlang_entry_001_execute, 1u, 1u, 3u, 4u, module_entry_001_input_type_ids, module_entry_001_output_type_ids, module_entry_001_diagnostics },
  { sizeof(al_module_entry), 2u, "C.failure", agentlang_entry_002_execute, 0u, 1u, 3u, 5u, NULL, module_entry_002_output_type_ids, module_entry_002_diagnostics },
};

static const al_module_desc module_descriptor = {
  AL_MODULE_ABI_VERSION,
  sizeof(al_module_desc),
  AL_RUNTIME_ABI_VERSION,
  3u,
  { 0xB7u, 0x15u, 0x80u, 0xF3u, 0xD6u, 0x8Fu, 0xBEu, 0x57u, 0x2Bu, 0x60u, 0xCDu, 0x84u, 0x35u, 0x21u, 0x9Eu, 0x82u, 0x2Bu, 0xF7u, 0x1Du, 0xC8u, 0x4Cu, 0xA2u, 0xB0u, 0x7Au, 0x29u, 0x46u, 0xC1u, 0x19u, 0xFCu, 0x6Eu, 0x64u, 0xA1u },
  &module_program,
  module_entries,
  module_type_names
};

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdll-attribute-on-redeclaration"
__declspec(dllexport) const al_module_desc *agentlang_module_descriptor(void) {
  return &module_descriptor;
}
#pragma clang diagnostic pop

%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 32
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  %stack.offset.24 = add i32 %argument.source, 24
  %stack.offset.25 = add i32 %context.value.15, 24
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 24, i32 24, i32 7, i32 8)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.25, i32 %stack.offset.24, i32 8, i32 8, i32 1, i32 8)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %frame.failure.0
runtime.continue.33:
  %step.status.34 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %step.ok.35 = icmp eq i32 %step.status.34, 0
  br i1 %step.ok.35, label %step.continue.36, label %frame.failure.0
step.continue.36:
  %stack.offset.37 = add i32 %context.value.15, 32
  %reserve.status.38 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 3)
  %reserve.ok.39 = icmp eq i32 %reserve.status.38, 0
  br i1 %reserve.ok.39, label %reserve.continue.40, label %frame.failure.0
reserve.continue.40:
  %callee.status.41 = call i32 @agentlang_word_0002(ptr %ctx, i32 %context.value.15, i32 %context.value.15, i32 4)
  %callee.ok.42 = icmp eq i32 %callee.status.41, 0
  br i1 %callee.ok.42, label %callee.returned.43, label %frame.failure.0
callee.returned.43:
  %stack.offset.44 = add i32 %context.value.15, 24
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.44, i32 0, i32 0, i32 0)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  %stack.offset.49 = add i32 %context.value.15, 24
  %cursor.check.50 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.49)
  %cursor.ok.51 = icmp eq i32 %cursor.check.50, 0
  br i1 %cursor.ok.51, label %cursor.continue.52, label %frame.failure.0
cursor.continue.52:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 24, i32 24, i32 7, i32 9)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %baseline.live.total.63 = add i32 %context.value.6, %context.value.8
  %current.live.total.64 = add i32 %context.value.58, %context.value.60
  %cleanup.live.delta.65 = sub i32 %baseline.live.total.63, %current.live.total.64
  %cleanup.local.delta.66 = sub i32 %context.value.8, %context.value.60
  %cleanup.reserved.delta.67 = sub i32 %context.value.62, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.65, i32 %cleanup.local.delta.66)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.67)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %frame.entered.26 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.27 = icmp eq i32 %frame.entered.26, 0
  br i1 %frame.entered.ok.27, label %frame.entered.continue.28, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.28:
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %stack.offset.31 = add i32 %context.value.30, 56
  %stack.offset.32 = add i32 %context.value.30, 64
  %reserve.status.33 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.32, i32 5)
  %reserve.ok.34 = icmp eq i32 %reserve.status.33, 0
  br i1 %reserve.ok.34, label %reserve.continue.35, label %frame.reserve.failure.1
reserve.continue.35:
  call void @al_owning_local_reserve(ptr %ctx, i32 56)
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %runtime.ok.38 = icmp eq i32 %context.value.37, 0
  br i1 %runtime.ok.38, label %runtime.continue.39, label %frame.failure.0
runtime.continue.39:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %runtime.ok.42 = icmp eq i32 %context.value.41, 0
  br i1 %runtime.ok.42, label %runtime.continue.43, label %frame.failure.0
runtime.continue.43:
  %step.status.44 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %step.ok.45 = icmp eq i32 %step.status.44, 0
  br i1 %step.ok.45, label %step.continue.46, label %frame.failure.0
step.continue.46:
  %local.is.active.47 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.48 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.49 = select i1 %local.is.active.47, i32 %local.previous.payload.48, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.30, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.49, i32 1)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %frame.failure.0
runtime.continue.57:
  %cursor.check.58 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.59 = icmp eq i32 %cursor.check.58, 0
  br i1 %cursor.ok.59, label %cursor.continue.60, label %frame.failure.0
cursor.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %step.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %step.ok.62, label %step.continue.63, label %frame.failure.0
step.continue.63:
  %stack.offset.64 = add i32 %stack.offset.31, 8
  %reserve.status.65 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.64, i32 8)
  %reserve.ok.66 = icmp eq i32 %reserve.status.65, 0
  br i1 %reserve.ok.66, label %reserve.continue.67, label %frame.failure.0
reserve.continue.67:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %context.value.30, i32 8, i32 8, i32 1)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %stack.offset.72 = add i32 %stack.offset.31, 8
  %cursor.check.73 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.72)
  %cursor.ok.74 = icmp eq i32 %cursor.check.73, 0
  br i1 %cursor.ok.74, label %cursor.continue.75, label %frame.failure.0
cursor.continue.75:
  %step.status.76 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %step.ok.77 = icmp eq i32 %step.status.76, 0
  br i1 %step.ok.77, label %step.continue.78, label %frame.failure.0
step.continue.78:
  %stack.offset.79 = add i32 %stack.offset.31, 8
  %stack.offset.80 = add i32 %stack.offset.79, 8
  %reserve.status.81 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.80, i32 10)
  %reserve.ok.82 = icmp eq i32 %reserve.status.81, 0
  br i1 %reserve.ok.82, label %reserve.continue.83, label %frame.failure.0
reserve.continue.83:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.79, i32 %context.value.30, i32 8, i32 8, i32 1)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %stack.offset.88 = add i32 %stack.offset.31, 16
  %cursor.check.89 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.88)
  %cursor.ok.90 = icmp eq i32 %cursor.check.89, 0
  br i1 %cursor.ok.90, label %cursor.continue.91, label %frame.failure.0
cursor.continue.91:
  %step.status.92 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %step.ok.93 = icmp eq i32 %step.status.92, 0
  br i1 %step.ok.93, label %step.continue.94, label %frame.failure.0
step.continue.94:
  %stack.offset.95 = add i32 %stack.offset.31, 16
  %stack.offset.96 = add i32 %stack.offset.95, 8
  %reserve.status.97 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.96, i32 12)
  %reserve.ok.98 = icmp eq i32 %reserve.status.97, 0
  br i1 %reserve.ok.98, label %reserve.continue.99, label %frame.failure.0
reserve.continue.99:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.95, i64 100, i32 1)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %stack.offset.108 = add i32 %stack.offset.31, 24
  %cursor.check.109 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.108)
  %cursor.ok.110 = icmp eq i32 %cursor.check.109, 0
  br i1 %cursor.ok.110, label %cursor.continue.111, label %frame.failure.0
cursor.continue.111:
  %step.status.112 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %step.ok.113 = icmp eq i32 %step.status.112, 0
  br i1 %step.ok.113, label %step.continue.114, label %frame.failure.0
step.continue.114:
  %stack.offset.115 = add i32 %stack.offset.31, 8
  %stack.offset.116 = add i32 %stack.offset.31, 16
  %integer.left.117 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.115)
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %runtime.ok.121 = icmp eq i32 %context.value.120, 0
  br i1 %runtime.ok.121, label %runtime.continue.122, label %frame.failure.0
runtime.continue.122:
  %integer.right.118 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.116)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %integer.checked.127 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.117, i64 %integer.right.118)
  %integer.result.128 = extractvalue { i64, i1 } %integer.checked.127, 0
  %integer.overflow.129 = extractvalue { i64, i1 } %integer.checked.127, 1
  br i1 %integer.overflow.129, label %integer.overflow.failure.131, label %integer.nooverflow.130
integer.overflow.failure.131:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.130:
  %stack.offset.132 = add i32 %stack.offset.31, 8
  %stack.offset.133 = add i32 %stack.offset.31, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.133, i32 8, i32 8, i32 1)
  %context.field.134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.135 = load i32, ptr %context.field.134, align 4
  %runtime.ok.136 = icmp eq i32 %context.value.135, 0
  br i1 %runtime.ok.136, label %runtime.continue.137, label %frame.failure.0
runtime.continue.137:
  %stack.offset.138 = add i32 %stack.offset.31, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.138, i32 8, i32 8, i32 1)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %frame.failure.0
runtime.continue.142:
  %stack.offset.143 = add i32 %stack.offset.132, 8
  %reserve.status.144 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.143, i32 15)
  %reserve.ok.145 = icmp eq i32 %reserve.status.144, 0
  br i1 %reserve.ok.145, label %reserve.continue.146, label %frame.failure.0
reserve.continue.146:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.132, i64 %integer.result.128, i32 1)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  %stack.offset.155 = add i32 %stack.offset.31, 16
  %cursor.check.156 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.155)
  %cursor.ok.157 = icmp eq i32 %cursor.check.156, 0
  br i1 %cursor.ok.157, label %cursor.continue.158, label %frame.failure.0
cursor.continue.158:
  %step.status.159 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %step.ok.160 = icmp eq i32 %step.status.159, 0
  br i1 %step.ok.160, label %step.continue.161, label %frame.failure.0
step.continue.161:
  %stack.offset.162 = add i32 %stack.offset.31, 16
  %reserve.status.163 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.162, i32 17)
  %reserve.ok.164 = icmp eq i32 %reserve.status.163, 0
  br i1 %reserve.ok.164, label %reserve.continue.165, label %frame.failure.0
reserve.continue.165:
  %callee.status.166 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 18)
  %callee.ok.167 = icmp eq i32 %callee.status.166, 0
  br i1 %callee.ok.167, label %callee.returned.168, label %frame.failure.0
callee.returned.168:
  %stack.offset.169 = add i32 %stack.offset.31, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.169, i32 0, i32 0, i32 0)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 %stack.offset.31, 16
  %cursor.check.175 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.174)
  %cursor.ok.176 = icmp eq i32 %cursor.check.175, 0
  br i1 %cursor.ok.176, label %cursor.continue.177, label %frame.failure.0
cursor.continue.177:
  %step.status.178 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %step.ok.179 = icmp eq i32 %step.status.178, 0
  br i1 %step.ok.179, label %step.continue.180, label %frame.failure.0
step.continue.180:
  %stack.offset.181 = add i32 %stack.offset.31, 16
  %stack.offset.182 = add i32 %stack.offset.181, 16
  %reserve.status.183 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.182, i32 20)
  %reserve.ok.184 = icmp eq i32 %reserve.status.183, 0
  br i1 %reserve.ok.184, label %reserve.continue.185, label %frame.failure.0
reserve.continue.185:
  call void @al_owning_duplicate(ptr %ctx, i32 %stack.offset.181, i32 %stack.offset.31, i32 16, i32 16, i32 5)
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %runtime.ok.188 = icmp eq i32 %context.value.187, 0
  br i1 %runtime.ok.188, label %runtime.continue.189, label %frame.failure.0
runtime.continue.189:
  %stack.offset.190 = add i32 %stack.offset.31, 32
  %cursor.check.191 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.190)
  %cursor.ok.192 = icmp eq i32 %cursor.check.191, 0
  br i1 %cursor.ok.192, label %cursor.continue.193, label %frame.failure.0
cursor.continue.193:
  %step.status.194 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %step.ok.195 = icmp eq i32 %step.status.194, 0
  br i1 %step.ok.195, label %step.continue.196, label %frame.failure.0
step.continue.196:
  %local.is.active.197 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.198 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.199 = select i1 %local.is.active.197, i32 %local.previous.payload.198, i32 0
  %stack.offset.200 = add i32 %context.value.30, 8
  %stack.offset.201 = add i32 %stack.offset.31, 16
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.200, i32 %stack.offset.201, i32 16, i32 16, i32 16, i32 %local.old.payload.199, i32 5)
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %runtime.ok.204 = icmp eq i32 %context.value.203, 0
  br i1 %runtime.ok.204, label %runtime.continue.205, label %frame.failure.0
runtime.continue.205:
  store i1 true, ptr %local.active.6, align 1
  store i32 16, ptr %local.payload.7, align 4
  store i32 5, ptr %local.type.8, align 4
  %stack.offset.206 = add i32 %stack.offset.31, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.206, i32 16, i32 16, i32 5)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  %stack.offset.211 = add i32 %stack.offset.31, 16
  %cursor.check.212 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.211)
  %cursor.ok.213 = icmp eq i32 %cursor.check.212, 0
  br i1 %cursor.ok.213, label %cursor.continue.214, label %frame.failure.0
cursor.continue.214:
  %step.status.215 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %step.ok.216 = icmp eq i32 %step.status.215, 0
  br i1 %step.ok.216, label %step.continue.217, label %frame.failure.0
step.continue.217:
  %local.is.active.218 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.219 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.220 = select i1 %local.is.active.218, i32 %local.previous.payload.219, i32 0
  %stack.offset.221 = add i32 %context.value.30, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.221, i32 %stack.offset.31, i32 16, i32 16, i32 16, i32 %local.old.payload.220, i32 5)
  %context.field.222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.223 = load i32, ptr %context.field.222, align 4
  %runtime.ok.224 = icmp eq i32 %context.value.223, 0
  br i1 %runtime.ok.224, label %runtime.continue.225, label %frame.failure.0
runtime.continue.225:
  store i1 true, ptr %local.active.9, align 1
  store i32 16, ptr %local.payload.10, align 4
  store i32 5, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 16, i32 16, i32 5)
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %runtime.ok.228 = icmp eq i32 %context.value.227, 0
  br i1 %runtime.ok.228, label %runtime.continue.229, label %frame.failure.0
runtime.continue.229:
  %cursor.check.230 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.231 = icmp eq i32 %cursor.check.230, 0
  br i1 %cursor.ok.231, label %cursor.continue.232, label %frame.failure.0
cursor.continue.232:
  %step.status.233 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %step.ok.234 = icmp eq i32 %step.status.233, 0
  br i1 %step.ok.234, label %step.continue.235, label %frame.failure.0
step.continue.235:
  %stack.offset.236 = add i32 %stack.offset.31, 16
  %reserve.status.237 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.236, i32 24)
  %reserve.ok.238 = icmp eq i32 %reserve.status.237, 0
  br i1 %reserve.ok.238, label %reserve.continue.239, label %frame.failure.0
reserve.continue.239:
  %stack.offset.240 = add i32 %context.value.30, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.240, i32 16, i32 16, i32 5)
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %runtime.ok.243 = icmp eq i32 %context.value.242, 0
  br i1 %runtime.ok.243, label %runtime.continue.244, label %frame.failure.0
runtime.continue.244:
  %stack.offset.245 = add i32 %stack.offset.31, 16
  %cursor.check.246 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.245)
  %cursor.ok.247 = icmp eq i32 %cursor.check.246, 0
  br i1 %cursor.ok.247, label %cursor.continue.248, label %frame.failure.0
cursor.continue.248:
  %step.status.249 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %step.ok.250 = icmp eq i32 %step.status.249, 0
  br i1 %step.ok.250, label %step.continue.251, label %frame.failure.0
step.continue.251:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 6, i32 7)
  %context.field.252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.253 = load i32, ptr %context.field.252, align 4
  %runtime.ok.254 = icmp eq i32 %context.value.253, 0
  br i1 %runtime.ok.254, label %runtime.continue.255, label %frame.failure.0
runtime.continue.255:
  %stack.offset.256 = add i32 %stack.offset.31, 8
  %stack.offset.257 = add i32 %stack.offset.31, 16
  %field.grows.258 = icmp ugt i32 %stack.offset.256, %stack.offset.257
  br i1 %field.grows.258, label %field.reserve.259, label %field.release.260
field.reserve.259:
  %reserve.status.262 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.256, i32 26)
  %reserve.ok.263 = icmp eq i32 %reserve.status.262, 0
  br i1 %reserve.ok.263, label %reserve.continue.264, label %frame.failure.0
reserve.continue.264:
  br label %field.ready.261
field.release.260:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.256, i32 0, i32 6, i32 8)
  %context.field.265 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.266 = load i32, ptr %context.field.265, align 4
  %runtime.ok.267 = icmp eq i32 %context.value.266, 0
  br i1 %runtime.ok.267, label %runtime.continue.268, label %frame.failure.0
runtime.continue.268:
  br label %field.ready.261
field.ready.261:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.270 = load i32, ptr %context.field.269, align 4
  %runtime.ok.271 = icmp eq i32 %context.value.270, 0
  br i1 %runtime.ok.271, label %runtime.continue.272, label %frame.failure.0
runtime.continue.272:
  %stack.offset.273 = add i32 %stack.offset.31, 8
  %cursor.check.274 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.273)
  %cursor.ok.275 = icmp eq i32 %cursor.check.274, 0
  br i1 %cursor.ok.275, label %cursor.continue.276, label %frame.failure.0
cursor.continue.276:
  %step.status.277 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %step.ok.278 = icmp eq i32 %step.status.277, 0
  br i1 %step.ok.278, label %step.continue.279, label %frame.failure.0
step.continue.279:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 7)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %stack.offset.284 = add i32 %stack.offset.31, 8
  %stack.offset.285 = add i32 %stack.offset.31, 8
  %field.grows.286 = icmp ugt i32 %stack.offset.284, %stack.offset.285
  br i1 %field.grows.286, label %field.reserve.287, label %field.release.288
field.reserve.287:
  %reserve.status.290 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.284, i32 28)
  %reserve.ok.291 = icmp eq i32 %reserve.status.290, 0
  br i1 %reserve.ok.291, label %reserve.continue.292, label %frame.failure.0
reserve.continue.292:
  br label %field.ready.289
field.release.288:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.284, i32 0, i32 1, i32 8)
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %runtime.ok.295 = icmp eq i32 %context.value.294, 0
  br i1 %runtime.ok.295, label %runtime.continue.296, label %frame.failure.0
runtime.continue.296:
  br label %field.ready.289
field.ready.289:
  %stack.offset.297 = add i32 %stack.offset.31, 8
  %cursor.check.298 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.297)
  %cursor.ok.299 = icmp eq i32 %cursor.check.298, 0
  br i1 %cursor.ok.299, label %cursor.continue.300, label %frame.failure.0
cursor.continue.300:
  %step.status.301 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %step.ok.302 = icmp eq i32 %step.status.301, 0
  br i1 %step.ok.302, label %step.continue.303, label %frame.failure.0
step.continue.303:
  %local.is.active.304 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.305 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.306 = select i1 %local.is.active.304, i32 %local.previous.payload.305, i32 0
  %stack.offset.307 = add i32 %context.value.30, 40
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.307, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.306, i32 1)
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %runtime.ok.310 = icmp eq i32 %context.value.309, 0
  br i1 %runtime.ok.310, label %runtime.continue.311, label %frame.failure.0
runtime.continue.311:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.312 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.313 = load i32, ptr %context.field.312, align 4
  %runtime.ok.314 = icmp eq i32 %context.value.313, 0
  br i1 %runtime.ok.314, label %runtime.continue.315, label %frame.failure.0
runtime.continue.315:
  %cursor.check.316 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.317 = icmp eq i32 %cursor.check.316, 0
  br i1 %cursor.ok.317, label %cursor.continue.318, label %frame.failure.0
cursor.continue.318:
  %step.status.319 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %step.ok.320 = icmp eq i32 %step.status.319, 0
  br i1 %step.ok.320, label %step.continue.321, label %frame.failure.0
step.continue.321:
  %stack.offset.322 = add i32 %stack.offset.31, 16
  %reserve.status.323 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.322, i32 31)
  %reserve.ok.324 = icmp eq i32 %reserve.status.323, 0
  br i1 %reserve.ok.324, label %reserve.continue.325, label %frame.failure.0
reserve.continue.325:
  %stack.offset.326 = add i32 %context.value.30, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.326, i32 16, i32 16, i32 5)
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %runtime.ok.329 = icmp eq i32 %context.value.328, 0
  br i1 %runtime.ok.329, label %runtime.continue.330, label %frame.failure.0
runtime.continue.330:
  %stack.offset.331 = add i32 %stack.offset.31, 16
  %cursor.check.332 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.331)
  %cursor.ok.333 = icmp eq i32 %cursor.check.332, 0
  br i1 %cursor.ok.333, label %cursor.continue.334, label %frame.failure.0
cursor.continue.334:
  %step.status.335 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %step.ok.336 = icmp eq i32 %step.status.335, 0
  br i1 %step.ok.336, label %step.continue.337, label %frame.failure.0
step.continue.337:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 6, i32 7)
  %context.field.338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.339 = load i32, ptr %context.field.338, align 4
  %runtime.ok.340 = icmp eq i32 %context.value.339, 0
  br i1 %runtime.ok.340, label %runtime.continue.341, label %frame.failure.0
runtime.continue.341:
  %stack.offset.342 = add i32 %stack.offset.31, 8
  %stack.offset.343 = add i32 %stack.offset.31, 16
  %field.grows.344 = icmp ugt i32 %stack.offset.342, %stack.offset.343
  br i1 %field.grows.344, label %field.reserve.345, label %field.release.346
field.reserve.345:
  %reserve.status.348 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.342, i32 33)
  %reserve.ok.349 = icmp eq i32 %reserve.status.348, 0
  br i1 %reserve.ok.349, label %reserve.continue.350, label %frame.failure.0
reserve.continue.350:
  br label %field.ready.347
field.release.346:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.342, i32 0, i32 6, i32 8)
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %runtime.ok.353 = icmp eq i32 %context.value.352, 0
  br i1 %runtime.ok.353, label %runtime.continue.354, label %frame.failure.0
runtime.continue.354:
  br label %field.ready.347
field.ready.347:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %runtime.ok.357 = icmp eq i32 %context.value.356, 0
  br i1 %runtime.ok.357, label %runtime.continue.358, label %frame.failure.0
runtime.continue.358:
  %stack.offset.359 = add i32 %stack.offset.31, 8
  %cursor.check.360 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.359)
  %cursor.ok.361 = icmp eq i32 %cursor.check.360, 0
  br i1 %cursor.ok.361, label %cursor.continue.362, label %frame.failure.0
cursor.continue.362:
  %step.status.363 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %step.ok.364 = icmp eq i32 %step.status.363, 0
  br i1 %step.ok.364, label %step.continue.365, label %frame.failure.0
step.continue.365:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 7)
  %context.field.366 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.367 = load i32, ptr %context.field.366, align 4
  %runtime.ok.368 = icmp eq i32 %context.value.367, 0
  br i1 %runtime.ok.368, label %runtime.continue.369, label %frame.failure.0
runtime.continue.369:
  %stack.offset.370 = add i32 %stack.offset.31, 8
  %stack.offset.371 = add i32 %stack.offset.31, 8
  %field.grows.372 = icmp ugt i32 %stack.offset.370, %stack.offset.371
  br i1 %field.grows.372, label %field.reserve.373, label %field.release.374
field.reserve.373:
  %reserve.status.376 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.370, i32 35)
  %reserve.ok.377 = icmp eq i32 %reserve.status.376, 0
  br i1 %reserve.ok.377, label %reserve.continue.378, label %frame.failure.0
reserve.continue.378:
  br label %field.ready.375
field.release.374:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.370, i32 0, i32 1, i32 8)
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %runtime.ok.381 = icmp eq i32 %context.value.380, 0
  br i1 %runtime.ok.381, label %runtime.continue.382, label %frame.failure.0
runtime.continue.382:
  br label %field.ready.375
field.ready.375:
  %stack.offset.383 = add i32 %stack.offset.31, 8
  %cursor.check.384 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.383)
  %cursor.ok.385 = icmp eq i32 %cursor.check.384, 0
  br i1 %cursor.ok.385, label %cursor.continue.386, label %frame.failure.0
cursor.continue.386:
  %step.status.387 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %step.ok.388 = icmp eq i32 %step.status.387, 0
  br i1 %step.ok.388, label %step.continue.389, label %frame.failure.0
step.continue.389:
  %local.is.active.390 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.391 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.392 = select i1 %local.is.active.390, i32 %local.previous.payload.391, i32 0
  %stack.offset.393 = add i32 %context.value.30, 48
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.393, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.392, i32 1)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %runtime.ok.400 = icmp eq i32 %context.value.399, 0
  br i1 %runtime.ok.400, label %runtime.continue.401, label %frame.failure.0
runtime.continue.401:
  %cursor.check.402 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.403 = icmp eq i32 %cursor.check.402, 0
  br i1 %cursor.ok.403, label %cursor.continue.404, label %frame.failure.0
cursor.continue.404:
  %step.status.405 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %step.ok.406 = icmp eq i32 %step.status.405, 0
  br i1 %step.ok.406, label %step.continue.407, label %frame.failure.0
step.continue.407:
  %stack.offset.408 = add i32 %stack.offset.31, 8
  %reserve.status.409 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.408, i32 38)
  %reserve.ok.410 = icmp eq i32 %reserve.status.409, 0
  br i1 %reserve.ok.410, label %reserve.continue.411, label %frame.failure.0
reserve.continue.411:
  %stack.offset.412 = add i32 %context.value.30, 40
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.412, i32 8, i32 8, i32 1)
  %context.field.413 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.414 = load i32, ptr %context.field.413, align 4
  %runtime.ok.415 = icmp eq i32 %context.value.414, 0
  br i1 %runtime.ok.415, label %runtime.continue.416, label %frame.failure.0
runtime.continue.416:
  %stack.offset.417 = add i32 %stack.offset.31, 8
  %cursor.check.418 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.417)
  %cursor.ok.419 = icmp eq i32 %cursor.check.418, 0
  br i1 %cursor.ok.419, label %cursor.continue.420, label %frame.failure.0
cursor.continue.420:
  %step.status.421 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %step.ok.422 = icmp eq i32 %step.status.421, 0
  br i1 %step.ok.422, label %step.continue.423, label %frame.failure.0
step.continue.423:
  %stack.offset.424 = add i32 %stack.offset.31, 8
  %stack.offset.425 = add i32 %stack.offset.424, 8
  %reserve.status.426 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.425, i32 40)
  %reserve.ok.427 = icmp eq i32 %reserve.status.426, 0
  br i1 %reserve.ok.427, label %reserve.continue.428, label %frame.failure.0
reserve.continue.428:
  %stack.offset.429 = add i32 %context.value.30, 48
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.424, i32 %stack.offset.429, i32 8, i32 8, i32 1)
  %context.field.430 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.431 = load i32, ptr %context.field.430, align 4
  %runtime.ok.432 = icmp eq i32 %context.value.431, 0
  br i1 %runtime.ok.432, label %runtime.continue.433, label %frame.failure.0
runtime.continue.433:
  %stack.offset.434 = add i32 %stack.offset.31, 16
  %cursor.check.435 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.434)
  %cursor.ok.436 = icmp eq i32 %cursor.check.435, 0
  br i1 %cursor.ok.436, label %cursor.continue.437, label %frame.failure.0
cursor.continue.437:
  %step.status.438 = call i32 @al_owning_charge_step(ptr %ctx, i32 41)
  %step.ok.439 = icmp eq i32 %step.status.438, 0
  br i1 %step.ok.439, label %step.continue.440, label %frame.failure.0
step.continue.440:
  %stack.offset.441 = add i32 %stack.offset.31, 8
  %integer.left.442 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.31)
  %context.field.444 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.445 = load i32, ptr %context.field.444, align 4
  %runtime.ok.446 = icmp eq i32 %context.value.445, 0
  br i1 %runtime.ok.446, label %runtime.continue.447, label %frame.failure.0
runtime.continue.447:
  %integer.right.443 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.441)
  %context.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.449 = load i32, ptr %context.field.448, align 4
  %runtime.ok.450 = icmp eq i32 %context.value.449, 0
  br i1 %runtime.ok.450, label %runtime.continue.451, label %frame.failure.0
runtime.continue.451:
  %integer.checked.452 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.442, i64 %integer.right.443)
  %integer.result.453 = extractvalue { i64, i1 } %integer.checked.452, 0
  %integer.overflow.454 = extractvalue { i64, i1 } %integer.checked.452, 1
  br i1 %integer.overflow.454, label %integer.overflow.failure.456, label %integer.nooverflow.455
integer.overflow.failure.456:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 42, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.455:
  %stack.offset.457 = add i32 %stack.offset.31, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.457, i32 8, i32 8, i32 1)
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %runtime.ok.460 = icmp eq i32 %context.value.459, 0
  br i1 %runtime.ok.460, label %runtime.continue.461, label %frame.failure.0
runtime.continue.461:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.463 = load i32, ptr %context.field.462, align 4
  %runtime.ok.464 = icmp eq i32 %context.value.463, 0
  br i1 %runtime.ok.464, label %runtime.continue.465, label %frame.failure.0
runtime.continue.465:
  %stack.offset.466 = add i32 %stack.offset.31, 8
  %reserve.status.467 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.466, i32 43)
  %reserve.ok.468 = icmp eq i32 %reserve.status.467, 0
  br i1 %reserve.ok.468, label %reserve.continue.469, label %frame.failure.0
reserve.continue.469:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.31, i64 %integer.result.453, i32 1)
  %context.field.470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.471 = load i32, ptr %context.field.470, align 4
  %runtime.ok.472 = icmp eq i32 %context.value.471, 0
  br i1 %runtime.ok.472, label %runtime.continue.473, label %frame.failure.0
runtime.continue.473:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.474 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.475 = load i32, ptr %context.field.474, align 4
  %runtime.ok.476 = icmp eq i32 %context.value.475, 0
  br i1 %runtime.ok.476, label %runtime.continue.477, label %frame.failure.0
runtime.continue.477:
  %stack.offset.478 = add i32 %stack.offset.31, 8
  %cursor.check.479 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.478)
  %cursor.ok.480 = icmp eq i32 %cursor.check.479, 0
  br i1 %cursor.ok.480, label %cursor.continue.481, label %frame.failure.0
cursor.continue.481:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 9)
  %context.field.482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.483 = load i32, ptr %context.field.482, align 4
  %runtime.ok.484 = icmp eq i32 %context.value.483, 0
  br i1 %runtime.ok.484, label %runtime.continue.485, label %frame.failure.0
runtime.continue.485:
  %local.is.active.486 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.487 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.488 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.489 = select i1 %local.is.active.486, i32 %local.clear.payload.487, i32 0
  %local.clear.live.type.490 = select i1 %local.is.active.486, i32 %local.clear.type.488, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.30, i32 8, i32 %local.clear.live.payload.489, i32 %local.clear.live.type.490)
  %context.field.491 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.492 = load i32, ptr %context.field.491, align 4
  %runtime.ok.493 = icmp eq i32 %context.value.492, 0
  br i1 %runtime.ok.493, label %runtime.continue.494, label %frame.failure.0
runtime.continue.494:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.495 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.496 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.497 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.498 = select i1 %local.is.active.495, i32 %local.clear.payload.496, i32 0
  %local.clear.live.type.499 = select i1 %local.is.active.495, i32 %local.clear.type.497, i32 0
  %stack.offset.500 = add i32 %context.value.30, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.500, i32 16, i32 %local.clear.live.payload.498, i32 %local.clear.live.type.499)
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  %runtime.ok.503 = icmp eq i32 %context.value.502, 0
  br i1 %runtime.ok.503, label %runtime.continue.504, label %frame.failure.0
runtime.continue.504:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.505 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.506 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.507 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.508 = select i1 %local.is.active.505, i32 %local.clear.payload.506, i32 0
  %local.clear.live.type.509 = select i1 %local.is.active.505, i32 %local.clear.type.507, i32 0
  %stack.offset.510 = add i32 %context.value.30, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.510, i32 16, i32 %local.clear.live.payload.508, i32 %local.clear.live.type.509)
  %context.field.511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.512 = load i32, ptr %context.field.511, align 4
  %runtime.ok.513 = icmp eq i32 %context.value.512, 0
  br i1 %runtime.ok.513, label %runtime.continue.514, label %frame.failure.0
runtime.continue.514:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.is.active.515 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.516 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.517 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.518 = select i1 %local.is.active.515, i32 %local.clear.payload.516, i32 0
  %local.clear.live.type.519 = select i1 %local.is.active.515, i32 %local.clear.type.517, i32 0
  %stack.offset.520 = add i32 %context.value.30, 40
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.520, i32 8, i32 %local.clear.live.payload.518, i32 %local.clear.live.type.519)
  %context.field.521 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.522 = load i32, ptr %context.field.521, align 4
  %runtime.ok.523 = icmp eq i32 %context.value.522, 0
  br i1 %runtime.ok.523, label %runtime.continue.524, label %frame.failure.0
runtime.continue.524:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.is.active.525 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.526 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.527 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.528 = select i1 %local.is.active.525, i32 %local.clear.payload.526, i32 0
  %local.clear.live.type.529 = select i1 %local.is.active.525, i32 %local.clear.type.527, i32 0
  %stack.offset.530 = add i32 %context.value.30, 48
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.530, i32 8, i32 %local.clear.live.payload.528, i32 %local.clear.live.type.529)
  %context.field.531 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.532 = load i32, ptr %context.field.531, align 4
  %runtime.ok.533 = icmp eq i32 %context.value.532, 0
  br i1 %runtime.ok.533, label %runtime.continue.534, label %frame.failure.0
runtime.continue.534:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  call void @al_owning_local_release(ptr %ctx, i32 56)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.30, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %context.field.537 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.538 = load i32, ptr %context.field.537, align 4
  %context.field.539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.540 = load i32, ptr %context.field.539, align 4
  %baseline.live.total.541 = add i32 %context.value.21, %context.value.23
  %current.live.total.542 = add i32 %context.value.536, %context.value.538
  %cleanup.live.delta.543 = sub i32 %baseline.live.total.541, %current.live.total.542
  %cleanup.local.delta.544 = sub i32 %context.value.23, %context.value.538
  %cleanup.reserved.delta.545 = sub i32 %context.value.540, %context.value.25
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.543, i32 %cleanup.local.delta.544)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.545)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %frame.entered.29 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.30 = icmp eq i32 %frame.entered.29, 0
  br i1 %frame.entered.ok.30, label %frame.entered.continue.31, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.offset.34 = add i32 %context.value.33, 40
  %stack.offset.35 = add i32 %context.value.33, 56
  %reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 44)
  %reserve.ok.37 = icmp eq i32 %reserve.status.36, 0
  br i1 %reserve.ok.37, label %reserve.continue.38, label %frame.reserve.failure.1
reserve.continue.38:
  call void @al_owning_local_reserve(ptr %ctx, i32 40)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, 8
  %stack.offset.44 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.44, i32 %stack.offset.43, i32 8, i32 8, i32 1, i32 8)
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.50 = load i32, ptr %context.field.49, align 4
  %runtime.ok.51 = icmp eq i32 %context.value.50, 0
  br i1 %runtime.ok.51, label %runtime.continue.52, label %frame.failure.0
runtime.continue.52:
  %step.status.53 = call i32 @al_owning_charge_step(ptr %ctx, i32 45)
  %step.ok.54 = icmp eq i32 %step.status.53, 0
  br i1 %step.ok.54, label %step.continue.55, label %frame.failure.0
step.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.57 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.58 = select i1 %local.is.active.56, i32 %local.previous.payload.57, i32 0
  %stack.offset.59 = add i32 %stack.offset.34, 8
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.33, i32 %stack.offset.59, i32 8, i32 8, i32 8, i32 %local.old.payload.58, i32 1)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  %stack.offset.64 = add i32 %stack.offset.34, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.64, i32 8, i32 8, i32 1)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %frame.failure.0
runtime.continue.68:
  %stack.offset.69 = add i32 %stack.offset.34, 8
  %cursor.check.70 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.69)
  %cursor.ok.71 = icmp eq i32 %cursor.check.70, 0
  br i1 %cursor.ok.71, label %cursor.continue.72, label %frame.failure.0
cursor.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 46)
  %step.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %step.ok.74, label %step.continue.75, label %frame.failure.0
step.continue.75:
  %local.is.active.76 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.77 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.78 = select i1 %local.is.active.76, i32 %local.previous.payload.77, i32 0
  %stack.offset.79 = add i32 %context.value.33, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.79, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.78, i32 1)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  store i1 true, ptr %local.active.6, align 1
  store i32 8, ptr %local.payload.7, align 4
  store i32 1, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %cursor.check.88 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.89 = icmp eq i32 %cursor.check.88, 0
  br i1 %cursor.ok.89, label %cursor.continue.90, label %frame.failure.0
cursor.continue.90:
  %step.status.91 = call i32 @al_owning_charge_step(ptr %ctx, i32 47)
  %step.ok.92 = icmp eq i32 %step.status.91, 0
  br i1 %step.ok.92, label %step.continue.93, label %frame.failure.0
step.continue.93:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 48)
  %step.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %step.ok.95, label %step.continue.96, label %frame.failure.0
step.continue.96:
  %stack.offset.97 = add i32 %stack.offset.34, 8
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 49)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %frame.failure.0
reserve.continue.100:
  %stack.offset.101 = add i32 %context.value.33, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.101, i32 8, i32 8, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 %stack.offset.34, 8
  %cursor.check.107 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.106)
  %cursor.ok.108 = icmp eq i32 %cursor.check.107, 0
  br i1 %cursor.ok.108, label %cursor.continue.109, label %frame.failure.0
cursor.continue.109:
  %step.status.110 = call i32 @al_owning_charge_step(ptr %ctx, i32 50)
  %step.ok.111 = icmp eq i32 %step.status.110, 0
  br i1 %step.ok.111, label %step.continue.112, label %frame.failure.0
step.continue.112:
  %local.is.active.113 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.114 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.115 = select i1 %local.is.active.113, i32 %local.previous.payload.114, i32 0
  %stack.offset.116 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.116, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.115, i32 1)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %runtime.ok.123 = icmp eq i32 %context.value.122, 0
  br i1 %runtime.ok.123, label %runtime.continue.124, label %frame.failure.0
runtime.continue.124:
  %cursor.check.125 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.126 = icmp eq i32 %cursor.check.125, 0
  br i1 %cursor.ok.126, label %cursor.continue.127, label %frame.failure.0
cursor.continue.127:
  %step.status.128 = call i32 @al_owning_charge_step(ptr %ctx, i32 51)
  %step.ok.129 = icmp eq i32 %step.status.128, 0
  br i1 %step.ok.129, label %step.continue.130, label %frame.failure.0
step.continue.130:
  %stack.offset.131 = add i32 %stack.offset.34, 8
  %reserve.status.132 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.131, i32 52)
  %reserve.ok.133 = icmp eq i32 %reserve.status.132, 0
  br i1 %reserve.ok.133, label %reserve.continue.134, label %frame.failure.0
reserve.continue.134:
  %stack.offset.135 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.135, i32 8, i32 8, i32 1)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %runtime.ok.138 = icmp eq i32 %context.value.137, 0
  br i1 %runtime.ok.138, label %runtime.continue.139, label %frame.failure.0
runtime.continue.139:
  %stack.offset.140 = add i32 %stack.offset.34, 8
  %cursor.check.141 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.140)
  %cursor.ok.142 = icmp eq i32 %cursor.check.141, 0
  br i1 %cursor.ok.142, label %cursor.continue.143, label %frame.failure.0
cursor.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 53)
  %step.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %step.ok.145, label %step.continue.146, label %frame.failure.0
step.continue.146:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 1, i32 6)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  %stack.offset.151 = add i32 %stack.offset.34, 8
  %stack.offset.152 = add i32 %stack.offset.34, 8
  %record.grows.153 = icmp ugt i32 %stack.offset.151, %stack.offset.152
  br i1 %record.grows.153, label %record.reserve.154, label %record.release.155
record.reserve.154:
  %reserve.status.157 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.151, i32 54)
  %reserve.ok.158 = icmp eq i32 %reserve.status.157, 0
  br i1 %reserve.ok.158, label %reserve.continue.159, label %frame.failure.0
reserve.continue.159:
  br label %record.ready.156
record.release.155:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.151, i32 0, i32 6, i32 8)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  br label %record.ready.156
record.ready.156:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %stack.offset.34, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  %stack.offset.168 = add i32 %stack.offset.34, 8
  %cursor.check.169 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.168)
  %cursor.ok.170 = icmp eq i32 %cursor.check.169, 0
  br i1 %cursor.ok.170, label %cursor.continue.171, label %frame.failure.0
cursor.continue.171:
  %local.is.active.172 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.173 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.174 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.175 = select i1 %local.is.active.172, i32 %local.clear.payload.173, i32 0
  %local.clear.live.type.176 = select i1 %local.is.active.172, i32 %local.clear.type.174, i32 0
  %stack.offset.177 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.177, i32 8, i32 %local.clear.live.payload.175, i32 %local.clear.live.type.176)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %stack.offset.182 = add i32 %stack.offset.34, 8
  %cursor.check.183 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.182)
  %cursor.ok.184 = icmp eq i32 %cursor.check.183, 0
  br i1 %cursor.ok.184, label %cursor.continue.185, label %frame.failure.0
cursor.continue.185:
  %step.status.186 = call i32 @al_owning_charge_step(ptr %ctx, i32 55)
  %step.ok.187 = icmp eq i32 %step.status.186, 0
  br i1 %step.ok.187, label %step.continue.188, label %frame.failure.0
step.continue.188:
  %local.is.active.189 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.190 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.191 = select i1 %local.is.active.189, i32 %local.previous.payload.190, i32 0
  %stack.offset.192 = add i32 %context.value.33, 16
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.192, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.191, i32 6)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %frame.failure.0
runtime.continue.196:
  store i1 true, ptr %local.active.9, align 1
  store i32 8, ptr %local.payload.10, align 4
  store i32 6, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %runtime.ok.199 = icmp eq i32 %context.value.198, 0
  br i1 %runtime.ok.199, label %runtime.continue.200, label %frame.failure.0
runtime.continue.200:
  %cursor.check.201 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.202 = icmp eq i32 %cursor.check.201, 0
  br i1 %cursor.ok.202, label %cursor.continue.203, label %frame.failure.0
cursor.continue.203:
  %step.status.204 = call i32 @al_owning_charge_step(ptr %ctx, i32 56)
  %step.ok.205 = icmp eq i32 %step.status.204, 0
  br i1 %step.ok.205, label %step.continue.206, label %frame.failure.0
step.continue.206:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 57)
  %step.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %step.ok.208, label %step.continue.209, label %frame.failure.0
step.continue.209:
  %stack.offset.210 = add i32 %stack.offset.34, 8
  %reserve.status.211 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.210, i32 58)
  %reserve.ok.212 = icmp eq i32 %reserve.status.211, 0
  br i1 %reserve.ok.212, label %reserve.continue.213, label %frame.failure.0
reserve.continue.213:
  %stack.offset.214 = add i32 %context.value.33, 16
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.214, i32 8, i32 8, i32 6)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  %stack.offset.219 = add i32 %stack.offset.34, 8
  %cursor.check.220 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.219)
  %cursor.ok.221 = icmp eq i32 %cursor.check.220, 0
  br i1 %cursor.ok.221, label %cursor.continue.222, label %frame.failure.0
cursor.continue.222:
  %step.status.223 = call i32 @al_owning_charge_step(ptr %ctx, i32 59)
  %step.ok.224 = icmp eq i32 %step.status.223, 0
  br i1 %step.ok.224, label %step.continue.225, label %frame.failure.0
step.continue.225:
  %local.is.active.226 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.227 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.228 = select i1 %local.is.active.226, i32 %local.previous.payload.227, i32 0
  %stack.offset.229 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.229, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.228, i32 6)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 6, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %cursor.check.238 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.239 = icmp eq i32 %cursor.check.238, 0
  br i1 %cursor.ok.239, label %cursor.continue.240, label %frame.failure.0
cursor.continue.240:
  %step.status.241 = call i32 @al_owning_charge_step(ptr %ctx, i32 60)
  %step.ok.242 = icmp eq i32 %step.status.241, 0
  br i1 %step.ok.242, label %step.continue.243, label %frame.failure.0
step.continue.243:
  %stack.offset.244 = add i32 %stack.offset.34, 8
  %reserve.status.245 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.244, i32 61)
  %reserve.ok.246 = icmp eq i32 %reserve.status.245, 0
  br i1 %reserve.ok.246, label %reserve.continue.247, label %frame.failure.0
reserve.continue.247:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %context.value.33, i32 8, i32 8, i32 1)
  %context.field.248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.249 = load i32, ptr %context.field.248, align 4
  %runtime.ok.250 = icmp eq i32 %context.value.249, 0
  br i1 %runtime.ok.250, label %runtime.continue.251, label %frame.failure.0
runtime.continue.251:
  %stack.offset.252 = add i32 %stack.offset.34, 8
  %cursor.check.253 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.252)
  %cursor.ok.254 = icmp eq i32 %cursor.check.253, 0
  br i1 %cursor.ok.254, label %cursor.continue.255, label %frame.failure.0
cursor.continue.255:
  %step.status.256 = call i32 @al_owning_charge_step(ptr %ctx, i32 62)
  %step.ok.257 = icmp eq i32 %step.status.256, 0
  br i1 %step.ok.257, label %step.continue.258, label %frame.failure.0
step.continue.258:
  %local.is.active.259 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.260 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.261 = select i1 %local.is.active.259, i32 %local.previous.payload.260, i32 0
  %stack.offset.262 = add i32 %context.value.33, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.262, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.261, i32 1)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %frame.failure.0
runtime.continue.266:
  store i1 true, ptr %local.active.18, align 1
  store i32 8, ptr %local.payload.19, align 4
  store i32 1, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %frame.failure.0
runtime.continue.270:
  %cursor.check.271 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.272 = icmp eq i32 %cursor.check.271, 0
  br i1 %cursor.ok.272, label %cursor.continue.273, label %frame.failure.0
cursor.continue.273:
  %step.status.274 = call i32 @al_owning_charge_step(ptr %ctx, i32 63)
  %step.ok.275 = icmp eq i32 %step.status.274, 0
  br i1 %step.ok.275, label %step.continue.276, label %frame.failure.0
step.continue.276:
  %stack.offset.277 = add i32 %stack.offset.34, 8
  %reserve.status.278 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.277, i32 64)
  %reserve.ok.279 = icmp eq i32 %reserve.status.278, 0
  br i1 %reserve.ok.279, label %reserve.continue.280, label %frame.failure.0
reserve.continue.280:
  %stack.offset.281 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.281, i32 8, i32 8, i32 6)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %stack.offset.286 = add i32 %stack.offset.34, 8
  %cursor.check.287 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.286)
  %cursor.ok.288 = icmp eq i32 %cursor.check.287, 0
  br i1 %cursor.ok.288, label %cursor.continue.289, label %frame.failure.0
cursor.continue.289:
  %step.status.290 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %step.ok.291 = icmp eq i32 %step.status.290, 0
  br i1 %step.ok.291, label %step.continue.292, label %frame.failure.0
step.continue.292:
  %stack.offset.293 = add i32 %stack.offset.34, 8
  %stack.offset.294 = add i32 %stack.offset.293, 8
  %reserve.status.295 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.294, i32 66)
  %reserve.ok.296 = icmp eq i32 %reserve.status.295, 0
  br i1 %reserve.ok.296, label %reserve.continue.297, label %frame.failure.0
reserve.continue.297:
  %stack.offset.298 = add i32 %context.value.33, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.293, i32 %stack.offset.298, i32 8, i32 8, i32 1)
  %context.field.299 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.300 = load i32, ptr %context.field.299, align 4
  %runtime.ok.301 = icmp eq i32 %context.value.300, 0
  br i1 %runtime.ok.301, label %runtime.continue.302, label %frame.failure.0
runtime.continue.302:
  %stack.offset.303 = add i32 %stack.offset.34, 16
  %cursor.check.304 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.303)
  %cursor.ok.305 = icmp eq i32 %cursor.check.304, 0
  br i1 %cursor.ok.305, label %cursor.continue.306, label %frame.failure.0
cursor.continue.306:
  %step.status.307 = call i32 @al_owning_charge_step(ptr %ctx, i32 67)
  %step.ok.308 = icmp eq i32 %step.status.307, 0
  br i1 %step.ok.308, label %step.continue.309, label %frame.failure.0
step.continue.309:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 6, i32 6)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %frame.failure.0
runtime.continue.313:
  %stack.offset.314 = add i32 %stack.offset.34, 8
  %stack.offset.315 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.314, i32 %stack.offset.315, i32 8, i32 8, i32 1, i32 6)
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %runtime.ok.318 = icmp eq i32 %context.value.317, 0
  br i1 %runtime.ok.318, label %runtime.continue.319, label %frame.failure.0
runtime.continue.319:
  %stack.offset.320 = add i32 %stack.offset.34, 16
  %stack.offset.321 = add i32 %stack.offset.34, 16
  %record.grows.322 = icmp ugt i32 %stack.offset.320, %stack.offset.321
  br i1 %record.grows.322, label %record.reserve.323, label %record.release.324
record.reserve.323:
  %reserve.status.326 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.320, i32 68)
  %reserve.ok.327 = icmp eq i32 %reserve.status.326, 0
  br i1 %reserve.ok.327, label %reserve.continue.328, label %frame.failure.0
reserve.continue.328:
  br label %record.ready.325
record.release.324:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.320, i32 0, i32 5, i32 16)
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %runtime.ok.331 = icmp eq i32 %context.value.330, 0
  br i1 %runtime.ok.331, label %runtime.continue.332, label %frame.failure.0
runtime.continue.332:
  br label %record.ready.325
record.ready.325:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %stack.offset.34, i32 16, i32 16, i32 0, i32 0)
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %runtime.ok.335 = icmp eq i32 %context.value.334, 0
  br i1 %runtime.ok.335, label %runtime.continue.336, label %frame.failure.0
runtime.continue.336:
  %stack.offset.337 = add i32 %stack.offset.34, 16
  %cursor.check.338 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.337)
  %cursor.ok.339 = icmp eq i32 %cursor.check.338, 0
  br i1 %cursor.ok.339, label %cursor.continue.340, label %frame.failure.0
cursor.continue.340:
  %local.is.active.341 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.342 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.343 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.344 = select i1 %local.is.active.341, i32 %local.clear.payload.342, i32 0
  %local.clear.live.type.345 = select i1 %local.is.active.341, i32 %local.clear.type.343, i32 0
  %stack.offset.346 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.346, i32 8, i32 %local.clear.live.payload.344, i32 %local.clear.live.type.345)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.is.active.351 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.352 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.353 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.354 = select i1 %local.is.active.351, i32 %local.clear.payload.352, i32 0
  %local.clear.live.type.355 = select i1 %local.is.active.351, i32 %local.clear.type.353, i32 0
  %stack.offset.356 = add i32 %context.value.33, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.356, i32 8, i32 %local.clear.live.payload.354, i32 %local.clear.live.type.355)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %stack.offset.361 = add i32 %stack.offset.34, 16
  %cursor.check.362 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.361)
  %cursor.ok.363 = icmp eq i32 %cursor.check.362, 0
  br i1 %cursor.ok.363, label %cursor.continue.364, label %frame.failure.0
cursor.continue.364:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.34, i32 16, i32 16, i32 5, i32 9)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %local.is.active.369 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.370 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.371 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.372 = select i1 %local.is.active.369, i32 %local.clear.payload.370, i32 0
  %local.clear.live.type.373 = select i1 %local.is.active.369, i32 %local.clear.type.371, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.33, i32 8, i32 %local.clear.live.payload.372, i32 %local.clear.live.type.373)
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %runtime.ok.376 = icmp eq i32 %context.value.375, 0
  br i1 %runtime.ok.376, label %runtime.continue.377, label %frame.failure.0
runtime.continue.377:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.378 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.379 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.380 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.381 = select i1 %local.is.active.378, i32 %local.clear.payload.379, i32 0
  %local.clear.live.type.382 = select i1 %local.is.active.378, i32 %local.clear.type.380, i32 0
  %stack.offset.383 = add i32 %context.value.33, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.383, i32 8, i32 %local.clear.live.payload.381, i32 %local.clear.live.type.382)
  %context.field.384 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.385 = load i32, ptr %context.field.384, align 4
  %runtime.ok.386 = icmp eq i32 %context.value.385, 0
  br i1 %runtime.ok.386, label %runtime.continue.387, label %frame.failure.0
runtime.continue.387:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.388 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.389 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.390 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.391 = select i1 %local.is.active.388, i32 %local.clear.payload.389, i32 0
  %local.clear.live.type.392 = select i1 %local.is.active.388, i32 %local.clear.type.390, i32 0
  %stack.offset.393 = add i32 %context.value.33, 16
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.393, i32 8, i32 %local.clear.live.payload.391, i32 %local.clear.live.type.392)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  call void @al_owning_local_release(ptr %ctx, i32 40)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.33, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %context.field.400 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.401 = load i32, ptr %context.field.400, align 4
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %baseline.live.total.404 = add i32 %context.value.24, %context.value.26
  %current.live.total.405 = add i32 %context.value.399, %context.value.401
  %cleanup.live.delta.406 = sub i32 %baseline.live.total.404, %current.live.total.405
  %cleanup.local.delta.407 = sub i32 %context.value.26, %context.value.401
  %cleanup.reserved.delta.408 = sub i32 %context.value.403, %context.value.28
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.406, i32 %cleanup.local.delta.407)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.408)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %local.active.21 = alloca i1, align 1
  %local.payload.22 = alloca i32, align 4
  %local.type.23 = alloca i32, align 4
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %local.active.24 = alloca i1, align 1
  %local.payload.25 = alloca i32, align 4
  %local.type.26 = alloca i32, align 4
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %context.field.31 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.32 = load i32, ptr %context.field.31, align 4
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %frame.entered.35 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.36 = icmp eq i32 %frame.entered.35, 0
  br i1 %frame.entered.ok.36, label %frame.entered.continue.37, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.offset.40 = add i32 %context.value.39, 88
  %stack.offset.41 = add i32 %context.value.39, 120
  %reserve.status.42 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.41, i32 69)
  %reserve.ok.43 = icmp eq i32 %reserve.status.42, 0
  br i1 %reserve.ok.43, label %reserve.continue.44, label %frame.reserve.failure.1
reserve.continue.44:
  call void @al_owning_local_reserve(ptr %ctx, i32 88)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  %stack.offset.49 = add i32 %argument.source, 24
  %stack.offset.50 = add i32 %stack.offset.40, 24
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.40, i32 %argument.source, i32 24, i32 24, i32 7, i32 8)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.50, i32 %stack.offset.49, i32 8, i32 8, i32 1, i32 8)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %frame.failure.0
runtime.continue.58:
  %step.status.59 = call i32 @al_owning_charge_step(ptr %ctx, i32 70)
  %step.ok.60 = icmp eq i32 %step.status.59, 0
  br i1 %step.ok.60, label %step.continue.61, label %frame.failure.0
step.continue.61:
  %local.is.active.62 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.63 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.64 = select i1 %local.is.active.62, i32 %local.previous.payload.63, i32 0
  %stack.offset.65 = add i32 %stack.offset.40, 24
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.39, i32 %stack.offset.65, i32 8, i32 8, i32 8, i32 %local.old.payload.64, i32 1)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %frame.failure.0
runtime.continue.69:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  %stack.offset.70 = add i32 %stack.offset.40, 24
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.70, i32 8, i32 8, i32 1)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %frame.failure.0
runtime.continue.74:
  %stack.offset.75 = add i32 %stack.offset.40, 24
  %cursor.check.76 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.75)
  %cursor.ok.77 = icmp eq i32 %cursor.check.76, 0
  br i1 %cursor.ok.77, label %cursor.continue.78, label %frame.failure.0
cursor.continue.78:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 71)
  %step.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %step.ok.80, label %step.continue.81, label %frame.failure.0
step.continue.81:
  %local.is.active.82 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.83 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.84 = select i1 %local.is.active.82, i32 %local.previous.payload.83, i32 0
  %stack.offset.85 = add i32 %context.value.39, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.85, i32 %stack.offset.40, i32 24, i32 24, i32 24, i32 %local.old.payload.84, i32 7)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %runtime.ok.88 = icmp eq i32 %context.value.87, 0
  br i1 %runtime.ok.88, label %runtime.continue.89, label %frame.failure.0
runtime.continue.89:
  store i1 true, ptr %local.active.6, align 1
  store i32 24, ptr %local.payload.7, align 4
  store i32 7, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 24, i32 24, i32 7)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %cursor.check.94 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.95 = icmp eq i32 %cursor.check.94, 0
  br i1 %cursor.ok.95, label %cursor.continue.96, label %frame.failure.0
cursor.continue.96:
  %step.status.97 = call i32 @al_owning_charge_step(ptr %ctx, i32 72)
  %step.ok.98 = icmp eq i32 %step.status.97, 0
  br i1 %step.ok.98, label %step.continue.99, label %frame.failure.0
step.continue.99:
  %stack.offset.100 = add i32 %stack.offset.40, 8
  %reserve.status.101 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.100, i32 73)
  %reserve.ok.102 = icmp eq i32 %reserve.status.101, 0
  br i1 %reserve.ok.102, label %reserve.continue.103, label %frame.failure.0
reserve.continue.103:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %context.value.39, i32 8, i32 8, i32 1)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %stack.offset.108 = add i32 %stack.offset.40, 8
  %cursor.check.109 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.108)
  %cursor.ok.110 = icmp eq i32 %cursor.check.109, 0
  br i1 %cursor.ok.110, label %cursor.continue.111, label %frame.failure.0
cursor.continue.111:
  %step.status.112 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %step.ok.113 = icmp eq i32 %step.status.112, 0
  br i1 %step.ok.113, label %step.continue.114, label %frame.failure.0
step.continue.114:
  %stack.offset.115 = add i32 %stack.offset.40, 8
  %stack.offset.116 = add i32 %stack.offset.115, 8
  %reserve.status.117 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.116, i32 75)
  %reserve.ok.118 = icmp eq i32 %reserve.status.117, 0
  br i1 %reserve.ok.118, label %reserve.continue.119, label %frame.failure.0
reserve.continue.119:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.115, i32 %context.value.39, i32 8, i32 8, i32 1)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %frame.failure.0
runtime.continue.123:
  %stack.offset.124 = add i32 %stack.offset.40, 16
  %cursor.check.125 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.124)
  %cursor.ok.126 = icmp eq i32 %cursor.check.125, 0
  br i1 %cursor.ok.126, label %cursor.continue.127, label %frame.failure.0
cursor.continue.127:
  %step.status.128 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %step.ok.129 = icmp eq i32 %step.status.128, 0
  br i1 %step.ok.129, label %step.continue.130, label %frame.failure.0
step.continue.130:
  %stack.offset.131 = add i32 %stack.offset.40, 16
  %stack.offset.132 = add i32 %stack.offset.131, 8
  %reserve.status.133 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.132, i32 77)
  %reserve.ok.134 = icmp eq i32 %reserve.status.133, 0
  br i1 %reserve.ok.134, label %reserve.continue.135, label %frame.failure.0
reserve.continue.135:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.131, i64 1000, i32 1)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %runtime.ok.138 = icmp eq i32 %context.value.137, 0
  br i1 %runtime.ok.138, label %runtime.continue.139, label %frame.failure.0
runtime.continue.139:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %runtime.ok.142 = icmp eq i32 %context.value.141, 0
  br i1 %runtime.ok.142, label %runtime.continue.143, label %frame.failure.0
runtime.continue.143:
  %stack.offset.144 = add i32 %stack.offset.40, 24
  %cursor.check.145 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.144)
  %cursor.ok.146 = icmp eq i32 %cursor.check.145, 0
  br i1 %cursor.ok.146, label %cursor.continue.147, label %frame.failure.0
cursor.continue.147:
  %step.status.148 = call i32 @al_owning_charge_step(ptr %ctx, i32 78)
  %step.ok.149 = icmp eq i32 %step.status.148, 0
  br i1 %step.ok.149, label %step.continue.150, label %frame.failure.0
step.continue.150:
  %stack.offset.151 = add i32 %stack.offset.40, 8
  %stack.offset.152 = add i32 %stack.offset.40, 16
  %integer.left.153 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.151)
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %runtime.ok.157 = icmp eq i32 %context.value.156, 0
  br i1 %runtime.ok.157, label %runtime.continue.158, label %frame.failure.0
runtime.continue.158:
  %integer.right.154 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.152)
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %runtime.ok.161 = icmp eq i32 %context.value.160, 0
  br i1 %runtime.ok.161, label %runtime.continue.162, label %frame.failure.0
runtime.continue.162:
  %integer.checked.163 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.153, i64 %integer.right.154)
  %integer.result.164 = extractvalue { i64, i1 } %integer.checked.163, 0
  %integer.overflow.165 = extractvalue { i64, i1 } %integer.checked.163, 1
  br i1 %integer.overflow.165, label %integer.overflow.failure.167, label %integer.nooverflow.166
integer.overflow.failure.167:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 79, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.166:
  %stack.offset.168 = add i32 %stack.offset.40, 8
  %stack.offset.169 = add i32 %stack.offset.40, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.169, i32 8, i32 8, i32 1)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 %stack.offset.40, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.174, i32 8, i32 8, i32 1)
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %runtime.ok.177 = icmp eq i32 %context.value.176, 0
  br i1 %runtime.ok.177, label %runtime.continue.178, label %frame.failure.0
runtime.continue.178:
  %stack.offset.179 = add i32 %stack.offset.168, 8
  %reserve.status.180 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.179, i32 80)
  %reserve.ok.181 = icmp eq i32 %reserve.status.180, 0
  br i1 %reserve.ok.181, label %reserve.continue.182, label %frame.failure.0
reserve.continue.182:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.168, i64 %integer.result.164, i32 1)
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %runtime.ok.185 = icmp eq i32 %context.value.184, 0
  br i1 %runtime.ok.185, label %runtime.continue.186, label %frame.failure.0
runtime.continue.186:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %runtime.ok.189 = icmp eq i32 %context.value.188, 0
  br i1 %runtime.ok.189, label %runtime.continue.190, label %frame.failure.0
runtime.continue.190:
  %stack.offset.191 = add i32 %stack.offset.40, 16
  %cursor.check.192 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.191)
  %cursor.ok.193 = icmp eq i32 %cursor.check.192, 0
  br i1 %cursor.ok.193, label %cursor.continue.194, label %frame.failure.0
cursor.continue.194:
  %step.status.195 = call i32 @al_owning_charge_step(ptr %ctx, i32 81)
  %step.ok.196 = icmp eq i32 %step.status.195, 0
  br i1 %step.ok.196, label %step.continue.197, label %frame.failure.0
step.continue.197:
  %stack.offset.198 = add i32 %stack.offset.40, 16
  %reserve.status.199 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.198, i32 82)
  %reserve.ok.200 = icmp eq i32 %reserve.status.199, 0
  br i1 %reserve.ok.200, label %reserve.continue.201, label %frame.failure.0
reserve.continue.201:
  %callee.status.202 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 83)
  %callee.ok.203 = icmp eq i32 %callee.status.202, 0
  br i1 %callee.ok.203, label %callee.returned.204, label %frame.failure.0
callee.returned.204:
  %stack.offset.205 = add i32 %stack.offset.40, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.205, i32 0, i32 0, i32 0)
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %runtime.ok.208 = icmp eq i32 %context.value.207, 0
  br i1 %runtime.ok.208, label %runtime.continue.209, label %frame.failure.0
runtime.continue.209:
  %stack.offset.210 = add i32 %stack.offset.40, 16
  %cursor.check.211 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.210)
  %cursor.ok.212 = icmp eq i32 %cursor.check.211, 0
  br i1 %cursor.ok.212, label %cursor.continue.213, label %frame.failure.0
cursor.continue.213:
  %step.status.214 = call i32 @al_owning_charge_step(ptr %ctx, i32 84)
  %step.ok.215 = icmp eq i32 %step.status.214, 0
  br i1 %step.ok.215, label %step.continue.216, label %frame.failure.0
step.continue.216:
  %local.is.active.217 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.218 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.219 = select i1 %local.is.active.217, i32 %local.previous.payload.218, i32 0
  %stack.offset.220 = add i32 %context.value.39, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.220, i32 %stack.offset.40, i32 16, i32 16, i32 16, i32 %local.old.payload.219, i32 5)
  %context.field.221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.222 = load i32, ptr %context.field.221, align 4
  %runtime.ok.223 = icmp eq i32 %context.value.222, 0
  br i1 %runtime.ok.223, label %runtime.continue.224, label %frame.failure.0
runtime.continue.224:
  store i1 true, ptr %local.active.9, align 1
  store i32 16, ptr %local.payload.10, align 4
  store i32 5, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 16, i32 16, i32 5)
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %runtime.ok.227 = icmp eq i32 %context.value.226, 0
  br i1 %runtime.ok.227, label %runtime.continue.228, label %frame.failure.0
runtime.continue.228:
  %cursor.check.229 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.230 = icmp eq i32 %cursor.check.229, 0
  br i1 %cursor.ok.230, label %cursor.continue.231, label %frame.failure.0
cursor.continue.231:
  %step.status.232 = call i32 @al_owning_charge_step(ptr %ctx, i32 85)
  %step.ok.233 = icmp eq i32 %step.status.232, 0
  br i1 %step.ok.233, label %step.continue.234, label %frame.failure.0
step.continue.234:
  %stack.offset.235 = add i32 %stack.offset.40, 8
  %reserve.status.236 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.235, i32 86)
  %reserve.ok.237 = icmp eq i32 %reserve.status.236, 0
  br i1 %reserve.ok.237, label %reserve.continue.238, label %frame.failure.0
reserve.continue.238:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %context.value.39, i32 8, i32 8, i32 1)
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %runtime.ok.241 = icmp eq i32 %context.value.240, 0
  br i1 %runtime.ok.241, label %runtime.continue.242, label %frame.failure.0
runtime.continue.242:
  %stack.offset.243 = add i32 %stack.offset.40, 8
  %cursor.check.244 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.243)
  %cursor.ok.245 = icmp eq i32 %cursor.check.244, 0
  br i1 %cursor.ok.245, label %cursor.continue.246, label %frame.failure.0
cursor.continue.246:
  %step.status.247 = call i32 @al_owning_charge_step(ptr %ctx, i32 87)
  %step.ok.248 = icmp eq i32 %step.status.247, 0
  br i1 %step.ok.248, label %step.continue.249, label %frame.failure.0
step.continue.249:
  %stack.offset.250 = add i32 %stack.offset.40, 8
  %reserve.status.251 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.250, i32 88)
  %reserve.ok.252 = icmp eq i32 %reserve.status.251, 0
  br i1 %reserve.ok.252, label %reserve.continue.253, label %frame.failure.0
reserve.continue.253:
  %callee.status.254 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 89)
  %callee.ok.255 = icmp eq i32 %callee.status.254, 0
  br i1 %callee.ok.255, label %callee.returned.256, label %frame.failure.0
callee.returned.256:
  %stack.offset.257 = add i32 %stack.offset.40, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.257, i32 0, i32 0, i32 0)
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %runtime.ok.260 = icmp eq i32 %context.value.259, 0
  br i1 %runtime.ok.260, label %runtime.continue.261, label %frame.failure.0
runtime.continue.261:
  %stack.offset.262 = add i32 %stack.offset.40, 8
  %cursor.check.263 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.262)
  %cursor.ok.264 = icmp eq i32 %cursor.check.263, 0
  br i1 %cursor.ok.264, label %cursor.continue.265, label %frame.failure.0
cursor.continue.265:
  %step.status.266 = call i32 @al_owning_charge_step(ptr %ctx, i32 90)
  %step.ok.267 = icmp eq i32 %step.status.266, 0
  br i1 %step.ok.267, label %step.continue.268, label %frame.failure.0
step.continue.268:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.269 = call i32 @al_owning_charge_step(ptr %ctx, i32 91)
  %step.ok.270 = icmp eq i32 %step.status.269, 0
  br i1 %step.ok.270, label %step.continue.271, label %frame.failure.0
step.continue.271:
  %local.is.active.272 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.273 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.274 = select i1 %local.is.active.272, i32 %local.previous.payload.273, i32 0
  %stack.offset.275 = add i32 %context.value.39, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.275, i32 %stack.offset.40, i32 8, i32 8, i32 8, i32 %local.old.payload.274, i32 1)
  %context.field.276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.277 = load i32, ptr %context.field.276, align 4
  %runtime.ok.278 = icmp eq i32 %context.value.277, 0
  br i1 %runtime.ok.278, label %runtime.continue.279, label %frame.failure.0
runtime.continue.279:
  store i1 true, ptr %local.active.18, align 1
  store i32 8, ptr %local.payload.19, align 4
  store i32 1, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %cursor.check.284 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.285 = icmp eq i32 %cursor.check.284, 0
  br i1 %cursor.ok.285, label %cursor.continue.286, label %frame.failure.0
cursor.continue.286:
  %local.is.active.287 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.288 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.289 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.290 = select i1 %local.is.active.287, i32 %local.clear.payload.288, i32 0
  %local.clear.live.type.291 = select i1 %local.is.active.287, i32 %local.clear.type.289, i32 0
  %stack.offset.292 = add i32 %context.value.39, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.292, i32 8, i32 %local.clear.live.payload.290, i32 %local.clear.live.type.291)
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %runtime.ok.295 = icmp eq i32 %context.value.294, 0
  br i1 %runtime.ok.295, label %runtime.continue.296, label %frame.failure.0
runtime.continue.296:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %cursor.check.297 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.298 = icmp eq i32 %cursor.check.297, 0
  br i1 %cursor.ok.298, label %cursor.continue.299, label %frame.failure.0
cursor.continue.299:
  %step.status.300 = call i32 @al_owning_charge_step(ptr %ctx, i32 92)
  %step.ok.301 = icmp eq i32 %step.status.300, 0
  br i1 %step.ok.301, label %step.continue.302, label %frame.failure.0
step.continue.302:
  %stack.offset.303 = add i32 %stack.offset.40, 16
  %reserve.status.304 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.303, i32 93)
  %reserve.ok.305 = icmp eq i32 %reserve.status.304, 0
  br i1 %reserve.ok.305, label %reserve.continue.306, label %frame.failure.0
reserve.continue.306:
  %stack.offset.307 = add i32 %context.value.39, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.307, i32 16, i32 16, i32 5)
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %runtime.ok.310 = icmp eq i32 %context.value.309, 0
  br i1 %runtime.ok.310, label %runtime.continue.311, label %frame.failure.0
runtime.continue.311:
  %stack.offset.312 = add i32 %stack.offset.40, 16
  %cursor.check.313 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.312)
  %cursor.ok.314 = icmp eq i32 %cursor.check.313, 0
  br i1 %cursor.ok.314, label %cursor.continue.315, label %frame.failure.0
cursor.continue.315:
  %step.status.316 = call i32 @al_owning_charge_step(ptr %ctx, i32 94)
  %step.ok.317 = icmp eq i32 %step.status.316, 0
  br i1 %step.ok.317, label %step.continue.318, label %frame.failure.0
step.continue.318:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 8, i32 8, i32 6, i32 7)
  %context.field.319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.320 = load i32, ptr %context.field.319, align 4
  %runtime.ok.321 = icmp eq i32 %context.value.320, 0
  br i1 %runtime.ok.321, label %runtime.continue.322, label %frame.failure.0
runtime.continue.322:
  %stack.offset.323 = add i32 %stack.offset.40, 8
  %stack.offset.324 = add i32 %stack.offset.40, 16
  %field.grows.325 = icmp ugt i32 %stack.offset.323, %stack.offset.324
  br i1 %field.grows.325, label %field.reserve.326, label %field.release.327
field.reserve.326:
  %reserve.status.329 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.323, i32 95)
  %reserve.ok.330 = icmp eq i32 %reserve.status.329, 0
  br i1 %reserve.ok.330, label %reserve.continue.331, label %frame.failure.0
reserve.continue.331:
  br label %field.ready.328
field.release.327:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.323, i32 0, i32 6, i32 8)
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %runtime.ok.334 = icmp eq i32 %context.value.333, 0
  br i1 %runtime.ok.334, label %runtime.continue.335, label %frame.failure.0
runtime.continue.335:
  br label %field.ready.328
field.ready.328:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.336 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.337 = load i32, ptr %context.field.336, align 4
  %runtime.ok.338 = icmp eq i32 %context.value.337, 0
  br i1 %runtime.ok.338, label %runtime.continue.339, label %frame.failure.0
runtime.continue.339:
  %stack.offset.340 = add i32 %stack.offset.40, 8
  %cursor.check.341 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.340)
  %cursor.ok.342 = icmp eq i32 %cursor.check.341, 0
  br i1 %cursor.ok.342, label %cursor.continue.343, label %frame.failure.0
cursor.continue.343:
  %step.status.344 = call i32 @al_owning_charge_step(ptr %ctx, i32 96)
  %step.ok.345 = icmp eq i32 %step.status.344, 0
  br i1 %step.ok.345, label %step.continue.346, label %frame.failure.0
step.continue.346:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 8, i32 8, i32 1, i32 7)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  %stack.offset.351 = add i32 %stack.offset.40, 8
  %stack.offset.352 = add i32 %stack.offset.40, 8
  %field.grows.353 = icmp ugt i32 %stack.offset.351, %stack.offset.352
  br i1 %field.grows.353, label %field.reserve.354, label %field.release.355
field.reserve.354:
  %reserve.status.357 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.351, i32 97)
  %reserve.ok.358 = icmp eq i32 %reserve.status.357, 0
  br i1 %reserve.ok.358, label %reserve.continue.359, label %frame.failure.0
reserve.continue.359:
  br label %field.ready.356
field.release.355:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.351, i32 0, i32 1, i32 8)
  %context.field.360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.361 = load i32, ptr %context.field.360, align 4
  %runtime.ok.362 = icmp eq i32 %context.value.361, 0
  br i1 %runtime.ok.362, label %runtime.continue.363, label %frame.failure.0
runtime.continue.363:
  br label %field.ready.356
field.ready.356:
  %stack.offset.364 = add i32 %stack.offset.40, 8
  %cursor.check.365 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.364)
  %cursor.ok.366 = icmp eq i32 %cursor.check.365, 0
  br i1 %cursor.ok.366, label %cursor.continue.367, label %frame.failure.0
cursor.continue.367:
  %step.status.368 = call i32 @al_owning_charge_step(ptr %ctx, i32 98)
  %step.ok.369 = icmp eq i32 %step.status.368, 0
  br i1 %step.ok.369, label %step.continue.370, label %frame.failure.0
step.continue.370:
  %local.is.active.371 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.372 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.373 = select i1 %local.is.active.371, i32 %local.previous.payload.372, i32 0
  %stack.offset.374 = add i32 %context.value.39, 48
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.374, i32 %stack.offset.40, i32 8, i32 8, i32 8, i32 %local.old.payload.373, i32 1)
  %context.field.375 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.376 = load i32, ptr %context.field.375, align 4
  %runtime.ok.377 = icmp eq i32 %context.value.376, 0
  br i1 %runtime.ok.377, label %runtime.continue.378, label %frame.failure.0
runtime.continue.378:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %runtime.ok.381 = icmp eq i32 %context.value.380, 0
  br i1 %runtime.ok.381, label %runtime.continue.382, label %frame.failure.0
runtime.continue.382:
  %cursor.check.383 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.384 = icmp eq i32 %cursor.check.383, 0
  br i1 %cursor.ok.384, label %cursor.continue.385, label %frame.failure.0
cursor.continue.385:
  %step.status.386 = call i32 @al_owning_charge_step(ptr %ctx, i32 99)
  %step.ok.387 = icmp eq i32 %step.status.386, 0
  br i1 %step.ok.387, label %step.continue.388, label %frame.failure.0
step.continue.388:
  %stack.offset.389 = add i32 %stack.offset.40, 8
  %reserve.status.390 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.389, i32 100)
  %reserve.ok.391 = icmp eq i32 %reserve.status.390, 0
  br i1 %reserve.ok.391, label %reserve.continue.392, label %frame.failure.0
reserve.continue.392:
  %stack.offset.393 = add i32 %context.value.39, 48
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.393, i32 8, i32 8, i32 1)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  %stack.offset.398 = add i32 %stack.offset.40, 8
  %cursor.check.399 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.398)
  %cursor.ok.400 = icmp eq i32 %cursor.check.399, 0
  br i1 %cursor.ok.400, label %cursor.continue.401, label %frame.failure.0
cursor.continue.401:
  %step.status.402 = call i32 @al_owning_charge_step(ptr %ctx, i32 101)
  %step.ok.403 = icmp eq i32 %step.status.402, 0
  br i1 %step.ok.403, label %step.continue.404, label %frame.failure.0
step.continue.404:
  %stack.offset.405 = add i32 %stack.offset.40, 8
  %stack.offset.406 = add i32 %stack.offset.405, 8
  %reserve.status.407 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.406, i32 102)
  %reserve.ok.408 = icmp eq i32 %reserve.status.407, 0
  br i1 %reserve.ok.408, label %reserve.continue.409, label %frame.failure.0
reserve.continue.409:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.405, i32 %context.value.39, i32 8, i32 8, i32 1)
  %context.field.410 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.411 = load i32, ptr %context.field.410, align 4
  %runtime.ok.412 = icmp eq i32 %context.value.411, 0
  br i1 %runtime.ok.412, label %runtime.continue.413, label %frame.failure.0
runtime.continue.413:
  %stack.offset.414 = add i32 %stack.offset.40, 16
  %cursor.check.415 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.414)
  %cursor.ok.416 = icmp eq i32 %cursor.check.415, 0
  br i1 %cursor.ok.416, label %cursor.continue.417, label %frame.failure.0
cursor.continue.417:
  %step.status.418 = call i32 @al_owning_charge_step(ptr %ctx, i32 103)
  %step.ok.419 = icmp eq i32 %step.status.418, 0
  br i1 %step.ok.419, label %step.continue.420, label %frame.failure.0
step.continue.420:
  %stack.offset.421 = add i32 %stack.offset.40, 8
  %equals.result.422 = call i32 @al_owning_equal(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.421, i32 8)
  %context.field.423 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.424 = load i32, ptr %context.field.423, align 4
  %runtime.ok.425 = icmp eq i32 %context.value.424, 0
  br i1 %runtime.ok.425, label %runtime.continue.426, label %frame.failure.0
runtime.continue.426:
  %equals.bool.427 = icmp ne i32 %equals.result.422, 0
  %equals.value.428 = zext i1 %equals.bool.427 to i64
  %stack.offset.429 = add i32 %stack.offset.40, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.429, i32 8, i32 8, i32 1)
  %context.field.430 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.431 = load i32, ptr %context.field.430, align 4
  %runtime.ok.432 = icmp eq i32 %context.value.431, 0
  br i1 %runtime.ok.432, label %runtime.continue.433, label %frame.failure.0
runtime.continue.433:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.435 = load i32, ptr %context.field.434, align 4
  %runtime.ok.436 = icmp eq i32 %context.value.435, 0
  br i1 %runtime.ok.436, label %runtime.continue.437, label %frame.failure.0
runtime.continue.437:
  %stack.offset.438 = add i32 %stack.offset.40, 8
  %reserve.status.439 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.438, i32 104)
  %reserve.ok.440 = icmp eq i32 %reserve.status.439, 0
  br i1 %reserve.ok.440, label %reserve.continue.441, label %frame.failure.0
reserve.continue.441:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.40, i64 %equals.value.428, i32 2)
  %context.field.442 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.443 = load i32, ptr %context.field.442, align 4
  %runtime.ok.444 = icmp eq i32 %context.value.443, 0
  br i1 %runtime.ok.444, label %runtime.continue.445, label %frame.failure.0
runtime.continue.445:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.446 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.447 = load i32, ptr %context.field.446, align 4
  %runtime.ok.448 = icmp eq i32 %context.value.447, 0
  br i1 %runtime.ok.448, label %runtime.continue.449, label %frame.failure.0
runtime.continue.449:
  %stack.offset.450 = add i32 %stack.offset.40, 8
  %cursor.check.451 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.450)
  %cursor.ok.452 = icmp eq i32 %cursor.check.451, 0
  br i1 %cursor.ok.452, label %cursor.continue.453, label %frame.failure.0
cursor.continue.453:
  %step.status.454 = call i32 @al_owning_charge_step(ptr %ctx, i32 105)
  %step.ok.455 = icmp eq i32 %step.status.454, 0
  br i1 %step.ok.455, label %step.continue.456, label %frame.failure.0
step.continue.456:
  %if.condition.raw.457 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.40)
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %runtime.ok.460 = icmp eq i32 %context.value.459, 0
  br i1 %runtime.ok.460, label %runtime.continue.461, label %frame.failure.0
runtime.continue.461:
  %if.condition.462 = icmp ne i64 %if.condition.raw.457, 0
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 2)
  %context.field.463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.464 = load i32, ptr %context.field.463, align 4
  %runtime.ok.465 = icmp eq i32 %context.value.464, 0
  br i1 %runtime.ok.465, label %runtime.continue.466, label %frame.failure.0
runtime.continue.466:
  br i1 %if.condition.462, label %if.then.467, label %if.else.468
if.then.467:
  %step.status.470 = call i32 @al_owning_charge_step(ptr %ctx, i32 106)
  %step.ok.471 = icmp eq i32 %step.status.470, 0
  br i1 %step.ok.471, label %step.continue.472, label %frame.failure.0
step.continue.472:
  %step.status.473 = call i32 @al_owning_charge_step(ptr %ctx, i32 107)
  %step.ok.474 = icmp eq i32 %step.status.473, 0
  br i1 %step.ok.474, label %step.continue.475, label %frame.failure.0
step.continue.475:
  %stack.offset.476 = add i32 %stack.offset.40, 8
  %reserve.status.477 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.476, i32 108)
  %reserve.ok.478 = icmp eq i32 %reserve.status.477, 0
  br i1 %reserve.ok.478, label %reserve.continue.479, label %frame.failure.0
reserve.continue.479:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.40, i64 1, i32 1)
  %context.field.480 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.481 = load i32, ptr %context.field.480, align 4
  %runtime.ok.482 = icmp eq i32 %context.value.481, 0
  br i1 %runtime.ok.482, label %runtime.continue.483, label %frame.failure.0
runtime.continue.483:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.485 = load i32, ptr %context.field.484, align 4
  %runtime.ok.486 = icmp eq i32 %context.value.485, 0
  br i1 %runtime.ok.486, label %runtime.continue.487, label %frame.failure.0
runtime.continue.487:
  %stack.offset.488 = add i32 %stack.offset.40, 8
  %cursor.check.489 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.488)
  %cursor.ok.490 = icmp eq i32 %cursor.check.489, 0
  br i1 %cursor.ok.490, label %cursor.continue.491, label %frame.failure.0
cursor.continue.491:
  %stack.offset.492 = add i32 %stack.offset.40, 8
  %cursor.check.493 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.492)
  %cursor.ok.494 = icmp eq i32 %cursor.check.493, 0
  br i1 %cursor.ok.494, label %cursor.continue.495, label %frame.failure.0
cursor.continue.495:
  br label %if.join.469
if.else.468:
  %step.status.496 = call i32 @al_owning_charge_step(ptr %ctx, i32 109)
  %step.ok.497 = icmp eq i32 %step.status.496, 0
  br i1 %step.ok.497, label %step.continue.498, label %frame.failure.0
step.continue.498:
  %step.status.499 = call i32 @al_owning_charge_step(ptr %ctx, i32 110)
  %step.ok.500 = icmp eq i32 %step.status.499, 0
  br i1 %step.ok.500, label %step.continue.501, label %frame.failure.0
step.continue.501:
  %stack.offset.502 = add i32 %stack.offset.40, 8
  %reserve.status.503 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.502, i32 111)
  %reserve.ok.504 = icmp eq i32 %reserve.status.503, 0
  br i1 %reserve.ok.504, label %reserve.continue.505, label %frame.failure.0
reserve.continue.505:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.40, i64 2, i32 1)
  %context.field.506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.507 = load i32, ptr %context.field.506, align 4
  %runtime.ok.508 = icmp eq i32 %context.value.507, 0
  br i1 %runtime.ok.508, label %runtime.continue.509, label %frame.failure.0
runtime.continue.509:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.510 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.511 = load i32, ptr %context.field.510, align 4
  %runtime.ok.512 = icmp eq i32 %context.value.511, 0
  br i1 %runtime.ok.512, label %runtime.continue.513, label %frame.failure.0
runtime.continue.513:
  %stack.offset.514 = add i32 %stack.offset.40, 8
  %cursor.check.515 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.514)
  %cursor.ok.516 = icmp eq i32 %cursor.check.515, 0
  br i1 %cursor.ok.516, label %cursor.continue.517, label %frame.failure.0
cursor.continue.517:
  %stack.offset.518 = add i32 %stack.offset.40, 8
  %cursor.check.519 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.518)
  %cursor.ok.520 = icmp eq i32 %cursor.check.519, 0
  br i1 %cursor.ok.520, label %cursor.continue.521, label %frame.failure.0
cursor.continue.521:
  br label %if.join.469
if.join.469:
  %stack.offset.522 = add i32 %stack.offset.40, 8
  %cursor.check.523 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.522)
  %cursor.ok.524 = icmp eq i32 %cursor.check.523, 0
  br i1 %cursor.ok.524, label %cursor.continue.525, label %frame.failure.0
cursor.continue.525:
  %step.status.526 = call i32 @al_owning_charge_step(ptr %ctx, i32 112)
  %step.ok.527 = icmp eq i32 %step.status.526, 0
  br i1 %step.ok.527, label %step.continue.528, label %frame.failure.0
step.continue.528:
  %local.is.active.529 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.530 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.531 = select i1 %local.is.active.529, i32 %local.previous.payload.530, i32 0
  %stack.offset.532 = add i32 %context.value.39, 56
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.532, i32 %stack.offset.40, i32 8, i32 8, i32 8, i32 %local.old.payload.531, i32 1)
  %context.field.533 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.534 = load i32, ptr %context.field.533, align 4
  %runtime.ok.535 = icmp eq i32 %context.value.534, 0
  br i1 %runtime.ok.535, label %runtime.continue.536, label %frame.failure.0
runtime.continue.536:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.537 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.538 = load i32, ptr %context.field.537, align 4
  %runtime.ok.539 = icmp eq i32 %context.value.538, 0
  br i1 %runtime.ok.539, label %runtime.continue.540, label %frame.failure.0
runtime.continue.540:
  %cursor.check.541 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.542 = icmp eq i32 %cursor.check.541, 0
  br i1 %cursor.ok.542, label %cursor.continue.543, label %frame.failure.0
cursor.continue.543:
  %step.status.544 = call i32 @al_owning_charge_step(ptr %ctx, i32 113)
  %step.ok.545 = icmp eq i32 %step.status.544, 0
  br i1 %step.ok.545, label %step.continue.546, label %frame.failure.0
step.continue.546:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %step.status.547 = call i32 @al_owning_charge_step(ptr %ctx, i32 114)
  %step.ok.548 = icmp eq i32 %step.status.547, 0
  br i1 %step.ok.548, label %step.continue.549, label %frame.failure.0
step.continue.549:
  %stack.offset.550 = add i32 %stack.offset.40, 24
  %reserve.status.551 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.550, i32 115)
  %reserve.ok.552 = icmp eq i32 %reserve.status.551, 0
  br i1 %reserve.ok.552, label %reserve.continue.553, label %frame.failure.0
reserve.continue.553:
  %stack.offset.554 = add i32 %context.value.39, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.554, i32 24, i32 24, i32 7)
  %context.field.555 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.556 = load i32, ptr %context.field.555, align 4
  %runtime.ok.557 = icmp eq i32 %context.value.556, 0
  br i1 %runtime.ok.557, label %runtime.continue.558, label %frame.failure.0
runtime.continue.558:
  %stack.offset.559 = add i32 %stack.offset.40, 24
  %cursor.check.560 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.559)
  %cursor.ok.561 = icmp eq i32 %cursor.check.560, 0
  br i1 %cursor.ok.561, label %cursor.continue.562, label %frame.failure.0
cursor.continue.562:
  %step.status.563 = call i32 @al_owning_charge_step(ptr %ctx, i32 116)
  %step.ok.564 = icmp eq i32 %step.status.563, 0
  br i1 %step.ok.564, label %step.continue.565, label %frame.failure.0
step.continue.565:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 8, i32 8, i32 1, i32 7)
  %context.field.566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.567 = load i32, ptr %context.field.566, align 4
  %runtime.ok.568 = icmp eq i32 %context.value.567, 0
  br i1 %runtime.ok.568, label %runtime.continue.569, label %frame.failure.0
runtime.continue.569:
  %stack.offset.570 = add i32 %stack.offset.40, 8
  %stack.offset.571 = add i32 %stack.offset.40, 24
  %field.grows.572 = icmp ugt i32 %stack.offset.570, %stack.offset.571
  br i1 %field.grows.572, label %field.reserve.573, label %field.release.574
field.reserve.573:
  %reserve.status.576 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.570, i32 117)
  %reserve.ok.577 = icmp eq i32 %reserve.status.576, 0
  br i1 %reserve.ok.577, label %reserve.continue.578, label %frame.failure.0
reserve.continue.578:
  br label %field.ready.575
field.release.574:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.570, i32 0, i32 1, i32 8)
  %context.field.579 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.580 = load i32, ptr %context.field.579, align 4
  %runtime.ok.581 = icmp eq i32 %context.value.580, 0
  br i1 %runtime.ok.581, label %runtime.continue.582, label %frame.failure.0
runtime.continue.582:
  br label %field.ready.575
field.ready.575:
  call void @al_owning_update_live(ptr %ctx, i32 -16, i32 0)
  %context.field.583 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.584 = load i32, ptr %context.field.583, align 4
  %runtime.ok.585 = icmp eq i32 %context.value.584, 0
  br i1 %runtime.ok.585, label %runtime.continue.586, label %frame.failure.0
runtime.continue.586:
  %stack.offset.587 = add i32 %stack.offset.40, 8
  %cursor.check.588 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.587)
  %cursor.ok.589 = icmp eq i32 %cursor.check.588, 0
  br i1 %cursor.ok.589, label %cursor.continue.590, label %frame.failure.0
cursor.continue.590:
  %step.status.591 = call i32 @al_owning_charge_step(ptr %ctx, i32 118)
  %step.ok.592 = icmp eq i32 %step.status.591, 0
  br i1 %step.ok.592, label %step.continue.593, label %frame.failure.0
step.continue.593:
  %stack.offset.594 = add i32 %stack.offset.40, 8
  %stack.offset.595 = add i32 %stack.offset.594, 8
  %reserve.status.596 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.595, i32 119)
  %reserve.ok.597 = icmp eq i32 %reserve.status.596, 0
  br i1 %reserve.ok.597, label %reserve.continue.598, label %frame.failure.0
reserve.continue.598:
  %stack.offset.599 = add i32 %context.value.39, 56
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.594, i32 %stack.offset.599, i32 8, i32 8, i32 1)
  %context.field.600 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.601 = load i32, ptr %context.field.600, align 4
  %runtime.ok.602 = icmp eq i32 %context.value.601, 0
  br i1 %runtime.ok.602, label %runtime.continue.603, label %frame.failure.0
runtime.continue.603:
  %stack.offset.604 = add i32 %stack.offset.40, 16
  %cursor.check.605 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.604)
  %cursor.ok.606 = icmp eq i32 %cursor.check.605, 0
  br i1 %cursor.ok.606, label %cursor.continue.607, label %frame.failure.0
cursor.continue.607:
  %step.status.608 = call i32 @al_owning_charge_step(ptr %ctx, i32 120)
  %step.ok.609 = icmp eq i32 %step.status.608, 0
  br i1 %step.ok.609, label %step.continue.610, label %frame.failure.0
step.continue.610:
  %stack.offset.611 = add i32 %stack.offset.40, 8
  %integer.left.612 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.40)
  %context.field.614 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.615 = load i32, ptr %context.field.614, align 4
  %runtime.ok.616 = icmp eq i32 %context.value.615, 0
  br i1 %runtime.ok.616, label %runtime.continue.617, label %frame.failure.0
runtime.continue.617:
  %integer.right.613 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.611)
  %context.field.618 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.619 = load i32, ptr %context.field.618, align 4
  %runtime.ok.620 = icmp eq i32 %context.value.619, 0
  br i1 %runtime.ok.620, label %runtime.continue.621, label %frame.failure.0
runtime.continue.621:
  %integer.checked.622 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.612, i64 %integer.right.613)
  %integer.result.623 = extractvalue { i64, i1 } %integer.checked.622, 0
  %integer.overflow.624 = extractvalue { i64, i1 } %integer.checked.622, 1
  br i1 %integer.overflow.624, label %integer.overflow.failure.626, label %integer.nooverflow.625
integer.overflow.failure.626:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 121, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.625:
  %stack.offset.627 = add i32 %stack.offset.40, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.627, i32 8, i32 8, i32 1)
  %context.field.628 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.629 = load i32, ptr %context.field.628, align 4
  %runtime.ok.630 = icmp eq i32 %context.value.629, 0
  br i1 %runtime.ok.630, label %runtime.continue.631, label %frame.failure.0
runtime.continue.631:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.632 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.633 = load i32, ptr %context.field.632, align 4
  %runtime.ok.634 = icmp eq i32 %context.value.633, 0
  br i1 %runtime.ok.634, label %runtime.continue.635, label %frame.failure.0
runtime.continue.635:
  %stack.offset.636 = add i32 %stack.offset.40, 8
  %reserve.status.637 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.636, i32 122)
  %reserve.ok.638 = icmp eq i32 %reserve.status.637, 0
  br i1 %reserve.ok.638, label %reserve.continue.639, label %frame.failure.0
reserve.continue.639:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.40, i64 %integer.result.623, i32 1)
  %context.field.640 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.641 = load i32, ptr %context.field.640, align 4
  %runtime.ok.642 = icmp eq i32 %context.value.641, 0
  br i1 %runtime.ok.642, label %runtime.continue.643, label %frame.failure.0
runtime.continue.643:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.644 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.645 = load i32, ptr %context.field.644, align 4
  %runtime.ok.646 = icmp eq i32 %context.value.645, 0
  br i1 %runtime.ok.646, label %runtime.continue.647, label %frame.failure.0
runtime.continue.647:
  %stack.offset.648 = add i32 %stack.offset.40, 8
  %cursor.check.649 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.648)
  %cursor.ok.650 = icmp eq i32 %cursor.check.649, 0
  br i1 %cursor.ok.650, label %cursor.continue.651, label %frame.failure.0
cursor.continue.651:
  %step.status.652 = call i32 @al_owning_charge_step(ptr %ctx, i32 123)
  %step.ok.653 = icmp eq i32 %step.status.652, 0
  br i1 %step.ok.653, label %step.continue.654, label %frame.failure.0
step.continue.654:
  %local.is.active.655 = load i1, ptr %local.active.21, align 1
  %local.previous.payload.656 = load i32, ptr %local.payload.22, align 4
  %local.old.payload.657 = select i1 %local.is.active.655, i32 %local.previous.payload.656, i32 0
  %stack.offset.658 = add i32 %context.value.39, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.658, i32 %stack.offset.40, i32 8, i32 8, i32 8, i32 %local.old.payload.657, i32 1)
  %context.field.659 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.660 = load i32, ptr %context.field.659, align 4
  %runtime.ok.661 = icmp eq i32 %context.value.660, 0
  br i1 %runtime.ok.661, label %runtime.continue.662, label %frame.failure.0
runtime.continue.662:
  store i1 true, ptr %local.active.21, align 1
  store i32 8, ptr %local.payload.22, align 4
  store i32 1, ptr %local.type.23, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 8, i32 8, i32 1)
  %context.field.663 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.664 = load i32, ptr %context.field.663, align 4
  %runtime.ok.665 = icmp eq i32 %context.value.664, 0
  br i1 %runtime.ok.665, label %runtime.continue.666, label %frame.failure.0
runtime.continue.666:
  %cursor.check.667 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.668 = icmp eq i32 %cursor.check.667, 0
  br i1 %cursor.ok.668, label %cursor.continue.669, label %frame.failure.0
cursor.continue.669:
  %step.status.670 = call i32 @al_owning_charge_step(ptr %ctx, i32 124)
  %step.ok.671 = icmp eq i32 %step.status.670, 0
  br i1 %step.ok.671, label %step.continue.672, label %frame.failure.0
step.continue.672:
  %stack.offset.673 = add i32 %stack.offset.40, 16
  %reserve.status.674 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.673, i32 125)
  %reserve.ok.675 = icmp eq i32 %reserve.status.674, 0
  br i1 %reserve.ok.675, label %reserve.continue.676, label %frame.failure.0
reserve.continue.676:
  %stack.offset.677 = add i32 %context.value.39, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.677, i32 16, i32 16, i32 5)
  %context.field.678 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.679 = load i32, ptr %context.field.678, align 4
  %runtime.ok.680 = icmp eq i32 %context.value.679, 0
  br i1 %runtime.ok.680, label %runtime.continue.681, label %frame.failure.0
runtime.continue.681:
  %stack.offset.682 = add i32 %stack.offset.40, 16
  %cursor.check.683 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.682)
  %cursor.ok.684 = icmp eq i32 %cursor.check.683, 0
  br i1 %cursor.ok.684, label %cursor.continue.685, label %frame.failure.0
cursor.continue.685:
  %step.status.686 = call i32 @al_owning_charge_step(ptr %ctx, i32 126)
  %step.ok.687 = icmp eq i32 %step.status.686, 0
  br i1 %step.ok.687, label %step.continue.688, label %frame.failure.0
step.continue.688:
  %local.is.active.689 = load i1, ptr %local.active.24, align 1
  %local.previous.payload.690 = load i32, ptr %local.payload.25, align 4
  %local.old.payload.691 = select i1 %local.is.active.689, i32 %local.previous.payload.690, i32 0
  %stack.offset.692 = add i32 %context.value.39, 72
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.692, i32 %stack.offset.40, i32 16, i32 16, i32 16, i32 %local.old.payload.691, i32 5)
  %context.field.693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.694 = load i32, ptr %context.field.693, align 4
  %runtime.ok.695 = icmp eq i32 %context.value.694, 0
  br i1 %runtime.ok.695, label %runtime.continue.696, label %frame.failure.0
runtime.continue.696:
  store i1 true, ptr %local.active.24, align 1
  store i32 16, ptr %local.payload.25, align 4
  store i32 5, ptr %local.type.26, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.40, i32 16, i32 16, i32 5)
  %context.field.697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.698 = load i32, ptr %context.field.697, align 4
  %runtime.ok.699 = icmp eq i32 %context.value.698, 0
  br i1 %runtime.ok.699, label %runtime.continue.700, label %frame.failure.0
runtime.continue.700:
  %cursor.check.701 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.40)
  %cursor.ok.702 = icmp eq i32 %cursor.check.701, 0
  br i1 %cursor.ok.702, label %cursor.continue.703, label %frame.failure.0
cursor.continue.703:
  %step.status.704 = call i32 @al_owning_charge_step(ptr %ctx, i32 127)
  %step.ok.705 = icmp eq i32 %step.status.704, 0
  br i1 %step.ok.705, label %step.continue.706, label %frame.failure.0
step.continue.706:
  %stack.offset.707 = add i32 %stack.offset.40, 8
  %reserve.status.708 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.707, i32 128)
  %reserve.ok.709 = icmp eq i32 %reserve.status.708, 0
  br i1 %reserve.ok.709, label %reserve.continue.710, label %frame.failure.0
reserve.continue.710:
  %stack.offset.711 = add i32 %context.value.39, 64
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.711, i32 8, i32 8, i32 1)
  %context.field.712 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.713 = load i32, ptr %context.field.712, align 4
  %runtime.ok.714 = icmp eq i32 %context.value.713, 0
  br i1 %runtime.ok.714, label %runtime.continue.715, label %frame.failure.0
runtime.continue.715:
  %stack.offset.716 = add i32 %stack.offset.40, 8
  %cursor.check.717 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.716)
  %cursor.ok.718 = icmp eq i32 %cursor.check.717, 0
  br i1 %cursor.ok.718, label %cursor.continue.719, label %frame.failure.0
cursor.continue.719:
  %step.status.720 = call i32 @al_owning_charge_step(ptr %ctx, i32 129)
  %step.ok.721 = icmp eq i32 %step.status.720, 0
  br i1 %step.ok.721, label %step.continue.722, label %frame.failure.0
step.continue.722:
  %stack.offset.723 = add i32 %stack.offset.40, 8
  %stack.offset.724 = add i32 %stack.offset.723, 16
  %reserve.status.725 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.724, i32 130)
  %reserve.ok.726 = icmp eq i32 %reserve.status.725, 0
  br i1 %reserve.ok.726, label %reserve.continue.727, label %frame.failure.0
reserve.continue.727:
  %stack.offset.728 = add i32 %context.value.39, 72
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.723, i32 %stack.offset.728, i32 16, i32 16, i32 5)
  %context.field.729 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.730 = load i32, ptr %context.field.729, align 4
  %runtime.ok.731 = icmp eq i32 %context.value.730, 0
  br i1 %runtime.ok.731, label %runtime.continue.732, label %frame.failure.0
runtime.continue.732:
  %stack.offset.733 = add i32 %stack.offset.40, 24
  %cursor.check.734 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.733)
  %cursor.ok.735 = icmp eq i32 %cursor.check.734, 0
  br i1 %cursor.ok.735, label %cursor.continue.736, label %frame.failure.0
cursor.continue.736:
  %step.status.737 = call i32 @al_owning_charge_step(ptr %ctx, i32 131)
  %step.ok.738 = icmp eq i32 %step.status.737, 0
  br i1 %step.ok.738, label %step.continue.739, label %frame.failure.0
step.continue.739:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.40, i32 %stack.offset.40, i32 8, i32 8, i32 1, i32 6)
  %context.field.740 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.741 = load i32, ptr %context.field.740, align 4
  %runtime.ok.742 = icmp eq i32 %context.value.741, 0
  br i1 %runtime.ok.742, label %runtime.continue.743, label %frame.failure.0
runtime.continue.743:
  %stack.offset.744 = add i32 %stack.offset.40, 8
  %stack.offset.745 = add i32 %stack.offset.40, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.744, i32 %stack.offset.745, i32 16, i32 16, i32 5, i32 6)
  %context.field.746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.747 = load i32, ptr %context.field.746, align 4
  %runtime.ok.748 = icmp eq i32 %context.value.747, 0
  br i1 %runtime.ok.748, label %runtime.continue.749, label %frame.failure.0
runtime.continue.749:
  %stack.offset.750 = add i32 %stack.offset.40, 24
  %stack.offset.751 = add i32 %stack.offset.40, 24
  %record.grows.752 = icmp ugt i32 %stack.offset.750, %stack.offset.751
  br i1 %record.grows.752, label %record.reserve.753, label %record.release.754
record.reserve.753:
  %reserve.status.756 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.750, i32 132)
  %reserve.ok.757 = icmp eq i32 %reserve.status.756, 0
  br i1 %reserve.ok.757, label %reserve.continue.758, label %frame.failure.0
reserve.continue.758:
  br label %record.ready.755
record.release.754:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.750, i32 0, i32 7, i32 24)
  %context.field.759 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.760 = load i32, ptr %context.field.759, align 4
  %runtime.ok.761 = icmp eq i32 %context.value.760, 0
  br i1 %runtime.ok.761, label %runtime.continue.762, label %frame.failure.0
runtime.continue.762:
  br label %record.ready.755
record.ready.755:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 7, i32 %stack.offset.40, i32 24, i32 24, i32 0, i32 0)
  %context.field.763 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.764 = load i32, ptr %context.field.763, align 4
  %runtime.ok.765 = icmp eq i32 %context.value.764, 0
  br i1 %runtime.ok.765, label %runtime.continue.766, label %frame.failure.0
runtime.continue.766:
  %stack.offset.767 = add i32 %stack.offset.40, 24
  %cursor.check.768 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.767)
  %cursor.ok.769 = icmp eq i32 %cursor.check.768, 0
  br i1 %cursor.ok.769, label %cursor.continue.770, label %frame.failure.0
cursor.continue.770:
  %local.is.active.771 = load i1, ptr %local.active.21, align 1
  %local.clear.payload.772 = load i32, ptr %local.payload.22, align 4
  %local.clear.type.773 = load i32, ptr %local.type.23, align 4
  %local.clear.live.payload.774 = select i1 %local.is.active.771, i32 %local.clear.payload.772, i32 0
  %local.clear.live.type.775 = select i1 %local.is.active.771, i32 %local.clear.type.773, i32 0
  %stack.offset.776 = add i32 %context.value.39, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.776, i32 8, i32 %local.clear.live.payload.774, i32 %local.clear.live.type.775)
  %context.field.777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.778 = load i32, ptr %context.field.777, align 4
  %runtime.ok.779 = icmp eq i32 %context.value.778, 0
  br i1 %runtime.ok.779, label %runtime.continue.780, label %frame.failure.0
runtime.continue.780:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %local.is.active.781 = load i1, ptr %local.active.24, align 1
  %local.clear.payload.782 = load i32, ptr %local.payload.25, align 4
  %local.clear.type.783 = load i32, ptr %local.type.26, align 4
  %local.clear.live.payload.784 = select i1 %local.is.active.781, i32 %local.clear.payload.782, i32 0
  %local.clear.live.type.785 = select i1 %local.is.active.781, i32 %local.clear.type.783, i32 0
  %stack.offset.786 = add i32 %context.value.39, 72
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.786, i32 16, i32 %local.clear.live.payload.784, i32 %local.clear.live.type.785)
  %context.field.787 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.788 = load i32, ptr %context.field.787, align 4
  %runtime.ok.789 = icmp eq i32 %context.value.788, 0
  br i1 %runtime.ok.789, label %runtime.continue.790, label %frame.failure.0
runtime.continue.790:
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %stack.offset.791 = add i32 %stack.offset.40, 24
  %cursor.check.792 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.791)
  %cursor.ok.793 = icmp eq i32 %cursor.check.792, 0
  br i1 %cursor.ok.793, label %cursor.continue.794, label %frame.failure.0
cursor.continue.794:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.40, i32 24, i32 24, i32 7, i32 9)
  %context.field.795 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.796 = load i32, ptr %context.field.795, align 4
  %runtime.ok.797 = icmp eq i32 %context.value.796, 0
  br i1 %runtime.ok.797, label %runtime.continue.798, label %frame.failure.0
runtime.continue.798:
  %local.is.active.799 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.800 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.801 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.802 = select i1 %local.is.active.799, i32 %local.clear.payload.800, i32 0
  %local.clear.live.type.803 = select i1 %local.is.active.799, i32 %local.clear.type.801, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.39, i32 8, i32 %local.clear.live.payload.802, i32 %local.clear.live.type.803)
  %context.field.804 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.805 = load i32, ptr %context.field.804, align 4
  %runtime.ok.806 = icmp eq i32 %context.value.805, 0
  br i1 %runtime.ok.806, label %runtime.continue.807, label %frame.failure.0
runtime.continue.807:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.808 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.809 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.810 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.811 = select i1 %local.is.active.808, i32 %local.clear.payload.809, i32 0
  %local.clear.live.type.812 = select i1 %local.is.active.808, i32 %local.clear.type.810, i32 0
  %stack.offset.813 = add i32 %context.value.39, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.813, i32 24, i32 %local.clear.live.payload.811, i32 %local.clear.live.type.812)
  %context.field.814 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.815 = load i32, ptr %context.field.814, align 4
  %runtime.ok.816 = icmp eq i32 %context.value.815, 0
  br i1 %runtime.ok.816, label %runtime.continue.817, label %frame.failure.0
runtime.continue.817:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.818 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.819 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.820 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.821 = select i1 %local.is.active.818, i32 %local.clear.payload.819, i32 0
  %local.clear.live.type.822 = select i1 %local.is.active.818, i32 %local.clear.type.820, i32 0
  %stack.offset.823 = add i32 %context.value.39, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.823, i32 16, i32 %local.clear.live.payload.821, i32 %local.clear.live.type.822)
  %context.field.824 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.825 = load i32, ptr %context.field.824, align 4
  %runtime.ok.826 = icmp eq i32 %context.value.825, 0
  br i1 %runtime.ok.826, label %runtime.continue.827, label %frame.failure.0
runtime.continue.827:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.is.active.828 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.829 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.830 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.831 = select i1 %local.is.active.828, i32 %local.clear.payload.829, i32 0
  %local.clear.live.type.832 = select i1 %local.is.active.828, i32 %local.clear.type.830, i32 0
  %stack.offset.833 = add i32 %context.value.39, 48
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.833, i32 8, i32 %local.clear.live.payload.831, i32 %local.clear.live.type.832)
  %context.field.834 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.835 = load i32, ptr %context.field.834, align 4
  %runtime.ok.836 = icmp eq i32 %context.value.835, 0
  br i1 %runtime.ok.836, label %runtime.continue.837, label %frame.failure.0
runtime.continue.837:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.is.active.838 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.839 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.840 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.841 = select i1 %local.is.active.838, i32 %local.clear.payload.839, i32 0
  %local.clear.live.type.842 = select i1 %local.is.active.838, i32 %local.clear.type.840, i32 0
  %stack.offset.843 = add i32 %context.value.39, 56
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.843, i32 8, i32 %local.clear.live.payload.841, i32 %local.clear.live.type.842)
  %context.field.844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.845 = load i32, ptr %context.field.844, align 4
  %runtime.ok.846 = icmp eq i32 %context.value.845, 0
  br i1 %runtime.ok.846, label %runtime.continue.847, label %frame.failure.0
runtime.continue.847:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  call void @al_owning_local_release(ptr %ctx, i32 88)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.28, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.28, i32 0, i32 0, i32 0)
  %context.field.848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.849 = load i32, ptr %context.field.848, align 4
  %context.field.850 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.851 = load i32, ptr %context.field.850, align 4
  %context.field.852 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.853 = load i32, ptr %context.field.852, align 4
  %baseline.live.total.854 = add i32 %context.value.30, %context.value.32
  %current.live.total.855 = add i32 %context.value.849, %context.value.851
  %cleanup.live.delta.856 = sub i32 %baseline.live.total.854, %current.live.total.855
  %cleanup.local.delta.857 = sub i32 %context.value.32, %context.value.851
  %cleanup.reserved.delta.858 = sub i32 %context.value.853, %context.value.34
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.856, i32 %cleanup.local.delta.857)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.858)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 32
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 32, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 32, i32 133)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 24, i32 24, i32 7)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %input.pointer.17 = getelementptr inbounds i8, ptr %input, i32 24
  call void @al_owning_copy_external(ptr %ctx, i32 24, ptr %input.pointer.17, i32 8, i32 8, i32 1)
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %runtime.ok.20 = icmp eq i32 %context.value.19, 0
  br i1 %runtime.ok.20, label %runtime.continue.21, label %entry.failure.0
runtime.continue.21:
  %entry.body.status.22 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.23 = icmp eq i32 %entry.body.status.22, 0
  br i1 %entry.body.ok.23, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.31 = load i32, ptr %context.field.30, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.32 = add i32 %context.value.27, %context.value.29
  %entry.failure.delta.33 = sub i32 0, %entry.failure.live.32
  %entry.failure.local.delta.34 = sub i32 0, %context.value.29
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.33, i32 %entry.failure.local.delta.34)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.31)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 24, i32 7)
  %context.field.35 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.36 = load i32, ptr %context.field.35, align 4
  %runtime.ok.37 = icmp eq i32 %context.value.36, 0
  br i1 %runtime.ok.37, label %runtime.continue.38, label %entry.failure.0
runtime.continue.38:
  call void @al_owning_update_live(ptr %ctx, i32 -24, i32 0)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %entry.failure.0
runtime.continue.42:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.50 = load i32, ptr %context.field.49, align 4
  %entry.cleanup.total.live.51 = add i32 %context.value.46, %context.value.48
  %entry.cleanup.live.delta.52 = sub i32 0, %entry.cleanup.total.live.51
  %entry.cleanup.local.delta.53 = sub i32 0, %context.value.48
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.52, i32 %entry.cleanup.local.delta.53)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.50)
  br label %entry.return.status
entry.return.status:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  ret i32 %context.value.55
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_copy_external(ptr, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare void @al_owning_store_local(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_clear_local(ptr, i32, i32, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %context.field.5 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.6 = load i32, ptr %context.field.5, align 4
  %context.field.7 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.8 = load i32, ptr %context.field.7, align 4
  %context.field.9 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.10 = load i32, ptr %context.field.9, align 4
  %frame.entered.11 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.12 = icmp eq i32 %frame.entered.11, 0
  br i1 %frame.entered.ok.12, label %frame.entered.continue.13, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.13:
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %stack.offset.16 = add i32 %context.value.15, 32
  %reserve.status.17 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.16, i32 1)
  %reserve.ok.18 = icmp eq i32 %reserve.status.17, 0
  br i1 %reserve.ok.18, label %reserve.continue.19, label %frame.reserve.failure.1
reserve.continue.19:
  call void @al_owning_local_reserve(ptr %ctx, i32 0)
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %runtime.ok.22 = icmp eq i32 %context.value.21, 0
  br i1 %runtime.ok.22, label %runtime.continue.23, label %frame.failure.0
runtime.continue.23:
  %stack.offset.24 = add i32 %argument.source, 24
  %stack.offset.25 = add i32 %context.value.15, 24
  call void @al_owning_move_range(ptr %ctx, i32 %context.value.15, i32 %argument.source, i32 24, i32 24, i32 7, i32 8)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.25, i32 %stack.offset.24, i32 8, i32 8, i32 1, i32 8)
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %runtime.ok.32 = icmp eq i32 %context.value.31, 0
  br i1 %runtime.ok.32, label %runtime.continue.33, label %frame.failure.0
runtime.continue.33:
  %step.status.34 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %step.ok.35 = icmp eq i32 %step.status.34, 0
  br i1 %step.ok.35, label %step.continue.36, label %frame.failure.0
step.continue.36:
  %stack.offset.37 = add i32 %context.value.15, 32
  %reserve.status.38 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.37, i32 3)
  %reserve.ok.39 = icmp eq i32 %reserve.status.38, 0
  br i1 %reserve.ok.39, label %reserve.continue.40, label %frame.failure.0
reserve.continue.40:
  %callee.status.41 = call i32 @agentlang_word_0002(ptr %ctx, i32 %context.value.15, i32 %context.value.15, i32 4)
  %callee.ok.42 = icmp eq i32 %callee.status.41, 0
  br i1 %callee.ok.42, label %callee.returned.43, label %frame.failure.0
callee.returned.43:
  %stack.offset.44 = add i32 %context.value.15, 24
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.44, i32 0, i32 0, i32 0)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  %stack.offset.49 = add i32 %context.value.15, 24
  %cursor.check.50 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.49)
  %cursor.ok.51 = icmp eq i32 %cursor.check.50, 0
  br i1 %cursor.ok.51, label %cursor.continue.52, label %frame.failure.0
cursor.continue.52:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %context.value.15, i32 24, i32 24, i32 7, i32 9)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  call void @al_owning_local_release(ptr %ctx, i32 0)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.4, i32 0, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %baseline.live.total.63 = add i32 %context.value.6, %context.value.8
  %current.live.total.64 = add i32 %context.value.58, %context.value.60
  %cleanup.live.delta.65 = sub i32 %baseline.live.total.63, %current.live.total.64
  %cleanup.local.delta.66 = sub i32 %context.value.8, %context.value.60
  %cleanup.reserved.delta.67 = sub i32 %context.value.62, %context.value.10
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.65, i32 %cleanup.local.delta.66)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.67)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %frame.entered.26 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.27 = icmp eq i32 %frame.entered.26, 0
  br i1 %frame.entered.ok.27, label %frame.entered.continue.28, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.28:
  %context.field.29 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.30 = load i32, ptr %context.field.29, align 4
  %stack.offset.31 = add i32 %context.value.30, 56
  %stack.offset.32 = add i32 %context.value.30, 64
  %reserve.status.33 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.32, i32 5)
  %reserve.ok.34 = icmp eq i32 %reserve.status.33, 0
  br i1 %reserve.ok.34, label %reserve.continue.35, label %frame.reserve.failure.1
reserve.continue.35:
  call void @al_owning_local_reserve(ptr %ctx, i32 56)
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %runtime.ok.38 = icmp eq i32 %context.value.37, 0
  br i1 %runtime.ok.38, label %runtime.continue.39, label %frame.failure.0
runtime.continue.39:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %runtime.ok.42 = icmp eq i32 %context.value.41, 0
  br i1 %runtime.ok.42, label %runtime.continue.43, label %frame.failure.0
runtime.continue.43:
  %step.status.44 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %step.ok.45 = icmp eq i32 %step.status.44, 0
  br i1 %step.ok.45, label %step.continue.46, label %frame.failure.0
step.continue.46:
  %local.is.active.47 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.48 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.49 = select i1 %local.is.active.47, i32 %local.previous.payload.48, i32 0
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.30, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.49, i32 1)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %runtime.ok.56 = icmp eq i32 %context.value.55, 0
  br i1 %runtime.ok.56, label %runtime.continue.57, label %frame.failure.0
runtime.continue.57:
  %cursor.check.58 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.59 = icmp eq i32 %cursor.check.58, 0
  br i1 %cursor.ok.59, label %cursor.continue.60, label %frame.failure.0
cursor.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %step.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %step.ok.62, label %step.continue.63, label %frame.failure.0
step.continue.63:
  %stack.offset.64 = add i32 %stack.offset.31, 8
  %reserve.status.65 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.64, i32 8)
  %reserve.ok.66 = icmp eq i32 %reserve.status.65, 0
  br i1 %reserve.ok.66, label %reserve.continue.67, label %frame.failure.0
reserve.continue.67:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %context.value.30, i32 8, i32 8, i32 1)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %stack.offset.72 = add i32 %stack.offset.31, 8
  %cursor.check.73 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.72)
  %cursor.ok.74 = icmp eq i32 %cursor.check.73, 0
  br i1 %cursor.ok.74, label %cursor.continue.75, label %frame.failure.0
cursor.continue.75:
  %step.status.76 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %step.ok.77 = icmp eq i32 %step.status.76, 0
  br i1 %step.ok.77, label %step.continue.78, label %frame.failure.0
step.continue.78:
  %stack.offset.79 = add i32 %stack.offset.31, 8
  %stack.offset.80 = add i32 %stack.offset.79, 8
  %reserve.status.81 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.80, i32 10)
  %reserve.ok.82 = icmp eq i32 %reserve.status.81, 0
  br i1 %reserve.ok.82, label %reserve.continue.83, label %frame.failure.0
reserve.continue.83:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.79, i32 %context.value.30, i32 8, i32 8, i32 1)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %stack.offset.88 = add i32 %stack.offset.31, 16
  %cursor.check.89 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.88)
  %cursor.ok.90 = icmp eq i32 %cursor.check.89, 0
  br i1 %cursor.ok.90, label %cursor.continue.91, label %frame.failure.0
cursor.continue.91:
  %step.status.92 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %step.ok.93 = icmp eq i32 %step.status.92, 0
  br i1 %step.ok.93, label %step.continue.94, label %frame.failure.0
step.continue.94:
  %stack.offset.95 = add i32 %stack.offset.31, 16
  %stack.offset.96 = add i32 %stack.offset.95, 8
  %reserve.status.97 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.96, i32 12)
  %reserve.ok.98 = icmp eq i32 %reserve.status.97, 0
  br i1 %reserve.ok.98, label %reserve.continue.99, label %frame.failure.0
reserve.continue.99:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.95, i64 100, i32 1)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %stack.offset.108 = add i32 %stack.offset.31, 24
  %cursor.check.109 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.108)
  %cursor.ok.110 = icmp eq i32 %cursor.check.109, 0
  br i1 %cursor.ok.110, label %cursor.continue.111, label %frame.failure.0
cursor.continue.111:
  %step.status.112 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %step.ok.113 = icmp eq i32 %step.status.112, 0
  br i1 %step.ok.113, label %step.continue.114, label %frame.failure.0
step.continue.114:
  %stack.offset.115 = add i32 %stack.offset.31, 8
  %stack.offset.116 = add i32 %stack.offset.31, 16
  %integer.left.117 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.115)
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %runtime.ok.121 = icmp eq i32 %context.value.120, 0
  br i1 %runtime.ok.121, label %runtime.continue.122, label %frame.failure.0
runtime.continue.122:
  %integer.right.118 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.116)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %integer.checked.127 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.117, i64 %integer.right.118)
  %integer.result.128 = extractvalue { i64, i1 } %integer.checked.127, 0
  %integer.overflow.129 = extractvalue { i64, i1 } %integer.checked.127, 1
  br i1 %integer.overflow.129, label %integer.overflow.failure.131, label %integer.nooverflow.130
integer.overflow.failure.131:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.130:
  %stack.offset.132 = add i32 %stack.offset.31, 8
  %stack.offset.133 = add i32 %stack.offset.31, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.133, i32 8, i32 8, i32 1)
  %context.field.134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.135 = load i32, ptr %context.field.134, align 4
  %runtime.ok.136 = icmp eq i32 %context.value.135, 0
  br i1 %runtime.ok.136, label %runtime.continue.137, label %frame.failure.0
runtime.continue.137:
  %stack.offset.138 = add i32 %stack.offset.31, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.138, i32 8, i32 8, i32 1)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %frame.failure.0
runtime.continue.142:
  %stack.offset.143 = add i32 %stack.offset.132, 8
  %reserve.status.144 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.143, i32 15)
  %reserve.ok.145 = icmp eq i32 %reserve.status.144, 0
  br i1 %reserve.ok.145, label %reserve.continue.146, label %frame.failure.0
reserve.continue.146:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.132, i64 %integer.result.128, i32 1)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  %stack.offset.155 = add i32 %stack.offset.31, 16
  %cursor.check.156 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.155)
  %cursor.ok.157 = icmp eq i32 %cursor.check.156, 0
  br i1 %cursor.ok.157, label %cursor.continue.158, label %frame.failure.0
cursor.continue.158:
  %step.status.159 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %step.ok.160 = icmp eq i32 %step.status.159, 0
  br i1 %step.ok.160, label %step.continue.161, label %frame.failure.0
step.continue.161:
  %stack.offset.162 = add i32 %stack.offset.31, 16
  %reserve.status.163 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.162, i32 17)
  %reserve.ok.164 = icmp eq i32 %reserve.status.163, 0
  br i1 %reserve.ok.164, label %reserve.continue.165, label %frame.failure.0
reserve.continue.165:
  %callee.status.166 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 18)
  %callee.ok.167 = icmp eq i32 %callee.status.166, 0
  br i1 %callee.ok.167, label %callee.returned.168, label %frame.failure.0
callee.returned.168:
  %stack.offset.169 = add i32 %stack.offset.31, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.169, i32 0, i32 0, i32 0)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 %stack.offset.31, 16
  %cursor.check.175 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.174)
  %cursor.ok.176 = icmp eq i32 %cursor.check.175, 0
  br i1 %cursor.ok.176, label %cursor.continue.177, label %frame.failure.0
cursor.continue.177:
  %step.status.178 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %step.ok.179 = icmp eq i32 %step.status.178, 0
  br i1 %step.ok.179, label %step.continue.180, label %frame.failure.0
step.continue.180:
  %stack.offset.181 = add i32 %stack.offset.31, 16
  %stack.offset.182 = add i32 %stack.offset.181, 16
  %reserve.status.183 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.182, i32 20)
  %reserve.ok.184 = icmp eq i32 %reserve.status.183, 0
  br i1 %reserve.ok.184, label %reserve.continue.185, label %frame.failure.0
reserve.continue.185:
  call void @al_owning_duplicate(ptr %ctx, i32 %stack.offset.181, i32 %stack.offset.31, i32 16, i32 16, i32 5)
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %runtime.ok.188 = icmp eq i32 %context.value.187, 0
  br i1 %runtime.ok.188, label %runtime.continue.189, label %frame.failure.0
runtime.continue.189:
  %stack.offset.190 = add i32 %stack.offset.31, 32
  %cursor.check.191 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.190)
  %cursor.ok.192 = icmp eq i32 %cursor.check.191, 0
  br i1 %cursor.ok.192, label %cursor.continue.193, label %frame.failure.0
cursor.continue.193:
  %step.status.194 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %step.ok.195 = icmp eq i32 %step.status.194, 0
  br i1 %step.ok.195, label %step.continue.196, label %frame.failure.0
step.continue.196:
  %local.is.active.197 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.198 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.199 = select i1 %local.is.active.197, i32 %local.previous.payload.198, i32 0
  %stack.offset.200 = add i32 %context.value.30, 8
  %stack.offset.201 = add i32 %stack.offset.31, 16
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.200, i32 %stack.offset.201, i32 16, i32 16, i32 16, i32 %local.old.payload.199, i32 5)
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %runtime.ok.204 = icmp eq i32 %context.value.203, 0
  br i1 %runtime.ok.204, label %runtime.continue.205, label %frame.failure.0
runtime.continue.205:
  store i1 true, ptr %local.active.6, align 1
  store i32 16, ptr %local.payload.7, align 4
  store i32 5, ptr %local.type.8, align 4
  %stack.offset.206 = add i32 %stack.offset.31, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.206, i32 16, i32 16, i32 5)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  %stack.offset.211 = add i32 %stack.offset.31, 16
  %cursor.check.212 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.211)
  %cursor.ok.213 = icmp eq i32 %cursor.check.212, 0
  br i1 %cursor.ok.213, label %cursor.continue.214, label %frame.failure.0
cursor.continue.214:
  %step.status.215 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %step.ok.216 = icmp eq i32 %step.status.215, 0
  br i1 %step.ok.216, label %step.continue.217, label %frame.failure.0
step.continue.217:
  %local.is.active.218 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.219 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.220 = select i1 %local.is.active.218, i32 %local.previous.payload.219, i32 0
  %stack.offset.221 = add i32 %context.value.30, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.221, i32 %stack.offset.31, i32 16, i32 16, i32 16, i32 %local.old.payload.220, i32 5)
  %context.field.222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.223 = load i32, ptr %context.field.222, align 4
  %runtime.ok.224 = icmp eq i32 %context.value.223, 0
  br i1 %runtime.ok.224, label %runtime.continue.225, label %frame.failure.0
runtime.continue.225:
  store i1 true, ptr %local.active.9, align 1
  store i32 16, ptr %local.payload.10, align 4
  store i32 5, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 16, i32 16, i32 5)
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %runtime.ok.228 = icmp eq i32 %context.value.227, 0
  br i1 %runtime.ok.228, label %runtime.continue.229, label %frame.failure.0
runtime.continue.229:
  %cursor.check.230 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.231 = icmp eq i32 %cursor.check.230, 0
  br i1 %cursor.ok.231, label %cursor.continue.232, label %frame.failure.0
cursor.continue.232:
  %step.status.233 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %step.ok.234 = icmp eq i32 %step.status.233, 0
  br i1 %step.ok.234, label %step.continue.235, label %frame.failure.0
step.continue.235:
  %stack.offset.236 = add i32 %stack.offset.31, 16
  %reserve.status.237 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.236, i32 24)
  %reserve.ok.238 = icmp eq i32 %reserve.status.237, 0
  br i1 %reserve.ok.238, label %reserve.continue.239, label %frame.failure.0
reserve.continue.239:
  %stack.offset.240 = add i32 %context.value.30, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.240, i32 16, i32 16, i32 5)
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %runtime.ok.243 = icmp eq i32 %context.value.242, 0
  br i1 %runtime.ok.243, label %runtime.continue.244, label %frame.failure.0
runtime.continue.244:
  %stack.offset.245 = add i32 %stack.offset.31, 16
  %cursor.check.246 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.245)
  %cursor.ok.247 = icmp eq i32 %cursor.check.246, 0
  br i1 %cursor.ok.247, label %cursor.continue.248, label %frame.failure.0
cursor.continue.248:
  %step.status.249 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %step.ok.250 = icmp eq i32 %step.status.249, 0
  br i1 %step.ok.250, label %step.continue.251, label %frame.failure.0
step.continue.251:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 6, i32 7)
  %context.field.252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.253 = load i32, ptr %context.field.252, align 4
  %runtime.ok.254 = icmp eq i32 %context.value.253, 0
  br i1 %runtime.ok.254, label %runtime.continue.255, label %frame.failure.0
runtime.continue.255:
  %stack.offset.256 = add i32 %stack.offset.31, 8
  %stack.offset.257 = add i32 %stack.offset.31, 16
  %field.grows.258 = icmp ugt i32 %stack.offset.256, %stack.offset.257
  br i1 %field.grows.258, label %field.reserve.259, label %field.release.260
field.reserve.259:
  %reserve.status.262 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.256, i32 26)
  %reserve.ok.263 = icmp eq i32 %reserve.status.262, 0
  br i1 %reserve.ok.263, label %reserve.continue.264, label %frame.failure.0
reserve.continue.264:
  br label %field.ready.261
field.release.260:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.256, i32 0, i32 6, i32 8)
  %context.field.265 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.266 = load i32, ptr %context.field.265, align 4
  %runtime.ok.267 = icmp eq i32 %context.value.266, 0
  br i1 %runtime.ok.267, label %runtime.continue.268, label %frame.failure.0
runtime.continue.268:
  br label %field.ready.261
field.ready.261:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.270 = load i32, ptr %context.field.269, align 4
  %runtime.ok.271 = icmp eq i32 %context.value.270, 0
  br i1 %runtime.ok.271, label %runtime.continue.272, label %frame.failure.0
runtime.continue.272:
  %stack.offset.273 = add i32 %stack.offset.31, 8
  %cursor.check.274 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.273)
  %cursor.ok.275 = icmp eq i32 %cursor.check.274, 0
  br i1 %cursor.ok.275, label %cursor.continue.276, label %frame.failure.0
cursor.continue.276:
  %step.status.277 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %step.ok.278 = icmp eq i32 %step.status.277, 0
  br i1 %step.ok.278, label %step.continue.279, label %frame.failure.0
step.continue.279:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 7)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %stack.offset.284 = add i32 %stack.offset.31, 8
  %stack.offset.285 = add i32 %stack.offset.31, 8
  %field.grows.286 = icmp ugt i32 %stack.offset.284, %stack.offset.285
  br i1 %field.grows.286, label %field.reserve.287, label %field.release.288
field.reserve.287:
  %reserve.status.290 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.284, i32 28)
  %reserve.ok.291 = icmp eq i32 %reserve.status.290, 0
  br i1 %reserve.ok.291, label %reserve.continue.292, label %frame.failure.0
reserve.continue.292:
  br label %field.ready.289
field.release.288:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.284, i32 0, i32 1, i32 8)
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %runtime.ok.295 = icmp eq i32 %context.value.294, 0
  br i1 %runtime.ok.295, label %runtime.continue.296, label %frame.failure.0
runtime.continue.296:
  br label %field.ready.289
field.ready.289:
  %stack.offset.297 = add i32 %stack.offset.31, 8
  %cursor.check.298 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.297)
  %cursor.ok.299 = icmp eq i32 %cursor.check.298, 0
  br i1 %cursor.ok.299, label %cursor.continue.300, label %frame.failure.0
cursor.continue.300:
  %step.status.301 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %step.ok.302 = icmp eq i32 %step.status.301, 0
  br i1 %step.ok.302, label %step.continue.303, label %frame.failure.0
step.continue.303:
  %local.is.active.304 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.305 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.306 = select i1 %local.is.active.304, i32 %local.previous.payload.305, i32 0
  %stack.offset.307 = add i32 %context.value.30, 40
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.307, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.306, i32 1)
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %runtime.ok.310 = icmp eq i32 %context.value.309, 0
  br i1 %runtime.ok.310, label %runtime.continue.311, label %frame.failure.0
runtime.continue.311:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.312 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.313 = load i32, ptr %context.field.312, align 4
  %runtime.ok.314 = icmp eq i32 %context.value.313, 0
  br i1 %runtime.ok.314, label %runtime.continue.315, label %frame.failure.0
runtime.continue.315:
  %cursor.check.316 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.317 = icmp eq i32 %cursor.check.316, 0
  br i1 %cursor.ok.317, label %cursor.continue.318, label %frame.failure.0
cursor.continue.318:
  %step.status.319 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %step.ok.320 = icmp eq i32 %step.status.319, 0
  br i1 %step.ok.320, label %step.continue.321, label %frame.failure.0
step.continue.321:
  %stack.offset.322 = add i32 %stack.offset.31, 16
  %reserve.status.323 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.322, i32 31)
  %reserve.ok.324 = icmp eq i32 %reserve.status.323, 0
  br i1 %reserve.ok.324, label %reserve.continue.325, label %frame.failure.0
reserve.continue.325:
  %stack.offset.326 = add i32 %context.value.30, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.326, i32 16, i32 16, i32 5)
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %runtime.ok.329 = icmp eq i32 %context.value.328, 0
  br i1 %runtime.ok.329, label %runtime.continue.330, label %frame.failure.0
runtime.continue.330:
  %stack.offset.331 = add i32 %stack.offset.31, 16
  %cursor.check.332 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.331)
  %cursor.ok.333 = icmp eq i32 %cursor.check.332, 0
  br i1 %cursor.ok.333, label %cursor.continue.334, label %frame.failure.0
cursor.continue.334:
  %step.status.335 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %step.ok.336 = icmp eq i32 %step.status.335, 0
  br i1 %step.ok.336, label %step.continue.337, label %frame.failure.0
step.continue.337:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 6, i32 7)
  %context.field.338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.339 = load i32, ptr %context.field.338, align 4
  %runtime.ok.340 = icmp eq i32 %context.value.339, 0
  br i1 %runtime.ok.340, label %runtime.continue.341, label %frame.failure.0
runtime.continue.341:
  %stack.offset.342 = add i32 %stack.offset.31, 8
  %stack.offset.343 = add i32 %stack.offset.31, 16
  %field.grows.344 = icmp ugt i32 %stack.offset.342, %stack.offset.343
  br i1 %field.grows.344, label %field.reserve.345, label %field.release.346
field.reserve.345:
  %reserve.status.348 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.342, i32 33)
  %reserve.ok.349 = icmp eq i32 %reserve.status.348, 0
  br i1 %reserve.ok.349, label %reserve.continue.350, label %frame.failure.0
reserve.continue.350:
  br label %field.ready.347
field.release.346:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.342, i32 0, i32 6, i32 8)
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %runtime.ok.353 = icmp eq i32 %context.value.352, 0
  br i1 %runtime.ok.353, label %runtime.continue.354, label %frame.failure.0
runtime.continue.354:
  br label %field.ready.347
field.ready.347:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %runtime.ok.357 = icmp eq i32 %context.value.356, 0
  br i1 %runtime.ok.357, label %runtime.continue.358, label %frame.failure.0
runtime.continue.358:
  %stack.offset.359 = add i32 %stack.offset.31, 8
  %cursor.check.360 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.359)
  %cursor.ok.361 = icmp eq i32 %cursor.check.360, 0
  br i1 %cursor.ok.361, label %cursor.continue.362, label %frame.failure.0
cursor.continue.362:
  %step.status.363 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %step.ok.364 = icmp eq i32 %step.status.363, 0
  br i1 %step.ok.364, label %step.continue.365, label %frame.failure.0
step.continue.365:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 7)
  %context.field.366 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.367 = load i32, ptr %context.field.366, align 4
  %runtime.ok.368 = icmp eq i32 %context.value.367, 0
  br i1 %runtime.ok.368, label %runtime.continue.369, label %frame.failure.0
runtime.continue.369:
  %stack.offset.370 = add i32 %stack.offset.31, 8
  %stack.offset.371 = add i32 %stack.offset.31, 8
  %field.grows.372 = icmp ugt i32 %stack.offset.370, %stack.offset.371
  br i1 %field.grows.372, label %field.reserve.373, label %field.release.374
field.reserve.373:
  %reserve.status.376 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.370, i32 35)
  %reserve.ok.377 = icmp eq i32 %reserve.status.376, 0
  br i1 %reserve.ok.377, label %reserve.continue.378, label %frame.failure.0
reserve.continue.378:
  br label %field.ready.375
field.release.374:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.370, i32 0, i32 1, i32 8)
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %runtime.ok.381 = icmp eq i32 %context.value.380, 0
  br i1 %runtime.ok.381, label %runtime.continue.382, label %frame.failure.0
runtime.continue.382:
  br label %field.ready.375
field.ready.375:
  %stack.offset.383 = add i32 %stack.offset.31, 8
  %cursor.check.384 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.383)
  %cursor.ok.385 = icmp eq i32 %cursor.check.384, 0
  br i1 %cursor.ok.385, label %cursor.continue.386, label %frame.failure.0
cursor.continue.386:
  %step.status.387 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %step.ok.388 = icmp eq i32 %step.status.387, 0
  br i1 %step.ok.388, label %step.continue.389, label %frame.failure.0
step.continue.389:
  %local.is.active.390 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.391 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.392 = select i1 %local.is.active.390, i32 %local.previous.payload.391, i32 0
  %stack.offset.393 = add i32 %context.value.30, 48
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.393, i32 %stack.offset.31, i32 8, i32 8, i32 8, i32 %local.old.payload.392, i32 1)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %runtime.ok.400 = icmp eq i32 %context.value.399, 0
  br i1 %runtime.ok.400, label %runtime.continue.401, label %frame.failure.0
runtime.continue.401:
  %cursor.check.402 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.31)
  %cursor.ok.403 = icmp eq i32 %cursor.check.402, 0
  br i1 %cursor.ok.403, label %cursor.continue.404, label %frame.failure.0
cursor.continue.404:
  %step.status.405 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %step.ok.406 = icmp eq i32 %step.status.405, 0
  br i1 %step.ok.406, label %step.continue.407, label %frame.failure.0
step.continue.407:
  %stack.offset.408 = add i32 %stack.offset.31, 8
  %reserve.status.409 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.408, i32 38)
  %reserve.ok.410 = icmp eq i32 %reserve.status.409, 0
  br i1 %reserve.ok.410, label %reserve.continue.411, label %frame.failure.0
reserve.continue.411:
  %stack.offset.412 = add i32 %context.value.30, 40
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.31, i32 %stack.offset.412, i32 8, i32 8, i32 1)
  %context.field.413 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.414 = load i32, ptr %context.field.413, align 4
  %runtime.ok.415 = icmp eq i32 %context.value.414, 0
  br i1 %runtime.ok.415, label %runtime.continue.416, label %frame.failure.0
runtime.continue.416:
  %stack.offset.417 = add i32 %stack.offset.31, 8
  %cursor.check.418 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.417)
  %cursor.ok.419 = icmp eq i32 %cursor.check.418, 0
  br i1 %cursor.ok.419, label %cursor.continue.420, label %frame.failure.0
cursor.continue.420:
  %step.status.421 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %step.ok.422 = icmp eq i32 %step.status.421, 0
  br i1 %step.ok.422, label %step.continue.423, label %frame.failure.0
step.continue.423:
  %stack.offset.424 = add i32 %stack.offset.31, 8
  %stack.offset.425 = add i32 %stack.offset.424, 8
  %reserve.status.426 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.425, i32 40)
  %reserve.ok.427 = icmp eq i32 %reserve.status.426, 0
  br i1 %reserve.ok.427, label %reserve.continue.428, label %frame.failure.0
reserve.continue.428:
  %stack.offset.429 = add i32 %context.value.30, 48
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.424, i32 %stack.offset.429, i32 8, i32 8, i32 1)
  %context.field.430 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.431 = load i32, ptr %context.field.430, align 4
  %runtime.ok.432 = icmp eq i32 %context.value.431, 0
  br i1 %runtime.ok.432, label %runtime.continue.433, label %frame.failure.0
runtime.continue.433:
  %stack.offset.434 = add i32 %stack.offset.31, 16
  %cursor.check.435 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.434)
  %cursor.ok.436 = icmp eq i32 %cursor.check.435, 0
  br i1 %cursor.ok.436, label %cursor.continue.437, label %frame.failure.0
cursor.continue.437:
  %step.status.438 = call i32 @al_owning_charge_step(ptr %ctx, i32 41)
  %step.ok.439 = icmp eq i32 %step.status.438, 0
  br i1 %step.ok.439, label %step.continue.440, label %frame.failure.0
step.continue.440:
  %stack.offset.441 = add i32 %stack.offset.31, 8
  %integer.left.442 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.31)
  %context.field.444 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.445 = load i32, ptr %context.field.444, align 4
  %runtime.ok.446 = icmp eq i32 %context.value.445, 0
  br i1 %runtime.ok.446, label %runtime.continue.447, label %frame.failure.0
runtime.continue.447:
  %integer.right.443 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.441)
  %context.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.449 = load i32, ptr %context.field.448, align 4
  %runtime.ok.450 = icmp eq i32 %context.value.449, 0
  br i1 %runtime.ok.450, label %runtime.continue.451, label %frame.failure.0
runtime.continue.451:
  %integer.checked.452 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.442, i64 %integer.right.443)
  %integer.result.453 = extractvalue { i64, i1 } %integer.checked.452, 0
  %integer.overflow.454 = extractvalue { i64, i1 } %integer.checked.452, 1
  br i1 %integer.overflow.454, label %integer.overflow.failure.456, label %integer.nooverflow.455
integer.overflow.failure.456:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 42, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.455:
  %stack.offset.457 = add i32 %stack.offset.31, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.457, i32 8, i32 8, i32 1)
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %runtime.ok.460 = icmp eq i32 %context.value.459, 0
  br i1 %runtime.ok.460, label %runtime.continue.461, label %frame.failure.0
runtime.continue.461:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.31, i32 8, i32 8, i32 1)
  %context.field.462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.463 = load i32, ptr %context.field.462, align 4
  %runtime.ok.464 = icmp eq i32 %context.value.463, 0
  br i1 %runtime.ok.464, label %runtime.continue.465, label %frame.failure.0
runtime.continue.465:
  %stack.offset.466 = add i32 %stack.offset.31, 8
  %reserve.status.467 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.466, i32 43)
  %reserve.ok.468 = icmp eq i32 %reserve.status.467, 0
  br i1 %reserve.ok.468, label %reserve.continue.469, label %frame.failure.0
reserve.continue.469:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.31, i64 %integer.result.453, i32 1)
  %context.field.470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.471 = load i32, ptr %context.field.470, align 4
  %runtime.ok.472 = icmp eq i32 %context.value.471, 0
  br i1 %runtime.ok.472, label %runtime.continue.473, label %frame.failure.0
runtime.continue.473:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.474 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.475 = load i32, ptr %context.field.474, align 4
  %runtime.ok.476 = icmp eq i32 %context.value.475, 0
  br i1 %runtime.ok.476, label %runtime.continue.477, label %frame.failure.0
runtime.continue.477:
  %stack.offset.478 = add i32 %stack.offset.31, 8
  %cursor.check.479 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.478)
  %cursor.ok.480 = icmp eq i32 %cursor.check.479, 0
  br i1 %cursor.ok.480, label %cursor.continue.481, label %frame.failure.0
cursor.continue.481:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.31, i32 8, i32 8, i32 1, i32 9)
  %context.field.482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.483 = load i32, ptr %context.field.482, align 4
  %runtime.ok.484 = icmp eq i32 %context.value.483, 0
  br i1 %runtime.ok.484, label %runtime.continue.485, label %frame.failure.0
runtime.continue.485:
  %local.is.active.486 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.487 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.488 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.489 = select i1 %local.is.active.486, i32 %local.clear.payload.487, i32 0
  %local.clear.live.type.490 = select i1 %local.is.active.486, i32 %local.clear.type.488, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.30, i32 8, i32 %local.clear.live.payload.489, i32 %local.clear.live.type.490)
  %context.field.491 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.492 = load i32, ptr %context.field.491, align 4
  %runtime.ok.493 = icmp eq i32 %context.value.492, 0
  br i1 %runtime.ok.493, label %runtime.continue.494, label %frame.failure.0
runtime.continue.494:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.495 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.496 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.497 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.498 = select i1 %local.is.active.495, i32 %local.clear.payload.496, i32 0
  %local.clear.live.type.499 = select i1 %local.is.active.495, i32 %local.clear.type.497, i32 0
  %stack.offset.500 = add i32 %context.value.30, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.500, i32 16, i32 %local.clear.live.payload.498, i32 %local.clear.live.type.499)
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  %runtime.ok.503 = icmp eq i32 %context.value.502, 0
  br i1 %runtime.ok.503, label %runtime.continue.504, label %frame.failure.0
runtime.continue.504:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.505 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.506 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.507 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.508 = select i1 %local.is.active.505, i32 %local.clear.payload.506, i32 0
  %local.clear.live.type.509 = select i1 %local.is.active.505, i32 %local.clear.type.507, i32 0
  %stack.offset.510 = add i32 %context.value.30, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.510, i32 16, i32 %local.clear.live.payload.508, i32 %local.clear.live.type.509)
  %context.field.511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.512 = load i32, ptr %context.field.511, align 4
  %runtime.ok.513 = icmp eq i32 %context.value.512, 0
  br i1 %runtime.ok.513, label %runtime.continue.514, label %frame.failure.0
runtime.continue.514:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.is.active.515 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.516 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.517 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.518 = select i1 %local.is.active.515, i32 %local.clear.payload.516, i32 0
  %local.clear.live.type.519 = select i1 %local.is.active.515, i32 %local.clear.type.517, i32 0
  %stack.offset.520 = add i32 %context.value.30, 40
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.520, i32 8, i32 %local.clear.live.payload.518, i32 %local.clear.live.type.519)
  %context.field.521 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.522 = load i32, ptr %context.field.521, align 4
  %runtime.ok.523 = icmp eq i32 %context.value.522, 0
  br i1 %runtime.ok.523, label %runtime.continue.524, label %frame.failure.0
runtime.continue.524:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.is.active.525 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.526 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.527 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.528 = select i1 %local.is.active.525, i32 %local.clear.payload.526, i32 0
  %local.clear.live.type.529 = select i1 %local.is.active.525, i32 %local.clear.type.527, i32 0
  %stack.offset.530 = add i32 %context.value.30, 48
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.530, i32 8, i32 %local.clear.live.payload.528, i32 %local.clear.live.type.529)
  %context.field.531 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.532 = load i32, ptr %context.field.531, align 4
  %runtime.ok.533 = icmp eq i32 %context.value.532, 0
  br i1 %runtime.ok.533, label %runtime.continue.534, label %frame.failure.0
runtime.continue.534:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  call void @al_owning_local_release(ptr %ctx, i32 56)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.30, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.19, i32 0, i32 0, i32 0)
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %context.field.537 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.538 = load i32, ptr %context.field.537, align 4
  %context.field.539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.540 = load i32, ptr %context.field.539, align 4
  %baseline.live.total.541 = add i32 %context.value.21, %context.value.23
  %current.live.total.542 = add i32 %context.value.536, %context.value.538
  %cleanup.live.delta.543 = sub i32 %baseline.live.total.541, %current.live.total.542
  %cleanup.local.delta.544 = sub i32 %context.value.23, %context.value.538
  %cleanup.reserved.delta.545 = sub i32 %context.value.540, %context.value.25
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.543, i32 %cleanup.local.delta.544)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.545)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %context.field.21 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.22 = load i32, ptr %context.field.21, align 4
  %context.field.23 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.24 = load i32, ptr %context.field.23, align 4
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %frame.entered.29 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.30 = icmp eq i32 %frame.entered.29, 0
  br i1 %frame.entered.ok.30, label %frame.entered.continue.31, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.offset.34 = add i32 %context.value.33, 40
  %stack.offset.35 = add i32 %context.value.33, 56
  %reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 44)
  %reserve.ok.37 = icmp eq i32 %reserve.status.36, 0
  br i1 %reserve.ok.37, label %reserve.continue.38, label %frame.reserve.failure.1
reserve.continue.38:
  call void @al_owning_local_reserve(ptr %ctx, i32 40)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %frame.failure.0
runtime.continue.42:
  %stack.offset.43 = add i32 %argument.source, 8
  %stack.offset.44 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %argument.source, i32 8, i32 8, i32 1, i32 8)
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %runtime.ok.47 = icmp eq i32 %context.value.46, 0
  br i1 %runtime.ok.47, label %runtime.continue.48, label %frame.failure.0
runtime.continue.48:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.44, i32 %stack.offset.43, i32 8, i32 8, i32 1, i32 8)
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.50 = load i32, ptr %context.field.49, align 4
  %runtime.ok.51 = icmp eq i32 %context.value.50, 0
  br i1 %runtime.ok.51, label %runtime.continue.52, label %frame.failure.0
runtime.continue.52:
  %step.status.53 = call i32 @al_owning_charge_step(ptr %ctx, i32 45)
  %step.ok.54 = icmp eq i32 %step.status.53, 0
  br i1 %step.ok.54, label %step.continue.55, label %frame.failure.0
step.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.57 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.58 = select i1 %local.is.active.56, i32 %local.previous.payload.57, i32 0
  %stack.offset.59 = add i32 %stack.offset.34, 8
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.33, i32 %stack.offset.59, i32 8, i32 8, i32 8, i32 %local.old.payload.58, i32 1)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  %stack.offset.64 = add i32 %stack.offset.34, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.64, i32 8, i32 8, i32 1)
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %runtime.ok.67 = icmp eq i32 %context.value.66, 0
  br i1 %runtime.ok.67, label %runtime.continue.68, label %frame.failure.0
runtime.continue.68:
  %stack.offset.69 = add i32 %stack.offset.34, 8
  %cursor.check.70 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.69)
  %cursor.ok.71 = icmp eq i32 %cursor.check.70, 0
  br i1 %cursor.ok.71, label %cursor.continue.72, label %frame.failure.0
cursor.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 46)
  %step.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %step.ok.74, label %step.continue.75, label %frame.failure.0
step.continue.75:
  %local.is.active.76 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.77 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.78 = select i1 %local.is.active.76, i32 %local.previous.payload.77, i32 0
  %stack.offset.79 = add i32 %context.value.33, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.79, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.78, i32 1)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  store i1 true, ptr %local.active.6, align 1
  store i32 8, ptr %local.payload.7, align 4
  store i32 1, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.84 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.85 = load i32, ptr %context.field.84, align 4
  %runtime.ok.86 = icmp eq i32 %context.value.85, 0
  br i1 %runtime.ok.86, label %runtime.continue.87, label %frame.failure.0
runtime.continue.87:
  %cursor.check.88 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.89 = icmp eq i32 %cursor.check.88, 0
  br i1 %cursor.ok.89, label %cursor.continue.90, label %frame.failure.0
cursor.continue.90:
  %step.status.91 = call i32 @al_owning_charge_step(ptr %ctx, i32 47)
  %step.ok.92 = icmp eq i32 %step.status.91, 0
  br i1 %step.ok.92, label %step.continue.93, label %frame.failure.0
step.continue.93:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 48)
  %step.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %step.ok.95, label %step.continue.96, label %frame.failure.0
step.continue.96:
  %stack.offset.97 = add i32 %stack.offset.34, 8
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 49)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %frame.failure.0
reserve.continue.100:
  %stack.offset.101 = add i32 %context.value.33, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.101, i32 8, i32 8, i32 1)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 %stack.offset.34, 8
  %cursor.check.107 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.106)
  %cursor.ok.108 = icmp eq i32 %cursor.check.107, 0
  br i1 %cursor.ok.108, label %cursor.continue.109, label %frame.failure.0
cursor.continue.109:
  %step.status.110 = call i32 @al_owning_charge_step(ptr %ctx, i32 50)
  %step.ok.111 = icmp eq i32 %step.status.110, 0
  br i1 %step.ok.111, label %step.continue.112, label %frame.failure.0
step.continue.112:
  %local.is.active.113 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.114 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.115 = select i1 %local.is.active.113, i32 %local.previous.payload.114, i32 0
  %stack.offset.116 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.116, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.115, i32 1)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %runtime.ok.123 = icmp eq i32 %context.value.122, 0
  br i1 %runtime.ok.123, label %runtime.continue.124, label %frame.failure.0
runtime.continue.124:
  %cursor.check.125 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.126 = icmp eq i32 %cursor.check.125, 0
  br i1 %cursor.ok.126, label %cursor.continue.127, label %frame.failure.0
cursor.continue.127:
  %step.status.128 = call i32 @al_owning_charge_step(ptr %ctx, i32 51)
  %step.ok.129 = icmp eq i32 %step.status.128, 0
  br i1 %step.ok.129, label %step.continue.130, label %frame.failure.0
step.continue.130:
  %stack.offset.131 = add i32 %stack.offset.34, 8
  %reserve.status.132 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.131, i32 52)
  %reserve.ok.133 = icmp eq i32 %reserve.status.132, 0
  br i1 %reserve.ok.133, label %reserve.continue.134, label %frame.failure.0
reserve.continue.134:
  %stack.offset.135 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.135, i32 8, i32 8, i32 1)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %runtime.ok.138 = icmp eq i32 %context.value.137, 0
  br i1 %runtime.ok.138, label %runtime.continue.139, label %frame.failure.0
runtime.continue.139:
  %stack.offset.140 = add i32 %stack.offset.34, 8
  %cursor.check.141 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.140)
  %cursor.ok.142 = icmp eq i32 %cursor.check.141, 0
  br i1 %cursor.ok.142, label %cursor.continue.143, label %frame.failure.0
cursor.continue.143:
  %step.status.144 = call i32 @al_owning_charge_step(ptr %ctx, i32 53)
  %step.ok.145 = icmp eq i32 %step.status.144, 0
  br i1 %step.ok.145, label %step.continue.146, label %frame.failure.0
step.continue.146:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 1, i32 6)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  %stack.offset.151 = add i32 %stack.offset.34, 8
  %stack.offset.152 = add i32 %stack.offset.34, 8
  %record.grows.153 = icmp ugt i32 %stack.offset.151, %stack.offset.152
  br i1 %record.grows.153, label %record.reserve.154, label %record.release.155
record.reserve.154:
  %reserve.status.157 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.151, i32 54)
  %reserve.ok.158 = icmp eq i32 %reserve.status.157, 0
  br i1 %reserve.ok.158, label %reserve.continue.159, label %frame.failure.0
reserve.continue.159:
  br label %record.ready.156
record.release.155:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.151, i32 0, i32 6, i32 8)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  br label %record.ready.156
record.ready.156:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %stack.offset.34, i32 8, i32 8, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %frame.failure.0
runtime.continue.167:
  %stack.offset.168 = add i32 %stack.offset.34, 8
  %cursor.check.169 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.168)
  %cursor.ok.170 = icmp eq i32 %cursor.check.169, 0
  br i1 %cursor.ok.170, label %cursor.continue.171, label %frame.failure.0
cursor.continue.171:
  %local.is.active.172 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.173 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.174 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.175 = select i1 %local.is.active.172, i32 %local.clear.payload.173, i32 0
  %local.clear.live.type.176 = select i1 %local.is.active.172, i32 %local.clear.type.174, i32 0
  %stack.offset.177 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.177, i32 8, i32 %local.clear.live.payload.175, i32 %local.clear.live.type.176)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %stack.offset.182 = add i32 %stack.offset.34, 8
  %cursor.check.183 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.182)
  %cursor.ok.184 = icmp eq i32 %cursor.check.183, 0
  br i1 %cursor.ok.184, label %cursor.continue.185, label %frame.failure.0
cursor.continue.185:
  %step.status.186 = call i32 @al_owning_charge_step(ptr %ctx, i32 55)
  %step.ok.187 = icmp eq i32 %step.status.186, 0
  br i1 %step.ok.187, label %step.continue.188, label %frame.failure.0
step.continue.188:
  %local.is.active.189 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.190 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.191 = select i1 %local.is.active.189, i32 %local.previous.payload.190, i32 0
  %stack.offset.192 = add i32 %context.value.33, 16
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.192, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.191, i32 6)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %frame.failure.0
runtime.continue.196:
  store i1 true, ptr %local.active.9, align 1
  store i32 8, ptr %local.payload.10, align 4
  store i32 6, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.198 = load i32, ptr %context.field.197, align 4
  %runtime.ok.199 = icmp eq i32 %context.value.198, 0
  br i1 %runtime.ok.199, label %runtime.continue.200, label %frame.failure.0
runtime.continue.200:
  %cursor.check.201 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.202 = icmp eq i32 %cursor.check.201, 0
  br i1 %cursor.ok.202, label %cursor.continue.203, label %frame.failure.0
cursor.continue.203:
  %step.status.204 = call i32 @al_owning_charge_step(ptr %ctx, i32 56)
  %step.ok.205 = icmp eq i32 %step.status.204, 0
  br i1 %step.ok.205, label %step.continue.206, label %frame.failure.0
step.continue.206:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 57)
  %step.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %step.ok.208, label %step.continue.209, label %frame.failure.0
step.continue.209:
  %stack.offset.210 = add i32 %stack.offset.34, 8
  %reserve.status.211 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.210, i32 58)
  %reserve.ok.212 = icmp eq i32 %reserve.status.211, 0
  br i1 %reserve.ok.212, label %reserve.continue.213, label %frame.failure.0
reserve.continue.213:
  %stack.offset.214 = add i32 %context.value.33, 16
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.214, i32 8, i32 8, i32 6)
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %runtime.ok.217 = icmp eq i32 %context.value.216, 0
  br i1 %runtime.ok.217, label %runtime.continue.218, label %frame.failure.0
runtime.continue.218:
  %stack.offset.219 = add i32 %stack.offset.34, 8
  %cursor.check.220 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.219)
  %cursor.ok.221 = icmp eq i32 %cursor.check.220, 0
  br i1 %cursor.ok.221, label %cursor.continue.222, label %frame.failure.0
cursor.continue.222:
  %step.status.223 = call i32 @al_owning_charge_step(ptr %ctx, i32 59)
  %step.ok.224 = icmp eq i32 %step.status.223, 0
  br i1 %step.ok.224, label %step.continue.225, label %frame.failure.0
step.continue.225:
  %local.is.active.226 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.227 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.228 = select i1 %local.is.active.226, i32 %local.previous.payload.227, i32 0
  %stack.offset.229 = add i32 %context.value.33, 24
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.229, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.228, i32 6)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 6, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 6)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %cursor.check.238 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.239 = icmp eq i32 %cursor.check.238, 0
  br i1 %cursor.ok.239, label %cursor.continue.240, label %frame.failure.0
cursor.continue.240:
  %step.status.241 = call i32 @al_owning_charge_step(ptr %ctx, i32 60)
  %step.ok.242 = icmp eq i32 %step.status.241, 0
  br i1 %step.ok.242, label %step.continue.243, label %frame.failure.0
step.continue.243:
  %stack.offset.244 = add i32 %stack.offset.34, 8
  %reserve.status.245 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.244, i32 61)
  %reserve.ok.246 = icmp eq i32 %reserve.status.245, 0
  br i1 %reserve.ok.246, label %reserve.continue.247, label %frame.failure.0
reserve.continue.247:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %context.value.33, i32 8, i32 8, i32 1)
  %context.field.248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.249 = load i32, ptr %context.field.248, align 4
  %runtime.ok.250 = icmp eq i32 %context.value.249, 0
  br i1 %runtime.ok.250, label %runtime.continue.251, label %frame.failure.0
runtime.continue.251:
  %stack.offset.252 = add i32 %stack.offset.34, 8
  %cursor.check.253 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.252)
  %cursor.ok.254 = icmp eq i32 %cursor.check.253, 0
  br i1 %cursor.ok.254, label %cursor.continue.255, label %frame.failure.0
cursor.continue.255:
  %step.status.256 = call i32 @al_owning_charge_step(ptr %ctx, i32 62)
  %step.ok.257 = icmp eq i32 %step.status.256, 0
  br i1 %step.ok.257, label %step.continue.258, label %frame.failure.0
step.continue.258:
  %local.is.active.259 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.260 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.261 = select i1 %local.is.active.259, i32 %local.previous.payload.260, i32 0
  %stack.offset.262 = add i32 %context.value.33, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.262, i32 %stack.offset.34, i32 8, i32 8, i32 8, i32 %local.old.payload.261, i32 1)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %frame.failure.0
runtime.continue.266:
  store i1 true, ptr %local.active.18, align 1
  store i32 8, ptr %local.payload.19, align 4
  store i32 1, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.34, i32 8, i32 8, i32 1)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %frame.failure.0
runtime.continue.270:
  %cursor.check.271 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.34)
  %cursor.ok.272 = icmp eq i32 %cursor.check.271, 0
  br i1 %cursor.ok.272, label %cursor.continue.273, label %frame.failure.0
cursor.continue.273:
  %step.status.274 = call i32 @al_owning_charge_step(ptr %ctx, i32 63)
  %step.ok.275 = icmp eq i32 %step.status.274, 0
  br i1 %step.ok.275, label %step.continue.276, label %frame.failure.0
step.continue.276:
  %stack.offset.277 = add i32 %stack.offset.34, 8
  %reserve.status.278 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.277, i32 64)
  %reserve.ok.279 = icmp eq i32 %reserve.status.278, 0
  br i1 %reserve.ok.279, label %reserve.continue.280, label %frame.failure.0
reserve.continue.280:
  %stack.offset.281 = add i32 %context.value.33, 24
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.281, i32 8, i32 8, i32 6)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %stack.offset.286 = add i32 %stack.offset.34, 8
  %cursor.check.287 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.286)
  %cursor.ok.288 = icmp eq i32 %cursor.check.287, 0
  br i1 %cursor.ok.288, label %cursor.continue.289, label %frame.failure.0
cursor.continue.289:
  %step.status.290 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %step.ok.291 = icmp eq i32 %step.status.290, 0
  br i1 %step.ok.291, label %step.continue.292, label %frame.failure.0
step.continue.292:
  %stack.offset.293 = add i32 %stack.offset.34, 8
  %stack.offset.294 = add i32 %stack.offset.293, 8
  %reserve.status.295 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.294, i32 66)
  %reserve.ok.296 = icmp eq i32 %reserve.status.295, 0
  br i1 %reserve.ok.296, label %reserve.continue.297, label %frame.failure.0
reserve.continue.297:
  %stack.offset.298 = add i32 %context.value.33, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.293, i32 %stack.offset.298, i32 8, i32 8, i32 1)
  %context.field.299 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.300 = load i32, ptr %context.field.299, align 4
  %runtime.ok.301 = icmp eq i32 %context.value.300, 0
  br i1 %runtime.ok.301, label %runtime.continue.302, label %frame.failure.0
runtime.continue.302:
  %stack.offset.303 = add i32 %stack.offset.34, 16
  %cursor.check.304 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.303)
  %cursor.ok.305 = icmp eq i32 %cursor.check.304, 0
  br i1 %cursor.ok.305, label %cursor.continue.306, label %frame.failure.0
cursor.continue.306:
  %step.status.307 = call i32 @al_owning_charge_step(ptr %ctx, i32 67)
  %step.ok.308 = icmp eq i32 %step.status.307, 0
  br i1 %step.ok.308, label %step.continue.309, label %frame.failure.0
step.continue.309:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.34, i32 %stack.offset.34, i32 8, i32 8, i32 6, i32 6)
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %runtime.ok.312 = icmp eq i32 %context.value.311, 0
  br i1 %runtime.ok.312, label %runtime.continue.313, label %frame.failure.0
runtime.continue.313:
  %stack.offset.314 = add i32 %stack.offset.34, 8
  %stack.offset.315 = add i32 %stack.offset.34, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.314, i32 %stack.offset.315, i32 8, i32 8, i32 1, i32 6)
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %runtime.ok.318 = icmp eq i32 %context.value.317, 0
  br i1 %runtime.ok.318, label %runtime.continue.319, label %frame.failure.0
runtime.continue.319:
  %stack.offset.320 = add i32 %stack.offset.34, 16
  %stack.offset.321 = add i32 %stack.offset.34, 16
  %record.grows.322 = icmp ugt i32 %stack.offset.320, %stack.offset.321
  br i1 %record.grows.322, label %record.reserve.323, label %record.release.324
record.reserve.323:
  %reserve.status.326 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.320, i32 68)
  %reserve.ok.327 = icmp eq i32 %reserve.status.326, 0
  br i1 %reserve.ok.327, label %reserve.continue.328, label %frame.failure.0
reserve.continue.328:
  br label %record.ready.325
record.release.324:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.320, i32 0, i32 5, i32 16)
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %runtime.ok.331 = icmp eq i32 %context.value.330, 0
  br i1 %runtime.ok.331, label %runtime.continue.332, label %frame.failure.0
runtime.continue.332:
  br label %record.ready.325
record.ready.325:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %stack.offset.34, i32 16, i32 16, i32 0, i32 0)
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %runtime.ok.335 = icmp eq i32 %context.value.334, 0
  br i1 %runtime.ok.335, label %runtime.continue.336, label %frame.failure.0
runtime.continue.336:
  %stack.offset.337 = add i32 %stack.offset.34, 16
  %cursor.check.338 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.337)
  %cursor.ok.339 = icmp eq i32 %cursor.check.338, 0
  br i1 %cursor.ok.339, label %cursor.continue.340, label %frame.failure.0
cursor.continue.340:
  %local.is.active.341 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.342 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.343 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.344 = select i1 %local.is.active.341, i32 %local.clear.payload.342, i32 0
  %local.clear.live.type.345 = select i1 %local.is.active.341, i32 %local.clear.type.343, i32 0
  %stack.offset.346 = add i32 %context.value.33, 24
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.346, i32 8, i32 %local.clear.live.payload.344, i32 %local.clear.live.type.345)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.is.active.351 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.352 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.353 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.354 = select i1 %local.is.active.351, i32 %local.clear.payload.352, i32 0
  %local.clear.live.type.355 = select i1 %local.is.active.351, i32 %local.clear.type.353, i32 0
  %stack.offset.356 = add i32 %context.value.33, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.356, i32 8, i32 %local.clear.live.payload.354, i32 %local.clear.live.type.355)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %stack.offset.361 = add i32 %stack.offset.34, 16
  %cursor.check.362 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.361)
  %cursor.ok.363 = icmp eq i32 %cursor.check.362, 0
  br i1 %cursor.ok.363, label %cursor.continue.364, label %frame.failure.0
cursor.continue.364:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.34, i32 16, i32 16, i32 5, i32 9)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %local.is.active.369 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.370 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.371 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.372 = select i1 %local.is.active.369, i32 %local.clear.payload.370, i32 0
  %local.clear.live.type.373 = select i1 %local.is.active.369, i32 %local.clear.type.371, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.33, i32 8, i32 %local.clear.live.payload.372, i32 %local.clear.live.type.373)
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %runtime.ok.376 = icmp eq i32 %context.value.375, 0
  br i1 %runtime.ok.376, label %runtime.continue.377, label %frame.failure.0
runtime.continue.377:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.378 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.379 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.380 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.381 = select i1 %local.is.active.378, i32 %local.clear.payload.379, i32 0
  %local.clear.live.type.382 = select i1 %local.is.active.378, i32 %local.clear.type.380, i32 0
  %stack.offset.383 = add i32 %context.value.33, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.383, i32 8, i32 %local.clear.live.payload.381, i32 %local.clear.live.type.382)
  %context.field.384 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.385 = load i32, ptr %context.field.384, align 4
  %runtime.ok.386 = icmp eq i32 %context.value.385, 0
  br i1 %runtime.ok.386, label %runtime.continue.387, label %frame.failure.0
runtime.continue.387:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.388 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.389 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.390 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.391 = select i1 %local.is.active.388, i32 %local.clear.payload.389, i32 0
  %local.clear.live.type.392 = select i1 %local.is.active.388, i32 %local.clear.type.390, i32 0
  %stack.offset.393 = add i32 %context.value.33, 16
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.393, i32 8, i32 %local.clear.live.payload.391, i32 %local.clear.live.type.392)
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %runtime.ok.396 = icmp eq i32 %context.value.395, 0
  br i1 %runtime.ok.396, label %runtime.continue.397, label %frame.failure.0
runtime.continue.397:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  call void @al_owning_local_release(ptr %ctx, i32 40)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.33, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.22, i32 0, i32 0, i32 0)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %context.field.400 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.401 = load i32, ptr %context.field.400, align 4
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %baseline.live.total.404 = add i32 %context.value.24, %context.value.26
  %current.live.total.405 = add i32 %context.value.399, %context.value.401
  %cleanup.live.delta.406 = sub i32 %baseline.live.total.404, %current.live.total.405
  %cleanup.local.delta.407 = sub i32 %context.value.26, %context.value.401
  %cleanup.reserved.delta.408 = sub i32 %context.value.403, %context.value.28
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.406, i32 %cleanup.local.delta.407)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.408)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, i32 %argument.source, i32 %result.destination, i32 %depth.error) {
entry:
  %local.active.3 = alloca i1, align 1
  %local.payload.4 = alloca i32, align 4
  %local.type.5 = alloca i32, align 4
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.active.6 = alloca i1, align 1
  %local.payload.7 = alloca i32, align 4
  %local.type.8 = alloca i32, align 4
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.active.9 = alloca i1, align 1
  %local.payload.10 = alloca i32, align 4
  %local.type.11 = alloca i32, align 4
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.active.12 = alloca i1, align 1
  %local.payload.13 = alloca i32, align 4
  %local.type.14 = alloca i32, align 4
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.active.15 = alloca i1, align 1
  %local.payload.16 = alloca i32, align 4
  %local.type.17 = alloca i32, align 4
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  %local.active.18 = alloca i1, align 1
  %local.payload.19 = alloca i32, align 4
  %local.type.20 = alloca i32, align 4
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %local.active.21 = alloca i1, align 1
  %local.payload.22 = alloca i32, align 4
  %local.type.23 = alloca i32, align 4
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %local.active.24 = alloca i1, align 1
  %local.payload.25 = alloca i32, align 4
  %local.type.26 = alloca i32, align 4
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %local.active.27 = alloca i1, align 1
  %local.payload.28 = alloca i32, align 4
  %local.type.29 = alloca i32, align 4
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  %local.active.30 = alloca i1, align 1
  %local.payload.31 = alloca i32, align 4
  %local.type.32 = alloca i32, align 4
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %local.active.33 = alloca i1, align 1
  %local.payload.34 = alloca i32, align 4
  %local.type.35 = alloca i32, align 4
  store i1 false, ptr %local.active.33, align 1
  store i32 0, ptr %local.payload.34, align 4
  store i32 0, ptr %local.type.35, align 4
  %local.active.36 = alloca i1, align 1
  %local.payload.37 = alloca i32, align 4
  %local.type.38 = alloca i32, align 4
  store i1 false, ptr %local.active.36, align 1
  store i32 0, ptr %local.payload.37, align 4
  store i32 0, ptr %local.type.38, align 4
  %local.active.39 = alloca i1, align 1
  %local.payload.40 = alloca i32, align 4
  %local.type.41 = alloca i32, align 4
  store i1 false, ptr %local.active.39, align 1
  store i32 0, ptr %local.payload.40, align 4
  store i32 0, ptr %local.type.41, align 4
  %local.active.42 = alloca i1, align 1
  %local.payload.43 = alloca i32, align 4
  %local.type.44 = alloca i32, align 4
  store i1 false, ptr %local.active.42, align 1
  store i32 0, ptr %local.payload.43, align 4
  store i32 0, ptr %local.type.44, align 4
  %local.active.45 = alloca i1, align 1
  %local.payload.46 = alloca i32, align 4
  %local.type.47 = alloca i32, align 4
  store i1 false, ptr %local.active.45, align 1
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %frame.entered.56 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.entered.ok.57 = icmp eq i32 %frame.entered.56, 0
  br i1 %frame.entered.ok.57, label %frame.entered.continue.58, label %frame.enter.failure.2
frame.enter.failure.2:
  ret i32 1
frame.entered.continue.58:
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %stack.offset.61 = add i32 %context.value.60, 88
  %stack.offset.62 = add i32 %context.value.60, 120
  %reserve.status.63 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.62, i32 69)
  %reserve.ok.64 = icmp eq i32 %reserve.status.63, 0
  br i1 %reserve.ok.64, label %reserve.continue.65, label %frame.reserve.failure.1
reserve.continue.65:
  call void @al_owning_local_reserve(ptr %ctx, i32 88)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %frame.failure.0
runtime.continue.69:
  %stack.offset.70 = add i32 %argument.source, 24
  %stack.offset.71 = add i32 %stack.offset.61, 24
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.61, i32 %argument.source, i32 24, i32 24, i32 7, i32 8)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %frame.failure.0
runtime.continue.75:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.71, i32 %stack.offset.70, i32 8, i32 8, i32 1, i32 8)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  %step.status.80 = call i32 @al_owning_charge_step(ptr %ctx, i32 70)
  %step.ok.81 = icmp eq i32 %step.status.80, 0
  br i1 %step.ok.81, label %step.continue.82, label %frame.failure.0
step.continue.82:
  %local.is.active.83 = load i1, ptr %local.active.3, align 1
  %local.previous.payload.84 = load i32, ptr %local.payload.4, align 4
  %local.old.payload.85 = select i1 %local.is.active.83, i32 %local.previous.payload.84, i32 0
  %stack.offset.86 = add i32 %stack.offset.61, 24
  call void @al_owning_store_local(ptr %ctx, i32 %context.value.60, i32 %stack.offset.86, i32 8, i32 8, i32 8, i32 %local.old.payload.85, i32 1)
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %runtime.ok.89 = icmp eq i32 %context.value.88, 0
  br i1 %runtime.ok.89, label %runtime.continue.90, label %frame.failure.0
runtime.continue.90:
  store i1 true, ptr %local.active.3, align 1
  store i32 8, ptr %local.payload.4, align 4
  store i32 1, ptr %local.type.5, align 4
  %stack.offset.91 = add i32 %stack.offset.61, 24
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.91, i32 8, i32 8, i32 1)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  %stack.offset.96 = add i32 %stack.offset.61, 24
  %cursor.check.97 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.96)
  %cursor.ok.98 = icmp eq i32 %cursor.check.97, 0
  br i1 %cursor.ok.98, label %cursor.continue.99, label %frame.failure.0
cursor.continue.99:
  %step.status.100 = call i32 @al_owning_charge_step(ptr %ctx, i32 71)
  %step.ok.101 = icmp eq i32 %step.status.100, 0
  br i1 %step.ok.101, label %step.continue.102, label %frame.failure.0
step.continue.102:
  %local.is.active.103 = load i1, ptr %local.active.6, align 1
  %local.previous.payload.104 = load i32, ptr %local.payload.7, align 4
  %local.old.payload.105 = select i1 %local.is.active.103, i32 %local.previous.payload.104, i32 0
  %stack.offset.106 = add i32 %context.value.60, 8
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.106, i32 %stack.offset.61, i32 24, i32 24, i32 24, i32 %local.old.payload.105, i32 7)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %runtime.ok.109 = icmp eq i32 %context.value.108, 0
  br i1 %runtime.ok.109, label %runtime.continue.110, label %frame.failure.0
runtime.continue.110:
  store i1 true, ptr %local.active.6, align 1
  store i32 24, ptr %local.payload.7, align 4
  store i32 7, ptr %local.type.8, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 24, i32 24, i32 7)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  %cursor.check.115 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.116 = icmp eq i32 %cursor.check.115, 0
  br i1 %cursor.ok.116, label %cursor.continue.117, label %frame.failure.0
cursor.continue.117:
  %step.status.118 = call i32 @al_owning_charge_step(ptr %ctx, i32 72)
  %step.ok.119 = icmp eq i32 %step.status.118, 0
  br i1 %step.ok.119, label %step.continue.120, label %frame.failure.0
step.continue.120:
  %stack.offset.121 = add i32 %stack.offset.61, 8
  %reserve.status.122 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.121, i32 73)
  %reserve.ok.123 = icmp eq i32 %reserve.status.122, 0
  br i1 %reserve.ok.123, label %reserve.continue.124, label %frame.failure.0
reserve.continue.124:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %runtime.ok.127 = icmp eq i32 %context.value.126, 0
  br i1 %runtime.ok.127, label %runtime.continue.128, label %frame.failure.0
runtime.continue.128:
  %stack.offset.129 = add i32 %stack.offset.61, 8
  %cursor.check.130 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.129)
  %cursor.ok.131 = icmp eq i32 %cursor.check.130, 0
  br i1 %cursor.ok.131, label %cursor.continue.132, label %frame.failure.0
cursor.continue.132:
  %step.status.133 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %step.ok.134 = icmp eq i32 %step.status.133, 0
  br i1 %step.ok.134, label %step.continue.135, label %frame.failure.0
step.continue.135:
  %stack.offset.136 = add i32 %stack.offset.61, 8
  %stack.offset.137 = add i32 %stack.offset.136, 8
  %reserve.status.138 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.137, i32 75)
  %reserve.ok.139 = icmp eq i32 %reserve.status.138, 0
  br i1 %reserve.ok.139, label %reserve.continue.140, label %frame.failure.0
reserve.continue.140:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.136, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %runtime.ok.143 = icmp eq i32 %context.value.142, 0
  br i1 %runtime.ok.143, label %runtime.continue.144, label %frame.failure.0
runtime.continue.144:
  %stack.offset.145 = add i32 %stack.offset.61, 16
  %cursor.check.146 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.145)
  %cursor.ok.147 = icmp eq i32 %cursor.check.146, 0
  br i1 %cursor.ok.147, label %cursor.continue.148, label %frame.failure.0
cursor.continue.148:
  %step.status.149 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %step.ok.150 = icmp eq i32 %step.status.149, 0
  br i1 %step.ok.150, label %step.continue.151, label %frame.failure.0
step.continue.151:
  %stack.offset.152 = add i32 %stack.offset.61, 16
  %stack.offset.153 = add i32 %stack.offset.152, 8
  %reserve.status.154 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.153, i32 77)
  %reserve.ok.155 = icmp eq i32 %reserve.status.154, 0
  br i1 %reserve.ok.155, label %reserve.continue.156, label %frame.failure.0
reserve.continue.156:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.152, i64 1000, i32 1)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %runtime.ok.163 = icmp eq i32 %context.value.162, 0
  br i1 %runtime.ok.163, label %runtime.continue.164, label %frame.failure.0
runtime.continue.164:
  %stack.offset.165 = add i32 %stack.offset.61, 24
  %cursor.check.166 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.165)
  %cursor.ok.167 = icmp eq i32 %cursor.check.166, 0
  br i1 %cursor.ok.167, label %cursor.continue.168, label %frame.failure.0
cursor.continue.168:
  %step.status.169 = call i32 @al_owning_charge_step(ptr %ctx, i32 78)
  %step.ok.170 = icmp eq i32 %step.status.169, 0
  br i1 %step.ok.170, label %step.continue.171, label %frame.failure.0
step.continue.171:
  %stack.offset.172 = add i32 %stack.offset.61, 8
  %stack.offset.173 = add i32 %stack.offset.61, 16
  %integer.left.174 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.172)
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %runtime.ok.178 = icmp eq i32 %context.value.177, 0
  br i1 %runtime.ok.178, label %runtime.continue.179, label %frame.failure.0
runtime.continue.179:
  %integer.right.175 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.173)
  %context.field.180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.181 = load i32, ptr %context.field.180, align 4
  %runtime.ok.182 = icmp eq i32 %context.value.181, 0
  br i1 %runtime.ok.182, label %runtime.continue.183, label %frame.failure.0
runtime.continue.183:
  %integer.checked.184 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.174, i64 %integer.right.175)
  %integer.result.185 = extractvalue { i64, i1 } %integer.checked.184, 0
  %integer.overflow.186 = extractvalue { i64, i1 } %integer.checked.184, 1
  br i1 %integer.overflow.186, label %integer.overflow.failure.188, label %integer.nooverflow.187
integer.overflow.failure.188:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 79, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.187:
  %stack.offset.189 = add i32 %stack.offset.61, 8
  %stack.offset.190 = add i32 %stack.offset.61, 16
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.190, i32 8, i32 8, i32 1)
  %context.field.191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.192 = load i32, ptr %context.field.191, align 4
  %runtime.ok.193 = icmp eq i32 %context.value.192, 0
  br i1 %runtime.ok.193, label %runtime.continue.194, label %frame.failure.0
runtime.continue.194:
  %stack.offset.195 = add i32 %stack.offset.61, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.195, i32 8, i32 8, i32 1)
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %runtime.ok.198 = icmp eq i32 %context.value.197, 0
  br i1 %runtime.ok.198, label %runtime.continue.199, label %frame.failure.0
runtime.continue.199:
  %stack.offset.200 = add i32 %stack.offset.189, 8
  %reserve.status.201 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.200, i32 80)
  %reserve.ok.202 = icmp eq i32 %reserve.status.201, 0
  br i1 %reserve.ok.202, label %reserve.continue.203, label %frame.failure.0
reserve.continue.203:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.189, i64 %integer.result.185, i32 1)
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %runtime.ok.206 = icmp eq i32 %context.value.205, 0
  br i1 %runtime.ok.206, label %runtime.continue.207, label %frame.failure.0
runtime.continue.207:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %runtime.ok.210 = icmp eq i32 %context.value.209, 0
  br i1 %runtime.ok.210, label %runtime.continue.211, label %frame.failure.0
runtime.continue.211:
  %stack.offset.212 = add i32 %stack.offset.61, 16
  %cursor.check.213 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.212)
  %cursor.ok.214 = icmp eq i32 %cursor.check.213, 0
  br i1 %cursor.ok.214, label %cursor.continue.215, label %frame.failure.0
cursor.continue.215:
  %step.status.216 = call i32 @al_owning_charge_step(ptr %ctx, i32 81)
  %step.ok.217 = icmp eq i32 %step.status.216, 0
  br i1 %step.ok.217, label %step.continue.218, label %frame.failure.0
step.continue.218:
  %stack.offset.219 = add i32 %stack.offset.61, 16
  %reserve.status.220 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.219, i32 82)
  %reserve.ok.221 = icmp eq i32 %reserve.status.220, 0
  br i1 %reserve.ok.221, label %reserve.continue.222, label %frame.failure.0
reserve.continue.222:
  %callee.status.223 = call i32 @agentlang_word_0001(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 83)
  %callee.ok.224 = icmp eq i32 %callee.status.223, 0
  br i1 %callee.ok.224, label %callee.returned.225, label %frame.failure.0
callee.returned.225:
  %stack.offset.226 = add i32 %stack.offset.61, 16
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.226, i32 0, i32 0, i32 0)
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %runtime.ok.229 = icmp eq i32 %context.value.228, 0
  br i1 %runtime.ok.229, label %runtime.continue.230, label %frame.failure.0
runtime.continue.230:
  %stack.offset.231 = add i32 %stack.offset.61, 16
  %cursor.check.232 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.231)
  %cursor.ok.233 = icmp eq i32 %cursor.check.232, 0
  br i1 %cursor.ok.233, label %cursor.continue.234, label %frame.failure.0
cursor.continue.234:
  %step.status.235 = call i32 @al_owning_charge_step(ptr %ctx, i32 84)
  %step.ok.236 = icmp eq i32 %step.status.235, 0
  br i1 %step.ok.236, label %step.continue.237, label %frame.failure.0
step.continue.237:
  %local.is.active.238 = load i1, ptr %local.active.9, align 1
  %local.previous.payload.239 = load i32, ptr %local.payload.10, align 4
  %local.old.payload.240 = select i1 %local.is.active.238, i32 %local.previous.payload.239, i32 0
  %stack.offset.241 = add i32 %context.value.60, 32
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.241, i32 %stack.offset.61, i32 16, i32 16, i32 16, i32 %local.old.payload.240, i32 5)
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %runtime.ok.244 = icmp eq i32 %context.value.243, 0
  br i1 %runtime.ok.244, label %runtime.continue.245, label %frame.failure.0
runtime.continue.245:
  store i1 true, ptr %local.active.9, align 1
  store i32 16, ptr %local.payload.10, align 4
  store i32 5, ptr %local.type.11, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 16, i32 16, i32 5)
  %context.field.246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.247 = load i32, ptr %context.field.246, align 4
  %runtime.ok.248 = icmp eq i32 %context.value.247, 0
  br i1 %runtime.ok.248, label %runtime.continue.249, label %frame.failure.0
runtime.continue.249:
  %cursor.check.250 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.251 = icmp eq i32 %cursor.check.250, 0
  br i1 %cursor.ok.251, label %cursor.continue.252, label %frame.failure.0
cursor.continue.252:
  %step.status.253 = call i32 @al_owning_charge_step(ptr %ctx, i32 85)
  %step.ok.254 = icmp eq i32 %step.status.253, 0
  br i1 %step.ok.254, label %step.continue.255, label %frame.failure.0
step.continue.255:
  %stack.offset.256 = add i32 %stack.offset.61, 8
  %reserve.status.257 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.256, i32 86)
  %reserve.ok.258 = icmp eq i32 %reserve.status.257, 0
  br i1 %reserve.ok.258, label %reserve.continue.259, label %frame.failure.0
reserve.continue.259:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %runtime.ok.262 = icmp eq i32 %context.value.261, 0
  br i1 %runtime.ok.262, label %runtime.continue.263, label %frame.failure.0
runtime.continue.263:
  %stack.offset.264 = add i32 %stack.offset.61, 8
  %cursor.check.265 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.264)
  %cursor.ok.266 = icmp eq i32 %cursor.check.265, 0
  br i1 %cursor.ok.266, label %cursor.continue.267, label %frame.failure.0
cursor.continue.267:
  %step.status.268 = call i32 @al_owning_charge_step(ptr %ctx, i32 87)
  %step.ok.269 = icmp eq i32 %step.status.268, 0
  br i1 %step.ok.269, label %step.continue.270, label %frame.failure.0
step.continue.270:
  %stack.offset.271 = add i32 %stack.offset.61, 8
  %reserve.status.272 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.271, i32 88)
  %reserve.ok.273 = icmp eq i32 %reserve.status.272, 0
  br i1 %reserve.ok.273, label %reserve.continue.274, label %frame.failure.0
reserve.continue.274:
  %callee.status.275 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 89)
  %callee.ok.276 = icmp eq i32 %callee.status.275, 0
  br i1 %callee.ok.276, label %callee.returned.277, label %frame.failure.0
callee.returned.277:
  %stack.offset.278 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.278, i32 0, i32 0, i32 0)
  %context.field.279 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.280 = load i32, ptr %context.field.279, align 4
  %runtime.ok.281 = icmp eq i32 %context.value.280, 0
  br i1 %runtime.ok.281, label %runtime.continue.282, label %frame.failure.0
runtime.continue.282:
  %stack.offset.283 = add i32 %stack.offset.61, 8
  %cursor.check.284 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.283)
  %cursor.ok.285 = icmp eq i32 %cursor.check.284, 0
  br i1 %cursor.ok.285, label %cursor.continue.286, label %frame.failure.0
cursor.continue.286:
  %step.status.287 = call i32 @al_owning_charge_step(ptr %ctx, i32 90)
  %step.ok.288 = icmp eq i32 %step.status.287, 0
  br i1 %step.ok.288, label %step.continue.289, label %frame.failure.0
step.continue.289:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %step.status.290 = call i32 @al_owning_charge_step(ptr %ctx, i32 91)
  %step.ok.291 = icmp eq i32 %step.status.290, 0
  br i1 %step.ok.291, label %step.continue.292, label %frame.failure.0
step.continue.292:
  %local.is.active.293 = load i1, ptr %local.active.18, align 1
  %local.previous.payload.294 = load i32, ptr %local.payload.19, align 4
  %local.old.payload.295 = select i1 %local.is.active.293, i32 %local.previous.payload.294, i32 0
  %stack.offset.296 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.296, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.295, i32 1)
  %context.field.297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.298 = load i32, ptr %context.field.297, align 4
  %runtime.ok.299 = icmp eq i32 %context.value.298, 0
  br i1 %runtime.ok.299, label %runtime.continue.300, label %frame.failure.0
runtime.continue.300:
  store i1 true, ptr %local.active.18, align 1
  store i32 8, ptr %local.payload.19, align 4
  store i32 1, ptr %local.type.20, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.302 = load i32, ptr %context.field.301, align 4
  %runtime.ok.303 = icmp eq i32 %context.value.302, 0
  br i1 %runtime.ok.303, label %runtime.continue.304, label %frame.failure.0
runtime.continue.304:
  %cursor.check.305 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.306 = icmp eq i32 %cursor.check.305, 0
  br i1 %cursor.ok.306, label %cursor.continue.307, label %frame.failure.0
cursor.continue.307:
  %local.is.active.308 = load i1, ptr %local.active.18, align 1
  %local.clear.payload.309 = load i32, ptr %local.payload.19, align 4
  %local.clear.type.310 = load i32, ptr %local.type.20, align 4
  %local.clear.live.payload.311 = select i1 %local.is.active.308, i32 %local.clear.payload.309, i32 0
  %local.clear.live.type.312 = select i1 %local.is.active.308, i32 %local.clear.type.310, i32 0
  %stack.offset.313 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.313, i32 8, i32 %local.clear.live.payload.311, i32 %local.clear.live.type.312)
  %context.field.314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.315 = load i32, ptr %context.field.314, align 4
  %runtime.ok.316 = icmp eq i32 %context.value.315, 0
  br i1 %runtime.ok.316, label %runtime.continue.317, label %frame.failure.0
runtime.continue.317:
  store i1 false, ptr %local.active.18, align 1
  store i32 0, ptr %local.payload.19, align 4
  store i32 0, ptr %local.type.20, align 4
  %cursor.check.318 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.319 = icmp eq i32 %cursor.check.318, 0
  br i1 %cursor.ok.319, label %cursor.continue.320, label %frame.failure.0
cursor.continue.320:
  %step.status.321 = call i32 @al_owning_charge_step(ptr %ctx, i32 92)
  %step.ok.322 = icmp eq i32 %step.status.321, 0
  br i1 %step.ok.322, label %step.continue.323, label %frame.failure.0
step.continue.323:
  %stack.offset.324 = add i32 %stack.offset.61, 8
  %reserve.status.325 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.324, i32 93)
  %reserve.ok.326 = icmp eq i32 %reserve.status.325, 0
  br i1 %reserve.ok.326, label %reserve.continue.327, label %frame.failure.0
reserve.continue.327:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %runtime.ok.330 = icmp eq i32 %context.value.329, 0
  br i1 %runtime.ok.330, label %runtime.continue.331, label %frame.failure.0
runtime.continue.331:
  %stack.offset.332 = add i32 %stack.offset.61, 8
  %cursor.check.333 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.332)
  %cursor.ok.334 = icmp eq i32 %cursor.check.333, 0
  br i1 %cursor.ok.334, label %cursor.continue.335, label %frame.failure.0
cursor.continue.335:
  %step.status.336 = call i32 @al_owning_charge_step(ptr %ctx, i32 94)
  %step.ok.337 = icmp eq i32 %step.status.336, 0
  br i1 %step.ok.337, label %step.continue.338, label %frame.failure.0
step.continue.338:
  %stack.offset.339 = add i32 %stack.offset.61, 8
  %reserve.status.340 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.339, i32 95)
  %reserve.ok.341 = icmp eq i32 %reserve.status.340, 0
  br i1 %reserve.ok.341, label %reserve.continue.342, label %frame.failure.0
reserve.continue.342:
  %callee.status.343 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 96)
  %callee.ok.344 = icmp eq i32 %callee.status.343, 0
  br i1 %callee.ok.344, label %callee.returned.345, label %frame.failure.0
callee.returned.345:
  %stack.offset.346 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.346, i32 0, i32 0, i32 0)
  %context.field.347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.348 = load i32, ptr %context.field.347, align 4
  %runtime.ok.349 = icmp eq i32 %context.value.348, 0
  br i1 %runtime.ok.349, label %runtime.continue.350, label %frame.failure.0
runtime.continue.350:
  %stack.offset.351 = add i32 %stack.offset.61, 8
  %cursor.check.352 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.351)
  %cursor.ok.353 = icmp eq i32 %cursor.check.352, 0
  br i1 %cursor.ok.353, label %cursor.continue.354, label %frame.failure.0
cursor.continue.354:
  %step.status.355 = call i32 @al_owning_charge_step(ptr %ctx, i32 97)
  %step.ok.356 = icmp eq i32 %step.status.355, 0
  br i1 %step.ok.356, label %step.continue.357, label %frame.failure.0
step.continue.357:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %step.status.358 = call i32 @al_owning_charge_step(ptr %ctx, i32 98)
  %step.ok.359 = icmp eq i32 %step.status.358, 0
  br i1 %step.ok.359, label %step.continue.360, label %frame.failure.0
step.continue.360:
  %local.is.active.361 = load i1, ptr %local.active.21, align 1
  %local.previous.payload.362 = load i32, ptr %local.payload.22, align 4
  %local.old.payload.363 = select i1 %local.is.active.361, i32 %local.previous.payload.362, i32 0
  %stack.offset.364 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.364, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.363, i32 1)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  store i1 true, ptr %local.active.21, align 1
  store i32 8, ptr %local.payload.22, align 4
  store i32 1, ptr %local.type.23, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %runtime.ok.371 = icmp eq i32 %context.value.370, 0
  br i1 %runtime.ok.371, label %runtime.continue.372, label %frame.failure.0
runtime.continue.372:
  %cursor.check.373 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.374 = icmp eq i32 %cursor.check.373, 0
  br i1 %cursor.ok.374, label %cursor.continue.375, label %frame.failure.0
cursor.continue.375:
  %local.is.active.376 = load i1, ptr %local.active.21, align 1
  %local.clear.payload.377 = load i32, ptr %local.payload.22, align 4
  %local.clear.type.378 = load i32, ptr %local.type.23, align 4
  %local.clear.live.payload.379 = select i1 %local.is.active.376, i32 %local.clear.payload.377, i32 0
  %local.clear.live.type.380 = select i1 %local.is.active.376, i32 %local.clear.type.378, i32 0
  %stack.offset.381 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.381, i32 8, i32 %local.clear.live.payload.379, i32 %local.clear.live.type.380)
  %context.field.382 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.383 = load i32, ptr %context.field.382, align 4
  %runtime.ok.384 = icmp eq i32 %context.value.383, 0
  br i1 %runtime.ok.384, label %runtime.continue.385, label %frame.failure.0
runtime.continue.385:
  store i1 false, ptr %local.active.21, align 1
  store i32 0, ptr %local.payload.22, align 4
  store i32 0, ptr %local.type.23, align 4
  %cursor.check.386 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.387 = icmp eq i32 %cursor.check.386, 0
  br i1 %cursor.ok.387, label %cursor.continue.388, label %frame.failure.0
cursor.continue.388:
  %step.status.389 = call i32 @al_owning_charge_step(ptr %ctx, i32 99)
  %step.ok.390 = icmp eq i32 %step.status.389, 0
  br i1 %step.ok.390, label %step.continue.391, label %frame.failure.0
step.continue.391:
  %stack.offset.392 = add i32 %stack.offset.61, 8
  %reserve.status.393 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.392, i32 100)
  %reserve.ok.394 = icmp eq i32 %reserve.status.393, 0
  br i1 %reserve.ok.394, label %reserve.continue.395, label %frame.failure.0
reserve.continue.395:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.396 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.397 = load i32, ptr %context.field.396, align 4
  %runtime.ok.398 = icmp eq i32 %context.value.397, 0
  br i1 %runtime.ok.398, label %runtime.continue.399, label %frame.failure.0
runtime.continue.399:
  %stack.offset.400 = add i32 %stack.offset.61, 8
  %cursor.check.401 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.400)
  %cursor.ok.402 = icmp eq i32 %cursor.check.401, 0
  br i1 %cursor.ok.402, label %cursor.continue.403, label %frame.failure.0
cursor.continue.403:
  %step.status.404 = call i32 @al_owning_charge_step(ptr %ctx, i32 101)
  %step.ok.405 = icmp eq i32 %step.status.404, 0
  br i1 %step.ok.405, label %step.continue.406, label %frame.failure.0
step.continue.406:
  %stack.offset.407 = add i32 %stack.offset.61, 8
  %reserve.status.408 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.407, i32 102)
  %reserve.ok.409 = icmp eq i32 %reserve.status.408, 0
  br i1 %reserve.ok.409, label %reserve.continue.410, label %frame.failure.0
reserve.continue.410:
  %callee.status.411 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 103)
  %callee.ok.412 = icmp eq i32 %callee.status.411, 0
  br i1 %callee.ok.412, label %callee.returned.413, label %frame.failure.0
callee.returned.413:
  %stack.offset.414 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.414, i32 0, i32 0, i32 0)
  %context.field.415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.416 = load i32, ptr %context.field.415, align 4
  %runtime.ok.417 = icmp eq i32 %context.value.416, 0
  br i1 %runtime.ok.417, label %runtime.continue.418, label %frame.failure.0
runtime.continue.418:
  %stack.offset.419 = add i32 %stack.offset.61, 8
  %cursor.check.420 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.419)
  %cursor.ok.421 = icmp eq i32 %cursor.check.420, 0
  br i1 %cursor.ok.421, label %cursor.continue.422, label %frame.failure.0
cursor.continue.422:
  %step.status.423 = call i32 @al_owning_charge_step(ptr %ctx, i32 104)
  %step.ok.424 = icmp eq i32 %step.status.423, 0
  br i1 %step.ok.424, label %step.continue.425, label %frame.failure.0
step.continue.425:
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %step.status.426 = call i32 @al_owning_charge_step(ptr %ctx, i32 105)
  %step.ok.427 = icmp eq i32 %step.status.426, 0
  br i1 %step.ok.427, label %step.continue.428, label %frame.failure.0
step.continue.428:
  %local.is.active.429 = load i1, ptr %local.active.24, align 1
  %local.previous.payload.430 = load i32, ptr %local.payload.25, align 4
  %local.old.payload.431 = select i1 %local.is.active.429, i32 %local.previous.payload.430, i32 0
  %stack.offset.432 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.432, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.431, i32 1)
  %context.field.433 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.434 = load i32, ptr %context.field.433, align 4
  %runtime.ok.435 = icmp eq i32 %context.value.434, 0
  br i1 %runtime.ok.435, label %runtime.continue.436, label %frame.failure.0
runtime.continue.436:
  store i1 true, ptr %local.active.24, align 1
  store i32 8, ptr %local.payload.25, align 4
  store i32 1, ptr %local.type.26, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.438 = load i32, ptr %context.field.437, align 4
  %runtime.ok.439 = icmp eq i32 %context.value.438, 0
  br i1 %runtime.ok.439, label %runtime.continue.440, label %frame.failure.0
runtime.continue.440:
  %cursor.check.441 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.442 = icmp eq i32 %cursor.check.441, 0
  br i1 %cursor.ok.442, label %cursor.continue.443, label %frame.failure.0
cursor.continue.443:
  %local.is.active.444 = load i1, ptr %local.active.24, align 1
  %local.clear.payload.445 = load i32, ptr %local.payload.25, align 4
  %local.clear.type.446 = load i32, ptr %local.type.26, align 4
  %local.clear.live.payload.447 = select i1 %local.is.active.444, i32 %local.clear.payload.445, i32 0
  %local.clear.live.type.448 = select i1 %local.is.active.444, i32 %local.clear.type.446, i32 0
  %stack.offset.449 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.449, i32 8, i32 %local.clear.live.payload.447, i32 %local.clear.live.type.448)
  %context.field.450 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.451 = load i32, ptr %context.field.450, align 4
  %runtime.ok.452 = icmp eq i32 %context.value.451, 0
  br i1 %runtime.ok.452, label %runtime.continue.453, label %frame.failure.0
runtime.continue.453:
  store i1 false, ptr %local.active.24, align 1
  store i32 0, ptr %local.payload.25, align 4
  store i32 0, ptr %local.type.26, align 4
  %cursor.check.454 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.455 = icmp eq i32 %cursor.check.454, 0
  br i1 %cursor.ok.455, label %cursor.continue.456, label %frame.failure.0
cursor.continue.456:
  %step.status.457 = call i32 @al_owning_charge_step(ptr %ctx, i32 106)
  %step.ok.458 = icmp eq i32 %step.status.457, 0
  br i1 %step.ok.458, label %step.continue.459, label %frame.failure.0
step.continue.459:
  %stack.offset.460 = add i32 %stack.offset.61, 8
  %reserve.status.461 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.460, i32 107)
  %reserve.ok.462 = icmp eq i32 %reserve.status.461, 0
  br i1 %reserve.ok.462, label %reserve.continue.463, label %frame.failure.0
reserve.continue.463:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.464 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.465 = load i32, ptr %context.field.464, align 4
  %runtime.ok.466 = icmp eq i32 %context.value.465, 0
  br i1 %runtime.ok.466, label %runtime.continue.467, label %frame.failure.0
runtime.continue.467:
  %stack.offset.468 = add i32 %stack.offset.61, 8
  %cursor.check.469 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.468)
  %cursor.ok.470 = icmp eq i32 %cursor.check.469, 0
  br i1 %cursor.ok.470, label %cursor.continue.471, label %frame.failure.0
cursor.continue.471:
  %step.status.472 = call i32 @al_owning_charge_step(ptr %ctx, i32 108)
  %step.ok.473 = icmp eq i32 %step.status.472, 0
  br i1 %step.ok.473, label %step.continue.474, label %frame.failure.0
step.continue.474:
  %stack.offset.475 = add i32 %stack.offset.61, 8
  %reserve.status.476 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.475, i32 109)
  %reserve.ok.477 = icmp eq i32 %reserve.status.476, 0
  br i1 %reserve.ok.477, label %reserve.continue.478, label %frame.failure.0
reserve.continue.478:
  %callee.status.479 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 110)
  %callee.ok.480 = icmp eq i32 %callee.status.479, 0
  br i1 %callee.ok.480, label %callee.returned.481, label %frame.failure.0
callee.returned.481:
  %stack.offset.482 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.482, i32 0, i32 0, i32 0)
  %context.field.483 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.484 = load i32, ptr %context.field.483, align 4
  %runtime.ok.485 = icmp eq i32 %context.value.484, 0
  br i1 %runtime.ok.485, label %runtime.continue.486, label %frame.failure.0
runtime.continue.486:
  %stack.offset.487 = add i32 %stack.offset.61, 8
  %cursor.check.488 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.487)
  %cursor.ok.489 = icmp eq i32 %cursor.check.488, 0
  br i1 %cursor.ok.489, label %cursor.continue.490, label %frame.failure.0
cursor.continue.490:
  %step.status.491 = call i32 @al_owning_charge_step(ptr %ctx, i32 111)
  %step.ok.492 = icmp eq i32 %step.status.491, 0
  br i1 %step.ok.492, label %step.continue.493, label %frame.failure.0
step.continue.493:
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  %step.status.494 = call i32 @al_owning_charge_step(ptr %ctx, i32 112)
  %step.ok.495 = icmp eq i32 %step.status.494, 0
  br i1 %step.ok.495, label %step.continue.496, label %frame.failure.0
step.continue.496:
  %local.is.active.497 = load i1, ptr %local.active.27, align 1
  %local.previous.payload.498 = load i32, ptr %local.payload.28, align 4
  %local.old.payload.499 = select i1 %local.is.active.497, i32 %local.previous.payload.498, i32 0
  %stack.offset.500 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.500, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.499, i32 1)
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  %runtime.ok.503 = icmp eq i32 %context.value.502, 0
  br i1 %runtime.ok.503, label %runtime.continue.504, label %frame.failure.0
runtime.continue.504:
  store i1 true, ptr %local.active.27, align 1
  store i32 8, ptr %local.payload.28, align 4
  store i32 1, ptr %local.type.29, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %runtime.ok.507 = icmp eq i32 %context.value.506, 0
  br i1 %runtime.ok.507, label %runtime.continue.508, label %frame.failure.0
runtime.continue.508:
  %cursor.check.509 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.510 = icmp eq i32 %cursor.check.509, 0
  br i1 %cursor.ok.510, label %cursor.continue.511, label %frame.failure.0
cursor.continue.511:
  %local.is.active.512 = load i1, ptr %local.active.27, align 1
  %local.clear.payload.513 = load i32, ptr %local.payload.28, align 4
  %local.clear.type.514 = load i32, ptr %local.type.29, align 4
  %local.clear.live.payload.515 = select i1 %local.is.active.512, i32 %local.clear.payload.513, i32 0
  %local.clear.live.type.516 = select i1 %local.is.active.512, i32 %local.clear.type.514, i32 0
  %stack.offset.517 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.517, i32 8, i32 %local.clear.live.payload.515, i32 %local.clear.live.type.516)
  %context.field.518 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.519 = load i32, ptr %context.field.518, align 4
  %runtime.ok.520 = icmp eq i32 %context.value.519, 0
  br i1 %runtime.ok.520, label %runtime.continue.521, label %frame.failure.0
runtime.continue.521:
  store i1 false, ptr %local.active.27, align 1
  store i32 0, ptr %local.payload.28, align 4
  store i32 0, ptr %local.type.29, align 4
  %cursor.check.522 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.523 = icmp eq i32 %cursor.check.522, 0
  br i1 %cursor.ok.523, label %cursor.continue.524, label %frame.failure.0
cursor.continue.524:
  %step.status.525 = call i32 @al_owning_charge_step(ptr %ctx, i32 113)
  %step.ok.526 = icmp eq i32 %step.status.525, 0
  br i1 %step.ok.526, label %step.continue.527, label %frame.failure.0
step.continue.527:
  %stack.offset.528 = add i32 %stack.offset.61, 8
  %reserve.status.529 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.528, i32 114)
  %reserve.ok.530 = icmp eq i32 %reserve.status.529, 0
  br i1 %reserve.ok.530, label %reserve.continue.531, label %frame.failure.0
reserve.continue.531:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.533 = load i32, ptr %context.field.532, align 4
  %runtime.ok.534 = icmp eq i32 %context.value.533, 0
  br i1 %runtime.ok.534, label %runtime.continue.535, label %frame.failure.0
runtime.continue.535:
  %stack.offset.536 = add i32 %stack.offset.61, 8
  %cursor.check.537 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.536)
  %cursor.ok.538 = icmp eq i32 %cursor.check.537, 0
  br i1 %cursor.ok.538, label %cursor.continue.539, label %frame.failure.0
cursor.continue.539:
  %step.status.540 = call i32 @al_owning_charge_step(ptr %ctx, i32 115)
  %step.ok.541 = icmp eq i32 %step.status.540, 0
  br i1 %step.ok.541, label %step.continue.542, label %frame.failure.0
step.continue.542:
  %stack.offset.543 = add i32 %stack.offset.61, 8
  %reserve.status.544 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.543, i32 116)
  %reserve.ok.545 = icmp eq i32 %reserve.status.544, 0
  br i1 %reserve.ok.545, label %reserve.continue.546, label %frame.failure.0
reserve.continue.546:
  %callee.status.547 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 117)
  %callee.ok.548 = icmp eq i32 %callee.status.547, 0
  br i1 %callee.ok.548, label %callee.returned.549, label %frame.failure.0
callee.returned.549:
  %stack.offset.550 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.550, i32 0, i32 0, i32 0)
  %context.field.551 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.552 = load i32, ptr %context.field.551, align 4
  %runtime.ok.553 = icmp eq i32 %context.value.552, 0
  br i1 %runtime.ok.553, label %runtime.continue.554, label %frame.failure.0
runtime.continue.554:
  %stack.offset.555 = add i32 %stack.offset.61, 8
  %cursor.check.556 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.555)
  %cursor.ok.557 = icmp eq i32 %cursor.check.556, 0
  br i1 %cursor.ok.557, label %cursor.continue.558, label %frame.failure.0
cursor.continue.558:
  %step.status.559 = call i32 @al_owning_charge_step(ptr %ctx, i32 118)
  %step.ok.560 = icmp eq i32 %step.status.559, 0
  br i1 %step.ok.560, label %step.continue.561, label %frame.failure.0
step.continue.561:
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %step.status.562 = call i32 @al_owning_charge_step(ptr %ctx, i32 119)
  %step.ok.563 = icmp eq i32 %step.status.562, 0
  br i1 %step.ok.563, label %step.continue.564, label %frame.failure.0
step.continue.564:
  %local.is.active.565 = load i1, ptr %local.active.30, align 1
  %local.previous.payload.566 = load i32, ptr %local.payload.31, align 4
  %local.old.payload.567 = select i1 %local.is.active.565, i32 %local.previous.payload.566, i32 0
  %stack.offset.568 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.568, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.567, i32 1)
  %context.field.569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.570 = load i32, ptr %context.field.569, align 4
  %runtime.ok.571 = icmp eq i32 %context.value.570, 0
  br i1 %runtime.ok.571, label %runtime.continue.572, label %frame.failure.0
runtime.continue.572:
  store i1 true, ptr %local.active.30, align 1
  store i32 8, ptr %local.payload.31, align 4
  store i32 1, ptr %local.type.32, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.573 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.574 = load i32, ptr %context.field.573, align 4
  %runtime.ok.575 = icmp eq i32 %context.value.574, 0
  br i1 %runtime.ok.575, label %runtime.continue.576, label %frame.failure.0
runtime.continue.576:
  %cursor.check.577 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.578 = icmp eq i32 %cursor.check.577, 0
  br i1 %cursor.ok.578, label %cursor.continue.579, label %frame.failure.0
cursor.continue.579:
  %local.is.active.580 = load i1, ptr %local.active.30, align 1
  %local.clear.payload.581 = load i32, ptr %local.payload.31, align 4
  %local.clear.type.582 = load i32, ptr %local.type.32, align 4
  %local.clear.live.payload.583 = select i1 %local.is.active.580, i32 %local.clear.payload.581, i32 0
  %local.clear.live.type.584 = select i1 %local.is.active.580, i32 %local.clear.type.582, i32 0
  %stack.offset.585 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.585, i32 8, i32 %local.clear.live.payload.583, i32 %local.clear.live.type.584)
  %context.field.586 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.587 = load i32, ptr %context.field.586, align 4
  %runtime.ok.588 = icmp eq i32 %context.value.587, 0
  br i1 %runtime.ok.588, label %runtime.continue.589, label %frame.failure.0
runtime.continue.589:
  store i1 false, ptr %local.active.30, align 1
  store i32 0, ptr %local.payload.31, align 4
  store i32 0, ptr %local.type.32, align 4
  %cursor.check.590 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.591 = icmp eq i32 %cursor.check.590, 0
  br i1 %cursor.ok.591, label %cursor.continue.592, label %frame.failure.0
cursor.continue.592:
  %step.status.593 = call i32 @al_owning_charge_step(ptr %ctx, i32 120)
  %step.ok.594 = icmp eq i32 %step.status.593, 0
  br i1 %step.ok.594, label %step.continue.595, label %frame.failure.0
step.continue.595:
  %stack.offset.596 = add i32 %stack.offset.61, 8
  %reserve.status.597 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.596, i32 121)
  %reserve.ok.598 = icmp eq i32 %reserve.status.597, 0
  br i1 %reserve.ok.598, label %reserve.continue.599, label %frame.failure.0
reserve.continue.599:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.600 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.601 = load i32, ptr %context.field.600, align 4
  %runtime.ok.602 = icmp eq i32 %context.value.601, 0
  br i1 %runtime.ok.602, label %runtime.continue.603, label %frame.failure.0
runtime.continue.603:
  %stack.offset.604 = add i32 %stack.offset.61, 8
  %cursor.check.605 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.604)
  %cursor.ok.606 = icmp eq i32 %cursor.check.605, 0
  br i1 %cursor.ok.606, label %cursor.continue.607, label %frame.failure.0
cursor.continue.607:
  %step.status.608 = call i32 @al_owning_charge_step(ptr %ctx, i32 122)
  %step.ok.609 = icmp eq i32 %step.status.608, 0
  br i1 %step.ok.609, label %step.continue.610, label %frame.failure.0
step.continue.610:
  %stack.offset.611 = add i32 %stack.offset.61, 8
  %reserve.status.612 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.611, i32 123)
  %reserve.ok.613 = icmp eq i32 %reserve.status.612, 0
  br i1 %reserve.ok.613, label %reserve.continue.614, label %frame.failure.0
reserve.continue.614:
  %callee.status.615 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 124)
  %callee.ok.616 = icmp eq i32 %callee.status.615, 0
  br i1 %callee.ok.616, label %callee.returned.617, label %frame.failure.0
callee.returned.617:
  %stack.offset.618 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.618, i32 0, i32 0, i32 0)
  %context.field.619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.620 = load i32, ptr %context.field.619, align 4
  %runtime.ok.621 = icmp eq i32 %context.value.620, 0
  br i1 %runtime.ok.621, label %runtime.continue.622, label %frame.failure.0
runtime.continue.622:
  %stack.offset.623 = add i32 %stack.offset.61, 8
  %cursor.check.624 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.623)
  %cursor.ok.625 = icmp eq i32 %cursor.check.624, 0
  br i1 %cursor.ok.625, label %cursor.continue.626, label %frame.failure.0
cursor.continue.626:
  %step.status.627 = call i32 @al_owning_charge_step(ptr %ctx, i32 125)
  %step.ok.628 = icmp eq i32 %step.status.627, 0
  br i1 %step.ok.628, label %step.continue.629, label %frame.failure.0
step.continue.629:
  store i1 false, ptr %local.active.33, align 1
  store i32 0, ptr %local.payload.34, align 4
  store i32 0, ptr %local.type.35, align 4
  %step.status.630 = call i32 @al_owning_charge_step(ptr %ctx, i32 126)
  %step.ok.631 = icmp eq i32 %step.status.630, 0
  br i1 %step.ok.631, label %step.continue.632, label %frame.failure.0
step.continue.632:
  %local.is.active.633 = load i1, ptr %local.active.33, align 1
  %local.previous.payload.634 = load i32, ptr %local.payload.34, align 4
  %local.old.payload.635 = select i1 %local.is.active.633, i32 %local.previous.payload.634, i32 0
  %stack.offset.636 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.636, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.635, i32 1)
  %context.field.637 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.638 = load i32, ptr %context.field.637, align 4
  %runtime.ok.639 = icmp eq i32 %context.value.638, 0
  br i1 %runtime.ok.639, label %runtime.continue.640, label %frame.failure.0
runtime.continue.640:
  store i1 true, ptr %local.active.33, align 1
  store i32 8, ptr %local.payload.34, align 4
  store i32 1, ptr %local.type.35, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.641 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.642 = load i32, ptr %context.field.641, align 4
  %runtime.ok.643 = icmp eq i32 %context.value.642, 0
  br i1 %runtime.ok.643, label %runtime.continue.644, label %frame.failure.0
runtime.continue.644:
  %cursor.check.645 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.646 = icmp eq i32 %cursor.check.645, 0
  br i1 %cursor.ok.646, label %cursor.continue.647, label %frame.failure.0
cursor.continue.647:
  %local.is.active.648 = load i1, ptr %local.active.33, align 1
  %local.clear.payload.649 = load i32, ptr %local.payload.34, align 4
  %local.clear.type.650 = load i32, ptr %local.type.35, align 4
  %local.clear.live.payload.651 = select i1 %local.is.active.648, i32 %local.clear.payload.649, i32 0
  %local.clear.live.type.652 = select i1 %local.is.active.648, i32 %local.clear.type.650, i32 0
  %stack.offset.653 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.653, i32 8, i32 %local.clear.live.payload.651, i32 %local.clear.live.type.652)
  %context.field.654 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.655 = load i32, ptr %context.field.654, align 4
  %runtime.ok.656 = icmp eq i32 %context.value.655, 0
  br i1 %runtime.ok.656, label %runtime.continue.657, label %frame.failure.0
runtime.continue.657:
  store i1 false, ptr %local.active.33, align 1
  store i32 0, ptr %local.payload.34, align 4
  store i32 0, ptr %local.type.35, align 4
  %cursor.check.658 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.659 = icmp eq i32 %cursor.check.658, 0
  br i1 %cursor.ok.659, label %cursor.continue.660, label %frame.failure.0
cursor.continue.660:
  %step.status.661 = call i32 @al_owning_charge_step(ptr %ctx, i32 127)
  %step.ok.662 = icmp eq i32 %step.status.661, 0
  br i1 %step.ok.662, label %step.continue.663, label %frame.failure.0
step.continue.663:
  %stack.offset.664 = add i32 %stack.offset.61, 8
  %reserve.status.665 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.664, i32 128)
  %reserve.ok.666 = icmp eq i32 %reserve.status.665, 0
  br i1 %reserve.ok.666, label %reserve.continue.667, label %frame.failure.0
reserve.continue.667:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.668 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.669 = load i32, ptr %context.field.668, align 4
  %runtime.ok.670 = icmp eq i32 %context.value.669, 0
  br i1 %runtime.ok.670, label %runtime.continue.671, label %frame.failure.0
runtime.continue.671:
  %stack.offset.672 = add i32 %stack.offset.61, 8
  %cursor.check.673 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.672)
  %cursor.ok.674 = icmp eq i32 %cursor.check.673, 0
  br i1 %cursor.ok.674, label %cursor.continue.675, label %frame.failure.0
cursor.continue.675:
  %step.status.676 = call i32 @al_owning_charge_step(ptr %ctx, i32 129)
  %step.ok.677 = icmp eq i32 %step.status.676, 0
  br i1 %step.ok.677, label %step.continue.678, label %frame.failure.0
step.continue.678:
  %stack.offset.679 = add i32 %stack.offset.61, 8
  %reserve.status.680 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.679, i32 130)
  %reserve.ok.681 = icmp eq i32 %reserve.status.680, 0
  br i1 %reserve.ok.681, label %reserve.continue.682, label %frame.failure.0
reserve.continue.682:
  %callee.status.683 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 131)
  %callee.ok.684 = icmp eq i32 %callee.status.683, 0
  br i1 %callee.ok.684, label %callee.returned.685, label %frame.failure.0
callee.returned.685:
  %stack.offset.686 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.686, i32 0, i32 0, i32 0)
  %context.field.687 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.688 = load i32, ptr %context.field.687, align 4
  %runtime.ok.689 = icmp eq i32 %context.value.688, 0
  br i1 %runtime.ok.689, label %runtime.continue.690, label %frame.failure.0
runtime.continue.690:
  %stack.offset.691 = add i32 %stack.offset.61, 8
  %cursor.check.692 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.691)
  %cursor.ok.693 = icmp eq i32 %cursor.check.692, 0
  br i1 %cursor.ok.693, label %cursor.continue.694, label %frame.failure.0
cursor.continue.694:
  %step.status.695 = call i32 @al_owning_charge_step(ptr %ctx, i32 132)
  %step.ok.696 = icmp eq i32 %step.status.695, 0
  br i1 %step.ok.696, label %step.continue.697, label %frame.failure.0
step.continue.697:
  store i1 false, ptr %local.active.36, align 1
  store i32 0, ptr %local.payload.37, align 4
  store i32 0, ptr %local.type.38, align 4
  %step.status.698 = call i32 @al_owning_charge_step(ptr %ctx, i32 133)
  %step.ok.699 = icmp eq i32 %step.status.698, 0
  br i1 %step.ok.699, label %step.continue.700, label %frame.failure.0
step.continue.700:
  %local.is.active.701 = load i1, ptr %local.active.36, align 1
  %local.previous.payload.702 = load i32, ptr %local.payload.37, align 4
  %local.old.payload.703 = select i1 %local.is.active.701, i32 %local.previous.payload.702, i32 0
  %stack.offset.704 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.704, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.703, i32 1)
  %context.field.705 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.706 = load i32, ptr %context.field.705, align 4
  %runtime.ok.707 = icmp eq i32 %context.value.706, 0
  br i1 %runtime.ok.707, label %runtime.continue.708, label %frame.failure.0
runtime.continue.708:
  store i1 true, ptr %local.active.36, align 1
  store i32 8, ptr %local.payload.37, align 4
  store i32 1, ptr %local.type.38, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.710 = load i32, ptr %context.field.709, align 4
  %runtime.ok.711 = icmp eq i32 %context.value.710, 0
  br i1 %runtime.ok.711, label %runtime.continue.712, label %frame.failure.0
runtime.continue.712:
  %cursor.check.713 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.714 = icmp eq i32 %cursor.check.713, 0
  br i1 %cursor.ok.714, label %cursor.continue.715, label %frame.failure.0
cursor.continue.715:
  %local.is.active.716 = load i1, ptr %local.active.36, align 1
  %local.clear.payload.717 = load i32, ptr %local.payload.37, align 4
  %local.clear.type.718 = load i32, ptr %local.type.38, align 4
  %local.clear.live.payload.719 = select i1 %local.is.active.716, i32 %local.clear.payload.717, i32 0
  %local.clear.live.type.720 = select i1 %local.is.active.716, i32 %local.clear.type.718, i32 0
  %stack.offset.721 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.721, i32 8, i32 %local.clear.live.payload.719, i32 %local.clear.live.type.720)
  %context.field.722 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.723 = load i32, ptr %context.field.722, align 4
  %runtime.ok.724 = icmp eq i32 %context.value.723, 0
  br i1 %runtime.ok.724, label %runtime.continue.725, label %frame.failure.0
runtime.continue.725:
  store i1 false, ptr %local.active.36, align 1
  store i32 0, ptr %local.payload.37, align 4
  store i32 0, ptr %local.type.38, align 4
  %cursor.check.726 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.727 = icmp eq i32 %cursor.check.726, 0
  br i1 %cursor.ok.727, label %cursor.continue.728, label %frame.failure.0
cursor.continue.728:
  %step.status.729 = call i32 @al_owning_charge_step(ptr %ctx, i32 134)
  %step.ok.730 = icmp eq i32 %step.status.729, 0
  br i1 %step.ok.730, label %step.continue.731, label %frame.failure.0
step.continue.731:
  %stack.offset.732 = add i32 %stack.offset.61, 8
  %reserve.status.733 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.732, i32 135)
  %reserve.ok.734 = icmp eq i32 %reserve.status.733, 0
  br i1 %reserve.ok.734, label %reserve.continue.735, label %frame.failure.0
reserve.continue.735:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.737 = load i32, ptr %context.field.736, align 4
  %runtime.ok.738 = icmp eq i32 %context.value.737, 0
  br i1 %runtime.ok.738, label %runtime.continue.739, label %frame.failure.0
runtime.continue.739:
  %stack.offset.740 = add i32 %stack.offset.61, 8
  %cursor.check.741 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.740)
  %cursor.ok.742 = icmp eq i32 %cursor.check.741, 0
  br i1 %cursor.ok.742, label %cursor.continue.743, label %frame.failure.0
cursor.continue.743:
  %step.status.744 = call i32 @al_owning_charge_step(ptr %ctx, i32 136)
  %step.ok.745 = icmp eq i32 %step.status.744, 0
  br i1 %step.ok.745, label %step.continue.746, label %frame.failure.0
step.continue.746:
  %stack.offset.747 = add i32 %stack.offset.61, 8
  %reserve.status.748 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.747, i32 137)
  %reserve.ok.749 = icmp eq i32 %reserve.status.748, 0
  br i1 %reserve.ok.749, label %reserve.continue.750, label %frame.failure.0
reserve.continue.750:
  %callee.status.751 = call i32 @agentlang_word_0000(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 138)
  %callee.ok.752 = icmp eq i32 %callee.status.751, 0
  br i1 %callee.ok.752, label %callee.returned.753, label %frame.failure.0
callee.returned.753:
  %stack.offset.754 = add i32 %stack.offset.61, 8
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.754, i32 0, i32 0, i32 0)
  %context.field.755 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.756 = load i32, ptr %context.field.755, align 4
  %runtime.ok.757 = icmp eq i32 %context.value.756, 0
  br i1 %runtime.ok.757, label %runtime.continue.758, label %frame.failure.0
runtime.continue.758:
  %stack.offset.759 = add i32 %stack.offset.61, 8
  %cursor.check.760 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.759)
  %cursor.ok.761 = icmp eq i32 %cursor.check.760, 0
  br i1 %cursor.ok.761, label %cursor.continue.762, label %frame.failure.0
cursor.continue.762:
  %step.status.763 = call i32 @al_owning_charge_step(ptr %ctx, i32 139)
  %step.ok.764 = icmp eq i32 %step.status.763, 0
  br i1 %step.ok.764, label %step.continue.765, label %frame.failure.0
step.continue.765:
  store i1 false, ptr %local.active.39, align 1
  store i32 0, ptr %local.payload.40, align 4
  store i32 0, ptr %local.type.41, align 4
  %step.status.766 = call i32 @al_owning_charge_step(ptr %ctx, i32 140)
  %step.ok.767 = icmp eq i32 %step.status.766, 0
  br i1 %step.ok.767, label %step.continue.768, label %frame.failure.0
step.continue.768:
  %local.is.active.769 = load i1, ptr %local.active.39, align 1
  %local.previous.payload.770 = load i32, ptr %local.payload.40, align 4
  %local.old.payload.771 = select i1 %local.is.active.769, i32 %local.previous.payload.770, i32 0
  %stack.offset.772 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.772, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.771, i32 1)
  %context.field.773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.774 = load i32, ptr %context.field.773, align 4
  %runtime.ok.775 = icmp eq i32 %context.value.774, 0
  br i1 %runtime.ok.775, label %runtime.continue.776, label %frame.failure.0
runtime.continue.776:
  store i1 true, ptr %local.active.39, align 1
  store i32 8, ptr %local.payload.40, align 4
  store i32 1, ptr %local.type.41, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.778 = load i32, ptr %context.field.777, align 4
  %runtime.ok.779 = icmp eq i32 %context.value.778, 0
  br i1 %runtime.ok.779, label %runtime.continue.780, label %frame.failure.0
runtime.continue.780:
  %cursor.check.781 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.782 = icmp eq i32 %cursor.check.781, 0
  br i1 %cursor.ok.782, label %cursor.continue.783, label %frame.failure.0
cursor.continue.783:
  %local.is.active.784 = load i1, ptr %local.active.39, align 1
  %local.clear.payload.785 = load i32, ptr %local.payload.40, align 4
  %local.clear.type.786 = load i32, ptr %local.type.41, align 4
  %local.clear.live.payload.787 = select i1 %local.is.active.784, i32 %local.clear.payload.785, i32 0
  %local.clear.live.type.788 = select i1 %local.is.active.784, i32 %local.clear.type.786, i32 0
  %stack.offset.789 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.789, i32 8, i32 %local.clear.live.payload.787, i32 %local.clear.live.type.788)
  %context.field.790 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.791 = load i32, ptr %context.field.790, align 4
  %runtime.ok.792 = icmp eq i32 %context.value.791, 0
  br i1 %runtime.ok.792, label %runtime.continue.793, label %frame.failure.0
runtime.continue.793:
  store i1 false, ptr %local.active.39, align 1
  store i32 0, ptr %local.payload.40, align 4
  store i32 0, ptr %local.type.41, align 4
  %cursor.check.794 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.795 = icmp eq i32 %cursor.check.794, 0
  br i1 %cursor.ok.795, label %cursor.continue.796, label %frame.failure.0
cursor.continue.796:
  %step.status.797 = call i32 @al_owning_charge_step(ptr %ctx, i32 141)
  %step.ok.798 = icmp eq i32 %step.status.797, 0
  br i1 %step.ok.798, label %step.continue.799, label %frame.failure.0
step.continue.799:
  %stack.offset.800 = add i32 %stack.offset.61, 16
  %reserve.status.801 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.800, i32 142)
  %reserve.ok.802 = icmp eq i32 %reserve.status.801, 0
  br i1 %reserve.ok.802, label %reserve.continue.803, label %frame.failure.0
reserve.continue.803:
  %stack.offset.804 = add i32 %context.value.60, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.804, i32 16, i32 16, i32 5)
  %context.field.805 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.806 = load i32, ptr %context.field.805, align 4
  %runtime.ok.807 = icmp eq i32 %context.value.806, 0
  br i1 %runtime.ok.807, label %runtime.continue.808, label %frame.failure.0
runtime.continue.808:
  %stack.offset.809 = add i32 %stack.offset.61, 16
  %cursor.check.810 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.809)
  %cursor.ok.811 = icmp eq i32 %cursor.check.810, 0
  br i1 %cursor.ok.811, label %cursor.continue.812, label %frame.failure.0
cursor.continue.812:
  %step.status.813 = call i32 @al_owning_charge_step(ptr %ctx, i32 143)
  %step.ok.814 = icmp eq i32 %step.status.813, 0
  br i1 %step.ok.814, label %step.continue.815, label %frame.failure.0
step.continue.815:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 8, i32 8, i32 6, i32 7)
  %context.field.816 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.817 = load i32, ptr %context.field.816, align 4
  %runtime.ok.818 = icmp eq i32 %context.value.817, 0
  br i1 %runtime.ok.818, label %runtime.continue.819, label %frame.failure.0
runtime.continue.819:
  %stack.offset.820 = add i32 %stack.offset.61, 8
  %stack.offset.821 = add i32 %stack.offset.61, 16
  %field.grows.822 = icmp ugt i32 %stack.offset.820, %stack.offset.821
  br i1 %field.grows.822, label %field.reserve.823, label %field.release.824
field.reserve.823:
  %reserve.status.826 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.820, i32 144)
  %reserve.ok.827 = icmp eq i32 %reserve.status.826, 0
  br i1 %reserve.ok.827, label %reserve.continue.828, label %frame.failure.0
reserve.continue.828:
  br label %field.ready.825
field.release.824:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.820, i32 0, i32 6, i32 8)
  %context.field.829 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.830 = load i32, ptr %context.field.829, align 4
  %runtime.ok.831 = icmp eq i32 %context.value.830, 0
  br i1 %runtime.ok.831, label %runtime.continue.832, label %frame.failure.0
runtime.continue.832:
  br label %field.ready.825
field.ready.825:
  call void @al_owning_update_live(ptr %ctx, i32 -8, i32 0)
  %context.field.833 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.834 = load i32, ptr %context.field.833, align 4
  %runtime.ok.835 = icmp eq i32 %context.value.834, 0
  br i1 %runtime.ok.835, label %runtime.continue.836, label %frame.failure.0
runtime.continue.836:
  %stack.offset.837 = add i32 %stack.offset.61, 8
  %cursor.check.838 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.837)
  %cursor.ok.839 = icmp eq i32 %cursor.check.838, 0
  br i1 %cursor.ok.839, label %cursor.continue.840, label %frame.failure.0
cursor.continue.840:
  %step.status.841 = call i32 @al_owning_charge_step(ptr %ctx, i32 145)
  %step.ok.842 = icmp eq i32 %step.status.841, 0
  br i1 %step.ok.842, label %step.continue.843, label %frame.failure.0
step.continue.843:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 8, i32 8, i32 1, i32 7)
  %context.field.844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.845 = load i32, ptr %context.field.844, align 4
  %runtime.ok.846 = icmp eq i32 %context.value.845, 0
  br i1 %runtime.ok.846, label %runtime.continue.847, label %frame.failure.0
runtime.continue.847:
  %stack.offset.848 = add i32 %stack.offset.61, 8
  %stack.offset.849 = add i32 %stack.offset.61, 8
  %field.grows.850 = icmp ugt i32 %stack.offset.848, %stack.offset.849
  br i1 %field.grows.850, label %field.reserve.851, label %field.release.852
field.reserve.851:
  %reserve.status.854 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.848, i32 146)
  %reserve.ok.855 = icmp eq i32 %reserve.status.854, 0
  br i1 %reserve.ok.855, label %reserve.continue.856, label %frame.failure.0
reserve.continue.856:
  br label %field.ready.853
field.release.852:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.848, i32 0, i32 1, i32 8)
  %context.field.857 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.858 = load i32, ptr %context.field.857, align 4
  %runtime.ok.859 = icmp eq i32 %context.value.858, 0
  br i1 %runtime.ok.859, label %runtime.continue.860, label %frame.failure.0
runtime.continue.860:
  br label %field.ready.853
field.ready.853:
  %stack.offset.861 = add i32 %stack.offset.61, 8
  %cursor.check.862 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.861)
  %cursor.ok.863 = icmp eq i32 %cursor.check.862, 0
  br i1 %cursor.ok.863, label %cursor.continue.864, label %frame.failure.0
cursor.continue.864:
  %step.status.865 = call i32 @al_owning_charge_step(ptr %ctx, i32 147)
  %step.ok.866 = icmp eq i32 %step.status.865, 0
  br i1 %step.ok.866, label %step.continue.867, label %frame.failure.0
step.continue.867:
  %local.is.active.868 = load i1, ptr %local.active.12, align 1
  %local.previous.payload.869 = load i32, ptr %local.payload.13, align 4
  %local.old.payload.870 = select i1 %local.is.active.868, i32 %local.previous.payload.869, i32 0
  %stack.offset.871 = add i32 %context.value.60, 48
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.871, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.870, i32 1)
  %context.field.872 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.873 = load i32, ptr %context.field.872, align 4
  %runtime.ok.874 = icmp eq i32 %context.value.873, 0
  br i1 %runtime.ok.874, label %runtime.continue.875, label %frame.failure.0
runtime.continue.875:
  store i1 true, ptr %local.active.12, align 1
  store i32 8, ptr %local.payload.13, align 4
  store i32 1, ptr %local.type.14, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.877 = load i32, ptr %context.field.876, align 4
  %runtime.ok.878 = icmp eq i32 %context.value.877, 0
  br i1 %runtime.ok.878, label %runtime.continue.879, label %frame.failure.0
runtime.continue.879:
  %cursor.check.880 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.881 = icmp eq i32 %cursor.check.880, 0
  br i1 %cursor.ok.881, label %cursor.continue.882, label %frame.failure.0
cursor.continue.882:
  %step.status.883 = call i32 @al_owning_charge_step(ptr %ctx, i32 148)
  %step.ok.884 = icmp eq i32 %step.status.883, 0
  br i1 %step.ok.884, label %step.continue.885, label %frame.failure.0
step.continue.885:
  %stack.offset.886 = add i32 %stack.offset.61, 8
  %reserve.status.887 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.886, i32 149)
  %reserve.ok.888 = icmp eq i32 %reserve.status.887, 0
  br i1 %reserve.ok.888, label %reserve.continue.889, label %frame.failure.0
reserve.continue.889:
  %stack.offset.890 = add i32 %context.value.60, 48
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.890, i32 8, i32 8, i32 1)
  %context.field.891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.892 = load i32, ptr %context.field.891, align 4
  %runtime.ok.893 = icmp eq i32 %context.value.892, 0
  br i1 %runtime.ok.893, label %runtime.continue.894, label %frame.failure.0
runtime.continue.894:
  %stack.offset.895 = add i32 %stack.offset.61, 8
  %cursor.check.896 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.895)
  %cursor.ok.897 = icmp eq i32 %cursor.check.896, 0
  br i1 %cursor.ok.897, label %cursor.continue.898, label %frame.failure.0
cursor.continue.898:
  %step.status.899 = call i32 @al_owning_charge_step(ptr %ctx, i32 150)
  %step.ok.900 = icmp eq i32 %step.status.899, 0
  br i1 %step.ok.900, label %step.continue.901, label %frame.failure.0
step.continue.901:
  %stack.offset.902 = add i32 %stack.offset.61, 8
  %stack.offset.903 = add i32 %stack.offset.902, 8
  %reserve.status.904 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.903, i32 151)
  %reserve.ok.905 = icmp eq i32 %reserve.status.904, 0
  br i1 %reserve.ok.905, label %reserve.continue.906, label %frame.failure.0
reserve.continue.906:
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.902, i32 %context.value.60, i32 8, i32 8, i32 1)
  %context.field.907 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.908 = load i32, ptr %context.field.907, align 4
  %runtime.ok.909 = icmp eq i32 %context.value.908, 0
  br i1 %runtime.ok.909, label %runtime.continue.910, label %frame.failure.0
runtime.continue.910:
  %stack.offset.911 = add i32 %stack.offset.61, 16
  %cursor.check.912 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.911)
  %cursor.ok.913 = icmp eq i32 %cursor.check.912, 0
  br i1 %cursor.ok.913, label %cursor.continue.914, label %frame.failure.0
cursor.continue.914:
  %step.status.915 = call i32 @al_owning_charge_step(ptr %ctx, i32 152)
  %step.ok.916 = icmp eq i32 %step.status.915, 0
  br i1 %step.ok.916, label %step.continue.917, label %frame.failure.0
step.continue.917:
  %stack.offset.918 = add i32 %stack.offset.61, 8
  %equals.result.919 = call i32 @al_owning_equal(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.918, i32 8)
  %context.field.920 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.921 = load i32, ptr %context.field.920, align 4
  %runtime.ok.922 = icmp eq i32 %context.value.921, 0
  br i1 %runtime.ok.922, label %runtime.continue.923, label %frame.failure.0
runtime.continue.923:
  %equals.bool.924 = icmp ne i32 %equals.result.919, 0
  %equals.value.925 = zext i1 %equals.bool.924 to i64
  %stack.offset.926 = add i32 %stack.offset.61, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.926, i32 8, i32 8, i32 1)
  %context.field.927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.928 = load i32, ptr %context.field.927, align 4
  %runtime.ok.929 = icmp eq i32 %context.value.928, 0
  br i1 %runtime.ok.929, label %runtime.continue.930, label %frame.failure.0
runtime.continue.930:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.931 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.932 = load i32, ptr %context.field.931, align 4
  %runtime.ok.933 = icmp eq i32 %context.value.932, 0
  br i1 %runtime.ok.933, label %runtime.continue.934, label %frame.failure.0
runtime.continue.934:
  %stack.offset.935 = add i32 %stack.offset.61, 8
  %reserve.status.936 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.935, i32 153)
  %reserve.ok.937 = icmp eq i32 %reserve.status.936, 0
  br i1 %reserve.ok.937, label %reserve.continue.938, label %frame.failure.0
reserve.continue.938:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.61, i64 %equals.value.925, i32 2)
  %context.field.939 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.940 = load i32, ptr %context.field.939, align 4
  %runtime.ok.941 = icmp eq i32 %context.value.940, 0
  br i1 %runtime.ok.941, label %runtime.continue.942, label %frame.failure.0
runtime.continue.942:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.943 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.944 = load i32, ptr %context.field.943, align 4
  %runtime.ok.945 = icmp eq i32 %context.value.944, 0
  br i1 %runtime.ok.945, label %runtime.continue.946, label %frame.failure.0
runtime.continue.946:
  %stack.offset.947 = add i32 %stack.offset.61, 8
  %cursor.check.948 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.947)
  %cursor.ok.949 = icmp eq i32 %cursor.check.948, 0
  br i1 %cursor.ok.949, label %cursor.continue.950, label %frame.failure.0
cursor.continue.950:
  %step.status.951 = call i32 @al_owning_charge_step(ptr %ctx, i32 154)
  %step.ok.952 = icmp eq i32 %step.status.951, 0
  br i1 %step.ok.952, label %step.continue.953, label %frame.failure.0
step.continue.953:
  %if.condition.raw.954 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.61)
  %context.field.955 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.956 = load i32, ptr %context.field.955, align 4
  %runtime.ok.957 = icmp eq i32 %context.value.956, 0
  br i1 %runtime.ok.957, label %runtime.continue.958, label %frame.failure.0
runtime.continue.958:
  %if.condition.959 = icmp ne i64 %if.condition.raw.954, 0
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 2)
  %context.field.960 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.961 = load i32, ptr %context.field.960, align 4
  %runtime.ok.962 = icmp eq i32 %context.value.961, 0
  br i1 %runtime.ok.962, label %runtime.continue.963, label %frame.failure.0
runtime.continue.963:
  br i1 %if.condition.959, label %if.then.964, label %if.else.965
if.then.964:
  %step.status.967 = call i32 @al_owning_charge_step(ptr %ctx, i32 155)
  %step.ok.968 = icmp eq i32 %step.status.967, 0
  br i1 %step.ok.968, label %step.continue.969, label %frame.failure.0
step.continue.969:
  %step.status.970 = call i32 @al_owning_charge_step(ptr %ctx, i32 156)
  %step.ok.971 = icmp eq i32 %step.status.970, 0
  br i1 %step.ok.971, label %step.continue.972, label %frame.failure.0
step.continue.972:
  %stack.offset.973 = add i32 %stack.offset.61, 8
  %reserve.status.974 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.973, i32 157)
  %reserve.ok.975 = icmp eq i32 %reserve.status.974, 0
  br i1 %reserve.ok.975, label %reserve.continue.976, label %frame.failure.0
reserve.continue.976:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.61, i64 1, i32 1)
  %context.field.977 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.978 = load i32, ptr %context.field.977, align 4
  %runtime.ok.979 = icmp eq i32 %context.value.978, 0
  br i1 %runtime.ok.979, label %runtime.continue.980, label %frame.failure.0
runtime.continue.980:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.981 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.982 = load i32, ptr %context.field.981, align 4
  %runtime.ok.983 = icmp eq i32 %context.value.982, 0
  br i1 %runtime.ok.983, label %runtime.continue.984, label %frame.failure.0
runtime.continue.984:
  %stack.offset.985 = add i32 %stack.offset.61, 8
  %cursor.check.986 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.985)
  %cursor.ok.987 = icmp eq i32 %cursor.check.986, 0
  br i1 %cursor.ok.987, label %cursor.continue.988, label %frame.failure.0
cursor.continue.988:
  %stack.offset.989 = add i32 %stack.offset.61, 8
  %cursor.check.990 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.989)
  %cursor.ok.991 = icmp eq i32 %cursor.check.990, 0
  br i1 %cursor.ok.991, label %cursor.continue.992, label %frame.failure.0
cursor.continue.992:
  br label %if.join.966
if.else.965:
  %step.status.993 = call i32 @al_owning_charge_step(ptr %ctx, i32 158)
  %step.ok.994 = icmp eq i32 %step.status.993, 0
  br i1 %step.ok.994, label %step.continue.995, label %frame.failure.0
step.continue.995:
  %step.status.996 = call i32 @al_owning_charge_step(ptr %ctx, i32 159)
  %step.ok.997 = icmp eq i32 %step.status.996, 0
  br i1 %step.ok.997, label %step.continue.998, label %frame.failure.0
step.continue.998:
  %stack.offset.999 = add i32 %stack.offset.61, 8
  %reserve.status.1000 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.999, i32 160)
  %reserve.ok.1001 = icmp eq i32 %reserve.status.1000, 0
  br i1 %reserve.ok.1001, label %reserve.continue.1002, label %frame.failure.0
reserve.continue.1002:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.61, i64 2, i32 1)
  %context.field.1003 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1004 = load i32, ptr %context.field.1003, align 4
  %runtime.ok.1005 = icmp eq i32 %context.value.1004, 0
  br i1 %runtime.ok.1005, label %runtime.continue.1006, label %frame.failure.0
runtime.continue.1006:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1007 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1008 = load i32, ptr %context.field.1007, align 4
  %runtime.ok.1009 = icmp eq i32 %context.value.1008, 0
  br i1 %runtime.ok.1009, label %runtime.continue.1010, label %frame.failure.0
runtime.continue.1010:
  %stack.offset.1011 = add i32 %stack.offset.61, 8
  %cursor.check.1012 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1011)
  %cursor.ok.1013 = icmp eq i32 %cursor.check.1012, 0
  br i1 %cursor.ok.1013, label %cursor.continue.1014, label %frame.failure.0
cursor.continue.1014:
  %stack.offset.1015 = add i32 %stack.offset.61, 8
  %cursor.check.1016 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1015)
  %cursor.ok.1017 = icmp eq i32 %cursor.check.1016, 0
  br i1 %cursor.ok.1017, label %cursor.continue.1018, label %frame.failure.0
cursor.continue.1018:
  br label %if.join.966
if.join.966:
  %stack.offset.1019 = add i32 %stack.offset.61, 8
  %cursor.check.1020 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1019)
  %cursor.ok.1021 = icmp eq i32 %cursor.check.1020, 0
  br i1 %cursor.ok.1021, label %cursor.continue.1022, label %frame.failure.0
cursor.continue.1022:
  %step.status.1023 = call i32 @al_owning_charge_step(ptr %ctx, i32 161)
  %step.ok.1024 = icmp eq i32 %step.status.1023, 0
  br i1 %step.ok.1024, label %step.continue.1025, label %frame.failure.0
step.continue.1025:
  %local.is.active.1026 = load i1, ptr %local.active.15, align 1
  %local.previous.payload.1027 = load i32, ptr %local.payload.16, align 4
  %local.old.payload.1028 = select i1 %local.is.active.1026, i32 %local.previous.payload.1027, i32 0
  %stack.offset.1029 = add i32 %context.value.60, 56
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.1029, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.1028, i32 1)
  %context.field.1030 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1031 = load i32, ptr %context.field.1030, align 4
  %runtime.ok.1032 = icmp eq i32 %context.value.1031, 0
  br i1 %runtime.ok.1032, label %runtime.continue.1033, label %frame.failure.0
runtime.continue.1033:
  store i1 true, ptr %local.active.15, align 1
  store i32 8, ptr %local.payload.16, align 4
  store i32 1, ptr %local.type.17, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.1034 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1035 = load i32, ptr %context.field.1034, align 4
  %runtime.ok.1036 = icmp eq i32 %context.value.1035, 0
  br i1 %runtime.ok.1036, label %runtime.continue.1037, label %frame.failure.0
runtime.continue.1037:
  %cursor.check.1038 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.1039 = icmp eq i32 %cursor.check.1038, 0
  br i1 %cursor.ok.1039, label %cursor.continue.1040, label %frame.failure.0
cursor.continue.1040:
  %step.status.1041 = call i32 @al_owning_charge_step(ptr %ctx, i32 162)
  %step.ok.1042 = icmp eq i32 %step.status.1041, 0
  br i1 %step.ok.1042, label %step.continue.1043, label %frame.failure.0
step.continue.1043:
  store i1 false, ptr %local.active.42, align 1
  store i32 0, ptr %local.payload.43, align 4
  store i32 0, ptr %local.type.44, align 4
  store i1 false, ptr %local.active.45, align 1
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  %step.status.1044 = call i32 @al_owning_charge_step(ptr %ctx, i32 163)
  %step.ok.1045 = icmp eq i32 %step.status.1044, 0
  br i1 %step.ok.1045, label %step.continue.1046, label %frame.failure.0
step.continue.1046:
  %stack.offset.1047 = add i32 %stack.offset.61, 24
  %reserve.status.1048 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1047, i32 164)
  %reserve.ok.1049 = icmp eq i32 %reserve.status.1048, 0
  br i1 %reserve.ok.1049, label %reserve.continue.1050, label %frame.failure.0
reserve.continue.1050:
  %stack.offset.1051 = add i32 %context.value.60, 8
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.1051, i32 24, i32 24, i32 7)
  %context.field.1052 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1053 = load i32, ptr %context.field.1052, align 4
  %runtime.ok.1054 = icmp eq i32 %context.value.1053, 0
  br i1 %runtime.ok.1054, label %runtime.continue.1055, label %frame.failure.0
runtime.continue.1055:
  %stack.offset.1056 = add i32 %stack.offset.61, 24
  %cursor.check.1057 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1056)
  %cursor.ok.1058 = icmp eq i32 %cursor.check.1057, 0
  br i1 %cursor.ok.1058, label %cursor.continue.1059, label %frame.failure.0
cursor.continue.1059:
  %step.status.1060 = call i32 @al_owning_charge_step(ptr %ctx, i32 165)
  %step.ok.1061 = icmp eq i32 %step.status.1060, 0
  br i1 %step.ok.1061, label %step.continue.1062, label %frame.failure.0
step.continue.1062:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 8, i32 8, i32 1, i32 7)
  %context.field.1063 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1064 = load i32, ptr %context.field.1063, align 4
  %runtime.ok.1065 = icmp eq i32 %context.value.1064, 0
  br i1 %runtime.ok.1065, label %runtime.continue.1066, label %frame.failure.0
runtime.continue.1066:
  %stack.offset.1067 = add i32 %stack.offset.61, 8
  %stack.offset.1068 = add i32 %stack.offset.61, 24
  %field.grows.1069 = icmp ugt i32 %stack.offset.1067, %stack.offset.1068
  br i1 %field.grows.1069, label %field.reserve.1070, label %field.release.1071
field.reserve.1070:
  %reserve.status.1073 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1067, i32 166)
  %reserve.ok.1074 = icmp eq i32 %reserve.status.1073, 0
  br i1 %reserve.ok.1074, label %reserve.continue.1075, label %frame.failure.0
reserve.continue.1075:
  br label %field.ready.1072
field.release.1071:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1067, i32 0, i32 1, i32 8)
  %context.field.1076 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1077 = load i32, ptr %context.field.1076, align 4
  %runtime.ok.1078 = icmp eq i32 %context.value.1077, 0
  br i1 %runtime.ok.1078, label %runtime.continue.1079, label %frame.failure.0
runtime.continue.1079:
  br label %field.ready.1072
field.ready.1072:
  call void @al_owning_update_live(ptr %ctx, i32 -16, i32 0)
  %context.field.1080 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1081 = load i32, ptr %context.field.1080, align 4
  %runtime.ok.1082 = icmp eq i32 %context.value.1081, 0
  br i1 %runtime.ok.1082, label %runtime.continue.1083, label %frame.failure.0
runtime.continue.1083:
  %stack.offset.1084 = add i32 %stack.offset.61, 8
  %cursor.check.1085 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1084)
  %cursor.ok.1086 = icmp eq i32 %cursor.check.1085, 0
  br i1 %cursor.ok.1086, label %cursor.continue.1087, label %frame.failure.0
cursor.continue.1087:
  %step.status.1088 = call i32 @al_owning_charge_step(ptr %ctx, i32 167)
  %step.ok.1089 = icmp eq i32 %step.status.1088, 0
  br i1 %step.ok.1089, label %step.continue.1090, label %frame.failure.0
step.continue.1090:
  %stack.offset.1091 = add i32 %stack.offset.61, 8
  %stack.offset.1092 = add i32 %stack.offset.1091, 8
  %reserve.status.1093 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1092, i32 168)
  %reserve.ok.1094 = icmp eq i32 %reserve.status.1093, 0
  br i1 %reserve.ok.1094, label %reserve.continue.1095, label %frame.failure.0
reserve.continue.1095:
  %stack.offset.1096 = add i32 %context.value.60, 56
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.1091, i32 %stack.offset.1096, i32 8, i32 8, i32 1)
  %context.field.1097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1098 = load i32, ptr %context.field.1097, align 4
  %runtime.ok.1099 = icmp eq i32 %context.value.1098, 0
  br i1 %runtime.ok.1099, label %runtime.continue.1100, label %frame.failure.0
runtime.continue.1100:
  %stack.offset.1101 = add i32 %stack.offset.61, 16
  %cursor.check.1102 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1101)
  %cursor.ok.1103 = icmp eq i32 %cursor.check.1102, 0
  br i1 %cursor.ok.1103, label %cursor.continue.1104, label %frame.failure.0
cursor.continue.1104:
  %step.status.1105 = call i32 @al_owning_charge_step(ptr %ctx, i32 169)
  %step.ok.1106 = icmp eq i32 %step.status.1105, 0
  br i1 %step.ok.1106, label %step.continue.1107, label %frame.failure.0
step.continue.1107:
  %stack.offset.1108 = add i32 %stack.offset.61, 8
  %integer.left.1109 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.61)
  %context.field.1111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1112 = load i32, ptr %context.field.1111, align 4
  %runtime.ok.1113 = icmp eq i32 %context.value.1112, 0
  br i1 %runtime.ok.1113, label %runtime.continue.1114, label %frame.failure.0
runtime.continue.1114:
  %integer.right.1110 = call i64 @al_owning_load_i64(ptr %ctx, i32 %stack.offset.1108)
  %context.field.1115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1116 = load i32, ptr %context.field.1115, align 4
  %runtime.ok.1117 = icmp eq i32 %context.value.1116, 0
  br i1 %runtime.ok.1117, label %runtime.continue.1118, label %frame.failure.0
runtime.continue.1118:
  %integer.checked.1119 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.1109, i64 %integer.right.1110)
  %integer.result.1120 = extractvalue { i64, i1 } %integer.checked.1119, 0
  %integer.overflow.1121 = extractvalue { i64, i1 } %integer.checked.1119, 1
  br i1 %integer.overflow.1121, label %integer.overflow.failure.1123, label %integer.nooverflow.1122
integer.overflow.failure.1123:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 170, i32 0, i32 0)
  br label %frame.failure.0
integer.nooverflow.1122:
  %stack.offset.1124 = add i32 %stack.offset.61, 8
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.1124, i32 8, i32 8, i32 1)
  %context.field.1125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1126 = load i32, ptr %context.field.1125, align 4
  %runtime.ok.1127 = icmp eq i32 %context.value.1126, 0
  br i1 %runtime.ok.1127, label %runtime.continue.1128, label %frame.failure.0
runtime.continue.1128:
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.1129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1130 = load i32, ptr %context.field.1129, align 4
  %runtime.ok.1131 = icmp eq i32 %context.value.1130, 0
  br i1 %runtime.ok.1131, label %runtime.continue.1132, label %frame.failure.0
runtime.continue.1132:
  %stack.offset.1133 = add i32 %stack.offset.61, 8
  %reserve.status.1134 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1133, i32 171)
  %reserve.ok.1135 = icmp eq i32 %reserve.status.1134, 0
  br i1 %reserve.ok.1135, label %reserve.continue.1136, label %frame.failure.0
reserve.continue.1136:
  call void @al_owning_store_i64(ptr %ctx, i32 %stack.offset.61, i64 %integer.result.1120, i32 1)
  %context.field.1137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1138 = load i32, ptr %context.field.1137, align 4
  %runtime.ok.1139 = icmp eq i32 %context.value.1138, 0
  br i1 %runtime.ok.1139, label %runtime.continue.1140, label %frame.failure.0
runtime.continue.1140:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1142 = load i32, ptr %context.field.1141, align 4
  %runtime.ok.1143 = icmp eq i32 %context.value.1142, 0
  br i1 %runtime.ok.1143, label %runtime.continue.1144, label %frame.failure.0
runtime.continue.1144:
  %stack.offset.1145 = add i32 %stack.offset.61, 8
  %cursor.check.1146 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1145)
  %cursor.ok.1147 = icmp eq i32 %cursor.check.1146, 0
  br i1 %cursor.ok.1147, label %cursor.continue.1148, label %frame.failure.0
cursor.continue.1148:
  %step.status.1149 = call i32 @al_owning_charge_step(ptr %ctx, i32 172)
  %step.ok.1150 = icmp eq i32 %step.status.1149, 0
  br i1 %step.ok.1150, label %step.continue.1151, label %frame.failure.0
step.continue.1151:
  %local.is.active.1152 = load i1, ptr %local.active.42, align 1
  %local.previous.payload.1153 = load i32, ptr %local.payload.43, align 4
  %local.old.payload.1154 = select i1 %local.is.active.1152, i32 %local.previous.payload.1153, i32 0
  %stack.offset.1155 = add i32 %context.value.60, 64
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.1155, i32 %stack.offset.61, i32 8, i32 8, i32 8, i32 %local.old.payload.1154, i32 1)
  %context.field.1156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1157 = load i32, ptr %context.field.1156, align 4
  %runtime.ok.1158 = icmp eq i32 %context.value.1157, 0
  br i1 %runtime.ok.1158, label %runtime.continue.1159, label %frame.failure.0
runtime.continue.1159:
  store i1 true, ptr %local.active.42, align 1
  store i32 8, ptr %local.payload.43, align 4
  store i32 1, ptr %local.type.44, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 8, i32 8, i32 1)
  %context.field.1160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1161 = load i32, ptr %context.field.1160, align 4
  %runtime.ok.1162 = icmp eq i32 %context.value.1161, 0
  br i1 %runtime.ok.1162, label %runtime.continue.1163, label %frame.failure.0
runtime.continue.1163:
  %cursor.check.1164 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.1165 = icmp eq i32 %cursor.check.1164, 0
  br i1 %cursor.ok.1165, label %cursor.continue.1166, label %frame.failure.0
cursor.continue.1166:
  %step.status.1167 = call i32 @al_owning_charge_step(ptr %ctx, i32 173)
  %step.ok.1168 = icmp eq i32 %step.status.1167, 0
  br i1 %step.ok.1168, label %step.continue.1169, label %frame.failure.0
step.continue.1169:
  %stack.offset.1170 = add i32 %stack.offset.61, 16
  %reserve.status.1171 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1170, i32 174)
  %reserve.ok.1172 = icmp eq i32 %reserve.status.1171, 0
  br i1 %reserve.ok.1172, label %reserve.continue.1173, label %frame.failure.0
reserve.continue.1173:
  %stack.offset.1174 = add i32 %context.value.60, 32
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.1174, i32 16, i32 16, i32 5)
  %context.field.1175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1176 = load i32, ptr %context.field.1175, align 4
  %runtime.ok.1177 = icmp eq i32 %context.value.1176, 0
  br i1 %runtime.ok.1177, label %runtime.continue.1178, label %frame.failure.0
runtime.continue.1178:
  %stack.offset.1179 = add i32 %stack.offset.61, 16
  %cursor.check.1180 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1179)
  %cursor.ok.1181 = icmp eq i32 %cursor.check.1180, 0
  br i1 %cursor.ok.1181, label %cursor.continue.1182, label %frame.failure.0
cursor.continue.1182:
  %step.status.1183 = call i32 @al_owning_charge_step(ptr %ctx, i32 175)
  %step.ok.1184 = icmp eq i32 %step.status.1183, 0
  br i1 %step.ok.1184, label %step.continue.1185, label %frame.failure.0
step.continue.1185:
  %local.is.active.1186 = load i1, ptr %local.active.45, align 1
  %local.previous.payload.1187 = load i32, ptr %local.payload.46, align 4
  %local.old.payload.1188 = select i1 %local.is.active.1186, i32 %local.previous.payload.1187, i32 0
  %stack.offset.1189 = add i32 %context.value.60, 72
  call void @al_owning_store_local(ptr %ctx, i32 %stack.offset.1189, i32 %stack.offset.61, i32 16, i32 16, i32 16, i32 %local.old.payload.1188, i32 5)
  %context.field.1190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1191 = load i32, ptr %context.field.1190, align 4
  %runtime.ok.1192 = icmp eq i32 %context.value.1191, 0
  br i1 %runtime.ok.1192, label %runtime.continue.1193, label %frame.failure.0
runtime.continue.1193:
  store i1 true, ptr %local.active.45, align 1
  store i32 16, ptr %local.payload.46, align 4
  store i32 5, ptr %local.type.47, align 4
  call void @al_owning_drop(ptr %ctx, i32 %stack.offset.61, i32 16, i32 16, i32 5)
  %context.field.1194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1195 = load i32, ptr %context.field.1194, align 4
  %runtime.ok.1196 = icmp eq i32 %context.value.1195, 0
  br i1 %runtime.ok.1196, label %runtime.continue.1197, label %frame.failure.0
runtime.continue.1197:
  %cursor.check.1198 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.61)
  %cursor.ok.1199 = icmp eq i32 %cursor.check.1198, 0
  br i1 %cursor.ok.1199, label %cursor.continue.1200, label %frame.failure.0
cursor.continue.1200:
  %step.status.1201 = call i32 @al_owning_charge_step(ptr %ctx, i32 176)
  %step.ok.1202 = icmp eq i32 %step.status.1201, 0
  br i1 %step.ok.1202, label %step.continue.1203, label %frame.failure.0
step.continue.1203:
  %stack.offset.1204 = add i32 %stack.offset.61, 8
  %reserve.status.1205 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1204, i32 177)
  %reserve.ok.1206 = icmp eq i32 %reserve.status.1205, 0
  br i1 %reserve.ok.1206, label %reserve.continue.1207, label %frame.failure.0
reserve.continue.1207:
  %stack.offset.1208 = add i32 %context.value.60, 64
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.1208, i32 8, i32 8, i32 1)
  %context.field.1209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1210 = load i32, ptr %context.field.1209, align 4
  %runtime.ok.1211 = icmp eq i32 %context.value.1210, 0
  br i1 %runtime.ok.1211, label %runtime.continue.1212, label %frame.failure.0
runtime.continue.1212:
  %stack.offset.1213 = add i32 %stack.offset.61, 8
  %cursor.check.1214 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1213)
  %cursor.ok.1215 = icmp eq i32 %cursor.check.1214, 0
  br i1 %cursor.ok.1215, label %cursor.continue.1216, label %frame.failure.0
cursor.continue.1216:
  %step.status.1217 = call i32 @al_owning_charge_step(ptr %ctx, i32 178)
  %step.ok.1218 = icmp eq i32 %step.status.1217, 0
  br i1 %step.ok.1218, label %step.continue.1219, label %frame.failure.0
step.continue.1219:
  %stack.offset.1220 = add i32 %stack.offset.61, 8
  %stack.offset.1221 = add i32 %stack.offset.1220, 16
  %reserve.status.1222 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1221, i32 179)
  %reserve.ok.1223 = icmp eq i32 %reserve.status.1222, 0
  br i1 %reserve.ok.1223, label %reserve.continue.1224, label %frame.failure.0
reserve.continue.1224:
  %stack.offset.1225 = add i32 %context.value.60, 72
  call void @al_owning_load_local(ptr %ctx, i32 %stack.offset.1220, i32 %stack.offset.1225, i32 16, i32 16, i32 5)
  %context.field.1226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1227 = load i32, ptr %context.field.1226, align 4
  %runtime.ok.1228 = icmp eq i32 %context.value.1227, 0
  br i1 %runtime.ok.1228, label %runtime.continue.1229, label %frame.failure.0
runtime.continue.1229:
  %stack.offset.1230 = add i32 %stack.offset.61, 24
  %cursor.check.1231 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1230)
  %cursor.ok.1232 = icmp eq i32 %cursor.check.1231, 0
  br i1 %cursor.ok.1232, label %cursor.continue.1233, label %frame.failure.0
cursor.continue.1233:
  %step.status.1234 = call i32 @al_owning_charge_step(ptr %ctx, i32 180)
  %step.ok.1235 = icmp eq i32 %step.status.1234, 0
  br i1 %step.ok.1235, label %step.continue.1236, label %frame.failure.0
step.continue.1236:
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.61, i32 %stack.offset.61, i32 8, i32 8, i32 1, i32 6)
  %context.field.1237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1238 = load i32, ptr %context.field.1237, align 4
  %runtime.ok.1239 = icmp eq i32 %context.value.1238, 0
  br i1 %runtime.ok.1239, label %runtime.continue.1240, label %frame.failure.0
runtime.continue.1240:
  %stack.offset.1241 = add i32 %stack.offset.61, 8
  %stack.offset.1242 = add i32 %stack.offset.61, 8
  call void @al_owning_move_range(ptr %ctx, i32 %stack.offset.1241, i32 %stack.offset.1242, i32 16, i32 16, i32 5, i32 6)
  %context.field.1243 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1244 = load i32, ptr %context.field.1243, align 4
  %runtime.ok.1245 = icmp eq i32 %context.value.1244, 0
  br i1 %runtime.ok.1245, label %runtime.continue.1246, label %frame.failure.0
runtime.continue.1246:
  %stack.offset.1247 = add i32 %stack.offset.61, 24
  %stack.offset.1248 = add i32 %stack.offset.61, 24
  %record.grows.1249 = icmp ugt i32 %stack.offset.1247, %stack.offset.1248
  br i1 %record.grows.1249, label %record.reserve.1250, label %record.release.1251
record.reserve.1250:
  %reserve.status.1253 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1247, i32 181)
  %reserve.ok.1254 = icmp eq i32 %reserve.status.1253, 0
  br i1 %reserve.ok.1254, label %reserve.continue.1255, label %frame.failure.0
reserve.continue.1255:
  br label %record.ready.1252
record.release.1251:
  call void @al_owning_release_to(ptr %ctx, i32 %stack.offset.1247, i32 0, i32 7, i32 24)
  %context.field.1256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1257 = load i32, ptr %context.field.1256, align 4
  %runtime.ok.1258 = icmp eq i32 %context.value.1257, 0
  br i1 %runtime.ok.1258, label %runtime.continue.1259, label %frame.failure.0
runtime.continue.1259:
  br label %record.ready.1252
record.ready.1252:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 7, i32 %stack.offset.61, i32 24, i32 24, i32 0, i32 0)
  %context.field.1260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1261 = load i32, ptr %context.field.1260, align 4
  %runtime.ok.1262 = icmp eq i32 %context.value.1261, 0
  br i1 %runtime.ok.1262, label %runtime.continue.1263, label %frame.failure.0
runtime.continue.1263:
  %stack.offset.1264 = add i32 %stack.offset.61, 24
  %cursor.check.1265 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1264)
  %cursor.ok.1266 = icmp eq i32 %cursor.check.1265, 0
  br i1 %cursor.ok.1266, label %cursor.continue.1267, label %frame.failure.0
cursor.continue.1267:
  %local.is.active.1268 = load i1, ptr %local.active.42, align 1
  %local.clear.payload.1269 = load i32, ptr %local.payload.43, align 4
  %local.clear.type.1270 = load i32, ptr %local.type.44, align 4
  %local.clear.live.payload.1271 = select i1 %local.is.active.1268, i32 %local.clear.payload.1269, i32 0
  %local.clear.live.type.1272 = select i1 %local.is.active.1268, i32 %local.clear.type.1270, i32 0
  %stack.offset.1273 = add i32 %context.value.60, 64
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1273, i32 8, i32 %local.clear.live.payload.1271, i32 %local.clear.live.type.1272)
  %context.field.1274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1275 = load i32, ptr %context.field.1274, align 4
  %runtime.ok.1276 = icmp eq i32 %context.value.1275, 0
  br i1 %runtime.ok.1276, label %runtime.continue.1277, label %frame.failure.0
runtime.continue.1277:
  store i1 false, ptr %local.active.42, align 1
  store i32 0, ptr %local.payload.43, align 4
  store i32 0, ptr %local.type.44, align 4
  %local.is.active.1278 = load i1, ptr %local.active.45, align 1
  %local.clear.payload.1279 = load i32, ptr %local.payload.46, align 4
  %local.clear.type.1280 = load i32, ptr %local.type.47, align 4
  %local.clear.live.payload.1281 = select i1 %local.is.active.1278, i32 %local.clear.payload.1279, i32 0
  %local.clear.live.type.1282 = select i1 %local.is.active.1278, i32 %local.clear.type.1280, i32 0
  %stack.offset.1283 = add i32 %context.value.60, 72
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1283, i32 16, i32 %local.clear.live.payload.1281, i32 %local.clear.live.type.1282)
  %context.field.1284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1285 = load i32, ptr %context.field.1284, align 4
  %runtime.ok.1286 = icmp eq i32 %context.value.1285, 0
  br i1 %runtime.ok.1286, label %runtime.continue.1287, label %frame.failure.0
runtime.continue.1287:
  store i1 false, ptr %local.active.45, align 1
  store i32 0, ptr %local.payload.46, align 4
  store i32 0, ptr %local.type.47, align 4
  %stack.offset.1288 = add i32 %stack.offset.61, 24
  %cursor.check.1289 = call i32 @al_owning_check_cursor(ptr %ctx, i32 %stack.offset.1288)
  %cursor.ok.1290 = icmp eq i32 %cursor.check.1289, 0
  br i1 %cursor.ok.1290, label %cursor.continue.1291, label %frame.failure.0
cursor.continue.1291:
  call void @al_owning_move_range(ptr %ctx, i32 %result.destination, i32 %stack.offset.61, i32 24, i32 24, i32 7, i32 9)
  %context.field.1292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1293 = load i32, ptr %context.field.1292, align 4
  %runtime.ok.1294 = icmp eq i32 %context.value.1293, 0
  br i1 %runtime.ok.1294, label %runtime.continue.1295, label %frame.failure.0
runtime.continue.1295:
  %local.is.active.1296 = load i1, ptr %local.active.3, align 1
  %local.clear.payload.1297 = load i32, ptr %local.payload.4, align 4
  %local.clear.type.1298 = load i32, ptr %local.type.5, align 4
  %local.clear.live.payload.1299 = select i1 %local.is.active.1296, i32 %local.clear.payload.1297, i32 0
  %local.clear.live.type.1300 = select i1 %local.is.active.1296, i32 %local.clear.type.1298, i32 0
  call void @al_owning_clear_local(ptr %ctx, i32 %context.value.60, i32 8, i32 %local.clear.live.payload.1299, i32 %local.clear.live.type.1300)
  %context.field.1301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1302 = load i32, ptr %context.field.1301, align 4
  %runtime.ok.1303 = icmp eq i32 %context.value.1302, 0
  br i1 %runtime.ok.1303, label %runtime.continue.1304, label %frame.failure.0
runtime.continue.1304:
  store i1 false, ptr %local.active.3, align 1
  store i32 0, ptr %local.payload.4, align 4
  store i32 0, ptr %local.type.5, align 4
  %local.is.active.1305 = load i1, ptr %local.active.6, align 1
  %local.clear.payload.1306 = load i32, ptr %local.payload.7, align 4
  %local.clear.type.1307 = load i32, ptr %local.type.8, align 4
  %local.clear.live.payload.1308 = select i1 %local.is.active.1305, i32 %local.clear.payload.1306, i32 0
  %local.clear.live.type.1309 = select i1 %local.is.active.1305, i32 %local.clear.type.1307, i32 0
  %stack.offset.1310 = add i32 %context.value.60, 8
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1310, i32 24, i32 %local.clear.live.payload.1308, i32 %local.clear.live.type.1309)
  %context.field.1311 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1312 = load i32, ptr %context.field.1311, align 4
  %runtime.ok.1313 = icmp eq i32 %context.value.1312, 0
  br i1 %runtime.ok.1313, label %runtime.continue.1314, label %frame.failure.0
runtime.continue.1314:
  store i1 false, ptr %local.active.6, align 1
  store i32 0, ptr %local.payload.7, align 4
  store i32 0, ptr %local.type.8, align 4
  %local.is.active.1315 = load i1, ptr %local.active.9, align 1
  %local.clear.payload.1316 = load i32, ptr %local.payload.10, align 4
  %local.clear.type.1317 = load i32, ptr %local.type.11, align 4
  %local.clear.live.payload.1318 = select i1 %local.is.active.1315, i32 %local.clear.payload.1316, i32 0
  %local.clear.live.type.1319 = select i1 %local.is.active.1315, i32 %local.clear.type.1317, i32 0
  %stack.offset.1320 = add i32 %context.value.60, 32
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1320, i32 16, i32 %local.clear.live.payload.1318, i32 %local.clear.live.type.1319)
  %context.field.1321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1322 = load i32, ptr %context.field.1321, align 4
  %runtime.ok.1323 = icmp eq i32 %context.value.1322, 0
  br i1 %runtime.ok.1323, label %runtime.continue.1324, label %frame.failure.0
runtime.continue.1324:
  store i1 false, ptr %local.active.9, align 1
  store i32 0, ptr %local.payload.10, align 4
  store i32 0, ptr %local.type.11, align 4
  %local.is.active.1325 = load i1, ptr %local.active.12, align 1
  %local.clear.payload.1326 = load i32, ptr %local.payload.13, align 4
  %local.clear.type.1327 = load i32, ptr %local.type.14, align 4
  %local.clear.live.payload.1328 = select i1 %local.is.active.1325, i32 %local.clear.payload.1326, i32 0
  %local.clear.live.type.1329 = select i1 %local.is.active.1325, i32 %local.clear.type.1327, i32 0
  %stack.offset.1330 = add i32 %context.value.60, 48
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1330, i32 8, i32 %local.clear.live.payload.1328, i32 %local.clear.live.type.1329)
  %context.field.1331 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1332 = load i32, ptr %context.field.1331, align 4
  %runtime.ok.1333 = icmp eq i32 %context.value.1332, 0
  br i1 %runtime.ok.1333, label %runtime.continue.1334, label %frame.failure.0
runtime.continue.1334:
  store i1 false, ptr %local.active.12, align 1
  store i32 0, ptr %local.payload.13, align 4
  store i32 0, ptr %local.type.14, align 4
  %local.is.active.1335 = load i1, ptr %local.active.15, align 1
  %local.clear.payload.1336 = load i32, ptr %local.payload.16, align 4
  %local.clear.type.1337 = load i32, ptr %local.type.17, align 4
  %local.clear.live.payload.1338 = select i1 %local.is.active.1335, i32 %local.clear.payload.1336, i32 0
  %local.clear.live.type.1339 = select i1 %local.is.active.1335, i32 %local.clear.type.1337, i32 0
  %stack.offset.1340 = add i32 %context.value.60, 56
  call void @al_owning_clear_local(ptr %ctx, i32 %stack.offset.1340, i32 8, i32 %local.clear.live.payload.1338, i32 %local.clear.live.type.1339)
  %context.field.1341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1342 = load i32, ptr %context.field.1341, align 4
  %runtime.ok.1343 = icmp eq i32 %context.value.1342, 0
  br i1 %runtime.ok.1343, label %runtime.continue.1344, label %frame.failure.0
runtime.continue.1344:
  store i1 false, ptr %local.active.15, align 1
  store i32 0, ptr %local.payload.16, align 4
  store i32 0, ptr %local.type.17, align 4
  call void @al_owning_local_release(ptr %ctx, i32 88)
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.60, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.reserve.failure.1:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.49, i32 0, i32 0, i32 0)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.49, i32 0, i32 0, i32 0)
  %context.field.1345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1346 = load i32, ptr %context.field.1345, align 4
  %context.field.1347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1348 = load i32, ptr %context.field.1347, align 4
  %context.field.1349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1350 = load i32, ptr %context.field.1349, align 4
  %baseline.live.total.1351 = add i32 %context.value.51, %context.value.53
  %current.live.total.1352 = add i32 %context.value.1346, %context.value.1348
  %cleanup.live.delta.1353 = sub i32 %baseline.live.total.1351, %current.live.total.1352
  %cleanup.local.delta.1354 = sub i32 %context.value.53, %context.value.1348
  %cleanup.reserved.delta.1355 = sub i32 %context.value.1350, %context.value.55
  call void @al_owning_update_live(ptr %ctx, i32 %cleanup.live.delta.1353, i32 %cleanup.local.delta.1354)
  call void @al_owning_local_release(ptr %ctx, i32 %cleanup.reserved.delta.1355)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.length.ok.7 = icmp eq i32 %input.bytes, 32
  br i1 %entry.input.length.ok.7, label %entry.input.valid.8, label %entry.input.invalid.9
entry.input.invalid.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 32, i32 %input.bytes)
  br label %entry.failure.0
entry.input.valid.8:
  %reserve.status.10 = call i32 @al_owning_reserve_to(ptr %ctx, i32 32, i32 182)
  %reserve.ok.11 = icmp eq i32 %reserve.status.10, 0
  br i1 %reserve.ok.11, label %reserve.continue.12, label %entry.failure.0
reserve.continue.12:
  call void @al_owning_copy_external(ptr %ctx, i32 0, ptr %input, i32 24, i32 24, i32 7)
  %context.field.13 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.14 = load i32, ptr %context.field.13, align 4
  %runtime.ok.15 = icmp eq i32 %context.value.14, 0
  br i1 %runtime.ok.15, label %runtime.continue.16, label %entry.failure.0
runtime.continue.16:
  %input.pointer.17 = getelementptr inbounds i8, ptr %input, i32 24
  call void @al_owning_copy_external(ptr %ctx, i32 24, ptr %input.pointer.17, i32 8, i32 8, i32 1)
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %runtime.ok.20 = icmp eq i32 %context.value.19, 0
  br i1 %runtime.ok.20, label %runtime.continue.21, label %entry.failure.0
runtime.continue.21:
  %entry.body.status.22 = call i32 @agentlang_entry_frame(ptr %ctx, i32 0, i32 0, i32 0)
  %entry.body.ok.23 = icmp eq i32 %entry.body.status.22, 0
  br i1 %entry.body.ok.23, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.31 = load i32, ptr %context.field.30, align 4
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %entry.failure.live.32 = add i32 %context.value.27, %context.value.29
  %entry.failure.delta.33 = sub i32 0, %entry.failure.live.32
  %entry.failure.local.delta.34 = sub i32 0, %context.value.29
  call void @al_owning_update_live(ptr %ctx, i32 %entry.failure.delta.33, i32 %entry.failure.local.delta.34)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.31)
  br label %entry.return.status
entry.success.2:
  call void @al_owning_publish(ptr %ctx, ptr %retained, i32 %retained.capacity, i32 0, i32 24, i32 7)
  %context.field.35 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.36 = load i32, ptr %context.field.35, align 4
  %runtime.ok.37 = icmp eq i32 %context.value.36, 0
  br i1 %runtime.ok.37, label %runtime.continue.38, label %entry.failure.0
runtime.continue.38:
  call void @al_owning_update_live(ptr %ctx, i32 -24, i32 0)
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %runtime.ok.41 = icmp eq i32 %context.value.40, 0
  br i1 %runtime.ok.41, label %runtime.continue.42, label %entry.failure.0
runtime.continue.42:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  br label %entry.return.status
entry.failure.0:
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %context.field.47 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.48 = load i32, ptr %context.field.47, align 4
  %context.field.49 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.50 = load i32, ptr %context.field.49, align 4
  %entry.cleanup.total.live.51 = add i32 %context.value.46, %context.value.48
  %entry.cleanup.live.delta.52 = sub i32 0, %entry.cleanup.total.live.51
  %entry.cleanup.local.delta.53 = sub i32 0, %context.value.48
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %entry.cleanup.live.delta.52, i32 %entry.cleanup.local.delta.53)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.50)
  br label %entry.return.status
entry.return.status:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.55 = load i32, ptr %context.field.54, align 4
  ret i32 %context.value.55
}


import hashlib
import json
import sys
import zipfile
from pathlib import Path

repo = Path.cwd().resolve()
local = repo / '.agentlang/refined-mailbox-180'
native = repo / '.agentlang/owning-stack-003/verification-380f97853cc4458a8ac73f6343d7d7dd'
policy = repo / '.agentlang/owning-mailbox-002/policy-run-1b6ceb4877ab4847a2b3b7910f6fcfe5'
io = repo / '.agentlang/owning-mailbox-003/io-run-e7599f4f57de49e6bc4f33a136a65521'
failed_io = repo / '.agentlang/owning-mailbox-003/io-run-259fa0e6ca2b4f57844f53c0c7c9bd36'
failed_mailbox = repo / '.agentlang/owning-mailbox-001/integration-run-75f4c94e30e4437590e62b206de67b28'
mailbox = (repo / sys.argv[1]).resolve()
out = repo / 'reports/evidence/180-native-refined-mailbox'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
nr = load(native / 'verification-evidence.json')
mr = load(mailbox / 'integration-evidence.json')
pr = load(policy / 'policy-evidence.json')
ir = load(io / 'io-evidence.json')
fr = load(local / 'full-validation-002.json')
assert nr['passed'] and nr['sourceInputsStable']
assert mr['passed'] and mr['sourceInputHashes']['unchanged']
assert mr['refinements']['passed'] and pr['passed'] and ir['passed'] and fr['passed']
assert len(fr['checks']) == 37 and all(row['exitCode'] == 0 for row in fr['checks'])
assert '655 assertions' in (local / 'implementation/full-llvm-tests.log').read_text(encoding='utf-8-sig')
assert load(local / 'full-gate-resource-check.json')['matches']
assert load(local / 'fixture-freeze-post-correction.json')['sha256'].lower() == sha((repo / 'tests/fixtures/native-conformance/owning-mailbox-refinements.json').read_bytes())

files = set()
pin_groups = [nr['sourceInputHashesBefore'], mr['sourceInputHashes']['before'],
              pr['sourceHashesBefore'], ir['sourceHashesBefore']]
assert pr['sourceHashesBefore'] == pr['sourceHashesAfter']
assert ir['sourceHashesBefore'] == ir['sourceHashesAfter']
for group in pin_groups:
    for row in group:
        p = Path(row['path']).resolve()
        assert p.is_relative_to(repo) and p.is_file(), p
        assert sha(p.read_bytes()).lower() == row['sha256'].lower(), p
        files.add(p)

allowed = {'.json', '.jsonl', '.txt', '.log', '.md', '.flow', '.fsx', '.py', '.c', '.h', '.ps1'}
excluded_parts = {'build', 'bin', 'obj', 'dotnet-artifacts', 'local-test-temp', 'native-artifacts', 'native-runtime'}
for p in local.rglob('*'):
    if p.is_file() and p.suffix in allowed and not (set(p.relative_to(local).parts) & excluded_parts):
        files.add(p.resolve())

def gate_logs(root):
    for p in root.iterdir():
        if p.is_file() and p.suffix in allowed:
            files.add(p.resolve())
    for dirname in ('logs', 'processes'):
        d = root / dirname
        if d.exists():
            files.update(p.resolve() for p in d.rglob('*') if p.is_file() and p.suffix in allowed)

for root in (native, mailbox, policy, io, failed_io, failed_mailbox):
    gate_logs(root)
# Preserve independent runner results and compile-only arithmetic, not build trees.
for p in (local / 'oracle').rglob('native-value-stack-evidence.json'):
    files.add(p.resolve())
# Keep generated refined mailbox IR/C/manifest for accepted and failed modules.
for report in (mr, load(failed_mailbox / 'integration-evidence.json')):
    for row in report['refinementsModuleBuilds']:
        module_path = Path(row['modulePath'])
        assert module_path.resolve().is_relative_to(repo)
        for p in module_path.parent.iterdir():
            if p.is_file() and p.suffix in {'.ll', '.c', '.json'}:
                files.add(p.resolve())
files.add(Path(__file__).resolve())
assert not out.exists(), 'Refuse to overwrite an evidence publication'
out.mkdir(parents=True)
rows = []
with zipfile.ZipFile(out / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(files):
        assert p.is_relative_to(repo) and p.is_file(), p
        data = p.read_bytes()
        rel = p.relative_to(repo).as_posix()
        archive.writestr(rel, data)
        rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(rows)
    for row in rows:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
index = {
    'status': 'verified',
    'description': 'Accepted local gates, failed attempts, independent oracle corrections, source pins and selected generated refined mailbox modules. Build trees, binaries and environment dumps excluded.',
    'archive': {'path': 'evidence.zip', 'bytes': (out / 'evidence.zip').stat().st_size,
                'sha256': sha((out / 'evidence.zip').read_bytes())},
    'accepted': {'llvmAssertions': 655, 'focusedMailboxAssertions': 5,
                 'nativeChecks': len(nr['checks']), 'nativeSourcePins': len(nr['sourceInputHashesBefore']),
                 'mailboxChecks': len(mr['checks']), 'refinedChecks': len(mr['refinements']['checks']),
                 'mailboxSourcePins': len(mr['sourceInputHashes']['before']),
                 'policyChecks': len(pr['checks']), 'realIoChecks': len(ir['checks']),
                 'fullLocalChecks': len(fr['checks'])},
    'files': rows,
}
(out / 'archive.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in index.items() if key != 'files'}))

# Int64.MinValue refinement-prefix audit

This audit ran before any native module or callback execution. It compiled the final Flow/2 source into verified IR, inspected the positive-id validator, and counted interpreter `ChargeInstruction` callbacks for a normal input and `Int64.MinValue`.

Command:

```powershell
dotnet fsi --exec .agentlang/refined-mailbox-180/intmin-failprefix.fsx
```

The verified validator IR begins with `StoreLocal`, `LoadLocal`, `Constant(-1)`, and `Call(divide)`. The checked division throws on `Int64.MinValue` during that fourth instruction. A wrapper used to invoke the predicate contributes two instructions, so its observed totals were 14 for a successful input and 6 for `Int64.MinValue`; subtracting those two wrapper instructions yields 12 for the normal predicate body and a 4-instruction runtime-error prefix.

Relevant output:

```text
normal-entry-steps=14 normal-result=success
overflow-entry-steps=6 overflow-result=AgentLang.LanguageException: LanguageException { Code = "RUNTIME_OVERFLOW" ... }
validator-prefix-normal=12 validator-prefix-overflow=4
```

The fixture records 12 only as the full normal predicate cost and 4 for the `Int64.MinValue` direct-admission failure. The full scratch output, including the verified IR body, remains in `intmin-failprefix.txt`.

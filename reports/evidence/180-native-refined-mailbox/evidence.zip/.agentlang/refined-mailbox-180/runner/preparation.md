# Refined mailbox runner preparation evidence

This records the runner worker's preflight checks. The outputs were returned in the task session and were not saved to separate command-log files. No generated native module was executed by this worker; the parent owns the fresh official gate.

## Focused checks

1. C syntax and warning check, exit code 0, no stdout/stderr:

   ```powershell
   & 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\x64\bin\clang.exe' --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O0 -I src/AgentLang.Llvm/native -fsyntax-only experiments/AgentLang.OwningMailbox/native_owning_mailbox_refinements.c
   ```

2. PowerShell AST and frozen-fixture contract check, exit code 0; output: `PowerShell AST and fixture JSON checks passed.`

   ```powershell
   $tokens=$null; $parseErrors=$null; [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path scripts/Verify-OwningMailbox.ps1), [ref]$tokens, [ref]$parseErrors) | Out-Null; if ($parseErrors.Count -gt 0) { $parseErrors | Format-List | Out-String | Write-Error; exit 1 }; $fixture=Get-Content tests/fixtures/native-conformance/owning-mailbox-refinements.json -Raw | ConvertFrom-Json -AsHashtable -Depth 80 -ErrorAction Stop; if ($fixture.sourceDerivedStepOracle.stepsConsumedByCall.RETURN.Count -ne 5 -or $fixture.directAdmissionControls.outputDescriptorContract.earlyBoundaryWrongInputTypeIndex.actualInputTypeIndex -ne 2) { throw 'Frozen refinement fixture contract mismatch.' }; 'PowerShell AST and fixture JSON checks passed.'
   ```

3. Whitespace and diff check, exit code 0; output: `Diff and C whitespace checks passed.` The PowerShell script emitted no whitespace errors, and a separate `Select-String` check found no trailing whitespace in the untracked C runner.

   ```powershell
   git diff --check -- scripts/Verify-OwningMailbox.ps1; $bad=Select-String -Path experiments/AgentLang.OwningMailbox/native_owning_mailbox_refinements.c -Pattern '[ \t]+$'; if ($bad) { $bad | Select-Object -First 20; exit 1 }; 'Diff and C whitespace checks passed.'
   ```

4. After the final script-only evidence-status edit, the C syntax command above was rerun with exit code 0 and no output. The following AST/diff check also exited 0 and printed `PowerShell AST and diff checks passed.`

   ```powershell
   $tokens=$null; $parseErrors=$null; [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path scripts/Verify-OwningMailbox.ps1), [ref]$tokens, [ref]$parseErrors) | Out-Null; if ($parseErrors.Count -gt 0) { $parseErrors | Format-List | Out-String | Write-Error; exit 1 }; git diff --check -- scripts/Verify-OwningMailbox.ps1; 'PowerShell AST and diff checks passed.'
   ```

## Pre-run corrections recorded

- The runner emits 13 named checks (indexes 0 through 12); the PowerShell assertion now expects 13.
- The C CLI uses `argc == 9`: module DLL, six emitted layout indexes, and the fixture's initialized-State serialized hex. PowerShell supplies and C decodes that final hex argument.
- The early boundary control uses a valid but wrong layout index: Continuation index 2 where State index 5 is required. It does not use an out-of-range sentinel index.
- Malformed nested Option/Result tags fail during the post-preflight external-value scan, after generated callbacks invalidate outputs; the runner expects invalid descriptors. The separate early wrong-type-index preflight control expects output sentinels to remain unchanged.
- The frozen direct-admission oracle uses 4 steps for Int64.MinValue's checked-division overflow prefix, not the normal 12-step predicate return. The `Option.Some(empty NonEmptyString)` case uses 22 steps and checks the active Result.Error string as well.
- The fixture was corrected and frozen before native execution at SHA-256 `d903fd6d61406d76c424ded506f437ba406ea61b6fedad686530043916b548e9`; the earlier hash and descriptor-contract correction are recorded in the fixture provenance.

## Inspection-command correction

One header-search inspection used a PowerShell-expanded `*.h` path and failed with ripgrep exit code 123 (`IO error ... The filename, directory name, or volume label syntax is incorrect`). The search was rerun successfully using `rg -n --glob '*.h' ... src/AgentLang.Llvm/native`. This was an inspection-command quoting issue, not a code or validation failure.

## Gate001 correction and saved-output replay

The official Gate001 run (run ID `75f4c94e30e4437590e62b206de67b28`) completed its bounded O0/diagnostic callback checks but failed on expected diagnostic labels and then raised a separate PowerShell empty-array `Count` exception. Its original sources remain preserved under `failed-gate-001-sources`; its evidence is `.agentlang/owning-mailbox-001/integration-run-75f4c94e30e4437590e62b206de67b28/integration-evidence.json`. The saved runner stdout is `.agentlang/refined-mailbox-180/runner/integration-run-75f4c94e30e4437590e62b206de67b28/native-refined-runner-run-O0-diagnostic.stdout.txt`.

Corrections were limited to the verifier and the independently owned fixture. The verifier now compares the three direct structural controls against their exact diagnostic codes and numeric context status 4, normalizes empty expected-root collections before `.Count` use, validates the disclosed correction hash chain and metadata, and includes provenance in the oracle result. Its bounded fixture-integrity pin is `A22BB448EE864713903D5EE7946C785CD7C8978CF54DA02E0F2E0B86911CBBB1`; the verifier compares this with `Get-FileHash` of the live fixture. The fixture preserves the initial pre-run hash `D903FD6D61406D76C424DED506F437BA406EA61B6FEDAD686530043916B548E9`, the diagnostic correction's intermediate hash `CBAA516667B1F14D516D36B0F9D9992D62C76E6E0652E2E5A993021934AD7376`, and the post-run copy-accounting correction. Copy accounting is 232 bytes: the first 184-byte oracle omitted three 16-byte dynamic `FAIL` string literals (48 bytes total), independently derived from the Flow, emitter, and runtime counter paths. The verifier also requires `copyOracleFrozenBeforeNativeExecution=false` and `copyOracleCorrectedAfterFirstNativeExecution=true`.

The following no-build replay used the saved Gate001 native JSON and bootstrap, not a newly executed native runner. It exited 0 and reported `astParse=passed`, `oracleResult=true`, 23 native evidence results, 108 checks, no failed checks, and the pinned fixture hash above:

```powershell
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:refinementsFixturePath = Join-Path (Get-Location) 'tests/fixtures/native-conformance/owning-mailbox-refinements.json'
$tokens = $null
$parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path 'scripts/Verify-OwningMailbox.ps1'), [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -gt 0) { throw (($parseErrors | ForEach-Object Message) -join "`n") }
foreach ($functionAst in $ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)) { Invoke-Expression $functionAst.Extent.Text }
$script:checks = [Collections.Generic.List[object]]::new()
$evidence = Get-Content '.agentlang/owning-mailbox-001/integration-run-75f4c94e30e4437590e62b206de67b28/integration-evidence.json' -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$fixture = Get-Content $script:refinementsFixturePath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$runnerOutputPath = '.agentlang/refined-mailbox-180/runner/integration-run-75f4c94e30e4437590e62b206de67b28/native-refined-runner-run-O0-diagnostic.stdout.txt'
$native = Get-Content $runnerOutputPath -Raw | ConvertFrom-Json -AsHashtable -Depth 100
$module = $evidence.refinements.modules | Where-Object { $_.optimization -ceq 'O0' -and $_.runtimeProfile -ceq 'diagnostic' } | Select-Object -First 1
$oracleResult = Test-RefinementOracle $module.bootstrap $fixture 'Gate001 replay'
$nativeResult = Check-RefinementNativeEvidence $native $fixture $module.bootstrap $module.layoutIndexes 'Gate001 replay'
$failed = @($script:checks | Where-Object { -not $_.passed } | ForEach-Object { $_.name })
if (-not $oracleResult -or @($nativeResult | Where-Object { -not $_ }).Count -gt 0 -or $failed.Count -gt 0) { throw "Replay failed: $($failed -join ', ')" }
git diff --check -- scripts/Verify-OwningMailbox.ps1
if ($LASTEXITCODE -ne 0) { throw 'git diff --check failed.' }
[pscustomobject]@{ astParse = 'passed'; oracleResult = $oracleResult; nativeResultCount = $nativeResult.Count; checks = $script:checks.Count; failures = $failed; fixtureHash = (Get-FileHash $script:refinementsFixturePath -Algorithm SHA256).Hash } | ConvertTo-Json -Depth 10
```

No native build or execution was performed during this repair pass. The C runner still hashes to `1CE52EF481E1A7709439D515B3DF36E2CBCAB7D14F55EC7FD53B89AAF2EE9176`, matching the preserved Gate001 source copy; the C runner was not changed. Gate002 is the next fresh native matrix and is owned by the parent.

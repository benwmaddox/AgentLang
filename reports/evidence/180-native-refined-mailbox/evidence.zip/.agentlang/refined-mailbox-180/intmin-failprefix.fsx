#r @"D:\code\AgentLang\.agentlang\refined-mailbox-180\artifacts\bin\AgentLang.Core\release\AgentLang.Core.dll"

open System
open System.IO
open AgentLang

let sourcePath = @"D:\code\AgentLang\experiments\AgentLang.OwningMailbox\owning-mailbox-refinements.flow"
let source = File.ReadAllText sourcePath
let document =
    match FlowParser.parseDocumentWithVersion 2 sourcePath source with
    | Ok parsed -> parsed
    | Error diagnostic -> failwith (Diagnostics.render diagnostic)

let sourceSpan file column =
    { File = file; Line = 1; Column = column; Length = 1 }
let lowerFirst (name: string) = string (Char.ToLowerInvariant name[0]) + name.Substring(1)

let records = document.Records |> List.map (fun record -> record.Name, record) |> Map.ofList
let scalars = document.Scalars |> List.map (fun scalar -> scalar.Name, scalar) |> Map.ofList
let generatedEntries =
    let recordEntries =
        records
        |> Map.toList
        |> List.collect (fun (name, record) ->
            let prefix = lowerFirst name
            let definition wordName inputs outputs =
                { Name = wordName; Inputs = inputs; Outputs = outputs; Effects = Set.empty; Maturity = LibraryWord
                  Revision = 1; Documentation = "generated"; Body = []; SourceText = ""; Span = sourceSpan "<record>" 1 }
            let entry builtin wordName inputs outputs =
                { Definition = definition wordName inputs outputs; Builtin = Some builtin; Status = Persistent
                  Maturity = LibraryWord; Revision = 1 }
            let constructor = entry (RecordConstructor name) (prefix + ".new") (record.Fields |> List.map (fun field -> field.Type)) [ TNamed name ]
            let accessors = record.Fields |> List.map (fun field -> entry (RecordAccessor(name, field.Name)) (prefix + "." + field.Name) [ TNamed name ] [ field.Type ])
            constructor :: accessors)
    let scalarEntries =
        scalars
        |> Map.toList
        |> List.collect (fun (name, scalar) ->
            let prefix = lowerFirst name
            let definition wordName inputs outputs =
                { Name = wordName; Inputs = inputs; Outputs = outputs; Effects = Set.empty; Maturity = LibraryWord
                  Revision = 1; Documentation = "generated"; Body = []; SourceText = ""; Span = scalar.Span }
            let entry builtin wordName inputs outputs =
                { Definition = definition wordName inputs outputs; Builtin = Some builtin; Status = Persistent
                  Maturity = LibraryWord; Revision = 1 }
            [ entry (ScalarConstructor name) (prefix + ".new") [ scalar.BaseType ] [ TNamed name ]
              entry (ScalarAccessor name) (prefix + ".value") [ TNamed name ] [ scalar.BaseType ] ])
    recordEntries @ scalarEntries

let words = generatedEntries |> List.fold (fun current entry -> Map.add entry.Definition.Name entry current) Compiler.primitives
let wordIds =
    words
    |> Map.toList
    |> List.map (fun (name, entry) ->
        let prefix = match entry.Builtin with Some(BuiltinOp _) -> "primitive-" | Some _ -> "generated-" | None -> "user-"
        name, WordId(prefix + name))
    |> Map.ofList
let compilerContext: Compiler.IrLoweringContext =
    { Words = words; Records = records; Scalars = scalars; Enums = Map.empty; WordIds = wordIds }
let context: FlowLowering.Context =
    { CompilerContext = compilerContext; ParameterNames = Map.empty; Flow2OwnerIds = Set.empty; SourceOrigins = Map.empty }
let changes: FlowLowering.FlowWordChange list =
    document.Words
    |> List.map (fun definition ->
        { FlowLowering.FlowWordChange.Definition = definition
          RevisionIntent = FlowLowering.FlowWordRevisionIntent.Add(WordId("owning-mailbox-source-" + definition.Name), 1) })
let compiled = FlowLowering.compileBatchWords context changes
let program = compiled.Program
let positive =
    VerifiedIrProgram.inspect program
    |> fun inspected -> inspected.FunctionsById |> Map.toList |> List.map snd
    |> List.find (fun fn -> fn.FunctionName = "mailbox.is-positive-id?")
printfn "validator-ir: %A" positive.FunctionBody

let runValue value =
    let count = ref 0
    let wordSpans = compiled.Context.CompilerContext.Words |> Map.map (fun _ entry -> entry.Definition.Span)
    let host =
        { PreflightEffects = fun _ _ _ -> ()
          ChargeInstruction = fun _ _ -> count.Value <- count.Value + 1
          RecordBranchOutcome = fun _ _ _ -> ()
          RecordUse = ignore
          InvokeEffect = fun _ -> EffectUnit
          EnterUserFunction = fun _ _ _ -> fun () -> ()
          ReturnUserFunction = fun _ _ _ -> ()
          WordDefinitionSpan = fun word -> wordSpans.TryFind word
          PrimitiveDefinitionSpan = fun word -> wordSpans.TryFind word }
    let body =
        Compiler.compileIrBodyAgainstProgramWithSourceOrigins compiled.Context.CompilerContext program "count-positive-validator" []
            [ Push(LInt value, sourceSpan "<int-min-prefix>" 1); Call("mailbox.is-positive-id?", sourceSpan "<int-min-prefix>" 1) ]
            compiled.Context.SourceOrigins
    try
        use _result = IrInterpreter.executeBodyWithInputs host "count-positive-validator" body None []
        count.Value, "success"
    with error -> count.Value, error.ToString()

let normalSteps, normalResult = runValue 1L
let overflowSteps, overflowResult = runValue Int64.MinValue
printfn "normal-entry-steps=%d normal-result=%s" normalSteps normalResult
printfn "overflow-entry-steps=%d overflow-result=%s" overflowSteps overflowResult
printfn "validator-prefix-normal=%d validator-prefix-overflow=%d" (normalSteps - 2) (overflowSteps - 2)

# Refined mailbox admission — bounded implementation plan

Base: main at 4bd0ecc. Study179 completed; this is native semantic conformance,
not a new agent efficacy or throughput experiment.

Enable the ordinary owning backend's existing refined Int/String forms for
mailbox compilation. Reuse frozen pure predicate identities and recursive
active-payload validation after physical import and before external callback
body execution. A temporary validation frame must clean up on success and
failure, and generated metadata bounds must cover it.

Associated resume remains a trusted-host path over privately retained, admitted
State/Continuation roots. Do not replay their predicates. RETURN imports at the
external boundary again and must validate again. Constructor checks preserve
newly constructed output validity; do not add blanket output replay.

Do not change stack ABI1, mailbox/module ABI1, layout schema3, ownership syntax,
arena policy, physical nominal identity or effect capabilities. Unsupported
Bool/Float, unvalidated String wrappers and record predicates remain explicit.

Structural preflight errors preserve output sentinels. After preflight, a
predicate failure leaves output descriptors invalid under the existing ABI.
Committed retained bytes, logical roots and pending token must survive failure;
the same token must be retryable. Validator false and execution failure remain
distinct. Admission traversal must add no extra root import or deep copy. Count actual dynamic-path copy/move calls independently. Descriptor-transfer traces are metadata, not physical payload moves; the earlier proposed nonzero call-frame movement formula was incorrect. Retain failed assertions and distinguish handler record-construction copies from validation.

Ownership: compiler and focused LLVM tests; independent NativeValueStack
conformance update; independent real OwningMailbox lifecycle fixture and gate.
Main owns documentation, broad local gates, review and milestone publication.
All use the canonical checkout with non-overlapping files and isolated build
artifacts. Preserve unrelated untracked retention files.

Acceptance: frozen targets/revisions/purity; exact nominal identities and
independent serialized bytes; active nested record/Option/Result admission;
inactive alternatives not validated; failure before handler/output publication;
cleanup, roots/token preservation, retry; both arena policies and O0/O2 with
existing host profiles; exact copy and predicate replay accounting.

Fresh focused Int/String/updated mailbox checks, full LLVM, native value-stack,
mailbox integration/policy and applicable local I/O regressions, and
scripts/Validate.ps1 -Configuration Release -SerialBuild -SkipPackageAudit must
pass before publication. Keep failed attempts. Reports must distinguish
conformance from security certification and throughput/agent-efficacy evidence.

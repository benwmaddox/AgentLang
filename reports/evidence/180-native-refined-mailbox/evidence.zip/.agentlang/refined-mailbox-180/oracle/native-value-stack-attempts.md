# NativeValueStack refined mailbox check — milestone 180

## Change

Replaced the refined String mailbox rejection expectation in `experiments/AgentLang.NativeValueStack/Program.fs` with a positive check against the compiled mailbox module. The check verifies the compiler-minted pure `is-non-empty?` validator target and revision, exact `NonEmptyString` and distinct State/Continuation identities in layouts and callback signatures, matching TypeIds in the emitted module manifest, and format/module/layout versions 1/1/3. The existing Bool, Float, and unvalidated String rejection checks remain in the O0/O2 runner.

This runner check validates compiled metadata and callback signatures. Actual exported-callback admission, state preservation, retry, and predicate replay behavior remain covered by the separate lifecycle fixture.

## Validation attempts

The first fresh build exposed type errors in the new assertion: source `LangType` constructors were used where verified IR types were required, and the existing ID helper's numeric key was mistaken for `ProgramTypeKey`. Both were corrected by using `IrString`/`IrBool` and taking exact keys from the verified program's nominal table.

Fresh Release build, isolated from repository `bin`/`obj` outputs:

```powershell
dotnet build experiments/AgentLang.NativeValueStack/AgentLang.NativeValueStack.fsproj --artifacts-path .agentlang/refined-mailbox-180/oracle/build --configuration Release --verbosity minimal -p:NuGetAudit=false -m:1
```

Result: passed, 0 warnings, 0 errors.

The existing runner has no mailbox-only mode, so its full default native execution was used with separate isolated runtime artifacts:

```powershell
dotnet .agentlang/refined-mailbox-180/oracle/build/bin/AgentLang.NativeValueStack/release/AgentLang.NativeValueStack.dll tests/fixtures/native-conformance/native-value-stack.json .agentlang/refined-mailbox-180/oracle/native-artifacts .agentlang/refined-mailbox-180/oracle/native-value-stack-evidence.json
```

Result: passed, 1,424 checks, 0 failures. The mailbox check passed at O0 and O2. Its complete emitted details are in `native-value-stack-evidence.json`; generated native outputs are under `native-artifacts/`.

`git diff --check -- experiments/AgentLang.NativeValueStack/Program.fs` passed before the successful build.

# Copy/move accounting correction

The first focused raw Int callback assertion expected zero deep-copy and move
bytes. It failed. The next proposed formula counted ordinary descriptor
transfers as physical movement and also failed: measured deepCopyBytes=8,
moveBytes=0, inputCopyBytes=24 versus proposed moveBytes=56.

Source inspection resolves the movement confusion: emitDescriptorTransfer in
the dynamic emitter calls al_owning_record_layout with event kind 17. It records
descriptor metadata and does not invoke a physical move. Older fixed-layout
emitter move_range sites are not this dynamic path. emitCopyDynamicRange calls
al_owning_copy_range for actual construction copies. The handler constructs
a continuation record with an eight-byte Int field; its construction must be
accounted independently rather than charged to predicate admission.

Implementation and fixture workers were asked to derive final counters from
the dynamic IR and runtime copy/move sites before rerunning. This note does not
declare final acceptance; preserve the original failed runs. The user-facing
statement about actual predicate frame movement was corrected after inspection.

# Owning stack 003: compiler-proven stable arena values

Status: revised bounded plan for the prototype. Report 129 and
`.agentlang/owning-stack-002/` remain the correctness baseline; their packed
payload placement is the behavior to replace. This plan uses compiler-owned
scope/call provenance, inline canonical values, and conservative bump-pointer
rewinds. It does not add source references or lifetime annotations.

## Contract and representation

- Keep `TypedIR.fs`, `IrInterpreter.fs`, source syntax, and value semantics
  unchanged. Use the verified stack/local shapes, block scopes, call signatures,
  and existing type layout information.
- Keep one bounded request-working payload arena. Strings, scalars, and records
  remain canonical inline byte ranges. A value is represented in the backend
  by a descriptor `{ type, offset, extent, payload, ownerEnd }`; operand stacks
  and locals carry these descriptors instead of assuming that values occupy
  one contiguous suffix at the current cursor. `ownerEnd` bounds reads and
  preserves the full parent allocation when a projected field remains live.
- Keep descriptor metadata in generated per-frame LLVM values/allocas. Do not
  add a runtime descriptor heap, allocation log, object graph, or per-operation
  reference counting. Count the descriptor alloca layout in the existing
  backend metadata bound.
- `StoreLocal` transfers a descriptor into its local slot. `LoadLocal` copies
  only descriptor metadata. Record field projection returns a descriptor for
  the field’s byte range and inherits the parent’s `ownerEnd`. These operations
  do not copy or move payload bytes.
- `MakeRecord` creates a new canonical inline record in the arena by copying its
  field ranges into declaration-order positions. This is a value construction
  copy; account for it explicitly. The result’s `ownerEnd` is the end of the new
  record. Destination-passing or in-place construction can be considered later.
- A value descriptor from an external root has `ownerEnd = offset + extent`.
  A descriptor produced by projecting a field inherits its containing record’s
  `ownerEnd`, even when its own field extent is shorter. Nested projections
  preserve that same owner bound. This conservative rule keeps parent bytes
  alive while an extracted field is in use.
- Keep the canonical input/output encoding and layout schema unchanged. Do not
  add a prototype ABI or evidence-schema version bump for this placement
  change. Continue to use the existing context, scanner, `reserve_to`,
  `release_to`, copy, and event structures where they fit.

## Static lifetime proof and rewind rules

Make rewind decisions in the compiler’s IR/provenance analysis. Runtime code
must never scan roots or choose a safe cursor from observed handles. If the
analysis cannot prove that a suffix is dead, emit no rewind and let the arena
grow to an enclosing proven boundary or request completion.

Track abstract allocation origins through the supported IR. A new constant,
scalar result, concatenation, or `MakeRecord` belongs to its current scope/frame
region. `LoadLocal` and `StoreLocal` preserve origin. `GetRecordField` inherits
the parent origin. `If` joins origins from both arms. Calls use an output
provenance summary when it is available; otherwise treat their outputs as
belonging to the caller’s current region. A branch or call that may expose a
region makes that region escape for the boundary in question.

At `Scope` entry, save the current payload cursor as a generated scalar mark.
At successful exit, release child locals and inspect the compiler-known
outgoing operand and surviving local origins. Emit `release_to(mark)` only when
none can refer to an allocation made in that scope. Preserve the entire suffix
when any value escapes or provenance is uncertain. In particular, a result
allocated after a temporary keeps both ranges occupied if the temporary lies
beneath it; do not move the result to expose the hole. A later enclosing scope
may rewind to its own mark after it proves that the result and all other values
from that region are dead.

Apply the same rule at function return. The caller’s arena prefix is protected
by the callee’s frame-entry mark, so the callee does not inspect caller roots.
If every output is proven to refer only to data at or below that mark, rewind to
the mark. If an output may refer to a callee allocation, keep the cursor and
return its descriptor directly; the caller assigns that result to its current
region for subsequent scope analysis. On request success, serialize outputs
before resetting the complete request arena. On any failure, unwind to the
entry mark and leave the caller’s output buffer unchanged.

The verifier already restores outer locals at `Scope` exit, so a same-slot child
store remains a shadow and cannot replace the outer descriptor. Branch joins
must preserve the current verified shape and conservatively join allocation
origins. Scope/frame marks are numeric runtime offsets; the decision to rewind
to one is static and compiler-proven.

## Emitter and runtime work

1. Route normal owning-stack compilation through one descriptor-based emitter
   for both fixed and dynamic layouts. The current dynamic emitter already
   handles the required types; generalize its lowering and dispatch so fixed
   record controls do not silently keep the packed local path. Keep the old
   fixed emitter only as a clearly named historical control if it remains
   useful; it must not be selected by the normal `compile` API.
2. Change the dynamic stack entry from implicit suffix position plus extent and
   payload to explicit offset, extent, payload, owner end, and type. Store those
   fields in generated local metadata. Change cursor validation from
   `cursor == sum(live stack extents)` to checked descriptor bounds:
   `offset + extent <= ownerEnd <= cursor` for each operand/local range.
3. Replace packed `emitStoreLocal`, `removeLocal`, `emitCompactMove`,
   `emitEntryOffset`, and cursor-join assumptions. Local replacement and scope
   cleanup update descriptor metadata and active flags only. At a statically
   dead scope exit, call the existing `al_owning_release_to` with the saved
   mark. Do not issue `LOCAL_COMPACT` or payload move events for binding,
   projection, call/return, or cleanup.
4. Pass user-call inputs and results through caller-owned descriptor slots.
   The callee reads argument ranges directly in the shared request arena and
   returns descriptors; it does not copy arguments to a frame or move a
   contiguous output range back over arguments. Dynamic `If` merges descriptor
   fields, including `ownerEnd`, along the selected branch.
5. Keep generated-record construction canonical and checked. Precompute the
   exact parent layout and capacity, reserve the output, copy each field range
   into the record, then publish the output descriptor. Keep empty-record
   standalone token and nested zero-width behavior. For field access, use the
   verified layout/scanner to obtain offset, payload, and extent, then return a
   descriptor with the parent `ownerEnd`; do not allocate a payload result.
6. New scalar/String results and concatenation append at the arena cursor and
   never relocate live operands. Explicit `dup` may make an independent payload
   copy. Record construction and duplication copies are reported as payload
   copies; external input and retained output copies keep their existing
   separate counters.
7. At the wrapper, validate external values before their one required copy into
   the arena. Serialize each returned descriptor range into bounded retained
   staging in output order, after preflighting total bytes and ranges. Preserve
   success-only host commit and the existing UTF-16 code-unit behavior,
   diagnostics, capacity boundaries, and `ExecuteInto` API.
8. Update only existing components: `OwningStackAot.fs`,
   `native/owning_stack_runtime.[ch]` and `owning_stack_runtime_test.c` where
   runtime checks/events need adjustment, `experiments/AgentLang.NativeValueStack/Program.fs`,
   `tests/fixtures/native-conformance/native-value-stack.json`, and
   `scripts/Verify-NativeValueStack.ps1`. Keep report 129 and owning-stack-002
   artifacts unchanged.

## Metrics and evidence semantics

- `MoveBytes` counts physical payload moves only; binding, field projection,
  call/return, and scope cleanup contribute zero. `DeepCopyBytes` counts actual
  payload copies, including `MakeRecord` construction and explicit duplicate.
  `InputCopyBytes` and `RetainedCopyBytes` remain boundary-specific.
- Report descriptor transfer counts/bytes separately from payload copies and
  moves. `BackendMetadataPerFrameBytes` and
  `BackendMetadataPeakBoundBytes` continue to describe generated metadata,
  including the new descriptor slots.
- Do not estimate unique live payload by summing aliased descriptors or locals.
  If logical roots are reported, label their sum as logical bytes. Report unique
  live payload only when an exact interval-union measurement is available; it
  may remain debug-only. Capacity and occupied memory use cursor/peak cursor,
  which includes dead interior holes retained beneath a live result.

## Required tests

- **Six locals:** create six String locals and exit a dead-only scope. Assert
  zero payload moves/copies for stores, loads, and cleanup; cursor rewinds once
  to the saved mark. Replacing an earlier local while younger values remain
  must not move those values.
- **Ordinary binding and call:** load a value through locals, pass it through a
  user call, and return it unchanged. Assert payload `DeepCopyBytes` and
  `MoveBytes` for those operations are zero, aside from independently reported
  input/retained boundary copies. Keep multiple outputs with a larger first
  result and distinct second-output sentinel, plus a zero-output call.
- **Nested dead-only scopes:** inner and outer scopes allocate values that do
  not escape. Assert each proven exit rewinds to its own saved mark, following
  scopes can reuse that capacity, and no payload range is compacted.
- **Escaping scope result:** allocate a temporary followed by a String result
  and return the result from the inner scope. Assert the inner scope emits no
  rewind, the result remains readable, and the dead temporary beneath it stays
  occupied. After the result dies, an enclosing scope with a proof that its
  entire suffix is dead rewinds to its mark.
- **Parent-backed field:** project a String field from a record constructed or
  read before an inner scope, return the field descriptor, and read it after
  the parent stack operand is consumed. Verify inherited `ownerEnd` preserves
  the parent bytes until the enclosing proven boundary.
- **Record and wire controls:** construct/project nested `[Empty, String, Int]`
  records, compare exact literal output bytes, and cover zero-width nested
  Empty, standalone Empty token, dynamic String offsets/padding, embedded NUL,
  astral pairs, and isolated surrogates. Assert construction-copy bytes are
  counted separately from projection/binding/call movement.
- **Failure isolation and old controls:** retain malformed/truncated inputs,
  stack/retained capacity boundaries, failure after allocation, call-depth
  64/65, explicit dup/drop, same-slot scope shadowing, branch joins, and
  interpreter/O0/O2 parity. Every failure keeps the caller buffer unchanged,
  resets the cursor to the request mark, and clears live accounting.
- The direct native suite keeps strict C checks at O0/O2 and UBSan trap. Pin
  release-to behavior at saved marks and ensure validation rejects descriptor
  ranges outside their parent owner even when they remain below the global
  cursor.

## Validation commands

Update the focused runner’s evidence output path to
`.agentlang/owning-stack-003/`, then run it from a fresh serial build. It covers
the native storage suite, O0/O2 generated execution, interpreter and literal
byte oracles, and stable source hashes:

```powershell
pwsh -NoProfile -File scripts/Verify-NativeValueStack.ps1
```

Then run the full serial Release gate and whitespace check:

```powershell
pwsh -NoProfile -File scripts/Validate.ps1 -SerialBuild -SkipPackageAudit
git diff --check
```

Report cursor peaks, payload copy/move bytes, descriptor metadata, boundary
copies, and instrumentation storage separately. These counters prove the
placement contract; they do not by themselves prove throughput or total-process
memory improvements.

## Limits

Compiler-proven scope exits release only fully dead suffixes. Values that escape
retain their whole canonical owner range, along with any dead bytes beneath
them, until a later enclosing proof or request reset. Large scopes with many
temporaries can therefore reach capacity earlier than the packed implementation;
tests must record that occupied cursor and allow an honest capacity failure.
When provenance is uncertain at a branch or call boundary, retain the region
until an enclosing boundary proves it dead. The current native subset has
bounded calls and no loop opcode; no loop or cross-request value lifetime is
implied by this plan.

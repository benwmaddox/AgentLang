# Owning stack 003 acceptance plan

This is the harness audit and oracle plan for the stable arena policy. It records
expected behavior before the new emitter is exercised; it contains no measured
results. Report 129 and `owning-stack-002` remain the historical packed-layout
control.

## Current packed-layout assumptions

The existing comparison runner already covers interpreter and LLVM O0/O2
semantics, fixed record bytes, dynamic UTF-16 encoding, capacity boundaries,
failure isolation, call/layout depth, repeated requests, and local shadowing.
Those independent controls remain acceptance requirements.

The runner also encodes packed-placement assumptions that must be replaced in
place:

- The direct `dup`/`drop` check correlates a duplicate range, a drop range, a
  call-return move range, and the retained-copy source range. Keep the
  independent duplicate and survivor checks; remove the expectation that
  return transfers or compacts payload ranges.
- The String range correlator treats local store/load, field extraction,
  drop, scope clearing, user-call input/return, and `local-compact` events as
  payload mutations. Descriptor operations must instead be checked for zero
  payload copy/move bytes; only construction, `dup`, concatenation, and the
  already separate input/retained boundaries may account for physical copies.
- The independent concatenation capacity oracle hard-codes a packed schedule
  with frame-input copies, local-load copies, and result scratch. Replace that
  schedule with semantic output checks, measured cursor/high-water evidence,
  and the descriptor/copy categories promised by the new policy.
- `PeakLiveStackBytes` and `PeakLiveLocalBytes` are summed beside reservations
  as though each live payload has one packed owner. Stable descriptors can
  alias parent ranges, and an escaped result can leave dead interior bytes
  occupied. Report logical root bytes separately from unique live payload
  (only if exact interval-union evidence is supplied), occupied cursor/dead
  interior space, reserved capacity, and metadata.
- The focus runner writes under `.agentlang/owning-stack-002/`; route new runs
  and evidence under `.agentlang/owning-stack-003/` so the frozen baseline is
  untouched.

Do not remove byte-for-byte serialization, layout, UTF-16, interpreter parity,
or failure tests to accommodate the new placement policy. Keep explicit
duplicate disjointness and survivor readability: explicit `dup` still creates
an independent value.

## Stable arena oracles

For both fixed-only and String-bearing programs, at LLVM O0 and O2:

1. Local store/load, field projection, same-arena call/return, and scope cleanup
   transfer descriptors and produce zero payload moves or copies. Canonical
   record construction and explicit duplication may copy and must be reported
   as deep-copy bytes; external input staging and retained output are reported
   separately.
2. A nested dead-only scope emits a rewind to its saved mark. A small fresh
   construction after that rewind must start at the mark, and later local
   loads must still refer to the original premark inputs without payload
   moves. A scope returning an allocation made after a temporary emits no
   inner rewind; the cursor keeps the result and the temporary beneath it
   until a later proven enclosing boundary.
3. Branch joins and calls with uncertain output provenance block early rewind.
   The tests inspect the emitted lifetime decisions/LLVM: only compiler-proven
   sites rewind, and there is no runtime root/liveness scan or conditional
   liveness decision. Same-slot child shadowing restores the outer descriptor.
4. A projected field retains its parent `ownerEnd` after the parent operand is
   consumed. The field remains readable until the enclosing proven boundary.
5. Repeated completed requests reset to the entry mark and reuse capacity.
   Results preserve their arena address across binding, projection, call, and
   return; no descriptor survives reset into retained state.
6. Keep exact semantic and wire controls: fixed record layouts, nested and
   zero-width Empty, standalone Empty token, dynamic offsets/padding, embedded
   NUL, astral pairs, isolated surrogates, branch output order, multi-output
   sentinel, zero-output calls, explicit dup/drop, stack and retained capacity
   boundaries, malformed/truncated input, failure unwind/buffer atomicity,
   same-slot shadowing, call depth 64/65, and layout depth 64/65.
7. Keep interpreter/O0/O2 parity and fixed ABI3 controls where applicable.
   Preserve the existing native storage suite and ABI checks that remain part
   of its contract; update independently pinned values only when the runtime
   owner changes that contract for the stable policy.

## Evidence and validation

The focused script must hash the harness inputs and place all new artifacts and
evidence below `.agentlang/owning-stack-003/`. Preserve the old independent
semantic/encoding/capacity oracles; replace only assertions tied to packed
addresses, payload-moving local/call behavior, or summed aliased live ranges.
The emitted metrics and static lifetime evidence are authoritative; do not tune
fixture expectations to a failing implementation run.

After the emitter and runtime changes are ready, run the fresh serial Release
focused gate:

```powershell
pwsh -NoProfile -File scripts/Verify-NativeValueStack.ps1
```

The root task owns the final full Release validation gate. This worker will not
start the focused runner until the emitter owner confirms the stable API and
artifacts are ready.

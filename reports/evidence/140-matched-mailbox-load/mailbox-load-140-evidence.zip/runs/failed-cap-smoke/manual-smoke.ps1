$ErrorActionPreference = 'Stop'
$root = 'D:\code\AgentLang\.agentlang\mailbox-load-140\4e1e4ffd0d2c4e8fb878a63fe70b5d80'
$r = Get-Content (Join-Path $root 'run-report.json') -Raw | ConvertFrom-Json -AsHashtable
$out = Join-Path $root 'manual-smoke'
[IO.Directory]::CreateDirectory($out) | Out-Null
foreach ($variant in @('fsharp','return4','keep4','return16','keep16')) {
  $dir = Join-Path $out $variant
  [IO.Directory]::CreateDirectory($dir) | Out-Null
  $ready = Join-Path $dir 'ready.json'
  $stop = Join-Path $dir 'stop'
  $providerArgs = @($r.buildIdentity.provider.path,'--port','0','--persistent','true','--ready-file',$ready,'--stop-file',$stop)
  $p = Start-Process -FilePath $r.runtime.dotnetPath -ArgumentList $providerArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $dir 'provider.stdout.txt') -RedirectStandardError (Join-Path $dir 'provider.stderr.txt')
  try {
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    while (!(Test-Path $ready) -and !$p.HasExited -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 20 }
    if (!(Test-Path $ready)) { throw 'Provider failed readiness' }
    $port = (Get-Content $ready -Raw | ConvertFrom-Json).port
    $common = @('--port',"$port",'--rate','500','--payload-bytes','4096','--delay-ms','5','--warmup-ms','100','--duration-ms','1200','--output',(Join-Path $dir 'result.json'))
    if ($variant -eq 'fsharp') { & $r.runtime.dotnetPath $r.buildIdentity.fsharpBaseline.path @common }
    else {
      $policy = if ($variant.StartsWith('return')) {'return'} else {'keep'}
      $slots = if ($variant.EndsWith('16')) {'16'} else {'4'}
      & $r.buildIdentity.native.path --module $r.buildIdentity.mailboxModule.path --policy $policy --scratch-slots $slots @common
    }
    if ($LASTEXITCODE -ne 0) { throw "Application $variant exited $LASTEXITCODE" }
    $app = Get-Content (Join-Path $dir 'result.json') -Raw | ConvertFrom-Json
    [pscustomobject]@{variant=$variant;offered=$app.offered;admitted=$app.admitted;completed=$app.completed;errors=$app.errors;verified=$app.verified} | ConvertTo-Json -Compress
  } finally {
    [IO.File]::WriteAllText($stop,'stop')
    if (!$p.WaitForExit(10000)) { Stop-Process -Id $p.Id; throw 'Provider failed graceful stop' }
    $p.Dispose()
  }
}
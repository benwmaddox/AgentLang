#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <wchar.h>

int wmain(int argc, wchar_t **argv) {
  if (argc != 2) return 81;
  if (wcscmp(argv[1], L"cap") == 0) {
    const SIZE_T request_bytes = 64U * 1024U * 1024U;
    const SIZE_T page_bytes = 4096U;
    SIZE_T offset;
    unsigned char *region = (unsigned char *)VirtualAlloc(NULL, request_bytes, MEM_RESERVE, PAGE_READWRITE);
    if (region == NULL) return 82;
    puts("cap probe reserved 64 MiB; committing and touching pages");
    fflush(stdout);
    for (offset = 0; offset < request_bytes; offset += page_bytes) {
      void *page = VirtualAlloc(region + offset, page_bytes, MEM_COMMIT, PAGE_READWRITE);
      if (page == NULL) {
        printf("job ceiling blocked commit at %llu bytes (error=%lu)\n",
               (unsigned long long)offset, (unsigned long)GetLastError());
        fflush(stdout);
        return 77;
      }
      ((volatile unsigned char *)page)[0] = (unsigned char)(offset / page_bytes);
    }
    puts("cap probe committed and touched all 64 MiB");
    fflush(stdout);
    return 0;
  }
  if (wcscmp(argv[1], L"timeout") == 0) {
    puts("timeout probe entered its bounded wait");
    fflush(stdout);
    Sleep(60000);
    return 0;
  }
  if (wcscmp(argv[1], L"exit") == 0) {
    puts("exit probe stdout marker");
    fputs("exit probe stderr marker\n", stderr);
    fflush(stdout);
    fflush(stderr);
    return 23;
  }
  return 82;
}
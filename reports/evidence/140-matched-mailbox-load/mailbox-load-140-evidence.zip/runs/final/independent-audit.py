import collections
import hashlib
import json
import math
from pathlib import Path

root = Path(__file__).parent
report = json.loads((root / 'run-report.json').read_text(encoding='utf-8'))
assert report['error'] is None and report['sourceStable'] is True
assert report['scoringPreflight']['passed'] is True
assert len(report['controls']) == 4 and all(c['passed'] for c in report['controls'])
before = {x['path']: x['sha256'] for x in report['sourceHashesBefore']}
after = {x['path']: x['sha256'] for x in report['sourceHashesAfter']}
assert before == after
for name, digest in before.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name

groups = collections.defaultdict(list)
derived = []
ids = set()
for trial in report['trials']:
    ident = trial['trialId']
    assert ident not in ids and trial['validComparison'] is True, ident
    ids.add(ident)
    app = json.loads(Path(trial['paths']['applicationResult']).read_text(encoding='utf-8'))
    process = json.loads(Path(trial['paths']['applicationRunner']).read_text(encoding='utf-8'))
    provider = trial['provider']['counters']
    for field in ('rate', 'payloadBytes', 'delayMs', 'warmupMs', 'durationMs', 'backend', 'policy'):
        assert app[field] == trial[field], (ident, field)
    if trial['backend'] == 'native':
        assert app['scratchSlots'] == trial['scratchSlots'], ident
    phase = trial['phase']
    if phase in ('grid', 'confirmation-30s', 'capacity-16-slot', 'capacity-fsharp-reference', 'native-plus25'):
        assert trial['warmupMs'] == 1000 and trial['payloadBytes'] == 4096, ident
        assert trial['durationMs'] == (30000 if phase == 'confirmation-30s' else 3000), ident
        assert trial['applicationLimitBytes'] == (335544320 if phase == 'native-plus25' else 268435456), ident
    if phase == 'capacity-16-slot':
        assert trial['backend'] == 'native' and trial['scratchSlots'] == 16, ident
    if phase == 'native-plus25':
        assert trial['backend'] == 'native' and trial['scratchSlots'] == 4, ident
    assert process['exitCode'] == 0 and not process['timedOut'] and not process['jobDrainTimedOut'], ident
    assert process['jobAssigned'] and process['capConfigured'], ident
    assert process['enforcedJobMemoryLimitBytes'] == trial['applicationLimitBytes'], ident
    assert int(process['affinityMask'], 16) == int(report['cpu']['applicationAffinityMask'], 16), ident
    assert app['verified'] and app['errors'] == app['timedOut'] == app['pendingAtEnd'] == 0, ident
    assert app['offered'] == (trial['rate'] * trial['durationMs'] + 999) // 1000, ident
    assert app['offered'] == app['admitted'] + app['rejected'], ident
    assert app['admitted'] == app['completed'], ident
    assert app['completedWithinWindow'] <= app['completed'], ident
    assert app['missedArrivals'] <= app['rejected'] and app['peakPending'] <= 16, ident
    assert len(app['mailboxes']) == 16 and {m['id'] for m in app['mailboxes']} == set(range(16)), ident
    assert all(m['latestVerified'] and m['attempted'] == m['completed'] for m in app['mailboxes']), ident
    assert sum(m['attempted'] for m in app['mailboxes']) == app['admitted'], ident
    assert provider['acceptedConnections'] == 16, ident
    assert provider['acceptedFrames'] == provider['completedFrames'] == app['warmupCompleted'] + app['completed'], ident
    assert all(provider[k] == 0 for k in ('rejectedBusy', 'invalidFrames', 'timedOut', 'cancelled', 'ioFailures', 'internalErrors')), ident
    values = sorted(app['latencyMicroseconds'])
    assert len(values) == app['completed'] and all(type(v) is int and v >= 0 for v in values), ident
    p99 = values[(99 * len(values) + 99) // 100 - 1] if values else None
    rejection = app['rejected'] / app['offered']
    throughput = app['completedWithinWindow'] * 1000 / trial['durationMs']
    qualifies = p99 is not None and p99 <= 50000 and rejection <= .01
    summary = trial['application']
    assert p99 == summary['p99LatencyMicroseconds'] and qualifies == summary['qualifies'], ident
    assert math.isclose(throughput, summary['throughputPerSecond'], abs_tol=1e-9), ident
    assert math.isclose(rejection, summary['rejectedFraction'], abs_tol=1e-12), ident
    key = (trial['phase'], trial['backend'], trial['policy'], trial['scratchSlots'], trial['delayMs'], trial['rate'])
    groups[key].append((trial['repeat'], qualifies))
    derived.append(dict(id=ident, phase=trial['phase'], backend=trial['backend'], policy=trial['policy'],
                        slots=trial['scratchSlots'], delay=trial['delayMs'], rate=trial['rate'],
                        qualifies=qualifies, p99=p99, rejection=rejection, throughput=throughput,
                        committedBytes=process['peakJobCommittedBytes'], workingSetBytes=process['peakWorkingSetBytes']))

def qualified(phase, backend, policy, slots, delay, rate):
    rows = groups[(phase, backend, policy, slots, delay, rate)]
    return sorted(r for r, _ in rows) == [1, 2, 3] and all(q for _, q in rows)

reported_groups = {}
for row in report['score']['grid']:
    key = ('grid', row['backend'], row['policy'], row['scratchSlots'], row['delayMs'], row['rate'])
    assert key not in reported_groups
    reported_groups[key] = row
assert set(reported_groups) == {key for key in groups if key[0] == 'grid'}
for key, row in reported_groups.items():
    assert row['repeatCount'] == 3 and row['allRepeatsQualify'] == qualified(*key), key
    expected_ids = {t['trialId'] for t in report['trials'] if
                    (t['phase'], t['backend'], t['policy'], t['scratchSlots'], t['delayMs'], t['rate']) == key}
    assert set(row['trialIds']) == expected_ids and len(row['trialIds']) == 3, key

highest = []
for backend, policy, slots in [('fsharp', 'gc', None), ('native', 'return', 4), ('native', 'keep', 4)]:
    for delay in (0, 5):
        rates = sorted(k[-1] for k in groups if k[:5] == ('grid', backend, policy, slots, delay))
        assert set((250, 500, 1000, 2000, 4000, 8000)) <= set(rates)
        assert all(sorted(r for r, _ in groups[('grid', backend, policy, slots, delay, rate)]) == [1, 2, 3] for rate in rates)
        passing = [rate for rate in rates if qualified('grid', backend, policy, slots, delay, rate)]
        best = max(passing) if passing else None
        row = next(x for x in report['score']['highestQualifyingTestedRates'] if
                   (x['backend'], x['policy'], x['scratchSlots'], x['delayMs']) == (backend, policy, slots, delay))
        assert row['highestQualifyingTestedRate'] == best
        confirmation = [x for x in derived if (x['phase'], x['backend'], x['policy'], x['slots'], x['delay']) ==
                        ('confirmation-30s', backend, policy, slots, delay)]
        assert len(confirmation) == 1 and confirmation[0]['rate'] == (best or 250)
        if backend == 'native':
            followup = groups[('native-plus25', backend, policy, slots, delay, best or 250)]
            assert sorted(r for r, _ in followup) == [1, 2, 3]
        highest.append(dict(backend=backend, policy=policy, slots=slots, delay=delay, highest=best,
                            confirmationQualifies=confirmation[0]['qualifies']))

grid_rates = sorted({k[-1] for k in groups if k[0] == 'grid'})
assert report['score']['testedRateGrid'] == grid_rates
for rate in grid_rates:
    if rate >= 8000 and rate < 64000 and any(qualified(*key) for key in list(groups) if key[0] == 'grid' and key[-1] == rate):
        assert rate * 2 in grid_rates, ('missing grid extension', rate)
assert report['score']['sustainedClaimAllowed'] == all(x['confirmationQualifies'] for x in highest)
for delay in (0, 5):
    required = set()
    for row in highest:
        if row['backend'] == 'native' and row['delay'] == delay:
            rate = row['highest'] or 250
            required.add(rate)
            if rate < 64000:
                required.add(rate * 2)
    for policy in ('return', 'keep'):
        actual = {k[-1] for k in groups if k[:5] == ('capacity-16-slot', 'native', policy, 16, delay)}
        assert required <= actual, ('missing capacity point', policy, delay)
        for rate in actual:
            assert sorted(r for r, _ in groups[('capacity-16-slot', 'native', policy, 16, delay, rate)]) == [1, 2, 3]
    capacity_rates = sorted({k[-1] for k in groups if k[0] == 'capacity-16-slot' and k[4] == delay})
    last = max(capacity_rates)
    assert last == 64000 or not any(qualified('capacity-16-slot', 'native', p, 16, delay, last) for p in ('return', 'keep'))
    for rate in capacity_rates:
        reference = groups.get(('grid', 'fsharp', 'gc', None, delay, rate))
        if reference is None:
            reference = groups.get(('capacity-fsharp-reference', 'fsharp', 'gc', None, delay, rate), [])
        assert sorted(r for r, _ in reference) == [1, 2, 3], ('missing F# capacity reference', delay, rate)

output = dict(passed=True, trialCount=len(derived), sourceCount=len(before), highest=highest,
              gridRates=grid_rates, trials=derived)
(root / 'independent-audit.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in output.items() if k != 'trials'}, indent=2))

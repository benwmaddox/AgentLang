#requires -Version 7.0
# Per-change AOT native host benchmark: the report-259 native lifetime protocol
# (same snapshot, cookie, contract, loadgen, core pinning, 2 s warmup at 4
# clients, 8 s timed at 16 clients, gzip off) plus host memory capture.
param(
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,48}$')][string]$RunName,
  [Parameter(Mandatory)][string]$BuildDir,
  [string]$Snapshot = 'snap-nc'
)
$ErrorActionPreference = 'Stop'
$w = Join-Path $PSScriptRoot '../campfire-matched-258'
$out = Join-Path $PSScriptRoot "runs/$RunName"
$priv = Join-Path $PSScriptRoot "private/native-db-$RunName"
if ((Test-Path -LiteralPath $out) -or (Test-Path -LiteralPath $priv)) { throw 'Run roots are immutable.' }
$null = New-Item -ItemType Directory -Path $out, $priv -Force
function Note([string]$t) { "$([DateTime]::UtcNow.ToString('O')) $t" | Add-Content -LiteralPath (Join-Path $out 'driver.log') -Encoding utf8NoBOM; Write-Output $t }
if (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 13773, 13774) { throw 'Port 13773/13774 busy.' }

$labels = Get-Content (Join-Path $w '../once-campfire-verification/fixtures/default/labels.json') -Raw | ConvertFrom-Json
$room = $labels.'rooms.watercooler'
$cookie = [IO.File]::ReadAllText((Join-Path $w "private/rails-cookie-$Snapshot.txt"))
Copy-Item -LiteralPath (Join-Path $w "private/native-db-$Snapshot/production.sqlite3") -Destination (Join-Path $priv 'production.sqlite3')
$db = Join-Path $priv 'production.sqlite3'
$lg = Join-Path $w 'loadgen-target/release/loadgen.exe'
$contract = Join-Path $w 'contracts-preflight-1/room_show.json'
$stopName = 'Local\CampfireBenchStop'
$serverMask = [IntPtr]0x5401
$clientMask = [IntPtr]0x3F03FC
$build = (Resolve-Path -LiteralPath $BuildDir).Path

function Invoke-Loadgen([string]$Tag, [string[]]$Arguments) {
  $psi = [Diagnostics.ProcessStartInfo]::new($lg)
  $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
  foreach ($a in $Arguments) { [void]$psi.ArgumentList.Add($a) }
  $proc = [Diagnostics.Process]::Start($psi)
  $proc.ProcessorAffinity = $clientMask
  $stdout = $proc.StandardOutput.ReadToEndAsync(); $stderr = $proc.StandardError.ReadToEndAsync()
  $proc.WaitForExit()
  $result = [ordered]@{ exit = $proc.ExitCode; clientCpuMs = $proc.TotalProcessorTime.TotalMilliseconds }
  $stderr.GetAwaiter().GetResult() | Set-Content (Join-Path $out "loadgen-$Tag.err.log") -Encoding utf8NoBOM
  $text = $stdout.GetAwaiter().GetResult()
  $proc.Dispose()
  return @($text, $result)
}

$hostArgs = @('--module', (Join-Path $build 'owning-stack-native-host.dll'), '--manifest', (Join-Path $build 'owning-stack-native-host-manifest.json'),
              '--db', $db, '--secret-file', (Join-Path $w 'private/secret-key-base.txt'), '--port', '13773', '--workers', '4', '--stop-event', $stopName)
$hostLog = Join-Path $out 'native-host.log'
$hostProc = Start-Process -FilePath (Join-Path $build 'native_http_host.exe') -ArgumentList $hostArgs -PassThru -NoNewWindow `
  -RedirectStandardOutput $hostLog -RedirectStandardError (Join-Path $out 'native-host.stderr.log')
$null = $hostProc.Handle
$hostProc.ProcessorAffinity = $serverMask
$summary = [ordered]@{ run = $RunName; build = $build }
try {
  $deadline = [DateTime]::UtcNow.AddSeconds(60)
  while ([DateTime]::UtcNow -lt $deadline -and -not $hostProc.HasExited -and -not ((Test-Path $hostLog) -and (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet))) { Start-Sleep -Milliseconds 200 }
  if (-not (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet)) { throw 'native host not READY' }
  $hostProc.Refresh()
  $summary.readyWorkingSetBytes = $hostProc.WorkingSet64
  $summary.readyPrivateBytes = $hostProc.PrivateMemorySize64
  $base = @('--base', 'http://127.0.0.1:13773', '--cookie', $cookie)
  $file = Join-Path $priv 'body.html'
  $null = Invoke-Loadgen 'fetch' (@('fetch') + $base + @('--path', "/rooms/$room", '--out', $file))
  $summary.decodedBytes = (Get-Item $file).Length
  $common = @('--path', "/rooms/$room", '--validate', $contract)
  $null = Invoke-Loadgen 'warm' (@('http') + $base + $common + @('--conc', '4', '--duration', '2', '--gzip', '0'))
  $hostProc.Refresh(); $s0 = $hostProc.TotalProcessorTime.TotalMilliseconds
  $timed = Invoke-Loadgen 'timed' (@('http') + $base + $common + @('--conc', '16', '--duration', '8', '--gzip', '0'))
  $hostProc.Refresh(); $s1 = $hostProc.TotalProcessorTime.TotalMilliseconds
  $timed[0] | Set-Content (Join-Path $out 'timed.json') -Encoding utf8NoBOM
  $result = $timed[0] | ConvertFrom-Json
  $summary.rps = $result.rps
  $summary.ok = $result.ok
  $summary.invalid = $result.invalid_responses
  $summary.errors = $result.errors
  $summary.p50Ms = $result.latency.p50_ms
  $summary.p99Ms = $result.latency.p99_ms
  $summary.serverCpuMsPerRequest = [math]::Round(($s1 - $s0) / [math]::Max(1, $result.ok), 4)
  $summary.peakWorkingSetBytes = $hostProc.PeakWorkingSet64
  $summary.peakPrivateBytes = $hostProc.PeakPagedMemorySize64
  $summary.endPrivateBytes = $hostProc.PrivateMemorySize64
  $summary.loadgenExit = $timed[1].exit
} finally {
  try { $e = [Threading.EventWaitHandle]::OpenExisting($stopName); [void]$e.Set(); $e.Dispose() } catch { Note "stop event unavailable: $($_.Exception.Message)" }
  if (-not $hostProc.WaitForExit(60000)) { Note 'native host did not exit' } else { $hostProc.WaitForExit(); $summary.hostExit = $hostProc.ExitCode }
}
$summary | ConvertTo-Json | Set-Content (Join-Path $out 'summary.json') -Encoding utf8NoBOM
Note ($summary | ConvertTo-Json -Compress)

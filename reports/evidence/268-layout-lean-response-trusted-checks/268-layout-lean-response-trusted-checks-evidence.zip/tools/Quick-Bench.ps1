#requires -Version 7.0
# Quick per-batch benchmark (user, 2026-10-13): runs ONLY the AgentLang native
# host on the fixed room-page behavior (report-259 protocol, via Native-Bench.ps1),
# appends the median to history.jsonl, and compares it with the previous
# AgentLang record and the recorded Rails/Rust runs (reference-records.json).
# Rails and Rust are never rerun here: their code does not change.
param(
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,32}$')][string]$Label,
  [Parameter(Mandatory)][string]$BuildDir,
  [ValidateRange(1, 5)][int]$Runs = 2
)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$history = Join-Path $here 'history.jsonl'
$references = Get-Content -Raw -LiteralPath (Join-Path $here 'reference-records.json') | ConvertFrom-Json
$previous = if (Test-Path -LiteralPath $history) { Get-Content -LiteralPath $history | ForEach-Object { $_ | ConvertFrom-Json } | Where-Object { -not $_.contaminated } | Select-Object -Last 1 } else { $null }

$samples = foreach ($index in 1..$Runs) {
  $name = "quick-$Label-$index"
  & (Join-Path $here 'Native-Bench.ps1') -RunName $name -BuildDir $BuildDir | Out-Null
  Get-Content -Raw -LiteralPath (Join-Path $here "runs/$name/summary.json") | ConvertFrom-Json
}
foreach ($sample in $samples) {
  if ($sample.invalid -ne 0 -or $sample.errors -ne 0) { throw "Run $($sample.run) had invalid responses or errors." }
}
function Median([double[]]$values) { $sorted = $values | Sort-Object; $sorted[[int][Math]::Floor(($sorted.Count - 1) / 2)] }
$record = [ordered]@{
  utc = [DateTime]::UtcNow.ToString('o')
  label = $Label
  build = (Resolve-Path -LiteralPath $BuildDir).Path
  runs = $Runs
  pageBytes = [int]$samples[0].decodedBytes
  rps = [Math]::Round((Median @($samples.rps)), 1)
  serverCpuMsPerRequest = [Math]::Round((Median @($samples.serverCpuMsPerRequest)), 3)
  p50Ms = [Math]::Round((Median @($samples.p50Ms)), 3)
  p99Ms = [Math]::Round((Median @($samples.p99Ms)), 3)
  peakWorkingSetMB = [Math]::Round((Median @($samples.peakWorkingSetBytes)) / 1MB, 1)
  peakPrivateMB = [Math]::Round((Median @($samples.peakPrivateBytes)) / 1MB, 1)
  invalid = 0
}
($record | ConvertTo-Json -Compress) | Add-Content -LiteralPath $history -Encoding utf8NoBOM

$rows = @(
  [pscustomobject]@{ Server = "AgentLang ($Label)"; PageBytes = $record.pageBytes; ReqPerSec = $record.rps; CpuMsPerReq = $record.serverCpuMsPerRequest; P99Ms = $record.p99Ms; PeakWsMB = $record.peakWorkingSetMB; PeakPrivateMB = $record.peakPrivateMB }
)
if ($null -ne $previous) {
  $rows += [pscustomobject]@{ Server = "AgentLang (prev: $($previous.label))"; PageBytes = $previous.pageBytes; ReqPerSec = $previous.rps; CpuMsPerReq = $previous.serverCpuMsPerRequest; P99Ms = $previous.p99Ms; PeakWsMB = $previous.peakWorkingSetMB; PeakPrivateMB = $previous.peakPrivateMB }
}
foreach ($reference in $references.records) {
  $rows += [pscustomobject]@{ Server = "$($reference.server) (recorded)"; PageBytes = $reference.pageBytes; ReqPerSec = $reference.rps; CpuMsPerReq = $reference.serverCpuMsPerRequest; P99Ms = $reference.p99Ms; PeakWsMB = '-'; PeakPrivateMB = '-' }
}
$rows | Format-Table -AutoSize | Out-String | Write-Output
if ($null -ne $previous -and $previous.rps -gt 0) {
  Write-Output ("Change vs previous AgentLang record: {0:+0.0;-0.0}% req/s, {1:+0.0;-0.0}% CPU/request" -f ((($record.rps / $previous.rps) - 1) * 100), ((($record.serverCpuMsPerRequest / $previous.serverCpuMsPerRequest) - 1) * 100))
}
Write-Output "Pages are not equivalent until the full Rails room page is rendered; no speed ratio is claimed."

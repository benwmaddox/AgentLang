%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [3 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 5, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 3, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.sub.75 = sub i32 %context.value.74, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.75, i32 0, i32 0, i32 0)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %frame.failure.0
runtime.continue.79:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %runtime.ok.82 = icmp eq i32 %context.value.81, 0
  br i1 %runtime.ok.82, label %runtime.continue.83, label %frame.failure.0
runtime.continue.83:
  %descriptor.element.84 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 0
  store i32 5, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.89, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %descriptor.element.94 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.95 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 0
  store i32 4, ptr %descriptor.field.95, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.98, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.99, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %stack.offset.110 = add i32 %context.value.5, %context.value.7
  %stack.offset.111 = add i32 %context.value.105, %context.value.107
  %stack.sub.112 = sub i32 %stack.offset.110, %stack.offset.111
  %stack.sub.113 = sub i32 %context.value.7, %context.value.107
  %stack.sub.114 = sub i32 %context.value.109, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.112, i32 %stack.sub.113)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.114)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [2 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.payload.pointer.45 = alloca i32, align 4
  %input.measured.extent.pointer.46 = alloca i32, align 4
  %entry.output.descriptors.92 = alloca [2 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 1, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.extent.pointer.36 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.37 = load i32, ptr %input.extent.pointer.36, align 4
  %stack.sub.38 = sub i32 %input.bytes, %stack.offset.35
  %input.offset.within.bytes.39 = icmp ule i32 %stack.offset.35, %input.bytes
  %input.extent.within.bytes.40 = icmp ule i32 %input.host.extent.37, %stack.sub.38
  %input.slice.within.bytes.41 = and i1 %input.offset.within.bytes.39, %input.extent.within.bytes.40
  br i1 %input.slice.within.bytes.41, label %input.slice.ready.42, label %input.slice.invalid.43
input.slice.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.42:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.44, i32 %input.host.extent.37, i32 0, i32 2, ptr %input.payload.pointer.45, ptr %input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %input.measured.payload.50 = load i32, ptr %input.payload.pointer.45, align 4
  %input.measured.extent.51 = load i32, ptr %input.measured.extent.pointer.46, align 4
  %input.extent.exact.52 = icmp eq i32 %input.measured.extent.51, %input.host.extent.37
  br i1 %input.extent.exact.52, label %input.extent.exact.53, label %input.extent.invalid.54
input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 %input.measured.extent.51, i32 %input.host.extent.37)
  br label %entry.failure.0
input.extent.exact.53:
  %stack.offset.55 = add i32 %stack.offset.35, %input.host.extent.37
  %input.total.exact.56 = icmp eq i32 %stack.offset.55, %input.bytes
  br i1 %input.total.exact.56, label %input.valid.57, label %input.invalid.58
input.invalid.58:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.55, i32 %input.bytes)
  br label %entry.failure.0
input.valid.57:
  %reserve.status.59 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.55, i32 3)
  %reserve.ok.60 = icmp eq i32 %reserve.status.59, 0
  br i1 %reserve.ok.60, label %reserve.continue.61, label %entry.failure.0
reserve.continue.61:
  %host.pointer.62 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.63 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.62, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 5, i32 4)
  %helper.ok.64 = icmp eq i32 %input.copy.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %entry.failure.0
helper.continue.65:
  %stack.offset.66 = add i32 0, %input.host.extent.17
  %descriptor.element.67 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 0
  store i32 5, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 1
  store i32 0, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.70, align 4
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.71, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 4
  store i32 %stack.offset.66, ptr %descriptor.field.72, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.66, i32 %input.host.extent.17)
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %runtime.ok.75 = icmp eq i32 %context.value.74, 0
  br i1 %runtime.ok.75, label %runtime.continue.76, label %entry.failure.0
runtime.continue.76:
  %host.pointer.77 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.copy.status.78 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.35, ptr %host.pointer.77, i32 %input.host.extent.37, i32 0, i32 %input.measured.payload.50, i32 %input.host.extent.37, i32 4, i32 5)
  %helper.ok.79 = icmp eq i32 %input.copy.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %entry.failure.0
helper.continue.80:
  %stack.offset.81 = add i32 %stack.offset.35, %input.host.extent.37
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 1
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  store i32 4, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  store i32 %stack.offset.35, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  store i32 %input.host.extent.37, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  store i32 %input.measured.payload.50, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  store i32 %stack.offset.81, ptr %descriptor.field.87, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %stack.offset.35, i32 20, i32 %input.measured.payload.50, i32 %stack.offset.81, i32 %input.host.extent.37)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %entry.failure.0
runtime.continue.91:
  %entry.body.status.93 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.92, i32 6)
  %entry.body.ok.94 = icmp eq i32 %entry.body.status.93, 0
  br i1 %entry.body.ok.94, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.95 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.92, i32 0
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 0
  %descriptor.value.97 = load i32, ptr %descriptor.field.96, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 1
  %descriptor.value.99 = load i32, ptr %descriptor.field.98, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 2
  %descriptor.value.101 = load i32, ptr %descriptor.field.100, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 3
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 4
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %entry.output.type.valid.106 = icmp eq i32 %descriptor.value.97, 5
  br i1 %entry.output.type.valid.106, label %entry.output.type.ok.107, label %entry.output.type.invalid.108
entry.output.type.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.107:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %descriptor.value.105, %descriptor.value.99
  %descriptor.owner.inside.111 = icmp ule i32 %descriptor.value.105, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %descriptor.value.99, %descriptor.value.105
  %descriptor.extent.inside.114 = icmp ule i32 %descriptor.value.101, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %descriptor.value.103, %descriptor.value.101
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 5, 5
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.99, i32 %descriptor.value.101)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %entry.failure.0
helper.continue.125:
  %entry.output.size.i64.126 = zext i32 %descriptor.value.101 to i64
  %entry.output.total.i64.127 = add i64 0, %entry.output.size.i64.126
  %descriptor.element.128 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.92, i32 1
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.128, i32 0, i32 0
  %descriptor.value.130 = load i32, ptr %descriptor.field.129, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.128, i32 0, i32 1
  %descriptor.value.132 = load i32, ptr %descriptor.field.131, align 4
  %descriptor.field.133 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.128, i32 0, i32 2
  %descriptor.value.134 = load i32, ptr %descriptor.field.133, align 4
  %descriptor.field.135 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.128, i32 0, i32 3
  %descriptor.value.136 = load i32, ptr %descriptor.field.135, align 4
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.128, i32 0, i32 4
  %descriptor.value.138 = load i32, ptr %descriptor.field.137, align 4
  %entry.output.type.valid.139 = icmp eq i32 %descriptor.value.130, 4
  br i1 %entry.output.type.valid.139, label %entry.output.type.ok.140, label %entry.output.type.invalid.141
entry.output.type.invalid.141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.140:
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %stack.sub.146 = sub i32 %descriptor.value.138, %descriptor.value.132
  %descriptor.owner.inside.144 = icmp ule i32 %descriptor.value.138, %context.value.143
  %descriptor.offset.inside.145 = icmp ule i32 %descriptor.value.132, %descriptor.value.138
  %descriptor.extent.inside.147 = icmp ule i32 %descriptor.value.134, %stack.sub.146
  %descriptor.payload.inside.148 = icmp ule i32 %descriptor.value.136, %descriptor.value.134
  %descriptor.owner.offset.valid.149 = and i1 %descriptor.owner.inside.144, %descriptor.offset.inside.145
  %descriptor.range.inside.151 = and i1 %descriptor.owner.offset.valid.149, %descriptor.extent.inside.147
  %descriptor.range.valid.150 = and i1 %descriptor.range.inside.151, %descriptor.payload.inside.148
  %descriptor.type.valid.152 = icmp eq i32 4, 4
  %descriptor.valid.153 = and i1 %descriptor.range.valid.150, %descriptor.type.valid.152
  br i1 %descriptor.valid.153, label %descriptor.valid.154, label %descriptor.invalid.155
descriptor.invalid.155:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.154:
  %descriptor.initialized.status.156 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.132, i32 %descriptor.value.134)
  %helper.ok.157 = icmp eq i32 %descriptor.initialized.status.156, 0
  br i1 %helper.ok.157, label %helper.continue.158, label %entry.failure.0
helper.continue.158:
  %entry.output.size.i64.159 = zext i32 %descriptor.value.134 to i64
  %entry.output.total.i64.160 = add i64 %entry.output.total.i64.127, %entry.output.size.i64.159
  %entry.retained.capacity.i64.161 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.162 = icmp ule i64 %entry.output.total.i64.160, 4294967295
  %entry.retained.required.truncated.163 = trunc i64 %entry.output.total.i64.160 to i32
  %entry.retained.required.164 = select i1 %entry.retained.required.fits.u32.162, i32 %entry.retained.required.truncated.163, i32 4294967295
  %entry.retained.capacity.ok.165 = icmp ule i64 %entry.output.total.i64.160, %entry.retained.capacity.i64.161
  br i1 %entry.retained.capacity.ok.165, label %entry.retained.capacity.ready.166, label %entry.retained.capacity.failure.167
entry.retained.capacity.failure.167:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.164, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.166:
  %host.pointer.168 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.169 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.168, i32 %stack.sub.169, i32 %descriptor.value.99, i32 %descriptor.value.101, i32 5)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %entry.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 0, %descriptor.value.101
  %host.pointer.175 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.174
  %stack.sub.176 = sub i32 %retained.capacity, %stack.offset.174
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.175, i32 %stack.sub.176, i32 %descriptor.value.132, i32 %descriptor.value.134, i32 4)
  %context.field.177 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.178 = load i32, ptr %context.field.177, align 4
  %runtime.ok.179 = icmp eq i32 %context.value.178, 0
  br i1 %runtime.ok.179, label %runtime.continue.180, label %entry.failure.0
runtime.continue.180:
  %stack.offset.181 = add i32 %stack.offset.174, %descriptor.value.134
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %context.field.184 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.185 = load i32, ptr %context.field.184, align 4
  %stack.sub.186 = sub i32 0, %context.value.183
  %stack.sub.187 = sub i32 0, %context.value.185
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.186, i32 %stack.sub.187)
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %runtime.ok.190 = icmp eq i32 %context.value.189, 0
  br i1 %runtime.ok.190, label %runtime.continue.191, label %entry.failure.0
runtime.continue.191:
  br label %entry.return.status
entry.failure.0:
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %stack.offset.198 = add i32 %context.value.193, %context.value.195
  %stack.sub.199 = sub i32 0, %stack.offset.198
  %stack.sub.200 = sub i32 0, %context.value.195
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.199, i32 %stack.sub.200)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.197)
  br label %entry.return.status
entry.return.status:
  %context.field.201 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.202 = load i32, ptr %context.field.201, align 4
  ret i32 %context.value.202
}


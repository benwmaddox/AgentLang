define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %stack.sub.55 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.53 = icmp ule i32 %descriptor.value.23, %context.value.52
  %descriptor.offset.inside.54 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.56 = icmp ule i32 %descriptor.value.19, %stack.sub.55
  %descriptor.payload.inside.57 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.58 = and i1 %descriptor.owner.inside.53, %descriptor.offset.inside.54
  %descriptor.range.inside.60 = and i1 %descriptor.owner.offset.valid.58, %descriptor.extent.inside.56
  %descriptor.range.valid.59 = and i1 %descriptor.range.inside.60, %descriptor.payload.inside.57
  %descriptor.type.valid.61 = icmp eq i32 6, 6
  %descriptor.valid.62 = and i1 %descriptor.range.valid.59, %descriptor.type.valid.61
  br i1 %descriptor.valid.62, label %descriptor.valid.63, label %descriptor.invalid.64
descriptor.invalid.64:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.63:
  %descriptor.initialized.status.65 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.66 = icmp eq i32 %descriptor.initialized.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %frame.failure.0
helper.continue.67:
  %step.status.68 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.69 = icmp eq i32 %step.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %inline.target.depth.within.interpreter.limit.73 = icmp ule i32 %context.value.72, 65
  br i1 %inline.target.depth.within.interpreter.limit.73, label %inline.target.depth.ok.74, label %inline.target.depth.invalid.75
inline.target.depth.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.74:
  %stack.offset.76 = add i32 0, %descriptor.value.21
  %stack.offset.77 = add i32 0, %descriptor.value.19
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %stack.offset.80 = add i32 %context.value.79, %stack.offset.77
  %reserve.status.81 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.80, i32 5)
  %reserve.ok.82 = icmp eq i32 %reserve.status.81, 0
  br i1 %reserve.ok.82, label %reserve.continue.83, label %frame.failure.0
reserve.continue.83:
  %stack.offset.84 = add i32 %context.value.79, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.84, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 6, i32 6)
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %runtime.ok.87 = icmp eq i32 %context.value.86, 0
  br i1 %runtime.ok.87, label %runtime.continue.88, label %frame.failure.0
runtime.continue.88:
  %stack.offset.89 = add i32 0, %descriptor.value.19
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.79, i32 %stack.offset.77, i32 %stack.offset.76, i32 0, i32 0)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %stack.sub.98 = sub i32 %stack.offset.80, %context.value.79
  %descriptor.owner.inside.96 = icmp ule i32 %stack.offset.80, %context.value.95
  %descriptor.offset.inside.97 = icmp ule i32 %context.value.79, %stack.offset.80
  %descriptor.extent.inside.99 = icmp ule i32 %stack.offset.77, %stack.sub.98
  %descriptor.payload.inside.100 = icmp ule i32 %stack.offset.76, %stack.offset.77
  %descriptor.owner.offset.valid.101 = and i1 %descriptor.owner.inside.96, %descriptor.offset.inside.97
  %descriptor.range.inside.103 = and i1 %descriptor.owner.offset.valid.101, %descriptor.extent.inside.99
  %descriptor.range.valid.102 = and i1 %descriptor.range.inside.103, %descriptor.payload.inside.100
  %descriptor.type.valid.104 = icmp eq i32 5, 5
  %descriptor.valid.105 = and i1 %descriptor.range.valid.102, %descriptor.type.valid.104
  br i1 %descriptor.valid.105, label %descriptor.valid.106, label %descriptor.invalid.107
descriptor.invalid.107:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.106:
  %descriptor.initialized.status.108 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.79, i32 %stack.offset.77)
  %helper.ok.109 = icmp eq i32 %descriptor.initialized.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %descriptor.element.111 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 0
  store i32 5, ptr %descriptor.field.112, align 4
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 1
  store i32 %context.value.79, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 2
  store i32 %stack.offset.77, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 3
  store i32 %stack.offset.76, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 4
  store i32 %stack.offset.80, ptr %descriptor.field.116, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.79, i32 20, i32 %stack.offset.76, i32 %stack.offset.80, i32 %stack.offset.77)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %stack.offset.127 = add i32 %context.value.5, %context.value.7
  %stack.offset.128 = add i32 %context.value.122, %context.value.124
  %stack.sub.129 = sub i32 %stack.offset.127, %stack.offset.128
  %stack.sub.130 = sub i32 %context.value.7, %context.value.124
  %stack.sub.131 = sub i32 %context.value.126, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.129, i32 %stack.sub.130)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.131)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %field.location.162 = alloca %AlOwningFieldLocation, align 4
  %string.length.units.260 = alloca i32, align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %inline.target.depth.within.interpreter.limit.78 = icmp ule i32 %context.value.77, 65
  br i1 %inline.target.depth.within.interpreter.limit.78, label %inline.target.depth.ok.79, label %inline.target.depth.invalid.80
inline.target.depth.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.79:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %frame.failure.0
runtime.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.23, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.19, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 5, 5
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  %step.status.102 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.103 = icmp eq i32 %step.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %inline.target.depth.within.interpreter.limit.107 = icmp ule i32 %context.value.106, 65
  br i1 %inline.target.depth.within.interpreter.limit.107, label %inline.target.depth.ok.108, label %inline.target.depth.invalid.109
inline.target.depth.invalid.109:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.108:
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.offset.112 = add i32 %context.value.111, %descriptor.value.19
  %reserve.status.113 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.112, i32 10)
  %reserve.ok.114 = icmp eq i32 %reserve.status.113, 0
  br i1 %reserve.ok.114, label %reserve.continue.115, label %frame.failure.0
reserve.continue.115:
  call void @al_owning_duplicate(ptr %ctx, i32 %context.value.111, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 5)
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %runtime.ok.118 = icmp eq i32 %context.value.117, 0
  br i1 %runtime.ok.118, label %runtime.continue.119, label %frame.failure.0
runtime.continue.119:
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %stack.sub.124 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.122 = icmp ule i32 %descriptor.value.23, %context.value.121
  %descriptor.offset.inside.123 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.125 = icmp ule i32 %descriptor.value.19, %stack.sub.124
  %descriptor.payload.inside.126 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.127 = and i1 %descriptor.owner.inside.122, %descriptor.offset.inside.123
  %descriptor.range.inside.129 = and i1 %descriptor.owner.offset.valid.127, %descriptor.extent.inside.125
  %descriptor.range.valid.128 = and i1 %descriptor.range.inside.129, %descriptor.payload.inside.126
  %descriptor.type.valid.130 = icmp eq i32 5, 5
  %descriptor.valid.131 = and i1 %descriptor.range.valid.128, %descriptor.type.valid.130
  br i1 %descriptor.valid.131, label %descriptor.valid.132, label %descriptor.invalid.133
descriptor.invalid.133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.132:
  %descriptor.initialized.status.134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.135 = icmp eq i32 %descriptor.initialized.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %stack.sub.141 = sub i32 %stack.offset.112, %context.value.111
  %descriptor.owner.inside.139 = icmp ule i32 %stack.offset.112, %context.value.138
  %descriptor.offset.inside.140 = icmp ule i32 %context.value.111, %stack.offset.112
  %descriptor.extent.inside.142 = icmp ule i32 %descriptor.value.19, %stack.sub.141
  %descriptor.payload.inside.143 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.144 = and i1 %descriptor.owner.inside.139, %descriptor.offset.inside.140
  %descriptor.range.inside.146 = and i1 %descriptor.owner.offset.valid.144, %descriptor.extent.inside.142
  %descriptor.range.valid.145 = and i1 %descriptor.range.inside.146, %descriptor.payload.inside.143
  %descriptor.type.valid.147 = icmp eq i32 5, 5
  %descriptor.valid.148 = and i1 %descriptor.range.valid.145, %descriptor.type.valid.147
  br i1 %descriptor.valid.148, label %descriptor.valid.149, label %descriptor.invalid.150
descriptor.invalid.150:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.149:
  %descriptor.initialized.status.151 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.111, i32 %descriptor.value.19)
  %helper.ok.152 = icmp eq i32 %descriptor.initialized.status.151, 0
  br i1 %helper.ok.152, label %helper.continue.153, label %frame.failure.0
helper.continue.153:
  %step.status.154 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.155 = icmp eq i32 %step.status.154, 0
  br i1 %helper.ok.155, label %helper.continue.156, label %frame.failure.0
helper.continue.156:
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %inline.target.depth.within.interpreter.limit.159 = icmp ule i32 %context.value.158, 65
  br i1 %inline.target.depth.within.interpreter.limit.159, label %inline.target.depth.ok.160, label %inline.target.depth.invalid.161
inline.target.depth.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 12, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.160:
  %field.location.status.163 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %context.value.111, i32 %descriptor.value.19, i32 0, i32 13, ptr %field.location.162)
  %helper.ok.164 = icmp eq i32 %field.location.status.163, 0
  br i1 %helper.ok.164, label %helper.continue.165, label %frame.failure.0
helper.continue.165:
  %field.offset.pointer.166 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.162, i32 0, i32 0
  %field.offset.167 = load i32, ptr %field.offset.pointer.166, align 4
  %field.payload.pointer.168 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.162, i32 0, i32 1
  %field.payload.169 = load i32, ptr %field.payload.pointer.168, align 4
  %field.extent.pointer.170 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.162, i32 0, i32 2
  %field.extent.171 = load i32, ptr %field.extent.pointer.170, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 6, i32 %context.value.111, i32 %field.extent.171, i32 %field.payload.169, i32 %field.offset.167, i32 %field.extent.171)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %frame.failure.0
runtime.continue.175:
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %stack.sub.180 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.178 = icmp ule i32 %descriptor.value.23, %context.value.177
  %descriptor.offset.inside.179 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.181 = icmp ule i32 %descriptor.value.19, %stack.sub.180
  %descriptor.payload.inside.182 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.183 = and i1 %descriptor.owner.inside.178, %descriptor.offset.inside.179
  %descriptor.range.inside.185 = and i1 %descriptor.owner.offset.valid.183, %descriptor.extent.inside.181
  %descriptor.range.valid.184 = and i1 %descriptor.range.inside.185, %descriptor.payload.inside.182
  %descriptor.type.valid.186 = icmp eq i32 5, 5
  %descriptor.valid.187 = and i1 %descriptor.range.valid.184, %descriptor.type.valid.186
  br i1 %descriptor.valid.187, label %descriptor.valid.188, label %descriptor.invalid.189
descriptor.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.188:
  %descriptor.initialized.status.190 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.191 = icmp eq i32 %descriptor.initialized.status.190, 0
  br i1 %helper.ok.191, label %helper.continue.192, label %frame.failure.0
helper.continue.192:
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.197 = sub i32 %stack.offset.112, %field.offset.167
  %descriptor.owner.inside.195 = icmp ule i32 %stack.offset.112, %context.value.194
  %descriptor.offset.inside.196 = icmp ule i32 %field.offset.167, %stack.offset.112
  %descriptor.extent.inside.198 = icmp ule i32 %field.extent.171, %stack.sub.197
  %descriptor.payload.inside.199 = icmp ule i32 %field.payload.169, %field.extent.171
  %descriptor.owner.offset.valid.200 = and i1 %descriptor.owner.inside.195, %descriptor.offset.inside.196
  %descriptor.range.inside.202 = and i1 %descriptor.owner.offset.valid.200, %descriptor.extent.inside.198
  %descriptor.range.valid.201 = and i1 %descriptor.range.inside.202, %descriptor.payload.inside.199
  %descriptor.type.valid.203 = icmp eq i32 6, 6
  %descriptor.valid.204 = and i1 %descriptor.range.valid.201, %descriptor.type.valid.203
  br i1 %descriptor.valid.204, label %descriptor.valid.205, label %descriptor.invalid.206
descriptor.invalid.206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.205:
  %descriptor.initialized.status.207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.167, i32 %field.extent.171)
  %helper.ok.208 = icmp eq i32 %descriptor.initialized.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %step.status.210 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.211 = icmp eq i32 %step.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %inline.target.depth.within.interpreter.limit.215 = icmp ule i32 %context.value.214, 65
  br i1 %inline.target.depth.within.interpreter.limit.215, label %inline.target.depth.ok.216, label %inline.target.depth.invalid.217
inline.target.depth.invalid.217:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 15, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.216:
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.sub.222 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.220 = icmp ule i32 %descriptor.value.23, %context.value.219
  %descriptor.offset.inside.221 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.223 = icmp ule i32 %descriptor.value.19, %stack.sub.222
  %descriptor.payload.inside.224 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.225 = and i1 %descriptor.owner.inside.220, %descriptor.offset.inside.221
  %descriptor.range.inside.227 = and i1 %descriptor.owner.offset.valid.225, %descriptor.extent.inside.223
  %descriptor.range.valid.226 = and i1 %descriptor.range.inside.227, %descriptor.payload.inside.224
  %descriptor.type.valid.228 = icmp eq i32 5, 5
  %descriptor.valid.229 = and i1 %descriptor.range.valid.226, %descriptor.type.valid.228
  br i1 %descriptor.valid.229, label %descriptor.valid.230, label %descriptor.invalid.231
descriptor.invalid.231:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.230:
  %descriptor.initialized.status.232 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.233 = icmp eq i32 %descriptor.initialized.status.232, 0
  br i1 %helper.ok.233, label %helper.continue.234, label %frame.failure.0
helper.continue.234:
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %stack.sub.239 = sub i32 %stack.offset.112, %field.offset.167
  %descriptor.owner.inside.237 = icmp ule i32 %stack.offset.112, %context.value.236
  %descriptor.offset.inside.238 = icmp ule i32 %field.offset.167, %stack.offset.112
  %descriptor.extent.inside.240 = icmp ule i32 %field.extent.171, %stack.sub.239
  %descriptor.payload.inside.241 = icmp ule i32 %field.payload.169, %field.extent.171
  %descriptor.owner.offset.valid.242 = and i1 %descriptor.owner.inside.237, %descriptor.offset.inside.238
  %descriptor.range.inside.244 = and i1 %descriptor.owner.offset.valid.242, %descriptor.extent.inside.240
  %descriptor.range.valid.243 = and i1 %descriptor.range.inside.244, %descriptor.payload.inside.241
  %descriptor.type.valid.245 = icmp eq i32 7, 7
  %descriptor.valid.246 = and i1 %descriptor.range.valid.243, %descriptor.type.valid.245
  br i1 %descriptor.valid.246, label %descriptor.valid.247, label %descriptor.invalid.248
descriptor.invalid.248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.247:
  %descriptor.initialized.status.249 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.167, i32 %field.extent.171)
  %helper.ok.250 = icmp eq i32 %descriptor.initialized.status.249, 0
  br i1 %helper.ok.250, label %helper.continue.251, label %frame.failure.0
helper.continue.251:
  %step.status.252 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.253 = icmp eq i32 %step.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  %context.field.255 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.256 = load i32, ptr %context.field.255, align 4
  %inline.target.depth.within.interpreter.limit.257 = icmp ule i32 %context.value.256, 65
  br i1 %inline.target.depth.within.interpreter.limit.257, label %inline.target.depth.ok.258, label %inline.target.depth.invalid.259
inline.target.depth.invalid.259:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.258:
  %string.length.status.261 = call i32 @al_owning_string_length(ptr %ctx, i32 %field.offset.167, i32 %field.extent.171, i32 18, ptr %string.length.units.260)
  %helper.ok.262 = icmp eq i32 %string.length.status.261, 0
  br i1 %helper.ok.262, label %helper.continue.263, label %frame.failure.0
helper.continue.263:
  %string.length.value.264 = load i32, ptr %string.length.units.260, align 4
  %string.length.int.265 = zext i32 %string.length.value.264 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %field.offset.167, i32 %field.extent.171, i32 %field.payload.169, i32 0, i32 0)
  %context.field.266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.267 = load i32, ptr %context.field.266, align 4
  %runtime.ok.268 = icmp eq i32 %context.value.267, 0
  br i1 %runtime.ok.268, label %runtime.continue.269, label %frame.failure.0
runtime.continue.269:
  %context.field.270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.271 = load i32, ptr %context.field.270, align 4
  %stack.offset.272 = add i32 %context.value.271, 8
  %reserve.status.273 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.272, i32 19)
  %reserve.ok.274 = icmp eq i32 %reserve.status.273, 0
  br i1 %reserve.ok.274, label %reserve.continue.275, label %frame.failure.0
reserve.continue.275:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.271, i64 %string.length.int.265, i32 1)
  %context.field.276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.277 = load i32, ptr %context.field.276, align 4
  %runtime.ok.278 = icmp eq i32 %context.value.277, 0
  br i1 %runtime.ok.278, label %runtime.continue.279, label %frame.failure.0
runtime.continue.279:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %stack.offset.284 = add i32 %context.value.271, 8
  %context.field.285 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.286 = load i32, ptr %context.field.285, align 4
  %stack.sub.289 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.287 = icmp ule i32 %descriptor.value.23, %context.value.286
  %descriptor.offset.inside.288 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.290 = icmp ule i32 %descriptor.value.19, %stack.sub.289
  %descriptor.payload.inside.291 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.292 = and i1 %descriptor.owner.inside.287, %descriptor.offset.inside.288
  %descriptor.range.inside.294 = and i1 %descriptor.owner.offset.valid.292, %descriptor.extent.inside.290
  %descriptor.range.valid.293 = and i1 %descriptor.range.inside.294, %descriptor.payload.inside.291
  %descriptor.type.valid.295 = icmp eq i32 5, 5
  %descriptor.valid.296 = and i1 %descriptor.range.valid.293, %descriptor.type.valid.295
  br i1 %descriptor.valid.296, label %descriptor.valid.297, label %descriptor.invalid.298
descriptor.invalid.298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.297:
  %descriptor.initialized.status.299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.300 = icmp eq i32 %descriptor.initialized.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %context.field.302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.303 = load i32, ptr %context.field.302, align 4
  %stack.sub.306 = sub i32 %stack.offset.284, %context.value.271
  %descriptor.owner.inside.304 = icmp ule i32 %stack.offset.284, %context.value.303
  %descriptor.offset.inside.305 = icmp ule i32 %context.value.271, %stack.offset.284
  %descriptor.extent.inside.307 = icmp ule i32 8, %stack.sub.306
  %descriptor.payload.inside.308 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.309 = and i1 %descriptor.owner.inside.304, %descriptor.offset.inside.305
  %descriptor.range.inside.311 = and i1 %descriptor.owner.offset.valid.309, %descriptor.extent.inside.307
  %descriptor.range.valid.310 = and i1 %descriptor.range.inside.311, %descriptor.payload.inside.308
  %descriptor.type.valid.312 = icmp eq i32 1, 1
  %descriptor.valid.313 = and i1 %descriptor.range.valid.310, %descriptor.type.valid.312
  br i1 %descriptor.valid.313, label %descriptor.valid.314, label %descriptor.invalid.315
descriptor.invalid.315:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.314:
  %descriptor.initialized.status.316 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.271, i32 8)
  %helper.ok.317 = icmp eq i32 %descriptor.initialized.status.316, 0
  br i1 %helper.ok.317, label %helper.continue.318, label %frame.failure.0
helper.continue.318:
  %step.status.319 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.320 = icmp eq i32 %step.status.319, 0
  br i1 %helper.ok.320, label %helper.continue.321, label %frame.failure.0
helper.continue.321:
  %context.field.322 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.323 = load i32, ptr %context.field.322, align 4
  %inline.target.depth.within.interpreter.limit.324 = icmp ule i32 %context.value.323, 65
  br i1 %inline.target.depth.within.interpreter.limit.324, label %inline.target.depth.ok.325, label %inline.target.depth.invalid.326
inline.target.depth.invalid.326:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.325:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.271, i32 8, i32 8, i32 0, i32 0)
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %runtime.ok.329 = icmp eq i32 %context.value.328, 0
  br i1 %runtime.ok.329, label %runtime.continue.330, label %frame.failure.0
runtime.continue.330:
  %context.field.331 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.332 = load i32, ptr %context.field.331, align 4
  %stack.sub.335 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.333 = icmp ule i32 %descriptor.value.23, %context.value.332
  %descriptor.offset.inside.334 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.336 = icmp ule i32 %descriptor.value.19, %stack.sub.335
  %descriptor.payload.inside.337 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.338 = and i1 %descriptor.owner.inside.333, %descriptor.offset.inside.334
  %descriptor.range.inside.340 = and i1 %descriptor.owner.offset.valid.338, %descriptor.extent.inside.336
  %descriptor.range.valid.339 = and i1 %descriptor.range.inside.340, %descriptor.payload.inside.337
  %descriptor.type.valid.341 = icmp eq i32 5, 5
  %descriptor.valid.342 = and i1 %descriptor.range.valid.339, %descriptor.type.valid.341
  br i1 %descriptor.valid.342, label %descriptor.valid.343, label %descriptor.invalid.344
descriptor.invalid.344:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.343:
  %descriptor.initialized.status.345 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.346 = icmp eq i32 %descriptor.initialized.status.345, 0
  br i1 %helper.ok.346, label %helper.continue.347, label %frame.failure.0
helper.continue.347:
  %step.status.348 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.349 = icmp eq i32 %step.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %frame.failure.0
helper.continue.350:
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %stack.offset.353 = add i32 %context.value.352, 8
  %reserve.status.354 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.353, i32 23)
  %reserve.ok.355 = icmp eq i32 %reserve.status.354, 0
  br i1 %reserve.ok.355, label %reserve.continue.356, label %frame.failure.0
reserve.continue.356:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.352, i64 1, i32 1)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.361 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.362 = load i32, ptr %context.field.361, align 4
  %runtime.ok.363 = icmp eq i32 %context.value.362, 0
  br i1 %runtime.ok.363, label %runtime.continue.364, label %frame.failure.0
runtime.continue.364:
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %stack.sub.369 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.367 = icmp ule i32 %descriptor.value.23, %context.value.366
  %descriptor.offset.inside.368 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.370 = icmp ule i32 %descriptor.value.19, %stack.sub.369
  %descriptor.payload.inside.371 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.372 = and i1 %descriptor.owner.inside.367, %descriptor.offset.inside.368
  %descriptor.range.inside.374 = and i1 %descriptor.owner.offset.valid.372, %descriptor.extent.inside.370
  %descriptor.range.valid.373 = and i1 %descriptor.range.inside.374, %descriptor.payload.inside.371
  %descriptor.type.valid.375 = icmp eq i32 5, 5
  %descriptor.valid.376 = and i1 %descriptor.range.valid.373, %descriptor.type.valid.375
  br i1 %descriptor.valid.376, label %descriptor.valid.377, label %descriptor.invalid.378
descriptor.invalid.378:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.377:
  %descriptor.initialized.status.379 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.380 = icmp eq i32 %descriptor.initialized.status.379, 0
  br i1 %helper.ok.380, label %helper.continue.381, label %frame.failure.0
helper.continue.381:
  %context.field.382 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.383 = load i32, ptr %context.field.382, align 4
  %stack.sub.386 = sub i32 %stack.offset.353, %context.value.352
  %descriptor.owner.inside.384 = icmp ule i32 %stack.offset.353, %context.value.383
  %descriptor.offset.inside.385 = icmp ule i32 %context.value.352, %stack.offset.353
  %descriptor.extent.inside.387 = icmp ule i32 8, %stack.sub.386
  %descriptor.payload.inside.388 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.389 = and i1 %descriptor.owner.inside.384, %descriptor.offset.inside.385
  %descriptor.range.inside.391 = and i1 %descriptor.owner.offset.valid.389, %descriptor.extent.inside.387
  %descriptor.range.valid.390 = and i1 %descriptor.range.inside.391, %descriptor.payload.inside.388
  %descriptor.type.valid.392 = icmp eq i32 1, 1
  %descriptor.valid.393 = and i1 %descriptor.range.valid.390, %descriptor.type.valid.392
  br i1 %descriptor.valid.393, label %descriptor.valid.394, label %descriptor.invalid.395
descriptor.invalid.395:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.394:
  %descriptor.initialized.status.396 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.352, i32 8)
  %helper.ok.397 = icmp eq i32 %descriptor.initialized.status.396, 0
  br i1 %helper.ok.397, label %helper.continue.398, label %frame.failure.0
helper.continue.398:
  %step.status.399 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.400 = icmp eq i32 %step.status.399, 0
  br i1 %helper.ok.400, label %helper.continue.401, label %frame.failure.0
helper.continue.401:
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %inline.target.depth.within.interpreter.limit.404 = icmp ule i32 %context.value.403, 65
  br i1 %inline.target.depth.within.interpreter.limit.404, label %inline.target.depth.ok.405, label %inline.target.depth.invalid.406
inline.target.depth.invalid.406:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.405:
  %stack.offset.407 = add i32 0, 8
  %stack.offset.408 = add i32 0, 8
  %context.field.409 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.410 = load i32, ptr %context.field.409, align 4
  %stack.offset.411 = add i32 %context.value.410, %stack.offset.408
  %reserve.status.412 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.411, i32 26)
  %reserve.ok.413 = icmp eq i32 %reserve.status.412, 0
  br i1 %reserve.ok.413, label %reserve.continue.414, label %frame.failure.0
reserve.continue.414:
  %stack.offset.415 = add i32 %context.value.410, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.415, i32 %context.value.352, i32 8, i32 8, i32 1, i32 6)
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %runtime.ok.418 = icmp eq i32 %context.value.417, 0
  br i1 %runtime.ok.418, label %runtime.continue.419, label %frame.failure.0
runtime.continue.419:
  %stack.offset.420 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.410, i32 %stack.offset.408, i32 %stack.offset.407, i32 0, i32 0)
  %context.field.421 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.422 = load i32, ptr %context.field.421, align 4
  %runtime.ok.423 = icmp eq i32 %context.value.422, 0
  br i1 %runtime.ok.423, label %runtime.continue.424, label %frame.failure.0
runtime.continue.424:
  %context.field.425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.426 = load i32, ptr %context.field.425, align 4
  %stack.sub.429 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.427 = icmp ule i32 %descriptor.value.23, %context.value.426
  %descriptor.offset.inside.428 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.430 = icmp ule i32 %descriptor.value.19, %stack.sub.429
  %descriptor.payload.inside.431 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.432 = and i1 %descriptor.owner.inside.427, %descriptor.offset.inside.428
  %descriptor.range.inside.434 = and i1 %descriptor.owner.offset.valid.432, %descriptor.extent.inside.430
  %descriptor.range.valid.433 = and i1 %descriptor.range.inside.434, %descriptor.payload.inside.431
  %descriptor.type.valid.435 = icmp eq i32 5, 5
  %descriptor.valid.436 = and i1 %descriptor.range.valid.433, %descriptor.type.valid.435
  br i1 %descriptor.valid.436, label %descriptor.valid.437, label %descriptor.invalid.438
descriptor.invalid.438:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.437:
  %descriptor.initialized.status.439 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.440 = icmp eq i32 %descriptor.initialized.status.439, 0
  br i1 %helper.ok.440, label %helper.continue.441, label %frame.failure.0
helper.continue.441:
  %context.field.442 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.443 = load i32, ptr %context.field.442, align 4
  %stack.sub.446 = sub i32 %stack.offset.411, %context.value.410
  %descriptor.owner.inside.444 = icmp ule i32 %stack.offset.411, %context.value.443
  %descriptor.offset.inside.445 = icmp ule i32 %context.value.410, %stack.offset.411
  %descriptor.extent.inside.447 = icmp ule i32 %stack.offset.408, %stack.sub.446
  %descriptor.payload.inside.448 = icmp ule i32 %stack.offset.407, %stack.offset.408
  %descriptor.owner.offset.valid.449 = and i1 %descriptor.owner.inside.444, %descriptor.offset.inside.445
  %descriptor.range.inside.451 = and i1 %descriptor.owner.offset.valid.449, %descriptor.extent.inside.447
  %descriptor.range.valid.450 = and i1 %descriptor.range.inside.451, %descriptor.payload.inside.448
  %descriptor.type.valid.452 = icmp eq i32 4, 4
  %descriptor.valid.453 = and i1 %descriptor.range.valid.450, %descriptor.type.valid.452
  br i1 %descriptor.valid.453, label %descriptor.valid.454, label %descriptor.invalid.455
descriptor.invalid.455:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.454:
  %descriptor.initialized.status.456 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.410, i32 %stack.offset.408)
  %helper.ok.457 = icmp eq i32 %descriptor.initialized.status.456, 0
  br i1 %helper.ok.457, label %helper.continue.458, label %frame.failure.0
helper.continue.458:
  %descriptor.element.459 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.460 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.459, i32 0, i32 0
  store i32 5, ptr %descriptor.field.460, align 4
  %descriptor.field.461 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.459, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.461, align 4
  %descriptor.field.462 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.459, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.462, align 4
  %descriptor.field.463 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.459, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.463, align 4
  %descriptor.field.464 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.459, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.464, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.465 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.466 = load i32, ptr %context.field.465, align 4
  %runtime.ok.467 = icmp eq i32 %context.value.466, 0
  br i1 %runtime.ok.467, label %runtime.continue.468, label %frame.failure.0
runtime.continue.468:
  %descriptor.element.469 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.470 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.469, i32 0, i32 0
  store i32 4, ptr %descriptor.field.470, align 4
  %descriptor.field.471 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.469, i32 0, i32 1
  store i32 %context.value.410, ptr %descriptor.field.471, align 4
  %descriptor.field.472 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.469, i32 0, i32 2
  store i32 %stack.offset.408, ptr %descriptor.field.472, align 4
  %descriptor.field.473 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.469, i32 0, i32 3
  store i32 %stack.offset.407, ptr %descriptor.field.473, align 4
  %descriptor.field.474 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.469, i32 0, i32 4
  store i32 %stack.offset.411, ptr %descriptor.field.474, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.410, i32 20, i32 %stack.offset.407, i32 %stack.offset.411, i32 %stack.offset.408)
  %context.field.475 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.476 = load i32, ptr %context.field.475, align 4
  %runtime.ok.477 = icmp eq i32 %context.value.476, 0
  br i1 %runtime.ok.477, label %runtime.continue.478, label %frame.failure.0
runtime.continue.478:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.479 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.480 = load i32, ptr %context.field.479, align 4
  %context.field.481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.482 = load i32, ptr %context.field.481, align 4
  %context.field.483 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.484 = load i32, ptr %context.field.483, align 4
  %stack.offset.485 = add i32 %context.value.5, %context.value.7
  %stack.offset.486 = add i32 %context.value.480, %context.value.482
  %stack.sub.487 = sub i32 %stack.offset.485, %stack.offset.486
  %stack.sub.488 = sub i32 %context.value.7, %context.value.482
  %stack.sub.489 = sub i32 %context.value.484, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.487, i32 %stack.sub.488)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.489)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [8 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 10, i32 4, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 11, i32 6, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [8 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 8, ptr @al_owning_fields, i32 8 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 9
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 9, 9
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 9
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 9, 9
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %descriptor.element.103 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 3
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 0
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 1
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 2
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 3
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 4
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %argument.type.valid.114 = icmp eq i32 %descriptor.value.105, 10
  br i1 %argument.type.valid.114, label %argument.type.ok.115, label %frame.failure.0
argument.type.ok.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.113, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.109, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 10, 10
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %descriptor.element.133 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 0
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 1
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 2
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 3
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 4
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %argument.type.valid.144 = icmp eq i32 %descriptor.value.135, 10
  br i1 %argument.type.valid.144, label %argument.type.ok.145, label %frame.failure.0
argument.type.ok.145:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.150 = sub i32 %descriptor.value.143, %descriptor.value.137
  %descriptor.owner.inside.148 = icmp ule i32 %descriptor.value.143, %context.value.147
  %descriptor.offset.inside.149 = icmp ule i32 %descriptor.value.137, %descriptor.value.143
  %descriptor.extent.inside.151 = icmp ule i32 %descriptor.value.139, %stack.sub.150
  %descriptor.payload.inside.152 = icmp ule i32 %descriptor.value.141, %descriptor.value.139
  %descriptor.owner.offset.valid.153 = and i1 %descriptor.owner.inside.148, %descriptor.offset.inside.149
  %descriptor.range.inside.155 = and i1 %descriptor.owner.offset.valid.153, %descriptor.extent.inside.151
  %descriptor.range.valid.154 = and i1 %descriptor.range.inside.155, %descriptor.payload.inside.152
  %descriptor.type.valid.156 = icmp eq i32 10, 10
  %descriptor.valid.157 = and i1 %descriptor.range.valid.154, %descriptor.type.valid.156
  br i1 %descriptor.valid.157, label %descriptor.valid.158, label %descriptor.invalid.159
descriptor.invalid.159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.158:
  %descriptor.initialized.status.160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.137, i32 %descriptor.value.139)
  %helper.ok.161 = icmp eq i32 %descriptor.initialized.status.160, 0
  br i1 %helper.ok.161, label %helper.continue.162, label %frame.failure.0
helper.continue.162:
  %descriptor.element.163 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 5
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 0
  %descriptor.value.165 = load i32, ptr %descriptor.field.164, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 1
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 2
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 3
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 4
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %argument.type.valid.174 = icmp eq i32 %descriptor.value.165, 11
  br i1 %argument.type.valid.174, label %argument.type.ok.175, label %frame.failure.0
argument.type.ok.175:
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %stack.sub.180 = sub i32 %descriptor.value.173, %descriptor.value.167
  %descriptor.owner.inside.178 = icmp ule i32 %descriptor.value.173, %context.value.177
  %descriptor.offset.inside.179 = icmp ule i32 %descriptor.value.167, %descriptor.value.173
  %descriptor.extent.inside.181 = icmp ule i32 %descriptor.value.169, %stack.sub.180
  %descriptor.payload.inside.182 = icmp ule i32 %descriptor.value.171, %descriptor.value.169
  %descriptor.owner.offset.valid.183 = and i1 %descriptor.owner.inside.178, %descriptor.offset.inside.179
  %descriptor.range.inside.185 = and i1 %descriptor.owner.offset.valid.183, %descriptor.extent.inside.181
  %descriptor.range.valid.184 = and i1 %descriptor.range.inside.185, %descriptor.payload.inside.182
  %descriptor.type.valid.186 = icmp eq i32 11, 11
  %descriptor.valid.187 = and i1 %descriptor.range.valid.184, %descriptor.type.valid.186
  br i1 %descriptor.valid.187, label %descriptor.valid.188, label %descriptor.invalid.189
descriptor.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.188:
  %descriptor.initialized.status.190 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.167, i32 %descriptor.value.169)
  %helper.ok.191 = icmp eq i32 %descriptor.initialized.status.190, 0
  br i1 %helper.ok.191, label %helper.continue.192, label %frame.failure.0
helper.continue.192:
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.195 = sub i32 %context.value.194, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.195, i32 0, i32 0, i32 0)
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %runtime.ok.198 = icmp eq i32 %context.value.197, 0
  br i1 %runtime.ok.198, label %runtime.continue.199, label %frame.failure.0
runtime.continue.199:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %runtime.ok.202 = icmp eq i32 %context.value.201, 0
  br i1 %runtime.ok.202, label %runtime.continue.203, label %frame.failure.0
runtime.continue.203:
  %descriptor.element.204 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 0
  store i32 5, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.204, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.209, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %runtime.ok.212 = icmp eq i32 %context.value.211, 0
  br i1 %runtime.ok.212, label %runtime.continue.213, label %frame.failure.0
runtime.continue.213:
  %descriptor.element.214 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 0
  store i32 9, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.218, align 4
  %descriptor.field.219 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.219, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  %descriptor.element.224 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 2
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.224, i32 0, i32 0
  store i32 9, ptr %descriptor.field.225, align 4
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.224, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.224, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.224, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.228, align 4
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.224, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.229, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  %descriptor.element.234 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 3
  %descriptor.field.235 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 0
  store i32 10, ptr %descriptor.field.235, align 4
  %descriptor.field.236 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 1
  store i32 %descriptor.value.107, ptr %descriptor.field.236, align 4
  %descriptor.field.237 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 2
  store i32 %descriptor.value.109, ptr %descriptor.field.237, align 4
  %descriptor.field.238 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 3
  store i32 %descriptor.value.111, ptr %descriptor.field.238, align 4
  %descriptor.field.239 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 4
  store i32 %descriptor.value.113, ptr %descriptor.field.239, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.241 = load i32, ptr %context.field.240, align 4
  %runtime.ok.242 = icmp eq i32 %context.value.241, 0
  br i1 %runtime.ok.242, label %runtime.continue.243, label %frame.failure.0
runtime.continue.243:
  %descriptor.element.244 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 4
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 0
  store i32 10, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 1
  store i32 %descriptor.value.137, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 2
  store i32 %descriptor.value.139, ptr %descriptor.field.247, align 4
  %descriptor.field.248 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 3
  store i32 %descriptor.value.141, ptr %descriptor.field.248, align 4
  %descriptor.field.249 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 4
  store i32 %descriptor.value.143, ptr %descriptor.field.249, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.137, i32 20, i32 %descriptor.value.141, i32 %descriptor.value.143, i32 %descriptor.value.139)
  %context.field.250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.251 = load i32, ptr %context.field.250, align 4
  %runtime.ok.252 = icmp eq i32 %context.value.251, 0
  br i1 %runtime.ok.252, label %runtime.continue.253, label %frame.failure.0
runtime.continue.253:
  %descriptor.element.254 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 5
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 0
  store i32 11, ptr %descriptor.field.255, align 4
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 1
  store i32 %descriptor.value.167, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 2
  store i32 %descriptor.value.169, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 3
  store i32 %descriptor.value.171, ptr %descriptor.field.258, align 4
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 4
  store i32 %descriptor.value.173, ptr %descriptor.field.259, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.167, i32 20, i32 %descriptor.value.171, i32 %descriptor.value.173, i32 %descriptor.value.169)
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %runtime.ok.262 = icmp eq i32 %context.value.261, 0
  br i1 %runtime.ok.262, label %runtime.continue.263, label %frame.failure.0
runtime.continue.263:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %context.field.266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.267 = load i32, ptr %context.field.266, align 4
  %context.field.268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.269 = load i32, ptr %context.field.268, align 4
  %stack.offset.270 = add i32 %context.value.5, %context.value.7
  %stack.offset.271 = add i32 %context.value.265, %context.value.267
  %stack.sub.272 = sub i32 %stack.offset.270, %stack.offset.271
  %stack.sub.273 = sub i32 %context.value.7, %context.value.267
  %stack.sub.274 = sub i32 %context.value.269, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.272, i32 %stack.sub.273)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.274)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [6 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.payload.pointer.45 = alloca i32, align 4
  %input.measured.extent.pointer.46 = alloca i32, align 4
  %input.payload.pointer.65 = alloca i32, align 4
  %input.measured.extent.pointer.66 = alloca i32, align 4
  %input.payload.pointer.85 = alloca i32, align 4
  %input.measured.extent.pointer.86 = alloca i32, align 4
  %input.payload.pointer.105 = alloca i32, align 4
  %input.measured.extent.pointer.106 = alloca i32, align 4
  %input.payload.pointer.125 = alloca i32, align 4
  %input.measured.extent.pointer.126 = alloca i32, align 4
  %entry.output.descriptors.232 = alloca [6 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 6
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 6, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 6, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 1, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.extent.pointer.36 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.37 = load i32, ptr %input.extent.pointer.36, align 4
  %stack.sub.38 = sub i32 %input.bytes, %stack.offset.35
  %input.offset.within.bytes.39 = icmp ule i32 %stack.offset.35, %input.bytes
  %input.extent.within.bytes.40 = icmp ule i32 %input.host.extent.37, %stack.sub.38
  %input.slice.within.bytes.41 = and i1 %input.offset.within.bytes.39, %input.extent.within.bytes.40
  br i1 %input.slice.within.bytes.41, label %input.slice.ready.42, label %input.slice.invalid.43
input.slice.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.42:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.44, i32 %input.host.extent.37, i32 0, i32 2, ptr %input.payload.pointer.45, ptr %input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %input.measured.payload.50 = load i32, ptr %input.payload.pointer.45, align 4
  %input.measured.extent.51 = load i32, ptr %input.measured.extent.pointer.46, align 4
  %input.extent.exact.52 = icmp eq i32 %input.measured.extent.51, %input.host.extent.37
  br i1 %input.extent.exact.52, label %input.extent.exact.53, label %input.extent.invalid.54
input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 %input.measured.extent.51, i32 %input.host.extent.37)
  br label %entry.failure.0
input.extent.exact.53:
  %stack.offset.55 = add i32 %stack.offset.35, %input.host.extent.37
  %input.extent.pointer.56 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.57 = load i32, ptr %input.extent.pointer.56, align 4
  %stack.sub.58 = sub i32 %input.bytes, %stack.offset.55
  %input.offset.within.bytes.59 = icmp ule i32 %stack.offset.55, %input.bytes
  %input.extent.within.bytes.60 = icmp ule i32 %input.host.extent.57, %stack.sub.58
  %input.slice.within.bytes.61 = and i1 %input.offset.within.bytes.59, %input.extent.within.bytes.60
  br i1 %input.slice.within.bytes.61, label %input.slice.ready.62, label %input.slice.invalid.63
input.slice.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 3, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.62:
  %host.pointer.64 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.55
  %input.measure.status.67 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.64, i32 %input.host.extent.57, i32 0, i32 3, ptr %input.payload.pointer.65, ptr %input.measured.extent.pointer.66)
  %helper.ok.68 = icmp eq i32 %input.measure.status.67, 0
  br i1 %helper.ok.68, label %helper.continue.69, label %entry.failure.0
helper.continue.69:
  %input.measured.payload.70 = load i32, ptr %input.payload.pointer.65, align 4
  %input.measured.extent.71 = load i32, ptr %input.measured.extent.pointer.66, align 4
  %input.extent.exact.72 = icmp eq i32 %input.measured.extent.71, %input.host.extent.57
  br i1 %input.extent.exact.72, label %input.extent.exact.73, label %input.extent.invalid.74
input.extent.invalid.74:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 3, i32 %input.measured.extent.71, i32 %input.host.extent.57)
  br label %entry.failure.0
input.extent.exact.73:
  %stack.offset.75 = add i32 %stack.offset.55, %input.host.extent.57
  %input.extent.pointer.76 = getelementptr inbounds i32, ptr %input.extents, i32 3
  %input.host.extent.77 = load i32, ptr %input.extent.pointer.76, align 4
  %stack.sub.78 = sub i32 %input.bytes, %stack.offset.75
  %input.offset.within.bytes.79 = icmp ule i32 %stack.offset.75, %input.bytes
  %input.extent.within.bytes.80 = icmp ule i32 %input.host.extent.77, %stack.sub.78
  %input.slice.within.bytes.81 = and i1 %input.offset.within.bytes.79, %input.extent.within.bytes.80
  br i1 %input.slice.within.bytes.81, label %input.slice.ready.82, label %input.slice.invalid.83
input.slice.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.82:
  %host.pointer.84 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.75
  %input.measure.status.87 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 6, ptr %host.pointer.84, i32 %input.host.extent.77, i32 0, i32 4, ptr %input.payload.pointer.85, ptr %input.measured.extent.pointer.86)
  %helper.ok.88 = icmp eq i32 %input.measure.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %entry.failure.0
helper.continue.89:
  %input.measured.payload.90 = load i32, ptr %input.payload.pointer.85, align 4
  %input.measured.extent.91 = load i32, ptr %input.measured.extent.pointer.86, align 4
  %input.extent.exact.92 = icmp eq i32 %input.measured.extent.91, %input.host.extent.77
  br i1 %input.extent.exact.92, label %input.extent.exact.93, label %input.extent.invalid.94
input.extent.invalid.94:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 %input.measured.extent.91, i32 %input.host.extent.77)
  br label %entry.failure.0
input.extent.exact.93:
  %stack.offset.95 = add i32 %stack.offset.75, %input.host.extent.77
  %input.extent.pointer.96 = getelementptr inbounds i32, ptr %input.extents, i32 4
  %input.host.extent.97 = load i32, ptr %input.extent.pointer.96, align 4
  %stack.sub.98 = sub i32 %input.bytes, %stack.offset.95
  %input.offset.within.bytes.99 = icmp ule i32 %stack.offset.95, %input.bytes
  %input.extent.within.bytes.100 = icmp ule i32 %input.host.extent.97, %stack.sub.98
  %input.slice.within.bytes.101 = and i1 %input.offset.within.bytes.99, %input.extent.within.bytes.100
  br i1 %input.slice.within.bytes.101, label %input.slice.ready.102, label %input.slice.invalid.103
input.slice.invalid.103:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 5, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.102:
  %host.pointer.104 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.95
  %input.measure.status.107 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 6, ptr %host.pointer.104, i32 %input.host.extent.97, i32 0, i32 5, ptr %input.payload.pointer.105, ptr %input.measured.extent.pointer.106)
  %helper.ok.108 = icmp eq i32 %input.measure.status.107, 0
  br i1 %helper.ok.108, label %helper.continue.109, label %entry.failure.0
helper.continue.109:
  %input.measured.payload.110 = load i32, ptr %input.payload.pointer.105, align 4
  %input.measured.extent.111 = load i32, ptr %input.measured.extent.pointer.106, align 4
  %input.extent.exact.112 = icmp eq i32 %input.measured.extent.111, %input.host.extent.97
  br i1 %input.extent.exact.112, label %input.extent.exact.113, label %input.extent.invalid.114
input.extent.invalid.114:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 5, i32 %input.measured.extent.111, i32 %input.host.extent.97)
  br label %entry.failure.0
input.extent.exact.113:
  %stack.offset.115 = add i32 %stack.offset.95, %input.host.extent.97
  %input.extent.pointer.116 = getelementptr inbounds i32, ptr %input.extents, i32 5
  %input.host.extent.117 = load i32, ptr %input.extent.pointer.116, align 4
  %stack.sub.118 = sub i32 %input.bytes, %stack.offset.115
  %input.offset.within.bytes.119 = icmp ule i32 %stack.offset.115, %input.bytes
  %input.extent.within.bytes.120 = icmp ule i32 %input.host.extent.117, %stack.sub.118
  %input.slice.within.bytes.121 = and i1 %input.offset.within.bytes.119, %input.extent.within.bytes.120
  br i1 %input.slice.within.bytes.121, label %input.slice.ready.122, label %input.slice.invalid.123
input.slice.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.122:
  %host.pointer.124 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.115
  %input.measure.status.127 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 7, ptr %host.pointer.124, i32 %input.host.extent.117, i32 0, i32 6, ptr %input.payload.pointer.125, ptr %input.measured.extent.pointer.126)
  %helper.ok.128 = icmp eq i32 %input.measure.status.127, 0
  br i1 %helper.ok.128, label %helper.continue.129, label %entry.failure.0
helper.continue.129:
  %input.measured.payload.130 = load i32, ptr %input.payload.pointer.125, align 4
  %input.measured.extent.131 = load i32, ptr %input.measured.extent.pointer.126, align 4
  %input.extent.exact.132 = icmp eq i32 %input.measured.extent.131, %input.host.extent.117
  br i1 %input.extent.exact.132, label %input.extent.exact.133, label %input.extent.invalid.134
input.extent.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 %input.measured.extent.131, i32 %input.host.extent.117)
  br label %entry.failure.0
input.extent.exact.133:
  %stack.offset.135 = add i32 %stack.offset.115, %input.host.extent.117
  %input.total.exact.136 = icmp eq i32 %stack.offset.135, %input.bytes
  br i1 %input.total.exact.136, label %input.valid.137, label %input.invalid.138
input.invalid.138:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.135, i32 %input.bytes)
  br label %entry.failure.0
input.valid.137:
  %reserve.status.139 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.135, i32 7)
  %reserve.ok.140 = icmp eq i32 %reserve.status.139, 0
  br i1 %reserve.ok.140, label %reserve.continue.141, label %entry.failure.0
reserve.continue.141:
  %host.pointer.142 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.143 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.142, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 5, i32 8)
  %helper.ok.144 = icmp eq i32 %input.copy.status.143, 0
  br i1 %helper.ok.144, label %helper.continue.145, label %entry.failure.0
helper.continue.145:
  %stack.offset.146 = add i32 0, %input.host.extent.17
  %descriptor.element.147 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.147, i32 0, i32 0
  store i32 5, ptr %descriptor.field.148, align 4
  %descriptor.field.149 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.147, i32 0, i32 1
  store i32 0, ptr %descriptor.field.149, align 4
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.147, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.150, align 4
  %descriptor.field.151 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.147, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.151, align 4
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.147, i32 0, i32 4
  store i32 %stack.offset.146, ptr %descriptor.field.152, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.146, i32 %input.host.extent.17)
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %runtime.ok.155 = icmp eq i32 %context.value.154, 0
  br i1 %runtime.ok.155, label %runtime.continue.156, label %entry.failure.0
runtime.continue.156:
  %host.pointer.157 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.copy.status.158 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.35, ptr %host.pointer.157, i32 %input.host.extent.37, i32 0, i32 %input.measured.payload.50, i32 %input.host.extent.37, i32 9, i32 9)
  %helper.ok.159 = icmp eq i32 %input.copy.status.158, 0
  br i1 %helper.ok.159, label %helper.continue.160, label %entry.failure.0
helper.continue.160:
  %stack.offset.161 = add i32 %stack.offset.35, %input.host.extent.37
  %descriptor.element.162 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 1
  %descriptor.field.163 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 0
  store i32 9, ptr %descriptor.field.163, align 4
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 1
  store i32 %stack.offset.35, ptr %descriptor.field.164, align 4
  %descriptor.field.165 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 2
  store i32 %input.host.extent.37, ptr %descriptor.field.165, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 3
  store i32 %input.measured.payload.50, ptr %descriptor.field.166, align 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 4
  store i32 %stack.offset.161, ptr %descriptor.field.167, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %stack.offset.35, i32 20, i32 %input.measured.payload.50, i32 %stack.offset.161, i32 %input.host.extent.37)
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %runtime.ok.170 = icmp eq i32 %context.value.169, 0
  br i1 %runtime.ok.170, label %runtime.continue.171, label %entry.failure.0
runtime.continue.171:
  %host.pointer.172 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.55
  %input.copy.status.173 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.55, ptr %host.pointer.172, i32 %input.host.extent.57, i32 0, i32 %input.measured.payload.70, i32 %input.host.extent.57, i32 9, i32 10)
  %helper.ok.174 = icmp eq i32 %input.copy.status.173, 0
  br i1 %helper.ok.174, label %helper.continue.175, label %entry.failure.0
helper.continue.175:
  %stack.offset.176 = add i32 %stack.offset.55, %input.host.extent.57
  %descriptor.element.177 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 2
  %descriptor.field.178 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.177, i32 0, i32 0
  store i32 9, ptr %descriptor.field.178, align 4
  %descriptor.field.179 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.177, i32 0, i32 1
  store i32 %stack.offset.55, ptr %descriptor.field.179, align 4
  %descriptor.field.180 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.177, i32 0, i32 2
  store i32 %input.host.extent.57, ptr %descriptor.field.180, align 4
  %descriptor.field.181 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.177, i32 0, i32 3
  store i32 %input.measured.payload.70, ptr %descriptor.field.181, align 4
  %descriptor.field.182 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.177, i32 0, i32 4
  store i32 %stack.offset.176, ptr %descriptor.field.182, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %stack.offset.55, i32 20, i32 %input.measured.payload.70, i32 %stack.offset.176, i32 %input.host.extent.57)
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %runtime.ok.185 = icmp eq i32 %context.value.184, 0
  br i1 %runtime.ok.185, label %runtime.continue.186, label %entry.failure.0
runtime.continue.186:
  %host.pointer.187 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.75
  %input.copy.status.188 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.75, ptr %host.pointer.187, i32 %input.host.extent.77, i32 0, i32 %input.measured.payload.90, i32 %input.host.extent.77, i32 10, i32 11)
  %helper.ok.189 = icmp eq i32 %input.copy.status.188, 0
  br i1 %helper.ok.189, label %helper.continue.190, label %entry.failure.0
helper.continue.190:
  %stack.offset.191 = add i32 %stack.offset.75, %input.host.extent.77
  %descriptor.element.192 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 3
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 0
  store i32 10, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 1
  store i32 %stack.offset.75, ptr %descriptor.field.194, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 2
  store i32 %input.host.extent.77, ptr %descriptor.field.195, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 3
  store i32 %input.measured.payload.90, ptr %descriptor.field.196, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 4
  store i32 %stack.offset.191, ptr %descriptor.field.197, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %stack.offset.75, i32 20, i32 %input.measured.payload.90, i32 %stack.offset.191, i32 %input.host.extent.77)
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %runtime.ok.200 = icmp eq i32 %context.value.199, 0
  br i1 %runtime.ok.200, label %runtime.continue.201, label %entry.failure.0
runtime.continue.201:
  %host.pointer.202 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.95
  %input.copy.status.203 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.95, ptr %host.pointer.202, i32 %input.host.extent.97, i32 0, i32 %input.measured.payload.110, i32 %input.host.extent.97, i32 10, i32 12)
  %helper.ok.204 = icmp eq i32 %input.copy.status.203, 0
  br i1 %helper.ok.204, label %helper.continue.205, label %entry.failure.0
helper.continue.205:
  %stack.offset.206 = add i32 %stack.offset.95, %input.host.extent.97
  %descriptor.element.207 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 0
  store i32 10, ptr %descriptor.field.208, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 1
  store i32 %stack.offset.95, ptr %descriptor.field.209, align 4
  %descriptor.field.210 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 2
  store i32 %input.host.extent.97, ptr %descriptor.field.210, align 4
  %descriptor.field.211 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 3
  store i32 %input.measured.payload.110, ptr %descriptor.field.211, align 4
  %descriptor.field.212 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.207, i32 0, i32 4
  store i32 %stack.offset.206, ptr %descriptor.field.212, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %stack.offset.95, i32 20, i32 %input.measured.payload.110, i32 %stack.offset.206, i32 %input.host.extent.97)
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %runtime.ok.215 = icmp eq i32 %context.value.214, 0
  br i1 %runtime.ok.215, label %runtime.continue.216, label %entry.failure.0
runtime.continue.216:
  %host.pointer.217 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.115
  %input.copy.status.218 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.115, ptr %host.pointer.217, i32 %input.host.extent.117, i32 0, i32 %input.measured.payload.130, i32 %input.host.extent.117, i32 11, i32 13)
  %helper.ok.219 = icmp eq i32 %input.copy.status.218, 0
  br i1 %helper.ok.219, label %helper.continue.220, label %entry.failure.0
helper.continue.220:
  %stack.offset.221 = add i32 %stack.offset.115, %input.host.extent.117
  %descriptor.element.222 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 5
  %descriptor.field.223 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.222, i32 0, i32 0
  store i32 11, ptr %descriptor.field.223, align 4
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.222, i32 0, i32 1
  store i32 %stack.offset.115, ptr %descriptor.field.224, align 4
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.222, i32 0, i32 2
  store i32 %input.host.extent.117, ptr %descriptor.field.225, align 4
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.222, i32 0, i32 3
  store i32 %input.measured.payload.130, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.222, i32 0, i32 4
  store i32 %stack.offset.221, ptr %descriptor.field.227, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %stack.offset.115, i32 20, i32 %input.measured.payload.130, i32 %stack.offset.221, i32 %input.host.extent.117)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %entry.failure.0
runtime.continue.231:
  %entry.body.status.233 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.232, i32 14)
  %entry.body.ok.234 = icmp eq i32 %entry.body.status.233, 0
  br i1 %entry.body.ok.234, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.235 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 0
  %descriptor.field.236 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.235, i32 0, i32 0
  %descriptor.value.237 = load i32, ptr %descriptor.field.236, align 4
  %descriptor.field.238 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.235, i32 0, i32 1
  %descriptor.value.239 = load i32, ptr %descriptor.field.238, align 4
  %descriptor.field.240 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.235, i32 0, i32 2
  %descriptor.value.241 = load i32, ptr %descriptor.field.240, align 4
  %descriptor.field.242 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.235, i32 0, i32 3
  %descriptor.value.243 = load i32, ptr %descriptor.field.242, align 4
  %descriptor.field.244 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.235, i32 0, i32 4
  %descriptor.value.245 = load i32, ptr %descriptor.field.244, align 4
  %entry.output.type.valid.246 = icmp eq i32 %descriptor.value.237, 5
  br i1 %entry.output.type.valid.246, label %entry.output.type.ok.247, label %entry.output.type.invalid.248
entry.output.type.invalid.248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.247:
  %context.field.249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.250 = load i32, ptr %context.field.249, align 4
  %stack.sub.253 = sub i32 %descriptor.value.245, %descriptor.value.239
  %descriptor.owner.inside.251 = icmp ule i32 %descriptor.value.245, %context.value.250
  %descriptor.offset.inside.252 = icmp ule i32 %descriptor.value.239, %descriptor.value.245
  %descriptor.extent.inside.254 = icmp ule i32 %descriptor.value.241, %stack.sub.253
  %descriptor.payload.inside.255 = icmp ule i32 %descriptor.value.243, %descriptor.value.241
  %descriptor.owner.offset.valid.256 = and i1 %descriptor.owner.inside.251, %descriptor.offset.inside.252
  %descriptor.range.inside.258 = and i1 %descriptor.owner.offset.valid.256, %descriptor.extent.inside.254
  %descriptor.range.valid.257 = and i1 %descriptor.range.inside.258, %descriptor.payload.inside.255
  %descriptor.type.valid.259 = icmp eq i32 5, 5
  %descriptor.valid.260 = and i1 %descriptor.range.valid.257, %descriptor.type.valid.259
  br i1 %descriptor.valid.260, label %descriptor.valid.261, label %descriptor.invalid.262
descriptor.invalid.262:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.261:
  %descriptor.initialized.status.263 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.239, i32 %descriptor.value.241)
  %helper.ok.264 = icmp eq i32 %descriptor.initialized.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %entry.failure.0
helper.continue.265:
  %entry.output.size.i64.266 = zext i32 %descriptor.value.241 to i64
  %entry.output.total.i64.267 = add i64 0, %entry.output.size.i64.266
  %descriptor.element.268 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 1
  %descriptor.field.269 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 0
  %descriptor.value.270 = load i32, ptr %descriptor.field.269, align 4
  %descriptor.field.271 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 1
  %descriptor.value.272 = load i32, ptr %descriptor.field.271, align 4
  %descriptor.field.273 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 2
  %descriptor.value.274 = load i32, ptr %descriptor.field.273, align 4
  %descriptor.field.275 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 3
  %descriptor.value.276 = load i32, ptr %descriptor.field.275, align 4
  %descriptor.field.277 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 4
  %descriptor.value.278 = load i32, ptr %descriptor.field.277, align 4
  %entry.output.type.valid.279 = icmp eq i32 %descriptor.value.270, 9
  br i1 %entry.output.type.valid.279, label %entry.output.type.ok.280, label %entry.output.type.invalid.281
entry.output.type.invalid.281:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.280:
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %stack.sub.286 = sub i32 %descriptor.value.278, %descriptor.value.272
  %descriptor.owner.inside.284 = icmp ule i32 %descriptor.value.278, %context.value.283
  %descriptor.offset.inside.285 = icmp ule i32 %descriptor.value.272, %descriptor.value.278
  %descriptor.extent.inside.287 = icmp ule i32 %descriptor.value.274, %stack.sub.286
  %descriptor.payload.inside.288 = icmp ule i32 %descriptor.value.276, %descriptor.value.274
  %descriptor.owner.offset.valid.289 = and i1 %descriptor.owner.inside.284, %descriptor.offset.inside.285
  %descriptor.range.inside.291 = and i1 %descriptor.owner.offset.valid.289, %descriptor.extent.inside.287
  %descriptor.range.valid.290 = and i1 %descriptor.range.inside.291, %descriptor.payload.inside.288
  %descriptor.type.valid.292 = icmp eq i32 9, 9
  %descriptor.valid.293 = and i1 %descriptor.range.valid.290, %descriptor.type.valid.292
  br i1 %descriptor.valid.293, label %descriptor.valid.294, label %descriptor.invalid.295
descriptor.invalid.295:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.294:
  %descriptor.initialized.status.296 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.272, i32 %descriptor.value.274)
  %helper.ok.297 = icmp eq i32 %descriptor.initialized.status.296, 0
  br i1 %helper.ok.297, label %helper.continue.298, label %entry.failure.0
helper.continue.298:
  %entry.output.size.i64.299 = zext i32 %descriptor.value.274 to i64
  %entry.output.total.i64.300 = add i64 %entry.output.total.i64.267, %entry.output.size.i64.299
  %descriptor.element.301 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 2
  %descriptor.field.302 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.301, i32 0, i32 0
  %descriptor.value.303 = load i32, ptr %descriptor.field.302, align 4
  %descriptor.field.304 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.301, i32 0, i32 1
  %descriptor.value.305 = load i32, ptr %descriptor.field.304, align 4
  %descriptor.field.306 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.301, i32 0, i32 2
  %descriptor.value.307 = load i32, ptr %descriptor.field.306, align 4
  %descriptor.field.308 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.301, i32 0, i32 3
  %descriptor.value.309 = load i32, ptr %descriptor.field.308, align 4
  %descriptor.field.310 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.301, i32 0, i32 4
  %descriptor.value.311 = load i32, ptr %descriptor.field.310, align 4
  %entry.output.type.valid.312 = icmp eq i32 %descriptor.value.303, 9
  br i1 %entry.output.type.valid.312, label %entry.output.type.ok.313, label %entry.output.type.invalid.314
entry.output.type.invalid.314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.313:
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.316 = load i32, ptr %context.field.315, align 4
  %stack.sub.319 = sub i32 %descriptor.value.311, %descriptor.value.305
  %descriptor.owner.inside.317 = icmp ule i32 %descriptor.value.311, %context.value.316
  %descriptor.offset.inside.318 = icmp ule i32 %descriptor.value.305, %descriptor.value.311
  %descriptor.extent.inside.320 = icmp ule i32 %descriptor.value.307, %stack.sub.319
  %descriptor.payload.inside.321 = icmp ule i32 %descriptor.value.309, %descriptor.value.307
  %descriptor.owner.offset.valid.322 = and i1 %descriptor.owner.inside.317, %descriptor.offset.inside.318
  %descriptor.range.inside.324 = and i1 %descriptor.owner.offset.valid.322, %descriptor.extent.inside.320
  %descriptor.range.valid.323 = and i1 %descriptor.range.inside.324, %descriptor.payload.inside.321
  %descriptor.type.valid.325 = icmp eq i32 9, 9
  %descriptor.valid.326 = and i1 %descriptor.range.valid.323, %descriptor.type.valid.325
  br i1 %descriptor.valid.326, label %descriptor.valid.327, label %descriptor.invalid.328
descriptor.invalid.328:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.327:
  %descriptor.initialized.status.329 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.305, i32 %descriptor.value.307)
  %helper.ok.330 = icmp eq i32 %descriptor.initialized.status.329, 0
  br i1 %helper.ok.330, label %helper.continue.331, label %entry.failure.0
helper.continue.331:
  %entry.output.size.i64.332 = zext i32 %descriptor.value.307 to i64
  %entry.output.total.i64.333 = add i64 %entry.output.total.i64.300, %entry.output.size.i64.332
  %descriptor.element.334 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 3
  %descriptor.field.335 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.334, i32 0, i32 0
  %descriptor.value.336 = load i32, ptr %descriptor.field.335, align 4
  %descriptor.field.337 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.334, i32 0, i32 1
  %descriptor.value.338 = load i32, ptr %descriptor.field.337, align 4
  %descriptor.field.339 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.334, i32 0, i32 2
  %descriptor.value.340 = load i32, ptr %descriptor.field.339, align 4
  %descriptor.field.341 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.334, i32 0, i32 3
  %descriptor.value.342 = load i32, ptr %descriptor.field.341, align 4
  %descriptor.field.343 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.334, i32 0, i32 4
  %descriptor.value.344 = load i32, ptr %descriptor.field.343, align 4
  %entry.output.type.valid.345 = icmp eq i32 %descriptor.value.336, 10
  br i1 %entry.output.type.valid.345, label %entry.output.type.ok.346, label %entry.output.type.invalid.347
entry.output.type.invalid.347:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.346:
  %context.field.348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.349 = load i32, ptr %context.field.348, align 4
  %stack.sub.352 = sub i32 %descriptor.value.344, %descriptor.value.338
  %descriptor.owner.inside.350 = icmp ule i32 %descriptor.value.344, %context.value.349
  %descriptor.offset.inside.351 = icmp ule i32 %descriptor.value.338, %descriptor.value.344
  %descriptor.extent.inside.353 = icmp ule i32 %descriptor.value.340, %stack.sub.352
  %descriptor.payload.inside.354 = icmp ule i32 %descriptor.value.342, %descriptor.value.340
  %descriptor.owner.offset.valid.355 = and i1 %descriptor.owner.inside.350, %descriptor.offset.inside.351
  %descriptor.range.inside.357 = and i1 %descriptor.owner.offset.valid.355, %descriptor.extent.inside.353
  %descriptor.range.valid.356 = and i1 %descriptor.range.inside.357, %descriptor.payload.inside.354
  %descriptor.type.valid.358 = icmp eq i32 10, 10
  %descriptor.valid.359 = and i1 %descriptor.range.valid.356, %descriptor.type.valid.358
  br i1 %descriptor.valid.359, label %descriptor.valid.360, label %descriptor.invalid.361
descriptor.invalid.361:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.360:
  %descriptor.initialized.status.362 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.338, i32 %descriptor.value.340)
  %helper.ok.363 = icmp eq i32 %descriptor.initialized.status.362, 0
  br i1 %helper.ok.363, label %helper.continue.364, label %entry.failure.0
helper.continue.364:
  %entry.output.size.i64.365 = zext i32 %descriptor.value.340 to i64
  %entry.output.total.i64.366 = add i64 %entry.output.total.i64.333, %entry.output.size.i64.365
  %descriptor.element.367 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 4
  %descriptor.field.368 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.367, i32 0, i32 0
  %descriptor.value.369 = load i32, ptr %descriptor.field.368, align 4
  %descriptor.field.370 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.367, i32 0, i32 1
  %descriptor.value.371 = load i32, ptr %descriptor.field.370, align 4
  %descriptor.field.372 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.367, i32 0, i32 2
  %descriptor.value.373 = load i32, ptr %descriptor.field.372, align 4
  %descriptor.field.374 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.367, i32 0, i32 3
  %descriptor.value.375 = load i32, ptr %descriptor.field.374, align 4
  %descriptor.field.376 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.367, i32 0, i32 4
  %descriptor.value.377 = load i32, ptr %descriptor.field.376, align 4
  %entry.output.type.valid.378 = icmp eq i32 %descriptor.value.369, 10
  br i1 %entry.output.type.valid.378, label %entry.output.type.ok.379, label %entry.output.type.invalid.380
entry.output.type.invalid.380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.379:
  %context.field.381 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.382 = load i32, ptr %context.field.381, align 4
  %stack.sub.385 = sub i32 %descriptor.value.377, %descriptor.value.371
  %descriptor.owner.inside.383 = icmp ule i32 %descriptor.value.377, %context.value.382
  %descriptor.offset.inside.384 = icmp ule i32 %descriptor.value.371, %descriptor.value.377
  %descriptor.extent.inside.386 = icmp ule i32 %descriptor.value.373, %stack.sub.385
  %descriptor.payload.inside.387 = icmp ule i32 %descriptor.value.375, %descriptor.value.373
  %descriptor.owner.offset.valid.388 = and i1 %descriptor.owner.inside.383, %descriptor.offset.inside.384
  %descriptor.range.inside.390 = and i1 %descriptor.owner.offset.valid.388, %descriptor.extent.inside.386
  %descriptor.range.valid.389 = and i1 %descriptor.range.inside.390, %descriptor.payload.inside.387
  %descriptor.type.valid.391 = icmp eq i32 10, 10
  %descriptor.valid.392 = and i1 %descriptor.range.valid.389, %descriptor.type.valid.391
  br i1 %descriptor.valid.392, label %descriptor.valid.393, label %descriptor.invalid.394
descriptor.invalid.394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.393:
  %descriptor.initialized.status.395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.371, i32 %descriptor.value.373)
  %helper.ok.396 = icmp eq i32 %descriptor.initialized.status.395, 0
  br i1 %helper.ok.396, label %helper.continue.397, label %entry.failure.0
helper.continue.397:
  %entry.output.size.i64.398 = zext i32 %descriptor.value.373 to i64
  %entry.output.total.i64.399 = add i64 %entry.output.total.i64.366, %entry.output.size.i64.398
  %descriptor.element.400 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.232, i32 5
  %descriptor.field.401 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.400, i32 0, i32 0
  %descriptor.value.402 = load i32, ptr %descriptor.field.401, align 4
  %descriptor.field.403 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.400, i32 0, i32 1
  %descriptor.value.404 = load i32, ptr %descriptor.field.403, align 4
  %descriptor.field.405 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.400, i32 0, i32 2
  %descriptor.value.406 = load i32, ptr %descriptor.field.405, align 4
  %descriptor.field.407 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.400, i32 0, i32 3
  %descriptor.value.408 = load i32, ptr %descriptor.field.407, align 4
  %descriptor.field.409 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.400, i32 0, i32 4
  %descriptor.value.410 = load i32, ptr %descriptor.field.409, align 4
  %entry.output.type.valid.411 = icmp eq i32 %descriptor.value.402, 11
  br i1 %entry.output.type.valid.411, label %entry.output.type.ok.412, label %entry.output.type.invalid.413
entry.output.type.invalid.413:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.412:
  %context.field.414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.415 = load i32, ptr %context.field.414, align 4
  %stack.sub.418 = sub i32 %descriptor.value.410, %descriptor.value.404
  %descriptor.owner.inside.416 = icmp ule i32 %descriptor.value.410, %context.value.415
  %descriptor.offset.inside.417 = icmp ule i32 %descriptor.value.404, %descriptor.value.410
  %descriptor.extent.inside.419 = icmp ule i32 %descriptor.value.406, %stack.sub.418
  %descriptor.payload.inside.420 = icmp ule i32 %descriptor.value.408, %descriptor.value.406
  %descriptor.owner.offset.valid.421 = and i1 %descriptor.owner.inside.416, %descriptor.offset.inside.417
  %descriptor.range.inside.423 = and i1 %descriptor.owner.offset.valid.421, %descriptor.extent.inside.419
  %descriptor.range.valid.422 = and i1 %descriptor.range.inside.423, %descriptor.payload.inside.420
  %descriptor.type.valid.424 = icmp eq i32 11, 11
  %descriptor.valid.425 = and i1 %descriptor.range.valid.422, %descriptor.type.valid.424
  br i1 %descriptor.valid.425, label %descriptor.valid.426, label %descriptor.invalid.427
descriptor.invalid.427:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.426:
  %descriptor.initialized.status.428 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.404, i32 %descriptor.value.406)
  %helper.ok.429 = icmp eq i32 %descriptor.initialized.status.428, 0
  br i1 %helper.ok.429, label %helper.continue.430, label %entry.failure.0
helper.continue.430:
  %entry.output.size.i64.431 = zext i32 %descriptor.value.406 to i64
  %entry.output.total.i64.432 = add i64 %entry.output.total.i64.399, %entry.output.size.i64.431
  %entry.retained.capacity.i64.433 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.434 = icmp ule i64 %entry.output.total.i64.432, 4294967295
  %entry.retained.required.truncated.435 = trunc i64 %entry.output.total.i64.432 to i32
  %entry.retained.required.436 = select i1 %entry.retained.required.fits.u32.434, i32 %entry.retained.required.truncated.435, i32 4294967295
  %entry.retained.capacity.ok.437 = icmp ule i64 %entry.output.total.i64.432, %entry.retained.capacity.i64.433
  br i1 %entry.retained.capacity.ok.437, label %entry.retained.capacity.ready.438, label %entry.retained.capacity.failure.439
entry.retained.capacity.failure.439:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.436, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.438:
  %host.pointer.440 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.441 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.440, i32 %stack.sub.441, i32 %descriptor.value.239, i32 %descriptor.value.241, i32 5)
  %context.field.442 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.443 = load i32, ptr %context.field.442, align 4
  %runtime.ok.444 = icmp eq i32 %context.value.443, 0
  br i1 %runtime.ok.444, label %runtime.continue.445, label %entry.failure.0
runtime.continue.445:
  %stack.offset.446 = add i32 0, %descriptor.value.241
  %host.pointer.447 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.446
  %stack.sub.448 = sub i32 %retained.capacity, %stack.offset.446
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.447, i32 %stack.sub.448, i32 %descriptor.value.272, i32 %descriptor.value.274, i32 9)
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %runtime.ok.451 = icmp eq i32 %context.value.450, 0
  br i1 %runtime.ok.451, label %runtime.continue.452, label %entry.failure.0
runtime.continue.452:
  %stack.offset.453 = add i32 %stack.offset.446, %descriptor.value.274
  %host.pointer.454 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.453
  %stack.sub.455 = sub i32 %retained.capacity, %stack.offset.453
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.454, i32 %stack.sub.455, i32 %descriptor.value.305, i32 %descriptor.value.307, i32 9)
  %context.field.456 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.457 = load i32, ptr %context.field.456, align 4
  %runtime.ok.458 = icmp eq i32 %context.value.457, 0
  br i1 %runtime.ok.458, label %runtime.continue.459, label %entry.failure.0
runtime.continue.459:
  %stack.offset.460 = add i32 %stack.offset.453, %descriptor.value.307
  %host.pointer.461 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.460
  %stack.sub.462 = sub i32 %retained.capacity, %stack.offset.460
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.461, i32 %stack.sub.462, i32 %descriptor.value.338, i32 %descriptor.value.340, i32 10)
  %context.field.463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.464 = load i32, ptr %context.field.463, align 4
  %runtime.ok.465 = icmp eq i32 %context.value.464, 0
  br i1 %runtime.ok.465, label %runtime.continue.466, label %entry.failure.0
runtime.continue.466:
  %stack.offset.467 = add i32 %stack.offset.460, %descriptor.value.340
  %host.pointer.468 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.467
  %stack.sub.469 = sub i32 %retained.capacity, %stack.offset.467
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.468, i32 %stack.sub.469, i32 %descriptor.value.371, i32 %descriptor.value.373, i32 10)
  %context.field.470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.471 = load i32, ptr %context.field.470, align 4
  %runtime.ok.472 = icmp eq i32 %context.value.471, 0
  br i1 %runtime.ok.472, label %runtime.continue.473, label %entry.failure.0
runtime.continue.473:
  %stack.offset.474 = add i32 %stack.offset.467, %descriptor.value.373
  %host.pointer.475 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.474
  %stack.sub.476 = sub i32 %retained.capacity, %stack.offset.474
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.475, i32 %stack.sub.476, i32 %descriptor.value.404, i32 %descriptor.value.406, i32 11)
  %context.field.477 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.478 = load i32, ptr %context.field.477, align 4
  %runtime.ok.479 = icmp eq i32 %context.value.478, 0
  br i1 %runtime.ok.479, label %runtime.continue.480, label %entry.failure.0
runtime.continue.480:
  %stack.offset.481 = add i32 %stack.offset.474, %descriptor.value.406
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.483 = load i32, ptr %context.field.482, align 4
  %context.field.484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.485 = load i32, ptr %context.field.484, align 4
  %stack.sub.486 = sub i32 0, %context.value.483
  %stack.sub.487 = sub i32 0, %context.value.485
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.486, i32 %stack.sub.487)
  %context.field.488 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.489 = load i32, ptr %context.field.488, align 4
  %runtime.ok.490 = icmp eq i32 %context.value.489, 0
  br i1 %runtime.ok.490, label %runtime.continue.491, label %entry.failure.0
runtime.continue.491:
  br label %entry.return.status
entry.failure.0:
  %context.field.492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.493 = load i32, ptr %context.field.492, align 4
  %context.field.494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.495 = load i32, ptr %context.field.494, align 4
  %context.field.496 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.497 = load i32, ptr %context.field.496, align 4
  %stack.offset.498 = add i32 %context.value.493, %context.value.495
  %stack.sub.499 = sub i32 0, %stack.offset.498
  %stack.sub.500 = sub i32 0, %context.value.495
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.499, i32 %stack.sub.500)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.497)
  br label %entry.return.status
entry.return.status:
  %context.field.501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.502 = load i32, ptr %context.field.501, align 4
  ret i32 %context.value.502
}


target triple = "x86_64-pc-windows-msvc"
define dllexport i8 @oversized(i64 %index) {
entry:
  %buffer = alloca [131072 x i8], align 16
  %cell = getelementptr [131072 x i8], ptr %buffer, i64 0, i64 %index
  store volatile i8 7, ptr %cell
  %value = load volatile i8, ptr %cell
  ret i8 %value
}
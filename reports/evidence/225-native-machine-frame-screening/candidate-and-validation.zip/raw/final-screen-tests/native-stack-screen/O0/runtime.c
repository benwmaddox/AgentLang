int runtime_fixture(void) { return 0; }

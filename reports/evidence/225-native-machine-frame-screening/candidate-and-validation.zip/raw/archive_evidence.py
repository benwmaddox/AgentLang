from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
raw = root / '.agentlang/native-stack-225'
destination = root / 'reports/evidence/225-native-machine-frame-screening'
destination.mkdir(parents=True, exist_ok=True)
sources = [
    'src/AgentLang.Llvm/NativeStackUsage.fs',
    'src/AgentLang.Llvm/LlvmToolchain.fs',
    'src/AgentLang.Llvm/OwningStackAot.fs',
    'src/AgentLang.Llvm/AgentLang.Llvm.fsproj',
    'src/AgentLang.Llvm/native/owning_stack_runtime.c',
    'src/AgentLang.Llvm/native/owning_stack_runtime.h',
    'src/AgentLang.Llvm/native/float_format.h',
    'tests/AgentLang.Llvm.Tests/Program.fs',
]
members = [(p, 'raw/' + p.relative_to(raw).as_posix())
           for p in sorted(raw.rglob('*'))
           if p.is_file() and p.suffix not in {'.tmp', '.dll', '.pdb', '.lib', '.exp'}]
members += [(root / p, 'candidate-source/' + p) for p in sources]
index = []
archive = destination / 'candidate-and-validation.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path, name in members:
        data = path.read_bytes()
        z.writestr(name, data)
        index.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    for member in index:
        data = z.read(member['path'])
        assert len(data) == member['bytes']
        assert hashlib.sha256(data).hexdigest() == member['sha256']
receipt = {
    'status': 'local candidate; focused checks pass; full branch acceptance pending Float contract',
    'baseCommit': '57097550576df10208563c15235d4468c1b3bb4b',
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'members': index,
}
(destination / 'index.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'membersVerified': len(index), 'archiveSha256': receipt['archiveSha256']}))

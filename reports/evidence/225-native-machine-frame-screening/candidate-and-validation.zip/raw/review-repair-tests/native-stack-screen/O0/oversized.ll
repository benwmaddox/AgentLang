define dllexport i32 @small() {
entry:
  ret i32 0
}

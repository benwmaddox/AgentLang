int runtime_fixture(unsigned int count) { volatile unsigned char scratch[count]; scratch[0] = 7; return scratch[count - 1]; }

define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %inline.target.depth.within.interpreter.limit.78 = icmp ule i32 %context.value.77, 65
  br i1 %inline.target.depth.within.interpreter.limit.78, label %inline.target.depth.ok.79, label %inline.target.depth.invalid.80
inline.target.depth.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.79:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %frame.failure.0
runtime.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.23, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.19, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 5, 5
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  %step.status.102 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.103 = icmp eq i32 %step.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %stack.offset.107 = add i32 %context.value.106, 8
  %reserve.status.108 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.107, i32 16)
  %reserve.ok.109 = icmp eq i32 %reserve.status.108, 0
  br i1 %reserve.ok.109, label %reserve.continue.110, label %frame.failure.0
reserve.continue.110:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.106, i64 1, i32 1)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %runtime.ok.117 = icmp eq i32 %context.value.116, 0
  br i1 %runtime.ok.117, label %runtime.continue.118, label %frame.failure.0
runtime.continue.118:
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.121 = icmp ule i32 %descriptor.value.23, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.124 = icmp ule i32 %descriptor.value.19, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  %descriptor.type.valid.129 = icmp eq i32 5, 5
  %descriptor.valid.130 = and i1 %descriptor.range.valid.127, %descriptor.type.valid.129
  br i1 %descriptor.valid.130, label %descriptor.valid.131, label %descriptor.invalid.132
descriptor.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.131:
  %descriptor.initialized.status.133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.134 = icmp eq i32 %descriptor.initialized.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %stack.sub.140 = sub i32 %stack.offset.107, %context.value.106
  %descriptor.owner.inside.138 = icmp ule i32 %stack.offset.107, %context.value.137
  %descriptor.offset.inside.139 = icmp ule i32 %context.value.106, %stack.offset.107
  %descriptor.extent.inside.141 = icmp ule i32 8, %stack.sub.140
  %descriptor.payload.inside.142 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.143 = and i1 %descriptor.owner.inside.138, %descriptor.offset.inside.139
  %descriptor.range.inside.145 = and i1 %descriptor.owner.offset.valid.143, %descriptor.extent.inside.141
  %descriptor.range.valid.144 = and i1 %descriptor.range.inside.145, %descriptor.payload.inside.142
  %descriptor.type.valid.146 = icmp eq i32 1, 1
  %descriptor.valid.147 = and i1 %descriptor.range.valid.144, %descriptor.type.valid.146
  br i1 %descriptor.valid.147, label %descriptor.valid.148, label %descriptor.invalid.149
descriptor.invalid.149:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.148:
  %descriptor.initialized.status.150 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.106, i32 8)
  %helper.ok.151 = icmp eq i32 %descriptor.initialized.status.150, 0
  br i1 %helper.ok.151, label %helper.continue.152, label %frame.failure.0
helper.continue.152:
  %step.status.153 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.154 = icmp eq i32 %step.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %inline.target.depth.within.interpreter.limit.158 = icmp ule i32 %context.value.157, 65
  br i1 %inline.target.depth.within.interpreter.limit.158, label %inline.target.depth.ok.159, label %inline.target.depth.invalid.160
inline.target.depth.invalid.160:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 18, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.159:
  %stack.offset.161 = add i32 0, 8
  %stack.offset.162 = add i32 0, 8
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %stack.offset.165 = add i32 %context.value.164, %stack.offset.162
  %reserve.status.166 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.165, i32 19)
  %reserve.ok.167 = icmp eq i32 %reserve.status.166, 0
  br i1 %reserve.ok.167, label %reserve.continue.168, label %frame.failure.0
reserve.continue.168:
  %stack.offset.169 = add i32 %context.value.164, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.169, i32 %context.value.106, i32 8, i32 8, i32 1, i32 6)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.164, i32 %stack.offset.162, i32 %stack.offset.161, i32 0, i32 0)
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %runtime.ok.177 = icmp eq i32 %context.value.176, 0
  br i1 %runtime.ok.177, label %runtime.continue.178, label %frame.failure.0
runtime.continue.178:
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %stack.sub.183 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.181 = icmp ule i32 %descriptor.value.23, %context.value.180
  %descriptor.offset.inside.182 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.184 = icmp ule i32 %descriptor.value.19, %stack.sub.183
  %descriptor.payload.inside.185 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.186 = and i1 %descriptor.owner.inside.181, %descriptor.offset.inside.182
  %descriptor.range.inside.188 = and i1 %descriptor.owner.offset.valid.186, %descriptor.extent.inside.184
  %descriptor.range.valid.187 = and i1 %descriptor.range.inside.188, %descriptor.payload.inside.185
  %descriptor.type.valid.189 = icmp eq i32 5, 5
  %descriptor.valid.190 = and i1 %descriptor.range.valid.187, %descriptor.type.valid.189
  br i1 %descriptor.valid.190, label %descriptor.valid.191, label %descriptor.invalid.192
descriptor.invalid.192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.191:
  %descriptor.initialized.status.193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.194 = icmp eq i32 %descriptor.initialized.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %frame.failure.0
helper.continue.195:
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %stack.sub.200 = sub i32 %stack.offset.165, %context.value.164
  %descriptor.owner.inside.198 = icmp ule i32 %stack.offset.165, %context.value.197
  %descriptor.offset.inside.199 = icmp ule i32 %context.value.164, %stack.offset.165
  %descriptor.extent.inside.201 = icmp ule i32 %stack.offset.162, %stack.sub.200
  %descriptor.payload.inside.202 = icmp ule i32 %stack.offset.161, %stack.offset.162
  %descriptor.owner.offset.valid.203 = and i1 %descriptor.owner.inside.198, %descriptor.offset.inside.199
  %descriptor.range.inside.205 = and i1 %descriptor.owner.offset.valid.203, %descriptor.extent.inside.201
  %descriptor.range.valid.204 = and i1 %descriptor.range.inside.205, %descriptor.payload.inside.202
  %descriptor.type.valid.206 = icmp eq i32 4, 4
  %descriptor.valid.207 = and i1 %descriptor.range.valid.204, %descriptor.type.valid.206
  br i1 %descriptor.valid.207, label %descriptor.valid.208, label %descriptor.invalid.209
descriptor.invalid.209:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.208:
  %descriptor.initialized.status.210 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.164, i32 %stack.offset.162)
  %helper.ok.211 = icmp eq i32 %descriptor.initialized.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 5, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  %descriptor.element.223 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 0
  store i32 4, ptr %descriptor.field.224, align 4
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 1
  store i32 %context.value.164, ptr %descriptor.field.225, align 4
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 2
  store i32 %stack.offset.162, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 3
  store i32 %stack.offset.161, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 4
  store i32 %stack.offset.165, ptr %descriptor.field.228, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.164, i32 20, i32 %stack.offset.161, i32 %stack.offset.165, i32 %stack.offset.162)
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %runtime.ok.231 = icmp eq i32 %context.value.230, 0
  br i1 %runtime.ok.231, label %runtime.continue.232, label %frame.failure.0
runtime.continue.232:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %stack.offset.239 = add i32 %context.value.5, %context.value.7
  %stack.offset.240 = add i32 %context.value.234, %context.value.236
  %stack.sub.241 = sub i32 %stack.offset.239, %stack.offset.240
  %stack.sub.242 = sub i32 %context.value.7, %context.value.236
  %stack.sub.243 = sub i32 %context.value.238, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.241, i32 %stack.sub.242)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.243)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


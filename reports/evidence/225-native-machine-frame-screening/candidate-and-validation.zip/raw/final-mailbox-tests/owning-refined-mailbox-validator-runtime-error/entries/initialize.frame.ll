define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %validator.arguments.97 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.108 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %inline.target.depth.within.interpreter.limit.94 = icmp ule i32 %context.value.93, 65
  br i1 %inline.target.depth.within.interpreter.limit.94, label %inline.target.depth.ok.95, label %inline.target.depth.invalid.96
inline.target.depth.invalid.96:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 6, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.95:
  %descriptor.element.98 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.97, i32 0
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 0
  store i32 1, ptr %descriptor.field.99, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 1
  store i32 %context.value.59, ptr %descriptor.field.100, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 2
  store i32 8, ptr %descriptor.field.101, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 3
  store i32 8, ptr %descriptor.field.102, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 4
  store i32 %stack.offset.60, ptr %descriptor.field.103, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.59, i32 20, i32 8, i32 %stack.offset.60, i32 8)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %validator.depth.within.interpreter.limit.111 = icmp ule i32 %context.value.110, 64
  br i1 %validator.depth.within.interpreter.limit.111, label %validator.depth.ok.112, label %validator.depth.invalid.113
validator.depth.invalid.113:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.112:
  %validator.status.114 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.97, ptr %validator.results.108, i32 9)
  %helper.ok.115 = icmp eq i32 %validator.status.114, 0
  br i1 %helper.ok.115, label %helper.continue.116, label %frame.failure.0
helper.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.108, i32 0
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  %descriptor.value.127 = load i32, ptr %descriptor.field.126, align 4
  %validator.result.type.matches.128 = icmp eq i32 %descriptor.value.119, 2
  br i1 %validator.result.type.matches.128, label %validator.result.type.ok.129, label %validator.result.type.invalid.130
validator.result.type.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.129:
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %stack.sub.135 = sub i32 %descriptor.value.127, %descriptor.value.121
  %descriptor.owner.inside.133 = icmp ule i32 %descriptor.value.127, %context.value.132
  %descriptor.offset.inside.134 = icmp ule i32 %descriptor.value.121, %descriptor.value.127
  %descriptor.extent.inside.136 = icmp ule i32 %descriptor.value.123, %stack.sub.135
  %descriptor.payload.inside.137 = icmp ule i32 %descriptor.value.125, %descriptor.value.123
  %descriptor.owner.offset.valid.138 = and i1 %descriptor.owner.inside.133, %descriptor.offset.inside.134
  %descriptor.range.inside.140 = and i1 %descriptor.owner.offset.valid.138, %descriptor.extent.inside.136
  %descriptor.range.valid.139 = and i1 %descriptor.range.inside.140, %descriptor.payload.inside.137
  %descriptor.type.valid.141 = icmp eq i32 2, 2
  %descriptor.valid.142 = and i1 %descriptor.range.valid.139, %descriptor.type.valid.141
  br i1 %descriptor.valid.142, label %descriptor.valid.143, label %descriptor.invalid.144
descriptor.invalid.144:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.143:
  %descriptor.initialized.status.145 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.121, i32 %descriptor.value.123)
  %helper.ok.146 = icmp eq i32 %descriptor.initialized.status.145, 0
  br i1 %helper.ok.146, label %helper.continue.147, label %frame.failure.0
helper.continue.147:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.121, i32 20, i32 %descriptor.value.125, i32 %descriptor.value.127, i32 %descriptor.value.123)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %validator.bool.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.121)
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %runtime.ok.155 = icmp eq i32 %context.value.154, 0
  br i1 %runtime.ok.155, label %runtime.continue.156, label %frame.failure.0
runtime.continue.156:
  %validator.bool.true.157 = icmp eq i64 %validator.bool.152, 1
  %validator.bool.false.158 = icmp eq i64 %validator.bool.152, 0
  %validator.bool.valid.159 = or i1 %validator.bool.true.157, %validator.bool.false.158
  br i1 %validator.bool.valid.159, label %validator.bool.check.160, label %validator.bool.invalid.161
validator.bool.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.160:
  br i1 %validator.bool.true.157, label %validator.true.163, label %validator.false.162
validator.false.162:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
validator.true.163:
  br label %validator.join.164
validator.join.164:
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %stack.sub.169 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.167 = icmp ule i32 %stack.offset.60, %context.value.166
  %descriptor.offset.inside.168 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.170 = icmp ule i32 8, %stack.sub.169
  %descriptor.payload.inside.171 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.172 = and i1 %descriptor.owner.inside.167, %descriptor.offset.inside.168
  %descriptor.range.inside.174 = and i1 %descriptor.owner.offset.valid.172, %descriptor.extent.inside.170
  %descriptor.range.valid.173 = and i1 %descriptor.range.inside.174, %descriptor.payload.inside.171
  %descriptor.type.valid.175 = icmp eq i32 6, 6
  %descriptor.valid.176 = and i1 %descriptor.range.valid.173, %descriptor.type.valid.175
  br i1 %descriptor.valid.176, label %descriptor.valid.177, label %descriptor.invalid.178
descriptor.invalid.178:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.177:
  %descriptor.initialized.status.179 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.180 = icmp eq i32 %descriptor.initialized.status.179, 0
  br i1 %helper.ok.180, label %helper.continue.181, label %frame.failure.0
helper.continue.181:
  %step.status.182 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.183 = icmp eq i32 %step.status.182, 0
  br i1 %helper.ok.183, label %helper.continue.184, label %frame.failure.0
helper.continue.184:
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %inline.target.depth.within.interpreter.limit.187 = icmp ule i32 %context.value.186, 65
  br i1 %inline.target.depth.within.interpreter.limit.187, label %inline.target.depth.ok.188, label %inline.target.depth.invalid.189
inline.target.depth.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 11, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.188:
  %stack.offset.190 = add i32 0, 8
  %stack.offset.191 = add i32 0, 8
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %stack.offset.194 = add i32 %context.value.193, %stack.offset.191
  %reserve.status.195 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.194, i32 12)
  %reserve.ok.196 = icmp eq i32 %reserve.status.195, 0
  br i1 %reserve.ok.196, label %reserve.continue.197, label %frame.failure.0
reserve.continue.197:
  %stack.offset.198 = add i32 %context.value.193, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.198, i32 %context.value.59, i32 8, i32 8, i32 6, i32 6)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %frame.failure.0
runtime.continue.202:
  %stack.offset.203 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.193, i32 %stack.offset.191, i32 %stack.offset.190, i32 0, i32 0)
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %runtime.ok.206 = icmp eq i32 %context.value.205, 0
  br i1 %runtime.ok.206, label %runtime.continue.207, label %frame.failure.0
runtime.continue.207:
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %stack.sub.212 = sub i32 %stack.offset.194, %context.value.193
  %descriptor.owner.inside.210 = icmp ule i32 %stack.offset.194, %context.value.209
  %descriptor.offset.inside.211 = icmp ule i32 %context.value.193, %stack.offset.194
  %descriptor.extent.inside.213 = icmp ule i32 %stack.offset.191, %stack.sub.212
  %descriptor.payload.inside.214 = icmp ule i32 %stack.offset.190, %stack.offset.191
  %descriptor.owner.offset.valid.215 = and i1 %descriptor.owner.inside.210, %descriptor.offset.inside.211
  %descriptor.range.inside.217 = and i1 %descriptor.owner.offset.valid.215, %descriptor.extent.inside.213
  %descriptor.range.valid.216 = and i1 %descriptor.range.inside.217, %descriptor.payload.inside.214
  %descriptor.type.valid.218 = icmp eq i32 5, 5
  %descriptor.valid.219 = and i1 %descriptor.range.valid.216, %descriptor.type.valid.218
  br i1 %descriptor.valid.219, label %descriptor.valid.220, label %descriptor.invalid.221
descriptor.invalid.221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.220:
  %descriptor.initialized.status.222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.193, i32 %stack.offset.191)
  %helper.ok.223 = icmp eq i32 %descriptor.initialized.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  %descriptor.element.225 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 0
  store i32 5, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 1
  store i32 %context.value.193, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 2
  store i32 %stack.offset.191, ptr %descriptor.field.228, align 4
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 3
  store i32 %stack.offset.190, ptr %descriptor.field.229, align 4
  %descriptor.field.230 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 4
  store i32 %stack.offset.194, ptr %descriptor.field.230, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.193, i32 20, i32 %stack.offset.190, i32 %stack.offset.194, i32 %stack.offset.191)
  %context.field.231 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.232 = load i32, ptr %context.field.231, align 4
  %runtime.ok.233 = icmp eq i32 %context.value.232, 0
  br i1 %runtime.ok.233, label %runtime.continue.234, label %frame.failure.0
runtime.continue.234:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %stack.offset.241 = add i32 %context.value.5, %context.value.7
  %stack.offset.242 = add i32 %context.value.236, %context.value.238
  %stack.sub.243 = sub i32 %stack.offset.241, %stack.offset.242
  %stack.sub.244 = sub i32 %context.value.7, %context.value.238
  %stack.sub.245 = sub i32 %context.value.240, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.243, i32 %stack.sub.244)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.245)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


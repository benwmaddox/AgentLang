%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [6 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 1, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 1, i32 1, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 6, i32 2, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }], align 4
@agentlang_owning_mailbox_layout = constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 6, ptr @al_owning_fields, i32 2 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare i32 @agentlang_owning_mailbox_preflight(ptr, ptr, i32, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @agentlang_owning_mailbox_associated_preflight(ptr, ptr, i32, ptr, i32, ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %validator.arguments.97 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.108 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %inline.target.depth.within.interpreter.limit.94 = icmp ule i32 %context.value.93, 65
  br i1 %inline.target.depth.within.interpreter.limit.94, label %inline.target.depth.ok.95, label %inline.target.depth.invalid.96
inline.target.depth.invalid.96:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 6, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.95:
  %descriptor.element.98 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.97, i32 0
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 0
  store i32 1, ptr %descriptor.field.99, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 1
  store i32 %context.value.59, ptr %descriptor.field.100, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 2
  store i32 8, ptr %descriptor.field.101, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 3
  store i32 8, ptr %descriptor.field.102, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 4
  store i32 %stack.offset.60, ptr %descriptor.field.103, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.59, i32 20, i32 8, i32 %stack.offset.60, i32 8)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %validator.depth.within.interpreter.limit.111 = icmp ule i32 %context.value.110, 64
  br i1 %validator.depth.within.interpreter.limit.111, label %validator.depth.ok.112, label %validator.depth.invalid.113
validator.depth.invalid.113:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.112:
  %validator.status.114 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.97, ptr %validator.results.108, i32 9)
  %helper.ok.115 = icmp eq i32 %validator.status.114, 0
  br i1 %helper.ok.115, label %helper.continue.116, label %frame.failure.0
helper.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.108, i32 0
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  %descriptor.value.127 = load i32, ptr %descriptor.field.126, align 4
  %validator.result.type.matches.128 = icmp eq i32 %descriptor.value.119, 2
  br i1 %validator.result.type.matches.128, label %validator.result.type.ok.129, label %validator.result.type.invalid.130
validator.result.type.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.129:
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %stack.sub.135 = sub i32 %descriptor.value.127, %descriptor.value.121
  %descriptor.owner.inside.133 = icmp ule i32 %descriptor.value.127, %context.value.132
  %descriptor.offset.inside.134 = icmp ule i32 %descriptor.value.121, %descriptor.value.127
  %descriptor.extent.inside.136 = icmp ule i32 %descriptor.value.123, %stack.sub.135
  %descriptor.payload.inside.137 = icmp ule i32 %descriptor.value.125, %descriptor.value.123
  %descriptor.owner.offset.valid.138 = and i1 %descriptor.owner.inside.133, %descriptor.offset.inside.134
  %descriptor.range.inside.140 = and i1 %descriptor.owner.offset.valid.138, %descriptor.extent.inside.136
  %descriptor.range.valid.139 = and i1 %descriptor.range.inside.140, %descriptor.payload.inside.137
  %descriptor.type.valid.141 = icmp eq i32 2, 2
  %descriptor.valid.142 = and i1 %descriptor.range.valid.139, %descriptor.type.valid.141
  br i1 %descriptor.valid.142, label %descriptor.valid.143, label %descriptor.invalid.144
descriptor.invalid.144:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.143:
  %descriptor.initialized.status.145 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.121, i32 %descriptor.value.123)
  %helper.ok.146 = icmp eq i32 %descriptor.initialized.status.145, 0
  br i1 %helper.ok.146, label %helper.continue.147, label %frame.failure.0
helper.continue.147:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.121, i32 20, i32 %descriptor.value.125, i32 %descriptor.value.127, i32 %descriptor.value.123)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %validator.bool.152 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.121)
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %runtime.ok.155 = icmp eq i32 %context.value.154, 0
  br i1 %runtime.ok.155, label %runtime.continue.156, label %frame.failure.0
runtime.continue.156:
  %validator.bool.true.157 = icmp eq i64 %validator.bool.152, 1
  %validator.bool.false.158 = icmp eq i64 %validator.bool.152, 0
  %validator.bool.valid.159 = or i1 %validator.bool.true.157, %validator.bool.false.158
  br i1 %validator.bool.valid.159, label %validator.bool.check.160, label %validator.bool.invalid.161
validator.bool.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.160:
  br i1 %validator.bool.true.157, label %validator.true.163, label %validator.false.162
validator.false.162:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
validator.true.163:
  br label %validator.join.164
validator.join.164:
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %stack.sub.169 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.167 = icmp ule i32 %stack.offset.60, %context.value.166
  %descriptor.offset.inside.168 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.170 = icmp ule i32 8, %stack.sub.169
  %descriptor.payload.inside.171 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.172 = and i1 %descriptor.owner.inside.167, %descriptor.offset.inside.168
  %descriptor.range.inside.174 = and i1 %descriptor.owner.offset.valid.172, %descriptor.extent.inside.170
  %descriptor.range.valid.173 = and i1 %descriptor.range.inside.174, %descriptor.payload.inside.171
  %descriptor.type.valid.175 = icmp eq i32 6, 6
  %descriptor.valid.176 = and i1 %descriptor.range.valid.173, %descriptor.type.valid.175
  br i1 %descriptor.valid.176, label %descriptor.valid.177, label %descriptor.invalid.178
descriptor.invalid.178:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.177:
  %descriptor.initialized.status.179 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.180 = icmp eq i32 %descriptor.initialized.status.179, 0
  br i1 %helper.ok.180, label %helper.continue.181, label %frame.failure.0
helper.continue.181:
  %step.status.182 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.183 = icmp eq i32 %step.status.182, 0
  br i1 %helper.ok.183, label %helper.continue.184, label %frame.failure.0
helper.continue.184:
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %inline.target.depth.within.interpreter.limit.187 = icmp ule i32 %context.value.186, 65
  br i1 %inline.target.depth.within.interpreter.limit.187, label %inline.target.depth.ok.188, label %inline.target.depth.invalid.189
inline.target.depth.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 11, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.188:
  %stack.offset.190 = add i32 0, 8
  %stack.offset.191 = add i32 0, 8
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %stack.offset.194 = add i32 %context.value.193, %stack.offset.191
  %reserve.status.195 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.194, i32 12)
  %reserve.ok.196 = icmp eq i32 %reserve.status.195, 0
  br i1 %reserve.ok.196, label %reserve.continue.197, label %frame.failure.0
reserve.continue.197:
  %stack.offset.198 = add i32 %context.value.193, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.198, i32 %context.value.59, i32 8, i32 8, i32 6, i32 6)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %frame.failure.0
runtime.continue.202:
  %stack.offset.203 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.193, i32 %stack.offset.191, i32 %stack.offset.190, i32 0, i32 0)
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %runtime.ok.206 = icmp eq i32 %context.value.205, 0
  br i1 %runtime.ok.206, label %runtime.continue.207, label %frame.failure.0
runtime.continue.207:
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %stack.sub.212 = sub i32 %stack.offset.194, %context.value.193
  %descriptor.owner.inside.210 = icmp ule i32 %stack.offset.194, %context.value.209
  %descriptor.offset.inside.211 = icmp ule i32 %context.value.193, %stack.offset.194
  %descriptor.extent.inside.213 = icmp ule i32 %stack.offset.191, %stack.sub.212
  %descriptor.payload.inside.214 = icmp ule i32 %stack.offset.190, %stack.offset.191
  %descriptor.owner.offset.valid.215 = and i1 %descriptor.owner.inside.210, %descriptor.offset.inside.211
  %descriptor.range.inside.217 = and i1 %descriptor.owner.offset.valid.215, %descriptor.extent.inside.213
  %descriptor.range.valid.216 = and i1 %descriptor.range.inside.217, %descriptor.payload.inside.214
  %descriptor.type.valid.218 = icmp eq i32 5, 5
  %descriptor.valid.219 = and i1 %descriptor.range.valid.216, %descriptor.type.valid.218
  br i1 %descriptor.valid.219, label %descriptor.valid.220, label %descriptor.invalid.221
descriptor.invalid.221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.220:
  %descriptor.initialized.status.222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.193, i32 %stack.offset.191)
  %helper.ok.223 = icmp eq i32 %descriptor.initialized.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  %descriptor.element.225 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 0
  store i32 5, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 1
  store i32 %context.value.193, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 2
  store i32 %stack.offset.191, ptr %descriptor.field.228, align 4
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 3
  store i32 %stack.offset.190, ptr %descriptor.field.229, align 4
  %descriptor.field.230 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 4
  store i32 %stack.offset.194, ptr %descriptor.field.230, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.193, i32 20, i32 %stack.offset.190, i32 %stack.offset.194, i32 %stack.offset.191)
  %context.field.231 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.232 = load i32, ptr %context.field.231, align 4
  %runtime.ok.233 = icmp eq i32 %context.value.232, 0
  br i1 %runtime.ok.233, label %runtime.continue.234, label %frame.failure.0
runtime.continue.234:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %stack.offset.241 = add i32 %context.value.5, %context.value.7
  %stack.offset.242 = add i32 %context.value.236, %context.value.238
  %stack.sub.243 = sub i32 %stack.offset.241, %stack.offset.242
  %stack.sub.244 = sub i32 %context.value.7, %context.value.238
  %stack.sub.245 = sub i32 %context.value.240, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.243, i32 %stack.sub.244)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.245)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %inline.target.depth.within.interpreter.limit.78 = icmp ule i32 %context.value.77, 65
  br i1 %inline.target.depth.within.interpreter.limit.78, label %inline.target.depth.ok.79, label %inline.target.depth.invalid.80
inline.target.depth.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.79:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %frame.failure.0
runtime.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.23, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.19, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 5, 5
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  %step.status.102 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.103 = icmp eq i32 %step.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %stack.offset.107 = add i32 %context.value.106, 8
  %reserve.status.108 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.107, i32 16)
  %reserve.ok.109 = icmp eq i32 %reserve.status.108, 0
  br i1 %reserve.ok.109, label %reserve.continue.110, label %frame.failure.0
reserve.continue.110:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.106, i64 1, i32 1)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %runtime.ok.117 = icmp eq i32 %context.value.116, 0
  br i1 %runtime.ok.117, label %runtime.continue.118, label %frame.failure.0
runtime.continue.118:
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.121 = icmp ule i32 %descriptor.value.23, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.124 = icmp ule i32 %descriptor.value.19, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  %descriptor.type.valid.129 = icmp eq i32 5, 5
  %descriptor.valid.130 = and i1 %descriptor.range.valid.127, %descriptor.type.valid.129
  br i1 %descriptor.valid.130, label %descriptor.valid.131, label %descriptor.invalid.132
descriptor.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.131:
  %descriptor.initialized.status.133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.134 = icmp eq i32 %descriptor.initialized.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %stack.sub.140 = sub i32 %stack.offset.107, %context.value.106
  %descriptor.owner.inside.138 = icmp ule i32 %stack.offset.107, %context.value.137
  %descriptor.offset.inside.139 = icmp ule i32 %context.value.106, %stack.offset.107
  %descriptor.extent.inside.141 = icmp ule i32 8, %stack.sub.140
  %descriptor.payload.inside.142 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.143 = and i1 %descriptor.owner.inside.138, %descriptor.offset.inside.139
  %descriptor.range.inside.145 = and i1 %descriptor.owner.offset.valid.143, %descriptor.extent.inside.141
  %descriptor.range.valid.144 = and i1 %descriptor.range.inside.145, %descriptor.payload.inside.142
  %descriptor.type.valid.146 = icmp eq i32 1, 1
  %descriptor.valid.147 = and i1 %descriptor.range.valid.144, %descriptor.type.valid.146
  br i1 %descriptor.valid.147, label %descriptor.valid.148, label %descriptor.invalid.149
descriptor.invalid.149:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.148:
  %descriptor.initialized.status.150 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.106, i32 8)
  %helper.ok.151 = icmp eq i32 %descriptor.initialized.status.150, 0
  br i1 %helper.ok.151, label %helper.continue.152, label %frame.failure.0
helper.continue.152:
  %step.status.153 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.154 = icmp eq i32 %step.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %inline.target.depth.within.interpreter.limit.158 = icmp ule i32 %context.value.157, 65
  br i1 %inline.target.depth.within.interpreter.limit.158, label %inline.target.depth.ok.159, label %inline.target.depth.invalid.160
inline.target.depth.invalid.160:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 18, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.159:
  %stack.offset.161 = add i32 0, 8
  %stack.offset.162 = add i32 0, 8
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %stack.offset.165 = add i32 %context.value.164, %stack.offset.162
  %reserve.status.166 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.165, i32 19)
  %reserve.ok.167 = icmp eq i32 %reserve.status.166, 0
  br i1 %reserve.ok.167, label %reserve.continue.168, label %frame.failure.0
reserve.continue.168:
  %stack.offset.169 = add i32 %context.value.164, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.169, i32 %context.value.106, i32 8, i32 8, i32 1, i32 6)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.164, i32 %stack.offset.162, i32 %stack.offset.161, i32 0, i32 0)
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %runtime.ok.177 = icmp eq i32 %context.value.176, 0
  br i1 %runtime.ok.177, label %runtime.continue.178, label %frame.failure.0
runtime.continue.178:
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %stack.sub.183 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.181 = icmp ule i32 %descriptor.value.23, %context.value.180
  %descriptor.offset.inside.182 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.184 = icmp ule i32 %descriptor.value.19, %stack.sub.183
  %descriptor.payload.inside.185 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.186 = and i1 %descriptor.owner.inside.181, %descriptor.offset.inside.182
  %descriptor.range.inside.188 = and i1 %descriptor.owner.offset.valid.186, %descriptor.extent.inside.184
  %descriptor.range.valid.187 = and i1 %descriptor.range.inside.188, %descriptor.payload.inside.185
  %descriptor.type.valid.189 = icmp eq i32 5, 5
  %descriptor.valid.190 = and i1 %descriptor.range.valid.187, %descriptor.type.valid.189
  br i1 %descriptor.valid.190, label %descriptor.valid.191, label %descriptor.invalid.192
descriptor.invalid.192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.191:
  %descriptor.initialized.status.193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.194 = icmp eq i32 %descriptor.initialized.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %frame.failure.0
helper.continue.195:
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %stack.sub.200 = sub i32 %stack.offset.165, %context.value.164
  %descriptor.owner.inside.198 = icmp ule i32 %stack.offset.165, %context.value.197
  %descriptor.offset.inside.199 = icmp ule i32 %context.value.164, %stack.offset.165
  %descriptor.extent.inside.201 = icmp ule i32 %stack.offset.162, %stack.sub.200
  %descriptor.payload.inside.202 = icmp ule i32 %stack.offset.161, %stack.offset.162
  %descriptor.owner.offset.valid.203 = and i1 %descriptor.owner.inside.198, %descriptor.offset.inside.199
  %descriptor.range.inside.205 = and i1 %descriptor.owner.offset.valid.203, %descriptor.extent.inside.201
  %descriptor.range.valid.204 = and i1 %descriptor.range.inside.205, %descriptor.payload.inside.202
  %descriptor.type.valid.206 = icmp eq i32 4, 4
  %descriptor.valid.207 = and i1 %descriptor.range.valid.204, %descriptor.type.valid.206
  br i1 %descriptor.valid.207, label %descriptor.valid.208, label %descriptor.invalid.209
descriptor.invalid.209:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.208:
  %descriptor.initialized.status.210 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.164, i32 %stack.offset.162)
  %helper.ok.211 = icmp eq i32 %descriptor.initialized.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 5, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  %descriptor.element.223 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 0
  store i32 4, ptr %descriptor.field.224, align 4
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 1
  store i32 %context.value.164, ptr %descriptor.field.225, align 4
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 2
  store i32 %stack.offset.162, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 3
  store i32 %stack.offset.161, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 4
  store i32 %stack.offset.165, ptr %descriptor.field.228, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.164, i32 20, i32 %stack.offset.161, i32 %stack.offset.165, i32 %stack.offset.162)
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %runtime.ok.231 = icmp eq i32 %context.value.230, 0
  br i1 %runtime.ok.231, label %runtime.continue.232, label %frame.failure.0
runtime.continue.232:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %stack.offset.239 = add i32 %context.value.5, %context.value.7
  %stack.offset.240 = add i32 %context.value.234, %context.value.236
  %stack.sub.241 = sub i32 %stack.offset.239, %stack.offset.240
  %stack.sub.242 = sub i32 %context.value.7, %context.value.236
  %stack.sub.243 = sub i32 %context.value.238, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.241, i32 %stack.sub.242)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.243)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 7
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 7, 7
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %inline.target.depth.within.interpreter.limit.108 = icmp ule i32 %context.value.107, 65
  br i1 %inline.target.depth.within.interpreter.limit.108, label %inline.target.depth.ok.109, label %inline.target.depth.invalid.110
inline.target.depth.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.109:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.77, i32 %descriptor.value.79, i32 %descriptor.value.81, i32 0, i32 0)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %stack.sub.119 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.117 = icmp ule i32 %descriptor.value.23, %context.value.116
  %descriptor.offset.inside.118 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.120 = icmp ule i32 %descriptor.value.19, %stack.sub.119
  %descriptor.payload.inside.121 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.122 = and i1 %descriptor.owner.inside.117, %descriptor.offset.inside.118
  %descriptor.range.inside.124 = and i1 %descriptor.owner.offset.valid.122, %descriptor.extent.inside.120
  %descriptor.range.valid.123 = and i1 %descriptor.range.inside.124, %descriptor.payload.inside.121
  %descriptor.type.valid.125 = icmp eq i32 5, 5
  %descriptor.valid.126 = and i1 %descriptor.range.valid.123, %descriptor.type.valid.125
  br i1 %descriptor.valid.126, label %descriptor.valid.127, label %descriptor.invalid.128
descriptor.invalid.128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.127:
  %descriptor.initialized.status.129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.130 = icmp eq i32 %descriptor.initialized.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.134 = icmp ule i32 %descriptor.value.53, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.137 = icmp ule i32 %descriptor.value.49, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  %descriptor.type.valid.142 = icmp eq i32 4, 4
  %descriptor.valid.143 = and i1 %descriptor.range.valid.140, %descriptor.type.valid.142
  br i1 %descriptor.valid.143, label %descriptor.valid.144, label %descriptor.invalid.145
descriptor.invalid.145:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.144:
  %descriptor.initialized.status.146 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.147 = icmp eq i32 %descriptor.initialized.status.146, 0
  br i1 %helper.ok.147, label %helper.continue.148, label %frame.failure.0
helper.continue.148:
  %step.status.149 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.150 = icmp eq i32 %step.status.149, 0
  br i1 %helper.ok.150, label %helper.continue.151, label %frame.failure.0
helper.continue.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %inline.target.depth.within.interpreter.limit.154 = icmp ule i32 %context.value.153, 65
  br i1 %inline.target.depth.within.interpreter.limit.154, label %inline.target.depth.ok.155, label %inline.target.depth.invalid.156
inline.target.depth.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 23, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.155:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 4, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %stack.sub.165 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.163 = icmp ule i32 %descriptor.value.23, %context.value.162
  %descriptor.offset.inside.164 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.166 = icmp ule i32 %descriptor.value.19, %stack.sub.165
  %descriptor.payload.inside.167 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.168 = and i1 %descriptor.owner.inside.163, %descriptor.offset.inside.164
  %descriptor.range.inside.170 = and i1 %descriptor.owner.offset.valid.168, %descriptor.extent.inside.166
  %descriptor.range.valid.169 = and i1 %descriptor.range.inside.170, %descriptor.payload.inside.167
  %descriptor.type.valid.171 = icmp eq i32 5, 5
  %descriptor.valid.172 = and i1 %descriptor.range.valid.169, %descriptor.type.valid.171
  br i1 %descriptor.valid.172, label %descriptor.valid.173, label %descriptor.invalid.174
descriptor.invalid.174:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.173:
  %descriptor.initialized.status.175 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.176 = icmp eq i32 %descriptor.initialized.status.175, 0
  br i1 %helper.ok.176, label %helper.continue.177, label %frame.failure.0
helper.continue.177:
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.180 = sub i32 %context.value.179, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.180, i32 0, i32 0, i32 0)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %descriptor.element.189 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.190 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 0
  store i32 5, ptr %descriptor.field.190, align 4
  %descriptor.field.191 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.191, align 4
  %descriptor.field.192 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.192, align 4
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.194, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %runtime.ok.197 = icmp eq i32 %context.value.196, 0
  br i1 %runtime.ok.197, label %runtime.continue.198, label %frame.failure.0
runtime.continue.198:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %context.field.201 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.202 = load i32, ptr %context.field.201, align 4
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %stack.offset.205 = add i32 %context.value.5, %context.value.7
  %stack.offset.206 = add i32 %context.value.200, %context.value.202
  %stack.sub.207 = sub i32 %stack.offset.205, %stack.offset.206
  %stack.sub.208 = sub i32 %context.value.7, %context.value.202
  %stack.sub.209 = sub i32 %context.value.204, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.207, i32 %stack.sub.208)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.209)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 1
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 1, 1
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 8
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 27)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.59, i64 1, i32 1)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %runtime.ok.70 = icmp eq i32 %context.value.69, 0
  br i1 %runtime.ok.70, label %runtime.continue.71, label %frame.failure.0
runtime.continue.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.sub.76 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.74 = icmp ule i32 %stack.offset.60, %context.value.73
  %descriptor.offset.inside.75 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.77 = icmp ule i32 8, %stack.sub.76
  %descriptor.payload.inside.78 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.79 = and i1 %descriptor.owner.inside.74, %descriptor.offset.inside.75
  %descriptor.range.inside.81 = and i1 %descriptor.owner.offset.valid.79, %descriptor.extent.inside.77
  %descriptor.range.valid.80 = and i1 %descriptor.range.inside.81, %descriptor.payload.inside.78
  %descriptor.type.valid.82 = icmp eq i32 1, 1
  %descriptor.valid.83 = and i1 %descriptor.range.valid.80, %descriptor.type.valid.82
  br i1 %descriptor.valid.83, label %descriptor.valid.84, label %descriptor.invalid.85
descriptor.invalid.85:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.84:
  %descriptor.initialized.status.86 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.87 = icmp eq i32 %descriptor.initialized.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %frame.failure.0
helper.continue.88:
  %step.status.89 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.90 = icmp eq i32 %step.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.offset.94 = add i32 %context.value.93, 8
  %reserve.status.95 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 29)
  %reserve.ok.96 = icmp eq i32 %reserve.status.95, 0
  br i1 %reserve.ok.96, label %reserve.continue.97, label %frame.failure.0
reserve.continue.97:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.93, i64 0, i32 1)
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %runtime.ok.100 = icmp eq i32 %context.value.99, 0
  br i1 %runtime.ok.100, label %runtime.continue.101, label %frame.failure.0
runtime.continue.101:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %frame.failure.0
runtime.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %stack.sub.110 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.108 = icmp ule i32 %stack.offset.60, %context.value.107
  %descriptor.offset.inside.109 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.111 = icmp ule i32 8, %stack.sub.110
  %descriptor.payload.inside.112 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.113 = and i1 %descriptor.owner.inside.108, %descriptor.offset.inside.109
  %descriptor.range.inside.115 = and i1 %descriptor.owner.offset.valid.113, %descriptor.extent.inside.111
  %descriptor.range.valid.114 = and i1 %descriptor.range.inside.115, %descriptor.payload.inside.112
  %descriptor.type.valid.116 = icmp eq i32 1, 1
  %descriptor.valid.117 = and i1 %descriptor.range.valid.114, %descriptor.type.valid.116
  br i1 %descriptor.valid.117, label %descriptor.valid.118, label %descriptor.invalid.119
descriptor.invalid.119:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.118:
  %descriptor.initialized.status.120 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 8)
  %helper.ok.121 = icmp eq i32 %descriptor.initialized.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %frame.failure.0
helper.continue.122:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %stack.offset.94, %context.value.93
  %descriptor.owner.inside.125 = icmp ule i32 %stack.offset.94, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %context.value.93, %stack.offset.94
  %descriptor.extent.inside.128 = icmp ule i32 8, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 1, 1
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.93, i32 8)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %step.status.140 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.141 = icmp eq i32 %step.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %inline.target.depth.within.interpreter.limit.145 = icmp ule i32 %context.value.144, 65
  br i1 %inline.target.depth.within.interpreter.limit.145, label %inline.target.depth.ok.146, label %inline.target.depth.invalid.147
inline.target.depth.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 31, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.146:
  %integer.left.148 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.59)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %frame.failure.0
runtime.continue.153:
  %integer.right.149 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.93)
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %runtime.ok.156 = icmp eq i32 %context.value.155, 0
  br i1 %runtime.ok.156, label %runtime.continue.157, label %frame.failure.0
runtime.continue.157:
  %divide.zero.158 = icmp eq i64 %integer.right.149, 0
  br i1 %divide.zero.158, label %divide.zero.159, label %divide.nonzero.160
divide.zero.159:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 32, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.160:
  %divide.min.161 = icmp eq i64 %integer.left.148, -9223372036854775808
  %divide.minusone.162 = icmp eq i64 %integer.right.149, -1
  %divide.overflow.163 = and i1 %divide.min.161, %divide.minusone.162
  br i1 %divide.overflow.163, label %divide.overflow.164, label %divide.valid.165
divide.overflow.164:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 33, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.165:
  %divide.result.166 = sdiv i64 %integer.left.148, %integer.right.149
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.93, i32 8, i32 8, i32 0, i32 0)
  %context.field.167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.168 = load i32, ptr %context.field.167, align 4
  %runtime.ok.169 = icmp eq i32 %context.value.168, 0
  br i1 %runtime.ok.169, label %runtime.continue.170, label %frame.failure.0
runtime.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.59, i32 8, i32 8, i32 0, i32 0)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.offset.177 = add i32 %context.value.176, 8
  %reserve.status.178 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.177, i32 34)
  %reserve.ok.179 = icmp eq i32 %reserve.status.178, 0
  br i1 %reserve.ok.179, label %reserve.continue.180, label %frame.failure.0
reserve.continue.180:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.176, i64 %divide.result.166, i32 1)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %stack.offset.189 = add i32 %context.value.176, 8
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.192 = icmp ule i32 %stack.offset.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.195 = icmp ule i32 8, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  %descriptor.type.valid.200 = icmp eq i32 1, 1
  %descriptor.valid.201 = and i1 %descriptor.range.valid.198, %descriptor.type.valid.200
  br i1 %descriptor.valid.201, label %descriptor.valid.202, label %descriptor.invalid.203
descriptor.invalid.203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.202:
  %descriptor.initialized.status.204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.205 = icmp eq i32 %descriptor.initialized.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  %step.status.207 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.208 = icmp eq i32 %step.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.offset.212 = add i32 %context.value.211, 8
  %reserve.status.213 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.212, i32 36)
  %reserve.ok.214 = icmp eq i32 %reserve.status.213, 0
  br i1 %reserve.ok.214, label %reserve.continue.215, label %frame.failure.0
reserve.continue.215:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.211, i64 0, i32 1)
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %runtime.ok.218 = icmp eq i32 %context.value.217, 0
  br i1 %runtime.ok.218, label %runtime.continue.219, label %frame.failure.0
runtime.continue.219:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %stack.sub.228 = sub i32 %stack.offset.189, %context.value.176
  %descriptor.owner.inside.226 = icmp ule i32 %stack.offset.189, %context.value.225
  %descriptor.offset.inside.227 = icmp ule i32 %context.value.176, %stack.offset.189
  %descriptor.extent.inside.229 = icmp ule i32 8, %stack.sub.228
  %descriptor.payload.inside.230 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.231 = and i1 %descriptor.owner.inside.226, %descriptor.offset.inside.227
  %descriptor.range.inside.233 = and i1 %descriptor.owner.offset.valid.231, %descriptor.extent.inside.229
  %descriptor.range.valid.232 = and i1 %descriptor.range.inside.233, %descriptor.payload.inside.230
  %descriptor.type.valid.234 = icmp eq i32 1, 1
  %descriptor.valid.235 = and i1 %descriptor.range.valid.232, %descriptor.type.valid.234
  br i1 %descriptor.valid.235, label %descriptor.valid.236, label %descriptor.invalid.237
descriptor.invalid.237:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.236:
  %descriptor.initialized.status.238 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.176, i32 8)
  %helper.ok.239 = icmp eq i32 %descriptor.initialized.status.238, 0
  br i1 %helper.ok.239, label %helper.continue.240, label %frame.failure.0
helper.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %stack.offset.212, %context.value.211
  %descriptor.owner.inside.243 = icmp ule i32 %stack.offset.212, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %context.value.211, %stack.offset.212
  %descriptor.extent.inside.246 = icmp ule i32 8, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  %descriptor.type.valid.251 = icmp eq i32 1, 1
  %descriptor.valid.252 = and i1 %descriptor.range.valid.249, %descriptor.type.valid.251
  br i1 %descriptor.valid.252, label %descriptor.valid.253, label %descriptor.invalid.254
descriptor.invalid.254:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.253:
  %descriptor.initialized.status.255 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.211, i32 8)
  %helper.ok.256 = icmp eq i32 %descriptor.initialized.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %step.status.258 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %helper.ok.259 = icmp eq i32 %step.status.258, 0
  br i1 %helper.ok.259, label %helper.continue.260, label %frame.failure.0
helper.continue.260:
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %inline.target.depth.within.interpreter.limit.263 = icmp ule i32 %context.value.262, 65
  br i1 %inline.target.depth.within.interpreter.limit.263, label %inline.target.depth.ok.264, label %inline.target.depth.invalid.265
inline.target.depth.invalid.265:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 38, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.264:
  %integer.left.266 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.176)
  %context.field.268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.269 = load i32, ptr %context.field.268, align 4
  %runtime.ok.270 = icmp eq i32 %context.value.269, 0
  br i1 %runtime.ok.270, label %runtime.continue.271, label %frame.failure.0
runtime.continue.271:
  %integer.right.267 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.211)
  %context.field.272 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.273 = load i32, ptr %context.field.272, align 4
  %runtime.ok.274 = icmp eq i32 %context.value.273, 0
  br i1 %runtime.ok.274, label %runtime.continue.275, label %frame.failure.0
runtime.continue.275:
  %comparison.result.276 = icmp sgt i64 %integer.left.266, %integer.right.267
  %comparison.value.277 = zext i1 %comparison.result.276 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.211, i32 8, i32 8, i32 0, i32 0)
  %context.field.278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.279 = load i32, ptr %context.field.278, align 4
  %runtime.ok.280 = icmp eq i32 %context.value.279, 0
  br i1 %runtime.ok.280, label %runtime.continue.281, label %frame.failure.0
runtime.continue.281:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.176, i32 8, i32 8, i32 0, i32 0)
  %context.field.282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.283 = load i32, ptr %context.field.282, align 4
  %runtime.ok.284 = icmp eq i32 %context.value.283, 0
  br i1 %runtime.ok.284, label %runtime.continue.285, label %frame.failure.0
runtime.continue.285:
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.offset.288 = add i32 %context.value.287, 8
  %reserve.status.289 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.288, i32 39)
  %reserve.ok.290 = icmp eq i32 %reserve.status.289, 0
  br i1 %reserve.ok.290, label %reserve.continue.291, label %frame.failure.0
reserve.continue.291:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.287, i64 %comparison.value.277, i32 2)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %runtime.ok.298 = icmp eq i32 %context.value.297, 0
  br i1 %runtime.ok.298, label %runtime.continue.299, label %frame.failure.0
runtime.continue.299:
  %stack.offset.300 = add i32 %context.value.287, 8
  %context.field.301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.302 = load i32, ptr %context.field.301, align 4
  %stack.sub.305 = sub i32 %stack.offset.300, %context.value.287
  %descriptor.owner.inside.303 = icmp ule i32 %stack.offset.300, %context.value.302
  %descriptor.offset.inside.304 = icmp ule i32 %context.value.287, %stack.offset.300
  %descriptor.extent.inside.306 = icmp ule i32 8, %stack.sub.305
  %descriptor.payload.inside.307 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.308 = and i1 %descriptor.owner.inside.303, %descriptor.offset.inside.304
  %descriptor.range.inside.310 = and i1 %descriptor.owner.offset.valid.308, %descriptor.extent.inside.306
  %descriptor.range.valid.309 = and i1 %descriptor.range.inside.310, %descriptor.payload.inside.307
  %descriptor.type.valid.311 = icmp eq i32 2, 2
  %descriptor.valid.312 = and i1 %descriptor.range.valid.309, %descriptor.type.valid.311
  br i1 %descriptor.valid.312, label %descriptor.valid.313, label %descriptor.invalid.314
descriptor.invalid.314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.313:
  %descriptor.initialized.status.315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.287, i32 8)
  %helper.ok.316 = icmp eq i32 %descriptor.initialized.status.315, 0
  br i1 %helper.ok.316, label %helper.continue.317, label %frame.failure.0
helper.continue.317:
  %descriptor.element.318 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.319 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 0
  store i32 2, ptr %descriptor.field.319, align 4
  %descriptor.field.320 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 1
  store i32 %context.value.287, ptr %descriptor.field.320, align 4
  %descriptor.field.321 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 2
  store i32 8, ptr %descriptor.field.321, align 4
  %descriptor.field.322 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 3
  store i32 8, ptr %descriptor.field.322, align 4
  %descriptor.field.323 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.318, i32 0, i32 4
  store i32 %stack.offset.300, ptr %descriptor.field.323, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.287, i32 20, i32 8, i32 %stack.offset.300, i32 8)
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %runtime.ok.326 = icmp eq i32 %context.value.325, 0
  br i1 %runtime.ok.326, label %runtime.continue.327, label %frame.failure.0
runtime.continue.327:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.328 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.329 = load i32, ptr %context.field.328, align 4
  %context.field.330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.331 = load i32, ptr %context.field.330, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.offset.334 = add i32 %context.value.5, %context.value.7
  %stack.offset.335 = add i32 %context.value.329, %context.value.331
  %stack.sub.336 = sub i32 %stack.offset.334, %stack.offset.335
  %stack.sub.337 = sub i32 %context.value.7, %context.value.331
  %stack.sub.338 = sub i32 %context.value.333, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.336, i32 %stack.sub.337)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.338)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 40, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 40, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 40, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 41)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 7, i32 42)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 7, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 43)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 5
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 5)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}

define i32 @agentlang_mailbox_initialize(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.initialize.context.valid.1, label %mailbox.initialize.failure.0
mailbox.initialize.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 0, i32 44, i32 45, i32 46, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.initialize.preflight.ready.2, label %mailbox.initialize.failure.0
mailbox.initialize.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 47, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.initialize.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 47, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.initialize.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 7, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.total.35 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.35, i32 48)
  %helper.ok.37 = icmp eq i32 %mailbox.input.reserve.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %mailbox.initialize.failure.0
helper.continue.38:
  %mailbox.input.copy.status.39 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 7, i32 48)
  %helper.ok.40 = icmp eq i32 %mailbox.input.copy.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %mailbox.initialize.failure.0
helper.continue.41:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %mailbox.initialize.failure.0
runtime.continue.45:
  %mailbox.frame.status.47 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.46, i32 49)
  %helper.ok.48 = icmp eq i32 %mailbox.frame.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.initialize.failure.0
helper.continue.49:
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.46, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  %descriptor.value.52 = load i32, ptr %descriptor.field.51, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  %descriptor.value.54 = load i32, ptr %descriptor.field.53, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  %descriptor.value.56 = load i32, ptr %descriptor.field.55, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %mailbox.output.type.matches.61 = icmp eq i32 %descriptor.value.52, 5
  br i1 %mailbox.output.type.matches.61, label %mailbox.output.type.ok.62, label %mailbox.output.type.invalid.63
mailbox.output.type.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
mailbox.output.type.ok.62:
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %descriptor.value.60, %descriptor.value.54
  %descriptor.owner.inside.66 = icmp ule i32 %descriptor.value.60, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %descriptor.value.54, %descriptor.value.60
  %descriptor.extent.inside.69 = icmp ule i32 %descriptor.value.56, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %descriptor.value.58, %descriptor.value.56
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  %descriptor.type.valid.74 = icmp eq i32 5, 5
  %descriptor.valid.75 = and i1 %descriptor.range.valid.72, %descriptor.type.valid.74
  br i1 %descriptor.valid.75, label %descriptor.valid.76, label %descriptor.invalid.77
descriptor.invalid.77:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
descriptor.valid.76:
  %descriptor.initialized.status.78 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.54, i32 %descriptor.value.56)
  %helper.ok.79 = icmp eq i32 %descriptor.initialized.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %mailbox.initialize.failure.0
helper.continue.80:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.54, i32 20, i32 %descriptor.value.58, i32 %descriptor.value.60, i32 %descriptor.value.56)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %mailbox.initialize.failure.0
runtime.continue.84:
  %mailbox.output.descriptor.85 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.86 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.86, align 4
  %mailbox.output.field.87 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 1
  store i32 %descriptor.value.54, ptr %mailbox.output.field.87, align 4
  %mailbox.output.field.88 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 2
  store i32 %descriptor.value.60, ptr %mailbox.output.field.88, align 4
  %mailbox.output.field.89 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.89, align 4
  ret i32 0
mailbox.initialize.failure.0:
  %mailbox.failure.context.null.90 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.90, label %mailbox.failure.null.context.92, label %mailbox.failure.has.context.91
mailbox.failure.null.context.92:
  ret i32 4
mailbox.failure.has.context.91:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %mailbox.failure.status.set.96 = icmp ne i32 %context.value.95, 0
  br i1 %mailbox.failure.status.set.96, label %mailbox.failure.status.ready.93, label %mailbox.failure.set.fallback.97
mailbox.failure.set.fallback.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 44, i32 0, i32 0)
  br label %mailbox.failure.status.ready.93
mailbox.failure.status.ready.93:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  ret i32 %context.value.99
}


define i32 @agentlang_mailbox_begin(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.17 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.23 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.24 = alloca i32, align 4
  %mailbox.input.payload.pointer.45 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.46 = alloca i32, align 4
  %input.field.location.84 = alloca %AlOwningFieldLocation, align 4
  %validator.arguments.94 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.105 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.output.descriptors.158 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.begin.context.valid.1, label %mailbox.begin.failure.0
mailbox.begin.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 1, i32 50, i32 51, i32 52, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.begin.preflight.ready.2, label %mailbox.begin.failure.0
mailbox.begin.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.output.descriptor.12 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.13, align 4
  %mailbox.output.field.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.14, align 4
  %mailbox.output.field.15 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.15, align 4
  %mailbox.output.field.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.16, align 4
  %mailbox.input.slice.18 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.19 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 0
  %mailbox.input.bytes.20 = load ptr, ptr %mailbox.input.bytes.field.19, align 8
  %mailbox.input.extent.field.21 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 1
  %mailbox.input.extent.22 = load i32, ptr %mailbox.input.extent.field.21, align 4
  %mailbox.input.measure.status.25 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 53, ptr %mailbox.input.payload.pointer.23, ptr %mailbox.input.measured.extent.pointer.24)
  %helper.ok.26 = icmp eq i32 %mailbox.input.measure.status.25, 0
  br i1 %helper.ok.26, label %helper.continue.27, label %mailbox.begin.failure.0
helper.continue.27:
  %mailbox.input.payload.28 = load i32, ptr %mailbox.input.payload.pointer.23, align 4
  %mailbox.input.measured.extent.29 = load i32, ptr %mailbox.input.measured.extent.pointer.24, align 4
  %mailbox.input.extent.exact.30 = icmp eq i32 %mailbox.input.measured.extent.29, %mailbox.input.extent.22
  br i1 %mailbox.input.extent.exact.30, label %mailbox.input.extent.ok.31, label %mailbox.input.extent.invalid.32
mailbox.input.extent.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 53, i32 %mailbox.input.measured.extent.29, i32 %mailbox.input.extent.22)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.31:
  %stack.offset.33 = add i32 0, %mailbox.input.extent.22
  %descriptor.element.34 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 0
  %descriptor.field.35 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 0
  store i32 5, ptr %descriptor.field.35, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 1
  store i32 0, ptr %descriptor.field.36, align 4
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 2
  store i32 %mailbox.input.extent.22, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 3
  store i32 %mailbox.input.payload.28, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.39, align 4
  %mailbox.input.slice.40 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.41 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 0
  %mailbox.input.bytes.42 = load ptr, ptr %mailbox.input.bytes.field.41, align 8
  %mailbox.input.extent.field.43 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 1
  %mailbox.input.extent.44 = load i32, ptr %mailbox.input.extent.field.43, align 4
  %mailbox.input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 53, ptr %mailbox.input.payload.pointer.45, ptr %mailbox.input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %mailbox.input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.begin.failure.0
helper.continue.49:
  %mailbox.input.payload.50 = load i32, ptr %mailbox.input.payload.pointer.45, align 4
  %mailbox.input.measured.extent.51 = load i32, ptr %mailbox.input.measured.extent.pointer.46, align 4
  %mailbox.input.extent.exact.52 = icmp eq i32 %mailbox.input.measured.extent.51, %mailbox.input.extent.44
  br i1 %mailbox.input.extent.exact.52, label %mailbox.input.extent.ok.53, label %mailbox.input.extent.invalid.54
mailbox.input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 53, i32 %mailbox.input.measured.extent.51, i32 %mailbox.input.extent.44)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.53:
  %stack.offset.55 = add i32 %stack.offset.33, %mailbox.input.extent.44
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  store i32 7, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  store i32 %stack.offset.33, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  store i32 %mailbox.input.extent.44, ptr %descriptor.field.59, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  store i32 %mailbox.input.payload.50, ptr %descriptor.field.60, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  store i32 %stack.offset.55, ptr %descriptor.field.61, align 4
  %mailbox.input.total.62 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.63 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.62, i32 54)
  %helper.ok.64 = icmp eq i32 %mailbox.input.reserve.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %mailbox.begin.failure.0
helper.continue.65:
  %mailbox.input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 %mailbox.input.payload.28, i32 %mailbox.input.extent.22, i32 5, i32 54)
  %helper.ok.67 = icmp eq i32 %mailbox.input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %mailbox.begin.failure.0
helper.continue.68:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.28, i32 %stack.offset.33, i32 %mailbox.input.extent.22)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %mailbox.begin.failure.0
runtime.continue.72:
  %mailbox.input.copy.status.73 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.33, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 %mailbox.input.payload.50, i32 %mailbox.input.extent.44, i32 7, i32 54)
  %helper.ok.74 = icmp eq i32 %mailbox.input.copy.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %mailbox.begin.failure.0
helper.continue.75:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.33, i32 20, i32 %mailbox.input.payload.50, i32 %stack.offset.55, i32 %mailbox.input.extent.44)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %mailbox.begin.failure.0
runtime.continue.79:
  %mailbox.validation.frame.entered.81 = call i32 @al_owning_enter_frame(ptr %ctx, i32 56)
  %helper.ok.82 = icmp eq i32 %mailbox.validation.frame.entered.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %mailbox.begin.failure.0
helper.continue.83:
  %input.field.status.85 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 0, i32 %mailbox.input.extent.22, i32 0, i32 57, ptr %input.field.location.84)
  %helper.ok.86 = icmp eq i32 %input.field.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %mailbox.begin.validation.failure.80
helper.continue.87:
  %input.field.offset.pointer.88 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 0
  %input.field.offset.89 = load i32, ptr %input.field.offset.pointer.88, align 4
  %input.field.payload.pointer.90 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 1
  %input.field.payload.91 = load i32, ptr %input.field.payload.pointer.90, align 4
  %input.field.extent.pointer.92 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 2
  %input.field.extent.93 = load i32, ptr %input.field.extent.pointer.92, align 4
  %descriptor.element.95 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.94, i32 0
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 0
  store i32 1, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 1
  store i32 %input.field.offset.89, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 2
  store i32 %input.field.extent.93, ptr %descriptor.field.98, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 3
  store i32 %input.field.payload.91, ptr %descriptor.field.99, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.100, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %input.field.offset.89, i32 20, i32 %input.field.payload.91, i32 %stack.offset.33, i32 %input.field.extent.93)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %mailbox.begin.validation.failure.80
runtime.continue.104:
  %validator.status.106 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.94, ptr %validator.results.105, i32 60)
  %helper.ok.107 = icmp eq i32 %validator.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %mailbox.begin.validation.failure.80
helper.continue.108:
  %descriptor.element.109 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.105, i32 0
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 0
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 1
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 2
  %descriptor.value.115 = load i32, ptr %descriptor.field.114, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 3
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 4
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %validator.result.type.matches.120 = icmp eq i32 %descriptor.value.111, 2
  br i1 %validator.result.type.matches.120, label %validator.result.type.ok.121, label %validator.result.type.invalid.122
validator.result.type.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 59, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.result.type.ok.121:
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.125 = icmp ule i32 %descriptor.value.119, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.128 = icmp ule i32 %descriptor.value.115, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  %descriptor.type.valid.133 = icmp eq i32 2, 2
  %descriptor.valid.134 = and i1 %descriptor.range.valid.131, %descriptor.type.valid.133
  br i1 %descriptor.valid.134, label %descriptor.valid.135, label %descriptor.invalid.136
descriptor.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
descriptor.valid.135:
  %descriptor.initialized.status.137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.138 = icmp eq i32 %descriptor.initialized.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %mailbox.begin.validation.failure.80
helper.continue.139:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.113, i32 20, i32 %descriptor.value.117, i32 %descriptor.value.119, i32 %descriptor.value.115)
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %runtime.ok.142 = icmp eq i32 %context.value.141, 0
  br i1 %runtime.ok.142, label %runtime.continue.143, label %mailbox.begin.validation.failure.80
runtime.continue.143:
  %validator.bool.144 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.113)
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %runtime.ok.147 = icmp eq i32 %context.value.146, 0
  br i1 %runtime.ok.147, label %runtime.continue.148, label %mailbox.begin.validation.failure.80
runtime.continue.148:
  %validator.bool.true.149 = icmp eq i64 %validator.bool.144, 1
  %validator.bool.false.150 = icmp eq i64 %validator.bool.144, 0
  %validator.bool.valid.151 = or i1 %validator.bool.true.149, %validator.bool.false.150
  br i1 %validator.bool.valid.151, label %validator.bool.check.152, label %validator.bool.invalid.153
validator.bool.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 59, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.bool.check.152:
  br i1 %validator.bool.true.149, label %validator.true.155, label %validator.false.154
validator.false.154:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 58, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.true.155:
  br label %validator.join.156
validator.join.156:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.begin.validation.succeeded.157
mailbox.begin.validation.failure.80:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.begin.failure.0
mailbox.begin.validation.succeeded.157:
  %mailbox.frame.status.159 = call i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %mailbox.input.descriptors.17, ptr %mailbox.output.descriptors.158, i32 55)
  %helper.ok.160 = icmp eq i32 %mailbox.frame.status.159, 0
  br i1 %helper.ok.160, label %helper.continue.161, label %mailbox.begin.failure.0
helper.continue.161:
  %descriptor.element.162 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.158, i32 0
  %descriptor.field.163 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 0
  %descriptor.value.164 = load i32, ptr %descriptor.field.163, align 4
  %descriptor.field.165 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 1
  %descriptor.value.166 = load i32, ptr %descriptor.field.165, align 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 2
  %descriptor.value.168 = load i32, ptr %descriptor.field.167, align 4
  %descriptor.field.169 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 3
  %descriptor.value.170 = load i32, ptr %descriptor.field.169, align 4
  %descriptor.field.171 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.162, i32 0, i32 4
  %descriptor.value.172 = load i32, ptr %descriptor.field.171, align 4
  %mailbox.output.type.matches.173 = icmp eq i32 %descriptor.value.164, 5
  br i1 %mailbox.output.type.matches.173, label %mailbox.output.type.ok.174, label %mailbox.output.type.invalid.175
mailbox.output.type.invalid.175:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.174:
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %stack.sub.180 = sub i32 %descriptor.value.172, %descriptor.value.166
  %descriptor.owner.inside.178 = icmp ule i32 %descriptor.value.172, %context.value.177
  %descriptor.offset.inside.179 = icmp ule i32 %descriptor.value.166, %descriptor.value.172
  %descriptor.extent.inside.181 = icmp ule i32 %descriptor.value.168, %stack.sub.180
  %descriptor.payload.inside.182 = icmp ule i32 %descriptor.value.170, %descriptor.value.168
  %descriptor.owner.offset.valid.183 = and i1 %descriptor.owner.inside.178, %descriptor.offset.inside.179
  %descriptor.range.inside.185 = and i1 %descriptor.owner.offset.valid.183, %descriptor.extent.inside.181
  %descriptor.range.valid.184 = and i1 %descriptor.range.inside.185, %descriptor.payload.inside.182
  %descriptor.type.valid.186 = icmp eq i32 5, 5
  %descriptor.valid.187 = and i1 %descriptor.range.valid.184, %descriptor.type.valid.186
  br i1 %descriptor.valid.187, label %descriptor.valid.188, label %descriptor.invalid.189
descriptor.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.188:
  %descriptor.initialized.status.190 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.166, i32 %descriptor.value.168)
  %helper.ok.191 = icmp eq i32 %descriptor.initialized.status.190, 0
  br i1 %helper.ok.191, label %helper.continue.192, label %mailbox.begin.failure.0
helper.continue.192:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.166, i32 20, i32 %descriptor.value.170, i32 %descriptor.value.172, i32 %descriptor.value.168)
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %runtime.ok.195 = icmp eq i32 %context.value.194, 0
  br i1 %runtime.ok.195, label %runtime.continue.196, label %mailbox.begin.failure.0
runtime.continue.196:
  %descriptor.element.197 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.158, i32 1
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 0
  %descriptor.value.199 = load i32, ptr %descriptor.field.198, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 1
  %descriptor.value.201 = load i32, ptr %descriptor.field.200, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 2
  %descriptor.value.203 = load i32, ptr %descriptor.field.202, align 4
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 3
  %descriptor.value.205 = load i32, ptr %descriptor.field.204, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 4
  %descriptor.value.207 = load i32, ptr %descriptor.field.206, align 4
  %mailbox.output.type.matches.208 = icmp eq i32 %descriptor.value.199, 4
  br i1 %mailbox.output.type.matches.208, label %mailbox.output.type.ok.209, label %mailbox.output.type.invalid.210
mailbox.output.type.invalid.210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.209:
  %context.field.211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.212 = load i32, ptr %context.field.211, align 4
  %stack.sub.215 = sub i32 %descriptor.value.207, %descriptor.value.201
  %descriptor.owner.inside.213 = icmp ule i32 %descriptor.value.207, %context.value.212
  %descriptor.offset.inside.214 = icmp ule i32 %descriptor.value.201, %descriptor.value.207
  %descriptor.extent.inside.216 = icmp ule i32 %descriptor.value.203, %stack.sub.215
  %descriptor.payload.inside.217 = icmp ule i32 %descriptor.value.205, %descriptor.value.203
  %descriptor.owner.offset.valid.218 = and i1 %descriptor.owner.inside.213, %descriptor.offset.inside.214
  %descriptor.range.inside.220 = and i1 %descriptor.owner.offset.valid.218, %descriptor.extent.inside.216
  %descriptor.range.valid.219 = and i1 %descriptor.range.inside.220, %descriptor.payload.inside.217
  %descriptor.type.valid.221 = icmp eq i32 4, 4
  %descriptor.valid.222 = and i1 %descriptor.range.valid.219, %descriptor.type.valid.221
  br i1 %descriptor.valid.222, label %descriptor.valid.223, label %descriptor.invalid.224
descriptor.invalid.224:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.223:
  %descriptor.initialized.status.225 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.201, i32 %descriptor.value.203)
  %helper.ok.226 = icmp eq i32 %descriptor.initialized.status.225, 0
  br i1 %helper.ok.226, label %helper.continue.227, label %mailbox.begin.failure.0
helper.continue.227:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.201, i32 20, i32 %descriptor.value.205, i32 %descriptor.value.207, i32 %descriptor.value.203)
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %runtime.ok.230 = icmp eq i32 %context.value.229, 0
  br i1 %runtime.ok.230, label %runtime.continue.231, label %mailbox.begin.failure.0
runtime.continue.231:
  %mailbox.output.descriptor.232 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.233 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.232, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.233, align 4
  %mailbox.output.field.234 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.232, i32 0, i32 1
  store i32 %descriptor.value.166, ptr %mailbox.output.field.234, align 4
  %mailbox.output.field.235 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.232, i32 0, i32 2
  store i32 %descriptor.value.172, ptr %mailbox.output.field.235, align 4
  %mailbox.output.field.236 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.232, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.236, align 4
  %mailbox.output.descriptor.237 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.238 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 0
  store i32 2, ptr %mailbox.output.field.238, align 4
  %mailbox.output.field.239 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 1
  store i32 %descriptor.value.201, ptr %mailbox.output.field.239, align 4
  %mailbox.output.field.240 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 2
  store i32 %descriptor.value.207, ptr %mailbox.output.field.240, align 4
  %mailbox.output.field.241 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.241, align 4
  ret i32 0
mailbox.begin.failure.0:
  %mailbox.failure.context.null.242 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.242, label %mailbox.failure.null.context.244, label %mailbox.failure.has.context.243
mailbox.failure.null.context.244:
  ret i32 4
mailbox.failure.has.context.243:
  %context.field.246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.247 = load i32, ptr %context.field.246, align 4
  %mailbox.failure.status.set.248 = icmp ne i32 %context.value.247, 0
  br i1 %mailbox.failure.status.set.248, label %mailbox.failure.status.ready.245, label %mailbox.failure.set.fallback.249
mailbox.failure.set.fallback.249:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 50, i32 0, i32 0)
  br label %mailbox.failure.status.ready.245
mailbox.failure.status.ready.245:
  %context.field.250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.251 = load i32, ptr %context.field.250, align 4
  ret i32 %context.value.251
}


define i32 @agentlang_mailbox_resume(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.input.payload.pointer.40 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.41 = alloca i32, align 4
  %mailbox.input.payload.pointer.62 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.63 = alloca i32, align 4
  %input.field.location.108 = alloca %AlOwningFieldLocation, align 4
  %validator.arguments.118 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.129 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.output.descriptors.182 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.resume.context.valid.1, label %mailbox.resume.failure.0
mailbox.resume.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 2, i32 61, i32 62, i32 63, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.resume.preflight.ready.2, label %mailbox.resume.failure.0
mailbox.resume.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 64, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.resume.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 64, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 5, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.slice.35 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.36 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 0
  %mailbox.input.bytes.37 = load ptr, ptr %mailbox.input.bytes.field.36, align 8
  %mailbox.input.extent.field.38 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 1
  %mailbox.input.extent.39 = load i32, ptr %mailbox.input.extent.field.38, align 4
  %mailbox.input.measure.status.42 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 64, ptr %mailbox.input.payload.pointer.40, ptr %mailbox.input.measured.extent.pointer.41)
  %helper.ok.43 = icmp eq i32 %mailbox.input.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %mailbox.resume.failure.0
helper.continue.44:
  %mailbox.input.payload.45 = load i32, ptr %mailbox.input.payload.pointer.40, align 4
  %mailbox.input.measured.extent.46 = load i32, ptr %mailbox.input.measured.extent.pointer.41, align 4
  %mailbox.input.extent.exact.47 = icmp eq i32 %mailbox.input.measured.extent.46, %mailbox.input.extent.39
  br i1 %mailbox.input.extent.exact.47, label %mailbox.input.extent.ok.48, label %mailbox.input.extent.invalid.49
mailbox.input.extent.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 64, i32 %mailbox.input.measured.extent.46, i32 %mailbox.input.extent.39)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.48:
  %stack.offset.50 = add i32 %stack.offset.28, %mailbox.input.extent.39
  %descriptor.element.51 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 1
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 0
  store i32 4, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 1
  store i32 %stack.offset.28, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 2
  store i32 %mailbox.input.extent.39, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 3
  store i32 %mailbox.input.payload.45, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 4
  store i32 %stack.offset.50, ptr %descriptor.field.56, align 4
  %mailbox.input.slice.57 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 2
  %mailbox.input.bytes.field.58 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 0
  %mailbox.input.bytes.59 = load ptr, ptr %mailbox.input.bytes.field.58, align 8
  %mailbox.input.extent.field.60 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 1
  %mailbox.input.extent.61 = load i32, ptr %mailbox.input.extent.field.60, align 4
  %mailbox.input.measure.status.64 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 64, ptr %mailbox.input.payload.pointer.62, ptr %mailbox.input.measured.extent.pointer.63)
  %helper.ok.65 = icmp eq i32 %mailbox.input.measure.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %mailbox.resume.failure.0
helper.continue.66:
  %mailbox.input.payload.67 = load i32, ptr %mailbox.input.payload.pointer.62, align 4
  %mailbox.input.measured.extent.68 = load i32, ptr %mailbox.input.measured.extent.pointer.63, align 4
  %mailbox.input.extent.exact.69 = icmp eq i32 %mailbox.input.measured.extent.68, %mailbox.input.extent.61
  br i1 %mailbox.input.extent.exact.69, label %mailbox.input.extent.ok.70, label %mailbox.input.extent.invalid.71
mailbox.input.extent.invalid.71:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 64, i32 %mailbox.input.measured.extent.68, i32 %mailbox.input.extent.61)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.70:
  %stack.offset.72 = add i32 %stack.offset.50, %mailbox.input.extent.61
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  store i32 7, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  store i32 %stack.offset.50, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  store i32 %mailbox.input.extent.61, ptr %descriptor.field.76, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  store i32 %mailbox.input.payload.67, ptr %descriptor.field.77, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  store i32 %stack.offset.72, ptr %descriptor.field.78, align 4
  %mailbox.input.total.79 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.79, i32 65)
  %helper.ok.81 = icmp eq i32 %mailbox.input.reserve.status.80, 0
  br i1 %helper.ok.81, label %helper.continue.82, label %mailbox.resume.failure.0
helper.continue.82:
  %mailbox.input.copy.status.83 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 5, i32 65)
  %helper.ok.84 = icmp eq i32 %mailbox.input.copy.status.83, 0
  br i1 %helper.ok.84, label %helper.continue.85, label %mailbox.resume.failure.0
helper.continue.85:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %runtime.ok.88 = icmp eq i32 %context.value.87, 0
  br i1 %runtime.ok.88, label %runtime.continue.89, label %mailbox.resume.failure.0
runtime.continue.89:
  %mailbox.input.copy.status.90 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.28, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 %mailbox.input.payload.45, i32 %mailbox.input.extent.39, i32 4, i32 65)
  %helper.ok.91 = icmp eq i32 %mailbox.input.copy.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %mailbox.resume.failure.0
helper.continue.92:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %stack.offset.28, i32 20, i32 %mailbox.input.payload.45, i32 %stack.offset.50, i32 %mailbox.input.extent.39)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %mailbox.resume.failure.0
runtime.continue.96:
  %mailbox.input.copy.status.97 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.50, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 %mailbox.input.payload.67, i32 %mailbox.input.extent.61, i32 7, i32 65)
  %helper.ok.98 = icmp eq i32 %mailbox.input.copy.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %mailbox.resume.failure.0
helper.continue.99:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.50, i32 20, i32 %mailbox.input.payload.67, i32 %stack.offset.72, i32 %mailbox.input.extent.61)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %mailbox.resume.failure.0
runtime.continue.103:
  %mailbox.validation.frame.entered.105 = call i32 @al_owning_enter_frame(ptr %ctx, i32 67)
  %helper.ok.106 = icmp eq i32 %mailbox.validation.frame.entered.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %mailbox.resume.failure.0
helper.continue.107:
  %input.field.status.109 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 0, i32 %mailbox.input.extent.17, i32 0, i32 68, ptr %input.field.location.108)
  %helper.ok.110 = icmp eq i32 %input.field.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %mailbox.resume.validation.failure.104
helper.continue.111:
  %input.field.offset.pointer.112 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 0
  %input.field.offset.113 = load i32, ptr %input.field.offset.pointer.112, align 4
  %input.field.payload.pointer.114 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 1
  %input.field.payload.115 = load i32, ptr %input.field.payload.pointer.114, align 4
  %input.field.extent.pointer.116 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 2
  %input.field.extent.117 = load i32, ptr %input.field.extent.pointer.116, align 4
  %descriptor.element.119 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.118, i32 0
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 0
  store i32 1, ptr %descriptor.field.120, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 1
  store i32 %input.field.offset.113, ptr %descriptor.field.121, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 2
  store i32 %input.field.extent.117, ptr %descriptor.field.122, align 4
  %descriptor.field.123 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 3
  store i32 %input.field.payload.115, ptr %descriptor.field.123, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.124, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %input.field.offset.113, i32 20, i32 %input.field.payload.115, i32 %stack.offset.28, i32 %input.field.extent.117)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %runtime.ok.127 = icmp eq i32 %context.value.126, 0
  br i1 %runtime.ok.127, label %runtime.continue.128, label %mailbox.resume.validation.failure.104
runtime.continue.128:
  %validator.status.130 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.118, ptr %validator.results.129, i32 71)
  %helper.ok.131 = icmp eq i32 %validator.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %mailbox.resume.validation.failure.104
helper.continue.132:
  %descriptor.element.133 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.129, i32 0
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 0
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 1
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 2
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 3
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 4
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %validator.result.type.matches.144 = icmp eq i32 %descriptor.value.135, 2
  br i1 %validator.result.type.matches.144, label %validator.result.type.ok.145, label %validator.result.type.invalid.146
validator.result.type.invalid.146:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 70, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.result.type.ok.145:
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %stack.sub.151 = sub i32 %descriptor.value.143, %descriptor.value.137
  %descriptor.owner.inside.149 = icmp ule i32 %descriptor.value.143, %context.value.148
  %descriptor.offset.inside.150 = icmp ule i32 %descriptor.value.137, %descriptor.value.143
  %descriptor.extent.inside.152 = icmp ule i32 %descriptor.value.139, %stack.sub.151
  %descriptor.payload.inside.153 = icmp ule i32 %descriptor.value.141, %descriptor.value.139
  %descriptor.owner.offset.valid.154 = and i1 %descriptor.owner.inside.149, %descriptor.offset.inside.150
  %descriptor.range.inside.156 = and i1 %descriptor.owner.offset.valid.154, %descriptor.extent.inside.152
  %descriptor.range.valid.155 = and i1 %descriptor.range.inside.156, %descriptor.payload.inside.153
  %descriptor.type.valid.157 = icmp eq i32 2, 2
  %descriptor.valid.158 = and i1 %descriptor.range.valid.155, %descriptor.type.valid.157
  br i1 %descriptor.valid.158, label %descriptor.valid.159, label %descriptor.invalid.160
descriptor.invalid.160:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
descriptor.valid.159:
  %descriptor.initialized.status.161 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.137, i32 %descriptor.value.139)
  %helper.ok.162 = icmp eq i32 %descriptor.initialized.status.161, 0
  br i1 %helper.ok.162, label %helper.continue.163, label %mailbox.resume.validation.failure.104
helper.continue.163:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.137, i32 20, i32 %descriptor.value.141, i32 %descriptor.value.143, i32 %descriptor.value.139)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %runtime.ok.166 = icmp eq i32 %context.value.165, 0
  br i1 %runtime.ok.166, label %runtime.continue.167, label %mailbox.resume.validation.failure.104
runtime.continue.167:
  %validator.bool.168 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.137)
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %runtime.ok.171 = icmp eq i32 %context.value.170, 0
  br i1 %runtime.ok.171, label %runtime.continue.172, label %mailbox.resume.validation.failure.104
runtime.continue.172:
  %validator.bool.true.173 = icmp eq i64 %validator.bool.168, 1
  %validator.bool.false.174 = icmp eq i64 %validator.bool.168, 0
  %validator.bool.valid.175 = or i1 %validator.bool.true.173, %validator.bool.false.174
  br i1 %validator.bool.valid.175, label %validator.bool.check.176, label %validator.bool.invalid.177
validator.bool.invalid.177:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 70, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.bool.check.176:
  br i1 %validator.bool.true.173, label %validator.true.179, label %validator.false.178
validator.false.178:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 69, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.true.179:
  br label %validator.join.180
validator.join.180:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.resume.validation.succeeded.181
mailbox.resume.validation.failure.104:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.resume.failure.0
mailbox.resume.validation.succeeded.181:
  %mailbox.frame.status.183 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.182, i32 66)
  %helper.ok.184 = icmp eq i32 %mailbox.frame.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %mailbox.resume.failure.0
helper.continue.185:
  %descriptor.element.186 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.182, i32 0
  %descriptor.field.187 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.186, i32 0, i32 0
  %descriptor.value.188 = load i32, ptr %descriptor.field.187, align 4
  %descriptor.field.189 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.186, i32 0, i32 1
  %descriptor.value.190 = load i32, ptr %descriptor.field.189, align 4
  %descriptor.field.191 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.186, i32 0, i32 2
  %descriptor.value.192 = load i32, ptr %descriptor.field.191, align 4
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.186, i32 0, i32 3
  %descriptor.value.194 = load i32, ptr %descriptor.field.193, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.186, i32 0, i32 4
  %descriptor.value.196 = load i32, ptr %descriptor.field.195, align 4
  %mailbox.output.type.matches.197 = icmp eq i32 %descriptor.value.188, 5
  br i1 %mailbox.output.type.matches.197, label %mailbox.output.type.ok.198, label %mailbox.output.type.invalid.199
mailbox.output.type.invalid.199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
mailbox.output.type.ok.198:
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %stack.sub.204 = sub i32 %descriptor.value.196, %descriptor.value.190
  %descriptor.owner.inside.202 = icmp ule i32 %descriptor.value.196, %context.value.201
  %descriptor.offset.inside.203 = icmp ule i32 %descriptor.value.190, %descriptor.value.196
  %descriptor.extent.inside.205 = icmp ule i32 %descriptor.value.192, %stack.sub.204
  %descriptor.payload.inside.206 = icmp ule i32 %descriptor.value.194, %descriptor.value.192
  %descriptor.owner.offset.valid.207 = and i1 %descriptor.owner.inside.202, %descriptor.offset.inside.203
  %descriptor.range.inside.209 = and i1 %descriptor.owner.offset.valid.207, %descriptor.extent.inside.205
  %descriptor.range.valid.208 = and i1 %descriptor.range.inside.209, %descriptor.payload.inside.206
  %descriptor.type.valid.210 = icmp eq i32 5, 5
  %descriptor.valid.211 = and i1 %descriptor.range.valid.208, %descriptor.type.valid.210
  br i1 %descriptor.valid.211, label %descriptor.valid.212, label %descriptor.invalid.213
descriptor.invalid.213:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
descriptor.valid.212:
  %descriptor.initialized.status.214 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.190, i32 %descriptor.value.192)
  %helper.ok.215 = icmp eq i32 %descriptor.initialized.status.214, 0
  br i1 %helper.ok.215, label %helper.continue.216, label %mailbox.resume.failure.0
helper.continue.216:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.190, i32 20, i32 %descriptor.value.194, i32 %descriptor.value.196, i32 %descriptor.value.192)
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %runtime.ok.219 = icmp eq i32 %context.value.218, 0
  br i1 %runtime.ok.219, label %runtime.continue.220, label %mailbox.resume.failure.0
runtime.continue.220:
  %mailbox.output.descriptor.221 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.222 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.221, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.222, align 4
  %mailbox.output.field.223 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.221, i32 0, i32 1
  store i32 %descriptor.value.190, ptr %mailbox.output.field.223, align 4
  %mailbox.output.field.224 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.221, i32 0, i32 2
  store i32 %descriptor.value.196, ptr %mailbox.output.field.224, align 4
  %mailbox.output.field.225 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.221, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.225, align 4
  ret i32 0
mailbox.resume.failure.0:
  %mailbox.failure.context.null.226 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.226, label %mailbox.failure.null.context.228, label %mailbox.failure.has.context.227
mailbox.failure.null.context.228:
  ret i32 4
mailbox.failure.has.context.227:
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %mailbox.failure.status.set.232 = icmp ne i32 %context.value.231, 0
  br i1 %mailbox.failure.status.set.232, label %mailbox.failure.status.ready.229, label %mailbox.failure.set.fallback.233
mailbox.failure.set.fallback.233:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 61, i32 0, i32 0)
  br label %mailbox.failure.status.ready.229
mailbox.failure.status.ready.229:
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  ret i32 %context.value.235
}


define i32 @agentlang_mailbox_resume_associated(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity) {
entry:
  %associated.resume.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %associated.resume.retained.value.size.18 = alloca %AlOwningValueSize, align 4
  %associated.resume.retained.value.size.41 = alloca %AlOwningValueSize, align 4
  %associated.resume.completion.payload.pointer.63 = alloca i32, align 4
  %associated.resume.completion.measured.extent.pointer.64 = alloca i32, align 4
  %associated.resume.output.descriptors.92 = alloca [1 x %AlOwningDescriptor], align 4
  %associated.resume.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %associated.resume.context.nonnull.3, label %associated.resume.context.valid.1, label %associated.resume.failure.0
associated.resume.context.valid.1:
  %associated.resume.preflight.status.4 = call i32 @agentlang_owning_mailbox_associated_preflight(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity, i32 72, i32 73, i32 74)
  %associated.resume.preflight.ok.5 = icmp eq i32 %associated.resume.preflight.status.4, 0
  br i1 %associated.resume.preflight.ok.5, label %associated.resume.preflight.ready.2, label %associated.resume.failure.0
associated.resume.preflight.ready.2:
  %associated.resume.output.descriptor.6 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %associated.resume.output.field.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 4294967295, ptr %associated.resume.output.field.7, align 4
  %associated.resume.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 0, ptr %associated.resume.output.field.8, align 4
  %associated.resume.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 0, ptr %associated.resume.output.field.9, align 4
  %associated.resume.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.10, align 4
  %context.field.11 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 10
  store i32 0, ptr %context.field.11, align 4
  %associated.resume.retained.slice.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 0
  %associated.resume.retained.offset.pointer.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.15 = load i32, ptr %associated.resume.retained.offset.pointer.14, align 4
  %associated.resume.retained.owner.end.pointer.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.17 = load i32, ptr %associated.resume.retained.owner.end.pointer.16, align 4
  %associated.resume.retained.measure.status.19 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %associated.resume.retained.offset.pointer.value.15, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 75, ptr %associated.resume.retained.value.size.18)
  %helper.ok.20 = icmp eq i32 %associated.resume.retained.measure.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %associated.resume.failure.0
helper.continue.21:
  %associated.resume.retained.payload.pointer.22 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 0
  %associated.resume.retained.extent.pointer.23 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 1
  %associated.resume.retained.payload.24 = load i32, ptr %associated.resume.retained.payload.pointer.22, align 4
  %associated.resume.retained.extent.25 = load i32, ptr %associated.resume.retained.extent.pointer.23, align 4
  %descriptor.element.26 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 0
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 0
  store i32 5, ptr %descriptor.field.27, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.15, ptr %descriptor.field.28, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 2
  store i32 %associated.resume.retained.extent.25, ptr %descriptor.field.29, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 3
  store i32 %associated.resume.retained.payload.24, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.17, ptr %descriptor.field.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %associated.resume.retained.offset.pointer.value.15, i32 20, i32 %associated.resume.retained.payload.24, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 %associated.resume.retained.extent.25)
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %runtime.ok.34 = icmp eq i32 %context.value.33, 0
  br i1 %runtime.ok.34, label %runtime.continue.35, label %associated.resume.failure.0
runtime.continue.35:
  %associated.resume.retained.slice.36 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 1
  %associated.resume.retained.offset.pointer.37 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.38 = load i32, ptr %associated.resume.retained.offset.pointer.37, align 4
  %associated.resume.retained.owner.end.pointer.39 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.40 = load i32, ptr %associated.resume.retained.owner.end.pointer.39, align 4
  %associated.resume.retained.measure.status.42 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %associated.resume.retained.offset.pointer.value.38, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 75, ptr %associated.resume.retained.value.size.41)
  %helper.ok.43 = icmp eq i32 %associated.resume.retained.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %associated.resume.failure.0
helper.continue.44:
  %associated.resume.retained.payload.pointer.45 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 0
  %associated.resume.retained.extent.pointer.46 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 1
  %associated.resume.retained.payload.47 = load i32, ptr %associated.resume.retained.payload.pointer.45, align 4
  %associated.resume.retained.extent.48 = load i32, ptr %associated.resume.retained.extent.pointer.46, align 4
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 1
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  store i32 4, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.38, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  store i32 %associated.resume.retained.extent.48, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  store i32 %associated.resume.retained.payload.47, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.40, ptr %descriptor.field.54, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %associated.resume.retained.offset.pointer.value.38, i32 20, i32 %associated.resume.retained.payload.47, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 %associated.resume.retained.extent.48)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %associated.resume.failure.0
runtime.continue.58:
  %associated.resume.completion.bytes.pointer.59 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 0
  %associated.resume.completion.bytes.60 = load ptr, ptr %associated.resume.completion.bytes.pointer.59, align 8
  %associated.resume.completion.extent.pointer.61 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 1
  %associated.resume.completion.extent.62 = load i32, ptr %associated.resume.completion.extent.pointer.61, align 4
  %associated.resume.completion.measure.status.65 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 75, ptr %associated.resume.completion.payload.pointer.63, ptr %associated.resume.completion.measured.extent.pointer.64)
  %helper.ok.66 = icmp eq i32 %associated.resume.completion.measure.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %associated.resume.failure.0
helper.continue.67:
  %associated.resume.completion.payload.68 = load i32, ptr %associated.resume.completion.payload.pointer.63, align 4
  %associated.resume.completion.measured.extent.69 = load i32, ptr %associated.resume.completion.measured.extent.pointer.64, align 4
  %associated.resume.completion.extent.matches.70 = icmp eq i32 %associated.resume.completion.measured.extent.69, %associated.resume.completion.extent.62
  br i1 %associated.resume.completion.extent.matches.70, label %associated.resume.completion.extent.ok.71, label %associated.resume.failure.0
associated.resume.completion.extent.ok.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.offset.74 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %reserve.status.75 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.74, i32 76)
  %reserve.ok.76 = icmp eq i32 %reserve.status.75, 0
  br i1 %reserve.ok.76, label %reserve.continue.77, label %associated.resume.failure.0
reserve.continue.77:
  %associated.resume.completion.copy.status.78 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %context.value.73, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 %associated.resume.completion.payload.68, i32 %associated.resume.completion.extent.62, i32 7, i32 76)
  %helper.ok.79 = icmp eq i32 %associated.resume.completion.copy.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %associated.resume.failure.0
helper.continue.80:
  %stack.offset.81 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 2
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  store i32 7, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  store i32 %context.value.73, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  store i32 %associated.resume.completion.extent.62, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  store i32 %associated.resume.completion.payload.68, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  store i32 %stack.offset.81, ptr %descriptor.field.87, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %context.value.73, i32 20, i32 %associated.resume.completion.payload.68, i32 %stack.offset.81, i32 %associated.resume.completion.extent.62)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %associated.resume.failure.0
runtime.continue.91:
  %associated.resume.frame.status.93 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %associated.resume.input.descriptors.12, ptr %associated.resume.output.descriptors.92, i32 77)
  %helper.ok.94 = icmp eq i32 %associated.resume.frame.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %associated.resume.failure.0
helper.continue.95:
  %descriptor.element.96 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.output.descriptors.92, i32 0
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 0
  %descriptor.value.98 = load i32, ptr %descriptor.field.97, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 1
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 2
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 3
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 4
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %associated.resume.output.type.matches.107 = icmp eq i32 %descriptor.value.98, 5
  br i1 %associated.resume.output.type.matches.107, label %associated.resume.output.type.ok.108, label %associated.resume.failure.0
associated.resume.output.type.ok.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %descriptor.value.106, %descriptor.value.100
  %descriptor.owner.inside.111 = icmp ule i32 %descriptor.value.106, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %descriptor.value.100, %descriptor.value.106
  %descriptor.extent.inside.114 = icmp ule i32 %descriptor.value.102, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %descriptor.value.104, %descriptor.value.102
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 5, 5
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %associated.resume.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.100, i32 %descriptor.value.102)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %associated.resume.failure.0
helper.continue.125:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.100, i32 20, i32 %descriptor.value.104, i32 %descriptor.value.106, i32 %descriptor.value.102)
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %runtime.ok.128 = icmp eq i32 %context.value.127, 0
  br i1 %runtime.ok.128, label %runtime.continue.129, label %associated.resume.failure.0
runtime.continue.129:
  %associated.resume.output.field.130 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 3, ptr %associated.resume.output.field.130, align 4
  %associated.resume.output.field.131 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 %descriptor.value.100, ptr %associated.resume.output.field.131, align 4
  %associated.resume.output.field.132 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 %descriptor.value.106, ptr %associated.resume.output.field.132, align 4
  %associated.resume.output.field.133 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.133, align 4
  ret i32 0
associated.resume.failure.0:
  %associated.resume.failure.context.null.134 = icmp eq ptr %ctx, null
  br i1 %associated.resume.failure.context.null.134, label %associated.resume.failure.null.context.136, label %associated.resume.failure.has.context.135
associated.resume.failure.null.context.136:
  ret i32 4
associated.resume.failure.has.context.135:
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %associated.resume.failure.status.set.140 = icmp ne i32 %context.value.139, 0
  br i1 %associated.resume.failure.status.set.140, label %associated.resume.failure.status.ready.137, label %associated.resume.failure.set.fallback.141
associated.resume.failure.set.fallback.141:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 72, i32 0, i32 0)
  br label %associated.resume.failure.status.ready.137
associated.resume.failure.status.ready.137:
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  ret i32 %context.value.143
}



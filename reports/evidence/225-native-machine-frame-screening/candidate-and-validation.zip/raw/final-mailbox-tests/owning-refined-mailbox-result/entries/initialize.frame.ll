define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 24
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  %literal.status.64 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.59, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 24, i32 24, i32 7, i32 5)
  %helper.ok.65 = icmp eq i32 %literal.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %frame.failure.0
helper.continue.66:
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %stack.sub.71 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.69 = icmp ule i32 %stack.offset.60, %context.value.68
  %descriptor.offset.inside.70 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.72 = icmp ule i32 24, %stack.sub.71
  %descriptor.payload.inside.73 = icmp ule i32 24, 24
  %descriptor.owner.offset.valid.74 = and i1 %descriptor.owner.inside.69, %descriptor.offset.inside.70
  %descriptor.range.inside.76 = and i1 %descriptor.owner.offset.valid.74, %descriptor.extent.inside.72
  %descriptor.range.valid.75 = and i1 %descriptor.range.inside.76, %descriptor.payload.inside.73
  %descriptor.type.valid.77 = icmp eq i32 7, 7
  %descriptor.valid.78 = and i1 %descriptor.range.valid.75, %descriptor.type.valid.77
  br i1 %descriptor.valid.78, label %descriptor.valid.79, label %descriptor.invalid.80
descriptor.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.79:
  %descriptor.initialized.status.81 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 24)
  %helper.ok.82 = icmp eq i32 %descriptor.initialized.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %step.status.84 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.85 = icmp eq i32 %step.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %stack.offset.89 = add i32 8, 24
  %stack.offset.90 = add i32 8, 24
  %stack.offset.91 = add i32 %context.value.88, %stack.offset.89
  %reserve.status.92 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.91, i32 7)
  %reserve.ok.93 = icmp eq i32 %reserve.status.92, 0
  br i1 %reserve.ok.93, label %reserve.continue.94, label %frame.failure.0
reserve.continue.94:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.88, i64 1, i32 9)
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %runtime.ok.97 = icmp eq i32 %context.value.96, 0
  br i1 %runtime.ok.97, label %runtime.continue.98, label %frame.failure.0
runtime.continue.98:
  %stack.offset.99 = add i32 %context.value.88, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.99, i32 %context.value.59, i32 24, i32 24, i32 7, i32 6)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 9, i32 %context.value.88, i32 %stack.offset.89, i32 %stack.offset.90, i32 %context.value.59, i32 24)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %stack.offset.91, %context.value.88
  %descriptor.owner.inside.114 = icmp ule i32 %stack.offset.91, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %context.value.88, %stack.offset.91
  %descriptor.extent.inside.117 = icmp ule i32 %stack.offset.89, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %stack.offset.90, %stack.offset.89
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 9, 9
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.88, i32 %stack.offset.89)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %frame.failure.0
helper.continue.128:
  %step.status.129 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.130 = icmp eq i32 %step.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %inline.target.depth.within.interpreter.limit.134 = icmp ule i32 %context.value.133, 65
  br i1 %inline.target.depth.within.interpreter.limit.134, label %inline.target.depth.ok.135, label %inline.target.depth.invalid.136
inline.target.depth.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.135:
  %stack.offset.137 = add i32 0, %stack.offset.90
  %stack.offset.138 = add i32 0, %stack.offset.89
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.140, %stack.offset.138
  %reserve.status.142 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.141, i32 10)
  %reserve.ok.143 = icmp eq i32 %reserve.status.142, 0
  br i1 %reserve.ok.143, label %reserve.continue.144, label %frame.failure.0
reserve.continue.144:
  %stack.offset.145 = add i32 %context.value.140, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.145, i32 %context.value.88, i32 %stack.offset.89, i32 %stack.offset.90, i32 9, i32 6)
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %runtime.ok.148 = icmp eq i32 %context.value.147, 0
  br i1 %runtime.ok.148, label %runtime.continue.149, label %frame.failure.0
runtime.continue.149:
  %stack.offset.150 = add i32 0, %stack.offset.89
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.140, i32 %stack.offset.138, i32 %stack.offset.137, i32 0, i32 0)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %stack.sub.159 = sub i32 %stack.offset.141, %context.value.140
  %descriptor.owner.inside.157 = icmp ule i32 %stack.offset.141, %context.value.156
  %descriptor.offset.inside.158 = icmp ule i32 %context.value.140, %stack.offset.141
  %descriptor.extent.inside.160 = icmp ule i32 %stack.offset.138, %stack.sub.159
  %descriptor.payload.inside.161 = icmp ule i32 %stack.offset.137, %stack.offset.138
  %descriptor.owner.offset.valid.162 = and i1 %descriptor.owner.inside.157, %descriptor.offset.inside.158
  %descriptor.range.inside.164 = and i1 %descriptor.owner.offset.valid.162, %descriptor.extent.inside.160
  %descriptor.range.valid.163 = and i1 %descriptor.range.inside.164, %descriptor.payload.inside.161
  %descriptor.type.valid.165 = icmp eq i32 5, 5
  %descriptor.valid.166 = and i1 %descriptor.range.valid.163, %descriptor.type.valid.165
  br i1 %descriptor.valid.166, label %descriptor.valid.167, label %descriptor.invalid.168
descriptor.invalid.168:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.167:
  %descriptor.initialized.status.169 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.140, i32 %stack.offset.138)
  %helper.ok.170 = icmp eq i32 %descriptor.initialized.status.169, 0
  br i1 %helper.ok.170, label %helper.continue.171, label %frame.failure.0
helper.continue.171:
  %descriptor.element.172 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.173 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 0
  store i32 5, ptr %descriptor.field.173, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 1
  store i32 %context.value.140, ptr %descriptor.field.174, align 4
  %descriptor.field.175 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 2
  store i32 %stack.offset.138, ptr %descriptor.field.175, align 4
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 3
  store i32 %stack.offset.137, ptr %descriptor.field.176, align 4
  %descriptor.field.177 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 4
  store i32 %stack.offset.141, ptr %descriptor.field.177, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.140, i32 20, i32 %stack.offset.137, i32 %stack.offset.141, i32 %stack.offset.138)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %context.field.184 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.185 = load i32, ptr %context.field.184, align 4
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %stack.offset.188 = add i32 %context.value.5, %context.value.7
  %stack.offset.189 = add i32 %context.value.183, %context.value.185
  %stack.sub.190 = sub i32 %stack.offset.188, %stack.offset.189
  %stack.sub.191 = sub i32 %context.value.7, %context.value.185
  %stack.sub.192 = sub i32 %context.value.187, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.190, i32 %stack.sub.191)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.192)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


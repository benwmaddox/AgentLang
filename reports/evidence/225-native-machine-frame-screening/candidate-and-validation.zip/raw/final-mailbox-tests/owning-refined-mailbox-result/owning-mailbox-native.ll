%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [7 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 1, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 1, i32 1, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 6, i32 2, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 8, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 5, i32 8, i32 0, i32 0 }], align 4
@agentlang_owning_mailbox_layout = constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 7, ptr @al_owning_fields, i32 4 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [24 x i8] c"\08\00\00\00\00\00\00\00\69\00\6E\00\61\00\63\00\74\00\69\00\76\00\65\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare i32 @agentlang_owning_mailbox_preflight(ptr, ptr, i32, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @agentlang_owning_mailbox_associated_preflight(ptr, ptr, i32, ptr, i32, ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 24
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  %literal.status.64 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.59, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 24, i32 24, i32 7, i32 5)
  %helper.ok.65 = icmp eq i32 %literal.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %frame.failure.0
helper.continue.66:
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %stack.sub.71 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.69 = icmp ule i32 %stack.offset.60, %context.value.68
  %descriptor.offset.inside.70 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.72 = icmp ule i32 24, %stack.sub.71
  %descriptor.payload.inside.73 = icmp ule i32 24, 24
  %descriptor.owner.offset.valid.74 = and i1 %descriptor.owner.inside.69, %descriptor.offset.inside.70
  %descriptor.range.inside.76 = and i1 %descriptor.owner.offset.valid.74, %descriptor.extent.inside.72
  %descriptor.range.valid.75 = and i1 %descriptor.range.inside.76, %descriptor.payload.inside.73
  %descriptor.type.valid.77 = icmp eq i32 7, 7
  %descriptor.valid.78 = and i1 %descriptor.range.valid.75, %descriptor.type.valid.77
  br i1 %descriptor.valid.78, label %descriptor.valid.79, label %descriptor.invalid.80
descriptor.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.79:
  %descriptor.initialized.status.81 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 24)
  %helper.ok.82 = icmp eq i32 %descriptor.initialized.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %step.status.84 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.85 = icmp eq i32 %step.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %stack.offset.89 = add i32 8, 24
  %stack.offset.90 = add i32 8, 24
  %stack.offset.91 = add i32 %context.value.88, %stack.offset.89
  %reserve.status.92 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.91, i32 7)
  %reserve.ok.93 = icmp eq i32 %reserve.status.92, 0
  br i1 %reserve.ok.93, label %reserve.continue.94, label %frame.failure.0
reserve.continue.94:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.88, i64 1, i32 9)
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %runtime.ok.97 = icmp eq i32 %context.value.96, 0
  br i1 %runtime.ok.97, label %runtime.continue.98, label %frame.failure.0
runtime.continue.98:
  %stack.offset.99 = add i32 %context.value.88, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.99, i32 %context.value.59, i32 24, i32 24, i32 7, i32 6)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 9, i32 %context.value.88, i32 %stack.offset.89, i32 %stack.offset.90, i32 %context.value.59, i32 24)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %stack.offset.91, %context.value.88
  %descriptor.owner.inside.114 = icmp ule i32 %stack.offset.91, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %context.value.88, %stack.offset.91
  %descriptor.extent.inside.117 = icmp ule i32 %stack.offset.89, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %stack.offset.90, %stack.offset.89
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 9, 9
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.88, i32 %stack.offset.89)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %frame.failure.0
helper.continue.128:
  %step.status.129 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.130 = icmp eq i32 %step.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %inline.target.depth.within.interpreter.limit.134 = icmp ule i32 %context.value.133, 65
  br i1 %inline.target.depth.within.interpreter.limit.134, label %inline.target.depth.ok.135, label %inline.target.depth.invalid.136
inline.target.depth.invalid.136:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.135:
  %stack.offset.137 = add i32 0, %stack.offset.90
  %stack.offset.138 = add i32 0, %stack.offset.89
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.140, %stack.offset.138
  %reserve.status.142 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.141, i32 10)
  %reserve.ok.143 = icmp eq i32 %reserve.status.142, 0
  br i1 %reserve.ok.143, label %reserve.continue.144, label %frame.failure.0
reserve.continue.144:
  %stack.offset.145 = add i32 %context.value.140, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.145, i32 %context.value.88, i32 %stack.offset.89, i32 %stack.offset.90, i32 9, i32 6)
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %runtime.ok.148 = icmp eq i32 %context.value.147, 0
  br i1 %runtime.ok.148, label %runtime.continue.149, label %frame.failure.0
runtime.continue.149:
  %stack.offset.150 = add i32 0, %stack.offset.89
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.140, i32 %stack.offset.138, i32 %stack.offset.137, i32 0, i32 0)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %frame.failure.0
runtime.continue.154:
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %stack.sub.159 = sub i32 %stack.offset.141, %context.value.140
  %descriptor.owner.inside.157 = icmp ule i32 %stack.offset.141, %context.value.156
  %descriptor.offset.inside.158 = icmp ule i32 %context.value.140, %stack.offset.141
  %descriptor.extent.inside.160 = icmp ule i32 %stack.offset.138, %stack.sub.159
  %descriptor.payload.inside.161 = icmp ule i32 %stack.offset.137, %stack.offset.138
  %descriptor.owner.offset.valid.162 = and i1 %descriptor.owner.inside.157, %descriptor.offset.inside.158
  %descriptor.range.inside.164 = and i1 %descriptor.owner.offset.valid.162, %descriptor.extent.inside.160
  %descriptor.range.valid.163 = and i1 %descriptor.range.inside.164, %descriptor.payload.inside.161
  %descriptor.type.valid.165 = icmp eq i32 5, 5
  %descriptor.valid.166 = and i1 %descriptor.range.valid.163, %descriptor.type.valid.165
  br i1 %descriptor.valid.166, label %descriptor.valid.167, label %descriptor.invalid.168
descriptor.invalid.168:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.167:
  %descriptor.initialized.status.169 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.140, i32 %stack.offset.138)
  %helper.ok.170 = icmp eq i32 %descriptor.initialized.status.169, 0
  br i1 %helper.ok.170, label %helper.continue.171, label %frame.failure.0
helper.continue.171:
  %descriptor.element.172 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.173 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 0
  store i32 5, ptr %descriptor.field.173, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 1
  store i32 %context.value.140, ptr %descriptor.field.174, align 4
  %descriptor.field.175 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 2
  store i32 %stack.offset.138, ptr %descriptor.field.175, align 4
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 3
  store i32 %stack.offset.137, ptr %descriptor.field.176, align 4
  %descriptor.field.177 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.172, i32 0, i32 4
  store i32 %stack.offset.141, ptr %descriptor.field.177, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.140, i32 20, i32 %stack.offset.137, i32 %stack.offset.141, i32 %stack.offset.138)
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %runtime.ok.180 = icmp eq i32 %context.value.179, 0
  br i1 %runtime.ok.180, label %runtime.continue.181, label %frame.failure.0
runtime.continue.181:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %context.field.184 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.185 = load i32, ptr %context.field.184, align 4
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %stack.offset.188 = add i32 %context.value.5, %context.value.7
  %stack.offset.189 = add i32 %context.value.183, %context.value.185
  %stack.sub.190 = sub i32 %stack.offset.188, %stack.offset.189
  %stack.sub.191 = sub i32 %context.value.7, %context.value.185
  %stack.sub.192 = sub i32 %context.value.187, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.190, i32 %stack.sub.191)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.192)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 7
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 7, 7
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %inline.target.depth.within.interpreter.limit.78 = icmp ule i32 %context.value.77, 65
  br i1 %inline.target.depth.within.interpreter.limit.78, label %inline.target.depth.ok.79, label %inline.target.depth.invalid.80
inline.target.depth.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 12, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.79:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %frame.failure.0
runtime.continue.84:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.sub.89 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.87 = icmp ule i32 %descriptor.value.23, %context.value.86
  %descriptor.offset.inside.88 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.90 = icmp ule i32 %descriptor.value.19, %stack.sub.89
  %descriptor.payload.inside.91 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.92 = and i1 %descriptor.owner.inside.87, %descriptor.offset.inside.88
  %descriptor.range.inside.94 = and i1 %descriptor.owner.offset.valid.92, %descriptor.extent.inside.90
  %descriptor.range.valid.93 = and i1 %descriptor.range.inside.94, %descriptor.payload.inside.91
  %descriptor.type.valid.95 = icmp eq i32 5, 5
  %descriptor.valid.96 = and i1 %descriptor.range.valid.93, %descriptor.type.valid.95
  br i1 %descriptor.valid.96, label %descriptor.valid.97, label %descriptor.invalid.98
descriptor.invalid.98:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.97:
  %descriptor.initialized.status.99 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.100 = icmp eq i32 %descriptor.initialized.status.99, 0
  br i1 %helper.ok.100, label %helper.continue.101, label %frame.failure.0
helper.continue.101:
  %step.status.102 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.103 = icmp eq i32 %step.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %stack.offset.107 = add i32 %context.value.106, 8
  %reserve.status.108 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.107, i32 14)
  %reserve.ok.109 = icmp eq i32 %reserve.status.108, 0
  br i1 %reserve.ok.109, label %reserve.continue.110, label %frame.failure.0
reserve.continue.110:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.106, i64 1, i32 1)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %runtime.ok.117 = icmp eq i32 %context.value.116, 0
  br i1 %runtime.ok.117, label %runtime.continue.118, label %frame.failure.0
runtime.continue.118:
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.121 = icmp ule i32 %descriptor.value.23, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.124 = icmp ule i32 %descriptor.value.19, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  %descriptor.type.valid.129 = icmp eq i32 5, 5
  %descriptor.valid.130 = and i1 %descriptor.range.valid.127, %descriptor.type.valid.129
  br i1 %descriptor.valid.130, label %descriptor.valid.131, label %descriptor.invalid.132
descriptor.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.131:
  %descriptor.initialized.status.133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.134 = icmp eq i32 %descriptor.initialized.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %stack.sub.140 = sub i32 %stack.offset.107, %context.value.106
  %descriptor.owner.inside.138 = icmp ule i32 %stack.offset.107, %context.value.137
  %descriptor.offset.inside.139 = icmp ule i32 %context.value.106, %stack.offset.107
  %descriptor.extent.inside.141 = icmp ule i32 8, %stack.sub.140
  %descriptor.payload.inside.142 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.143 = and i1 %descriptor.owner.inside.138, %descriptor.offset.inside.139
  %descriptor.range.inside.145 = and i1 %descriptor.owner.offset.valid.143, %descriptor.extent.inside.141
  %descriptor.range.valid.144 = and i1 %descriptor.range.inside.145, %descriptor.payload.inside.142
  %descriptor.type.valid.146 = icmp eq i32 1, 1
  %descriptor.valid.147 = and i1 %descriptor.range.valid.144, %descriptor.type.valid.146
  br i1 %descriptor.valid.147, label %descriptor.valid.148, label %descriptor.invalid.149
descriptor.invalid.149:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.148:
  %descriptor.initialized.status.150 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.106, i32 8)
  %helper.ok.151 = icmp eq i32 %descriptor.initialized.status.150, 0
  br i1 %helper.ok.151, label %helper.continue.152, label %frame.failure.0
helper.continue.152:
  %step.status.153 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.154 = icmp eq i32 %step.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %inline.target.depth.within.interpreter.limit.158 = icmp ule i32 %context.value.157, 65
  br i1 %inline.target.depth.within.interpreter.limit.158, label %inline.target.depth.ok.159, label %inline.target.depth.invalid.160
inline.target.depth.invalid.160:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 16, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.159:
  %stack.offset.161 = add i32 0, 8
  %stack.offset.162 = add i32 0, 8
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %stack.offset.165 = add i32 %context.value.164, %stack.offset.162
  %reserve.status.166 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.165, i32 17)
  %reserve.ok.167 = icmp eq i32 %reserve.status.166, 0
  br i1 %reserve.ok.167, label %reserve.continue.168, label %frame.failure.0
reserve.continue.168:
  %stack.offset.169 = add i32 %context.value.164, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.169, i32 %context.value.106, i32 8, i32 8, i32 1, i32 6)
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %runtime.ok.172 = icmp eq i32 %context.value.171, 0
  br i1 %runtime.ok.172, label %runtime.continue.173, label %frame.failure.0
runtime.continue.173:
  %stack.offset.174 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.164, i32 %stack.offset.162, i32 %stack.offset.161, i32 0, i32 0)
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %runtime.ok.177 = icmp eq i32 %context.value.176, 0
  br i1 %runtime.ok.177, label %runtime.continue.178, label %frame.failure.0
runtime.continue.178:
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %stack.sub.183 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.181 = icmp ule i32 %descriptor.value.23, %context.value.180
  %descriptor.offset.inside.182 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.184 = icmp ule i32 %descriptor.value.19, %stack.sub.183
  %descriptor.payload.inside.185 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.186 = and i1 %descriptor.owner.inside.181, %descriptor.offset.inside.182
  %descriptor.range.inside.188 = and i1 %descriptor.owner.offset.valid.186, %descriptor.extent.inside.184
  %descriptor.range.valid.187 = and i1 %descriptor.range.inside.188, %descriptor.payload.inside.185
  %descriptor.type.valid.189 = icmp eq i32 5, 5
  %descriptor.valid.190 = and i1 %descriptor.range.valid.187, %descriptor.type.valid.189
  br i1 %descriptor.valid.190, label %descriptor.valid.191, label %descriptor.invalid.192
descriptor.invalid.192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.191:
  %descriptor.initialized.status.193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.194 = icmp eq i32 %descriptor.initialized.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %frame.failure.0
helper.continue.195:
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %stack.sub.200 = sub i32 %stack.offset.165, %context.value.164
  %descriptor.owner.inside.198 = icmp ule i32 %stack.offset.165, %context.value.197
  %descriptor.offset.inside.199 = icmp ule i32 %context.value.164, %stack.offset.165
  %descriptor.extent.inside.201 = icmp ule i32 %stack.offset.162, %stack.sub.200
  %descriptor.payload.inside.202 = icmp ule i32 %stack.offset.161, %stack.offset.162
  %descriptor.owner.offset.valid.203 = and i1 %descriptor.owner.inside.198, %descriptor.offset.inside.199
  %descriptor.range.inside.205 = and i1 %descriptor.owner.offset.valid.203, %descriptor.extent.inside.201
  %descriptor.range.valid.204 = and i1 %descriptor.range.inside.205, %descriptor.payload.inside.202
  %descriptor.type.valid.206 = icmp eq i32 4, 4
  %descriptor.valid.207 = and i1 %descriptor.range.valid.204, %descriptor.type.valid.206
  br i1 %descriptor.valid.207, label %descriptor.valid.208, label %descriptor.invalid.209
descriptor.invalid.209:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.208:
  %descriptor.initialized.status.210 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.164, i32 %stack.offset.162)
  %helper.ok.211 = icmp eq i32 %descriptor.initialized.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 5, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  %descriptor.element.223 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 0
  store i32 4, ptr %descriptor.field.224, align 4
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 1
  store i32 %context.value.164, ptr %descriptor.field.225, align 4
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 2
  store i32 %stack.offset.162, ptr %descriptor.field.226, align 4
  %descriptor.field.227 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 3
  store i32 %stack.offset.161, ptr %descriptor.field.227, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.223, i32 0, i32 4
  store i32 %stack.offset.165, ptr %descriptor.field.228, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.164, i32 20, i32 %stack.offset.161, i32 %stack.offset.165, i32 %stack.offset.162)
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %runtime.ok.231 = icmp eq i32 %context.value.230, 0
  br i1 %runtime.ok.231, label %runtime.continue.232, label %frame.failure.0
runtime.continue.232:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %context.field.235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.236 = load i32, ptr %context.field.235, align 4
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %stack.offset.239 = add i32 %context.value.5, %context.value.7
  %stack.offset.240 = add i32 %context.value.234, %context.value.236
  %stack.sub.241 = sub i32 %stack.offset.239, %stack.offset.240
  %stack.sub.242 = sub i32 %context.value.7, %context.value.236
  %stack.sub.243 = sub i32 %context.value.238, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.241, i32 %stack.sub.242)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.243)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 7
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 7, 7
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %inline.target.depth.within.interpreter.limit.108 = icmp ule i32 %context.value.107, 65
  br i1 %inline.target.depth.within.interpreter.limit.108, label %inline.target.depth.ok.109, label %inline.target.depth.invalid.110
inline.target.depth.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 19, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.109:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.77, i32 %descriptor.value.79, i32 %descriptor.value.81, i32 0, i32 0)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %frame.failure.0
runtime.continue.114:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %stack.sub.119 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.117 = icmp ule i32 %descriptor.value.23, %context.value.116
  %descriptor.offset.inside.118 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.120 = icmp ule i32 %descriptor.value.19, %stack.sub.119
  %descriptor.payload.inside.121 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.122 = and i1 %descriptor.owner.inside.117, %descriptor.offset.inside.118
  %descriptor.range.inside.124 = and i1 %descriptor.owner.offset.valid.122, %descriptor.extent.inside.120
  %descriptor.range.valid.123 = and i1 %descriptor.range.inside.124, %descriptor.payload.inside.121
  %descriptor.type.valid.125 = icmp eq i32 5, 5
  %descriptor.valid.126 = and i1 %descriptor.range.valid.123, %descriptor.type.valid.125
  br i1 %descriptor.valid.126, label %descriptor.valid.127, label %descriptor.invalid.128
descriptor.invalid.128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.127:
  %descriptor.initialized.status.129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.130 = icmp eq i32 %descriptor.initialized.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.134 = icmp ule i32 %descriptor.value.53, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.137 = icmp ule i32 %descriptor.value.49, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  %descriptor.type.valid.142 = icmp eq i32 4, 4
  %descriptor.valid.143 = and i1 %descriptor.range.valid.140, %descriptor.type.valid.142
  br i1 %descriptor.valid.143, label %descriptor.valid.144, label %descriptor.invalid.145
descriptor.invalid.145:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.144:
  %descriptor.initialized.status.146 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.147 = icmp eq i32 %descriptor.initialized.status.146, 0
  br i1 %helper.ok.147, label %helper.continue.148, label %frame.failure.0
helper.continue.148:
  %step.status.149 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.150 = icmp eq i32 %step.status.149, 0
  br i1 %helper.ok.150, label %helper.continue.151, label %frame.failure.0
helper.continue.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %inline.target.depth.within.interpreter.limit.154 = icmp ule i32 %context.value.153, 65
  br i1 %inline.target.depth.within.interpreter.limit.154, label %inline.target.depth.ok.155, label %inline.target.depth.invalid.156
inline.target.depth.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.155:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 4, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 %descriptor.value.51, i32 0, i32 0)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %stack.sub.165 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.163 = icmp ule i32 %descriptor.value.23, %context.value.162
  %descriptor.offset.inside.164 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.166 = icmp ule i32 %descriptor.value.19, %stack.sub.165
  %descriptor.payload.inside.167 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.168 = and i1 %descriptor.owner.inside.163, %descriptor.offset.inside.164
  %descriptor.range.inside.170 = and i1 %descriptor.owner.offset.valid.168, %descriptor.extent.inside.166
  %descriptor.range.valid.169 = and i1 %descriptor.range.inside.170, %descriptor.payload.inside.167
  %descriptor.type.valid.171 = icmp eq i32 5, 5
  %descriptor.valid.172 = and i1 %descriptor.range.valid.169, %descriptor.type.valid.171
  br i1 %descriptor.valid.172, label %descriptor.valid.173, label %descriptor.invalid.174
descriptor.invalid.174:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.173:
  %descriptor.initialized.status.175 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.176 = icmp eq i32 %descriptor.initialized.status.175, 0
  br i1 %helper.ok.176, label %helper.continue.177, label %frame.failure.0
helper.continue.177:
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.180 = sub i32 %context.value.179, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.180, i32 0, i32 0, i32 0)
  %context.field.181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.182 = load i32, ptr %context.field.181, align 4
  %runtime.ok.183 = icmp eq i32 %context.value.182, 0
  br i1 %runtime.ok.183, label %runtime.continue.184, label %frame.failure.0
runtime.continue.184:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %frame.failure.0
runtime.continue.188:
  %descriptor.element.189 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.190 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 0
  store i32 5, ptr %descriptor.field.190, align 4
  %descriptor.field.191 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.191, align 4
  %descriptor.field.192 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.192, align 4
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.189, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.194, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %runtime.ok.197 = icmp eq i32 %context.value.196, 0
  br i1 %runtime.ok.197, label %runtime.continue.198, label %frame.failure.0
runtime.continue.198:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %context.field.201 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.202 = load i32, ptr %context.field.201, align 4
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %stack.offset.205 = add i32 %context.value.5, %context.value.7
  %stack.offset.206 = add i32 %context.value.200, %context.value.202
  %stack.sub.207 = sub i32 %stack.offset.205, %stack.offset.206
  %stack.sub.208 = sub i32 %context.value.7, %context.value.202
  %stack.sub.209 = sub i32 %context.value.204, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.207, i32 %stack.sub.208)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.209)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 1
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 1, 1
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %stack.offset.48 = add i32 %context.value.47, 8
  %reserve.status.49 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.48, i32 23)
  %reserve.ok.50 = icmp eq i32 %reserve.status.49, 0
  br i1 %reserve.ok.50, label %reserve.continue.51, label %frame.failure.0
reserve.continue.51:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.47, i64 0, i32 1)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %stack.sub.64 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.62 = icmp ule i32 %descriptor.value.23, %context.value.61
  %descriptor.offset.inside.63 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.65 = icmp ule i32 %descriptor.value.19, %stack.sub.64
  %descriptor.payload.inside.66 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.67 = and i1 %descriptor.owner.inside.62, %descriptor.offset.inside.63
  %descriptor.range.inside.69 = and i1 %descriptor.owner.offset.valid.67, %descriptor.extent.inside.65
  %descriptor.range.valid.68 = and i1 %descriptor.range.inside.69, %descriptor.payload.inside.66
  %descriptor.type.valid.70 = icmp eq i32 1, 1
  %descriptor.valid.71 = and i1 %descriptor.range.valid.68, %descriptor.type.valid.70
  br i1 %descriptor.valid.71, label %descriptor.valid.72, label %descriptor.invalid.73
descriptor.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.72:
  %descriptor.initialized.status.74 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.75 = icmp eq i32 %descriptor.initialized.status.74, 0
  br i1 %helper.ok.75, label %helper.continue.76, label %frame.failure.0
helper.continue.76:
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %stack.sub.81 = sub i32 %stack.offset.48, %context.value.47
  %descriptor.owner.inside.79 = icmp ule i32 %stack.offset.48, %context.value.78
  %descriptor.offset.inside.80 = icmp ule i32 %context.value.47, %stack.offset.48
  %descriptor.extent.inside.82 = icmp ule i32 8, %stack.sub.81
  %descriptor.payload.inside.83 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.84 = and i1 %descriptor.owner.inside.79, %descriptor.offset.inside.80
  %descriptor.range.inside.86 = and i1 %descriptor.owner.offset.valid.84, %descriptor.extent.inside.82
  %descriptor.range.valid.85 = and i1 %descriptor.range.inside.86, %descriptor.payload.inside.83
  %descriptor.type.valid.87 = icmp eq i32 1, 1
  %descriptor.valid.88 = and i1 %descriptor.range.valid.85, %descriptor.type.valid.87
  br i1 %descriptor.valid.88, label %descriptor.valid.89, label %descriptor.invalid.90
descriptor.invalid.90:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.89:
  %descriptor.initialized.status.91 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.47, i32 8)
  %helper.ok.92 = icmp eq i32 %descriptor.initialized.status.91, 0
  br i1 %helper.ok.92, label %helper.continue.93, label %frame.failure.0
helper.continue.93:
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %helper.ok.95, label %helper.continue.96, label %frame.failure.0
helper.continue.96:
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %inline.target.depth.within.interpreter.limit.99 = icmp ule i32 %context.value.98, 65
  br i1 %inline.target.depth.within.interpreter.limit.99, label %inline.target.depth.ok.100, label %inline.target.depth.invalid.101
inline.target.depth.invalid.101:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.100:
  %integer.left.102 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.17)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %integer.right.103 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.47)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %comparison.result.112 = icmp sgt i64 %integer.left.102, %integer.right.103
  %comparison.value.113 = zext i1 %comparison.result.112 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.47, i32 8, i32 8, i32 0, i32 0)
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %runtime.ok.116 = icmp eq i32 %context.value.115, 0
  br i1 %runtime.ok.116, label %runtime.continue.117, label %frame.failure.0
runtime.continue.117:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.offset.124 = add i32 %context.value.123, 8
  %reserve.status.125 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.124, i32 26)
  %reserve.ok.126 = icmp eq i32 %reserve.status.125, 0
  br i1 %reserve.ok.126, label %reserve.continue.127, label %frame.failure.0
reserve.continue.127:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.123, i64 %comparison.value.113, i32 2)
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %runtime.ok.130 = icmp eq i32 %context.value.129, 0
  br i1 %runtime.ok.130, label %runtime.continue.131, label %frame.failure.0
runtime.continue.131:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %runtime.ok.134 = icmp eq i32 %context.value.133, 0
  br i1 %runtime.ok.134, label %runtime.continue.135, label %frame.failure.0
runtime.continue.135:
  %stack.offset.136 = add i32 %context.value.123, 8
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %stack.sub.141 = sub i32 %stack.offset.136, %context.value.123
  %descriptor.owner.inside.139 = icmp ule i32 %stack.offset.136, %context.value.138
  %descriptor.offset.inside.140 = icmp ule i32 %context.value.123, %stack.offset.136
  %descriptor.extent.inside.142 = icmp ule i32 8, %stack.sub.141
  %descriptor.payload.inside.143 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.144 = and i1 %descriptor.owner.inside.139, %descriptor.offset.inside.140
  %descriptor.range.inside.146 = and i1 %descriptor.owner.offset.valid.144, %descriptor.extent.inside.142
  %descriptor.range.valid.145 = and i1 %descriptor.range.inside.146, %descriptor.payload.inside.143
  %descriptor.type.valid.147 = icmp eq i32 2, 2
  %descriptor.valid.148 = and i1 %descriptor.range.valid.145, %descriptor.type.valid.147
  br i1 %descriptor.valid.148, label %descriptor.valid.149, label %descriptor.invalid.150
descriptor.invalid.150:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.149:
  %descriptor.initialized.status.151 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.123, i32 8)
  %helper.ok.152 = icmp eq i32 %descriptor.initialized.status.151, 0
  br i1 %helper.ok.152, label %helper.continue.153, label %frame.failure.0
helper.continue.153:
  %descriptor.element.154 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 0
  store i32 2, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 1
  store i32 %context.value.123, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 2
  store i32 8, ptr %descriptor.field.157, align 4
  %descriptor.field.158 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 3
  store i32 8, ptr %descriptor.field.158, align 4
  %descriptor.field.159 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 4
  store i32 %stack.offset.136, ptr %descriptor.field.159, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.123, i32 20, i32 8, i32 %stack.offset.136, i32 8)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %stack.offset.170 = add i32 %context.value.5, %context.value.7
  %stack.offset.171 = add i32 %context.value.165, %context.value.167
  %stack.sub.172 = sub i32 %stack.offset.170, %stack.offset.171
  %stack.sub.173 = sub i32 %context.value.7, %context.value.167
  %stack.sub.174 = sub i32 %context.value.169, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.172, i32 %stack.sub.173)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.174)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 27, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 27, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 27, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 28)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 7, i32 29)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 7, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 30)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 5
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 5)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}

define i32 @agentlang_mailbox_initialize(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.initialize.context.valid.1, label %mailbox.initialize.failure.0
mailbox.initialize.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 0, i32 31, i32 32, i32 33, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.initialize.preflight.ready.2, label %mailbox.initialize.failure.0
mailbox.initialize.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 34, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.initialize.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 34, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.initialize.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 7, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.total.35 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.35, i32 35)
  %helper.ok.37 = icmp eq i32 %mailbox.input.reserve.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %mailbox.initialize.failure.0
helper.continue.38:
  %mailbox.input.copy.status.39 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 7, i32 35)
  %helper.ok.40 = icmp eq i32 %mailbox.input.copy.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %mailbox.initialize.failure.0
helper.continue.41:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %mailbox.initialize.failure.0
runtime.continue.45:
  %mailbox.frame.status.47 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.46, i32 36)
  %helper.ok.48 = icmp eq i32 %mailbox.frame.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.initialize.failure.0
helper.continue.49:
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.46, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  %descriptor.value.52 = load i32, ptr %descriptor.field.51, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  %descriptor.value.54 = load i32, ptr %descriptor.field.53, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  %descriptor.value.56 = load i32, ptr %descriptor.field.55, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %mailbox.output.type.matches.61 = icmp eq i32 %descriptor.value.52, 5
  br i1 %mailbox.output.type.matches.61, label %mailbox.output.type.ok.62, label %mailbox.output.type.invalid.63
mailbox.output.type.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
mailbox.output.type.ok.62:
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %descriptor.value.60, %descriptor.value.54
  %descriptor.owner.inside.66 = icmp ule i32 %descriptor.value.60, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %descriptor.value.54, %descriptor.value.60
  %descriptor.extent.inside.69 = icmp ule i32 %descriptor.value.56, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %descriptor.value.58, %descriptor.value.56
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  %descriptor.type.valid.74 = icmp eq i32 5, 5
  %descriptor.valid.75 = and i1 %descriptor.range.valid.72, %descriptor.type.valid.74
  br i1 %descriptor.valid.75, label %descriptor.valid.76, label %descriptor.invalid.77
descriptor.invalid.77:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
descriptor.valid.76:
  %descriptor.initialized.status.78 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.54, i32 %descriptor.value.56)
  %helper.ok.79 = icmp eq i32 %descriptor.initialized.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %mailbox.initialize.failure.0
helper.continue.80:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.54, i32 20, i32 %descriptor.value.58, i32 %descriptor.value.60, i32 %descriptor.value.56)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %mailbox.initialize.failure.0
runtime.continue.84:
  %mailbox.output.descriptor.85 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.86 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.86, align 4
  %mailbox.output.field.87 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 1
  store i32 %descriptor.value.54, ptr %mailbox.output.field.87, align 4
  %mailbox.output.field.88 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 2
  store i32 %descriptor.value.60, ptr %mailbox.output.field.88, align 4
  %mailbox.output.field.89 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.89, align 4
  ret i32 0
mailbox.initialize.failure.0:
  %mailbox.failure.context.null.90 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.90, label %mailbox.failure.null.context.92, label %mailbox.failure.has.context.91
mailbox.failure.null.context.92:
  ret i32 4
mailbox.failure.has.context.91:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %mailbox.failure.status.set.96 = icmp ne i32 %context.value.95, 0
  br i1 %mailbox.failure.status.set.96, label %mailbox.failure.status.ready.93, label %mailbox.failure.set.fallback.97
mailbox.failure.set.fallback.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 31, i32 0, i32 0)
  br label %mailbox.failure.status.ready.93
mailbox.failure.status.ready.93:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  ret i32 %context.value.99
}


define i32 @agentlang_mailbox_begin(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.17 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.23 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.24 = alloca i32, align 4
  %mailbox.input.payload.pointer.45 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.46 = alloca i32, align 4
  %input.field.location.84 = alloca %AlOwningFieldLocation, align 4
  %input.result.case.94 = alloca i32, align 4
  %input.result.location.95 = alloca %AlOwningFieldLocation, align 4
  %validator.arguments.110 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.121 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.output.descriptors.174 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.begin.context.valid.1, label %mailbox.begin.failure.0
mailbox.begin.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 1, i32 37, i32 38, i32 39, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.begin.preflight.ready.2, label %mailbox.begin.failure.0
mailbox.begin.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.output.descriptor.12 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.13, align 4
  %mailbox.output.field.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.14, align 4
  %mailbox.output.field.15 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.15, align 4
  %mailbox.output.field.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.16, align 4
  %mailbox.input.slice.18 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.19 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 0
  %mailbox.input.bytes.20 = load ptr, ptr %mailbox.input.bytes.field.19, align 8
  %mailbox.input.extent.field.21 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 1
  %mailbox.input.extent.22 = load i32, ptr %mailbox.input.extent.field.21, align 4
  %mailbox.input.measure.status.25 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 40, ptr %mailbox.input.payload.pointer.23, ptr %mailbox.input.measured.extent.pointer.24)
  %helper.ok.26 = icmp eq i32 %mailbox.input.measure.status.25, 0
  br i1 %helper.ok.26, label %helper.continue.27, label %mailbox.begin.failure.0
helper.continue.27:
  %mailbox.input.payload.28 = load i32, ptr %mailbox.input.payload.pointer.23, align 4
  %mailbox.input.measured.extent.29 = load i32, ptr %mailbox.input.measured.extent.pointer.24, align 4
  %mailbox.input.extent.exact.30 = icmp eq i32 %mailbox.input.measured.extent.29, %mailbox.input.extent.22
  br i1 %mailbox.input.extent.exact.30, label %mailbox.input.extent.ok.31, label %mailbox.input.extent.invalid.32
mailbox.input.extent.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 40, i32 %mailbox.input.measured.extent.29, i32 %mailbox.input.extent.22)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.31:
  %stack.offset.33 = add i32 0, %mailbox.input.extent.22
  %descriptor.element.34 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 0
  %descriptor.field.35 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 0
  store i32 5, ptr %descriptor.field.35, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 1
  store i32 0, ptr %descriptor.field.36, align 4
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 2
  store i32 %mailbox.input.extent.22, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 3
  store i32 %mailbox.input.payload.28, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.39, align 4
  %mailbox.input.slice.40 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.41 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 0
  %mailbox.input.bytes.42 = load ptr, ptr %mailbox.input.bytes.field.41, align 8
  %mailbox.input.extent.field.43 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 1
  %mailbox.input.extent.44 = load i32, ptr %mailbox.input.extent.field.43, align 4
  %mailbox.input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 40, ptr %mailbox.input.payload.pointer.45, ptr %mailbox.input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %mailbox.input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.begin.failure.0
helper.continue.49:
  %mailbox.input.payload.50 = load i32, ptr %mailbox.input.payload.pointer.45, align 4
  %mailbox.input.measured.extent.51 = load i32, ptr %mailbox.input.measured.extent.pointer.46, align 4
  %mailbox.input.extent.exact.52 = icmp eq i32 %mailbox.input.measured.extent.51, %mailbox.input.extent.44
  br i1 %mailbox.input.extent.exact.52, label %mailbox.input.extent.ok.53, label %mailbox.input.extent.invalid.54
mailbox.input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 40, i32 %mailbox.input.measured.extent.51, i32 %mailbox.input.extent.44)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.53:
  %stack.offset.55 = add i32 %stack.offset.33, %mailbox.input.extent.44
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  store i32 7, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  store i32 %stack.offset.33, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  store i32 %mailbox.input.extent.44, ptr %descriptor.field.59, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  store i32 %mailbox.input.payload.50, ptr %descriptor.field.60, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  store i32 %stack.offset.55, ptr %descriptor.field.61, align 4
  %mailbox.input.total.62 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.63 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.62, i32 41)
  %helper.ok.64 = icmp eq i32 %mailbox.input.reserve.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %mailbox.begin.failure.0
helper.continue.65:
  %mailbox.input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 %mailbox.input.payload.28, i32 %mailbox.input.extent.22, i32 5, i32 41)
  %helper.ok.67 = icmp eq i32 %mailbox.input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %mailbox.begin.failure.0
helper.continue.68:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.28, i32 %stack.offset.33, i32 %mailbox.input.extent.22)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %mailbox.begin.failure.0
runtime.continue.72:
  %mailbox.input.copy.status.73 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.33, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 %mailbox.input.payload.50, i32 %mailbox.input.extent.44, i32 7, i32 41)
  %helper.ok.74 = icmp eq i32 %mailbox.input.copy.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %mailbox.begin.failure.0
helper.continue.75:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.33, i32 20, i32 %mailbox.input.payload.50, i32 %stack.offset.55, i32 %mailbox.input.extent.44)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %mailbox.begin.failure.0
runtime.continue.79:
  %mailbox.validation.frame.entered.81 = call i32 @al_owning_enter_frame(ptr %ctx, i32 43)
  %helper.ok.82 = icmp eq i32 %mailbox.validation.frame.entered.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %mailbox.begin.failure.0
helper.continue.83:
  %input.field.status.85 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 0, i32 %mailbox.input.extent.22, i32 0, i32 44, ptr %input.field.location.84)
  %helper.ok.86 = icmp eq i32 %input.field.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %mailbox.begin.validation.failure.80
helper.continue.87:
  %input.field.offset.pointer.88 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 0
  %input.field.offset.89 = load i32, ptr %input.field.offset.pointer.88, align 4
  %input.field.payload.pointer.90 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 1
  %input.field.payload.91 = load i32, ptr %input.field.payload.pointer.90, align 4
  %input.field.extent.pointer.92 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.84, i32 0, i32 2
  %input.field.extent.93 = load i32, ptr %input.field.extent.pointer.92, align 4
  %input.result.status.96 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 6, i32 %input.field.offset.89, i32 %input.field.extent.93, i32 45, ptr %input.result.case.94, ptr %input.result.location.95)
  %helper.ok.97 = icmp eq i32 %input.result.status.96, 0
  br i1 %helper.ok.97, label %helper.continue.98, label %mailbox.begin.validation.failure.80
helper.continue.98:
  %input.result.tag.99 = load i32, ptr %input.result.case.94, align 4
  %input.result.is.ok.100 = icmp eq i32 %input.result.tag.99, 0
  br i1 %input.result.is.ok.100, label %input.result.ok.101, label %input.result.error.102
input.result.ok.101:
  %input.result.offset.pointer.104 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.95, i32 0, i32 0
  %input.result.offset.105 = load i32, ptr %input.result.offset.pointer.104, align 4
  %input.result.payload.pointer.106 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.95, i32 0, i32 1
  %input.result.payload.107 = load i32, ptr %input.result.payload.pointer.106, align 4
  %input.result.extent.pointer.108 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.95, i32 0, i32 2
  %input.result.extent.109 = load i32, ptr %input.result.extent.pointer.108, align 4
  %descriptor.element.111 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.110, i32 0
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 0
  store i32 1, ptr %descriptor.field.112, align 4
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 1
  store i32 %input.result.offset.105, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 2
  store i32 %input.result.extent.109, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 3
  store i32 %input.result.payload.107, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.111, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.116, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %input.result.offset.105, i32 20, i32 %input.result.payload.107, i32 %stack.offset.33, i32 %input.result.extent.109)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %mailbox.begin.validation.failure.80
runtime.continue.120:
  %validator.status.122 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.110, ptr %validator.results.121, i32 48)
  %helper.ok.123 = icmp eq i32 %validator.status.122, 0
  br i1 %helper.ok.123, label %helper.continue.124, label %mailbox.begin.validation.failure.80
helper.continue.124:
  %descriptor.element.125 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.121, i32 0
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 0
  %descriptor.value.127 = load i32, ptr %descriptor.field.126, align 4
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 1
  %descriptor.value.129 = load i32, ptr %descriptor.field.128, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 2
  %descriptor.value.131 = load i32, ptr %descriptor.field.130, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 3
  %descriptor.value.133 = load i32, ptr %descriptor.field.132, align 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 4
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %validator.result.type.matches.136 = icmp eq i32 %descriptor.value.127, 2
  br i1 %validator.result.type.matches.136, label %validator.result.type.ok.137, label %validator.result.type.invalid.138
validator.result.type.invalid.138:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 47, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.result.type.ok.137:
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.sub.143 = sub i32 %descriptor.value.135, %descriptor.value.129
  %descriptor.owner.inside.141 = icmp ule i32 %descriptor.value.135, %context.value.140
  %descriptor.offset.inside.142 = icmp ule i32 %descriptor.value.129, %descriptor.value.135
  %descriptor.extent.inside.144 = icmp ule i32 %descriptor.value.131, %stack.sub.143
  %descriptor.payload.inside.145 = icmp ule i32 %descriptor.value.133, %descriptor.value.131
  %descriptor.owner.offset.valid.146 = and i1 %descriptor.owner.inside.141, %descriptor.offset.inside.142
  %descriptor.range.inside.148 = and i1 %descriptor.owner.offset.valid.146, %descriptor.extent.inside.144
  %descriptor.range.valid.147 = and i1 %descriptor.range.inside.148, %descriptor.payload.inside.145
  %descriptor.type.valid.149 = icmp eq i32 2, 2
  %descriptor.valid.150 = and i1 %descriptor.range.valid.147, %descriptor.type.valid.149
  br i1 %descriptor.valid.150, label %descriptor.valid.151, label %descriptor.invalid.152
descriptor.invalid.152:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
descriptor.valid.151:
  %descriptor.initialized.status.153 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.129, i32 %descriptor.value.131)
  %helper.ok.154 = icmp eq i32 %descriptor.initialized.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %mailbox.begin.validation.failure.80
helper.continue.155:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.129, i32 20, i32 %descriptor.value.133, i32 %descriptor.value.135, i32 %descriptor.value.131)
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %runtime.ok.158 = icmp eq i32 %context.value.157, 0
  br i1 %runtime.ok.158, label %runtime.continue.159, label %mailbox.begin.validation.failure.80
runtime.continue.159:
  %validator.bool.160 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.129)
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %runtime.ok.163 = icmp eq i32 %context.value.162, 0
  br i1 %runtime.ok.163, label %runtime.continue.164, label %mailbox.begin.validation.failure.80
runtime.continue.164:
  %validator.bool.true.165 = icmp eq i64 %validator.bool.160, 1
  %validator.bool.false.166 = icmp eq i64 %validator.bool.160, 0
  %validator.bool.valid.167 = or i1 %validator.bool.true.165, %validator.bool.false.166
  br i1 %validator.bool.valid.167, label %validator.bool.check.168, label %validator.bool.invalid.169
validator.bool.invalid.169:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 47, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.bool.check.168:
  br i1 %validator.bool.true.165, label %validator.true.171, label %validator.false.170
validator.false.170:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 46, i32 0, i32 0)
  br label %mailbox.begin.validation.failure.80
validator.true.171:
  br label %validator.join.172
validator.join.172:
  br label %input.result.validated.103
input.result.error.102:
  br label %input.result.validated.103
input.result.validated.103:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.begin.validation.succeeded.173
mailbox.begin.validation.failure.80:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.begin.failure.0
mailbox.begin.validation.succeeded.173:
  %mailbox.frame.status.175 = call i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %mailbox.input.descriptors.17, ptr %mailbox.output.descriptors.174, i32 42)
  %helper.ok.176 = icmp eq i32 %mailbox.frame.status.175, 0
  br i1 %helper.ok.176, label %helper.continue.177, label %mailbox.begin.failure.0
helper.continue.177:
  %descriptor.element.178 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.174, i32 0
  %descriptor.field.179 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.178, i32 0, i32 0
  %descriptor.value.180 = load i32, ptr %descriptor.field.179, align 4
  %descriptor.field.181 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.178, i32 0, i32 1
  %descriptor.value.182 = load i32, ptr %descriptor.field.181, align 4
  %descriptor.field.183 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.178, i32 0, i32 2
  %descriptor.value.184 = load i32, ptr %descriptor.field.183, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.178, i32 0, i32 3
  %descriptor.value.186 = load i32, ptr %descriptor.field.185, align 4
  %descriptor.field.187 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.178, i32 0, i32 4
  %descriptor.value.188 = load i32, ptr %descriptor.field.187, align 4
  %mailbox.output.type.matches.189 = icmp eq i32 %descriptor.value.180, 5
  br i1 %mailbox.output.type.matches.189, label %mailbox.output.type.ok.190, label %mailbox.output.type.invalid.191
mailbox.output.type.invalid.191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.190:
  %context.field.192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.193 = load i32, ptr %context.field.192, align 4
  %stack.sub.196 = sub i32 %descriptor.value.188, %descriptor.value.182
  %descriptor.owner.inside.194 = icmp ule i32 %descriptor.value.188, %context.value.193
  %descriptor.offset.inside.195 = icmp ule i32 %descriptor.value.182, %descriptor.value.188
  %descriptor.extent.inside.197 = icmp ule i32 %descriptor.value.184, %stack.sub.196
  %descriptor.payload.inside.198 = icmp ule i32 %descriptor.value.186, %descriptor.value.184
  %descriptor.owner.offset.valid.199 = and i1 %descriptor.owner.inside.194, %descriptor.offset.inside.195
  %descriptor.range.inside.201 = and i1 %descriptor.owner.offset.valid.199, %descriptor.extent.inside.197
  %descriptor.range.valid.200 = and i1 %descriptor.range.inside.201, %descriptor.payload.inside.198
  %descriptor.type.valid.202 = icmp eq i32 5, 5
  %descriptor.valid.203 = and i1 %descriptor.range.valid.200, %descriptor.type.valid.202
  br i1 %descriptor.valid.203, label %descriptor.valid.204, label %descriptor.invalid.205
descriptor.invalid.205:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.204:
  %descriptor.initialized.status.206 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.182, i32 %descriptor.value.184)
  %helper.ok.207 = icmp eq i32 %descriptor.initialized.status.206, 0
  br i1 %helper.ok.207, label %helper.continue.208, label %mailbox.begin.failure.0
helper.continue.208:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.182, i32 20, i32 %descriptor.value.186, i32 %descriptor.value.188, i32 %descriptor.value.184)
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %runtime.ok.211 = icmp eq i32 %context.value.210, 0
  br i1 %runtime.ok.211, label %runtime.continue.212, label %mailbox.begin.failure.0
runtime.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.174, i32 1
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  %descriptor.value.215 = load i32, ptr %descriptor.field.214, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  %descriptor.value.217 = load i32, ptr %descriptor.field.216, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  %descriptor.value.219 = load i32, ptr %descriptor.field.218, align 4
  %descriptor.field.220 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  %descriptor.value.221 = load i32, ptr %descriptor.field.220, align 4
  %descriptor.field.222 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  %descriptor.value.223 = load i32, ptr %descriptor.field.222, align 4
  %mailbox.output.type.matches.224 = icmp eq i32 %descriptor.value.215, 4
  br i1 %mailbox.output.type.matches.224, label %mailbox.output.type.ok.225, label %mailbox.output.type.invalid.226
mailbox.output.type.invalid.226:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.225:
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %stack.sub.231 = sub i32 %descriptor.value.223, %descriptor.value.217
  %descriptor.owner.inside.229 = icmp ule i32 %descriptor.value.223, %context.value.228
  %descriptor.offset.inside.230 = icmp ule i32 %descriptor.value.217, %descriptor.value.223
  %descriptor.extent.inside.232 = icmp ule i32 %descriptor.value.219, %stack.sub.231
  %descriptor.payload.inside.233 = icmp ule i32 %descriptor.value.221, %descriptor.value.219
  %descriptor.owner.offset.valid.234 = and i1 %descriptor.owner.inside.229, %descriptor.offset.inside.230
  %descriptor.range.inside.236 = and i1 %descriptor.owner.offset.valid.234, %descriptor.extent.inside.232
  %descriptor.range.valid.235 = and i1 %descriptor.range.inside.236, %descriptor.payload.inside.233
  %descriptor.type.valid.237 = icmp eq i32 4, 4
  %descriptor.valid.238 = and i1 %descriptor.range.valid.235, %descriptor.type.valid.237
  br i1 %descriptor.valid.238, label %descriptor.valid.239, label %descriptor.invalid.240
descriptor.invalid.240:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.239:
  %descriptor.initialized.status.241 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.217, i32 %descriptor.value.219)
  %helper.ok.242 = icmp eq i32 %descriptor.initialized.status.241, 0
  br i1 %helper.ok.242, label %helper.continue.243, label %mailbox.begin.failure.0
helper.continue.243:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.217, i32 20, i32 %descriptor.value.221, i32 %descriptor.value.223, i32 %descriptor.value.219)
  %context.field.244 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.245 = load i32, ptr %context.field.244, align 4
  %runtime.ok.246 = icmp eq i32 %context.value.245, 0
  br i1 %runtime.ok.246, label %runtime.continue.247, label %mailbox.begin.failure.0
runtime.continue.247:
  %mailbox.output.descriptor.248 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.249 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.248, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.249, align 4
  %mailbox.output.field.250 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.248, i32 0, i32 1
  store i32 %descriptor.value.182, ptr %mailbox.output.field.250, align 4
  %mailbox.output.field.251 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.248, i32 0, i32 2
  store i32 %descriptor.value.188, ptr %mailbox.output.field.251, align 4
  %mailbox.output.field.252 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.248, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.252, align 4
  %mailbox.output.descriptor.253 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.254 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.253, i32 0, i32 0
  store i32 2, ptr %mailbox.output.field.254, align 4
  %mailbox.output.field.255 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.253, i32 0, i32 1
  store i32 %descriptor.value.217, ptr %mailbox.output.field.255, align 4
  %mailbox.output.field.256 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.253, i32 0, i32 2
  store i32 %descriptor.value.223, ptr %mailbox.output.field.256, align 4
  %mailbox.output.field.257 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.253, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.257, align 4
  ret i32 0
mailbox.begin.failure.0:
  %mailbox.failure.context.null.258 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.258, label %mailbox.failure.null.context.260, label %mailbox.failure.has.context.259
mailbox.failure.null.context.260:
  ret i32 4
mailbox.failure.has.context.259:
  %context.field.262 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.263 = load i32, ptr %context.field.262, align 4
  %mailbox.failure.status.set.264 = icmp ne i32 %context.value.263, 0
  br i1 %mailbox.failure.status.set.264, label %mailbox.failure.status.ready.261, label %mailbox.failure.set.fallback.265
mailbox.failure.set.fallback.265:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 37, i32 0, i32 0)
  br label %mailbox.failure.status.ready.261
mailbox.failure.status.ready.261:
  %context.field.266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.267 = load i32, ptr %context.field.266, align 4
  ret i32 %context.value.267
}


define i32 @agentlang_mailbox_resume(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.input.payload.pointer.40 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.41 = alloca i32, align 4
  %mailbox.input.payload.pointer.62 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.63 = alloca i32, align 4
  %input.field.location.108 = alloca %AlOwningFieldLocation, align 4
  %input.result.case.118 = alloca i32, align 4
  %input.result.location.119 = alloca %AlOwningFieldLocation, align 4
  %validator.arguments.134 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.145 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.output.descriptors.198 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.resume.context.valid.1, label %mailbox.resume.failure.0
mailbox.resume.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 2, i32 49, i32 50, i32 51, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.resume.preflight.ready.2, label %mailbox.resume.failure.0
mailbox.resume.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 52, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.resume.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 52, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 5, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.slice.35 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.36 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 0
  %mailbox.input.bytes.37 = load ptr, ptr %mailbox.input.bytes.field.36, align 8
  %mailbox.input.extent.field.38 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 1
  %mailbox.input.extent.39 = load i32, ptr %mailbox.input.extent.field.38, align 4
  %mailbox.input.measure.status.42 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 52, ptr %mailbox.input.payload.pointer.40, ptr %mailbox.input.measured.extent.pointer.41)
  %helper.ok.43 = icmp eq i32 %mailbox.input.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %mailbox.resume.failure.0
helper.continue.44:
  %mailbox.input.payload.45 = load i32, ptr %mailbox.input.payload.pointer.40, align 4
  %mailbox.input.measured.extent.46 = load i32, ptr %mailbox.input.measured.extent.pointer.41, align 4
  %mailbox.input.extent.exact.47 = icmp eq i32 %mailbox.input.measured.extent.46, %mailbox.input.extent.39
  br i1 %mailbox.input.extent.exact.47, label %mailbox.input.extent.ok.48, label %mailbox.input.extent.invalid.49
mailbox.input.extent.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 52, i32 %mailbox.input.measured.extent.46, i32 %mailbox.input.extent.39)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.48:
  %stack.offset.50 = add i32 %stack.offset.28, %mailbox.input.extent.39
  %descriptor.element.51 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 1
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 0
  store i32 4, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 1
  store i32 %stack.offset.28, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 2
  store i32 %mailbox.input.extent.39, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 3
  store i32 %mailbox.input.payload.45, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 4
  store i32 %stack.offset.50, ptr %descriptor.field.56, align 4
  %mailbox.input.slice.57 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 2
  %mailbox.input.bytes.field.58 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 0
  %mailbox.input.bytes.59 = load ptr, ptr %mailbox.input.bytes.field.58, align 8
  %mailbox.input.extent.field.60 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 1
  %mailbox.input.extent.61 = load i32, ptr %mailbox.input.extent.field.60, align 4
  %mailbox.input.measure.status.64 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 52, ptr %mailbox.input.payload.pointer.62, ptr %mailbox.input.measured.extent.pointer.63)
  %helper.ok.65 = icmp eq i32 %mailbox.input.measure.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %mailbox.resume.failure.0
helper.continue.66:
  %mailbox.input.payload.67 = load i32, ptr %mailbox.input.payload.pointer.62, align 4
  %mailbox.input.measured.extent.68 = load i32, ptr %mailbox.input.measured.extent.pointer.63, align 4
  %mailbox.input.extent.exact.69 = icmp eq i32 %mailbox.input.measured.extent.68, %mailbox.input.extent.61
  br i1 %mailbox.input.extent.exact.69, label %mailbox.input.extent.ok.70, label %mailbox.input.extent.invalid.71
mailbox.input.extent.invalid.71:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 52, i32 %mailbox.input.measured.extent.68, i32 %mailbox.input.extent.61)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.70:
  %stack.offset.72 = add i32 %stack.offset.50, %mailbox.input.extent.61
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  store i32 7, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  store i32 %stack.offset.50, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  store i32 %mailbox.input.extent.61, ptr %descriptor.field.76, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  store i32 %mailbox.input.payload.67, ptr %descriptor.field.77, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  store i32 %stack.offset.72, ptr %descriptor.field.78, align 4
  %mailbox.input.total.79 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.79, i32 53)
  %helper.ok.81 = icmp eq i32 %mailbox.input.reserve.status.80, 0
  br i1 %helper.ok.81, label %helper.continue.82, label %mailbox.resume.failure.0
helper.continue.82:
  %mailbox.input.copy.status.83 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 5, i32 53)
  %helper.ok.84 = icmp eq i32 %mailbox.input.copy.status.83, 0
  br i1 %helper.ok.84, label %helper.continue.85, label %mailbox.resume.failure.0
helper.continue.85:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %runtime.ok.88 = icmp eq i32 %context.value.87, 0
  br i1 %runtime.ok.88, label %runtime.continue.89, label %mailbox.resume.failure.0
runtime.continue.89:
  %mailbox.input.copy.status.90 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.28, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 %mailbox.input.payload.45, i32 %mailbox.input.extent.39, i32 4, i32 53)
  %helper.ok.91 = icmp eq i32 %mailbox.input.copy.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %mailbox.resume.failure.0
helper.continue.92:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %stack.offset.28, i32 20, i32 %mailbox.input.payload.45, i32 %stack.offset.50, i32 %mailbox.input.extent.39)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %mailbox.resume.failure.0
runtime.continue.96:
  %mailbox.input.copy.status.97 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.50, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 %mailbox.input.payload.67, i32 %mailbox.input.extent.61, i32 7, i32 53)
  %helper.ok.98 = icmp eq i32 %mailbox.input.copy.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %mailbox.resume.failure.0
helper.continue.99:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %stack.offset.50, i32 20, i32 %mailbox.input.payload.67, i32 %stack.offset.72, i32 %mailbox.input.extent.61)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %mailbox.resume.failure.0
runtime.continue.103:
  %mailbox.validation.frame.entered.105 = call i32 @al_owning_enter_frame(ptr %ctx, i32 55)
  %helper.ok.106 = icmp eq i32 %mailbox.validation.frame.entered.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %mailbox.resume.failure.0
helper.continue.107:
  %input.field.status.109 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 0, i32 %mailbox.input.extent.17, i32 0, i32 56, ptr %input.field.location.108)
  %helper.ok.110 = icmp eq i32 %input.field.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %mailbox.resume.validation.failure.104
helper.continue.111:
  %input.field.offset.pointer.112 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 0
  %input.field.offset.113 = load i32, ptr %input.field.offset.pointer.112, align 4
  %input.field.payload.pointer.114 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 1
  %input.field.payload.115 = load i32, ptr %input.field.payload.pointer.114, align 4
  %input.field.extent.pointer.116 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.field.location.108, i32 0, i32 2
  %input.field.extent.117 = load i32, ptr %input.field.extent.pointer.116, align 4
  %input.result.status.120 = call i32 @al_owning_locate_sum_case(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 6, i32 %input.field.offset.113, i32 %input.field.extent.117, i32 57, ptr %input.result.case.118, ptr %input.result.location.119)
  %helper.ok.121 = icmp eq i32 %input.result.status.120, 0
  br i1 %helper.ok.121, label %helper.continue.122, label %mailbox.resume.validation.failure.104
helper.continue.122:
  %input.result.tag.123 = load i32, ptr %input.result.case.118, align 4
  %input.result.is.ok.124 = icmp eq i32 %input.result.tag.123, 0
  br i1 %input.result.is.ok.124, label %input.result.ok.125, label %input.result.error.126
input.result.ok.125:
  %input.result.offset.pointer.128 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.119, i32 0, i32 0
  %input.result.offset.129 = load i32, ptr %input.result.offset.pointer.128, align 4
  %input.result.payload.pointer.130 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.119, i32 0, i32 1
  %input.result.payload.131 = load i32, ptr %input.result.payload.pointer.130, align 4
  %input.result.extent.pointer.132 = getelementptr inbounds %AlOwningFieldLocation, ptr %input.result.location.119, i32 0, i32 2
  %input.result.extent.133 = load i32, ptr %input.result.extent.pointer.132, align 4
  %descriptor.element.135 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.134, i32 0
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 0
  store i32 1, ptr %descriptor.field.136, align 4
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 1
  store i32 %input.result.offset.129, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 2
  store i32 %input.result.extent.133, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 3
  store i32 %input.result.payload.131, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.140, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %input.result.offset.129, i32 20, i32 %input.result.payload.131, i32 %stack.offset.28, i32 %input.result.extent.133)
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %runtime.ok.143 = icmp eq i32 %context.value.142, 0
  br i1 %runtime.ok.143, label %runtime.continue.144, label %mailbox.resume.validation.failure.104
runtime.continue.144:
  %validator.status.146 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.134, ptr %validator.results.145, i32 60)
  %helper.ok.147 = icmp eq i32 %validator.status.146, 0
  br i1 %helper.ok.147, label %helper.continue.148, label %mailbox.resume.validation.failure.104
helper.continue.148:
  %descriptor.element.149 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.145, i32 0
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.149, i32 0, i32 0
  %descriptor.value.151 = load i32, ptr %descriptor.field.150, align 4
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.149, i32 0, i32 1
  %descriptor.value.153 = load i32, ptr %descriptor.field.152, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.149, i32 0, i32 2
  %descriptor.value.155 = load i32, ptr %descriptor.field.154, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.149, i32 0, i32 3
  %descriptor.value.157 = load i32, ptr %descriptor.field.156, align 4
  %descriptor.field.158 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.149, i32 0, i32 4
  %descriptor.value.159 = load i32, ptr %descriptor.field.158, align 4
  %validator.result.type.matches.160 = icmp eq i32 %descriptor.value.151, 2
  br i1 %validator.result.type.matches.160, label %validator.result.type.ok.161, label %validator.result.type.invalid.162
validator.result.type.invalid.162:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 59, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.result.type.ok.161:
  %context.field.163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.164 = load i32, ptr %context.field.163, align 4
  %stack.sub.167 = sub i32 %descriptor.value.159, %descriptor.value.153
  %descriptor.owner.inside.165 = icmp ule i32 %descriptor.value.159, %context.value.164
  %descriptor.offset.inside.166 = icmp ule i32 %descriptor.value.153, %descriptor.value.159
  %descriptor.extent.inside.168 = icmp ule i32 %descriptor.value.155, %stack.sub.167
  %descriptor.payload.inside.169 = icmp ule i32 %descriptor.value.157, %descriptor.value.155
  %descriptor.owner.offset.valid.170 = and i1 %descriptor.owner.inside.165, %descriptor.offset.inside.166
  %descriptor.range.inside.172 = and i1 %descriptor.owner.offset.valid.170, %descriptor.extent.inside.168
  %descriptor.range.valid.171 = and i1 %descriptor.range.inside.172, %descriptor.payload.inside.169
  %descriptor.type.valid.173 = icmp eq i32 2, 2
  %descriptor.valid.174 = and i1 %descriptor.range.valid.171, %descriptor.type.valid.173
  br i1 %descriptor.valid.174, label %descriptor.valid.175, label %descriptor.invalid.176
descriptor.invalid.176:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
descriptor.valid.175:
  %descriptor.initialized.status.177 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.153, i32 %descriptor.value.155)
  %helper.ok.178 = icmp eq i32 %descriptor.initialized.status.177, 0
  br i1 %helper.ok.178, label %helper.continue.179, label %mailbox.resume.validation.failure.104
helper.continue.179:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.153, i32 20, i32 %descriptor.value.157, i32 %descriptor.value.159, i32 %descriptor.value.155)
  %context.field.180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.181 = load i32, ptr %context.field.180, align 4
  %runtime.ok.182 = icmp eq i32 %context.value.181, 0
  br i1 %runtime.ok.182, label %runtime.continue.183, label %mailbox.resume.validation.failure.104
runtime.continue.183:
  %validator.bool.184 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.153)
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %runtime.ok.187 = icmp eq i32 %context.value.186, 0
  br i1 %runtime.ok.187, label %runtime.continue.188, label %mailbox.resume.validation.failure.104
runtime.continue.188:
  %validator.bool.true.189 = icmp eq i64 %validator.bool.184, 1
  %validator.bool.false.190 = icmp eq i64 %validator.bool.184, 0
  %validator.bool.valid.191 = or i1 %validator.bool.true.189, %validator.bool.false.190
  br i1 %validator.bool.valid.191, label %validator.bool.check.192, label %validator.bool.invalid.193
validator.bool.invalid.193:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 59, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.bool.check.192:
  br i1 %validator.bool.true.189, label %validator.true.195, label %validator.false.194
validator.false.194:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 58, i32 0, i32 0)
  br label %mailbox.resume.validation.failure.104
validator.true.195:
  br label %validator.join.196
validator.join.196:
  br label %input.result.validated.127
input.result.error.126:
  br label %input.result.validated.127
input.result.validated.127:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.resume.validation.succeeded.197
mailbox.resume.validation.failure.104:
  call void @al_owning_leave_frame(ptr %ctx)
  br label %mailbox.resume.failure.0
mailbox.resume.validation.succeeded.197:
  %mailbox.frame.status.199 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.198, i32 54)
  %helper.ok.200 = icmp eq i32 %mailbox.frame.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %mailbox.resume.failure.0
helper.continue.201:
  %descriptor.element.202 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.198, i32 0
  %descriptor.field.203 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.202, i32 0, i32 0
  %descriptor.value.204 = load i32, ptr %descriptor.field.203, align 4
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.202, i32 0, i32 1
  %descriptor.value.206 = load i32, ptr %descriptor.field.205, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.202, i32 0, i32 2
  %descriptor.value.208 = load i32, ptr %descriptor.field.207, align 4
  %descriptor.field.209 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.202, i32 0, i32 3
  %descriptor.value.210 = load i32, ptr %descriptor.field.209, align 4
  %descriptor.field.211 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.202, i32 0, i32 4
  %descriptor.value.212 = load i32, ptr %descriptor.field.211, align 4
  %mailbox.output.type.matches.213 = icmp eq i32 %descriptor.value.204, 5
  br i1 %mailbox.output.type.matches.213, label %mailbox.output.type.ok.214, label %mailbox.output.type.invalid.215
mailbox.output.type.invalid.215:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
mailbox.output.type.ok.214:
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %stack.sub.220 = sub i32 %descriptor.value.212, %descriptor.value.206
  %descriptor.owner.inside.218 = icmp ule i32 %descriptor.value.212, %context.value.217
  %descriptor.offset.inside.219 = icmp ule i32 %descriptor.value.206, %descriptor.value.212
  %descriptor.extent.inside.221 = icmp ule i32 %descriptor.value.208, %stack.sub.220
  %descriptor.payload.inside.222 = icmp ule i32 %descriptor.value.210, %descriptor.value.208
  %descriptor.owner.offset.valid.223 = and i1 %descriptor.owner.inside.218, %descriptor.offset.inside.219
  %descriptor.range.inside.225 = and i1 %descriptor.owner.offset.valid.223, %descriptor.extent.inside.221
  %descriptor.range.valid.224 = and i1 %descriptor.range.inside.225, %descriptor.payload.inside.222
  %descriptor.type.valid.226 = icmp eq i32 5, 5
  %descriptor.valid.227 = and i1 %descriptor.range.valid.224, %descriptor.type.valid.226
  br i1 %descriptor.valid.227, label %descriptor.valid.228, label %descriptor.invalid.229
descriptor.invalid.229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
descriptor.valid.228:
  %descriptor.initialized.status.230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.206, i32 %descriptor.value.208)
  %helper.ok.231 = icmp eq i32 %descriptor.initialized.status.230, 0
  br i1 %helper.ok.231, label %helper.continue.232, label %mailbox.resume.failure.0
helper.continue.232:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.206, i32 20, i32 %descriptor.value.210, i32 %descriptor.value.212, i32 %descriptor.value.208)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %runtime.ok.235 = icmp eq i32 %context.value.234, 0
  br i1 %runtime.ok.235, label %runtime.continue.236, label %mailbox.resume.failure.0
runtime.continue.236:
  %mailbox.output.descriptor.237 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.238 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.238, align 4
  %mailbox.output.field.239 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 1
  store i32 %descriptor.value.206, ptr %mailbox.output.field.239, align 4
  %mailbox.output.field.240 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 2
  store i32 %descriptor.value.212, ptr %mailbox.output.field.240, align 4
  %mailbox.output.field.241 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.237, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.241, align 4
  ret i32 0
mailbox.resume.failure.0:
  %mailbox.failure.context.null.242 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.242, label %mailbox.failure.null.context.244, label %mailbox.failure.has.context.243
mailbox.failure.null.context.244:
  ret i32 4
mailbox.failure.has.context.243:
  %context.field.246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.247 = load i32, ptr %context.field.246, align 4
  %mailbox.failure.status.set.248 = icmp ne i32 %context.value.247, 0
  br i1 %mailbox.failure.status.set.248, label %mailbox.failure.status.ready.245, label %mailbox.failure.set.fallback.249
mailbox.failure.set.fallback.249:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 49, i32 0, i32 0)
  br label %mailbox.failure.status.ready.245
mailbox.failure.status.ready.245:
  %context.field.250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.251 = load i32, ptr %context.field.250, align 4
  ret i32 %context.value.251
}


define i32 @agentlang_mailbox_resume_associated(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity) {
entry:
  %associated.resume.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %associated.resume.retained.value.size.18 = alloca %AlOwningValueSize, align 4
  %associated.resume.retained.value.size.41 = alloca %AlOwningValueSize, align 4
  %associated.resume.completion.payload.pointer.63 = alloca i32, align 4
  %associated.resume.completion.measured.extent.pointer.64 = alloca i32, align 4
  %associated.resume.output.descriptors.92 = alloca [1 x %AlOwningDescriptor], align 4
  %associated.resume.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %associated.resume.context.nonnull.3, label %associated.resume.context.valid.1, label %associated.resume.failure.0
associated.resume.context.valid.1:
  %associated.resume.preflight.status.4 = call i32 @agentlang_owning_mailbox_associated_preflight(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity, i32 61, i32 62, i32 63)
  %associated.resume.preflight.ok.5 = icmp eq i32 %associated.resume.preflight.status.4, 0
  br i1 %associated.resume.preflight.ok.5, label %associated.resume.preflight.ready.2, label %associated.resume.failure.0
associated.resume.preflight.ready.2:
  %associated.resume.output.descriptor.6 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %associated.resume.output.field.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 4294967295, ptr %associated.resume.output.field.7, align 4
  %associated.resume.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 0, ptr %associated.resume.output.field.8, align 4
  %associated.resume.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 0, ptr %associated.resume.output.field.9, align 4
  %associated.resume.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.10, align 4
  %context.field.11 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 10
  store i32 0, ptr %context.field.11, align 4
  %associated.resume.retained.slice.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 0
  %associated.resume.retained.offset.pointer.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.15 = load i32, ptr %associated.resume.retained.offset.pointer.14, align 4
  %associated.resume.retained.owner.end.pointer.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.17 = load i32, ptr %associated.resume.retained.owner.end.pointer.16, align 4
  %associated.resume.retained.measure.status.19 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %associated.resume.retained.offset.pointer.value.15, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 64, ptr %associated.resume.retained.value.size.18)
  %helper.ok.20 = icmp eq i32 %associated.resume.retained.measure.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %associated.resume.failure.0
helper.continue.21:
  %associated.resume.retained.payload.pointer.22 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 0
  %associated.resume.retained.extent.pointer.23 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 1
  %associated.resume.retained.payload.24 = load i32, ptr %associated.resume.retained.payload.pointer.22, align 4
  %associated.resume.retained.extent.25 = load i32, ptr %associated.resume.retained.extent.pointer.23, align 4
  %descriptor.element.26 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 0
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 0
  store i32 5, ptr %descriptor.field.27, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.15, ptr %descriptor.field.28, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 2
  store i32 %associated.resume.retained.extent.25, ptr %descriptor.field.29, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 3
  store i32 %associated.resume.retained.payload.24, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.17, ptr %descriptor.field.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %associated.resume.retained.offset.pointer.value.15, i32 20, i32 %associated.resume.retained.payload.24, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 %associated.resume.retained.extent.25)
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %runtime.ok.34 = icmp eq i32 %context.value.33, 0
  br i1 %runtime.ok.34, label %runtime.continue.35, label %associated.resume.failure.0
runtime.continue.35:
  %associated.resume.retained.slice.36 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 1
  %associated.resume.retained.offset.pointer.37 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.38 = load i32, ptr %associated.resume.retained.offset.pointer.37, align 4
  %associated.resume.retained.owner.end.pointer.39 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.40 = load i32, ptr %associated.resume.retained.owner.end.pointer.39, align 4
  %associated.resume.retained.measure.status.42 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %associated.resume.retained.offset.pointer.value.38, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 64, ptr %associated.resume.retained.value.size.41)
  %helper.ok.43 = icmp eq i32 %associated.resume.retained.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %associated.resume.failure.0
helper.continue.44:
  %associated.resume.retained.payload.pointer.45 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 0
  %associated.resume.retained.extent.pointer.46 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 1
  %associated.resume.retained.payload.47 = load i32, ptr %associated.resume.retained.payload.pointer.45, align 4
  %associated.resume.retained.extent.48 = load i32, ptr %associated.resume.retained.extent.pointer.46, align 4
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 1
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  store i32 4, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.38, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  store i32 %associated.resume.retained.extent.48, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  store i32 %associated.resume.retained.payload.47, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.40, ptr %descriptor.field.54, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %associated.resume.retained.offset.pointer.value.38, i32 20, i32 %associated.resume.retained.payload.47, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 %associated.resume.retained.extent.48)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %associated.resume.failure.0
runtime.continue.58:
  %associated.resume.completion.bytes.pointer.59 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 0
  %associated.resume.completion.bytes.60 = load ptr, ptr %associated.resume.completion.bytes.pointer.59, align 8
  %associated.resume.completion.extent.pointer.61 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 1
  %associated.resume.completion.extent.62 = load i32, ptr %associated.resume.completion.extent.pointer.61, align 4
  %associated.resume.completion.measure.status.65 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 5, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 64, ptr %associated.resume.completion.payload.pointer.63, ptr %associated.resume.completion.measured.extent.pointer.64)
  %helper.ok.66 = icmp eq i32 %associated.resume.completion.measure.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %associated.resume.failure.0
helper.continue.67:
  %associated.resume.completion.payload.68 = load i32, ptr %associated.resume.completion.payload.pointer.63, align 4
  %associated.resume.completion.measured.extent.69 = load i32, ptr %associated.resume.completion.measured.extent.pointer.64, align 4
  %associated.resume.completion.extent.matches.70 = icmp eq i32 %associated.resume.completion.measured.extent.69, %associated.resume.completion.extent.62
  br i1 %associated.resume.completion.extent.matches.70, label %associated.resume.completion.extent.ok.71, label %associated.resume.failure.0
associated.resume.completion.extent.ok.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.offset.74 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %reserve.status.75 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.74, i32 65)
  %reserve.ok.76 = icmp eq i32 %reserve.status.75, 0
  br i1 %reserve.ok.76, label %reserve.continue.77, label %associated.resume.failure.0
reserve.continue.77:
  %associated.resume.completion.copy.status.78 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %context.value.73, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 %associated.resume.completion.payload.68, i32 %associated.resume.completion.extent.62, i32 7, i32 65)
  %helper.ok.79 = icmp eq i32 %associated.resume.completion.copy.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %associated.resume.failure.0
helper.continue.80:
  %stack.offset.81 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 2
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  store i32 7, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  store i32 %context.value.73, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  store i32 %associated.resume.completion.extent.62, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  store i32 %associated.resume.completion.payload.68, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  store i32 %stack.offset.81, ptr %descriptor.field.87, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %context.value.73, i32 20, i32 %associated.resume.completion.payload.68, i32 %stack.offset.81, i32 %associated.resume.completion.extent.62)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %associated.resume.failure.0
runtime.continue.91:
  %associated.resume.frame.status.93 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %associated.resume.input.descriptors.12, ptr %associated.resume.output.descriptors.92, i32 66)
  %helper.ok.94 = icmp eq i32 %associated.resume.frame.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %associated.resume.failure.0
helper.continue.95:
  %descriptor.element.96 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.output.descriptors.92, i32 0
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 0
  %descriptor.value.98 = load i32, ptr %descriptor.field.97, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 1
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 2
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 3
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 4
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %associated.resume.output.type.matches.107 = icmp eq i32 %descriptor.value.98, 5
  br i1 %associated.resume.output.type.matches.107, label %associated.resume.output.type.ok.108, label %associated.resume.failure.0
associated.resume.output.type.ok.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %descriptor.value.106, %descriptor.value.100
  %descriptor.owner.inside.111 = icmp ule i32 %descriptor.value.106, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %descriptor.value.100, %descriptor.value.106
  %descriptor.extent.inside.114 = icmp ule i32 %descriptor.value.102, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %descriptor.value.104, %descriptor.value.102
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 5, 5
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %associated.resume.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.100, i32 %descriptor.value.102)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %associated.resume.failure.0
helper.continue.125:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.100, i32 20, i32 %descriptor.value.104, i32 %descriptor.value.106, i32 %descriptor.value.102)
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %runtime.ok.128 = icmp eq i32 %context.value.127, 0
  br i1 %runtime.ok.128, label %runtime.continue.129, label %associated.resume.failure.0
runtime.continue.129:
  %associated.resume.output.field.130 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 3, ptr %associated.resume.output.field.130, align 4
  %associated.resume.output.field.131 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 %descriptor.value.100, ptr %associated.resume.output.field.131, align 4
  %associated.resume.output.field.132 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 %descriptor.value.106, ptr %associated.resume.output.field.132, align 4
  %associated.resume.output.field.133 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.133, align 4
  ret i32 0
associated.resume.failure.0:
  %associated.resume.failure.context.null.134 = icmp eq ptr %ctx, null
  br i1 %associated.resume.failure.context.null.134, label %associated.resume.failure.null.context.136, label %associated.resume.failure.has.context.135
associated.resume.failure.null.context.136:
  ret i32 4
associated.resume.failure.has.context.135:
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %associated.resume.failure.status.set.140 = icmp ne i32 %context.value.139, 0
  br i1 %associated.resume.failure.status.set.140, label %associated.resume.failure.status.ready.137, label %associated.resume.failure.set.fallback.141
associated.resume.failure.set.fallback.141:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 61, i32 0, i32 0)
  br label %associated.resume.failure.status.ready.137
associated.resume.failure.status.ready.137:
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  ret i32 %context.value.143
}



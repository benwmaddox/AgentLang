%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 6, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 7, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 8, i32 9, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 2 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [24 x i8] c"\08\00\00\00\00\00\00\00\69\00\6E\00\61\00\63\00\74\00\69\00\76\00\65\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 24
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  %literal.status.22 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.17, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 24, i32 24, i32 7, i32 3)
  %helper.ok.23 = icmp eq i32 %literal.status.22, 0
  br i1 %helper.ok.23, label %helper.continue.24, label %frame.failure.0
helper.continue.24:
  %context.field.25 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.26 = load i32, ptr %context.field.25, align 4
  %stack.sub.29 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.27 = icmp ule i32 %stack.offset.18, %context.value.26
  %descriptor.offset.inside.28 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.30 = icmp ule i32 24, %stack.sub.29
  %descriptor.payload.inside.31 = icmp ule i32 24, 24
  %descriptor.owner.offset.valid.32 = and i1 %descriptor.owner.inside.27, %descriptor.offset.inside.28
  %descriptor.range.inside.34 = and i1 %descriptor.owner.offset.valid.32, %descriptor.extent.inside.30
  %descriptor.range.valid.33 = and i1 %descriptor.range.inside.34, %descriptor.payload.inside.31
  %descriptor.type.valid.35 = icmp eq i32 7, 7
  %descriptor.valid.36 = and i1 %descriptor.range.valid.33, %descriptor.type.valid.35
  br i1 %descriptor.valid.36, label %descriptor.valid.37, label %descriptor.invalid.38
descriptor.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.37:
  %descriptor.initialized.status.39 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 24)
  %helper.ok.40 = icmp eq i32 %descriptor.initialized.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %frame.failure.0
helper.continue.41:
  %step.status.42 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.43 = icmp eq i32 %step.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %frame.failure.0
helper.continue.44:
  %context.field.45 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.46 = load i32, ptr %context.field.45, align 4
  %stack.offset.47 = add i32 8, 24
  %stack.offset.48 = add i32 8, 24
  %stack.offset.49 = add i32 %context.value.46, %stack.offset.47
  %reserve.status.50 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.49, i32 5)
  %reserve.ok.51 = icmp eq i32 %reserve.status.50, 0
  br i1 %reserve.ok.51, label %reserve.continue.52, label %frame.failure.0
reserve.continue.52:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.46, i64 1, i32 9)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %stack.offset.57 = add i32 %context.value.46, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.57, i32 %context.value.17, i32 24, i32 24, i32 7, i32 6)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %runtime.ok.64 = icmp eq i32 %context.value.63, 0
  br i1 %runtime.ok.64, label %runtime.continue.65, label %frame.failure.0
runtime.continue.65:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 9, i32 %context.value.46, i32 %stack.offset.47, i32 %stack.offset.48, i32 %context.value.17, i32 24)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %runtime.ok.68 = icmp eq i32 %context.value.67, 0
  br i1 %runtime.ok.68, label %runtime.continue.69, label %frame.failure.0
runtime.continue.69:
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %stack.offset.49, %context.value.46
  %descriptor.owner.inside.72 = icmp ule i32 %stack.offset.49, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %context.value.46, %stack.offset.49
  %descriptor.extent.inside.75 = icmp ule i32 %stack.offset.47, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %stack.offset.48, %stack.offset.47
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  %descriptor.type.valid.80 = icmp eq i32 9, 9
  %descriptor.valid.81 = and i1 %descriptor.range.valid.78, %descriptor.type.valid.80
  br i1 %descriptor.valid.81, label %descriptor.valid.82, label %descriptor.invalid.83
descriptor.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.82:
  %descriptor.initialized.status.84 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.46, i32 %stack.offset.47)
  %helper.ok.85 = icmp eq i32 %descriptor.initialized.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 9, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %context.value.46, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %stack.offset.47, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %stack.offset.48, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %stack.offset.49, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %context.value.46, i32 20, i32 %stack.offset.48, i32 %stack.offset.49, i32 %stack.offset.47)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %stack.offset.103 = add i32 %context.value.5, %context.value.7
  %stack.offset.104 = add i32 %context.value.98, %context.value.100
  %stack.sub.105 = sub i32 %stack.offset.103, %stack.offset.104
  %stack.sub.106 = sub i32 %context.value.7, %context.value.100
  %stack.sub.107 = sub i32 %context.value.102, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.105, i32 %stack.sub.106)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.107)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 1
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 1, 1
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %stack.offset.48 = add i32 %context.value.47, 8
  %reserve.status.49 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.48, i32 7)
  %reserve.ok.50 = icmp eq i32 %reserve.status.49, 0
  br i1 %reserve.ok.50, label %reserve.continue.51, label %frame.failure.0
reserve.continue.51:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.47, i64 0, i32 1)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %stack.sub.64 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.62 = icmp ule i32 %descriptor.value.23, %context.value.61
  %descriptor.offset.inside.63 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.65 = icmp ule i32 %descriptor.value.19, %stack.sub.64
  %descriptor.payload.inside.66 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.67 = and i1 %descriptor.owner.inside.62, %descriptor.offset.inside.63
  %descriptor.range.inside.69 = and i1 %descriptor.owner.offset.valid.67, %descriptor.extent.inside.65
  %descriptor.range.valid.68 = and i1 %descriptor.range.inside.69, %descriptor.payload.inside.66
  %descriptor.type.valid.70 = icmp eq i32 1, 1
  %descriptor.valid.71 = and i1 %descriptor.range.valid.68, %descriptor.type.valid.70
  br i1 %descriptor.valid.71, label %descriptor.valid.72, label %descriptor.invalid.73
descriptor.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.72:
  %descriptor.initialized.status.74 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.75 = icmp eq i32 %descriptor.initialized.status.74, 0
  br i1 %helper.ok.75, label %helper.continue.76, label %frame.failure.0
helper.continue.76:
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %stack.sub.81 = sub i32 %stack.offset.48, %context.value.47
  %descriptor.owner.inside.79 = icmp ule i32 %stack.offset.48, %context.value.78
  %descriptor.offset.inside.80 = icmp ule i32 %context.value.47, %stack.offset.48
  %descriptor.extent.inside.82 = icmp ule i32 8, %stack.sub.81
  %descriptor.payload.inside.83 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.84 = and i1 %descriptor.owner.inside.79, %descriptor.offset.inside.80
  %descriptor.range.inside.86 = and i1 %descriptor.owner.offset.valid.84, %descriptor.extent.inside.82
  %descriptor.range.valid.85 = and i1 %descriptor.range.inside.86, %descriptor.payload.inside.83
  %descriptor.type.valid.87 = icmp eq i32 1, 1
  %descriptor.valid.88 = and i1 %descriptor.range.valid.85, %descriptor.type.valid.87
  br i1 %descriptor.valid.88, label %descriptor.valid.89, label %descriptor.invalid.90
descriptor.invalid.90:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.89:
  %descriptor.initialized.status.91 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.47, i32 8)
  %helper.ok.92 = icmp eq i32 %descriptor.initialized.status.91, 0
  br i1 %helper.ok.92, label %helper.continue.93, label %frame.failure.0
helper.continue.93:
  %step.status.94 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.95 = icmp eq i32 %step.status.94, 0
  br i1 %helper.ok.95, label %helper.continue.96, label %frame.failure.0
helper.continue.96:
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %inline.target.depth.within.interpreter.limit.99 = icmp ule i32 %context.value.98, 65
  br i1 %inline.target.depth.within.interpreter.limit.99, label %inline.target.depth.ok.100, label %inline.target.depth.invalid.101
inline.target.depth.invalid.101:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.100:
  %integer.left.102 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.17)
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %runtime.ok.106 = icmp eq i32 %context.value.105, 0
  br i1 %runtime.ok.106, label %runtime.continue.107, label %frame.failure.0
runtime.continue.107:
  %integer.right.103 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.47)
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %runtime.ok.110 = icmp eq i32 %context.value.109, 0
  br i1 %runtime.ok.110, label %runtime.continue.111, label %frame.failure.0
runtime.continue.111:
  %comparison.result.112 = icmp sgt i64 %integer.left.102, %integer.right.103
  %comparison.value.113 = zext i1 %comparison.result.112 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.47, i32 8, i32 8, i32 0, i32 0)
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %runtime.ok.116 = icmp eq i32 %context.value.115, 0
  br i1 %runtime.ok.116, label %runtime.continue.117, label %frame.failure.0
runtime.continue.117:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.offset.124 = add i32 %context.value.123, 8
  %reserve.status.125 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.124, i32 10)
  %reserve.ok.126 = icmp eq i32 %reserve.status.125, 0
  br i1 %reserve.ok.126, label %reserve.continue.127, label %frame.failure.0
reserve.continue.127:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.123, i64 %comparison.value.113, i32 2)
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %runtime.ok.130 = icmp eq i32 %context.value.129, 0
  br i1 %runtime.ok.130, label %runtime.continue.131, label %frame.failure.0
runtime.continue.131:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %runtime.ok.134 = icmp eq i32 %context.value.133, 0
  br i1 %runtime.ok.134, label %runtime.continue.135, label %frame.failure.0
runtime.continue.135:
  %stack.offset.136 = add i32 %context.value.123, 8
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %stack.sub.141 = sub i32 %stack.offset.136, %context.value.123
  %descriptor.owner.inside.139 = icmp ule i32 %stack.offset.136, %context.value.138
  %descriptor.offset.inside.140 = icmp ule i32 %context.value.123, %stack.offset.136
  %descriptor.extent.inside.142 = icmp ule i32 8, %stack.sub.141
  %descriptor.payload.inside.143 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.144 = and i1 %descriptor.owner.inside.139, %descriptor.offset.inside.140
  %descriptor.range.inside.146 = and i1 %descriptor.owner.offset.valid.144, %descriptor.extent.inside.142
  %descriptor.range.valid.145 = and i1 %descriptor.range.inside.146, %descriptor.payload.inside.143
  %descriptor.type.valid.147 = icmp eq i32 2, 2
  %descriptor.valid.148 = and i1 %descriptor.range.valid.145, %descriptor.type.valid.147
  br i1 %descriptor.valid.148, label %descriptor.valid.149, label %descriptor.invalid.150
descriptor.invalid.150:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.149:
  %descriptor.initialized.status.151 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.123, i32 8)
  %helper.ok.152 = icmp eq i32 %descriptor.initialized.status.151, 0
  br i1 %helper.ok.152, label %helper.continue.153, label %frame.failure.0
helper.continue.153:
  %descriptor.element.154 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 0
  store i32 2, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 1
  store i32 %context.value.123, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 2
  store i32 8, ptr %descriptor.field.157, align 4
  %descriptor.field.158 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 3
  store i32 8, ptr %descriptor.field.158, align 4
  %descriptor.field.159 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 4
  store i32 %stack.offset.136, ptr %descriptor.field.159, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %context.value.123, i32 20, i32 8, i32 %stack.offset.136, i32 8)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %stack.offset.170 = add i32 %context.value.5, %context.value.7
  %stack.offset.171 = add i32 %context.value.165, %context.value.167
  %stack.sub.172 = sub i32 %stack.offset.170, %stack.offset.171
  %stack.sub.173 = sub i32 %context.value.7, %context.value.167
  %stack.sub.174 = sub i32 %context.value.169, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.172, i32 %stack.sub.173)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.174)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 11)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 12)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 9
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 9, 9
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 9)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


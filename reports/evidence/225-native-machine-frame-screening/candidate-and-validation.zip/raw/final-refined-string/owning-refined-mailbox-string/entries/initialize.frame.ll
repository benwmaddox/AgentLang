define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %validator.arguments.92 = alloca [1 x %AlOwningDescriptor], align 4
  %validator.results.103 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %inline.target.depth.within.interpreter.limit.48 = icmp ule i32 %context.value.47, 65
  br i1 %inline.target.depth.within.interpreter.limit.48, label %inline.target.depth.ok.49, label %inline.target.depth.invalid.50
inline.target.depth.invalid.50:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 2, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.49:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 7, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.51 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.52 = load i32, ptr %context.field.51, align 4
  %runtime.ok.53 = icmp eq i32 %context.value.52, 0
  br i1 %runtime.ok.53, label %runtime.continue.54, label %frame.failure.0
runtime.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.offset.60 = add i32 %context.value.59, 24
  %reserve.status.61 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.60, i32 4)
  %reserve.ok.62 = icmp eq i32 %reserve.status.61, 0
  br i1 %reserve.ok.62, label %reserve.continue.63, label %frame.failure.0
reserve.continue.63:
  %literal.status.64 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.59, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 18, i32 24, i32 7, i32 5)
  %helper.ok.65 = icmp eq i32 %literal.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %frame.failure.0
helper.continue.66:
  %context.field.67 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.68 = load i32, ptr %context.field.67, align 4
  %stack.sub.71 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.69 = icmp ule i32 %stack.offset.60, %context.value.68
  %descriptor.offset.inside.70 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.72 = icmp ule i32 24, %stack.sub.71
  %descriptor.payload.inside.73 = icmp ule i32 18, 24
  %descriptor.owner.offset.valid.74 = and i1 %descriptor.owner.inside.69, %descriptor.offset.inside.70
  %descriptor.range.inside.76 = and i1 %descriptor.owner.offset.valid.74, %descriptor.extent.inside.72
  %descriptor.range.valid.75 = and i1 %descriptor.range.inside.76, %descriptor.payload.inside.73
  %descriptor.type.valid.77 = icmp eq i32 7, 7
  %descriptor.valid.78 = and i1 %descriptor.range.valid.75, %descriptor.type.valid.77
  br i1 %descriptor.valid.78, label %descriptor.valid.79, label %descriptor.invalid.80
descriptor.invalid.80:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.79:
  %descriptor.initialized.status.81 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 24)
  %helper.ok.82 = icmp eq i32 %descriptor.initialized.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %step.status.84 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.85 = icmp eq i32 %step.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %context.field.87 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.88 = load i32, ptr %context.field.87, align 4
  %inline.target.depth.within.interpreter.limit.89 = icmp ule i32 %context.value.88, 65
  br i1 %inline.target.depth.within.interpreter.limit.89, label %inline.target.depth.ok.90, label %inline.target.depth.invalid.91
inline.target.depth.invalid.91:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.90:
  %descriptor.element.93 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.arguments.92, i32 0
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 0
  store i32 7, ptr %descriptor.field.94, align 4
  %descriptor.field.95 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 1
  store i32 %context.value.59, ptr %descriptor.field.95, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 2
  store i32 24, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 3
  store i32 18, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 4
  store i32 %stack.offset.60, ptr %descriptor.field.98, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %context.value.59, i32 20, i32 18, i32 %stack.offset.60, i32 24)
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %runtime.ok.101 = icmp eq i32 %context.value.100, 0
  br i1 %runtime.ok.101, label %runtime.continue.102, label %frame.failure.0
runtime.continue.102:
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %validator.depth.within.interpreter.limit.106 = icmp ule i32 %context.value.105, 64
  br i1 %validator.depth.within.interpreter.limit.106, label %validator.depth.ok.107, label %validator.depth.invalid.108
validator.depth.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 10, i32 0, i32 0)
  br label %frame.failure.0
validator.depth.ok.107:
  %validator.status.109 = call i32 @agentlang_word_0000(ptr %ctx, ptr %validator.arguments.92, ptr %validator.results.103, i32 10)
  %helper.ok.110 = icmp eq i32 %validator.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %validator.results.103, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  %descriptor.value.114 = load i32, ptr %descriptor.field.113, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  %descriptor.value.116 = load i32, ptr %descriptor.field.115, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  %descriptor.value.118 = load i32, ptr %descriptor.field.117, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  %descriptor.value.120 = load i32, ptr %descriptor.field.119, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  %descriptor.value.122 = load i32, ptr %descriptor.field.121, align 4
  %validator.result.type.matches.123 = icmp eq i32 %descriptor.value.114, 2
  br i1 %validator.result.type.matches.123, label %validator.result.type.ok.124, label %validator.result.type.invalid.125
validator.result.type.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
validator.result.type.ok.124:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.sub.130 = sub i32 %descriptor.value.122, %descriptor.value.116
  %descriptor.owner.inside.128 = icmp ule i32 %descriptor.value.122, %context.value.127
  %descriptor.offset.inside.129 = icmp ule i32 %descriptor.value.116, %descriptor.value.122
  %descriptor.extent.inside.131 = icmp ule i32 %descriptor.value.118, %stack.sub.130
  %descriptor.payload.inside.132 = icmp ule i32 %descriptor.value.120, %descriptor.value.118
  %descriptor.owner.offset.valid.133 = and i1 %descriptor.owner.inside.128, %descriptor.offset.inside.129
  %descriptor.range.inside.135 = and i1 %descriptor.owner.offset.valid.133, %descriptor.extent.inside.131
  %descriptor.range.valid.134 = and i1 %descriptor.range.inside.135, %descriptor.payload.inside.132
  %descriptor.type.valid.136 = icmp eq i32 2, 2
  %descriptor.valid.137 = and i1 %descriptor.range.valid.134, %descriptor.type.valid.136
  br i1 %descriptor.valid.137, label %descriptor.valid.138, label %descriptor.invalid.139
descriptor.invalid.139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.138:
  %descriptor.initialized.status.140 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.116, i32 %descriptor.value.118)
  %helper.ok.141 = icmp eq i32 %descriptor.initialized.status.140, 0
  br i1 %helper.ok.141, label %helper.continue.142, label %frame.failure.0
helper.continue.142:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.116, i32 20, i32 %descriptor.value.120, i32 %descriptor.value.122, i32 %descriptor.value.118)
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %runtime.ok.145 = icmp eq i32 %context.value.144, 0
  br i1 %runtime.ok.145, label %runtime.continue.146, label %frame.failure.0
runtime.continue.146:
  %validator.bool.147 = call i64 @al_owning_load_i64(ptr %ctx, i32 %descriptor.value.116)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %validator.bool.true.152 = icmp eq i64 %validator.bool.147, 1
  %validator.bool.false.153 = icmp eq i64 %validator.bool.147, 0
  %validator.bool.valid.154 = or i1 %validator.bool.true.152, %validator.bool.false.153
  br i1 %validator.bool.valid.154, label %validator.bool.check.155, label %validator.bool.invalid.156
validator.bool.invalid.156:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 9, i32 0, i32 0)
  br label %frame.failure.0
validator.bool.check.155:
  br i1 %validator.bool.true.152, label %validator.true.158, label %validator.false.157
validator.false.157:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 0, i32 0)
  br label %frame.failure.0
validator.true.158:
  br label %validator.join.159
validator.join.159:
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %stack.sub.164 = sub i32 %stack.offset.60, %context.value.59
  %descriptor.owner.inside.162 = icmp ule i32 %stack.offset.60, %context.value.161
  %descriptor.offset.inside.163 = icmp ule i32 %context.value.59, %stack.offset.60
  %descriptor.extent.inside.165 = icmp ule i32 24, %stack.sub.164
  %descriptor.payload.inside.166 = icmp ule i32 18, 24
  %descriptor.owner.offset.valid.167 = and i1 %descriptor.owner.inside.162, %descriptor.offset.inside.163
  %descriptor.range.inside.169 = and i1 %descriptor.owner.offset.valid.167, %descriptor.extent.inside.165
  %descriptor.range.valid.168 = and i1 %descriptor.range.inside.169, %descriptor.payload.inside.166
  %descriptor.type.valid.170 = icmp eq i32 6, 6
  %descriptor.valid.171 = and i1 %descriptor.range.valid.168, %descriptor.type.valid.170
  br i1 %descriptor.valid.171, label %descriptor.valid.172, label %descriptor.invalid.173
descriptor.invalid.173:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.172:
  %descriptor.initialized.status.174 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.59, i32 24)
  %helper.ok.175 = icmp eq i32 %descriptor.initialized.status.174, 0
  br i1 %helper.ok.175, label %helper.continue.176, label %frame.failure.0
helper.continue.176:
  %step.status.177 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.178 = icmp eq i32 %step.status.177, 0
  br i1 %helper.ok.178, label %helper.continue.179, label %frame.failure.0
helper.continue.179:
  %context.field.180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.181 = load i32, ptr %context.field.180, align 4
  %inline.target.depth.within.interpreter.limit.182 = icmp ule i32 %context.value.181, 65
  br i1 %inline.target.depth.within.interpreter.limit.182, label %inline.target.depth.ok.183, label %inline.target.depth.invalid.184
inline.target.depth.invalid.184:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 12, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.183:
  %stack.offset.185 = add i32 0, 18
  %stack.offset.186 = add i32 0, 24
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.offset.189 = add i32 %context.value.188, %stack.offset.186
  %reserve.status.190 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.189, i32 13)
  %reserve.ok.191 = icmp eq i32 %reserve.status.190, 0
  br i1 %reserve.ok.191, label %reserve.continue.192, label %frame.failure.0
reserve.continue.192:
  %stack.offset.193 = add i32 %context.value.188, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.193, i32 %context.value.59, i32 24, i32 18, i32 6, i32 6)
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %runtime.ok.196 = icmp eq i32 %context.value.195, 0
  br i1 %runtime.ok.196, label %runtime.continue.197, label %frame.failure.0
runtime.continue.197:
  %stack.offset.198 = add i32 0, 24
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.188, i32 %stack.offset.186, i32 %stack.offset.185, i32 0, i32 0)
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %runtime.ok.201 = icmp eq i32 %context.value.200, 0
  br i1 %runtime.ok.201, label %runtime.continue.202, label %frame.failure.0
runtime.continue.202:
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %stack.sub.207 = sub i32 %stack.offset.189, %context.value.188
  %descriptor.owner.inside.205 = icmp ule i32 %stack.offset.189, %context.value.204
  %descriptor.offset.inside.206 = icmp ule i32 %context.value.188, %stack.offset.189
  %descriptor.extent.inside.208 = icmp ule i32 %stack.offset.186, %stack.sub.207
  %descriptor.payload.inside.209 = icmp ule i32 %stack.offset.185, %stack.offset.186
  %descriptor.owner.offset.valid.210 = and i1 %descriptor.owner.inside.205, %descriptor.offset.inside.206
  %descriptor.range.inside.212 = and i1 %descriptor.owner.offset.valid.210, %descriptor.extent.inside.208
  %descriptor.range.valid.211 = and i1 %descriptor.range.inside.212, %descriptor.payload.inside.209
  %descriptor.type.valid.213 = icmp eq i32 5, 5
  %descriptor.valid.214 = and i1 %descriptor.range.valid.211, %descriptor.type.valid.213
  br i1 %descriptor.valid.214, label %descriptor.valid.215, label %descriptor.invalid.216
descriptor.invalid.216:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.215:
  %descriptor.initialized.status.217 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.188, i32 %stack.offset.186)
  %helper.ok.218 = icmp eq i32 %descriptor.initialized.status.217, 0
  br i1 %helper.ok.218, label %helper.continue.219, label %frame.failure.0
helper.continue.219:
  %descriptor.element.220 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.221 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.220, i32 0, i32 0
  store i32 5, ptr %descriptor.field.221, align 4
  %descriptor.field.222 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.220, i32 0, i32 1
  store i32 %context.value.188, ptr %descriptor.field.222, align 4
  %descriptor.field.223 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.220, i32 0, i32 2
  store i32 %stack.offset.186, ptr %descriptor.field.223, align 4
  %descriptor.field.224 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.220, i32 0, i32 3
  store i32 %stack.offset.185, ptr %descriptor.field.224, align 4
  %descriptor.field.225 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.220, i32 0, i32 4
  store i32 %stack.offset.189, ptr %descriptor.field.225, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.188, i32 20, i32 %stack.offset.185, i32 %stack.offset.189, i32 %stack.offset.186)
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %runtime.ok.228 = icmp eq i32 %context.value.227, 0
  br i1 %runtime.ok.228, label %runtime.continue.229, label %frame.failure.0
runtime.continue.229:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.233 = load i32, ptr %context.field.232, align 4
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %stack.offset.236 = add i32 %context.value.5, %context.value.7
  %stack.offset.237 = add i32 %context.value.231, %context.value.233
  %stack.sub.238 = sub i32 %stack.offset.236, %stack.offset.237
  %stack.sub.239 = sub i32 %context.value.7, %context.value.233
  %stack.sub.240 = sub i32 %context.value.235, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.238, i32 %stack.sub.239)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.240)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


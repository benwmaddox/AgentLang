# Native stack investigation evidence (225)

Scope: read-only production investigation on `feat/native-float-format`; probes and retained evidence are under `.agentlang/native-stack-225`. No float-format contract changes were made. Inputs are the existing 256-input corpus artifact (`tests-2927...`) that crashed during `OwningStackCompiledProgram.Execute`, and the later 32-input corpus artifacts (`tests-07a...`) that completed. Native artifacts were inspected/compiled, not run again for this investigation.

## Findings

| Corpus / optimization | Function | Clang `.su` bytes | `.su` class | COFF prologue allocation | COFF saved-register pushes | Prologue frame bytes |
|---|---|---:|---:|---:|---:|---:|
| 256 / O0 | `agentlang_entry_frame` | 1,599,544 | dynamic | 1,599,536 | 8 | 1,599,544 |
| 256 / O0 | `agentlang_owning_execute` | 17,512 | dynamic | 17,496 | 16 | 17,512 |
| 32 / O0 | `agentlang_entry_frame` | 27,960 | dynamic | 27,952 | 8 | 27,960 |
| 32 / O0 | `agentlang_owning_execute` | 2,280 | dynamic | 2,264 | 16 | 2,280 |
| 32 / O2 | `agentlang_entry_frame` | 936 | dynamic | 872 | 64 | 936 |
| 32 / O2 | `agentlang_owning_execute` | 968 | dynamic | 904 | 64 | 968 |

The 256-input O0 artifact has a fixed entry frame of about 1.6 MiB before any callee frames. That alone exceeds the conventional 1 MiB Windows thread-stack reservation, and is consistent with the recorded fatal stack overflow in `OwningStackCompiledProgram.Execute`. This identifies a concrete, sufficient cause for the observed crash; it does not establish the exact stack reservation or complete stack trace for every host. The 32-input O0 and O2 artifacts preserve the compared corpus while reducing the reported frames substantially.

The LLVM IR scan found, for `agentlang_entry_frame`, 1,536 allocas in the entry block and 512 fixed-size allocas in 256 non-entry blocks for the 256-input O0 artifact; the 32-input artifact has 192 entry allocas and 64 fixed-size allocas in 32 non-entry blocks. `agentlang_owning_execute` has 514 and 66 fixed-size allocas in non-entry blocks respectively. The scan found no variable-count alloca in either function. Entry-frame alloca types in the 256-input artifact include 256 `[32 x i8]` buffers, 256 `i1`, and 1,536 `i32` slots. The execute function includes per-input `i32` scratch and descriptor arrays.

These non-entry fixed allocas are still dynamically accumulated: executing an `alloca` in a non-entry block adjusts the stack each time that block is visited, and the generated function does not restore the stack pointer after each such instruction. The saved 32-input O0 assembly shows `__chkstk` followed by `subq %rax, %rsp` for a 32-byte and a 16-byte alloca inside `float.to.string.input.finite.1181` (assembly lines 2090–2098); the function restores its stack at its epilogue. There are two such alloca adjustments per finite-stringify block. In this corpus those finite blocks are distinct unrolled call sites; their aggregate small dynamic allocations are about 48 bytes per call site (about 1.5 KiB for 32, 12 KiB for 256), separate from the large 256-input fixed frame. Clang marks both functions `dynamic` in `.su` even though the IR scan found no variable-count alloca.

Windows x64 COFF `.pdata/.xdata` unwind records capture the prologue stack allocation and saved registers. They do not describe later body stack adjustments, so unwind allocation is not a complete function-frame bound when dynamic stack changes exist. Clang 19.1.5's `-fstack-usage` works on the LLVM IR object and on C runtime objects; it writes a tab-separated `.su` beside the object with `file:function`, byte count, and `static` or `dynamic`. The retained `runtime-O0-stack-usage.su` and `runtime-O2-stack-usage.su` are the C-runtime probe output. `.su` byte counts for `dynamic` functions are not upper bounds. `-fstack-size-section` was accepted but the COFF object had no `.stack_sizes` section or records.

## Bounded recommendation

Normalize only known constant scratch allocas emitted in these function bodies into the function entry block, with one distinct entry slot per original alloca and the original initialization/use sites unchanged. This retains callsite buffer separation and prevents repeated stack-pointer growth for the examined generated blocks. Do not apply a generic hoist/reuse transform to arbitrary allocas: escaping pointers, loop revisits, overlapping lifetimes, or address identity can make reuse observably different. The concrete emitter sites are the float stringify `asciiBuffer` (`[32 x i8]`) and `lengthPointer` (`i32`) in `OwningStackAot.fs`, plus the known per-input validation scratch slots emitted by the entry/execute wrappers.

Then use Clang `-fstack-usage` on each generated LLVM object and C runtime object, parse the records strictly, and reject a missing/malformed record, any `dynamic` record, or any per-function frame above the prototype's 64 KiB threshold before linking/invoking. Treat this as a conservative **per-frame screen only**. It does not bound transitive call chains, recursion, callback/host frames, or uninstrumented libraries. Untrusted native code still needs a worker-process boundary with an OS-enforced resource limit; this report is not a whole-call-chain safety proof.

## Limits and preserved references

The 256-input O2 compile was attempted against the 638 MB IR and manually interrupted after it remained too expensive for this bounded investigation. No 256/O2 frame number is claimed; the command, empty build log, and zero-byte temporary object are retained. The available O2 comparison is the 32-input artifact. The 256-input O0 / 32-input O0 / 32-input O2 `.su` and unwind evidence are in the filenames referenced by `stack-evidence-index.json`; `commands.txt` records the probe commands and `hashes.sha256` pins the source artifacts and direct evidence files.

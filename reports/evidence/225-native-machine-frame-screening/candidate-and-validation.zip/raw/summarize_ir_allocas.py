from pathlib import Path
import re, sys
for arg in sys.argv[1:]:
    path = Path(arg)
    current = None
    current_block = None
    first_block = None
    stats = {}
    for line_no, line in enumerate(path.open('r', encoding='utf-8', errors='replace'), 1):
        if line.startswith('define '):
            m = re.search(r'@([^ (]+)\(', line)
            current = m.group(1) if m else '<unknown>'
            stats[current] = {'entry_allocas': 0, 'nonentry_allocas': 0, 'variable_count_allocas': 0,
                              'nonentry_blocks': set(), 'types': {}}
            current_block = None
            first_block = None
        elif current is not None and line.strip() == '}':
            current = None
            current_block = None
            first_block = None
        elif current is not None:
            s = line.strip()
            if s.endswith(':') and not s.startswith(';'):
                current_block = s[:-1]
                if first_block is None:
                    first_block = current_block
            if re.search(r'\balloca\s', line):
                x = stats[current]
                if current_block == first_block:
                    x['entry_allocas'] += 1
                else:
                    x['nonentry_allocas'] += 1
                    x['nonentry_blocks'].add(current_block)
                m = re.search(r'\balloca\s+(.+)', line)
                declaration = m.group(1).strip() if m else '?'
                typ = re.split(r',\s*(?:align\s+\d+|i\d+\s+%|i\d+\s+\d+)', declaration, maxsplit=1)[0]
                x['types'][typ] = x['types'].get(typ, 0) + 1
                if re.search(r',\s*i\d+\s+%', line):
                    x['variable_count_allocas'] += 1
    print(f'FILE {path} bytes={path.stat().st_size}')
    for name, x in stats.items():
        print(f"FUNCTION {name} entry_allocas={x['entry_allocas']} nonentry_fixed_allocas={x['nonentry_allocas']} variable_count_allocas={x['variable_count_allocas']} nonentry_blocks={len(x['nonentry_blocks'])}")
        print('  alloca_types=' + repr(x['types']))

"""Read-only post-trial preservation and reuse audit for the email-batch actors."""

from __future__ import annotations

import argparse
import ast
from collections import Counter, deque
import difflib
import hashlib
import json
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
PREPARATION_PATH = HERE / "audit-preparation.json"
FREEZE_PATH = HERE / "freeze.json"
FLOW_HELPERS = {"email.apply-delivery-result", "email.delivery-fold-step"}
TARGET_NAME = "email.deliver-batch"
ALLOWED_FSHARP_EDITS = {"business/Business.fs", "tests/Program.fs"}
GENERATED_COMPONENTS = {"bin", "obj"}
TOP_LEVEL_LET = re.compile(r"^ {4}let\s+(?:(?:private|mutable)\s+)*([A-Za-z_][A-Za-z0-9_']*)\b", re.MULTILINE)
GROUP_CALL = re.compile(r'^\s+group\s+"([^"]+)"\s+([A-Za-z_][A-Za-z0-9_\']*)\s*$', re.MULTILINE)
CASE_DECLARATION = re.compile(r"^(?:test|example)\s+([^\s{]+)\s*\{", re.MULTILINE)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise TypeError(f"Expected a JSON object: {path}")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_inventory(root: Path, *, ignore_generated: bool = False) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root).as_posix()
        if ignore_generated and {part.lower() for part in Path(relative).parts} & GENERATED_COMPONENTS:
            continue
        data = path.read_bytes()
        rows.append({"path": relative, "bytes": len(data), "sha256": sha256_bytes(data)})
    return rows


def keyed_inventory(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(row["path"]): row for row in rows}


def load_store_manifest(project: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    store = project / ".agentlang/store"
    current = read_json(store / "CURRENT")
    manifest_hash = current.get("manifestHash")
    if not isinstance(manifest_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", manifest_hash):
        raise ValueError(f"Invalid store CURRENT manifestHash in {project}")
    manifest_path = store / "manifests" / f"{manifest_hash}.json"
    manifest = read_json(manifest_path)
    return current, manifest


def blob_path(project: Path, digest: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError(f"Invalid object hash: {digest!r}")
    return project / ".agentlang/store/objects" / f"{digest}.agent"


def blob_bytes(project: Path, digest: str) -> bytes | None:
    path = blob_path(project, digest)
    return path.read_bytes() if path.is_file() else None


def revision_index(manifest: dict[str, Any]) -> dict[tuple[str, int], dict[str, Any]]:
    return {(str(row["wordId"]), int(row["revision"])): row for row in manifest.get("revisions", [])}


def current_revision(word: dict[str, Any] | None, revisions: dict[tuple[str, int], dict[str, Any]]) -> dict[str, Any] | None:
    if word is None:
        return None
    return revisions.get((str(word["wordId"]), int(word["currentRevision"])))


def attached_hashes(revision: dict[str, Any], field: str) -> list[str]:
    return [str(row["hash"]) for row in revision.get(field, [])]


def object_ref_diff(seed_project: Path, actor_project: Path, old_hash: str, new_hash: str | None,
                    label: str) -> dict[str, Any]:
    old = blob_bytes(seed_project, old_hash)
    new = blob_bytes(actor_project, new_hash) if new_hash else None
    if old is None:
        return {"label": label, "oldHash": old_hash, "newHash": new_hash, "diff": None,
                "error": "accepted seed object blob is missing"}
    try:
        old_text = old.decode("utf-8").splitlines(keepends=True)
        new_text = new.decode("utf-8").splitlines(keepends=True) if new is not None else []
    except UnicodeDecodeError:
        return {"label": label, "oldHash": old_hash, "newHash": new_hash, "diff": None,
                "oldBytes": len(old), "newBytes": len(new) if new is not None else None,
                "error": "object is not UTF-8 text"}
    diff = "".join(difflib.unified_diff(old_text, new_text,
                                       fromfile=f"seed/{label}@{old_hash}",
                                       tofile=f"candidate/{label}@{new_hash or 'missing'}"))
    return {"label": label, "oldHash": old_hash, "newHash": new_hash, "diff": diff,
            "byteIdentical": old == new}


def load_terminal_trace(path: Path, *, synthetic: bool = False) -> dict[str, Any]:
    if not path.is_file():
        return {"path": str(path), "terminal": False, "reason": "trace file is missing", "synthetic": synthetic}
    rows: list[dict[str, Any]] = []
    try:
        for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
            if line.strip():
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise TypeError(f"trace row {line_number} is not an object")
                rows.append(row)
    except (OSError, UnicodeError, json.JSONDecodeError, TypeError) as error:
        return {"path": str(path), "terminal": False, "reason": f"unreadable trace: {type(error).__name__}: {error}",
                "synthetic": synthetic}
    if not rows or rows[0].get("event") != "session-start":
        return {"path": str(path), "terminal": False, "reason": "trace lacks session-start", "rowCount": len(rows),
                "synthetic": synthetic}
    ending = rows[-1]
    required = ("finishedUtc", "terminationKind", "hostExitCode", "runtimeExitCode")
    missing = [field for field in required if field not in ending]
    if ending.get("event") != "session-end" or missing:
        return {"path": str(path), "terminal": False, "reason": "trace tail is not a terminal session-end",
                "tailEvent": ending.get("event"), "missingTerminalFields": missing, "rowCount": len(rows),
                "synthetic": synthetic}
    malformed = []
    if not isinstance(ending.get("finishedUtc"), str) or not ending["finishedUtc"]:
        malformed.append("finishedUtc")
    if not isinstance(ending.get("terminationKind"), str) or not ending["terminationKind"]:
        malformed.append("terminationKind")
    if not isinstance(ending.get("hostExitCode"), int):
        malformed.append("hostExitCode")
    if not isinstance(ending.get("runtimeExitCode"), int):
        malformed.append("runtimeExitCode")
    if malformed:
        return {"path": str(path), "terminal": False, "reason": "session-end terminal fields are malformed",
                "malformedTerminalFields": malformed, "rowCount": len(rows), "synthetic": synthetic}
    exchanges = [row for row in rows if row.get("event") == "exchange"]
    return {
        "path": str(path), "terminal": True, "rowCount": len(rows), "exchangeCount": len(exchanges),
        "terminationKind": ending.get("terminationKind"), "hostExitCode": ending.get("hostExitCode"),
        "runtimeExitCode": ending.get("runtimeExitCode"), "finishedUtc": ending.get("finishedUtc"),
        "synthetic": synthetic, "rows": rows,
    }


def trace_gate(flow_trace_path: Path, fsharp_trace_path: Path, *, synthetic: bool = False) -> dict[str, Any]:
    # Both traces are fully checked before any candidate project path is touched.
    flow = load_terminal_trace(flow_trace_path, synthetic=synthetic)
    fsharp = load_terminal_trace(fsharp_trace_path, synthetic=synthetic)
    passed = flow.get("terminal") is True and fsharp.get("terminal") is True
    return {"passed": passed, "flow": flow, "fsharp": fsharp}


def definition_bindings(revision: dict[str, Any]) -> list[dict[str, Any]]:
    definition_hash = revision.get("definition", {}).get("hash")
    return [
        binding for binding in revision.get("callBindings", [])
        if binding.get("bodyRole") == "definition"
        and binding.get("source", {}).get("kind") == "word-definition"
        and binding.get("source", {}).get("hash") == definition_hash
    ]


def flow_trace_behavior(trace_rows: list[dict[str, Any]]) -> dict[str, Any]:
    operations: list[dict[str, Any]] = []
    for row in trace_rows:
        if row.get("event") != "exchange":
            continue
        operation = row.get("operation")
        if operation != "test-all":
            continue
        response = row.get("response")
        runtime = None
        if isinstance(response, dict) and isinstance(response.get("rawLine"), str):
            try:
                runtime = json.loads(response["rawLine"])
            except json.JSONDecodeError:
                pass
        data = runtime.get("data") if isinstance(runtime, dict) else None
        scalar_data = {}
        if isinstance(data, dict):
            scalar_data = {key: value for key, value in data.items()
                           if isinstance(value, (str, int, float, bool)) or value is None}
        operations.append({
            "exchange": row.get("index"), "requestOperation": operation,
            "responseOk": runtime.get("ok") if isinstance(runtime, dict) else None,
            "responseKind": runtime.get("kind") if isinstance(runtime, dict) else None,
            "responseText": str(runtime.get("text", ""))[:500] if isinstance(runtime, dict) else None,
            "dataKeys": sorted(data.keys()) if isinstance(data, dict) else [],
            "dataScalars": scalar_data,
        })
    return {"testAllObserved": bool(operations), "testAllExchanges": operations,
            "responseSuccessObserved": bool(operations) and all(row["responseOk"] is True for row in operations)}


def fsharp_validation_evidence(trace_rows: list[dict[str, Any]]) -> dict[str, Any]:
    validations: list[dict[str, Any]] = []
    count_pattern = re.compile(r"Business reference:\s*(\d+) groups,\s*(\d+) assertions")
    for row in trace_rows:
        if row.get("event") != "exchange" or row.get("operation") != "validate":
            continue
        runtime = None
        response = row.get("response")
        if isinstance(response, dict) and isinstance(response.get("rawLine"), str):
            try:
                runtime = json.loads(response["rawLine"])
            except json.JSONDecodeError:
                pass
        data = runtime.get("data") if isinstance(runtime, dict) else None
        stdout = data.get("stdout") if isinstance(data, dict) else None
        match = count_pattern.search(stdout) if isinstance(stdout, str) else None
        validations.append({
            "exchange": row.get("index"), "responseOk": runtime.get("ok") if isinstance(runtime, dict) else None,
            "exitCode": data.get("exitCode") if isinstance(data, dict) else None,
            "timedOut": data.get("timedOut") if isinstance(data, dict) else None,
            "businessReferenceGroups": int(match.group(1)) if match else None,
            "businessReferenceAssertions": int(match.group(2)) if match else None,
        })
    return {"validationObserved": bool(validations), "validations": validations,
            "latestPassed": bool(validations) and validations[-1].get("responseOk") is True
            and validations[-1].get("exitCode") == 0 and validations[-1].get("timedOut") is not True}


def flow_audit(seed_project: Path, actor_project: Path, flow_trace: dict[str, Any], preparation: dict[str, Any]) -> dict[str, Any]:
    seed_current, seed_manifest = load_store_manifest(seed_project)
    actor_current, actor_manifest = load_store_manifest(actor_project)
    seed_words = {str(row["wordId"]): row for row in seed_manifest.get("words", [])}
    actor_words = {str(row["wordId"]): row for row in actor_manifest.get("words", [])}
    seed_revisions = revision_index(seed_manifest)
    actor_revisions = revision_index(actor_manifest)
    seed_by_name = {str(row["currentName"]): row for row in seed_words.values()}
    actor_by_name = {str(row["currentName"]): row for row in actor_words.values()}
    helper_ids = {str(value) for value in preparation["flowHelperIds"].values()}
    changed_word_rows: list[dict[str, Any]] = []
    allowed_helper_pointer_changes: list[dict[str, Any]] = []
    missing_word_ids = sorted(set(seed_words) - set(actor_words))
    unauthorized_word_changes: list[dict[str, Any]] = []
    for word_id, old_row in seed_words.items():
        new_row = actor_words.get(word_id)
        if new_row is None or new_row == old_row:
            continue
        changed_word_rows.append({"stableId": word_id, "seed": old_row, "candidate": new_row})
        old_without_pointer = {key: value for key, value in old_row.items() if key != "currentRevision"}
        new_without_pointer = {key: value for key, value in new_row.items() if key != "currentRevision"}
        if word_id in helper_ids and old_without_pointer == new_without_pointer:
            allowed_helper_pointer_changes.append({"stableId": word_id, "name": old_row["currentName"],
                                                   "seedCurrentRevision": old_row["currentRevision"],
                                                   "candidateCurrentRevision": new_row["currentRevision"]})
        else:
            unauthorized_word_changes.append(word_id)

    changed_original_revisions: list[dict[str, Any]] = []
    for revision_key, old_revision in seed_revisions.items():
        new_revision = actor_revisions.get(revision_key)
        if new_revision != old_revision:
            changed_original_revisions.append({"stableId": revision_key[0], "revision": revision_key[1],
                                               "name": old_revision.get("name"),
                                               "candidatePresent": new_revision is not None})
    additional_revisions = [row for key, row in actor_revisions.items() if key not in seed_revisions]
    unauthorized_new_revisions = [
        {"stableId": row["wordId"], "revision": row["revision"], "name": row.get("name")}
        for row in additional_revisions
        if str(row["wordId"]) in seed_words and str(row["wordId"]) not in helper_ids
    ]
    new_word_revisions = [
        {"stableId": row["wordId"], "revision": row["revision"], "name": row.get("name"),
         "maturity": row.get("maturity")}
        for row in additional_revisions if str(row["wordId"]) not in seed_words
    ]

    seed_types = {str(row["name"]): row for row in seed_manifest.get("types", [])}
    actor_types = {str(row["name"]): row for row in actor_manifest.get("types", [])}
    changed_types = [name for name, row in seed_types.items() if actor_types.get(name) != row]
    added_types = sorted(set(actor_types) - set(seed_types))

    seed_objects_root = seed_project / ".agentlang/store/objects"
    actor_objects_root = actor_project / ".agentlang/store/objects"
    original_objects = sorted(path for path in seed_objects_root.rglob("*") if path.is_file() and not path.is_symlink())
    changed_objects: list[str] = []
    invalid_seed_object_addresses: list[str] = []
    for old_path in original_objects:
        old_digest = sha256_bytes(old_path.read_bytes())
        if old_path.stem != old_digest:
            invalid_seed_object_addresses.append(old_path.relative_to(seed_project).as_posix())
        candidate_path = actor_objects_root / old_path.relative_to(seed_objects_root)
        if not candidate_path.is_file() or sha256_bytes(candidate_path.read_bytes()) != old_digest:
            changed_objects.append(old_path.relative_to(seed_project).as_posix())

    missing_current_attachments: list[dict[str, Any]] = []
    inherited_tests = Counter()
    inherited_examples = Counter()
    for word_id, old_word in seed_words.items():
        old_revision = current_revision(old_word, seed_revisions)
        new_word = actor_words.get(word_id)
        new_revision = current_revision(new_word, actor_revisions)
        if old_revision is None or new_revision is None:
            missing_current_attachments.append({"stableId": word_id, "name": old_word["currentName"],
                                                "reason": "current revision missing"})
            continue
        for field, counter in (("tests", inherited_tests), ("examples", inherited_examples)):
            old_refs = attached_hashes(old_revision, field)
            new_refs = attached_hashes(new_revision, field)
            counter.update(old_refs)
            missing = Counter(old_refs) - Counter(new_refs)
            if missing:
                missing_current_attachments.append({"stableId": word_id, "name": old_word["currentName"],
                                                    "field": field, "missingHashes": list(missing.elements())})

    helper_body_checks = []
    flow_object_diffs = []
    for helper_name, helper_id in preparation["flowHelperIds"].items():
        old_word = seed_words.get(helper_id)
        new_word = actor_words.get(helper_id)
        old_revision = current_revision(old_word, seed_revisions)
        new_revision = current_revision(new_word, actor_revisions)
        old_hash = old_revision.get("definition", {}).get("hash") if old_revision else None
        new_hash = new_revision.get("definition", {}).get("hash") if new_revision else None
        identical = bool(old_hash and new_hash and blob_bytes(seed_project, old_hash) == blob_bytes(actor_project, new_hash))
        old_definition_bindings = definition_bindings(old_revision) if old_revision else []
        new_definition_bindings = definition_bindings(new_revision) if new_revision else []
        changed_case_binding_hashes = []
        if old_revision and new_revision:
            for field in ("tests", "examples"):
                for case_hash in attached_hashes(old_revision, field):
                    old_case_bindings = [binding for binding in old_revision.get("callBindings", [])
                                         if binding.get("source", {}).get("hash") == case_hash]
                    new_case_bindings = [binding for binding in new_revision.get("callBindings", [])
                                         if binding.get("source", {}).get("hash") == case_hash]
                    if old_case_bindings != new_case_bindings:
                        changed_case_binding_hashes.append(case_hash)
        definition_bindings_same = old_definition_bindings == new_definition_bindings
        helper_body_checks.append({"name": helper_name, "stableId": helper_id,
                                   "seedDefinitionHash": old_hash, "candidateDefinitionHash": new_hash,
                                   "bodyByteIdentical": identical,
                                   "definitionBindingsUnchanged": definition_bindings_same,
                                   "changedInheritedCaseBindingHashes": changed_case_binding_hashes})
        if not identical and old_hash:
            flow_object_diffs.append(object_ref_diff(seed_project, actor_project, old_hash, new_hash,
                                                     f"{helper_name}/definition"))

    for word_id, old_word in seed_words.items():
        old_revision = current_revision(old_word, seed_revisions)
        new_word = actor_words.get(word_id)
        new_revision = current_revision(new_word, actor_revisions)
        if old_revision is None or new_revision is None:
            continue
        for field in ("tests", "examples"):
            old_refs = attached_hashes(old_revision, field)
            new_refs = attached_hashes(new_revision, field)
            missing_refs = Counter(old_refs) - Counter(new_refs)
            if not missing_refs:
                continue
            new_case_by_name = {}
            for new_hash in new_refs:
                body = blob_bytes(actor_project, new_hash)
                if body:
                    match = CASE_DECLARATION.search(body.decode("utf-8", errors="replace"))
                    if match:
                        new_case_by_name[match.group(1)] = new_hash
            for old_hash in missing_refs.elements():
                old_body = blob_bytes(seed_project, old_hash)
                old_name = None
                if old_body:
                    match = CASE_DECLARATION.search(old_body.decode("utf-8", errors="replace"))
                    old_name = match.group(1) if match else None
                flow_object_diffs.append(object_ref_diff(seed_project, actor_project, old_hash,
                    new_case_by_name.get(old_name) if old_name else None,
                    f"{old_word['currentName']}/{field}/{old_name or old_hash}"))

    target_word = actor_by_name.get(TARGET_NAME)
    target_revision = current_revision(target_word, actor_revisions)
    if target_word is None or target_revision is None:
        target_report: dict[str, Any] = {"status": "incomplete", "reason": f"{TARGET_NAME} is absent from the candidate store"}
        closure: dict[str, Any] = {"status": "incomplete", "reason": "target function is absent"}
    else:
        target_test_hashes = attached_hashes(target_revision, "tests")
        target_example_hashes = attached_hashes(target_revision, "examples")
        def case_rows(hashes: list[str], kind: str) -> list[dict[str, Any]]:
            rows = []
            for digest in hashes:
                body = blob_bytes(actor_project, digest)
                text = body.decode("utf-8", errors="replace") if body is not None else ""
                match = CASE_DECLARATION.search(text)
                rows.append({"hash": digest, "name": match.group(1) if match else None,
                             "kind": kind, "blobPresent": body is not None})
            return rows
        target_report = {
            "status": "present", "stableId": target_word["wordId"], "currentRevision": target_word["currentRevision"],
            "maturity": target_revision.get("maturity"), "definitionHash": target_revision.get("definition", {}).get("hash"),
            "emailBatchResultTypePresent": "EmailBatchResult" in actor_types,
            "attachedTestCount": len(target_test_hashes), "attachedTests": case_rows(target_test_hashes, "test"),
            "attachedExampleCount": len(target_example_hashes), "attachedExamples": case_rows(target_example_hashes, "example"),
        }

        candidate_word_by_id = actor_words
        paths: dict[str, list[str]] = {str(target_word["wordId"]): [TARGET_NAME]}
        pending = deque([str(target_word["wordId"])])
        primitives: set[str] = set()
        unresolved: list[str] = []
        direct_bindings = definition_bindings(target_revision)
        while pending:
            source_id = pending.popleft()
            source_word = candidate_word_by_id.get(source_id)
            source_revision = current_revision(source_word, actor_revisions)
            if source_word is None or source_revision is None:
                unresolved.append(source_id)
                continue
            for binding in definition_bindings(source_revision):
                target = binding.get("target", {})
                kind = target.get("kind")
                if kind == "primitive":
                    primitives.add(str(target.get("identity", binding.get("requestedName", ""))))
                elif kind == "userWord":
                    dependency_id = str(target.get("identity"))
                    if dependency_id not in paths:
                        dependency_word = candidate_word_by_id.get(dependency_id)
                        dependency_name = str(dependency_word.get("currentName")) if dependency_word else str(binding.get("requestedName"))
                        paths[dependency_id] = [*paths[source_id], dependency_name]
                        pending.append(dependency_id)
        closure_rows = []
        for word_id, path in paths.items():
            word = candidate_word_by_id.get(word_id)
            revision = current_revision(word, actor_revisions)
            closure_rows.append({
                "stableId": word_id, "name": word.get("currentName") if word else None,
                "maturity": revision.get("maturity") if revision else None,
                "revision": word.get("currentRevision") if word else None,
                "pathFromTarget": path,
            })
        closure_rows.sort(key=lambda row: str(row["name"]))
        apply_id = str(preparation["flowHelperIds"]["email.apply-delivery-result"])
        direct_apply = any(binding.get("target", {}).get("kind") == "userWord"
                           and binding.get("target", {}).get("identity") == apply_id for binding in direct_bindings)
        apply_path = paths.get(apply_id)
        closure = {
            "status": "complete", "directUserCalls": [
                {"requestedName": binding.get("requestedName"), "stableId": binding.get("target", {}).get("identity"),
                 "candidateName": (candidate_word_by_id.get(str(binding.get("target", {}).get("identity"))) or {}).get("currentName")}
                for binding in direct_bindings if binding.get("target", {}).get("kind") == "userWord"
            ],
            "userWordClosure": closure_rows, "primitiveCalls": sorted(primitives),
            "unresolvedStableIds": sorted(set(unresolved)),
            "allUserWordDependenciesLibrary": not unresolved and all(row.get("maturity") == "library" for row in closure_rows),
            "emailApplyDeliveryResult": {
                "existingStableId": apply_id,
                "directReuse": direct_apply,
                "transitiveReuse": bool(apply_path) and not direct_apply,
                "reachableByExistingStableId": bool(apply_path),
                "reusePath": apply_path,
            },
        }

    original_object_count = len(original_objects)
    original_test_count = sum(len(row.get("tests", [])) for row in seed_manifest.get("revisions", []))
    original_example_count = sum(len(row.get("examples", [])) for row in seed_manifest.get("revisions", []))
    preservation_issues = []
    for label, condition in (
        ("missingOriginalWordIds", not missing_word_ids),
        ("unauthorizedCurrentWordRowChanges", not unauthorized_word_changes),
        ("changedOrMissingOriginalRevisions", not changed_original_revisions),
        ("unexpectedNewRevisions", not unauthorized_new_revisions),
        ("changedOriginalTypes", not changed_types),
        ("changedOriginalObjectBlobs", not changed_objects),
        ("invalidSeedObjectAddresses", not invalid_seed_object_addresses),
        ("missingInheritedCurrentAttachments", not missing_current_attachments),
        ("inheritedHelperDefinitionBodies", all(row["bodyByteIdentical"] for row in helper_body_checks)),
        ("inheritedHelperDefinitionBindings", all(row["definitionBindingsUnchanged"] for row in helper_body_checks)),
        ("inheritedHelperCaseBindings", all(not row["changedInheritedCaseBindingHashes"] for row in helper_body_checks)),
    ):
        if not condition:
            preservation_issues.append(label)
    current_counts = {
        "authoredWords": len(actor_manifest.get("words", [])), "types": len(actor_manifest.get("types", [])),
        "revisions": len(actor_manifest.get("revisions", [])),
    }
    return {
        "status": "incomplete" if target_report["status"] == "incomplete" else "completed",
        "seedManifest": {"hash": seed_current.get("manifestHash"), "generation": seed_current.get("generation")},
        "candidateManifest": {"hash": actor_current.get("manifestHash"), "generation": actor_current.get("generation")},
        "candidateCounts": current_counts,
        "preservationPassed": not preservation_issues,
        "preservationIssues": preservation_issues,
        "originalCounts": {"wordRows": len(seed_words), "revisionRows": len(seed_revisions),
                           "types": len(seed_types), "objectBlobs": original_object_count,
                           "attachedTests": original_test_count, "attachedExamples": original_example_count},
        "missingOriginalWordIds": missing_word_ids,
        "changedCurrentWordRows": changed_word_rows,
        "allowedHelperCurrentRevisionChanges": allowed_helper_pointer_changes,
        "unauthorizedCurrentWordRowChanges": unauthorized_word_changes,
        "changedOrMissingOriginalRevisions": changed_original_revisions,
        "allowedAdditionalHelperRevisions": [
            {"stableId": row["wordId"], "revision": row["revision"], "name": row.get("name"), "maturity": row.get("maturity")}
            for row in additional_revisions if str(row["wordId"]) in helper_ids
        ],
        "newWordRevisions": new_word_revisions,
        "unexpectedNewRevisions": unauthorized_new_revisions,
        "changedOriginalTypes": changed_types, "addedTypes": added_types,
        "changedOriginalObjectBlobs": changed_objects,
        "invalidSeedObjectAddresses": invalid_seed_object_addresses,
        "missingInheritedCurrentAttachments": missing_current_attachments,
        "inheritedHelperDefinitionBodies": helper_body_checks,
        "flowObjectDiffs": flow_object_diffs,
        "target": target_report,
        "transitiveLibraryClosure": closure,
        "traceBehaviorEvidence": flow_trace_behavior(flow_trace["rows"]),
    }


def top_level_blocks(source: str) -> dict[str, str]:
    matches = list(TOP_LEVEL_LET.finditer(source))
    result: dict[str, str] = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(source)
        result[match.group(1)] = source[match.start():end]
    return result


def group_calls_in_main(blocks: dict[str, str]) -> list[tuple[str, str]]:
    return GROUP_CALL.findall(blocks.get("main", ""))


def is_subsequence(expected: list[Any], actual: list[Any]) -> bool:
    iterator = iter(actual)
    return all(any(value == candidate for candidate in iterator) for value in expected)


def fsharp_audit(seed_project: Path, actor_project: Path, frozen_inventory: object,
                 preparation: dict[str, Any]) -> dict[str, Any]:
    seed_inventory = file_inventory(seed_project, ignore_generated=True)
    actor_inventory = file_inventory(actor_project, ignore_generated=True)
    seed_map, actor_map = keyed_inventory(seed_inventory), keyed_inventory(actor_inventory)
    expected_paths = set(preparation.get("acceptedFsharpSourceFiles", []))
    seed_paths_match_expected = bool(expected_paths) and set(seed_map) == expected_paths
    frozen_matches_seed = (seed_paths_match_expected and isinstance(frozen_inventory, list)
                           and keyed_inventory(seed_inventory) == keyed_inventory(frozen_inventory))
    changed_paths = sorted(
        path for path in set(seed_map) | set(actor_map)
        if seed_map.get(path) != actor_map.get(path)
    )
    changed_files = []
    generated_diffs: dict[str, str] = {}
    for relative in changed_paths:
        before_path, after_path = seed_project / relative, actor_project / relative
        before = before_path.read_bytes() if before_path.is_file() else b""
        after = after_path.read_bytes() if after_path.is_file() else b""
        entry = {"path": relative, "allowed": relative in ALLOWED_FSHARP_EDITS,
                 "seedSha256": sha256_bytes(before) if before_path.is_file() else None,
                 "candidateSha256": sha256_bytes(after) if after_path.is_file() else None,
                 "seedPresent": before_path.is_file(), "candidatePresent": after_path.is_file()}
        try:
            before_lines = before.decode("utf-8").splitlines(keepends=True)
            after_lines = after.decode("utf-8").splitlines(keepends=True)
            diff = "".join(difflib.unified_diff(before_lines, after_lines,
                                               fromfile=f"seed/{relative}" if before_path.is_file() else "/dev/null",
                                               tofile=f"candidate/{relative}" if after_path.is_file() else "/dev/null"))
            generated_diffs[relative] = diff
        except UnicodeDecodeError:
            generated_diffs[relative] = f"Binary/non-UTF-8 file differs: {len(before)} seed bytes, {len(after)} candidate bytes.\n"
        changed_files.append(entry)

    seed_program_path = seed_project / "tests/Program.fs"
    actor_program_path = actor_project / "tests/Program.fs"
    seed_program = seed_program_path.read_text(encoding="utf-8")
    actor_program = actor_program_path.read_text(encoding="utf-8") if actor_program_path.is_file() else ""
    seed_blocks, actor_blocks = top_level_blocks(seed_program), top_level_blocks(actor_program)
    original_bindings = sorted(name for name in seed_blocks if name != "main")
    changed_original_bindings = [name for name in original_bindings if actor_blocks.get(name) != seed_blocks[name]]
    original_group_calls = group_calls_in_main(seed_blocks)
    candidate_group_calls = group_calls_in_main(actor_blocks)
    old_group_calls_retained = is_subsequence(original_group_calls, candidate_group_calls)
    added_group_calls = list((Counter(candidate_group_calls) - Counter(original_group_calls)).elements())
    program_changed = "tests/Program.fs" in changed_paths
    assertion_review = {
        "originalTopLevelBindingsExceptMain": original_bindings,
        "lineEndingNormalizedIdenticalOriginalBindings": [
            name for name in original_bindings if name not in changed_original_bindings
        ],
        "changedOriginalBindings": changed_original_bindings,
        "originalGroupCalls": original_group_calls,
        "candidateGroupCalls": candidate_group_calls,
        "addedGroupCalls": added_group_calls,
        "allOriginalGroupCallsRetainedInOrder": old_group_calls_retained,
        "programDiffGenerated": program_changed,
        "explicitRootReviewRequired": program_changed,
        "preservationClaim": "original test/support bindings are line-ending-normalized source-identical and prior group calls retained"
        if not changed_original_bindings and old_group_calls_retained
        else "not established; inspect generated tests/Program.fs diff",
    }
    allowed_scope = all(row["allowed"] for row in changed_files)
    source_scope_passed = frozen_matches_seed and allowed_scope
    return {
        "status": "completed", "frozenFiveFileInventoryMatchesAcceptedSeed": frozen_matches_seed,
        "acceptedSeedPathsMatchPreparation": seed_paths_match_expected,
        "seedFileCount": len(seed_inventory), "candidateSourceFileCountIgnoringBinObj": len(actor_inventory),
        "changedPaths": changed_paths, "changedFiles": changed_files,
        "onlyAllowedPathsChanged": allowed_scope, "sourceScopePassed": source_scope_passed,
        "allowedEditPaths": sorted(ALLOWED_FSHARP_EDITS),
        "generatedDiffsForRootReview": generated_diffs,
        "inheritedAssertions": assertion_review,
    }


def resolve_repo_path(value: str) -> Path:
    path = Path(value)
    resolved = path.resolve() if path.is_absolute() else (REPO / path).resolve()
    if not resolved.is_relative_to(REPO.resolve()):
        raise ValueError(f"Path escapes repository root: {value}")
    return resolved


def run_audit(seed_flow: Path, candidate_flow: Path, seed_fsharp: Path, candidate_fsharp: Path,
              flow_trace: dict[str, Any], fsharp_trace: dict[str, Any], frozen_fsharp_inventory: object,
              preparation: dict[str, Any]) -> dict[str, Any]:
    # This function is called only after trace_gate passes. Keep candidate access below this point.
    if not flow_trace.get("terminal") or not fsharp_trace.get("terminal"):
        return {"status": "incomplete", "candidateSourcesRead": False,
                "reason": "both actor traces must end with terminal session-end rows"}
    try:
        flow = flow_audit(seed_flow, candidate_flow, flow_trace, preparation)
        fsharp = fsharp_audit(seed_fsharp, candidate_fsharp, frozen_fsharp_inventory, preparation)
    except (OSError, UnicodeError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        return {"status": "incomplete", "candidateSourcesRead": True,
                "reason": f"audit input could not be read: {type(error).__name__}: {error}"}
    fsharp_trace_evidence = fsharp_validation_evidence(fsharp_trace["rows"])
    target_present = flow.get("target", {}).get("status") == "present"
    status = "completed" if target_present else "incomplete"
    checks = {
        "flowPreservation": flow.get("preservationPassed"),
        "flowTargetLibrary": flow.get("target", {}).get("maturity") == "library" if target_present else None,
        "flowTargetHasTests": flow.get("target", {}).get("attachedTestCount", 0) > 0 if target_present else None,
        "flowEmailBatchResultType": flow.get("target", {}).get("emailBatchResultTypePresent") if target_present else None,
        "flowLibraryClosure": flow.get("transitiveLibraryClosure", {}).get("allUserWordDependenciesLibrary") if target_present else None,
        "flowTestAllObserved": flow.get("traceBehaviorEvidence", {}).get("testAllObserved"),
        "flowTestAllResponsesOk": flow.get("traceBehaviorEvidence", {}).get("responseSuccessObserved"),
        "fsharpScope": fsharp.get("sourceScopePassed"),
        "fsharpOriginalAssertionBindings": not fsharp.get("inheritedAssertions", {}).get("changedOriginalBindings", []),
        "fsharpPriorGroupsRetained": fsharp.get("inheritedAssertions", {}).get("allOriginalGroupCallsRetainedInOrder"),
        "fsharpValidationPassed": fsharp_trace_evidence.get("latestPassed"),
    }
    return {
        "status": status,
        "auditPassed": status == "completed" and all(value is True for value in checks.values()),
        "candidateSourcesRead": True,
        "traceGate": {"flow": {key: value for key, value in flow_trace.items() if key != "rows"},
                      "fsharp": {key: value for key, value in fsharp_trace.items() if key != "rows"}},
        "flow": flow,
        "fsharp": fsharp,
        "fsharpTraceValidationEvidence": fsharp_trace_evidence,
        "acceptanceChecks": checks,
        "reviewNotes": [
            "Generated F# unified diffs are attached; inspect Business.fs and Program.fs before making semantic claims.",
            "Program.fs original test/support bindings are compared as complete top-level blocks; main group calls are checked as an ordered subsequence.",
            "Flow preservation is structural and content-addressed; test-all responses are reported from the terminal trace.",
        ],
    }


def load_preparation() -> dict[str, Any]:
    preparation = read_json(PREPARATION_PATH)
    if preparation.get("schemaVersion") != 1:
        raise ValueError("Unsupported audit-preparation schema version")
    return preparation


def seed_paths(preparation: dict[str, Any]) -> tuple[Path, Path]:
    return (resolve_repo_path(preparation["acceptedFlowSeedProject"]),
            resolve_repo_path(preparation["acceptedFsharpSeedProject"]))


def load_frozen_actors() -> dict[str, dict[str, Any]]:
    freeze = read_json(FREEZE_PATH)
    actors = freeze.get("actorInputs")
    if not isinstance(actors, list):
        raise ValueError("freeze.json lacks an actorInputs list")
    by_arm = {str(row.get("arm")): row for row in actors if isinstance(row, dict)}
    if set(by_arm) != {"flow", "fsharp"}:
        raise ValueError("freeze.json must contain exactly one Flow actor and one F# actor")
    return by_arm


def prepare_self_test(preparation: dict[str, Any]) -> dict[str, Any]:
    seed_flow, seed_fsharp = seed_paths(preparation)
    with tempfile.TemporaryDirectory(prefix="email-batch175-audit-selftest-", dir=REPO) as temp_name:
        temp = Path(temp_name)
        flow_copy, fsharp_copy = temp / "flow", temp / "fsharp"
        shutil.copytree(seed_flow, flow_copy)
        shutil.copytree(seed_fsharp, fsharp_copy)
        flow_trace_path, fsharp_trace_path = temp / "flow-trace.jsonl", temp / "fsharp-trace.jsonl"
        synthetic_start = {"event": "session-start", "schemaVersion": 1, "syntheticSelfTest": True}
        synthetic_end = {"event": "session-end", "finishedUtc": "synthetic-self-test-only",
                         "terminationKind": "host-close", "hostExitCode": 0, "runtimeExitCode": 0,
                         "syntheticSelfTest": True}
        trace_text = "\n".join(json.dumps(row, separators=(",", ":")) for row in (synthetic_start, synthetic_end)) + "\n"
        flow_trace_path.write_text(trace_text, encoding="utf-8")
        fsharp_trace_path.write_text(trace_text, encoding="utf-8")
        gate = trace_gate(flow_trace_path, fsharp_trace_path, synthetic=True)
        if not gate["passed"]:
            raise AssertionError("synthetic terminal traces were not accepted")
        flow_trace, fsharp_trace = gate["flow"], gate["fsharp"]
        report = run_audit(seed_flow, flow_copy, seed_fsharp, fsharp_copy, flow_trace, fsharp_trace,
                           file_inventory(seed_fsharp), preparation)
        if report.get("status") != "incomplete" or report.get("flow", {}).get("target", {}).get("status") != "incomplete":
            raise AssertionError("baseline seed without email.deliver-batch must be reported incomplete")
        if report.get("flow", {}).get("preservationPassed") is not True:
            raise AssertionError("identical Flow seed copy failed preservation self-check")
        if report.get("fsharp", {}).get("sourceScopePassed") is not True:
            raise AssertionError("identical F# seed copy failed scope self-check")
        inherited = report.get("fsharp", {}).get("inheritedAssertions", {})
        if inherited.get("changedOriginalBindings") or inherited.get("allOriginalGroupCallsRetainedInOrder") is not True:
            raise AssertionError("identical F# seed copy failed inherited assertion block self-check")

        unfinished_trace = temp / "flow-trace-incomplete.jsonl"
        unfinished_trace.write_text(json.dumps(synthetic_start) + "\n", encoding="utf-8")
        bad_gate = trace_gate(unfinished_trace, fsharp_trace_path, synthetic=True)
        tripwire_candidate = temp / "candidate-source-must-not-be-read"
        blocked_report = run_audit(seed_flow, tripwire_candidate, seed_fsharp, tripwire_candidate,
                                   bad_gate["flow"], bad_gate["fsharp"], [], preparation)
        if bad_gate["passed"] or blocked_report.get("candidateSourcesRead") is not False:
            raise AssertionError("nonterminal trace did not block candidate-source access")
        return {
            "passed": True,
            "syntheticTraceLabel": "syntheticSelfTest; not actor outcome evidence",
            "pythonAstParsePassed": True,
            "identicalSeedCopiesPreservationPassed": True,
            "originalFsharpBindingsLineEndingNormalizedIdentical": True,
            "originalFsharpGroupCallsRetainedInOrder": True,
            "targetAbsentReportedIncomplete": True,
            "nonterminalTraceBlocksCandidateRead": True,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true", help="audit only disposable accepted-seed copies and synthetic traces")
    args = parser.parse_args()
    preparation = load_preparation()
    seed_flow, seed_fsharp = seed_paths(preparation)
    seed_current, seed_manifest = load_store_manifest(seed_flow)
    if seed_current.get("manifestHash") != preparation.get("acceptedFlowManifestHash"):
        raise SystemExit("Accepted Flow seed manifest differs from audit-preparation.json.")
    expected_counts = preparation.get("acceptedFlowCounts", {})
    actual_counts = {"words": len(seed_manifest.get("words", [])), "revisions": len(seed_manifest.get("revisions", [])),
                     "types": len(seed_manifest.get("types", []))}
    if any(actual_counts.get(key) != value for key, value in expected_counts.items()):
        raise SystemExit(f"Accepted Flow seed counts differ from audit-preparation.json: {actual_counts}")
    fsharp_seed_inventory = file_inventory(seed_fsharp, ignore_generated=True)
    if len(fsharp_seed_inventory) != preparation.get("acceptedFsharpSourceCount") or \
       set(keyed_inventory(fsharp_seed_inventory)) != set(preparation.get("acceptedFsharpSourceFiles", [])):
        raise SystemExit("Accepted F# source file inventory differs from audit-preparation.json.")

    if args.self_test:
        ast.parse(Path(__file__).read_text(encoding="utf-8"), filename=Path(__file__).name)
        self_test = prepare_self_test(preparation)
        preparation["auditScriptSha256"] = sha256_bytes(Path(__file__).read_bytes())
        preparation["selfCheck"] = self_test
        write_json(PREPARATION_PATH, preparation)
        print(json.dumps({"status": "passed", **self_test}, separators=(",", ":")))
        return 0

    frozen = load_frozen_actors()
    flow_trace_path = resolve_repo_path(str(frozen["flow"]["trace"]))
    fsharp_trace_path = resolve_repo_path(str(frozen["fsharp"]["trace"]))
    gate = trace_gate(flow_trace_path, fsharp_trace_path)
    if not gate["passed"]:
        report = {"status": "incomplete", "candidateSourcesRead": False,
                  "reason": "both actor traces must end with terminal session-end rows before candidate sources are read",
                  "traceGate": {"flow": {key: value for key, value in gate["flow"].items() if key != "rows"},
                                "fsharp": {key: value for key, value in gate["fsharp"].items() if key != "rows"}}}
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 2

    # Candidate project paths are not checked or opened until after both traces have terminal session-end rows.
    candidate_flow = resolve_repo_path(str(frozen["flow"]["project"]))
    candidate_fsharp = resolve_repo_path(str(frozen["fsharp"]["project"]))
    report = run_audit(seed_flow, candidate_flow, seed_fsharp, candidate_fsharp,
                       gate["flow"], gate["fsharp"], frozen["fsharp"].get("seedProjectInventory"), preparation)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report.get("status") == "incomplete":
        return 2
    return 0 if report.get("auditPassed") else 1


if __name__ == "__main__":
    raise SystemExit(main())

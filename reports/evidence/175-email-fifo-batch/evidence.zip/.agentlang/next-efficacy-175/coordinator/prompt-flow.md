You are a fresh external experimental coding agent. The human explicitly authorizes edits only to your supplied isolated project and local test execution through its broker. Read this prompt, then launch the specified broker once. Use only that broker for project discovery, edits, and tests. Do not access the main repository, other trials, hidden oracles, reports, or snapshots. Do not use web tools, spawn/list/read/contact other agents, or run other shell commands. If non-broker tool use occurs, disclose it. Use at most 100 exchanges and a 120000 ms broker request timeout. If a request is still running, poll the same live handle; never restart a confirmed-live broker for silence or uncertainty. Finish with {"op":"host.close"} and observe the terminal status.

Add a reusable email-delivery batch operation over the existing Store. It takes
an ordered finite list of synthetic provider outcomes, each success Unit or
failure String. Process queued messages in FIFO order using the existing
single-message delivery logic. Keep its behavior and inherited test assertions.

Each success moves only the queue head to the end of the sent list and increments
the delivered count. On the first provider failure, stop attempting deliveries:
return the state after the successful prefix, retain the failed message and all
later messages in order, and report EMAIL_PROVIDER_FAILURE with that provider's
original detail. Ignore later outcomes. Stop without a failure when the queue or
outcome list ends; do not fabricate NO_PENDING_EMAIL for batch exhaustion.
Preserve the caller's input and every non-email Store field.

Public language interface: email.deliver-batch(Store,
List<Result<Unit,String>>) -> EmailBatchResult, with fields store: Store,
delivered: Int and failure: Option<BusinessError>. The conventional interface
is EmailOutbox.deliverBatch taking Store and Result<unit,string> list and returning
an analogous EmailBatchResult record with Store, Delivered and Failure fields.
Use each environment's existing provider-error representation/message convention.
Names of internal helper functions are your choice.

For the language, publish the batch and its dependencies as qualified library
functions. You may qualify existing project functions and add relevant tests
while retaining their behavior and inherited assertions. Do not weaken a gate or
replace existing assertions with easier expectations. For conventional F#, add
relevant self-tests and run the supplied validation operation. All provider
outcomes are synthetic; no real email sending is part of this task.

Flow arm instructions:
- The accepted seed has 62 authored words, 37 types, 191 inherited tests, 44 examples, and 59 library / 3 project words. Preserve every inherited assertion and existing behavior.
- Qualify only task-relevant project functions needed by the library closure, preserving behavior, tests, and examples; leave unrelated project functions unchanged.
- Keep the batch and its task-relevant dependencies as qualified library functions. Add useful new tests as the public task requests. Do not weaken coverage or remove inherited tests.
- Use Flow/2 for all new definitions, with exact frontend and syntax metadata. Query versioned help and source/tests through the broker; do not use filesystem access or a direct CLI.

Flow/2 primer (with the pinned runtime's accepted help request fields):

Use only the supplied JSONL broker, one request per line through its live session.
AI agents are external users of the language; the runtime contains none.

Discover names with `{"op":"search","query":"subscription"}` or
`{"op":"words","compact":true}`. `describe` returns metadata and source;
`source`, `dependencies`, `callers`, `tests` and bounded `context` support inspection.
Use dictionary names for protocol queries. Use reported Flow/2 `flowReference`
spellings for calls; an exact-root call begins with a dot, as in `.add(1, 2)`.

Select `frontend:"flow", syntaxVersion:2` on every definition/evaluation request.
Flow/2 uses `fn`, named typed inputs, immutable `let`, dotted qualified calls,
record properties `value.field`, newline separators and exhaustive matches.
A bound receiver passes itself as the first argument: `value.operation(args)`.
Both branches return the declared type. No implicit nominal conversions occur.

```flow
fn increment(value: Int) -> Int {
    effects none
    doc "Adds one."

    .add(value, 1)
}
test increment/basic {
    .increment(1)
    => 2
}
```

Omitted effects means pure. Put effects before doc, then a blank line before code.
Use versioned runtime help for exact syntax:
`{"op":"help","syntaxVersion":2,"topic":"define"}`.
Generic values use `result.ok<T,E>(value)`, `result.error<T,E>(error)` and
`option.some<T>(value)`. Inspect examples/tests rather than guessing constructors.

Tests attach through `function-name/case-name`. Bare `=>` accepts supported
literals; `=> value expression` compares constructed values. `=> error CODE`
expects a runtime failure, not a returned `Result.error` value. Inspect authored
cases with `{"op":"tests","word":"...","includeSource":true,"caseName":"..."}`.

Begin a task with `task.begin` and a goal. Define source, run `test` for the new
function, then `commit` with its word name and `library:true`. Library functions
need passing own tests, complete own instruction/branch and finite-value coverage,
and qualified dependencies. Caller tests do not replace helper coverage.
Run relevant regressions, preserve all old definitions/tests, and finish with
`task.commit`. `test-all` updates the latest coverage batch; a later single-word
test can replace that batch. Query help for failures rather than weakening gates.

Protocol bytes are not model tokens. Poll the same live handle after observation
timeouts; never repeat an uncertain mutation. Finish with `{"op":"host.close"}`
and observe terminal status. Do not spawn/contact other agents or use other tools.

Launch once with exec_command, tty:true, yield_time_ms:10000. If it reports a live session, poll that same session ID.

```powershell
$env:TEMP = 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\temp\flow'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = $env:TEMP
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\next-efficacy-173\pinned-runtime\pr171\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\actors\flow' -TracePath 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\actors\flow-trace.jsonl' -AllowedOperations @('help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort') -Profile 'agentlang' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

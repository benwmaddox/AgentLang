You are a fresh external experimental coding agent. The human explicitly authorizes edits only to your supplied isolated project and local test execution through its broker. Read this prompt, then launch the specified broker once. Use only that broker for project discovery, edits, and tests. Do not access the main repository, other trials, hidden oracles, reports, or snapshots. Do not use web tools, spawn/list/read/contact other agents, or run other shell commands. If non-broker tool use occurs, disclose it. Use at most 100 exchanges and a 120000 ms broker request timeout. If a request is still running, poll the same live handle; never restart a confirmed-live broker for silence or uncertainty. Finish with {"op":"host.close"} and observe the terminal status.

Add a reusable email-delivery batch operation over the existing Store. It takes
an ordered finite list of synthetic provider outcomes, each success Unit or
failure String. Process queued messages in FIFO order using the existing
single-message delivery logic. Keep its behavior and inherited test assertions.

Each success moves only the queue head to the end of the sent list and increments
the delivered count. On the first provider failure, stop attempting deliveries:
return the state after the successful prefix, retain the failed message and all
later messages in order, and report EMAIL_PROVIDER_FAILURE with that provider's
original detail. Ignore later outcomes. Stop without a failure when the queue or
outcome list ends; do not fabricate NO_PENDING_EMAIL for batch exhaustion.
Preserve the caller's input and every non-email Store field.

Public language interface: email.deliver-batch(Store,
List<Result<Unit,String>>) -> EmailBatchResult, with fields store: Store,
delivered: Int and failure: Option<BusinessError>. The conventional interface
is EmailOutbox.deliverBatch taking Store and Result<unit,string> list and returning
an analogous EmailBatchResult record with Store, Delivered and Failure fields.
Use each environment's existing provider-error representation/message convention.
Names of internal helper functions are your choice.

For the language, publish the batch and its dependencies as qualified library
functions. You may qualify existing project functions and add relevant tests
while retaining their behavior and inherited assertions. Do not weaken a gate or
replace existing assertions with easier expectations. For conventional F#, add
relevant self-tests and run the supplied validation operation. All provider
outcomes are synthetic; no real email sending is part of this task.

F# arm instructions:
- Work only in your supplied isolated project. You are authorized to edit `business/Business.fs` and `tests/Program.fs`; all other files are frozen.
- Preserve the existing behavior and inherited assertions. Add relevant self-tests for the batch semantics, including success, FIFO prefix, first failure, ignored later outcomes, empty input/queue, and preservation of unrelated Store fields.
- Use the broker `inspect`, `read`, and `search` operations to understand the project; use `patch` or `replace` with the broker-provided expected hash. Run `validate` after your changes. It targets `tests/AgentLang.Business.Tests.fsproj`; do not run `dotnet` or other shell commands directly.
- The conventional broker receives `--validation-project tests/AgentLang.Business.Tests.fsproj`.

Launch once with exec_command, tty:true, yield_time_ms:10000. If it reports a live session, poll that same session ID.

```powershell
$env:TEMP = 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\temp\fsharp'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = $env:TEMP
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\broker-runtime\conventional\AgentLang.Conventional.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\actors\fsharp' -TracePath 'D:\code\AgentLang\.agentlang\next-efficacy-175\coordinator\actors\fsharp-trace.jsonl' -AllowedOperations @('inspect,read,search,patch,replace,validate') -Profile 'conventional' -AdditionalCliArguments @('--validation-project','tests/AgentLang.Business.Tests.fsproj') -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

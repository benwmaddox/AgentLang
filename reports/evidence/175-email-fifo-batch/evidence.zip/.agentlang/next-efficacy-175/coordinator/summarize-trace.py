"""Summarize completed broker evidence; never infer LLM tokens from byte counts."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('trace', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
assert not args.output.exists(), 'Refuse evidence overwrite'
rows = [json.loads(line) for line in args.trace.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
starts = [row for row in rows if row['event'] == 'session-start']
ends = [row for row in rows if row['event'] == 'session-end']
assert len(starts) == len(ends) == 1, 'A completed single broker session is required'
assert rows[-1]['event'] == 'session-end', 'Evidence exists after terminal event'
exchanges = [row for row in rows if row['event'] == 'exchange']
errors, validation_failures = [], []
for row in exchanges:
    response = row.get('response') or {}
    raw = response.get('canonical') or response.get('rawLine')
    if not raw:
        errors.append({'index': row['index'], 'operation': row['operation'], 'code': 'NO_RESPONSE'})
        continue
    value = json.loads(raw)
    if not value.get('ok', False):
        error = value.get('error') or {}
        errors.append({'index': row['index'], 'operation': row['operation'], 'code': error.get('code', 'REJECTED')})
    data = value.get('data') or {}
    if row['operation'] == 'validate' and data.get('exitCode', 0) != 0:
        validation_failures.append({'index': row['index'], 'exitCode': data['exitCode']})
start, end = starts[0], ends[0]
report = {
    'trace': str(args.trace), 'traceSha256': hashlib.sha256(args.trace.read_bytes()).hexdigest(),
    'profile': start['profile'], 'terminationKind': end['terminationKind'],
    'hostExitCode': end['hostExitCode'], 'runtimeExitCode': end['runtimeExitCode'],
    'brokerExchanges': len(exchanges), 'operations': dict(Counter(row['operation'] for row in exchanges)),
    'rejectedResponses': errors, 'conventionalValidationFailures': validation_failures,
    'requestPayloadUtf8Bytes': sum(row['request']['payloadUtf8Bytes'] for row in exchanges),
    'responseTextUtf8Bytes': sum(len((row.get('response') or {}).get('rawLine', '').encode('utf-8')) for row in exchanges),
    'brokerElapsedSeconds': (datetime.fromisoformat(end['finishedUtc']) - datetime.fromisoformat(start['startedUtc'])).total_seconds(),
    'llmInputTokens': None, 'llmOutputTokens': None, 'agentTurns': None,
    'limits': 'Protocol byte counts are not LLM tokens or context consumption. Concurrent runs do not support causal latency comparison. Rejected responses are observations, not all resolved-error events.',
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))

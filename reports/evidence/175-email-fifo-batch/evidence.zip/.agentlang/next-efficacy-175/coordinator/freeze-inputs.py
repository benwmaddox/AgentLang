"""Verify bounded study evidence before authorizing fresh participants."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

repo = Path.cwd().resolve()
base = repo / '.agentlang/next-efficacy-175'
coordinator = base / 'coordinator'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def checked(relative):
    path = (repo / relative).resolve()
    assert path.is_relative_to(repo) and path.is_file(), relative
    return path

actors_path = coordinator / 'actors.json'
actors = read(actors_path)
assert not actors['frozen'] and not actors['dispatched']
assert not (coordinator / 'freeze.json').exists()
pins = read(base / 'oracle/input-hashes.json')['inputs']
for row in pins:
    assert digest(checked(row['path'])) == row['sha256'], row['path']
calibration_path = base / 'oracle/calibration-summary.json'
calibration = read(calibration_path)
assert calibration['caseInputSha256'] == digest(base / 'oracle/cases.json')
for arm in ('flow', 'fsharp'):
    control = calibration[arm]['correct']
    mutants = calibration[arm]['mutants']
    assert len(mutants) == 4
    for row in [control] + mutants:
        result_path = checked(row['resultPath'])
        assert digest(result_path) == row['resultSha256']
        result = read(result_path)
        if 'derivedFrom' in row:
            original = row['derivedFrom']
            assert digest(checked(original['resultPath'])) == original['resultSha256']
            assert len(read(checked(original['resultPath']))['cases']) == 6
        if 'candidateSourcePath' in row:
            assert digest(checked(row['candidateSourcePath'])) == row['candidateSourceSha256']
        assert row['executed'] and row['caseCount'] == 6 and not row['executionErrors']
        assert result['passed'] == row['passed']
        assert len(result['cases']) == 6
        if arm == 'flow':
            checks = [check for case in result['cases'] for check in case['checks']]
            assert len(checks) == 60
            assert all(check['error'] is None and isinstance(check['actual'], bool) for check in checks)
        else:
            assert result['responseCount'] == 6
        if not row['passed']:
            assert any(not case['passed'] for case in result['cases'])
    assert control['passed'] and not control['failingCases']
    assert all(not row['passed'] and row['behaviorallyRejected'] and row['failingCases'] for row in mutants)
smoke_path = coordinator / 'broker-smoke/attempt-02/summary.json'
smoke = read(smoke_path)
assert smoke['status'] == 'passed' and smoke['smokeOnly']
assert all(row['exitCode'] == 0 and row['hostCloseObserved'] for row in smoke['results'])
for actor in actors['actors']:
    assert actor['model'] == 'gpt-6-luna' and actor['reasoning'] == 'max'
    prompt = coordinator / actor['prompt']
    assert digest(prompt) == actor['promptSha256']
    assert digest(checked(actor['cli'])) == actor['cliSha256']
    project = (repo / actor['project']).resolve()
    assert project.is_relative_to(coordinator / 'actors')
    actual = {p.relative_to(project).as_posix(): digest(p) for p in project.rglob('*') if p.is_file()}
    expected = {row['path']: row['sha256'] for row in actor['seedProjectInventory']}
    assert actual == expected, actor['name']
    assert not (repo / actor['trace']).exists(), 'Participant already launched'
inputs = actors['inputs']
for key in ('taskDraft', 'flowPrimer', 'acceptedFlowReport', 'acceptedFSharpCopyReport', 'trialHost', 'flowCli'):
    assert digest(checked(inputs[key + 'Path'])) == inputs[key + 'Sha256'], key
for row in inputs['conventionalRuntimePins']:
    assert digest(checked(inputs['conventionalRuntimeCopiedPath'] + '/' + row['path'])) == row['sha256']
record = {
    'schemaVersion': 1, 'status': 'frozen; dispatch allowed',
    'frozenUtc': datetime.now(timezone.utc).isoformat(),
    'actorsBeforeFreezeSha256': digest(actors_path),
    'calibrationSummarySha256': digest(calibration_path),
    'inputHashManifestSha256': digest(base / 'oracle/input-hashes.json'),
    'oraclePinsChecked': len(pins), 'calibrationCasesPerArm': 6, 'mutantsRejectedPerArm': 4,
    'smokeSummarySha256': digest(smoke_path),
    'scope': 'One fresh pair, synthetic I/O; no causal performance or comparative reliability claim.',
    'actorInputs': actors['actors'],
}
(coordinator / 'freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
actors.update(status='frozen; dispatch allowed', frozen=True, dispatchAllowed=True)
actors_path.write_text(json.dumps(actors, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k != 'actorInputs'}))

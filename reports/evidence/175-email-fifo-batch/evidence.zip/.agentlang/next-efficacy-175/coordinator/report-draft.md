# 175 — FIFO delivery and partial progress

Status: inputs frozen; two fresh participants running. No participant outcome
is claimed yet. This file is a report draft, not a completed study.

## Question

Can an external coding agent discover an existing typed vocabulary and use it
to implement a correct multi-step operation while preserving prior behavior?
The concrete task is FIFO email delivery over synthetic provider outcomes,
retaining successful progress and stopping at the first failure.

## Method

One fresh pair uses GPT-6 Luna/max and separate isolated project copies.
Participants receive the same public behavior contract and broker-only tooling.
They receive no helper names or hidden acceptance cases. Runs are concurrent;
their elapsed times are observations under shared load, not a causal latency
comparison. This pair cannot establish comparative reliability or token savings.
The broker interfaces also differ: the language exposes definition-level
introspection, while the F# broker exposes file read/search/edit operations.
Report discovery behavior in that context; do not attribute an interface or
response-truncation limitation to F#'s type system or runtime.

The language arm must publish qualified library functions and their dependency
closure. The F# arm adds self-tests and passes its conventional validation gate.
Those different publication requirements are disclosed and scored separately.
All provider outcomes are synthetic; there is no external email delivery.
The broker workflow is not an operating-system security sandbox.

## Frozen evidence

`freeze.json` verifies 392 oracle source pins, actor source inventories, prompt
hashes, pinned runtime hashes, accepted seed reports and broker smoke results.
`dispatch.json` records the fresh pair and concurrent dispatch. The retained
Flow seed was rehydrated through the normal protocol: authored bodies, tests and
examples match the original seed, while IDs, revisions and history were reset.
That lineage difference must remain in the published report.

Six independent cases cover FIFO success, first failure, partial success then
failure, exhausted outcomes, exhausted queue and empty input. Each checks the
result count, failure detail, email ordering and unrelated Store fields.
Correct controls pass in both arms. Four executing mutants per arm fail:
dropping the failed item, continuing after failure, rolling back the successful
prefix, and reversing sent order.

The Flow input assertion combines equality of the retained input with observing
the expected delivered count. Count has a separate check; failure of the
composite alone does not prove input mutation. Label-normalized control result
views preserve original terminal outputs, hashes and identical request code.

## Remaining acceptance

- Observe participant broker closure before scoring candidate state.
- Run the frozen behavioral scorer against each candidate.
- Verify inherited assertions and allowed edit scope.
- Check language library qualification and transitive dependency closure.
- Review whether production code calls the existing single-delivery operation.
- Report validation failures, discovery interactions and tool limitations.
- Preserve raw attempts and terminal evidence, then update durable reports
  before committing or pushing the milestone.

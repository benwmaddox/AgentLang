"""Prepare one isolated actor per arm; never dispatch a participant."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
FLOW_SEED = REPO / ".agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/flow/project"
FLOW_REPORT_PATH = REPO / ".agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/seed-report.json"
FSHARP_SEED = REPO / ".agentlang/next-efficacy-175/seed-preparation/fsharp/project"
FSHARP_COPY_REPORT_PATH = REPO / ".agentlang/next-efficacy-175/seed-preparation/fsharp-source-copy-verification.json"
FLOW_CLI = REPO / ".agentlang/next-efficacy-173/pinned-runtime/pr171/AgentLang.Cli.dll"
CONVENTIONAL_RUNTIME_SOURCE = REPO / ".agentlang/next-efficacy-173-coordinator/runtime/conventional"
HOST_SCRIPT = REPO / "scripts/Start-SubagentTrialHostV2.ps1"
TASK_DRAFT_PATH = HERE / "task-draft.md"
FLOW_PRIMER_PATH = REPO / ".agentlang/preview-retention-171/primer.md"

EXPECTED_FLOW_CLI_SHA256 = "27fd71d7d7c78a02903c56e82824cd1732d60dd9c883a6ce1eb9b9b41af0ec42"
EXPECTED_FSHARP_FILES = {
    "README.md",
    "business/AgentLang.Business.fsproj",
    "business/Business.fs",
    "tests/AgentLang.Business.Tests.fsproj",
    "tests/Program.fs",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inventory(root: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"Symlinks are not allowed in actor input trees: {path}")
        if path.is_file():
            rows.append(
                {
                    "path": path.relative_to(root).as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    return rows


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def ps_quote(value: Path | str) -> str:
    return str(value).replace("'", "''")


def assert_equal_inventory(actual: list[dict[str, object]], expected: list[dict[str, object]], label: str) -> None:
    expected_by_path = {str(row["path"]): row for row in expected}
    actual_by_path = {str(row["path"]): row for row in actual}
    missing = sorted(set(expected_by_path) - set(actual_by_path))
    added = sorted(set(actual_by_path) - set(expected_by_path))
    changed = sorted(
        path
        for path in set(expected_by_path) & set(actual_by_path)
        if expected_by_path[path] != actual_by_path[path]
    )
    if missing or added or changed or len(actual) != len(actual_by_path) or len(expected) != len(expected_by_path):
        raise RuntimeError(f"{label} inventory differs: missing={missing}, added={added}, changed={changed}")


def same_inventory(actual: list[dict[str, object]], expected: list[dict[str, object]]) -> bool:
    return len(actual) == len(expected) and {
        str(row["path"]): row for row in actual
    } == {
        str(row["path"]): row for row in expected
    }


def absolute(value: Path | str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else REPO / path


def render_launch(actor: dict[str, object]) -> str:
    temp = ps_quote(absolute(str(actor["temp"])))
    host = ps_quote(HOST_SCRIPT)
    cli = ps_quote(absolute(str(actor["cli"])))
    project = ps_quote(absolute(str(actor["project"])))
    trace = ps_quote(absolute(str(actor["trace"])))
    allowed = ",".join(str(value) for value in actor["allowedOperations"])
    command = (
        f"$env:TEMP = '{temp}'\n"
        "$env:TMP = $env:TEMP\n"
        "$env:DOTNET_CLI_HOME = $env:TEMP\n"
        f"& '{host}' -CliDll '{cli}' -ProjectPath '{project}' -TracePath '{trace}' "
        f"-AllowedOperations @('{allowed}') -Profile '{actor['profile']}' "
    )
    if actor["arm"] == "fsharp":
        command += "-AdditionalCliArguments @('--validation-project','tests/AgentLang.Business.Tests.fsproj') "
    command += "-ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100"
    return command


def render_common_prompt(public_task: str) -> str:
    return (
        "You are a fresh external experimental coding agent. The human explicitly authorizes edits only to your supplied isolated project and local test execution through its broker. "
        "Read this prompt, then launch the specified broker once. Use only that broker for project discovery, edits, and tests. "
        "Do not access the main repository, other trials, hidden oracles, reports, or snapshots. Do not use web tools, spawn/list/read/contact other agents, or run other shell commands. "
        "If non-broker tool use occurs, disclose it. Use at most 100 exchanges and a 120000 ms broker request timeout. "
        "If a request is still running, poll the same live handle; never restart a confirmed-live broker for silence or uncertainty. "
        "Finish with {\"op\":\"host.close\"} and observe the terminal status.\n\n"
        f"{public_task}\n\n"
    )


def main() -> None:
    owned_directories = [HERE / "actors", HERE / "broker-runtime", HERE / "broker-smoke", HERE / "temp"]
    owned_files = [HERE / "actors.json", HERE / "prompt-flow.md", HERE / "prompt-fsharp.md", HERE / "prep-evidence.json"]
    existing = [str(path) for path in [*owned_directories, *owned_files] if path.exists()]
    if existing:
        raise RuntimeError(f"Preparation outputs already exist; preserving them and refusing to reset: {existing}")

    for path in [FLOW_SEED, FLOW_REPORT_PATH, FSHARP_SEED, FSHARP_COPY_REPORT_PATH, FLOW_CLI,
                 CONVENTIONAL_RUNTIME_SOURCE, HOST_SCRIPT, TASK_DRAFT_PATH, FLOW_PRIMER_PATH]:
        if not path.exists():
            raise FileNotFoundError(path)

    flow_report = json.loads(FLOW_REPORT_PATH.read_text(encoding="utf-8-sig"))
    if flow_report.get("status") != "completed" or flow_report.get("counts") != {
        "words": 62,
        "types": 37,
        "tests": 191,
        "examples": 44,
        "libraryWords": 59,
        "projectWords": 3,
    }:
        raise RuntimeError("Accepted Flow seed report is not the completed 62-word, 59/3 seed.")
    flow_expected = flow_report.get("flowProjectInventory")
    if not isinstance(flow_expected, list):
        raise RuntimeError("Accepted Flow seed report has no source inventory.")
    flow_source_inventory = inventory(FLOW_SEED)
    assert_equal_inventory(flow_source_inventory, flow_expected, "Accepted Flow seed")
    if sha256(FLOW_CLI) != EXPECTED_FLOW_CLI_SHA256:
        raise RuntimeError("Pinned Flow CLI hash differs from the accepted runtime pin.")

    fsharp_copy_report = json.loads(FSHARP_COPY_REPORT_PATH.read_text(encoding="utf-8-sig"))
    fsharp_expected_rows = fsharp_copy_report.get("files")
    if fsharp_copy_report.get("exactCopy") is not True or not isinstance(fsharp_expected_rows, list):
        raise RuntimeError("Accepted F# source-copy verification is not an exact copied seed.")
    fsharp_expected = sorted(
        ({"path": row["path"], "bytes": int(row["bytes"]), "sha256": row["sha256"]} for row in fsharp_expected_rows),
        key=lambda row: str(row["path"]),
    )
    if {str(row["path"]) for row in fsharp_expected} != EXPECTED_FSHARP_FILES:
        raise RuntimeError("Accepted F# source inventory is not the expected five source/project files.")
    fsharp_source_inventory = inventory(FSHARP_SEED)
    generated_parts = {"bin", "obj", "artifacts"}
    fsharp_source_without_generated = [
        row for row in fsharp_source_inventory
        if not (set(Path(str(row["path"])).parts) & generated_parts)
    ]
    assert_equal_inventory(fsharp_source_without_generated, fsharp_expected, "Accepted F# source seed")

    runtime_source_inventory = inventory(CONVENTIONAL_RUNTIME_SOURCE)
    runtime_required = {
        "AgentLang.Conventional.Cli.dll",
        "AgentLang.Conventional.Cli.deps.json",
        "AgentLang.Conventional.Cli.runtimeconfig.json",
    }
    if not runtime_required.issubset({str(row["path"]) for row in runtime_source_inventory}):
        raise RuntimeError("Conventional broker runtime is missing a CLI DLL companion file.")

    task_raw = TASK_DRAFT_PATH.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
    if "\n\n" not in task_raw:
        raise RuntimeError("Task draft does not separate its title from the public task body.")
    public_task = task_raw.split("\n\n", 1)[1].rstrip()
    primer = FLOW_PRIMER_PATH.read_text(encoding="utf-8-sig").replace("\r\n", "\n").rstrip()
    invalid_help_request = '{"op":"help","frontend":"flow","syntaxVersion":2,"topic":"define"}'
    valid_help_request = '{"op":"help","syntaxVersion":2,"topic":"define"}'
    if primer.count(invalid_help_request) != 1:
        raise RuntimeError("Current Flow primer does not contain the expected pinned-runtime help example.")
    primer = primer.replace(invalid_help_request, valid_help_request)

    flow_root = HERE / "actors/flow"
    fsharp_root = HERE / "actors/fsharp"
    runtime_root = HERE / "broker-runtime/conventional"
    smoke_root = HERE / "broker-smoke"
    temp_root = HERE / "temp"
    flow_root.parent.mkdir(parents=True)
    shutil.copytree(FLOW_SEED, flow_root)
    fsharp_root.mkdir(parents=True)
    for row in fsharp_expected:
        relative = Path(str(row["path"]))
        source = FSHARP_SEED / relative
        target = fsharp_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    runtime_root.parent.mkdir(parents=True)
    shutil.copytree(CONVENTIONAL_RUNTIME_SOURCE, runtime_root)
    smoke_root.mkdir(parents=True)
    (temp_root / "flow").mkdir(parents=True)
    (temp_root / "fsharp").mkdir(parents=True)

    flow_actor: dict[str, object] = {
        "name": "flow",
        "arm": "flow",
        "order": 1,
        "model": "gpt-6-luna",
        "reasoning": "max",
        "project": flow_root,
        "trace": HERE / "actors/flow-trace.jsonl",
        "temp": temp_root / "flow",
        "cli": FLOW_CLI,
        "cliSha256": sha256(FLOW_CLI),
        "profile": "agentlang",
        "allowedOperations": [
            "help", "words", "source", "tests", "define", "test", "test-all", "commit",
            "replace-word", "storage.status", "task.begin", "task.status", "task.commit",
            "describe", "search", "eval", "context", "dependencies", "callers", "failed-tests",
            "examples", "effects", "type-of", "history", "task.abort",
        ],
        "edits": "isolated AgentLang project through the supplied broker only",
        "seedCounts": flow_report["counts"],
        "seedManifest": flow_report["manifest"],
        "seedProjectInventory": flow_source_inventory,
    }
    fsharp_actor: dict[str, object] = {
        "name": "fsharp",
        "arm": "fsharp",
        "order": 2,
        "model": "gpt-6-luna",
        "reasoning": "max",
        "project": fsharp_root,
        "trace": HERE / "actors/fsharp-trace.jsonl",
        "temp": temp_root / "fsharp",
        "cli": runtime_root / "AgentLang.Conventional.Cli.dll",
        "cliSha256": sha256(runtime_root / "AgentLang.Conventional.Cli.dll"),
        "profile": "conventional",
        "allowedOperations": ["inspect", "read", "search", "patch", "replace", "validate"],
        "validationProject": "tests/AgentLang.Business.Tests.fsproj",
        "additionalCliArguments": ["--validation-project", "tests/AgentLang.Business.Tests.fsproj"],
        "edits": ["business/Business.fs", "tests/Program.fs"],
        "seedProjectInventory": inventory(fsharp_root),
    }
    for actor in (flow_actor, fsharp_actor):
        actor["project"] = Path(actor["project"]).relative_to(REPO).as_posix()
        actor["trace"] = Path(actor["trace"]).relative_to(REPO).as_posix()
        actor["temp"] = Path(actor["temp"]).relative_to(REPO).as_posix()
        actor["cli"] = Path(actor["cli"]).relative_to(REPO).as_posix()
        actor["launch"] = render_launch(actor)

    flow_prompt = render_common_prompt(public_task)
    flow_prompt += (
        "Flow arm instructions:\n"
        "- The accepted seed has 62 authored words, 37 types, 191 inherited tests, 44 examples, and 59 library / 3 project words. Preserve every inherited assertion and existing behavior.\n"
        "- Qualify only task-relevant project functions needed by the library closure, preserving behavior, tests, and examples; leave unrelated project functions unchanged.\n"
        "- Keep the batch and its task-relevant dependencies as qualified library functions. Add useful new tests as the public task requests. Do not weaken coverage or remove inherited tests.\n"
        "- Use Flow/2 for all new definitions, with exact frontend and syntax metadata. Query versioned help and source/tests through the broker; do not use filesystem access or a direct CLI.\n\n"
        "Flow/2 primer (with the pinned runtime's accepted help request fields):\n\n"
        f"{primer}\n\n"
        "Launch once with exec_command, tty:true, yield_time_ms:10000. If it reports a live session, poll that same session ID.\n\n"
        "```powershell\n"
        f"{flow_actor['launch']}\n"
        "```\n"
    )
    fsharp_prompt = render_common_prompt(public_task)
    fsharp_prompt += (
        "F# arm instructions:\n"
        "- Work only in your supplied isolated project. You are authorized to edit `business/Business.fs` and `tests/Program.fs`; all other files are frozen.\n"
        "- Preserve the existing behavior and inherited assertions. Add relevant self-tests for the batch semantics, including success, FIFO prefix, first failure, ignored later outcomes, empty input/queue, and preservation of unrelated Store fields.\n"
        "- Use the broker `inspect`, `read`, and `search` operations to understand the project; use `patch` or `replace` with the broker-provided expected hash. Run `validate` after your changes. It targets `tests/AgentLang.Business.Tests.fsproj`; do not run `dotnet` or other shell commands directly.\n"
        "- The conventional broker receives `--validation-project tests/AgentLang.Business.Tests.fsproj`.\n\n"
        "Launch once with exec_command, tty:true, yield_time_ms:10000. If it reports a live session, poll that same session ID.\n\n"
        "```powershell\n"
        f"{fsharp_actor['launch']}\n"
        "```\n"
    )
    (HERE / "prompt-flow.md").write_text(flow_prompt, encoding="utf-8", newline="\n")
    (HERE / "prompt-fsharp.md").write_text(fsharp_prompt, encoding="utf-8", newline="\n")

    flow_prompt_hash = sha256(HERE / "prompt-flow.md")
    fsharp_prompt_hash = sha256(HERE / "prompt-fsharp.md")
    flow_actor["prompt"] = "prompt-flow.md"
    flow_actor["promptSha256"] = flow_prompt_hash
    fsharp_actor["prompt"] = "prompt-fsharp.md"
    fsharp_actor["promptSha256"] = fsharp_prompt_hash
    actors_manifest = {
        "schemaVersion": 1,
        "status": "prepared; awaiting root control pass and input freeze",
        "frozen": False,
        "dispatched": False,
        "dispatchAllowed": False,
        "actorCount": 2,
        "actors": [flow_actor, fsharp_actor],
        "inputs": {
            "taskDraftPath": TASK_DRAFT_PATH.relative_to(REPO).as_posix(),
            "taskDraftSha256": sha256(TASK_DRAFT_PATH),
            "publicTaskBodySha256": hashlib.sha256(public_task.encode("utf-8")).hexdigest(),
            "flowPrimerPath": FLOW_PRIMER_PATH.relative_to(REPO).as_posix(),
            "flowPrimerSha256": sha256(FLOW_PRIMER_PATH),
            "acceptedFlowSeedPath": FLOW_SEED.relative_to(REPO).as_posix(),
            "acceptedFlowReportPath": FLOW_REPORT_PATH.relative_to(REPO).as_posix(),
            "acceptedFlowReportSha256": sha256(FLOW_REPORT_PATH),
            "acceptedFSharpSeedPath": FSHARP_SEED.relative_to(REPO).as_posix(),
            "acceptedFSharpCopyReportPath": FSHARP_COPY_REPORT_PATH.relative_to(REPO).as_posix(),
            "acceptedFSharpCopyReportSha256": sha256(FSHARP_COPY_REPORT_PATH),
            "trialHostPath": HOST_SCRIPT.relative_to(REPO).as_posix(),
            "trialHostSha256": sha256(HOST_SCRIPT),
            "flowCliPath": FLOW_CLI.relative_to(REPO).as_posix(),
            "flowCliSha256": sha256(FLOW_CLI),
            "conventionalRuntimeSourcePath": CONVENTIONAL_RUNTIME_SOURCE.relative_to(REPO).as_posix(),
            "conventionalRuntimeCopiedPath": runtime_root.relative_to(REPO).as_posix(),
            "conventionalRuntimePins": inventory(runtime_root),
            "conventionalRuntimeSourcePins": runtime_source_inventory,
        },
    }
    write_json(HERE / "actors.json", actors_manifest)
    write_json(
        HERE / "prep-evidence.json",
        {
            "status": "prepared; actors not launched",
            "controlsPassed": False,
            "inputsFrozen": False,
            "participantsDispatched": False,
            "flowSourceFileCount": len(flow_source_inventory),
            "flowActorFileCount": len(inventory(flow_root)),
            "flowInventoryExact": inventory(flow_root) == flow_source_inventory,
            "fsharpAcceptedSourceFileCount": len(fsharp_expected),
            "fsharpActorSourceFileCount": len(inventory(fsharp_root)),
            "fsharpInventoryExact": same_inventory(inventory(fsharp_root), fsharp_expected),
            "fsharpGeneratedFilesCopied": [],
            "conventionalRuntimeFileCount": len(inventory(runtime_root)),
            "flowPromptSha256": flow_prompt_hash,
            "fsharpPromptSha256": fsharp_prompt_hash,
            "publicTaskBodySha256": hashlib.sha256(public_task.encode("utf-8")).hexdigest(),
        },
    )
    print(json.dumps({"prepared": ["flow", "fsharp"], "dispatched": False, "flowFiles": len(flow_source_inventory), "fsharpFiles": len(fsharp_expected)}))


if __name__ == "__main__":
    main()

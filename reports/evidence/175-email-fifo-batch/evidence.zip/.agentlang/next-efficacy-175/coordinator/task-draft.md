# Draft public task: typed FIFO email delivery batch

Add a reusable email-delivery batch operation over the existing Store. It takes
an ordered finite list of synthetic provider outcomes, each success Unit or
failure String. Process queued messages in FIFO order using the existing
single-message delivery logic. Keep its behavior and inherited test assertions.

Each success moves only the queue head to the end of the sent list and increments
the delivered count. On the first provider failure, stop attempting deliveries:
return the state after the successful prefix, retain the failed message and all
later messages in order, and report EMAIL_PROVIDER_FAILURE with that provider's
original detail. Ignore later outcomes. Stop without a failure when the queue or
outcome list ends; do not fabricate NO_PENDING_EMAIL for batch exhaustion.
Preserve the caller's input and every non-email Store field.

Public language interface: email.deliver-batch(Store,
List<Result<Unit,String>>) -> EmailBatchResult, with fields store: Store,
delivered: Int and failure: Option<BusinessError>. The conventional interface
is EmailOutbox.deliverBatch taking Store and Result<unit,string> list and returning
an analogous EmailBatchResult record with Store, Delivered and Failure fields.
Use each environment's existing provider-error representation/message convention.
Names of internal helper functions are your choice.

For the language, publish the batch and its dependencies as qualified library
functions. You may qualify existing project functions and add relevant tests
while retaining their behavior and inherited assertions. Do not weaken a gate or
replace existing assertions with easier expectations. For conventional F#, add
relevant self-tests and run the supplied validation operation. All provider
outcomes are synthetic; no real email sending is part of this task.

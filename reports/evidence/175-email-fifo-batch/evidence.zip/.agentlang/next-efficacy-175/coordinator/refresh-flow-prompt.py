"""Refresh the Flow prompt digest after the coordinator-approved wording change."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROMPT = HERE / "prompt-flow.md"
ACTORS = HERE / "actors.json"
EVIDENCE = HERE / "prep-evidence.json"
OLD_HELPER_NAMES = (
    "email.apply-delivery-result",
    "email.delivery-fold-step",
    "maintenance141.fixture-import-payment",
)
INVALID_HELP_REQUEST = '{"op":"help","frontend":"flow","syntaxVersion":2,"topic":"define"}'


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"Expected a JSON object in {path.name}.")
    return value


def write_json(path: Path, value: dict[str, object]) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


prompt_bytes = PROMPT.read_bytes()
prompt_text = prompt_bytes.decode("utf-8")
if any(name in prompt_text for name in OLD_HELPER_NAMES):
    raise SystemExit("Flow prompt still pre-names a project helper.")
if INVALID_HELP_REQUEST in prompt_text:
    raise SystemExit("Flow prompt still contains the pinned runtime's invalid help request field.")
generic_guidance = "Qualify only task-relevant project functions needed by the library closure, preserving behavior, tests, and examples; leave unrelated project functions unchanged."
if prompt_text.count(generic_guidance) != 1:
    raise SystemExit("Expected the coordinator-approved generic qualification guidance exactly once.")

digest = hashlib.sha256(prompt_bytes).hexdigest()
actors = read_json(ACTORS)
actor_rows = actors.get("actors")
if not isinstance(actor_rows, list):
    raise TypeError("Actor manifest does not contain an actors list.")
flow_rows = [row for row in actor_rows if isinstance(row, dict) and row.get("arm") == "flow"]
if len(flow_rows) != 1:
    raise SystemExit("Expected exactly one Flow actor.")
flow_rows[0]["promptSha256"] = digest
write_json(ACTORS, actors)

evidence = read_json(EVIDENCE)
evidence["flowPromptSha256"] = digest
evidence["flowPromptGuidance"] = generic_guidance
evidence["preNamedProjectHelperNames"] = False
write_json(EVIDENCE, evidence)

print(json.dumps({"flowPromptSha256": digest, "actorManifestUpdated": True, "prepEvidenceUpdated": True}, separators=(",", ":")))

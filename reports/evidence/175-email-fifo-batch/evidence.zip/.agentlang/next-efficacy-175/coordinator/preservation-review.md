# Preservation review: email batch candidates

This is a source-only review of the differences recorded in
`candidate-audit-002.json` and the final candidate sources compared with their
accepted seeds. It does not change or override that audit: `auditPassed` and
Flow `preservationPassed` remain `false`, and the audit's F# original-binding
flag remains `false`. The review separates behavioral equivalence from
byte-identical preservation. No build or runtime was run.

## Flow helper, inherited tests, and example

The accepted Flow seed manifest is
`189e34ac39234465b4a1784c09d38f2b106a790aa806635162df03693b5ac3be`; the
candidate manifest is
`50980053b0beb77cf870b916ece66e268a3d2d206504a5164a03dff373ca804a`. Both
manifest files hash to their names/current pointers. The source dictionary
hashes are:

| Source | SHA-256 |
| --- | --- |
| Seed `dictionary.agent` | `bad5086e27fe05ad7d72c87b528db7379dea28a814ec2418fbdcb80b7f5c1044` |
| Candidate `dictionary.agent` | `b2512f1e1c0862f4e9e5814b3ffcdf9e63752b74a822d846cc7970295cd4c920` |

`email.apply-delivery-result` keeps its stable ID, signature, effect
declaration, documentation, error codes, and user-visible error messages, but
revision 2 converts the definition from Flow/1 `word` syntax to a Flow/2 `fn`.
The seed folds the outbox into `EmailDeliveryPlan` using
`email.delivery-fold-step`, then reads `plan.first()` and `plan.remaining()`.
The candidate uses `list.get(queued, 0)` and `list.tail(queued)`. For a proper
list, those select the same head and suffix. Both versions check the head
before the outcome, return `NO_PENDING_EMAIL` and
`There is no queued email to deliver.` for an empty queue, return
`EMAIL_PROVIDER_FAILURE` with the original provider message on failure, and on
success append only the head to sent mail and update email state through
`store.with-email-state`. I found no production behavior difference for the
valid `Store` and `List` contract. This is a semantic source review; the
helper revision and its bindings/attachments are not structurally identical.

All three inherited helper tests retain their assertions and literals through
the Flow/2 rewrite:

| Test | Preserved assertions |
| --- | --- |
| `empty-outbox-precedes-provider-error` | `DECLINED` / `mail rejected` input; empty queue wins and reports `NO_PENDING_EMAIL`; success is rejected. |
| `provider-failure-retains-fifo-state` | `TEMPORARY` / `mail gateway unavailable`; exact `EMAIL_PROVIDER_FAILURE` code and message; both queued messages and zero sent count remain; success is rejected. |
| `success-moves-only-first-message` | Later outbox message remains; sent list is prior message followed by first; customers, products, subscriptions, invoices, and payments are unchanged; error is rejected. |

The stored object hashes differ because the tests were translated from
Flow/1 syntax to Flow/2 syntax; both seed and candidate object files were
verified against the content hashes in the audit.

The inherited example has a material output difference. The seed returns the
String `NO_PENDING_EMAIL` and expects that String. The candidate compares the
error code with the same literal, returns Bool `true` for a match, and expects
Bool `true`. Its predicate still checks the intended empty-queue behavior, but
the example's observable result changed from String to Bool. Strict example
output preservation is therefore **false**.

The batch implementation reaches the existing helper transitively through
`email.deliver-batch-step`; it does not bypass the single-message transition.
The step checks for a queued head before calling the helper, so queue
exhaustion returns the accumulated batch result rather than synthesizing
`NO_PENDING_EMAIL`.

## F# test assertions and production reuse

The F# seed and candidate each contain five source files with the same relative
paths. Only `business/Business.fs` and `tests/Program.fs` differ. Their hashes
are recorded in `preservation-review.json`.

The candidate inserts batch setup and assertions at the start of the existing
`testEmailOutboxAndProviderIsolation` function. From the original
`let store = baseStore ()` line through the next top-level test function, the
candidate suffix is byte-identical to the seed after normalizing CRLF/LF line
endings: both hash to
`f8876ea46e34233db0616b6e856523d616ab1d2137d298fb8bb1e816dacdd6c0` at 2,288
UTF-8 bytes. That preserved suffix contains all 10 original `equal` calls and
all 6 original `errorCode` calls with their original strings and literals.
The inserted batch block adds 25 `equal` assertions and no new top-level test
group call. Thus the audit's changed-binding result reflects extension of the
function block, not loss or alteration of its original assertions.

The new `EmailOutbox.deliverBatch` builds a temporary provider whose `Send`
returns the next scripted result, then calls the unchanged
`EmailOutbox.deliverNext current provider`. The extracted `deliverNext` body is
identical to the seed after line-ending normalization; both hash to
`328bbca09b7d1933c51c80c75e845f1b1356639b38012d4443ddccb7c42bf337` at 553
bytes. On success, the batch recurs with the updated Store and increments the
count. On error, it returns the current Store, prior-success count, and
`Some failure`, retaining the failed head and successful prefix. Matching an
empty queue or exhausted outcomes returns without a synthetic failure. This
directly reuses the existing single-step production transition.

## Review conclusion

The Flow single-message transition and its three test predicates are
behaviorally preserved by source review; the inherited example still checks
the same error code but changes its observable output type/value. F# retains
every original assertion in the edited email test and directly reuses the
byte-identical `deliverNext` body. These findings do not turn the raw audit
into a pass, and passing runtime totals are not used as preservation proof.

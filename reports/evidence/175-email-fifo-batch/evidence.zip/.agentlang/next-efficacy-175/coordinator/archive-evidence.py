import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd().resolve()
root = repo / '.agentlang/next-efficacy-175'
out = repo / 'reports/evidence/175-email-fifo-batch'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
coord = root / 'coordinator'
flow = load(coord / 'result-flow-001.json')
fsharp = load(root / 'oracle/runs/fsharp-participant-001/result.json')
audit = load(coord / 'candidate-audit-002.json')
review = load(coord / 'preservation-review.json')
assert flow['passed'] and flow['caseCount'] == 6 and flow['checkCount'] == 60
assert all(c['passed'] and all(t['passed'] and t['error'] is None for t in c['checks']) for c in flow['cases'])
assert fsharp['passed'] and len(fsharp['cases']) == 6
assert all(c['passed'] and all(c['checks'].values()) for c in fsharp['cases'])
assert sum(len(c['checks']) for c in fsharp['cases']) == 78
assert not audit['auditPassed'] and not audit['acceptanceChecks']['flowPreservation']
assert audit['acceptanceChecks']['flowLibraryClosure'] and audit['acceptanceChecks']['fsharpScope']
assert review['candidateAudit']['reviewDoesNotOverrideAudit']
assert review['candidateAudit']['sha256'] == sha((coord / 'candidate-audit-002.json').read_bytes())
for name in ('flow', 'fsharp'):
    metric = load(coord / f'metrics-{name}.json')
    assert metric['hostExitCode'] == metric['runtimeExitCode'] == 0
    assert metric['traceSha256'] == sha((repo / metric['trace']).read_bytes())
    assert load(coord / f'score-{name}-001-exit.json')['exitCode'] == 0

pins = load(root / 'oracle/input-hashes.json')['inputs']
assert len(pins) == 392
files = set()
omitted_pins = []
for row in pins:
    p = (repo / row['path']).resolve()
    assert p.is_relative_to(repo) and sha(p.read_bytes()) == row['sha256'], p
    if p.suffix.lower() in ('.dll', '.exe', '.pdb'):
        omitted_pins.append(row)
    else:
        files.add(p)

# Keep logs, failed attempts, source and final project state. Intermediate
# generated manifest snapshots and duplicate load-check project bodies are
# omitted unless explicitly frozen by a hash pin; CURRENT manifests are kept.
allowed = {'.agent', '.flow', '.json', '.jsonl', '.md', '.txt', '.log', '.fs',
           '.fsx', '.fsproj', '.props', '.py', '.ps1'}
excluded_parts = {'bin', 'obj', 'temp', '__pycache__', 'broker-runtime'}
for p in root.rglob('*'):
    if not p.is_file():
        continue
    rel = p.relative_to(root)
    if any(part in excluded_parts for part in rel.parts):
        continue
    if rel.parts[:2] == ('load-check', 'project'):
        continue
    if p.suffix not in allowed and p.name != 'CURRENT':
        continue
    if p.parent.name == 'manifests':
        current = p.parent.parent / 'CURRENT'
        if current.exists() and p.stem != current.read_text(encoding='utf-8-sig').strip():
            continue
    files.add(p.resolve())

files.add(repo / 'reports/175-email-fifo-batch.md')
files.add(repo / 'docs/ROADMAP.md')
assert not out.exists(), 'Refuse overwrite'
out.mkdir(parents=True)
rows = []
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(files):
        assert p.is_file() and p.is_relative_to(repo)
        data = p.read_bytes()
        name = p.relative_to(repo).as_posix()
        archive.writestr(name, data)
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(rows)
    for row in rows:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']

index = {
    'schemaVersion': 1,
    'status': 'verified',
    'study': '175-email-fifo-batch',
    'behavior': {'flowCasesPassed': 6, 'flowChecksPassed': 60, 'fsharpCasesPassed': 6, 'fsharpChecksPassed': 78},
    'strictStructuralAuditPassed': False,
    'interpretation': 'Both behavior contracts pass; Flow example output preservation fails. Source review is separate from the unchanged raw structural audit.',
    'frozenInputPinsVerified': len(pins),
    'excluded': 'Build trees, binaries, temporary environments, lock files, duplicate load-check project bodies and unpinned intermediate generated manifest snapshots. Runtime binary hashes remain recorded.',
    'omittedBinaryPins': omitted_pins,
    'archive': {'path': 'evidence.zip', 'bytes': (out / 'evidence.zip').stat().st_size, 'sha256': sha((out / 'evidence.zip').read_bytes())},
    'files': rows,
}
(out / 'archive.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in index.items() if key not in ('files', 'omittedBinaryPins')}))

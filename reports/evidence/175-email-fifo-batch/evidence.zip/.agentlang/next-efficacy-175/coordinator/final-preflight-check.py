"""Read-only final checks for prepared, undispatched actor inputs."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
INVALID_HELP = '{"op":"help","frontend":"flow","syntaxVersion":2,"topic":"define"}'
VALID_HELP = '{"op":"help","syntaxVersion":2,"topic":"define"}'
GUIDANCE = "Qualify only task-relevant project functions needed by the library closure, preserving behavior, tests, and examples; leave unrelated project functions unchanged."
HELPER_HINTS = ("email.apply-delivery-result", "email.delivery-fold-step", "maintenance141.fixture-import-payment")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root: Path) -> list[dict[str, object]]:
    return [
        {"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}
        for path in sorted(root.rglob("*")) if path.is_file() and not path.is_symlink()
    ]


def same_inventory(actual: list[dict[str, object]], expected: object) -> bool:
    return isinstance(expected, list) and {row["path"]: row for row in actual} == {row["path"]: row for row in expected}


manifest = json.loads((HERE / "actors.json").read_text(encoding="utf-8"))
evidence = json.loads((HERE / "prep-evidence.json").read_text(encoding="utf-8"))
task = (HERE / "task-draft.md").read_text(encoding="utf-8").replace("\r\n", "\n").split("\n\n", 1)[1].rstrip()
flow_path, fsharp_path = HERE / "prompt-flow.md", HERE / "prompt-fsharp.md"
flow, fsharp = flow_path.read_text(encoding="utf-8"), fsharp_path.read_text(encoding="utf-8")

for relative in ("prepare-actors.py", "refresh-flow-prompt.py", "broker-smoke/smoke-brokers.py", "final-preflight-check.py"):
    ast.parse((HERE / relative).read_text(encoding="utf-8"), filename=relative)
if flow.count(task) != 1 or fsharp.count(task) != 1:
    raise SystemExit("Public task body is not exact and unique in each prompt.")
if any(hint in flow or hint in fsharp for hint in HELPER_HINTS):
    raise SystemExit("An actor prompt pre-names a project helper.")
if flow.count(GUIDANCE) != 1 or INVALID_HELP in flow or INVALID_HELP in fsharp or VALID_HELP not in flow:
    raise SystemExit("Flow qualification guidance/help example is stale or invalid.")

upstream = (REPO / ".agentlang/preview-retention-171/primer.md").read_text(encoding="utf-8-sig").replace("\r\n", "\n").rstrip()
expected_primer = upstream.replace(INVALID_HELP, VALID_HELP)
start = flow.index("Use only the supplied JSONL broker, one request per line through its live session.")
end = flow.index("\n\nLaunch once with exec_command", start)
if flow[start:end].rstrip() != expected_primer:
    raise SystemExit("Flow primer differs beyond the accepted help-field correction.")

actors = manifest.get("actors")
if not isinstance(actors, list) or len(actors) != 2:
    raise SystemExit("Expected two actors.")
by_arm = {row.get("arm"): row for row in actors if isinstance(row, dict)}
if set(by_arm) != {"flow", "fsharp"}:
    raise SystemExit("Expected one Flow and one F# actor.")
if any(manifest.get(key) is not False for key in ("frozen", "dispatched", "dispatchAllowed")):
    raise SystemExit("Actor inputs must remain unfrozen and undispatched.")
for arm, prompt_path in (("flow", flow_path), ("fsharp", fsharp_path)):
    if by_arm[arm].get("promptSha256") != sha256(prompt_path):
        raise SystemExit(f"{arm} actor prompt hash is stale.")
    project = REPO / str(by_arm[arm]["project"])
    if not same_inventory(inventory(project), by_arm[arm].get("seedProjectInventory")):
        raise SystemExit(f"{arm} actor source inventory changed.")
    if sha256(REPO / str(by_arm[arm]["cli"])) != by_arm[arm].get("cliSha256"):
        raise SystemExit(f"{arm} CLI pin hash changed.")
if evidence.get("flowPromptSha256") != sha256(flow_path) or evidence.get("fsharpPromptSha256") != sha256(fsharp_path):
    raise SystemExit("Prompt hashes in prep evidence are stale.")
if evidence.get("publicTaskBodySha256") != hashlib.sha256(task.encode("utf-8")).hexdigest():
    raise SystemExit("Public task body hash changed.")
if len(inventory(HERE / "broker-runtime/conventional")) != evidence.get("conventionalRuntimeFileCount"):
    raise SystemExit("Conventional runtime inventory count changed.")

flow_smoke = HERE / "broker-smoke/attempt-02"
flow_requests = [json.loads(line) for line in (flow_smoke / "flow-requests.jsonl").read_text(encoding="utf-8").splitlines()]
flow_responses = [json.loads(line) for line in (flow_smoke / "flow-stdout.jsonl").read_text(encoding="utf-8").splitlines()]
flow_status = json.loads((flow_smoke / "flow-exit.json").read_text(encoding="utf-8"))
fsharp_status = json.loads((HERE / "broker-smoke/attempt-01/fsharp-exit.json").read_text(encoding="utf-8"))
if flow_requests[0] != json.loads(VALID_HELP) or flow_requests[-1].get("op") != "host.close":
    raise SystemExit("Flow smoke request fields/close are incorrect.")
if flow_status.get("status") != "passed" or flow_status.get("hostCloseObserved") is not True:
    raise SystemExit("Corrected Flow smoke did not pass and close.")
if len(flow_responses) != 2 or any(row.get("ok") is not True for row in flow_responses):
    raise SystemExit("Flow help/words smoke responses failed.")
if fsharp_status.get("status") != "passed" or fsharp_status.get("validationExitCode") != 0 or fsharp_status.get("hostCloseObserved") is not True:
    raise SystemExit("F# accepted smoke evidence is incomplete.")

print(json.dumps({
    "status": "passed", "pythonScriptsParsed": 4,
    "publicTaskExactInBothPrompts": True,
    "upstreamPrimerPreservedExceptHelpFields": True,
    "flowHelpFields": ["op", "syntaxVersion", "topic"],
    "namedProjectHelpersInPrompts": False,
    "flowActorFiles": len(inventory(REPO / str(by_arm["flow"]["project"]))),
    "fsharpActorFiles": len(inventory(REPO / str(by_arm["fsharp"]["project"]))),
    "noDispatchOrFreeze": True,
    "flowSmoke": "passed/host-close", "fsharpSmoke": "passed/host-close/18-groups-157-assertions",
    "flowPromptSha256": sha256(flow_path), "fsharpPromptSha256": sha256(fsharp_path),
}, separators=(",", ":")))

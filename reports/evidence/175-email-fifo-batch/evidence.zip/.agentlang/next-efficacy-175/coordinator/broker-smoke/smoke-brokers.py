"""Smoke both broker profiles on disposable actor copies; never dispatch a task."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
HOST_SCRIPT = REPO / "scripts/Start-SubagentTrialHostV2.ps1"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inventory(root: Path) -> list[dict[str, object]]:
    return [
        {
            "path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        for path in sorted(root.rglob("*"))
        if path.is_file() and not path.is_symlink()
    ]


def same_inventory(actual: list[dict[str, object]], expected: list[dict[str, object]]) -> bool:
    return len(actual) == len(expected) and {
        str(row["path"]): row for row in actual
    } == {
        str(row["path"]): row for row in expected
    }


def write_text(path: Path, value: str) -> None:
    path.write_text(value, encoding="utf-8", newline="\n")


def write_json(path: Path, value: object) -> None:
    write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def parse_trace(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    if len(sys.argv) > 2:
        raise SystemExit("Usage: smoke-brokers.py [attempt-01|attempt-02|...]")
    attempt_name = sys.argv[1] if len(sys.argv) == 2 else "attempt-01"
    if not re.fullmatch(r"attempt-[0-9]{2}", attempt_name):
        raise SystemExit("Attempt name must match attempt-NN.")
    attempt_root = HERE / attempt_name
    if attempt_root.exists():
        raise SystemExit(f"Preserving existing broker smoke attempt: {attempt_root}")

    actor_manifest_path = HERE.parent / "actors.json"
    actor_manifest = json.loads(actor_manifest_path.read_text(encoding="utf-8"))
    if actor_manifest.get("dispatched") is not False or actor_manifest.get("frozen") is not False:
        raise SystemExit("Smoke preparation requires actor inputs to remain unfrozen and undispatched.")
    actor_by_arm = {actor["arm"]: actor for actor in actor_manifest["actors"]}
    if set(actor_by_arm) != {"flow", "fsharp"}:
        raise SystemExit("Expected exactly one prepared Flow actor and one F# actor.")

    attempt_root.mkdir(parents=True)
    results: list[dict[str, object]] = []
    for arm in ("flow", "fsharp"):
        actor = actor_by_arm[arm]
        project = attempt_root / arm
        shutil.copytree(REPO / actor["project"], project)
        copied_inventory = inventory(project)
        if not same_inventory(copied_inventory, actor["seedProjectInventory"]):
            raise RuntimeError(f"Disposable {arm} smoke copy differs from the pinned actor source inventory.")
        temp = attempt_root / "temp" / arm
        temp.mkdir(parents=True)
        trace = attempt_root / f"trace-{arm}.jsonl"
        requests_path = attempt_root / f"{arm}-requests.jsonl"
        stdout_path = attempt_root / f"{arm}-stdout.jsonl"
        stderr_path = attempt_root / f"{arm}-stderr.txt"
        status_path = attempt_root / f"{arm}-exit.json"

        if arm == "flow":
            requests = [
                {"op": "help", "syntaxVersion": 2, "topic": "define"},
                {"op": "words", "compact": True},
            ]
        else:
            requests = [{"op": "inspect"}, {"op": "validate"}]
        requests_with_close = [*requests, {"op": "host.close"}]
        request_text = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in requests_with_close)
        write_text(requests_path, request_text)

        command = [
            "pwsh", "-NoLogo", "-NoProfile", "-File", str(HOST_SCRIPT),
            "-CliDll", str(REPO / actor["cli"]),
            "-ProjectPath", str(project),
            "-TracePath", str(trace),
            "-AllowedOperations", ",".join(actor["allowedOperations"]),
            "-Profile", actor["profile"],
            "-ExchangeTimeoutMilliseconds", "120000",
            "-MaxExchanges", "100",
        ]
        if arm == "fsharp":
            command += [
                "-AdditionalCliArgumentsJson",
                json.dumps(actor["additionalCliArguments"], separators=(",", ":")),
            ]
        env = os.environ.copy()
        env.update(TEMP=str(temp), TMP=str(temp), DOTNET_CLI_HOME=str(temp))
        started_utc = utc_now()
        process_started = False
        return_code: int | None = None
        failure: str | None = None
        try:
            process = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=REPO,
                env=env,
            )
            process_started = True
            stdout_text, stderr_text = process.communicate(input=request_text)
            return_code = process.returncode
        except BaseException as error:
            failure = f"{type(error).__name__}: {error}"
            stdout_text = ""
            stderr_text = failure + "\n"
            if "process" in locals() and process.poll() is None:
                # Do not restart or kill a live host on silence; this code path only records an exception.
                pass
        write_text(stdout_path, stdout_text)
        write_text(stderr_path, stderr_text)

        response_rows = []
        response_parse_error = None
        try:
            response_rows = [json.loads(line) for line in stdout_text.splitlines() if line.strip()]
        except json.JSONDecodeError as error:
            response_parse_error = f"{type(error).__name__}: {error}"
        trace_rows = parse_trace(trace) if trace.exists() else []
        end_event = trace_rows[-1] if trace_rows else None
        request_ok = len(response_rows) == len(requests) and all(row.get("ok") is True for row in response_rows)
        if arm == "flow" and request_ok:
            request_ok = response_rows[0].get("kind") == "help" and response_rows[1].get("kind") == "words"
        if arm == "fsharp" and request_ok:
            validation_data = response_rows[1].get("data", {})
            request_ok = (
                response_rows[0].get("kind") == "inspect"
                and response_rows[1].get("kind") == "validation"
                and validation_data.get("project") == actor["validationProject"]
                and validation_data.get("exitCode") == 0
            )
        trace_ok = bool(
            end_event
            and end_event.get("event") == "session-end"
            and end_event.get("terminationKind") == "host-close"
            and end_event.get("hostExitCode") == 0
            and end_event.get("runtimeExitCode") == 0
        )
        ok = return_code == 0 and request_ok and trace_ok and failure is None
        status = {
            "arm": arm,
            "status": "passed" if ok else "failed",
            "command": command,
            "cliPath": actor["cli"],
            "cliSha256": actor["cliSha256"],
            "projectPath": str(project),
            "tracePath": str(trace),
            "tempPath": str(temp),
            "startedUtc": started_utc,
            "finishedUtc": utc_now(),
            "processStarted": process_started,
            "terminalStatus": "completed" if return_code == 0 else ("not-started" if not process_started else "nonzero-exit"),
            "exitCode": return_code,
            "requestCount": len(requests_with_close),
            "runtimeResponseCount": len(response_rows),
            "hostCloseObserved": bool(end_event and end_event.get("terminationKind") == "host-close"),
            "hostExitCode": end_event.get("hostExitCode") if end_event else None,
            "runtimeExitCode": end_event.get("runtimeExitCode") if end_event else None,
            "requestsAreNonMutating": True,
            "requestOps": [row["op"] for row in requests_with_close],
            "responseKinds": [row.get("kind") for row in response_rows],
            "validationExitCode": response_rows[1].get("data", {}).get("exitCode") if arm == "fsharp" and len(response_rows) > 1 else None,
            "responseParseError": response_parse_error,
            "failure": failure,
            "stdoutPath": stdout_path.name,
            "stderrPath": stderr_path.name,
            "requestsPath": requests_path.name,
            "traceRows": len(trace_rows),
            "traceSha256": sha256(trace) if trace.exists() else None,
        }
        write_json(status_path, status)
        results.append(status)

    all_passed = all(row["status"] == "passed" for row in results)
    summary = {
        "status": "passed" if all_passed else "failed",
        "participantsDispatched": False,
        "actorInputsFrozen": False,
        "smokeOnly": True,
        "requestsAreNonMutating": True,
        "attempt": attempt_name,
        "results": results,
    }
    write_json(attempt_root / "summary.json", summary)
    print(json.dumps({"status": summary["status"], "participantsDispatched": False, "profiles": len(results)}))
    return 0 if all_passed else 1


if __name__ == "__main__":
    raise SystemExit(main())

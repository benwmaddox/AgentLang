# Email batch calibration record

Recorded 2026-10-10. The frozen case input SHA-256 is
`e1ef9ab99e46b099f23b9785bc5eef1b3c483c2db1ecca1bbd4114b3f0d8f072`. The
machine-readable result summary is `calibration-summary.json`; it names every
accepted correct/mutant result path for both language arms and records each
behavioral failure. `input-hashes.json` freezes the case/model/scorer sources,
study plan/task draft, inspected report-141 sources, both accepted seed copies,
the Flow seed report, and the pinned CLI. The summary itself and these notes
are also hashed after they are finalized.

## AgentLang / Flow

The accepted Flow seed is
`.agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/flow/project`.
The seed report records 62 words, 37 types, 191 attached tests, 59 library
words, and 3 project words, with all 191 tests passing on fresh reload. Its
349-file project inventory and the seed report are included in the frozen input
hashes. The pinned CLI is
`.agentlang/next-efficacy-173/pinned-runtime/pr171/AgentLang.Cli.dll`, SHA-256
`27fd71d7d7c78a02903c56e82824cd1732d60dd9c883a6ce1eb9b9b41af0ec42`.

Controls were installed into fresh copies of that project and scored by the
pinned CLI. Each result has six executed cases and 60 structured checks. The
Flow source audit checks all five emitted Flow/2 controls and all 60 generated
single-expression eval snippets; it passed without invoking a CLI or runtime.
Each generated expression binds the input Store, calls the candidate once,
then combines comparison of the retained input with a second complete input
reconstruction and observation of the expected delivered count. A separate
delivered check isolates count mismatches. The composite check alone cannot
show whether an input mismatch or count mismatch caused it to fail.

| Control | Result | Behavioral failures |
| --- | --- | --- |
| `flow-correct-sameinput1-labeled` | Correct control passed all 6 cases and 60 checks, including all six composite checks. | None |
| `flow-drop-failed-sameinput1-labeled` | Mutant executed all 6 cases and 60 checks. | `failure-on-first-retains-head/store.email-outbox`; `partial-progress-stops-at-failure/store.email-outbox` |
| `flow-continue-after-failure-sameinput1-labeled` | Mutant executed all 6 cases and 60 checks. | `failure-on-first-retains-head` and `partial-progress-stops-at-failure`: composite input/count check, outbox, sent list, and delivered count |
| `flow-rollback-prefix-sameinput1-labeled` | Mutant executed all 6 cases and 60 checks. | `partial-progress-stops-at-failure`: composite input/count check, outbox, sent list, and delivered count |
| `flow-reverse-sent-sameinput1-labeled` | Mutant executed all 6 cases and 60 checks. | `three-successes-fifo`, `partial-progress-stops-at-failure`, `outcomes-end-before-queue`, and `queue-ends-before-outcomes`: sent-list order |

The control code calls the seed's existing `email.apply-delivery-result` for
each selected outcome. Provider errors use `EMAIL_PROVIDER_FAILURE` and retain
the provider detail. The controls were installed as project candidates;
library qualification and inherited-test preservation remain separate checks.
Flow eval accepts one expression, so each scorer assertion uses a scoped
single-expression block to bind the fixture input and provider outcomes,
invoke `email.deliver-batch` once, and assert a result field. The
`input-unchanged-and-delivered` check is explicitly composite: it compares the
retained binding with a reconstructed full input Store and observes the
expected count to keep the candidate result observable. A separate `delivered`
check localizes count errors. Composite failures for the continuation and
rollback mutants do not establish input mutation; their separate output and
count checks show the behavioral failures. Each returned Store field is
compared independently against the derived state.

## F#

The prepared F# seed is
`.agentlang/next-efficacy-175/seed-preparation/fsharp/project`. Its seedworker
verified the exact report-141 source copy and reported 18 test groups / 157
assertions passing. Every control was built serially in its own artifact and
temporary directory with `NuGetAudit=false`, `BuildInParallel=false`, and
`-m:1`; each scoring result contains six provider-outcome responses and 78
checks (13 per case).

| Control | Result | Behavioral failures |
| --- | --- | --- |
| `fsharp-correct-auditfix2` | Correct control passed all 6 cases and 78 checks. | None |
| `fsharp-drop-failed` | Mutant executed all 6 cases. | `failure-on-first-retains-head`; `partial-progress-stops-at-failure` |
| `fsharp-continue-after-failure` | Mutant executed all 6 cases. | `failure-on-first-retains-head`; `partial-progress-stops-at-failure` |
| `fsharp-rollback-prefix` | Mutant executed all 6 cases. | `partial-progress-stops-at-failure` |
| `fsharp-reverse-sent` | Mutant executed all 6 cases. | `three-successes-fifo`, `partial-progress-stops-at-failure`, `outcomes-end-before-queue`, and `queue-ends-before-outcomes` |

The F# scorer compares full Store projections, counts, caller-input equality,
and the native failure display. It records the existing
`Email provider failed: ` prefix and normalizes that prefix once when
comparing the shared provider detail.

## Excluded preliminary attempts

These failed attempts are preserved in their own project copies, run outputs,
and terminal transcripts, and are not included as calibration evidence:

- Flow `correct` and `correct-grammarfix1` exposed the unsupported arithmetic
  syntax in the first control source drafts.
- Flow `correct-checkedint` parsed and defined the candidate but commit rejected
  the callback for lacking an attached passing test. The control source gained
  two minimal, control-only empty-queue tests before the accepted preparation.
- `flow-correct-tests1/result.json` and `flow-correct-equals1/result.json`
  exposed two scorer defects: eval does not accept top-level `let` statements,
  and one single-quoted PowerShell here-string left a `$batchExpression` token
  literal. The scorer was changed to single Flow expressions, then rerun.
- The initially accepted Flow results (`flow-correct-expression2` and the four
  `*-final1`/`reverse-sent-final2` mutant results) are preserved but superseded;
  their check only compared fixture construction. The raw `*-sameinput1`
  outputs were executed with the post-call composite expression but used an
  overly narrow check label. The `*-sameinput1-labeled` result files preserve
  their values and cases, changing only `input-unchanged` to
  `input-unchanged-and-delivered`. Each normalized file records its raw source
  path and SHA-256 in `calibration-summary.json`; both raw and normalized files
  are retained.
- `reverse-sent-final1` failed during candidate validation because
  `list.append` received a list as its item; the fresh `reverse-sent-final2`
  copy uses `list.concat` and executed successfully.
- F# `fsharp-correct` built and executed, but the scorer compared output Store
  counts against pre-transition counts. `fsharp-correct-auditfix` then failed
  scorer compilation due an ambiguous JSON indexer; both issues were fixed
  before accepted `fsharp-correct-auditfix2` passed.

All calibration execution was local and synthetic. No provider, network
service, participant agent, product build, or shared build root was used.

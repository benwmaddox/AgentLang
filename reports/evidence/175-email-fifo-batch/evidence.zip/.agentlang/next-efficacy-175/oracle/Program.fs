namespace AgentLang.EmailBatchScorer

open System
open System.Globalization
open System.IO
open System.Text.Json
open System.Text.Json.Nodes
open AgentLang.Business.Domain

module Program =
    let private fail message = invalidOp message

    let private property (element: JsonElement) (name: string) = element.GetProperty(name)

    let private stringValue (element: JsonElement) (name: string) =
        let value = property element name
        if value.ValueKind <> JsonValueKind.String then fail $"Input property '{name}' must be a string."
        value.GetString()

    let private int64Value (element: JsonElement) (name: string) =
        let value = property element name
        if value.ValueKind <> JsonValueKind.Number then fail $"Input property '{name}' must be an integer."
        value.GetInt64()

    let private required (context: string) (value: Result<'value, DomainError>) =
        match value with
        | Ok parsed -> parsed
        | Error error -> fail $"{context}: {DomainError.code error} ({DomainError.message error})"

    let private nodeString (value: string) = JsonValue.Create(value) :> JsonNode
    let private nodeInt (value: int) = JsonValue.Create(value) :> JsonNode
    let private nodeInt64 (value: int64) = JsonValue.Create(value) :> JsonNode
    let private nodeBool (value: bool) = JsonValue.Create(value) :> JsonNode

    let private add (target: JsonObject) name (value: JsonNode) = target.Add(name, value)

    let private isoInstant (value: DateTimeOffset) =
        value.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fffffffzzz", CultureInfo.InvariantCulture)

    let private instant (element: JsonElement) name =
        DateTimeOffset.Parse(stringValue element name, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind)

    let private parseId context parse value =
        parse value |> required context

    let private customerId value = parseId "customer id" CustomerId.parse value
    let private productId value = parseId "product id" ProductId.parse value
    let private subscriptionId value = parseId "subscription id" SubscriptionId.parse value
    let private invoiceId value = parseId "invoice id" InvoiceId.parse value
    let private paymentId value = parseId "payment id" PaymentId.parse value

    let private array (element: JsonElement) name =
        let value = property element name
        if value.ValueKind <> JsonValueKind.Array then fail $"Input property '{name}' must be an array."
        value.EnumerateArray() |> Seq.toArray

    let private makeInputStore (case: JsonElement) =
        let storeSpec = property case "store"
        let customers = array storeSpec "customers"
        let products = array storeSpec "products"
        let subscriptions = array storeSpec "subscriptions"
        let invoices = array storeSpec "invoices"
        let payments = array storeSpec "payments"
        if customers.Length <> 1 || products.Length <> 1 || subscriptions.Length <> 1 || invoices.Length <> 1 || payments.Length <> 1 then
            fail "Each frozen case must contain one customer, product, subscription, invoice, and payment sentinel."

        let customerSpec = customers[0]
        let customerKey = customerId (stringValue customerSpec "id")
        let address = Email.create (stringValue customerSpec "email") |> required "create sentinel email"
        let customer =
            Customer.create customerKey address (stringValue customerSpec "kind")
                (Money.ofMinorUnits (int64Value customerSpec "balance")) (instant customerSpec "createdAt")
            |> required "create sentinel customer"
        let initial = Store.addCustomer customer Store.empty |> required "add sentinel customer"

        let productSpec = products[0]
        let productKey = productId (stringValue productSpec "id")
        let product =
            Product.create productKey (stringValue productSpec "name") (Money.ofMinorUnits (int64Value productSpec "unitPrice"))
            |> required "create sentinel product"
        let withProduct = Store.addProduct product initial |> required "add sentinel product"

        let subscriptionSpec = subscriptions[0]
        if stringValue subscriptionSpec "status" <> "active" || (property subscriptionSpec "cancelledAt").ValueKind <> JsonValueKind.Null then
            fail "The current F# fixture adapter expects an active subscription with no cancellation timestamp."
        let withSubscription, _ =
            Subscription.start withProduct (subscriptionId (stringValue subscriptionSpec "id")) customerKey productKey
                (stringValue subscriptionSpec "term") (instant subscriptionSpec "startedAt") (instant subscriptionSpec "expiresAt")
            |> required "create sentinel subscription"

        let invoiceSpec = invoices[0]
        if stringValue invoiceSpec "status" <> "paid" then fail "The frozen invoice sentinel must be paid."
        let invoiceLines = array invoiceSpec "lines"
        if invoiceLines.Length <> 1 then fail "The F# input adapter expects one invoice line sentinel."
        let invoiceLine = invoiceLines[0]
        if productId (stringValue invoiceLine "productId") <> productKey ||
           stringValue invoiceLine "description" <> Product.name product ||
           int64Value invoiceLine "unitPrice" <> int64Value productSpec "unitPrice" then
            fail "The invoice line must match the sentinel product."
        let quantity = int (int64Value invoiceLine "quantity")
        let withInvoice, createdInvoice =
            Invoice.create withSubscription (invoiceId (stringValue invoiceSpec "id")) customerKey [ productKey, quantity ] (instant invoiceSpec "createdAt")
            |> required "create sentinel invoice"
        if Money.minorUnits (Invoice.total createdInvoice) <> int64Value invoiceSpec "total" ||
           Money.minorUnits (InvoiceLine.lineTotal (Invoice.lines createdInvoice |> List.head)) <> int64Value invoiceLine "lineTotal" then
            fail "The invoice fixture's calculated total does not match its frozen projection."

        let paymentSpec = payments[0]
        if invoiceId (stringValue paymentSpec "invoiceId") <> invoiceId (stringValue invoiceSpec "id") then
            fail "The sentinel payment must refer to the sentinel invoice."
        let withPayment, _ =
            Payment.submit withInvoice (PaymentProvider.deterministic (stringValue paymentSpec "providerReference"))
                (paymentId (stringValue paymentSpec "id")) (invoiceId (stringValue paymentSpec "invoiceId"))
                (Money.ofMinorUnits (int64Value paymentSpec "amount")) (instant paymentSpec "paidAt")
            |> required "submit sentinel payment"

        let withPriorSent =
            array storeSpec "sentEmails"
            |> Array.fold (fun current messageSpec ->
                let queued, _ =
                    EmailOutbox.queue current customerKey (stringValue messageSpec "subject") (stringValue messageSpec "body")
                    |> required "queue preexisting sent email"
                EmailOutbox.deliverNext queued EmailProvider.deterministic |> required "seed preexisting sent email") withPayment

        let initial =
            array storeSpec "emailOutbox"
            |> Array.fold (fun current messageSpec ->
                EmailOutbox.queue current customerKey (stringValue messageSpec "subject") (stringValue messageSpec "body")
                |> required "queue input email"
                |> fst) withPriorSent
        initial, customerKey, address

    let private emailNode (message: EmailMessage) =
        let node = JsonObject()
        add node "to" (nodeString (EmailMessage.toAddress message |> Email.value))
        add node "subject" (nodeString (EmailMessage.subject message))
        add node "body" (nodeString (EmailMessage.body message))
        node :> JsonNode

    let private customerNode (customer: Customer) =
        let node = JsonObject()
        add node "id" (nodeString (Customer.id customer |> CustomerId.toString))
        add node "email" (nodeString (Customer.email customer |> Email.value))
        add node "kind" (nodeString (Customer.kind customer))
        add node "balance" (nodeInt64 (Customer.balance customer |> Money.minorUnits))
        add node "createdAt" (nodeString (Customer.createdAt customer |> isoInstant))
        node :> JsonNode

    let private productNode (product: Product) =
        let node = JsonObject()
        add node "id" (nodeString (Product.id product |> ProductId.toString))
        add node "name" (nodeString (Product.name product))
        add node "unitPrice" (nodeInt64 (Product.unitPrice product |> Money.minorUnits))
        node :> JsonNode

    let private jsonArray values =
        let output = JsonArray()
        values |> Seq.iter (fun value -> output.Add(value))
        output :> JsonNode

    let private subscriptionNode (subscription: Subscription) =
        let node = JsonObject()
        add node "id" (nodeString (Subscription.id subscription |> SubscriptionId.toString))
        add node "customerId" (nodeString (Subscription.customerId subscription |> CustomerId.toString))
        add node "productId" (nodeString (Subscription.productId subscription |> ProductId.toString))
        add node "term" (nodeString (Subscription.term subscription))
        add node "startedAt" (nodeString (Subscription.startedAt subscription |> isoInstant))
        add node "expiresAt" (nodeString (Subscription.expiresAt subscription |> isoInstant))
        add node "status" (nodeString (if Subscription.status subscription = Active then "active" else "cancelled"))
        add node "cancelledAt" (Subscription.cancelledAt subscription |> Option.map (isoInstant >> nodeString) |> Option.defaultValue null)
        node :> JsonNode

    let private invoiceLineNode (line: InvoiceLine) =
        let node = JsonObject()
        add node "productId" (nodeString (InvoiceLine.productId line |> ProductId.toString))
        add node "description" (nodeString (InvoiceLine.description line))
        add node "quantity" (nodeInt (InvoiceLine.quantity line))
        add node "unitPrice" (nodeInt64 (InvoiceLine.unitPrice line |> Money.minorUnits))
        add node "lineTotal" (nodeInt64 (InvoiceLine.lineTotal line |> Money.minorUnits))
        node :> JsonNode

    let private invoiceNode (invoice: Invoice) =
        let node = JsonObject()
        add node "id" (nodeString (Invoice.id invoice |> InvoiceId.toString))
        add node "customerId" (nodeString (Invoice.customerId invoice |> CustomerId.toString))
        add node "lines" (Invoice.lines invoice |> List.map invoiceLineNode |> jsonArray)
        add node "total" (nodeInt64 (Invoice.total invoice |> Money.minorUnits))
        add node "createdAt" (nodeString (Invoice.createdAt invoice |> isoInstant))
        add node "status" (nodeString (if Invoice.status invoice = Paid then "paid" else "open"))
        node :> JsonNode

    let private paymentNode (payment: Payment) =
        let node = JsonObject()
        add node "id" (nodeString (Payment.id payment |> PaymentId.toString))
        add node "invoiceId" (nodeString (Payment.invoiceId payment |> InvoiceId.toString))
        add node "amount" (nodeInt64 (Payment.amount payment |> Money.minorUnits))
        add node "providerReference" (nodeString (Payment.providerReference payment))
        add node "paidAt" (nodeString (Payment.paidAt payment |> isoInstant))
        node :> JsonNode

    let private storeProjection (case: JsonElement) (store: Store) =
        let node = JsonObject()
        add node "customers" (Store.customers store |> List.map customerNode |> jsonArray)
        let storeSpec = property case "store"
        let products =
            array storeSpec "products"
            |> Array.choose (fun spec ->
                ProductId.parse (stringValue spec "id")
                |> required "projection product id"
                |> fun key -> Store.product key store |> Option.map productNode)
            |> jsonArray
        let subscriptions =
            array storeSpec "subscriptions"
            |> Array.choose (fun spec ->
                SubscriptionId.parse (stringValue spec "id")
                |> required "projection subscription id"
                |> fun key -> Store.subscription key store |> Option.map subscriptionNode)
            |> jsonArray
        let invoices =
            array storeSpec "invoices"
            |> Array.choose (fun spec ->
                InvoiceId.parse (stringValue spec "id")
                |> required "projection invoice id"
                |> fun key -> Store.invoice key store |> Option.map invoiceNode)
            |> jsonArray
        add node "products" products
        add node "subscriptions" subscriptions
        add node "invoices" invoices
        add node "payments" (Store.payments store |> List.map paymentNode |> jsonArray)
        add node "emailOutbox" (Store.pendingEmails store |> List.map emailNode |> jsonArray)
        add node "sentEmails" (Store.sentEmails store |> List.map emailNode |> jsonArray)
        node :> JsonNode

    let private outcome (element: JsonElement) =
        let hasOk, okValue = element.TryGetProperty("ok")
        let hasError, errorValue = element.TryGetProperty("error")
        if hasOk && not hasError && okValue.ValueKind = JsonValueKind.True then
            Ok ()
        elif hasError && not hasOk && errorValue.ValueKind = JsonValueKind.String then
            Error(errorValue.GetString())
        else
            fail "Provider outcomes must be exactly {ok:true} or {error:<string>}."

    let private derive (case: JsonElement) =
        let queueLength = (array (property case "store") "emailOutbox").Length
        let outcomes = array case "outcomes"
        let mutable delivered = 0
        let mutable failure: string option = None
        let mutable index = 0
        let mutable running = true
        while running && index < outcomes.Length && delivered < queueLength do
            match outcome outcomes[index] with
            | Ok () -> delivered <- delivered + 1
            | Error detail -> failure <- Some detail; running <- false
            index <- index + 1
        delivered, failure

    let private cloneElement (element: JsonElement) = JsonNode.Parse(element.GetRawText())

    let private canonicalNode (node: JsonNode) = JsonNode.Parse(node.ToJsonString())

    let private deriveExpectedStore (case: JsonElement) delivered =
        let storeSpec = property case "store"
        let expected = JsonNode.Parse(storeSpec.GetRawText()).AsObject()
        let queue = array storeSpec "emailOutbox"
        let priorSent = array storeSpec "sentEmails"
        let remaining = JsonArray()
        queue |> Array.skip delivered |> Array.iter (cloneElement >> remaining.Add)
        let sent = JsonArray()
        priorSent |> Array.iter (cloneElement >> sent.Add)
        queue |> Array.take delivered |> Array.iter (cloneElement >> sent.Add)
        expected["emailOutbox"] <- remaining
        expected["sentEmails"] <- sent
        expected

    let private expectedFailure detail =
        match detail with
        | None -> null
        | Some value ->
            let node = JsonObject()
            add node "code" (nodeString "EMAIL_PROVIDER_FAILURE")
            add node "detail" (nodeString value)
            node :> JsonNode

    let private normalizeFSharpDetail (message: string) =
        let prefix = "Email provider failed: "
        if message.StartsWith(prefix, StringComparison.Ordinal) then message.Substring(prefix.Length) else message

    let private actualFailure (failure: DomainError option) =
        match failure with
        | None -> null
        | Some error ->
            let node = JsonObject()
            add node "code" (nodeString (DomainError.code error))
            add node "nativeMessage" (nodeString (DomainError.message error))
            add node "detail" (nodeString (DomainError.message error |> normalizeFSharpDetail))
            node :> JsonNode

    let private failureMatches (expected: string option) (actual: DomainError option) =
        match expected, actual with
        | None, None -> true
        | Some detail, Some error ->
            DomainError.code error = "EMAIL_PROVIDER_FAILURE" && normalizeFSharpDetail (DomainError.message error) = detail
        | _ -> false

    let private expectedCounts (expectedStore: JsonObject) =
        let count (field: string) = expectedStore[field].AsArray().Count
        count "customers",
        count "products",
        count "subscriptions",
        count "invoices",
        count "payments",
        count "emailOutbox",
        count "sentEmails"

    let private countsMatch (expectedStore: JsonObject) (store: Store) =
        let actual = Store.summary store
        let customers, products, subscriptions, invoices, payments, pending, sent = expectedCounts expectedStore
        actual.Customers = customers && actual.Products = products && actual.Subscriptions = subscriptions &&
        actual.Invoices = invoices && actual.Payments = payments && actual.PendingEmails = pending && actual.SentEmails = sent

    let private scoreCase (case: JsonElement) =
        let initial, _, _ = makeInputStore case
        let beforeProjection = storeProjection case initial
        let outcomes = array case "outcomes" |> Array.map outcome |> Array.toList
        let expectedDelivered, expectedFailureDetail = derive case
        let expectedStore = deriveExpectedStore case expectedDelivered

        // Invoke the candidate's public production operation through a one-line source adapter.
        let actual = CandidateAdapter.invoke initial outcomes
        let actualProjection = storeProjection case actual.Store
        let afterInputProjection = storeProjection case initial
        let beforeComparable = canonicalNode beforeProjection
        let afterComparable = canonicalNode afterInputProjection
        let expectedComparable = canonicalNode expectedStore
        let actualComparable = canonicalNode actualProjection
        let inputMatchesFixture = JsonNode.DeepEquals(beforeComparable, JsonNode.Parse((property case "store").GetRawText()))
        let inputUnchanged = JsonNode.DeepEquals(beforeComparable, afterComparable)
        let actualError = actualFailure actual.Failure
        let expectedError = expectedFailure expectedFailureDetail
        let checks = JsonObject()
        add checks "inputMatchesFixture" (nodeBool inputMatchesFixture)
        add checks "inputUnchanged" (nodeBool inputUnchanged)
        add checks "fullStore" (nodeBool (JsonNode.DeepEquals(actualComparable, expectedComparable)))
        for field in [ "customers"; "products"; "subscriptions"; "invoices"; "payments"; "emailOutbox"; "sentEmails" ] do
            add checks $"store.{field}" (nodeBool (JsonNode.DeepEquals(actualComparable[field], expectedComparable[field])))
        add checks "storeCounts" (nodeBool (countsMatch expectedStore actual.Store))
        add checks "delivered" (nodeBool (actual.Delivered = expectedDelivered))
        add checks "failureCodeAndDetail" (nodeBool (failureMatches expectedFailureDetail actual.Failure))
        let passed = checks |> Seq.forall (fun pair -> pair.Value.GetValue<bool>())

        let actualNode = JsonObject()
        add actualNode "store" actualProjection
        add actualNode "delivered" (nodeInt actual.Delivered)
        add actualNode "failure" actualError
        let expectedNode = JsonObject()
        add expectedNode "store" expectedStore
        add expectedNode "delivered" (nodeInt expectedDelivered)
        add expectedNode "failure" expectedError
        let output = JsonObject()
        add output "id" (nodeString (stringValue case "id"))
        add output "passed" (nodeBool passed)
        add output "checks" checks
        add output "expected" expectedNode
        add output "actual" actualNode
        output :> JsonNode, passed

    [<EntryPoint>]
    let main arguments =
        try
            let casesPath =
                arguments
                |> Array.toList
                |> List.tryFindIndex ((=) "--cases")
                |> Option.bind (fun index -> if index + 1 < arguments.Length then Some arguments[index + 1] else None)
                |> Option.defaultWith (fun () -> fail "Usage: scorer --cases <cases.json>")
            use document = JsonDocument.Parse(File.ReadAllText(casesPath, Text.Encoding.UTF8))
            let cases = property document.RootElement "cases" |> fun value -> value.EnumerateArray() |> Seq.toArray
            if cases.Length <> 6 then fail $"Expected six frozen cases; found {cases.Length}."
            let expectedIds = [| "three-successes-fifo"; "failure-on-first-retains-head"; "partial-progress-stops-at-failure"; "outcomes-end-before-queue"; "queue-ends-before-outcomes"; "empty-queue-and-outcomes" |]
            let actualIds = cases |> Array.map (fun case -> stringValue case "id")
            if actualIds <> expectedIds then fail "The frozen six-case IDs or order changed."
            let scored = cases |> Array.map scoreCase
            let outputCases = JsonArray()
            scored |> Array.iter (fun (item, _) -> outputCases.Add(item))
            let output = JsonObject()
            add output "schemaVersion" (nodeInt 1)
            add output "operation" (nodeString "EmailOutbox.deliverBatch")
            add output "responseCount" (nodeInt scored.Length)
            add output "passed" (nodeBool (scored |> Array.forall snd))
            add output "cases" (outputCases :> JsonNode)
            Console.WriteLine("EMAIL_BATCH_SCORE_JSON:" + output.ToJsonString())
            0
        with error ->
            eprintfn "SCORER_ERROR: %s" (error.ToString())
            2

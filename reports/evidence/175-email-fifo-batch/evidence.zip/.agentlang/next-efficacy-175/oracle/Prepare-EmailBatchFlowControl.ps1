#requires -Version 7.5
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('correct','drop-failed','continue-after-failure','rollback-prefix','reverse-sent')][string]$Mode,
    [Parameter(Mandatory)][string]$CliDll,
    [Parameter(Mandatory)][string]$SourceProject,
    [Parameter(Mandatory)][string]$Destination
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$CliDll = (Resolve-Path -LiteralPath $CliDll).Path
$SourceProject = (Resolve-Path -LiteralPath $SourceProject).Path
$Destination = [IO.Path]::GetFullPath($Destination)
if (Test-Path -LiteralPath $Destination) { throw "Refusing to overwrite existing control project: $Destination" }
[void][IO.Directory]::CreateDirectory($Destination)
foreach ($item in Get-ChildItem -LiteralPath $SourceProject -Recurse -Force) {
    $relative = [IO.Path]::GetRelativePath($SourceProject, $item.FullName)
    if ($relative -match '(^|[\\/])(bin|obj|\.git)([\\/]|$)') { continue }
    $target = Join-Path $Destination $relative
    if ($item.PSIsContainer) { [void][IO.Directory]::CreateDirectory($target) }
    else {
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        [IO.File]::Copy($item.FullName, $target, $false)
    }
}

if (-not (Test-Path -LiteralPath (Join-Path $Destination 'dictionary.agent') -PathType Leaf)) { throw 'Flow source project is missing dictionary.agent.' }
if ((Get-Content -LiteralPath (Join-Path $Destination 'dictionary.agent') -Raw).Contains('email.deliver-batch')) {
    throw 'Control source must start from the batch-operation-free Flow seed.'
}

. (Join-Path $PSScriptRoot 'EmailBatchFlowControlSource.ps1')
$source = New-EmailBatchFlowControlSource -Mode $Mode

$requests = @(
    [ordered]@{ op = 'task.begin'; goal = "Install email batch $Mode control" },
    [ordered]@{ op = 'define'; frontend = 'flow'; syntaxVersion = 2; source = $source },
    [ordered]@{ op = 'commit'; word = 'email.deliver-batch'; library = $false },
    [ordered]@{ op = 'task.commit' }
)
$start = [Diagnostics.ProcessStartInfo]::new()
$start.FileName = 'dotnet'; $start.WorkingDirectory = $Destination; $start.UseShellExecute = $false
$start.CreateNoWindow = $true; $start.RedirectStandardInput = $true
$start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
$start.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
foreach ($argument in @($CliDll, '--project', $Destination, '--jsonl')) { [void]$start.ArgumentList.Add([string]$argument) }
$process = [Diagnostics.Process]::new(); $process.StartInfo = $start
if (-not $process.Start()) { throw 'Flow CLI did not start.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync(); $stderrTask = $process.StandardError.ReadToEndAsync()
foreach ($request in $requests) { $process.StandardInput.WriteLine((ConvertTo-Json -InputObject $request -Depth 40 -Compress)) }
$process.StandardInput.Close()
if (-not $process.WaitForExit(180000)) { try { $process.Kill($true) } catch { }; throw 'Flow control installation timed out.' }
$stdout = $stdoutTask.GetAwaiter().GetResult(); $stderr = $stderrTask.GetAwaiter().GetResult()
$exitCode = $process.ExitCode; $process.Dispose()
$responses = @($stdout -split '\r?\n' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { ConvertFrom-Json -InputObject $_ -AsHashtable -Depth 40 })
$evidencePath = Join-Path $Destination '..' "control-$Mode-install.jsonl"
[IO.File]::WriteAllText([IO.Path]::GetFullPath($evidencePath), $stdout, [Text.UTF8Encoding]::new($false))
if ($exitCode -ne 0 -or $responses.Count -ne $requests.Count -or @($responses | Where-Object { $_.ok -ne $true }).Count -gt 0) {
    throw "Flow control install failed (exit=$exitCode, responses=$($responses.Count)/$($requests.Count)): $stderr`n$stdout"
}
[pscustomobject]@{ Mode = $Mode; Project = $Destination; PublicAdapter = 'email.deliver-batch'; UsesExistingSingleStep = $true; Evidence = [IO.Path]::GetFullPath($evidencePath) }

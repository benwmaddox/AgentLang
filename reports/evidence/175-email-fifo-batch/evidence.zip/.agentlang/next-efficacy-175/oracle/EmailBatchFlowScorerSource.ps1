function ConvertTo-FlowStringLiteral([string]$Value) {
    ConvertTo-Json -InputObject $Value -Compress -Depth 20
}

function New-FlowListExpression([string]$Type, [object[]]$Items) {
    $expression = "list.empty<$Type>()"
    foreach ($item in $Items) {
        if ($null -ne $item -and -not [string]::IsNullOrWhiteSpace([string]$item)) {
            $expression = "list.append($expression, $item)"
        }
    }
    $expression
}

function ConvertTo-FlowMoneyExpression($Value) {
    "Money.new($([long]$Value))"
}

function ConvertTo-FlowInstantExpression([string]$Value) {
    if ($Value.EndsWith('Z', [StringComparison]::Ordinal)) {
        $Value = $Value.Substring(0, $Value.Length - 1) + '+00:00'
    }
    "Instant.new($(ConvertTo-FlowStringLiteral $Value))"
}

function ConvertTo-FlowIdExpression([string]$Type, [string]$Value) {
    "$Type.new($(ConvertTo-FlowStringLiteral $Value))"
}

function ConvertTo-FlowEmailExpression($Message) {
    "emailMessage.new(to = Email.new($(ConvertTo-FlowStringLiteral ([string]$Message.to))), subject = $(ConvertTo-FlowStringLiteral ([string]$Message.subject)), body = $(ConvertTo-FlowStringLiteral ([string]$Message.body)))"
}

function ConvertTo-FlowStoreExpression($Store) {
    $customers = foreach ($item in $Store.customers) {
        "customer.new(id = $(ConvertTo-FlowIdExpression 'CustomerId' ([string]$item.id)), email = Email.new($(ConvertTo-FlowStringLiteral ([string]$item.email))), kind = $(ConvertTo-FlowStringLiteral ([string]$item.kind)), balance = $(ConvertTo-FlowMoneyExpression $item.balance), created-at = $(ConvertTo-FlowInstantExpression ([string]$item.createdAt)))"
    }
    $products = foreach ($item in $Store.products) {
        "product.new(id = $(ConvertTo-FlowIdExpression 'ProductId' ([string]$item.id)), name = $(ConvertTo-FlowStringLiteral ([string]$item.name)), unit-price = $(ConvertTo-FlowMoneyExpression $item.unitPrice))"
    }
    $subscriptions = foreach ($item in $Store.subscriptions) {
        $cancelled = if ($null -eq $item.cancelledAt) {
            'option.none<Instant>()'
        } else {
            "option.some<Instant>($(ConvertTo-FlowInstantExpression ([string]$item.cancelledAt)))"
        }
        "subscription.new(id = $(ConvertTo-FlowIdExpression 'SubscriptionId' ([string]$item.id)), customer-id = $(ConvertTo-FlowIdExpression 'CustomerId' ([string]$item.customerId)), product-id = $(ConvertTo-FlowIdExpression 'ProductId' ([string]$item.productId)), term = $(ConvertTo-FlowStringLiteral ([string]$item.term)), started-at = $(ConvertTo-FlowInstantExpression ([string]$item.startedAt)), expires-at = $(ConvertTo-FlowInstantExpression ([string]$item.expiresAt)), status = SubscriptionStatus.new($(ConvertTo-FlowStringLiteral ([string]$item.status))), cancelled-at = $cancelled)"
    }
    $invoices = foreach ($item in $Store.invoices) {
        $lines = foreach ($line in $item.lines) {
            "invoiceLine.new(product-id = $(ConvertTo-FlowIdExpression 'ProductId' ([string]$line.productId)), description = $(ConvertTo-FlowStringLiteral ([string]$line.description)), quantity = $([int]$line.quantity), unit-price = $(ConvertTo-FlowMoneyExpression $line.unitPrice), line-total = $(ConvertTo-FlowMoneyExpression $line.lineTotal))"
        }
        $lineList = New-FlowListExpression 'InvoiceLine' @($lines)
        "invoice.new(id = $(ConvertTo-FlowIdExpression 'InvoiceId' ([string]$item.id)), customer-id = $(ConvertTo-FlowIdExpression 'CustomerId' ([string]$item.customerId)), lines = $lineList, total = $(ConvertTo-FlowMoneyExpression $item.total), created-at = $(ConvertTo-FlowInstantExpression ([string]$item.createdAt)), status = InvoiceStatus.new($(ConvertTo-FlowStringLiteral ([string]$item.status))))"
    }
    $payments = foreach ($item in $Store.payments) {
        "payment.new(id = $(ConvertTo-FlowIdExpression 'PaymentId' ([string]$item.id)), invoice-id = $(ConvertTo-FlowIdExpression 'InvoiceId' ([string]$item.invoiceId)), amount = $(ConvertTo-FlowMoneyExpression $item.amount), provider-reference = $(ConvertTo-FlowStringLiteral ([string]$item.providerReference)), paid-at = $(ConvertTo-FlowInstantExpression ([string]$item.paidAt)))"
    }
    $outbox = foreach ($item in $Store.emailOutbox) { ConvertTo-FlowEmailExpression $item }
    $sent = foreach ($item in $Store.sentEmails) { ConvertTo-FlowEmailExpression $item }
    "store.new(customers = $(New-FlowListExpression 'Customer' @($customers)), products = $(New-FlowListExpression 'Product' @($products)), subscriptions = $(New-FlowListExpression 'Subscription' @($subscriptions)), invoices = $(New-FlowListExpression 'Invoice' @($invoices)), payments = $(New-FlowListExpression 'Payment' @($payments)), email-outbox = $(New-FlowListExpression 'EmailMessage' @($outbox)), sent-emails = $(New-FlowListExpression 'EmailMessage' @($sent)))"
}

function ConvertTo-FlowOutcomeExpression($Outcome) {
    $hasSuccess = $Outcome.Contains('ok')
    $hasError = $Outcome.Contains('error')
    if ($hasSuccess -and -not $hasError -and $Outcome.ok -is [bool] -and $Outcome.ok) {
        'result.ok<Unit, String>(unit)'
    } elseif ($hasError -and -not $hasSuccess -and $Outcome.error -is [string]) {
        "result.error<Unit, String>($(ConvertTo-FlowStringLiteral ([string]$Outcome.error)))"
    } else {
        throw 'Provider outcomes must be exactly {ok:true} or {error:<string>}.'
    }
}

function New-EmailBatchFlowEvalExpressions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Case,
        [Parameter(Mandatory)]$Expected
    )

    $inputStoreExpression = ConvertTo-FlowStoreExpression $Case.store
    $expectedStoreExpression = ConvertTo-FlowStoreExpression $Expected.store
    $outcomeExpressions = foreach ($outcome in $Case.outcomes) { ConvertTo-FlowOutcomeExpression $outcome }
    $outcomesExpression = New-FlowListExpression 'Result<Unit, String>' @($outcomeExpressions)
    $prefix = "if true {`n    let initial = $inputStoreExpression`n    let outcomes = $outcomesExpression`n    let batch = email.deliver-batch(initial, outcomes)`n    let expected = $expectedStoreExpression`n    "

    $items = [Collections.Generic.List[object]]::new()
    [void]$items.Add(@{ label = 'input-unchanged-and-delivered'; code = "bool.and(equals(initial, $inputStoreExpression), equals(batch.delivered, $([int]$Expected.delivered)))" })
    $storeFields = @(
        @{ label = 'store/customers'; field = 'customers' },
        @{ label = 'store/products'; field = 'products' },
        @{ label = 'store/subscriptions'; field = 'subscriptions' },
        @{ label = 'store/invoices'; field = 'invoices' },
        @{ label = 'store/payments'; field = 'payments' },
        @{ label = 'store/email-outbox'; field = 'email-outbox' },
        @{ label = 'store/sent-emails'; field = 'sent-emails' }
    )
    foreach ($field in $storeFields) {
        [void]$items.Add(@{ label = $field.label; code = "equals(batch.store.$($field.field), expected.$($field.field))" })
    }
    [void]$items.Add(@{ label = 'delivered'; code = "equals(batch.delivered, $([int]$Expected.delivered))" })

    if ($null -eq $Expected.failure) {
        $failureExpression = @"
match batch.failure {
    some ignored => false
    none => true
}
"@
    } else {
        $failureExpression = @"
match batch.failure {
    some problem => {
        if equals(problem.code, $(ConvertTo-FlowStringLiteral ([string]$Expected.failure.code))) {
            equals(problem.message, $(ConvertTo-FlowStringLiteral ([string]$Expected.failure.detail)))
        } else {
            false
        }
    }
    none => false
}
"@
    }
    [void]$items.Add(@{ label = 'failure-code-and-native-detail'; code = $failureExpression })

    foreach ($item in $items) {
        $item.code = $prefix + [string]$item.code + "`n} else { false }"
    }
    return ,$items.ToArray()
}

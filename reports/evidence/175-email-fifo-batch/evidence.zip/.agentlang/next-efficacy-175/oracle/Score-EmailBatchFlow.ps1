#requires -Version 7.5
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CliDll,
    [Parameter(Mandatory)][string]$Project,
    [string]$Cases = (Join-Path $PSScriptRoot 'cases.json'),
    [Parameter(Mandatory)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$CliDll = (Resolve-Path -LiteralPath $CliDll).Path
$Project = (Resolve-Path -LiteralPath $Project).Path
$Cases = (Resolve-Path -LiteralPath $Cases).Path
$caseHash = (Get-FileHash -LiteralPath $Cases -Algorithm SHA256).Hash.ToLowerInvariant()
$hashManifestPath = Join-Path $PSScriptRoot 'input-hashes.json'
$hashManifest = [IO.File]::ReadAllText($hashManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -AsHashtable -Depth 12
$caseHashEntry = @($hashManifest.inputs | Where-Object { $_.path -ceq '.agentlang/next-efficacy-175/oracle/cases.json' })
if ($hashManifest.schemaVersion -ne 1 -or $caseHashEntry.Count -ne 1 -or $caseHash -cne [string]$caseHashEntry[0].sha256) {
    throw 'The case file does not match the frozen input hash manifest.'
}
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
$requestPath = [IO.Path]::ChangeExtension($OutputPath, 'requests.jsonl')
$responsePath = [IO.Path]::ChangeExtension($OutputPath, 'responses.jsonl')
foreach ($path in @($OutputPath, $requestPath, $responsePath)) {
    if (Test-Path -LiteralPath $path) { throw "Refusing to overwrite scorer evidence: $path" }
}
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($OutputPath))

. (Join-Path $PSScriptRoot 'EmailBatchFlowScorerSource.ps1')

function DecodeBool($Node) {
    if ($Node.kind -cne 'bool' -or $Node.value -isnot [bool]) { throw "Expected structured Bool; received $(ConvertTo-Json -InputObject $Node -Compress -Depth 8)" }
    [bool]$Node.value
}
function Invoke-FlowRequests([object[]]$Requests) {
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = 'dotnet'; $start.WorkingDirectory = $Project; $start.UseShellExecute = $false
    $start.CreateNoWindow = $true; $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
    $start.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
    foreach ($argument in @($CliDll, '--project', $Project, '--jsonl')) { [void]$start.ArgumentList.Add([string]$argument) }
    $process = [Diagnostics.Process]::new(); $process.StartInfo = $start
    if (-not $process.Start()) { throw 'Flow CLI did not start.' }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync(); $stderrTask = $process.StandardError.ReadToEndAsync()
    foreach ($request in $Requests) { $process.StandardInput.WriteLine((ConvertTo-Json -InputObject $request -Depth 30 -Compress)) }
    $process.StandardInput.Close()
    if (-not $process.WaitForExit(180000)) { try { $process.Kill($true) } catch { }; throw 'Flow scoring timed out.' }
    $stdout = $stdoutTask.GetAwaiter().GetResult(); $stderr = $stderrTask.GetAwaiter().GetResult()
    $exitCode = $process.ExitCode; $process.Dispose()
    $script:FlowRawOutput = $stdout
    $responses = @($stdout -split '\r?\n' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { ConvertFrom-Json -InputObject $_ -AsHashtable -Depth 30 -DateKind String })
    if ($exitCode -ne 0 -or $responses.Count -ne $Requests.Count) { throw "Flow scorer expected $($Requests.Count) responses, got $($responses.Count), exit=$exitCode. $stderr`n$stdout" }
    return ,$responses
}

$document = [IO.File]::ReadAllText($Cases, [Text.Encoding]::UTF8) | ConvertFrom-Json -AsHashtable -Depth 30 -DateKind String
if ($document.schemaVersion -ne 1 -or $document.cases.Count -ne 6) { throw 'The frozen six-case matrix is missing or has an unsupported schema.' }
$expectedCaseIds = @('three-successes-fifo', 'failure-on-first-retains-head', 'partial-progress-stops-at-failure', 'outcomes-end-before-queue', 'queue-ends-before-outcomes', 'empty-queue-and-outcomes')
$actualCaseIds = @($document.cases | ForEach-Object { [string]$_.id })
if (($actualCaseIds -join "`n") -cne ($expectedCaseIds -join "`n")) { throw 'The frozen six-case IDs or order changed.' }
$requests = [Collections.Generic.List[object]]::new()
$checkSpecs = [Collections.Generic.List[object]]::new()
foreach ($case in $document.cases) {
    $expected = [ordered]@{ store = $case.store.Clone(); delivered = 0; failure = $null }
    $successes = 0
    foreach ($outcome in $case.outcomes) {
        if ($successes -ge $case.store.emailOutbox.Count) { break }
        if ($outcome.Contains('error')) {
            $expected.failure = @{ code = 'EMAIL_PROVIDER_FAILURE'; detail = [string]$outcome.error }
            break
        }
        $successes++
    }
    $expected.delivered = $successes
    $expected.store.emailOutbox = @($case.store.emailOutbox | Select-Object -Skip $successes)
    $expected.store.sentEmails = @($case.store.sentEmails) + @($case.store.emailOutbox | Select-Object -First $successes)

    $items = New-EmailBatchFlowEvalExpressions -Case $case -Expected $expected
    foreach ($item in $items) {
        [void]$checkSpecs.Add([ordered]@{ case = [string]$case.id; label = [string]$item.label })
        [void]$requests.Add([ordered]@{ op = 'eval'; frontend = 'flow'; syntaxVersion = 2; structured = $true; code = [string]$item.code })
    }
}

$responses = Invoke-FlowRequests $requests.ToArray()
[IO.File]::WriteAllLines($requestPath, [string[]]@($requests | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 30 -Compress }), [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($responsePath, $script:FlowRawOutput, [Text.UTF8Encoding]::new($false))
$results = [Collections.Generic.List[object]]::new()
for ($index = 0; $index -lt $responses.Count; $index++) {
    $response = $responses[$index]
    $check = $checkSpecs[$index]
    $actual = $null; $errorCode = $null; $errorText = $null
    if ($response.ok -and @($response.data.structuredStack.values).Count -eq 1) {
        try { $actual = DecodeBool $response.data.structuredStack.values[0] }
        catch { $errorCode = 'SCORER_DECODE_ERROR'; $errorText = $_.Exception.Message }
    } else {
        $errorCode = if ($response.ok) { 'STRUCTURED_VALUE_MISSING' } else { [string]$response.error.code }
        $errorText = if ($response.ok) { 'Eval succeeded without exactly one structured value.' } else { [string]$response.text }
    }
    [void]$results.Add([ordered]@{ case = $check.case; check = $check.label; passed = ($actual -eq $true); actual = $actual; error = $errorCode; errorText = $errorText })
}
$caseResults = foreach ($case in $document.cases) {
    $checks = @($results | Where-Object { $_.case -ceq [string]$case.id })
    [ordered]@{ id = [string]$case.id; passed = (@($checks | Where-Object { -not $_.passed }).Count -eq 0); checks = $checks }
}
$summary = [ordered]@{
    schemaVersion = 1
    operation = 'email.deliver-batch'
    project = $Project
    casesSha256 = $caseHash
    passed = (@($caseResults | Where-Object { -not $_.passed }).Count -eq 0)
    caseCount = $caseResults.Count
    checkCount = $results.Count
    cases = @($caseResults)
}
[IO.File]::WriteAllText($OutputPath, (ConvertTo-Json -InputObject $summary -Depth 24), [Text.UTF8Encoding]::new($false))
$summary | ConvertTo-Json -Depth 24

function New-EmailBatchFlowControlSource {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('correct','drop-failed','continue-after-failure','rollback-prefix','reverse-sent')]
        [string]$Mode
    )

    $priorGuard = if ($Mode -ceq 'continue-after-failure') {
@'
        some earlier => {
            if list.is-empty?(state.store.email-outbox) {
                state
            } else {
                match outcome {
                    ok delivered => {
                        match email.apply-delivery-result(state.store, result.ok<Unit, BusinessError>(unit)) {
                            ok updated => {
                                match int.add-checked(state.delivered, 1) {
                                    ok next-count => {
                                        emailBatchAccumulator.new(original = state.original, store = updated, delivered = next-count, failure = state.failure)
                                    }
                                    error ignored => { state }
                                }
                            }
                            error ignored => { state }
                        }
                    }
                    error detail => {
                        let provider-error = businessError.new(code = "EMAIL_PROVIDER_FAILURE", message = detail)
                        match email.apply-delivery-result(state.store, result.error<Unit, BusinessError>(provider-error)) {
                            ok unexpected => { state }
                            error ignored => { state }
                        }
                    }
                }
            }
        }
        none => {
'@
    } else {
@'
        some earlier => { state }
        none => {
'@
    }

    $failureTransition = switch ($Mode) {
        'drop-failed' {
@'
                            let updated = store.with-email-state(state.store, list.tail(state.store.email-outbox), state.store.sent-emails)
                            emailBatchAccumulator.new(original = state.original, store = updated, delivered = state.delivered, failure = option.some<BusinessError>(problem))
'@
        }
        'rollback-prefix' {
@'
                            emailBatchAccumulator.new(original = state.original, store = state.original, delivered = 0, failure = option.some<BusinessError>(problem))
'@
        }
        default {
@'
                            emailBatchAccumulator.new(original = state.original, store = state.store, delivered = state.delivered, failure = option.some<BusinessError>(problem))
'@
        }
    }

    $successTransition = if ($Mode -ceq 'reverse-sent') {
@'
                            match list.get(state.store.email-outbox, 0) {
                                some first => {
                                    let reversed = list.concat(list.singleton<EmailMessage>(first), state.store.sent-emails)
                                    let reordered = store.with-email-state(updated, updated.email-outbox, reversed)
                                    match int.add-checked(state.delivered, 1) {
                                        ok next-count => {
                                            emailBatchAccumulator.new(original = state.original, store = reordered, delivered = next-count, failure = state.failure)
                                        }
                                        error ignored => { state }
                                    }
                                }
                                none => { state }
                            }
'@
    } else {
@'
                            match int.add-checked(state.delivered, 1) {
                                ok next-count => {
                                    emailBatchAccumulator.new(original = state.original, store = updated, delivered = next-count, failure = state.failure)
                                }
                                error ignored => { state }
                            }
'@
    }

    $source = @"
// Explicit Flow/2 calibration adapter. This is candidate source, not a model-only oracle.
record EmailBatchResult {
    field store: Store
    field delivered: Int
    field failure: Option<BusinessError>
}

record EmailBatchAccumulator {
    field original: Store
    field store: Store
    field delivered: Int
    field failure: Option<BusinessError>
}

fn email.batch-delivery-step(state: EmailBatchAccumulator, outcome: Result<Unit, String>) -> EmailBatchAccumulator {
    match state.failure {
$priorGuard
            if list.is-empty?(state.store.email-outbox) {
                state
            } else {
                match outcome {
                    ok delivered => {
                        match email.apply-delivery-result(state.store, result.ok<Unit, BusinessError>(unit)) {
                            ok updated => {
$successTransition
                            }
                            error unexpected => { state }
                        }
                    }
                    error detail => {
                        let provider-error = businessError.new(code = "EMAIL_PROVIDER_FAILURE", message = detail)
                        match email.apply-delivery-result(state.store, result.error<Unit, BusinessError>(provider-error)) {
                            ok unexpected => { state }
                            error problem => {
$failureTransition
                            }
                        }
                    }
                }
            }
        }
    }
}

fn email.deliver-batch(store: Store, outcomes: List<Result<Unit, String>>) -> EmailBatchResult {
    doc "Control-only batch adapter used to calibrate the external acceptance scorer."

    let initial = emailBatchAccumulator.new(original = store, store = store, delivered = 0, failure = option.none<BusinessError>())
    let completed = outcomes.fold(initial, email.batch-delivery-step)
    emailBatchResult.new(store = completed.store, delivered = completed.delivered, failure = completed.failure)
}

test email.batch-delivery-step/empty-queue-noop {
    let empty-store = store.empty(unit)
    let initial = emailBatchAccumulator.new(original = empty-store, store = empty-store, delivered = 0, failure = option.none<BusinessError>())
    let actual = email.batch-delivery-step(initial, result.ok<Unit, String>(unit))
    equals(actual, initial)
    => true
}

test email.deliver-batch/empty-queue-noop {
    let empty-store = store.empty(unit)
    let actual = email.deliver-batch(empty-store, list.empty<Result<Unit, String>>())
    bool.and(
        equals(actual.store, empty-store),
        bool.and(equals(actual.delivered, 0), equals(actual.failure, option.none<BusinessError>()))
    )
    => true
}

"@

    return $source
}

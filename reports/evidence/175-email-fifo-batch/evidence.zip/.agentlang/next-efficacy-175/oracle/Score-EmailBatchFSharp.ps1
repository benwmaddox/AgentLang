#requires -Version 7.5
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CandidateProject,
    [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9._-]+$')][string]$RunId,
    [string]$Cases = (Join-Path $PSScriptRoot 'cases.json')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$CandidateProject = (Resolve-Path -LiteralPath $CandidateProject).Path
$Cases = (Resolve-Path -LiteralPath $Cases).Path
$caseHash = (Get-FileHash -LiteralPath $Cases -Algorithm SHA256).Hash.ToLowerInvariant()
$hashManifestPath = Join-Path $PSScriptRoot 'input-hashes.json'
$hashManifest = [IO.File]::ReadAllText($hashManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -AsHashtable -Depth 12
$caseHashEntry = @($hashManifest.inputs | Where-Object { $_.path -ceq '.agentlang/next-efficacy-175/oracle/cases.json' })
if ($hashManifest.schemaVersion -ne 1 -or $caseHashEntry.Count -ne 1 -or $caseHash -cne [string]$caseHashEntry[0].sha256) {
    throw 'The case file does not match the frozen input hash manifest.'
}
$runRoot = Join-Path (Join-Path $PSScriptRoot 'runs') $RunId
$artifactRoot = Join-Path $runRoot 'artifacts'
if (Test-Path -LiteralPath $runRoot) { throw "Evidence run already exists; choose a fresh RunId: $runRoot" }
[void][IO.Directory]::CreateDirectory($artifactRoot)

$buildArguments = @(
    'build', (Join-Path $PSScriptRoot 'EmailBatchScorer.fsproj'),
    '--artifacts-path', $artifactRoot,
    '-c', 'Release',
    "-p:CandidateProject=$CandidateProject",
    '-p:NuGetAudit=false',
    '-p:BuildInParallel=false',
    '-m:1'
)
$buildOutput = @(& dotnet @buildArguments 2>&1 | ForEach-Object { $_.ToString() })
$buildExitCode = $LASTEXITCODE
$buildOutput | Set-Content -LiteralPath (Join-Path $runRoot 'build.log') -Encoding utf8
if ($buildExitCode -ne 0) { throw "Source scorer/candidate build failed with exit code $buildExitCode. See $(Join-Path $runRoot 'build.log')." }

$scorerDll = Join-Path $artifactRoot 'bin\EmailBatchScorer\release\EmailBatchScorer.dll'
if (-not (Test-Path -LiteralPath $scorerDll -PathType Leaf)) { throw "Expected freshly built scorer DLL at $scorerDll." }
$scoreArguments = @($scorerDll, '--cases', $Cases)
$scoreOutput = @(& dotnet @scoreArguments 2>&1 | ForEach-Object { $_.ToString() })
$scoreExitCode = $LASTEXITCODE
$scoreOutput | Set-Content -LiteralPath (Join-Path $runRoot 'scorer.log') -Encoding utf8
$marker = 'EMAIL_BATCH_SCORE_JSON:'
$scoreLines = @($scoreOutput | Where-Object { $_.StartsWith($marker, [StringComparison]::Ordinal) })
if ($scoreExitCode -ne 0) { throw "Scorer process failed with exit code $scoreExitCode. See $(Join-Path $runRoot 'scorer.log')." }
if ($scoreLines.Count -ne 1) { throw "Scorer returned $($scoreLines.Count) JSON responses; expected one. See $(Join-Path $runRoot 'scorer.log')." }
$scoreJson = $scoreLines[0].Substring($marker.Length)
$score = $scoreJson | ConvertFrom-Json -Depth 30
if ($score.schemaVersion -ne 1 -or $score.responseCount -ne 6 -or $score.cases.Count -ne 6) {
    throw "Scorer response contract failed: schema=$($score.schemaVersion), responses=$($score.responseCount), cases=$($score.cases.Count)."
}
[IO.File]::WriteAllText((Join-Path $runRoot 'result.json'), $scoreJson + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))

$sourceFiles = @(
    $CandidateProject,
    (Join-Path (Split-Path -Parent $CandidateProject) 'Business.fs'),
    $Cases,
    (Join-Path $PSScriptRoot 'Program.fs'),
    (Join-Path $PSScriptRoot 'CandidateAdapter.fs'),
    (Join-Path $PSScriptRoot 'EmailBatchScorer.fsproj'),
    $PSCommandPath
)
$hashes = [ordered]@{}
foreach ($path in $sourceFiles) {
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $relative = if ($path.StartsWith($repositoryRoot, [StringComparison]::OrdinalIgnoreCase)) { $path.Substring($repositoryRoot.Length).TrimStart('\') } else { $path }
        $hashes[$relative] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}
$commandRecord = [ordered]@{
    runId = $RunId
    candidateProject = $CandidateProject
    cases = $Cases
    casesSha256 = $caseHash
    build = [ordered]@{ executable = 'dotnet'; arguments = $buildArguments; exitCode = $buildExitCode }
    scorer = [ordered]@{ executable = 'dotnet'; arguments = $scoreArguments; exitCode = $scoreExitCode; responseCount = $score.responseCount; behaviorPassed = [bool]$score.passed }
    sourceSha256 = $hashes
}
$commandRecord | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $runRoot 'command.json') -Encoding utf8
[pscustomobject]@{
    RunId = $RunId
    RunRoot = $runRoot
    ResultPath = Join-Path $runRoot 'result.json'
    BehaviorPassed = [bool]$score.passed
    CaseCount = [int]$score.responseCount
    CaseResults = @($score.cases | ForEach-Object { [pscustomobject]@{ Id = $_.id; Passed = [bool]$_.passed } })
}

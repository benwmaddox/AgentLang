#requires -Version 7.5
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'EmailBatchFlowControlSource.ps1')
. (Join-Path $PSScriptRoot 'EmailBatchFlowScorerSource.ps1')

function Read-OracleJson([string]$Name) {
    $path = Join-Path $PSScriptRoot $Name
    [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8) | ConvertFrom-Json -AsHashtable -Depth 40 -DateKind String
}

function Remove-FlowStringsAndComments([string]$Source, [string]$Name) {
    $builder = [Text.StringBuilder]::new()
    $inString = $false
    $escaped = $false
    $inLineComment = $false
    for ($index = 0; $index -lt $Source.Length; $index++) {
        $character = $Source[$index]
        $next = if ($index + 1 -lt $Source.Length) { $Source[$index + 1] } else { [char]0 }

        if ($inString) {
            if ($character -eq "`n") { [void]$builder.Append("`n") } else { [void]$builder.Append(' ') }
            if ($escaped) { $escaped = $false }
            elseif ($character -eq '\') { $escaped = $true }
            elseif ($character -eq '"') { $inString = $false }
            continue
        }

        if ($inLineComment) {
            if ($character -eq "`n") {
                $inLineComment = $false
                [void]$builder.Append("`n")
            } else {
                [void]$builder.Append(' ')
            }
            continue
        }

        if ($character -eq '"') {
            $inString = $true
            [void]$builder.Append(' ')
            continue
        }
        if ($character -eq '/' -and $next -eq '/') {
            $inLineComment = $true
            [void]$builder.Append(' ')
            $index++
            continue
        }
        [void]$builder.Append($character)
    }

    if ($inString) { throw "$Name has an unterminated Flow string literal." }
    $builder.ToString()
}

function Assert-Flow2Source([string]$Source, [string]$Name) {
    $code = Remove-FlowStringsAndComments $Source $Name
    if ($code -match '::') { throw "$Name contains a Flow/1 qualified call; Flow/2 uses dotted calls." }
    if ($code.Contains(';')) { throw "$Name contains an optional Flow statement separator; generated Flow/2 source uses newlines." }
    if ($code -match '\bword\s+') { throw "$Name declares a Flow/1 word instead of a Flow/2 function." }
    if ($code -match '\s(?:==|!=|<=|>=|\+|\*|/|&&|\|\|)\s') { throw "$Name contains unsupported Flow infix syntax." }
    if ($code -match '\.(customers|products|subscriptions|invoices|payments|email-outbox|sent-emails|store|delivered|failure)\s*\(') {
        throw "$Name invokes a record property with accessor parentheses; Flow/2 properties are plain dot access."
    }

    $stack = [Collections.Generic.List[char]]::new()
    for ($index = 0; $index -lt $code.Length; $index++) {
        $character = $code[$index]
        switch -CaseSensitive ([string]$character) {
            '(' { [void]$stack.Add('(') }
            '{' { [void]$stack.Add('{') }
            '[' { [void]$stack.Add('[') }
            '<' { [void]$stack.Add('<') }
            ')' {
                if ($stack.Count -eq 0 -or $stack[$stack.Count - 1] -cne '(') { throw "$Name has an unbalanced ')' delimiter." }
                $stack.RemoveAt($stack.Count - 1)
            }
            '}' {
                if ($stack.Count -eq 0 -or $stack[$stack.Count - 1] -cne '{') { throw "$Name has an unbalanced '}' delimiter." }
                $stack.RemoveAt($stack.Count - 1)
            }
            ']' {
                if ($stack.Count -eq 0 -or $stack[$stack.Count - 1] -cne '[') { throw "$Name has an unbalanced ']' delimiter." }
                $stack.RemoveAt($stack.Count - 1)
            }
            '>' {
                $previous = if ($index -gt 0) { $code[$index - 1] } else { [char]0 }
                if ($previous -ne '-' -and $previous -ne '=') {
                    if ($stack.Count -eq 0 -or $stack[$stack.Count - 1] -cne '<') { throw "$Name has an unbalanced generic '>' delimiter." }
                    $stack.RemoveAt($stack.Count - 1)
                }
            }
        }
    }
    if ($stack.Count -ne 0) { throw "$Name has unclosed Flow delimiters: $(-join $stack.ToArray())." }
    return $code
}

function Assert-Contains([string]$Text, [string]$Pattern, [string]$Description) {
    if ($Text -notmatch $Pattern) { throw "Missing Flow source requirement: $Description" }
}

function Derive-ExpectedState($Case) {
    $outbox = @($Case.store.emailOutbox)
    $successCount = 0
    $failure = $null
    foreach ($outcome in $Case.outcomes) {
        if ($successCount -ge $outbox.Count) { break }
        if ($outcome.Contains('error')) {
            $failure = [ordered]@{ code = 'EMAIL_PROVIDER_FAILURE'; detail = [string]$outcome.error }
            break
        }
        $successCount++
    }
    $store = $Case.store.Clone()
    $store.emailOutbox = @($outbox | Select-Object -Skip $successCount)
    $store.sentEmails = @($Case.store.sentEmails) + @($outbox | Select-Object -First $successCount)
    [ordered]@{ id = [string]$Case.id; store = $store; delivered = $successCount; failure = $failure }
}

$casesDocument = Read-OracleJson 'cases.json'
$expectedDocument = Read-OracleJson 'expected.json'
$scorerPath = Join-Path $PSScriptRoot 'Score-EmailBatchFlow.ps1'
$scorerText = [IO.File]::ReadAllText($scorerPath, [Text.Encoding]::UTF8)
if ($casesDocument.schemaVersion -ne 1 -or $casesDocument.cases.Count -ne 6) { throw 'Source audit requires the frozen six-case matrix.' }
if ($expectedDocument.schemaVersion -ne 1 -or $expectedDocument.cases.Count -ne 6) { throw 'Source audit requires six derived expected states.' }

$expectedIds = @('three-successes-fifo', 'failure-on-first-retains-head', 'partial-progress-stops-at-failure', 'outcomes-end-before-queue', 'queue-ends-before-outcomes', 'empty-queue-and-outcomes')
if (($casesDocument.cases.id -join "`n") -cne ($expectedIds -join "`n") -or ($expectedDocument.cases.id -join "`n") -cne ($expectedIds -join "`n")) {
    throw 'Case or expected-state order differs from the six frozen acceptance cases.'
}
Assert-Contains $scorerText '\. \(Join-Path \$PSScriptRoot ''EmailBatchFlowScorerSource\.ps1''\)' 'the runtime scorer imports the audited expression generator'
Assert-Contains $scorerText 'New-EmailBatchFlowEvalExpressions -Case \$case -Expected \$expected' 'the runtime scorer submits the audited generated evaluations'
Assert-Contains $scorerText 'op = ''eval''; frontend = ''flow''; syntaxVersion = 2; structured = \$true; code = \[string\]\$item\.code' 'the scorer submits structured Flow/2 eval requests'

$modeNames = @('correct', 'drop-failed', 'continue-after-failure', 'rollback-prefix', 'reverse-sent')
$controlSources = @{}
foreach ($mode in $modeNames) {
    $source = New-EmailBatchFlowControlSource -Mode $mode
    $code = Assert-Flow2Source $source "control/$mode"
    Assert-Contains $code 'record EmailBatchResult\s*\{\s*field store: Store\s*field delivered: Int\s*field failure: Option<BusinessError>' "$mode result record fields"
    Assert-Contains $code 'record EmailBatchAccumulator\s*\{' "$mode accumulator record"
    Assert-Contains $code 'fn email\.batch-delivery-step\(' "$mode batch fold callback"
    Assert-Contains $code 'fn email\.deliver-batch\(' "$mode public batch function"
    Assert-Contains $code 'email\.apply-delivery-result\(state\.store,' "$mode calls the existing single-message transition"
    Assert-Contains $code 'outcomes\.fold\(initial, email\.batch-delivery-step\)' "$mode folds ordered outcomes through the callback"
    Assert-Contains $code 'emailBatchResult\.new\(store = completed\.store, delivered = completed\.delivered, failure = completed\.failure\)' "$mode returns all public result fields"
    $controlSources[$mode] = $code
}

Assert-Contains $controlSources['correct'] 'some earlier => \{\s*state\s*\}\s*none =>' 'correct control freezes after an earlier failure'
if ($controlSources['correct'] -match 'list\.tail\(state\.store\.email-outbox\)|email\.reverse-sent-step|store = state\.original, delivered = 0') {
    throw 'The correct control contains a mutant-only transition.'
}
Assert-Contains $controlSources['drop-failed'] 'list\.tail\(state\.store\.email-outbox\)' 'drop-failed mutant removes the failed head'
Assert-Contains $controlSources['continue-after-failure'] 'some earlier => \{\s*if list\.is-empty\?\(state\.store\.email-outbox\) \{\s*state\s*\} else \{\s*match outcome' 'continue-after-failure mutant executes later outcomes'
Assert-Contains $controlSources['rollback-prefix'] 'emailBatchAccumulator\.new\(original = state\.original, store = state\.original, delivered = 0, failure = option\.some<BusinessError>\(problem\)\)' 'rollback-prefix mutant restores initial Store and zero count'
Assert-Contains $controlSources['reverse-sent'] 'list\.concat\(list\.singleton<EmailMessage>\(first\), state\.store\.sent-emails\)' 'reverse-sent mutant prepends delivered messages'

$allLabels = @('input-unchanged-and-delivered', 'store/customers', 'store/products', 'store/subscriptions', 'store/invoices', 'store/payments', 'store/email-outbox', 'store/sent-emails', 'delivered', 'failure-code-and-native-detail')
$snippetCount = 0
for ($caseIndex = 0; $caseIndex -lt $casesDocument.cases.Count; $caseIndex++) {
    $case = $casesDocument.cases[$caseIndex]
    $derived = Derive-ExpectedState $case
    $frozen = $expectedDocument.cases[$caseIndex]
    if ($derived.id -cne $frozen.id -or (ConvertTo-Json -InputObject $derived.store -Compress -Depth 30) -cne (ConvertTo-Json -InputObject $frozen.store -Compress -Depth 30) -or
        $derived.delivered -ne $frozen.delivered -or (ConvertTo-Json -InputObject $derived.failure -Compress -Depth 8) -cne (ConvertTo-Json -InputObject $frozen.failure -Compress -Depth 8)) {
        throw "$($case.id): frozen expected state does not match independent FIFO derivation."
    }

    $items = New-EmailBatchFlowEvalExpressions -Case $case -Expected $derived
    $labels = @($items | ForEach-Object { [string]$_.label })
    if (($labels -join "`n") -cne ($allLabels -join "`n")) { throw "$($case.id): generated scorer assertion set is incomplete or reordered." }
    foreach ($item in $items) {
        $code = Assert-Flow2Source ([string]$item.code) "eval/$($case.id)/$($item.label)"
        Assert-Contains $code '^\s*if true \{' "$($case.id)/$($item.label) is a single Flow expression accepted by eval"
        Assert-Contains $code 'let initial = store\.new\(' "$($case.id)/$($item.label) binds the complete caller input Store"
        Assert-Contains $code 'let outcomes = (list\.empty<Result<Unit, String>>\(\)|list\.append\()' "$($case.id)/$($item.label) binds explicitly typed provider outcomes"
        Assert-Contains $code 'let batch = email\.deliver-batch\(initial, outcomes\)' "$($case.id)/$($item.label) invokes the production candidate once"
        Assert-Contains $code 'let expected = store\.new\(' "$($case.id)/$($item.label) binds a separately reconstructed expected Store"
        Assert-Contains $code '\} else \{ false \}\s*$' "$($case.id)/$($item.label) closes the single-expression wrapper"
        if ([string]$item.label -ceq 'input-unchanged-and-delivered') {
            Assert-Contains $code 'bool\.and\(equals\(initial, store\.new\(.*\)\), equals\(batch\.delivered,' "$($case.id) combines post-call retained input comparison and candidate count observability"
        }
        if ([string]$item.label -like 'store/*') {
            $field = ([string]$item.label).Substring(6)
            Assert-Contains $code "equals\(batch\.store\.$([regex]::Escape($field)), expected\.$([regex]::Escape($field))\)" "$($case.id) checks full Store field $field"
        }
        if ([string]$item.label -ceq 'delivered') { Assert-Contains $code 'equals\(batch\.delivered, [0-9]+\)' "$($case.id) checks delivered count" }
        if ([string]$item.label -ceq 'failure-code-and-native-detail') {
            Assert-Contains $code 'match batch\.failure \{' "$($case.id) checks optional failure shape"
            if ($null -ne $derived.failure) {
                Assert-Contains $code 'equals\(problem\.code,' "$($case.id) checks failure category"
                Assert-Contains $code 'equals\(problem\.message,' "$($case.id) checks native provider detail"
            }
        }
        $snippetCount++
    }
}

if ($snippetCount -ne 60) { throw "Expected 60 candidate evaluation snippets, generated $snippetCount." }
"Flow/2 source audit passed: $($modeNames.Count) executable-source controls, $($casesDocument.cases.Count) independently checked expected states, $snippetCount candidate eval snippets, 10 assertions per case. No CLI, build, or runtime was invoked."

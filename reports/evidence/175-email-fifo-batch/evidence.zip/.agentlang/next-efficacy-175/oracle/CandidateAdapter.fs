namespace AgentLang.EmailBatchScorer

open AgentLang.Business.Domain

/// One-line source adapter for the task's F# public operation.
/// If a candidate intentionally uses another API spelling, adapt only this binding.
module CandidateAdapter =
    let invoke (store: Store) (outcomes: Result<unit, string> list) =
        EmailOutbox.deliverBatch store outcomes

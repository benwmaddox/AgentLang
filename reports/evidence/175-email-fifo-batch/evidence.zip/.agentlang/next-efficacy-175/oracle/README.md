# Email batch independent oracle

This folder contains a narrow host-side oracle for the six FIFO email batch cases in `cases.json`. The pure model derives expected state from each input queue and scripted provider outcomes. Both language scorers call the candidate's production operation and compare the returned count, failure, and every Store collection. F# also checks the same input object before and after the call. Each Flow eval binds the complete input once, invokes the candidate, and combines comparison of that retained binding against a reconstructed full input Store with an expected-count observation. A separate count check reports count mismatches independently.

Each input Store has one sentinel customer, product, subscription, invoice, and payment, two messages already in `sentEmails`, and the case-specific outbox. The F# projection reads the known sentinel entities through the existing public getters and also checks `Store.summary` counts, so removal, alteration, or addition in any collection is visible. Flow compares each complete collection directly. Email comparisons include recipient, subject, and body.

The six cases are three ordered successes; a first-message failure; one success then failure with a trailing success; outcomes exhausted before the queue; queue exhausted before a trailing provider error; and an empty queue with no outcomes. The provider failure must retain code `EMAIL_PROVIDER_FAILURE` and the exact scripted detail. AgentLang exposes the detail as `BusinessError.message`; F# retains the seed's native `Email provider failed: ` prefix, which the F# scorer records and strips once for the shared detail comparison.

The F# adapter binds the exact public `EmailOutbox.deliverBatch` operation and infers its result type from the candidate assembly. It depends on the contract fields `Store`, `Delivered`, and `Failure`; it does not constrain where the candidate declares its result record. The Flow scorer emits Flow/2 source with dotted namespace calls and plain record-property access, invokes `email.deliver-batch` through the pinned CLI JSONL interface, and scores each Store collection separately to make failures localizable. Each Flow eval request is a single expression, as required by the runtime interface. `Audit-EmailBatchFlowSource.ps1` checks the exact generated controls and evaluation snippets for Flow/2 grammar conventions and required case assertions without invoking the CLI or candidate runtime.

The four controls are source adapters installed into disposable copies of the prepared seed. They call the real single-message transition (`EmailOutbox.deliverNext` in F# and `email::apply-delivery-result` in AgentLang), then introduce one behavior error:

| Control | Distinguishing failure |
| --- | --- |
| `drop-failed` | Removes the failed head; the first-failure case catches it. |
| `continue-after-failure` | Uses the next success against the retained failed head; the partial-progress case catches it. |
| `rollback-prefix` | Restores the initial Store and zero count after a later failure; the partial-progress case catches it. |
| `reverse-sent` | Prepends delivered messages to sent mail, disturbing FIFO order; the three-success case catches it. |

The calibrated correct controls passed all six cases in each arm. All four Flow and F# mutants executed and failed at least one behavioral case. Exact result paths, case/check counts, and per-mutant failures are in [`calibration-summary.json`](calibration-summary.json); full terminal/build transcripts are under `calibration-terminal/` and `runs/`. The final Flow result files are metadata-normalized copies of preserved runtime outputs: only the composite check label changed to describe both the retained-input comparison and count observation. Summary entries identify each original output by path and hash. Earlier Flow outputs without the post-call composite check remain preserved and are listed as superseded.

This measures batch behavior only. The Flow control installer commits its batch word outside library qualification, so Flow library qualification and inherited-test preservation remain separate acceptance checks.

`python .agentlang/next-efficacy-175/oracle/model.py --freeze` validates the frozen input matrix, writes `expected.json`, and refreshes `input-hashes.json` with exact hashes for the oracle sources, study plan/task draft, inspected report-141 inputs, the complete accepted Flow and F# seed copies, the Flow seed report, and the pinned CLI. The hash file intentionally excludes itself and the derived expected file; the model freeze itself is source-only.

Execution evidence and both bounded control calibrations are recorded in [`calibration-notes.md`](calibration-notes.md). The correct controls and mutants are local synthetic adapters only; no external provider, network service, participant, or product build was run.

#requires -Version 7.5
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('correct','drop-failed','continue-after-failure','rollback-prefix','reverse-sent')][string]$Mode,
    [Parameter(Mandatory)][string]$SourceProject,
    [Parameter(Mandatory)][string]$Destination
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$SourceProject = (Resolve-Path -LiteralPath $SourceProject).Path
$Destination = [IO.Path]::GetFullPath($Destination)
if (-not (Test-Path -LiteralPath $SourceProject -PathType Container)) { throw "Source project folder not found: $SourceProject" }
if (Test-Path -LiteralPath $Destination) { throw "Refusing to overwrite existing control project: $Destination" }
[void][IO.Directory]::CreateDirectory($Destination)
foreach ($item in Get-ChildItem -LiteralPath $SourceProject -Recurse -Force) {
    $relative = [IO.Path]::GetRelativePath($SourceProject, $item.FullName)
    if ($relative -match '(^|[\\/])(bin|obj|\.git)([\\/]|$)') { continue }
    $target = Join-Path $Destination $relative
    if ($item.PSIsContainer) { [void][IO.Directory]::CreateDirectory($target) }
    else {
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        [IO.File]::Copy($item.FullName, $target, $false)
    }
}

$businessPath = Join-Path $Destination 'business\Business.fs'
$businessSource = [IO.File]::ReadAllText($businessPath, [Text.Encoding]::UTF8)
if ($businessSource.Contains('type EmailBatchResult =') -or $businessSource.Contains('let deliverBatch')) {
    throw 'Control source must start from the batch-operation-free F# seed.'
}
$resultMarker = '    module EmailOutbox ='
$customerMarker = '    module Customer ='
if (([regex]::Matches($businessSource, [regex]::Escape($resultMarker)).Count -ne 1) -or ([regex]::Matches($businessSource, [regex]::Escape($customerMarker)).Count -ne 1)) {
    throw 'Expected the report-141 EmailOutbox and Customer insertion points exactly once.'
}
$resultSource = @'
    type EmailBatchResult = {
        Store: Store
        Delivered: int
        Failure: DomainError option
    }

    type private EmailBatchState = {
        Original: Store
        Store: Store
        Delivered: int
        Failure: DomainError option
    }

'@
$businessSource = $businessSource.Replace($resultMarker, $resultSource + $resultMarker)

$attemptGuard = if ($Mode -ceq 'continue-after-failure') { 'true' } else { 'Option.isNone state.Failure' }
$failureStore = switch ($Mode) {
    'drop-failed' { @'
                                match state.Store.EmailOutbox with
                                | _ :: remaining -> { state.Store with EmailOutbox = remaining }
                                | [] -> state.Store
'@ }
    'rollback-prefix' { '                                state.Original' }
    default { '                                state.Store' }
}
$failureCount = if ($Mode -ceq 'rollback-prefix') { '                                0' } else { '                                state.Delivered' }
$successStore = if ($Mode -ceq 'reverse-sent') {
    '                                { updated with SentEmailMessages = List.rev updated.SentEmailMessages }'
} else {
    '                                updated'
}
$functionSource = @"
        /// Control-only batch adapter used to calibrate the external acceptance scorer.
        let deliverBatch (store: Store) (outcomes: Result<unit, string> list) : EmailBatchResult =
            let initial: EmailBatchState = { Original = store; Store = store; Delivered = 0; Failure = None }
            let step (state: EmailBatchState) (selectedOutcome: Result<unit, string>) : EmailBatchState =
                if not ($attemptGuard) then
                    state
                else
                    match state.Store.EmailOutbox with
                    | [] -> state
                    | _ ->
                        let provider = { Send = fun _ -> selectedOutcome }
                        match deliverNext state.Store provider with
                        | Ok updated ->
                            let nextStore =
$successStore
                            { state with Store = nextStore; Delivered = state.Delivered + 1 }
                        | Error error ->
                            let nextStore =
$failureStore
                            let nextDelivered =
$failureCount
                            let failure =
                                match state.Failure with
                                | Some earlier -> Some earlier
                                | None -> Some error
                            { state with Store = nextStore; Delivered = nextDelivered; Failure = failure }
            let completed = outcomes |> List.fold step initial
            { Store = completed.Store; Delivered = completed.Delivered; Failure = completed.Failure }: EmailBatchResult

"@
$businessSource = $businessSource.Replace($customerMarker, $functionSource + $customerMarker)
[IO.File]::WriteAllText($businessPath, $businessSource, [Text.UTF8Encoding]::new($false))

[pscustomobject]@{
    Mode = $Mode
    Project = $Destination
    BusinessFile = $businessPath
    UsesExistingSingleStep = $true
    PublicAdapter = 'EmailOutbox.deliverBatch'
}

#!/usr/bin/env python3
"""Pure host-side acceptance model for the six frozen email batch cases."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CASES_PATH = ROOT / "cases.json"
EXPECTED_PATH = ROOT / "expected.json"
HASHES_PATH = ROOT / "input-hashes.json"
FIELDS = ("customers", "products", "subscriptions", "invoices", "payments", "emailOutbox", "sentEmails")
CASE_IDS = (
    "three-successes-fifo",
    "failure-on-first-retains-head",
    "partial-progress-stops-at-failure",
    "outcomes-end-before-queue",
    "queue-ends-before-outcomes",
    "empty-queue-and-outcomes",
)


def load_cases() -> dict[str, Any]:
    with CASES_PATH.open("r", encoding="utf-8") as source:
        return json.load(source)


def derive(case: dict[str, Any]) -> dict[str, Any]:
    """Derive the expected prefix transition without calling language code."""
    expected_store = copy.deepcopy(case["store"])
    queue = case["store"]["emailOutbox"]
    sent = copy.deepcopy(case["store"]["sentEmails"])
    delivered = 0
    failure = None
    for outcome in case["outcomes"]:
        if delivered >= len(queue):
            break
        if "error" in outcome:
            failure = {"code": "EMAIL_PROVIDER_FAILURE", "detail": outcome["error"]}
            break
        delivered += 1

    expected_store["emailOutbox"] = copy.deepcopy(queue[delivered:])
    expected_store["sentEmails"] = sent + copy.deepcopy(queue[:delivered])
    return {"store": expected_store, "delivered": delivered, "failure": failure}


def validate_inputs(document: dict[str, Any]) -> None:
    if document.get("schemaVersion") != 1:
        raise ValueError("cases schemaVersion must be 1")
    if document.get("projectionFields") != list(FIELDS):
        raise ValueError("projectionFields must name every Store collection in source order")
    cases = document.get("cases")
    if not isinstance(cases, list) or tuple(case.get("id") for case in cases) != CASE_IDS:
        raise ValueError("case IDs or order differ from the frozen six-case matrix")
    for case in cases:
        store = case.get("store")
        if not isinstance(store, dict) or tuple(store) != FIELDS:
            raise ValueError(f"{case['id']}: Store projection must contain all seven ordered collections")
        for field in FIELDS[:5]:
            if len(store[field]) != 1:
                raise ValueError(f"{case['id']}: expected one non-email sentinel in {field}")
        if len(store["sentEmails"]) != 2:
            raise ValueError(f"{case['id']}: expected two preexisting sent-message sentinels")
        for message in store["emailOutbox"] + store["sentEmails"]:
            if set(message) != {"to", "subject", "body"}:
                raise ValueError(f"{case['id']}: email projection must include recipient, subject, and body")
        for outcome in case["outcomes"]:
            if (set(outcome) not in ({"ok"}, {"error"}) or
                    ("ok" in outcome and outcome["ok"] is not True) or
                    ("error" in outcome and not isinstance(outcome["error"], str))):
                raise ValueError(f"{case['id']}: outcomes must be explicit success or provider-detail failure")
    if [len(c["store"]["emailOutbox"]) for c in cases] != [3, 2, 3, 3, 2, 0]:
        raise ValueError("queue lengths no longer distinguish all six acceptance cases")
    if [len(c["outcomes"]) for c in cases] != [3, 2, 3, 2, 3, 0]:
        raise ValueError("outcome lengths no longer distinguish all six acceptance cases")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def freeze() -> None:
    document = load_cases()
    validate_inputs(document)
    expected = {
        "schemaVersion": 1,
        "derivation": "left-to-right successes until queue/outcome exhaustion or first provider error",
        "cases": [{"id": case["id"], **derive(case)} for case in document["cases"]],
    }
    EXPECTED_PATH.write_text(json.dumps(expected, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    repository_root = ROOT.parents[2]
    local_inputs = [
        CASES_PATH,
        Path(__file__),
        ROOT / "README.md",
        ROOT / "Score-EmailBatchFlow.ps1",
        ROOT / "EmailBatchFlowScorerSource.ps1",
        ROOT / "calibration-notes.md",
        ROOT / "calibration-summary.json",
        ROOT / "EmailBatchFlowControlSource.ps1",
        ROOT / "Audit-EmailBatchFlowSource.ps1",
        ROOT / "Program.fs",
        ROOT / "CandidateAdapter.fs",
        ROOT / "EmailBatchScorer.fsproj",
        ROOT / "Score-EmailBatchFSharp.ps1",
        ROOT / "Prepare-EmailBatchFlowControl.ps1",
        ROOT / "Prepare-EmailBatchFSharpControl.ps1",
    ]
    inspected_sources = [
        repository_root / ".agentlang/next-efficacy-175/plan.md",
        repository_root / ".agentlang/next-efficacy-175/coordinator/task-draft.md",
        repository_root / "docs/CURRENT-SYNTAX.md",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/flow-retained/project/fixtures/business-payments-email.agent",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/flow-retained/project/dictionary.agent",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/fsharp/project/business/Business.fs",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/fsharp/project/tests/Program.fs",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/scoring/flow/Score-Maintenance141Flow.ps1",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/scoring/fsharp/Program.fs",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/scoring/fsharp/AgentLang.Maintenance141.FSharpScorer.fsproj",
        repository_root / "experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/scoring/fsharp/Invoke-Maintenance141FSharpScore.ps1",
    ]
    prepared_fsharp_seed = repository_root / ".agentlang/next-efficacy-175/seed-preparation/fsharp/project"
    prepared_fsharp_sources = sorted(
        path for path in prepared_fsharp_seed.rglob("*")
        if path.is_file() and not {".git", "bin", "obj"}.intersection(path.relative_to(prepared_fsharp_seed).parts)
    )
    prepared_flow_seed = repository_root / ".agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/flow/project"
    prepared_flow_sources = sorted(
        path for path in prepared_flow_seed.rglob("*")
        if path.is_file() and not {".git", "bin", "obj"}.intersection(path.relative_to(prepared_flow_seed).parts)
    )
    flow_control_sources = [
        repository_root / ".agentlang/next-efficacy-175/oracle/controls/flow" / control / "dictionary.agent"
        for control in (
            "correct-tests1",
            "drop-failed-final1",
            "continue-after-failure-final1",
            "rollback-prefix-final1",
            "reverse-sent-final2",
        )
    ]
    fsharp_control_sources = [
        repository_root / ".agentlang/next-efficacy-175/oracle/controls/fsharp" / control / "business/Business.fs"
        for control in ("correct", "drop-failed", "continue-after-failure", "rollback-prefix", "reverse-sent")
    ]
    flow_seed_report = repository_root / ".agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/seed-report.json"
    pinned_flow_cli = repository_root / ".agentlang/next-efficacy-173/pinned-runtime/pr171/AgentLang.Cli.dll"
    input_paths = (
        local_inputs + inspected_sources + prepared_fsharp_sources + prepared_flow_sources +
        flow_control_sources + fsharp_control_sources + [flow_seed_report, pinned_flow_cli]
    )
    missing_inputs = [path for path in input_paths if not path.is_file()]
    if missing_inputs:
        raise FileNotFoundError("required hash inputs are missing: " + ", ".join(str(path) for path in missing_inputs))
    hashes = {
        "schemaVersion": 1,
        "inputs": [
            {
                "path": str(path.relative_to(repository_root)).replace("\\", "/"),
                "sha256": sha256(path),
            }
            for path in input_paths
        ],
    }
    HASHES_PATH.write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"validated {len(document['cases'])} frozen inputs; wrote expected states and {len(hashes['inputs'])} exact source hashes")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true", help="validate cases and write derived expected states and input hashes")
    args = parser.parse_args()
    if args.freeze:
        freeze()
        return 0
    document = load_cases()
    validate_inputs(document)
    print(json.dumps([{"id": case["id"], **derive(case)} for case in document["cases"]], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

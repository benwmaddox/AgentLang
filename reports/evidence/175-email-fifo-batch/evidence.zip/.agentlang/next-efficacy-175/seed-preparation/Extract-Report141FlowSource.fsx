open System
open System.IO
open System.Text.RegularExpressions
open System.Text.Json
open AgentLang

type Declaration =
    { path: string
      syntaxVersion: int
      kind: string
      owner: string
      name: string
      source: string }

let requestPath = Environment.GetEnvironmentVariable("AGENTLANG_FLOW_SOURCE_REQUEST")
if String.IsNullOrWhiteSpace requestPath then
    failwith "Set AGENTLANG_FLOW_SOURCE_REQUEST."

let requestJson = JsonDocument.Parse(File.ReadAllText requestPath)
let inputs =
    requestJson.RootElement.GetProperty("inputs").EnumerateArray()
    |> Seq.map (fun item ->
        item.GetProperty("path").GetString(),
        item.GetProperty("syntaxVersion").GetInt32(),
        item.GetProperty("splitFrontendMarkers").GetBoolean())
    |> Seq.toArray

let declarations = ResizeArray<Declaration>()
let addDocument path syntaxVersion source =
    let document =
        FlowParser.parseDocumentWithVersion syntaxVersion path source
        |> Result.defaultWith (fun diagnostic -> failwith (Diagnostics.render diagnostic))
    for item in document.Records do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "type"
              owner = item.Name
              name = item.Name
              source = item.SourceText })
    for item in document.Scalars do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "type"
              owner = item.Name
              name = item.Name
              source = item.SourceText })
    for item in document.Enums do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "type"
              owner = item.Name
              name = item.Name
              source = item.SourceText })
    for item in document.Words do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "word"
              owner = item.Name
              name = item.Name
              source = item.SourceText })
    for item in document.Tests do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "test"
              owner = item.Word
              name = item.CaseName
              source = item.SourceText })
    for item in document.Examples do
        declarations.Add(
            { path = path
              syntaxVersion = syntaxVersion
              kind = "example"
              owner = item.Word
              name = item.CaseName
              source = item.SourceText })

for path, syntaxVersion, splitFrontendMarkers in inputs do
    let source = File.ReadAllText path
    if splitFrontendMarkers then
        let markers = Regex.Matches(source, "(?m)^// frontend: flow/([0-9]+)[ \\t]*$")
        if markers.Count = 0 || markers[0].Index <> 0 then
            failwithf "Expected source-format marker at the beginning of %s." path
        for index = 0 to markers.Count - 1 do
            let marker = markers[index]
            let finish = if index + 1 < markers.Count then markers[index + 1].Index else source.Length
            let syntaxVersion = Int32.Parse(marker.Groups[1].Value)
            addDocument path syntaxVersion (source.Substring(marker.Index, finish - marker.Index))
    else
        addDocument path syntaxVersion source

Console.Out.WriteLine(JsonSerializer.Serialize(declarations.ToArray()))

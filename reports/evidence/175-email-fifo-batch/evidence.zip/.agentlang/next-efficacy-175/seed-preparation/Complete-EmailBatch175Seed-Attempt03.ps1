#requires -Version 7.0
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$seedRoot = $PSScriptRoot
$attemptRoot = Join-Path $seedRoot 'attempt-03-completion'
$partialProject = Join-Path $seedRoot 'attempt-02/flow/project'
$flowProject = Join-Path $attemptRoot 'flow/project'
$protocolRoot = Join-Path $attemptRoot 'protocol'
$tempRoot = Join-Path $attemptRoot 'workspace-temp'
$sourceProject = Join-Path $repoRoot 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/flow-retained/project'
$cliPath = Join-Path $repoRoot '.agentlang/next-efficacy-173/pinned-runtime/pr171/AgentLang.Cli.dll'
$expectedCliSha256 = '27fd71d7d7c78a02903c56e82824cd1732d60dd9c883a6ce1eb9b9b41af0ec42'
$expectedInputPath = Join-Path $seedRoot 'attempt-02/baseline-source-inventory.json'
$partialReportPath = Join-Path $seedRoot 'attempt-02/partial-reconstruction-report.json'

if (Test-Path -LiteralPath $attemptRoot) {
    throw "Fresh completion destination already exists: $attemptRoot"
}
if (-not (Test-Path -LiteralPath $partialProject -PathType Container)) {
    throw "Missing report-141 partial project: $partialProject"
}
if ((Get-FileHash -LiteralPath $cliPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $expectedCliSha256) {
    throw 'Pinned AgentLang CLI hash differs from the task-pinned runtime.'
}

[void][IO.Directory]::CreateDirectory($attemptRoot)
[void][IO.Directory]::CreateDirectory($flowProject)
[void][IO.Directory]::CreateDirectory($protocolRoot)
[void][IO.Directory]::CreateDirectory($tempRoot)
$env:TEMP = $tempRoot
$env:TMP = $tempRoot

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-TextSha256([string]$Text) {
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Text)
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
}

function Write-Json([string]$Path, [object]$Value) {
    [IO.File]::WriteAllText($Path, (ConvertTo-Json -InputObject $Value -Depth 100), [Text.UTF8Encoding]::new($false))
}

function Get-Inventory([string]$Root) {
    @(
        Get-ChildItem -LiteralPath $Root -File -Recurse -Force |
            ForEach-Object {
                [ordered]@{
                    path = [IO.Path]::GetRelativePath($Root, $_.FullName).Replace('\', '/')
                    bytes = $_.Length
                    sha256 = Get-Sha256 $_.FullName
                }
            } |
            Sort-Object path
    )
}

function Copy-ProjectTree([string]$Source, [string]$Destination) {
    foreach ($item in Get-ChildItem -LiteralPath $Source -File -Recurse -Force) {
        $relative = [IO.Path]::GetRelativePath($Source, $item.FullName)
        $target = Join-Path $Destination $relative
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        [IO.File]::Copy($item.FullName, $target, $false)
    }
}

function Read-ObjectSource([string]$Project, [string]$ObjectHash) {
    $path = Join-Path (Join-Path $Project '.agentlang/store/objects') ($ObjectHash + '.agent')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing content-addressed source object '$ObjectHash' in '$Project'."
    }
    if ((Get-Sha256 $path) -cne $ObjectHash) {
        throw "Source object '$ObjectHash' failed its content-address check."
    }
    return [IO.File]::ReadAllText($path)
}

function Get-AttachmentName([string]$Kind, [string]$Source) {
    $keyword = if ($Kind -ceq 'test') { 'test' } elseif ($Kind -ceq 'example') { 'example' } else { throw "Unsupported attachment kind '$Kind'." }
    if ($Source -cnotmatch "\A[ \t]*$keyword\s+([A-Za-z0-9_./?!-]+)\s*\{") {
        throw "Could not read the authored $Kind name from its stored source body."
    }
    return [string]$Matches[1]
}

function Get-Revision([object]$Manifest, [string]$WordId, [int]$Revision) {
    $matches = @($Manifest.revisions | Where-Object { $_.wordId -ceq $WordId -and $_.revision -eq $Revision })
    if ($matches.Count -ne 1) { throw "Expected one revision for word '$WordId' revision $Revision; found $($matches.Count)." }
    return $matches[0]
}

function Get-BodyKey([object]$Entry) {
    $maturity = if ($null -eq $Entry.maturity) { '' } else { [string]$Entry.maturity }
    return "$($Entry.kind)|$($Entry.name)|$($Entry.sourceSha256)|$($Entry.sourceFormat)|$maturity"
}

function New-AgentSession([string]$Name, [string]$Project) {
    $sessionDirectory = Join-Path $protocolRoot $Name
    [void][IO.Directory]::CreateDirectory($sessionDirectory)
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = 'dotnet'
    $start.WorkingDirectory = $Project
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($argument in @($cliPath, '--project', $Project, '--filesystem', 'virtual', '--jsonl')) {
        [void]$start.ArgumentList.Add([string]$argument)
    }
    $start.Environment['TEMP'] = $tempRoot
    $start.Environment['TMP'] = $tempRoot
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    $startedUtc = [DateTimeOffset]::UtcNow
    $context = @{
        name = $Name
        project = $Project
        directory = $sessionDirectory
        process = $process
        processStarted = $false
        stderrTask = $null
        requests = [Collections.Generic.List[string]]::new()
        responses = [Collections.Generic.List[string]]::new()
        terminalStatus = 'starting'
        failure = $null
        startedUtc = $startedUtc
        stopped = $false
        exitCode = $null
    }
    if (-not $process.Start()) { throw "Pinned CLI did not start for session '$Name'." }
    $context.processStarted = $true
    $context.terminalStatus = 'running'
    $context.stderrTask = $process.StandardError.ReadToEndAsync()
    return $context
}

function Send-AgentRequest([hashtable]$Context, [object]$Request) {
    $line = ConvertTo-Json -InputObject $Request -Depth 100 -Compress
    $Context.requests.Add($line)
    [IO.File]::WriteAllLines((Join-Path $Context.directory 'requests.jsonl'), $Context.requests, [Text.UTF8Encoding]::new($false))
    $Context.process.StandardInput.WriteLine($line)
    $Context.process.StandardInput.Flush()
    $readTask = $Context.process.StandardOutput.ReadLineAsync()
    if (-not $readTask.Wait(120000)) {
        $Context.terminalStatus = 'timed-out'
        $Context.failure = "Pinned CLI timed out on request '$($Request.op)'; the process will not be restarted."
        throw $Context.failure
    }
    $responseLine = $readTask.Result
    if ([string]::IsNullOrWhiteSpace($responseLine)) {
        $Context.terminalStatus = 'closed-before-response'
        $Context.failure = "Pinned CLI ended before replying to request '$($Request.op)'."
        throw $Context.failure
    }
    $Context.responses.Add($responseLine)
    [IO.File]::WriteAllLines((Join-Path $Context.directory 'responses.jsonl'), $Context.responses, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllLines((Join-Path $Context.directory 'stdout.txt'), $Context.responses, [Text.UTF8Encoding]::new($false))
    $response = ConvertFrom-Json -InputObject $responseLine -Depth 100
    if ($response.ok -ne $true) {
        $Context.terminalStatus = 'request-failed'
        $Context.failure = "Request '$($Request.op)' failed: $responseLine"
        throw $Context.failure
    }
    return $response
}

function Stop-AgentSession([hashtable]$Context) {
    if ($Context.stopped) { return [int]$Context.exitCode }
    try { $Context.process.StandardInput.Close() } catch { }
    if ($Context.processStarted -and -not $Context.process.HasExited) {
        if (-not $Context.process.WaitForExit(60000)) {
            try { $Context.process.Kill($true) } catch { }
            $Context.terminalStatus = 'killed-after-close-timeout'
        }
    }
    if ($Context.processStarted -and $Context.process.HasExited) {
        $Context.exitCode = [int]$Context.process.ExitCode
    }
    $stderrText = if ($null -ne $Context.stderrTask) { $Context.stderrTask.GetAwaiter().GetResult() } else { '' }
    [IO.File]::WriteAllText((Join-Path $Context.directory 'stderr.txt'), $stderrText, [Text.UTF8Encoding]::new($false))
    if ($Context.terminalStatus -eq 'running') {
        $Context.terminalStatus = if ($Context.exitCode -eq 0) { 'completed' } else { 'nonzero-exit' }
    }
    Write-Json (Join-Path $Context.directory 'exit.json') ([ordered]@{
        command = 'dotnet <pinned AgentLang.Cli.dll> --project <project> --filesystem virtual --jsonl'
        cliPath = [IO.Path]::GetRelativePath($repoRoot, $cliPath).Replace('\', '/')
        cliSha256 = $expectedCliSha256
        projectPath = [IO.Path]::GetFullPath($Context.project)
        tempPath = [IO.Path]::GetFullPath($tempRoot)
        processStarted = $Context.processStarted
        startedUtc = $Context.startedUtc.ToString('O')
        finishedUtc = [DateTimeOffset]::UtcNow.ToString('O')
        terminalStatus = $Context.terminalStatus
        exitCode = $Context.exitCode
        requestsSent = $Context.requests.Count
        responsesRead = $Context.responses.Count
        failure = $Context.failure
        stdoutPath = 'stdout.txt'
        stderrPath = 'stderr.txt'
    })
    $Context.process.Dispose()
    $Context.stopped = $true
    return [int]$Context.exitCode
}

function Assert-TestResults([object]$Response, [int]$ExpectedCount, [string]$Label) {
    $results = @($Response.data.results)
    $failed = @($results | Where-Object { $_.passed -ne $true })
    if ($results.Count -ne $ExpectedCount -or $failed.Count -gt 0) {
        $names = ($failed | ForEach-Object { "$($_.word)/$($_.name)" }) -join ', '
        throw "$Label expected $ExpectedCount passing tests; actual=$($results.Count); failed=$names"
    }
    return [ordered]@{ expected = $ExpectedCount; actual = $results.Count; passed = $true }
}

$stage = 'preflight'
$defineSent = $false
$activeSessions = [Collections.Generic.List[object]]::new()
$completionSession = $null
$finalSession = $null
$failure = $null

try {
    Copy-ProjectTree $partialProject $flowProject
    $partialInventory = Get-Inventory $partialProject
    $copiedInventory = Get-Inventory $flowProject
    if ((ConvertTo-Json -InputObject $partialInventory -Depth 30 -Compress) -cne (ConvertTo-Json -InputObject $copiedInventory -Depth 30 -Compress)) {
        throw 'The copied attempt-02 partial project differs from its source inventory.'
    }

    $partialCurrent = Get-Content -LiteralPath (Join-Path $partialProject '.agentlang/store/CURRENT') -Raw | ConvertFrom-Json -Depth 20
    $partialManifestPath = Join-Path (Join-Path $partialProject '.agentlang/store/manifests') ($partialCurrent.manifestHash + '.json')
    $partialManifest = Get-Content -LiteralPath $partialManifestPath -Raw | ConvertFrom-Json -Depth 100
    $partialReport = Get-Content -LiteralPath $partialReportPath -Raw | ConvertFrom-Json -Depth 100
    if (@($partialManifest.words).Count -ne 61 -or [int]$partialCurrent.generation -ne 2) {
        throw 'The copied partial source is not the expected 61-word, generation-2 completion point.'
    }
    if ([string]$partialReport.current.manifestHash -cne [string]$partialCurrent.manifestHash -or [int]$partialReport.current.wordCount -ne 61) {
        throw 'The preserved attempt-02 report does not match the partial project being completed.'
    }

    $sourceCurrent = Get-Content -LiteralPath (Join-Path $sourceProject '.agentlang/store/CURRENT') -Raw | ConvertFrom-Json -Depth 20
    $sourceManifestPath = Join-Path (Join-Path $sourceProject '.agentlang/store/manifests') ($sourceCurrent.manifestHash + '.json')
    $sourceManifest = Get-Content -LiteralPath $sourceManifestPath -Raw | ConvertFrom-Json -Depth 100
    $expectedInput = Get-Content -LiteralPath $expectedInputPath -Raw | ConvertFrom-Json -Depth 100
    if ($expectedInput.sourceProjectManifestHash -cne $sourceCurrent.manifestHash) {
        throw 'Frozen report-141 source manifest differs from the source inventory record.'
    }
    if ($expectedInput.cliSha256 -cne $expectedCliSha256) {
        throw 'The frozen source inventory records a different pinned CLI hash.'
    }
    $expectedBodies = @($expectedInput.expectedSourceBodies)
    foreach ($pair in @(@('word', 62), @('type', 37), @('test', 191), @('example', 44))) {
        $actual = @($expectedBodies | Where-Object kind -CEQ $pair[0]).Count
        if ($actual -ne [int]$pair[1]) { throw "Original report-141 $($pair[0]) body count differs: expected $($pair[1]), actual $actual." }
    }
    foreach ($entry in $expectedBodies) {
        $objectSource = Read-ObjectSource $sourceProject ([string]$entry.sourceSha256)
        if ((Get-TextSha256 $objectSource) -cne [string]$entry.sourceSha256) {
            throw "Original report-141 $($entry.kind) '$($entry.name)' text hash differs from its content address."
        }
        if ($entry.kind -in @('test', 'example') -and (Get-AttachmentName ([string]$entry.kind) $objectSource) -cne [string]$entry.name) {
            throw "Original report-141 $($entry.kind) name differs for '$($entry.name)'."
        }
    }

    $maintenanceWord = @($sourceManifest.words | Where-Object currentName -CEQ 'maintenance141.fixture-import-payment')
    if ($maintenanceWord.Count -ne 1) { throw 'The original report-141 manifest does not contain exactly one Maintenance141 word.' }
    $maintenanceRevision = Get-Revision $sourceManifest ([string]$maintenanceWord[0].wordId) ([int]$maintenanceWord[0].currentRevision)
    if ($maintenanceRevision.maturity -cne 'project' -or $maintenanceRevision.sourceFormat.frontend -cne 'flow' -or [int]$maintenanceRevision.sourceFormat.version -ne 2) {
        throw 'The original Maintenance141 word does not have its report-141 project/Flow-2 metadata.'
    }
    if (@($maintenanceRevision.tests).Count -ne 1 -or @($maintenanceRevision.examples).Count -ne 0) {
        throw 'The original Maintenance141 word must retain its one test and no examples.'
    }
    $maintenanceSource = Read-ObjectSource $sourceProject ([string]$maintenanceRevision.definition.hash)
    $maintenanceTestHash = [string]$maintenanceRevision.tests[0].hash
    $maintenanceTest = Read-ObjectSource $sourceProject $maintenanceTestHash
    $maintenanceTestName = Get-AttachmentName test $maintenanceTest
    if (-not $maintenanceTestName.StartsWith('maintenance141.fixture-import-payment/', [StringComparison]::Ordinal)) {
        throw "The original Maintenance141 test '$maintenanceTestName' has the wrong owner."
    }
    $maintenanceDefinitionHash = [string]$maintenanceRevision.definition.hash
    $maintenanceExpectedBody = @($expectedBodies | Where-Object { $_.kind -ceq 'word' -and $_.name -ceq 'maintenance141.fixture-import-payment' })
    $maintenanceExpectedTest = @($expectedBodies | Where-Object { $_.kind -ceq 'test' -and $_.name -ceq $maintenanceTestName })
    if ($maintenanceExpectedBody.Count -ne 1 -or $maintenanceExpectedBody[0].sourceSha256 -cne $maintenanceDefinitionHash -or
        $maintenanceExpectedTest.Count -ne 1 -or $maintenanceExpectedTest[0].sourceSha256 -cne $maintenanceTestHash) {
        throw 'The Maintenance141 source/test bodies do not match the frozen full report-141 inventory.'
    }

    $partialPersistentWords = @($partialManifest.words)
    $partialTests = 0
    $partialExamples = 0
    foreach ($word in $partialPersistentWords) {
        $revision = Get-Revision $partialManifest ([string]$word.wordId) ([int]$word.currentRevision)
        $partialTests += @($revision.tests).Count
        $partialExamples += @($revision.examples).Count
    }
    if ($partialTests -ne 190 -or $partialExamples -ne 44) {
        throw "The partial report-141 manifest must have 190 tests and 44 examples; found $partialTests/$partialExamples."
    }

    $stage = 'fresh-load-baseline'
    $completionSession = New-AgentSession 'complete-maintenance' $flowProject
    $activeSessions.Add($completionSession)
    $initialWordsResponse = Send-AgentRequest $completionSession ([ordered]@{op='words'})
    $initialWordRows = @($initialWordsResponse.data.words | Where-Object status -CEQ 'persistent')
    if ($initialWordRows.Count -ne 61 -or @($initialWordRows | Where-Object maturity -CEQ 'library').Count -ne 59 -or @($initialWordRows | Where-Object maturity -CEQ 'project').Count -ne 2) {
        throw 'Fresh load did not expose the expected 61 persistent words with 59 library / 2 project maturity.'
    }
    if (@($initialWordRows | Where-Object name -CEQ 'maintenance141.fixture-import-payment').Count -ne 0) {
        throw 'Maintenance141 unexpectedly persisted in the partial source before completion.'
    }
    $initialTestSummary = Assert-TestResults (Send-AgentRequest $completionSession ([ordered]@{op='test-all'})) 190 'Fresh-loaded report-141 partial project'

    $stage = 'define-maintenance141'
    $defineSent = $true
    $defineResponse = Send-AgentRequest $completionSession ([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 2
        source = ($maintenanceSource + "`n`n" + $maintenanceTest)
    })
    if ($defineResponse.kind -cne 'defined') { throw 'The original Maintenance141 definition and test did not stage through the public Flow JSONL protocol.' }
    $stagedTestSummary = Assert-TestResults (Send-AgentRequest $completionSession ([ordered]@{op='test-all'})) 191 'Maintenance141 restored report-141 source'
    $stagedWordResponse = Send-AgentRequest $completionSession ([ordered]@{op='words'})
    $stagedMaintenanceRows = @($stagedWordResponse.data.words | Where-Object { $_.name -ceq 'maintenance141.fixture-import-payment' -and $_.status -ceq 'candidate' })
    if ($stagedMaintenanceRows.Count -ne 1) { throw 'Expected exactly one staged Maintenance141 project candidate.' }

    $stage = 'commit-maintenance141-project'
    $commitResponse = Send-AgentRequest $completionSession ([ordered]@{op='commit-word';word='maintenance141.fixture-import-payment';library=$false})
    if ($commitResponse.kind -cne 'commit') { throw 'The original Maintenance141 word did not commit at project maturity.' }
    $committedTestSummary = Assert-TestResults (Send-AgentRequest $completionSession ([ordered]@{op='test-all'})) 191 'Committed report-141 source'
    $committedWordResponse = Send-AgentRequest $completionSession ([ordered]@{op='words'})
    $committedWordRows = @($committedWordResponse.data.words | Where-Object status -CEQ 'persistent')
    if ($committedWordRows.Count -ne 62 -or @($committedWordRows | Where-Object maturity -CEQ 'library').Count -ne 59 -or @($committedWordRows | Where-Object maturity -CEQ 'project').Count -ne 3) {
        throw 'In-process post-commit inventory differs from the expected 62 persistent words and 59/3 maturity.'
    }
    if ((Stop-AgentSession $completionSession) -ne 0) { throw 'The completion JSONL process exited nonzero; see its terminal status.' }

    $stage = 'fresh-final-reload'
    $finalSession = New-AgentSession 'final-reload' $flowProject
    $activeSessions.Add($finalSession)
    $finalWordsResponse = Send-AgentRequest $finalSession ([ordered]@{op='words'})
    $finalWordRows = @($finalWordsResponse.data.words | Where-Object status -CEQ 'persistent')
    if ($finalWordRows.Count -ne 62 -or @($finalWordRows | Where-Object maturity -CEQ 'library').Count -ne 59 -or @($finalWordRows | Where-Object maturity -CEQ 'project').Count -ne 3) {
        throw 'Fresh final reload did not load the complete 62-word 59-library/3-project inventory.'
    }
    $finalTestSummary = Assert-TestResults (Send-AgentRequest $finalSession ([ordered]@{op='test-all'})) 191 'Fresh-process completed report-141 source'

    $sourceQueryChecks = [Collections.Generic.List[object]]::new()
    foreach ($entry in $expectedBodies | Where-Object { $_.kind -in @('word', 'type') }) {
        $selector = if ($entry.kind -ceq 'word') { 'word' } else { 'type' }
        $request = [ordered]@{op='source'}
        $request[$selector] = [string]$entry.name
        $response = Send-AgentRequest $finalSession $request
        if ($response.kind -cne 'source') { throw "Fresh source inspection failed for $($entry.kind) '$($entry.name)'." }
        $body = [string]$response.data
        $bodyHash = Get-TextSha256 $body
        if ($bodyHash -cne [string]$entry.sourceSha256) { throw "Fresh source query hash differs for $($entry.kind) '$($entry.name)'." }
        $sourceQueryChecks.Add([ordered]@{kind=$entry.kind;name=$entry.name;sourceSha256=$bodyHash;preserved=$true})
    }
    if ((Stop-AgentSession $finalSession) -ne 0) { throw 'The final reload JSONL process exited nonzero; see its terminal status.' }

    $freshCurrent = Get-Content -LiteralPath (Join-Path $flowProject '.agentlang/store/CURRENT') -Raw | ConvertFrom-Json -Depth 20
    $freshManifestPath = Join-Path (Join-Path $flowProject '.agentlang/store/manifests') ($freshCurrent.manifestHash + '.json')
    $freshManifest = Get-Content -LiteralPath $freshManifestPath -Raw | ConvertFrom-Json -Depth 100
    if (@($freshManifest.words).Count -ne 62 -or @($freshManifest.types).Count -ne 37) {
        throw 'Fresh manifest count differs from the full report-141 source: expected 62 words and 37 types.'
    }

    $freshWordByName = @{}
    foreach ($word in $freshManifest.words) {
        $revision = Get-Revision $freshManifest ([string]$word.wordId) ([int]$word.currentRevision)
        $freshWordByName[[string]$word.currentName] = $revision
    }
    $sourceWordByName = @{}
    foreach ($word in $sourceManifest.words) {
        $revision = Get-Revision $sourceManifest ([string]$word.wordId) ([int]$word.currentRevision)
        $sourceWordByName[[string]$word.currentName] = [ordered]@{
            id = [string]$word.wordId
            revision = [int]$word.currentRevision
            maturity = [string]$revision.maturity
            sourceFormat = "$($revision.sourceFormat.frontend)/$($revision.sourceFormat.version)"
            definitionHash = [string]$revision.definition.hash
        }
    }
    $bodyChecks = [Collections.Generic.List[object]]::new()
    $actualBodyKeys = [Collections.Generic.List[string]]::new()
    $expectedBodyKeys = [Collections.Generic.List[string]]::new()
    foreach ($entry in $expectedBodies) { $expectedBodyKeys.Add((Get-BodyKey $entry)) }
    foreach ($type in $freshManifest.types) {
        $hash = [string]$type.definition.hash
        $objectSource = Read-ObjectSource $flowProject $hash
        $format = "$($type.sourceFormat.frontend)/$($type.sourceFormat.version)"
        $entry = [ordered]@{kind='type';name=[string]$type.name;sourceSha256=$hash;sourceFormat=$format;maturity=$null}
        $actualBodyKeys.Add((Get-BodyKey $entry))
        $bodyChecks.Add([ordered]@{kind='type';name=$type.name;sourceSha256=$hash;preserved=$true})
    }
    foreach ($word in $freshManifest.words) {
        $revision = $freshWordByName[[string]$word.currentName]
        $sourceMeta = $sourceWordByName[[string]$word.currentName]
        if ($null -eq $sourceMeta) { throw "Fresh manifest contains unexpected word '$($word.currentName)'." }
        $format = "$($revision.sourceFormat.frontend)/$($revision.sourceFormat.version)"
        if ($revision.maturity -cne $sourceMeta.maturity -or $format -cne $sourceMeta.sourceFormat) {
            throw "Maturity or source format changed for '$($word.currentName)'."
        }
        $definitionHash = [string]$revision.definition.hash
        [void](Read-ObjectSource $flowProject $definitionHash)
        $actualBodyKeys.Add((Get-BodyKey ([ordered]@{kind='word';name=[string]$word.currentName;sourceSha256=$definitionHash;sourceFormat=$format;maturity=[string]$revision.maturity})))
        $bodyChecks.Add([ordered]@{kind='word';name=$word.currentName;sourceSha256=$definitionHash;preserved=$true})
        foreach ($reference in $revision.tests) {
            $hash = [string]$reference.hash
            $body = Read-ObjectSource $flowProject $hash
            $name = Get-AttachmentName test $body
            if (-not $name.StartsWith([string]$word.currentName + '/', [StringComparison]::Ordinal)) { throw "Fresh test '$name' is attached to the wrong word." }
            $actualBodyKeys.Add((Get-BodyKey ([ordered]@{kind='test';name=$name;sourceSha256=$hash;sourceFormat=$format;maturity=[string]$revision.maturity})))
            $bodyChecks.Add([ordered]@{kind='test';name=$name;sourceSha256=$hash;preserved=$true})
        }
        foreach ($reference in $revision.examples) {
            $hash = [string]$reference.hash
            $body = Read-ObjectSource $flowProject $hash
            $name = Get-AttachmentName example $body
            if (-not $name.StartsWith([string]$word.currentName + '/', [StringComparison]::Ordinal)) { throw "Fresh example '$name' is attached to the wrong word." }
            $actualBodyKeys.Add((Get-BodyKey ([ordered]@{kind='example';name=$name;sourceSha256=$hash;sourceFormat=$format;maturity=[string]$revision.maturity})))
            $bodyChecks.Add([ordered]@{kind='example';name=$name;sourceSha256=$hash;preserved=$true})
        }
    }
    foreach ($type in $freshManifest.types) {
        $typeName = [string]$type.name
        $originalType = @($sourceManifest.types | Where-Object name -CEQ $typeName)
        if ($originalType.Count -ne 1) { throw "Fresh manifest contains unexpected type '$typeName'." }
        $originalHash = [string]$originalType[0].definition.hash
        if ([string]$type.definition.hash -cne $originalHash) { throw "Definition hash changed for type '$typeName'." }
        if ("$($type.sourceFormat.frontend)/$($type.sourceFormat.version)" -cne "$($originalType[0].sourceFormat.frontend)/$($originalType[0].sourceFormat.version)") {
            throw "Source format changed for type '$typeName'."
        }
    }
    foreach ($name in $sourceWordByName.Keys) {
        if (-not $freshWordByName.ContainsKey($name)) { throw "Fresh manifest is missing report-141 word '$name'." }
        $actualRevision = $freshWordByName[$name]
        $original = $sourceWordByName[$name]
        if ([string]$actualRevision.definition.hash -cne $original.definitionHash) { throw "Definition hash changed for word '$name'." }
        $actualTestHashes = @($actualRevision.tests | ForEach-Object { [string]$_.hash } | Sort-Object -CaseSensitive)
        $originalRow = @($sourceManifest.words | Where-Object currentName -CEQ $name)[0]
        $originalRevision = Get-Revision $sourceManifest ([string]$originalRow.wordId) ([int]$originalRow.currentRevision)
        $expectedTestHashes = @($originalRevision.tests | ForEach-Object { [string]$_.hash } | Sort-Object -CaseSensitive)
        $actualExampleHashes = @($actualRevision.examples | ForEach-Object { [string]$_.hash } | Sort-Object -CaseSensitive)
        $expectedExampleHashes = @($originalRevision.examples | ForEach-Object { [string]$_.hash } | Sort-Object -CaseSensitive)
        if (($actualTestHashes -join "`n") -cne ($expectedTestHashes -join "`n")) { throw "Attached test hashes changed for word '$name'." }
        if (($actualExampleHashes -join "`n") -cne ($expectedExampleHashes -join "`n")) { throw "Attached example hashes changed for word '$name'." }
    }
    $actualBodySorted = @($actualBodyKeys | Sort-Object -CaseSensitive)
    $expectedBodySorted = @($expectedBodyKeys | Sort-Object -CaseSensitive)
    if (($actualBodySorted -join "`n") -cne ($expectedBodySorted -join "`n")) {
        throw "Fresh manifest source/test/example inventory differs from the original report-141 bodies. expected=$($expectedBodySorted.Count), actual=$($actualBodySorted.Count)."
    }
    if ($actualBodySorted.Count -ne 334 -or @($bodyChecks | Where-Object kind -CEQ 'test').Count -ne 191 -or @($bodyChecks | Where-Object kind -CEQ 'example').Count -ne 44) {
        throw 'Fresh source object inventory did not preserve 62 words, 37 types, 191 tests, and 44 examples.'
    }
    foreach ($word in $finalWordRows) {
        $manifestRow = @($freshManifest.words | Where-Object currentName -CEQ $word.name)
        if ($manifestRow.Count -ne 1 -or [string]$manifestRow[0].wordId -cne [string]$word.id) {
            throw "Fresh runtime word identity differs from its manifest row for '$($word.name)'."
        }
    }
    $finalLineage = [Collections.Generic.List[object]]::new()
    foreach ($word in $freshManifest.words | Sort-Object currentName -CaseSensitive) {
        $revision = $freshWordByName[[string]$word.currentName]
        $finalLineage.Add([ordered]@{name=[string]$word.currentName;id=[string]$word.wordId;revision=[int]$word.currentRevision;maturity=[string]$revision.maturity;sourceFormat="$($revision.sourceFormat.frontend)/$($revision.sourceFormat.version)";definitionHash=[string]$revision.definition.hash})
    }
    $historyRoot = Join-Path $flowProject 'history'
    $historyFiles = @(
        if (Test-Path -LiteralPath $historyRoot) {
            Get-ChildItem -LiteralPath $historyRoot -File -Force | Sort-Object Name | ForEach-Object {
                [ordered]@{path=$_.Name;bytes=$_.Length;sha256=Get-Sha256 $_.FullName}
            }
        }
    )
    $maturityCounts = @($finalWordRows | Group-Object maturity | ForEach-Object { [ordered]@{maturity=$_.Name;count=$_.Count} })
    $fsharpBuild = Get-Content -LiteralPath (Join-Path $seedRoot 'fsharp-build-exit.json') -Raw | ConvertFrom-Json -Depth 20
    $fsharpTest = Get-Content -LiteralPath (Join-Path $seedRoot 'fsharp-selftest-exit.json') -Raw | ConvertFrom-Json -Depth 20
    if ($fsharpBuild.exitCode -ne 0 -or $fsharpTest.exitCode -ne 0) { throw 'The recorded F# report-141 baseline build/self-test did not pass.' }

    $seedReport = [ordered]@{
        schemaVersion = 1
        status = 'completed'
        preparedUtc = [DateTimeOffset]::UtcNow.ToString('O')
        sourceLineage = [ordered]@{
            sourceReport = 'paid-invoice-maintenance-141'
            sourceManifestGeneration = [int]$sourceCurrent.generation
            sourceManifestHash = [string]$sourceCurrent.manifestHash
            sourceExportHash = [string]$sourceManifest.projectSource.hash
            originalDirectCopyLoadFailure = '.agentlang/next-efficacy-175/load-check/stderr.txt: STORAGE_PROJECT_MISMATCH'
            pinnedRuntime = [ordered]@{path=[IO.Path]::GetRelativePath($repoRoot,$cliPath).Replace('\','/');sha256=$expectedCliSha256}
            replayMethod = 'copied durable attempt-02 partial project; ordinary JSONL load/test-all, exact source-object define, test-all, project commit-word; no manifest/export editing'
            maintenance141DefinitionHash = $maintenanceDefinitionHash
            maintenance141TestHash = $maintenanceTestHash
            maintenance141TestName = $maintenanceTestName
            absentDictionaryOnlyAdditions = @()
        }
        counts = [ordered]@{words=62;types=37;tests=191;examples=44;libraryWords=59;projectWords=3}
        baselineReload = [ordered]@{words=61;libraryWords=59;projectWords=2;tests=$initialTestSummary}
        completion = [ordered]@{definitionStaged=$true;originalMaintenanceTestStaged=$true;stagedTests=$stagedTestSummary;projectCommitSucceeded=$true;committedTests=$committedTestSummary}
        freshReload = [ordered]@{persistentWords=$finalWordRows.Count;libraryWords=59;projectWords=3;tests=$finalTestSummary;sourceQueryChecks=@($sourceQueryChecks)}
        bodyChecks = @($bodyChecks)
        maturityCounts = $maturityCounts
        lineage = @($finalLineage)
        manifest = [ordered]@{generation=[int]$freshCurrent.generation;hash=[string]$freshCurrent.manifestHash;formatVersion=[int]$freshManifest.formatVersion;historyFiles=$historyFiles}
        flowProjectInventory = Get-Inventory $flowProject
        fsharp = [ordered]@{projectRelativePath='.agentlang/next-efficacy-175/seed-preparation/fsharp/project';sourceInventoryPath='.agentlang/next-efficacy-175/seed-preparation/fsharp-source-copy-verification.json';buildStatus=$fsharpBuild.terminalStatus;buildExitCode=$fsharpBuild.exitCode;selfTestStatus=$fsharpTest.terminalStatus;selfTestOutputPath='.agentlang/next-efficacy-175/seed-preparation/fsharp-selftest-stdout.txt';selfTestSummary='18 groups, 157 assertions'}
        attempts = @(
            [ordered]@{attempt=1;result='failed-discard-order';statusPath='.agentlang/next-efficacy-175/seed-preparation/preparation-exit.json';detail='Maintenance141 was not staged before the first attempt tried to discard it.'},
            [ordered]@{attempt=2;result='partial-commit-order';statusPath='.agentlang/next-efficacy-175/seed-preparation/attempt-02/preparation-exit.json';detail='Committing email.apply-delivery-result also persisted its project-only helper.'},
            [ordered]@{attempt=3;result='completed';statusPath='.agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-exit.json';detail='Restored only the original Maintenance141 definition and its one original test.'}
        )
        launcherPreflightFailure = '.agentlang/next-efficacy-175/seed-preparation/attempt-03/preparation-exit.json records a wrapper-created non-fresh destination; no CLI process started and no project files were copied or changed.'
    }
    Write-Json (Join-Path $attemptRoot 'seed-report.json') $seedReport
}
catch {
    $failure = $_.Exception.Message
    Write-Json (Join-Path $attemptRoot 'completion-failure.json') ([ordered]@{
        stage = $stage
        error = $failure
        defineSent = $defineSent
        finishedUtc = [DateTimeOffset]::UtcNow.ToString('O')
    })
}
finally {
    foreach ($session in $activeSessions) {
        if (-not $session.stopped) {
            try { [void](Stop-AgentSession $session) } catch { }
        }
    }
}

if ($null -ne $failure) { throw "Attempt-03 seed completion failed during '$stage': $failure" }
Write-Output (Join-Path $attemptRoot 'seed-report.json')

#requires -Version 7.0
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$seedRoot = $PSScriptRoot
$flowProject = Join-Path $seedRoot 'flow/project'
$fsharpProject = Join-Path $seedRoot 'fsharp/project'
$protocolRoot = Join-Path $seedRoot 'protocol'
$tempRoot = Join-Path $seedRoot 'workspace-temp'
$sourceRoot = Join-Path $repoRoot 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts'
$flowSourceProject = Join-Path $sourceRoot 'flow-retained/project'
$fsharpSourceProject = Join-Path $sourceRoot 'fsharp/project'
$cliPath = Join-Path $repoRoot '.agentlang/next-efficacy-173/pinned-runtime/pr171/AgentLang.Cli.dll'
$expectedCliSha256 = '27fd71d7d7c78a02903c56e82824cd1732d60dd9c883a6ce1eb9b9b41af0ec42'
$baselineExtractPath = Join-Path $seedRoot 'extract-attempt-02-stdout.json'

if ((Test-Path -LiteralPath $flowProject) -or (Test-Path -LiteralPath $fsharpProject)) {
    throw 'A seed output already exists. Refusing to replace it or repeat a failed reconstruction.'
}
if (-not (Test-Path -LiteralPath $baselineExtractPath -PathType Leaf)) {
    throw "Missing successful source extraction output: $baselineExtractPath"
}
if ((Get-FileHash -LiteralPath $cliPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $expectedCliSha256) {
    throw 'Pinned AgentLang CLI hash differs from the task-pinned runtime.'
}

[void][IO.Directory]::CreateDirectory($flowProject)
[void][IO.Directory]::CreateDirectory($fsharpProject)
[void][IO.Directory]::CreateDirectory($protocolRoot)
[void][IO.Directory]::CreateDirectory($tempRoot)
$env:TEMP = $tempRoot
$env:TMP = $tempRoot

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-TextSha256([string]$Text) {
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Text)
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
}

function Write-Json([string]$Path, [object]$Value) {
    [IO.File]::WriteAllText($Path, (ConvertTo-Json -InputObject $Value -Depth 100), [Text.UTF8Encoding]::new($false))
}

function Read-ObjectSource([string]$ObjectHash) {
    $path = Join-Path (Join-Path $flowSourceProject '.agentlang/store/objects') ($ObjectHash + '.agent')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing baseline source object '$ObjectHash'."
    }
    $source = [IO.File]::ReadAllText($path)
    if ((Get-Sha256 $path) -cne $ObjectHash) {
        throw "Baseline source object '$ObjectHash' failed its content-address check."
    }
    return $source
}

function Copy-SourceTree([string]$Source, [string]$Destination) {
    foreach ($item in Get-ChildItem -LiteralPath $Source -File -Recurse -Force) {
        $relative = [IO.Path]::GetRelativePath($Source, $item.FullName)
        if ($relative -match '(^|[\\/])(bin|obj|\.git)([\\/]|$)') { continue }
        $target = Join-Path $Destination $relative
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        [IO.File]::Copy($item.FullName, $target, $false)
    }
}

function Get-Inventory([string]$Root) {
    @(
        Get-ChildItem -LiteralPath $Root -File -Recurse -Force |
            ForEach-Object {
                [ordered]@{
                    path = [IO.Path]::GetRelativePath($Root, $_.FullName).Replace('\', '/')
                    bytes = $_.Length
                    sha256 = Get-Sha256 $_.FullName
                }
            } |
            Sort-Object path
    )
}

function Invoke-AgentJsonl([string]$Project, [string]$Name, [object[]]$Requests) {
    $sessionDirectory = Join-Path $protocolRoot $Name
    [void][IO.Directory]::CreateDirectory($sessionDirectory)
    $requestPath = Join-Path $sessionDirectory 'requests.jsonl'
    $responsePath = Join-Path $sessionDirectory 'responses.jsonl'
    $stdoutPath = Join-Path $sessionDirectory 'stdout.txt'
    $stderrPath = Join-Path $sessionDirectory 'stderr.txt'
    $statusPath = Join-Path $sessionDirectory 'exit.json'
    $responses = [Collections.Generic.List[object]]::new()
    $requestLines = [Collections.Generic.List[string]]::new()
    $responseLines = [Collections.Generic.List[string]]::new()
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = 'dotnet'
    $start.WorkingDirectory = $Project
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    foreach ($argument in @($cliPath, '--project', $Project, '--filesystem', 'virtual', '--jsonl')) {
        [void]$start.ArgumentList.Add([string]$argument)
    }
    $start.Environment['TEMP'] = $tempRoot
    $start.Environment['TMP'] = $tempRoot
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    $startedUtc = [DateTimeOffset]::UtcNow
    $terminalStatus = 'starting'
    $failure = $null
    $stderrTask = $null
    $processStarted = $false
    try {
        if (-not $process.Start()) { throw 'Pinned CLI did not start.' }
        $processStarted = $true
        $terminalStatus = 'running'
        $stderrTask = $process.StandardError.ReadToEndAsync()
        foreach ($request in $Requests) {
            $line = ConvertTo-Json -InputObject $request -Depth 100 -Compress
            $requestLines.Add($line)
            [IO.File]::WriteAllLines($requestPath, $requestLines, [Text.UTF8Encoding]::new($false))
            $process.StandardInput.WriteLine($line)
            $process.StandardInput.Flush()
            $readTask = $process.StandardOutput.ReadLineAsync()
            if (-not $readTask.Wait(120000)) {
                $terminalStatus = 'timed-out'
                throw "Pinned CLI timed out on request '$($request.op)'; the process will not be restarted."
            }
            $responseLine = $readTask.Result
            if ([string]::IsNullOrWhiteSpace($responseLine)) {
                $terminalStatus = 'closed-before-response'
                throw "Pinned CLI ended before replying to request '$($request.op)'."
            }
            $responseLines.Add($responseLine)
            [IO.File]::WriteAllLines($responsePath, $responseLines, [Text.UTF8Encoding]::new($false))
            [IO.File]::WriteAllLines($stdoutPath, $responseLines, [Text.UTF8Encoding]::new($false))
            $response = ConvertFrom-Json -InputObject $responseLine -Depth 100
            $responses.Add($response)
            if ($response.ok -ne $true) {
                $terminalStatus = 'request-failed'
                $failure = "Request '$($request.op)' failed: $responseLine"
                break
            }
        }
    }
    catch {
        if ($null -eq $failure) { $failure = $_.Exception.Message }
    }
    finally {
        try { $process.StandardInput.Close() } catch { }
        if ($processStarted -and -not $process.HasExited) {
            if (-not $process.WaitForExit(60000)) {
                try { $process.Kill($true) } catch { }
                $terminalStatus = 'killed-after-close-timeout'
            }
        }
        $exitCode = if ($processStarted -and $process.HasExited) { $process.ExitCode } else { $null }
        $stderrText = if ($null -ne $stderrTask) { $stderrTask.GetAwaiter().GetResult() } else { '' }
        [IO.File]::WriteAllText($stderrPath, $stderrText, [Text.UTF8Encoding]::new($false))
        if ($terminalStatus -eq 'running') { $terminalStatus = if ($exitCode -eq 0) { 'completed' } else { 'nonzero-exit' } }
        Write-Json $statusPath ([ordered]@{
            command = 'dotnet <pinned AgentLang.Cli.dll> --project <project> --filesystem virtual --jsonl'
            cliPath = [IO.Path]::GetRelativePath($repoRoot, $cliPath).Replace('\', '/')
            cliSha256 = $expectedCliSha256
            projectPath = [IO.Path]::GetFullPath($Project)
            tempPath = [IO.Path]::GetFullPath($tempRoot)
            processStarted = $processStarted
            startedUtc = $startedUtc.ToString('O')
            finishedUtc = [DateTimeOffset]::UtcNow.ToString('O')
            terminalStatus = $terminalStatus
            exitCode = $exitCode
            requestsSent = $requestLines.Count
            responsesRead = $responseLines.Count
            failure = $failure
            stdoutPath = 'stdout.txt'
            stderrPath = 'stderr.txt'
        })
        $process.Dispose()
    }
    if ($null -ne $failure) { throw $failure }
    if ($null -ne $exitCode -and $exitCode -ne 0) { throw "Pinned CLI exited with code $exitCode. See '$stderrPath'." }
    if ($responses.Count -ne $Requests.Count) {
        throw "Pinned CLI returned $($responses.Count) of $($Requests.Count) responses. See '$statusPath'."
    }
    return ,$responses.ToArray()
}

function Assert-TestResults([object]$Response, [int]$ExpectedCount, [string]$Label) {
    $results = @($Response.data.results)
    $failed = @($results | Where-Object { $_.passed -ne $true })
    if ($results.Count -ne $ExpectedCount -or $failed.Count -gt 0) {
        $names = ($failed | ForEach-Object { "$($_.word)/$($_.name)" }) -join ', '
        throw "$Label expected $ExpectedCount passing tests; actual=$($results.Count); failed=$names"
    }
    return [ordered]@{ expected = $ExpectedCount; actual = $results.Count; passed = $true }
}

function Get-Revision([object]$Manifest, [string]$WordId, [int]$Revision) {
    $matches = @($Manifest.revisions | Where-Object { $_.wordId -ceq $WordId -and $_.revision -eq $Revision })
    if ($matches.Count -ne 1) { throw "Expected one current revision for '$WordId' revision $Revision; found $($matches.Count)." }
    return $matches[0]
}

function Get-ObjectHash([string]$Kind, [string]$Source) {
    $hash = Get-TextSha256 $Source
    if ($hash -notmatch '^[0-9a-f]{64}$') { throw "Could not calculate source hash for $Kind." }
    return $hash
}

function Get-AttachmentName([string]$Kind, [string]$Source) {
    $keyword = if ($Kind -ceq 'test') { 'test' } elseif ($Kind -ceq 'example') { 'example' } else { throw "Unsupported attachment kind '$Kind'." }
    if ($Source -cnotmatch "\A[ \t]*$keyword\s+([A-Za-z0-9_./?!-]+)\s*\{") {
        throw "Could not read the authored $Kind name from its stored source body."
    }
    return [string]$Matches[1]
}

# Copy the frozen F# seed byte for byte and retain its complete source inventory.
Copy-SourceTree $fsharpSourceProject $fsharpProject
$fsharpSourceInventory = Get-Inventory $fsharpSourceProject
$fsharpCopiedInventory = Get-Inventory $fsharpProject
if ((ConvertTo-Json $fsharpSourceInventory -Depth 20 -Compress) -cne (ConvertTo-Json $fsharpCopiedInventory -Depth 20 -Compress)) {
    throw 'F# seed copy does not match the frozen report-141 source tree.'
}

# This order is the established dependency order in Initialize-LanguageSeed.
$fixtureNames = @(
    'business-values.agent',
    'business-store.agent',
    'business-state.agent',
    'business-subscriptions.agent',
    'business-invoices.agent',
    'business-payments-email.agent'
)
$fixtureSourcePaths = @($fixtureNames | ForEach-Object { Join-Path (Join-Path $flowSourceProject 'fixtures') $_ })
$fixtureInventory = [Collections.Generic.List[object]]::new()
foreach ($source in $fixtureSourcePaths) {
    $destination = Join-Path (Join-Path $flowProject 'fixtures') ([IO.Path]::GetFileName($source))
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination))
    [IO.File]::Copy($source, $destination, $false)
    $sourceHash = Get-Sha256 $source
    $copiedHash = Get-Sha256 $destination
    if ($sourceHash -cne $copiedHash) { throw "Frozen fixture copy differs: $source" }
    $fixtureInventory.Add([ordered]@{
        name = [IO.Path]::GetFileName($source)
        sourcePath = [IO.Path]::GetRelativePath($repoRoot, $source).Replace('\', '/')
        sourceSha256 = $sourceHash
        copiedSha256 = $copiedHash
    })
}

$sourceExtraction = Get-Content -LiteralPath $baselineExtractPath -Raw | ConvertFrom-Json -Depth 50
$fixturePathSet = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($path in $fixtureSourcePaths) { [void]$fixturePathSet.Add([IO.Path]::GetFullPath($path)) }
$fixtureDeclarations = @($sourceExtraction | Where-Object { $fixturePathSet.Contains([IO.Path]::GetFullPath([string]$_.path)) })
$fixtureWords = @($fixtureDeclarations | Where-Object kind -ceq 'word')
$fixtureTypes = @($fixtureDeclarations | Where-Object kind -ceq 'type')
$fixtureTests = @($fixtureDeclarations | Where-Object kind -ceq 'test')
$fixtureExamples = @($fixtureDeclarations | Where-Object kind -ceq 'example')
if ($fixtureWords.Count -ne 53 -or $fixtureTypes.Count -ne 31 -or $fixtureTests.Count -ne 154 -or $fixtureExamples.Count -ne 44) {
    throw "Frozen fixture inventory drifted: words=$($fixtureWords.Count), types=$($fixtureTypes.Count), tests=$($fixtureTests.Count), examples=$($fixtureExamples.Count)."
}
if (@($fixtureDeclarations | Where-Object { $_.syntaxVersion -ne 1 }).Count -gt 0) {
    throw 'The six report-141 fixture files must remain Flow/1 sources.'
}

$currentFile = Join-Path $flowSourceProject '.agentlang/store/CURRENT'
$sourceCurrent = Get-Content -LiteralPath $currentFile -Raw | ConvertFrom-Json -Depth 20
$sourceManifestPath = Join-Path (Join-Path $flowSourceProject '.agentlang/store/manifests') ($sourceCurrent.manifestHash + '.json')
$sourceManifest = Get-Content -LiteralPath $sourceManifestPath -Raw | ConvertFrom-Json -Depth 100
$sourceObjectRoot = Join-Path $flowSourceProject '.agentlang/store/objects'
$fixtureWordNames = @($fixtureWords | ForEach-Object { [string]$_.owner } | Sort-Object -Unique)
$fixtureTypeNames = @($fixtureTypes | ForEach-Object { [string]$_.owner } | Sort-Object -Unique)
$expectedSourceBodies = [Collections.Generic.List[object]]::new()
$expectedWordRows = [Collections.Generic.List[object]]::new()
$wordRevisionByName = @{}
$sourceWordRows = [Collections.Generic.List[object]]::new()
foreach ($word in $sourceManifest.words) {
    $revision = Get-Revision $sourceManifest ([string]$word.wordId) ([int]$word.currentRevision)
    $wordRevisionByName[[string]$word.currentName] = $revision
    $sourceWordRows.Add([pscustomobject]@{
        id = [string]$word.wordId
        name = [string]$word.currentName
        revision = [int]$word.currentRevision
        maturity = [string]$revision.maturity
        frontend = [string]$revision.sourceFormat.frontend
        syntaxVersion = [int]$revision.sourceFormat.version
        definitionHash = [string]$revision.definition.hash
        testHashes = @($revision.tests | ForEach-Object { [string]$_.hash })
        exampleHashes = @($revision.examples | ForEach-Object { [string]$_.hash })
    })
}
$sourceWordByName = @{}
foreach ($word in $sourceWordRows) { $sourceWordByName[$word.name] = $word }
$sourceTypeByName = @{}
foreach ($type in $sourceManifest.types) { $sourceTypeByName[[string]$type.name] = $type }

foreach ($declaration in $fixtureTypes) {
    $name = [string]$declaration.owner
    if (-not $sourceTypeByName.ContainsKey($name)) { throw "Fixture type '$name' is absent from the report-141 manifest." }
    $type = $sourceTypeByName[$name]
    if ($type.sourceFormat.frontend -cne 'flow' -or [int]$type.sourceFormat.version -ne 1) {
        throw "Fixture type '$name' has source metadata inconsistent with Flow/1."
    }
    $baselineSource = Read-ObjectSource ([string]$type.definition.hash)
    if ([string]$declaration.source -cne $baselineSource) { throw "Fixture type '$name' differs from the stored report-141 source body." }
    $expectedSourceBodies.Add([ordered]@{kind='type';name=$name;sourceSha256=Get-ObjectHash type $baselineSource;sourceFormat='flow/1';maturity=$null})
}

$extraTypeNames = @($sourceManifest.types | Where-Object { $fixtureTypeNames -cnotcontains $_.name } | ForEach-Object { [string]$_.name } | Sort-Object -CaseSensitive)
if ($extraTypeNames.Count -ne 6) { throw "Expected six dictionary-only report-141 types; found $($extraTypeNames.Count)." }
$extraTypeSource = [Collections.Generic.List[string]]::new()
foreach ($name in $extraTypeNames) {
    $type = $sourceTypeByName[$name]
    if ($type.sourceFormat.frontend -cne 'flow' -or [int]$type.sourceFormat.version -ne 2) {
        throw "Dictionary-only type '$name' must retain its Flow/2 source metadata."
    }
    $source = Read-ObjectSource ([string]$type.definition.hash)
    $extraTypeSource.Add($source)
    $expectedSourceBodies.Add([ordered]@{kind='type';name=$name;sourceSha256=Get-ObjectHash type $source;sourceFormat='flow/2';maturity=$null})
}

foreach ($declaration in $fixtureWords) {
    $name = [string]$declaration.owner
    if (-not $sourceWordByName.ContainsKey($name)) { throw "Fixture word '$name' is absent from the report-141 manifest." }
    $word = $sourceWordByName[$name]
    if ($word.frontend -cne 'flow' -or $word.syntaxVersion -ne 1) {
        throw "Fixture word '$name' has source metadata inconsistent with Flow/1."
    }
    $baselineSource = Read-ObjectSource $word.definitionHash
    if ([string]$declaration.source -cne $baselineSource) { throw "Fixture word '$name' differs from the stored report-141 source body." }
}

$extraWordNames = @($sourceWordRows | Where-Object { $fixtureWordNames -cnotcontains $_.name } | ForEach-Object { [string]$_.name } | Sort-Object -CaseSensitive)
if ($extraWordNames.Count -ne 9) { throw "Expected nine dictionary-only report-141 words; found $($extraWordNames.Count)." }
$projectWordNames = @($sourceWordRows | Where-Object maturity -ceq 'project' | ForEach-Object { [string]$_.name } | Sort-Object -CaseSensitive)
$libraryWordNames = @($sourceWordRows | Where-Object maturity -ceq 'library' | ForEach-Object { [string]$_.name } | Sort-Object -CaseSensitive)
if (($libraryWordNames.Count -ne 59) -or ($projectWordNames.Count -ne 3)) {
    throw "Report-141 maturity inventory changed: library=$($libraryWordNames.Count), project=$($projectWordNames.Count)."
}
$expectedProjectNames = @('email.apply-delivery-result', 'email.delivery-fold-step', 'maintenance141.fixture-import-payment') | Sort-Object -CaseSensitive
if (($projectWordNames -join "`n") -cne ($expectedProjectNames -join "`n")) {
    throw 'The three report-141 project words differ from the frozen maturity inventory.'
}

$extraWordSource = [Collections.Generic.List[string]]::new()
$projectSourceByVersion = @{ 1 = [Collections.Generic.List[string]]::new(); 2 = [Collections.Generic.List[string]]::new() }
foreach ($name in $extraWordNames) {
    $word = $sourceWordByName[$name]
    if ($word.frontend -cne 'flow' -or $word.syntaxVersion -ne 2) {
        throw "Dictionary-only word '$name' must retain its Flow/2 source metadata."
    }
    $source = Read-ObjectSource $word.definitionHash
    $attachments = [Collections.Generic.List[string]]::new()
    foreach ($hash in $word.testHashes) { $attachments.Add((Read-ObjectSource $hash)) }
    foreach ($hash in $word.exampleHashes) { $attachments.Add((Read-ObjectSource $hash)) }
    $wordBlock = @($source) + @($attachments.ToArray())
    if ($word.maturity -ceq 'library') {
        $extraWordSource.AddRange([string[]]$wordBlock)
    } else {
        $projectSourceByVersion[2].AddRange([string[]]$wordBlock)
    }
    $expectedSourceBodies.Add([ordered]@{kind='word';name=$name;sourceSha256=Get-ObjectHash word $source;sourceFormat='flow/2';maturity=$word.maturity})
    foreach ($hash in $word.testHashes) {
        $body = Read-ObjectSource $hash
        $attachmentName = Get-AttachmentName test $body
        if (-not $attachmentName.StartsWith($name + '/', [StringComparison]::Ordinal)) {
            throw "Stored test '$attachmentName' is attached to the wrong report-141 word '$name'."
        }
        $expectedSourceBodies.Add([ordered]@{kind='test';name=$attachmentName;sourceSha256=$hash;sourceFormat='flow/2';maturity=$word.maturity})
    }
    foreach ($hash in $word.exampleHashes) {
        $body = Read-ObjectSource $hash
        $attachmentName = Get-AttachmentName example $body
        if (-not $attachmentName.StartsWith($name + '/', [StringComparison]::Ordinal)) {
            throw "Stored example '$attachmentName' is attached to the wrong report-141 word '$name'."
        }
        $expectedSourceBodies.Add([ordered]@{kind='example';name=$attachmentName;sourceSha256=$hash;sourceFormat='flow/2';maturity=$word.maturity})
    }
}

# Freeze expectations before any runtime mutation.
foreach ($declaration in $fixtureWords) {
    $name = [string]$declaration.owner
    $word = $sourceWordByName[$name]
    $expectedSourceBodies.Add([ordered]@{kind='word';name=$name;sourceSha256=Get-ObjectHash word ([string]$declaration.source);sourceFormat='flow/1';maturity=$word.maturity})
}
foreach ($declaration in $fixtureTests) {
    $name = [string]$declaration.owner
    $word = $sourceWordByName[$name]
    $hash = Get-ObjectHash test ([string]$declaration.source)
    $expectedSourceBodies.Add([ordered]@{kind='test';name="$name/$($declaration.name)";sourceSha256=$hash;sourceFormat='flow/1';maturity=$word.maturity})
}
foreach ($declaration in $fixtureExamples) {
    $name = [string]$declaration.owner
    $word = $sourceWordByName[$name]
    $hash = Get-ObjectHash example ([string]$declaration.source)
    $expectedSourceBodies.Add([ordered]@{kind='example';name="$name/$($declaration.name)";sourceSha256=$hash;sourceFormat='flow/1';maturity=$word.maturity})
}
$expectedInput = [ordered]@{
    sourceReport = '141 paid-invoice-maintenance'
    sourceProjectManifestGeneration = [int]$sourceCurrent.generation
    sourceProjectManifestHash = [string]$sourceCurrent.manifestHash
    cliPath = [IO.Path]::GetRelativePath($repoRoot, $cliPath).Replace('\', '/')
    cliSha256 = $expectedCliSha256
    fixtures = @($fixtureInventory)
    fixtureCounts = [ordered]@{ words = 53; types = 31; tests = 154; examples = 44 }
    dictionaryOnlyWords = $extraWordNames
    dictionaryOnlyTypes = $extraTypeNames
    maturity = [ordered]@{ libraryWords = 59; projectWords = 3; projectNames = $projectWordNames }
    fullInheritedTests = 191
    expectedSourceBodies = @($expectedSourceBodies)
    fsharpSourceProject = 'experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/fsharp/project'
    fsharpFiles = $fsharpSourceInventory
}
Write-Json (Join-Path $seedRoot 'baseline-source-inventory.json') $expectedInput

# Define the six frozen source files and the nine object-backed additions only
# through the public JSONL protocol. The fixture sources stay Flow/1; additions
# retain their report-141 Flow/2 metadata.
$requests = [Collections.Generic.List[object]]::new()
foreach ($source in $fixtureSourcePaths) {
    $requests.Add([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 1
        source = [IO.File]::ReadAllText($source)
    })
}
if ($extraTypeSource.Count -gt 0) {
    $requests.Add([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 2
        source = ($extraTypeSource -join "`n`n")
    })
}
if ($extraWordSource.Count -gt 0) {
    $requests.Add([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 2
        source = ($extraWordSource -join "`n`n")
    })
}
$fullTestIndex = $requests.Count
$requests.Add([ordered]@{ op = 'test-all' })
$wordsBeforeDiscardIndex = $requests.Count
$requests.Add([ordered]@{ op = 'words' })
$discardIndexes = @{}
foreach ($name in $projectWordNames) {
    $discardIndexes[$name] = $requests.Count
    $requests.Add([ordered]@{ op = 'discard'; word = $name })
}
$libraryTestIndex = $requests.Count
$requests.Add([ordered]@{ op = 'test-all' })
$libraryCommitIndex = $requests.Count
$requests.Add([ordered]@{ op = 'commit'; library = $true })
foreach ($name in @('email.apply-delivery-result', 'email.delivery-fold-step')) {
    $group = @($fixtureDeclarations | Where-Object { $_.owner -ceq $name } | Sort-Object @{Expression={ if ($_.kind -ceq 'word') { 0 } elseif ($_.kind -ceq 'test') { 1 } else { 2 } }}, name)
    $projectSourceByVersion[1].AddRange([string[]]@($group | ForEach-Object { [string]$_.source }))
}
if ($projectSourceByVersion[1].Count -gt 0) {
    $requests.Add([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 1
        source = ($projectSourceByVersion[1] -join "`n`n")
    })
}
if ($projectSourceByVersion[2].Count -gt 0) {
    $requests.Add([ordered]@{
        op = 'define'
        frontend = 'flow'
        syntaxVersion = 2
        source = ($projectSourceByVersion[2] -join "`n`n")
    })
}
$restoredTestIndex = $requests.Count
$requests.Add([ordered]@{ op = 'test-all' })
$projectCommitIndexes = @{}
foreach ($name in $projectWordNames) {
    $projectCommitIndexes[$name] = $requests.Count
    $requests.Add([ordered]@{ op = 'commit-word'; word = $name; library = $false })
}
$finalTestIndex = $requests.Count
$requests.Add([ordered]@{ op = 'test-all' })
$finalWordsIndex = $requests.Count
$requests.Add([ordered]@{ op = 'words' })

$responses = Invoke-AgentJsonl $flowProject 'rehydrate' $requests.ToArray()
$fullTests = Assert-TestResults $responses[$fullTestIndex] 191 'Full staged report-141 source'
$candidateWords = @($responses[$wordsBeforeDiscardIndex].data.words)
foreach ($name in $libraryWordNames) {
    $rows = @($candidateWords | Where-Object { $_.name -ceq $name -and $_.status -ceq 'candidate' })
    if ($rows.Count -ne 1) { throw "Expected library word '$name' to be staged before commit." }
}
foreach ($name in $projectWordNames) {
    $discardResponse = $responses[$discardIndexes[$name]]
    if ($discardResponse.kind -cne 'discard') { throw "Could not separate project word '$name' before the library commit." }
}
$libraryTestCount = 191 - @($expectedSourceBodies | Where-Object { $_.kind -ceq 'test' -and $projectWordNames -contains ($_.name -replace '/.*$', '') }).Count
$libraryTests = Assert-TestResults $responses[$libraryTestIndex] $libraryTestCount 'Library-only report-141 source'
if ($responses[$libraryCommitIndex].kind -cne 'commit') { throw 'The 59 library words did not commit as library vocabulary.' }
$restoredTests = Assert-TestResults $responses[$restoredTestIndex] 191 'Restored report-141 source'
foreach ($name in $projectWordNames) {
    if ($responses[$projectCommitIndexes[$name]].kind -cne 'commit') { throw "Project word '$name' did not commit with project maturity." }
}
$finalTests = Assert-TestResults $responses[$finalTestIndex] 191 'Final committed report-141 source'
$finalWordRows = @($responses[$finalWordsIndex].data.words)
$finalLineage = [Collections.Generic.List[object]]::new()
foreach ($expectedWord in $sourceWordRows) {
    $rows = @($finalWordRows | Where-Object { $_.name -ceq $expectedWord.name -and $_.status -ceq 'persistent' })
    if ($rows.Count -ne 1) { throw "Final inventory does not contain exactly one persistent '$($expectedWord.name)'." }
    $row = $rows[0]
    if ($row.maturity -cne $expectedWord.maturity) { throw "Maturity changed for '$($expectedWord.name)': expected $($expectedWord.maturity), got $($row.maturity)." }
    $finalLineage.Add([ordered]@{
        name = [string]$row.name
        id = [string]$row.id
        revision = [int]$row.revision
        maturity = [string]$row.maturity
        status = [string]$row.status
        sourceFormat = "$($expectedWord.frontend)/$($expectedWord.syntaxVersion)"
        sourceDefinitionHash = $expectedWord.definitionHash
    })
}

# Start exactly one fresh pinned-runtime process to verify the saved canonical
# project, every stored definition body, every stored test body, and maturity.
$reloadRequests = [Collections.Generic.List[object]]::new()
$reloadWordsIndex = $reloadRequests.Count
$reloadRequests.Add([ordered]@{ op = 'words' })
$reloadTestIndex = $reloadRequests.Count
$reloadRequests.Add([ordered]@{ op = 'test-all' })
$sourceRequestIndexes = @{}
foreach ($entry in $expectedSourceBodies | Where-Object { $_.kind -in @('word', 'type') }) {
    $selector = if ($entry.kind -ceq 'word') { 'word' } else { 'type' }
    $key = "$($entry.kind)|$($entry.name)"
    $sourceRequestIndexes[$key] = $reloadRequests.Count
    $request = [ordered]@{ op = 'source' }
    $request[$selector] = $entry.name
    $reloadRequests.Add($request)
}
$reloadResponses = Invoke-AgentJsonl $flowProject 'reload-verify' $reloadRequests.ToArray()
$reloadWordRows = @($reloadResponses[$reloadWordsIndex].data.words)
$reloadTestSummary = Assert-TestResults $reloadResponses[$reloadTestIndex] 191 'Fresh-process report-141 source'
foreach ($entry in $expectedSourceBodies | Where-Object { $_.kind -in @('word', 'type') }) {
    $key = "$($entry.kind)|$($entry.name)"
    $body = [string]$reloadResponses[$sourceRequestIndexes[$key]].data
    if ((Get-TextSha256 $body) -cne $entry.sourceSha256) {
        throw "Fresh-process source body differs for $($entry.kind) '$($entry.name)'."
    }
}

$freshManifestCurrent = Get-Content -LiteralPath (Join-Path $flowProject '.agentlang/store/CURRENT') -Raw | ConvertFrom-Json -Depth 20
$freshManifestPath = Join-Path (Join-Path $flowProject '.agentlang/store/manifests') ($freshManifestCurrent.manifestHash + '.json')
$freshManifest = Get-Content -LiteralPath $freshManifestPath -Raw | ConvertFrom-Json -Depth 100
$freshObjectRoot = Join-Path $flowProject '.agentlang/store/objects'
$freshWordByName = @{}
foreach ($word in $freshManifest.words) {
    $revision = Get-Revision $freshManifest ([string]$word.wordId) ([int]$word.currentRevision)
    $freshWordByName[[string]$word.currentName] = $revision
}
$bodyChecks = [Collections.Generic.List[object]]::new()
foreach ($entry in $expectedSourceBodies) {
    $hash = $null
    if ($entry.kind -ceq 'type') {
        $type = @($freshManifest.types | Where-Object { $_.name -ceq $entry.name })
        if ($type.Count -ne 1) { throw "Fresh manifest is missing type '$($entry.name)'." }
        $hash = [string]$type[0].definition.hash
    } elseif ($entry.kind -ceq 'word') {
        $revision = $freshWordByName[[string]$entry.name]
        if ($null -eq $revision) { throw "Fresh manifest is missing word '$($entry.name)'." }
        $hash = [string]$revision.definition.hash
    } else {
        $parts = ([string]$entry.name).Split('/', 2)
        $revision = $freshWordByName[$parts[0]]
        if ($null -eq $revision) { throw "Fresh manifest is missing owner '$($parts[0])' for $($entry.kind)." }
        $references = if ($entry.kind -ceq 'test') { @($revision.tests) } else { @($revision.examples) }
        $matched = @($references | Where-Object { [string]$_.hash -ceq [string]$entry.sourceSha256 })
        if ($matched.Count -ne 1) { throw "Fresh manifest does not contain exactly one $($entry.kind) '$($entry.name)'." }
        $hash = [string]$matched[0].hash
    }
    $objectPath = Join-Path $freshObjectRoot ($hash + '.agent')
    if (-not (Test-Path -LiteralPath $objectPath -PathType Leaf)) { throw "Fresh source object is missing: $hash" }
    $actualHash = Get-Sha256 $objectPath
    if ($actualHash -cne $entry.sourceSha256) {
        throw "Persisted $($entry.kind) '$($entry.name)' body hash differs from the frozen report-141 input."
    }
    $bodyChecks.Add([ordered]@{kind=$entry.kind;name=$entry.name;sourceSha256=$actualHash;preserved=$true})
}

$maturityCounts = @($reloadWordRows | Group-Object maturity | ForEach-Object { [ordered]@{maturity=$_.Name;count=$_.Count} })
if (@($reloadWordRows).Count -ne 62 -or @($reloadWordRows | Where-Object status -ceq 'persistent').Count -ne 62) {
    throw 'Fresh-process inventory did not load all 62 persistent report-141 words.'
}
if (@($reloadWordRows | Where-Object { $_.maturity -ceq 'library' }).Count -ne 59 -or @($reloadWordRows | Where-Object { $_.maturity -ceq 'project' }).Count -ne 3) {
    throw 'Fresh-process maturity split differs from the report-141 59-library/3-project source.'
}

$historyFiles = @(Get-ChildItem (Join-Path $flowProject 'history') -File -Force | Sort-Object Name | ForEach-Object { [ordered]@{path=$_.Name;sha256=Get-Sha256 $_.FullName} })
$seedReport = [ordered]@{
    schemaVersion = 1
    preparedUtc = [DateTimeOffset]::UtcNow.ToString('O')
    sourceLineage = [ordered]@{
        sourceReport = 'paid-invoice-maintenance-141'
        sourceManifestGeneration = [int]$sourceCurrent.generation
        sourceManifestHash = [string]$sourceCurrent.manifestHash
        sourceExportHash = [string]$sourceManifest.projectSource.hash
        sourceDictionarySha256 = Get-Sha256 (Join-Path $flowSourceProject 'dictionary.agent')
        originalDirectCopyLoadFailure = '.agentlang/next-efficacy-175/load-check/stderr.txt: STORAGE_PROJECT_MISMATCH'
        pinnedRuntime = [ordered]@{path=[IO.Path]::GetRelativePath($repoRoot,$cliPath).Replace('\','/');sha256=$expectedCliSha256}
        replayMethod = 'public JSONL define, test-all, discard, commit, commit-word; no manifest/export editing'
        fixtureSourceFormat = 'flow/1'
        dictionaryOnlySourceFormat = 'flow/2'
        dictionaryOnlyWords = $extraWordNames
        dictionaryOnlyTypes = $extraTypeNames
        absentDictionaryOnlyAdditions = @()
    }
    counts = [ordered]@{
        fixtureWords = 53
        fixtureTypes = 31
        fixtureTests = 154
        fixtureExamples = 44
        fullInheritedTests = 191
        fullInheritedExamples = 44
        words = 62
        types = 37
        libraryWords = 59
        projectWords = 3
    }
    tests = [ordered]@{
        fullStaged = $fullTests
        libraryOnly = $libraryTests
        restored = $restoredTests
        committed = $finalTests
        freshProcessReload = $reloadTestSummary
    }
    bodyChecks = @($bodyChecks)
    maturityCounts = $maturityCounts
    lineage = @($finalLineage)
    manifest = [ordered]@{
        generation = [int]$freshManifestCurrent.generation
        hash = [string]$freshManifestCurrent.manifestHash
        formatVersion = [int]$freshManifest.formatVersion
        historyFiles = $historyFiles
    }
    flowProjectInventory = Get-Inventory $flowProject
    fsharpProjectInventory = $fsharpCopiedInventory
    fsharpValidation = [ordered]@{
        buildRun = $false
        command = 'dotnet build .agentlang/next-efficacy-175/seed-preparation/fsharp/project/tests/AgentLang.Business.Tests.fsproj --artifacts-path .agentlang/next-efficacy-175/fsharp/report141-seed -c Release -p:NuGetAudit=false -p:BuildInParallel=false -m:1; dotnet .agentlang/next-efficacy-175/fsharp/report141-seed/bin/AgentLang.Business.Tests/release/AgentLang.Business.Tests.dll'
        sourceFilesUnchanged = $true
    }
}
Write-Json (Join-Path $seedRoot 'seed-report.json') $seedReport
Write-Output (Join-Path $seedRoot 'seed-report.json')

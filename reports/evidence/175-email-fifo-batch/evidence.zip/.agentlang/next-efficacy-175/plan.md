# 175 — FIFO email delivery with partial progress

Status: planning proposal only. No seed, runtime, oracle, or product files were
changed during this research pass.

## Recommendation

Run one fresh AgentLang/F# pair on a stateful batch-delivery operation over the
accepted business seed. The operation should process queued messages in FIFO
order, retain each successful delivery, and stop at the first provider failure
while returning the successful prefix and its failure explicitly. This tests a
real multi-step state transition with visible partial progress. It is distinct
from subscription-window maintenance and from the pure preview wrapper in
report 171.

The task should require the new batch path to build on the seed's existing
single-message delivery operation, but should not name that operation in the
public prompt. Source review can record whether the agent found and called it.
This makes vocabulary discovery observable without prescribing a helper name.

## Public behavior

Suggested public targets are `email.deliver-batch` in AgentLang and
`EmailOutbox.deliverBatch` in F#. Given a Store and a finite ordered sequence of
delivery outcomes, attempt the outcomes against the head of the email outbox in
order. Return a typed `EmailBatchResult` record with the resulting Store, an
integer count of successful deliveries, and an optional failure
(`Option<BusinessError>` in AgentLang; `DomainError option` in F#). Use the
same ordered provider-outcome input in both arms: `List<Result<Unit, String>>`
in AgentLang and `Result<unit, string> list` in F#. The F# batch function adapts
each selected outcome through the existing `EmailProvider.Send` interface for
one `EmailOutbox.deliverNext` call. AgentLang adapts an error detail to
`businessError::new(code = "EMAIL_PROVIDER_FAILURE", message = detail)` before
calling its existing single-message operation. Do not accept arbitrary
`BusinessError` outcomes: the F# provider surface cannot express arbitrary
AgentLang error codes. Internal accumulator helper names remain the
participant's choice.

- A successful outcome moves only the current outbox head to the end of the
  sent list and increments the count.
- The first provider failure stops the batch. Return the Store after the
  successful prefix; leave the failed message at the outbox head with all later
  messages in their original order. Preserve the failure category and ignore
  all later outcomes.
- Stop cleanly when either the queue or outcomes end. An exhausted queue does
  not produce a synthetic `NO_PENDING_EMAIL`; an exhausted outcome list leaves
  the remaining queue untouched.
- Preserve every non-email Store field and the caller's original immutable
  input. Keep the existing one-message operation's behavior and tests intact.

Do not require a particular new function or record name. Require a durable,
tested AgentLang library word with complete own-body coverage. The F# participant
can add the equivalent function and result record in the established module.

## Accepted seeds and lineage

Use isolated copies of the verified report-141 starts:

- AgentLang: `experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/flow-retained/project`
- F#: `experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/starts/fsharp/project`

Report 141 verifies these source copies against the accepted report-135 replica
two projects. The AgentLang email vocabulary and its attached tests are in
`fixtures/business-payments-email.agent`. The F# counterpart is
`business/Business.fs`, with the existing delivery checks in
`tests/Program.fs` (`testEmailOutboxAndProviderIsolation`). Both already cover
single-message success, provider failure, FIFO retention, and immutable input.
The new sequence behavior is absent from both seeds.

The existing email words and attached cases use Flow/1 source. The retained
`dictionary.agent` marks definitions with `// frontend: flow/1`; persisted
report-141 baseline manifests likewise record the email words as
`sourceFormat: flow/1`. Keep those inherited definitions and test bodies in
their authored syntax. The Flow/1 forms `word`, `::`, semicolon-terminated
statements, and generated accessors are valid historical syntax, not work for
the participant to translate. New words may use an explicitly selected
supported version, but do not make broad migration a prerequisite.

The existing vocabulary supports `items.fold(seed, domain::step)` with a
statically named callback (`docs/LIST-FOLD-PLAN.md`); nested closed containers
such as `List<Result<Unit, String>>` are supported. Fold carries an evolving
typed accumulator left-to-right, but it does not short-circuit or capture
locals. A single `EmailBatchResult` record can serve as both fold accumulator
and public output: after failure or an empty outbox, the callback returns it
unchanged; otherwise it applies one outcome and updates Store/count. This stops
further delivery attempts while the fold visits remaining scripted outcomes as
no-ops. The existing one-message word splits the queue with `emailDeliveryPlan`
and `email::delivery-fold-step`; the batch callback must check
`list.is-empty?` before calling it, so queue exhaustion does not fabricate
`NO_PENDING_EMAIL`. `list.tail` is also available and preserves list type/order,
but explicit recursive traversal is not an option: executable word call graphs
must be acyclic (`IR_RECURSIVE_CALL_GRAPH`), and vocabulary expansion rejects
recursive words. No runtime or syntax extension is required.

The pinned-runtime preflight was attempted on an isolated byte-identical
report-141 copy and failed closed with `STORAGE_PROJECT_MISMATCH`: the durable
project export does not match its manifest-backed source objects. The runtime
requires exact canonical `sourceFor` equality for manifest format 2+, so this
is not evidence that Flow/1 syntax or inherited tests are unsupported. Do not
weaken that guard or translate inherited definitions to make the load pass.

Reuse the exact study seed builder before attempting a manifest migration:
`experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/Prepare-Maintenance141.ps1`.
It copies the accepted report-135 replica-two Flow and F# projects, preserving
their manifests, histories, object IDs, and authored tests, then adds only the
Maintenance 141 test fixture through the supported Flow JSONL sequence
`task.begin` → `define` (explicit `frontend=flow`, `syntaxVersion=2`) →
`commit` (`library=false`) → `task.commit`. The script records accepted/study
hashes in `start-inventory.json`; `source-provenance.md` records a fresh CLI
load with all 191 attached tests passing. Recreate the start in a new isolated
destination and supply the pinned current CLI, then check reload and inherited
tests. This is the smallest coordinator preparation and avoids rebuilding the
seed from only six fixture documents, which would omit report-141 additions.
If the copied accepted base or the fixture-added start still fails with the
same canonical-export mismatch, then there is no existing ordinary full-project
manifest migration to reuse: prepare a coordinator-only canonical re-export of
the full existing source, preserving source versions, maturity, all fixture
bodies, and inherited test bodies/assertions, and verify their hashes before
using it. Do not weaken storage validation or make translation a participant
task. No product compatibility change is indicated.

The seed histories and test surfaces are not identical. The AgentLang
single-step word accepts `Result<Unit, BusinessError>` and on provider failure
returns code `EMAIL_PROVIDER_FAILURE` with the input error's message verbatim.
F# `EmailOutbox.deliverNext` calls
`EmailProvider.Send : EmailMessage -> Result<unit, string>` and maps the detail
to `DomainError.EmailProviderFailure`; its established message adds the prefix
`Email provider failed: `. Keep both one-step adapters and their error text
unchanged. The batch's shared input is only a success or provider-detail string,
so test failure as the native category/code plus that detail after normalizing
F#'s established display prefix. AgentLang has attached word tests plus library
qualification; F# has a console self-test project. Preserve these separate
denominators and do not claim equal test history or identical API shape. The
report-141 Flow seed also contains its maintenance-specific imported-payment
fixture and payment aggregation; keep those files frozen and outside the new
production call path.

## Independent cases and controls

Use a small host-side oracle over real candidate code, not participant tests, to
check complete Store projections and outcome fields in both environments.
Cover at least:

1. Three successes: all messages move to sent in FIFO order and all other Store
   fields remain equal in the full semantic projection.
2. Failure on the first message: zero deliveries, original outbox retained, and
   the provider-failure category returned.
3. One success followed by failure and a trailing success: only the first message
   moves; the failed message and tail remain ordered; count and failure describe
   the partial result; the trailing outcome is unused.
4. Outcomes end before the queue: the successful prefix is retained, the
   remaining queue is unchanged, and no failure is fabricated.
5. The queue ends before outcomes: all queued messages move, excess outcomes
   are ignored, and no `NO_PENDING_EMAIL` is fabricated.
6. Empty queue and empty outcomes: zero count, unchanged Store, no failure.

Before any dispatch, score one correct control and executing mutants that (a)
drop the failed message, (b) continue after failure, (c) roll back the successful
prefix, or (d) reverse sent-message order. Require actual case failures, not
compile or transport errors. Audit that the batch path calls the existing
single-message transition and that no inherited test body/name or unrelated
definition was removed or changed.

## Local harness and validation

There is no frozen independent email-batch oracle. Reuse the report-141 local
interfaces without presenting its payment oracle as batch coverage: its Flow
scorer uses structured JSONL `eval` requests, and its F# scorer builds and loads
the candidate project into a host-side scorer. Add only a narrow batch case
adapter/scorer for this task; do not build a general benchmark runner.

The accepted F# self-test build pattern is:

```powershell
dotnet build <candidate>\tests\AgentLang.Business.Tests.fsproj --artifacts-path .agentlang\next-efficacy-175\fsharp\<run> -c Release -p:NuGetAudit=false -p:BuildInParallel=false -m:1
dotnet .agentlang\next-efficacy-175\fsharp\<run>\bin\AgentLang.Business.Tests\release\AgentLang.Business.Tests.dll
```

For AgentLang, use the pinned Release CLI and the existing JSONL project runner
pattern from `experiments/AgentLang.SubagentTrials/paid-invoice-maintenance-141/scoring/flow/Score-Maintenance141Flow.ps1`:

```powershell
dotnet <pinned-AgentLang.Cli.dll> --project <candidate-flow-project> --jsonl
```

Feed it the frozen structured evaluations, then reload the saved project and run
all attached tests and the new word's library coverage gate. Reuse the current
report-171/report-173 runtime pin when unchanged; if CLI/runtime sources change,
build fresh Release artifacts and run:

```powershell
pwsh ./scripts/Validate.ps1 -Configuration Release -SerialBuild -SkipPackageAudit -ReportPath .agentlang/next-efficacy-175/full-validation.json
```

For F#, retain the pinned offline NuGet setting shown above.

Run one fresh Luna/max participant per language with isolated projects, source
access to the complete assigned project and tests, and the existing broker
protocol. Record behavioral acceptance, preserved inherited assertions,
attached-test results, library qualification, and helper reuse separately.
This single pair can establish bounded feasibility and expose discovery issues;
it cannot establish comparative reliability, language advantage, or token/cost
claims.

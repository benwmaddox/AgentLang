import hashlib
import json
import zipfile
from pathlib import Path

repo = Path.cwd().resolve()
root = repo / '.agentlang/next-efficacy-175'
out = repo / 'reports/evidence/175-email-fifo-batch'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
original = load(out / 'archive.json')
assert sha((out / 'evidence.zip').read_bytes()) == original['archive']['sha256']
assert not (out / 'supplement.zip').exists() and not (out / 'supplement.json').exists()
rows = []
files = {Path(__file__).resolve()}
for current in root.rglob('CURRENT'):
    if any(part in ('bin', 'obj', 'temp', 'broker-runtime') for part in current.relative_to(root).parts):
        continue
    pointer = load(current)
    manifest = current.parent / 'manifests' / (pointer['manifestHash'] + '.json')
    assert sha(manifest.read_bytes()) == pointer['manifestHash']
    files.update((current.resolve(), manifest.resolve()))
review = load(root / 'coordinator/preservation-review.json')
candidate = repo / review['flow']['candidateManifest']['path']
assert candidate in files and sha(candidate.read_bytes()) == review['flow']['candidateManifest']['sha256']
with zipfile.ZipFile(out / 'supplement.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(files):
        data = p.read_bytes()
        name = p.relative_to(repo).as_posix()
        archive.writestr(name, data)
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(out / 'supplement.zip') as archive:
    assert archive.testzip() is None
    for row in rows:
        data = archive.read(row['path'])
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
index = {'schemaVersion': 1, 'status': 'verified',
         'reason': 'Original filter compared manifest stem with raw CURRENT text. CURRENT is a JSON pointer. Supplement retains every referenced final manifest and its pointer; original archive and outcomes are unchanged.',
         'originalArchiveSha256': original['archive']['sha256'],
         'archive': {'path': 'supplement.zip', 'bytes': (out / 'supplement.zip').stat().st_size,
                     'sha256': sha((out / 'supplement.zip').read_bytes())}, 'files': rows}
(out / 'supplement.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in index.items() if k != 'files'}))

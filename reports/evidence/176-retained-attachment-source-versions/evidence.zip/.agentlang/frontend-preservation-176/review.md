# Milestone 176 independent source review

Reviewed the frozen milestone 176 source against `attachment-plan.md`, focusing on attachment source-version preservation, parser alias semantics, and the storage/runtime boundaries described there.

## Findings

No outstanding concrete findings remain in the current frozen source.

## Follow-up correction to the initial review

The initial review missed a separate v5 type-source read/write mismatch. `Storage.typeSourceNode` writes `sourceFormat` and `validatorTarget` for v5, while `parseTypeSource` initially accepted strict fields only for versions 3 and 4. A real v5 reload containing type sources therefore failed. The follow-up changed `src/AgentLang.Core/Storage.fs:846-856` to apply the strict branch to version 5 and added a fresh-load regression in `tests/AgentLang.Storage.Tests/Program.fs`. I verified the corrected parser branch and test source; this issue is resolved in the current source.

A later follow-up review found a second v5 omission at `src/AgentLang.Core/Runtime.fs:2365`: generated record/scalar Stack cases were recovered from the aggregate export for versions 1–4 only. The current source explicitly includes version 5, and `testGeneratedRecordCasesPersistBesideFlow` now combines generated-record tests and examples with a Flow/2 attachment on a Flow/1 owner, persists a wrapper, and checks fresh reload of the generated cases and wrapper. I verified the gate and regression source. This issue is resolved in the current source. The initial review did not identify the type-source omission; the subsequent follow-up identified the generated-case omission, both are disclosed here.

Focused validation later exposed a third preservation bug that this source review did not catch: the single-owner legacy replacement rebuilt `FlowTestFiles` from only the changed owner, dropping wrappers belonging to unrelated owners while retaining their case rows. The current source at `src/AgentLang.Core/Runtime.fs:4738-4745` filters the old wrapper map by owner, retains unrelated wrappers, then merges in the changed owner's rewritten wrappers. The regression in `tests/AgentLang.Flow.Runtime.Tests/Program.fs` checks both unrelated wrapper references, source/settings, scoped override bindings, and fresh v5 reload. I verified the merge and regression scope after the writer's freeze signal. This issue was caught by the focused run and is resolved in the current source; I did not run that build or test.

## Review coverage

- Manifest format 5 serializes a deterministic attachment-reference-to-format map. Validation requires exact test/example reference coverage, rejects duplicates, unsupported versions, and frontend mismatches, and rejects loss of independent formats when serializing an older manifest version. The version gates at `Storage.fs:692-720`, `768-803`, and `919-992` support v5 while retaining the v1-v4 compatibility rules.
- Type-source serialization and parsing now agree on the strict v3-v5 fields. The v5 type-source fresh-load regression covers this corrected branch.
- Generated record/scalar cases are recovered for v5 as well as v1-v4. The regression keeps generated test/example sources and a shared wrapper present while an independent Flow attachment selects v5, then checks fresh reload.
- Single-owner replacement retains wrappers owned by other words while merging rewritten wrappers for the changed owner. The focused regression checks source references, wrapper settings and scoped bindings before and after commit and after fresh reload.
- Rehydration selects each test, example, and test-file wrapper parser from that exact source reference. Manifests 1–4 use the documented owner-format fallback. Stored call-binding paths choose the format by body role and attachment reference while retaining existing role/source/case checks.
- Runtime publication gathers each attachment's own format, preserves formats for retained sources across owner revisions, and emits the per-attachment format in durable project export. Wrapper-backed case rows use the wrapper's recorded version. Rewrite, rename, deprecation, and owner-replacement paths inspected here reparse retained attachments using their recorded source version.
- The wrapper-only registration route accepts Flow/2 wrapper syntax, and runtime validation requires wrappers to be Flow/2. The apparent use of the submitted `syntaxVersion` while removing a case in that route is therefore aligned with all reachable valid wrappers; Flow/1 attachment-only requests use the separate legacy attachment route.
- Leading-dot container constructors and namespace-qualified static callbacks are Flow/2-only aliases to the existing canonical constructor/reference AST forms. Tests cover canonicalization, static binding identity under shadowing, and rejection in Flow/1 or malformed forms.

No builds or tests were run by this reviewer; validation remains with the coordinating agent's fresh focused and full gates.

# Attachment frontend preservation plan

## Observed failure

In `flow-trace.jsonl`, exchanges 24 and 56 fail while replacing
`email.apply-delivery-result` with a Flow/2 owner revision. The retained
Flow/1 attachment still has the same stable owner ID and the updated owner
revision; the runtime rejects it because its `SyntaxVersion` differs from the
owner's. The same equality is applied to a test-file wrapper. Durable
`WordRevision` metadata stores only the owner's `SourceFormat`, so loading also
parses every attached test, example, and test-file wrapper using the owner's
syntax version. Removing the runtime equality alone would therefore make
rehydration ambiguous and would not preserve the independent source format.

## Contract and schema

Add `AttachmentSourceFormats : Map<SourceRef, SourceFormat>` to `WordRevision`.
The keys are the exact immutable references already listed by `Tests` and
`Examples`; a test-file wrapper is represented by its one `TestDefinition`
reference, including every wrapper-backed binding's shared source reference.

Manifest format 5 stores an `attachmentSourceFormats` array on each revision.
Each row contains the complete `SourceRef` (`kind`, `hash`) and its
`SourceFormat` (`frontend`, `version`). Sort rows by source kind and hash for
deterministic serialization. Format 5 requires exactly one row per distinct
test/example source reference, with no missing or extra references. Reject
duplicate rows, unsupported formats, and frontend differences from the owner.
Stack attachments remain Stack/1; Flow attachments may independently be
Flow/1 or Flow/2. Do not infer format from source text or translate source.

Manifests 1–4 deserialize with an in-memory map assigning each attached
reference the owner's format. Keep their wire representation and deterministic
expected strings unchanged. New commits select format 5 only when a retained
attachment format differs from its owner, and keep format 5 once the existing
manifest has reached it. Format 5 always writes the complete exact map, even
when the current revision's attachment formats happen to match its owner.

## Runtime behavior

On commit, collect each Flow test, wrapper, and example source's own version
alongside the exact source reference. Existing Stack sources use Stack/1. A
format difference is permitted only within the same frontend and supported
versions; preserve existing owner ID, owner revision, source kind, source hash,
wrapper scope/case ownership, and settings/version checks. Continue rejecting
Stack/Flow mixtures. On rehydration, select the source version by the exact
reference for standalone tests, examples, and whole test-file wrappers; stamp
wrapper-backed case rows with that wrapper version. Keep each source's bytes
and hashes unchanged when the owner revision advances.

Attachment-only and wrapper-only documents parse at their explicitly selected
attachment version, then compile against the unchanged owner parsed at its
stored definition version. Owner revision/CAS checks still guard those edits.
When removing a case rewrites a shared wrapper, reparse the rewritten wrapper
at the wrapper's recorded version so a retained Flow/2 case stays Flow/2 under
a Flow/1 owner.

Storage call-binding checks select syntax by role: `Definition` uses the owner
format; `Actual`, `ExpectedExpression`, and `TestOverride` use the format for
their exact attachment source reference. Apply Flow/1 path-shape restrictions
against that selected format. This admits Flow/2 attachment metadata under a
Flow/1 owner while retaining Flow/1 checks on the definition and all existing
role/source/case/target binding validation.

## Preservation and rejection invariants

- Replacing a Flow/1 owner with Flow/2 (and the reverse where valid) may
  advance only the owner revision and owner definition source; retained tests,
  examples, and test-file wrappers preserve exact source bytes, hashes, values,
  IDs, case names, and call-target identities through commit and fresh reload.
- Keep optimistic-generation/CAS, content-address/hash, library maturity,
  overlay, stable owner identity, revision, capability, and effect assertion
  gates unchanged. No parser fallback, AST sniffing, or attachment conversion.
- Reject an attachment map with a bad reference, an extra or missing entry,
  duplicate entry, cross-frontend format, or unsupported version before commit;
  confirm authority/generation and durable source content do not drift.
- Existing format-1 through format-4 deterministic serialization assertions
  remain unchanged. Frozen efficacy-175 evidence is read-only.

## Implementation and validation scope

Owned files: `src/AgentLang.Core/Storage.fs`,
`src/AgentLang.Core/Runtime.fs`, `tests/AgentLang.Storage.Tests/Program.fs`,
and `tests/AgentLang.Flow.Runtime.Tests/Program.fs`. `FlowLowering.fs` is not
expected to change because it already parses attachment documents with their
declared syntax version and validates owner IDs/revisions and stable bindings.
The parser agent owns `FlowParser.fs` and `tests/AgentLang.Flow.Tests/Program.fs`;
root owns help, reports, and frozen evidence. First run `git diff --check`.
Wait for root's source-freeze signal before running the storage and Flow runtime
test projects; do not run the full gate or remote commands.

import hashlib,json,zipfile
from pathlib import Path
repo=Path.cwd().resolve()
root=repo/'.agentlang/frontend-preservation-176'
out=repo/'reports/evidence/176-retained-attachment-source-versions'
assert not out.exists(), 'Refuse evidence overwrite'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=load(root/'source-pins-008.json')
for f in pins['files']:
 assert sha((repo/f['path']).read_bytes())==f['sha256'], f['path']
focused=load(root/'focused-008/result.json'); replay=load(root/'replay-003/result.json'); full=load(root/'full-001/validation.json')
assert focused['passed'] and replay['passed'] and full['passed']
assert load(root/'full-001/exit.json')['exitCode']==0
files={}
for p in root.rglob('*'):
 if p.is_file() and 'temp' not in p.relative_to(root).parts and not any(x in p.relative_to(root).parts for x in ['bin','obj','__pycache__']):
  files[p.relative_to(repo).as_posix()]=p
for f in pins['files']:
 p=repo/f['path']; files[f['path']]=p
for name in ['docs/CURRENT-SYNTAX.md','docs/PRD.md','docs/STORAGE.md','docs/ROADMAP.md','reports/176-retained-attachment-source-versions.md']:
 files[name]=repo/name
# CURRENT is a JSON pointer. Check every archived replay manifest reference.
for current in root.glob('replay-*/project/.agentlang/store/CURRENT'):
 pointer=load(current); manifest=current.parent/'manifests'/(pointer['manifestHash']+'.json')
 assert manifest.exists() and sha(manifest.read_bytes())==pointer['manifestHash']
 assert manifest.relative_to(repo).as_posix() in files
out.mkdir(parents=True)
archive=out/'evidence.zip'
entries=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  b=p.read_bytes(); z.writestr(name,b); entries.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for e in entries: assert sha(z.read(e['path']))==e['sha256']
index={'schemaVersion':1,'archive':'evidence.zip','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'entries':entries,'sourcePins':'source-pins-008.json','focusedAttempt':'008','replayAttempt':'003','fullAttempt':'001','preservedFailedAttempts':['focused-001','focused-002','focused-003','focused-004','focused-005','focused-006','focused-007','replay-001'],'securityAudit':False}
(out/'archive.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in index.items() if k!='entries'}))

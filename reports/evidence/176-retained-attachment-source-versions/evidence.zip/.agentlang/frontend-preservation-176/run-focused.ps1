param([string]$Attempt = '001')
$ErrorActionPreference = 'Stop'
$repo = (Get-Location).Path
$root = Join-Path $repo '.agentlang/frontend-preservation-176'
$output = Join-Path $root ('focused-' + $Attempt)
if (Test-Path -LiteralPath $output) { throw 'Refuse overwrite or restart' }
[void][IO.Directory]::CreateDirectory($output)
$env:TEMP = Join-Path $root 'temp/focused'
$env:TMP = $env:TEMP
[void][IO.Directory]::CreateDirectory($env:TEMP)
$checks = [Collections.Generic.List[object]]::new()
function Invoke-Check([string]$Name, [string]$Command, [string[]]$Arguments) {
    $log = Join-Path $output ($Name + '.log')
    & $Command @Arguments *> $log
    $code = $LASTEXITCODE
    $checks.Add([ordered]@{name=$Name;command=(@($Command)+$Arguments)-join ' ';exitCode=$code;log=$log})
    Write-Host "$Name exit=$code"
    return $code
}
$build = Invoke-Check 'build' 'dotnet' @('build','AgentLang.sln','--configuration','Release','-m:1','-p:NuGetAudit=false')
if ($build -eq 0) {
    foreach ($name in @('AgentLang.Flow.Tests','AgentLang.Discovery.Tests','AgentLang.Storage.Tests','AgentLang.Flow.Runtime.Tests')) {
        $null = Invoke-Check $name 'dotnet' @('run','--no-build','--configuration','Release','--project',('tests/'+$name))
    }
}
$passed = @($checks | Where-Object exitCode -ne 0).Count -eq 0
[IO.File]::WriteAllText((Join-Path $output 'result.json'), ([ordered]@{schemaVersion=1;passed=$passed;checks=$checks.ToArray()} | ConvertTo-Json -Depth 8))
if (-not $passed) { exit 1 }

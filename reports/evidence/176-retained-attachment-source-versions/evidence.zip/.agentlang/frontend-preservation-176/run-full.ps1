param([string]$Attempt = '001')
$ErrorActionPreference = 'Stop'
$root = Join-Path (Get-Location).Path '.agentlang/frontend-preservation-176'
$output = Join-Path $root ('full-' + $Attempt)
if (Test-Path -LiteralPath $output) { throw 'Refuse overwrite or restart' }
[void][IO.Directory]::CreateDirectory($output)
$env:TEMP = Join-Path $root 'temp/full'
$env:TMP = $env:TEMP
[void][IO.Directory]::CreateDirectory($env:TEMP)
& pwsh -NoProfile -File scripts/Validate.ps1 -ReportPath (Join-Path $output 'validation.json') -Configuration Release -SerialBuild -SkipPackageAudit *> (Join-Path $output 'validation.log')
$code = $LASTEXITCODE
[IO.File]::WriteAllText((Join-Path $output 'exit.json'), ([ordered]@{exitCode=$code} | ConvertTo-Json))
Write-Host "Full local validation exit=$code"
exit $code

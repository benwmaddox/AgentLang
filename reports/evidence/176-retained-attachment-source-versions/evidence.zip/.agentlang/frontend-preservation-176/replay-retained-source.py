"""Engineering replay of trial 175's blocked replacement, not an agent trial."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

repo = Path.cwd().resolve()
root = repo / '.agentlang/frontend-preservation-176'
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', default='001')
arguments = parser.parse_args()
assert arguments.attempt.isdigit() and len(arguments.attempt) == 3
run = root / ('replay-' + arguments.attempt)
assert not run.exists(), 'Refuse overwrite or restart'
seed = repo / '.agentlang/next-efficacy-175/seed-preparation/attempt-03-completion-validated/flow/project'
run.mkdir()
project = run / 'project'
shutil.copytree(seed, project)
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()

def manifest():
    store = project / '.agentlang/store'
    return load(store / 'manifests' / (load(store / 'CURRENT')['manifestHash'] + '.json'))

before = manifest()
target_id = next(w['wordId'] for w in before['words'] if w['currentName'] == 'email.apply-delivery-result')
old = next(w for w in before['revisions'] if w['wordId'] == target_id and w['revision'] == 1)
trace = repo / '.agentlang/next-efficacy-175/coordinator/actors/flow-trace.jsonl'
row = next(loadrow for line in trace.read_text(encoding='utf-8-sig').splitlines()
           if (loadrow := json.loads(line)).get('event') == 'exchange' and loadrow['index'] == 24)
replacement = json.loads(row['request']['canonical'])
assert replacement['syntaxVersion'] == 2 and replacement['expectedRevision'] == 1

def invoke(label, requests):
    raw = ''.join(json.dumps(request, ensure_ascii=False) + '\n' for request in requests)
    (run / f'{label}-requests.jsonl').write_text(raw, encoding='utf-8')
    env = os.environ.copy()
    temp = root / 'temp/replay'
    temp.mkdir(parents=True, exist_ok=True)
    env['TEMP'] = env['TMP'] = str(temp)
    process = subprocess.run(['dotnet', str(cli), '--project', str(project), '--jsonl'],
                             input=raw, capture_output=True, text=True, encoding='utf-8',
                             cwd=project, env=env)
    (run / f'{label}-responses.jsonl').write_text(process.stdout, encoding='utf-8')
    (run / f'{label}-stderr.txt').write_text(process.stderr, encoding='utf-8')
    responses = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
    assert process.returncode == 0 and len(responses) == len(requests), (process.returncode, process.stderr)
    assert all(response['ok'] for response in responses), responses
    return responses

requests = [replacement, {'op': 'test', 'word': 'email.apply-delivery-result'},
            {'op': 'example', 'word': 'email.apply-delivery-result'}, {'op': 'test-all'},
            {'op': 'commit', 'word': 'email.apply-delivery-result', 'library': True}]
first = invoke('replace', requests)
assert len(first[1]['data']['results']) == 3 and all(row['passed'] for row in first[1]['data']['results'])
assert len(first[2]['data']['results']) == 1 and all(row['passed'] for row in first[2]['data']['results'])
assert first[2]['data']['results'][0]['actual'] == ['"NO_PENDING_EMAIL"']
assert len(first[3]['data']['results']) == 191 and all(row['passed'] for row in first[3]['data']['results'])
after = manifest()
new = next(w for w in after['revisions'] if w['wordId'] == target_id and w['revision'] == 2)
assert after['formatVersion'] == 5
assert old['tests'] == new['tests'] and old['examples'] == new['examples']
assert new['sourceFormat'] == {'frontend': 'flow', 'version': 2}
assert all(row['sourceFormat'] == {'frontend': 'flow', 'version': 1} for row in new['attachmentSourceFormats'])
assert {json.dumps(row['source'], sort_keys=True) for row in new['attachmentSourceFormats']} == {
    json.dumps(ref, sort_keys=True) for ref in old['tests'] + old['examples']}
old_bindings = [item for item in old['callBindings'] if item['bodyRole'] != 'definition']
new_bindings = [item for item in new['callBindings'] if item['bodyRole'] != 'definition']
assert old_bindings == new_bindings
second = invoke('reload', [{'op': 'tests', 'word': 'email.apply-delivery-result', 'includeSource': True},
                           {'op': 'test', 'word': 'email.apply-delivery-result'},
                           {'op': 'example', 'word': 'email.apply-delivery-result'}, {'op': 'test-all'}])
assert len(second[1]['data']['results']) == 3 and all(row['passed'] for row in second[1]['data']['results'])
assert len(second[2]['data']['results']) == 1 and all(row['passed'] for row in second[2]['data']['results'])
assert second[2]['data']['results'][0]['actual'] == ['"NO_PENDING_EMAIL"']
assert len(second[3]['data']['results']) == 191 and all(row['passed'] for row in second[3]['data']['results'])
assert manifest() == after
result = {'schemaVersion': 1, 'passed': True, 'engineeringReplayNotAgentTrial': True,
          'trialTraceSha256': sha(trace.read_bytes()), 'blockedExchange': 24,
          'freshCliSha256': sha(cli.read_bytes()), 'ownerIdPreserved': target_id,
          'ownerRevision': 2, 'manifestFormat': 5,
          'testsRetained': len(new['tests']), 'examplesRetained': len(new['examples']),
          'savedTestsPassedBeforeAndAfterReload': 191,
          'exampleActualBeforeAndAfterReload': '"NO_PENDING_EMAIL"',
          'sourceRefsAndAttachmentBindingsUnchanged': True,
          'retainedAttachmentFormat': {'frontend': 'flow', 'version': 1},
          'replacementResponseCount': len(first), 'reloadResponseCount': len(second)}
(run / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))

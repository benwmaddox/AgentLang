[CmdletBinding()]
param(
    [switch]$CreateArchive,
    [switch]$ReleaseConfirmed
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not $CreateArchive -or -not $ReleaseConfirmed) {
    throw 'Final study 138 packaging requires -CreateArchive -ReleaseConfirmed after coordinator release.'
}

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$inputRelative = '.agentlang/native-reset-138/archive/package-inputs.json'
$inputPath = Join-Path $repoRoot $inputRelative
$inputs = Get-Content -LiteralPath $inputPath -Raw | ConvertFrom-Json
$outputRelative = 'reports/evidence/138-native-reset-profile'
$outputRoot = Join-Path $repoRoot $outputRelative
$archiveName = '138-native-reset-profile.zip'
$archivePath = Join-Path $outputRoot $archiveName
$indexPath = Join-Path $outputRoot 'storage-index.json'
$zipHashPath = Join-Path $outputRoot 'zip.sha256'
$metadataRoot = Join-Path $PSScriptRoot 'metadata'
$beforePath = Join-Path $metadataRoot 'source-integrity-before.json'
$afterPath = Join-Path $metadataRoot 'source-integrity-after.json'
$reconciliationPath = Join-Path $metadataRoot 'source-evidence-reconciliation.json'
$beforeEntry = 'archive-metadata/source-integrity-before.json'
$afterEntry = 'archive-metadata/source-integrity-after.json'
$reconciliationEntry = 'archive-metadata/source-evidence-reconciliation.json'
$manifestEntry = 'archive-metadata/payload-sha256-manifest.json'
$supportFiles = @(
    '.agentlang/native-reset-138/archive/package-plan.md',
    '.agentlang/native-reset-138/archive/package-inputs.json',
    '.agentlang/native-reset-138/archive/Package-Evidence138.ps1'
)
$directoryRoots = [string[]] @($inputs.directoryRoots)
$evidenceInputs = @($inputs.sourceEvidenceJson)
$sourceFiles = [string[]] @($inputs.sourceFiles)
$reportPath = [string] $inputs.reportPath

function Write-JsonFile {
    param([string]$Path, [object]$Value)
    $json = ConvertTo-Json -InputObject $Value -Depth 24
    [System.IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
}

function Get-RelativePath {
    param([Parameter(Mandatory)][string]$Path)
    $full = [System.IO.Path]::GetFullPath($Path)
    $prefix = $repoRoot.TrimEnd([char[]]@('\', '/')) + [System.IO.Path]::DirectorySeparatorChar
    if (-not $full.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
    return $full.Substring($prefix.Length).Replace('\', '/')
}

function Resolve-InputPath {
    param([Parameter(Mandatory)][string]$Path)
    if ([System.IO.Path]::IsPathRooted($Path)) { return [System.IO.Path]::GetFullPath($Path) }
    return [System.IO.Path]::GetFullPath((Join-Path $repoRoot $Path))
}

function Test-ExcludedFile {
    param([System.IO.FileInfo]$File, [string]$RelativePath)
    $normalized = $RelativePath.Replace('\', '/')
    if ($normalized -match '^\.agentlang/native-reset-138/archive(/|$)') { return $true }
    $excludedDirectories = @('.git', '.vs', 'bin', 'obj', 'cache', 'node_modules', '__pycache__', 'temp', 'tmp', 'repo-temp', 'bootstrap-artifacts', 'provider-artifacts')
    foreach ($part in ($normalized -split '/')) {
        if ($excludedDirectories -contains $part.ToLowerInvariant()) { return $true }
    }
    $excludedExtensions = @('.dll', '.exe', '.pdb', '.obj', '.o', '.a', '.lib', '.so', '.dylib', '.bc', '.bin', '.binlog', '.cache', '.nupkg', '.class', '.pyc', '.pyo', '.zip', '.7z', '.tar', '.gz')
    if ($excludedExtensions -contains $File.Extension.ToLowerInvariant()) { return $true }
    if ($File.Extension.ToLowerInvariant() -in @('.pem', '.pfx', '.p12', '.key', '.keystore')) { return $true }
    if ($File.Name -match '^(\.env|credentials|secrets|private-key)(\.|$)') { return $true }
    return $false
}

function Get-RecordedHashRows {
    param([Parameter(Mandatory)][object]$Document, [Parameter(Mandatory)][string]$Label)
    $rows = [System.Collections.Generic.List[object]]::new()
    foreach ($propertyName in @('sourceHashesBefore', 'sourceHashesAfter', 'sourceHashes')) {
        if ($Document.PSObject.Properties.Name -contains $propertyName) {
            foreach ($item in @($Document.$propertyName)) {
                if ($null -ne $item -and $item.PSObject.Properties.Name -contains 'path') {
                    $sha = if ($item.PSObject.Properties.Name -contains 'sha256') { [string]$item.sha256 } else { $null }
                    $rows.Add([pscustomobject]@{ label = $Label; stage = $propertyName; path = [string]$item.path; expectedSha256 = $sha })
                }
            }
        }
    }
    if ($Document.PSObject.Properties.Name -contains 'sourceInputs') {
        foreach ($item in @($Document.sourceInputs)) {
            if ($item -is [string]) { $rows.Add([pscustomobject]@{ label = $Label; stage = 'sourceInputs'; path = [string]$item; expectedSha256 = $null }) }
        }
    }
    return $rows.ToArray()
}

function Test-RunHashStability {
    param([Parameter(Mandatory)][object]$Document)
    if (-not ($Document.PSObject.Properties.Name -contains 'sourceHashesBefore') -or
        -not ($Document.PSObject.Properties.Name -contains 'sourceHashesAfter')) { return $false }
    $afterByPath = [System.Collections.Generic.Dictionary[string, string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($row in @($Document.sourceHashesAfter)) { $afterByPath[[string]$row.path] = [string]$row.sha256 }
    if ($Document.sourceHashesBefore.Count -ne $Document.sourceHashesAfter.Count) { return $false }
    foreach ($row in @($Document.sourceHashesBefore)) {
        if (-not $afterByPath.ContainsKey([string]$row.path) -or $afterByPath[[string]$row.path] -ne [string]$row.sha256) { return $false }
    }
    return $true
}

function Get-SourceHashInventory {
    param([Parameter(Mandatory)][object[]]$Files)
    $records = [System.Collections.Generic.List[object]]::new()
    foreach ($item in $Files) {
        $file = Get-Item -LiteralPath $item.File.FullName
        $records.Add([pscustomobject]@{
            path = $item.Path
            bytes = [long]$file.Length
            sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        })
    }
    return $records.ToArray()
}

function Test-SourceInventoriesEqual {
    param([object[]]$Before, [object[]]$After)
    if ($Before.Count -ne $After.Count) { return $false }
    $afterByPath = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
    foreach ($record in $After) { $afterByPath[$record.path] = $record }
    foreach ($record in $Before) {
        if (-not $afterByPath.ContainsKey($record.path)) { return $false }
        $afterRecord = $afterByPath[$record.path]
        if ($record.bytes -ne $afterRecord.bytes -or $record.sha256 -ne $afterRecord.sha256) { return $false }
    }
    return $true
}

function Get-PayloadSelection {
    $selected = [System.Collections.Generic.Dictionary[string, System.IO.FileInfo]]::new([System.StringComparer]::Ordinal)
    $excludedCount = 0
    [long]$excludedBytes = 0
    $missingSources = [System.Collections.Generic.List[string]]::new()
    $reconciliation = [System.Collections.Generic.List[object]]::new()
    $evidenceSummaries = [System.Collections.Generic.List[object]]::new()

    foreach ($relativeRoot in $directoryRoots) {
        $absoluteRoot = Join-Path $repoRoot $relativeRoot
        if (-not (Test-Path -LiteralPath $absoluteRoot -PathType Container)) { throw "Required evidence directory is missing: $relativeRoot" }
        foreach ($file in Get-ChildItem -LiteralPath $absoluteRoot -File -Recurse -Force) {
            $relative = $file.FullName.Substring($repoRoot.Length).TrimStart('\').Replace('\', '/')
            if (Test-ExcludedFile -File $file -RelativePath $relative) {
                $excludedCount++
                $excludedBytes += $file.Length
                continue
            }
            $selected[$relative] = $file
        }
    }

    $requiredFiles = [System.Collections.Generic.List[string]]::new()
    foreach ($relative in $sourceFiles) { $requiredFiles.Add($relative) }
    $requiredFiles.Add($reportPath)
    foreach ($relative in $supportFiles) { $requiredFiles.Add($relative) }
    foreach ($evidence in $evidenceInputs) { $requiredFiles.Add([string]$evidence.path) }
    foreach ($relative in $requiredFiles) {
        $absolute = Join-Path $repoRoot $relative
        if (-not (Test-Path -LiteralPath $absolute -PathType Leaf)) { throw "Required payload file is missing: $relative" }
        $file = Get-Item -LiteralPath $absolute
        $normalized = $relative.Replace('\', '/')
        if ($supportFiles -contains $normalized) {
            $selected[$normalized] = $file
            continue
        }
        if (Test-ExcludedFile -File $file -RelativePath $normalized) {
            $excludedCount++
            $excludedBytes += $file.Length
            continue
        }
        $selected[$normalized] = $file
    }

    foreach ($evidence in $evidenceInputs) {
        $evidenceRelative = [string]$evidence.path
        $evidenceAbsolute = Join-Path $repoRoot $evidenceRelative
        $document = Get-Content -LiteralPath $evidenceAbsolute -Raw | ConvertFrom-Json
        $rows = @(Get-RecordedHashRows -Document $document -Label ([string]$evidence.label))
        $mismatchCount = 0
        foreach ($row in $rows) {
            $absolute = Resolve-InputPath -Path $row.path
            $relative = Get-RelativePath -Path $absolute
            $currentHash = $null
            $included = $false
            $reason = $null
            if ($null -eq $relative -or -not (Test-Path -LiteralPath $absolute -PathType Leaf)) {
                $missingSources.Add("$($row.label):$($row.stage):$($row.path)")
                $reason = 'not-present-in-current-repository'
            }
            else {
                $file = Get-Item -LiteralPath $absolute
                if (Test-ExcludedFile -File $file -RelativePath $relative) {
                    $reason = 'excluded-build-or-binary'
                }
                else {
                    $selected[$relative] = $file
                    $included = $true
                }
                $currentHash = (Get-FileHash -LiteralPath $absolute -Algorithm SHA256).Hash.ToLowerInvariant()
            }
            $isMatch = if ($null -ne $row.expectedSha256 -and $null -ne $currentHash) { $row.expectedSha256.ToLowerInvariant() -eq $currentHash } else { $null }
            if ($null -ne $isMatch -and -not $isMatch) { $mismatchCount++ }
            $reconciliation.Add([pscustomobject]@{
                evidence = $row.label
                stage = $row.stage
                path = $row.path
                expectedSha256 = $row.expectedSha256
                currentSha256 = $currentHash
                matchesCurrent = $isMatch
                selected = $included
                selectionNote = $reason
            })
        }
        $stable = Test-RunHashStability -Document $document
        $evidenceSummaries.Add([pscustomobject]@{
            label = [string]$evidence.label
            path = $evidenceRelative
            passed = if ($document.PSObject.Properties.Name -contains 'passed') { [bool]$document.passed } elseif ($document.PSObject.Properties.Name -contains 'allNonSanitizerCasesPassed') { [bool]$document.allNonSanitizerCasesPassed } else { $null }
            checks = if ($document.PSObject.Properties.Name -contains 'checks' -and $document.checks -is [array]) { $document.checks.Count } else { $null }
            nativeRuns = if ($document.PSObject.Properties.Name -contains 'nativeRuns') { @($document.nativeRuns).Count } else { $null }
            beforeAfterHashesStable = $stable
            recordedSourceHashCount = $rows.Count
            currentHashMismatchCount = $mismatchCount
        })
        if ([bool]$evidence.requireCurrentMatch -and $mismatchCount -gt 0) {
            throw "Current source bytes differ from released evidence '$($evidence.label)' in $mismatchCount recorded hashes."
        }
        if ([bool]$evidence.requireCurrentMatch -and $rows.Count -eq 0) { throw "Released evidence '$($evidence.label)' has no source inventory." }
    }

    $paths = [string[]]@($selected.Keys)
    [System.Array]::Sort($paths, [System.StringComparer]::Ordinal)
    $ordered = [System.Collections.Generic.List[object]]::new()
    foreach ($path in $paths) { $ordered.Add([pscustomobject]@{ Path = $path; File = $selected[$path] }) }
    return [pscustomobject]@{
        Files = $ordered.ToArray()
        ExcludedFileCount = $excludedCount
        ExcludedBytes = $excludedBytes
        MissingSources = @($missingSources | Sort-Object -Unique)
        Reconciliation = $reconciliation.ToArray()
        EvidenceSummaries = $evidenceSummaries.ToArray()
    }
}

function Add-ZipFileEntry {
    param([System.IO.Compression.ZipArchive]$Zip, [object]$Item)
    $entry = $Zip.CreateEntry($Item.Path, [System.IO.Compression.CompressionLevel]::Optimal)
    $entry.LastWriteTime = [DateTimeOffset]::new([DateTime]::new(2000, 1, 1, 0, 0, 0, [DateTimeKind]::Utc))
    $inputStream = [System.IO.File]::OpenRead($Item.File.FullName)
    try {
        $entryStream = $entry.Open()
        try { $inputStream.CopyTo($entryStream) } finally { $entryStream.Dispose() }
    }
    finally { $inputStream.Dispose() }
}

function Add-ZipTextEntry {
    param([System.IO.Compression.ZipArchive]$Zip, [string]$Path, [byte[]]$Bytes)
    $entry = $Zip.CreateEntry($Path, [System.IO.Compression.CompressionLevel]::Optimal)
    $entry.LastWriteTime = [DateTimeOffset]::new([DateTime]::new(2000, 1, 1, 0, 0, 0, [DateTimeKind]::Utc))
    $stream = $entry.Open()
    try { $stream.Write($Bytes, 0, $Bytes.Length) } finally { $stream.Dispose() }
}

function Get-ZipVerification {
    param([string]$Path, [object[]]$ManifestEntries, [string]$ManifestSha256)
    Add-Type -AssemblyName System.IO.Compression | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null
    $expected = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
    foreach ($record in $ManifestEntries) { $expected[$record.path] = $record }
    $missing = [System.Collections.Generic.List[string]]::new()
    $extra = [System.Collections.Generic.List[string]]::new()
    $mismatches = [System.Collections.Generic.List[object]]::new()
    $verified = 0
    $archiveEntries = 0
    [long]$bytes = 0
    $manifestVerified = $false
    $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        foreach ($entry in $zip.Entries) {
            if ($entry.FullName.EndsWith('/')) { continue }
            $archiveEntries++
            $entryPath = $entry.FullName.Replace('\', '/')
            $stream = $entry.Open()
            try {
                $sha = [System.Security.Cryptography.SHA256]::Create()
                try { $actualHash = [System.BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
                finally { $sha.Dispose() }
            }
            finally { $stream.Dispose() }
            if ($entryPath -eq $manifestEntry) {
                if ($actualHash -eq $ManifestSha256) { $manifestVerified = $true }
                else { $mismatches.Add([pscustomobject]@{ path = $entryPath; expectedSha256 = $ManifestSha256; actualSha256 = $actualHash }) }
                continue
            }
            if (-not $expected.ContainsKey($entryPath)) { $extra.Add($entryPath); continue }
            $record = $expected[$entryPath]
            [void]$expected.Remove($entryPath)
            if ($entry.Length -ne [long]$record.bytes -or $actualHash -ne [string]$record.sha256) {
                $mismatches.Add([pscustomobject]@{ path = $entryPath; expectedBytes = [long]$record.bytes; actualBytes = [long]$entry.Length; expectedSha256 = [string]$record.sha256; actualSha256 = $actualHash })
                continue
            }
            $verified++
            $bytes += $entry.Length
        }
    }
    finally { $zip.Dispose() }
    foreach ($path in $expected.Keys) { $missing.Add($path) }
    return [pscustomobject]@{
        archiveEntryCount = $archiveEntries
        verifiedPayloadEntries = $verified
        uncompressedBytes = $bytes
        embeddedManifestVerified = $manifestVerified
        missingEntries = @($missing | Sort-Object)
        extraEntries = @($extra | Sort-Object)
        hashOrLengthMismatches = $mismatches.ToArray()
        passed = ($missing.Count -eq 0 -and $extra.Count -eq 0 -and $mismatches.Count -eq 0 -and $manifestVerified -and $verified -eq $ManifestEntries.Count -and $archiveEntries -eq ($ManifestEntries.Count + 1))
    }
}

$selection = Get-PayloadSelection
$files = [object[]]$selection.Files
$policyPath = Join-Path $repoRoot '.agentlang/owning-mailbox-002/policy-run-092d7ce060ac469680f8ab6075bb7006/policy-evidence.json'
$failedIoPath = Join-Path $repoRoot '.agentlang/owning-mailbox-003/io-run-6a27d5a8a90841af82053b02bfca6b6f/io-evidence.json'
$intermediateIoPath = Join-Path $repoRoot '.agentlang/owning-mailbox-003/io-run-5dc913d15d044500ad8a04aac85cd989/io-evidence.json'
$finalIoPath = Join-Path $repoRoot '.agentlang/owning-mailbox-003/io-run-4cbaaf69d8cc46b795d63032ecfb756d/io-evidence.json'
$componentPath = Join-Path $repoRoot '.agentlang/native-reset-138/component-validation-final-corrected/component-validation.json'
$policy = Get-Content -LiteralPath $policyPath -Raw | ConvertFrom-Json
$failedIo = Get-Content -LiteralPath $failedIoPath -Raw | ConvertFrom-Json
$intermediateIo = Get-Content -LiteralPath $intermediateIoPath -Raw | ConvertFrom-Json
$finalIo = Get-Content -LiteralPath $finalIoPath -Raw | ConvertFrom-Json
$component = Get-Content -LiteralPath $componentPath -Raw | ConvertFrom-Json
if (-not $policy.passed -or $policy.checks.Count -ne [int]$inputs.expectedPolicyChecks) { throw 'Accepted policy evidence did not match the released 479-check result.' }
if (-not $intermediateIo.passed -or $intermediateIo.checks.Count -ne 139557 -or @($intermediateIo.nativeRuns).Count -ne 8) { throw 'Intermediate real-I/O evidence did not match its recorded passing run.' }
if (-not $finalIo.passed -or $finalIo.checks.Count -ne [int]$inputs.expectedFinalRealIoChecks -or @($finalIo.nativeRuns).Count -ne 8 -or -not (Test-RunHashStability -Document $finalIo)) { throw 'Final real-I/O evidence did not match its released stable 139,765-check result.' }
if ((Test-RunHashStability -Document $failedIo) -or $failedIo.sourceHashesBefore.Count -ne 85) { throw 'The preserved initial real-I/O control no longer shows its recorded integrity failure.' }
if ($component.cases.Count -ne 9 -or -not $component.allNonSanitizerCasesPassed -or -not $component.ubsanCasesPassed) { throw 'Final component validation did not match its released nine-case passing result.' }

if (Test-Path -LiteralPath $outputRoot) { throw "Refusing to overwrite existing evidence output folder: $outputRoot" }
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
New-Item -ItemType Directory -Path $metadataRoot -Force | Out-Null
if (Test-Path -LiteralPath $archivePath) { throw "Refusing to overwrite archive: $archivePath" }

$repositoryRevision = (& git -C $repoRoot rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Could not read the local repository revision.' }
$beforeRecords = Get-SourceHashInventory -Files $files
$beforeBytes = 0L
foreach ($record in $beforeRecords) { $beforeBytes += $record.bytes }
$beforeDocument = [pscustomobject]@{
    schemaVersion = 1
    study = 'native-reset-138'
    phase = 'source-integrity-before'
    capturedUtc = [DateTime]::UtcNow.ToString('o')
    repositoryRevision = $repositoryRevision
    fileCount = $beforeRecords.Count
    totalBytes = $beforeBytes
    files = $beforeRecords
}
Write-JsonFile -Path $beforePath -Value $beforeDocument

Add-Type -AssemblyName System.IO.Compression | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null
$zipStream = [System.IO.File]::Open($archivePath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    $zip = [System.IO.Compression.ZipArchive]::new($zipStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
    try { foreach ($item in $files) { Add-ZipFileEntry -Zip $zip -Item $item } }
    finally { $zip.Dispose() }
}
finally { $zipStream.Dispose() }

$afterSelection = Get-PayloadSelection
$afterFiles = [object[]]$afterSelection.Files
$afterRecords = Get-SourceHashInventory -Files $afterFiles
$sourceMatched = Test-SourceInventoriesEqual -Before $beforeRecords -After $afterRecords
$afterBytes = 0L
foreach ($record in $afterRecords) { $afterBytes += $record.bytes }
$afterDocument = [pscustomobject]@{
    schemaVersion = 1
    study = 'native-reset-138'
    phase = 'source-integrity-after'
    capturedUtc = [DateTime]::UtcNow.ToString('o')
    repositoryRevision = $repositoryRevision
    fileCount = $afterRecords.Count
    totalBytes = $afterBytes
    files = $afterRecords
}
Write-JsonFile -Path $afterPath -Value $afterDocument
$reconciliationDocument = [pscustomobject]@{
    schemaVersion = 1
    study = 'native-reset-138'
    historicalSourceNote = [string]$inputs.historicalSourceNote
    missingOrExternalSourcePaths = $selection.MissingSources
    evidence = $selection.EvidenceSummaries
    sourceHashes = $selection.Reconciliation
}
Write-JsonFile -Path $reconciliationPath -Value $reconciliationDocument

$metadataFiles = @(
    [pscustomobject]@{ Source = $beforePath; Path = $beforeEntry },
    [pscustomobject]@{ Source = $afterPath; Path = $afterEntry },
    [pscustomobject]@{ Source = $reconciliationPath; Path = $reconciliationEntry }
)
$manifestRecords = [System.Collections.Generic.List[object]]::new()
foreach ($record in $beforeRecords) { $manifestRecords.Add($record) }
foreach ($metadata in $metadataFiles) {
    $file = Get-Item -LiteralPath $metadata.Source
    $manifestRecords.Add([pscustomobject]@{
        path = $metadata.Path
        bytes = [long]$file.Length
        sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    })
}
$manifestByPath = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
foreach ($record in $manifestRecords) {
    if ($manifestByPath.ContainsKey($record.path)) { throw "Duplicate payload path: $($record.path)" }
    $manifestByPath[$record.path] = $record
}
$manifestPaths = [string[]]@($manifestByPath.Keys)
[System.Array]::Sort($manifestPaths, [System.StringComparer]::Ordinal)
$sortedManifestEntries = [System.Collections.Generic.List[object]]::new()
foreach ($path in $manifestPaths) { $sortedManifestEntries.Add($manifestByPath[$path]) }
$manifestDocument = [pscustomobject]@{
    schemaVersion = 1
    study = 'native-reset-138'
    archive = $archiveName
    entryCount = $sortedManifestEntries.Count
    uncompressedBytes = [long](($sortedManifestEntries | Measure-Object -Property bytes -Sum).Sum)
    entries = $sortedManifestEntries.ToArray()
}
$manifestJson = ConvertTo-Json -InputObject $manifestDocument -Depth 12
$manifestBytes = [System.Text.UTF8Encoding]::new($false).GetBytes($manifestJson + [Environment]::NewLine)
$manifestSha = [System.Security.Cryptography.SHA256]::Create()
try { $manifestSha256 = [System.BitConverter]::ToString($manifestSha.ComputeHash($manifestBytes)).Replace('-', '').ToLowerInvariant() }
finally { $manifestSha.Dispose() }

$updateStream = [System.IO.File]::Open($archivePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    $updateZip = [System.IO.Compression.ZipArchive]::new($updateStream, [System.IO.Compression.ZipArchiveMode]::Update, $false)
    try {
        foreach ($metadata in $metadataFiles) {
            Add-ZipFileEntry -Zip $updateZip -Item ([pscustomobject]@{ Path = $metadata.Path; File = (Get-Item -LiteralPath $metadata.Source) })
        }
        Add-ZipTextEntry -Zip $updateZip -Path $manifestEntry -Bytes $manifestBytes
    }
    finally { $updateZip.Dispose() }
}
finally { $updateStream.Dispose() }

$verification = Get-ZipVerification -Path $archivePath -ManifestEntries $sortedManifestEntries.ToArray() -ManifestSha256 $manifestSha256
$archiveHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()
$archiveBytes = (Get-Item -LiteralPath $archivePath).Length
$afterVerificationSelection = Get-PayloadSelection
$afterVerificationRecords = Get-SourceHashInventory -Files ([object[]]$afterVerificationSelection.Files)
$sourceStillMatched = Test-SourceInventoriesEqual -Before $afterRecords -After $afterVerificationRecords

$index = [pscustomobject]@{
    schemaVersion = 1
    study = 'native-reset-138'
    createdUtc = [DateTime]::UtcNow.ToString('o')
    repositoryRevision = $repositoryRevision
    archivePath = "$outputRelative/$archiveName"
    archiveBytes = [long]$archiveBytes
    archiveSha256 = $archiveHash
    zipSha256Sidecar = "$outputRelative/zip.sha256"
    archiveEntryCount = $verification.archiveEntryCount
    verifiedPayloadEntryCount = $verification.verifiedPayloadEntries
    embeddedPayloadManifestPath = $manifestEntry
    embeddedPayloadManifestSha256 = $manifestSha256
    embeddedPayloadManifestBytes = [long]$manifestBytes.Length
    sourceIntegrityBeforePath = $beforeEntry
    sourceIntegrityAfterPath = $afterEntry
    sourceIntegrityBeforeFileCount = $beforeRecords.Count
    sourceIntegrityAfterFileCount = $afterRecords.Count
    sourceBytesBefore = [long]$beforeBytes
    sourceBytesAfter = [long]$afterBytes
    sourceIntegrityBeforeAfterMatched = $sourceMatched
    sourceIntegrityStillStableAfterZipVerification = $sourceStillMatched
    payload = [pscustomobject]@{
        verified = $verification.passed
        verifiedPayloadEntries = $verification.verifiedPayloadEntries
        uncompressedBytes = $verification.uncompressedBytes
        missingEntries = $verification.missingEntries
        extraEntries = $verification.extraEntries
        hashOrLengthMismatches = $verification.hashOrLengthMismatches
        excludedBuildOrBinaryFileCount = $selection.ExcludedFileCount
        excludedBuildOrBinaryBytes = [long]$selection.ExcludedBytes
        compiledBinariesIncluded = $false
    }
    finalEvidence = @(
        [pscustomobject]@{ label = 'accepted policy'; checks = $policy.checks.Count; passed = [bool]$policy.passed; evidencePath = '.agentlang/owning-mailbox-002/policy-run-092d7ce060ac469680f8ab6075bb7006/policy-evidence.json' },
        [pscustomobject]@{ label = 'initial real-I/O failed integrity control'; checks = $failedIo.checks.Count; passed = [bool]$failedIo.passed; sourceHashesStable = (Test-RunHashStability -Document $failedIo); evidencePath = '.agentlang/owning-mailbox-003/io-run-6a27d5a8a90841af82053b02bfca6b6f/io-evidence.json' },
        [pscustomobject]@{ label = 'intermediate real-I/O pass'; checks = $intermediateIo.checks.Count; passed = [bool]$intermediateIo.passed; evidencePath = '.agentlang/owning-mailbox-003/io-run-5dc913d15d044500ad8a04aac85cd989/io-evidence.json' },
        [pscustomobject]@{ label = 'final real-I/O pass'; checks = $finalIo.checks.Count; nativeRuns = @($finalIo.nativeRuns).Count; passed = [bool]$finalIo.passed; sourceHashesStable = (Test-RunHashStability -Document $finalIo); evidencePath = '.agentlang/owning-mailbox-003/io-run-4cbaaf69d8cc46b795d63032ecfb756d/io-evidence.json' },
        [pscustomobject]@{ label = 'final component validation'; cases = $component.cases.Count; passed = [bool]$component.allNonSanitizerCasesPassed -and [bool]$component.ubsanCasesPassed; evidencePath = '.agentlang/native-reset-138/component-validation-final-corrected/component-validation.json' }
    )
    sourceUnion = @(
        'source paths referenced by accepted policy, failed/intermediate/final real-I/O, and component evidence',
        'seven changed native/mailbox implementation and verifier source files',
        'final report 138 snapshot'
    )
    limitations = @(
        [string]$inputs.historicalSourceNote,
        'The earlier component link-failure attempt and assertion/temp correction history are included only where raw logs and summaries exist; missing historical raw logs were not reconstructed.'
    )
}
$indexVerified = $verification.passed -and $sourceMatched -and $sourceStillMatched
Write-JsonFile -Path $indexPath -Value $index
[System.IO.File]::WriteAllText($zipHashPath, "$archiveHash  $archiveName" + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
if (-not $indexVerified) { throw 'Archive verification or frozen-source integrity check failed; see storage-index.json for details.' }

[pscustomobject]@{
    archivePath = "$outputRelative/$archiveName"
    archiveBytes = [long]$archiveBytes
    archiveSha256 = $archiveHash
    archiveEntryCount = $verification.archiveEntryCount
    verifiedPayloadEntries = $verification.verifiedPayloadEntries
    sourceFileCountBefore = $beforeRecords.Count
    sourceBytesBefore = $beforeBytes
    sourceFileCountAfter = $afterRecords.Count
    sourceBytesAfter = $afterBytes
    sourceIntegrityMatched = $sourceMatched
    sourceStillStableAfterVerification = $sourceStillMatched
    zipPayloadVerified = $verification.passed
    storageIndexPath = "$outputRelative/storage-index.json"
    storageIndexSha256 = (Get-FileHash -LiteralPath $indexPath -Algorithm SHA256).Hash.ToLowerInvariant()
    storageIndexBytes = (Get-Item -LiteralPath $indexPath).Length
} | ConvertTo-Json -Depth 8

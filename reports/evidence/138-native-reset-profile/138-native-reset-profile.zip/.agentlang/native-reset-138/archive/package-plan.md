# Native reset profile 138 evidence archive

The coordinator released final packaging after component validation, the final real-I/O run, and report 138 reached terminal, stable state.

The selected evidence includes the native-reset study directory (excluding this archive workspace and build/temp directories), the accepted 479-check policy run, the failed initial real-I/O attempt, the intermediate 139,557-check and final 139,765-check successful real-I/O runs, both component link-failure and corrected component attempts, the seven changed native/mailbox source and verifier files, and the final report snapshot. Source snapshots are also selected from the run manifests and component evidence paths.

Runtime binaries, `bin`/`obj`/cache/temp build trees, packages, symbols, and credential/private-key files are excluded. Command arguments, build/run logs, result JSON, generated IR/manifests, and source evidence remain selected. The initial real-I/O integrity-failed attempt is preserved as a failed control; its historical source content will not be reconstructed. The archive will distinguish that recorded hash history from the final source snapshot.

The packager captures sorted source SHA-256/byte inventories before and after packaging, embeds those inventories and a sorted payload hash manifest, reopens the ZIP, and verifies each payload entry. The external evidence folder contains only `storage-index.json` and `zip.sha256` alongside the ZIP.

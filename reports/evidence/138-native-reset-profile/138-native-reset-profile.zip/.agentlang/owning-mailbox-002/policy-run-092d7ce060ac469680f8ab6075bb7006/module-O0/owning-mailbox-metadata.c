#include <stddef.h>
#include <stdint.h>
#define AL_OWNING_MAILBOX_BUILD 1
#include "owning_mailbox_abi.h"

extern const al_owning_layout agentlang_owning_mailbox_layout;
int32_t agentlang_mailbox_initialize(al_owning_stack_context *, const al_owning_external_slice *, uint32_t, al_owning_bank_stack_slice *, uint32_t);
int32_t agentlang_mailbox_begin(al_owning_stack_context *, const al_owning_external_slice *, uint32_t, al_owning_bank_stack_slice *, uint32_t);
int32_t agentlang_mailbox_resume(al_owning_stack_context *, const al_owning_external_slice *, uint32_t, al_owning_bank_stack_slice *, uint32_t);
int32_t agentlang_mailbox_resume_associated(al_owning_stack_context *, const al_owning_bank_stack_slice *, uint32_t, const al_owning_external_slice *, uint32_t, al_owning_bank_stack_slice *, uint32_t);

static const al_owning_mailbox_module al_owning_mailbox_descriptor = {
  AL_OWNING_MAILBOX_ABI_VERSION,
  (uint32_t)sizeof(al_owning_mailbox_module),
  &agentlang_owning_mailbox_layout,
  {
    { 1u, 1u,
      { 4u, 0u, 0u },
      { 3u, 0u },
      &agentlang_mailbox_initialize },
    { 2u, 2u,
      { 3u, 4u, 0u },
      { 3u, 2u },
      &agentlang_mailbox_begin },
    { 3u, 1u,
      { 3u, 2u, 4u },
      { 3u, 0u },
      &agentlang_mailbox_resume }
  },
  &agentlang_mailbox_resume_associated
};

typedef struct al_owning_mailbox_span { uintptr_t begin; uintptr_t end; } al_owning_mailbox_span;
static uint32_t al_owning_mailbox_read_u32(const uint8_t *bytes) {
  uint32_t value;
  uint8_t *value_bytes = (uint8_t *)&value;
  uint32_t byte_index;
  for (byte_index = 0u; byte_index < (uint32_t)sizeof(value); ++byte_index) value_bytes[byte_index] = bytes[byte_index];
  return value;
}

static int al_owning_mailbox_make_span(const void *pointer, uint64_t byte_count, al_owning_mailbox_span *span) {
  uintptr_t begin = (uintptr_t)pointer;
  if (byte_count != 0u && pointer == 0) return 0;
  if (byte_count > (uint64_t)(UINTPTR_MAX - begin)) return 0;
  span->begin = begin;
  span->end = begin + (uintptr_t)byte_count;
  return 1;
}

static int al_owning_mailbox_add_span(al_owning_mailbox_span *spans, uint32_t *count, const void *pointer, uint64_t byte_count) {
  al_owning_mailbox_span candidate;
  uint32_t index;
  if (byte_count == 0u) return 1;
  if (!al_owning_mailbox_make_span(pointer, byte_count, &candidate)) return 0;
  for (index = 0u; index < *count; ++index) {
    if (candidate.begin < spans[index].end && spans[index].begin < candidate.end) return 0;
  }
  if (*count >= 16u) return 0;
  spans[(*count)++] = candidate;
  return 1;
}

static int32_t al_owning_mailbox_preflight_fail(al_owning_stack_context *ctx, uint32_t status, uint32_t error_id, uint32_t required, uint32_t available) {
  al_owning_set_failure(ctx, status, error_id, required, available);
  return 1;
}

int32_t agentlang_owning_mailbox_preflight(al_owning_stack_context *ctx, const al_owning_external_slice *inputs, uint32_t input_count, al_owning_bank_stack_slice *outputs, uint32_t output_capacity, uint32_t entry_index, uint32_t invalid_error, uint32_t input_capacity_error, uint32_t output_capacity_error, uint32_t *out_input_bytes) {
  al_owning_mailbox_span spans[16];
  uint32_t span_count = 0u;
  uint32_t index;
  uint32_t required_bitmap_bytes;
  uint64_t trace_bytes;
  uint64_t type_bytes;
  uint64_t field_bytes;
  uint64_t total_input_bytes = 0u;
  const al_owning_mailbox_module *module = &al_owning_mailbox_descriptor;
  const al_owning_mailbox_entry *entry;
  const al_owning_layout *layout;
  if (ctx == 0) return 1;
  if (ctx->status != AL_OWNING_STATUS_OK) return 1;
  if (ctx->abi_version != AL_OWNING_STACK_ABI_VERSION || ctx->cursor_bytes != 0u || ctx->call_depth != 0u || ((uintptr_t)ctx % _Alignof(al_owning_stack_context)) != 0u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (module->abi_version != AL_OWNING_MAILBOX_ABI_VERSION || module->struct_size != sizeof(*module) || module->layout == 0 || module->associated_resume != agentlang_mailbox_resume_associated || entry_index >= AL_OWNING_MAILBOX_ENTRY_COUNT)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  layout = module->layout;
  if (layout->abi_version != AL_OWNING_LAYOUT_ABI_VERSION || layout->type_count == 0u || layout->type_count > AL_OWNING_LAYOUT_MAX_TYPES || layout->types == 0 || layout->field_count > AL_OWNING_LAYOUT_MAX_FIELDS || (layout->field_count != 0u && layout->fields == 0))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if ((uint64_t)layout->type_count > UINT64_MAX / (uint64_t)sizeof(*layout->types) || (uint64_t)layout->field_count > UINT64_MAX / (uint64_t)sizeof(*layout->fields))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  type_bytes = (uint64_t)layout->type_count * (uint64_t)sizeof(*layout->types);
  field_bytes = (uint64_t)layout->field_count * (uint64_t)sizeof(*layout->fields);
  entry = &module->entries[entry_index];
  if (entry->execute == 0 || entry->input_count != (entry_index == 0u ? 1u : entry_index == 1u ? 2u : 3u) || entry->output_count != (entry_index == 1u ? 2u : 1u) || input_count != entry->input_count)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, entry->input_count, input_count);
  if ((entry_index == 0u && entry->execute != agentlang_mailbox_initialize) || (entry_index == 1u && entry->execute != agentlang_mailbox_begin) || (entry_index == 2u && entry->execute != agentlang_mailbox_resume))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (output_capacity < entry->output_count)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, output_capacity_error, entry->output_count, output_capacity);
  if (entry_index == 0u) {
    if (entry->input_type_indexes[0] != module->entries[1].input_type_indexes[1] || entry->input_type_indexes[0] != module->entries[2].input_type_indexes[2] || entry->output_type_indexes[0] != module->entries[1].input_type_indexes[0] || entry->input_type_indexes[0] >= layout->type_count || entry->output_type_indexes[0] >= layout->type_count || layout->types[entry->input_type_indexes[0]].kind != AL_OWNING_TYPE_STRING || layout->types[entry->output_type_indexes[0]].kind != AL_OWNING_TYPE_RECORD)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  } else if (entry_index == 1u) {
    if (entry->input_type_indexes[0] != module->entries[0].output_type_indexes[0] || entry->input_type_indexes[0] != entry->output_type_indexes[0] || entry->output_type_indexes[0] != module->entries[2].input_type_indexes[0] || entry->input_type_indexes[1] != module->entries[2].input_type_indexes[2] || entry->input_type_indexes[0] >= layout->type_count || entry->input_type_indexes[1] >= layout->type_count || entry->output_type_indexes[1] >= layout->type_count || layout->types[entry->input_type_indexes[0]].kind != AL_OWNING_TYPE_RECORD || layout->types[entry->input_type_indexes[1]].kind != AL_OWNING_TYPE_STRING || layout->types[entry->output_type_indexes[1]].kind != AL_OWNING_TYPE_RECORD)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  } else {
    if (entry->input_type_indexes[0] != module->entries[0].output_type_indexes[0] || entry->input_type_indexes[0] != module->entries[1].output_type_indexes[0] || entry->input_type_indexes[1] != module->entries[1].output_type_indexes[1] || entry->output_type_indexes[0] != entry->input_type_indexes[0] || entry->input_type_indexes[2] >= layout->type_count || entry->input_type_indexes[0] >= layout->type_count || entry->input_type_indexes[1] >= layout->type_count || layout->types[entry->input_type_indexes[0]].kind != AL_OWNING_TYPE_RECORD || layout->types[entry->input_type_indexes[1]].kind != AL_OWNING_TYPE_RECORD || layout->types[entry->input_type_indexes[2]].kind != AL_OWNING_TYPE_STRING)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  }
  for (index = 0u; index < entry->input_count; ++index) {
    uint32_t type_index = entry->input_type_indexes[index];
    if (type_index >= layout->type_count || layout->types[type_index].type_id == 0u)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, type_index, layout->type_count);
  }
  for (index = 0u; index < entry->output_count; ++index) {
    uint32_t type_index = entry->output_type_indexes[index];
    if (type_index >= layout->type_count || layout->types[type_index].type_id == 0u)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, type_index, layout->type_count);
  }
  if (inputs == 0 || outputs == 0 || out_input_bytes == 0 || ((uintptr_t)inputs % _Alignof(al_owning_external_slice)) != 0u || ((uintptr_t)outputs % _Alignof(uint32_t)) != 0u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (ctx->stack_capacity_bytes == 0u || ctx->stack_data == 0)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  required_bitmap_bytes = ctx->stack_capacity_bytes / 8u + (ctx->stack_capacity_bytes % 8u == 0u ? 0u : 1u);
  if (ctx->init_bitmap_bytes < required_bitmap_bytes || ctx->init_bitmap == 0 || ctx->poison_bitmap == 0 || (ctx->trace_event_capacity != 0u && ctx->trace_events == 0))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, required_bitmap_bytes, ctx->init_bitmap_bytes);
  trace_bytes = (uint64_t)ctx->trace_event_capacity * (uint64_t)sizeof(al_owning_stack_event);
  if (!al_owning_mailbox_add_span(spans, &span_count, module, sizeof(*module)) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout, sizeof(*layout)) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout->types, type_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout->fields, field_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx, sizeof(*ctx)) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->stack_data, ctx->stack_capacity_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->init_bitmap, ctx->init_bitmap_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->poison_bitmap, ctx->init_bitmap_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->trace_events, trace_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, inputs, (uint64_t)input_count * sizeof(*inputs)) ||
      !al_owning_mailbox_add_span(spans, &span_count, outputs, (uint64_t)entry->output_count * AL_OWNING_MAILBOX_OUTPUT_SLICE_BYTES))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  for (index = 0u; index < input_count; ++index) {
    const al_owning_external_slice *slice = &inputs[index];
    if (slice->bytes == 0 || slice->extent_bytes == 0u || slice->type_index != entry->input_type_indexes[index] || slice->type_index >= layout->type_count)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, entry->input_type_indexes[index], slice->type_index);
    if (UINT64_MAX - total_input_bytes < slice->extent_bytes)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, input_capacity_error, UINT32_MAX, ctx->stack_capacity_bytes);
    total_input_bytes += slice->extent_bytes;
    if (!al_owning_mailbox_add_span(spans, &span_count, slice->bytes, slice->extent_bytes))
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  }
  if (total_input_bytes > UINT32_MAX || total_input_bytes > ctx->stack_capacity_bytes) {
    uint32_t required = total_input_bytes > UINT32_MAX ? UINT32_MAX : (uint32_t)total_input_bytes;
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_STACK_CAPACITY, input_capacity_error, required, ctx->stack_capacity_bytes);
  }
  *out_input_bytes = (uint32_t)total_input_bytes;
  return 0;
}

int32_t agentlang_owning_mailbox_associated_preflight(al_owning_stack_context *ctx, const al_owning_bank_stack_slice *retained_inputs, uint32_t retained_count, const al_owning_external_slice *completion, uint32_t protected_cursor_bytes, al_owning_bank_stack_slice *outputs, uint32_t output_capacity, uint32_t invalid_error, uint32_t input_capacity_error, uint32_t output_capacity_error) {
  al_owning_mailbox_span spans[16];
  uint32_t span_count = 0u;
  uint32_t index;
  uint32_t required_bitmap_bytes;
  uint64_t trace_bytes;
  uint64_t type_bytes;
  uint64_t field_bytes;
  uint64_t completion_end;
  uint32_t state_index;
  uint32_t continuation_index;
  uint32_t string_index;
  const al_owning_mailbox_module *module = &al_owning_mailbox_descriptor;
  const al_owning_mailbox_entry *resume;
  const al_owning_layout *layout;
  if (ctx == 0) return 1;
  if (ctx->status != AL_OWNING_STATUS_OK) return 1;
  if (ctx->abi_version != AL_OWNING_STACK_ABI_VERSION || protected_cursor_bytes == 0u || ctx->cursor_bytes != protected_cursor_bytes || ctx->call_depth != 0u || ((uintptr_t)ctx % _Alignof(al_owning_stack_context)) != 0u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, protected_cursor_bytes, ctx->cursor_bytes);
  if (module->abi_version != AL_OWNING_MAILBOX_ABI_VERSION || module->struct_size != sizeof(*module) || module->layout == 0 || module->associated_resume != agentlang_mailbox_resume_associated)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  layout = module->layout;
  if (layout->abi_version != AL_OWNING_LAYOUT_ABI_VERSION || layout->type_count == 0u || layout->type_count > AL_OWNING_LAYOUT_MAX_TYPES || layout->types == 0 || layout->field_count > AL_OWNING_LAYOUT_MAX_FIELDS || (layout->field_count != 0u && layout->fields == 0))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if ((uint64_t)layout->type_count > UINT64_MAX / (uint64_t)sizeof(*layout->types) || (uint64_t)layout->field_count > UINT64_MAX / (uint64_t)sizeof(*layout->fields))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  type_bytes = (uint64_t)layout->type_count * (uint64_t)sizeof(*layout->types);
  field_bytes = (uint64_t)layout->field_count * (uint64_t)sizeof(*layout->fields);
  resume = &module->entries[2];
  if (module->entries[0].execute != agentlang_mailbox_initialize || module->entries[0].input_count != 1u || module->entries[0].output_count != 1u || module->entries[1].execute != agentlang_mailbox_begin || module->entries[1].input_count != 2u || module->entries[1].output_count != 2u || resume->execute != agentlang_mailbox_resume || resume->input_count != 3u || resume->output_count != 1u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 3u, resume->input_count);
  state_index = resume->input_type_indexes[0];
  continuation_index = resume->input_type_indexes[1];
  string_index = resume->input_type_indexes[2];
  if (resume->output_type_indexes[0] != state_index || module->entries[0].input_type_indexes[0] != string_index || module->entries[0].output_type_indexes[0] != state_index || module->entries[1].input_type_indexes[0] != state_index || module->entries[1].input_type_indexes[1] != string_index || module->entries[1].output_type_indexes[0] != state_index || module->entries[1].output_type_indexes[1] != continuation_index || state_index >= layout->type_count || continuation_index >= layout->type_count || string_index >= layout->type_count)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (layout->types[state_index].type_id == 0u || layout->types[continuation_index].type_id == 0u || layout->types[string_index].type_id == 0u || layout->types[state_index].kind != AL_OWNING_TYPE_RECORD || layout->types[continuation_index].kind != AL_OWNING_TYPE_RECORD || layout->types[string_index].kind != AL_OWNING_TYPE_STRING)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (retained_count != 2u || output_capacity < 1u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, output_capacity < 1u ? output_capacity_error : invalid_error, retained_count == 2u ? 1u : 2u, retained_count == 2u ? output_capacity : retained_count);
  if (retained_inputs == 0 || completion == 0 || outputs == 0 || ((uintptr_t)retained_inputs % _Alignof(uint32_t)) != 0u || ((uintptr_t)completion % _Alignof(al_owning_external_slice)) != 0u || ((uintptr_t)outputs % _Alignof(uint32_t)) != 0u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  if (ctx->stack_capacity_bytes == 0u || ctx->stack_capacity_bytes > (uint32_t)INT32_MAX || ctx->cursor_bytes > ctx->stack_capacity_bytes || ctx->stack_data == 0 || ((uintptr_t)ctx->stack_data % _Alignof(uint64_t)) != 0u)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  required_bitmap_bytes = ctx->stack_capacity_bytes / 8u + (ctx->stack_capacity_bytes % 8u == 0u ? 0u : 1u);
  if (ctx->init_bitmap_bytes < required_bitmap_bytes || ctx->init_bitmap == 0 || ctx->poison_bitmap == 0 || (ctx->trace_event_capacity != 0u && ctx->trace_events == 0))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, required_bitmap_bytes, ctx->init_bitmap_bytes);
  if ((uint64_t)ctx->trace_event_capacity > UINT64_MAX / (uint64_t)sizeof(al_owning_stack_event))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  trace_bytes = (uint64_t)ctx->trace_event_capacity * (uint64_t)sizeof(al_owning_stack_event);
  if (!al_owning_mailbox_add_span(spans, &span_count, module, sizeof(*module)) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout, sizeof(*layout)) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout->types, type_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, layout->fields, field_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx, sizeof(*ctx)) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->stack_data, ctx->stack_capacity_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->init_bitmap, ctx->init_bitmap_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->poison_bitmap, ctx->init_bitmap_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, ctx->trace_events, trace_bytes) ||
      !al_owning_mailbox_add_span(spans, &span_count, retained_inputs, (uint64_t)retained_count * AL_OWNING_MAILBOX_OUTPUT_SLICE_BYTES) ||
      !al_owning_mailbox_add_span(spans, &span_count, completion, sizeof(*completion)) ||
      !al_owning_mailbox_add_span(spans, &span_count, outputs, (uint64_t)resume->output_count * AL_OWNING_MAILBOX_OUTPUT_SLICE_BYTES))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  for (index = 0u; index < retained_count; ++index) {
    const uint8_t *slice_bytes = (const uint8_t *)retained_inputs + (uint64_t)index * AL_OWNING_MAILBOX_OUTPUT_SLICE_BYTES;
    uint32_t type_index = al_owning_mailbox_read_u32(slice_bytes);
    uint32_t source_offset_bytes = al_owning_mailbox_read_u32(slice_bytes + 4u);
    uint32_t source_owner_end_bytes = al_owning_mailbox_read_u32(slice_bytes + 8u);
    uint32_t reserved = al_owning_mailbox_read_u32(slice_bytes + 12u);
    if (type_index != resume->input_type_indexes[index] || reserved != 0u || source_offset_bytes > source_owner_end_bytes || source_owner_end_bytes > protected_cursor_bytes)
      return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, protected_cursor_bytes, source_owner_end_bytes);
  }
  if (completion->bytes == 0 || completion->extent_bytes == 0u || completion->type_index != string_index)
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, string_index, completion->type_index);
  completion_end = (uint64_t)protected_cursor_bytes + (uint64_t)completion->extent_bytes;
  if (completion_end > UINT32_MAX || completion_end > ctx->stack_capacity_bytes) {
    uint32_t required = completion_end > UINT32_MAX ? UINT32_MAX : (uint32_t)completion_end;
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_STACK_CAPACITY, input_capacity_error, required, ctx->stack_capacity_bytes);
  }
  if (!al_owning_mailbox_add_span(spans, &span_count, completion->bytes, completion->extent_bytes))
    return al_owning_mailbox_preflight_fail(ctx, AL_OWNING_STATUS_INVALID_REQUEST, invalid_error, 0u, 0u);
  return 0;
}

AL_OWNING_MAILBOX_EXPORT const al_owning_mailbox_module *agentlang_owning_mailbox_module(void) {
  return &al_owning_mailbox_descriptor;
}

target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_type_descriptors = private constant [3 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([3 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 3, i32 0 }
@agentlang_root_type_ids = private constant [14 x i32] [i32 0, i32 0, i32 0, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 0]
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %depth.exceeded.24 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %checked.tuple.29 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 9, i64 2)
  %checked.raw.30 = extractvalue { i64, i1 } %checked.tuple.29, 0
  %checked.overflow.31 = extractvalue { i64, i1 } %checked.tuple.29, 1
  br i1 %checked.overflow.31, label %overflow.32, label %checked.33
overflow.32:
  %ctx.field.34 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.35 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 9, ptr %ctx.field.34, align 8
  store i64 2, ptr %ctx.field.35, align 8
  %ctx.field.36 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.36, align 4
  %status.diagnostic.37 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.37, align 4
  ret void
checked.33:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.39 = load i32, ptr %ctx.field.38, align 4
  %steps.next.40 = add i32 %steps.current.39, 1
  store i32 %steps.next.40, ptr %ctx.field.38, align 4
  %steps.over.41 = icmp ugt i32 %steps.next.40, 10000
  br i1 %steps.over.41, label %failure.42, label %continue.43
failure.42:
  %ctx.field.44 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.44, align 4
  %status.diagnostic.45 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.45, align 4
  ret void
continue.43:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.47 = load i32, ptr %ctx.field.46, align 4
  %steps.next.48 = add i32 %steps.current.47, 1
  store i32 %steps.next.48, ptr %ctx.field.46, align 4
  %steps.over.49 = icmp ugt i32 %steps.next.48, 10000
  br i1 %steps.over.49, label %failure.50, label %continue.51
failure.50:
  %ctx.field.52 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.52, align 4
  %status.diagnostic.53 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.53, align 4
  ret void
continue.51:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.55 = load i32, ptr %ctx.field.54, align 4
  %steps.next.56 = add i32 %steps.current.55, 1
  store i32 %steps.next.56, ptr %ctx.field.54, align 4
  %steps.over.57 = icmp ugt i32 %steps.next.56, 10000
  br i1 %steps.over.57, label %failure.58, label %continue.59
failure.58:
  %ctx.field.60 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.60, align 4
  %status.diagnostic.61 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.61, align 4
  ret void
continue.59:
  %depth.exceeded.62 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.62, label %failure.63, label %continue.64
failure.63:
  %ctx.field.65 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.65, align 4
  %status.diagnostic.66 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.66, align 4
  ret void
continue.64:
  %checked.tuple.67 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 6, i64 7)
  %checked.raw.68 = extractvalue { i64, i1 } %checked.tuple.67, 0
  %checked.overflow.69 = extractvalue { i64, i1 } %checked.tuple.67, 1
  br i1 %checked.overflow.69, label %overflow.70, label %checked.71
overflow.70:
  %ctx.field.72 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.73 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 6, ptr %ctx.field.72, align 8
  store i64 7, ptr %ctx.field.73, align 8
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.74, align 4
  %status.diagnostic.75 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.75, align 4
  ret void
checked.71:
  %ctx.field.76 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.77 = load i32, ptr %ctx.field.76, align 4
  %steps.next.78 = add i32 %steps.current.77, 1
  store i32 %steps.next.78, ptr %ctx.field.76, align 4
  %steps.over.79 = icmp ugt i32 %steps.next.78, 10000
  br i1 %steps.over.79, label %failure.80, label %continue.81
failure.80:
  %ctx.field.82 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.82, align 4
  %status.diagnostic.83 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.83, align 4
  ret void
continue.81:
  %ctx.field.84 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.85 = load i32, ptr %ctx.field.84, align 4
  %steps.next.86 = add i32 %steps.current.85, 1
  store i32 %steps.next.86, ptr %ctx.field.84, align 4
  %steps.over.87 = icmp ugt i32 %steps.next.86, 10000
  br i1 %steps.over.87, label %failure.88, label %continue.89
failure.88:
  %ctx.field.90 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.90, align 4
  %status.diagnostic.91 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.91, align 4
  ret void
continue.89:
  %ctx.field.92 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.93 = load i32, ptr %ctx.field.92, align 4
  %steps.next.94 = add i32 %steps.current.93, 1
  store i32 %steps.next.94, ptr %ctx.field.92, align 4
  %steps.over.95 = icmp ugt i32 %steps.next.94, 10000
  br i1 %steps.over.95, label %failure.96, label %continue.97
failure.96:
  %ctx.field.98 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.98, align 4
  %status.diagnostic.99 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.99, align 4
  ret void
continue.97:
  %depth.exceeded.100 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.100, label %failure.101, label %continue.102
failure.101:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.103, align 4
  %status.diagnostic.104 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.104, align 4
  ret void
continue.102:
  %divide.zero.105 = icmp eq i64 3, 0
  br i1 %divide.zero.105, label %failure.106, label %continue.107
failure.106:
  %ctx.field.108 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.108, align 4
  %status.diagnostic.109 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.109, align 4
  ret void
continue.107:
  %divide.min.110 = icmp eq i64 9, -9223372036854775808
  %divide.negative.one.111 = icmp eq i64 3, -1
  %divide.overflow.112 = and i1 %divide.min.110, %divide.negative.one.111
  br i1 %divide.overflow.112, label %failure.113, label %continue.114
failure.113:
  %ctx.field.115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.115, align 4
  %status.diagnostic.116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.116, align 4
  ret void
continue.114:
  %divide.result.117 = sdiv i64 9, 3
  %ctx.field.118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.119 = load i32, ptr %ctx.field.118, align 4
  %steps.next.120 = add i32 %steps.current.119, 1
  store i32 %steps.next.120, ptr %ctx.field.118, align 4
  %steps.over.121 = icmp ugt i32 %steps.next.120, 10000
  br i1 %steps.over.121, label %failure.122, label %continue.123
failure.122:
  %ctx.field.124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.124, align 4
  %status.diagnostic.125 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.125, align 4
  ret void
continue.123:
  %ctx.field.126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.127 = load i32, ptr %ctx.field.126, align 4
  %steps.next.128 = add i32 %steps.current.127, 1
  store i32 %steps.next.128, ptr %ctx.field.126, align 4
  %steps.over.129 = icmp ugt i32 %steps.next.128, 10000
  br i1 %steps.over.129, label %failure.130, label %continue.131
failure.130:
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.132, align 4
  %status.diagnostic.133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.133, align 4
  ret void
continue.131:
  %ctx.field.134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.135 = load i32, ptr %ctx.field.134, align 4
  %steps.next.136 = add i32 %steps.current.135, 1
  store i32 %steps.next.136, ptr %ctx.field.134, align 4
  %steps.over.137 = icmp ugt i32 %steps.next.136, 10000
  br i1 %steps.over.137, label %failure.138, label %continue.139
failure.138:
  %ctx.field.140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.140, align 4
  %status.diagnostic.141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.141, align 4
  ret void
continue.139:
  %depth.exceeded.142 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.142, label %failure.143, label %continue.144
failure.143:
  %ctx.field.145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.145, align 4
  %status.diagnostic.146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.146, align 4
  ret void
continue.144:
  %int.compare.147 = icmp slt i64 1, 2
  %bool.slot.148 = zext i1 %int.compare.147 to i64
  %ctx.field.149 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.150 = load i32, ptr %ctx.field.149, align 4
  %steps.next.151 = add i32 %steps.current.150, 1
  store i32 %steps.next.151, ptr %ctx.field.149, align 4
  %steps.over.152 = icmp ugt i32 %steps.next.151, 10000
  br i1 %steps.over.152, label %failure.153, label %continue.154
failure.153:
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.155, align 4
  %status.diagnostic.156 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.156, align 4
  ret void
continue.154:
  %ctx.field.157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.158 = load i32, ptr %ctx.field.157, align 4
  %steps.next.159 = add i32 %steps.current.158, 1
  store i32 %steps.next.159, ptr %ctx.field.157, align 4
  %steps.over.160 = icmp ugt i32 %steps.next.159, 10000
  br i1 %steps.over.160, label %failure.161, label %continue.162
failure.161:
  %ctx.field.163 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.163, align 4
  %status.diagnostic.164 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.164, align 4
  ret void
continue.162:
  %ctx.field.165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.166 = load i32, ptr %ctx.field.165, align 4
  %steps.next.167 = add i32 %steps.current.166, 1
  store i32 %steps.next.167, ptr %ctx.field.165, align 4
  %steps.over.168 = icmp ugt i32 %steps.next.167, 10000
  br i1 %steps.over.168, label %failure.169, label %continue.170
failure.169:
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.171, align 4
  %status.diagnostic.172 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.172, align 4
  ret void
continue.170:
  %depth.exceeded.173 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.173, label %failure.174, label %continue.175
failure.174:
  %ctx.field.176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.176, align 4
  %status.diagnostic.177 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.177, align 4
  ret void
continue.175:
  %int.compare.178 = icmp sle i64 2, 2
  %bool.slot.179 = zext i1 %int.compare.178 to i64
  %ctx.field.180 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.181 = load i32, ptr %ctx.field.180, align 4
  %steps.next.182 = add i32 %steps.current.181, 1
  store i32 %steps.next.182, ptr %ctx.field.180, align 4
  %steps.over.183 = icmp ugt i32 %steps.next.182, 10000
  br i1 %steps.over.183, label %failure.184, label %continue.185
failure.184:
  %ctx.field.186 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.186, align 4
  %status.diagnostic.187 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.187, align 4
  ret void
continue.185:
  %ctx.field.188 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.189 = load i32, ptr %ctx.field.188, align 4
  %steps.next.190 = add i32 %steps.current.189, 1
  store i32 %steps.next.190, ptr %ctx.field.188, align 4
  %steps.over.191 = icmp ugt i32 %steps.next.190, 10000
  br i1 %steps.over.191, label %failure.192, label %continue.193
failure.192:
  %ctx.field.194 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.194, align 4
  %status.diagnostic.195 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.195, align 4
  ret void
continue.193:
  %ctx.field.196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.197 = load i32, ptr %ctx.field.196, align 4
  %steps.next.198 = add i32 %steps.current.197, 1
  store i32 %steps.next.198, ptr %ctx.field.196, align 4
  %steps.over.199 = icmp ugt i32 %steps.next.198, 10000
  br i1 %steps.over.199, label %failure.200, label %continue.201
failure.200:
  %ctx.field.202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.202, align 4
  %status.diagnostic.203 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.203, align 4
  ret void
continue.201:
  %depth.exceeded.204 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.204, label %failure.205, label %continue.206
failure.205:
  %ctx.field.207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.207, align 4
  %status.diagnostic.208 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.208, align 4
  ret void
continue.206:
  %int.compare.209 = icmp sge i64 3, 2
  %bool.slot.210 = zext i1 %int.compare.209 to i64
  %ctx.field.211 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.212 = load i32, ptr %ctx.field.211, align 4
  %steps.next.213 = add i32 %steps.current.212, 1
  store i32 %steps.next.213, ptr %ctx.field.211, align 4
  %steps.over.214 = icmp ugt i32 %steps.next.213, 10000
  br i1 %steps.over.214, label %failure.215, label %continue.216
failure.215:
  %ctx.field.217 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.217, align 4
  %status.diagnostic.218 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.218, align 4
  ret void
continue.216:
  %ctx.field.219 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.220 = load i32, ptr %ctx.field.219, align 4
  %steps.next.221 = add i32 %steps.current.220, 1
  store i32 %steps.next.221, ptr %ctx.field.219, align 4
  %steps.over.222 = icmp ugt i32 %steps.next.221, 10000
  br i1 %steps.over.222, label %failure.223, label %continue.224
failure.223:
  %ctx.field.225 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.225, align 4
  %status.diagnostic.226 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.226, align 4
  ret void
continue.224:
  %ctx.field.227 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.228 = load i32, ptr %ctx.field.227, align 4
  %steps.next.229 = add i32 %steps.current.228, 1
  store i32 %steps.next.229, ptr %ctx.field.227, align 4
  %steps.over.230 = icmp ugt i32 %steps.next.229, 10000
  br i1 %steps.over.230, label %failure.231, label %continue.232
failure.231:
  %ctx.field.233 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.233, align 4
  %status.diagnostic.234 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.234, align 4
  ret void
continue.232:
  %depth.exceeded.235 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.235, label %failure.236, label %continue.237
failure.236:
  %ctx.field.238 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.238, align 4
  %status.diagnostic.239 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.239, align 4
  ret void
continue.237:
  %scalar.equals.240 = icmp eq i64 42, 42
  %bool.slot.241 = zext i1 %scalar.equals.240 to i64
  %ctx.field.242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.243 = load i32, ptr %ctx.field.242, align 4
  %steps.next.244 = add i32 %steps.current.243, 1
  store i32 %steps.next.244, ptr %ctx.field.242, align 4
  %steps.over.245 = icmp ugt i32 %steps.next.244, 10000
  br i1 %steps.over.245, label %failure.246, label %continue.247
failure.246:
  %ctx.field.248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.248, align 4
  %status.diagnostic.249 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.249, align 4
  ret void
continue.247:
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.251 = load i32, ptr %ctx.field.250, align 4
  %steps.next.252 = add i32 %steps.current.251, 1
  store i32 %steps.next.252, ptr %ctx.field.250, align 4
  %steps.over.253 = icmp ugt i32 %steps.next.252, 10000
  br i1 %steps.over.253, label %failure.254, label %continue.255
failure.254:
  %ctx.field.256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.256, align 4
  %status.diagnostic.257 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.257, align 4
  ret void
continue.255:
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.259 = load i32, ptr %ctx.field.258, align 4
  %steps.next.260 = add i32 %steps.current.259, 1
  store i32 %steps.next.260, ptr %ctx.field.258, align 4
  %steps.over.261 = icmp ugt i32 %steps.next.260, 10000
  br i1 %steps.over.261, label %failure.262, label %continue.263
failure.262:
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.264, align 4
  %status.diagnostic.265 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.265, align 4
  ret void
continue.263:
  %depth.exceeded.266 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.266, label %failure.267, label %continue.268
failure.267:
  %ctx.field.269 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.269, align 4
  %status.diagnostic.270 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.270, align 4
  ret void
continue.268:
  %scalar.equals.271 = icmp eq i64 1, 0
  %bool.slot.272 = zext i1 %scalar.equals.271 to i64
  %ctx.field.273 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.274 = load i32, ptr %ctx.field.273, align 4
  %steps.next.275 = add i32 %steps.current.274, 1
  store i32 %steps.next.275, ptr %ctx.field.273, align 4
  %steps.over.276 = icmp ugt i32 %steps.next.275, 10000
  br i1 %steps.over.276, label %failure.277, label %continue.278
failure.277:
  %ctx.field.279 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.279, align 4
  %status.diagnostic.280 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.280, align 4
  ret void
continue.278:
  %ctx.field.281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.282 = load i32, ptr %ctx.field.281, align 4
  %steps.next.283 = add i32 %steps.current.282, 1
  store i32 %steps.next.283, ptr %ctx.field.281, align 4
  %steps.over.284 = icmp ugt i32 %steps.next.283, 10000
  br i1 %steps.over.284, label %failure.285, label %continue.286
failure.285:
  %ctx.field.287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.287, align 4
  %status.diagnostic.288 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.288, align 4
  ret void
continue.286:
  %ctx.field.289 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.290 = load i32, ptr %ctx.field.289, align 4
  %steps.next.291 = add i32 %steps.current.290, 1
  store i32 %steps.next.291, ptr %ctx.field.289, align 4
  %steps.over.292 = icmp ugt i32 %steps.next.291, 10000
  br i1 %steps.over.292, label %failure.293, label %continue.294
failure.293:
  %ctx.field.295 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.295, align 4
  %status.diagnostic.296 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.296, align 4
  ret void
continue.294:
  %depth.exceeded.297 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.297, label %failure.298, label %continue.299
failure.298:
  %ctx.field.300 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.300, align 4
  %status.diagnostic.301 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.301, align 4
  ret void
continue.299:
  %scalar.equals.302 = icmp eq i64 0, 0
  %bool.slot.303 = zext i1 %scalar.equals.302 to i64
  %ctx.field.304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.305 = load i32, ptr %ctx.field.304, align 4
  %steps.next.306 = add i32 %steps.current.305, 1
  store i32 %steps.next.306, ptr %ctx.field.304, align 4
  %steps.over.307 = icmp ugt i32 %steps.next.306, 10000
  br i1 %steps.over.307, label %failure.308, label %continue.309
failure.308:
  %ctx.field.310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.310, align 4
  %status.diagnostic.311 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.311, align 4
  ret void
continue.309:
  %ctx.field.312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.313 = load i32, ptr %ctx.field.312, align 4
  %steps.next.314 = add i32 %steps.current.313, 1
  store i32 %steps.next.314, ptr %ctx.field.312, align 4
  %steps.over.315 = icmp ugt i32 %steps.next.314, 10000
  br i1 %steps.over.315, label %failure.316, label %continue.317
failure.316:
  %ctx.field.318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.318, align 4
  %status.diagnostic.319 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.319, align 4
  ret void
continue.317:
  %ctx.field.320 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.321 = load i32, ptr %ctx.field.320, align 4
  %steps.next.322 = add i32 %steps.current.321, 1
  store i32 %steps.next.322, ptr %ctx.field.320, align 4
  %steps.over.323 = icmp ugt i32 %steps.next.322, 10000
  br i1 %steps.over.323, label %failure.324, label %continue.325
failure.324:
  %ctx.field.326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.326, align 4
  %status.diagnostic.327 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.327, align 4
  ret void
continue.325:
  %depth.exceeded.328 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.328, label %failure.329, label %continue.330
failure.329:
  %ctx.field.331 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.331, align 4
  %status.diagnostic.332 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.332, align 4
  ret void
continue.330:
  %bool.value.333 = icmp ne i64 1, 0
  %bool.value.334 = icmp ne i64 1, 0
  %bool.logic.335 = and i1 %bool.value.333, %bool.value.334
  %bool.slot.336 = zext i1 %bool.logic.335 to i64
  %ctx.field.337 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.338 = load i32, ptr %ctx.field.337, align 4
  %steps.next.339 = add i32 %steps.current.338, 1
  store i32 %steps.next.339, ptr %ctx.field.337, align 4
  %steps.over.340 = icmp ugt i32 %steps.next.339, 10000
  br i1 %steps.over.340, label %failure.341, label %continue.342
failure.341:
  %ctx.field.343 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.343, align 4
  %status.diagnostic.344 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.344, align 4
  ret void
continue.342:
  %ctx.field.345 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.346 = load i32, ptr %ctx.field.345, align 4
  %steps.next.347 = add i32 %steps.current.346, 1
  store i32 %steps.next.347, ptr %ctx.field.345, align 4
  %steps.over.348 = icmp ugt i32 %steps.next.347, 10000
  br i1 %steps.over.348, label %failure.349, label %continue.350
failure.349:
  %ctx.field.351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.351, align 4
  %status.diagnostic.352 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.352, align 4
  ret void
continue.350:
  %ctx.field.353 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.354 = load i32, ptr %ctx.field.353, align 4
  %steps.next.355 = add i32 %steps.current.354, 1
  store i32 %steps.next.355, ptr %ctx.field.353, align 4
  %steps.over.356 = icmp ugt i32 %steps.next.355, 10000
  br i1 %steps.over.356, label %failure.357, label %continue.358
failure.357:
  %ctx.field.359 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.359, align 4
  %status.diagnostic.360 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.360, align 4
  ret void
continue.358:
  %depth.exceeded.361 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.361, label %failure.362, label %continue.363
failure.362:
  %ctx.field.364 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.364, align 4
  %status.diagnostic.365 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.365, align 4
  ret void
continue.363:
  %bool.value.366 = icmp ne i64 0, 0
  %bool.value.367 = icmp ne i64 1, 0
  %bool.logic.368 = or i1 %bool.value.366, %bool.value.367
  %bool.slot.369 = zext i1 %bool.logic.368 to i64
  %ctx.field.370 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.371 = load i32, ptr %ctx.field.370, align 4
  %steps.next.372 = add i32 %steps.current.371, 1
  store i32 %steps.next.372, ptr %ctx.field.370, align 4
  %steps.over.373 = icmp ugt i32 %steps.next.372, 10000
  br i1 %steps.over.373, label %failure.374, label %continue.375
failure.374:
  %ctx.field.376 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.376, align 4
  %status.diagnostic.377 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.377, align 4
  ret void
continue.375:
  %ctx.field.378 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.379 = load i32, ptr %ctx.field.378, align 4
  %steps.next.380 = add i32 %steps.current.379, 1
  store i32 %steps.next.380, ptr %ctx.field.378, align 4
  %steps.over.381 = icmp ugt i32 %steps.next.380, 10000
  br i1 %steps.over.381, label %failure.382, label %continue.383
failure.382:
  %ctx.field.384 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.384, align 4
  %status.diagnostic.385 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.385, align 4
  ret void
continue.383:
  %depth.exceeded.386 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.386, label %failure.387, label %continue.388
failure.387:
  %ctx.field.389 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.389, align 4
  %status.diagnostic.390 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.390, align 4
  ret void
continue.388:
  %bool.value.391 = icmp ne i64 0, 0
  %bool.not.392 = xor i1 %bool.value.391, true
  %bool.slot.393 = zext i1 %bool.not.392 to i64
  %ctx.field.394 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.395 = load i32, ptr %ctx.field.394, align 4
  %steps.next.396 = add i32 %steps.current.395, 1
  store i32 %steps.next.396, ptr %ctx.field.394, align 4
  %steps.over.397 = icmp ugt i32 %steps.next.396, 10000
  br i1 %steps.over.397, label %failure.398, label %continue.399
failure.398:
  %ctx.field.400 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.400, align 4
  %status.diagnostic.401 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.401, align 4
  ret void
continue.399:
  %ctx.field.402 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.403 = load i32, ptr %ctx.field.402, align 4
  %steps.next.404 = add i32 %steps.current.403, 1
  store i32 %steps.next.404, ptr %ctx.field.402, align 4
  %steps.over.405 = icmp ugt i32 %steps.next.404, 10000
  br i1 %steps.over.405, label %failure.406, label %continue.407
failure.406:
  %ctx.field.408 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.408, align 4
  %status.diagnostic.409 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.409, align 4
  ret void
continue.407:
  %ctx.field.410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.411 = load i32, ptr %ctx.field.410, align 4
  %steps.next.412 = add i32 %steps.current.411, 1
  store i32 %steps.next.412, ptr %ctx.field.410, align 4
  %steps.over.413 = icmp ugt i32 %steps.next.412, 10000
  br i1 %steps.over.413, label %failure.414, label %continue.415
failure.414:
  %ctx.field.416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.416, align 4
  %status.diagnostic.417 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.417, align 4
  ret void
continue.415:
  %depth.exceeded.418 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.418, label %failure.419, label %continue.420
failure.419:
  %ctx.field.421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.421, align 4
  %status.diagnostic.422 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.422, align 4
  ret void
continue.420:
  %output.ptr.423 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %checked.raw.30, ptr %output.ptr.423, align 8
  %output.ptr.424 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %checked.raw.68, ptr %output.ptr.424, align 8
  %output.ptr.425 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %divide.result.117, ptr %output.ptr.425, align 8
  %output.ptr.426 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %bool.slot.148, ptr %output.ptr.426, align 8
  %output.ptr.427 = getelementptr inbounds i64, ptr %outputs, i64 4
  store i64 %bool.slot.179, ptr %output.ptr.427, align 8
  %output.ptr.428 = getelementptr inbounds i64, ptr %outputs, i64 5
  store i64 %bool.slot.210, ptr %output.ptr.428, align 8
  %output.ptr.429 = getelementptr inbounds i64, ptr %outputs, i64 6
  store i64 %bool.slot.241, ptr %output.ptr.429, align 8
  %output.ptr.430 = getelementptr inbounds i64, ptr %outputs, i64 7
  store i64 %bool.slot.272, ptr %output.ptr.430, align 8
  %output.ptr.431 = getelementptr inbounds i64, ptr %outputs, i64 8
  store i64 %bool.slot.303, ptr %output.ptr.431, align 8
  %output.ptr.432 = getelementptr inbounds i64, ptr %outputs, i64 9
  store i64 %bool.slot.336, ptr %output.ptr.432, align 8
  %output.ptr.433 = getelementptr inbounds i64, ptr %outputs, i64 10
  store i64 %bool.slot.369, ptr %output.ptr.433, align 8
  %output.ptr.434 = getelementptr inbounds i64, ptr %outputs, i64 11
  store i64 %bool.slot.393, ptr %output.ptr.434, align 8
  %output.ptr.435 = getelementptr inbounds i64, ptr %outputs, i64 12
  store i64 0, ptr %output.ptr.435, align 8
  %output.ptr.436 = getelementptr inbounds i64, ptr %outputs, i64 13
  store i64 5, ptr %output.ptr.436, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 14 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 14, i32 %capacity, ptr %status, i32 14)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 14, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

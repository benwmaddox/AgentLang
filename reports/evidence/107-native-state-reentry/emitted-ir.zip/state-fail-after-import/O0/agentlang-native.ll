target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [3 x i32] [i32 7, i32 0, i32 1]
@agentlang_fields_4 = private constant [1 x i32] [i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_7 = private constant [2 x i32] [i32 6, i32 4]
@agentlang_type_descriptors = private constant [8 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 3, ptr getelementptr inbounds ([3 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([8 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 8, i32 0 }
@agentlang_root_type_ids = private constant [1 x i32] [i32 0]
@agentlang_input_type_ids = private constant [5 x i32] [i32 3, i32 3, i32 0, i32 1, i32 2]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1, i64 %arg2, i64 %arg3, i64 %arg4) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %ctx.field.13 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.14 = load i32, ptr %ctx.field.13, align 4
  %steps.next.15 = add i32 %steps.current.14, 1
  store i32 %steps.next.15, ptr %ctx.field.13, align 4
  %steps.over.16 = icmp ugt i32 %steps.next.15, 10000
  br i1 %steps.over.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %depth.exceeded.21 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.21, label %failure.22, label %continue.23
failure.22:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.24, align 4
  %status.diagnostic.25 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.25, align 4
  ret void
continue.23:
  %ctx.field.26 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.27 = load i32, ptr %ctx.field.26, align 4
  %steps.next.28 = add i32 %steps.current.27, 1
  store i32 %steps.next.28, ptr %ctx.field.26, align 4
  %steps.over.29 = icmp ugt i32 %steps.next.28, 10000
  br i1 %steps.over.29, label %failure.30, label %continue.31
failure.30:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.32, align 4
  %status.diagnostic.33 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.33, align 4
  ret void
continue.31:
  %depth.exceeded.34 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.40 = load i32, ptr %ctx.field.39, align 4
  %steps.next.41 = add i32 %steps.current.40, 1
  store i32 %steps.next.41, ptr %ctx.field.39, align 4
  %steps.over.42 = icmp ugt i32 %steps.next.41, 10000
  br i1 %steps.over.42, label %failure.43, label %continue.44
failure.43:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.45, align 4
  %status.diagnostic.46 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.46, align 4
  ret void
continue.44:
  %depth.exceeded.47 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.47, label %failure.48, label %continue.49
failure.48:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.50, align 4
  %status.diagnostic.51 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.51, align 4
  ret void
continue.49:
  %ctx.field.52 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.53 = load i32, ptr %ctx.field.52, align 4
  %steps.next.54 = add i32 %steps.current.53, 1
  store i32 %steps.next.54, ptr %ctx.field.52, align 4
  %steps.over.55 = icmp ugt i32 %steps.next.54, 10000
  br i1 %steps.over.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %depth.exceeded.60 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.60, label %failure.61, label %continue.62
failure.61:
  %ctx.field.63 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.63, align 4
  %status.diagnostic.64 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.64, align 4
  ret void
continue.62:
  %ctx.field.65 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.66 = load i32, ptr %ctx.field.65, align 4
  %steps.next.67 = add i32 %steps.current.66, 1
  store i32 %steps.next.67, ptr %ctx.field.65, align 4
  %steps.over.68 = icmp ugt i32 %steps.next.67, 10000
  br i1 %steps.over.68, label %failure.69, label %continue.70
failure.69:
  %ctx.field.71 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.71, align 4
  %status.diagnostic.72 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.72, align 4
  ret void
continue.70:
  %ctx.field.73 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.74 = load i32, ptr %ctx.field.73, align 4
  %steps.next.75 = add i32 %steps.current.74, 1
  store i32 %steps.next.75, ptr %ctx.field.73, align 4
  %steps.over.76 = icmp ugt i32 %steps.next.75, 10000
  br i1 %steps.over.76, label %failure.77, label %continue.78
failure.77:
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.79, align 4
  %status.diagnostic.80 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.80, align 4
  ret void
continue.78:
  %ctx.field.81 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.82 = load i32, ptr %ctx.field.81, align 4
  %steps.next.83 = add i32 %steps.current.82, 1
  store i32 %steps.next.83, ptr %ctx.field.81, align 4
  %steps.over.84 = icmp ugt i32 %steps.next.83, 10000
  br i1 %steps.over.84, label %failure.85, label %continue.86
failure.85:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.87, align 4
  %status.diagnostic.88 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.88, align 4
  ret void
continue.86:
  %depth.exceeded.89 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.89, label %failure.90, label %continue.91
failure.90:
  %ctx.field.92 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.92, align 4
  %status.diagnostic.93 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.93, align 4
  ret void
continue.91:
  %divide.zero.94 = icmp eq i64 0, 0
  br i1 %divide.zero.94, label %failure.95, label %continue.96
failure.95:
  %ctx.field.97 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.97, align 4
  %status.diagnostic.98 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.98, align 4
  ret void
continue.96:
  %divide.min.99 = icmp eq i64 1, -9223372036854775808
  %divide.negative.one.100 = icmp eq i64 0, -1
  %divide.overflow.101 = and i1 %divide.min.99, %divide.negative.one.100
  br i1 %divide.overflow.101, label %failure.102, label %continue.103
failure.102:
  %ctx.field.104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.104, align 4
  %status.diagnostic.105 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.105, align 4
  ret void
continue.103:
  %divide.result.106 = sdiv i64 1, 0
  %output.ptr.107 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %divide.result.106, ptr %output.ptr.107, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 5 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 1, i32 %capacity, ptr %status, i32 5)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr @agentlang_input_type_ids, i32 5)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  %entry.arg0.ptr = getelementptr inbounds i64, ptr %workspace, i64 0
  %entry.arg0 = load i64, ptr %entry.arg0.ptr, align 8
  %entry.arg1.ptr = getelementptr inbounds i64, ptr %workspace, i64 1
  %entry.arg1 = load i64, ptr %entry.arg1.ptr, align 8
  %entry.arg2.ptr = getelementptr inbounds i64, ptr %workspace, i64 2
  %entry.arg2 = load i64, ptr %entry.arg2.ptr, align 8
  %entry.arg3.ptr = getelementptr inbounds i64, ptr %workspace, i64 3
  %entry.arg3 = load i64, ptr %entry.arg3.ptr, align 8
  %entry.arg4.ptr = getelementptr inbounds i64, ptr %workspace, i64 4
  %entry.arg4 = load i64, ptr %entry.arg4.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0, i64 %entry.arg0, i64 %entry.arg1, i64 %entry.arg2, i64 %entry.arg3, i64 %entry.arg4)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 1, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

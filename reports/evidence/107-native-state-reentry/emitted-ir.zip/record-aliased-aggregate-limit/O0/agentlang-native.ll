target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [1 x i32] [i32 0]
@agentlang_fields_4 = private constant [2 x i32] [i32 3, i32 3]
@agentlang_fields_5 = private constant [2 x i32] [i32 4, i32 4]
@agentlang_fields_6 = private constant [2 x i32] [i32 5, i32 5]
@agentlang_fields_7 = private constant [2 x i32] [i32 6, i32 6]
@agentlang_fields_8 = private constant [2 x i32] [i32 7, i32 7]
@agentlang_fields_9 = private constant [2 x i32] [i32 8, i32 8]
@agentlang_fields_10 = private constant [2 x i32] [i32 9, i32 9]
@agentlang_fields_11 = private constant [2 x i32] [i32 10, i32 10]
@agentlang_fields_12 = private constant [2 x i32] [i32 11, i32 11]
@agentlang_fields_13 = private constant [2 x i32] [i32 12, i32 12]
@agentlang_fields_14 = private constant [2 x i32] [i32 13, i32 13]
@agentlang_fields_15 = private constant [2 x i32] [i32 14, i32 14]
@agentlang_fields_16 = private constant [2 x i32] [i32 15, i32 15]
@agentlang_fields_17 = private constant [2 x i32] [i32 16, i32 16]
@agentlang_type_descriptors = private constant [18 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_8, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_9, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_10, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_11, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_12, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_13, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_14, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_15, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_16, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_17, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([18 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 18, i32 0 }
@agentlang_root_type_ids = private constant [1 x i32] [i32 17]
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %workspace.slot.21 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 1, ptr %workspace.slot.21, align 8
  %workspace.slot.22 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.23 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 1, ptr %workspace.slot.22)
  switch i32 %record.make.status.23, label %runtime.invalid.result.29 [ i32 0, label %runtime.success.24 i32 1, label %runtime.invalid.request.25 i32 2, label %runtime.invalid.reference.26 i32 3, label %runtime.scratch.capacity.27 i32 4, label %runtime.retained.capacity.28 ]
runtime.invalid.request.25:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.26:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.27:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.28:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.29:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.24:
  %record.make.handle.30 = load i64, ptr %workspace.slot.22, align 8
  %ctx.field.31 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.32 = load i32, ptr %ctx.field.31, align 4
  %steps.next.33 = add i32 %steps.current.32, 1
  store i32 %steps.next.33, ptr %ctx.field.31, align 4
  %steps.over.34 = icmp ugt i32 %steps.next.33, 10000
  br i1 %steps.over.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %depth.exceeded.39 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.39, label %failure.40, label %continue.41
failure.40:
  %ctx.field.42 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.42, align 4
  %status.diagnostic.43 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.43, align 4
  ret void
continue.41:
  %ctx.field.44 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.45 = load i32, ptr %ctx.field.44, align 4
  %steps.next.46 = add i32 %steps.current.45, 1
  store i32 %steps.next.46, ptr %ctx.field.44, align 4
  %steps.over.47 = icmp ugt i32 %steps.next.46, 10000
  br i1 %steps.over.47, label %failure.48, label %continue.49
failure.48:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.50, align 4
  %status.diagnostic.51 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.51, align 4
  ret void
continue.49:
  %depth.exceeded.52 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.52, label %failure.53, label %continue.54
failure.53:
  %ctx.field.55 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.55, align 4
  %status.diagnostic.56 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.56, align 4
  ret void
continue.54:
  %workspace.slot.57 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.30, ptr %workspace.slot.57, align 8
  %workspace.slot.58 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.30, ptr %workspace.slot.58, align 8
  %workspace.slot.59 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.60 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.59)
  switch i32 %record.make.status.60, label %runtime.invalid.result.66 [ i32 0, label %runtime.success.61 i32 1, label %runtime.invalid.request.62 i32 2, label %runtime.invalid.reference.63 i32 3, label %runtime.scratch.capacity.64 i32 4, label %runtime.retained.capacity.65 ]
runtime.invalid.request.62:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.63:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.64:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.65:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.66:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.61:
  %record.make.handle.67 = load i64, ptr %workspace.slot.59, align 8
  %ctx.field.68 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.69 = load i32, ptr %ctx.field.68, align 4
  %steps.next.70 = add i32 %steps.current.69, 1
  store i32 %steps.next.70, ptr %ctx.field.68, align 4
  %steps.over.71 = icmp ugt i32 %steps.next.70, 10000
  br i1 %steps.over.71, label %failure.72, label %continue.73
failure.72:
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.74, align 4
  %status.diagnostic.75 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.75, align 4
  ret void
continue.73:
  %depth.exceeded.76 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.76, label %failure.77, label %continue.78
failure.77:
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.79, align 4
  %status.diagnostic.80 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.80, align 4
  ret void
continue.78:
  %ctx.field.81 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.82 = load i32, ptr %ctx.field.81, align 4
  %steps.next.83 = add i32 %steps.current.82, 1
  store i32 %steps.next.83, ptr %ctx.field.81, align 4
  %steps.over.84 = icmp ugt i32 %steps.next.83, 10000
  br i1 %steps.over.84, label %failure.85, label %continue.86
failure.85:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.87, align 4
  %status.diagnostic.88 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.88, align 4
  ret void
continue.86:
  %depth.exceeded.89 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.89, label %failure.90, label %continue.91
failure.90:
  %ctx.field.92 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.92, align 4
  %status.diagnostic.93 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.93, align 4
  ret void
continue.91:
  %workspace.slot.94 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.67, ptr %workspace.slot.94, align 8
  %workspace.slot.95 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.67, ptr %workspace.slot.95, align 8
  %workspace.slot.96 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.97 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 2, ptr %workspace.slot.96)
  switch i32 %record.make.status.97, label %runtime.invalid.result.103 [ i32 0, label %runtime.success.98 i32 1, label %runtime.invalid.request.99 i32 2, label %runtime.invalid.reference.100 i32 3, label %runtime.scratch.capacity.101 i32 4, label %runtime.retained.capacity.102 ]
runtime.invalid.request.99:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.100:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.101:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.102:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.103:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.98:
  %record.make.handle.104 = load i64, ptr %workspace.slot.96, align 8
  %ctx.field.105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.106 = load i32, ptr %ctx.field.105, align 4
  %steps.next.107 = add i32 %steps.current.106, 1
  store i32 %steps.next.107, ptr %ctx.field.105, align 4
  %steps.over.108 = icmp ugt i32 %steps.next.107, 10000
  br i1 %steps.over.108, label %failure.109, label %continue.110
failure.109:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.111, align 4
  %status.diagnostic.112 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.112, align 4
  ret void
continue.110:
  %depth.exceeded.113 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.113, label %failure.114, label %continue.115
failure.114:
  %ctx.field.116 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.116, align 4
  %status.diagnostic.117 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.117, align 4
  ret void
continue.115:
  %ctx.field.118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.119 = load i32, ptr %ctx.field.118, align 4
  %steps.next.120 = add i32 %steps.current.119, 1
  store i32 %steps.next.120, ptr %ctx.field.118, align 4
  %steps.over.121 = icmp ugt i32 %steps.next.120, 10000
  br i1 %steps.over.121, label %failure.122, label %continue.123
failure.122:
  %ctx.field.124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.124, align 4
  %status.diagnostic.125 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.125, align 4
  ret void
continue.123:
  %depth.exceeded.126 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.126, label %failure.127, label %continue.128
failure.127:
  %ctx.field.129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.129, align 4
  %status.diagnostic.130 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.130, align 4
  ret void
continue.128:
  %workspace.slot.131 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.104, ptr %workspace.slot.131, align 8
  %workspace.slot.132 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.104, ptr %workspace.slot.132, align 8
  %workspace.slot.133 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.134 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 2, ptr %workspace.slot.133)
  switch i32 %record.make.status.134, label %runtime.invalid.result.140 [ i32 0, label %runtime.success.135 i32 1, label %runtime.invalid.request.136 i32 2, label %runtime.invalid.reference.137 i32 3, label %runtime.scratch.capacity.138 i32 4, label %runtime.retained.capacity.139 ]
runtime.invalid.request.136:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.137:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.138:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.139:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.140:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.135:
  %record.make.handle.141 = load i64, ptr %workspace.slot.133, align 8
  %ctx.field.142 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.143 = load i32, ptr %ctx.field.142, align 4
  %steps.next.144 = add i32 %steps.current.143, 1
  store i32 %steps.next.144, ptr %ctx.field.142, align 4
  %steps.over.145 = icmp ugt i32 %steps.next.144, 10000
  br i1 %steps.over.145, label %failure.146, label %continue.147
failure.146:
  %ctx.field.148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.148, align 4
  %status.diagnostic.149 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.149, align 4
  ret void
continue.147:
  %depth.exceeded.150 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.150, label %failure.151, label %continue.152
failure.151:
  %ctx.field.153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.153, align 4
  %status.diagnostic.154 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.154, align 4
  ret void
continue.152:
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.156 = load i32, ptr %ctx.field.155, align 4
  %steps.next.157 = add i32 %steps.current.156, 1
  store i32 %steps.next.157, ptr %ctx.field.155, align 4
  %steps.over.158 = icmp ugt i32 %steps.next.157, 10000
  br i1 %steps.over.158, label %failure.159, label %continue.160
failure.159:
  %ctx.field.161 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.161, align 4
  %status.diagnostic.162 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.162, align 4
  ret void
continue.160:
  %depth.exceeded.163 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.163, label %failure.164, label %continue.165
failure.164:
  %ctx.field.166 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.166, align 4
  %status.diagnostic.167 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.167, align 4
  ret void
continue.165:
  %workspace.slot.168 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.141, ptr %workspace.slot.168, align 8
  %workspace.slot.169 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.141, ptr %workspace.slot.169, align 8
  %workspace.slot.170 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.171 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 2, ptr %workspace.slot.170)
  switch i32 %record.make.status.171, label %runtime.invalid.result.177 [ i32 0, label %runtime.success.172 i32 1, label %runtime.invalid.request.173 i32 2, label %runtime.invalid.reference.174 i32 3, label %runtime.scratch.capacity.175 i32 4, label %runtime.retained.capacity.176 ]
runtime.invalid.request.173:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.174:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.175:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.176:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.177:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.172:
  %record.make.handle.178 = load i64, ptr %workspace.slot.170, align 8
  %ctx.field.179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.180 = load i32, ptr %ctx.field.179, align 4
  %steps.next.181 = add i32 %steps.current.180, 1
  store i32 %steps.next.181, ptr %ctx.field.179, align 4
  %steps.over.182 = icmp ugt i32 %steps.next.181, 10000
  br i1 %steps.over.182, label %failure.183, label %continue.184
failure.183:
  %ctx.field.185 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.185, align 4
  %status.diagnostic.186 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.186, align 4
  ret void
continue.184:
  %depth.exceeded.187 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.187, label %failure.188, label %continue.189
failure.188:
  %ctx.field.190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.190, align 4
  %status.diagnostic.191 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.191, align 4
  ret void
continue.189:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.193 = load i32, ptr %ctx.field.192, align 4
  %steps.next.194 = add i32 %steps.current.193, 1
  store i32 %steps.next.194, ptr %ctx.field.192, align 4
  %steps.over.195 = icmp ugt i32 %steps.next.194, 10000
  br i1 %steps.over.195, label %failure.196, label %continue.197
failure.196:
  %ctx.field.198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.198, align 4
  %status.diagnostic.199 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.199, align 4
  ret void
continue.197:
  %depth.exceeded.200 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.200, label %failure.201, label %continue.202
failure.201:
  %ctx.field.203 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.203, align 4
  %status.diagnostic.204 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.204, align 4
  ret void
continue.202:
  %workspace.slot.205 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.178, ptr %workspace.slot.205, align 8
  %workspace.slot.206 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.178, ptr %workspace.slot.206, align 8
  %workspace.slot.207 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.208 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 8, ptr %outputs, i32 2, ptr %workspace.slot.207)
  switch i32 %record.make.status.208, label %runtime.invalid.result.214 [ i32 0, label %runtime.success.209 i32 1, label %runtime.invalid.request.210 i32 2, label %runtime.invalid.reference.211 i32 3, label %runtime.scratch.capacity.212 i32 4, label %runtime.retained.capacity.213 ]
runtime.invalid.request.210:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.211:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.212:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.213:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.214:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.209:
  %record.make.handle.215 = load i64, ptr %workspace.slot.207, align 8
  %ctx.field.216 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.217 = load i32, ptr %ctx.field.216, align 4
  %steps.next.218 = add i32 %steps.current.217, 1
  store i32 %steps.next.218, ptr %ctx.field.216, align 4
  %steps.over.219 = icmp ugt i32 %steps.next.218, 10000
  br i1 %steps.over.219, label %failure.220, label %continue.221
failure.220:
  %ctx.field.222 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.222, align 4
  %status.diagnostic.223 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.223, align 4
  ret void
continue.221:
  %depth.exceeded.224 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.224, label %failure.225, label %continue.226
failure.225:
  %ctx.field.227 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.227, align 4
  %status.diagnostic.228 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.228, align 4
  ret void
continue.226:
  %ctx.field.229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.230 = load i32, ptr %ctx.field.229, align 4
  %steps.next.231 = add i32 %steps.current.230, 1
  store i32 %steps.next.231, ptr %ctx.field.229, align 4
  %steps.over.232 = icmp ugt i32 %steps.next.231, 10000
  br i1 %steps.over.232, label %failure.233, label %continue.234
failure.233:
  %ctx.field.235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.235, align 4
  %status.diagnostic.236 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.236, align 4
  ret void
continue.234:
  %depth.exceeded.237 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.237, label %failure.238, label %continue.239
failure.238:
  %ctx.field.240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.240, align 4
  %status.diagnostic.241 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.241, align 4
  ret void
continue.239:
  %workspace.slot.242 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.215, ptr %workspace.slot.242, align 8
  %workspace.slot.243 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.215, ptr %workspace.slot.243, align 8
  %workspace.slot.244 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.245 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 9, ptr %outputs, i32 2, ptr %workspace.slot.244)
  switch i32 %record.make.status.245, label %runtime.invalid.result.251 [ i32 0, label %runtime.success.246 i32 1, label %runtime.invalid.request.247 i32 2, label %runtime.invalid.reference.248 i32 3, label %runtime.scratch.capacity.249 i32 4, label %runtime.retained.capacity.250 ]
runtime.invalid.request.247:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.248:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.249:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.250:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.251:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.246:
  %record.make.handle.252 = load i64, ptr %workspace.slot.244, align 8
  %ctx.field.253 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.254 = load i32, ptr %ctx.field.253, align 4
  %steps.next.255 = add i32 %steps.current.254, 1
  store i32 %steps.next.255, ptr %ctx.field.253, align 4
  %steps.over.256 = icmp ugt i32 %steps.next.255, 10000
  br i1 %steps.over.256, label %failure.257, label %continue.258
failure.257:
  %ctx.field.259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.259, align 4
  %status.diagnostic.260 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.260, align 4
  ret void
continue.258:
  %depth.exceeded.261 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.261, label %failure.262, label %continue.263
failure.262:
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.264, align 4
  %status.diagnostic.265 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.265, align 4
  ret void
continue.263:
  %ctx.field.266 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.267 = load i32, ptr %ctx.field.266, align 4
  %steps.next.268 = add i32 %steps.current.267, 1
  store i32 %steps.next.268, ptr %ctx.field.266, align 4
  %steps.over.269 = icmp ugt i32 %steps.next.268, 10000
  br i1 %steps.over.269, label %failure.270, label %continue.271
failure.270:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.272, align 4
  %status.diagnostic.273 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.273, align 4
  ret void
continue.271:
  %depth.exceeded.274 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.274, label %failure.275, label %continue.276
failure.275:
  %ctx.field.277 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.277, align 4
  %status.diagnostic.278 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.278, align 4
  ret void
continue.276:
  %workspace.slot.279 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.252, ptr %workspace.slot.279, align 8
  %workspace.slot.280 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.252, ptr %workspace.slot.280, align 8
  %workspace.slot.281 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.282 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 10, ptr %outputs, i32 2, ptr %workspace.slot.281)
  switch i32 %record.make.status.282, label %runtime.invalid.result.288 [ i32 0, label %runtime.success.283 i32 1, label %runtime.invalid.request.284 i32 2, label %runtime.invalid.reference.285 i32 3, label %runtime.scratch.capacity.286 i32 4, label %runtime.retained.capacity.287 ]
runtime.invalid.request.284:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.285:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.286:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.287:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.288:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.283:
  %record.make.handle.289 = load i64, ptr %workspace.slot.281, align 8
  %ctx.field.290 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.291 = load i32, ptr %ctx.field.290, align 4
  %steps.next.292 = add i32 %steps.current.291, 1
  store i32 %steps.next.292, ptr %ctx.field.290, align 4
  %steps.over.293 = icmp ugt i32 %steps.next.292, 10000
  br i1 %steps.over.293, label %failure.294, label %continue.295
failure.294:
  %ctx.field.296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.296, align 4
  %status.diagnostic.297 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.297, align 4
  ret void
continue.295:
  %depth.exceeded.298 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.298, label %failure.299, label %continue.300
failure.299:
  %ctx.field.301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.301, align 4
  %status.diagnostic.302 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.302, align 4
  ret void
continue.300:
  %ctx.field.303 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.304 = load i32, ptr %ctx.field.303, align 4
  %steps.next.305 = add i32 %steps.current.304, 1
  store i32 %steps.next.305, ptr %ctx.field.303, align 4
  %steps.over.306 = icmp ugt i32 %steps.next.305, 10000
  br i1 %steps.over.306, label %failure.307, label %continue.308
failure.307:
  %ctx.field.309 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.309, align 4
  %status.diagnostic.310 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.310, align 4
  ret void
continue.308:
  %depth.exceeded.311 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.311, label %failure.312, label %continue.313
failure.312:
  %ctx.field.314 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.314, align 4
  %status.diagnostic.315 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.315, align 4
  ret void
continue.313:
  %workspace.slot.316 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.289, ptr %workspace.slot.316, align 8
  %workspace.slot.317 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.289, ptr %workspace.slot.317, align 8
  %workspace.slot.318 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.319 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 11, ptr %outputs, i32 2, ptr %workspace.slot.318)
  switch i32 %record.make.status.319, label %runtime.invalid.result.325 [ i32 0, label %runtime.success.320 i32 1, label %runtime.invalid.request.321 i32 2, label %runtime.invalid.reference.322 i32 3, label %runtime.scratch.capacity.323 i32 4, label %runtime.retained.capacity.324 ]
runtime.invalid.request.321:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.322:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.323:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.324:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.325:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.320:
  %record.make.handle.326 = load i64, ptr %workspace.slot.318, align 8
  %ctx.field.327 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.328 = load i32, ptr %ctx.field.327, align 4
  %steps.next.329 = add i32 %steps.current.328, 1
  store i32 %steps.next.329, ptr %ctx.field.327, align 4
  %steps.over.330 = icmp ugt i32 %steps.next.329, 10000
  br i1 %steps.over.330, label %failure.331, label %continue.332
failure.331:
  %ctx.field.333 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.333, align 4
  %status.diagnostic.334 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.334, align 4
  ret void
continue.332:
  %depth.exceeded.335 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.335, label %failure.336, label %continue.337
failure.336:
  %ctx.field.338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.338, align 4
  %status.diagnostic.339 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.339, align 4
  ret void
continue.337:
  %ctx.field.340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.341 = load i32, ptr %ctx.field.340, align 4
  %steps.next.342 = add i32 %steps.current.341, 1
  store i32 %steps.next.342, ptr %ctx.field.340, align 4
  %steps.over.343 = icmp ugt i32 %steps.next.342, 10000
  br i1 %steps.over.343, label %failure.344, label %continue.345
failure.344:
  %ctx.field.346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.346, align 4
  %status.diagnostic.347 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.347, align 4
  ret void
continue.345:
  %depth.exceeded.348 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.348, label %failure.349, label %continue.350
failure.349:
  %ctx.field.351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.351, align 4
  %status.diagnostic.352 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.352, align 4
  ret void
continue.350:
  %workspace.slot.353 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.326, ptr %workspace.slot.353, align 8
  %workspace.slot.354 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.326, ptr %workspace.slot.354, align 8
  %workspace.slot.355 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.356 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 12, ptr %outputs, i32 2, ptr %workspace.slot.355)
  switch i32 %record.make.status.356, label %runtime.invalid.result.362 [ i32 0, label %runtime.success.357 i32 1, label %runtime.invalid.request.358 i32 2, label %runtime.invalid.reference.359 i32 3, label %runtime.scratch.capacity.360 i32 4, label %runtime.retained.capacity.361 ]
runtime.invalid.request.358:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.359:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.360:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.361:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.362:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.357:
  %record.make.handle.363 = load i64, ptr %workspace.slot.355, align 8
  %ctx.field.364 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.365 = load i32, ptr %ctx.field.364, align 4
  %steps.next.366 = add i32 %steps.current.365, 1
  store i32 %steps.next.366, ptr %ctx.field.364, align 4
  %steps.over.367 = icmp ugt i32 %steps.next.366, 10000
  br i1 %steps.over.367, label %failure.368, label %continue.369
failure.368:
  %ctx.field.370 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.370, align 4
  %status.diagnostic.371 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.371, align 4
  ret void
continue.369:
  %depth.exceeded.372 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.372, label %failure.373, label %continue.374
failure.373:
  %ctx.field.375 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.375, align 4
  %status.diagnostic.376 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.376, align 4
  ret void
continue.374:
  %ctx.field.377 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.378 = load i32, ptr %ctx.field.377, align 4
  %steps.next.379 = add i32 %steps.current.378, 1
  store i32 %steps.next.379, ptr %ctx.field.377, align 4
  %steps.over.380 = icmp ugt i32 %steps.next.379, 10000
  br i1 %steps.over.380, label %failure.381, label %continue.382
failure.381:
  %ctx.field.383 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.383, align 4
  %status.diagnostic.384 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.384, align 4
  ret void
continue.382:
  %depth.exceeded.385 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.385, label %failure.386, label %continue.387
failure.386:
  %ctx.field.388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.388, align 4
  %status.diagnostic.389 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.389, align 4
  ret void
continue.387:
  %workspace.slot.390 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.363, ptr %workspace.slot.390, align 8
  %workspace.slot.391 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.363, ptr %workspace.slot.391, align 8
  %workspace.slot.392 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.393 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 13, ptr %outputs, i32 2, ptr %workspace.slot.392)
  switch i32 %record.make.status.393, label %runtime.invalid.result.399 [ i32 0, label %runtime.success.394 i32 1, label %runtime.invalid.request.395 i32 2, label %runtime.invalid.reference.396 i32 3, label %runtime.scratch.capacity.397 i32 4, label %runtime.retained.capacity.398 ]
runtime.invalid.request.395:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.396:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.397:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.398:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.399:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.394:
  %record.make.handle.400 = load i64, ptr %workspace.slot.392, align 8
  %ctx.field.401 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.402 = load i32, ptr %ctx.field.401, align 4
  %steps.next.403 = add i32 %steps.current.402, 1
  store i32 %steps.next.403, ptr %ctx.field.401, align 4
  %steps.over.404 = icmp ugt i32 %steps.next.403, 10000
  br i1 %steps.over.404, label %failure.405, label %continue.406
failure.405:
  %ctx.field.407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.407, align 4
  %status.diagnostic.408 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.408, align 4
  ret void
continue.406:
  %depth.exceeded.409 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.409, label %failure.410, label %continue.411
failure.410:
  %ctx.field.412 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.412, align 4
  %status.diagnostic.413 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.413, align 4
  ret void
continue.411:
  %ctx.field.414 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.415 = load i32, ptr %ctx.field.414, align 4
  %steps.next.416 = add i32 %steps.current.415, 1
  store i32 %steps.next.416, ptr %ctx.field.414, align 4
  %steps.over.417 = icmp ugt i32 %steps.next.416, 10000
  br i1 %steps.over.417, label %failure.418, label %continue.419
failure.418:
  %ctx.field.420 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.420, align 4
  %status.diagnostic.421 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.421, align 4
  ret void
continue.419:
  %depth.exceeded.422 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.422, label %failure.423, label %continue.424
failure.423:
  %ctx.field.425 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.425, align 4
  %status.diagnostic.426 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.426, align 4
  ret void
continue.424:
  %workspace.slot.427 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.400, ptr %workspace.slot.427, align 8
  %workspace.slot.428 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.400, ptr %workspace.slot.428, align 8
  %workspace.slot.429 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.430 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 14, ptr %outputs, i32 2, ptr %workspace.slot.429)
  switch i32 %record.make.status.430, label %runtime.invalid.result.436 [ i32 0, label %runtime.success.431 i32 1, label %runtime.invalid.request.432 i32 2, label %runtime.invalid.reference.433 i32 3, label %runtime.scratch.capacity.434 i32 4, label %runtime.retained.capacity.435 ]
runtime.invalid.request.432:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.433:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.434:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.435:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.436:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.431:
  %record.make.handle.437 = load i64, ptr %workspace.slot.429, align 8
  %ctx.field.438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.439 = load i32, ptr %ctx.field.438, align 4
  %steps.next.440 = add i32 %steps.current.439, 1
  store i32 %steps.next.440, ptr %ctx.field.438, align 4
  %steps.over.441 = icmp ugt i32 %steps.next.440, 10000
  br i1 %steps.over.441, label %failure.442, label %continue.443
failure.442:
  %ctx.field.444 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.444, align 4
  %status.diagnostic.445 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.445, align 4
  ret void
continue.443:
  %depth.exceeded.446 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.446, label %failure.447, label %continue.448
failure.447:
  %ctx.field.449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.449, align 4
  %status.diagnostic.450 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.450, align 4
  ret void
continue.448:
  %ctx.field.451 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.452 = load i32, ptr %ctx.field.451, align 4
  %steps.next.453 = add i32 %steps.current.452, 1
  store i32 %steps.next.453, ptr %ctx.field.451, align 4
  %steps.over.454 = icmp ugt i32 %steps.next.453, 10000
  br i1 %steps.over.454, label %failure.455, label %continue.456
failure.455:
  %ctx.field.457 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.457, align 4
  %status.diagnostic.458 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.458, align 4
  ret void
continue.456:
  %depth.exceeded.459 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.459, label %failure.460, label %continue.461
failure.460:
  %ctx.field.462 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.462, align 4
  %status.diagnostic.463 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.463, align 4
  ret void
continue.461:
  %workspace.slot.464 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.437, ptr %workspace.slot.464, align 8
  %workspace.slot.465 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.437, ptr %workspace.slot.465, align 8
  %workspace.slot.466 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.467 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 15, ptr %outputs, i32 2, ptr %workspace.slot.466)
  switch i32 %record.make.status.467, label %runtime.invalid.result.473 [ i32 0, label %runtime.success.468 i32 1, label %runtime.invalid.request.469 i32 2, label %runtime.invalid.reference.470 i32 3, label %runtime.scratch.capacity.471 i32 4, label %runtime.retained.capacity.472 ]
runtime.invalid.request.469:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.470:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.471:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.472:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.473:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.468:
  %record.make.handle.474 = load i64, ptr %workspace.slot.466, align 8
  %ctx.field.475 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.476 = load i32, ptr %ctx.field.475, align 4
  %steps.next.477 = add i32 %steps.current.476, 1
  store i32 %steps.next.477, ptr %ctx.field.475, align 4
  %steps.over.478 = icmp ugt i32 %steps.next.477, 10000
  br i1 %steps.over.478, label %failure.479, label %continue.480
failure.479:
  %ctx.field.481 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.481, align 4
  %status.diagnostic.482 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.482, align 4
  ret void
continue.480:
  %depth.exceeded.483 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.483, label %failure.484, label %continue.485
failure.484:
  %ctx.field.486 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.486, align 4
  %status.diagnostic.487 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.487, align 4
  ret void
continue.485:
  %ctx.field.488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.489 = load i32, ptr %ctx.field.488, align 4
  %steps.next.490 = add i32 %steps.current.489, 1
  store i32 %steps.next.490, ptr %ctx.field.488, align 4
  %steps.over.491 = icmp ugt i32 %steps.next.490, 10000
  br i1 %steps.over.491, label %failure.492, label %continue.493
failure.492:
  %ctx.field.494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.494, align 4
  %status.diagnostic.495 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.495, align 4
  ret void
continue.493:
  %depth.exceeded.496 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.496, label %failure.497, label %continue.498
failure.497:
  %ctx.field.499 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.499, align 4
  %status.diagnostic.500 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.500, align 4
  ret void
continue.498:
  %workspace.slot.501 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.474, ptr %workspace.slot.501, align 8
  %workspace.slot.502 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.474, ptr %workspace.slot.502, align 8
  %workspace.slot.503 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.504 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 16, ptr %outputs, i32 2, ptr %workspace.slot.503)
  switch i32 %record.make.status.504, label %runtime.invalid.result.510 [ i32 0, label %runtime.success.505 i32 1, label %runtime.invalid.request.506 i32 2, label %runtime.invalid.reference.507 i32 3, label %runtime.scratch.capacity.508 i32 4, label %runtime.retained.capacity.509 ]
runtime.invalid.request.506:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.507:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.508:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.509:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.510:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.505:
  %record.make.handle.511 = load i64, ptr %workspace.slot.503, align 8
  %ctx.field.512 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.513 = load i32, ptr %ctx.field.512, align 4
  %steps.next.514 = add i32 %steps.current.513, 1
  store i32 %steps.next.514, ptr %ctx.field.512, align 4
  %steps.over.515 = icmp ugt i32 %steps.next.514, 10000
  br i1 %steps.over.515, label %failure.516, label %continue.517
failure.516:
  %ctx.field.518 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.518, align 4
  %status.diagnostic.519 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.519, align 4
  ret void
continue.517:
  %depth.exceeded.520 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.520, label %failure.521, label %continue.522
failure.521:
  %ctx.field.523 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.523, align 4
  %status.diagnostic.524 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.524, align 4
  ret void
continue.522:
  %ctx.field.525 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.526 = load i32, ptr %ctx.field.525, align 4
  %steps.next.527 = add i32 %steps.current.526, 1
  store i32 %steps.next.527, ptr %ctx.field.525, align 4
  %steps.over.528 = icmp ugt i32 %steps.next.527, 10000
  br i1 %steps.over.528, label %failure.529, label %continue.530
failure.529:
  %ctx.field.531 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.531, align 4
  %status.diagnostic.532 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.532, align 4
  ret void
continue.530:
  %depth.exceeded.533 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.533, label %failure.534, label %continue.535
failure.534:
  %ctx.field.536 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.536, align 4
  %status.diagnostic.537 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.537, align 4
  ret void
continue.535:
  %workspace.slot.538 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.511, ptr %workspace.slot.538, align 8
  %workspace.slot.539 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.511, ptr %workspace.slot.539, align 8
  %workspace.slot.540 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.541 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 17, ptr %outputs, i32 2, ptr %workspace.slot.540)
  switch i32 %record.make.status.541, label %runtime.invalid.result.547 [ i32 0, label %runtime.success.542 i32 1, label %runtime.invalid.request.543 i32 2, label %runtime.invalid.reference.544 i32 3, label %runtime.scratch.capacity.545 i32 4, label %runtime.retained.capacity.546 ]
runtime.invalid.request.543:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.544:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.545:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.546:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.547:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.542:
  %record.make.handle.548 = load i64, ptr %workspace.slot.540, align 8
  %ctx.field.549 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.550 = load i32, ptr %ctx.field.549, align 4
  %steps.next.551 = add i32 %steps.current.550, 1
  store i32 %steps.next.551, ptr %ctx.field.549, align 4
  %steps.over.552 = icmp ugt i32 %steps.next.551, 10000
  br i1 %steps.over.552, label %failure.553, label %continue.554
failure.553:
  %ctx.field.555 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.555, align 4
  %status.diagnostic.556 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.556, align 4
  ret void
continue.554:
  %ctx.field.557 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.558 = load i32, ptr %ctx.field.557, align 4
  %steps.next.559 = add i32 %steps.current.558, 1
  store i32 %steps.next.559, ptr %ctx.field.557, align 4
  %steps.over.560 = icmp ugt i32 %steps.next.559, 10000
  br i1 %steps.over.560, label %failure.561, label %continue.562
failure.561:
  %ctx.field.563 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.563, align 4
  %status.diagnostic.564 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.564, align 4
  ret void
continue.562:
  %ctx.field.565 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.566 = load i32, ptr %ctx.field.565, align 4
  %steps.next.567 = add i32 %steps.current.566, 1
  store i32 %steps.next.567, ptr %ctx.field.565, align 4
  %steps.over.568 = icmp ugt i32 %steps.next.567, 10000
  br i1 %steps.over.568, label %failure.569, label %continue.570
failure.569:
  %ctx.field.571 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.571, align 4
  %status.diagnostic.572 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.572, align 4
  ret void
continue.570:
  %depth.exceeded.573 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.573, label %failure.574, label %continue.575
failure.574:
  %ctx.field.576 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.576, align 4
  %status.diagnostic.577 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.577, align 4
  ret void
continue.575:
  %workspace.slot.578 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 1, ptr %workspace.slot.578, align 8
  %workspace.slot.579 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.580 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 1, ptr %workspace.slot.579)
  switch i32 %record.make.status.580, label %runtime.invalid.result.586 [ i32 0, label %runtime.success.581 i32 1, label %runtime.invalid.request.582 i32 2, label %runtime.invalid.reference.583 i32 3, label %runtime.scratch.capacity.584 i32 4, label %runtime.retained.capacity.585 ]
runtime.invalid.request.582:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.583:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.584:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.585:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.586:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.581:
  %record.make.handle.587 = load i64, ptr %workspace.slot.579, align 8
  %ctx.field.588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.589 = load i32, ptr %ctx.field.588, align 4
  %steps.next.590 = add i32 %steps.current.589, 1
  store i32 %steps.next.590, ptr %ctx.field.588, align 4
  %steps.over.591 = icmp ugt i32 %steps.next.590, 10000
  br i1 %steps.over.591, label %failure.592, label %continue.593
failure.592:
  %ctx.field.594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.594, align 4
  %status.diagnostic.595 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.595, align 4
  ret void
continue.593:
  %depth.exceeded.596 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.596, label %failure.597, label %continue.598
failure.597:
  %ctx.field.599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.599, align 4
  %status.diagnostic.600 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.600, align 4
  ret void
continue.598:
  %ctx.field.601 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.602 = load i32, ptr %ctx.field.601, align 4
  %steps.next.603 = add i32 %steps.current.602, 1
  store i32 %steps.next.603, ptr %ctx.field.601, align 4
  %steps.over.604 = icmp ugt i32 %steps.next.603, 10000
  br i1 %steps.over.604, label %failure.605, label %continue.606
failure.605:
  %ctx.field.607 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.607, align 4
  %status.diagnostic.608 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.608, align 4
  ret void
continue.606:
  %depth.exceeded.609 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.609, label %failure.610, label %continue.611
failure.610:
  %ctx.field.612 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 66, ptr %ctx.field.612, align 4
  %status.diagnostic.613 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.613, align 4
  ret void
continue.611:
  %workspace.slot.614 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.587, ptr %workspace.slot.614, align 8
  %workspace.slot.615 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.587, ptr %workspace.slot.615, align 8
  %workspace.slot.616 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.617 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.616)
  switch i32 %record.make.status.617, label %runtime.invalid.result.623 [ i32 0, label %runtime.success.618 i32 1, label %runtime.invalid.request.619 i32 2, label %runtime.invalid.reference.620 i32 3, label %runtime.scratch.capacity.621 i32 4, label %runtime.retained.capacity.622 ]
runtime.invalid.request.619:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.620:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.621:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.622:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.623:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.618:
  %record.make.handle.624 = load i64, ptr %workspace.slot.616, align 8
  %ctx.field.625 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.626 = load i32, ptr %ctx.field.625, align 4
  %steps.next.627 = add i32 %steps.current.626, 1
  store i32 %steps.next.627, ptr %ctx.field.625, align 4
  %steps.over.628 = icmp ugt i32 %steps.next.627, 10000
  br i1 %steps.over.628, label %failure.629, label %continue.630
failure.629:
  %ctx.field.631 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 67, ptr %ctx.field.631, align 4
  %status.diagnostic.632 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.632, align 4
  ret void
continue.630:
  %depth.exceeded.633 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.633, label %failure.634, label %continue.635
failure.634:
  %ctx.field.636 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 68, ptr %ctx.field.636, align 4
  %status.diagnostic.637 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.637, align 4
  ret void
continue.635:
  %ctx.field.638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.639 = load i32, ptr %ctx.field.638, align 4
  %steps.next.640 = add i32 %steps.current.639, 1
  store i32 %steps.next.640, ptr %ctx.field.638, align 4
  %steps.over.641 = icmp ugt i32 %steps.next.640, 10000
  br i1 %steps.over.641, label %failure.642, label %continue.643
failure.642:
  %ctx.field.644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 69, ptr %ctx.field.644, align 4
  %status.diagnostic.645 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.645, align 4
  ret void
continue.643:
  %depth.exceeded.646 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.646, label %failure.647, label %continue.648
failure.647:
  %ctx.field.649 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 70, ptr %ctx.field.649, align 4
  %status.diagnostic.650 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.650, align 4
  ret void
continue.648:
  %workspace.slot.651 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.624, ptr %workspace.slot.651, align 8
  %workspace.slot.652 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.624, ptr %workspace.slot.652, align 8
  %workspace.slot.653 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.654 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 2, ptr %workspace.slot.653)
  switch i32 %record.make.status.654, label %runtime.invalid.result.660 [ i32 0, label %runtime.success.655 i32 1, label %runtime.invalid.request.656 i32 2, label %runtime.invalid.reference.657 i32 3, label %runtime.scratch.capacity.658 i32 4, label %runtime.retained.capacity.659 ]
runtime.invalid.request.656:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.657:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.658:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.659:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.660:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.655:
  %record.make.handle.661 = load i64, ptr %workspace.slot.653, align 8
  %ctx.field.662 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.663 = load i32, ptr %ctx.field.662, align 4
  %steps.next.664 = add i32 %steps.current.663, 1
  store i32 %steps.next.664, ptr %ctx.field.662, align 4
  %steps.over.665 = icmp ugt i32 %steps.next.664, 10000
  br i1 %steps.over.665, label %failure.666, label %continue.667
failure.666:
  %ctx.field.668 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 71, ptr %ctx.field.668, align 4
  %status.diagnostic.669 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.669, align 4
  ret void
continue.667:
  %depth.exceeded.670 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.670, label %failure.671, label %continue.672
failure.671:
  %ctx.field.673 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 72, ptr %ctx.field.673, align 4
  %status.diagnostic.674 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.674, align 4
  ret void
continue.672:
  %ctx.field.675 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.676 = load i32, ptr %ctx.field.675, align 4
  %steps.next.677 = add i32 %steps.current.676, 1
  store i32 %steps.next.677, ptr %ctx.field.675, align 4
  %steps.over.678 = icmp ugt i32 %steps.next.677, 10000
  br i1 %steps.over.678, label %failure.679, label %continue.680
failure.679:
  %ctx.field.681 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 73, ptr %ctx.field.681, align 4
  %status.diagnostic.682 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.682, align 4
  ret void
continue.680:
  %depth.exceeded.683 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.683, label %failure.684, label %continue.685
failure.684:
  %ctx.field.686 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 74, ptr %ctx.field.686, align 4
  %status.diagnostic.687 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.687, align 4
  ret void
continue.685:
  %workspace.slot.688 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.661, ptr %workspace.slot.688, align 8
  %workspace.slot.689 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.661, ptr %workspace.slot.689, align 8
  %workspace.slot.690 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.691 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 2, ptr %workspace.slot.690)
  switch i32 %record.make.status.691, label %runtime.invalid.result.697 [ i32 0, label %runtime.success.692 i32 1, label %runtime.invalid.request.693 i32 2, label %runtime.invalid.reference.694 i32 3, label %runtime.scratch.capacity.695 i32 4, label %runtime.retained.capacity.696 ]
runtime.invalid.request.693:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.694:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.695:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.696:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.697:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.692:
  %record.make.handle.698 = load i64, ptr %workspace.slot.690, align 8
  %ctx.field.699 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.700 = load i32, ptr %ctx.field.699, align 4
  %steps.next.701 = add i32 %steps.current.700, 1
  store i32 %steps.next.701, ptr %ctx.field.699, align 4
  %steps.over.702 = icmp ugt i32 %steps.next.701, 10000
  br i1 %steps.over.702, label %failure.703, label %continue.704
failure.703:
  %ctx.field.705 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 75, ptr %ctx.field.705, align 4
  %status.diagnostic.706 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.706, align 4
  ret void
continue.704:
  %depth.exceeded.707 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.707, label %failure.708, label %continue.709
failure.708:
  %ctx.field.710 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 76, ptr %ctx.field.710, align 4
  %status.diagnostic.711 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.711, align 4
  ret void
continue.709:
  %ctx.field.712 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.713 = load i32, ptr %ctx.field.712, align 4
  %steps.next.714 = add i32 %steps.current.713, 1
  store i32 %steps.next.714, ptr %ctx.field.712, align 4
  %steps.over.715 = icmp ugt i32 %steps.next.714, 10000
  br i1 %steps.over.715, label %failure.716, label %continue.717
failure.716:
  %ctx.field.718 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 77, ptr %ctx.field.718, align 4
  %status.diagnostic.719 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.719, align 4
  ret void
continue.717:
  %depth.exceeded.720 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.720, label %failure.721, label %continue.722
failure.721:
  %ctx.field.723 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 78, ptr %ctx.field.723, align 4
  %status.diagnostic.724 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.724, align 4
  ret void
continue.722:
  %workspace.slot.725 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.698, ptr %workspace.slot.725, align 8
  %workspace.slot.726 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.698, ptr %workspace.slot.726, align 8
  %workspace.slot.727 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.728 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 2, ptr %workspace.slot.727)
  switch i32 %record.make.status.728, label %runtime.invalid.result.734 [ i32 0, label %runtime.success.729 i32 1, label %runtime.invalid.request.730 i32 2, label %runtime.invalid.reference.731 i32 3, label %runtime.scratch.capacity.732 i32 4, label %runtime.retained.capacity.733 ]
runtime.invalid.request.730:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.731:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.732:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.733:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.734:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.729:
  %record.make.handle.735 = load i64, ptr %workspace.slot.727, align 8
  %ctx.field.736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.737 = load i32, ptr %ctx.field.736, align 4
  %steps.next.738 = add i32 %steps.current.737, 1
  store i32 %steps.next.738, ptr %ctx.field.736, align 4
  %steps.over.739 = icmp ugt i32 %steps.next.738, 10000
  br i1 %steps.over.739, label %failure.740, label %continue.741
failure.740:
  %ctx.field.742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 79, ptr %ctx.field.742, align 4
  %status.diagnostic.743 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.743, align 4
  ret void
continue.741:
  %depth.exceeded.744 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.744, label %failure.745, label %continue.746
failure.745:
  %ctx.field.747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 80, ptr %ctx.field.747, align 4
  %status.diagnostic.748 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.748, align 4
  ret void
continue.746:
  %ctx.field.749 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.750 = load i32, ptr %ctx.field.749, align 4
  %steps.next.751 = add i32 %steps.current.750, 1
  store i32 %steps.next.751, ptr %ctx.field.749, align 4
  %steps.over.752 = icmp ugt i32 %steps.next.751, 10000
  br i1 %steps.over.752, label %failure.753, label %continue.754
failure.753:
  %ctx.field.755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 81, ptr %ctx.field.755, align 4
  %status.diagnostic.756 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.756, align 4
  ret void
continue.754:
  %depth.exceeded.757 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.757, label %failure.758, label %continue.759
failure.758:
  %ctx.field.760 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 82, ptr %ctx.field.760, align 4
  %status.diagnostic.761 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.761, align 4
  ret void
continue.759:
  %workspace.slot.762 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.735, ptr %workspace.slot.762, align 8
  %workspace.slot.763 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.735, ptr %workspace.slot.763, align 8
  %workspace.slot.764 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.765 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 8, ptr %outputs, i32 2, ptr %workspace.slot.764)
  switch i32 %record.make.status.765, label %runtime.invalid.result.771 [ i32 0, label %runtime.success.766 i32 1, label %runtime.invalid.request.767 i32 2, label %runtime.invalid.reference.768 i32 3, label %runtime.scratch.capacity.769 i32 4, label %runtime.retained.capacity.770 ]
runtime.invalid.request.767:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.768:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.769:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.770:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.771:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.766:
  %record.make.handle.772 = load i64, ptr %workspace.slot.764, align 8
  %ctx.field.773 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.774 = load i32, ptr %ctx.field.773, align 4
  %steps.next.775 = add i32 %steps.current.774, 1
  store i32 %steps.next.775, ptr %ctx.field.773, align 4
  %steps.over.776 = icmp ugt i32 %steps.next.775, 10000
  br i1 %steps.over.776, label %failure.777, label %continue.778
failure.777:
  %ctx.field.779 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 83, ptr %ctx.field.779, align 4
  %status.diagnostic.780 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.780, align 4
  ret void
continue.778:
  %depth.exceeded.781 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.781, label %failure.782, label %continue.783
failure.782:
  %ctx.field.784 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 84, ptr %ctx.field.784, align 4
  %status.diagnostic.785 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.785, align 4
  ret void
continue.783:
  %ctx.field.786 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.787 = load i32, ptr %ctx.field.786, align 4
  %steps.next.788 = add i32 %steps.current.787, 1
  store i32 %steps.next.788, ptr %ctx.field.786, align 4
  %steps.over.789 = icmp ugt i32 %steps.next.788, 10000
  br i1 %steps.over.789, label %failure.790, label %continue.791
failure.790:
  %ctx.field.792 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 85, ptr %ctx.field.792, align 4
  %status.diagnostic.793 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.793, align 4
  ret void
continue.791:
  %depth.exceeded.794 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.794, label %failure.795, label %continue.796
failure.795:
  %ctx.field.797 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 86, ptr %ctx.field.797, align 4
  %status.diagnostic.798 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.798, align 4
  ret void
continue.796:
  %workspace.slot.799 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.772, ptr %workspace.slot.799, align 8
  %workspace.slot.800 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.772, ptr %workspace.slot.800, align 8
  %workspace.slot.801 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.802 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 9, ptr %outputs, i32 2, ptr %workspace.slot.801)
  switch i32 %record.make.status.802, label %runtime.invalid.result.808 [ i32 0, label %runtime.success.803 i32 1, label %runtime.invalid.request.804 i32 2, label %runtime.invalid.reference.805 i32 3, label %runtime.scratch.capacity.806 i32 4, label %runtime.retained.capacity.807 ]
runtime.invalid.request.804:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.805:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.806:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.807:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.808:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.803:
  %record.make.handle.809 = load i64, ptr %workspace.slot.801, align 8
  %ctx.field.810 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.811 = load i32, ptr %ctx.field.810, align 4
  %steps.next.812 = add i32 %steps.current.811, 1
  store i32 %steps.next.812, ptr %ctx.field.810, align 4
  %steps.over.813 = icmp ugt i32 %steps.next.812, 10000
  br i1 %steps.over.813, label %failure.814, label %continue.815
failure.814:
  %ctx.field.816 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 87, ptr %ctx.field.816, align 4
  %status.diagnostic.817 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.817, align 4
  ret void
continue.815:
  %depth.exceeded.818 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.818, label %failure.819, label %continue.820
failure.819:
  %ctx.field.821 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 88, ptr %ctx.field.821, align 4
  %status.diagnostic.822 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.822, align 4
  ret void
continue.820:
  %ctx.field.823 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.824 = load i32, ptr %ctx.field.823, align 4
  %steps.next.825 = add i32 %steps.current.824, 1
  store i32 %steps.next.825, ptr %ctx.field.823, align 4
  %steps.over.826 = icmp ugt i32 %steps.next.825, 10000
  br i1 %steps.over.826, label %failure.827, label %continue.828
failure.827:
  %ctx.field.829 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 89, ptr %ctx.field.829, align 4
  %status.diagnostic.830 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.830, align 4
  ret void
continue.828:
  %depth.exceeded.831 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.831, label %failure.832, label %continue.833
failure.832:
  %ctx.field.834 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 90, ptr %ctx.field.834, align 4
  %status.diagnostic.835 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.835, align 4
  ret void
continue.833:
  %workspace.slot.836 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.809, ptr %workspace.slot.836, align 8
  %workspace.slot.837 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.809, ptr %workspace.slot.837, align 8
  %workspace.slot.838 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.839 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 10, ptr %outputs, i32 2, ptr %workspace.slot.838)
  switch i32 %record.make.status.839, label %runtime.invalid.result.845 [ i32 0, label %runtime.success.840 i32 1, label %runtime.invalid.request.841 i32 2, label %runtime.invalid.reference.842 i32 3, label %runtime.scratch.capacity.843 i32 4, label %runtime.retained.capacity.844 ]
runtime.invalid.request.841:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.842:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.843:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.844:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.845:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.840:
  %record.make.handle.846 = load i64, ptr %workspace.slot.838, align 8
  %ctx.field.847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.848 = load i32, ptr %ctx.field.847, align 4
  %steps.next.849 = add i32 %steps.current.848, 1
  store i32 %steps.next.849, ptr %ctx.field.847, align 4
  %steps.over.850 = icmp ugt i32 %steps.next.849, 10000
  br i1 %steps.over.850, label %failure.851, label %continue.852
failure.851:
  %ctx.field.853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 91, ptr %ctx.field.853, align 4
  %status.diagnostic.854 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.854, align 4
  ret void
continue.852:
  %depth.exceeded.855 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.855, label %failure.856, label %continue.857
failure.856:
  %ctx.field.858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 92, ptr %ctx.field.858, align 4
  %status.diagnostic.859 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.859, align 4
  ret void
continue.857:
  %ctx.field.860 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.861 = load i32, ptr %ctx.field.860, align 4
  %steps.next.862 = add i32 %steps.current.861, 1
  store i32 %steps.next.862, ptr %ctx.field.860, align 4
  %steps.over.863 = icmp ugt i32 %steps.next.862, 10000
  br i1 %steps.over.863, label %failure.864, label %continue.865
failure.864:
  %ctx.field.866 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 93, ptr %ctx.field.866, align 4
  %status.diagnostic.867 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.867, align 4
  ret void
continue.865:
  %depth.exceeded.868 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.868, label %failure.869, label %continue.870
failure.869:
  %ctx.field.871 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 94, ptr %ctx.field.871, align 4
  %status.diagnostic.872 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.872, align 4
  ret void
continue.870:
  %workspace.slot.873 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.846, ptr %workspace.slot.873, align 8
  %workspace.slot.874 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.846, ptr %workspace.slot.874, align 8
  %workspace.slot.875 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.876 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 11, ptr %outputs, i32 2, ptr %workspace.slot.875)
  switch i32 %record.make.status.876, label %runtime.invalid.result.882 [ i32 0, label %runtime.success.877 i32 1, label %runtime.invalid.request.878 i32 2, label %runtime.invalid.reference.879 i32 3, label %runtime.scratch.capacity.880 i32 4, label %runtime.retained.capacity.881 ]
runtime.invalid.request.878:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.879:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.880:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.881:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.882:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.877:
  %record.make.handle.883 = load i64, ptr %workspace.slot.875, align 8
  %ctx.field.884 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.885 = load i32, ptr %ctx.field.884, align 4
  %steps.next.886 = add i32 %steps.current.885, 1
  store i32 %steps.next.886, ptr %ctx.field.884, align 4
  %steps.over.887 = icmp ugt i32 %steps.next.886, 10000
  br i1 %steps.over.887, label %failure.888, label %continue.889
failure.888:
  %ctx.field.890 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 95, ptr %ctx.field.890, align 4
  %status.diagnostic.891 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.891, align 4
  ret void
continue.889:
  %depth.exceeded.892 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.892, label %failure.893, label %continue.894
failure.893:
  %ctx.field.895 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 96, ptr %ctx.field.895, align 4
  %status.diagnostic.896 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.896, align 4
  ret void
continue.894:
  %ctx.field.897 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.898 = load i32, ptr %ctx.field.897, align 4
  %steps.next.899 = add i32 %steps.current.898, 1
  store i32 %steps.next.899, ptr %ctx.field.897, align 4
  %steps.over.900 = icmp ugt i32 %steps.next.899, 10000
  br i1 %steps.over.900, label %failure.901, label %continue.902
failure.901:
  %ctx.field.903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 97, ptr %ctx.field.903, align 4
  %status.diagnostic.904 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.904, align 4
  ret void
continue.902:
  %depth.exceeded.905 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.905, label %failure.906, label %continue.907
failure.906:
  %ctx.field.908 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 98, ptr %ctx.field.908, align 4
  %status.diagnostic.909 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.909, align 4
  ret void
continue.907:
  %workspace.slot.910 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.883, ptr %workspace.slot.910, align 8
  %workspace.slot.911 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.883, ptr %workspace.slot.911, align 8
  %workspace.slot.912 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.913 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 12, ptr %outputs, i32 2, ptr %workspace.slot.912)
  switch i32 %record.make.status.913, label %runtime.invalid.result.919 [ i32 0, label %runtime.success.914 i32 1, label %runtime.invalid.request.915 i32 2, label %runtime.invalid.reference.916 i32 3, label %runtime.scratch.capacity.917 i32 4, label %runtime.retained.capacity.918 ]
runtime.invalid.request.915:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.916:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.917:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.918:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.919:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.914:
  %record.make.handle.920 = load i64, ptr %workspace.slot.912, align 8
  %ctx.field.921 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.922 = load i32, ptr %ctx.field.921, align 4
  %steps.next.923 = add i32 %steps.current.922, 1
  store i32 %steps.next.923, ptr %ctx.field.921, align 4
  %steps.over.924 = icmp ugt i32 %steps.next.923, 10000
  br i1 %steps.over.924, label %failure.925, label %continue.926
failure.925:
  %ctx.field.927 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 99, ptr %ctx.field.927, align 4
  %status.diagnostic.928 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.928, align 4
  ret void
continue.926:
  %depth.exceeded.929 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.929, label %failure.930, label %continue.931
failure.930:
  %ctx.field.932 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 100, ptr %ctx.field.932, align 4
  %status.diagnostic.933 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.933, align 4
  ret void
continue.931:
  %ctx.field.934 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.935 = load i32, ptr %ctx.field.934, align 4
  %steps.next.936 = add i32 %steps.current.935, 1
  store i32 %steps.next.936, ptr %ctx.field.934, align 4
  %steps.over.937 = icmp ugt i32 %steps.next.936, 10000
  br i1 %steps.over.937, label %failure.938, label %continue.939
failure.938:
  %ctx.field.940 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 101, ptr %ctx.field.940, align 4
  %status.diagnostic.941 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.941, align 4
  ret void
continue.939:
  %depth.exceeded.942 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.942, label %failure.943, label %continue.944
failure.943:
  %ctx.field.945 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 102, ptr %ctx.field.945, align 4
  %status.diagnostic.946 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.946, align 4
  ret void
continue.944:
  %workspace.slot.947 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.920, ptr %workspace.slot.947, align 8
  %workspace.slot.948 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.920, ptr %workspace.slot.948, align 8
  %workspace.slot.949 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.950 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 13, ptr %outputs, i32 2, ptr %workspace.slot.949)
  switch i32 %record.make.status.950, label %runtime.invalid.result.956 [ i32 0, label %runtime.success.951 i32 1, label %runtime.invalid.request.952 i32 2, label %runtime.invalid.reference.953 i32 3, label %runtime.scratch.capacity.954 i32 4, label %runtime.retained.capacity.955 ]
runtime.invalid.request.952:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.953:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.954:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.955:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.956:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.951:
  %record.make.handle.957 = load i64, ptr %workspace.slot.949, align 8
  %ctx.field.958 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.959 = load i32, ptr %ctx.field.958, align 4
  %steps.next.960 = add i32 %steps.current.959, 1
  store i32 %steps.next.960, ptr %ctx.field.958, align 4
  %steps.over.961 = icmp ugt i32 %steps.next.960, 10000
  br i1 %steps.over.961, label %failure.962, label %continue.963
failure.962:
  %ctx.field.964 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 103, ptr %ctx.field.964, align 4
  %status.diagnostic.965 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.965, align 4
  ret void
continue.963:
  %depth.exceeded.966 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.966, label %failure.967, label %continue.968
failure.967:
  %ctx.field.969 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 104, ptr %ctx.field.969, align 4
  %status.diagnostic.970 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.970, align 4
  ret void
continue.968:
  %ctx.field.971 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.972 = load i32, ptr %ctx.field.971, align 4
  %steps.next.973 = add i32 %steps.current.972, 1
  store i32 %steps.next.973, ptr %ctx.field.971, align 4
  %steps.over.974 = icmp ugt i32 %steps.next.973, 10000
  br i1 %steps.over.974, label %failure.975, label %continue.976
failure.975:
  %ctx.field.977 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 105, ptr %ctx.field.977, align 4
  %status.diagnostic.978 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.978, align 4
  ret void
continue.976:
  %depth.exceeded.979 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.979, label %failure.980, label %continue.981
failure.980:
  %ctx.field.982 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 106, ptr %ctx.field.982, align 4
  %status.diagnostic.983 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.983, align 4
  ret void
continue.981:
  %workspace.slot.984 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.957, ptr %workspace.slot.984, align 8
  %workspace.slot.985 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.957, ptr %workspace.slot.985, align 8
  %workspace.slot.986 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.987 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 14, ptr %outputs, i32 2, ptr %workspace.slot.986)
  switch i32 %record.make.status.987, label %runtime.invalid.result.993 [ i32 0, label %runtime.success.988 i32 1, label %runtime.invalid.request.989 i32 2, label %runtime.invalid.reference.990 i32 3, label %runtime.scratch.capacity.991 i32 4, label %runtime.retained.capacity.992 ]
runtime.invalid.request.989:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.990:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.991:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.992:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.993:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.988:
  %record.make.handle.994 = load i64, ptr %workspace.slot.986, align 8
  %ctx.field.995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.996 = load i32, ptr %ctx.field.995, align 4
  %steps.next.997 = add i32 %steps.current.996, 1
  store i32 %steps.next.997, ptr %ctx.field.995, align 4
  %steps.over.998 = icmp ugt i32 %steps.next.997, 10000
  br i1 %steps.over.998, label %failure.999, label %continue.1000
failure.999:
  %ctx.field.1001 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 107, ptr %ctx.field.1001, align 4
  %status.diagnostic.1002 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1002, align 4
  ret void
continue.1000:
  %depth.exceeded.1003 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1003, label %failure.1004, label %continue.1005
failure.1004:
  %ctx.field.1006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 108, ptr %ctx.field.1006, align 4
  %status.diagnostic.1007 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1007, align 4
  ret void
continue.1005:
  %ctx.field.1008 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1009 = load i32, ptr %ctx.field.1008, align 4
  %steps.next.1010 = add i32 %steps.current.1009, 1
  store i32 %steps.next.1010, ptr %ctx.field.1008, align 4
  %steps.over.1011 = icmp ugt i32 %steps.next.1010, 10000
  br i1 %steps.over.1011, label %failure.1012, label %continue.1013
failure.1012:
  %ctx.field.1014 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 109, ptr %ctx.field.1014, align 4
  %status.diagnostic.1015 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1015, align 4
  ret void
continue.1013:
  %depth.exceeded.1016 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1016, label %failure.1017, label %continue.1018
failure.1017:
  %ctx.field.1019 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 110, ptr %ctx.field.1019, align 4
  %status.diagnostic.1020 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1020, align 4
  ret void
continue.1018:
  %workspace.slot.1021 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.994, ptr %workspace.slot.1021, align 8
  %workspace.slot.1022 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.994, ptr %workspace.slot.1022, align 8
  %workspace.slot.1023 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.1024 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 15, ptr %outputs, i32 2, ptr %workspace.slot.1023)
  switch i32 %record.make.status.1024, label %runtime.invalid.result.1030 [ i32 0, label %runtime.success.1025 i32 1, label %runtime.invalid.request.1026 i32 2, label %runtime.invalid.reference.1027 i32 3, label %runtime.scratch.capacity.1028 i32 4, label %runtime.retained.capacity.1029 ]
runtime.invalid.request.1026:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1027:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1028:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1029:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1030:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1025:
  %record.make.handle.1031 = load i64, ptr %workspace.slot.1023, align 8
  %ctx.field.1032 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1033 = load i32, ptr %ctx.field.1032, align 4
  %steps.next.1034 = add i32 %steps.current.1033, 1
  store i32 %steps.next.1034, ptr %ctx.field.1032, align 4
  %steps.over.1035 = icmp ugt i32 %steps.next.1034, 10000
  br i1 %steps.over.1035, label %failure.1036, label %continue.1037
failure.1036:
  %ctx.field.1038 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 111, ptr %ctx.field.1038, align 4
  %status.diagnostic.1039 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1039, align 4
  ret void
continue.1037:
  %depth.exceeded.1040 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1040, label %failure.1041, label %continue.1042
failure.1041:
  %ctx.field.1043 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 112, ptr %ctx.field.1043, align 4
  %status.diagnostic.1044 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1044, align 4
  ret void
continue.1042:
  br label %value.limit.failure.1045
value.limit.failure.1045:
  %ctx.field.1047 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 113, ptr %ctx.field.1047, align 4
  %status.diagnostic.1048 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1048, align 4
  ret void
value.limit.continue.1046:
  %ctx.field.1049 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1050 = load i32, ptr %ctx.field.1049, align 4
  %steps.next.1051 = add i32 %steps.current.1050, 1
  store i32 %steps.next.1051, ptr %ctx.field.1049, align 4
  %steps.over.1052 = icmp ugt i32 %steps.next.1051, 10000
  br i1 %steps.over.1052, label %failure.1053, label %continue.1054
failure.1053:
  %ctx.field.1055 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 114, ptr %ctx.field.1055, align 4
  %status.diagnostic.1056 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1056, align 4
  ret void
continue.1054:
  %depth.exceeded.1057 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1057, label %failure.1058, label %continue.1059
failure.1058:
  %ctx.field.1060 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 115, ptr %ctx.field.1060, align 4
  %status.diagnostic.1061 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1061, align 4
  ret void
continue.1059:
  %workspace.slot.1062 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1031, ptr %workspace.slot.1062, align 8
  %workspace.slot.1063 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.1031, ptr %workspace.slot.1063, align 8
  %workspace.slot.1064 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.1065 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 16, ptr %outputs, i32 2, ptr %workspace.slot.1064)
  switch i32 %record.make.status.1065, label %runtime.invalid.result.1071 [ i32 0, label %runtime.success.1066 i32 1, label %runtime.invalid.request.1067 i32 2, label %runtime.invalid.reference.1068 i32 3, label %runtime.scratch.capacity.1069 i32 4, label %runtime.retained.capacity.1070 ]
runtime.invalid.request.1067:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1068:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1069:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1070:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1071:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1066:
  %record.make.handle.1072 = load i64, ptr %workspace.slot.1064, align 8
  br label %value.limit.failure.1073
value.limit.failure.1073:
  %ctx.field.1075 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 116, ptr %ctx.field.1075, align 4
  %status.diagnostic.1076 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1076, align 4
  ret void
value.limit.continue.1074:
  %ctx.field.1077 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1078 = load i32, ptr %ctx.field.1077, align 4
  %steps.next.1079 = add i32 %steps.current.1078, 1
  store i32 %steps.next.1079, ptr %ctx.field.1077, align 4
  %steps.over.1080 = icmp ugt i32 %steps.next.1079, 10000
  br i1 %steps.over.1080, label %failure.1081, label %continue.1082
failure.1081:
  %ctx.field.1083 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 117, ptr %ctx.field.1083, align 4
  %status.diagnostic.1084 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1084, align 4
  ret void
continue.1082:
  %depth.exceeded.1085 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1085, label %failure.1086, label %continue.1087
failure.1086:
  %ctx.field.1088 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 118, ptr %ctx.field.1088, align 4
  %status.diagnostic.1089 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1089, align 4
  ret void
continue.1087:
  br label %value.limit.failure.1090
value.limit.failure.1090:
  %ctx.field.1092 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 119, ptr %ctx.field.1092, align 4
  %status.diagnostic.1093 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1093, align 4
  ret void
value.limit.continue.1091:
  %ctx.field.1094 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1095 = load i32, ptr %ctx.field.1094, align 4
  %steps.next.1096 = add i32 %steps.current.1095, 1
  store i32 %steps.next.1096, ptr %ctx.field.1094, align 4
  %steps.over.1097 = icmp ugt i32 %steps.next.1096, 10000
  br i1 %steps.over.1097, label %failure.1098, label %continue.1099
failure.1098:
  %ctx.field.1100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 120, ptr %ctx.field.1100, align 4
  %status.diagnostic.1101 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1101, align 4
  ret void
continue.1099:
  %depth.exceeded.1102 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1102, label %failure.1103, label %continue.1104
failure.1103:
  %ctx.field.1105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 121, ptr %ctx.field.1105, align 4
  %status.diagnostic.1106 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1106, align 4
  ret void
continue.1104:
  %workspace.slot.1107 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1072, ptr %workspace.slot.1107, align 8
  %workspace.slot.1108 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.1072, ptr %workspace.slot.1108, align 8
  %workspace.slot.1109 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.1110 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 17, ptr %outputs, i32 2, ptr %workspace.slot.1109)
  switch i32 %record.make.status.1110, label %runtime.invalid.result.1116 [ i32 0, label %runtime.success.1111 i32 1, label %runtime.invalid.request.1112 i32 2, label %runtime.invalid.reference.1113 i32 3, label %runtime.scratch.capacity.1114 i32 4, label %runtime.retained.capacity.1115 ]
runtime.invalid.request.1112:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1113:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1114:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1115:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1116:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1111:
  %record.make.handle.1117 = load i64, ptr %workspace.slot.1109, align 8
  br label %value.limit.failure.1118
value.limit.failure.1118:
  %ctx.field.1120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 122, ptr %ctx.field.1120, align 4
  %status.diagnostic.1121 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1121, align 4
  ret void
value.limit.continue.1119:
  %output.ptr.1122 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1117, ptr %output.ptr.1122, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 1, i32 %capacity, ptr %status, i32 3)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 1, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

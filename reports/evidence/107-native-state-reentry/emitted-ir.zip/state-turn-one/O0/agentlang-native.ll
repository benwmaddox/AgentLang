target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [3 x i32] [i32 7, i32 0, i32 1]
@agentlang_fields_4 = private constant [1 x i32] [i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_7 = private constant [2 x i32] [i32 6, i32 4]
@agentlang_type_descriptors = private constant [8 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 3, ptr getelementptr inbounds ([3 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([8 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 8, i32 0 }
@agentlang_root_type_ids = private constant [3 x i32] [i32 3, i32 3, i32 7]
@agentlang_input_type_ids = private constant [5 x i32] [i32 3, i32 3, i32 0, i32 1, i32 2]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1, i64 %arg2, i64 %arg3, i64 %arg4) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %ctx.field.13 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.14 = load i32, ptr %ctx.field.13, align 4
  %steps.next.15 = add i32 %steps.current.14, 1
  store i32 %steps.next.15, ptr %ctx.field.13, align 4
  %steps.over.16 = icmp ugt i32 %steps.next.15, 10000
  br i1 %steps.over.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %ctx.field.21 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.22 = load i32, ptr %ctx.field.21, align 4
  %steps.next.23 = add i32 %steps.current.22, 1
  store i32 %steps.next.23, ptr %ctx.field.21, align 4
  %steps.over.24 = icmp ugt i32 %steps.next.23, 10000
  br i1 %steps.over.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %ctx.field.29 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.30 = load i32, ptr %ctx.field.29, align 4
  %steps.next.31 = add i32 %steps.current.30, 1
  store i32 %steps.next.31, ptr %ctx.field.29, align 4
  %steps.over.32 = icmp ugt i32 %steps.next.31, 10000
  br i1 %steps.over.32, label %failure.33, label %continue.34
failure.33:
  %ctx.field.35 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.35, align 4
  %status.diagnostic.36 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.36, align 4
  ret void
continue.34:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.38 = load i32, ptr %ctx.field.37, align 4
  %steps.next.39 = add i32 %steps.current.38, 1
  store i32 %steps.next.39, ptr %ctx.field.37, align 4
  %steps.over.40 = icmp ugt i32 %steps.next.39, 10000
  br i1 %steps.over.40, label %failure.41, label %continue.42
failure.41:
  %ctx.field.43 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.43, align 4
  %status.diagnostic.44 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.44, align 4
  ret void
continue.42:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.46 = load i32, ptr %ctx.field.45, align 4
  %steps.next.47 = add i32 %steps.current.46, 1
  store i32 %steps.next.47, ptr %ctx.field.45, align 4
  %steps.over.48 = icmp ugt i32 %steps.next.47, 10000
  br i1 %steps.over.48, label %failure.49, label %continue.50
failure.49:
  %ctx.field.51 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.51, align 4
  %status.diagnostic.52 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.52, align 4
  ret void
continue.50:
  %ctx.field.53 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.54 = load i32, ptr %ctx.field.53, align 4
  %steps.next.55 = add i32 %steps.current.54, 1
  store i32 %steps.next.55, ptr %ctx.field.53, align 4
  %steps.over.56 = icmp ugt i32 %steps.next.55, 10000
  br i1 %steps.over.56, label %failure.57, label %continue.58
failure.57:
  %ctx.field.59 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.59, align 4
  %status.diagnostic.60 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.60, align 4
  ret void
continue.58:
  %depth.exceeded.61 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.61, label %failure.62, label %continue.63
failure.62:
  %ctx.field.64 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.64, align 4
  %status.diagnostic.65 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.65, align 4
  ret void
continue.63:
  %workspace.slot.66 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.67 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 3, i64 %arg0, i32 0, ptr %workspace.slot.66)
  switch i32 %record.field.status.67, label %runtime.invalid.result.73 [ i32 0, label %runtime.success.68 i32 1, label %runtime.invalid.request.69 i32 2, label %runtime.invalid.reference.70 i32 3, label %runtime.scratch.capacity.71 i32 4, label %runtime.retained.capacity.72 ]
runtime.invalid.request.69:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.70:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.71:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.72:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.73:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.68:
  %record.field.value.74 = load i64, ptr %workspace.slot.66, align 8
  %ctx.field.75 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.76 = load i32, ptr %ctx.field.75, align 4
  %steps.next.77 = add i32 %steps.current.76, 1
  store i32 %steps.next.77, ptr %ctx.field.75, align 4
  %steps.over.78 = icmp ugt i32 %steps.next.77, 10000
  br i1 %steps.over.78, label %failure.79, label %continue.80
failure.79:
  %ctx.field.81 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.81, align 4
  %status.diagnostic.82 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.82, align 4
  ret void
continue.80:
  %ctx.field.83 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.84 = load i32, ptr %ctx.field.83, align 4
  %steps.next.85 = add i32 %steps.current.84, 1
  store i32 %steps.next.85, ptr %ctx.field.83, align 4
  %steps.over.86 = icmp ugt i32 %steps.next.85, 10000
  br i1 %steps.over.86, label %failure.87, label %continue.88
failure.87:
  %ctx.field.89 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.89, align 4
  %status.diagnostic.90 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.90, align 4
  ret void
continue.88:
  %ctx.field.91 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.92 = load i32, ptr %ctx.field.91, align 4
  %steps.next.93 = add i32 %steps.current.92, 1
  store i32 %steps.next.93, ptr %ctx.field.91, align 4
  %steps.over.94 = icmp ugt i32 %steps.next.93, 10000
  br i1 %steps.over.94, label %failure.95, label %continue.96
failure.95:
  %ctx.field.97 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.97, align 4
  %status.diagnostic.98 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.98, align 4
  ret void
continue.96:
  %ctx.field.99 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.100 = load i32, ptr %ctx.field.99, align 4
  %steps.next.101 = add i32 %steps.current.100, 1
  store i32 %steps.next.101, ptr %ctx.field.99, align 4
  %steps.over.102 = icmp ugt i32 %steps.next.101, 10000
  br i1 %steps.over.102, label %failure.103, label %continue.104
failure.103:
  %ctx.field.105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.105, align 4
  %status.diagnostic.106 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.106, align 4
  ret void
continue.104:
  %depth.exceeded.107 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.107, label %failure.108, label %continue.109
failure.108:
  %ctx.field.110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.110, align 4
  %status.diagnostic.111 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.111, align 4
  ret void
continue.109:
  %workspace.slot.112 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.113 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 3, i64 %arg0, i32 1, ptr %workspace.slot.112)
  switch i32 %record.field.status.113, label %runtime.invalid.result.119 [ i32 0, label %runtime.success.114 i32 1, label %runtime.invalid.request.115 i32 2, label %runtime.invalid.reference.116 i32 3, label %runtime.scratch.capacity.117 i32 4, label %runtime.retained.capacity.118 ]
runtime.invalid.request.115:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.116:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.117:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.118:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.119:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.114:
  %record.field.value.120 = load i64, ptr %workspace.slot.112, align 8
  %ctx.field.121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.122 = load i32, ptr %ctx.field.121, align 4
  %steps.next.123 = add i32 %steps.current.122, 1
  store i32 %steps.next.123, ptr %ctx.field.121, align 4
  %steps.over.124 = icmp ugt i32 %steps.next.123, 10000
  br i1 %steps.over.124, label %failure.125, label %continue.126
failure.125:
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.127, align 4
  %status.diagnostic.128 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.128, align 4
  ret void
continue.126:
  %ctx.field.129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.130 = load i32, ptr %ctx.field.129, align 4
  %steps.next.131 = add i32 %steps.current.130, 1
  store i32 %steps.next.131, ptr %ctx.field.129, align 4
  %steps.over.132 = icmp ugt i32 %steps.next.131, 10000
  br i1 %steps.over.132, label %failure.133, label %continue.134
failure.133:
  %ctx.field.135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.135, align 4
  %status.diagnostic.136 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.136, align 4
  ret void
continue.134:
  %ctx.field.137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.138 = load i32, ptr %ctx.field.137, align 4
  %steps.next.139 = add i32 %steps.current.138, 1
  store i32 %steps.next.139, ptr %ctx.field.137, align 4
  %steps.over.140 = icmp ugt i32 %steps.next.139, 10000
  br i1 %steps.over.140, label %failure.141, label %continue.142
failure.141:
  %ctx.field.143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.143, align 4
  %status.diagnostic.144 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.144, align 4
  ret void
continue.142:
  %if.condition.145 = icmp ne i64 %arg3, 0
  br i1 %if.condition.145, label %if.then.146, label %if.else.147
if.then.146:
  %ctx.field.149 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.150 = load i32, ptr %ctx.field.149, align 4
  %steps.next.151 = add i32 %steps.current.150, 1
  store i32 %steps.next.151, ptr %ctx.field.149, align 4
  %steps.over.152 = icmp ugt i32 %steps.next.151, 10000
  br i1 %steps.over.152, label %failure.153, label %continue.154
failure.153:
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.155, align 4
  %status.diagnostic.156 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.156, align 4
  ret void
continue.154:
  %depth.exceeded.157 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.157, label %failure.158, label %continue.159
failure.158:
  %ctx.field.160 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.160, align 4
  %status.diagnostic.161 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.161, align 4
  ret void
continue.159:
  %checked.tuple.162 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %record.field.value.120, i64 %arg2)
  %checked.raw.163 = extractvalue { i64, i1 } %checked.tuple.162, 0
  %checked.overflow.164 = extractvalue { i64, i1 } %checked.tuple.162, 1
  br i1 %checked.overflow.164, label %overflow.165, label %checked.166
overflow.165:
  %ctx.field.167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %record.field.value.120, ptr %ctx.field.167, align 8
  store i64 %arg2, ptr %ctx.field.168, align 8
  %ctx.field.169 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.169, align 4
  %status.diagnostic.170 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.170, align 4
  ret void
checked.166:
  br label %if.merge.148
if.else.147:
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.172 = load i32, ptr %ctx.field.171, align 4
  %steps.next.173 = add i32 %steps.current.172, 1
  store i32 %steps.next.173, ptr %ctx.field.171, align 4
  %steps.over.174 = icmp ugt i32 %steps.next.173, 10000
  br i1 %steps.over.174, label %failure.175, label %continue.176
failure.175:
  %ctx.field.177 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.177, align 4
  %status.diagnostic.178 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.178, align 4
  ret void
continue.176:
  %depth.exceeded.179 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.179, label %failure.180, label %continue.181
failure.180:
  %ctx.field.182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.182, align 4
  %status.diagnostic.183 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.183, align 4
  ret void
continue.181:
  br label %if.merge.148
if.merge.148:
  %stack.phi.184 = phi i64 [ %record.field.value.74, %checked.166 ], [ %record.field.value.74, %continue.181 ]
  %stack.phi.185 = phi i64 [ %checked.raw.163, %checked.166 ], [ %record.field.value.120, %continue.181 ]
  %local.phi.186 = phi i64 [ %arg3, %checked.166 ], [ %arg3, %continue.181 ]
  %local.phi.187 = phi i64 [ %arg2, %checked.166 ], [ %arg2, %continue.181 ]
  %local.phi.188 = phi i64 [ %arg1, %checked.166 ], [ %arg1, %continue.181 ]
  %local.phi.189 = phi i64 [ %arg0, %checked.166 ], [ %arg0, %continue.181 ]
  %local.phi.190 = phi i64 [ %record.field.value.74, %checked.166 ], [ %record.field.value.74, %continue.181 ]
  %ctx.field.191 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.192 = load i32, ptr %ctx.field.191, align 4
  %steps.next.193 = add i32 %steps.current.192, 1
  store i32 %steps.next.193, ptr %ctx.field.191, align 4
  %steps.over.194 = icmp ugt i32 %steps.next.193, 10000
  br i1 %steps.over.194, label %failure.195, label %continue.196
failure.195:
  %ctx.field.197 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.197, align 4
  %status.diagnostic.198 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.198, align 4
  ret void
continue.196:
  %ctx.field.199 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.200 = load i32, ptr %ctx.field.199, align 4
  %steps.next.201 = add i32 %steps.current.200, 1
  store i32 %steps.next.201, ptr %ctx.field.199, align 4
  %steps.over.202 = icmp ugt i32 %steps.next.201, 10000
  br i1 %steps.over.202, label %failure.203, label %continue.204
failure.203:
  %ctx.field.205 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.205, align 4
  %status.diagnostic.206 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.206, align 4
  ret void
continue.204:
  %depth.exceeded.207 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.207, label %failure.208, label %continue.209
failure.208:
  %ctx.field.210 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.210, align 4
  %status.diagnostic.211 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.211, align 4
  ret void
continue.209:
  %workspace.slot.212 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %stack.phi.184, ptr %workspace.slot.212, align 8
  %workspace.slot.213 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %stack.phi.185, ptr %workspace.slot.213, align 8
  %workspace.slot.214 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %local.phi.186, ptr %workspace.slot.214, align 8
  %workspace.slot.215 = getelementptr inbounds i64, ptr %outputs, i64 3
  %record.make.status.216 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 3, ptr %workspace.slot.215)
  switch i32 %record.make.status.216, label %runtime.invalid.result.222 [ i32 0, label %runtime.success.217 i32 1, label %runtime.invalid.request.218 i32 2, label %runtime.invalid.reference.219 i32 3, label %runtime.scratch.capacity.220 i32 4, label %runtime.retained.capacity.221 ]
runtime.invalid.request.218:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.219:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.220:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.221:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.222:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.217:
  %record.make.handle.223 = load i64, ptr %workspace.slot.215, align 8
  %ctx.field.224 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.225 = load i32, ptr %ctx.field.224, align 4
  %steps.next.226 = add i32 %steps.current.225, 1
  store i32 %steps.next.226, ptr %ctx.field.224, align 4
  %steps.over.227 = icmp ugt i32 %steps.next.226, 10000
  br i1 %steps.over.227, label %failure.228, label %continue.229
failure.228:
  %ctx.field.230 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.230, align 4
  %status.diagnostic.231 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.231, align 4
  ret void
continue.229:
  %depth.exceeded.232 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.232, label %failure.233, label %continue.234
failure.233:
  %ctx.field.235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.235, align 4
  %status.diagnostic.236 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.236, align 4
  ret void
continue.234:
  %ctx.field.237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.238 = load i32, ptr %ctx.field.237, align 4
  %steps.next.239 = add i32 %steps.current.238, 1
  store i32 %steps.next.239, ptr %ctx.field.237, align 4
  %steps.over.240 = icmp ugt i32 %steps.next.239, 10000
  br i1 %steps.over.240, label %failure.241, label %continue.242
failure.241:
  %ctx.field.243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.243, align 4
  %status.diagnostic.244 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.244, align 4
  ret void
continue.242:
  %output.ptr.245 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.223, ptr %output.ptr.245, align 8
  %output.ptr.246 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.223, ptr %output.ptr.246, align 8
  %output.ptr.247 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %local.phi.190, ptr %output.ptr.247, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 5 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 3, i32 %capacity, ptr %status, i32 5)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr @agentlang_input_type_ids, i32 5)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  %entry.arg0.ptr = getelementptr inbounds i64, ptr %workspace, i64 0
  %entry.arg0 = load i64, ptr %entry.arg0.ptr, align 8
  %entry.arg1.ptr = getelementptr inbounds i64, ptr %workspace, i64 1
  %entry.arg1 = load i64, ptr %entry.arg1.ptr, align 8
  %entry.arg2.ptr = getelementptr inbounds i64, ptr %workspace, i64 2
  %entry.arg2 = load i64, ptr %entry.arg2.ptr, align 8
  %entry.arg3.ptr = getelementptr inbounds i64, ptr %workspace, i64 3
  %entry.arg3 = load i64, ptr %entry.arg3.ptr, align 8
  %entry.arg4.ptr = getelementptr inbounds i64, ptr %workspace, i64 4
  %entry.arg4 = load i64, ptr %entry.arg4.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0, i64 %entry.arg0, i64 %entry.arg1, i64 %entry.arg2, i64 %entry.arg3, i64 %entry.arg4)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 3, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

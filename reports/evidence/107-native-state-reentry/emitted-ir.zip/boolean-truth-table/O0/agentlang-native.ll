target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_type_descriptors = private constant [3 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([3 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 3, i32 0 }
@agentlang_root_type_ids = private constant [10 x i32] [i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1]
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %depth.exceeded.24 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %bool.value.29 = icmp ne i64 0, 0
  %bool.value.30 = icmp ne i64 0, 0
  %bool.logic.31 = and i1 %bool.value.29, %bool.value.30
  %bool.slot.32 = zext i1 %bool.logic.31 to i64
  %ctx.field.33 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.34 = load i32, ptr %ctx.field.33, align 4
  %steps.next.35 = add i32 %steps.current.34, 1
  store i32 %steps.next.35, ptr %ctx.field.33, align 4
  %steps.over.36 = icmp ugt i32 %steps.next.35, 10000
  br i1 %steps.over.36, label %failure.37, label %continue.38
failure.37:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.39, align 4
  %status.diagnostic.40 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.40, align 4
  ret void
continue.38:
  %ctx.field.41 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.42 = load i32, ptr %ctx.field.41, align 4
  %steps.next.43 = add i32 %steps.current.42, 1
  store i32 %steps.next.43, ptr %ctx.field.41, align 4
  %steps.over.44 = icmp ugt i32 %steps.next.43, 10000
  br i1 %steps.over.44, label %failure.45, label %continue.46
failure.45:
  %ctx.field.47 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.47, align 4
  %status.diagnostic.48 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.48, align 4
  ret void
continue.46:
  %ctx.field.49 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.50 = load i32, ptr %ctx.field.49, align 4
  %steps.next.51 = add i32 %steps.current.50, 1
  store i32 %steps.next.51, ptr %ctx.field.49, align 4
  %steps.over.52 = icmp ugt i32 %steps.next.51, 10000
  br i1 %steps.over.52, label %failure.53, label %continue.54
failure.53:
  %ctx.field.55 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.55, align 4
  %status.diagnostic.56 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.56, align 4
  ret void
continue.54:
  %depth.exceeded.57 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.57, label %failure.58, label %continue.59
failure.58:
  %ctx.field.60 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.60, align 4
  %status.diagnostic.61 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.61, align 4
  ret void
continue.59:
  %bool.value.62 = icmp ne i64 0, 0
  %bool.value.63 = icmp ne i64 1, 0
  %bool.logic.64 = and i1 %bool.value.62, %bool.value.63
  %bool.slot.65 = zext i1 %bool.logic.64 to i64
  %ctx.field.66 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.67 = load i32, ptr %ctx.field.66, align 4
  %steps.next.68 = add i32 %steps.current.67, 1
  store i32 %steps.next.68, ptr %ctx.field.66, align 4
  %steps.over.69 = icmp ugt i32 %steps.next.68, 10000
  br i1 %steps.over.69, label %failure.70, label %continue.71
failure.70:
  %ctx.field.72 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.72, align 4
  %status.diagnostic.73 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.73, align 4
  ret void
continue.71:
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.75 = load i32, ptr %ctx.field.74, align 4
  %steps.next.76 = add i32 %steps.current.75, 1
  store i32 %steps.next.76, ptr %ctx.field.74, align 4
  %steps.over.77 = icmp ugt i32 %steps.next.76, 10000
  br i1 %steps.over.77, label %failure.78, label %continue.79
failure.78:
  %ctx.field.80 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.80, align 4
  %status.diagnostic.81 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.81, align 4
  ret void
continue.79:
  %ctx.field.82 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.83 = load i32, ptr %ctx.field.82, align 4
  %steps.next.84 = add i32 %steps.current.83, 1
  store i32 %steps.next.84, ptr %ctx.field.82, align 4
  %steps.over.85 = icmp ugt i32 %steps.next.84, 10000
  br i1 %steps.over.85, label %failure.86, label %continue.87
failure.86:
  %ctx.field.88 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.88, align 4
  %status.diagnostic.89 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.89, align 4
  ret void
continue.87:
  %depth.exceeded.90 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %bool.value.95 = icmp ne i64 1, 0
  %bool.value.96 = icmp ne i64 0, 0
  %bool.logic.97 = and i1 %bool.value.95, %bool.value.96
  %bool.slot.98 = zext i1 %bool.logic.97 to i64
  %ctx.field.99 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.100 = load i32, ptr %ctx.field.99, align 4
  %steps.next.101 = add i32 %steps.current.100, 1
  store i32 %steps.next.101, ptr %ctx.field.99, align 4
  %steps.over.102 = icmp ugt i32 %steps.next.101, 10000
  br i1 %steps.over.102, label %failure.103, label %continue.104
failure.103:
  %ctx.field.105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.105, align 4
  %status.diagnostic.106 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.106, align 4
  ret void
continue.104:
  %ctx.field.107 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.108 = load i32, ptr %ctx.field.107, align 4
  %steps.next.109 = add i32 %steps.current.108, 1
  store i32 %steps.next.109, ptr %ctx.field.107, align 4
  %steps.over.110 = icmp ugt i32 %steps.next.109, 10000
  br i1 %steps.over.110, label %failure.111, label %continue.112
failure.111:
  %ctx.field.113 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.113, align 4
  %status.diagnostic.114 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.114, align 4
  ret void
continue.112:
  %ctx.field.115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.116 = load i32, ptr %ctx.field.115, align 4
  %steps.next.117 = add i32 %steps.current.116, 1
  store i32 %steps.next.117, ptr %ctx.field.115, align 4
  %steps.over.118 = icmp ugt i32 %steps.next.117, 10000
  br i1 %steps.over.118, label %failure.119, label %continue.120
failure.119:
  %ctx.field.121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.121, align 4
  %status.diagnostic.122 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.122, align 4
  ret void
continue.120:
  %depth.exceeded.123 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.123, label %failure.124, label %continue.125
failure.124:
  %ctx.field.126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.126, align 4
  %status.diagnostic.127 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.127, align 4
  ret void
continue.125:
  %bool.value.128 = icmp ne i64 1, 0
  %bool.value.129 = icmp ne i64 1, 0
  %bool.logic.130 = and i1 %bool.value.128, %bool.value.129
  %bool.slot.131 = zext i1 %bool.logic.130 to i64
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.133 = load i32, ptr %ctx.field.132, align 4
  %steps.next.134 = add i32 %steps.current.133, 1
  store i32 %steps.next.134, ptr %ctx.field.132, align 4
  %steps.over.135 = icmp ugt i32 %steps.next.134, 10000
  br i1 %steps.over.135, label %failure.136, label %continue.137
failure.136:
  %ctx.field.138 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.138, align 4
  %status.diagnostic.139 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.139, align 4
  ret void
continue.137:
  %ctx.field.140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.141 = load i32, ptr %ctx.field.140, align 4
  %steps.next.142 = add i32 %steps.current.141, 1
  store i32 %steps.next.142, ptr %ctx.field.140, align 4
  %steps.over.143 = icmp ugt i32 %steps.next.142, 10000
  br i1 %steps.over.143, label %failure.144, label %continue.145
failure.144:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.146, align 4
  %status.diagnostic.147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.147, align 4
  ret void
continue.145:
  %ctx.field.148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.149 = load i32, ptr %ctx.field.148, align 4
  %steps.next.150 = add i32 %steps.current.149, 1
  store i32 %steps.next.150, ptr %ctx.field.148, align 4
  %steps.over.151 = icmp ugt i32 %steps.next.150, 10000
  br i1 %steps.over.151, label %failure.152, label %continue.153
failure.152:
  %ctx.field.154 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.154, align 4
  %status.diagnostic.155 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.155, align 4
  ret void
continue.153:
  %depth.exceeded.156 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.156, label %failure.157, label %continue.158
failure.157:
  %ctx.field.159 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.159, align 4
  %status.diagnostic.160 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.160, align 4
  ret void
continue.158:
  %bool.value.161 = icmp ne i64 0, 0
  %bool.value.162 = icmp ne i64 0, 0
  %bool.logic.163 = or i1 %bool.value.161, %bool.value.162
  %bool.slot.164 = zext i1 %bool.logic.163 to i64
  %ctx.field.165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.166 = load i32, ptr %ctx.field.165, align 4
  %steps.next.167 = add i32 %steps.current.166, 1
  store i32 %steps.next.167, ptr %ctx.field.165, align 4
  %steps.over.168 = icmp ugt i32 %steps.next.167, 10000
  br i1 %steps.over.168, label %failure.169, label %continue.170
failure.169:
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.171, align 4
  %status.diagnostic.172 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.172, align 4
  ret void
continue.170:
  %ctx.field.173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.174 = load i32, ptr %ctx.field.173, align 4
  %steps.next.175 = add i32 %steps.current.174, 1
  store i32 %steps.next.175, ptr %ctx.field.173, align 4
  %steps.over.176 = icmp ugt i32 %steps.next.175, 10000
  br i1 %steps.over.176, label %failure.177, label %continue.178
failure.177:
  %ctx.field.179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.179, align 4
  %status.diagnostic.180 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.180, align 4
  ret void
continue.178:
  %ctx.field.181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.182 = load i32, ptr %ctx.field.181, align 4
  %steps.next.183 = add i32 %steps.current.182, 1
  store i32 %steps.next.183, ptr %ctx.field.181, align 4
  %steps.over.184 = icmp ugt i32 %steps.next.183, 10000
  br i1 %steps.over.184, label %failure.185, label %continue.186
failure.185:
  %ctx.field.187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.187, align 4
  %status.diagnostic.188 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.188, align 4
  ret void
continue.186:
  %depth.exceeded.189 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.189, label %failure.190, label %continue.191
failure.190:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.192, align 4
  %status.diagnostic.193 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.193, align 4
  ret void
continue.191:
  %bool.value.194 = icmp ne i64 0, 0
  %bool.value.195 = icmp ne i64 1, 0
  %bool.logic.196 = or i1 %bool.value.194, %bool.value.195
  %bool.slot.197 = zext i1 %bool.logic.196 to i64
  %ctx.field.198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.199 = load i32, ptr %ctx.field.198, align 4
  %steps.next.200 = add i32 %steps.current.199, 1
  store i32 %steps.next.200, ptr %ctx.field.198, align 4
  %steps.over.201 = icmp ugt i32 %steps.next.200, 10000
  br i1 %steps.over.201, label %failure.202, label %continue.203
failure.202:
  %ctx.field.204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.204, align 4
  %status.diagnostic.205 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.205, align 4
  ret void
continue.203:
  %ctx.field.206 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.207 = load i32, ptr %ctx.field.206, align 4
  %steps.next.208 = add i32 %steps.current.207, 1
  store i32 %steps.next.208, ptr %ctx.field.206, align 4
  %steps.over.209 = icmp ugt i32 %steps.next.208, 10000
  br i1 %steps.over.209, label %failure.210, label %continue.211
failure.210:
  %ctx.field.212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.212, align 4
  %status.diagnostic.213 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.213, align 4
  ret void
continue.211:
  %ctx.field.214 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.215 = load i32, ptr %ctx.field.214, align 4
  %steps.next.216 = add i32 %steps.current.215, 1
  store i32 %steps.next.216, ptr %ctx.field.214, align 4
  %steps.over.217 = icmp ugt i32 %steps.next.216, 10000
  br i1 %steps.over.217, label %failure.218, label %continue.219
failure.218:
  %ctx.field.220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.220, align 4
  %status.diagnostic.221 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.221, align 4
  ret void
continue.219:
  %depth.exceeded.222 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.222, label %failure.223, label %continue.224
failure.223:
  %ctx.field.225 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.225, align 4
  %status.diagnostic.226 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.226, align 4
  ret void
continue.224:
  %bool.value.227 = icmp ne i64 1, 0
  %bool.value.228 = icmp ne i64 0, 0
  %bool.logic.229 = or i1 %bool.value.227, %bool.value.228
  %bool.slot.230 = zext i1 %bool.logic.229 to i64
  %ctx.field.231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.232 = load i32, ptr %ctx.field.231, align 4
  %steps.next.233 = add i32 %steps.current.232, 1
  store i32 %steps.next.233, ptr %ctx.field.231, align 4
  %steps.over.234 = icmp ugt i32 %steps.next.233, 10000
  br i1 %steps.over.234, label %failure.235, label %continue.236
failure.235:
  %ctx.field.237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.237, align 4
  %status.diagnostic.238 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.238, align 4
  ret void
continue.236:
  %ctx.field.239 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.240 = load i32, ptr %ctx.field.239, align 4
  %steps.next.241 = add i32 %steps.current.240, 1
  store i32 %steps.next.241, ptr %ctx.field.239, align 4
  %steps.over.242 = icmp ugt i32 %steps.next.241, 10000
  br i1 %steps.over.242, label %failure.243, label %continue.244
failure.243:
  %ctx.field.245 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.245, align 4
  %status.diagnostic.246 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.246, align 4
  ret void
continue.244:
  %ctx.field.247 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.248 = load i32, ptr %ctx.field.247, align 4
  %steps.next.249 = add i32 %steps.current.248, 1
  store i32 %steps.next.249, ptr %ctx.field.247, align 4
  %steps.over.250 = icmp ugt i32 %steps.next.249, 10000
  br i1 %steps.over.250, label %failure.251, label %continue.252
failure.251:
  %ctx.field.253 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.253, align 4
  %status.diagnostic.254 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.254, align 4
  ret void
continue.252:
  %depth.exceeded.255 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.255, label %failure.256, label %continue.257
failure.256:
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.258, align 4
  %status.diagnostic.259 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.259, align 4
  ret void
continue.257:
  %bool.value.260 = icmp ne i64 1, 0
  %bool.value.261 = icmp ne i64 1, 0
  %bool.logic.262 = or i1 %bool.value.260, %bool.value.261
  %bool.slot.263 = zext i1 %bool.logic.262 to i64
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.265 = load i32, ptr %ctx.field.264, align 4
  %steps.next.266 = add i32 %steps.current.265, 1
  store i32 %steps.next.266, ptr %ctx.field.264, align 4
  %steps.over.267 = icmp ugt i32 %steps.next.266, 10000
  br i1 %steps.over.267, label %failure.268, label %continue.269
failure.268:
  %ctx.field.270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.270, align 4
  %status.diagnostic.271 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.271, align 4
  ret void
continue.269:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.273 = load i32, ptr %ctx.field.272, align 4
  %steps.next.274 = add i32 %steps.current.273, 1
  store i32 %steps.next.274, ptr %ctx.field.272, align 4
  %steps.over.275 = icmp ugt i32 %steps.next.274, 10000
  br i1 %steps.over.275, label %failure.276, label %continue.277
failure.276:
  %ctx.field.278 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.278, align 4
  %status.diagnostic.279 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.279, align 4
  ret void
continue.277:
  %depth.exceeded.280 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.280, label %failure.281, label %continue.282
failure.281:
  %ctx.field.283 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.283, align 4
  %status.diagnostic.284 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.284, align 4
  ret void
continue.282:
  %bool.value.285 = icmp ne i64 0, 0
  %bool.not.286 = xor i1 %bool.value.285, true
  %bool.slot.287 = zext i1 %bool.not.286 to i64
  %ctx.field.288 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.289 = load i32, ptr %ctx.field.288, align 4
  %steps.next.290 = add i32 %steps.current.289, 1
  store i32 %steps.next.290, ptr %ctx.field.288, align 4
  %steps.over.291 = icmp ugt i32 %steps.next.290, 10000
  br i1 %steps.over.291, label %failure.292, label %continue.293
failure.292:
  %ctx.field.294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.294, align 4
  %status.diagnostic.295 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.295, align 4
  ret void
continue.293:
  %ctx.field.296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.297 = load i32, ptr %ctx.field.296, align 4
  %steps.next.298 = add i32 %steps.current.297, 1
  store i32 %steps.next.298, ptr %ctx.field.296, align 4
  %steps.over.299 = icmp ugt i32 %steps.next.298, 10000
  br i1 %steps.over.299, label %failure.300, label %continue.301
failure.300:
  %ctx.field.302 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.302, align 4
  %status.diagnostic.303 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.303, align 4
  ret void
continue.301:
  %depth.exceeded.304 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.304, label %failure.305, label %continue.306
failure.305:
  %ctx.field.307 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.307, align 4
  %status.diagnostic.308 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.308, align 4
  ret void
continue.306:
  %bool.value.309 = icmp ne i64 1, 0
  %bool.not.310 = xor i1 %bool.value.309, true
  %bool.slot.311 = zext i1 %bool.not.310 to i64
  %output.ptr.312 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.32, ptr %output.ptr.312, align 8
  %output.ptr.313 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %bool.slot.65, ptr %output.ptr.313, align 8
  %output.ptr.314 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %bool.slot.98, ptr %output.ptr.314, align 8
  %output.ptr.315 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %bool.slot.131, ptr %output.ptr.315, align 8
  %output.ptr.316 = getelementptr inbounds i64, ptr %outputs, i64 4
  store i64 %bool.slot.164, ptr %output.ptr.316, align 8
  %output.ptr.317 = getelementptr inbounds i64, ptr %outputs, i64 5
  store i64 %bool.slot.197, ptr %output.ptr.317, align 8
  %output.ptr.318 = getelementptr inbounds i64, ptr %outputs, i64 6
  store i64 %bool.slot.230, ptr %output.ptr.318, align 8
  %output.ptr.319 = getelementptr inbounds i64, ptr %outputs, i64 7
  store i64 %bool.slot.263, ptr %output.ptr.319, align 8
  %output.ptr.320 = getelementptr inbounds i64, ptr %outputs, i64 8
  store i64 %bool.slot.287, ptr %output.ptr.320, align 8
  %output.ptr.321 = getelementptr inbounds i64, ptr %outputs, i64 9
  store i64 %bool.slot.311, ptr %output.ptr.321, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 10 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 10, i32 %capacity, ptr %status, i32 10)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 10, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

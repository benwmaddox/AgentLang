target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [2 x i32] [i32 5, i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_6 = private constant [1 x i32] [i32 0]
@agentlang_type_descriptors = private constant [7 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([7 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 7, i32 0 }
@agentlang_root_type_ids = private constant [7 x i32] [i32 3, i32 3, i32 5, i32 5, i32 1, i32 1, i32 4]
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %workspace.slot.21 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 99, ptr %workspace.slot.21, align 8
  %workspace.slot.22 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.23 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 1, ptr %workspace.slot.22)
  switch i32 %record.make.status.23, label %runtime.invalid.result.29 [ i32 0, label %runtime.success.24 i32 1, label %runtime.invalid.request.25 i32 2, label %runtime.invalid.reference.26 i32 3, label %runtime.scratch.capacity.27 i32 4, label %runtime.retained.capacity.28 ]
runtime.invalid.request.25:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.26:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.27:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.28:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.29:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.24:
  %record.make.handle.30 = load i64, ptr %workspace.slot.22, align 8
  %ctx.field.31 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.32 = load i32, ptr %ctx.field.31, align 4
  %steps.next.33 = add i32 %steps.current.32, 1
  store i32 %steps.next.33, ptr %ctx.field.31, align 4
  %steps.over.34 = icmp ugt i32 %steps.next.33, 10000
  br i1 %steps.over.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %depth.exceeded.39 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.39, label %failure.40, label %continue.41
failure.40:
  %ctx.field.42 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.42, align 4
  %status.diagnostic.43 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.43, align 4
  ret void
continue.41:
  %ctx.field.44 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.45 = load i32, ptr %ctx.field.44, align 4
  %steps.next.46 = add i32 %steps.current.45, 1
  store i32 %steps.next.46, ptr %ctx.field.44, align 4
  %steps.over.47 = icmp ugt i32 %steps.next.46, 10000
  br i1 %steps.over.47, label %failure.48, label %continue.49
failure.48:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.50, align 4
  %status.diagnostic.51 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.51, align 4
  ret void
continue.49:
  %ctx.field.52 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.53 = load i32, ptr %ctx.field.52, align 4
  %steps.next.54 = add i32 %steps.current.53, 1
  store i32 %steps.next.54, ptr %ctx.field.52, align 4
  %steps.over.55 = icmp ugt i32 %steps.next.54, 10000
  br i1 %steps.over.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %depth.exceeded.60 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.60, label %failure.61, label %continue.62
failure.61:
  %ctx.field.63 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.63, align 4
  %status.diagnostic.64 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.64, align 4
  ret void
continue.62:
  %workspace.slot.65 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 5, ptr %workspace.slot.65, align 8
  %workspace.slot.66 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.67 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.66)
  switch i32 %record.make.status.67, label %runtime.invalid.result.73 [ i32 0, label %runtime.success.68 i32 1, label %runtime.invalid.request.69 i32 2, label %runtime.invalid.reference.70 i32 3, label %runtime.scratch.capacity.71 i32 4, label %runtime.retained.capacity.72 ]
runtime.invalid.request.69:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.70:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.71:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.72:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.73:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.68:
  %record.make.handle.74 = load i64, ptr %workspace.slot.66, align 8
  %ctx.field.75 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.76 = load i32, ptr %ctx.field.75, align 4
  %steps.next.77 = add i32 %steps.current.76, 1
  store i32 %steps.next.77, ptr %ctx.field.75, align 4
  %steps.over.78 = icmp ugt i32 %steps.next.77, 10000
  br i1 %steps.over.78, label %failure.79, label %continue.80
failure.79:
  %ctx.field.81 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.81, align 4
  %status.diagnostic.82 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.82, align 4
  ret void
continue.80:
  %ctx.field.83 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.84 = load i32, ptr %ctx.field.83, align 4
  %steps.next.85 = add i32 %steps.current.84, 1
  store i32 %steps.next.85, ptr %ctx.field.83, align 4
  %steps.over.86 = icmp ugt i32 %steps.next.85, 10000
  br i1 %steps.over.86, label %failure.87, label %continue.88
failure.87:
  %ctx.field.89 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.89, align 4
  %status.diagnostic.90 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.90, align 4
  ret void
continue.88:
  %ctx.field.91 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.92 = load i32, ptr %ctx.field.91, align 4
  %steps.next.93 = add i32 %steps.current.92, 1
  store i32 %steps.next.93, ptr %ctx.field.91, align 4
  %steps.over.94 = icmp ugt i32 %steps.next.93, 10000
  br i1 %steps.over.94, label %failure.95, label %continue.96
failure.95:
  %ctx.field.97 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.97, align 4
  %status.diagnostic.98 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.98, align 4
  ret void
continue.96:
  %ctx.field.99 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.100 = load i32, ptr %ctx.field.99, align 4
  %steps.next.101 = add i32 %steps.current.100, 1
  store i32 %steps.next.101, ptr %ctx.field.99, align 4
  %steps.over.102 = icmp ugt i32 %steps.next.101, 10000
  br i1 %steps.over.102, label %failure.103, label %continue.104
failure.103:
  %ctx.field.105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.105, align 4
  %status.diagnostic.106 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.106, align 4
  ret void
continue.104:
  %depth.exceeded.107 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.107, label %failure.108, label %continue.109
failure.108:
  %ctx.field.110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.110, align 4
  %status.diagnostic.111 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.111, align 4
  ret void
continue.109:
  %workspace.slot.112 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.74, ptr %workspace.slot.112, align 8
  %workspace.slot.113 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 10, ptr %workspace.slot.113, align 8
  %workspace.slot.114 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.115 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 2, ptr %workspace.slot.114)
  switch i32 %record.make.status.115, label %runtime.invalid.result.121 [ i32 0, label %runtime.success.116 i32 1, label %runtime.invalid.request.117 i32 2, label %runtime.invalid.reference.118 i32 3, label %runtime.scratch.capacity.119 i32 4, label %runtime.retained.capacity.120 ]
runtime.invalid.request.117:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.118:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.119:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.120:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.121:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.116:
  %record.make.handle.122 = load i64, ptr %workspace.slot.114, align 8
  %ctx.field.123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.124 = load i32, ptr %ctx.field.123, align 4
  %steps.next.125 = add i32 %steps.current.124, 1
  store i32 %steps.next.125, ptr %ctx.field.123, align 4
  %steps.over.126 = icmp ugt i32 %steps.next.125, 10000
  br i1 %steps.over.126, label %failure.127, label %continue.128
failure.127:
  %ctx.field.129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.129, align 4
  %status.diagnostic.130 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.130, align 4
  ret void
continue.128:
  %ctx.field.131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.132 = load i32, ptr %ctx.field.131, align 4
  %steps.next.133 = add i32 %steps.current.132, 1
  store i32 %steps.next.133, ptr %ctx.field.131, align 4
  %steps.over.134 = icmp ugt i32 %steps.next.133, 10000
  br i1 %steps.over.134, label %failure.135, label %continue.136
failure.135:
  %ctx.field.137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.137, align 4
  %status.diagnostic.138 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.138, align 4
  ret void
continue.136:
  %ctx.field.139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.140 = load i32, ptr %ctx.field.139, align 4
  %steps.next.141 = add i32 %steps.current.140, 1
  store i32 %steps.next.141, ptr %ctx.field.139, align 4
  %steps.over.142 = icmp ugt i32 %steps.next.141, 10000
  br i1 %steps.over.142, label %failure.143, label %continue.144
failure.143:
  %ctx.field.145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.145, align 4
  %status.diagnostic.146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.146, align 4
  ret void
continue.144:
  %ctx.field.147 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.148 = load i32, ptr %ctx.field.147, align 4
  %steps.next.149 = add i32 %steps.current.148, 1
  store i32 %steps.next.149, ptr %ctx.field.147, align 4
  %steps.over.150 = icmp ugt i32 %steps.next.149, 10000
  br i1 %steps.over.150, label %failure.151, label %continue.152
failure.151:
  %ctx.field.153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.153, align 4
  %status.diagnostic.154 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.154, align 4
  ret void
continue.152:
  %depth.exceeded.155 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.155, label %failure.156, label %continue.157
failure.156:
  %ctx.field.158 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.158, align 4
  %status.diagnostic.159 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.159, align 4
  ret void
continue.157:
  %workspace.slot.160 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.74, ptr %workspace.slot.160, align 8
  %workspace.slot.161 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 20, ptr %workspace.slot.161, align 8
  %workspace.slot.162 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.163 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 2, ptr %workspace.slot.162)
  switch i32 %record.make.status.163, label %runtime.invalid.result.169 [ i32 0, label %runtime.success.164 i32 1, label %runtime.invalid.request.165 i32 2, label %runtime.invalid.reference.166 i32 3, label %runtime.scratch.capacity.167 i32 4, label %runtime.retained.capacity.168 ]
runtime.invalid.request.165:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.166:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.167:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.168:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.169:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.164:
  %record.make.handle.170 = load i64, ptr %workspace.slot.162, align 8
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.172 = load i32, ptr %ctx.field.171, align 4
  %steps.next.173 = add i32 %steps.current.172, 1
  store i32 %steps.next.173, ptr %ctx.field.171, align 4
  %steps.over.174 = icmp ugt i32 %steps.next.173, 10000
  br i1 %steps.over.174, label %failure.175, label %continue.176
failure.175:
  %ctx.field.177 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.177, align 4
  %status.diagnostic.178 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.178, align 4
  ret void
continue.176:
  %ctx.field.179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.180 = load i32, ptr %ctx.field.179, align 4
  %steps.next.181 = add i32 %steps.current.180, 1
  store i32 %steps.next.181, ptr %ctx.field.179, align 4
  %steps.over.182 = icmp ugt i32 %steps.next.181, 10000
  br i1 %steps.over.182, label %failure.183, label %continue.184
failure.183:
  %ctx.field.185 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.185, align 4
  %status.diagnostic.186 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.186, align 4
  ret void
continue.184:
  %ctx.field.187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.188 = load i32, ptr %ctx.field.187, align 4
  %steps.next.189 = add i32 %steps.current.188, 1
  store i32 %steps.next.189, ptr %ctx.field.187, align 4
  %steps.over.190 = icmp ugt i32 %steps.next.189, 10000
  br i1 %steps.over.190, label %failure.191, label %continue.192
failure.191:
  %ctx.field.193 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.193, align 4
  %status.diagnostic.194 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.194, align 4
  ret void
continue.192:
  %depth.exceeded.195 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.195, label %failure.196, label %continue.197
failure.196:
  %ctx.field.198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.198, align 4
  %status.diagnostic.199 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.199, align 4
  ret void
continue.197:
  %workspace.slot.200 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 5, ptr %workspace.slot.200, align 8
  %workspace.slot.201 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.202 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.201)
  switch i32 %record.make.status.202, label %runtime.invalid.result.208 [ i32 0, label %runtime.success.203 i32 1, label %runtime.invalid.request.204 i32 2, label %runtime.invalid.reference.205 i32 3, label %runtime.scratch.capacity.206 i32 4, label %runtime.retained.capacity.207 ]
runtime.invalid.request.204:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.205:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.206:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.207:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.208:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.203:
  %record.make.handle.209 = load i64, ptr %workspace.slot.201, align 8
  %ctx.field.210 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.211 = load i32, ptr %ctx.field.210, align 4
  %steps.next.212 = add i32 %steps.current.211, 1
  store i32 %steps.next.212, ptr %ctx.field.210, align 4
  %steps.over.213 = icmp ugt i32 %steps.next.212, 10000
  br i1 %steps.over.213, label %failure.214, label %continue.215
failure.214:
  %ctx.field.216 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.216, align 4
  %status.diagnostic.217 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.217, align 4
  ret void
continue.215:
  %ctx.field.218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.219 = load i32, ptr %ctx.field.218, align 4
  %steps.next.220 = add i32 %steps.current.219, 1
  store i32 %steps.next.220, ptr %ctx.field.218, align 4
  %steps.over.221 = icmp ugt i32 %steps.next.220, 10000
  br i1 %steps.over.221, label %failure.222, label %continue.223
failure.222:
  %ctx.field.224 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.224, align 4
  %status.diagnostic.225 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.225, align 4
  ret void
continue.223:
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.227 = load i32, ptr %ctx.field.226, align 4
  %steps.next.228 = add i32 %steps.current.227, 1
  store i32 %steps.next.228, ptr %ctx.field.226, align 4
  %steps.over.229 = icmp ugt i32 %steps.next.228, 10000
  br i1 %steps.over.229, label %failure.230, label %continue.231
failure.230:
  %ctx.field.232 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.232, align 4
  %status.diagnostic.233 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.233, align 4
  ret void
continue.231:
  %ctx.field.234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.235 = load i32, ptr %ctx.field.234, align 4
  %steps.next.236 = add i32 %steps.current.235, 1
  store i32 %steps.next.236, ptr %ctx.field.234, align 4
  %steps.over.237 = icmp ugt i32 %steps.next.236, 10000
  br i1 %steps.over.237, label %failure.238, label %continue.239
failure.238:
  %ctx.field.240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.240, align 4
  %status.diagnostic.241 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.241, align 4
  ret void
continue.239:
  %ctx.field.242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.243 = load i32, ptr %ctx.field.242, align 4
  %steps.next.244 = add i32 %steps.current.243, 1
  store i32 %steps.next.244, ptr %ctx.field.242, align 4
  %steps.over.245 = icmp ugt i32 %steps.next.244, 10000
  br i1 %steps.over.245, label %failure.246, label %continue.247
failure.246:
  %ctx.field.248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.248, align 4
  %status.diagnostic.249 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.249, align 4
  ret void
continue.247:
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.251 = load i32, ptr %ctx.field.250, align 4
  %steps.next.252 = add i32 %steps.current.251, 1
  store i32 %steps.next.252, ptr %ctx.field.250, align 4
  %steps.over.253 = icmp ugt i32 %steps.next.252, 10000
  br i1 %steps.over.253, label %failure.254, label %continue.255
failure.254:
  %ctx.field.256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.256, align 4
  %status.diagnostic.257 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.257, align 4
  ret void
continue.255:
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.259 = load i32, ptr %ctx.field.258, align 4
  %steps.next.260 = add i32 %steps.current.259, 1
  store i32 %steps.next.260, ptr %ctx.field.258, align 4
  %steps.over.261 = icmp ugt i32 %steps.next.260, 10000
  br i1 %steps.over.261, label %failure.262, label %continue.263
failure.262:
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.264, align 4
  %status.diagnostic.265 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.265, align 4
  ret void
continue.263:
  %ctx.field.266 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.267 = load i32, ptr %ctx.field.266, align 4
  %steps.next.268 = add i32 %steps.current.267, 1
  store i32 %steps.next.268, ptr %ctx.field.266, align 4
  %steps.over.269 = icmp ugt i32 %steps.next.268, 10000
  br i1 %steps.over.269, label %failure.270, label %continue.271
failure.270:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.272, align 4
  %status.diagnostic.273 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.273, align 4
  ret void
continue.271:
  %depth.exceeded.274 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.274, label %failure.275, label %continue.276
failure.275:
  %ctx.field.277 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.277, align 4
  %status.diagnostic.278 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.278, align 4
  ret void
continue.276:
  %workspace.slot.279 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.equal.status.280 = call i32 @al_runtime_equal(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.make.handle.74, i64 %record.make.handle.209, ptr %workspace.slot.279)
  switch i32 %record.equal.status.280, label %runtime.invalid.result.286 [ i32 0, label %runtime.success.281 i32 1, label %runtime.invalid.request.282 i32 2, label %runtime.invalid.reference.283 i32 3, label %runtime.scratch.capacity.284 i32 4, label %runtime.retained.capacity.285 ]
runtime.invalid.request.282:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.283:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.284:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.285:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.286:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.281:
  %record.equal.value.287 = load i32, ptr %workspace.slot.279, align 4
  %record.equal.slot.288 = zext i32 %record.equal.value.287 to i64
  %ctx.field.289 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.290 = load i32, ptr %ctx.field.289, align 4
  %steps.next.291 = add i32 %steps.current.290, 1
  store i32 %steps.next.291, ptr %ctx.field.289, align 4
  %steps.over.292 = icmp ugt i32 %steps.next.291, 10000
  br i1 %steps.over.292, label %failure.293, label %continue.294
failure.293:
  %ctx.field.295 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.295, align 4
  %status.diagnostic.296 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.296, align 4
  ret void
continue.294:
  %ctx.field.297 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.298 = load i32, ptr %ctx.field.297, align 4
  %steps.next.299 = add i32 %steps.current.298, 1
  store i32 %steps.next.299, ptr %ctx.field.297, align 4
  %steps.over.300 = icmp ugt i32 %steps.next.299, 10000
  br i1 %steps.over.300, label %failure.301, label %continue.302
failure.301:
  %ctx.field.303 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.303, align 4
  %status.diagnostic.304 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.304, align 4
  ret void
continue.302:
  %ctx.field.305 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.306 = load i32, ptr %ctx.field.305, align 4
  %steps.next.307 = add i32 %steps.current.306, 1
  store i32 %steps.next.307, ptr %ctx.field.305, align 4
  %steps.over.308 = icmp ugt i32 %steps.next.307, 10000
  br i1 %steps.over.308, label %failure.309, label %continue.310
failure.309:
  %ctx.field.311 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.311, align 4
  %status.diagnostic.312 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.312, align 4
  ret void
continue.310:
  %depth.exceeded.313 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.313, label %failure.314, label %continue.315
failure.314:
  %ctx.field.316 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.316, align 4
  %status.diagnostic.317 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.317, align 4
  ret void
continue.315:
  %workspace.slot.318 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.equal.status.319 = call i32 @al_runtime_equal(ptr %ctx, ptr @agentlang_program, i32 3, i64 %record.make.handle.122, i64 %record.make.handle.170, ptr %workspace.slot.318)
  switch i32 %record.equal.status.319, label %runtime.invalid.result.325 [ i32 0, label %runtime.success.320 i32 1, label %runtime.invalid.request.321 i32 2, label %runtime.invalid.reference.322 i32 3, label %runtime.scratch.capacity.323 i32 4, label %runtime.retained.capacity.324 ]
runtime.invalid.request.321:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.322:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.323:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.324:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.325:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.320:
  %record.equal.value.326 = load i32, ptr %workspace.slot.318, align 4
  %record.equal.slot.327 = zext i32 %record.equal.value.326 to i64
  %ctx.field.328 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.329 = load i32, ptr %ctx.field.328, align 4
  %steps.next.330 = add i32 %steps.current.329, 1
  store i32 %steps.next.330, ptr %ctx.field.328, align 4
  %steps.over.331 = icmp ugt i32 %steps.next.330, 10000
  br i1 %steps.over.331, label %failure.332, label %continue.333
failure.332:
  %ctx.field.334 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.334, align 4
  %status.diagnostic.335 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.335, align 4
  ret void
continue.333:
  %depth.exceeded.336 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.336, label %failure.337, label %continue.338
failure.337:
  %ctx.field.339 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.339, align 4
  %status.diagnostic.340 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.340, align 4
  ret void
continue.338:
  %workspace.slot.341 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.make.status.342 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 0, ptr %workspace.slot.341)
  switch i32 %record.make.status.342, label %runtime.invalid.result.348 [ i32 0, label %runtime.success.343 i32 1, label %runtime.invalid.request.344 i32 2, label %runtime.invalid.reference.345 i32 3, label %runtime.scratch.capacity.346 i32 4, label %runtime.retained.capacity.347 ]
runtime.invalid.request.344:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.345:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.346:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.347:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.348:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.343:
  %record.make.handle.349 = load i64, ptr %workspace.slot.341, align 8
  %output.ptr.350 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.122, ptr %output.ptr.350, align 8
  %output.ptr.351 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.170, ptr %output.ptr.351, align 8
  %output.ptr.352 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %record.make.handle.74, ptr %output.ptr.352, align 8
  %output.ptr.353 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %record.make.handle.209, ptr %output.ptr.353, align 8
  %output.ptr.354 = getelementptr inbounds i64, ptr %outputs, i64 4
  store i64 %record.equal.slot.288, ptr %output.ptr.354, align 8
  %output.ptr.355 = getelementptr inbounds i64, ptr %outputs, i64 5
  store i64 %record.equal.slot.327, ptr %output.ptr.355, align 8
  %output.ptr.356 = getelementptr inbounds i64, ptr %outputs, i64 6
  store i64 %record.make.handle.349, ptr %output.ptr.356, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 7 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 7, i32 %capacity, ptr %status, i32 7)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 7, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

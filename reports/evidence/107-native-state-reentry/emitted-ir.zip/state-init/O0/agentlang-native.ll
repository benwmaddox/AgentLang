target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [3 x i32] [i32 7, i32 0, i32 1]
@agentlang_fields_4 = private constant [1 x i32] [i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_7 = private constant [2 x i32] [i32 6, i32 4]
@agentlang_type_descriptors = private constant [8 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 3, ptr getelementptr inbounds ([3 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([8 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 8, i32 0 }
@agentlang_root_type_ids = private constant [4 x i32] [i32 3, i32 7, i32 4, i32 5]
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %validator.depth.21 = add i32 %depth, 1
  %depth.exceeded.22 = icmp ugt i32 %validator.depth.21, 64
  br i1 %depth.exceeded.22, label %failure.23, label %continue.24
failure.23:
  %ctx.field.25 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.25, align 4
  %status.diagnostic.26 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.26, align 4
  ret void
continue.24:
  %call.depth.27 = add i32 %validator.depth.21, 1
  call void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.27, i64 7)
  %callee.status.28 = load i32, ptr %status, align 4
  %callee.succeeded.29 = icmp eq i32 %callee.status.28, 0
  br i1 %callee.succeeded.29, label %callee.continue.31, label %callee.failure.30
callee.failure.30:
  ret void
callee.continue.31:
  %call.output.ptr.32 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.33 = load i64, ptr %call.output.ptr.32, align 8
  %validator.accepted.34 = icmp ne i64 %call.output.33, 0
  %validator.failed.35 = xor i1 %validator.accepted.34, true
  br i1 %validator.failed.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.41 = load i32, ptr %ctx.field.40, align 4
  %steps.next.42 = add i32 %steps.current.41, 1
  store i32 %steps.next.42, ptr %ctx.field.40, align 4
  %steps.over.43 = icmp ugt i32 %steps.next.42, 10000
  br i1 %steps.over.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %ctx.field.48 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.49 = load i32, ptr %ctx.field.48, align 4
  %steps.next.50 = add i32 %steps.current.49, 1
  store i32 %steps.next.50, ptr %ctx.field.48, align 4
  %steps.over.51 = icmp ugt i32 %steps.next.50, 10000
  br i1 %steps.over.51, label %failure.52, label %continue.53
failure.52:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.54, align 4
  %status.diagnostic.55 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.55, align 4
  ret void
continue.53:
  %ctx.field.56 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.57 = load i32, ptr %ctx.field.56, align 4
  %steps.next.58 = add i32 %steps.current.57, 1
  store i32 %steps.next.58, ptr %ctx.field.56, align 4
  %steps.over.59 = icmp ugt i32 %steps.next.58, 10000
  br i1 %steps.over.59, label %failure.60, label %continue.61
failure.60:
  %ctx.field.62 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.62, align 4
  %status.diagnostic.63 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.63, align 4
  ret void
continue.61:
  %depth.exceeded.64 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.64, label %failure.65, label %continue.66
failure.65:
  %ctx.field.67 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.67, align 4
  %status.diagnostic.68 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.68, align 4
  ret void
continue.66:
  %workspace.slot.69 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 5, ptr %workspace.slot.69, align 8
  %workspace.slot.70 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.71 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 1, ptr %workspace.slot.70)
  switch i32 %record.make.status.71, label %runtime.invalid.result.77 [ i32 0, label %runtime.success.72 i32 1, label %runtime.invalid.request.73 i32 2, label %runtime.invalid.reference.74 i32 3, label %runtime.scratch.capacity.75 i32 4, label %runtime.retained.capacity.76 ]
runtime.invalid.request.73:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.74:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.75:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.76:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.77:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.72:
  %record.make.handle.78 = load i64, ptr %workspace.slot.70, align 8
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.80 = load i32, ptr %ctx.field.79, align 4
  %steps.next.81 = add i32 %steps.current.80, 1
  store i32 %steps.next.81, ptr %ctx.field.79, align 4
  %steps.over.82 = icmp ugt i32 %steps.next.81, 10000
  br i1 %steps.over.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.88 = load i32, ptr %ctx.field.87, align 4
  %steps.next.89 = add i32 %steps.current.88, 1
  store i32 %steps.next.89, ptr %ctx.field.87, align 4
  %steps.over.90 = icmp ugt i32 %steps.next.89, 10000
  br i1 %steps.over.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %ctx.field.95 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.96 = load i32, ptr %ctx.field.95, align 4
  %steps.next.97 = add i32 %steps.current.96, 1
  store i32 %steps.next.97, ptr %ctx.field.95, align 4
  %steps.over.98 = icmp ugt i32 %steps.next.97, 10000
  br i1 %steps.over.98, label %failure.99, label %continue.100
failure.99:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.101, align 4
  %status.diagnostic.102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.102, align 4
  ret void
continue.100:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.104 = load i32, ptr %ctx.field.103, align 4
  %steps.next.105 = add i32 %steps.current.104, 1
  store i32 %steps.next.105, ptr %ctx.field.103, align 4
  %steps.over.106 = icmp ugt i32 %steps.next.105, 10000
  br i1 %steps.over.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %depth.exceeded.111 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.111, label %failure.112, label %continue.113
failure.112:
  %ctx.field.114 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.114, align 4
  %status.diagnostic.115 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.115, align 4
  ret void
continue.113:
  %workspace.slot.116 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 7, ptr %workspace.slot.116, align 8
  %workspace.slot.117 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.78, ptr %workspace.slot.117, align 8
  %workspace.slot.118 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.119 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 2, ptr %workspace.slot.118)
  switch i32 %record.make.status.119, label %runtime.invalid.result.125 [ i32 0, label %runtime.success.120 i32 1, label %runtime.invalid.request.121 i32 2, label %runtime.invalid.reference.122 i32 3, label %runtime.scratch.capacity.123 i32 4, label %runtime.retained.capacity.124 ]
runtime.invalid.request.121:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.122:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.123:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.124:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.125:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.120:
  %record.make.handle.126 = load i64, ptr %workspace.slot.118, align 8
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.128 = load i32, ptr %ctx.field.127, align 4
  %steps.next.129 = add i32 %steps.current.128, 1
  store i32 %steps.next.129, ptr %ctx.field.127, align 4
  %steps.over.130 = icmp ugt i32 %steps.next.129, 10000
  br i1 %steps.over.130, label %failure.131, label %continue.132
failure.131:
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.133, align 4
  %status.diagnostic.134 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.134, align 4
  ret void
continue.132:
  %ctx.field.135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.136 = load i32, ptr %ctx.field.135, align 4
  %steps.next.137 = add i32 %steps.current.136, 1
  store i32 %steps.next.137, ptr %ctx.field.135, align 4
  %steps.over.138 = icmp ugt i32 %steps.next.137, 10000
  br i1 %steps.over.138, label %failure.139, label %continue.140
failure.139:
  %ctx.field.141 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.141, align 4
  %status.diagnostic.142 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.142, align 4
  ret void
continue.140:
  %ctx.field.143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.144 = load i32, ptr %ctx.field.143, align 4
  %steps.next.145 = add i32 %steps.current.144, 1
  store i32 %steps.next.145, ptr %ctx.field.143, align 4
  %steps.over.146 = icmp ugt i32 %steps.next.145, 10000
  br i1 %steps.over.146, label %failure.147, label %continue.148
failure.147:
  %ctx.field.149 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.149, align 4
  %status.diagnostic.150 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.150, align 4
  ret void
continue.148:
  %ctx.field.151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.152 = load i32, ptr %ctx.field.151, align 4
  %steps.next.153 = add i32 %steps.current.152, 1
  store i32 %steps.next.153, ptr %ctx.field.151, align 4
  %steps.over.154 = icmp ugt i32 %steps.next.153, 10000
  br i1 %steps.over.154, label %failure.155, label %continue.156
failure.155:
  %ctx.field.157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.157, align 4
  %status.diagnostic.158 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.158, align 4
  ret void
continue.156:
  %ctx.field.159 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.160 = load i32, ptr %ctx.field.159, align 4
  %steps.next.161 = add i32 %steps.current.160, 1
  store i32 %steps.next.161, ptr %ctx.field.159, align 4
  %steps.over.162 = icmp ugt i32 %steps.next.161, 10000
  br i1 %steps.over.162, label %failure.163, label %continue.164
failure.163:
  %ctx.field.165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.165, align 4
  %status.diagnostic.166 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.166, align 4
  ret void
continue.164:
  %depth.exceeded.167 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.167, label %failure.168, label %continue.169
failure.168:
  %ctx.field.170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.170, align 4
  %status.diagnostic.171 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.171, align 4
  ret void
continue.169:
  %workspace.slot.172 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.126, ptr %workspace.slot.172, align 8
  %workspace.slot.173 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 0, ptr %workspace.slot.173, align 8
  %workspace.slot.174 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 0, ptr %workspace.slot.174, align 8
  %workspace.slot.175 = getelementptr inbounds i64, ptr %outputs, i64 3
  %record.make.status.176 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 3, ptr %workspace.slot.175)
  switch i32 %record.make.status.176, label %runtime.invalid.result.182 [ i32 0, label %runtime.success.177 i32 1, label %runtime.invalid.request.178 i32 2, label %runtime.invalid.reference.179 i32 3, label %runtime.scratch.capacity.180 i32 4, label %runtime.retained.capacity.181 ]
runtime.invalid.request.178:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.179:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.180:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.181:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.182:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.177:
  %record.make.handle.183 = load i64, ptr %workspace.slot.175, align 8
  %ctx.field.184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.185 = load i32, ptr %ctx.field.184, align 4
  %steps.next.186 = add i32 %steps.current.185, 1
  store i32 %steps.next.186, ptr %ctx.field.184, align 4
  %steps.over.187 = icmp ugt i32 %steps.next.186, 10000
  br i1 %steps.over.187, label %failure.188, label %continue.189
failure.188:
  %ctx.field.190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.190, align 4
  %status.diagnostic.191 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.191, align 4
  ret void
continue.189:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.193 = load i32, ptr %ctx.field.192, align 4
  %steps.next.194 = add i32 %steps.current.193, 1
  store i32 %steps.next.194, ptr %ctx.field.192, align 4
  %steps.over.195 = icmp ugt i32 %steps.next.194, 10000
  br i1 %steps.over.195, label %failure.196, label %continue.197
failure.196:
  %ctx.field.198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.198, align 4
  %status.diagnostic.199 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.199, align 4
  ret void
continue.197:
  %ctx.field.200 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.201 = load i32, ptr %ctx.field.200, align 4
  %steps.next.202 = add i32 %steps.current.201, 1
  store i32 %steps.next.202, ptr %ctx.field.200, align 4
  %steps.over.203 = icmp ugt i32 %steps.next.202, 10000
  br i1 %steps.over.203, label %failure.204, label %continue.205
failure.204:
  %ctx.field.206 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.206, align 4
  %status.diagnostic.207 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.207, align 4
  ret void
continue.205:
  %depth.exceeded.208 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.208, label %failure.209, label %continue.210
failure.209:
  %ctx.field.211 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.211, align 4
  %status.diagnostic.212 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.212, align 4
  ret void
continue.210:
  %workspace.slot.213 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 9, ptr %workspace.slot.213, align 8
  %workspace.slot.214 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.215 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.214)
  switch i32 %record.make.status.215, label %runtime.invalid.result.221 [ i32 0, label %runtime.success.216 i32 1, label %runtime.invalid.request.217 i32 2, label %runtime.invalid.reference.218 i32 3, label %runtime.scratch.capacity.219 i32 4, label %runtime.retained.capacity.220 ]
runtime.invalid.request.217:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.218:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.219:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.220:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.221:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.216:
  %record.make.handle.222 = load i64, ptr %workspace.slot.214, align 8
  %ctx.field.223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.224 = load i32, ptr %ctx.field.223, align 4
  %steps.next.225 = add i32 %steps.current.224, 1
  store i32 %steps.next.225, ptr %ctx.field.223, align 4
  %steps.over.226 = icmp ugt i32 %steps.next.225, 10000
  br i1 %steps.over.226, label %failure.227, label %continue.228
failure.227:
  %ctx.field.229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.229, align 4
  %status.diagnostic.230 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.230, align 4
  ret void
continue.228:
  %ctx.field.231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.232 = load i32, ptr %ctx.field.231, align 4
  %steps.next.233 = add i32 %steps.current.232, 1
  store i32 %steps.next.233, ptr %ctx.field.231, align 4
  %steps.over.234 = icmp ugt i32 %steps.next.233, 10000
  br i1 %steps.over.234, label %failure.235, label %continue.236
failure.235:
  %ctx.field.237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.237, align 4
  %status.diagnostic.238 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.238, align 4
  ret void
continue.236:
  %ctx.field.239 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.240 = load i32, ptr %ctx.field.239, align 4
  %steps.next.241 = add i32 %steps.current.240, 1
  store i32 %steps.next.241, ptr %ctx.field.239, align 4
  %steps.over.242 = icmp ugt i32 %steps.next.241, 10000
  br i1 %steps.over.242, label %failure.243, label %continue.244
failure.243:
  %ctx.field.245 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.245, align 4
  %status.diagnostic.246 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.246, align 4
  ret void
continue.244:
  %ctx.field.247 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.248 = load i32, ptr %ctx.field.247, align 4
  %steps.next.249 = add i32 %steps.current.248, 1
  store i32 %steps.next.249, ptr %ctx.field.247, align 4
  %steps.over.250 = icmp ugt i32 %steps.next.249, 10000
  br i1 %steps.over.250, label %failure.251, label %continue.252
failure.251:
  %ctx.field.253 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.253, align 4
  %status.diagnostic.254 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.254, align 4
  ret void
continue.252:
  %ctx.field.255 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.256 = load i32, ptr %ctx.field.255, align 4
  %steps.next.257 = add i32 %steps.current.256, 1
  store i32 %steps.next.257, ptr %ctx.field.255, align 4
  %steps.over.258 = icmp ugt i32 %steps.next.257, 10000
  br i1 %steps.over.258, label %failure.259, label %continue.260
failure.259:
  %ctx.field.261 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.261, align 4
  %status.diagnostic.262 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.262, align 4
  ret void
continue.260:
  %output.ptr.263 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.183, ptr %output.ptr.263, align 8
  %output.ptr.264 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.126, ptr %output.ptr.264, align 8
  %output.ptr.265 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %record.make.handle.78, ptr %output.ptr.265, align 8
  %output.ptr.266 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %record.make.handle.222, ptr %output.ptr.266, align 8
  ret void
}

define internal void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %int.compare.21 = icmp sgt i64 %arg0, 0
  %bool.slot.22 = zext i1 %int.compare.21 to i64
  %output.ptr.23 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.22, ptr %output.ptr.23, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 4 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 4, i32 %capacity, ptr %status, i32 4)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 4, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

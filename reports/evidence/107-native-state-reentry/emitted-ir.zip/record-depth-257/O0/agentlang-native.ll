target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [1 x i32] [i32 0]
@agentlang_fields_4 = private constant [1 x i32] [i32 3]
@agentlang_fields_5 = private constant [1 x i32] [i32 248]
@agentlang_fields_6 = private constant [1 x i32] [i32 258]
@agentlang_fields_7 = private constant [1 x i32] [i32 6]
@agentlang_fields_8 = private constant [1 x i32] [i32 7]
@agentlang_fields_9 = private constant [1 x i32] [i32 8]
@agentlang_fields_10 = private constant [1 x i32] [i32 9]
@agentlang_fields_11 = private constant [1 x i32] [i32 10]
@agentlang_fields_12 = private constant [1 x i32] [i32 11]
@agentlang_fields_13 = private constant [1 x i32] [i32 12]
@agentlang_fields_14 = private constant [1 x i32] [i32 13]
@agentlang_fields_15 = private constant [1 x i32] [i32 14]
@agentlang_fields_16 = private constant [1 x i32] [i32 5]
@agentlang_fields_17 = private constant [1 x i32] [i32 15]
@agentlang_fields_18 = private constant [1 x i32] [i32 17]
@agentlang_fields_19 = private constant [1 x i32] [i32 18]
@agentlang_fields_20 = private constant [1 x i32] [i32 19]
@agentlang_fields_21 = private constant [1 x i32] [i32 20]
@agentlang_fields_22 = private constant [1 x i32] [i32 21]
@agentlang_fields_23 = private constant [1 x i32] [i32 22]
@agentlang_fields_24 = private constant [1 x i32] [i32 23]
@agentlang_fields_25 = private constant [1 x i32] [i32 24]
@agentlang_fields_26 = private constant [1 x i32] [i32 25]
@agentlang_fields_27 = private constant [1 x i32] [i32 16]
@agentlang_fields_28 = private constant [1 x i32] [i32 26]
@agentlang_fields_29 = private constant [1 x i32] [i32 28]
@agentlang_fields_30 = private constant [1 x i32] [i32 29]
@agentlang_fields_31 = private constant [1 x i32] [i32 30]
@agentlang_fields_32 = private constant [1 x i32] [i32 31]
@agentlang_fields_33 = private constant [1 x i32] [i32 32]
@agentlang_fields_34 = private constant [1 x i32] [i32 33]
@agentlang_fields_35 = private constant [1 x i32] [i32 34]
@agentlang_fields_36 = private constant [1 x i32] [i32 35]
@agentlang_fields_37 = private constant [1 x i32] [i32 36]
@agentlang_fields_38 = private constant [1 x i32] [i32 27]
@agentlang_fields_39 = private constant [1 x i32] [i32 37]
@agentlang_fields_40 = private constant [1 x i32] [i32 39]
@agentlang_fields_41 = private constant [1 x i32] [i32 40]
@agentlang_fields_42 = private constant [1 x i32] [i32 41]
@agentlang_fields_43 = private constant [1 x i32] [i32 42]
@agentlang_fields_44 = private constant [1 x i32] [i32 43]
@agentlang_fields_45 = private constant [1 x i32] [i32 44]
@agentlang_fields_46 = private constant [1 x i32] [i32 45]
@agentlang_fields_47 = private constant [1 x i32] [i32 46]
@agentlang_fields_48 = private constant [1 x i32] [i32 47]
@agentlang_fields_49 = private constant [1 x i32] [i32 38]
@agentlang_fields_50 = private constant [1 x i32] [i32 48]
@agentlang_fields_51 = private constant [1 x i32] [i32 50]
@agentlang_fields_52 = private constant [1 x i32] [i32 51]
@agentlang_fields_53 = private constant [1 x i32] [i32 52]
@agentlang_fields_54 = private constant [1 x i32] [i32 53]
@agentlang_fields_55 = private constant [1 x i32] [i32 54]
@agentlang_fields_56 = private constant [1 x i32] [i32 55]
@agentlang_fields_57 = private constant [1 x i32] [i32 56]
@agentlang_fields_58 = private constant [1 x i32] [i32 57]
@agentlang_fields_59 = private constant [1 x i32] [i32 58]
@agentlang_fields_60 = private constant [1 x i32] [i32 49]
@agentlang_fields_61 = private constant [1 x i32] [i32 59]
@agentlang_fields_62 = private constant [1 x i32] [i32 61]
@agentlang_fields_63 = private constant [1 x i32] [i32 62]
@agentlang_fields_64 = private constant [1 x i32] [i32 63]
@agentlang_fields_65 = private constant [1 x i32] [i32 64]
@agentlang_fields_66 = private constant [1 x i32] [i32 65]
@agentlang_fields_67 = private constant [1 x i32] [i32 66]
@agentlang_fields_68 = private constant [1 x i32] [i32 67]
@agentlang_fields_69 = private constant [1 x i32] [i32 68]
@agentlang_fields_70 = private constant [1 x i32] [i32 69]
@agentlang_fields_71 = private constant [1 x i32] [i32 60]
@agentlang_fields_72 = private constant [1 x i32] [i32 70]
@agentlang_fields_73 = private constant [1 x i32] [i32 72]
@agentlang_fields_74 = private constant [1 x i32] [i32 73]
@agentlang_fields_75 = private constant [1 x i32] [i32 74]
@agentlang_fields_76 = private constant [1 x i32] [i32 75]
@agentlang_fields_77 = private constant [1 x i32] [i32 76]
@agentlang_fields_78 = private constant [1 x i32] [i32 77]
@agentlang_fields_79 = private constant [1 x i32] [i32 78]
@agentlang_fields_80 = private constant [1 x i32] [i32 79]
@agentlang_fields_81 = private constant [1 x i32] [i32 80]
@agentlang_fields_82 = private constant [1 x i32] [i32 71]
@agentlang_fields_83 = private constant [1 x i32] [i32 81]
@agentlang_fields_84 = private constant [1 x i32] [i32 83]
@agentlang_fields_85 = private constant [1 x i32] [i32 84]
@agentlang_fields_86 = private constant [1 x i32] [i32 85]
@agentlang_fields_87 = private constant [1 x i32] [i32 86]
@agentlang_fields_88 = private constant [1 x i32] [i32 87]
@agentlang_fields_89 = private constant [1 x i32] [i32 88]
@agentlang_fields_90 = private constant [1 x i32] [i32 89]
@agentlang_fields_91 = private constant [1 x i32] [i32 90]
@agentlang_fields_92 = private constant [1 x i32] [i32 91]
@agentlang_fields_93 = private constant [1 x i32] [i32 82]
@agentlang_fields_94 = private constant [1 x i32] [i32 92]
@agentlang_fields_95 = private constant [1 x i32] [i32 94]
@agentlang_fields_96 = private constant [1 x i32] [i32 95]
@agentlang_fields_97 = private constant [1 x i32] [i32 96]
@agentlang_fields_98 = private constant [1 x i32] [i32 97]
@agentlang_fields_99 = private constant [1 x i32] [i32 98]
@agentlang_fields_100 = private constant [1 x i32] [i32 99]
@agentlang_fields_101 = private constant [1 x i32] [i32 100]
@agentlang_fields_102 = private constant [1 x i32] [i32 101]
@agentlang_fields_103 = private constant [1 x i32] [i32 102]
@agentlang_fields_104 = private constant [1 x i32] [i32 93]
@agentlang_fields_105 = private constant [1 x i32] [i32 103]
@agentlang_fields_106 = private constant [1 x i32] [i32 105]
@agentlang_fields_107 = private constant [1 x i32] [i32 106]
@agentlang_fields_108 = private constant [1 x i32] [i32 107]
@agentlang_fields_109 = private constant [1 x i32] [i32 108]
@agentlang_fields_110 = private constant [1 x i32] [i32 109]
@agentlang_fields_111 = private constant [1 x i32] [i32 110]
@agentlang_fields_112 = private constant [1 x i32] [i32 111]
@agentlang_fields_113 = private constant [1 x i32] [i32 112]
@agentlang_fields_114 = private constant [1 x i32] [i32 113]
@agentlang_fields_115 = private constant [1 x i32] [i32 4]
@agentlang_fields_116 = private constant [1 x i32] [i32 104]
@agentlang_fields_117 = private constant [1 x i32] [i32 114]
@agentlang_fields_118 = private constant [1 x i32] [i32 117]
@agentlang_fields_119 = private constant [1 x i32] [i32 118]
@agentlang_fields_120 = private constant [1 x i32] [i32 119]
@agentlang_fields_121 = private constant [1 x i32] [i32 120]
@agentlang_fields_122 = private constant [1 x i32] [i32 121]
@agentlang_fields_123 = private constant [1 x i32] [i32 122]
@agentlang_fields_124 = private constant [1 x i32] [i32 123]
@agentlang_fields_125 = private constant [1 x i32] [i32 124]
@agentlang_fields_126 = private constant [1 x i32] [i32 125]
@agentlang_fields_127 = private constant [1 x i32] [i32 116]
@agentlang_fields_128 = private constant [1 x i32] [i32 126]
@agentlang_fields_129 = private constant [1 x i32] [i32 128]
@agentlang_fields_130 = private constant [1 x i32] [i32 129]
@agentlang_fields_131 = private constant [1 x i32] [i32 130]
@agentlang_fields_132 = private constant [1 x i32] [i32 131]
@agentlang_fields_133 = private constant [1 x i32] [i32 132]
@agentlang_fields_134 = private constant [1 x i32] [i32 133]
@agentlang_fields_135 = private constant [1 x i32] [i32 134]
@agentlang_fields_136 = private constant [1 x i32] [i32 135]
@agentlang_fields_137 = private constant [1 x i32] [i32 136]
@agentlang_fields_138 = private constant [1 x i32] [i32 127]
@agentlang_fields_139 = private constant [1 x i32] [i32 137]
@agentlang_fields_140 = private constant [1 x i32] [i32 139]
@agentlang_fields_141 = private constant [1 x i32] [i32 140]
@agentlang_fields_142 = private constant [1 x i32] [i32 141]
@agentlang_fields_143 = private constant [1 x i32] [i32 142]
@agentlang_fields_144 = private constant [1 x i32] [i32 143]
@agentlang_fields_145 = private constant [1 x i32] [i32 144]
@agentlang_fields_146 = private constant [1 x i32] [i32 145]
@agentlang_fields_147 = private constant [1 x i32] [i32 146]
@agentlang_fields_148 = private constant [1 x i32] [i32 147]
@agentlang_fields_149 = private constant [1 x i32] [i32 138]
@agentlang_fields_150 = private constant [1 x i32] [i32 148]
@agentlang_fields_151 = private constant [1 x i32] [i32 150]
@agentlang_fields_152 = private constant [1 x i32] [i32 151]
@agentlang_fields_153 = private constant [1 x i32] [i32 152]
@agentlang_fields_154 = private constant [1 x i32] [i32 153]
@agentlang_fields_155 = private constant [1 x i32] [i32 154]
@agentlang_fields_156 = private constant [1 x i32] [i32 155]
@agentlang_fields_157 = private constant [1 x i32] [i32 156]
@agentlang_fields_158 = private constant [1 x i32] [i32 157]
@agentlang_fields_159 = private constant [1 x i32] [i32 158]
@agentlang_fields_160 = private constant [1 x i32] [i32 149]
@agentlang_fields_161 = private constant [1 x i32] [i32 159]
@agentlang_fields_162 = private constant [1 x i32] [i32 161]
@agentlang_fields_163 = private constant [1 x i32] [i32 162]
@agentlang_fields_164 = private constant [1 x i32] [i32 163]
@agentlang_fields_165 = private constant [1 x i32] [i32 164]
@agentlang_fields_166 = private constant [1 x i32] [i32 165]
@agentlang_fields_167 = private constant [1 x i32] [i32 166]
@agentlang_fields_168 = private constant [1 x i32] [i32 167]
@agentlang_fields_169 = private constant [1 x i32] [i32 168]
@agentlang_fields_170 = private constant [1 x i32] [i32 169]
@agentlang_fields_171 = private constant [1 x i32] [i32 160]
@agentlang_fields_172 = private constant [1 x i32] [i32 170]
@agentlang_fields_173 = private constant [1 x i32] [i32 172]
@agentlang_fields_174 = private constant [1 x i32] [i32 173]
@agentlang_fields_175 = private constant [1 x i32] [i32 174]
@agentlang_fields_176 = private constant [1 x i32] [i32 175]
@agentlang_fields_177 = private constant [1 x i32] [i32 176]
@agentlang_fields_178 = private constant [1 x i32] [i32 171]
@agentlang_fields_179 = private constant [1 x i32] [i32 178]
@agentlang_fields_180 = private constant [1 x i32] [i32 179]
@agentlang_fields_181 = private constant [1 x i32] [i32 180]
@agentlang_fields_182 = private constant [1 x i32] [i32 115]
@agentlang_fields_183 = private constant [1 x i32] [i32 181]
@agentlang_fields_184 = private constant [1 x i32] [i32 183]
@agentlang_fields_185 = private constant [1 x i32] [i32 184]
@agentlang_fields_186 = private constant [1 x i32] [i32 185]
@agentlang_fields_187 = private constant [1 x i32] [i32 186]
@agentlang_fields_188 = private constant [1 x i32] [i32 187]
@agentlang_fields_189 = private constant [1 x i32] [i32 188]
@agentlang_fields_190 = private constant [1 x i32] [i32 189]
@agentlang_fields_191 = private constant [1 x i32] [i32 190]
@agentlang_fields_192 = private constant [1 x i32] [i32 191]
@agentlang_fields_193 = private constant [1 x i32] [i32 182]
@agentlang_fields_194 = private constant [1 x i32] [i32 192]
@agentlang_fields_195 = private constant [1 x i32] [i32 194]
@agentlang_fields_196 = private constant [1 x i32] [i32 195]
@agentlang_fields_197 = private constant [1 x i32] [i32 196]
@agentlang_fields_198 = private constant [1 x i32] [i32 197]
@agentlang_fields_199 = private constant [1 x i32] [i32 198]
@agentlang_fields_200 = private constant [1 x i32] [i32 199]
@agentlang_fields_201 = private constant [1 x i32] [i32 200]
@agentlang_fields_202 = private constant [1 x i32] [i32 201]
@agentlang_fields_203 = private constant [1 x i32] [i32 202]
@agentlang_fields_204 = private constant [1 x i32] [i32 193]
@agentlang_fields_205 = private constant [1 x i32] [i32 203]
@agentlang_fields_206 = private constant [1 x i32] [i32 205]
@agentlang_fields_207 = private constant [1 x i32] [i32 206]
@agentlang_fields_208 = private constant [1 x i32] [i32 207]
@agentlang_fields_209 = private constant [1 x i32] [i32 208]
@agentlang_fields_210 = private constant [1 x i32] [i32 209]
@agentlang_fields_211 = private constant [1 x i32] [i32 210]
@agentlang_fields_212 = private constant [1 x i32] [i32 211]
@agentlang_fields_213 = private constant [1 x i32] [i32 212]
@agentlang_fields_214 = private constant [1 x i32] [i32 213]
@agentlang_fields_215 = private constant [1 x i32] [i32 204]
@agentlang_fields_216 = private constant [1 x i32] [i32 214]
@agentlang_fields_217 = private constant [1 x i32] [i32 216]
@agentlang_fields_218 = private constant [1 x i32] [i32 217]
@agentlang_fields_219 = private constant [1 x i32] [i32 218]
@agentlang_fields_220 = private constant [1 x i32] [i32 219]
@agentlang_fields_221 = private constant [1 x i32] [i32 220]
@agentlang_fields_222 = private constant [1 x i32] [i32 221]
@agentlang_fields_223 = private constant [1 x i32] [i32 222]
@agentlang_fields_224 = private constant [1 x i32] [i32 223]
@agentlang_fields_225 = private constant [1 x i32] [i32 224]
@agentlang_fields_226 = private constant [1 x i32] [i32 215]
@agentlang_fields_227 = private constant [1 x i32] [i32 225]
@agentlang_fields_228 = private constant [1 x i32] [i32 227]
@agentlang_fields_229 = private constant [1 x i32] [i32 228]
@agentlang_fields_230 = private constant [1 x i32] [i32 229]
@agentlang_fields_231 = private constant [1 x i32] [i32 230]
@agentlang_fields_232 = private constant [1 x i32] [i32 231]
@agentlang_fields_233 = private constant [1 x i32] [i32 232]
@agentlang_fields_234 = private constant [1 x i32] [i32 233]
@agentlang_fields_235 = private constant [1 x i32] [i32 234]
@agentlang_fields_236 = private constant [1 x i32] [i32 235]
@agentlang_fields_237 = private constant [1 x i32] [i32 226]
@agentlang_fields_238 = private constant [1 x i32] [i32 236]
@agentlang_fields_239 = private constant [1 x i32] [i32 238]
@agentlang_fields_240 = private constant [1 x i32] [i32 239]
@agentlang_fields_241 = private constant [1 x i32] [i32 240]
@agentlang_fields_242 = private constant [1 x i32] [i32 241]
@agentlang_fields_243 = private constant [1 x i32] [i32 242]
@agentlang_fields_244 = private constant [1 x i32] [i32 243]
@agentlang_fields_245 = private constant [1 x i32] [i32 244]
@agentlang_fields_246 = private constant [1 x i32] [i32 245]
@agentlang_fields_247 = private constant [1 x i32] [i32 246]
@agentlang_fields_248 = private constant [1 x i32] [i32 237]
@agentlang_fields_249 = private constant [1 x i32] [i32 247]
@agentlang_fields_250 = private constant [1 x i32] [i32 249]
@agentlang_fields_251 = private constant [1 x i32] [i32 250]
@agentlang_fields_252 = private constant [1 x i32] [i32 251]
@agentlang_fields_253 = private constant [1 x i32] [i32 252]
@agentlang_fields_254 = private constant [1 x i32] [i32 253]
@agentlang_fields_255 = private constant [1 x i32] [i32 254]
@agentlang_fields_256 = private constant [1 x i32] [i32 255]
@agentlang_fields_257 = private constant [1 x i32] [i32 256]
@agentlang_fields_258 = private constant [1 x i32] [i32 257]
@agentlang_type_descriptors = private constant [259 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_8, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_9, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_10, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_11, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_12, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_13, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_14, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_15, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_16, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_17, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_18, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_19, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_20, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_21, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_22, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_23, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_24, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_25, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_26, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_27, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_28, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_29, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_30, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_31, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_32, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_33, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_34, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_35, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_36, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_37, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_38, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_39, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_40, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_41, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_42, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_43, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_44, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_45, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_46, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_47, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_48, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_49, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_50, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_51, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_52, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_53, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_54, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_55, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_56, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_57, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_58, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_59, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_60, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_61, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_62, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_63, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_64, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_65, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_66, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_67, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_68, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_69, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_70, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_71, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_72, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_73, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_74, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_75, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_76, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_77, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_78, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_79, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_80, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_81, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_82, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_83, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_84, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_85, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_86, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_87, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_88, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_89, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_90, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_91, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_92, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_93, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_94, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_95, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_96, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_97, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_98, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_99, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_100, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_101, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_102, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_103, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_104, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_105, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_106, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_107, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_108, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_109, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_110, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_111, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_112, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_113, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_114, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_115, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_116, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_117, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_118, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_119, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_120, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_121, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_122, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_123, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_124, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_125, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_126, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_127, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_128, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_129, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_130, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_131, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_132, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_133, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_134, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_135, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_136, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_137, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_138, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_139, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_140, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_141, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_142, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_143, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_144, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_145, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_146, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_147, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_148, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_149, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_150, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_151, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_152, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_153, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_154, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_155, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_156, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_157, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_158, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_159, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_160, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_161, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_162, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_163, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_164, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_165, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_166, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_167, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_168, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_169, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_170, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_171, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_172, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_173, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_174, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_175, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_176, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_177, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_178, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_179, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_180, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_181, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_182, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_183, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_184, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_185, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_186, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_187, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_188, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_189, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_190, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_191, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_192, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_193, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_194, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_195, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_196, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_197, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_198, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_199, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_200, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_201, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_202, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_203, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_204, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_205, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_206, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_207, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_208, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_209, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_210, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_211, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_212, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_213, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_214, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_215, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_216, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_217, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_218, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_219, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_220, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_221, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_222, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_223, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_224, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_225, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_226, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_227, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_228, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_229, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_230, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_231, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_232, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_233, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_234, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_235, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_236, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_237, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_238, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_239, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_240, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_241, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_242, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_243, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_244, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_245, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_246, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_247, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_248, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_249, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_250, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_251, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_252, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_253, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_254, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_255, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_256, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_257, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_258, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([259 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 259, i32 0 }
@agentlang_root_type_ids = private constant [0 x i32] []
@agentlang_input_type_ids = private constant [0 x i32] []

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %workspace.slot.21 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 1, ptr %workspace.slot.21, align 8
  %workspace.slot.22 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.23 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 1, ptr %workspace.slot.22)
  switch i32 %record.make.status.23, label %runtime.invalid.result.29 [ i32 0, label %runtime.success.24 i32 1, label %runtime.invalid.request.25 i32 2, label %runtime.invalid.reference.26 i32 3, label %runtime.scratch.capacity.27 i32 4, label %runtime.retained.capacity.28 ]
runtime.invalid.request.25:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.26:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.27:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.28:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.29:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.24:
  %record.make.handle.30 = load i64, ptr %workspace.slot.22, align 8
  %ctx.field.31 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.32 = load i32, ptr %ctx.field.31, align 4
  %steps.next.33 = add i32 %steps.current.32, 1
  store i32 %steps.next.33, ptr %ctx.field.31, align 4
  %steps.over.34 = icmp ugt i32 %steps.next.33, 10000
  br i1 %steps.over.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.40 = load i32, ptr %ctx.field.39, align 4
  %steps.next.41 = add i32 %steps.current.40, 1
  store i32 %steps.next.41, ptr %ctx.field.39, align 4
  %steps.over.42 = icmp ugt i32 %steps.next.41, 10000
  br i1 %steps.over.42, label %failure.43, label %continue.44
failure.43:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.45, align 4
  %status.diagnostic.46 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.46, align 4
  ret void
continue.44:
  %ctx.field.47 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.48 = load i32, ptr %ctx.field.47, align 4
  %steps.next.49 = add i32 %steps.current.48, 1
  store i32 %steps.next.49, ptr %ctx.field.47, align 4
  %steps.over.50 = icmp ugt i32 %steps.next.49, 10000
  br i1 %steps.over.50, label %failure.51, label %continue.52
failure.51:
  %ctx.field.53 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.53, align 4
  %status.diagnostic.54 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.54, align 4
  ret void
continue.52:
  %depth.exceeded.55 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %workspace.slot.60 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.30, ptr %workspace.slot.60, align 8
  %workspace.slot.61 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.62 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 1, ptr %workspace.slot.61)
  switch i32 %record.make.status.62, label %runtime.invalid.result.68 [ i32 0, label %runtime.success.63 i32 1, label %runtime.invalid.request.64 i32 2, label %runtime.invalid.reference.65 i32 3, label %runtime.scratch.capacity.66 i32 4, label %runtime.retained.capacity.67 ]
runtime.invalid.request.64:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.65:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.66:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.67:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.68:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.63:
  %record.make.handle.69 = load i64, ptr %workspace.slot.61, align 8
  %ctx.field.70 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.71 = load i32, ptr %ctx.field.70, align 4
  %steps.next.72 = add i32 %steps.current.71, 1
  store i32 %steps.next.72, ptr %ctx.field.70, align 4
  %steps.over.73 = icmp ugt i32 %steps.next.72, 10000
  br i1 %steps.over.73, label %failure.74, label %continue.75
failure.74:
  %ctx.field.76 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.76, align 4
  %status.diagnostic.77 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.77, align 4
  ret void
continue.75:
  %ctx.field.78 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.79 = load i32, ptr %ctx.field.78, align 4
  %steps.next.80 = add i32 %steps.current.79, 1
  store i32 %steps.next.80, ptr %ctx.field.78, align 4
  %steps.over.81 = icmp ugt i32 %steps.next.80, 10000
  br i1 %steps.over.81, label %failure.82, label %continue.83
failure.82:
  %ctx.field.84 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.84, align 4
  %status.diagnostic.85 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.85, align 4
  ret void
continue.83:
  %ctx.field.86 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.87 = load i32, ptr %ctx.field.86, align 4
  %steps.next.88 = add i32 %steps.current.87, 1
  store i32 %steps.next.88, ptr %ctx.field.86, align 4
  %steps.over.89 = icmp ugt i32 %steps.next.88, 10000
  br i1 %steps.over.89, label %failure.90, label %continue.91
failure.90:
  %ctx.field.92 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.92, align 4
  %status.diagnostic.93 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.93, align 4
  ret void
continue.91:
  %depth.exceeded.94 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.94, label %failure.95, label %continue.96
failure.95:
  %ctx.field.97 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.97, align 4
  %status.diagnostic.98 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.98, align 4
  ret void
continue.96:
  %workspace.slot.99 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.69, ptr %workspace.slot.99, align 8
  %workspace.slot.100 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.101 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 115, ptr %outputs, i32 1, ptr %workspace.slot.100)
  switch i32 %record.make.status.101, label %runtime.invalid.result.107 [ i32 0, label %runtime.success.102 i32 1, label %runtime.invalid.request.103 i32 2, label %runtime.invalid.reference.104 i32 3, label %runtime.scratch.capacity.105 i32 4, label %runtime.retained.capacity.106 ]
runtime.invalid.request.103:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.104:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.105:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.106:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.107:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.102:
  %record.make.handle.108 = load i64, ptr %workspace.slot.100, align 8
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.110 = load i32, ptr %ctx.field.109, align 4
  %steps.next.111 = add i32 %steps.current.110, 1
  store i32 %steps.next.111, ptr %ctx.field.109, align 4
  %steps.over.112 = icmp ugt i32 %steps.next.111, 10000
  br i1 %steps.over.112, label %failure.113, label %continue.114
failure.113:
  %ctx.field.115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.115, align 4
  %status.diagnostic.116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.116, align 4
  ret void
continue.114:
  %ctx.field.117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.118 = load i32, ptr %ctx.field.117, align 4
  %steps.next.119 = add i32 %steps.current.118, 1
  store i32 %steps.next.119, ptr %ctx.field.117, align 4
  %steps.over.120 = icmp ugt i32 %steps.next.119, 10000
  br i1 %steps.over.120, label %failure.121, label %continue.122
failure.121:
  %ctx.field.123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.123, align 4
  %status.diagnostic.124 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.124, align 4
  ret void
continue.122:
  %ctx.field.125 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.126 = load i32, ptr %ctx.field.125, align 4
  %steps.next.127 = add i32 %steps.current.126, 1
  store i32 %steps.next.127, ptr %ctx.field.125, align 4
  %steps.over.128 = icmp ugt i32 %steps.next.127, 10000
  br i1 %steps.over.128, label %failure.129, label %continue.130
failure.129:
  %ctx.field.131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.131, align 4
  %status.diagnostic.132 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.132, align 4
  ret void
continue.130:
  %depth.exceeded.133 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.133, label %failure.134, label %continue.135
failure.134:
  %ctx.field.136 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.136, align 4
  %status.diagnostic.137 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.137, align 4
  ret void
continue.135:
  %workspace.slot.138 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.108, ptr %workspace.slot.138, align 8
  %workspace.slot.139 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.140 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 182, ptr %outputs, i32 1, ptr %workspace.slot.139)
  switch i32 %record.make.status.140, label %runtime.invalid.result.146 [ i32 0, label %runtime.success.141 i32 1, label %runtime.invalid.request.142 i32 2, label %runtime.invalid.reference.143 i32 3, label %runtime.scratch.capacity.144 i32 4, label %runtime.retained.capacity.145 ]
runtime.invalid.request.142:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.143:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.144:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.145:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.146:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.141:
  %record.make.handle.147 = load i64, ptr %workspace.slot.139, align 8
  %ctx.field.148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.149 = load i32, ptr %ctx.field.148, align 4
  %steps.next.150 = add i32 %steps.current.149, 1
  store i32 %steps.next.150, ptr %ctx.field.148, align 4
  %steps.over.151 = icmp ugt i32 %steps.next.150, 10000
  br i1 %steps.over.151, label %failure.152, label %continue.153
failure.152:
  %ctx.field.154 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.154, align 4
  %status.diagnostic.155 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.155, align 4
  ret void
continue.153:
  %ctx.field.156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.157 = load i32, ptr %ctx.field.156, align 4
  %steps.next.158 = add i32 %steps.current.157, 1
  store i32 %steps.next.158, ptr %ctx.field.156, align 4
  %steps.over.159 = icmp ugt i32 %steps.next.158, 10000
  br i1 %steps.over.159, label %failure.160, label %continue.161
failure.160:
  %ctx.field.162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.162, align 4
  %status.diagnostic.163 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.163, align 4
  ret void
continue.161:
  %ctx.field.164 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.165 = load i32, ptr %ctx.field.164, align 4
  %steps.next.166 = add i32 %steps.current.165, 1
  store i32 %steps.next.166, ptr %ctx.field.164, align 4
  %steps.over.167 = icmp ugt i32 %steps.next.166, 10000
  br i1 %steps.over.167, label %failure.168, label %continue.169
failure.168:
  %ctx.field.170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.170, align 4
  %status.diagnostic.171 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.171, align 4
  ret void
continue.169:
  %depth.exceeded.172 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.172, label %failure.173, label %continue.174
failure.173:
  %ctx.field.175 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.175, align 4
  %status.diagnostic.176 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.176, align 4
  ret void
continue.174:
  %workspace.slot.177 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.147, ptr %workspace.slot.177, align 8
  %workspace.slot.178 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.179 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 193, ptr %outputs, i32 1, ptr %workspace.slot.178)
  switch i32 %record.make.status.179, label %runtime.invalid.result.185 [ i32 0, label %runtime.success.180 i32 1, label %runtime.invalid.request.181 i32 2, label %runtime.invalid.reference.182 i32 3, label %runtime.scratch.capacity.183 i32 4, label %runtime.retained.capacity.184 ]
runtime.invalid.request.181:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.182:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.183:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.184:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.185:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.180:
  %record.make.handle.186 = load i64, ptr %workspace.slot.178, align 8
  %ctx.field.187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.188 = load i32, ptr %ctx.field.187, align 4
  %steps.next.189 = add i32 %steps.current.188, 1
  store i32 %steps.next.189, ptr %ctx.field.187, align 4
  %steps.over.190 = icmp ugt i32 %steps.next.189, 10000
  br i1 %steps.over.190, label %failure.191, label %continue.192
failure.191:
  %ctx.field.193 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.193, align 4
  %status.diagnostic.194 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.194, align 4
  ret void
continue.192:
  %ctx.field.195 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.196 = load i32, ptr %ctx.field.195, align 4
  %steps.next.197 = add i32 %steps.current.196, 1
  store i32 %steps.next.197, ptr %ctx.field.195, align 4
  %steps.over.198 = icmp ugt i32 %steps.next.197, 10000
  br i1 %steps.over.198, label %failure.199, label %continue.200
failure.199:
  %ctx.field.201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.201, align 4
  %status.diagnostic.202 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.202, align 4
  ret void
continue.200:
  %ctx.field.203 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.204 = load i32, ptr %ctx.field.203, align 4
  %steps.next.205 = add i32 %steps.current.204, 1
  store i32 %steps.next.205, ptr %ctx.field.203, align 4
  %steps.over.206 = icmp ugt i32 %steps.next.205, 10000
  br i1 %steps.over.206, label %failure.207, label %continue.208
failure.207:
  %ctx.field.209 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.209, align 4
  %status.diagnostic.210 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.210, align 4
  ret void
continue.208:
  %depth.exceeded.211 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.211, label %failure.212, label %continue.213
failure.212:
  %ctx.field.214 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.214, align 4
  %status.diagnostic.215 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.215, align 4
  ret void
continue.213:
  %workspace.slot.216 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.186, ptr %workspace.slot.216, align 8
  %workspace.slot.217 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.218 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 204, ptr %outputs, i32 1, ptr %workspace.slot.217)
  switch i32 %record.make.status.218, label %runtime.invalid.result.224 [ i32 0, label %runtime.success.219 i32 1, label %runtime.invalid.request.220 i32 2, label %runtime.invalid.reference.221 i32 3, label %runtime.scratch.capacity.222 i32 4, label %runtime.retained.capacity.223 ]
runtime.invalid.request.220:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.221:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.222:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.223:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.224:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.219:
  %record.make.handle.225 = load i64, ptr %workspace.slot.217, align 8
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.227 = load i32, ptr %ctx.field.226, align 4
  %steps.next.228 = add i32 %steps.current.227, 1
  store i32 %steps.next.228, ptr %ctx.field.226, align 4
  %steps.over.229 = icmp ugt i32 %steps.next.228, 10000
  br i1 %steps.over.229, label %failure.230, label %continue.231
failure.230:
  %ctx.field.232 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.232, align 4
  %status.diagnostic.233 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.233, align 4
  ret void
continue.231:
  %ctx.field.234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.235 = load i32, ptr %ctx.field.234, align 4
  %steps.next.236 = add i32 %steps.current.235, 1
  store i32 %steps.next.236, ptr %ctx.field.234, align 4
  %steps.over.237 = icmp ugt i32 %steps.next.236, 10000
  br i1 %steps.over.237, label %failure.238, label %continue.239
failure.238:
  %ctx.field.240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.240, align 4
  %status.diagnostic.241 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.241, align 4
  ret void
continue.239:
  %ctx.field.242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.243 = load i32, ptr %ctx.field.242, align 4
  %steps.next.244 = add i32 %steps.current.243, 1
  store i32 %steps.next.244, ptr %ctx.field.242, align 4
  %steps.over.245 = icmp ugt i32 %steps.next.244, 10000
  br i1 %steps.over.245, label %failure.246, label %continue.247
failure.246:
  %ctx.field.248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.248, align 4
  %status.diagnostic.249 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.249, align 4
  ret void
continue.247:
  %depth.exceeded.250 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.250, label %failure.251, label %continue.252
failure.251:
  %ctx.field.253 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.253, align 4
  %status.diagnostic.254 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.254, align 4
  ret void
continue.252:
  %workspace.slot.255 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.225, ptr %workspace.slot.255, align 8
  %workspace.slot.256 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.257 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 215, ptr %outputs, i32 1, ptr %workspace.slot.256)
  switch i32 %record.make.status.257, label %runtime.invalid.result.263 [ i32 0, label %runtime.success.258 i32 1, label %runtime.invalid.request.259 i32 2, label %runtime.invalid.reference.260 i32 3, label %runtime.scratch.capacity.261 i32 4, label %runtime.retained.capacity.262 ]
runtime.invalid.request.259:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.260:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.261:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.262:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.263:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.258:
  %record.make.handle.264 = load i64, ptr %workspace.slot.256, align 8
  %ctx.field.265 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.266 = load i32, ptr %ctx.field.265, align 4
  %steps.next.267 = add i32 %steps.current.266, 1
  store i32 %steps.next.267, ptr %ctx.field.265, align 4
  %steps.over.268 = icmp ugt i32 %steps.next.267, 10000
  br i1 %steps.over.268, label %failure.269, label %continue.270
failure.269:
  %ctx.field.271 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.271, align 4
  %status.diagnostic.272 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.272, align 4
  ret void
continue.270:
  %ctx.field.273 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.274 = load i32, ptr %ctx.field.273, align 4
  %steps.next.275 = add i32 %steps.current.274, 1
  store i32 %steps.next.275, ptr %ctx.field.273, align 4
  %steps.over.276 = icmp ugt i32 %steps.next.275, 10000
  br i1 %steps.over.276, label %failure.277, label %continue.278
failure.277:
  %ctx.field.279 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.279, align 4
  %status.diagnostic.280 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.280, align 4
  ret void
continue.278:
  %ctx.field.281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.282 = load i32, ptr %ctx.field.281, align 4
  %steps.next.283 = add i32 %steps.current.282, 1
  store i32 %steps.next.283, ptr %ctx.field.281, align 4
  %steps.over.284 = icmp ugt i32 %steps.next.283, 10000
  br i1 %steps.over.284, label %failure.285, label %continue.286
failure.285:
  %ctx.field.287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.287, align 4
  %status.diagnostic.288 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.288, align 4
  ret void
continue.286:
  %depth.exceeded.289 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.289, label %failure.290, label %continue.291
failure.290:
  %ctx.field.292 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.292, align 4
  %status.diagnostic.293 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.293, align 4
  ret void
continue.291:
  %workspace.slot.294 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.264, ptr %workspace.slot.294, align 8
  %workspace.slot.295 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.296 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 226, ptr %outputs, i32 1, ptr %workspace.slot.295)
  switch i32 %record.make.status.296, label %runtime.invalid.result.302 [ i32 0, label %runtime.success.297 i32 1, label %runtime.invalid.request.298 i32 2, label %runtime.invalid.reference.299 i32 3, label %runtime.scratch.capacity.300 i32 4, label %runtime.retained.capacity.301 ]
runtime.invalid.request.298:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.299:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.300:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.301:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.302:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.297:
  %record.make.handle.303 = load i64, ptr %workspace.slot.295, align 8
  %ctx.field.304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.305 = load i32, ptr %ctx.field.304, align 4
  %steps.next.306 = add i32 %steps.current.305, 1
  store i32 %steps.next.306, ptr %ctx.field.304, align 4
  %steps.over.307 = icmp ugt i32 %steps.next.306, 10000
  br i1 %steps.over.307, label %failure.308, label %continue.309
failure.308:
  %ctx.field.310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.310, align 4
  %status.diagnostic.311 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.311, align 4
  ret void
continue.309:
  %ctx.field.312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.313 = load i32, ptr %ctx.field.312, align 4
  %steps.next.314 = add i32 %steps.current.313, 1
  store i32 %steps.next.314, ptr %ctx.field.312, align 4
  %steps.over.315 = icmp ugt i32 %steps.next.314, 10000
  br i1 %steps.over.315, label %failure.316, label %continue.317
failure.316:
  %ctx.field.318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.318, align 4
  %status.diagnostic.319 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.319, align 4
  ret void
continue.317:
  %ctx.field.320 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.321 = load i32, ptr %ctx.field.320, align 4
  %steps.next.322 = add i32 %steps.current.321, 1
  store i32 %steps.next.322, ptr %ctx.field.320, align 4
  %steps.over.323 = icmp ugt i32 %steps.next.322, 10000
  br i1 %steps.over.323, label %failure.324, label %continue.325
failure.324:
  %ctx.field.326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.326, align 4
  %status.diagnostic.327 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.327, align 4
  ret void
continue.325:
  %depth.exceeded.328 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.328, label %failure.329, label %continue.330
failure.329:
  %ctx.field.331 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.331, align 4
  %status.diagnostic.332 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.332, align 4
  ret void
continue.330:
  %workspace.slot.333 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.303, ptr %workspace.slot.333, align 8
  %workspace.slot.334 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.335 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 237, ptr %outputs, i32 1, ptr %workspace.slot.334)
  switch i32 %record.make.status.335, label %runtime.invalid.result.341 [ i32 0, label %runtime.success.336 i32 1, label %runtime.invalid.request.337 i32 2, label %runtime.invalid.reference.338 i32 3, label %runtime.scratch.capacity.339 i32 4, label %runtime.retained.capacity.340 ]
runtime.invalid.request.337:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.338:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.339:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.340:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.341:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.336:
  %record.make.handle.342 = load i64, ptr %workspace.slot.334, align 8
  %ctx.field.343 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.344 = load i32, ptr %ctx.field.343, align 4
  %steps.next.345 = add i32 %steps.current.344, 1
  store i32 %steps.next.345, ptr %ctx.field.343, align 4
  %steps.over.346 = icmp ugt i32 %steps.next.345, 10000
  br i1 %steps.over.346, label %failure.347, label %continue.348
failure.347:
  %ctx.field.349 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.349, align 4
  %status.diagnostic.350 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.350, align 4
  ret void
continue.348:
  %ctx.field.351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.352 = load i32, ptr %ctx.field.351, align 4
  %steps.next.353 = add i32 %steps.current.352, 1
  store i32 %steps.next.353, ptr %ctx.field.351, align 4
  %steps.over.354 = icmp ugt i32 %steps.next.353, 10000
  br i1 %steps.over.354, label %failure.355, label %continue.356
failure.355:
  %ctx.field.357 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.357, align 4
  %status.diagnostic.358 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.358, align 4
  ret void
continue.356:
  %ctx.field.359 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.360 = load i32, ptr %ctx.field.359, align 4
  %steps.next.361 = add i32 %steps.current.360, 1
  store i32 %steps.next.361, ptr %ctx.field.359, align 4
  %steps.over.362 = icmp ugt i32 %steps.next.361, 10000
  br i1 %steps.over.362, label %failure.363, label %continue.364
failure.363:
  %ctx.field.365 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.365, align 4
  %status.diagnostic.366 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.366, align 4
  ret void
continue.364:
  %depth.exceeded.367 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.367, label %failure.368, label %continue.369
failure.368:
  %ctx.field.370 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.370, align 4
  %status.diagnostic.371 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.371, align 4
  ret void
continue.369:
  %workspace.slot.372 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.342, ptr %workspace.slot.372, align 8
  %workspace.slot.373 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.374 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 248, ptr %outputs, i32 1, ptr %workspace.slot.373)
  switch i32 %record.make.status.374, label %runtime.invalid.result.380 [ i32 0, label %runtime.success.375 i32 1, label %runtime.invalid.request.376 i32 2, label %runtime.invalid.reference.377 i32 3, label %runtime.scratch.capacity.378 i32 4, label %runtime.retained.capacity.379 ]
runtime.invalid.request.376:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.377:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.378:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.379:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.380:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.375:
  %record.make.handle.381 = load i64, ptr %workspace.slot.373, align 8
  %ctx.field.382 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.383 = load i32, ptr %ctx.field.382, align 4
  %steps.next.384 = add i32 %steps.current.383, 1
  store i32 %steps.next.384, ptr %ctx.field.382, align 4
  %steps.over.385 = icmp ugt i32 %steps.next.384, 10000
  br i1 %steps.over.385, label %failure.386, label %continue.387
failure.386:
  %ctx.field.388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.388, align 4
  %status.diagnostic.389 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.389, align 4
  ret void
continue.387:
  %ctx.field.390 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.391 = load i32, ptr %ctx.field.390, align 4
  %steps.next.392 = add i32 %steps.current.391, 1
  store i32 %steps.next.392, ptr %ctx.field.390, align 4
  %steps.over.393 = icmp ugt i32 %steps.next.392, 10000
  br i1 %steps.over.393, label %failure.394, label %continue.395
failure.394:
  %ctx.field.396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.396, align 4
  %status.diagnostic.397 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.397, align 4
  ret void
continue.395:
  %ctx.field.398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.399 = load i32, ptr %ctx.field.398, align 4
  %steps.next.400 = add i32 %steps.current.399, 1
  store i32 %steps.next.400, ptr %ctx.field.398, align 4
  %steps.over.401 = icmp ugt i32 %steps.next.400, 10000
  br i1 %steps.over.401, label %failure.402, label %continue.403
failure.402:
  %ctx.field.404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.404, align 4
  %status.diagnostic.405 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.405, align 4
  ret void
continue.403:
  %depth.exceeded.406 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.406, label %failure.407, label %continue.408
failure.407:
  %ctx.field.409 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.409, align 4
  %status.diagnostic.410 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.410, align 4
  ret void
continue.408:
  %workspace.slot.411 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.381, ptr %workspace.slot.411, align 8
  %workspace.slot.412 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.413 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.412)
  switch i32 %record.make.status.413, label %runtime.invalid.result.419 [ i32 0, label %runtime.success.414 i32 1, label %runtime.invalid.request.415 i32 2, label %runtime.invalid.reference.416 i32 3, label %runtime.scratch.capacity.417 i32 4, label %runtime.retained.capacity.418 ]
runtime.invalid.request.415:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.416:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.417:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.418:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.419:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.414:
  %record.make.handle.420 = load i64, ptr %workspace.slot.412, align 8
  %ctx.field.421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.422 = load i32, ptr %ctx.field.421, align 4
  %steps.next.423 = add i32 %steps.current.422, 1
  store i32 %steps.next.423, ptr %ctx.field.421, align 4
  %steps.over.424 = icmp ugt i32 %steps.next.423, 10000
  br i1 %steps.over.424, label %failure.425, label %continue.426
failure.425:
  %ctx.field.427 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.427, align 4
  %status.diagnostic.428 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.428, align 4
  ret void
continue.426:
  %ctx.field.429 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.430 = load i32, ptr %ctx.field.429, align 4
  %steps.next.431 = add i32 %steps.current.430, 1
  store i32 %steps.next.431, ptr %ctx.field.429, align 4
  %steps.over.432 = icmp ugt i32 %steps.next.431, 10000
  br i1 %steps.over.432, label %failure.433, label %continue.434
failure.433:
  %ctx.field.435 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.435, align 4
  %status.diagnostic.436 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.436, align 4
  ret void
continue.434:
  %ctx.field.437 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.438 = load i32, ptr %ctx.field.437, align 4
  %steps.next.439 = add i32 %steps.current.438, 1
  store i32 %steps.next.439, ptr %ctx.field.437, align 4
  %steps.over.440 = icmp ugt i32 %steps.next.439, 10000
  br i1 %steps.over.440, label %failure.441, label %continue.442
failure.441:
  %ctx.field.443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.443, align 4
  %status.diagnostic.444 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.444, align 4
  ret void
continue.442:
  %depth.exceeded.445 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.445, label %failure.446, label %continue.447
failure.446:
  %ctx.field.448 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.448, align 4
  %status.diagnostic.449 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.449, align 4
  ret void
continue.447:
  %workspace.slot.450 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.420, ptr %workspace.slot.450, align 8
  %workspace.slot.451 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.452 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 16, ptr %outputs, i32 1, ptr %workspace.slot.451)
  switch i32 %record.make.status.452, label %runtime.invalid.result.458 [ i32 0, label %runtime.success.453 i32 1, label %runtime.invalid.request.454 i32 2, label %runtime.invalid.reference.455 i32 3, label %runtime.scratch.capacity.456 i32 4, label %runtime.retained.capacity.457 ]
runtime.invalid.request.454:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.455:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.456:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.457:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.458:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.453:
  %record.make.handle.459 = load i64, ptr %workspace.slot.451, align 8
  %ctx.field.460 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.461 = load i32, ptr %ctx.field.460, align 4
  %steps.next.462 = add i32 %steps.current.461, 1
  store i32 %steps.next.462, ptr %ctx.field.460, align 4
  %steps.over.463 = icmp ugt i32 %steps.next.462, 10000
  br i1 %steps.over.463, label %failure.464, label %continue.465
failure.464:
  %ctx.field.466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.466, align 4
  %status.diagnostic.467 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.467, align 4
  ret void
continue.465:
  %ctx.field.468 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.469 = load i32, ptr %ctx.field.468, align 4
  %steps.next.470 = add i32 %steps.current.469, 1
  store i32 %steps.next.470, ptr %ctx.field.468, align 4
  %steps.over.471 = icmp ugt i32 %steps.next.470, 10000
  br i1 %steps.over.471, label %failure.472, label %continue.473
failure.472:
  %ctx.field.474 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.474, align 4
  %status.diagnostic.475 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.475, align 4
  ret void
continue.473:
  %ctx.field.476 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.477 = load i32, ptr %ctx.field.476, align 4
  %steps.next.478 = add i32 %steps.current.477, 1
  store i32 %steps.next.478, ptr %ctx.field.476, align 4
  %steps.over.479 = icmp ugt i32 %steps.next.478, 10000
  br i1 %steps.over.479, label %failure.480, label %continue.481
failure.480:
  %ctx.field.482 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.482, align 4
  %status.diagnostic.483 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.483, align 4
  ret void
continue.481:
  %depth.exceeded.484 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.484, label %failure.485, label %continue.486
failure.485:
  %ctx.field.487 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.487, align 4
  %status.diagnostic.488 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.488, align 4
  ret void
continue.486:
  %workspace.slot.489 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.459, ptr %workspace.slot.489, align 8
  %workspace.slot.490 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.491 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 27, ptr %outputs, i32 1, ptr %workspace.slot.490)
  switch i32 %record.make.status.491, label %runtime.invalid.result.497 [ i32 0, label %runtime.success.492 i32 1, label %runtime.invalid.request.493 i32 2, label %runtime.invalid.reference.494 i32 3, label %runtime.scratch.capacity.495 i32 4, label %runtime.retained.capacity.496 ]
runtime.invalid.request.493:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.494:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.495:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.496:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.497:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.492:
  %record.make.handle.498 = load i64, ptr %workspace.slot.490, align 8
  %ctx.field.499 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.500 = load i32, ptr %ctx.field.499, align 4
  %steps.next.501 = add i32 %steps.current.500, 1
  store i32 %steps.next.501, ptr %ctx.field.499, align 4
  %steps.over.502 = icmp ugt i32 %steps.next.501, 10000
  br i1 %steps.over.502, label %failure.503, label %continue.504
failure.503:
  %ctx.field.505 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.505, align 4
  %status.diagnostic.506 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.506, align 4
  ret void
continue.504:
  %ctx.field.507 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.508 = load i32, ptr %ctx.field.507, align 4
  %steps.next.509 = add i32 %steps.current.508, 1
  store i32 %steps.next.509, ptr %ctx.field.507, align 4
  %steps.over.510 = icmp ugt i32 %steps.next.509, 10000
  br i1 %steps.over.510, label %failure.511, label %continue.512
failure.511:
  %ctx.field.513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.513, align 4
  %status.diagnostic.514 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.514, align 4
  ret void
continue.512:
  %ctx.field.515 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.516 = load i32, ptr %ctx.field.515, align 4
  %steps.next.517 = add i32 %steps.current.516, 1
  store i32 %steps.next.517, ptr %ctx.field.515, align 4
  %steps.over.518 = icmp ugt i32 %steps.next.517, 10000
  br i1 %steps.over.518, label %failure.519, label %continue.520
failure.519:
  %ctx.field.521 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.521, align 4
  %status.diagnostic.522 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.522, align 4
  ret void
continue.520:
  %depth.exceeded.523 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.523, label %failure.524, label %continue.525
failure.524:
  %ctx.field.526 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.526, align 4
  %status.diagnostic.527 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.527, align 4
  ret void
continue.525:
  %workspace.slot.528 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.498, ptr %workspace.slot.528, align 8
  %workspace.slot.529 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.530 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 38, ptr %outputs, i32 1, ptr %workspace.slot.529)
  switch i32 %record.make.status.530, label %runtime.invalid.result.536 [ i32 0, label %runtime.success.531 i32 1, label %runtime.invalid.request.532 i32 2, label %runtime.invalid.reference.533 i32 3, label %runtime.scratch.capacity.534 i32 4, label %runtime.retained.capacity.535 ]
runtime.invalid.request.532:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.533:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.534:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.535:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.536:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.531:
  %record.make.handle.537 = load i64, ptr %workspace.slot.529, align 8
  %ctx.field.538 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.539 = load i32, ptr %ctx.field.538, align 4
  %steps.next.540 = add i32 %steps.current.539, 1
  store i32 %steps.next.540, ptr %ctx.field.538, align 4
  %steps.over.541 = icmp ugt i32 %steps.next.540, 10000
  br i1 %steps.over.541, label %failure.542, label %continue.543
failure.542:
  %ctx.field.544 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.544, align 4
  %status.diagnostic.545 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.545, align 4
  ret void
continue.543:
  %ctx.field.546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.547 = load i32, ptr %ctx.field.546, align 4
  %steps.next.548 = add i32 %steps.current.547, 1
  store i32 %steps.next.548, ptr %ctx.field.546, align 4
  %steps.over.549 = icmp ugt i32 %steps.next.548, 10000
  br i1 %steps.over.549, label %failure.550, label %continue.551
failure.550:
  %ctx.field.552 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.552, align 4
  %status.diagnostic.553 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.553, align 4
  ret void
continue.551:
  %ctx.field.554 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.555 = load i32, ptr %ctx.field.554, align 4
  %steps.next.556 = add i32 %steps.current.555, 1
  store i32 %steps.next.556, ptr %ctx.field.554, align 4
  %steps.over.557 = icmp ugt i32 %steps.next.556, 10000
  br i1 %steps.over.557, label %failure.558, label %continue.559
failure.558:
  %ctx.field.560 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.560, align 4
  %status.diagnostic.561 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.561, align 4
  ret void
continue.559:
  %depth.exceeded.562 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.562, label %failure.563, label %continue.564
failure.563:
  %ctx.field.565 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.565, align 4
  %status.diagnostic.566 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.566, align 4
  ret void
continue.564:
  %workspace.slot.567 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.537, ptr %workspace.slot.567, align 8
  %workspace.slot.568 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.569 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 49, ptr %outputs, i32 1, ptr %workspace.slot.568)
  switch i32 %record.make.status.569, label %runtime.invalid.result.575 [ i32 0, label %runtime.success.570 i32 1, label %runtime.invalid.request.571 i32 2, label %runtime.invalid.reference.572 i32 3, label %runtime.scratch.capacity.573 i32 4, label %runtime.retained.capacity.574 ]
runtime.invalid.request.571:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.572:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.573:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.574:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.575:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.570:
  %record.make.handle.576 = load i64, ptr %workspace.slot.568, align 8
  %ctx.field.577 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.578 = load i32, ptr %ctx.field.577, align 4
  %steps.next.579 = add i32 %steps.current.578, 1
  store i32 %steps.next.579, ptr %ctx.field.577, align 4
  %steps.over.580 = icmp ugt i32 %steps.next.579, 10000
  br i1 %steps.over.580, label %failure.581, label %continue.582
failure.581:
  %ctx.field.583 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.583, align 4
  %status.diagnostic.584 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.584, align 4
  ret void
continue.582:
  %ctx.field.585 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.586 = load i32, ptr %ctx.field.585, align 4
  %steps.next.587 = add i32 %steps.current.586, 1
  store i32 %steps.next.587, ptr %ctx.field.585, align 4
  %steps.over.588 = icmp ugt i32 %steps.next.587, 10000
  br i1 %steps.over.588, label %failure.589, label %continue.590
failure.589:
  %ctx.field.591 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.591, align 4
  %status.diagnostic.592 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.592, align 4
  ret void
continue.590:
  %ctx.field.593 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.594 = load i32, ptr %ctx.field.593, align 4
  %steps.next.595 = add i32 %steps.current.594, 1
  store i32 %steps.next.595, ptr %ctx.field.593, align 4
  %steps.over.596 = icmp ugt i32 %steps.next.595, 10000
  br i1 %steps.over.596, label %failure.597, label %continue.598
failure.597:
  %ctx.field.599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.599, align 4
  %status.diagnostic.600 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.600, align 4
  ret void
continue.598:
  %depth.exceeded.601 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.601, label %failure.602, label %continue.603
failure.602:
  %ctx.field.604 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.604, align 4
  %status.diagnostic.605 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.605, align 4
  ret void
continue.603:
  %workspace.slot.606 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.576, ptr %workspace.slot.606, align 8
  %workspace.slot.607 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.608 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 60, ptr %outputs, i32 1, ptr %workspace.slot.607)
  switch i32 %record.make.status.608, label %runtime.invalid.result.614 [ i32 0, label %runtime.success.609 i32 1, label %runtime.invalid.request.610 i32 2, label %runtime.invalid.reference.611 i32 3, label %runtime.scratch.capacity.612 i32 4, label %runtime.retained.capacity.613 ]
runtime.invalid.request.610:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.611:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.612:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.613:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.614:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.609:
  %record.make.handle.615 = load i64, ptr %workspace.slot.607, align 8
  %ctx.field.616 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.617 = load i32, ptr %ctx.field.616, align 4
  %steps.next.618 = add i32 %steps.current.617, 1
  store i32 %steps.next.618, ptr %ctx.field.616, align 4
  %steps.over.619 = icmp ugt i32 %steps.next.618, 10000
  br i1 %steps.over.619, label %failure.620, label %continue.621
failure.620:
  %ctx.field.622 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.622, align 4
  %status.diagnostic.623 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.623, align 4
  ret void
continue.621:
  %ctx.field.624 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.625 = load i32, ptr %ctx.field.624, align 4
  %steps.next.626 = add i32 %steps.current.625, 1
  store i32 %steps.next.626, ptr %ctx.field.624, align 4
  %steps.over.627 = icmp ugt i32 %steps.next.626, 10000
  br i1 %steps.over.627, label %failure.628, label %continue.629
failure.628:
  %ctx.field.630 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.630, align 4
  %status.diagnostic.631 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.631, align 4
  ret void
continue.629:
  %ctx.field.632 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.633 = load i32, ptr %ctx.field.632, align 4
  %steps.next.634 = add i32 %steps.current.633, 1
  store i32 %steps.next.634, ptr %ctx.field.632, align 4
  %steps.over.635 = icmp ugt i32 %steps.next.634, 10000
  br i1 %steps.over.635, label %failure.636, label %continue.637
failure.636:
  %ctx.field.638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.638, align 4
  %status.diagnostic.639 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.639, align 4
  ret void
continue.637:
  %depth.exceeded.640 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.640, label %failure.641, label %continue.642
failure.641:
  %ctx.field.643 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 66, ptr %ctx.field.643, align 4
  %status.diagnostic.644 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.644, align 4
  ret void
continue.642:
  %workspace.slot.645 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.615, ptr %workspace.slot.645, align 8
  %workspace.slot.646 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.647 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 71, ptr %outputs, i32 1, ptr %workspace.slot.646)
  switch i32 %record.make.status.647, label %runtime.invalid.result.653 [ i32 0, label %runtime.success.648 i32 1, label %runtime.invalid.request.649 i32 2, label %runtime.invalid.reference.650 i32 3, label %runtime.scratch.capacity.651 i32 4, label %runtime.retained.capacity.652 ]
runtime.invalid.request.649:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.650:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.651:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.652:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.653:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.648:
  %record.make.handle.654 = load i64, ptr %workspace.slot.646, align 8
  %ctx.field.655 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.656 = load i32, ptr %ctx.field.655, align 4
  %steps.next.657 = add i32 %steps.current.656, 1
  store i32 %steps.next.657, ptr %ctx.field.655, align 4
  %steps.over.658 = icmp ugt i32 %steps.next.657, 10000
  br i1 %steps.over.658, label %failure.659, label %continue.660
failure.659:
  %ctx.field.661 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 67, ptr %ctx.field.661, align 4
  %status.diagnostic.662 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.662, align 4
  ret void
continue.660:
  %ctx.field.663 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.664 = load i32, ptr %ctx.field.663, align 4
  %steps.next.665 = add i32 %steps.current.664, 1
  store i32 %steps.next.665, ptr %ctx.field.663, align 4
  %steps.over.666 = icmp ugt i32 %steps.next.665, 10000
  br i1 %steps.over.666, label %failure.667, label %continue.668
failure.667:
  %ctx.field.669 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 68, ptr %ctx.field.669, align 4
  %status.diagnostic.670 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.670, align 4
  ret void
continue.668:
  %ctx.field.671 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.672 = load i32, ptr %ctx.field.671, align 4
  %steps.next.673 = add i32 %steps.current.672, 1
  store i32 %steps.next.673, ptr %ctx.field.671, align 4
  %steps.over.674 = icmp ugt i32 %steps.next.673, 10000
  br i1 %steps.over.674, label %failure.675, label %continue.676
failure.675:
  %ctx.field.677 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 69, ptr %ctx.field.677, align 4
  %status.diagnostic.678 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.678, align 4
  ret void
continue.676:
  %depth.exceeded.679 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.679, label %failure.680, label %continue.681
failure.680:
  %ctx.field.682 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 70, ptr %ctx.field.682, align 4
  %status.diagnostic.683 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.683, align 4
  ret void
continue.681:
  %workspace.slot.684 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.654, ptr %workspace.slot.684, align 8
  %workspace.slot.685 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.686 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 82, ptr %outputs, i32 1, ptr %workspace.slot.685)
  switch i32 %record.make.status.686, label %runtime.invalid.result.692 [ i32 0, label %runtime.success.687 i32 1, label %runtime.invalid.request.688 i32 2, label %runtime.invalid.reference.689 i32 3, label %runtime.scratch.capacity.690 i32 4, label %runtime.retained.capacity.691 ]
runtime.invalid.request.688:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.689:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.690:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.691:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.692:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.687:
  %record.make.handle.693 = load i64, ptr %workspace.slot.685, align 8
  %ctx.field.694 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.695 = load i32, ptr %ctx.field.694, align 4
  %steps.next.696 = add i32 %steps.current.695, 1
  store i32 %steps.next.696, ptr %ctx.field.694, align 4
  %steps.over.697 = icmp ugt i32 %steps.next.696, 10000
  br i1 %steps.over.697, label %failure.698, label %continue.699
failure.698:
  %ctx.field.700 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 71, ptr %ctx.field.700, align 4
  %status.diagnostic.701 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.701, align 4
  ret void
continue.699:
  %ctx.field.702 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.703 = load i32, ptr %ctx.field.702, align 4
  %steps.next.704 = add i32 %steps.current.703, 1
  store i32 %steps.next.704, ptr %ctx.field.702, align 4
  %steps.over.705 = icmp ugt i32 %steps.next.704, 10000
  br i1 %steps.over.705, label %failure.706, label %continue.707
failure.706:
  %ctx.field.708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 72, ptr %ctx.field.708, align 4
  %status.diagnostic.709 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.709, align 4
  ret void
continue.707:
  %ctx.field.710 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.711 = load i32, ptr %ctx.field.710, align 4
  %steps.next.712 = add i32 %steps.current.711, 1
  store i32 %steps.next.712, ptr %ctx.field.710, align 4
  %steps.over.713 = icmp ugt i32 %steps.next.712, 10000
  br i1 %steps.over.713, label %failure.714, label %continue.715
failure.714:
  %ctx.field.716 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 73, ptr %ctx.field.716, align 4
  %status.diagnostic.717 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.717, align 4
  ret void
continue.715:
  %depth.exceeded.718 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.718, label %failure.719, label %continue.720
failure.719:
  %ctx.field.721 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 74, ptr %ctx.field.721, align 4
  %status.diagnostic.722 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.722, align 4
  ret void
continue.720:
  %workspace.slot.723 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.693, ptr %workspace.slot.723, align 8
  %workspace.slot.724 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.725 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 93, ptr %outputs, i32 1, ptr %workspace.slot.724)
  switch i32 %record.make.status.725, label %runtime.invalid.result.731 [ i32 0, label %runtime.success.726 i32 1, label %runtime.invalid.request.727 i32 2, label %runtime.invalid.reference.728 i32 3, label %runtime.scratch.capacity.729 i32 4, label %runtime.retained.capacity.730 ]
runtime.invalid.request.727:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.728:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.729:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.730:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.731:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.726:
  %record.make.handle.732 = load i64, ptr %workspace.slot.724, align 8
  %ctx.field.733 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.734 = load i32, ptr %ctx.field.733, align 4
  %steps.next.735 = add i32 %steps.current.734, 1
  store i32 %steps.next.735, ptr %ctx.field.733, align 4
  %steps.over.736 = icmp ugt i32 %steps.next.735, 10000
  br i1 %steps.over.736, label %failure.737, label %continue.738
failure.737:
  %ctx.field.739 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 75, ptr %ctx.field.739, align 4
  %status.diagnostic.740 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.740, align 4
  ret void
continue.738:
  %ctx.field.741 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.742 = load i32, ptr %ctx.field.741, align 4
  %steps.next.743 = add i32 %steps.current.742, 1
  store i32 %steps.next.743, ptr %ctx.field.741, align 4
  %steps.over.744 = icmp ugt i32 %steps.next.743, 10000
  br i1 %steps.over.744, label %failure.745, label %continue.746
failure.745:
  %ctx.field.747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 76, ptr %ctx.field.747, align 4
  %status.diagnostic.748 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.748, align 4
  ret void
continue.746:
  %ctx.field.749 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.750 = load i32, ptr %ctx.field.749, align 4
  %steps.next.751 = add i32 %steps.current.750, 1
  store i32 %steps.next.751, ptr %ctx.field.749, align 4
  %steps.over.752 = icmp ugt i32 %steps.next.751, 10000
  br i1 %steps.over.752, label %failure.753, label %continue.754
failure.753:
  %ctx.field.755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 77, ptr %ctx.field.755, align 4
  %status.diagnostic.756 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.756, align 4
  ret void
continue.754:
  %depth.exceeded.757 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.757, label %failure.758, label %continue.759
failure.758:
  %ctx.field.760 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 78, ptr %ctx.field.760, align 4
  %status.diagnostic.761 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.761, align 4
  ret void
continue.759:
  %workspace.slot.762 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.732, ptr %workspace.slot.762, align 8
  %workspace.slot.763 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.764 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 104, ptr %outputs, i32 1, ptr %workspace.slot.763)
  switch i32 %record.make.status.764, label %runtime.invalid.result.770 [ i32 0, label %runtime.success.765 i32 1, label %runtime.invalid.request.766 i32 2, label %runtime.invalid.reference.767 i32 3, label %runtime.scratch.capacity.768 i32 4, label %runtime.retained.capacity.769 ]
runtime.invalid.request.766:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.767:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.768:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.769:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.770:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.765:
  %record.make.handle.771 = load i64, ptr %workspace.slot.763, align 8
  %ctx.field.772 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.773 = load i32, ptr %ctx.field.772, align 4
  %steps.next.774 = add i32 %steps.current.773, 1
  store i32 %steps.next.774, ptr %ctx.field.772, align 4
  %steps.over.775 = icmp ugt i32 %steps.next.774, 10000
  br i1 %steps.over.775, label %failure.776, label %continue.777
failure.776:
  %ctx.field.778 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 79, ptr %ctx.field.778, align 4
  %status.diagnostic.779 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.779, align 4
  ret void
continue.777:
  %ctx.field.780 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.781 = load i32, ptr %ctx.field.780, align 4
  %steps.next.782 = add i32 %steps.current.781, 1
  store i32 %steps.next.782, ptr %ctx.field.780, align 4
  %steps.over.783 = icmp ugt i32 %steps.next.782, 10000
  br i1 %steps.over.783, label %failure.784, label %continue.785
failure.784:
  %ctx.field.786 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 80, ptr %ctx.field.786, align 4
  %status.diagnostic.787 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.787, align 4
  ret void
continue.785:
  %ctx.field.788 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.789 = load i32, ptr %ctx.field.788, align 4
  %steps.next.790 = add i32 %steps.current.789, 1
  store i32 %steps.next.790, ptr %ctx.field.788, align 4
  %steps.over.791 = icmp ugt i32 %steps.next.790, 10000
  br i1 %steps.over.791, label %failure.792, label %continue.793
failure.792:
  %ctx.field.794 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 81, ptr %ctx.field.794, align 4
  %status.diagnostic.795 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.795, align 4
  ret void
continue.793:
  %depth.exceeded.796 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.796, label %failure.797, label %continue.798
failure.797:
  %ctx.field.799 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 82, ptr %ctx.field.799, align 4
  %status.diagnostic.800 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.800, align 4
  ret void
continue.798:
  %workspace.slot.801 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.771, ptr %workspace.slot.801, align 8
  %workspace.slot.802 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.803 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 116, ptr %outputs, i32 1, ptr %workspace.slot.802)
  switch i32 %record.make.status.803, label %runtime.invalid.result.809 [ i32 0, label %runtime.success.804 i32 1, label %runtime.invalid.request.805 i32 2, label %runtime.invalid.reference.806 i32 3, label %runtime.scratch.capacity.807 i32 4, label %runtime.retained.capacity.808 ]
runtime.invalid.request.805:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.806:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.807:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.808:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.809:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.804:
  %record.make.handle.810 = load i64, ptr %workspace.slot.802, align 8
  %ctx.field.811 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.812 = load i32, ptr %ctx.field.811, align 4
  %steps.next.813 = add i32 %steps.current.812, 1
  store i32 %steps.next.813, ptr %ctx.field.811, align 4
  %steps.over.814 = icmp ugt i32 %steps.next.813, 10000
  br i1 %steps.over.814, label %failure.815, label %continue.816
failure.815:
  %ctx.field.817 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 83, ptr %ctx.field.817, align 4
  %status.diagnostic.818 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.818, align 4
  ret void
continue.816:
  %ctx.field.819 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.820 = load i32, ptr %ctx.field.819, align 4
  %steps.next.821 = add i32 %steps.current.820, 1
  store i32 %steps.next.821, ptr %ctx.field.819, align 4
  %steps.over.822 = icmp ugt i32 %steps.next.821, 10000
  br i1 %steps.over.822, label %failure.823, label %continue.824
failure.823:
  %ctx.field.825 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 84, ptr %ctx.field.825, align 4
  %status.diagnostic.826 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.826, align 4
  ret void
continue.824:
  %ctx.field.827 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.828 = load i32, ptr %ctx.field.827, align 4
  %steps.next.829 = add i32 %steps.current.828, 1
  store i32 %steps.next.829, ptr %ctx.field.827, align 4
  %steps.over.830 = icmp ugt i32 %steps.next.829, 10000
  br i1 %steps.over.830, label %failure.831, label %continue.832
failure.831:
  %ctx.field.833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 85, ptr %ctx.field.833, align 4
  %status.diagnostic.834 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.834, align 4
  ret void
continue.832:
  %depth.exceeded.835 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.835, label %failure.836, label %continue.837
failure.836:
  %ctx.field.838 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 86, ptr %ctx.field.838, align 4
  %status.diagnostic.839 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.839, align 4
  ret void
continue.837:
  %workspace.slot.840 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.810, ptr %workspace.slot.840, align 8
  %workspace.slot.841 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.842 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 127, ptr %outputs, i32 1, ptr %workspace.slot.841)
  switch i32 %record.make.status.842, label %runtime.invalid.result.848 [ i32 0, label %runtime.success.843 i32 1, label %runtime.invalid.request.844 i32 2, label %runtime.invalid.reference.845 i32 3, label %runtime.scratch.capacity.846 i32 4, label %runtime.retained.capacity.847 ]
runtime.invalid.request.844:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.845:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.846:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.847:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.848:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.843:
  %record.make.handle.849 = load i64, ptr %workspace.slot.841, align 8
  %ctx.field.850 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.851 = load i32, ptr %ctx.field.850, align 4
  %steps.next.852 = add i32 %steps.current.851, 1
  store i32 %steps.next.852, ptr %ctx.field.850, align 4
  %steps.over.853 = icmp ugt i32 %steps.next.852, 10000
  br i1 %steps.over.853, label %failure.854, label %continue.855
failure.854:
  %ctx.field.856 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 87, ptr %ctx.field.856, align 4
  %status.diagnostic.857 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.857, align 4
  ret void
continue.855:
  %ctx.field.858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.859 = load i32, ptr %ctx.field.858, align 4
  %steps.next.860 = add i32 %steps.current.859, 1
  store i32 %steps.next.860, ptr %ctx.field.858, align 4
  %steps.over.861 = icmp ugt i32 %steps.next.860, 10000
  br i1 %steps.over.861, label %failure.862, label %continue.863
failure.862:
  %ctx.field.864 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 88, ptr %ctx.field.864, align 4
  %status.diagnostic.865 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.865, align 4
  ret void
continue.863:
  %ctx.field.866 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.867 = load i32, ptr %ctx.field.866, align 4
  %steps.next.868 = add i32 %steps.current.867, 1
  store i32 %steps.next.868, ptr %ctx.field.866, align 4
  %steps.over.869 = icmp ugt i32 %steps.next.868, 10000
  br i1 %steps.over.869, label %failure.870, label %continue.871
failure.870:
  %ctx.field.872 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 89, ptr %ctx.field.872, align 4
  %status.diagnostic.873 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.873, align 4
  ret void
continue.871:
  %depth.exceeded.874 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.874, label %failure.875, label %continue.876
failure.875:
  %ctx.field.877 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 90, ptr %ctx.field.877, align 4
  %status.diagnostic.878 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.878, align 4
  ret void
continue.876:
  %workspace.slot.879 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.849, ptr %workspace.slot.879, align 8
  %workspace.slot.880 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.881 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 138, ptr %outputs, i32 1, ptr %workspace.slot.880)
  switch i32 %record.make.status.881, label %runtime.invalid.result.887 [ i32 0, label %runtime.success.882 i32 1, label %runtime.invalid.request.883 i32 2, label %runtime.invalid.reference.884 i32 3, label %runtime.scratch.capacity.885 i32 4, label %runtime.retained.capacity.886 ]
runtime.invalid.request.883:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.884:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.885:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.886:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.887:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.882:
  %record.make.handle.888 = load i64, ptr %workspace.slot.880, align 8
  %ctx.field.889 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.890 = load i32, ptr %ctx.field.889, align 4
  %steps.next.891 = add i32 %steps.current.890, 1
  store i32 %steps.next.891, ptr %ctx.field.889, align 4
  %steps.over.892 = icmp ugt i32 %steps.next.891, 10000
  br i1 %steps.over.892, label %failure.893, label %continue.894
failure.893:
  %ctx.field.895 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 91, ptr %ctx.field.895, align 4
  %status.diagnostic.896 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.896, align 4
  ret void
continue.894:
  %ctx.field.897 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.898 = load i32, ptr %ctx.field.897, align 4
  %steps.next.899 = add i32 %steps.current.898, 1
  store i32 %steps.next.899, ptr %ctx.field.897, align 4
  %steps.over.900 = icmp ugt i32 %steps.next.899, 10000
  br i1 %steps.over.900, label %failure.901, label %continue.902
failure.901:
  %ctx.field.903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 92, ptr %ctx.field.903, align 4
  %status.diagnostic.904 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.904, align 4
  ret void
continue.902:
  %ctx.field.905 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.906 = load i32, ptr %ctx.field.905, align 4
  %steps.next.907 = add i32 %steps.current.906, 1
  store i32 %steps.next.907, ptr %ctx.field.905, align 4
  %steps.over.908 = icmp ugt i32 %steps.next.907, 10000
  br i1 %steps.over.908, label %failure.909, label %continue.910
failure.909:
  %ctx.field.911 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 93, ptr %ctx.field.911, align 4
  %status.diagnostic.912 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.912, align 4
  ret void
continue.910:
  %depth.exceeded.913 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.913, label %failure.914, label %continue.915
failure.914:
  %ctx.field.916 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 94, ptr %ctx.field.916, align 4
  %status.diagnostic.917 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.917, align 4
  ret void
continue.915:
  %workspace.slot.918 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.888, ptr %workspace.slot.918, align 8
  %workspace.slot.919 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.920 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 149, ptr %outputs, i32 1, ptr %workspace.slot.919)
  switch i32 %record.make.status.920, label %runtime.invalid.result.926 [ i32 0, label %runtime.success.921 i32 1, label %runtime.invalid.request.922 i32 2, label %runtime.invalid.reference.923 i32 3, label %runtime.scratch.capacity.924 i32 4, label %runtime.retained.capacity.925 ]
runtime.invalid.request.922:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.923:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.924:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.925:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.926:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.921:
  %record.make.handle.927 = load i64, ptr %workspace.slot.919, align 8
  %ctx.field.928 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.929 = load i32, ptr %ctx.field.928, align 4
  %steps.next.930 = add i32 %steps.current.929, 1
  store i32 %steps.next.930, ptr %ctx.field.928, align 4
  %steps.over.931 = icmp ugt i32 %steps.next.930, 10000
  br i1 %steps.over.931, label %failure.932, label %continue.933
failure.932:
  %ctx.field.934 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 95, ptr %ctx.field.934, align 4
  %status.diagnostic.935 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.935, align 4
  ret void
continue.933:
  %ctx.field.936 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.937 = load i32, ptr %ctx.field.936, align 4
  %steps.next.938 = add i32 %steps.current.937, 1
  store i32 %steps.next.938, ptr %ctx.field.936, align 4
  %steps.over.939 = icmp ugt i32 %steps.next.938, 10000
  br i1 %steps.over.939, label %failure.940, label %continue.941
failure.940:
  %ctx.field.942 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 96, ptr %ctx.field.942, align 4
  %status.diagnostic.943 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.943, align 4
  ret void
continue.941:
  %ctx.field.944 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.945 = load i32, ptr %ctx.field.944, align 4
  %steps.next.946 = add i32 %steps.current.945, 1
  store i32 %steps.next.946, ptr %ctx.field.944, align 4
  %steps.over.947 = icmp ugt i32 %steps.next.946, 10000
  br i1 %steps.over.947, label %failure.948, label %continue.949
failure.948:
  %ctx.field.950 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 97, ptr %ctx.field.950, align 4
  %status.diagnostic.951 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.951, align 4
  ret void
continue.949:
  %depth.exceeded.952 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.952, label %failure.953, label %continue.954
failure.953:
  %ctx.field.955 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 98, ptr %ctx.field.955, align 4
  %status.diagnostic.956 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.956, align 4
  ret void
continue.954:
  %workspace.slot.957 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.927, ptr %workspace.slot.957, align 8
  %workspace.slot.958 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.959 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 160, ptr %outputs, i32 1, ptr %workspace.slot.958)
  switch i32 %record.make.status.959, label %runtime.invalid.result.965 [ i32 0, label %runtime.success.960 i32 1, label %runtime.invalid.request.961 i32 2, label %runtime.invalid.reference.962 i32 3, label %runtime.scratch.capacity.963 i32 4, label %runtime.retained.capacity.964 ]
runtime.invalid.request.961:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.962:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.963:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.964:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.965:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.960:
  %record.make.handle.966 = load i64, ptr %workspace.slot.958, align 8
  %ctx.field.967 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.968 = load i32, ptr %ctx.field.967, align 4
  %steps.next.969 = add i32 %steps.current.968, 1
  store i32 %steps.next.969, ptr %ctx.field.967, align 4
  %steps.over.970 = icmp ugt i32 %steps.next.969, 10000
  br i1 %steps.over.970, label %failure.971, label %continue.972
failure.971:
  %ctx.field.973 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 99, ptr %ctx.field.973, align 4
  %status.diagnostic.974 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.974, align 4
  ret void
continue.972:
  %ctx.field.975 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.976 = load i32, ptr %ctx.field.975, align 4
  %steps.next.977 = add i32 %steps.current.976, 1
  store i32 %steps.next.977, ptr %ctx.field.975, align 4
  %steps.over.978 = icmp ugt i32 %steps.next.977, 10000
  br i1 %steps.over.978, label %failure.979, label %continue.980
failure.979:
  %ctx.field.981 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 100, ptr %ctx.field.981, align 4
  %status.diagnostic.982 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.982, align 4
  ret void
continue.980:
  %ctx.field.983 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.984 = load i32, ptr %ctx.field.983, align 4
  %steps.next.985 = add i32 %steps.current.984, 1
  store i32 %steps.next.985, ptr %ctx.field.983, align 4
  %steps.over.986 = icmp ugt i32 %steps.next.985, 10000
  br i1 %steps.over.986, label %failure.987, label %continue.988
failure.987:
  %ctx.field.989 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 101, ptr %ctx.field.989, align 4
  %status.diagnostic.990 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.990, align 4
  ret void
continue.988:
  %depth.exceeded.991 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.991, label %failure.992, label %continue.993
failure.992:
  %ctx.field.994 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 102, ptr %ctx.field.994, align 4
  %status.diagnostic.995 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.995, align 4
  ret void
continue.993:
  %workspace.slot.996 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.966, ptr %workspace.slot.996, align 8
  %workspace.slot.997 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.998 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 171, ptr %outputs, i32 1, ptr %workspace.slot.997)
  switch i32 %record.make.status.998, label %runtime.invalid.result.1004 [ i32 0, label %runtime.success.999 i32 1, label %runtime.invalid.request.1000 i32 2, label %runtime.invalid.reference.1001 i32 3, label %runtime.scratch.capacity.1002 i32 4, label %runtime.retained.capacity.1003 ]
runtime.invalid.request.1000:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1001:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1002:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1003:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1004:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.999:
  %record.make.handle.1005 = load i64, ptr %workspace.slot.997, align 8
  %ctx.field.1006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1007 = load i32, ptr %ctx.field.1006, align 4
  %steps.next.1008 = add i32 %steps.current.1007, 1
  store i32 %steps.next.1008, ptr %ctx.field.1006, align 4
  %steps.over.1009 = icmp ugt i32 %steps.next.1008, 10000
  br i1 %steps.over.1009, label %failure.1010, label %continue.1011
failure.1010:
  %ctx.field.1012 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 103, ptr %ctx.field.1012, align 4
  %status.diagnostic.1013 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1013, align 4
  ret void
continue.1011:
  %ctx.field.1014 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1015 = load i32, ptr %ctx.field.1014, align 4
  %steps.next.1016 = add i32 %steps.current.1015, 1
  store i32 %steps.next.1016, ptr %ctx.field.1014, align 4
  %steps.over.1017 = icmp ugt i32 %steps.next.1016, 10000
  br i1 %steps.over.1017, label %failure.1018, label %continue.1019
failure.1018:
  %ctx.field.1020 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 104, ptr %ctx.field.1020, align 4
  %status.diagnostic.1021 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1021, align 4
  ret void
continue.1019:
  %ctx.field.1022 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1023 = load i32, ptr %ctx.field.1022, align 4
  %steps.next.1024 = add i32 %steps.current.1023, 1
  store i32 %steps.next.1024, ptr %ctx.field.1022, align 4
  %steps.over.1025 = icmp ugt i32 %steps.next.1024, 10000
  br i1 %steps.over.1025, label %failure.1026, label %continue.1027
failure.1026:
  %ctx.field.1028 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 105, ptr %ctx.field.1028, align 4
  %status.diagnostic.1029 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1029, align 4
  ret void
continue.1027:
  %depth.exceeded.1030 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1030, label %failure.1031, label %continue.1032
failure.1031:
  %ctx.field.1033 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 106, ptr %ctx.field.1033, align 4
  %status.diagnostic.1034 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1034, align 4
  ret void
continue.1032:
  %workspace.slot.1035 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1005, ptr %workspace.slot.1035, align 8
  %workspace.slot.1036 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1037 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 178, ptr %outputs, i32 1, ptr %workspace.slot.1036)
  switch i32 %record.make.status.1037, label %runtime.invalid.result.1043 [ i32 0, label %runtime.success.1038 i32 1, label %runtime.invalid.request.1039 i32 2, label %runtime.invalid.reference.1040 i32 3, label %runtime.scratch.capacity.1041 i32 4, label %runtime.retained.capacity.1042 ]
runtime.invalid.request.1039:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1040:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1041:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1042:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1043:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1038:
  %record.make.handle.1044 = load i64, ptr %workspace.slot.1036, align 8
  %ctx.field.1045 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1046 = load i32, ptr %ctx.field.1045, align 4
  %steps.next.1047 = add i32 %steps.current.1046, 1
  store i32 %steps.next.1047, ptr %ctx.field.1045, align 4
  %steps.over.1048 = icmp ugt i32 %steps.next.1047, 10000
  br i1 %steps.over.1048, label %failure.1049, label %continue.1050
failure.1049:
  %ctx.field.1051 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 107, ptr %ctx.field.1051, align 4
  %status.diagnostic.1052 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1052, align 4
  ret void
continue.1050:
  %ctx.field.1053 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1054 = load i32, ptr %ctx.field.1053, align 4
  %steps.next.1055 = add i32 %steps.current.1054, 1
  store i32 %steps.next.1055, ptr %ctx.field.1053, align 4
  %steps.over.1056 = icmp ugt i32 %steps.next.1055, 10000
  br i1 %steps.over.1056, label %failure.1057, label %continue.1058
failure.1057:
  %ctx.field.1059 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 108, ptr %ctx.field.1059, align 4
  %status.diagnostic.1060 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1060, align 4
  ret void
continue.1058:
  %ctx.field.1061 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1062 = load i32, ptr %ctx.field.1061, align 4
  %steps.next.1063 = add i32 %steps.current.1062, 1
  store i32 %steps.next.1063, ptr %ctx.field.1061, align 4
  %steps.over.1064 = icmp ugt i32 %steps.next.1063, 10000
  br i1 %steps.over.1064, label %failure.1065, label %continue.1066
failure.1065:
  %ctx.field.1067 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 109, ptr %ctx.field.1067, align 4
  %status.diagnostic.1068 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1068, align 4
  ret void
continue.1066:
  %depth.exceeded.1069 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1069, label %failure.1070, label %continue.1071
failure.1070:
  %ctx.field.1072 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 110, ptr %ctx.field.1072, align 4
  %status.diagnostic.1073 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1073, align 4
  ret void
continue.1071:
  %workspace.slot.1074 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1044, ptr %workspace.slot.1074, align 8
  %workspace.slot.1075 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1076 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 179, ptr %outputs, i32 1, ptr %workspace.slot.1075)
  switch i32 %record.make.status.1076, label %runtime.invalid.result.1082 [ i32 0, label %runtime.success.1077 i32 1, label %runtime.invalid.request.1078 i32 2, label %runtime.invalid.reference.1079 i32 3, label %runtime.scratch.capacity.1080 i32 4, label %runtime.retained.capacity.1081 ]
runtime.invalid.request.1078:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1079:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1080:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1081:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1082:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1077:
  %record.make.handle.1083 = load i64, ptr %workspace.slot.1075, align 8
  %ctx.field.1084 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1085 = load i32, ptr %ctx.field.1084, align 4
  %steps.next.1086 = add i32 %steps.current.1085, 1
  store i32 %steps.next.1086, ptr %ctx.field.1084, align 4
  %steps.over.1087 = icmp ugt i32 %steps.next.1086, 10000
  br i1 %steps.over.1087, label %failure.1088, label %continue.1089
failure.1088:
  %ctx.field.1090 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 111, ptr %ctx.field.1090, align 4
  %status.diagnostic.1091 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1091, align 4
  ret void
continue.1089:
  %ctx.field.1092 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1093 = load i32, ptr %ctx.field.1092, align 4
  %steps.next.1094 = add i32 %steps.current.1093, 1
  store i32 %steps.next.1094, ptr %ctx.field.1092, align 4
  %steps.over.1095 = icmp ugt i32 %steps.next.1094, 10000
  br i1 %steps.over.1095, label %failure.1096, label %continue.1097
failure.1096:
  %ctx.field.1098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 112, ptr %ctx.field.1098, align 4
  %status.diagnostic.1099 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1099, align 4
  ret void
continue.1097:
  %ctx.field.1100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1101 = load i32, ptr %ctx.field.1100, align 4
  %steps.next.1102 = add i32 %steps.current.1101, 1
  store i32 %steps.next.1102, ptr %ctx.field.1100, align 4
  %steps.over.1103 = icmp ugt i32 %steps.next.1102, 10000
  br i1 %steps.over.1103, label %failure.1104, label %continue.1105
failure.1104:
  %ctx.field.1106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 113, ptr %ctx.field.1106, align 4
  %status.diagnostic.1107 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1107, align 4
  ret void
continue.1105:
  %depth.exceeded.1108 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1108, label %failure.1109, label %continue.1110
failure.1109:
  %ctx.field.1111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 114, ptr %ctx.field.1111, align 4
  %status.diagnostic.1112 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1112, align 4
  ret void
continue.1110:
  %workspace.slot.1113 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1083, ptr %workspace.slot.1113, align 8
  %workspace.slot.1114 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1115 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 180, ptr %outputs, i32 1, ptr %workspace.slot.1114)
  switch i32 %record.make.status.1115, label %runtime.invalid.result.1121 [ i32 0, label %runtime.success.1116 i32 1, label %runtime.invalid.request.1117 i32 2, label %runtime.invalid.reference.1118 i32 3, label %runtime.scratch.capacity.1119 i32 4, label %runtime.retained.capacity.1120 ]
runtime.invalid.request.1117:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1118:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1119:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1120:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1121:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1116:
  %record.make.handle.1122 = load i64, ptr %workspace.slot.1114, align 8
  %ctx.field.1123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1124 = load i32, ptr %ctx.field.1123, align 4
  %steps.next.1125 = add i32 %steps.current.1124, 1
  store i32 %steps.next.1125, ptr %ctx.field.1123, align 4
  %steps.over.1126 = icmp ugt i32 %steps.next.1125, 10000
  br i1 %steps.over.1126, label %failure.1127, label %continue.1128
failure.1127:
  %ctx.field.1129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 115, ptr %ctx.field.1129, align 4
  %status.diagnostic.1130 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1130, align 4
  ret void
continue.1128:
  %ctx.field.1131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1132 = load i32, ptr %ctx.field.1131, align 4
  %steps.next.1133 = add i32 %steps.current.1132, 1
  store i32 %steps.next.1133, ptr %ctx.field.1131, align 4
  %steps.over.1134 = icmp ugt i32 %steps.next.1133, 10000
  br i1 %steps.over.1134, label %failure.1135, label %continue.1136
failure.1135:
  %ctx.field.1137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 116, ptr %ctx.field.1137, align 4
  %status.diagnostic.1138 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1138, align 4
  ret void
continue.1136:
  %ctx.field.1139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1140 = load i32, ptr %ctx.field.1139, align 4
  %steps.next.1141 = add i32 %steps.current.1140, 1
  store i32 %steps.next.1141, ptr %ctx.field.1139, align 4
  %steps.over.1142 = icmp ugt i32 %steps.next.1141, 10000
  br i1 %steps.over.1142, label %failure.1143, label %continue.1144
failure.1143:
  %ctx.field.1145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 117, ptr %ctx.field.1145, align 4
  %status.diagnostic.1146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1146, align 4
  ret void
continue.1144:
  %depth.exceeded.1147 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1147, label %failure.1148, label %continue.1149
failure.1148:
  %ctx.field.1150 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 118, ptr %ctx.field.1150, align 4
  %status.diagnostic.1151 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1151, align 4
  ret void
continue.1149:
  %workspace.slot.1152 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1122, ptr %workspace.slot.1152, align 8
  %workspace.slot.1153 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1154 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 181, ptr %outputs, i32 1, ptr %workspace.slot.1153)
  switch i32 %record.make.status.1154, label %runtime.invalid.result.1160 [ i32 0, label %runtime.success.1155 i32 1, label %runtime.invalid.request.1156 i32 2, label %runtime.invalid.reference.1157 i32 3, label %runtime.scratch.capacity.1158 i32 4, label %runtime.retained.capacity.1159 ]
runtime.invalid.request.1156:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1157:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1158:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1159:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1160:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1155:
  %record.make.handle.1161 = load i64, ptr %workspace.slot.1153, align 8
  %ctx.field.1162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1163 = load i32, ptr %ctx.field.1162, align 4
  %steps.next.1164 = add i32 %steps.current.1163, 1
  store i32 %steps.next.1164, ptr %ctx.field.1162, align 4
  %steps.over.1165 = icmp ugt i32 %steps.next.1164, 10000
  br i1 %steps.over.1165, label %failure.1166, label %continue.1167
failure.1166:
  %ctx.field.1168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 119, ptr %ctx.field.1168, align 4
  %status.diagnostic.1169 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1169, align 4
  ret void
continue.1167:
  %ctx.field.1170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1171 = load i32, ptr %ctx.field.1170, align 4
  %steps.next.1172 = add i32 %steps.current.1171, 1
  store i32 %steps.next.1172, ptr %ctx.field.1170, align 4
  %steps.over.1173 = icmp ugt i32 %steps.next.1172, 10000
  br i1 %steps.over.1173, label %failure.1174, label %continue.1175
failure.1174:
  %ctx.field.1176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 120, ptr %ctx.field.1176, align 4
  %status.diagnostic.1177 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1177, align 4
  ret void
continue.1175:
  %ctx.field.1178 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1179 = load i32, ptr %ctx.field.1178, align 4
  %steps.next.1180 = add i32 %steps.current.1179, 1
  store i32 %steps.next.1180, ptr %ctx.field.1178, align 4
  %steps.over.1181 = icmp ugt i32 %steps.next.1180, 10000
  br i1 %steps.over.1181, label %failure.1182, label %continue.1183
failure.1182:
  %ctx.field.1184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 121, ptr %ctx.field.1184, align 4
  %status.diagnostic.1185 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1185, align 4
  ret void
continue.1183:
  %depth.exceeded.1186 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1186, label %failure.1187, label %continue.1188
failure.1187:
  %ctx.field.1189 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 122, ptr %ctx.field.1189, align 4
  %status.diagnostic.1190 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1190, align 4
  ret void
continue.1188:
  %workspace.slot.1191 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1161, ptr %workspace.slot.1191, align 8
  %workspace.slot.1192 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1193 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 183, ptr %outputs, i32 1, ptr %workspace.slot.1192)
  switch i32 %record.make.status.1193, label %runtime.invalid.result.1199 [ i32 0, label %runtime.success.1194 i32 1, label %runtime.invalid.request.1195 i32 2, label %runtime.invalid.reference.1196 i32 3, label %runtime.scratch.capacity.1197 i32 4, label %runtime.retained.capacity.1198 ]
runtime.invalid.request.1195:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1196:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1197:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1198:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1199:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1194:
  %record.make.handle.1200 = load i64, ptr %workspace.slot.1192, align 8
  %ctx.field.1201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1202 = load i32, ptr %ctx.field.1201, align 4
  %steps.next.1203 = add i32 %steps.current.1202, 1
  store i32 %steps.next.1203, ptr %ctx.field.1201, align 4
  %steps.over.1204 = icmp ugt i32 %steps.next.1203, 10000
  br i1 %steps.over.1204, label %failure.1205, label %continue.1206
failure.1205:
  %ctx.field.1207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 123, ptr %ctx.field.1207, align 4
  %status.diagnostic.1208 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1208, align 4
  ret void
continue.1206:
  %ctx.field.1209 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1210 = load i32, ptr %ctx.field.1209, align 4
  %steps.next.1211 = add i32 %steps.current.1210, 1
  store i32 %steps.next.1211, ptr %ctx.field.1209, align 4
  %steps.over.1212 = icmp ugt i32 %steps.next.1211, 10000
  br i1 %steps.over.1212, label %failure.1213, label %continue.1214
failure.1213:
  %ctx.field.1215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 124, ptr %ctx.field.1215, align 4
  %status.diagnostic.1216 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1216, align 4
  ret void
continue.1214:
  %ctx.field.1217 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1218 = load i32, ptr %ctx.field.1217, align 4
  %steps.next.1219 = add i32 %steps.current.1218, 1
  store i32 %steps.next.1219, ptr %ctx.field.1217, align 4
  %steps.over.1220 = icmp ugt i32 %steps.next.1219, 10000
  br i1 %steps.over.1220, label %failure.1221, label %continue.1222
failure.1221:
  %ctx.field.1223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 125, ptr %ctx.field.1223, align 4
  %status.diagnostic.1224 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1224, align 4
  ret void
continue.1222:
  %depth.exceeded.1225 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1225, label %failure.1226, label %continue.1227
failure.1226:
  %ctx.field.1228 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 126, ptr %ctx.field.1228, align 4
  %status.diagnostic.1229 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1229, align 4
  ret void
continue.1227:
  %workspace.slot.1230 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1200, ptr %workspace.slot.1230, align 8
  %workspace.slot.1231 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1232 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 184, ptr %outputs, i32 1, ptr %workspace.slot.1231)
  switch i32 %record.make.status.1232, label %runtime.invalid.result.1238 [ i32 0, label %runtime.success.1233 i32 1, label %runtime.invalid.request.1234 i32 2, label %runtime.invalid.reference.1235 i32 3, label %runtime.scratch.capacity.1236 i32 4, label %runtime.retained.capacity.1237 ]
runtime.invalid.request.1234:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1235:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1236:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1237:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1238:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1233:
  %record.make.handle.1239 = load i64, ptr %workspace.slot.1231, align 8
  %ctx.field.1240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1241 = load i32, ptr %ctx.field.1240, align 4
  %steps.next.1242 = add i32 %steps.current.1241, 1
  store i32 %steps.next.1242, ptr %ctx.field.1240, align 4
  %steps.over.1243 = icmp ugt i32 %steps.next.1242, 10000
  br i1 %steps.over.1243, label %failure.1244, label %continue.1245
failure.1244:
  %ctx.field.1246 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 127, ptr %ctx.field.1246, align 4
  %status.diagnostic.1247 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1247, align 4
  ret void
continue.1245:
  %ctx.field.1248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1249 = load i32, ptr %ctx.field.1248, align 4
  %steps.next.1250 = add i32 %steps.current.1249, 1
  store i32 %steps.next.1250, ptr %ctx.field.1248, align 4
  %steps.over.1251 = icmp ugt i32 %steps.next.1250, 10000
  br i1 %steps.over.1251, label %failure.1252, label %continue.1253
failure.1252:
  %ctx.field.1254 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 128, ptr %ctx.field.1254, align 4
  %status.diagnostic.1255 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1255, align 4
  ret void
continue.1253:
  %ctx.field.1256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1257 = load i32, ptr %ctx.field.1256, align 4
  %steps.next.1258 = add i32 %steps.current.1257, 1
  store i32 %steps.next.1258, ptr %ctx.field.1256, align 4
  %steps.over.1259 = icmp ugt i32 %steps.next.1258, 10000
  br i1 %steps.over.1259, label %failure.1260, label %continue.1261
failure.1260:
  %ctx.field.1262 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 129, ptr %ctx.field.1262, align 4
  %status.diagnostic.1263 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1263, align 4
  ret void
continue.1261:
  %depth.exceeded.1264 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1264, label %failure.1265, label %continue.1266
failure.1265:
  %ctx.field.1267 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 130, ptr %ctx.field.1267, align 4
  %status.diagnostic.1268 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1268, align 4
  ret void
continue.1266:
  %workspace.slot.1269 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1239, ptr %workspace.slot.1269, align 8
  %workspace.slot.1270 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1271 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 185, ptr %outputs, i32 1, ptr %workspace.slot.1270)
  switch i32 %record.make.status.1271, label %runtime.invalid.result.1277 [ i32 0, label %runtime.success.1272 i32 1, label %runtime.invalid.request.1273 i32 2, label %runtime.invalid.reference.1274 i32 3, label %runtime.scratch.capacity.1275 i32 4, label %runtime.retained.capacity.1276 ]
runtime.invalid.request.1273:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1274:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1275:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1276:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1277:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1272:
  %record.make.handle.1278 = load i64, ptr %workspace.slot.1270, align 8
  %ctx.field.1279 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1280 = load i32, ptr %ctx.field.1279, align 4
  %steps.next.1281 = add i32 %steps.current.1280, 1
  store i32 %steps.next.1281, ptr %ctx.field.1279, align 4
  %steps.over.1282 = icmp ugt i32 %steps.next.1281, 10000
  br i1 %steps.over.1282, label %failure.1283, label %continue.1284
failure.1283:
  %ctx.field.1285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 131, ptr %ctx.field.1285, align 4
  %status.diagnostic.1286 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1286, align 4
  ret void
continue.1284:
  %ctx.field.1287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1288 = load i32, ptr %ctx.field.1287, align 4
  %steps.next.1289 = add i32 %steps.current.1288, 1
  store i32 %steps.next.1289, ptr %ctx.field.1287, align 4
  %steps.over.1290 = icmp ugt i32 %steps.next.1289, 10000
  br i1 %steps.over.1290, label %failure.1291, label %continue.1292
failure.1291:
  %ctx.field.1293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 132, ptr %ctx.field.1293, align 4
  %status.diagnostic.1294 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1294, align 4
  ret void
continue.1292:
  %ctx.field.1295 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1296 = load i32, ptr %ctx.field.1295, align 4
  %steps.next.1297 = add i32 %steps.current.1296, 1
  store i32 %steps.next.1297, ptr %ctx.field.1295, align 4
  %steps.over.1298 = icmp ugt i32 %steps.next.1297, 10000
  br i1 %steps.over.1298, label %failure.1299, label %continue.1300
failure.1299:
  %ctx.field.1301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 133, ptr %ctx.field.1301, align 4
  %status.diagnostic.1302 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1302, align 4
  ret void
continue.1300:
  %depth.exceeded.1303 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1303, label %failure.1304, label %continue.1305
failure.1304:
  %ctx.field.1306 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 134, ptr %ctx.field.1306, align 4
  %status.diagnostic.1307 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1307, align 4
  ret void
continue.1305:
  %workspace.slot.1308 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1278, ptr %workspace.slot.1308, align 8
  %workspace.slot.1309 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1310 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 186, ptr %outputs, i32 1, ptr %workspace.slot.1309)
  switch i32 %record.make.status.1310, label %runtime.invalid.result.1316 [ i32 0, label %runtime.success.1311 i32 1, label %runtime.invalid.request.1312 i32 2, label %runtime.invalid.reference.1313 i32 3, label %runtime.scratch.capacity.1314 i32 4, label %runtime.retained.capacity.1315 ]
runtime.invalid.request.1312:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1313:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1314:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1315:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1316:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1311:
  %record.make.handle.1317 = load i64, ptr %workspace.slot.1309, align 8
  %ctx.field.1318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1319 = load i32, ptr %ctx.field.1318, align 4
  %steps.next.1320 = add i32 %steps.current.1319, 1
  store i32 %steps.next.1320, ptr %ctx.field.1318, align 4
  %steps.over.1321 = icmp ugt i32 %steps.next.1320, 10000
  br i1 %steps.over.1321, label %failure.1322, label %continue.1323
failure.1322:
  %ctx.field.1324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 135, ptr %ctx.field.1324, align 4
  %status.diagnostic.1325 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1325, align 4
  ret void
continue.1323:
  %ctx.field.1326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1327 = load i32, ptr %ctx.field.1326, align 4
  %steps.next.1328 = add i32 %steps.current.1327, 1
  store i32 %steps.next.1328, ptr %ctx.field.1326, align 4
  %steps.over.1329 = icmp ugt i32 %steps.next.1328, 10000
  br i1 %steps.over.1329, label %failure.1330, label %continue.1331
failure.1330:
  %ctx.field.1332 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 136, ptr %ctx.field.1332, align 4
  %status.diagnostic.1333 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1333, align 4
  ret void
continue.1331:
  %ctx.field.1334 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1335 = load i32, ptr %ctx.field.1334, align 4
  %steps.next.1336 = add i32 %steps.current.1335, 1
  store i32 %steps.next.1336, ptr %ctx.field.1334, align 4
  %steps.over.1337 = icmp ugt i32 %steps.next.1336, 10000
  br i1 %steps.over.1337, label %failure.1338, label %continue.1339
failure.1338:
  %ctx.field.1340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 137, ptr %ctx.field.1340, align 4
  %status.diagnostic.1341 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1341, align 4
  ret void
continue.1339:
  %depth.exceeded.1342 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1342, label %failure.1343, label %continue.1344
failure.1343:
  %ctx.field.1345 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 138, ptr %ctx.field.1345, align 4
  %status.diagnostic.1346 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1346, align 4
  ret void
continue.1344:
  %workspace.slot.1347 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1317, ptr %workspace.slot.1347, align 8
  %workspace.slot.1348 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1349 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 187, ptr %outputs, i32 1, ptr %workspace.slot.1348)
  switch i32 %record.make.status.1349, label %runtime.invalid.result.1355 [ i32 0, label %runtime.success.1350 i32 1, label %runtime.invalid.request.1351 i32 2, label %runtime.invalid.reference.1352 i32 3, label %runtime.scratch.capacity.1353 i32 4, label %runtime.retained.capacity.1354 ]
runtime.invalid.request.1351:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1352:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1353:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1354:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1355:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1350:
  %record.make.handle.1356 = load i64, ptr %workspace.slot.1348, align 8
  %ctx.field.1357 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1358 = load i32, ptr %ctx.field.1357, align 4
  %steps.next.1359 = add i32 %steps.current.1358, 1
  store i32 %steps.next.1359, ptr %ctx.field.1357, align 4
  %steps.over.1360 = icmp ugt i32 %steps.next.1359, 10000
  br i1 %steps.over.1360, label %failure.1361, label %continue.1362
failure.1361:
  %ctx.field.1363 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 139, ptr %ctx.field.1363, align 4
  %status.diagnostic.1364 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1364, align 4
  ret void
continue.1362:
  %ctx.field.1365 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1366 = load i32, ptr %ctx.field.1365, align 4
  %steps.next.1367 = add i32 %steps.current.1366, 1
  store i32 %steps.next.1367, ptr %ctx.field.1365, align 4
  %steps.over.1368 = icmp ugt i32 %steps.next.1367, 10000
  br i1 %steps.over.1368, label %failure.1369, label %continue.1370
failure.1369:
  %ctx.field.1371 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 140, ptr %ctx.field.1371, align 4
  %status.diagnostic.1372 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1372, align 4
  ret void
continue.1370:
  %ctx.field.1373 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1374 = load i32, ptr %ctx.field.1373, align 4
  %steps.next.1375 = add i32 %steps.current.1374, 1
  store i32 %steps.next.1375, ptr %ctx.field.1373, align 4
  %steps.over.1376 = icmp ugt i32 %steps.next.1375, 10000
  br i1 %steps.over.1376, label %failure.1377, label %continue.1378
failure.1377:
  %ctx.field.1379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 141, ptr %ctx.field.1379, align 4
  %status.diagnostic.1380 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1380, align 4
  ret void
continue.1378:
  %depth.exceeded.1381 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1381, label %failure.1382, label %continue.1383
failure.1382:
  %ctx.field.1384 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 142, ptr %ctx.field.1384, align 4
  %status.diagnostic.1385 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1385, align 4
  ret void
continue.1383:
  %workspace.slot.1386 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1356, ptr %workspace.slot.1386, align 8
  %workspace.slot.1387 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1388 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 188, ptr %outputs, i32 1, ptr %workspace.slot.1387)
  switch i32 %record.make.status.1388, label %runtime.invalid.result.1394 [ i32 0, label %runtime.success.1389 i32 1, label %runtime.invalid.request.1390 i32 2, label %runtime.invalid.reference.1391 i32 3, label %runtime.scratch.capacity.1392 i32 4, label %runtime.retained.capacity.1393 ]
runtime.invalid.request.1390:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1391:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1392:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1393:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1394:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1389:
  %record.make.handle.1395 = load i64, ptr %workspace.slot.1387, align 8
  %ctx.field.1396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1397 = load i32, ptr %ctx.field.1396, align 4
  %steps.next.1398 = add i32 %steps.current.1397, 1
  store i32 %steps.next.1398, ptr %ctx.field.1396, align 4
  %steps.over.1399 = icmp ugt i32 %steps.next.1398, 10000
  br i1 %steps.over.1399, label %failure.1400, label %continue.1401
failure.1400:
  %ctx.field.1402 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 143, ptr %ctx.field.1402, align 4
  %status.diagnostic.1403 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1403, align 4
  ret void
continue.1401:
  %ctx.field.1404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1405 = load i32, ptr %ctx.field.1404, align 4
  %steps.next.1406 = add i32 %steps.current.1405, 1
  store i32 %steps.next.1406, ptr %ctx.field.1404, align 4
  %steps.over.1407 = icmp ugt i32 %steps.next.1406, 10000
  br i1 %steps.over.1407, label %failure.1408, label %continue.1409
failure.1408:
  %ctx.field.1410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 144, ptr %ctx.field.1410, align 4
  %status.diagnostic.1411 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1411, align 4
  ret void
continue.1409:
  %ctx.field.1412 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1413 = load i32, ptr %ctx.field.1412, align 4
  %steps.next.1414 = add i32 %steps.current.1413, 1
  store i32 %steps.next.1414, ptr %ctx.field.1412, align 4
  %steps.over.1415 = icmp ugt i32 %steps.next.1414, 10000
  br i1 %steps.over.1415, label %failure.1416, label %continue.1417
failure.1416:
  %ctx.field.1418 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 145, ptr %ctx.field.1418, align 4
  %status.diagnostic.1419 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1419, align 4
  ret void
continue.1417:
  %depth.exceeded.1420 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1420, label %failure.1421, label %continue.1422
failure.1421:
  %ctx.field.1423 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 146, ptr %ctx.field.1423, align 4
  %status.diagnostic.1424 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1424, align 4
  ret void
continue.1422:
  %workspace.slot.1425 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1395, ptr %workspace.slot.1425, align 8
  %workspace.slot.1426 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1427 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 189, ptr %outputs, i32 1, ptr %workspace.slot.1426)
  switch i32 %record.make.status.1427, label %runtime.invalid.result.1433 [ i32 0, label %runtime.success.1428 i32 1, label %runtime.invalid.request.1429 i32 2, label %runtime.invalid.reference.1430 i32 3, label %runtime.scratch.capacity.1431 i32 4, label %runtime.retained.capacity.1432 ]
runtime.invalid.request.1429:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1430:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1431:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1432:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1433:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1428:
  %record.make.handle.1434 = load i64, ptr %workspace.slot.1426, align 8
  %ctx.field.1435 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1436 = load i32, ptr %ctx.field.1435, align 4
  %steps.next.1437 = add i32 %steps.current.1436, 1
  store i32 %steps.next.1437, ptr %ctx.field.1435, align 4
  %steps.over.1438 = icmp ugt i32 %steps.next.1437, 10000
  br i1 %steps.over.1438, label %failure.1439, label %continue.1440
failure.1439:
  %ctx.field.1441 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 147, ptr %ctx.field.1441, align 4
  %status.diagnostic.1442 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1442, align 4
  ret void
continue.1440:
  %ctx.field.1443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1444 = load i32, ptr %ctx.field.1443, align 4
  %steps.next.1445 = add i32 %steps.current.1444, 1
  store i32 %steps.next.1445, ptr %ctx.field.1443, align 4
  %steps.over.1446 = icmp ugt i32 %steps.next.1445, 10000
  br i1 %steps.over.1446, label %failure.1447, label %continue.1448
failure.1447:
  %ctx.field.1449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 148, ptr %ctx.field.1449, align 4
  %status.diagnostic.1450 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1450, align 4
  ret void
continue.1448:
  %ctx.field.1451 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1452 = load i32, ptr %ctx.field.1451, align 4
  %steps.next.1453 = add i32 %steps.current.1452, 1
  store i32 %steps.next.1453, ptr %ctx.field.1451, align 4
  %steps.over.1454 = icmp ugt i32 %steps.next.1453, 10000
  br i1 %steps.over.1454, label %failure.1455, label %continue.1456
failure.1455:
  %ctx.field.1457 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 149, ptr %ctx.field.1457, align 4
  %status.diagnostic.1458 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1458, align 4
  ret void
continue.1456:
  %depth.exceeded.1459 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1459, label %failure.1460, label %continue.1461
failure.1460:
  %ctx.field.1462 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 150, ptr %ctx.field.1462, align 4
  %status.diagnostic.1463 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1463, align 4
  ret void
continue.1461:
  %workspace.slot.1464 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1434, ptr %workspace.slot.1464, align 8
  %workspace.slot.1465 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1466 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 190, ptr %outputs, i32 1, ptr %workspace.slot.1465)
  switch i32 %record.make.status.1466, label %runtime.invalid.result.1472 [ i32 0, label %runtime.success.1467 i32 1, label %runtime.invalid.request.1468 i32 2, label %runtime.invalid.reference.1469 i32 3, label %runtime.scratch.capacity.1470 i32 4, label %runtime.retained.capacity.1471 ]
runtime.invalid.request.1468:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1469:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1470:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1471:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1472:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1467:
  %record.make.handle.1473 = load i64, ptr %workspace.slot.1465, align 8
  %ctx.field.1474 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1475 = load i32, ptr %ctx.field.1474, align 4
  %steps.next.1476 = add i32 %steps.current.1475, 1
  store i32 %steps.next.1476, ptr %ctx.field.1474, align 4
  %steps.over.1477 = icmp ugt i32 %steps.next.1476, 10000
  br i1 %steps.over.1477, label %failure.1478, label %continue.1479
failure.1478:
  %ctx.field.1480 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 151, ptr %ctx.field.1480, align 4
  %status.diagnostic.1481 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1481, align 4
  ret void
continue.1479:
  %ctx.field.1482 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1483 = load i32, ptr %ctx.field.1482, align 4
  %steps.next.1484 = add i32 %steps.current.1483, 1
  store i32 %steps.next.1484, ptr %ctx.field.1482, align 4
  %steps.over.1485 = icmp ugt i32 %steps.next.1484, 10000
  br i1 %steps.over.1485, label %failure.1486, label %continue.1487
failure.1486:
  %ctx.field.1488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 152, ptr %ctx.field.1488, align 4
  %status.diagnostic.1489 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1489, align 4
  ret void
continue.1487:
  %ctx.field.1490 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1491 = load i32, ptr %ctx.field.1490, align 4
  %steps.next.1492 = add i32 %steps.current.1491, 1
  store i32 %steps.next.1492, ptr %ctx.field.1490, align 4
  %steps.over.1493 = icmp ugt i32 %steps.next.1492, 10000
  br i1 %steps.over.1493, label %failure.1494, label %continue.1495
failure.1494:
  %ctx.field.1496 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 153, ptr %ctx.field.1496, align 4
  %status.diagnostic.1497 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1497, align 4
  ret void
continue.1495:
  %depth.exceeded.1498 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1498, label %failure.1499, label %continue.1500
failure.1499:
  %ctx.field.1501 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 154, ptr %ctx.field.1501, align 4
  %status.diagnostic.1502 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1502, align 4
  ret void
continue.1500:
  %workspace.slot.1503 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1473, ptr %workspace.slot.1503, align 8
  %workspace.slot.1504 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1505 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 191, ptr %outputs, i32 1, ptr %workspace.slot.1504)
  switch i32 %record.make.status.1505, label %runtime.invalid.result.1511 [ i32 0, label %runtime.success.1506 i32 1, label %runtime.invalid.request.1507 i32 2, label %runtime.invalid.reference.1508 i32 3, label %runtime.scratch.capacity.1509 i32 4, label %runtime.retained.capacity.1510 ]
runtime.invalid.request.1507:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1508:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1509:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1510:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1511:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1506:
  %record.make.handle.1512 = load i64, ptr %workspace.slot.1504, align 8
  %ctx.field.1513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1514 = load i32, ptr %ctx.field.1513, align 4
  %steps.next.1515 = add i32 %steps.current.1514, 1
  store i32 %steps.next.1515, ptr %ctx.field.1513, align 4
  %steps.over.1516 = icmp ugt i32 %steps.next.1515, 10000
  br i1 %steps.over.1516, label %failure.1517, label %continue.1518
failure.1517:
  %ctx.field.1519 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 155, ptr %ctx.field.1519, align 4
  %status.diagnostic.1520 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1520, align 4
  ret void
continue.1518:
  %ctx.field.1521 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1522 = load i32, ptr %ctx.field.1521, align 4
  %steps.next.1523 = add i32 %steps.current.1522, 1
  store i32 %steps.next.1523, ptr %ctx.field.1521, align 4
  %steps.over.1524 = icmp ugt i32 %steps.next.1523, 10000
  br i1 %steps.over.1524, label %failure.1525, label %continue.1526
failure.1525:
  %ctx.field.1527 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 156, ptr %ctx.field.1527, align 4
  %status.diagnostic.1528 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1528, align 4
  ret void
continue.1526:
  %ctx.field.1529 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1530 = load i32, ptr %ctx.field.1529, align 4
  %steps.next.1531 = add i32 %steps.current.1530, 1
  store i32 %steps.next.1531, ptr %ctx.field.1529, align 4
  %steps.over.1532 = icmp ugt i32 %steps.next.1531, 10000
  br i1 %steps.over.1532, label %failure.1533, label %continue.1534
failure.1533:
  %ctx.field.1535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 157, ptr %ctx.field.1535, align 4
  %status.diagnostic.1536 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1536, align 4
  ret void
continue.1534:
  %depth.exceeded.1537 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1537, label %failure.1538, label %continue.1539
failure.1538:
  %ctx.field.1540 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 158, ptr %ctx.field.1540, align 4
  %status.diagnostic.1541 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1541, align 4
  ret void
continue.1539:
  %workspace.slot.1542 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1512, ptr %workspace.slot.1542, align 8
  %workspace.slot.1543 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1544 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 192, ptr %outputs, i32 1, ptr %workspace.slot.1543)
  switch i32 %record.make.status.1544, label %runtime.invalid.result.1550 [ i32 0, label %runtime.success.1545 i32 1, label %runtime.invalid.request.1546 i32 2, label %runtime.invalid.reference.1547 i32 3, label %runtime.scratch.capacity.1548 i32 4, label %runtime.retained.capacity.1549 ]
runtime.invalid.request.1546:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1547:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1548:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1549:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1550:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1545:
  %record.make.handle.1551 = load i64, ptr %workspace.slot.1543, align 8
  %ctx.field.1552 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1553 = load i32, ptr %ctx.field.1552, align 4
  %steps.next.1554 = add i32 %steps.current.1553, 1
  store i32 %steps.next.1554, ptr %ctx.field.1552, align 4
  %steps.over.1555 = icmp ugt i32 %steps.next.1554, 10000
  br i1 %steps.over.1555, label %failure.1556, label %continue.1557
failure.1556:
  %ctx.field.1558 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 159, ptr %ctx.field.1558, align 4
  %status.diagnostic.1559 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1559, align 4
  ret void
continue.1557:
  %ctx.field.1560 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1561 = load i32, ptr %ctx.field.1560, align 4
  %steps.next.1562 = add i32 %steps.current.1561, 1
  store i32 %steps.next.1562, ptr %ctx.field.1560, align 4
  %steps.over.1563 = icmp ugt i32 %steps.next.1562, 10000
  br i1 %steps.over.1563, label %failure.1564, label %continue.1565
failure.1564:
  %ctx.field.1566 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 160, ptr %ctx.field.1566, align 4
  %status.diagnostic.1567 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1567, align 4
  ret void
continue.1565:
  %ctx.field.1568 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1569 = load i32, ptr %ctx.field.1568, align 4
  %steps.next.1570 = add i32 %steps.current.1569, 1
  store i32 %steps.next.1570, ptr %ctx.field.1568, align 4
  %steps.over.1571 = icmp ugt i32 %steps.next.1570, 10000
  br i1 %steps.over.1571, label %failure.1572, label %continue.1573
failure.1572:
  %ctx.field.1574 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 161, ptr %ctx.field.1574, align 4
  %status.diagnostic.1575 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1575, align 4
  ret void
continue.1573:
  %depth.exceeded.1576 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1576, label %failure.1577, label %continue.1578
failure.1577:
  %ctx.field.1579 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 162, ptr %ctx.field.1579, align 4
  %status.diagnostic.1580 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1580, align 4
  ret void
continue.1578:
  %workspace.slot.1581 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1551, ptr %workspace.slot.1581, align 8
  %workspace.slot.1582 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1583 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 194, ptr %outputs, i32 1, ptr %workspace.slot.1582)
  switch i32 %record.make.status.1583, label %runtime.invalid.result.1589 [ i32 0, label %runtime.success.1584 i32 1, label %runtime.invalid.request.1585 i32 2, label %runtime.invalid.reference.1586 i32 3, label %runtime.scratch.capacity.1587 i32 4, label %runtime.retained.capacity.1588 ]
runtime.invalid.request.1585:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1586:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1587:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1588:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1589:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1584:
  %record.make.handle.1590 = load i64, ptr %workspace.slot.1582, align 8
  %ctx.field.1591 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1592 = load i32, ptr %ctx.field.1591, align 4
  %steps.next.1593 = add i32 %steps.current.1592, 1
  store i32 %steps.next.1593, ptr %ctx.field.1591, align 4
  %steps.over.1594 = icmp ugt i32 %steps.next.1593, 10000
  br i1 %steps.over.1594, label %failure.1595, label %continue.1596
failure.1595:
  %ctx.field.1597 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 163, ptr %ctx.field.1597, align 4
  %status.diagnostic.1598 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1598, align 4
  ret void
continue.1596:
  %ctx.field.1599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1600 = load i32, ptr %ctx.field.1599, align 4
  %steps.next.1601 = add i32 %steps.current.1600, 1
  store i32 %steps.next.1601, ptr %ctx.field.1599, align 4
  %steps.over.1602 = icmp ugt i32 %steps.next.1601, 10000
  br i1 %steps.over.1602, label %failure.1603, label %continue.1604
failure.1603:
  %ctx.field.1605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 164, ptr %ctx.field.1605, align 4
  %status.diagnostic.1606 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1606, align 4
  ret void
continue.1604:
  %ctx.field.1607 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1608 = load i32, ptr %ctx.field.1607, align 4
  %steps.next.1609 = add i32 %steps.current.1608, 1
  store i32 %steps.next.1609, ptr %ctx.field.1607, align 4
  %steps.over.1610 = icmp ugt i32 %steps.next.1609, 10000
  br i1 %steps.over.1610, label %failure.1611, label %continue.1612
failure.1611:
  %ctx.field.1613 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 165, ptr %ctx.field.1613, align 4
  %status.diagnostic.1614 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1614, align 4
  ret void
continue.1612:
  %depth.exceeded.1615 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1615, label %failure.1616, label %continue.1617
failure.1616:
  %ctx.field.1618 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 166, ptr %ctx.field.1618, align 4
  %status.diagnostic.1619 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1619, align 4
  ret void
continue.1617:
  %workspace.slot.1620 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1590, ptr %workspace.slot.1620, align 8
  %workspace.slot.1621 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1622 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 195, ptr %outputs, i32 1, ptr %workspace.slot.1621)
  switch i32 %record.make.status.1622, label %runtime.invalid.result.1628 [ i32 0, label %runtime.success.1623 i32 1, label %runtime.invalid.request.1624 i32 2, label %runtime.invalid.reference.1625 i32 3, label %runtime.scratch.capacity.1626 i32 4, label %runtime.retained.capacity.1627 ]
runtime.invalid.request.1624:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1625:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1626:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1627:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1628:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1623:
  %record.make.handle.1629 = load i64, ptr %workspace.slot.1621, align 8
  %ctx.field.1630 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1631 = load i32, ptr %ctx.field.1630, align 4
  %steps.next.1632 = add i32 %steps.current.1631, 1
  store i32 %steps.next.1632, ptr %ctx.field.1630, align 4
  %steps.over.1633 = icmp ugt i32 %steps.next.1632, 10000
  br i1 %steps.over.1633, label %failure.1634, label %continue.1635
failure.1634:
  %ctx.field.1636 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 167, ptr %ctx.field.1636, align 4
  %status.diagnostic.1637 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1637, align 4
  ret void
continue.1635:
  %ctx.field.1638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1639 = load i32, ptr %ctx.field.1638, align 4
  %steps.next.1640 = add i32 %steps.current.1639, 1
  store i32 %steps.next.1640, ptr %ctx.field.1638, align 4
  %steps.over.1641 = icmp ugt i32 %steps.next.1640, 10000
  br i1 %steps.over.1641, label %failure.1642, label %continue.1643
failure.1642:
  %ctx.field.1644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 168, ptr %ctx.field.1644, align 4
  %status.diagnostic.1645 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1645, align 4
  ret void
continue.1643:
  %ctx.field.1646 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1647 = load i32, ptr %ctx.field.1646, align 4
  %steps.next.1648 = add i32 %steps.current.1647, 1
  store i32 %steps.next.1648, ptr %ctx.field.1646, align 4
  %steps.over.1649 = icmp ugt i32 %steps.next.1648, 10000
  br i1 %steps.over.1649, label %failure.1650, label %continue.1651
failure.1650:
  %ctx.field.1652 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 169, ptr %ctx.field.1652, align 4
  %status.diagnostic.1653 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1653, align 4
  ret void
continue.1651:
  %depth.exceeded.1654 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1654, label %failure.1655, label %continue.1656
failure.1655:
  %ctx.field.1657 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 170, ptr %ctx.field.1657, align 4
  %status.diagnostic.1658 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1658, align 4
  ret void
continue.1656:
  %workspace.slot.1659 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1629, ptr %workspace.slot.1659, align 8
  %workspace.slot.1660 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1661 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 196, ptr %outputs, i32 1, ptr %workspace.slot.1660)
  switch i32 %record.make.status.1661, label %runtime.invalid.result.1667 [ i32 0, label %runtime.success.1662 i32 1, label %runtime.invalid.request.1663 i32 2, label %runtime.invalid.reference.1664 i32 3, label %runtime.scratch.capacity.1665 i32 4, label %runtime.retained.capacity.1666 ]
runtime.invalid.request.1663:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1664:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1665:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1666:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1667:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1662:
  %record.make.handle.1668 = load i64, ptr %workspace.slot.1660, align 8
  %ctx.field.1669 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1670 = load i32, ptr %ctx.field.1669, align 4
  %steps.next.1671 = add i32 %steps.current.1670, 1
  store i32 %steps.next.1671, ptr %ctx.field.1669, align 4
  %steps.over.1672 = icmp ugt i32 %steps.next.1671, 10000
  br i1 %steps.over.1672, label %failure.1673, label %continue.1674
failure.1673:
  %ctx.field.1675 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 171, ptr %ctx.field.1675, align 4
  %status.diagnostic.1676 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1676, align 4
  ret void
continue.1674:
  %ctx.field.1677 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1678 = load i32, ptr %ctx.field.1677, align 4
  %steps.next.1679 = add i32 %steps.current.1678, 1
  store i32 %steps.next.1679, ptr %ctx.field.1677, align 4
  %steps.over.1680 = icmp ugt i32 %steps.next.1679, 10000
  br i1 %steps.over.1680, label %failure.1681, label %continue.1682
failure.1681:
  %ctx.field.1683 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 172, ptr %ctx.field.1683, align 4
  %status.diagnostic.1684 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1684, align 4
  ret void
continue.1682:
  %ctx.field.1685 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1686 = load i32, ptr %ctx.field.1685, align 4
  %steps.next.1687 = add i32 %steps.current.1686, 1
  store i32 %steps.next.1687, ptr %ctx.field.1685, align 4
  %steps.over.1688 = icmp ugt i32 %steps.next.1687, 10000
  br i1 %steps.over.1688, label %failure.1689, label %continue.1690
failure.1689:
  %ctx.field.1691 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 173, ptr %ctx.field.1691, align 4
  %status.diagnostic.1692 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1692, align 4
  ret void
continue.1690:
  %depth.exceeded.1693 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1693, label %failure.1694, label %continue.1695
failure.1694:
  %ctx.field.1696 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 174, ptr %ctx.field.1696, align 4
  %status.diagnostic.1697 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1697, align 4
  ret void
continue.1695:
  %workspace.slot.1698 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1668, ptr %workspace.slot.1698, align 8
  %workspace.slot.1699 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1700 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 197, ptr %outputs, i32 1, ptr %workspace.slot.1699)
  switch i32 %record.make.status.1700, label %runtime.invalid.result.1706 [ i32 0, label %runtime.success.1701 i32 1, label %runtime.invalid.request.1702 i32 2, label %runtime.invalid.reference.1703 i32 3, label %runtime.scratch.capacity.1704 i32 4, label %runtime.retained.capacity.1705 ]
runtime.invalid.request.1702:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1703:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1704:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1705:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1706:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1701:
  %record.make.handle.1707 = load i64, ptr %workspace.slot.1699, align 8
  %ctx.field.1708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1709 = load i32, ptr %ctx.field.1708, align 4
  %steps.next.1710 = add i32 %steps.current.1709, 1
  store i32 %steps.next.1710, ptr %ctx.field.1708, align 4
  %steps.over.1711 = icmp ugt i32 %steps.next.1710, 10000
  br i1 %steps.over.1711, label %failure.1712, label %continue.1713
failure.1712:
  %ctx.field.1714 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 175, ptr %ctx.field.1714, align 4
  %status.diagnostic.1715 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1715, align 4
  ret void
continue.1713:
  %ctx.field.1716 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1717 = load i32, ptr %ctx.field.1716, align 4
  %steps.next.1718 = add i32 %steps.current.1717, 1
  store i32 %steps.next.1718, ptr %ctx.field.1716, align 4
  %steps.over.1719 = icmp ugt i32 %steps.next.1718, 10000
  br i1 %steps.over.1719, label %failure.1720, label %continue.1721
failure.1720:
  %ctx.field.1722 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 176, ptr %ctx.field.1722, align 4
  %status.diagnostic.1723 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1723, align 4
  ret void
continue.1721:
  %ctx.field.1724 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1725 = load i32, ptr %ctx.field.1724, align 4
  %steps.next.1726 = add i32 %steps.current.1725, 1
  store i32 %steps.next.1726, ptr %ctx.field.1724, align 4
  %steps.over.1727 = icmp ugt i32 %steps.next.1726, 10000
  br i1 %steps.over.1727, label %failure.1728, label %continue.1729
failure.1728:
  %ctx.field.1730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 177, ptr %ctx.field.1730, align 4
  %status.diagnostic.1731 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1731, align 4
  ret void
continue.1729:
  %depth.exceeded.1732 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1732, label %failure.1733, label %continue.1734
failure.1733:
  %ctx.field.1735 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 178, ptr %ctx.field.1735, align 4
  %status.diagnostic.1736 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1736, align 4
  ret void
continue.1734:
  %workspace.slot.1737 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1707, ptr %workspace.slot.1737, align 8
  %workspace.slot.1738 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1739 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 198, ptr %outputs, i32 1, ptr %workspace.slot.1738)
  switch i32 %record.make.status.1739, label %runtime.invalid.result.1745 [ i32 0, label %runtime.success.1740 i32 1, label %runtime.invalid.request.1741 i32 2, label %runtime.invalid.reference.1742 i32 3, label %runtime.scratch.capacity.1743 i32 4, label %runtime.retained.capacity.1744 ]
runtime.invalid.request.1741:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1742:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1743:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1744:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1745:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1740:
  %record.make.handle.1746 = load i64, ptr %workspace.slot.1738, align 8
  %ctx.field.1747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1748 = load i32, ptr %ctx.field.1747, align 4
  %steps.next.1749 = add i32 %steps.current.1748, 1
  store i32 %steps.next.1749, ptr %ctx.field.1747, align 4
  %steps.over.1750 = icmp ugt i32 %steps.next.1749, 10000
  br i1 %steps.over.1750, label %failure.1751, label %continue.1752
failure.1751:
  %ctx.field.1753 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 179, ptr %ctx.field.1753, align 4
  %status.diagnostic.1754 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1754, align 4
  ret void
continue.1752:
  %ctx.field.1755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1756 = load i32, ptr %ctx.field.1755, align 4
  %steps.next.1757 = add i32 %steps.current.1756, 1
  store i32 %steps.next.1757, ptr %ctx.field.1755, align 4
  %steps.over.1758 = icmp ugt i32 %steps.next.1757, 10000
  br i1 %steps.over.1758, label %failure.1759, label %continue.1760
failure.1759:
  %ctx.field.1761 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 180, ptr %ctx.field.1761, align 4
  %status.diagnostic.1762 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1762, align 4
  ret void
continue.1760:
  %ctx.field.1763 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1764 = load i32, ptr %ctx.field.1763, align 4
  %steps.next.1765 = add i32 %steps.current.1764, 1
  store i32 %steps.next.1765, ptr %ctx.field.1763, align 4
  %steps.over.1766 = icmp ugt i32 %steps.next.1765, 10000
  br i1 %steps.over.1766, label %failure.1767, label %continue.1768
failure.1767:
  %ctx.field.1769 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 181, ptr %ctx.field.1769, align 4
  %status.diagnostic.1770 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1770, align 4
  ret void
continue.1768:
  %depth.exceeded.1771 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1771, label %failure.1772, label %continue.1773
failure.1772:
  %ctx.field.1774 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 182, ptr %ctx.field.1774, align 4
  %status.diagnostic.1775 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1775, align 4
  ret void
continue.1773:
  %workspace.slot.1776 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1746, ptr %workspace.slot.1776, align 8
  %workspace.slot.1777 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1778 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 199, ptr %outputs, i32 1, ptr %workspace.slot.1777)
  switch i32 %record.make.status.1778, label %runtime.invalid.result.1784 [ i32 0, label %runtime.success.1779 i32 1, label %runtime.invalid.request.1780 i32 2, label %runtime.invalid.reference.1781 i32 3, label %runtime.scratch.capacity.1782 i32 4, label %runtime.retained.capacity.1783 ]
runtime.invalid.request.1780:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1781:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1782:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1783:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1784:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1779:
  %record.make.handle.1785 = load i64, ptr %workspace.slot.1777, align 8
  %ctx.field.1786 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1787 = load i32, ptr %ctx.field.1786, align 4
  %steps.next.1788 = add i32 %steps.current.1787, 1
  store i32 %steps.next.1788, ptr %ctx.field.1786, align 4
  %steps.over.1789 = icmp ugt i32 %steps.next.1788, 10000
  br i1 %steps.over.1789, label %failure.1790, label %continue.1791
failure.1790:
  %ctx.field.1792 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 183, ptr %ctx.field.1792, align 4
  %status.diagnostic.1793 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1793, align 4
  ret void
continue.1791:
  %ctx.field.1794 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1795 = load i32, ptr %ctx.field.1794, align 4
  %steps.next.1796 = add i32 %steps.current.1795, 1
  store i32 %steps.next.1796, ptr %ctx.field.1794, align 4
  %steps.over.1797 = icmp ugt i32 %steps.next.1796, 10000
  br i1 %steps.over.1797, label %failure.1798, label %continue.1799
failure.1798:
  %ctx.field.1800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 184, ptr %ctx.field.1800, align 4
  %status.diagnostic.1801 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1801, align 4
  ret void
continue.1799:
  %ctx.field.1802 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1803 = load i32, ptr %ctx.field.1802, align 4
  %steps.next.1804 = add i32 %steps.current.1803, 1
  store i32 %steps.next.1804, ptr %ctx.field.1802, align 4
  %steps.over.1805 = icmp ugt i32 %steps.next.1804, 10000
  br i1 %steps.over.1805, label %failure.1806, label %continue.1807
failure.1806:
  %ctx.field.1808 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 185, ptr %ctx.field.1808, align 4
  %status.diagnostic.1809 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1809, align 4
  ret void
continue.1807:
  %depth.exceeded.1810 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1810, label %failure.1811, label %continue.1812
failure.1811:
  %ctx.field.1813 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 186, ptr %ctx.field.1813, align 4
  %status.diagnostic.1814 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1814, align 4
  ret void
continue.1812:
  %workspace.slot.1815 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1785, ptr %workspace.slot.1815, align 8
  %workspace.slot.1816 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1817 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 200, ptr %outputs, i32 1, ptr %workspace.slot.1816)
  switch i32 %record.make.status.1817, label %runtime.invalid.result.1823 [ i32 0, label %runtime.success.1818 i32 1, label %runtime.invalid.request.1819 i32 2, label %runtime.invalid.reference.1820 i32 3, label %runtime.scratch.capacity.1821 i32 4, label %runtime.retained.capacity.1822 ]
runtime.invalid.request.1819:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1820:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1821:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1822:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1823:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1818:
  %record.make.handle.1824 = load i64, ptr %workspace.slot.1816, align 8
  %ctx.field.1825 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1826 = load i32, ptr %ctx.field.1825, align 4
  %steps.next.1827 = add i32 %steps.current.1826, 1
  store i32 %steps.next.1827, ptr %ctx.field.1825, align 4
  %steps.over.1828 = icmp ugt i32 %steps.next.1827, 10000
  br i1 %steps.over.1828, label %failure.1829, label %continue.1830
failure.1829:
  %ctx.field.1831 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 187, ptr %ctx.field.1831, align 4
  %status.diagnostic.1832 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1832, align 4
  ret void
continue.1830:
  %ctx.field.1833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1834 = load i32, ptr %ctx.field.1833, align 4
  %steps.next.1835 = add i32 %steps.current.1834, 1
  store i32 %steps.next.1835, ptr %ctx.field.1833, align 4
  %steps.over.1836 = icmp ugt i32 %steps.next.1835, 10000
  br i1 %steps.over.1836, label %failure.1837, label %continue.1838
failure.1837:
  %ctx.field.1839 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 188, ptr %ctx.field.1839, align 4
  %status.diagnostic.1840 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1840, align 4
  ret void
continue.1838:
  %ctx.field.1841 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1842 = load i32, ptr %ctx.field.1841, align 4
  %steps.next.1843 = add i32 %steps.current.1842, 1
  store i32 %steps.next.1843, ptr %ctx.field.1841, align 4
  %steps.over.1844 = icmp ugt i32 %steps.next.1843, 10000
  br i1 %steps.over.1844, label %failure.1845, label %continue.1846
failure.1845:
  %ctx.field.1847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 189, ptr %ctx.field.1847, align 4
  %status.diagnostic.1848 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1848, align 4
  ret void
continue.1846:
  %depth.exceeded.1849 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1849, label %failure.1850, label %continue.1851
failure.1850:
  %ctx.field.1852 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 190, ptr %ctx.field.1852, align 4
  %status.diagnostic.1853 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1853, align 4
  ret void
continue.1851:
  %workspace.slot.1854 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1824, ptr %workspace.slot.1854, align 8
  %workspace.slot.1855 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1856 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 201, ptr %outputs, i32 1, ptr %workspace.slot.1855)
  switch i32 %record.make.status.1856, label %runtime.invalid.result.1862 [ i32 0, label %runtime.success.1857 i32 1, label %runtime.invalid.request.1858 i32 2, label %runtime.invalid.reference.1859 i32 3, label %runtime.scratch.capacity.1860 i32 4, label %runtime.retained.capacity.1861 ]
runtime.invalid.request.1858:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1859:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1860:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1861:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1862:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1857:
  %record.make.handle.1863 = load i64, ptr %workspace.slot.1855, align 8
  %ctx.field.1864 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1865 = load i32, ptr %ctx.field.1864, align 4
  %steps.next.1866 = add i32 %steps.current.1865, 1
  store i32 %steps.next.1866, ptr %ctx.field.1864, align 4
  %steps.over.1867 = icmp ugt i32 %steps.next.1866, 10000
  br i1 %steps.over.1867, label %failure.1868, label %continue.1869
failure.1868:
  %ctx.field.1870 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 191, ptr %ctx.field.1870, align 4
  %status.diagnostic.1871 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1871, align 4
  ret void
continue.1869:
  %ctx.field.1872 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1873 = load i32, ptr %ctx.field.1872, align 4
  %steps.next.1874 = add i32 %steps.current.1873, 1
  store i32 %steps.next.1874, ptr %ctx.field.1872, align 4
  %steps.over.1875 = icmp ugt i32 %steps.next.1874, 10000
  br i1 %steps.over.1875, label %failure.1876, label %continue.1877
failure.1876:
  %ctx.field.1878 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 192, ptr %ctx.field.1878, align 4
  %status.diagnostic.1879 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1879, align 4
  ret void
continue.1877:
  %ctx.field.1880 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1881 = load i32, ptr %ctx.field.1880, align 4
  %steps.next.1882 = add i32 %steps.current.1881, 1
  store i32 %steps.next.1882, ptr %ctx.field.1880, align 4
  %steps.over.1883 = icmp ugt i32 %steps.next.1882, 10000
  br i1 %steps.over.1883, label %failure.1884, label %continue.1885
failure.1884:
  %ctx.field.1886 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 193, ptr %ctx.field.1886, align 4
  %status.diagnostic.1887 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1887, align 4
  ret void
continue.1885:
  %depth.exceeded.1888 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1888, label %failure.1889, label %continue.1890
failure.1889:
  %ctx.field.1891 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 194, ptr %ctx.field.1891, align 4
  %status.diagnostic.1892 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1892, align 4
  ret void
continue.1890:
  %workspace.slot.1893 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1863, ptr %workspace.slot.1893, align 8
  %workspace.slot.1894 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1895 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 202, ptr %outputs, i32 1, ptr %workspace.slot.1894)
  switch i32 %record.make.status.1895, label %runtime.invalid.result.1901 [ i32 0, label %runtime.success.1896 i32 1, label %runtime.invalid.request.1897 i32 2, label %runtime.invalid.reference.1898 i32 3, label %runtime.scratch.capacity.1899 i32 4, label %runtime.retained.capacity.1900 ]
runtime.invalid.request.1897:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1898:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1899:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1900:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1901:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1896:
  %record.make.handle.1902 = load i64, ptr %workspace.slot.1894, align 8
  %ctx.field.1903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1904 = load i32, ptr %ctx.field.1903, align 4
  %steps.next.1905 = add i32 %steps.current.1904, 1
  store i32 %steps.next.1905, ptr %ctx.field.1903, align 4
  %steps.over.1906 = icmp ugt i32 %steps.next.1905, 10000
  br i1 %steps.over.1906, label %failure.1907, label %continue.1908
failure.1907:
  %ctx.field.1909 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 195, ptr %ctx.field.1909, align 4
  %status.diagnostic.1910 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1910, align 4
  ret void
continue.1908:
  %ctx.field.1911 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1912 = load i32, ptr %ctx.field.1911, align 4
  %steps.next.1913 = add i32 %steps.current.1912, 1
  store i32 %steps.next.1913, ptr %ctx.field.1911, align 4
  %steps.over.1914 = icmp ugt i32 %steps.next.1913, 10000
  br i1 %steps.over.1914, label %failure.1915, label %continue.1916
failure.1915:
  %ctx.field.1917 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 196, ptr %ctx.field.1917, align 4
  %status.diagnostic.1918 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1918, align 4
  ret void
continue.1916:
  %ctx.field.1919 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1920 = load i32, ptr %ctx.field.1919, align 4
  %steps.next.1921 = add i32 %steps.current.1920, 1
  store i32 %steps.next.1921, ptr %ctx.field.1919, align 4
  %steps.over.1922 = icmp ugt i32 %steps.next.1921, 10000
  br i1 %steps.over.1922, label %failure.1923, label %continue.1924
failure.1923:
  %ctx.field.1925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 197, ptr %ctx.field.1925, align 4
  %status.diagnostic.1926 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1926, align 4
  ret void
continue.1924:
  %depth.exceeded.1927 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1927, label %failure.1928, label %continue.1929
failure.1928:
  %ctx.field.1930 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 198, ptr %ctx.field.1930, align 4
  %status.diagnostic.1931 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1931, align 4
  ret void
continue.1929:
  %workspace.slot.1932 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1902, ptr %workspace.slot.1932, align 8
  %workspace.slot.1933 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1934 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 203, ptr %outputs, i32 1, ptr %workspace.slot.1933)
  switch i32 %record.make.status.1934, label %runtime.invalid.result.1940 [ i32 0, label %runtime.success.1935 i32 1, label %runtime.invalid.request.1936 i32 2, label %runtime.invalid.reference.1937 i32 3, label %runtime.scratch.capacity.1938 i32 4, label %runtime.retained.capacity.1939 ]
runtime.invalid.request.1936:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1937:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1938:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1939:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1940:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1935:
  %record.make.handle.1941 = load i64, ptr %workspace.slot.1933, align 8
  %ctx.field.1942 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1943 = load i32, ptr %ctx.field.1942, align 4
  %steps.next.1944 = add i32 %steps.current.1943, 1
  store i32 %steps.next.1944, ptr %ctx.field.1942, align 4
  %steps.over.1945 = icmp ugt i32 %steps.next.1944, 10000
  br i1 %steps.over.1945, label %failure.1946, label %continue.1947
failure.1946:
  %ctx.field.1948 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 199, ptr %ctx.field.1948, align 4
  %status.diagnostic.1949 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1949, align 4
  ret void
continue.1947:
  %ctx.field.1950 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1951 = load i32, ptr %ctx.field.1950, align 4
  %steps.next.1952 = add i32 %steps.current.1951, 1
  store i32 %steps.next.1952, ptr %ctx.field.1950, align 4
  %steps.over.1953 = icmp ugt i32 %steps.next.1952, 10000
  br i1 %steps.over.1953, label %failure.1954, label %continue.1955
failure.1954:
  %ctx.field.1956 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 200, ptr %ctx.field.1956, align 4
  %status.diagnostic.1957 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1957, align 4
  ret void
continue.1955:
  %ctx.field.1958 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1959 = load i32, ptr %ctx.field.1958, align 4
  %steps.next.1960 = add i32 %steps.current.1959, 1
  store i32 %steps.next.1960, ptr %ctx.field.1958, align 4
  %steps.over.1961 = icmp ugt i32 %steps.next.1960, 10000
  br i1 %steps.over.1961, label %failure.1962, label %continue.1963
failure.1962:
  %ctx.field.1964 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 201, ptr %ctx.field.1964, align 4
  %status.diagnostic.1965 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1965, align 4
  ret void
continue.1963:
  %depth.exceeded.1966 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1966, label %failure.1967, label %continue.1968
failure.1967:
  %ctx.field.1969 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 202, ptr %ctx.field.1969, align 4
  %status.diagnostic.1970 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1970, align 4
  ret void
continue.1968:
  %workspace.slot.1971 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1941, ptr %workspace.slot.1971, align 8
  %workspace.slot.1972 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1973 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 205, ptr %outputs, i32 1, ptr %workspace.slot.1972)
  switch i32 %record.make.status.1973, label %runtime.invalid.result.1979 [ i32 0, label %runtime.success.1974 i32 1, label %runtime.invalid.request.1975 i32 2, label %runtime.invalid.reference.1976 i32 3, label %runtime.scratch.capacity.1977 i32 4, label %runtime.retained.capacity.1978 ]
runtime.invalid.request.1975:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1976:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1977:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1978:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1979:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1974:
  %record.make.handle.1980 = load i64, ptr %workspace.slot.1972, align 8
  %ctx.field.1981 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1982 = load i32, ptr %ctx.field.1981, align 4
  %steps.next.1983 = add i32 %steps.current.1982, 1
  store i32 %steps.next.1983, ptr %ctx.field.1981, align 4
  %steps.over.1984 = icmp ugt i32 %steps.next.1983, 10000
  br i1 %steps.over.1984, label %failure.1985, label %continue.1986
failure.1985:
  %ctx.field.1987 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 203, ptr %ctx.field.1987, align 4
  %status.diagnostic.1988 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1988, align 4
  ret void
continue.1986:
  %ctx.field.1989 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1990 = load i32, ptr %ctx.field.1989, align 4
  %steps.next.1991 = add i32 %steps.current.1990, 1
  store i32 %steps.next.1991, ptr %ctx.field.1989, align 4
  %steps.over.1992 = icmp ugt i32 %steps.next.1991, 10000
  br i1 %steps.over.1992, label %failure.1993, label %continue.1994
failure.1993:
  %ctx.field.1995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 204, ptr %ctx.field.1995, align 4
  %status.diagnostic.1996 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1996, align 4
  ret void
continue.1994:
  %ctx.field.1997 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1998 = load i32, ptr %ctx.field.1997, align 4
  %steps.next.1999 = add i32 %steps.current.1998, 1
  store i32 %steps.next.1999, ptr %ctx.field.1997, align 4
  %steps.over.2000 = icmp ugt i32 %steps.next.1999, 10000
  br i1 %steps.over.2000, label %failure.2001, label %continue.2002
failure.2001:
  %ctx.field.2003 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 205, ptr %ctx.field.2003, align 4
  %status.diagnostic.2004 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2004, align 4
  ret void
continue.2002:
  %depth.exceeded.2005 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2005, label %failure.2006, label %continue.2007
failure.2006:
  %ctx.field.2008 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 206, ptr %ctx.field.2008, align 4
  %status.diagnostic.2009 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2009, align 4
  ret void
continue.2007:
  %workspace.slot.2010 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1980, ptr %workspace.slot.2010, align 8
  %workspace.slot.2011 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2012 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 206, ptr %outputs, i32 1, ptr %workspace.slot.2011)
  switch i32 %record.make.status.2012, label %runtime.invalid.result.2018 [ i32 0, label %runtime.success.2013 i32 1, label %runtime.invalid.request.2014 i32 2, label %runtime.invalid.reference.2015 i32 3, label %runtime.scratch.capacity.2016 i32 4, label %runtime.retained.capacity.2017 ]
runtime.invalid.request.2014:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2015:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2016:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2017:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2018:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2013:
  %record.make.handle.2019 = load i64, ptr %workspace.slot.2011, align 8
  %ctx.field.2020 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2021 = load i32, ptr %ctx.field.2020, align 4
  %steps.next.2022 = add i32 %steps.current.2021, 1
  store i32 %steps.next.2022, ptr %ctx.field.2020, align 4
  %steps.over.2023 = icmp ugt i32 %steps.next.2022, 10000
  br i1 %steps.over.2023, label %failure.2024, label %continue.2025
failure.2024:
  %ctx.field.2026 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 207, ptr %ctx.field.2026, align 4
  %status.diagnostic.2027 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2027, align 4
  ret void
continue.2025:
  %ctx.field.2028 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2029 = load i32, ptr %ctx.field.2028, align 4
  %steps.next.2030 = add i32 %steps.current.2029, 1
  store i32 %steps.next.2030, ptr %ctx.field.2028, align 4
  %steps.over.2031 = icmp ugt i32 %steps.next.2030, 10000
  br i1 %steps.over.2031, label %failure.2032, label %continue.2033
failure.2032:
  %ctx.field.2034 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 208, ptr %ctx.field.2034, align 4
  %status.diagnostic.2035 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2035, align 4
  ret void
continue.2033:
  %ctx.field.2036 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2037 = load i32, ptr %ctx.field.2036, align 4
  %steps.next.2038 = add i32 %steps.current.2037, 1
  store i32 %steps.next.2038, ptr %ctx.field.2036, align 4
  %steps.over.2039 = icmp ugt i32 %steps.next.2038, 10000
  br i1 %steps.over.2039, label %failure.2040, label %continue.2041
failure.2040:
  %ctx.field.2042 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 209, ptr %ctx.field.2042, align 4
  %status.diagnostic.2043 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2043, align 4
  ret void
continue.2041:
  %depth.exceeded.2044 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2044, label %failure.2045, label %continue.2046
failure.2045:
  %ctx.field.2047 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 210, ptr %ctx.field.2047, align 4
  %status.diagnostic.2048 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2048, align 4
  ret void
continue.2046:
  %workspace.slot.2049 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2019, ptr %workspace.slot.2049, align 8
  %workspace.slot.2050 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2051 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 207, ptr %outputs, i32 1, ptr %workspace.slot.2050)
  switch i32 %record.make.status.2051, label %runtime.invalid.result.2057 [ i32 0, label %runtime.success.2052 i32 1, label %runtime.invalid.request.2053 i32 2, label %runtime.invalid.reference.2054 i32 3, label %runtime.scratch.capacity.2055 i32 4, label %runtime.retained.capacity.2056 ]
runtime.invalid.request.2053:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2054:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2055:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2056:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2057:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2052:
  %record.make.handle.2058 = load i64, ptr %workspace.slot.2050, align 8
  %ctx.field.2059 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2060 = load i32, ptr %ctx.field.2059, align 4
  %steps.next.2061 = add i32 %steps.current.2060, 1
  store i32 %steps.next.2061, ptr %ctx.field.2059, align 4
  %steps.over.2062 = icmp ugt i32 %steps.next.2061, 10000
  br i1 %steps.over.2062, label %failure.2063, label %continue.2064
failure.2063:
  %ctx.field.2065 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 211, ptr %ctx.field.2065, align 4
  %status.diagnostic.2066 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2066, align 4
  ret void
continue.2064:
  %ctx.field.2067 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2068 = load i32, ptr %ctx.field.2067, align 4
  %steps.next.2069 = add i32 %steps.current.2068, 1
  store i32 %steps.next.2069, ptr %ctx.field.2067, align 4
  %steps.over.2070 = icmp ugt i32 %steps.next.2069, 10000
  br i1 %steps.over.2070, label %failure.2071, label %continue.2072
failure.2071:
  %ctx.field.2073 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 212, ptr %ctx.field.2073, align 4
  %status.diagnostic.2074 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2074, align 4
  ret void
continue.2072:
  %ctx.field.2075 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2076 = load i32, ptr %ctx.field.2075, align 4
  %steps.next.2077 = add i32 %steps.current.2076, 1
  store i32 %steps.next.2077, ptr %ctx.field.2075, align 4
  %steps.over.2078 = icmp ugt i32 %steps.next.2077, 10000
  br i1 %steps.over.2078, label %failure.2079, label %continue.2080
failure.2079:
  %ctx.field.2081 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 213, ptr %ctx.field.2081, align 4
  %status.diagnostic.2082 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2082, align 4
  ret void
continue.2080:
  %depth.exceeded.2083 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2083, label %failure.2084, label %continue.2085
failure.2084:
  %ctx.field.2086 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 214, ptr %ctx.field.2086, align 4
  %status.diagnostic.2087 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2087, align 4
  ret void
continue.2085:
  %workspace.slot.2088 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2058, ptr %workspace.slot.2088, align 8
  %workspace.slot.2089 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2090 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 208, ptr %outputs, i32 1, ptr %workspace.slot.2089)
  switch i32 %record.make.status.2090, label %runtime.invalid.result.2096 [ i32 0, label %runtime.success.2091 i32 1, label %runtime.invalid.request.2092 i32 2, label %runtime.invalid.reference.2093 i32 3, label %runtime.scratch.capacity.2094 i32 4, label %runtime.retained.capacity.2095 ]
runtime.invalid.request.2092:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2093:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2094:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2095:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2096:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2091:
  %record.make.handle.2097 = load i64, ptr %workspace.slot.2089, align 8
  %ctx.field.2098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2099 = load i32, ptr %ctx.field.2098, align 4
  %steps.next.2100 = add i32 %steps.current.2099, 1
  store i32 %steps.next.2100, ptr %ctx.field.2098, align 4
  %steps.over.2101 = icmp ugt i32 %steps.next.2100, 10000
  br i1 %steps.over.2101, label %failure.2102, label %continue.2103
failure.2102:
  %ctx.field.2104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 215, ptr %ctx.field.2104, align 4
  %status.diagnostic.2105 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2105, align 4
  ret void
continue.2103:
  %ctx.field.2106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2107 = load i32, ptr %ctx.field.2106, align 4
  %steps.next.2108 = add i32 %steps.current.2107, 1
  store i32 %steps.next.2108, ptr %ctx.field.2106, align 4
  %steps.over.2109 = icmp ugt i32 %steps.next.2108, 10000
  br i1 %steps.over.2109, label %failure.2110, label %continue.2111
failure.2110:
  %ctx.field.2112 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 216, ptr %ctx.field.2112, align 4
  %status.diagnostic.2113 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2113, align 4
  ret void
continue.2111:
  %ctx.field.2114 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2115 = load i32, ptr %ctx.field.2114, align 4
  %steps.next.2116 = add i32 %steps.current.2115, 1
  store i32 %steps.next.2116, ptr %ctx.field.2114, align 4
  %steps.over.2117 = icmp ugt i32 %steps.next.2116, 10000
  br i1 %steps.over.2117, label %failure.2118, label %continue.2119
failure.2118:
  %ctx.field.2120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 217, ptr %ctx.field.2120, align 4
  %status.diagnostic.2121 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2121, align 4
  ret void
continue.2119:
  %depth.exceeded.2122 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2122, label %failure.2123, label %continue.2124
failure.2123:
  %ctx.field.2125 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 218, ptr %ctx.field.2125, align 4
  %status.diagnostic.2126 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2126, align 4
  ret void
continue.2124:
  %workspace.slot.2127 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2097, ptr %workspace.slot.2127, align 8
  %workspace.slot.2128 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2129 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 209, ptr %outputs, i32 1, ptr %workspace.slot.2128)
  switch i32 %record.make.status.2129, label %runtime.invalid.result.2135 [ i32 0, label %runtime.success.2130 i32 1, label %runtime.invalid.request.2131 i32 2, label %runtime.invalid.reference.2132 i32 3, label %runtime.scratch.capacity.2133 i32 4, label %runtime.retained.capacity.2134 ]
runtime.invalid.request.2131:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2132:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2133:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2134:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2135:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2130:
  %record.make.handle.2136 = load i64, ptr %workspace.slot.2128, align 8
  %ctx.field.2137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2138 = load i32, ptr %ctx.field.2137, align 4
  %steps.next.2139 = add i32 %steps.current.2138, 1
  store i32 %steps.next.2139, ptr %ctx.field.2137, align 4
  %steps.over.2140 = icmp ugt i32 %steps.next.2139, 10000
  br i1 %steps.over.2140, label %failure.2141, label %continue.2142
failure.2141:
  %ctx.field.2143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 219, ptr %ctx.field.2143, align 4
  %status.diagnostic.2144 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2144, align 4
  ret void
continue.2142:
  %ctx.field.2145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2146 = load i32, ptr %ctx.field.2145, align 4
  %steps.next.2147 = add i32 %steps.current.2146, 1
  store i32 %steps.next.2147, ptr %ctx.field.2145, align 4
  %steps.over.2148 = icmp ugt i32 %steps.next.2147, 10000
  br i1 %steps.over.2148, label %failure.2149, label %continue.2150
failure.2149:
  %ctx.field.2151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 220, ptr %ctx.field.2151, align 4
  %status.diagnostic.2152 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2152, align 4
  ret void
continue.2150:
  %ctx.field.2153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2154 = load i32, ptr %ctx.field.2153, align 4
  %steps.next.2155 = add i32 %steps.current.2154, 1
  store i32 %steps.next.2155, ptr %ctx.field.2153, align 4
  %steps.over.2156 = icmp ugt i32 %steps.next.2155, 10000
  br i1 %steps.over.2156, label %failure.2157, label %continue.2158
failure.2157:
  %ctx.field.2159 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 221, ptr %ctx.field.2159, align 4
  %status.diagnostic.2160 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2160, align 4
  ret void
continue.2158:
  %depth.exceeded.2161 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2161, label %failure.2162, label %continue.2163
failure.2162:
  %ctx.field.2164 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 222, ptr %ctx.field.2164, align 4
  %status.diagnostic.2165 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2165, align 4
  ret void
continue.2163:
  %workspace.slot.2166 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2136, ptr %workspace.slot.2166, align 8
  %workspace.slot.2167 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2168 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 210, ptr %outputs, i32 1, ptr %workspace.slot.2167)
  switch i32 %record.make.status.2168, label %runtime.invalid.result.2174 [ i32 0, label %runtime.success.2169 i32 1, label %runtime.invalid.request.2170 i32 2, label %runtime.invalid.reference.2171 i32 3, label %runtime.scratch.capacity.2172 i32 4, label %runtime.retained.capacity.2173 ]
runtime.invalid.request.2170:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2171:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2172:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2173:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2174:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2169:
  %record.make.handle.2175 = load i64, ptr %workspace.slot.2167, align 8
  %ctx.field.2176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2177 = load i32, ptr %ctx.field.2176, align 4
  %steps.next.2178 = add i32 %steps.current.2177, 1
  store i32 %steps.next.2178, ptr %ctx.field.2176, align 4
  %steps.over.2179 = icmp ugt i32 %steps.next.2178, 10000
  br i1 %steps.over.2179, label %failure.2180, label %continue.2181
failure.2180:
  %ctx.field.2182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 223, ptr %ctx.field.2182, align 4
  %status.diagnostic.2183 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2183, align 4
  ret void
continue.2181:
  %ctx.field.2184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2185 = load i32, ptr %ctx.field.2184, align 4
  %steps.next.2186 = add i32 %steps.current.2185, 1
  store i32 %steps.next.2186, ptr %ctx.field.2184, align 4
  %steps.over.2187 = icmp ugt i32 %steps.next.2186, 10000
  br i1 %steps.over.2187, label %failure.2188, label %continue.2189
failure.2188:
  %ctx.field.2190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 224, ptr %ctx.field.2190, align 4
  %status.diagnostic.2191 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2191, align 4
  ret void
continue.2189:
  %ctx.field.2192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2193 = load i32, ptr %ctx.field.2192, align 4
  %steps.next.2194 = add i32 %steps.current.2193, 1
  store i32 %steps.next.2194, ptr %ctx.field.2192, align 4
  %steps.over.2195 = icmp ugt i32 %steps.next.2194, 10000
  br i1 %steps.over.2195, label %failure.2196, label %continue.2197
failure.2196:
  %ctx.field.2198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 225, ptr %ctx.field.2198, align 4
  %status.diagnostic.2199 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2199, align 4
  ret void
continue.2197:
  %depth.exceeded.2200 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2200, label %failure.2201, label %continue.2202
failure.2201:
  %ctx.field.2203 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 226, ptr %ctx.field.2203, align 4
  %status.diagnostic.2204 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2204, align 4
  ret void
continue.2202:
  %workspace.slot.2205 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2175, ptr %workspace.slot.2205, align 8
  %workspace.slot.2206 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2207 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 211, ptr %outputs, i32 1, ptr %workspace.slot.2206)
  switch i32 %record.make.status.2207, label %runtime.invalid.result.2213 [ i32 0, label %runtime.success.2208 i32 1, label %runtime.invalid.request.2209 i32 2, label %runtime.invalid.reference.2210 i32 3, label %runtime.scratch.capacity.2211 i32 4, label %runtime.retained.capacity.2212 ]
runtime.invalid.request.2209:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2210:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2211:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2212:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2213:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2208:
  %record.make.handle.2214 = load i64, ptr %workspace.slot.2206, align 8
  %ctx.field.2215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2216 = load i32, ptr %ctx.field.2215, align 4
  %steps.next.2217 = add i32 %steps.current.2216, 1
  store i32 %steps.next.2217, ptr %ctx.field.2215, align 4
  %steps.over.2218 = icmp ugt i32 %steps.next.2217, 10000
  br i1 %steps.over.2218, label %failure.2219, label %continue.2220
failure.2219:
  %ctx.field.2221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 227, ptr %ctx.field.2221, align 4
  %status.diagnostic.2222 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2222, align 4
  ret void
continue.2220:
  %ctx.field.2223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2224 = load i32, ptr %ctx.field.2223, align 4
  %steps.next.2225 = add i32 %steps.current.2224, 1
  store i32 %steps.next.2225, ptr %ctx.field.2223, align 4
  %steps.over.2226 = icmp ugt i32 %steps.next.2225, 10000
  br i1 %steps.over.2226, label %failure.2227, label %continue.2228
failure.2227:
  %ctx.field.2229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 228, ptr %ctx.field.2229, align 4
  %status.diagnostic.2230 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2230, align 4
  ret void
continue.2228:
  %ctx.field.2231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2232 = load i32, ptr %ctx.field.2231, align 4
  %steps.next.2233 = add i32 %steps.current.2232, 1
  store i32 %steps.next.2233, ptr %ctx.field.2231, align 4
  %steps.over.2234 = icmp ugt i32 %steps.next.2233, 10000
  br i1 %steps.over.2234, label %failure.2235, label %continue.2236
failure.2235:
  %ctx.field.2237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 229, ptr %ctx.field.2237, align 4
  %status.diagnostic.2238 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2238, align 4
  ret void
continue.2236:
  %depth.exceeded.2239 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2239, label %failure.2240, label %continue.2241
failure.2240:
  %ctx.field.2242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 230, ptr %ctx.field.2242, align 4
  %status.diagnostic.2243 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2243, align 4
  ret void
continue.2241:
  %workspace.slot.2244 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2214, ptr %workspace.slot.2244, align 8
  %workspace.slot.2245 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2246 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 212, ptr %outputs, i32 1, ptr %workspace.slot.2245)
  switch i32 %record.make.status.2246, label %runtime.invalid.result.2252 [ i32 0, label %runtime.success.2247 i32 1, label %runtime.invalid.request.2248 i32 2, label %runtime.invalid.reference.2249 i32 3, label %runtime.scratch.capacity.2250 i32 4, label %runtime.retained.capacity.2251 ]
runtime.invalid.request.2248:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2249:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2250:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2251:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2252:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2247:
  %record.make.handle.2253 = load i64, ptr %workspace.slot.2245, align 8
  %ctx.field.2254 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2255 = load i32, ptr %ctx.field.2254, align 4
  %steps.next.2256 = add i32 %steps.current.2255, 1
  store i32 %steps.next.2256, ptr %ctx.field.2254, align 4
  %steps.over.2257 = icmp ugt i32 %steps.next.2256, 10000
  br i1 %steps.over.2257, label %failure.2258, label %continue.2259
failure.2258:
  %ctx.field.2260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 231, ptr %ctx.field.2260, align 4
  %status.diagnostic.2261 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2261, align 4
  ret void
continue.2259:
  %ctx.field.2262 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2263 = load i32, ptr %ctx.field.2262, align 4
  %steps.next.2264 = add i32 %steps.current.2263, 1
  store i32 %steps.next.2264, ptr %ctx.field.2262, align 4
  %steps.over.2265 = icmp ugt i32 %steps.next.2264, 10000
  br i1 %steps.over.2265, label %failure.2266, label %continue.2267
failure.2266:
  %ctx.field.2268 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 232, ptr %ctx.field.2268, align 4
  %status.diagnostic.2269 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2269, align 4
  ret void
continue.2267:
  %ctx.field.2270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2271 = load i32, ptr %ctx.field.2270, align 4
  %steps.next.2272 = add i32 %steps.current.2271, 1
  store i32 %steps.next.2272, ptr %ctx.field.2270, align 4
  %steps.over.2273 = icmp ugt i32 %steps.next.2272, 10000
  br i1 %steps.over.2273, label %failure.2274, label %continue.2275
failure.2274:
  %ctx.field.2276 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 233, ptr %ctx.field.2276, align 4
  %status.diagnostic.2277 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2277, align 4
  ret void
continue.2275:
  %depth.exceeded.2278 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2278, label %failure.2279, label %continue.2280
failure.2279:
  %ctx.field.2281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 234, ptr %ctx.field.2281, align 4
  %status.diagnostic.2282 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2282, align 4
  ret void
continue.2280:
  %workspace.slot.2283 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2253, ptr %workspace.slot.2283, align 8
  %workspace.slot.2284 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2285 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 213, ptr %outputs, i32 1, ptr %workspace.slot.2284)
  switch i32 %record.make.status.2285, label %runtime.invalid.result.2291 [ i32 0, label %runtime.success.2286 i32 1, label %runtime.invalid.request.2287 i32 2, label %runtime.invalid.reference.2288 i32 3, label %runtime.scratch.capacity.2289 i32 4, label %runtime.retained.capacity.2290 ]
runtime.invalid.request.2287:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2288:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2289:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2290:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2291:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2286:
  %record.make.handle.2292 = load i64, ptr %workspace.slot.2284, align 8
  %ctx.field.2293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2294 = load i32, ptr %ctx.field.2293, align 4
  %steps.next.2295 = add i32 %steps.current.2294, 1
  store i32 %steps.next.2295, ptr %ctx.field.2293, align 4
  %steps.over.2296 = icmp ugt i32 %steps.next.2295, 10000
  br i1 %steps.over.2296, label %failure.2297, label %continue.2298
failure.2297:
  %ctx.field.2299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 235, ptr %ctx.field.2299, align 4
  %status.diagnostic.2300 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2300, align 4
  ret void
continue.2298:
  %ctx.field.2301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2302 = load i32, ptr %ctx.field.2301, align 4
  %steps.next.2303 = add i32 %steps.current.2302, 1
  store i32 %steps.next.2303, ptr %ctx.field.2301, align 4
  %steps.over.2304 = icmp ugt i32 %steps.next.2303, 10000
  br i1 %steps.over.2304, label %failure.2305, label %continue.2306
failure.2305:
  %ctx.field.2307 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 236, ptr %ctx.field.2307, align 4
  %status.diagnostic.2308 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2308, align 4
  ret void
continue.2306:
  %ctx.field.2309 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2310 = load i32, ptr %ctx.field.2309, align 4
  %steps.next.2311 = add i32 %steps.current.2310, 1
  store i32 %steps.next.2311, ptr %ctx.field.2309, align 4
  %steps.over.2312 = icmp ugt i32 %steps.next.2311, 10000
  br i1 %steps.over.2312, label %failure.2313, label %continue.2314
failure.2313:
  %ctx.field.2315 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 237, ptr %ctx.field.2315, align 4
  %status.diagnostic.2316 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2316, align 4
  ret void
continue.2314:
  %depth.exceeded.2317 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2317, label %failure.2318, label %continue.2319
failure.2318:
  %ctx.field.2320 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 238, ptr %ctx.field.2320, align 4
  %status.diagnostic.2321 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2321, align 4
  ret void
continue.2319:
  %workspace.slot.2322 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2292, ptr %workspace.slot.2322, align 8
  %workspace.slot.2323 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2324 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 214, ptr %outputs, i32 1, ptr %workspace.slot.2323)
  switch i32 %record.make.status.2324, label %runtime.invalid.result.2330 [ i32 0, label %runtime.success.2325 i32 1, label %runtime.invalid.request.2326 i32 2, label %runtime.invalid.reference.2327 i32 3, label %runtime.scratch.capacity.2328 i32 4, label %runtime.retained.capacity.2329 ]
runtime.invalid.request.2326:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2327:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2328:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2329:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2330:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2325:
  %record.make.handle.2331 = load i64, ptr %workspace.slot.2323, align 8
  %ctx.field.2332 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2333 = load i32, ptr %ctx.field.2332, align 4
  %steps.next.2334 = add i32 %steps.current.2333, 1
  store i32 %steps.next.2334, ptr %ctx.field.2332, align 4
  %steps.over.2335 = icmp ugt i32 %steps.next.2334, 10000
  br i1 %steps.over.2335, label %failure.2336, label %continue.2337
failure.2336:
  %ctx.field.2338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 239, ptr %ctx.field.2338, align 4
  %status.diagnostic.2339 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2339, align 4
  ret void
continue.2337:
  %ctx.field.2340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2341 = load i32, ptr %ctx.field.2340, align 4
  %steps.next.2342 = add i32 %steps.current.2341, 1
  store i32 %steps.next.2342, ptr %ctx.field.2340, align 4
  %steps.over.2343 = icmp ugt i32 %steps.next.2342, 10000
  br i1 %steps.over.2343, label %failure.2344, label %continue.2345
failure.2344:
  %ctx.field.2346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 240, ptr %ctx.field.2346, align 4
  %status.diagnostic.2347 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2347, align 4
  ret void
continue.2345:
  %ctx.field.2348 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2349 = load i32, ptr %ctx.field.2348, align 4
  %steps.next.2350 = add i32 %steps.current.2349, 1
  store i32 %steps.next.2350, ptr %ctx.field.2348, align 4
  %steps.over.2351 = icmp ugt i32 %steps.next.2350, 10000
  br i1 %steps.over.2351, label %failure.2352, label %continue.2353
failure.2352:
  %ctx.field.2354 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 241, ptr %ctx.field.2354, align 4
  %status.diagnostic.2355 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2355, align 4
  ret void
continue.2353:
  %depth.exceeded.2356 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2356, label %failure.2357, label %continue.2358
failure.2357:
  %ctx.field.2359 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 242, ptr %ctx.field.2359, align 4
  %status.diagnostic.2360 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2360, align 4
  ret void
continue.2358:
  %workspace.slot.2361 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2331, ptr %workspace.slot.2361, align 8
  %workspace.slot.2362 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2363 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 216, ptr %outputs, i32 1, ptr %workspace.slot.2362)
  switch i32 %record.make.status.2363, label %runtime.invalid.result.2369 [ i32 0, label %runtime.success.2364 i32 1, label %runtime.invalid.request.2365 i32 2, label %runtime.invalid.reference.2366 i32 3, label %runtime.scratch.capacity.2367 i32 4, label %runtime.retained.capacity.2368 ]
runtime.invalid.request.2365:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2366:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2367:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2368:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2369:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2364:
  %record.make.handle.2370 = load i64, ptr %workspace.slot.2362, align 8
  %ctx.field.2371 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2372 = load i32, ptr %ctx.field.2371, align 4
  %steps.next.2373 = add i32 %steps.current.2372, 1
  store i32 %steps.next.2373, ptr %ctx.field.2371, align 4
  %steps.over.2374 = icmp ugt i32 %steps.next.2373, 10000
  br i1 %steps.over.2374, label %failure.2375, label %continue.2376
failure.2375:
  %ctx.field.2377 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 243, ptr %ctx.field.2377, align 4
  %status.diagnostic.2378 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2378, align 4
  ret void
continue.2376:
  %ctx.field.2379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2380 = load i32, ptr %ctx.field.2379, align 4
  %steps.next.2381 = add i32 %steps.current.2380, 1
  store i32 %steps.next.2381, ptr %ctx.field.2379, align 4
  %steps.over.2382 = icmp ugt i32 %steps.next.2381, 10000
  br i1 %steps.over.2382, label %failure.2383, label %continue.2384
failure.2383:
  %ctx.field.2385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 244, ptr %ctx.field.2385, align 4
  %status.diagnostic.2386 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2386, align 4
  ret void
continue.2384:
  %ctx.field.2387 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2388 = load i32, ptr %ctx.field.2387, align 4
  %steps.next.2389 = add i32 %steps.current.2388, 1
  store i32 %steps.next.2389, ptr %ctx.field.2387, align 4
  %steps.over.2390 = icmp ugt i32 %steps.next.2389, 10000
  br i1 %steps.over.2390, label %failure.2391, label %continue.2392
failure.2391:
  %ctx.field.2393 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 245, ptr %ctx.field.2393, align 4
  %status.diagnostic.2394 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2394, align 4
  ret void
continue.2392:
  %depth.exceeded.2395 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2395, label %failure.2396, label %continue.2397
failure.2396:
  %ctx.field.2398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 246, ptr %ctx.field.2398, align 4
  %status.diagnostic.2399 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2399, align 4
  ret void
continue.2397:
  %workspace.slot.2400 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2370, ptr %workspace.slot.2400, align 8
  %workspace.slot.2401 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2402 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 217, ptr %outputs, i32 1, ptr %workspace.slot.2401)
  switch i32 %record.make.status.2402, label %runtime.invalid.result.2408 [ i32 0, label %runtime.success.2403 i32 1, label %runtime.invalid.request.2404 i32 2, label %runtime.invalid.reference.2405 i32 3, label %runtime.scratch.capacity.2406 i32 4, label %runtime.retained.capacity.2407 ]
runtime.invalid.request.2404:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2405:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2406:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2407:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2408:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2403:
  %record.make.handle.2409 = load i64, ptr %workspace.slot.2401, align 8
  %ctx.field.2410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2411 = load i32, ptr %ctx.field.2410, align 4
  %steps.next.2412 = add i32 %steps.current.2411, 1
  store i32 %steps.next.2412, ptr %ctx.field.2410, align 4
  %steps.over.2413 = icmp ugt i32 %steps.next.2412, 10000
  br i1 %steps.over.2413, label %failure.2414, label %continue.2415
failure.2414:
  %ctx.field.2416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 247, ptr %ctx.field.2416, align 4
  %status.diagnostic.2417 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2417, align 4
  ret void
continue.2415:
  %ctx.field.2418 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2419 = load i32, ptr %ctx.field.2418, align 4
  %steps.next.2420 = add i32 %steps.current.2419, 1
  store i32 %steps.next.2420, ptr %ctx.field.2418, align 4
  %steps.over.2421 = icmp ugt i32 %steps.next.2420, 10000
  br i1 %steps.over.2421, label %failure.2422, label %continue.2423
failure.2422:
  %ctx.field.2424 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 248, ptr %ctx.field.2424, align 4
  %status.diagnostic.2425 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2425, align 4
  ret void
continue.2423:
  %ctx.field.2426 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2427 = load i32, ptr %ctx.field.2426, align 4
  %steps.next.2428 = add i32 %steps.current.2427, 1
  store i32 %steps.next.2428, ptr %ctx.field.2426, align 4
  %steps.over.2429 = icmp ugt i32 %steps.next.2428, 10000
  br i1 %steps.over.2429, label %failure.2430, label %continue.2431
failure.2430:
  %ctx.field.2432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 249, ptr %ctx.field.2432, align 4
  %status.diagnostic.2433 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2433, align 4
  ret void
continue.2431:
  %depth.exceeded.2434 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2434, label %failure.2435, label %continue.2436
failure.2435:
  %ctx.field.2437 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 250, ptr %ctx.field.2437, align 4
  %status.diagnostic.2438 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2438, align 4
  ret void
continue.2436:
  %workspace.slot.2439 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2409, ptr %workspace.slot.2439, align 8
  %workspace.slot.2440 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2441 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 218, ptr %outputs, i32 1, ptr %workspace.slot.2440)
  switch i32 %record.make.status.2441, label %runtime.invalid.result.2447 [ i32 0, label %runtime.success.2442 i32 1, label %runtime.invalid.request.2443 i32 2, label %runtime.invalid.reference.2444 i32 3, label %runtime.scratch.capacity.2445 i32 4, label %runtime.retained.capacity.2446 ]
runtime.invalid.request.2443:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2444:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2445:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2446:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2447:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2442:
  %record.make.handle.2448 = load i64, ptr %workspace.slot.2440, align 8
  %ctx.field.2449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2450 = load i32, ptr %ctx.field.2449, align 4
  %steps.next.2451 = add i32 %steps.current.2450, 1
  store i32 %steps.next.2451, ptr %ctx.field.2449, align 4
  %steps.over.2452 = icmp ugt i32 %steps.next.2451, 10000
  br i1 %steps.over.2452, label %failure.2453, label %continue.2454
failure.2453:
  %ctx.field.2455 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 251, ptr %ctx.field.2455, align 4
  %status.diagnostic.2456 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2456, align 4
  ret void
continue.2454:
  %ctx.field.2457 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2458 = load i32, ptr %ctx.field.2457, align 4
  %steps.next.2459 = add i32 %steps.current.2458, 1
  store i32 %steps.next.2459, ptr %ctx.field.2457, align 4
  %steps.over.2460 = icmp ugt i32 %steps.next.2459, 10000
  br i1 %steps.over.2460, label %failure.2461, label %continue.2462
failure.2461:
  %ctx.field.2463 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 252, ptr %ctx.field.2463, align 4
  %status.diagnostic.2464 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2464, align 4
  ret void
continue.2462:
  %ctx.field.2465 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2466 = load i32, ptr %ctx.field.2465, align 4
  %steps.next.2467 = add i32 %steps.current.2466, 1
  store i32 %steps.next.2467, ptr %ctx.field.2465, align 4
  %steps.over.2468 = icmp ugt i32 %steps.next.2467, 10000
  br i1 %steps.over.2468, label %failure.2469, label %continue.2470
failure.2469:
  %ctx.field.2471 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 253, ptr %ctx.field.2471, align 4
  %status.diagnostic.2472 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2472, align 4
  ret void
continue.2470:
  %depth.exceeded.2473 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2473, label %failure.2474, label %continue.2475
failure.2474:
  %ctx.field.2476 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 254, ptr %ctx.field.2476, align 4
  %status.diagnostic.2477 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2477, align 4
  ret void
continue.2475:
  %workspace.slot.2478 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2448, ptr %workspace.slot.2478, align 8
  %workspace.slot.2479 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2480 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 219, ptr %outputs, i32 1, ptr %workspace.slot.2479)
  switch i32 %record.make.status.2480, label %runtime.invalid.result.2486 [ i32 0, label %runtime.success.2481 i32 1, label %runtime.invalid.request.2482 i32 2, label %runtime.invalid.reference.2483 i32 3, label %runtime.scratch.capacity.2484 i32 4, label %runtime.retained.capacity.2485 ]
runtime.invalid.request.2482:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2483:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2484:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2485:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2486:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2481:
  %record.make.handle.2487 = load i64, ptr %workspace.slot.2479, align 8
  %ctx.field.2488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2489 = load i32, ptr %ctx.field.2488, align 4
  %steps.next.2490 = add i32 %steps.current.2489, 1
  store i32 %steps.next.2490, ptr %ctx.field.2488, align 4
  %steps.over.2491 = icmp ugt i32 %steps.next.2490, 10000
  br i1 %steps.over.2491, label %failure.2492, label %continue.2493
failure.2492:
  %ctx.field.2494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 255, ptr %ctx.field.2494, align 4
  %status.diagnostic.2495 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2495, align 4
  ret void
continue.2493:
  %ctx.field.2496 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2497 = load i32, ptr %ctx.field.2496, align 4
  %steps.next.2498 = add i32 %steps.current.2497, 1
  store i32 %steps.next.2498, ptr %ctx.field.2496, align 4
  %steps.over.2499 = icmp ugt i32 %steps.next.2498, 10000
  br i1 %steps.over.2499, label %failure.2500, label %continue.2501
failure.2500:
  %ctx.field.2502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 256, ptr %ctx.field.2502, align 4
  %status.diagnostic.2503 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2503, align 4
  ret void
continue.2501:
  %ctx.field.2504 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2505 = load i32, ptr %ctx.field.2504, align 4
  %steps.next.2506 = add i32 %steps.current.2505, 1
  store i32 %steps.next.2506, ptr %ctx.field.2504, align 4
  %steps.over.2507 = icmp ugt i32 %steps.next.2506, 10000
  br i1 %steps.over.2507, label %failure.2508, label %continue.2509
failure.2508:
  %ctx.field.2510 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 257, ptr %ctx.field.2510, align 4
  %status.diagnostic.2511 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2511, align 4
  ret void
continue.2509:
  %depth.exceeded.2512 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2512, label %failure.2513, label %continue.2514
failure.2513:
  %ctx.field.2515 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 258, ptr %ctx.field.2515, align 4
  %status.diagnostic.2516 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2516, align 4
  ret void
continue.2514:
  %workspace.slot.2517 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2487, ptr %workspace.slot.2517, align 8
  %workspace.slot.2518 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2519 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 220, ptr %outputs, i32 1, ptr %workspace.slot.2518)
  switch i32 %record.make.status.2519, label %runtime.invalid.result.2525 [ i32 0, label %runtime.success.2520 i32 1, label %runtime.invalid.request.2521 i32 2, label %runtime.invalid.reference.2522 i32 3, label %runtime.scratch.capacity.2523 i32 4, label %runtime.retained.capacity.2524 ]
runtime.invalid.request.2521:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2522:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2523:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2524:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2525:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2520:
  %record.make.handle.2526 = load i64, ptr %workspace.slot.2518, align 8
  %ctx.field.2527 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2528 = load i32, ptr %ctx.field.2527, align 4
  %steps.next.2529 = add i32 %steps.current.2528, 1
  store i32 %steps.next.2529, ptr %ctx.field.2527, align 4
  %steps.over.2530 = icmp ugt i32 %steps.next.2529, 10000
  br i1 %steps.over.2530, label %failure.2531, label %continue.2532
failure.2531:
  %ctx.field.2533 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 259, ptr %ctx.field.2533, align 4
  %status.diagnostic.2534 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2534, align 4
  ret void
continue.2532:
  %ctx.field.2535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2536 = load i32, ptr %ctx.field.2535, align 4
  %steps.next.2537 = add i32 %steps.current.2536, 1
  store i32 %steps.next.2537, ptr %ctx.field.2535, align 4
  %steps.over.2538 = icmp ugt i32 %steps.next.2537, 10000
  br i1 %steps.over.2538, label %failure.2539, label %continue.2540
failure.2539:
  %ctx.field.2541 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 260, ptr %ctx.field.2541, align 4
  %status.diagnostic.2542 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2542, align 4
  ret void
continue.2540:
  %ctx.field.2543 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2544 = load i32, ptr %ctx.field.2543, align 4
  %steps.next.2545 = add i32 %steps.current.2544, 1
  store i32 %steps.next.2545, ptr %ctx.field.2543, align 4
  %steps.over.2546 = icmp ugt i32 %steps.next.2545, 10000
  br i1 %steps.over.2546, label %failure.2547, label %continue.2548
failure.2547:
  %ctx.field.2549 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 261, ptr %ctx.field.2549, align 4
  %status.diagnostic.2550 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2550, align 4
  ret void
continue.2548:
  %depth.exceeded.2551 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2551, label %failure.2552, label %continue.2553
failure.2552:
  %ctx.field.2554 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 262, ptr %ctx.field.2554, align 4
  %status.diagnostic.2555 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2555, align 4
  ret void
continue.2553:
  %workspace.slot.2556 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2526, ptr %workspace.slot.2556, align 8
  %workspace.slot.2557 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2558 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 221, ptr %outputs, i32 1, ptr %workspace.slot.2557)
  switch i32 %record.make.status.2558, label %runtime.invalid.result.2564 [ i32 0, label %runtime.success.2559 i32 1, label %runtime.invalid.request.2560 i32 2, label %runtime.invalid.reference.2561 i32 3, label %runtime.scratch.capacity.2562 i32 4, label %runtime.retained.capacity.2563 ]
runtime.invalid.request.2560:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2561:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2562:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2563:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2564:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2559:
  %record.make.handle.2565 = load i64, ptr %workspace.slot.2557, align 8
  %ctx.field.2566 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2567 = load i32, ptr %ctx.field.2566, align 4
  %steps.next.2568 = add i32 %steps.current.2567, 1
  store i32 %steps.next.2568, ptr %ctx.field.2566, align 4
  %steps.over.2569 = icmp ugt i32 %steps.next.2568, 10000
  br i1 %steps.over.2569, label %failure.2570, label %continue.2571
failure.2570:
  %ctx.field.2572 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 263, ptr %ctx.field.2572, align 4
  %status.diagnostic.2573 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2573, align 4
  ret void
continue.2571:
  %ctx.field.2574 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2575 = load i32, ptr %ctx.field.2574, align 4
  %steps.next.2576 = add i32 %steps.current.2575, 1
  store i32 %steps.next.2576, ptr %ctx.field.2574, align 4
  %steps.over.2577 = icmp ugt i32 %steps.next.2576, 10000
  br i1 %steps.over.2577, label %failure.2578, label %continue.2579
failure.2578:
  %ctx.field.2580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 264, ptr %ctx.field.2580, align 4
  %status.diagnostic.2581 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2581, align 4
  ret void
continue.2579:
  %ctx.field.2582 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2583 = load i32, ptr %ctx.field.2582, align 4
  %steps.next.2584 = add i32 %steps.current.2583, 1
  store i32 %steps.next.2584, ptr %ctx.field.2582, align 4
  %steps.over.2585 = icmp ugt i32 %steps.next.2584, 10000
  br i1 %steps.over.2585, label %failure.2586, label %continue.2587
failure.2586:
  %ctx.field.2588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 265, ptr %ctx.field.2588, align 4
  %status.diagnostic.2589 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2589, align 4
  ret void
continue.2587:
  %depth.exceeded.2590 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2590, label %failure.2591, label %continue.2592
failure.2591:
  %ctx.field.2593 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 266, ptr %ctx.field.2593, align 4
  %status.diagnostic.2594 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2594, align 4
  ret void
continue.2592:
  %workspace.slot.2595 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2565, ptr %workspace.slot.2595, align 8
  %workspace.slot.2596 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2597 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 222, ptr %outputs, i32 1, ptr %workspace.slot.2596)
  switch i32 %record.make.status.2597, label %runtime.invalid.result.2603 [ i32 0, label %runtime.success.2598 i32 1, label %runtime.invalid.request.2599 i32 2, label %runtime.invalid.reference.2600 i32 3, label %runtime.scratch.capacity.2601 i32 4, label %runtime.retained.capacity.2602 ]
runtime.invalid.request.2599:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2600:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2601:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2602:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2603:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2598:
  %record.make.handle.2604 = load i64, ptr %workspace.slot.2596, align 8
  %ctx.field.2605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2606 = load i32, ptr %ctx.field.2605, align 4
  %steps.next.2607 = add i32 %steps.current.2606, 1
  store i32 %steps.next.2607, ptr %ctx.field.2605, align 4
  %steps.over.2608 = icmp ugt i32 %steps.next.2607, 10000
  br i1 %steps.over.2608, label %failure.2609, label %continue.2610
failure.2609:
  %ctx.field.2611 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 267, ptr %ctx.field.2611, align 4
  %status.diagnostic.2612 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2612, align 4
  ret void
continue.2610:
  %ctx.field.2613 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2614 = load i32, ptr %ctx.field.2613, align 4
  %steps.next.2615 = add i32 %steps.current.2614, 1
  store i32 %steps.next.2615, ptr %ctx.field.2613, align 4
  %steps.over.2616 = icmp ugt i32 %steps.next.2615, 10000
  br i1 %steps.over.2616, label %failure.2617, label %continue.2618
failure.2617:
  %ctx.field.2619 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 268, ptr %ctx.field.2619, align 4
  %status.diagnostic.2620 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2620, align 4
  ret void
continue.2618:
  %ctx.field.2621 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2622 = load i32, ptr %ctx.field.2621, align 4
  %steps.next.2623 = add i32 %steps.current.2622, 1
  store i32 %steps.next.2623, ptr %ctx.field.2621, align 4
  %steps.over.2624 = icmp ugt i32 %steps.next.2623, 10000
  br i1 %steps.over.2624, label %failure.2625, label %continue.2626
failure.2625:
  %ctx.field.2627 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 269, ptr %ctx.field.2627, align 4
  %status.diagnostic.2628 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2628, align 4
  ret void
continue.2626:
  %depth.exceeded.2629 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2629, label %failure.2630, label %continue.2631
failure.2630:
  %ctx.field.2632 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 270, ptr %ctx.field.2632, align 4
  %status.diagnostic.2633 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2633, align 4
  ret void
continue.2631:
  %workspace.slot.2634 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2604, ptr %workspace.slot.2634, align 8
  %workspace.slot.2635 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2636 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 223, ptr %outputs, i32 1, ptr %workspace.slot.2635)
  switch i32 %record.make.status.2636, label %runtime.invalid.result.2642 [ i32 0, label %runtime.success.2637 i32 1, label %runtime.invalid.request.2638 i32 2, label %runtime.invalid.reference.2639 i32 3, label %runtime.scratch.capacity.2640 i32 4, label %runtime.retained.capacity.2641 ]
runtime.invalid.request.2638:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2639:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2640:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2641:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2642:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2637:
  %record.make.handle.2643 = load i64, ptr %workspace.slot.2635, align 8
  %ctx.field.2644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2645 = load i32, ptr %ctx.field.2644, align 4
  %steps.next.2646 = add i32 %steps.current.2645, 1
  store i32 %steps.next.2646, ptr %ctx.field.2644, align 4
  %steps.over.2647 = icmp ugt i32 %steps.next.2646, 10000
  br i1 %steps.over.2647, label %failure.2648, label %continue.2649
failure.2648:
  %ctx.field.2650 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 271, ptr %ctx.field.2650, align 4
  %status.diagnostic.2651 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2651, align 4
  ret void
continue.2649:
  %ctx.field.2652 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2653 = load i32, ptr %ctx.field.2652, align 4
  %steps.next.2654 = add i32 %steps.current.2653, 1
  store i32 %steps.next.2654, ptr %ctx.field.2652, align 4
  %steps.over.2655 = icmp ugt i32 %steps.next.2654, 10000
  br i1 %steps.over.2655, label %failure.2656, label %continue.2657
failure.2656:
  %ctx.field.2658 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 272, ptr %ctx.field.2658, align 4
  %status.diagnostic.2659 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2659, align 4
  ret void
continue.2657:
  %ctx.field.2660 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2661 = load i32, ptr %ctx.field.2660, align 4
  %steps.next.2662 = add i32 %steps.current.2661, 1
  store i32 %steps.next.2662, ptr %ctx.field.2660, align 4
  %steps.over.2663 = icmp ugt i32 %steps.next.2662, 10000
  br i1 %steps.over.2663, label %failure.2664, label %continue.2665
failure.2664:
  %ctx.field.2666 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 273, ptr %ctx.field.2666, align 4
  %status.diagnostic.2667 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2667, align 4
  ret void
continue.2665:
  %depth.exceeded.2668 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2668, label %failure.2669, label %continue.2670
failure.2669:
  %ctx.field.2671 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 274, ptr %ctx.field.2671, align 4
  %status.diagnostic.2672 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2672, align 4
  ret void
continue.2670:
  %workspace.slot.2673 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2643, ptr %workspace.slot.2673, align 8
  %workspace.slot.2674 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2675 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 224, ptr %outputs, i32 1, ptr %workspace.slot.2674)
  switch i32 %record.make.status.2675, label %runtime.invalid.result.2681 [ i32 0, label %runtime.success.2676 i32 1, label %runtime.invalid.request.2677 i32 2, label %runtime.invalid.reference.2678 i32 3, label %runtime.scratch.capacity.2679 i32 4, label %runtime.retained.capacity.2680 ]
runtime.invalid.request.2677:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2678:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2679:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2680:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2681:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2676:
  %record.make.handle.2682 = load i64, ptr %workspace.slot.2674, align 8
  %ctx.field.2683 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2684 = load i32, ptr %ctx.field.2683, align 4
  %steps.next.2685 = add i32 %steps.current.2684, 1
  store i32 %steps.next.2685, ptr %ctx.field.2683, align 4
  %steps.over.2686 = icmp ugt i32 %steps.next.2685, 10000
  br i1 %steps.over.2686, label %failure.2687, label %continue.2688
failure.2687:
  %ctx.field.2689 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 275, ptr %ctx.field.2689, align 4
  %status.diagnostic.2690 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2690, align 4
  ret void
continue.2688:
  %ctx.field.2691 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2692 = load i32, ptr %ctx.field.2691, align 4
  %steps.next.2693 = add i32 %steps.current.2692, 1
  store i32 %steps.next.2693, ptr %ctx.field.2691, align 4
  %steps.over.2694 = icmp ugt i32 %steps.next.2693, 10000
  br i1 %steps.over.2694, label %failure.2695, label %continue.2696
failure.2695:
  %ctx.field.2697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 276, ptr %ctx.field.2697, align 4
  %status.diagnostic.2698 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2698, align 4
  ret void
continue.2696:
  %ctx.field.2699 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2700 = load i32, ptr %ctx.field.2699, align 4
  %steps.next.2701 = add i32 %steps.current.2700, 1
  store i32 %steps.next.2701, ptr %ctx.field.2699, align 4
  %steps.over.2702 = icmp ugt i32 %steps.next.2701, 10000
  br i1 %steps.over.2702, label %failure.2703, label %continue.2704
failure.2703:
  %ctx.field.2705 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 277, ptr %ctx.field.2705, align 4
  %status.diagnostic.2706 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2706, align 4
  ret void
continue.2704:
  %depth.exceeded.2707 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2707, label %failure.2708, label %continue.2709
failure.2708:
  %ctx.field.2710 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 278, ptr %ctx.field.2710, align 4
  %status.diagnostic.2711 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2711, align 4
  ret void
continue.2709:
  %workspace.slot.2712 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2682, ptr %workspace.slot.2712, align 8
  %workspace.slot.2713 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2714 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 225, ptr %outputs, i32 1, ptr %workspace.slot.2713)
  switch i32 %record.make.status.2714, label %runtime.invalid.result.2720 [ i32 0, label %runtime.success.2715 i32 1, label %runtime.invalid.request.2716 i32 2, label %runtime.invalid.reference.2717 i32 3, label %runtime.scratch.capacity.2718 i32 4, label %runtime.retained.capacity.2719 ]
runtime.invalid.request.2716:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2717:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2718:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2719:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2720:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2715:
  %record.make.handle.2721 = load i64, ptr %workspace.slot.2713, align 8
  %ctx.field.2722 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2723 = load i32, ptr %ctx.field.2722, align 4
  %steps.next.2724 = add i32 %steps.current.2723, 1
  store i32 %steps.next.2724, ptr %ctx.field.2722, align 4
  %steps.over.2725 = icmp ugt i32 %steps.next.2724, 10000
  br i1 %steps.over.2725, label %failure.2726, label %continue.2727
failure.2726:
  %ctx.field.2728 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 279, ptr %ctx.field.2728, align 4
  %status.diagnostic.2729 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2729, align 4
  ret void
continue.2727:
  %ctx.field.2730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2731 = load i32, ptr %ctx.field.2730, align 4
  %steps.next.2732 = add i32 %steps.current.2731, 1
  store i32 %steps.next.2732, ptr %ctx.field.2730, align 4
  %steps.over.2733 = icmp ugt i32 %steps.next.2732, 10000
  br i1 %steps.over.2733, label %failure.2734, label %continue.2735
failure.2734:
  %ctx.field.2736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 280, ptr %ctx.field.2736, align 4
  %status.diagnostic.2737 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2737, align 4
  ret void
continue.2735:
  %ctx.field.2738 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2739 = load i32, ptr %ctx.field.2738, align 4
  %steps.next.2740 = add i32 %steps.current.2739, 1
  store i32 %steps.next.2740, ptr %ctx.field.2738, align 4
  %steps.over.2741 = icmp ugt i32 %steps.next.2740, 10000
  br i1 %steps.over.2741, label %failure.2742, label %continue.2743
failure.2742:
  %ctx.field.2744 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 281, ptr %ctx.field.2744, align 4
  %status.diagnostic.2745 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2745, align 4
  ret void
continue.2743:
  %depth.exceeded.2746 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2746, label %failure.2747, label %continue.2748
failure.2747:
  %ctx.field.2749 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 282, ptr %ctx.field.2749, align 4
  %status.diagnostic.2750 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2750, align 4
  ret void
continue.2748:
  %workspace.slot.2751 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2721, ptr %workspace.slot.2751, align 8
  %workspace.slot.2752 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2753 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 227, ptr %outputs, i32 1, ptr %workspace.slot.2752)
  switch i32 %record.make.status.2753, label %runtime.invalid.result.2759 [ i32 0, label %runtime.success.2754 i32 1, label %runtime.invalid.request.2755 i32 2, label %runtime.invalid.reference.2756 i32 3, label %runtime.scratch.capacity.2757 i32 4, label %runtime.retained.capacity.2758 ]
runtime.invalid.request.2755:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2756:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2757:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2758:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2759:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2754:
  %record.make.handle.2760 = load i64, ptr %workspace.slot.2752, align 8
  %ctx.field.2761 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2762 = load i32, ptr %ctx.field.2761, align 4
  %steps.next.2763 = add i32 %steps.current.2762, 1
  store i32 %steps.next.2763, ptr %ctx.field.2761, align 4
  %steps.over.2764 = icmp ugt i32 %steps.next.2763, 10000
  br i1 %steps.over.2764, label %failure.2765, label %continue.2766
failure.2765:
  %ctx.field.2767 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 283, ptr %ctx.field.2767, align 4
  %status.diagnostic.2768 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2768, align 4
  ret void
continue.2766:
  %ctx.field.2769 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2770 = load i32, ptr %ctx.field.2769, align 4
  %steps.next.2771 = add i32 %steps.current.2770, 1
  store i32 %steps.next.2771, ptr %ctx.field.2769, align 4
  %steps.over.2772 = icmp ugt i32 %steps.next.2771, 10000
  br i1 %steps.over.2772, label %failure.2773, label %continue.2774
failure.2773:
  %ctx.field.2775 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 284, ptr %ctx.field.2775, align 4
  %status.diagnostic.2776 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2776, align 4
  ret void
continue.2774:
  %ctx.field.2777 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2778 = load i32, ptr %ctx.field.2777, align 4
  %steps.next.2779 = add i32 %steps.current.2778, 1
  store i32 %steps.next.2779, ptr %ctx.field.2777, align 4
  %steps.over.2780 = icmp ugt i32 %steps.next.2779, 10000
  br i1 %steps.over.2780, label %failure.2781, label %continue.2782
failure.2781:
  %ctx.field.2783 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 285, ptr %ctx.field.2783, align 4
  %status.diagnostic.2784 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2784, align 4
  ret void
continue.2782:
  %depth.exceeded.2785 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2785, label %failure.2786, label %continue.2787
failure.2786:
  %ctx.field.2788 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 286, ptr %ctx.field.2788, align 4
  %status.diagnostic.2789 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2789, align 4
  ret void
continue.2787:
  %workspace.slot.2790 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2760, ptr %workspace.slot.2790, align 8
  %workspace.slot.2791 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2792 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 228, ptr %outputs, i32 1, ptr %workspace.slot.2791)
  switch i32 %record.make.status.2792, label %runtime.invalid.result.2798 [ i32 0, label %runtime.success.2793 i32 1, label %runtime.invalid.request.2794 i32 2, label %runtime.invalid.reference.2795 i32 3, label %runtime.scratch.capacity.2796 i32 4, label %runtime.retained.capacity.2797 ]
runtime.invalid.request.2794:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2795:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2796:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2797:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2798:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2793:
  %record.make.handle.2799 = load i64, ptr %workspace.slot.2791, align 8
  %ctx.field.2800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2801 = load i32, ptr %ctx.field.2800, align 4
  %steps.next.2802 = add i32 %steps.current.2801, 1
  store i32 %steps.next.2802, ptr %ctx.field.2800, align 4
  %steps.over.2803 = icmp ugt i32 %steps.next.2802, 10000
  br i1 %steps.over.2803, label %failure.2804, label %continue.2805
failure.2804:
  %ctx.field.2806 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 287, ptr %ctx.field.2806, align 4
  %status.diagnostic.2807 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2807, align 4
  ret void
continue.2805:
  %ctx.field.2808 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2809 = load i32, ptr %ctx.field.2808, align 4
  %steps.next.2810 = add i32 %steps.current.2809, 1
  store i32 %steps.next.2810, ptr %ctx.field.2808, align 4
  %steps.over.2811 = icmp ugt i32 %steps.next.2810, 10000
  br i1 %steps.over.2811, label %failure.2812, label %continue.2813
failure.2812:
  %ctx.field.2814 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 288, ptr %ctx.field.2814, align 4
  %status.diagnostic.2815 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2815, align 4
  ret void
continue.2813:
  %ctx.field.2816 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2817 = load i32, ptr %ctx.field.2816, align 4
  %steps.next.2818 = add i32 %steps.current.2817, 1
  store i32 %steps.next.2818, ptr %ctx.field.2816, align 4
  %steps.over.2819 = icmp ugt i32 %steps.next.2818, 10000
  br i1 %steps.over.2819, label %failure.2820, label %continue.2821
failure.2820:
  %ctx.field.2822 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 289, ptr %ctx.field.2822, align 4
  %status.diagnostic.2823 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2823, align 4
  ret void
continue.2821:
  %depth.exceeded.2824 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2824, label %failure.2825, label %continue.2826
failure.2825:
  %ctx.field.2827 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 290, ptr %ctx.field.2827, align 4
  %status.diagnostic.2828 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2828, align 4
  ret void
continue.2826:
  %workspace.slot.2829 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2799, ptr %workspace.slot.2829, align 8
  %workspace.slot.2830 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2831 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 229, ptr %outputs, i32 1, ptr %workspace.slot.2830)
  switch i32 %record.make.status.2831, label %runtime.invalid.result.2837 [ i32 0, label %runtime.success.2832 i32 1, label %runtime.invalid.request.2833 i32 2, label %runtime.invalid.reference.2834 i32 3, label %runtime.scratch.capacity.2835 i32 4, label %runtime.retained.capacity.2836 ]
runtime.invalid.request.2833:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2834:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2835:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2836:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2837:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2832:
  %record.make.handle.2838 = load i64, ptr %workspace.slot.2830, align 8
  %ctx.field.2839 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2840 = load i32, ptr %ctx.field.2839, align 4
  %steps.next.2841 = add i32 %steps.current.2840, 1
  store i32 %steps.next.2841, ptr %ctx.field.2839, align 4
  %steps.over.2842 = icmp ugt i32 %steps.next.2841, 10000
  br i1 %steps.over.2842, label %failure.2843, label %continue.2844
failure.2843:
  %ctx.field.2845 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 291, ptr %ctx.field.2845, align 4
  %status.diagnostic.2846 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2846, align 4
  ret void
continue.2844:
  %ctx.field.2847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2848 = load i32, ptr %ctx.field.2847, align 4
  %steps.next.2849 = add i32 %steps.current.2848, 1
  store i32 %steps.next.2849, ptr %ctx.field.2847, align 4
  %steps.over.2850 = icmp ugt i32 %steps.next.2849, 10000
  br i1 %steps.over.2850, label %failure.2851, label %continue.2852
failure.2851:
  %ctx.field.2853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 292, ptr %ctx.field.2853, align 4
  %status.diagnostic.2854 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2854, align 4
  ret void
continue.2852:
  %ctx.field.2855 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2856 = load i32, ptr %ctx.field.2855, align 4
  %steps.next.2857 = add i32 %steps.current.2856, 1
  store i32 %steps.next.2857, ptr %ctx.field.2855, align 4
  %steps.over.2858 = icmp ugt i32 %steps.next.2857, 10000
  br i1 %steps.over.2858, label %failure.2859, label %continue.2860
failure.2859:
  %ctx.field.2861 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 293, ptr %ctx.field.2861, align 4
  %status.diagnostic.2862 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2862, align 4
  ret void
continue.2860:
  %depth.exceeded.2863 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2863, label %failure.2864, label %continue.2865
failure.2864:
  %ctx.field.2866 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 294, ptr %ctx.field.2866, align 4
  %status.diagnostic.2867 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2867, align 4
  ret void
continue.2865:
  %workspace.slot.2868 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2838, ptr %workspace.slot.2868, align 8
  %workspace.slot.2869 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2870 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 230, ptr %outputs, i32 1, ptr %workspace.slot.2869)
  switch i32 %record.make.status.2870, label %runtime.invalid.result.2876 [ i32 0, label %runtime.success.2871 i32 1, label %runtime.invalid.request.2872 i32 2, label %runtime.invalid.reference.2873 i32 3, label %runtime.scratch.capacity.2874 i32 4, label %runtime.retained.capacity.2875 ]
runtime.invalid.request.2872:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2873:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2874:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2875:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2876:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2871:
  %record.make.handle.2877 = load i64, ptr %workspace.slot.2869, align 8
  %ctx.field.2878 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2879 = load i32, ptr %ctx.field.2878, align 4
  %steps.next.2880 = add i32 %steps.current.2879, 1
  store i32 %steps.next.2880, ptr %ctx.field.2878, align 4
  %steps.over.2881 = icmp ugt i32 %steps.next.2880, 10000
  br i1 %steps.over.2881, label %failure.2882, label %continue.2883
failure.2882:
  %ctx.field.2884 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 295, ptr %ctx.field.2884, align 4
  %status.diagnostic.2885 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2885, align 4
  ret void
continue.2883:
  %ctx.field.2886 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2887 = load i32, ptr %ctx.field.2886, align 4
  %steps.next.2888 = add i32 %steps.current.2887, 1
  store i32 %steps.next.2888, ptr %ctx.field.2886, align 4
  %steps.over.2889 = icmp ugt i32 %steps.next.2888, 10000
  br i1 %steps.over.2889, label %failure.2890, label %continue.2891
failure.2890:
  %ctx.field.2892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 296, ptr %ctx.field.2892, align 4
  %status.diagnostic.2893 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2893, align 4
  ret void
continue.2891:
  %ctx.field.2894 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2895 = load i32, ptr %ctx.field.2894, align 4
  %steps.next.2896 = add i32 %steps.current.2895, 1
  store i32 %steps.next.2896, ptr %ctx.field.2894, align 4
  %steps.over.2897 = icmp ugt i32 %steps.next.2896, 10000
  br i1 %steps.over.2897, label %failure.2898, label %continue.2899
failure.2898:
  %ctx.field.2900 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 297, ptr %ctx.field.2900, align 4
  %status.diagnostic.2901 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2901, align 4
  ret void
continue.2899:
  %depth.exceeded.2902 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2902, label %failure.2903, label %continue.2904
failure.2903:
  %ctx.field.2905 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 298, ptr %ctx.field.2905, align 4
  %status.diagnostic.2906 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2906, align 4
  ret void
continue.2904:
  %workspace.slot.2907 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2877, ptr %workspace.slot.2907, align 8
  %workspace.slot.2908 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2909 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 231, ptr %outputs, i32 1, ptr %workspace.slot.2908)
  switch i32 %record.make.status.2909, label %runtime.invalid.result.2915 [ i32 0, label %runtime.success.2910 i32 1, label %runtime.invalid.request.2911 i32 2, label %runtime.invalid.reference.2912 i32 3, label %runtime.scratch.capacity.2913 i32 4, label %runtime.retained.capacity.2914 ]
runtime.invalid.request.2911:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2912:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2913:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2914:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2915:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2910:
  %record.make.handle.2916 = load i64, ptr %workspace.slot.2908, align 8
  %ctx.field.2917 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2918 = load i32, ptr %ctx.field.2917, align 4
  %steps.next.2919 = add i32 %steps.current.2918, 1
  store i32 %steps.next.2919, ptr %ctx.field.2917, align 4
  %steps.over.2920 = icmp ugt i32 %steps.next.2919, 10000
  br i1 %steps.over.2920, label %failure.2921, label %continue.2922
failure.2921:
  %ctx.field.2923 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 299, ptr %ctx.field.2923, align 4
  %status.diagnostic.2924 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2924, align 4
  ret void
continue.2922:
  %ctx.field.2925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2926 = load i32, ptr %ctx.field.2925, align 4
  %steps.next.2927 = add i32 %steps.current.2926, 1
  store i32 %steps.next.2927, ptr %ctx.field.2925, align 4
  %steps.over.2928 = icmp ugt i32 %steps.next.2927, 10000
  br i1 %steps.over.2928, label %failure.2929, label %continue.2930
failure.2929:
  %ctx.field.2931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 300, ptr %ctx.field.2931, align 4
  %status.diagnostic.2932 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2932, align 4
  ret void
continue.2930:
  %ctx.field.2933 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2934 = load i32, ptr %ctx.field.2933, align 4
  %steps.next.2935 = add i32 %steps.current.2934, 1
  store i32 %steps.next.2935, ptr %ctx.field.2933, align 4
  %steps.over.2936 = icmp ugt i32 %steps.next.2935, 10000
  br i1 %steps.over.2936, label %failure.2937, label %continue.2938
failure.2937:
  %ctx.field.2939 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 301, ptr %ctx.field.2939, align 4
  %status.diagnostic.2940 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2940, align 4
  ret void
continue.2938:
  %depth.exceeded.2941 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2941, label %failure.2942, label %continue.2943
failure.2942:
  %ctx.field.2944 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 302, ptr %ctx.field.2944, align 4
  %status.diagnostic.2945 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2945, align 4
  ret void
continue.2943:
  %workspace.slot.2946 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2916, ptr %workspace.slot.2946, align 8
  %workspace.slot.2947 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2948 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 232, ptr %outputs, i32 1, ptr %workspace.slot.2947)
  switch i32 %record.make.status.2948, label %runtime.invalid.result.2954 [ i32 0, label %runtime.success.2949 i32 1, label %runtime.invalid.request.2950 i32 2, label %runtime.invalid.reference.2951 i32 3, label %runtime.scratch.capacity.2952 i32 4, label %runtime.retained.capacity.2953 ]
runtime.invalid.request.2950:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2951:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2952:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2953:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2954:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2949:
  %record.make.handle.2955 = load i64, ptr %workspace.slot.2947, align 8
  %ctx.field.2956 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2957 = load i32, ptr %ctx.field.2956, align 4
  %steps.next.2958 = add i32 %steps.current.2957, 1
  store i32 %steps.next.2958, ptr %ctx.field.2956, align 4
  %steps.over.2959 = icmp ugt i32 %steps.next.2958, 10000
  br i1 %steps.over.2959, label %failure.2960, label %continue.2961
failure.2960:
  %ctx.field.2962 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 303, ptr %ctx.field.2962, align 4
  %status.diagnostic.2963 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2963, align 4
  ret void
continue.2961:
  %ctx.field.2964 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2965 = load i32, ptr %ctx.field.2964, align 4
  %steps.next.2966 = add i32 %steps.current.2965, 1
  store i32 %steps.next.2966, ptr %ctx.field.2964, align 4
  %steps.over.2967 = icmp ugt i32 %steps.next.2966, 10000
  br i1 %steps.over.2967, label %failure.2968, label %continue.2969
failure.2968:
  %ctx.field.2970 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 304, ptr %ctx.field.2970, align 4
  %status.diagnostic.2971 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2971, align 4
  ret void
continue.2969:
  %ctx.field.2972 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2973 = load i32, ptr %ctx.field.2972, align 4
  %steps.next.2974 = add i32 %steps.current.2973, 1
  store i32 %steps.next.2974, ptr %ctx.field.2972, align 4
  %steps.over.2975 = icmp ugt i32 %steps.next.2974, 10000
  br i1 %steps.over.2975, label %failure.2976, label %continue.2977
failure.2976:
  %ctx.field.2978 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 305, ptr %ctx.field.2978, align 4
  %status.diagnostic.2979 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2979, align 4
  ret void
continue.2977:
  %depth.exceeded.2980 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2980, label %failure.2981, label %continue.2982
failure.2981:
  %ctx.field.2983 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 306, ptr %ctx.field.2983, align 4
  %status.diagnostic.2984 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2984, align 4
  ret void
continue.2982:
  %workspace.slot.2985 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2955, ptr %workspace.slot.2985, align 8
  %workspace.slot.2986 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2987 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 233, ptr %outputs, i32 1, ptr %workspace.slot.2986)
  switch i32 %record.make.status.2987, label %runtime.invalid.result.2993 [ i32 0, label %runtime.success.2988 i32 1, label %runtime.invalid.request.2989 i32 2, label %runtime.invalid.reference.2990 i32 3, label %runtime.scratch.capacity.2991 i32 4, label %runtime.retained.capacity.2992 ]
runtime.invalid.request.2989:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2990:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2991:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2992:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2993:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2988:
  %record.make.handle.2994 = load i64, ptr %workspace.slot.2986, align 8
  %ctx.field.2995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2996 = load i32, ptr %ctx.field.2995, align 4
  %steps.next.2997 = add i32 %steps.current.2996, 1
  store i32 %steps.next.2997, ptr %ctx.field.2995, align 4
  %steps.over.2998 = icmp ugt i32 %steps.next.2997, 10000
  br i1 %steps.over.2998, label %failure.2999, label %continue.3000
failure.2999:
  %ctx.field.3001 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 307, ptr %ctx.field.3001, align 4
  %status.diagnostic.3002 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3002, align 4
  ret void
continue.3000:
  %ctx.field.3003 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3004 = load i32, ptr %ctx.field.3003, align 4
  %steps.next.3005 = add i32 %steps.current.3004, 1
  store i32 %steps.next.3005, ptr %ctx.field.3003, align 4
  %steps.over.3006 = icmp ugt i32 %steps.next.3005, 10000
  br i1 %steps.over.3006, label %failure.3007, label %continue.3008
failure.3007:
  %ctx.field.3009 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 308, ptr %ctx.field.3009, align 4
  %status.diagnostic.3010 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3010, align 4
  ret void
continue.3008:
  %ctx.field.3011 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3012 = load i32, ptr %ctx.field.3011, align 4
  %steps.next.3013 = add i32 %steps.current.3012, 1
  store i32 %steps.next.3013, ptr %ctx.field.3011, align 4
  %steps.over.3014 = icmp ugt i32 %steps.next.3013, 10000
  br i1 %steps.over.3014, label %failure.3015, label %continue.3016
failure.3015:
  %ctx.field.3017 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 309, ptr %ctx.field.3017, align 4
  %status.diagnostic.3018 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3018, align 4
  ret void
continue.3016:
  %depth.exceeded.3019 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3019, label %failure.3020, label %continue.3021
failure.3020:
  %ctx.field.3022 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 310, ptr %ctx.field.3022, align 4
  %status.diagnostic.3023 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3023, align 4
  ret void
continue.3021:
  %workspace.slot.3024 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2994, ptr %workspace.slot.3024, align 8
  %workspace.slot.3025 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3026 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 234, ptr %outputs, i32 1, ptr %workspace.slot.3025)
  switch i32 %record.make.status.3026, label %runtime.invalid.result.3032 [ i32 0, label %runtime.success.3027 i32 1, label %runtime.invalid.request.3028 i32 2, label %runtime.invalid.reference.3029 i32 3, label %runtime.scratch.capacity.3030 i32 4, label %runtime.retained.capacity.3031 ]
runtime.invalid.request.3028:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3029:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3030:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3031:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3032:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3027:
  %record.make.handle.3033 = load i64, ptr %workspace.slot.3025, align 8
  %ctx.field.3034 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3035 = load i32, ptr %ctx.field.3034, align 4
  %steps.next.3036 = add i32 %steps.current.3035, 1
  store i32 %steps.next.3036, ptr %ctx.field.3034, align 4
  %steps.over.3037 = icmp ugt i32 %steps.next.3036, 10000
  br i1 %steps.over.3037, label %failure.3038, label %continue.3039
failure.3038:
  %ctx.field.3040 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 311, ptr %ctx.field.3040, align 4
  %status.diagnostic.3041 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3041, align 4
  ret void
continue.3039:
  %ctx.field.3042 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3043 = load i32, ptr %ctx.field.3042, align 4
  %steps.next.3044 = add i32 %steps.current.3043, 1
  store i32 %steps.next.3044, ptr %ctx.field.3042, align 4
  %steps.over.3045 = icmp ugt i32 %steps.next.3044, 10000
  br i1 %steps.over.3045, label %failure.3046, label %continue.3047
failure.3046:
  %ctx.field.3048 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 312, ptr %ctx.field.3048, align 4
  %status.diagnostic.3049 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3049, align 4
  ret void
continue.3047:
  %ctx.field.3050 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3051 = load i32, ptr %ctx.field.3050, align 4
  %steps.next.3052 = add i32 %steps.current.3051, 1
  store i32 %steps.next.3052, ptr %ctx.field.3050, align 4
  %steps.over.3053 = icmp ugt i32 %steps.next.3052, 10000
  br i1 %steps.over.3053, label %failure.3054, label %continue.3055
failure.3054:
  %ctx.field.3056 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 313, ptr %ctx.field.3056, align 4
  %status.diagnostic.3057 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3057, align 4
  ret void
continue.3055:
  %depth.exceeded.3058 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3058, label %failure.3059, label %continue.3060
failure.3059:
  %ctx.field.3061 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 314, ptr %ctx.field.3061, align 4
  %status.diagnostic.3062 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3062, align 4
  ret void
continue.3060:
  %workspace.slot.3063 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3033, ptr %workspace.slot.3063, align 8
  %workspace.slot.3064 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3065 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 235, ptr %outputs, i32 1, ptr %workspace.slot.3064)
  switch i32 %record.make.status.3065, label %runtime.invalid.result.3071 [ i32 0, label %runtime.success.3066 i32 1, label %runtime.invalid.request.3067 i32 2, label %runtime.invalid.reference.3068 i32 3, label %runtime.scratch.capacity.3069 i32 4, label %runtime.retained.capacity.3070 ]
runtime.invalid.request.3067:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3068:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3069:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3070:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3071:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3066:
  %record.make.handle.3072 = load i64, ptr %workspace.slot.3064, align 8
  %ctx.field.3073 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3074 = load i32, ptr %ctx.field.3073, align 4
  %steps.next.3075 = add i32 %steps.current.3074, 1
  store i32 %steps.next.3075, ptr %ctx.field.3073, align 4
  %steps.over.3076 = icmp ugt i32 %steps.next.3075, 10000
  br i1 %steps.over.3076, label %failure.3077, label %continue.3078
failure.3077:
  %ctx.field.3079 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 315, ptr %ctx.field.3079, align 4
  %status.diagnostic.3080 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3080, align 4
  ret void
continue.3078:
  %ctx.field.3081 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3082 = load i32, ptr %ctx.field.3081, align 4
  %steps.next.3083 = add i32 %steps.current.3082, 1
  store i32 %steps.next.3083, ptr %ctx.field.3081, align 4
  %steps.over.3084 = icmp ugt i32 %steps.next.3083, 10000
  br i1 %steps.over.3084, label %failure.3085, label %continue.3086
failure.3085:
  %ctx.field.3087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 316, ptr %ctx.field.3087, align 4
  %status.diagnostic.3088 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3088, align 4
  ret void
continue.3086:
  %ctx.field.3089 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3090 = load i32, ptr %ctx.field.3089, align 4
  %steps.next.3091 = add i32 %steps.current.3090, 1
  store i32 %steps.next.3091, ptr %ctx.field.3089, align 4
  %steps.over.3092 = icmp ugt i32 %steps.next.3091, 10000
  br i1 %steps.over.3092, label %failure.3093, label %continue.3094
failure.3093:
  %ctx.field.3095 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 317, ptr %ctx.field.3095, align 4
  %status.diagnostic.3096 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3096, align 4
  ret void
continue.3094:
  %depth.exceeded.3097 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3097, label %failure.3098, label %continue.3099
failure.3098:
  %ctx.field.3100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 318, ptr %ctx.field.3100, align 4
  %status.diagnostic.3101 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3101, align 4
  ret void
continue.3099:
  %workspace.slot.3102 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3072, ptr %workspace.slot.3102, align 8
  %workspace.slot.3103 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3104 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 236, ptr %outputs, i32 1, ptr %workspace.slot.3103)
  switch i32 %record.make.status.3104, label %runtime.invalid.result.3110 [ i32 0, label %runtime.success.3105 i32 1, label %runtime.invalid.request.3106 i32 2, label %runtime.invalid.reference.3107 i32 3, label %runtime.scratch.capacity.3108 i32 4, label %runtime.retained.capacity.3109 ]
runtime.invalid.request.3106:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3107:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3108:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3109:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3110:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3105:
  %record.make.handle.3111 = load i64, ptr %workspace.slot.3103, align 8
  %ctx.field.3112 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3113 = load i32, ptr %ctx.field.3112, align 4
  %steps.next.3114 = add i32 %steps.current.3113, 1
  store i32 %steps.next.3114, ptr %ctx.field.3112, align 4
  %steps.over.3115 = icmp ugt i32 %steps.next.3114, 10000
  br i1 %steps.over.3115, label %failure.3116, label %continue.3117
failure.3116:
  %ctx.field.3118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 319, ptr %ctx.field.3118, align 4
  %status.diagnostic.3119 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3119, align 4
  ret void
continue.3117:
  %ctx.field.3120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3121 = load i32, ptr %ctx.field.3120, align 4
  %steps.next.3122 = add i32 %steps.current.3121, 1
  store i32 %steps.next.3122, ptr %ctx.field.3120, align 4
  %steps.over.3123 = icmp ugt i32 %steps.next.3122, 10000
  br i1 %steps.over.3123, label %failure.3124, label %continue.3125
failure.3124:
  %ctx.field.3126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 320, ptr %ctx.field.3126, align 4
  %status.diagnostic.3127 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3127, align 4
  ret void
continue.3125:
  %ctx.field.3128 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3129 = load i32, ptr %ctx.field.3128, align 4
  %steps.next.3130 = add i32 %steps.current.3129, 1
  store i32 %steps.next.3130, ptr %ctx.field.3128, align 4
  %steps.over.3131 = icmp ugt i32 %steps.next.3130, 10000
  br i1 %steps.over.3131, label %failure.3132, label %continue.3133
failure.3132:
  %ctx.field.3134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 321, ptr %ctx.field.3134, align 4
  %status.diagnostic.3135 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3135, align 4
  ret void
continue.3133:
  %depth.exceeded.3136 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3136, label %failure.3137, label %continue.3138
failure.3137:
  %ctx.field.3139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 322, ptr %ctx.field.3139, align 4
  %status.diagnostic.3140 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3140, align 4
  ret void
continue.3138:
  %workspace.slot.3141 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3111, ptr %workspace.slot.3141, align 8
  %workspace.slot.3142 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3143 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 238, ptr %outputs, i32 1, ptr %workspace.slot.3142)
  switch i32 %record.make.status.3143, label %runtime.invalid.result.3149 [ i32 0, label %runtime.success.3144 i32 1, label %runtime.invalid.request.3145 i32 2, label %runtime.invalid.reference.3146 i32 3, label %runtime.scratch.capacity.3147 i32 4, label %runtime.retained.capacity.3148 ]
runtime.invalid.request.3145:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3146:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3147:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3148:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3149:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3144:
  %record.make.handle.3150 = load i64, ptr %workspace.slot.3142, align 8
  %ctx.field.3151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3152 = load i32, ptr %ctx.field.3151, align 4
  %steps.next.3153 = add i32 %steps.current.3152, 1
  store i32 %steps.next.3153, ptr %ctx.field.3151, align 4
  %steps.over.3154 = icmp ugt i32 %steps.next.3153, 10000
  br i1 %steps.over.3154, label %failure.3155, label %continue.3156
failure.3155:
  %ctx.field.3157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 323, ptr %ctx.field.3157, align 4
  %status.diagnostic.3158 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3158, align 4
  ret void
continue.3156:
  %ctx.field.3159 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3160 = load i32, ptr %ctx.field.3159, align 4
  %steps.next.3161 = add i32 %steps.current.3160, 1
  store i32 %steps.next.3161, ptr %ctx.field.3159, align 4
  %steps.over.3162 = icmp ugt i32 %steps.next.3161, 10000
  br i1 %steps.over.3162, label %failure.3163, label %continue.3164
failure.3163:
  %ctx.field.3165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 324, ptr %ctx.field.3165, align 4
  %status.diagnostic.3166 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3166, align 4
  ret void
continue.3164:
  %ctx.field.3167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3168 = load i32, ptr %ctx.field.3167, align 4
  %steps.next.3169 = add i32 %steps.current.3168, 1
  store i32 %steps.next.3169, ptr %ctx.field.3167, align 4
  %steps.over.3170 = icmp ugt i32 %steps.next.3169, 10000
  br i1 %steps.over.3170, label %failure.3171, label %continue.3172
failure.3171:
  %ctx.field.3173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 325, ptr %ctx.field.3173, align 4
  %status.diagnostic.3174 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3174, align 4
  ret void
continue.3172:
  %depth.exceeded.3175 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3175, label %failure.3176, label %continue.3177
failure.3176:
  %ctx.field.3178 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 326, ptr %ctx.field.3178, align 4
  %status.diagnostic.3179 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3179, align 4
  ret void
continue.3177:
  %workspace.slot.3180 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3150, ptr %workspace.slot.3180, align 8
  %workspace.slot.3181 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3182 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 239, ptr %outputs, i32 1, ptr %workspace.slot.3181)
  switch i32 %record.make.status.3182, label %runtime.invalid.result.3188 [ i32 0, label %runtime.success.3183 i32 1, label %runtime.invalid.request.3184 i32 2, label %runtime.invalid.reference.3185 i32 3, label %runtime.scratch.capacity.3186 i32 4, label %runtime.retained.capacity.3187 ]
runtime.invalid.request.3184:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3185:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3186:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3187:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3188:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3183:
  %record.make.handle.3189 = load i64, ptr %workspace.slot.3181, align 8
  %ctx.field.3190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3191 = load i32, ptr %ctx.field.3190, align 4
  %steps.next.3192 = add i32 %steps.current.3191, 1
  store i32 %steps.next.3192, ptr %ctx.field.3190, align 4
  %steps.over.3193 = icmp ugt i32 %steps.next.3192, 10000
  br i1 %steps.over.3193, label %failure.3194, label %continue.3195
failure.3194:
  %ctx.field.3196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 327, ptr %ctx.field.3196, align 4
  %status.diagnostic.3197 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3197, align 4
  ret void
continue.3195:
  %ctx.field.3198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3199 = load i32, ptr %ctx.field.3198, align 4
  %steps.next.3200 = add i32 %steps.current.3199, 1
  store i32 %steps.next.3200, ptr %ctx.field.3198, align 4
  %steps.over.3201 = icmp ugt i32 %steps.next.3200, 10000
  br i1 %steps.over.3201, label %failure.3202, label %continue.3203
failure.3202:
  %ctx.field.3204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 328, ptr %ctx.field.3204, align 4
  %status.diagnostic.3205 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3205, align 4
  ret void
continue.3203:
  %ctx.field.3206 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3207 = load i32, ptr %ctx.field.3206, align 4
  %steps.next.3208 = add i32 %steps.current.3207, 1
  store i32 %steps.next.3208, ptr %ctx.field.3206, align 4
  %steps.over.3209 = icmp ugt i32 %steps.next.3208, 10000
  br i1 %steps.over.3209, label %failure.3210, label %continue.3211
failure.3210:
  %ctx.field.3212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 329, ptr %ctx.field.3212, align 4
  %status.diagnostic.3213 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3213, align 4
  ret void
continue.3211:
  %depth.exceeded.3214 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3214, label %failure.3215, label %continue.3216
failure.3215:
  %ctx.field.3217 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 330, ptr %ctx.field.3217, align 4
  %status.diagnostic.3218 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3218, align 4
  ret void
continue.3216:
  %workspace.slot.3219 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3189, ptr %workspace.slot.3219, align 8
  %workspace.slot.3220 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3221 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 240, ptr %outputs, i32 1, ptr %workspace.slot.3220)
  switch i32 %record.make.status.3221, label %runtime.invalid.result.3227 [ i32 0, label %runtime.success.3222 i32 1, label %runtime.invalid.request.3223 i32 2, label %runtime.invalid.reference.3224 i32 3, label %runtime.scratch.capacity.3225 i32 4, label %runtime.retained.capacity.3226 ]
runtime.invalid.request.3223:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3224:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3225:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3226:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3227:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3222:
  %record.make.handle.3228 = load i64, ptr %workspace.slot.3220, align 8
  %ctx.field.3229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3230 = load i32, ptr %ctx.field.3229, align 4
  %steps.next.3231 = add i32 %steps.current.3230, 1
  store i32 %steps.next.3231, ptr %ctx.field.3229, align 4
  %steps.over.3232 = icmp ugt i32 %steps.next.3231, 10000
  br i1 %steps.over.3232, label %failure.3233, label %continue.3234
failure.3233:
  %ctx.field.3235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 331, ptr %ctx.field.3235, align 4
  %status.diagnostic.3236 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3236, align 4
  ret void
continue.3234:
  %ctx.field.3237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3238 = load i32, ptr %ctx.field.3237, align 4
  %steps.next.3239 = add i32 %steps.current.3238, 1
  store i32 %steps.next.3239, ptr %ctx.field.3237, align 4
  %steps.over.3240 = icmp ugt i32 %steps.next.3239, 10000
  br i1 %steps.over.3240, label %failure.3241, label %continue.3242
failure.3241:
  %ctx.field.3243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 332, ptr %ctx.field.3243, align 4
  %status.diagnostic.3244 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3244, align 4
  ret void
continue.3242:
  %ctx.field.3245 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3246 = load i32, ptr %ctx.field.3245, align 4
  %steps.next.3247 = add i32 %steps.current.3246, 1
  store i32 %steps.next.3247, ptr %ctx.field.3245, align 4
  %steps.over.3248 = icmp ugt i32 %steps.next.3247, 10000
  br i1 %steps.over.3248, label %failure.3249, label %continue.3250
failure.3249:
  %ctx.field.3251 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 333, ptr %ctx.field.3251, align 4
  %status.diagnostic.3252 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3252, align 4
  ret void
continue.3250:
  %depth.exceeded.3253 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3253, label %failure.3254, label %continue.3255
failure.3254:
  %ctx.field.3256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 334, ptr %ctx.field.3256, align 4
  %status.diagnostic.3257 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3257, align 4
  ret void
continue.3255:
  %workspace.slot.3258 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3228, ptr %workspace.slot.3258, align 8
  %workspace.slot.3259 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3260 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 241, ptr %outputs, i32 1, ptr %workspace.slot.3259)
  switch i32 %record.make.status.3260, label %runtime.invalid.result.3266 [ i32 0, label %runtime.success.3261 i32 1, label %runtime.invalid.request.3262 i32 2, label %runtime.invalid.reference.3263 i32 3, label %runtime.scratch.capacity.3264 i32 4, label %runtime.retained.capacity.3265 ]
runtime.invalid.request.3262:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3263:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3264:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3265:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3266:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3261:
  %record.make.handle.3267 = load i64, ptr %workspace.slot.3259, align 8
  %ctx.field.3268 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3269 = load i32, ptr %ctx.field.3268, align 4
  %steps.next.3270 = add i32 %steps.current.3269, 1
  store i32 %steps.next.3270, ptr %ctx.field.3268, align 4
  %steps.over.3271 = icmp ugt i32 %steps.next.3270, 10000
  br i1 %steps.over.3271, label %failure.3272, label %continue.3273
failure.3272:
  %ctx.field.3274 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 335, ptr %ctx.field.3274, align 4
  %status.diagnostic.3275 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3275, align 4
  ret void
continue.3273:
  %ctx.field.3276 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3277 = load i32, ptr %ctx.field.3276, align 4
  %steps.next.3278 = add i32 %steps.current.3277, 1
  store i32 %steps.next.3278, ptr %ctx.field.3276, align 4
  %steps.over.3279 = icmp ugt i32 %steps.next.3278, 10000
  br i1 %steps.over.3279, label %failure.3280, label %continue.3281
failure.3280:
  %ctx.field.3282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 336, ptr %ctx.field.3282, align 4
  %status.diagnostic.3283 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3283, align 4
  ret void
continue.3281:
  %ctx.field.3284 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3285 = load i32, ptr %ctx.field.3284, align 4
  %steps.next.3286 = add i32 %steps.current.3285, 1
  store i32 %steps.next.3286, ptr %ctx.field.3284, align 4
  %steps.over.3287 = icmp ugt i32 %steps.next.3286, 10000
  br i1 %steps.over.3287, label %failure.3288, label %continue.3289
failure.3288:
  %ctx.field.3290 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 337, ptr %ctx.field.3290, align 4
  %status.diagnostic.3291 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3291, align 4
  ret void
continue.3289:
  %depth.exceeded.3292 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3292, label %failure.3293, label %continue.3294
failure.3293:
  %ctx.field.3295 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 338, ptr %ctx.field.3295, align 4
  %status.diagnostic.3296 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3296, align 4
  ret void
continue.3294:
  %workspace.slot.3297 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3267, ptr %workspace.slot.3297, align 8
  %workspace.slot.3298 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3299 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 242, ptr %outputs, i32 1, ptr %workspace.slot.3298)
  switch i32 %record.make.status.3299, label %runtime.invalid.result.3305 [ i32 0, label %runtime.success.3300 i32 1, label %runtime.invalid.request.3301 i32 2, label %runtime.invalid.reference.3302 i32 3, label %runtime.scratch.capacity.3303 i32 4, label %runtime.retained.capacity.3304 ]
runtime.invalid.request.3301:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3302:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3303:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3304:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3305:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3300:
  %record.make.handle.3306 = load i64, ptr %workspace.slot.3298, align 8
  %ctx.field.3307 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3308 = load i32, ptr %ctx.field.3307, align 4
  %steps.next.3309 = add i32 %steps.current.3308, 1
  store i32 %steps.next.3309, ptr %ctx.field.3307, align 4
  %steps.over.3310 = icmp ugt i32 %steps.next.3309, 10000
  br i1 %steps.over.3310, label %failure.3311, label %continue.3312
failure.3311:
  %ctx.field.3313 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 339, ptr %ctx.field.3313, align 4
  %status.diagnostic.3314 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3314, align 4
  ret void
continue.3312:
  %ctx.field.3315 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3316 = load i32, ptr %ctx.field.3315, align 4
  %steps.next.3317 = add i32 %steps.current.3316, 1
  store i32 %steps.next.3317, ptr %ctx.field.3315, align 4
  %steps.over.3318 = icmp ugt i32 %steps.next.3317, 10000
  br i1 %steps.over.3318, label %failure.3319, label %continue.3320
failure.3319:
  %ctx.field.3321 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 340, ptr %ctx.field.3321, align 4
  %status.diagnostic.3322 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3322, align 4
  ret void
continue.3320:
  %ctx.field.3323 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3324 = load i32, ptr %ctx.field.3323, align 4
  %steps.next.3325 = add i32 %steps.current.3324, 1
  store i32 %steps.next.3325, ptr %ctx.field.3323, align 4
  %steps.over.3326 = icmp ugt i32 %steps.next.3325, 10000
  br i1 %steps.over.3326, label %failure.3327, label %continue.3328
failure.3327:
  %ctx.field.3329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 341, ptr %ctx.field.3329, align 4
  %status.diagnostic.3330 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3330, align 4
  ret void
continue.3328:
  %depth.exceeded.3331 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3331, label %failure.3332, label %continue.3333
failure.3332:
  %ctx.field.3334 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 342, ptr %ctx.field.3334, align 4
  %status.diagnostic.3335 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3335, align 4
  ret void
continue.3333:
  %workspace.slot.3336 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3306, ptr %workspace.slot.3336, align 8
  %workspace.slot.3337 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3338 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 243, ptr %outputs, i32 1, ptr %workspace.slot.3337)
  switch i32 %record.make.status.3338, label %runtime.invalid.result.3344 [ i32 0, label %runtime.success.3339 i32 1, label %runtime.invalid.request.3340 i32 2, label %runtime.invalid.reference.3341 i32 3, label %runtime.scratch.capacity.3342 i32 4, label %runtime.retained.capacity.3343 ]
runtime.invalid.request.3340:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3341:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3342:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3343:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3344:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3339:
  %record.make.handle.3345 = load i64, ptr %workspace.slot.3337, align 8
  %ctx.field.3346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3347 = load i32, ptr %ctx.field.3346, align 4
  %steps.next.3348 = add i32 %steps.current.3347, 1
  store i32 %steps.next.3348, ptr %ctx.field.3346, align 4
  %steps.over.3349 = icmp ugt i32 %steps.next.3348, 10000
  br i1 %steps.over.3349, label %failure.3350, label %continue.3351
failure.3350:
  %ctx.field.3352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 343, ptr %ctx.field.3352, align 4
  %status.diagnostic.3353 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3353, align 4
  ret void
continue.3351:
  %ctx.field.3354 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3355 = load i32, ptr %ctx.field.3354, align 4
  %steps.next.3356 = add i32 %steps.current.3355, 1
  store i32 %steps.next.3356, ptr %ctx.field.3354, align 4
  %steps.over.3357 = icmp ugt i32 %steps.next.3356, 10000
  br i1 %steps.over.3357, label %failure.3358, label %continue.3359
failure.3358:
  %ctx.field.3360 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 344, ptr %ctx.field.3360, align 4
  %status.diagnostic.3361 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3361, align 4
  ret void
continue.3359:
  %ctx.field.3362 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3363 = load i32, ptr %ctx.field.3362, align 4
  %steps.next.3364 = add i32 %steps.current.3363, 1
  store i32 %steps.next.3364, ptr %ctx.field.3362, align 4
  %steps.over.3365 = icmp ugt i32 %steps.next.3364, 10000
  br i1 %steps.over.3365, label %failure.3366, label %continue.3367
failure.3366:
  %ctx.field.3368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 345, ptr %ctx.field.3368, align 4
  %status.diagnostic.3369 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3369, align 4
  ret void
continue.3367:
  %depth.exceeded.3370 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3370, label %failure.3371, label %continue.3372
failure.3371:
  %ctx.field.3373 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 346, ptr %ctx.field.3373, align 4
  %status.diagnostic.3374 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3374, align 4
  ret void
continue.3372:
  %workspace.slot.3375 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3345, ptr %workspace.slot.3375, align 8
  %workspace.slot.3376 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3377 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 244, ptr %outputs, i32 1, ptr %workspace.slot.3376)
  switch i32 %record.make.status.3377, label %runtime.invalid.result.3383 [ i32 0, label %runtime.success.3378 i32 1, label %runtime.invalid.request.3379 i32 2, label %runtime.invalid.reference.3380 i32 3, label %runtime.scratch.capacity.3381 i32 4, label %runtime.retained.capacity.3382 ]
runtime.invalid.request.3379:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3380:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3381:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3382:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3383:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3378:
  %record.make.handle.3384 = load i64, ptr %workspace.slot.3376, align 8
  %ctx.field.3385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3386 = load i32, ptr %ctx.field.3385, align 4
  %steps.next.3387 = add i32 %steps.current.3386, 1
  store i32 %steps.next.3387, ptr %ctx.field.3385, align 4
  %steps.over.3388 = icmp ugt i32 %steps.next.3387, 10000
  br i1 %steps.over.3388, label %failure.3389, label %continue.3390
failure.3389:
  %ctx.field.3391 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 347, ptr %ctx.field.3391, align 4
  %status.diagnostic.3392 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3392, align 4
  ret void
continue.3390:
  %ctx.field.3393 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3394 = load i32, ptr %ctx.field.3393, align 4
  %steps.next.3395 = add i32 %steps.current.3394, 1
  store i32 %steps.next.3395, ptr %ctx.field.3393, align 4
  %steps.over.3396 = icmp ugt i32 %steps.next.3395, 10000
  br i1 %steps.over.3396, label %failure.3397, label %continue.3398
failure.3397:
  %ctx.field.3399 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 348, ptr %ctx.field.3399, align 4
  %status.diagnostic.3400 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3400, align 4
  ret void
continue.3398:
  %ctx.field.3401 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3402 = load i32, ptr %ctx.field.3401, align 4
  %steps.next.3403 = add i32 %steps.current.3402, 1
  store i32 %steps.next.3403, ptr %ctx.field.3401, align 4
  %steps.over.3404 = icmp ugt i32 %steps.next.3403, 10000
  br i1 %steps.over.3404, label %failure.3405, label %continue.3406
failure.3405:
  %ctx.field.3407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 349, ptr %ctx.field.3407, align 4
  %status.diagnostic.3408 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3408, align 4
  ret void
continue.3406:
  %depth.exceeded.3409 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3409, label %failure.3410, label %continue.3411
failure.3410:
  %ctx.field.3412 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 350, ptr %ctx.field.3412, align 4
  %status.diagnostic.3413 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3413, align 4
  ret void
continue.3411:
  %workspace.slot.3414 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3384, ptr %workspace.slot.3414, align 8
  %workspace.slot.3415 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3416 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 245, ptr %outputs, i32 1, ptr %workspace.slot.3415)
  switch i32 %record.make.status.3416, label %runtime.invalid.result.3422 [ i32 0, label %runtime.success.3417 i32 1, label %runtime.invalid.request.3418 i32 2, label %runtime.invalid.reference.3419 i32 3, label %runtime.scratch.capacity.3420 i32 4, label %runtime.retained.capacity.3421 ]
runtime.invalid.request.3418:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3419:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3420:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3421:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3422:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3417:
  %record.make.handle.3423 = load i64, ptr %workspace.slot.3415, align 8
  %ctx.field.3424 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3425 = load i32, ptr %ctx.field.3424, align 4
  %steps.next.3426 = add i32 %steps.current.3425, 1
  store i32 %steps.next.3426, ptr %ctx.field.3424, align 4
  %steps.over.3427 = icmp ugt i32 %steps.next.3426, 10000
  br i1 %steps.over.3427, label %failure.3428, label %continue.3429
failure.3428:
  %ctx.field.3430 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 351, ptr %ctx.field.3430, align 4
  %status.diagnostic.3431 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3431, align 4
  ret void
continue.3429:
  %ctx.field.3432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3433 = load i32, ptr %ctx.field.3432, align 4
  %steps.next.3434 = add i32 %steps.current.3433, 1
  store i32 %steps.next.3434, ptr %ctx.field.3432, align 4
  %steps.over.3435 = icmp ugt i32 %steps.next.3434, 10000
  br i1 %steps.over.3435, label %failure.3436, label %continue.3437
failure.3436:
  %ctx.field.3438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 352, ptr %ctx.field.3438, align 4
  %status.diagnostic.3439 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3439, align 4
  ret void
continue.3437:
  %ctx.field.3440 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3441 = load i32, ptr %ctx.field.3440, align 4
  %steps.next.3442 = add i32 %steps.current.3441, 1
  store i32 %steps.next.3442, ptr %ctx.field.3440, align 4
  %steps.over.3443 = icmp ugt i32 %steps.next.3442, 10000
  br i1 %steps.over.3443, label %failure.3444, label %continue.3445
failure.3444:
  %ctx.field.3446 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 353, ptr %ctx.field.3446, align 4
  %status.diagnostic.3447 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3447, align 4
  ret void
continue.3445:
  %depth.exceeded.3448 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3448, label %failure.3449, label %continue.3450
failure.3449:
  %ctx.field.3451 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 354, ptr %ctx.field.3451, align 4
  %status.diagnostic.3452 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3452, align 4
  ret void
continue.3450:
  %workspace.slot.3453 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3423, ptr %workspace.slot.3453, align 8
  %workspace.slot.3454 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3455 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 246, ptr %outputs, i32 1, ptr %workspace.slot.3454)
  switch i32 %record.make.status.3455, label %runtime.invalid.result.3461 [ i32 0, label %runtime.success.3456 i32 1, label %runtime.invalid.request.3457 i32 2, label %runtime.invalid.reference.3458 i32 3, label %runtime.scratch.capacity.3459 i32 4, label %runtime.retained.capacity.3460 ]
runtime.invalid.request.3457:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3458:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3459:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3460:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3461:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3456:
  %record.make.handle.3462 = load i64, ptr %workspace.slot.3454, align 8
  %ctx.field.3463 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3464 = load i32, ptr %ctx.field.3463, align 4
  %steps.next.3465 = add i32 %steps.current.3464, 1
  store i32 %steps.next.3465, ptr %ctx.field.3463, align 4
  %steps.over.3466 = icmp ugt i32 %steps.next.3465, 10000
  br i1 %steps.over.3466, label %failure.3467, label %continue.3468
failure.3467:
  %ctx.field.3469 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 355, ptr %ctx.field.3469, align 4
  %status.diagnostic.3470 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3470, align 4
  ret void
continue.3468:
  %ctx.field.3471 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3472 = load i32, ptr %ctx.field.3471, align 4
  %steps.next.3473 = add i32 %steps.current.3472, 1
  store i32 %steps.next.3473, ptr %ctx.field.3471, align 4
  %steps.over.3474 = icmp ugt i32 %steps.next.3473, 10000
  br i1 %steps.over.3474, label %failure.3475, label %continue.3476
failure.3475:
  %ctx.field.3477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 356, ptr %ctx.field.3477, align 4
  %status.diagnostic.3478 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3478, align 4
  ret void
continue.3476:
  %ctx.field.3479 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3480 = load i32, ptr %ctx.field.3479, align 4
  %steps.next.3481 = add i32 %steps.current.3480, 1
  store i32 %steps.next.3481, ptr %ctx.field.3479, align 4
  %steps.over.3482 = icmp ugt i32 %steps.next.3481, 10000
  br i1 %steps.over.3482, label %failure.3483, label %continue.3484
failure.3483:
  %ctx.field.3485 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 357, ptr %ctx.field.3485, align 4
  %status.diagnostic.3486 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3486, align 4
  ret void
continue.3484:
  %depth.exceeded.3487 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3487, label %failure.3488, label %continue.3489
failure.3488:
  %ctx.field.3490 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 358, ptr %ctx.field.3490, align 4
  %status.diagnostic.3491 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3491, align 4
  ret void
continue.3489:
  %workspace.slot.3492 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3462, ptr %workspace.slot.3492, align 8
  %workspace.slot.3493 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3494 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 247, ptr %outputs, i32 1, ptr %workspace.slot.3493)
  switch i32 %record.make.status.3494, label %runtime.invalid.result.3500 [ i32 0, label %runtime.success.3495 i32 1, label %runtime.invalid.request.3496 i32 2, label %runtime.invalid.reference.3497 i32 3, label %runtime.scratch.capacity.3498 i32 4, label %runtime.retained.capacity.3499 ]
runtime.invalid.request.3496:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3497:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3498:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3499:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3500:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3495:
  %record.make.handle.3501 = load i64, ptr %workspace.slot.3493, align 8
  %ctx.field.3502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3503 = load i32, ptr %ctx.field.3502, align 4
  %steps.next.3504 = add i32 %steps.current.3503, 1
  store i32 %steps.next.3504, ptr %ctx.field.3502, align 4
  %steps.over.3505 = icmp ugt i32 %steps.next.3504, 10000
  br i1 %steps.over.3505, label %failure.3506, label %continue.3507
failure.3506:
  %ctx.field.3508 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 359, ptr %ctx.field.3508, align 4
  %status.diagnostic.3509 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3509, align 4
  ret void
continue.3507:
  %ctx.field.3510 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3511 = load i32, ptr %ctx.field.3510, align 4
  %steps.next.3512 = add i32 %steps.current.3511, 1
  store i32 %steps.next.3512, ptr %ctx.field.3510, align 4
  %steps.over.3513 = icmp ugt i32 %steps.next.3512, 10000
  br i1 %steps.over.3513, label %failure.3514, label %continue.3515
failure.3514:
  %ctx.field.3516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 360, ptr %ctx.field.3516, align 4
  %status.diagnostic.3517 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3517, align 4
  ret void
continue.3515:
  %ctx.field.3518 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3519 = load i32, ptr %ctx.field.3518, align 4
  %steps.next.3520 = add i32 %steps.current.3519, 1
  store i32 %steps.next.3520, ptr %ctx.field.3518, align 4
  %steps.over.3521 = icmp ugt i32 %steps.next.3520, 10000
  br i1 %steps.over.3521, label %failure.3522, label %continue.3523
failure.3522:
  %ctx.field.3524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 361, ptr %ctx.field.3524, align 4
  %status.diagnostic.3525 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3525, align 4
  ret void
continue.3523:
  %depth.exceeded.3526 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3526, label %failure.3527, label %continue.3528
failure.3527:
  %ctx.field.3529 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 362, ptr %ctx.field.3529, align 4
  %status.diagnostic.3530 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3530, align 4
  ret void
continue.3528:
  %workspace.slot.3531 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3501, ptr %workspace.slot.3531, align 8
  %workspace.slot.3532 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3533 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 249, ptr %outputs, i32 1, ptr %workspace.slot.3532)
  switch i32 %record.make.status.3533, label %runtime.invalid.result.3539 [ i32 0, label %runtime.success.3534 i32 1, label %runtime.invalid.request.3535 i32 2, label %runtime.invalid.reference.3536 i32 3, label %runtime.scratch.capacity.3537 i32 4, label %runtime.retained.capacity.3538 ]
runtime.invalid.request.3535:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3536:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3537:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3538:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3539:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3534:
  %record.make.handle.3540 = load i64, ptr %workspace.slot.3532, align 8
  %ctx.field.3541 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3542 = load i32, ptr %ctx.field.3541, align 4
  %steps.next.3543 = add i32 %steps.current.3542, 1
  store i32 %steps.next.3543, ptr %ctx.field.3541, align 4
  %steps.over.3544 = icmp ugt i32 %steps.next.3543, 10000
  br i1 %steps.over.3544, label %failure.3545, label %continue.3546
failure.3545:
  %ctx.field.3547 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 363, ptr %ctx.field.3547, align 4
  %status.diagnostic.3548 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3548, align 4
  ret void
continue.3546:
  %ctx.field.3549 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3550 = load i32, ptr %ctx.field.3549, align 4
  %steps.next.3551 = add i32 %steps.current.3550, 1
  store i32 %steps.next.3551, ptr %ctx.field.3549, align 4
  %steps.over.3552 = icmp ugt i32 %steps.next.3551, 10000
  br i1 %steps.over.3552, label %failure.3553, label %continue.3554
failure.3553:
  %ctx.field.3555 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 364, ptr %ctx.field.3555, align 4
  %status.diagnostic.3556 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3556, align 4
  ret void
continue.3554:
  %ctx.field.3557 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3558 = load i32, ptr %ctx.field.3557, align 4
  %steps.next.3559 = add i32 %steps.current.3558, 1
  store i32 %steps.next.3559, ptr %ctx.field.3557, align 4
  %steps.over.3560 = icmp ugt i32 %steps.next.3559, 10000
  br i1 %steps.over.3560, label %failure.3561, label %continue.3562
failure.3561:
  %ctx.field.3563 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 365, ptr %ctx.field.3563, align 4
  %status.diagnostic.3564 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3564, align 4
  ret void
continue.3562:
  %depth.exceeded.3565 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3565, label %failure.3566, label %continue.3567
failure.3566:
  %ctx.field.3568 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 366, ptr %ctx.field.3568, align 4
  %status.diagnostic.3569 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3569, align 4
  ret void
continue.3567:
  %workspace.slot.3570 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3540, ptr %workspace.slot.3570, align 8
  %workspace.slot.3571 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3572 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 250, ptr %outputs, i32 1, ptr %workspace.slot.3571)
  switch i32 %record.make.status.3572, label %runtime.invalid.result.3578 [ i32 0, label %runtime.success.3573 i32 1, label %runtime.invalid.request.3574 i32 2, label %runtime.invalid.reference.3575 i32 3, label %runtime.scratch.capacity.3576 i32 4, label %runtime.retained.capacity.3577 ]
runtime.invalid.request.3574:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3575:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3576:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3577:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3578:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3573:
  %record.make.handle.3579 = load i64, ptr %workspace.slot.3571, align 8
  %ctx.field.3580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3581 = load i32, ptr %ctx.field.3580, align 4
  %steps.next.3582 = add i32 %steps.current.3581, 1
  store i32 %steps.next.3582, ptr %ctx.field.3580, align 4
  %steps.over.3583 = icmp ugt i32 %steps.next.3582, 10000
  br i1 %steps.over.3583, label %failure.3584, label %continue.3585
failure.3584:
  %ctx.field.3586 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 367, ptr %ctx.field.3586, align 4
  %status.diagnostic.3587 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3587, align 4
  ret void
continue.3585:
  %ctx.field.3588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3589 = load i32, ptr %ctx.field.3588, align 4
  %steps.next.3590 = add i32 %steps.current.3589, 1
  store i32 %steps.next.3590, ptr %ctx.field.3588, align 4
  %steps.over.3591 = icmp ugt i32 %steps.next.3590, 10000
  br i1 %steps.over.3591, label %failure.3592, label %continue.3593
failure.3592:
  %ctx.field.3594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 368, ptr %ctx.field.3594, align 4
  %status.diagnostic.3595 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3595, align 4
  ret void
continue.3593:
  %ctx.field.3596 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3597 = load i32, ptr %ctx.field.3596, align 4
  %steps.next.3598 = add i32 %steps.current.3597, 1
  store i32 %steps.next.3598, ptr %ctx.field.3596, align 4
  %steps.over.3599 = icmp ugt i32 %steps.next.3598, 10000
  br i1 %steps.over.3599, label %failure.3600, label %continue.3601
failure.3600:
  %ctx.field.3602 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 369, ptr %ctx.field.3602, align 4
  %status.diagnostic.3603 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3603, align 4
  ret void
continue.3601:
  %depth.exceeded.3604 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3604, label %failure.3605, label %continue.3606
failure.3605:
  %ctx.field.3607 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 370, ptr %ctx.field.3607, align 4
  %status.diagnostic.3608 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3608, align 4
  ret void
continue.3606:
  %workspace.slot.3609 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3579, ptr %workspace.slot.3609, align 8
  %workspace.slot.3610 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3611 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 251, ptr %outputs, i32 1, ptr %workspace.slot.3610)
  switch i32 %record.make.status.3611, label %runtime.invalid.result.3617 [ i32 0, label %runtime.success.3612 i32 1, label %runtime.invalid.request.3613 i32 2, label %runtime.invalid.reference.3614 i32 3, label %runtime.scratch.capacity.3615 i32 4, label %runtime.retained.capacity.3616 ]
runtime.invalid.request.3613:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3614:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3615:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3616:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3617:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3612:
  %record.make.handle.3618 = load i64, ptr %workspace.slot.3610, align 8
  %ctx.field.3619 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3620 = load i32, ptr %ctx.field.3619, align 4
  %steps.next.3621 = add i32 %steps.current.3620, 1
  store i32 %steps.next.3621, ptr %ctx.field.3619, align 4
  %steps.over.3622 = icmp ugt i32 %steps.next.3621, 10000
  br i1 %steps.over.3622, label %failure.3623, label %continue.3624
failure.3623:
  %ctx.field.3625 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 371, ptr %ctx.field.3625, align 4
  %status.diagnostic.3626 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3626, align 4
  ret void
continue.3624:
  %ctx.field.3627 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3628 = load i32, ptr %ctx.field.3627, align 4
  %steps.next.3629 = add i32 %steps.current.3628, 1
  store i32 %steps.next.3629, ptr %ctx.field.3627, align 4
  %steps.over.3630 = icmp ugt i32 %steps.next.3629, 10000
  br i1 %steps.over.3630, label %failure.3631, label %continue.3632
failure.3631:
  %ctx.field.3633 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 372, ptr %ctx.field.3633, align 4
  %status.diagnostic.3634 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3634, align 4
  ret void
continue.3632:
  %ctx.field.3635 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3636 = load i32, ptr %ctx.field.3635, align 4
  %steps.next.3637 = add i32 %steps.current.3636, 1
  store i32 %steps.next.3637, ptr %ctx.field.3635, align 4
  %steps.over.3638 = icmp ugt i32 %steps.next.3637, 10000
  br i1 %steps.over.3638, label %failure.3639, label %continue.3640
failure.3639:
  %ctx.field.3641 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 373, ptr %ctx.field.3641, align 4
  %status.diagnostic.3642 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3642, align 4
  ret void
continue.3640:
  %depth.exceeded.3643 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3643, label %failure.3644, label %continue.3645
failure.3644:
  %ctx.field.3646 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 374, ptr %ctx.field.3646, align 4
  %status.diagnostic.3647 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3647, align 4
  ret void
continue.3645:
  %workspace.slot.3648 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3618, ptr %workspace.slot.3648, align 8
  %workspace.slot.3649 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3650 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 252, ptr %outputs, i32 1, ptr %workspace.slot.3649)
  switch i32 %record.make.status.3650, label %runtime.invalid.result.3656 [ i32 0, label %runtime.success.3651 i32 1, label %runtime.invalid.request.3652 i32 2, label %runtime.invalid.reference.3653 i32 3, label %runtime.scratch.capacity.3654 i32 4, label %runtime.retained.capacity.3655 ]
runtime.invalid.request.3652:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3653:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3654:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3655:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3656:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3651:
  %record.make.handle.3657 = load i64, ptr %workspace.slot.3649, align 8
  %ctx.field.3658 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3659 = load i32, ptr %ctx.field.3658, align 4
  %steps.next.3660 = add i32 %steps.current.3659, 1
  store i32 %steps.next.3660, ptr %ctx.field.3658, align 4
  %steps.over.3661 = icmp ugt i32 %steps.next.3660, 10000
  br i1 %steps.over.3661, label %failure.3662, label %continue.3663
failure.3662:
  %ctx.field.3664 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 375, ptr %ctx.field.3664, align 4
  %status.diagnostic.3665 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3665, align 4
  ret void
continue.3663:
  %ctx.field.3666 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3667 = load i32, ptr %ctx.field.3666, align 4
  %steps.next.3668 = add i32 %steps.current.3667, 1
  store i32 %steps.next.3668, ptr %ctx.field.3666, align 4
  %steps.over.3669 = icmp ugt i32 %steps.next.3668, 10000
  br i1 %steps.over.3669, label %failure.3670, label %continue.3671
failure.3670:
  %ctx.field.3672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 376, ptr %ctx.field.3672, align 4
  %status.diagnostic.3673 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3673, align 4
  ret void
continue.3671:
  %ctx.field.3674 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3675 = load i32, ptr %ctx.field.3674, align 4
  %steps.next.3676 = add i32 %steps.current.3675, 1
  store i32 %steps.next.3676, ptr %ctx.field.3674, align 4
  %steps.over.3677 = icmp ugt i32 %steps.next.3676, 10000
  br i1 %steps.over.3677, label %failure.3678, label %continue.3679
failure.3678:
  %ctx.field.3680 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 377, ptr %ctx.field.3680, align 4
  %status.diagnostic.3681 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3681, align 4
  ret void
continue.3679:
  %depth.exceeded.3682 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3682, label %failure.3683, label %continue.3684
failure.3683:
  %ctx.field.3685 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 378, ptr %ctx.field.3685, align 4
  %status.diagnostic.3686 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3686, align 4
  ret void
continue.3684:
  %workspace.slot.3687 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3657, ptr %workspace.slot.3687, align 8
  %workspace.slot.3688 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3689 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 253, ptr %outputs, i32 1, ptr %workspace.slot.3688)
  switch i32 %record.make.status.3689, label %runtime.invalid.result.3695 [ i32 0, label %runtime.success.3690 i32 1, label %runtime.invalid.request.3691 i32 2, label %runtime.invalid.reference.3692 i32 3, label %runtime.scratch.capacity.3693 i32 4, label %runtime.retained.capacity.3694 ]
runtime.invalid.request.3691:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3692:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3693:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3694:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3695:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3690:
  %record.make.handle.3696 = load i64, ptr %workspace.slot.3688, align 8
  %ctx.field.3697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3698 = load i32, ptr %ctx.field.3697, align 4
  %steps.next.3699 = add i32 %steps.current.3698, 1
  store i32 %steps.next.3699, ptr %ctx.field.3697, align 4
  %steps.over.3700 = icmp ugt i32 %steps.next.3699, 10000
  br i1 %steps.over.3700, label %failure.3701, label %continue.3702
failure.3701:
  %ctx.field.3703 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 379, ptr %ctx.field.3703, align 4
  %status.diagnostic.3704 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3704, align 4
  ret void
continue.3702:
  %ctx.field.3705 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3706 = load i32, ptr %ctx.field.3705, align 4
  %steps.next.3707 = add i32 %steps.current.3706, 1
  store i32 %steps.next.3707, ptr %ctx.field.3705, align 4
  %steps.over.3708 = icmp ugt i32 %steps.next.3707, 10000
  br i1 %steps.over.3708, label %failure.3709, label %continue.3710
failure.3709:
  %ctx.field.3711 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 380, ptr %ctx.field.3711, align 4
  %status.diagnostic.3712 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3712, align 4
  ret void
continue.3710:
  %ctx.field.3713 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3714 = load i32, ptr %ctx.field.3713, align 4
  %steps.next.3715 = add i32 %steps.current.3714, 1
  store i32 %steps.next.3715, ptr %ctx.field.3713, align 4
  %steps.over.3716 = icmp ugt i32 %steps.next.3715, 10000
  br i1 %steps.over.3716, label %failure.3717, label %continue.3718
failure.3717:
  %ctx.field.3719 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 381, ptr %ctx.field.3719, align 4
  %status.diagnostic.3720 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3720, align 4
  ret void
continue.3718:
  %depth.exceeded.3721 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3721, label %failure.3722, label %continue.3723
failure.3722:
  %ctx.field.3724 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 382, ptr %ctx.field.3724, align 4
  %status.diagnostic.3725 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3725, align 4
  ret void
continue.3723:
  %workspace.slot.3726 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3696, ptr %workspace.slot.3726, align 8
  %workspace.slot.3727 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3728 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 254, ptr %outputs, i32 1, ptr %workspace.slot.3727)
  switch i32 %record.make.status.3728, label %runtime.invalid.result.3734 [ i32 0, label %runtime.success.3729 i32 1, label %runtime.invalid.request.3730 i32 2, label %runtime.invalid.reference.3731 i32 3, label %runtime.scratch.capacity.3732 i32 4, label %runtime.retained.capacity.3733 ]
runtime.invalid.request.3730:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3731:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3732:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3733:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3734:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3729:
  %record.make.handle.3735 = load i64, ptr %workspace.slot.3727, align 8
  %ctx.field.3736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3737 = load i32, ptr %ctx.field.3736, align 4
  %steps.next.3738 = add i32 %steps.current.3737, 1
  store i32 %steps.next.3738, ptr %ctx.field.3736, align 4
  %steps.over.3739 = icmp ugt i32 %steps.next.3738, 10000
  br i1 %steps.over.3739, label %failure.3740, label %continue.3741
failure.3740:
  %ctx.field.3742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 383, ptr %ctx.field.3742, align 4
  %status.diagnostic.3743 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3743, align 4
  ret void
continue.3741:
  %ctx.field.3744 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3745 = load i32, ptr %ctx.field.3744, align 4
  %steps.next.3746 = add i32 %steps.current.3745, 1
  store i32 %steps.next.3746, ptr %ctx.field.3744, align 4
  %steps.over.3747 = icmp ugt i32 %steps.next.3746, 10000
  br i1 %steps.over.3747, label %failure.3748, label %continue.3749
failure.3748:
  %ctx.field.3750 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 384, ptr %ctx.field.3750, align 4
  %status.diagnostic.3751 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3751, align 4
  ret void
continue.3749:
  %ctx.field.3752 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3753 = load i32, ptr %ctx.field.3752, align 4
  %steps.next.3754 = add i32 %steps.current.3753, 1
  store i32 %steps.next.3754, ptr %ctx.field.3752, align 4
  %steps.over.3755 = icmp ugt i32 %steps.next.3754, 10000
  br i1 %steps.over.3755, label %failure.3756, label %continue.3757
failure.3756:
  %ctx.field.3758 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 385, ptr %ctx.field.3758, align 4
  %status.diagnostic.3759 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3759, align 4
  ret void
continue.3757:
  %depth.exceeded.3760 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3760, label %failure.3761, label %continue.3762
failure.3761:
  %ctx.field.3763 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 386, ptr %ctx.field.3763, align 4
  %status.diagnostic.3764 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3764, align 4
  ret void
continue.3762:
  %workspace.slot.3765 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3735, ptr %workspace.slot.3765, align 8
  %workspace.slot.3766 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3767 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 255, ptr %outputs, i32 1, ptr %workspace.slot.3766)
  switch i32 %record.make.status.3767, label %runtime.invalid.result.3773 [ i32 0, label %runtime.success.3768 i32 1, label %runtime.invalid.request.3769 i32 2, label %runtime.invalid.reference.3770 i32 3, label %runtime.scratch.capacity.3771 i32 4, label %runtime.retained.capacity.3772 ]
runtime.invalid.request.3769:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3770:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3771:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3772:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3773:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3768:
  %record.make.handle.3774 = load i64, ptr %workspace.slot.3766, align 8
  %ctx.field.3775 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3776 = load i32, ptr %ctx.field.3775, align 4
  %steps.next.3777 = add i32 %steps.current.3776, 1
  store i32 %steps.next.3777, ptr %ctx.field.3775, align 4
  %steps.over.3778 = icmp ugt i32 %steps.next.3777, 10000
  br i1 %steps.over.3778, label %failure.3779, label %continue.3780
failure.3779:
  %ctx.field.3781 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 387, ptr %ctx.field.3781, align 4
  %status.diagnostic.3782 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3782, align 4
  ret void
continue.3780:
  %ctx.field.3783 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3784 = load i32, ptr %ctx.field.3783, align 4
  %steps.next.3785 = add i32 %steps.current.3784, 1
  store i32 %steps.next.3785, ptr %ctx.field.3783, align 4
  %steps.over.3786 = icmp ugt i32 %steps.next.3785, 10000
  br i1 %steps.over.3786, label %failure.3787, label %continue.3788
failure.3787:
  %ctx.field.3789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 388, ptr %ctx.field.3789, align 4
  %status.diagnostic.3790 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3790, align 4
  ret void
continue.3788:
  %ctx.field.3791 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3792 = load i32, ptr %ctx.field.3791, align 4
  %steps.next.3793 = add i32 %steps.current.3792, 1
  store i32 %steps.next.3793, ptr %ctx.field.3791, align 4
  %steps.over.3794 = icmp ugt i32 %steps.next.3793, 10000
  br i1 %steps.over.3794, label %failure.3795, label %continue.3796
failure.3795:
  %ctx.field.3797 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 389, ptr %ctx.field.3797, align 4
  %status.diagnostic.3798 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3798, align 4
  ret void
continue.3796:
  %depth.exceeded.3799 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3799, label %failure.3800, label %continue.3801
failure.3800:
  %ctx.field.3802 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 390, ptr %ctx.field.3802, align 4
  %status.diagnostic.3803 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3803, align 4
  ret void
continue.3801:
  %workspace.slot.3804 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3774, ptr %workspace.slot.3804, align 8
  %workspace.slot.3805 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3806 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 256, ptr %outputs, i32 1, ptr %workspace.slot.3805)
  switch i32 %record.make.status.3806, label %runtime.invalid.result.3812 [ i32 0, label %runtime.success.3807 i32 1, label %runtime.invalid.request.3808 i32 2, label %runtime.invalid.reference.3809 i32 3, label %runtime.scratch.capacity.3810 i32 4, label %runtime.retained.capacity.3811 ]
runtime.invalid.request.3808:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3809:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3810:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3811:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3812:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3807:
  %record.make.handle.3813 = load i64, ptr %workspace.slot.3805, align 8
  %ctx.field.3814 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3815 = load i32, ptr %ctx.field.3814, align 4
  %steps.next.3816 = add i32 %steps.current.3815, 1
  store i32 %steps.next.3816, ptr %ctx.field.3814, align 4
  %steps.over.3817 = icmp ugt i32 %steps.next.3816, 10000
  br i1 %steps.over.3817, label %failure.3818, label %continue.3819
failure.3818:
  %ctx.field.3820 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 391, ptr %ctx.field.3820, align 4
  %status.diagnostic.3821 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3821, align 4
  ret void
continue.3819:
  %ctx.field.3822 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3823 = load i32, ptr %ctx.field.3822, align 4
  %steps.next.3824 = add i32 %steps.current.3823, 1
  store i32 %steps.next.3824, ptr %ctx.field.3822, align 4
  %steps.over.3825 = icmp ugt i32 %steps.next.3824, 10000
  br i1 %steps.over.3825, label %failure.3826, label %continue.3827
failure.3826:
  %ctx.field.3828 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 392, ptr %ctx.field.3828, align 4
  %status.diagnostic.3829 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3829, align 4
  ret void
continue.3827:
  %ctx.field.3830 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3831 = load i32, ptr %ctx.field.3830, align 4
  %steps.next.3832 = add i32 %steps.current.3831, 1
  store i32 %steps.next.3832, ptr %ctx.field.3830, align 4
  %steps.over.3833 = icmp ugt i32 %steps.next.3832, 10000
  br i1 %steps.over.3833, label %failure.3834, label %continue.3835
failure.3834:
  %ctx.field.3836 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 393, ptr %ctx.field.3836, align 4
  %status.diagnostic.3837 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3837, align 4
  ret void
continue.3835:
  %depth.exceeded.3838 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3838, label %failure.3839, label %continue.3840
failure.3839:
  %ctx.field.3841 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 394, ptr %ctx.field.3841, align 4
  %status.diagnostic.3842 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3842, align 4
  ret void
continue.3840:
  %workspace.slot.3843 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3813, ptr %workspace.slot.3843, align 8
  %workspace.slot.3844 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3845 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 257, ptr %outputs, i32 1, ptr %workspace.slot.3844)
  switch i32 %record.make.status.3845, label %runtime.invalid.result.3851 [ i32 0, label %runtime.success.3846 i32 1, label %runtime.invalid.request.3847 i32 2, label %runtime.invalid.reference.3848 i32 3, label %runtime.scratch.capacity.3849 i32 4, label %runtime.retained.capacity.3850 ]
runtime.invalid.request.3847:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3848:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3849:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3850:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3851:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3846:
  %record.make.handle.3852 = load i64, ptr %workspace.slot.3844, align 8
  %ctx.field.3853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3854 = load i32, ptr %ctx.field.3853, align 4
  %steps.next.3855 = add i32 %steps.current.3854, 1
  store i32 %steps.next.3855, ptr %ctx.field.3853, align 4
  %steps.over.3856 = icmp ugt i32 %steps.next.3855, 10000
  br i1 %steps.over.3856, label %failure.3857, label %continue.3858
failure.3857:
  %ctx.field.3859 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 395, ptr %ctx.field.3859, align 4
  %status.diagnostic.3860 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3860, align 4
  ret void
continue.3858:
  %ctx.field.3861 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3862 = load i32, ptr %ctx.field.3861, align 4
  %steps.next.3863 = add i32 %steps.current.3862, 1
  store i32 %steps.next.3863, ptr %ctx.field.3861, align 4
  %steps.over.3864 = icmp ugt i32 %steps.next.3863, 10000
  br i1 %steps.over.3864, label %failure.3865, label %continue.3866
failure.3865:
  %ctx.field.3867 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 396, ptr %ctx.field.3867, align 4
  %status.diagnostic.3868 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3868, align 4
  ret void
continue.3866:
  %ctx.field.3869 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3870 = load i32, ptr %ctx.field.3869, align 4
  %steps.next.3871 = add i32 %steps.current.3870, 1
  store i32 %steps.next.3871, ptr %ctx.field.3869, align 4
  %steps.over.3872 = icmp ugt i32 %steps.next.3871, 10000
  br i1 %steps.over.3872, label %failure.3873, label %continue.3874
failure.3873:
  %ctx.field.3875 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 397, ptr %ctx.field.3875, align 4
  %status.diagnostic.3876 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3876, align 4
  ret void
continue.3874:
  %depth.exceeded.3877 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3877, label %failure.3878, label %continue.3879
failure.3878:
  %ctx.field.3880 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 398, ptr %ctx.field.3880, align 4
  %status.diagnostic.3881 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3881, align 4
  ret void
continue.3879:
  %workspace.slot.3882 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3852, ptr %workspace.slot.3882, align 8
  %workspace.slot.3883 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3884 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 258, ptr %outputs, i32 1, ptr %workspace.slot.3883)
  switch i32 %record.make.status.3884, label %runtime.invalid.result.3890 [ i32 0, label %runtime.success.3885 i32 1, label %runtime.invalid.request.3886 i32 2, label %runtime.invalid.reference.3887 i32 3, label %runtime.scratch.capacity.3888 i32 4, label %runtime.retained.capacity.3889 ]
runtime.invalid.request.3886:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3887:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3888:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3889:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3890:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3885:
  %record.make.handle.3891 = load i64, ptr %workspace.slot.3883, align 8
  %ctx.field.3892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3893 = load i32, ptr %ctx.field.3892, align 4
  %steps.next.3894 = add i32 %steps.current.3893, 1
  store i32 %steps.next.3894, ptr %ctx.field.3892, align 4
  %steps.over.3895 = icmp ugt i32 %steps.next.3894, 10000
  br i1 %steps.over.3895, label %failure.3896, label %continue.3897
failure.3896:
  %ctx.field.3898 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 399, ptr %ctx.field.3898, align 4
  %status.diagnostic.3899 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3899, align 4
  ret void
continue.3897:
  %ctx.field.3900 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3901 = load i32, ptr %ctx.field.3900, align 4
  %steps.next.3902 = add i32 %steps.current.3901, 1
  store i32 %steps.next.3902, ptr %ctx.field.3900, align 4
  %steps.over.3903 = icmp ugt i32 %steps.next.3902, 10000
  br i1 %steps.over.3903, label %failure.3904, label %continue.3905
failure.3904:
  %ctx.field.3906 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 400, ptr %ctx.field.3906, align 4
  %status.diagnostic.3907 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3907, align 4
  ret void
continue.3905:
  %ctx.field.3908 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3909 = load i32, ptr %ctx.field.3908, align 4
  %steps.next.3910 = add i32 %steps.current.3909, 1
  store i32 %steps.next.3910, ptr %ctx.field.3908, align 4
  %steps.over.3911 = icmp ugt i32 %steps.next.3910, 10000
  br i1 %steps.over.3911, label %failure.3912, label %continue.3913
failure.3912:
  %ctx.field.3914 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 401, ptr %ctx.field.3914, align 4
  %status.diagnostic.3915 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3915, align 4
  ret void
continue.3913:
  %depth.exceeded.3916 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3916, label %failure.3917, label %continue.3918
failure.3917:
  %ctx.field.3919 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 402, ptr %ctx.field.3919, align 4
  %status.diagnostic.3920 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3920, align 4
  ret void
continue.3918:
  %workspace.slot.3921 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3891, ptr %workspace.slot.3921, align 8
  %workspace.slot.3922 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3923 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 1, ptr %workspace.slot.3922)
  switch i32 %record.make.status.3923, label %runtime.invalid.result.3929 [ i32 0, label %runtime.success.3924 i32 1, label %runtime.invalid.request.3925 i32 2, label %runtime.invalid.reference.3926 i32 3, label %runtime.scratch.capacity.3927 i32 4, label %runtime.retained.capacity.3928 ]
runtime.invalid.request.3925:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3926:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3927:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3928:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3929:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3924:
  %record.make.handle.3930 = load i64, ptr %workspace.slot.3922, align 8
  %ctx.field.3931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3932 = load i32, ptr %ctx.field.3931, align 4
  %steps.next.3933 = add i32 %steps.current.3932, 1
  store i32 %steps.next.3933, ptr %ctx.field.3931, align 4
  %steps.over.3934 = icmp ugt i32 %steps.next.3933, 10000
  br i1 %steps.over.3934, label %failure.3935, label %continue.3936
failure.3935:
  %ctx.field.3937 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 403, ptr %ctx.field.3937, align 4
  %status.diagnostic.3938 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3938, align 4
  ret void
continue.3936:
  %ctx.field.3939 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3940 = load i32, ptr %ctx.field.3939, align 4
  %steps.next.3941 = add i32 %steps.current.3940, 1
  store i32 %steps.next.3941, ptr %ctx.field.3939, align 4
  %steps.over.3942 = icmp ugt i32 %steps.next.3941, 10000
  br i1 %steps.over.3942, label %failure.3943, label %continue.3944
failure.3943:
  %ctx.field.3945 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 404, ptr %ctx.field.3945, align 4
  %status.diagnostic.3946 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3946, align 4
  ret void
continue.3944:
  %ctx.field.3947 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3948 = load i32, ptr %ctx.field.3947, align 4
  %steps.next.3949 = add i32 %steps.current.3948, 1
  store i32 %steps.next.3949, ptr %ctx.field.3947, align 4
  %steps.over.3950 = icmp ugt i32 %steps.next.3949, 10000
  br i1 %steps.over.3950, label %failure.3951, label %continue.3952
failure.3951:
  %ctx.field.3953 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 405, ptr %ctx.field.3953, align 4
  %status.diagnostic.3954 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3954, align 4
  ret void
continue.3952:
  %depth.exceeded.3955 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3955, label %failure.3956, label %continue.3957
failure.3956:
  %ctx.field.3958 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 406, ptr %ctx.field.3958, align 4
  %status.diagnostic.3959 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3959, align 4
  ret void
continue.3957:
  %workspace.slot.3960 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3930, ptr %workspace.slot.3960, align 8
  %workspace.slot.3961 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3962 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 1, ptr %workspace.slot.3961)
  switch i32 %record.make.status.3962, label %runtime.invalid.result.3968 [ i32 0, label %runtime.success.3963 i32 1, label %runtime.invalid.request.3964 i32 2, label %runtime.invalid.reference.3965 i32 3, label %runtime.scratch.capacity.3966 i32 4, label %runtime.retained.capacity.3967 ]
runtime.invalid.request.3964:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3965:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3966:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3967:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3968:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3963:
  %record.make.handle.3969 = load i64, ptr %workspace.slot.3961, align 8
  %ctx.field.3970 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3971 = load i32, ptr %ctx.field.3970, align 4
  %steps.next.3972 = add i32 %steps.current.3971, 1
  store i32 %steps.next.3972, ptr %ctx.field.3970, align 4
  %steps.over.3973 = icmp ugt i32 %steps.next.3972, 10000
  br i1 %steps.over.3973, label %failure.3974, label %continue.3975
failure.3974:
  %ctx.field.3976 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 407, ptr %ctx.field.3976, align 4
  %status.diagnostic.3977 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3977, align 4
  ret void
continue.3975:
  %ctx.field.3978 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3979 = load i32, ptr %ctx.field.3978, align 4
  %steps.next.3980 = add i32 %steps.current.3979, 1
  store i32 %steps.next.3980, ptr %ctx.field.3978, align 4
  %steps.over.3981 = icmp ugt i32 %steps.next.3980, 10000
  br i1 %steps.over.3981, label %failure.3982, label %continue.3983
failure.3982:
  %ctx.field.3984 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 408, ptr %ctx.field.3984, align 4
  %status.diagnostic.3985 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3985, align 4
  ret void
continue.3983:
  %ctx.field.3986 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3987 = load i32, ptr %ctx.field.3986, align 4
  %steps.next.3988 = add i32 %steps.current.3987, 1
  store i32 %steps.next.3988, ptr %ctx.field.3986, align 4
  %steps.over.3989 = icmp ugt i32 %steps.next.3988, 10000
  br i1 %steps.over.3989, label %failure.3990, label %continue.3991
failure.3990:
  %ctx.field.3992 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 409, ptr %ctx.field.3992, align 4
  %status.diagnostic.3993 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3993, align 4
  ret void
continue.3991:
  %depth.exceeded.3994 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3994, label %failure.3995, label %continue.3996
failure.3995:
  %ctx.field.3997 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 410, ptr %ctx.field.3997, align 4
  %status.diagnostic.3998 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3998, align 4
  ret void
continue.3996:
  %workspace.slot.3999 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3969, ptr %workspace.slot.3999, align 8
  %workspace.slot.4000 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4001 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 8, ptr %outputs, i32 1, ptr %workspace.slot.4000)
  switch i32 %record.make.status.4001, label %runtime.invalid.result.4007 [ i32 0, label %runtime.success.4002 i32 1, label %runtime.invalid.request.4003 i32 2, label %runtime.invalid.reference.4004 i32 3, label %runtime.scratch.capacity.4005 i32 4, label %runtime.retained.capacity.4006 ]
runtime.invalid.request.4003:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4004:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4005:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4006:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4007:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4002:
  %record.make.handle.4008 = load i64, ptr %workspace.slot.4000, align 8
  %ctx.field.4009 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4010 = load i32, ptr %ctx.field.4009, align 4
  %steps.next.4011 = add i32 %steps.current.4010, 1
  store i32 %steps.next.4011, ptr %ctx.field.4009, align 4
  %steps.over.4012 = icmp ugt i32 %steps.next.4011, 10000
  br i1 %steps.over.4012, label %failure.4013, label %continue.4014
failure.4013:
  %ctx.field.4015 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 411, ptr %ctx.field.4015, align 4
  %status.diagnostic.4016 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4016, align 4
  ret void
continue.4014:
  %ctx.field.4017 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4018 = load i32, ptr %ctx.field.4017, align 4
  %steps.next.4019 = add i32 %steps.current.4018, 1
  store i32 %steps.next.4019, ptr %ctx.field.4017, align 4
  %steps.over.4020 = icmp ugt i32 %steps.next.4019, 10000
  br i1 %steps.over.4020, label %failure.4021, label %continue.4022
failure.4021:
  %ctx.field.4023 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 412, ptr %ctx.field.4023, align 4
  %status.diagnostic.4024 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4024, align 4
  ret void
continue.4022:
  %ctx.field.4025 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4026 = load i32, ptr %ctx.field.4025, align 4
  %steps.next.4027 = add i32 %steps.current.4026, 1
  store i32 %steps.next.4027, ptr %ctx.field.4025, align 4
  %steps.over.4028 = icmp ugt i32 %steps.next.4027, 10000
  br i1 %steps.over.4028, label %failure.4029, label %continue.4030
failure.4029:
  %ctx.field.4031 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 413, ptr %ctx.field.4031, align 4
  %status.diagnostic.4032 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4032, align 4
  ret void
continue.4030:
  %depth.exceeded.4033 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4033, label %failure.4034, label %continue.4035
failure.4034:
  %ctx.field.4036 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 414, ptr %ctx.field.4036, align 4
  %status.diagnostic.4037 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4037, align 4
  ret void
continue.4035:
  %workspace.slot.4038 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4008, ptr %workspace.slot.4038, align 8
  %workspace.slot.4039 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4040 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 9, ptr %outputs, i32 1, ptr %workspace.slot.4039)
  switch i32 %record.make.status.4040, label %runtime.invalid.result.4046 [ i32 0, label %runtime.success.4041 i32 1, label %runtime.invalid.request.4042 i32 2, label %runtime.invalid.reference.4043 i32 3, label %runtime.scratch.capacity.4044 i32 4, label %runtime.retained.capacity.4045 ]
runtime.invalid.request.4042:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4043:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4044:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4045:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4046:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4041:
  %record.make.handle.4047 = load i64, ptr %workspace.slot.4039, align 8
  %ctx.field.4048 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4049 = load i32, ptr %ctx.field.4048, align 4
  %steps.next.4050 = add i32 %steps.current.4049, 1
  store i32 %steps.next.4050, ptr %ctx.field.4048, align 4
  %steps.over.4051 = icmp ugt i32 %steps.next.4050, 10000
  br i1 %steps.over.4051, label %failure.4052, label %continue.4053
failure.4052:
  %ctx.field.4054 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 415, ptr %ctx.field.4054, align 4
  %status.diagnostic.4055 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4055, align 4
  ret void
continue.4053:
  %ctx.field.4056 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4057 = load i32, ptr %ctx.field.4056, align 4
  %steps.next.4058 = add i32 %steps.current.4057, 1
  store i32 %steps.next.4058, ptr %ctx.field.4056, align 4
  %steps.over.4059 = icmp ugt i32 %steps.next.4058, 10000
  br i1 %steps.over.4059, label %failure.4060, label %continue.4061
failure.4060:
  %ctx.field.4062 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 416, ptr %ctx.field.4062, align 4
  %status.diagnostic.4063 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4063, align 4
  ret void
continue.4061:
  %ctx.field.4064 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4065 = load i32, ptr %ctx.field.4064, align 4
  %steps.next.4066 = add i32 %steps.current.4065, 1
  store i32 %steps.next.4066, ptr %ctx.field.4064, align 4
  %steps.over.4067 = icmp ugt i32 %steps.next.4066, 10000
  br i1 %steps.over.4067, label %failure.4068, label %continue.4069
failure.4068:
  %ctx.field.4070 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 417, ptr %ctx.field.4070, align 4
  %status.diagnostic.4071 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4071, align 4
  ret void
continue.4069:
  %depth.exceeded.4072 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4072, label %failure.4073, label %continue.4074
failure.4073:
  %ctx.field.4075 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 418, ptr %ctx.field.4075, align 4
  %status.diagnostic.4076 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4076, align 4
  ret void
continue.4074:
  %workspace.slot.4077 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4047, ptr %workspace.slot.4077, align 8
  %workspace.slot.4078 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4079 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 10, ptr %outputs, i32 1, ptr %workspace.slot.4078)
  switch i32 %record.make.status.4079, label %runtime.invalid.result.4085 [ i32 0, label %runtime.success.4080 i32 1, label %runtime.invalid.request.4081 i32 2, label %runtime.invalid.reference.4082 i32 3, label %runtime.scratch.capacity.4083 i32 4, label %runtime.retained.capacity.4084 ]
runtime.invalid.request.4081:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4082:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4083:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4084:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4085:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4080:
  %record.make.handle.4086 = load i64, ptr %workspace.slot.4078, align 8
  %ctx.field.4087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4088 = load i32, ptr %ctx.field.4087, align 4
  %steps.next.4089 = add i32 %steps.current.4088, 1
  store i32 %steps.next.4089, ptr %ctx.field.4087, align 4
  %steps.over.4090 = icmp ugt i32 %steps.next.4089, 10000
  br i1 %steps.over.4090, label %failure.4091, label %continue.4092
failure.4091:
  %ctx.field.4093 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 419, ptr %ctx.field.4093, align 4
  %status.diagnostic.4094 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4094, align 4
  ret void
continue.4092:
  %ctx.field.4095 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4096 = load i32, ptr %ctx.field.4095, align 4
  %steps.next.4097 = add i32 %steps.current.4096, 1
  store i32 %steps.next.4097, ptr %ctx.field.4095, align 4
  %steps.over.4098 = icmp ugt i32 %steps.next.4097, 10000
  br i1 %steps.over.4098, label %failure.4099, label %continue.4100
failure.4099:
  %ctx.field.4101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 420, ptr %ctx.field.4101, align 4
  %status.diagnostic.4102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4102, align 4
  ret void
continue.4100:
  %ctx.field.4103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4104 = load i32, ptr %ctx.field.4103, align 4
  %steps.next.4105 = add i32 %steps.current.4104, 1
  store i32 %steps.next.4105, ptr %ctx.field.4103, align 4
  %steps.over.4106 = icmp ugt i32 %steps.next.4105, 10000
  br i1 %steps.over.4106, label %failure.4107, label %continue.4108
failure.4107:
  %ctx.field.4109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 421, ptr %ctx.field.4109, align 4
  %status.diagnostic.4110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4110, align 4
  ret void
continue.4108:
  %depth.exceeded.4111 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4111, label %failure.4112, label %continue.4113
failure.4112:
  %ctx.field.4114 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 422, ptr %ctx.field.4114, align 4
  %status.diagnostic.4115 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4115, align 4
  ret void
continue.4113:
  %workspace.slot.4116 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4086, ptr %workspace.slot.4116, align 8
  %workspace.slot.4117 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4118 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 11, ptr %outputs, i32 1, ptr %workspace.slot.4117)
  switch i32 %record.make.status.4118, label %runtime.invalid.result.4124 [ i32 0, label %runtime.success.4119 i32 1, label %runtime.invalid.request.4120 i32 2, label %runtime.invalid.reference.4121 i32 3, label %runtime.scratch.capacity.4122 i32 4, label %runtime.retained.capacity.4123 ]
runtime.invalid.request.4120:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4121:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4122:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4123:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4124:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4119:
  %record.make.handle.4125 = load i64, ptr %workspace.slot.4117, align 8
  %ctx.field.4126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4127 = load i32, ptr %ctx.field.4126, align 4
  %steps.next.4128 = add i32 %steps.current.4127, 1
  store i32 %steps.next.4128, ptr %ctx.field.4126, align 4
  %steps.over.4129 = icmp ugt i32 %steps.next.4128, 10000
  br i1 %steps.over.4129, label %failure.4130, label %continue.4131
failure.4130:
  %ctx.field.4132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 423, ptr %ctx.field.4132, align 4
  %status.diagnostic.4133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4133, align 4
  ret void
continue.4131:
  %ctx.field.4134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4135 = load i32, ptr %ctx.field.4134, align 4
  %steps.next.4136 = add i32 %steps.current.4135, 1
  store i32 %steps.next.4136, ptr %ctx.field.4134, align 4
  %steps.over.4137 = icmp ugt i32 %steps.next.4136, 10000
  br i1 %steps.over.4137, label %failure.4138, label %continue.4139
failure.4138:
  %ctx.field.4140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 424, ptr %ctx.field.4140, align 4
  %status.diagnostic.4141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4141, align 4
  ret void
continue.4139:
  %ctx.field.4142 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4143 = load i32, ptr %ctx.field.4142, align 4
  %steps.next.4144 = add i32 %steps.current.4143, 1
  store i32 %steps.next.4144, ptr %ctx.field.4142, align 4
  %steps.over.4145 = icmp ugt i32 %steps.next.4144, 10000
  br i1 %steps.over.4145, label %failure.4146, label %continue.4147
failure.4146:
  %ctx.field.4148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 425, ptr %ctx.field.4148, align 4
  %status.diagnostic.4149 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4149, align 4
  ret void
continue.4147:
  %depth.exceeded.4150 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4150, label %failure.4151, label %continue.4152
failure.4151:
  %ctx.field.4153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 426, ptr %ctx.field.4153, align 4
  %status.diagnostic.4154 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4154, align 4
  ret void
continue.4152:
  %workspace.slot.4155 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4125, ptr %workspace.slot.4155, align 8
  %workspace.slot.4156 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4157 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 12, ptr %outputs, i32 1, ptr %workspace.slot.4156)
  switch i32 %record.make.status.4157, label %runtime.invalid.result.4163 [ i32 0, label %runtime.success.4158 i32 1, label %runtime.invalid.request.4159 i32 2, label %runtime.invalid.reference.4160 i32 3, label %runtime.scratch.capacity.4161 i32 4, label %runtime.retained.capacity.4162 ]
runtime.invalid.request.4159:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4160:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4161:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4162:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4163:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4158:
  %record.make.handle.4164 = load i64, ptr %workspace.slot.4156, align 8
  %ctx.field.4165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4166 = load i32, ptr %ctx.field.4165, align 4
  %steps.next.4167 = add i32 %steps.current.4166, 1
  store i32 %steps.next.4167, ptr %ctx.field.4165, align 4
  %steps.over.4168 = icmp ugt i32 %steps.next.4167, 10000
  br i1 %steps.over.4168, label %failure.4169, label %continue.4170
failure.4169:
  %ctx.field.4171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 427, ptr %ctx.field.4171, align 4
  %status.diagnostic.4172 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4172, align 4
  ret void
continue.4170:
  %ctx.field.4173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4174 = load i32, ptr %ctx.field.4173, align 4
  %steps.next.4175 = add i32 %steps.current.4174, 1
  store i32 %steps.next.4175, ptr %ctx.field.4173, align 4
  %steps.over.4176 = icmp ugt i32 %steps.next.4175, 10000
  br i1 %steps.over.4176, label %failure.4177, label %continue.4178
failure.4177:
  %ctx.field.4179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 428, ptr %ctx.field.4179, align 4
  %status.diagnostic.4180 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4180, align 4
  ret void
continue.4178:
  %ctx.field.4181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4182 = load i32, ptr %ctx.field.4181, align 4
  %steps.next.4183 = add i32 %steps.current.4182, 1
  store i32 %steps.next.4183, ptr %ctx.field.4181, align 4
  %steps.over.4184 = icmp ugt i32 %steps.next.4183, 10000
  br i1 %steps.over.4184, label %failure.4185, label %continue.4186
failure.4185:
  %ctx.field.4187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 429, ptr %ctx.field.4187, align 4
  %status.diagnostic.4188 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4188, align 4
  ret void
continue.4186:
  %depth.exceeded.4189 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4189, label %failure.4190, label %continue.4191
failure.4190:
  %ctx.field.4192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 430, ptr %ctx.field.4192, align 4
  %status.diagnostic.4193 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4193, align 4
  ret void
continue.4191:
  %workspace.slot.4194 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4164, ptr %workspace.slot.4194, align 8
  %workspace.slot.4195 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4196 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 13, ptr %outputs, i32 1, ptr %workspace.slot.4195)
  switch i32 %record.make.status.4196, label %runtime.invalid.result.4202 [ i32 0, label %runtime.success.4197 i32 1, label %runtime.invalid.request.4198 i32 2, label %runtime.invalid.reference.4199 i32 3, label %runtime.scratch.capacity.4200 i32 4, label %runtime.retained.capacity.4201 ]
runtime.invalid.request.4198:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4199:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4200:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4201:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4202:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4197:
  %record.make.handle.4203 = load i64, ptr %workspace.slot.4195, align 8
  %ctx.field.4204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4205 = load i32, ptr %ctx.field.4204, align 4
  %steps.next.4206 = add i32 %steps.current.4205, 1
  store i32 %steps.next.4206, ptr %ctx.field.4204, align 4
  %steps.over.4207 = icmp ugt i32 %steps.next.4206, 10000
  br i1 %steps.over.4207, label %failure.4208, label %continue.4209
failure.4208:
  %ctx.field.4210 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 431, ptr %ctx.field.4210, align 4
  %status.diagnostic.4211 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4211, align 4
  ret void
continue.4209:
  %ctx.field.4212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4213 = load i32, ptr %ctx.field.4212, align 4
  %steps.next.4214 = add i32 %steps.current.4213, 1
  store i32 %steps.next.4214, ptr %ctx.field.4212, align 4
  %steps.over.4215 = icmp ugt i32 %steps.next.4214, 10000
  br i1 %steps.over.4215, label %failure.4216, label %continue.4217
failure.4216:
  %ctx.field.4218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 432, ptr %ctx.field.4218, align 4
  %status.diagnostic.4219 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4219, align 4
  ret void
continue.4217:
  %ctx.field.4220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4221 = load i32, ptr %ctx.field.4220, align 4
  %steps.next.4222 = add i32 %steps.current.4221, 1
  store i32 %steps.next.4222, ptr %ctx.field.4220, align 4
  %steps.over.4223 = icmp ugt i32 %steps.next.4222, 10000
  br i1 %steps.over.4223, label %failure.4224, label %continue.4225
failure.4224:
  %ctx.field.4226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 433, ptr %ctx.field.4226, align 4
  %status.diagnostic.4227 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4227, align 4
  ret void
continue.4225:
  %depth.exceeded.4228 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4228, label %failure.4229, label %continue.4230
failure.4229:
  %ctx.field.4231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 434, ptr %ctx.field.4231, align 4
  %status.diagnostic.4232 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4232, align 4
  ret void
continue.4230:
  %workspace.slot.4233 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4203, ptr %workspace.slot.4233, align 8
  %workspace.slot.4234 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4235 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 14, ptr %outputs, i32 1, ptr %workspace.slot.4234)
  switch i32 %record.make.status.4235, label %runtime.invalid.result.4241 [ i32 0, label %runtime.success.4236 i32 1, label %runtime.invalid.request.4237 i32 2, label %runtime.invalid.reference.4238 i32 3, label %runtime.scratch.capacity.4239 i32 4, label %runtime.retained.capacity.4240 ]
runtime.invalid.request.4237:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4238:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4239:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4240:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4241:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4236:
  %record.make.handle.4242 = load i64, ptr %workspace.slot.4234, align 8
  %ctx.field.4243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4244 = load i32, ptr %ctx.field.4243, align 4
  %steps.next.4245 = add i32 %steps.current.4244, 1
  store i32 %steps.next.4245, ptr %ctx.field.4243, align 4
  %steps.over.4246 = icmp ugt i32 %steps.next.4245, 10000
  br i1 %steps.over.4246, label %failure.4247, label %continue.4248
failure.4247:
  %ctx.field.4249 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 435, ptr %ctx.field.4249, align 4
  %status.diagnostic.4250 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4250, align 4
  ret void
continue.4248:
  %ctx.field.4251 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4252 = load i32, ptr %ctx.field.4251, align 4
  %steps.next.4253 = add i32 %steps.current.4252, 1
  store i32 %steps.next.4253, ptr %ctx.field.4251, align 4
  %steps.over.4254 = icmp ugt i32 %steps.next.4253, 10000
  br i1 %steps.over.4254, label %failure.4255, label %continue.4256
failure.4255:
  %ctx.field.4257 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 436, ptr %ctx.field.4257, align 4
  %status.diagnostic.4258 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4258, align 4
  ret void
continue.4256:
  %ctx.field.4259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4260 = load i32, ptr %ctx.field.4259, align 4
  %steps.next.4261 = add i32 %steps.current.4260, 1
  store i32 %steps.next.4261, ptr %ctx.field.4259, align 4
  %steps.over.4262 = icmp ugt i32 %steps.next.4261, 10000
  br i1 %steps.over.4262, label %failure.4263, label %continue.4264
failure.4263:
  %ctx.field.4265 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 437, ptr %ctx.field.4265, align 4
  %status.diagnostic.4266 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4266, align 4
  ret void
continue.4264:
  %depth.exceeded.4267 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4267, label %failure.4268, label %continue.4269
failure.4268:
  %ctx.field.4270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 438, ptr %ctx.field.4270, align 4
  %status.diagnostic.4271 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4271, align 4
  ret void
continue.4269:
  %workspace.slot.4272 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4242, ptr %workspace.slot.4272, align 8
  %workspace.slot.4273 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4274 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 15, ptr %outputs, i32 1, ptr %workspace.slot.4273)
  switch i32 %record.make.status.4274, label %runtime.invalid.result.4280 [ i32 0, label %runtime.success.4275 i32 1, label %runtime.invalid.request.4276 i32 2, label %runtime.invalid.reference.4277 i32 3, label %runtime.scratch.capacity.4278 i32 4, label %runtime.retained.capacity.4279 ]
runtime.invalid.request.4276:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4277:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4278:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4279:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4280:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4275:
  %record.make.handle.4281 = load i64, ptr %workspace.slot.4273, align 8
  %ctx.field.4282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4283 = load i32, ptr %ctx.field.4282, align 4
  %steps.next.4284 = add i32 %steps.current.4283, 1
  store i32 %steps.next.4284, ptr %ctx.field.4282, align 4
  %steps.over.4285 = icmp ugt i32 %steps.next.4284, 10000
  br i1 %steps.over.4285, label %failure.4286, label %continue.4287
failure.4286:
  %ctx.field.4288 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 439, ptr %ctx.field.4288, align 4
  %status.diagnostic.4289 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4289, align 4
  ret void
continue.4287:
  %ctx.field.4290 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4291 = load i32, ptr %ctx.field.4290, align 4
  %steps.next.4292 = add i32 %steps.current.4291, 1
  store i32 %steps.next.4292, ptr %ctx.field.4290, align 4
  %steps.over.4293 = icmp ugt i32 %steps.next.4292, 10000
  br i1 %steps.over.4293, label %failure.4294, label %continue.4295
failure.4294:
  %ctx.field.4296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 440, ptr %ctx.field.4296, align 4
  %status.diagnostic.4297 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4297, align 4
  ret void
continue.4295:
  %ctx.field.4298 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4299 = load i32, ptr %ctx.field.4298, align 4
  %steps.next.4300 = add i32 %steps.current.4299, 1
  store i32 %steps.next.4300, ptr %ctx.field.4298, align 4
  %steps.over.4301 = icmp ugt i32 %steps.next.4300, 10000
  br i1 %steps.over.4301, label %failure.4302, label %continue.4303
failure.4302:
  %ctx.field.4304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 441, ptr %ctx.field.4304, align 4
  %status.diagnostic.4305 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4305, align 4
  ret void
continue.4303:
  %depth.exceeded.4306 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4306, label %failure.4307, label %continue.4308
failure.4307:
  %ctx.field.4309 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 442, ptr %ctx.field.4309, align 4
  %status.diagnostic.4310 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4310, align 4
  ret void
continue.4308:
  %workspace.slot.4311 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4281, ptr %workspace.slot.4311, align 8
  %workspace.slot.4312 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4313 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 17, ptr %outputs, i32 1, ptr %workspace.slot.4312)
  switch i32 %record.make.status.4313, label %runtime.invalid.result.4319 [ i32 0, label %runtime.success.4314 i32 1, label %runtime.invalid.request.4315 i32 2, label %runtime.invalid.reference.4316 i32 3, label %runtime.scratch.capacity.4317 i32 4, label %runtime.retained.capacity.4318 ]
runtime.invalid.request.4315:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4316:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4317:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4318:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4319:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4314:
  %record.make.handle.4320 = load i64, ptr %workspace.slot.4312, align 8
  %ctx.field.4321 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4322 = load i32, ptr %ctx.field.4321, align 4
  %steps.next.4323 = add i32 %steps.current.4322, 1
  store i32 %steps.next.4323, ptr %ctx.field.4321, align 4
  %steps.over.4324 = icmp ugt i32 %steps.next.4323, 10000
  br i1 %steps.over.4324, label %failure.4325, label %continue.4326
failure.4325:
  %ctx.field.4327 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 443, ptr %ctx.field.4327, align 4
  %status.diagnostic.4328 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4328, align 4
  ret void
continue.4326:
  %ctx.field.4329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4330 = load i32, ptr %ctx.field.4329, align 4
  %steps.next.4331 = add i32 %steps.current.4330, 1
  store i32 %steps.next.4331, ptr %ctx.field.4329, align 4
  %steps.over.4332 = icmp ugt i32 %steps.next.4331, 10000
  br i1 %steps.over.4332, label %failure.4333, label %continue.4334
failure.4333:
  %ctx.field.4335 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 444, ptr %ctx.field.4335, align 4
  %status.diagnostic.4336 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4336, align 4
  ret void
continue.4334:
  %ctx.field.4337 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4338 = load i32, ptr %ctx.field.4337, align 4
  %steps.next.4339 = add i32 %steps.current.4338, 1
  store i32 %steps.next.4339, ptr %ctx.field.4337, align 4
  %steps.over.4340 = icmp ugt i32 %steps.next.4339, 10000
  br i1 %steps.over.4340, label %failure.4341, label %continue.4342
failure.4341:
  %ctx.field.4343 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 445, ptr %ctx.field.4343, align 4
  %status.diagnostic.4344 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4344, align 4
  ret void
continue.4342:
  %depth.exceeded.4345 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4345, label %failure.4346, label %continue.4347
failure.4346:
  %ctx.field.4348 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 446, ptr %ctx.field.4348, align 4
  %status.diagnostic.4349 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4349, align 4
  ret void
continue.4347:
  %workspace.slot.4350 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4320, ptr %workspace.slot.4350, align 8
  %workspace.slot.4351 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4352 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 18, ptr %outputs, i32 1, ptr %workspace.slot.4351)
  switch i32 %record.make.status.4352, label %runtime.invalid.result.4358 [ i32 0, label %runtime.success.4353 i32 1, label %runtime.invalid.request.4354 i32 2, label %runtime.invalid.reference.4355 i32 3, label %runtime.scratch.capacity.4356 i32 4, label %runtime.retained.capacity.4357 ]
runtime.invalid.request.4354:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4355:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4356:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4357:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4358:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4353:
  %record.make.handle.4359 = load i64, ptr %workspace.slot.4351, align 8
  %ctx.field.4360 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4361 = load i32, ptr %ctx.field.4360, align 4
  %steps.next.4362 = add i32 %steps.current.4361, 1
  store i32 %steps.next.4362, ptr %ctx.field.4360, align 4
  %steps.over.4363 = icmp ugt i32 %steps.next.4362, 10000
  br i1 %steps.over.4363, label %failure.4364, label %continue.4365
failure.4364:
  %ctx.field.4366 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 447, ptr %ctx.field.4366, align 4
  %status.diagnostic.4367 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4367, align 4
  ret void
continue.4365:
  %ctx.field.4368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4369 = load i32, ptr %ctx.field.4368, align 4
  %steps.next.4370 = add i32 %steps.current.4369, 1
  store i32 %steps.next.4370, ptr %ctx.field.4368, align 4
  %steps.over.4371 = icmp ugt i32 %steps.next.4370, 10000
  br i1 %steps.over.4371, label %failure.4372, label %continue.4373
failure.4372:
  %ctx.field.4374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 448, ptr %ctx.field.4374, align 4
  %status.diagnostic.4375 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4375, align 4
  ret void
continue.4373:
  %ctx.field.4376 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4377 = load i32, ptr %ctx.field.4376, align 4
  %steps.next.4378 = add i32 %steps.current.4377, 1
  store i32 %steps.next.4378, ptr %ctx.field.4376, align 4
  %steps.over.4379 = icmp ugt i32 %steps.next.4378, 10000
  br i1 %steps.over.4379, label %failure.4380, label %continue.4381
failure.4380:
  %ctx.field.4382 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 449, ptr %ctx.field.4382, align 4
  %status.diagnostic.4383 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4383, align 4
  ret void
continue.4381:
  %depth.exceeded.4384 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4384, label %failure.4385, label %continue.4386
failure.4385:
  %ctx.field.4387 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 450, ptr %ctx.field.4387, align 4
  %status.diagnostic.4388 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4388, align 4
  ret void
continue.4386:
  %workspace.slot.4389 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4359, ptr %workspace.slot.4389, align 8
  %workspace.slot.4390 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4391 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 19, ptr %outputs, i32 1, ptr %workspace.slot.4390)
  switch i32 %record.make.status.4391, label %runtime.invalid.result.4397 [ i32 0, label %runtime.success.4392 i32 1, label %runtime.invalid.request.4393 i32 2, label %runtime.invalid.reference.4394 i32 3, label %runtime.scratch.capacity.4395 i32 4, label %runtime.retained.capacity.4396 ]
runtime.invalid.request.4393:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4394:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4395:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4396:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4397:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4392:
  %record.make.handle.4398 = load i64, ptr %workspace.slot.4390, align 8
  %ctx.field.4399 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4400 = load i32, ptr %ctx.field.4399, align 4
  %steps.next.4401 = add i32 %steps.current.4400, 1
  store i32 %steps.next.4401, ptr %ctx.field.4399, align 4
  %steps.over.4402 = icmp ugt i32 %steps.next.4401, 10000
  br i1 %steps.over.4402, label %failure.4403, label %continue.4404
failure.4403:
  %ctx.field.4405 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 451, ptr %ctx.field.4405, align 4
  %status.diagnostic.4406 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4406, align 4
  ret void
continue.4404:
  %ctx.field.4407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4408 = load i32, ptr %ctx.field.4407, align 4
  %steps.next.4409 = add i32 %steps.current.4408, 1
  store i32 %steps.next.4409, ptr %ctx.field.4407, align 4
  %steps.over.4410 = icmp ugt i32 %steps.next.4409, 10000
  br i1 %steps.over.4410, label %failure.4411, label %continue.4412
failure.4411:
  %ctx.field.4413 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 452, ptr %ctx.field.4413, align 4
  %status.diagnostic.4414 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4414, align 4
  ret void
continue.4412:
  %ctx.field.4415 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4416 = load i32, ptr %ctx.field.4415, align 4
  %steps.next.4417 = add i32 %steps.current.4416, 1
  store i32 %steps.next.4417, ptr %ctx.field.4415, align 4
  %steps.over.4418 = icmp ugt i32 %steps.next.4417, 10000
  br i1 %steps.over.4418, label %failure.4419, label %continue.4420
failure.4419:
  %ctx.field.4421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 453, ptr %ctx.field.4421, align 4
  %status.diagnostic.4422 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4422, align 4
  ret void
continue.4420:
  %depth.exceeded.4423 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4423, label %failure.4424, label %continue.4425
failure.4424:
  %ctx.field.4426 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 454, ptr %ctx.field.4426, align 4
  %status.diagnostic.4427 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4427, align 4
  ret void
continue.4425:
  %workspace.slot.4428 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4398, ptr %workspace.slot.4428, align 8
  %workspace.slot.4429 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4430 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 20, ptr %outputs, i32 1, ptr %workspace.slot.4429)
  switch i32 %record.make.status.4430, label %runtime.invalid.result.4436 [ i32 0, label %runtime.success.4431 i32 1, label %runtime.invalid.request.4432 i32 2, label %runtime.invalid.reference.4433 i32 3, label %runtime.scratch.capacity.4434 i32 4, label %runtime.retained.capacity.4435 ]
runtime.invalid.request.4432:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4433:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4434:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4435:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4436:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4431:
  %record.make.handle.4437 = load i64, ptr %workspace.slot.4429, align 8
  %ctx.field.4438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4439 = load i32, ptr %ctx.field.4438, align 4
  %steps.next.4440 = add i32 %steps.current.4439, 1
  store i32 %steps.next.4440, ptr %ctx.field.4438, align 4
  %steps.over.4441 = icmp ugt i32 %steps.next.4440, 10000
  br i1 %steps.over.4441, label %failure.4442, label %continue.4443
failure.4442:
  %ctx.field.4444 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 455, ptr %ctx.field.4444, align 4
  %status.diagnostic.4445 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4445, align 4
  ret void
continue.4443:
  %ctx.field.4446 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4447 = load i32, ptr %ctx.field.4446, align 4
  %steps.next.4448 = add i32 %steps.current.4447, 1
  store i32 %steps.next.4448, ptr %ctx.field.4446, align 4
  %steps.over.4449 = icmp ugt i32 %steps.next.4448, 10000
  br i1 %steps.over.4449, label %failure.4450, label %continue.4451
failure.4450:
  %ctx.field.4452 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 456, ptr %ctx.field.4452, align 4
  %status.diagnostic.4453 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4453, align 4
  ret void
continue.4451:
  %ctx.field.4454 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4455 = load i32, ptr %ctx.field.4454, align 4
  %steps.next.4456 = add i32 %steps.current.4455, 1
  store i32 %steps.next.4456, ptr %ctx.field.4454, align 4
  %steps.over.4457 = icmp ugt i32 %steps.next.4456, 10000
  br i1 %steps.over.4457, label %failure.4458, label %continue.4459
failure.4458:
  %ctx.field.4460 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 457, ptr %ctx.field.4460, align 4
  %status.diagnostic.4461 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4461, align 4
  ret void
continue.4459:
  %depth.exceeded.4462 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4462, label %failure.4463, label %continue.4464
failure.4463:
  %ctx.field.4465 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 458, ptr %ctx.field.4465, align 4
  %status.diagnostic.4466 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4466, align 4
  ret void
continue.4464:
  %workspace.slot.4467 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4437, ptr %workspace.slot.4467, align 8
  %workspace.slot.4468 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4469 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 21, ptr %outputs, i32 1, ptr %workspace.slot.4468)
  switch i32 %record.make.status.4469, label %runtime.invalid.result.4475 [ i32 0, label %runtime.success.4470 i32 1, label %runtime.invalid.request.4471 i32 2, label %runtime.invalid.reference.4472 i32 3, label %runtime.scratch.capacity.4473 i32 4, label %runtime.retained.capacity.4474 ]
runtime.invalid.request.4471:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4472:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4473:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4474:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4475:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4470:
  %record.make.handle.4476 = load i64, ptr %workspace.slot.4468, align 8
  %ctx.field.4477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4478 = load i32, ptr %ctx.field.4477, align 4
  %steps.next.4479 = add i32 %steps.current.4478, 1
  store i32 %steps.next.4479, ptr %ctx.field.4477, align 4
  %steps.over.4480 = icmp ugt i32 %steps.next.4479, 10000
  br i1 %steps.over.4480, label %failure.4481, label %continue.4482
failure.4481:
  %ctx.field.4483 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 459, ptr %ctx.field.4483, align 4
  %status.diagnostic.4484 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4484, align 4
  ret void
continue.4482:
  %ctx.field.4485 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4486 = load i32, ptr %ctx.field.4485, align 4
  %steps.next.4487 = add i32 %steps.current.4486, 1
  store i32 %steps.next.4487, ptr %ctx.field.4485, align 4
  %steps.over.4488 = icmp ugt i32 %steps.next.4487, 10000
  br i1 %steps.over.4488, label %failure.4489, label %continue.4490
failure.4489:
  %ctx.field.4491 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 460, ptr %ctx.field.4491, align 4
  %status.diagnostic.4492 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4492, align 4
  ret void
continue.4490:
  %ctx.field.4493 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4494 = load i32, ptr %ctx.field.4493, align 4
  %steps.next.4495 = add i32 %steps.current.4494, 1
  store i32 %steps.next.4495, ptr %ctx.field.4493, align 4
  %steps.over.4496 = icmp ugt i32 %steps.next.4495, 10000
  br i1 %steps.over.4496, label %failure.4497, label %continue.4498
failure.4497:
  %ctx.field.4499 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 461, ptr %ctx.field.4499, align 4
  %status.diagnostic.4500 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4500, align 4
  ret void
continue.4498:
  %depth.exceeded.4501 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4501, label %failure.4502, label %continue.4503
failure.4502:
  %ctx.field.4504 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 462, ptr %ctx.field.4504, align 4
  %status.diagnostic.4505 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4505, align 4
  ret void
continue.4503:
  %workspace.slot.4506 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4476, ptr %workspace.slot.4506, align 8
  %workspace.slot.4507 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4508 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 22, ptr %outputs, i32 1, ptr %workspace.slot.4507)
  switch i32 %record.make.status.4508, label %runtime.invalid.result.4514 [ i32 0, label %runtime.success.4509 i32 1, label %runtime.invalid.request.4510 i32 2, label %runtime.invalid.reference.4511 i32 3, label %runtime.scratch.capacity.4512 i32 4, label %runtime.retained.capacity.4513 ]
runtime.invalid.request.4510:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4511:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4512:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4513:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4514:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4509:
  %record.make.handle.4515 = load i64, ptr %workspace.slot.4507, align 8
  %ctx.field.4516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4517 = load i32, ptr %ctx.field.4516, align 4
  %steps.next.4518 = add i32 %steps.current.4517, 1
  store i32 %steps.next.4518, ptr %ctx.field.4516, align 4
  %steps.over.4519 = icmp ugt i32 %steps.next.4518, 10000
  br i1 %steps.over.4519, label %failure.4520, label %continue.4521
failure.4520:
  %ctx.field.4522 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 463, ptr %ctx.field.4522, align 4
  %status.diagnostic.4523 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4523, align 4
  ret void
continue.4521:
  %ctx.field.4524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4525 = load i32, ptr %ctx.field.4524, align 4
  %steps.next.4526 = add i32 %steps.current.4525, 1
  store i32 %steps.next.4526, ptr %ctx.field.4524, align 4
  %steps.over.4527 = icmp ugt i32 %steps.next.4526, 10000
  br i1 %steps.over.4527, label %failure.4528, label %continue.4529
failure.4528:
  %ctx.field.4530 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 464, ptr %ctx.field.4530, align 4
  %status.diagnostic.4531 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4531, align 4
  ret void
continue.4529:
  %ctx.field.4532 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4533 = load i32, ptr %ctx.field.4532, align 4
  %steps.next.4534 = add i32 %steps.current.4533, 1
  store i32 %steps.next.4534, ptr %ctx.field.4532, align 4
  %steps.over.4535 = icmp ugt i32 %steps.next.4534, 10000
  br i1 %steps.over.4535, label %failure.4536, label %continue.4537
failure.4536:
  %ctx.field.4538 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 465, ptr %ctx.field.4538, align 4
  %status.diagnostic.4539 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4539, align 4
  ret void
continue.4537:
  %depth.exceeded.4540 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4540, label %failure.4541, label %continue.4542
failure.4541:
  %ctx.field.4543 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 466, ptr %ctx.field.4543, align 4
  %status.diagnostic.4544 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4544, align 4
  ret void
continue.4542:
  %workspace.slot.4545 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4515, ptr %workspace.slot.4545, align 8
  %workspace.slot.4546 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4547 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 23, ptr %outputs, i32 1, ptr %workspace.slot.4546)
  switch i32 %record.make.status.4547, label %runtime.invalid.result.4553 [ i32 0, label %runtime.success.4548 i32 1, label %runtime.invalid.request.4549 i32 2, label %runtime.invalid.reference.4550 i32 3, label %runtime.scratch.capacity.4551 i32 4, label %runtime.retained.capacity.4552 ]
runtime.invalid.request.4549:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4550:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4551:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4552:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4553:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4548:
  %record.make.handle.4554 = load i64, ptr %workspace.slot.4546, align 8
  %ctx.field.4555 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4556 = load i32, ptr %ctx.field.4555, align 4
  %steps.next.4557 = add i32 %steps.current.4556, 1
  store i32 %steps.next.4557, ptr %ctx.field.4555, align 4
  %steps.over.4558 = icmp ugt i32 %steps.next.4557, 10000
  br i1 %steps.over.4558, label %failure.4559, label %continue.4560
failure.4559:
  %ctx.field.4561 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 467, ptr %ctx.field.4561, align 4
  %status.diagnostic.4562 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4562, align 4
  ret void
continue.4560:
  %ctx.field.4563 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4564 = load i32, ptr %ctx.field.4563, align 4
  %steps.next.4565 = add i32 %steps.current.4564, 1
  store i32 %steps.next.4565, ptr %ctx.field.4563, align 4
  %steps.over.4566 = icmp ugt i32 %steps.next.4565, 10000
  br i1 %steps.over.4566, label %failure.4567, label %continue.4568
failure.4567:
  %ctx.field.4569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 468, ptr %ctx.field.4569, align 4
  %status.diagnostic.4570 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4570, align 4
  ret void
continue.4568:
  %ctx.field.4571 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4572 = load i32, ptr %ctx.field.4571, align 4
  %steps.next.4573 = add i32 %steps.current.4572, 1
  store i32 %steps.next.4573, ptr %ctx.field.4571, align 4
  %steps.over.4574 = icmp ugt i32 %steps.next.4573, 10000
  br i1 %steps.over.4574, label %failure.4575, label %continue.4576
failure.4575:
  %ctx.field.4577 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 469, ptr %ctx.field.4577, align 4
  %status.diagnostic.4578 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4578, align 4
  ret void
continue.4576:
  %depth.exceeded.4579 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4579, label %failure.4580, label %continue.4581
failure.4580:
  %ctx.field.4582 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 470, ptr %ctx.field.4582, align 4
  %status.diagnostic.4583 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4583, align 4
  ret void
continue.4581:
  %workspace.slot.4584 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4554, ptr %workspace.slot.4584, align 8
  %workspace.slot.4585 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4586 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 24, ptr %outputs, i32 1, ptr %workspace.slot.4585)
  switch i32 %record.make.status.4586, label %runtime.invalid.result.4592 [ i32 0, label %runtime.success.4587 i32 1, label %runtime.invalid.request.4588 i32 2, label %runtime.invalid.reference.4589 i32 3, label %runtime.scratch.capacity.4590 i32 4, label %runtime.retained.capacity.4591 ]
runtime.invalid.request.4588:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4589:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4590:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4591:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4592:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4587:
  %record.make.handle.4593 = load i64, ptr %workspace.slot.4585, align 8
  %ctx.field.4594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4595 = load i32, ptr %ctx.field.4594, align 4
  %steps.next.4596 = add i32 %steps.current.4595, 1
  store i32 %steps.next.4596, ptr %ctx.field.4594, align 4
  %steps.over.4597 = icmp ugt i32 %steps.next.4596, 10000
  br i1 %steps.over.4597, label %failure.4598, label %continue.4599
failure.4598:
  %ctx.field.4600 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 471, ptr %ctx.field.4600, align 4
  %status.diagnostic.4601 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4601, align 4
  ret void
continue.4599:
  %ctx.field.4602 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4603 = load i32, ptr %ctx.field.4602, align 4
  %steps.next.4604 = add i32 %steps.current.4603, 1
  store i32 %steps.next.4604, ptr %ctx.field.4602, align 4
  %steps.over.4605 = icmp ugt i32 %steps.next.4604, 10000
  br i1 %steps.over.4605, label %failure.4606, label %continue.4607
failure.4606:
  %ctx.field.4608 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 472, ptr %ctx.field.4608, align 4
  %status.diagnostic.4609 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4609, align 4
  ret void
continue.4607:
  %ctx.field.4610 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4611 = load i32, ptr %ctx.field.4610, align 4
  %steps.next.4612 = add i32 %steps.current.4611, 1
  store i32 %steps.next.4612, ptr %ctx.field.4610, align 4
  %steps.over.4613 = icmp ugt i32 %steps.next.4612, 10000
  br i1 %steps.over.4613, label %failure.4614, label %continue.4615
failure.4614:
  %ctx.field.4616 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 473, ptr %ctx.field.4616, align 4
  %status.diagnostic.4617 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4617, align 4
  ret void
continue.4615:
  %depth.exceeded.4618 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4618, label %failure.4619, label %continue.4620
failure.4619:
  %ctx.field.4621 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 474, ptr %ctx.field.4621, align 4
  %status.diagnostic.4622 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4622, align 4
  ret void
continue.4620:
  %workspace.slot.4623 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4593, ptr %workspace.slot.4623, align 8
  %workspace.slot.4624 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4625 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 25, ptr %outputs, i32 1, ptr %workspace.slot.4624)
  switch i32 %record.make.status.4625, label %runtime.invalid.result.4631 [ i32 0, label %runtime.success.4626 i32 1, label %runtime.invalid.request.4627 i32 2, label %runtime.invalid.reference.4628 i32 3, label %runtime.scratch.capacity.4629 i32 4, label %runtime.retained.capacity.4630 ]
runtime.invalid.request.4627:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4628:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4629:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4630:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4631:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4626:
  %record.make.handle.4632 = load i64, ptr %workspace.slot.4624, align 8
  %ctx.field.4633 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4634 = load i32, ptr %ctx.field.4633, align 4
  %steps.next.4635 = add i32 %steps.current.4634, 1
  store i32 %steps.next.4635, ptr %ctx.field.4633, align 4
  %steps.over.4636 = icmp ugt i32 %steps.next.4635, 10000
  br i1 %steps.over.4636, label %failure.4637, label %continue.4638
failure.4637:
  %ctx.field.4639 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 475, ptr %ctx.field.4639, align 4
  %status.diagnostic.4640 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4640, align 4
  ret void
continue.4638:
  %ctx.field.4641 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4642 = load i32, ptr %ctx.field.4641, align 4
  %steps.next.4643 = add i32 %steps.current.4642, 1
  store i32 %steps.next.4643, ptr %ctx.field.4641, align 4
  %steps.over.4644 = icmp ugt i32 %steps.next.4643, 10000
  br i1 %steps.over.4644, label %failure.4645, label %continue.4646
failure.4645:
  %ctx.field.4647 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 476, ptr %ctx.field.4647, align 4
  %status.diagnostic.4648 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4648, align 4
  ret void
continue.4646:
  %ctx.field.4649 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4650 = load i32, ptr %ctx.field.4649, align 4
  %steps.next.4651 = add i32 %steps.current.4650, 1
  store i32 %steps.next.4651, ptr %ctx.field.4649, align 4
  %steps.over.4652 = icmp ugt i32 %steps.next.4651, 10000
  br i1 %steps.over.4652, label %failure.4653, label %continue.4654
failure.4653:
  %ctx.field.4655 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 477, ptr %ctx.field.4655, align 4
  %status.diagnostic.4656 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4656, align 4
  ret void
continue.4654:
  %depth.exceeded.4657 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4657, label %failure.4658, label %continue.4659
failure.4658:
  %ctx.field.4660 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 478, ptr %ctx.field.4660, align 4
  %status.diagnostic.4661 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4661, align 4
  ret void
continue.4659:
  %workspace.slot.4662 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4632, ptr %workspace.slot.4662, align 8
  %workspace.slot.4663 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4664 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 26, ptr %outputs, i32 1, ptr %workspace.slot.4663)
  switch i32 %record.make.status.4664, label %runtime.invalid.result.4670 [ i32 0, label %runtime.success.4665 i32 1, label %runtime.invalid.request.4666 i32 2, label %runtime.invalid.reference.4667 i32 3, label %runtime.scratch.capacity.4668 i32 4, label %runtime.retained.capacity.4669 ]
runtime.invalid.request.4666:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4667:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4668:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4669:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4670:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4665:
  %record.make.handle.4671 = load i64, ptr %workspace.slot.4663, align 8
  %ctx.field.4672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4673 = load i32, ptr %ctx.field.4672, align 4
  %steps.next.4674 = add i32 %steps.current.4673, 1
  store i32 %steps.next.4674, ptr %ctx.field.4672, align 4
  %steps.over.4675 = icmp ugt i32 %steps.next.4674, 10000
  br i1 %steps.over.4675, label %failure.4676, label %continue.4677
failure.4676:
  %ctx.field.4678 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 479, ptr %ctx.field.4678, align 4
  %status.diagnostic.4679 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4679, align 4
  ret void
continue.4677:
  %ctx.field.4680 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4681 = load i32, ptr %ctx.field.4680, align 4
  %steps.next.4682 = add i32 %steps.current.4681, 1
  store i32 %steps.next.4682, ptr %ctx.field.4680, align 4
  %steps.over.4683 = icmp ugt i32 %steps.next.4682, 10000
  br i1 %steps.over.4683, label %failure.4684, label %continue.4685
failure.4684:
  %ctx.field.4686 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 480, ptr %ctx.field.4686, align 4
  %status.diagnostic.4687 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4687, align 4
  ret void
continue.4685:
  %ctx.field.4688 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4689 = load i32, ptr %ctx.field.4688, align 4
  %steps.next.4690 = add i32 %steps.current.4689, 1
  store i32 %steps.next.4690, ptr %ctx.field.4688, align 4
  %steps.over.4691 = icmp ugt i32 %steps.next.4690, 10000
  br i1 %steps.over.4691, label %failure.4692, label %continue.4693
failure.4692:
  %ctx.field.4694 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 481, ptr %ctx.field.4694, align 4
  %status.diagnostic.4695 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4695, align 4
  ret void
continue.4693:
  %depth.exceeded.4696 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4696, label %failure.4697, label %continue.4698
failure.4697:
  %ctx.field.4699 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 482, ptr %ctx.field.4699, align 4
  %status.diagnostic.4700 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4700, align 4
  ret void
continue.4698:
  %workspace.slot.4701 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4671, ptr %workspace.slot.4701, align 8
  %workspace.slot.4702 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4703 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 28, ptr %outputs, i32 1, ptr %workspace.slot.4702)
  switch i32 %record.make.status.4703, label %runtime.invalid.result.4709 [ i32 0, label %runtime.success.4704 i32 1, label %runtime.invalid.request.4705 i32 2, label %runtime.invalid.reference.4706 i32 3, label %runtime.scratch.capacity.4707 i32 4, label %runtime.retained.capacity.4708 ]
runtime.invalid.request.4705:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4706:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4707:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4708:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4709:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4704:
  %record.make.handle.4710 = load i64, ptr %workspace.slot.4702, align 8
  %ctx.field.4711 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4712 = load i32, ptr %ctx.field.4711, align 4
  %steps.next.4713 = add i32 %steps.current.4712, 1
  store i32 %steps.next.4713, ptr %ctx.field.4711, align 4
  %steps.over.4714 = icmp ugt i32 %steps.next.4713, 10000
  br i1 %steps.over.4714, label %failure.4715, label %continue.4716
failure.4715:
  %ctx.field.4717 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 483, ptr %ctx.field.4717, align 4
  %status.diagnostic.4718 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4718, align 4
  ret void
continue.4716:
  %ctx.field.4719 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4720 = load i32, ptr %ctx.field.4719, align 4
  %steps.next.4721 = add i32 %steps.current.4720, 1
  store i32 %steps.next.4721, ptr %ctx.field.4719, align 4
  %steps.over.4722 = icmp ugt i32 %steps.next.4721, 10000
  br i1 %steps.over.4722, label %failure.4723, label %continue.4724
failure.4723:
  %ctx.field.4725 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 484, ptr %ctx.field.4725, align 4
  %status.diagnostic.4726 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4726, align 4
  ret void
continue.4724:
  %ctx.field.4727 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4728 = load i32, ptr %ctx.field.4727, align 4
  %steps.next.4729 = add i32 %steps.current.4728, 1
  store i32 %steps.next.4729, ptr %ctx.field.4727, align 4
  %steps.over.4730 = icmp ugt i32 %steps.next.4729, 10000
  br i1 %steps.over.4730, label %failure.4731, label %continue.4732
failure.4731:
  %ctx.field.4733 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 485, ptr %ctx.field.4733, align 4
  %status.diagnostic.4734 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4734, align 4
  ret void
continue.4732:
  %depth.exceeded.4735 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4735, label %failure.4736, label %continue.4737
failure.4736:
  %ctx.field.4738 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 486, ptr %ctx.field.4738, align 4
  %status.diagnostic.4739 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4739, align 4
  ret void
continue.4737:
  %workspace.slot.4740 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4710, ptr %workspace.slot.4740, align 8
  %workspace.slot.4741 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4742 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 29, ptr %outputs, i32 1, ptr %workspace.slot.4741)
  switch i32 %record.make.status.4742, label %runtime.invalid.result.4748 [ i32 0, label %runtime.success.4743 i32 1, label %runtime.invalid.request.4744 i32 2, label %runtime.invalid.reference.4745 i32 3, label %runtime.scratch.capacity.4746 i32 4, label %runtime.retained.capacity.4747 ]
runtime.invalid.request.4744:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4745:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4746:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4747:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4748:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4743:
  %record.make.handle.4749 = load i64, ptr %workspace.slot.4741, align 8
  %ctx.field.4750 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4751 = load i32, ptr %ctx.field.4750, align 4
  %steps.next.4752 = add i32 %steps.current.4751, 1
  store i32 %steps.next.4752, ptr %ctx.field.4750, align 4
  %steps.over.4753 = icmp ugt i32 %steps.next.4752, 10000
  br i1 %steps.over.4753, label %failure.4754, label %continue.4755
failure.4754:
  %ctx.field.4756 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 487, ptr %ctx.field.4756, align 4
  %status.diagnostic.4757 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4757, align 4
  ret void
continue.4755:
  %ctx.field.4758 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4759 = load i32, ptr %ctx.field.4758, align 4
  %steps.next.4760 = add i32 %steps.current.4759, 1
  store i32 %steps.next.4760, ptr %ctx.field.4758, align 4
  %steps.over.4761 = icmp ugt i32 %steps.next.4760, 10000
  br i1 %steps.over.4761, label %failure.4762, label %continue.4763
failure.4762:
  %ctx.field.4764 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 488, ptr %ctx.field.4764, align 4
  %status.diagnostic.4765 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4765, align 4
  ret void
continue.4763:
  %ctx.field.4766 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4767 = load i32, ptr %ctx.field.4766, align 4
  %steps.next.4768 = add i32 %steps.current.4767, 1
  store i32 %steps.next.4768, ptr %ctx.field.4766, align 4
  %steps.over.4769 = icmp ugt i32 %steps.next.4768, 10000
  br i1 %steps.over.4769, label %failure.4770, label %continue.4771
failure.4770:
  %ctx.field.4772 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 489, ptr %ctx.field.4772, align 4
  %status.diagnostic.4773 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4773, align 4
  ret void
continue.4771:
  %depth.exceeded.4774 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4774, label %failure.4775, label %continue.4776
failure.4775:
  %ctx.field.4777 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 490, ptr %ctx.field.4777, align 4
  %status.diagnostic.4778 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4778, align 4
  ret void
continue.4776:
  %workspace.slot.4779 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4749, ptr %workspace.slot.4779, align 8
  %workspace.slot.4780 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4781 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 30, ptr %outputs, i32 1, ptr %workspace.slot.4780)
  switch i32 %record.make.status.4781, label %runtime.invalid.result.4787 [ i32 0, label %runtime.success.4782 i32 1, label %runtime.invalid.request.4783 i32 2, label %runtime.invalid.reference.4784 i32 3, label %runtime.scratch.capacity.4785 i32 4, label %runtime.retained.capacity.4786 ]
runtime.invalid.request.4783:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4784:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4785:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4786:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4787:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4782:
  %record.make.handle.4788 = load i64, ptr %workspace.slot.4780, align 8
  %ctx.field.4789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4790 = load i32, ptr %ctx.field.4789, align 4
  %steps.next.4791 = add i32 %steps.current.4790, 1
  store i32 %steps.next.4791, ptr %ctx.field.4789, align 4
  %steps.over.4792 = icmp ugt i32 %steps.next.4791, 10000
  br i1 %steps.over.4792, label %failure.4793, label %continue.4794
failure.4793:
  %ctx.field.4795 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 491, ptr %ctx.field.4795, align 4
  %status.diagnostic.4796 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4796, align 4
  ret void
continue.4794:
  %ctx.field.4797 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4798 = load i32, ptr %ctx.field.4797, align 4
  %steps.next.4799 = add i32 %steps.current.4798, 1
  store i32 %steps.next.4799, ptr %ctx.field.4797, align 4
  %steps.over.4800 = icmp ugt i32 %steps.next.4799, 10000
  br i1 %steps.over.4800, label %failure.4801, label %continue.4802
failure.4801:
  %ctx.field.4803 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 492, ptr %ctx.field.4803, align 4
  %status.diagnostic.4804 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4804, align 4
  ret void
continue.4802:
  %ctx.field.4805 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4806 = load i32, ptr %ctx.field.4805, align 4
  %steps.next.4807 = add i32 %steps.current.4806, 1
  store i32 %steps.next.4807, ptr %ctx.field.4805, align 4
  %steps.over.4808 = icmp ugt i32 %steps.next.4807, 10000
  br i1 %steps.over.4808, label %failure.4809, label %continue.4810
failure.4809:
  %ctx.field.4811 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 493, ptr %ctx.field.4811, align 4
  %status.diagnostic.4812 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4812, align 4
  ret void
continue.4810:
  %depth.exceeded.4813 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4813, label %failure.4814, label %continue.4815
failure.4814:
  %ctx.field.4816 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 494, ptr %ctx.field.4816, align 4
  %status.diagnostic.4817 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4817, align 4
  ret void
continue.4815:
  %workspace.slot.4818 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4788, ptr %workspace.slot.4818, align 8
  %workspace.slot.4819 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4820 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 31, ptr %outputs, i32 1, ptr %workspace.slot.4819)
  switch i32 %record.make.status.4820, label %runtime.invalid.result.4826 [ i32 0, label %runtime.success.4821 i32 1, label %runtime.invalid.request.4822 i32 2, label %runtime.invalid.reference.4823 i32 3, label %runtime.scratch.capacity.4824 i32 4, label %runtime.retained.capacity.4825 ]
runtime.invalid.request.4822:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4823:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4824:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4825:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4826:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4821:
  %record.make.handle.4827 = load i64, ptr %workspace.slot.4819, align 8
  %ctx.field.4828 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4829 = load i32, ptr %ctx.field.4828, align 4
  %steps.next.4830 = add i32 %steps.current.4829, 1
  store i32 %steps.next.4830, ptr %ctx.field.4828, align 4
  %steps.over.4831 = icmp ugt i32 %steps.next.4830, 10000
  br i1 %steps.over.4831, label %failure.4832, label %continue.4833
failure.4832:
  %ctx.field.4834 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 495, ptr %ctx.field.4834, align 4
  %status.diagnostic.4835 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4835, align 4
  ret void
continue.4833:
  %ctx.field.4836 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4837 = load i32, ptr %ctx.field.4836, align 4
  %steps.next.4838 = add i32 %steps.current.4837, 1
  store i32 %steps.next.4838, ptr %ctx.field.4836, align 4
  %steps.over.4839 = icmp ugt i32 %steps.next.4838, 10000
  br i1 %steps.over.4839, label %failure.4840, label %continue.4841
failure.4840:
  %ctx.field.4842 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 496, ptr %ctx.field.4842, align 4
  %status.diagnostic.4843 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4843, align 4
  ret void
continue.4841:
  %ctx.field.4844 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4845 = load i32, ptr %ctx.field.4844, align 4
  %steps.next.4846 = add i32 %steps.current.4845, 1
  store i32 %steps.next.4846, ptr %ctx.field.4844, align 4
  %steps.over.4847 = icmp ugt i32 %steps.next.4846, 10000
  br i1 %steps.over.4847, label %failure.4848, label %continue.4849
failure.4848:
  %ctx.field.4850 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 497, ptr %ctx.field.4850, align 4
  %status.diagnostic.4851 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4851, align 4
  ret void
continue.4849:
  %depth.exceeded.4852 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4852, label %failure.4853, label %continue.4854
failure.4853:
  %ctx.field.4855 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 498, ptr %ctx.field.4855, align 4
  %status.diagnostic.4856 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4856, align 4
  ret void
continue.4854:
  %workspace.slot.4857 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4827, ptr %workspace.slot.4857, align 8
  %workspace.slot.4858 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4859 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 32, ptr %outputs, i32 1, ptr %workspace.slot.4858)
  switch i32 %record.make.status.4859, label %runtime.invalid.result.4865 [ i32 0, label %runtime.success.4860 i32 1, label %runtime.invalid.request.4861 i32 2, label %runtime.invalid.reference.4862 i32 3, label %runtime.scratch.capacity.4863 i32 4, label %runtime.retained.capacity.4864 ]
runtime.invalid.request.4861:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4862:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4863:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4864:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4865:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4860:
  %record.make.handle.4866 = load i64, ptr %workspace.slot.4858, align 8
  %ctx.field.4867 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4868 = load i32, ptr %ctx.field.4867, align 4
  %steps.next.4869 = add i32 %steps.current.4868, 1
  store i32 %steps.next.4869, ptr %ctx.field.4867, align 4
  %steps.over.4870 = icmp ugt i32 %steps.next.4869, 10000
  br i1 %steps.over.4870, label %failure.4871, label %continue.4872
failure.4871:
  %ctx.field.4873 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 499, ptr %ctx.field.4873, align 4
  %status.diagnostic.4874 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4874, align 4
  ret void
continue.4872:
  %ctx.field.4875 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4876 = load i32, ptr %ctx.field.4875, align 4
  %steps.next.4877 = add i32 %steps.current.4876, 1
  store i32 %steps.next.4877, ptr %ctx.field.4875, align 4
  %steps.over.4878 = icmp ugt i32 %steps.next.4877, 10000
  br i1 %steps.over.4878, label %failure.4879, label %continue.4880
failure.4879:
  %ctx.field.4881 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 500, ptr %ctx.field.4881, align 4
  %status.diagnostic.4882 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4882, align 4
  ret void
continue.4880:
  %ctx.field.4883 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4884 = load i32, ptr %ctx.field.4883, align 4
  %steps.next.4885 = add i32 %steps.current.4884, 1
  store i32 %steps.next.4885, ptr %ctx.field.4883, align 4
  %steps.over.4886 = icmp ugt i32 %steps.next.4885, 10000
  br i1 %steps.over.4886, label %failure.4887, label %continue.4888
failure.4887:
  %ctx.field.4889 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 501, ptr %ctx.field.4889, align 4
  %status.diagnostic.4890 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4890, align 4
  ret void
continue.4888:
  %depth.exceeded.4891 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4891, label %failure.4892, label %continue.4893
failure.4892:
  %ctx.field.4894 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 502, ptr %ctx.field.4894, align 4
  %status.diagnostic.4895 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4895, align 4
  ret void
continue.4893:
  %workspace.slot.4896 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4866, ptr %workspace.slot.4896, align 8
  %workspace.slot.4897 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4898 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 33, ptr %outputs, i32 1, ptr %workspace.slot.4897)
  switch i32 %record.make.status.4898, label %runtime.invalid.result.4904 [ i32 0, label %runtime.success.4899 i32 1, label %runtime.invalid.request.4900 i32 2, label %runtime.invalid.reference.4901 i32 3, label %runtime.scratch.capacity.4902 i32 4, label %runtime.retained.capacity.4903 ]
runtime.invalid.request.4900:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4901:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4902:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4903:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4904:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4899:
  %record.make.handle.4905 = load i64, ptr %workspace.slot.4897, align 8
  %ctx.field.4906 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4907 = load i32, ptr %ctx.field.4906, align 4
  %steps.next.4908 = add i32 %steps.current.4907, 1
  store i32 %steps.next.4908, ptr %ctx.field.4906, align 4
  %steps.over.4909 = icmp ugt i32 %steps.next.4908, 10000
  br i1 %steps.over.4909, label %failure.4910, label %continue.4911
failure.4910:
  %ctx.field.4912 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 503, ptr %ctx.field.4912, align 4
  %status.diagnostic.4913 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4913, align 4
  ret void
continue.4911:
  %ctx.field.4914 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4915 = load i32, ptr %ctx.field.4914, align 4
  %steps.next.4916 = add i32 %steps.current.4915, 1
  store i32 %steps.next.4916, ptr %ctx.field.4914, align 4
  %steps.over.4917 = icmp ugt i32 %steps.next.4916, 10000
  br i1 %steps.over.4917, label %failure.4918, label %continue.4919
failure.4918:
  %ctx.field.4920 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 504, ptr %ctx.field.4920, align 4
  %status.diagnostic.4921 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4921, align 4
  ret void
continue.4919:
  %ctx.field.4922 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4923 = load i32, ptr %ctx.field.4922, align 4
  %steps.next.4924 = add i32 %steps.current.4923, 1
  store i32 %steps.next.4924, ptr %ctx.field.4922, align 4
  %steps.over.4925 = icmp ugt i32 %steps.next.4924, 10000
  br i1 %steps.over.4925, label %failure.4926, label %continue.4927
failure.4926:
  %ctx.field.4928 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 505, ptr %ctx.field.4928, align 4
  %status.diagnostic.4929 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4929, align 4
  ret void
continue.4927:
  %depth.exceeded.4930 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4930, label %failure.4931, label %continue.4932
failure.4931:
  %ctx.field.4933 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 506, ptr %ctx.field.4933, align 4
  %status.diagnostic.4934 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4934, align 4
  ret void
continue.4932:
  %workspace.slot.4935 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4905, ptr %workspace.slot.4935, align 8
  %workspace.slot.4936 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4937 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 34, ptr %outputs, i32 1, ptr %workspace.slot.4936)
  switch i32 %record.make.status.4937, label %runtime.invalid.result.4943 [ i32 0, label %runtime.success.4938 i32 1, label %runtime.invalid.request.4939 i32 2, label %runtime.invalid.reference.4940 i32 3, label %runtime.scratch.capacity.4941 i32 4, label %runtime.retained.capacity.4942 ]
runtime.invalid.request.4939:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4940:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4941:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4942:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4943:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4938:
  %record.make.handle.4944 = load i64, ptr %workspace.slot.4936, align 8
  %ctx.field.4945 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4946 = load i32, ptr %ctx.field.4945, align 4
  %steps.next.4947 = add i32 %steps.current.4946, 1
  store i32 %steps.next.4947, ptr %ctx.field.4945, align 4
  %steps.over.4948 = icmp ugt i32 %steps.next.4947, 10000
  br i1 %steps.over.4948, label %failure.4949, label %continue.4950
failure.4949:
  %ctx.field.4951 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 507, ptr %ctx.field.4951, align 4
  %status.diagnostic.4952 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4952, align 4
  ret void
continue.4950:
  %ctx.field.4953 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4954 = load i32, ptr %ctx.field.4953, align 4
  %steps.next.4955 = add i32 %steps.current.4954, 1
  store i32 %steps.next.4955, ptr %ctx.field.4953, align 4
  %steps.over.4956 = icmp ugt i32 %steps.next.4955, 10000
  br i1 %steps.over.4956, label %failure.4957, label %continue.4958
failure.4957:
  %ctx.field.4959 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 508, ptr %ctx.field.4959, align 4
  %status.diagnostic.4960 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4960, align 4
  ret void
continue.4958:
  %ctx.field.4961 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4962 = load i32, ptr %ctx.field.4961, align 4
  %steps.next.4963 = add i32 %steps.current.4962, 1
  store i32 %steps.next.4963, ptr %ctx.field.4961, align 4
  %steps.over.4964 = icmp ugt i32 %steps.next.4963, 10000
  br i1 %steps.over.4964, label %failure.4965, label %continue.4966
failure.4965:
  %ctx.field.4967 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 509, ptr %ctx.field.4967, align 4
  %status.diagnostic.4968 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4968, align 4
  ret void
continue.4966:
  %depth.exceeded.4969 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4969, label %failure.4970, label %continue.4971
failure.4970:
  %ctx.field.4972 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 510, ptr %ctx.field.4972, align 4
  %status.diagnostic.4973 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4973, align 4
  ret void
continue.4971:
  %workspace.slot.4974 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4944, ptr %workspace.slot.4974, align 8
  %workspace.slot.4975 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4976 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 35, ptr %outputs, i32 1, ptr %workspace.slot.4975)
  switch i32 %record.make.status.4976, label %runtime.invalid.result.4982 [ i32 0, label %runtime.success.4977 i32 1, label %runtime.invalid.request.4978 i32 2, label %runtime.invalid.reference.4979 i32 3, label %runtime.scratch.capacity.4980 i32 4, label %runtime.retained.capacity.4981 ]
runtime.invalid.request.4978:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4979:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4980:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4981:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4982:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4977:
  %record.make.handle.4983 = load i64, ptr %workspace.slot.4975, align 8
  %ctx.field.4984 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4985 = load i32, ptr %ctx.field.4984, align 4
  %steps.next.4986 = add i32 %steps.current.4985, 1
  store i32 %steps.next.4986, ptr %ctx.field.4984, align 4
  %steps.over.4987 = icmp ugt i32 %steps.next.4986, 10000
  br i1 %steps.over.4987, label %failure.4988, label %continue.4989
failure.4988:
  %ctx.field.4990 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 511, ptr %ctx.field.4990, align 4
  %status.diagnostic.4991 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4991, align 4
  ret void
continue.4989:
  %ctx.field.4992 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4993 = load i32, ptr %ctx.field.4992, align 4
  %steps.next.4994 = add i32 %steps.current.4993, 1
  store i32 %steps.next.4994, ptr %ctx.field.4992, align 4
  %steps.over.4995 = icmp ugt i32 %steps.next.4994, 10000
  br i1 %steps.over.4995, label %failure.4996, label %continue.4997
failure.4996:
  %ctx.field.4998 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 512, ptr %ctx.field.4998, align 4
  %status.diagnostic.4999 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4999, align 4
  ret void
continue.4997:
  %ctx.field.5000 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5001 = load i32, ptr %ctx.field.5000, align 4
  %steps.next.5002 = add i32 %steps.current.5001, 1
  store i32 %steps.next.5002, ptr %ctx.field.5000, align 4
  %steps.over.5003 = icmp ugt i32 %steps.next.5002, 10000
  br i1 %steps.over.5003, label %failure.5004, label %continue.5005
failure.5004:
  %ctx.field.5006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 513, ptr %ctx.field.5006, align 4
  %status.diagnostic.5007 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5007, align 4
  ret void
continue.5005:
  %depth.exceeded.5008 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5008, label %failure.5009, label %continue.5010
failure.5009:
  %ctx.field.5011 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 514, ptr %ctx.field.5011, align 4
  %status.diagnostic.5012 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5012, align 4
  ret void
continue.5010:
  %workspace.slot.5013 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4983, ptr %workspace.slot.5013, align 8
  %workspace.slot.5014 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5015 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 36, ptr %outputs, i32 1, ptr %workspace.slot.5014)
  switch i32 %record.make.status.5015, label %runtime.invalid.result.5021 [ i32 0, label %runtime.success.5016 i32 1, label %runtime.invalid.request.5017 i32 2, label %runtime.invalid.reference.5018 i32 3, label %runtime.scratch.capacity.5019 i32 4, label %runtime.retained.capacity.5020 ]
runtime.invalid.request.5017:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5018:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5019:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5020:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5021:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5016:
  %record.make.handle.5022 = load i64, ptr %workspace.slot.5014, align 8
  %ctx.field.5023 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5024 = load i32, ptr %ctx.field.5023, align 4
  %steps.next.5025 = add i32 %steps.current.5024, 1
  store i32 %steps.next.5025, ptr %ctx.field.5023, align 4
  %steps.over.5026 = icmp ugt i32 %steps.next.5025, 10000
  br i1 %steps.over.5026, label %failure.5027, label %continue.5028
failure.5027:
  %ctx.field.5029 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 515, ptr %ctx.field.5029, align 4
  %status.diagnostic.5030 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5030, align 4
  ret void
continue.5028:
  %ctx.field.5031 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5032 = load i32, ptr %ctx.field.5031, align 4
  %steps.next.5033 = add i32 %steps.current.5032, 1
  store i32 %steps.next.5033, ptr %ctx.field.5031, align 4
  %steps.over.5034 = icmp ugt i32 %steps.next.5033, 10000
  br i1 %steps.over.5034, label %failure.5035, label %continue.5036
failure.5035:
  %ctx.field.5037 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 516, ptr %ctx.field.5037, align 4
  %status.diagnostic.5038 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5038, align 4
  ret void
continue.5036:
  %ctx.field.5039 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5040 = load i32, ptr %ctx.field.5039, align 4
  %steps.next.5041 = add i32 %steps.current.5040, 1
  store i32 %steps.next.5041, ptr %ctx.field.5039, align 4
  %steps.over.5042 = icmp ugt i32 %steps.next.5041, 10000
  br i1 %steps.over.5042, label %failure.5043, label %continue.5044
failure.5043:
  %ctx.field.5045 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 517, ptr %ctx.field.5045, align 4
  %status.diagnostic.5046 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5046, align 4
  ret void
continue.5044:
  %depth.exceeded.5047 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5047, label %failure.5048, label %continue.5049
failure.5048:
  %ctx.field.5050 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 518, ptr %ctx.field.5050, align 4
  %status.diagnostic.5051 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5051, align 4
  ret void
continue.5049:
  %workspace.slot.5052 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5022, ptr %workspace.slot.5052, align 8
  %workspace.slot.5053 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5054 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 37, ptr %outputs, i32 1, ptr %workspace.slot.5053)
  switch i32 %record.make.status.5054, label %runtime.invalid.result.5060 [ i32 0, label %runtime.success.5055 i32 1, label %runtime.invalid.request.5056 i32 2, label %runtime.invalid.reference.5057 i32 3, label %runtime.scratch.capacity.5058 i32 4, label %runtime.retained.capacity.5059 ]
runtime.invalid.request.5056:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5057:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5058:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5059:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5060:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5055:
  %record.make.handle.5061 = load i64, ptr %workspace.slot.5053, align 8
  %ctx.field.5062 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5063 = load i32, ptr %ctx.field.5062, align 4
  %steps.next.5064 = add i32 %steps.current.5063, 1
  store i32 %steps.next.5064, ptr %ctx.field.5062, align 4
  %steps.over.5065 = icmp ugt i32 %steps.next.5064, 10000
  br i1 %steps.over.5065, label %failure.5066, label %continue.5067
failure.5066:
  %ctx.field.5068 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 519, ptr %ctx.field.5068, align 4
  %status.diagnostic.5069 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5069, align 4
  ret void
continue.5067:
  %ctx.field.5070 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5071 = load i32, ptr %ctx.field.5070, align 4
  %steps.next.5072 = add i32 %steps.current.5071, 1
  store i32 %steps.next.5072, ptr %ctx.field.5070, align 4
  %steps.over.5073 = icmp ugt i32 %steps.next.5072, 10000
  br i1 %steps.over.5073, label %failure.5074, label %continue.5075
failure.5074:
  %ctx.field.5076 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 520, ptr %ctx.field.5076, align 4
  %status.diagnostic.5077 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5077, align 4
  ret void
continue.5075:
  %ctx.field.5078 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5079 = load i32, ptr %ctx.field.5078, align 4
  %steps.next.5080 = add i32 %steps.current.5079, 1
  store i32 %steps.next.5080, ptr %ctx.field.5078, align 4
  %steps.over.5081 = icmp ugt i32 %steps.next.5080, 10000
  br i1 %steps.over.5081, label %failure.5082, label %continue.5083
failure.5082:
  %ctx.field.5084 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 521, ptr %ctx.field.5084, align 4
  %status.diagnostic.5085 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5085, align 4
  ret void
continue.5083:
  %depth.exceeded.5086 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5086, label %failure.5087, label %continue.5088
failure.5087:
  %ctx.field.5089 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 522, ptr %ctx.field.5089, align 4
  %status.diagnostic.5090 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5090, align 4
  ret void
continue.5088:
  %workspace.slot.5091 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5061, ptr %workspace.slot.5091, align 8
  %workspace.slot.5092 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5093 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 39, ptr %outputs, i32 1, ptr %workspace.slot.5092)
  switch i32 %record.make.status.5093, label %runtime.invalid.result.5099 [ i32 0, label %runtime.success.5094 i32 1, label %runtime.invalid.request.5095 i32 2, label %runtime.invalid.reference.5096 i32 3, label %runtime.scratch.capacity.5097 i32 4, label %runtime.retained.capacity.5098 ]
runtime.invalid.request.5095:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5096:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5097:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5098:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5099:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5094:
  %record.make.handle.5100 = load i64, ptr %workspace.slot.5092, align 8
  %ctx.field.5101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5102 = load i32, ptr %ctx.field.5101, align 4
  %steps.next.5103 = add i32 %steps.current.5102, 1
  store i32 %steps.next.5103, ptr %ctx.field.5101, align 4
  %steps.over.5104 = icmp ugt i32 %steps.next.5103, 10000
  br i1 %steps.over.5104, label %failure.5105, label %continue.5106
failure.5105:
  %ctx.field.5107 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 523, ptr %ctx.field.5107, align 4
  %status.diagnostic.5108 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5108, align 4
  ret void
continue.5106:
  %ctx.field.5109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5110 = load i32, ptr %ctx.field.5109, align 4
  %steps.next.5111 = add i32 %steps.current.5110, 1
  store i32 %steps.next.5111, ptr %ctx.field.5109, align 4
  %steps.over.5112 = icmp ugt i32 %steps.next.5111, 10000
  br i1 %steps.over.5112, label %failure.5113, label %continue.5114
failure.5113:
  %ctx.field.5115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 524, ptr %ctx.field.5115, align 4
  %status.diagnostic.5116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5116, align 4
  ret void
continue.5114:
  %ctx.field.5117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5118 = load i32, ptr %ctx.field.5117, align 4
  %steps.next.5119 = add i32 %steps.current.5118, 1
  store i32 %steps.next.5119, ptr %ctx.field.5117, align 4
  %steps.over.5120 = icmp ugt i32 %steps.next.5119, 10000
  br i1 %steps.over.5120, label %failure.5121, label %continue.5122
failure.5121:
  %ctx.field.5123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 525, ptr %ctx.field.5123, align 4
  %status.diagnostic.5124 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5124, align 4
  ret void
continue.5122:
  %depth.exceeded.5125 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5125, label %failure.5126, label %continue.5127
failure.5126:
  %ctx.field.5128 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 526, ptr %ctx.field.5128, align 4
  %status.diagnostic.5129 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5129, align 4
  ret void
continue.5127:
  %workspace.slot.5130 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5100, ptr %workspace.slot.5130, align 8
  %workspace.slot.5131 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5132 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 40, ptr %outputs, i32 1, ptr %workspace.slot.5131)
  switch i32 %record.make.status.5132, label %runtime.invalid.result.5138 [ i32 0, label %runtime.success.5133 i32 1, label %runtime.invalid.request.5134 i32 2, label %runtime.invalid.reference.5135 i32 3, label %runtime.scratch.capacity.5136 i32 4, label %runtime.retained.capacity.5137 ]
runtime.invalid.request.5134:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5135:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5136:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5137:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5138:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5133:
  %record.make.handle.5139 = load i64, ptr %workspace.slot.5131, align 8
  %ctx.field.5140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5141 = load i32, ptr %ctx.field.5140, align 4
  %steps.next.5142 = add i32 %steps.current.5141, 1
  store i32 %steps.next.5142, ptr %ctx.field.5140, align 4
  %steps.over.5143 = icmp ugt i32 %steps.next.5142, 10000
  br i1 %steps.over.5143, label %failure.5144, label %continue.5145
failure.5144:
  %ctx.field.5146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 527, ptr %ctx.field.5146, align 4
  %status.diagnostic.5147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5147, align 4
  ret void
continue.5145:
  %ctx.field.5148 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5149 = load i32, ptr %ctx.field.5148, align 4
  %steps.next.5150 = add i32 %steps.current.5149, 1
  store i32 %steps.next.5150, ptr %ctx.field.5148, align 4
  %steps.over.5151 = icmp ugt i32 %steps.next.5150, 10000
  br i1 %steps.over.5151, label %failure.5152, label %continue.5153
failure.5152:
  %ctx.field.5154 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 528, ptr %ctx.field.5154, align 4
  %status.diagnostic.5155 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5155, align 4
  ret void
continue.5153:
  %ctx.field.5156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5157 = load i32, ptr %ctx.field.5156, align 4
  %steps.next.5158 = add i32 %steps.current.5157, 1
  store i32 %steps.next.5158, ptr %ctx.field.5156, align 4
  %steps.over.5159 = icmp ugt i32 %steps.next.5158, 10000
  br i1 %steps.over.5159, label %failure.5160, label %continue.5161
failure.5160:
  %ctx.field.5162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 529, ptr %ctx.field.5162, align 4
  %status.diagnostic.5163 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5163, align 4
  ret void
continue.5161:
  %depth.exceeded.5164 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5164, label %failure.5165, label %continue.5166
failure.5165:
  %ctx.field.5167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 530, ptr %ctx.field.5167, align 4
  %status.diagnostic.5168 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5168, align 4
  ret void
continue.5166:
  %workspace.slot.5169 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5139, ptr %workspace.slot.5169, align 8
  %workspace.slot.5170 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5171 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 41, ptr %outputs, i32 1, ptr %workspace.slot.5170)
  switch i32 %record.make.status.5171, label %runtime.invalid.result.5177 [ i32 0, label %runtime.success.5172 i32 1, label %runtime.invalid.request.5173 i32 2, label %runtime.invalid.reference.5174 i32 3, label %runtime.scratch.capacity.5175 i32 4, label %runtime.retained.capacity.5176 ]
runtime.invalid.request.5173:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5174:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5175:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5176:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5177:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5172:
  %record.make.handle.5178 = load i64, ptr %workspace.slot.5170, align 8
  %ctx.field.5179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5180 = load i32, ptr %ctx.field.5179, align 4
  %steps.next.5181 = add i32 %steps.current.5180, 1
  store i32 %steps.next.5181, ptr %ctx.field.5179, align 4
  %steps.over.5182 = icmp ugt i32 %steps.next.5181, 10000
  br i1 %steps.over.5182, label %failure.5183, label %continue.5184
failure.5183:
  %ctx.field.5185 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 531, ptr %ctx.field.5185, align 4
  %status.diagnostic.5186 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5186, align 4
  ret void
continue.5184:
  %ctx.field.5187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5188 = load i32, ptr %ctx.field.5187, align 4
  %steps.next.5189 = add i32 %steps.current.5188, 1
  store i32 %steps.next.5189, ptr %ctx.field.5187, align 4
  %steps.over.5190 = icmp ugt i32 %steps.next.5189, 10000
  br i1 %steps.over.5190, label %failure.5191, label %continue.5192
failure.5191:
  %ctx.field.5193 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 532, ptr %ctx.field.5193, align 4
  %status.diagnostic.5194 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5194, align 4
  ret void
continue.5192:
  %ctx.field.5195 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5196 = load i32, ptr %ctx.field.5195, align 4
  %steps.next.5197 = add i32 %steps.current.5196, 1
  store i32 %steps.next.5197, ptr %ctx.field.5195, align 4
  %steps.over.5198 = icmp ugt i32 %steps.next.5197, 10000
  br i1 %steps.over.5198, label %failure.5199, label %continue.5200
failure.5199:
  %ctx.field.5201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 533, ptr %ctx.field.5201, align 4
  %status.diagnostic.5202 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5202, align 4
  ret void
continue.5200:
  %depth.exceeded.5203 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5203, label %failure.5204, label %continue.5205
failure.5204:
  %ctx.field.5206 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 534, ptr %ctx.field.5206, align 4
  %status.diagnostic.5207 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5207, align 4
  ret void
continue.5205:
  %workspace.slot.5208 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5178, ptr %workspace.slot.5208, align 8
  %workspace.slot.5209 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5210 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 42, ptr %outputs, i32 1, ptr %workspace.slot.5209)
  switch i32 %record.make.status.5210, label %runtime.invalid.result.5216 [ i32 0, label %runtime.success.5211 i32 1, label %runtime.invalid.request.5212 i32 2, label %runtime.invalid.reference.5213 i32 3, label %runtime.scratch.capacity.5214 i32 4, label %runtime.retained.capacity.5215 ]
runtime.invalid.request.5212:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5213:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5214:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5215:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5216:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5211:
  %record.make.handle.5217 = load i64, ptr %workspace.slot.5209, align 8
  %ctx.field.5218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5219 = load i32, ptr %ctx.field.5218, align 4
  %steps.next.5220 = add i32 %steps.current.5219, 1
  store i32 %steps.next.5220, ptr %ctx.field.5218, align 4
  %steps.over.5221 = icmp ugt i32 %steps.next.5220, 10000
  br i1 %steps.over.5221, label %failure.5222, label %continue.5223
failure.5222:
  %ctx.field.5224 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 535, ptr %ctx.field.5224, align 4
  %status.diagnostic.5225 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5225, align 4
  ret void
continue.5223:
  %ctx.field.5226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5227 = load i32, ptr %ctx.field.5226, align 4
  %steps.next.5228 = add i32 %steps.current.5227, 1
  store i32 %steps.next.5228, ptr %ctx.field.5226, align 4
  %steps.over.5229 = icmp ugt i32 %steps.next.5228, 10000
  br i1 %steps.over.5229, label %failure.5230, label %continue.5231
failure.5230:
  %ctx.field.5232 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 536, ptr %ctx.field.5232, align 4
  %status.diagnostic.5233 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5233, align 4
  ret void
continue.5231:
  %ctx.field.5234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5235 = load i32, ptr %ctx.field.5234, align 4
  %steps.next.5236 = add i32 %steps.current.5235, 1
  store i32 %steps.next.5236, ptr %ctx.field.5234, align 4
  %steps.over.5237 = icmp ugt i32 %steps.next.5236, 10000
  br i1 %steps.over.5237, label %failure.5238, label %continue.5239
failure.5238:
  %ctx.field.5240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 537, ptr %ctx.field.5240, align 4
  %status.diagnostic.5241 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5241, align 4
  ret void
continue.5239:
  %depth.exceeded.5242 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5242, label %failure.5243, label %continue.5244
failure.5243:
  %ctx.field.5245 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 538, ptr %ctx.field.5245, align 4
  %status.diagnostic.5246 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5246, align 4
  ret void
continue.5244:
  %workspace.slot.5247 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5217, ptr %workspace.slot.5247, align 8
  %workspace.slot.5248 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5249 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 43, ptr %outputs, i32 1, ptr %workspace.slot.5248)
  switch i32 %record.make.status.5249, label %runtime.invalid.result.5255 [ i32 0, label %runtime.success.5250 i32 1, label %runtime.invalid.request.5251 i32 2, label %runtime.invalid.reference.5252 i32 3, label %runtime.scratch.capacity.5253 i32 4, label %runtime.retained.capacity.5254 ]
runtime.invalid.request.5251:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5252:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5253:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5254:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5255:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5250:
  %record.make.handle.5256 = load i64, ptr %workspace.slot.5248, align 8
  %ctx.field.5257 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5258 = load i32, ptr %ctx.field.5257, align 4
  %steps.next.5259 = add i32 %steps.current.5258, 1
  store i32 %steps.next.5259, ptr %ctx.field.5257, align 4
  %steps.over.5260 = icmp ugt i32 %steps.next.5259, 10000
  br i1 %steps.over.5260, label %failure.5261, label %continue.5262
failure.5261:
  %ctx.field.5263 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 539, ptr %ctx.field.5263, align 4
  %status.diagnostic.5264 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5264, align 4
  ret void
continue.5262:
  %ctx.field.5265 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5266 = load i32, ptr %ctx.field.5265, align 4
  %steps.next.5267 = add i32 %steps.current.5266, 1
  store i32 %steps.next.5267, ptr %ctx.field.5265, align 4
  %steps.over.5268 = icmp ugt i32 %steps.next.5267, 10000
  br i1 %steps.over.5268, label %failure.5269, label %continue.5270
failure.5269:
  %ctx.field.5271 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 540, ptr %ctx.field.5271, align 4
  %status.diagnostic.5272 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5272, align 4
  ret void
continue.5270:
  %ctx.field.5273 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5274 = load i32, ptr %ctx.field.5273, align 4
  %steps.next.5275 = add i32 %steps.current.5274, 1
  store i32 %steps.next.5275, ptr %ctx.field.5273, align 4
  %steps.over.5276 = icmp ugt i32 %steps.next.5275, 10000
  br i1 %steps.over.5276, label %failure.5277, label %continue.5278
failure.5277:
  %ctx.field.5279 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 541, ptr %ctx.field.5279, align 4
  %status.diagnostic.5280 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5280, align 4
  ret void
continue.5278:
  %depth.exceeded.5281 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5281, label %failure.5282, label %continue.5283
failure.5282:
  %ctx.field.5284 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 542, ptr %ctx.field.5284, align 4
  %status.diagnostic.5285 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5285, align 4
  ret void
continue.5283:
  %workspace.slot.5286 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5256, ptr %workspace.slot.5286, align 8
  %workspace.slot.5287 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5288 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 44, ptr %outputs, i32 1, ptr %workspace.slot.5287)
  switch i32 %record.make.status.5288, label %runtime.invalid.result.5294 [ i32 0, label %runtime.success.5289 i32 1, label %runtime.invalid.request.5290 i32 2, label %runtime.invalid.reference.5291 i32 3, label %runtime.scratch.capacity.5292 i32 4, label %runtime.retained.capacity.5293 ]
runtime.invalid.request.5290:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5291:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5292:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5293:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5294:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5289:
  %record.make.handle.5295 = load i64, ptr %workspace.slot.5287, align 8
  %ctx.field.5296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5297 = load i32, ptr %ctx.field.5296, align 4
  %steps.next.5298 = add i32 %steps.current.5297, 1
  store i32 %steps.next.5298, ptr %ctx.field.5296, align 4
  %steps.over.5299 = icmp ugt i32 %steps.next.5298, 10000
  br i1 %steps.over.5299, label %failure.5300, label %continue.5301
failure.5300:
  %ctx.field.5302 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 543, ptr %ctx.field.5302, align 4
  %status.diagnostic.5303 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5303, align 4
  ret void
continue.5301:
  %ctx.field.5304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5305 = load i32, ptr %ctx.field.5304, align 4
  %steps.next.5306 = add i32 %steps.current.5305, 1
  store i32 %steps.next.5306, ptr %ctx.field.5304, align 4
  %steps.over.5307 = icmp ugt i32 %steps.next.5306, 10000
  br i1 %steps.over.5307, label %failure.5308, label %continue.5309
failure.5308:
  %ctx.field.5310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 544, ptr %ctx.field.5310, align 4
  %status.diagnostic.5311 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5311, align 4
  ret void
continue.5309:
  %ctx.field.5312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5313 = load i32, ptr %ctx.field.5312, align 4
  %steps.next.5314 = add i32 %steps.current.5313, 1
  store i32 %steps.next.5314, ptr %ctx.field.5312, align 4
  %steps.over.5315 = icmp ugt i32 %steps.next.5314, 10000
  br i1 %steps.over.5315, label %failure.5316, label %continue.5317
failure.5316:
  %ctx.field.5318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 545, ptr %ctx.field.5318, align 4
  %status.diagnostic.5319 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5319, align 4
  ret void
continue.5317:
  %depth.exceeded.5320 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5320, label %failure.5321, label %continue.5322
failure.5321:
  %ctx.field.5323 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 546, ptr %ctx.field.5323, align 4
  %status.diagnostic.5324 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5324, align 4
  ret void
continue.5322:
  %workspace.slot.5325 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5295, ptr %workspace.slot.5325, align 8
  %workspace.slot.5326 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5327 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 45, ptr %outputs, i32 1, ptr %workspace.slot.5326)
  switch i32 %record.make.status.5327, label %runtime.invalid.result.5333 [ i32 0, label %runtime.success.5328 i32 1, label %runtime.invalid.request.5329 i32 2, label %runtime.invalid.reference.5330 i32 3, label %runtime.scratch.capacity.5331 i32 4, label %runtime.retained.capacity.5332 ]
runtime.invalid.request.5329:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5330:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5331:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5332:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5333:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5328:
  %record.make.handle.5334 = load i64, ptr %workspace.slot.5326, align 8
  %ctx.field.5335 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5336 = load i32, ptr %ctx.field.5335, align 4
  %steps.next.5337 = add i32 %steps.current.5336, 1
  store i32 %steps.next.5337, ptr %ctx.field.5335, align 4
  %steps.over.5338 = icmp ugt i32 %steps.next.5337, 10000
  br i1 %steps.over.5338, label %failure.5339, label %continue.5340
failure.5339:
  %ctx.field.5341 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 547, ptr %ctx.field.5341, align 4
  %status.diagnostic.5342 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5342, align 4
  ret void
continue.5340:
  %ctx.field.5343 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5344 = load i32, ptr %ctx.field.5343, align 4
  %steps.next.5345 = add i32 %steps.current.5344, 1
  store i32 %steps.next.5345, ptr %ctx.field.5343, align 4
  %steps.over.5346 = icmp ugt i32 %steps.next.5345, 10000
  br i1 %steps.over.5346, label %failure.5347, label %continue.5348
failure.5347:
  %ctx.field.5349 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 548, ptr %ctx.field.5349, align 4
  %status.diagnostic.5350 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5350, align 4
  ret void
continue.5348:
  %ctx.field.5351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5352 = load i32, ptr %ctx.field.5351, align 4
  %steps.next.5353 = add i32 %steps.current.5352, 1
  store i32 %steps.next.5353, ptr %ctx.field.5351, align 4
  %steps.over.5354 = icmp ugt i32 %steps.next.5353, 10000
  br i1 %steps.over.5354, label %failure.5355, label %continue.5356
failure.5355:
  %ctx.field.5357 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 549, ptr %ctx.field.5357, align 4
  %status.diagnostic.5358 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5358, align 4
  ret void
continue.5356:
  %depth.exceeded.5359 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5359, label %failure.5360, label %continue.5361
failure.5360:
  %ctx.field.5362 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 550, ptr %ctx.field.5362, align 4
  %status.diagnostic.5363 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5363, align 4
  ret void
continue.5361:
  %workspace.slot.5364 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5334, ptr %workspace.slot.5364, align 8
  %workspace.slot.5365 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5366 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 46, ptr %outputs, i32 1, ptr %workspace.slot.5365)
  switch i32 %record.make.status.5366, label %runtime.invalid.result.5372 [ i32 0, label %runtime.success.5367 i32 1, label %runtime.invalid.request.5368 i32 2, label %runtime.invalid.reference.5369 i32 3, label %runtime.scratch.capacity.5370 i32 4, label %runtime.retained.capacity.5371 ]
runtime.invalid.request.5368:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5369:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5370:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5371:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5372:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5367:
  %record.make.handle.5373 = load i64, ptr %workspace.slot.5365, align 8
  %ctx.field.5374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5375 = load i32, ptr %ctx.field.5374, align 4
  %steps.next.5376 = add i32 %steps.current.5375, 1
  store i32 %steps.next.5376, ptr %ctx.field.5374, align 4
  %steps.over.5377 = icmp ugt i32 %steps.next.5376, 10000
  br i1 %steps.over.5377, label %failure.5378, label %continue.5379
failure.5378:
  %ctx.field.5380 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 551, ptr %ctx.field.5380, align 4
  %status.diagnostic.5381 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5381, align 4
  ret void
continue.5379:
  %ctx.field.5382 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5383 = load i32, ptr %ctx.field.5382, align 4
  %steps.next.5384 = add i32 %steps.current.5383, 1
  store i32 %steps.next.5384, ptr %ctx.field.5382, align 4
  %steps.over.5385 = icmp ugt i32 %steps.next.5384, 10000
  br i1 %steps.over.5385, label %failure.5386, label %continue.5387
failure.5386:
  %ctx.field.5388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 552, ptr %ctx.field.5388, align 4
  %status.diagnostic.5389 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5389, align 4
  ret void
continue.5387:
  %ctx.field.5390 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5391 = load i32, ptr %ctx.field.5390, align 4
  %steps.next.5392 = add i32 %steps.current.5391, 1
  store i32 %steps.next.5392, ptr %ctx.field.5390, align 4
  %steps.over.5393 = icmp ugt i32 %steps.next.5392, 10000
  br i1 %steps.over.5393, label %failure.5394, label %continue.5395
failure.5394:
  %ctx.field.5396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 553, ptr %ctx.field.5396, align 4
  %status.diagnostic.5397 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5397, align 4
  ret void
continue.5395:
  %depth.exceeded.5398 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5398, label %failure.5399, label %continue.5400
failure.5399:
  %ctx.field.5401 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 554, ptr %ctx.field.5401, align 4
  %status.diagnostic.5402 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5402, align 4
  ret void
continue.5400:
  %workspace.slot.5403 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5373, ptr %workspace.slot.5403, align 8
  %workspace.slot.5404 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5405 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 47, ptr %outputs, i32 1, ptr %workspace.slot.5404)
  switch i32 %record.make.status.5405, label %runtime.invalid.result.5411 [ i32 0, label %runtime.success.5406 i32 1, label %runtime.invalid.request.5407 i32 2, label %runtime.invalid.reference.5408 i32 3, label %runtime.scratch.capacity.5409 i32 4, label %runtime.retained.capacity.5410 ]
runtime.invalid.request.5407:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5408:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5409:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5410:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5411:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5406:
  %record.make.handle.5412 = load i64, ptr %workspace.slot.5404, align 8
  %ctx.field.5413 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5414 = load i32, ptr %ctx.field.5413, align 4
  %steps.next.5415 = add i32 %steps.current.5414, 1
  store i32 %steps.next.5415, ptr %ctx.field.5413, align 4
  %steps.over.5416 = icmp ugt i32 %steps.next.5415, 10000
  br i1 %steps.over.5416, label %failure.5417, label %continue.5418
failure.5417:
  %ctx.field.5419 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 555, ptr %ctx.field.5419, align 4
  %status.diagnostic.5420 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5420, align 4
  ret void
continue.5418:
  %ctx.field.5421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5422 = load i32, ptr %ctx.field.5421, align 4
  %steps.next.5423 = add i32 %steps.current.5422, 1
  store i32 %steps.next.5423, ptr %ctx.field.5421, align 4
  %steps.over.5424 = icmp ugt i32 %steps.next.5423, 10000
  br i1 %steps.over.5424, label %failure.5425, label %continue.5426
failure.5425:
  %ctx.field.5427 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 556, ptr %ctx.field.5427, align 4
  %status.diagnostic.5428 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5428, align 4
  ret void
continue.5426:
  %ctx.field.5429 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5430 = load i32, ptr %ctx.field.5429, align 4
  %steps.next.5431 = add i32 %steps.current.5430, 1
  store i32 %steps.next.5431, ptr %ctx.field.5429, align 4
  %steps.over.5432 = icmp ugt i32 %steps.next.5431, 10000
  br i1 %steps.over.5432, label %failure.5433, label %continue.5434
failure.5433:
  %ctx.field.5435 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 557, ptr %ctx.field.5435, align 4
  %status.diagnostic.5436 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5436, align 4
  ret void
continue.5434:
  %depth.exceeded.5437 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5437, label %failure.5438, label %continue.5439
failure.5438:
  %ctx.field.5440 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 558, ptr %ctx.field.5440, align 4
  %status.diagnostic.5441 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5441, align 4
  ret void
continue.5439:
  %workspace.slot.5442 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5412, ptr %workspace.slot.5442, align 8
  %workspace.slot.5443 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5444 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 48, ptr %outputs, i32 1, ptr %workspace.slot.5443)
  switch i32 %record.make.status.5444, label %runtime.invalid.result.5450 [ i32 0, label %runtime.success.5445 i32 1, label %runtime.invalid.request.5446 i32 2, label %runtime.invalid.reference.5447 i32 3, label %runtime.scratch.capacity.5448 i32 4, label %runtime.retained.capacity.5449 ]
runtime.invalid.request.5446:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5447:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5448:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5449:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5450:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5445:
  %record.make.handle.5451 = load i64, ptr %workspace.slot.5443, align 8
  %ctx.field.5452 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5453 = load i32, ptr %ctx.field.5452, align 4
  %steps.next.5454 = add i32 %steps.current.5453, 1
  store i32 %steps.next.5454, ptr %ctx.field.5452, align 4
  %steps.over.5455 = icmp ugt i32 %steps.next.5454, 10000
  br i1 %steps.over.5455, label %failure.5456, label %continue.5457
failure.5456:
  %ctx.field.5458 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 559, ptr %ctx.field.5458, align 4
  %status.diagnostic.5459 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5459, align 4
  ret void
continue.5457:
  %ctx.field.5460 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5461 = load i32, ptr %ctx.field.5460, align 4
  %steps.next.5462 = add i32 %steps.current.5461, 1
  store i32 %steps.next.5462, ptr %ctx.field.5460, align 4
  %steps.over.5463 = icmp ugt i32 %steps.next.5462, 10000
  br i1 %steps.over.5463, label %failure.5464, label %continue.5465
failure.5464:
  %ctx.field.5466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 560, ptr %ctx.field.5466, align 4
  %status.diagnostic.5467 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5467, align 4
  ret void
continue.5465:
  %ctx.field.5468 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5469 = load i32, ptr %ctx.field.5468, align 4
  %steps.next.5470 = add i32 %steps.current.5469, 1
  store i32 %steps.next.5470, ptr %ctx.field.5468, align 4
  %steps.over.5471 = icmp ugt i32 %steps.next.5470, 10000
  br i1 %steps.over.5471, label %failure.5472, label %continue.5473
failure.5472:
  %ctx.field.5474 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 561, ptr %ctx.field.5474, align 4
  %status.diagnostic.5475 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5475, align 4
  ret void
continue.5473:
  %depth.exceeded.5476 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5476, label %failure.5477, label %continue.5478
failure.5477:
  %ctx.field.5479 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 562, ptr %ctx.field.5479, align 4
  %status.diagnostic.5480 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5480, align 4
  ret void
continue.5478:
  %workspace.slot.5481 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5451, ptr %workspace.slot.5481, align 8
  %workspace.slot.5482 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5483 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 50, ptr %outputs, i32 1, ptr %workspace.slot.5482)
  switch i32 %record.make.status.5483, label %runtime.invalid.result.5489 [ i32 0, label %runtime.success.5484 i32 1, label %runtime.invalid.request.5485 i32 2, label %runtime.invalid.reference.5486 i32 3, label %runtime.scratch.capacity.5487 i32 4, label %runtime.retained.capacity.5488 ]
runtime.invalid.request.5485:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5486:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5487:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5488:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5489:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5484:
  %record.make.handle.5490 = load i64, ptr %workspace.slot.5482, align 8
  %ctx.field.5491 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5492 = load i32, ptr %ctx.field.5491, align 4
  %steps.next.5493 = add i32 %steps.current.5492, 1
  store i32 %steps.next.5493, ptr %ctx.field.5491, align 4
  %steps.over.5494 = icmp ugt i32 %steps.next.5493, 10000
  br i1 %steps.over.5494, label %failure.5495, label %continue.5496
failure.5495:
  %ctx.field.5497 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 563, ptr %ctx.field.5497, align 4
  %status.diagnostic.5498 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5498, align 4
  ret void
continue.5496:
  %ctx.field.5499 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5500 = load i32, ptr %ctx.field.5499, align 4
  %steps.next.5501 = add i32 %steps.current.5500, 1
  store i32 %steps.next.5501, ptr %ctx.field.5499, align 4
  %steps.over.5502 = icmp ugt i32 %steps.next.5501, 10000
  br i1 %steps.over.5502, label %failure.5503, label %continue.5504
failure.5503:
  %ctx.field.5505 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 564, ptr %ctx.field.5505, align 4
  %status.diagnostic.5506 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5506, align 4
  ret void
continue.5504:
  %ctx.field.5507 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5508 = load i32, ptr %ctx.field.5507, align 4
  %steps.next.5509 = add i32 %steps.current.5508, 1
  store i32 %steps.next.5509, ptr %ctx.field.5507, align 4
  %steps.over.5510 = icmp ugt i32 %steps.next.5509, 10000
  br i1 %steps.over.5510, label %failure.5511, label %continue.5512
failure.5511:
  %ctx.field.5513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 565, ptr %ctx.field.5513, align 4
  %status.diagnostic.5514 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5514, align 4
  ret void
continue.5512:
  %depth.exceeded.5515 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5515, label %failure.5516, label %continue.5517
failure.5516:
  %ctx.field.5518 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 566, ptr %ctx.field.5518, align 4
  %status.diagnostic.5519 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5519, align 4
  ret void
continue.5517:
  %workspace.slot.5520 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5490, ptr %workspace.slot.5520, align 8
  %workspace.slot.5521 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5522 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 51, ptr %outputs, i32 1, ptr %workspace.slot.5521)
  switch i32 %record.make.status.5522, label %runtime.invalid.result.5528 [ i32 0, label %runtime.success.5523 i32 1, label %runtime.invalid.request.5524 i32 2, label %runtime.invalid.reference.5525 i32 3, label %runtime.scratch.capacity.5526 i32 4, label %runtime.retained.capacity.5527 ]
runtime.invalid.request.5524:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5525:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5526:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5527:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5528:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5523:
  %record.make.handle.5529 = load i64, ptr %workspace.slot.5521, align 8
  %ctx.field.5530 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5531 = load i32, ptr %ctx.field.5530, align 4
  %steps.next.5532 = add i32 %steps.current.5531, 1
  store i32 %steps.next.5532, ptr %ctx.field.5530, align 4
  %steps.over.5533 = icmp ugt i32 %steps.next.5532, 10000
  br i1 %steps.over.5533, label %failure.5534, label %continue.5535
failure.5534:
  %ctx.field.5536 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 567, ptr %ctx.field.5536, align 4
  %status.diagnostic.5537 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5537, align 4
  ret void
continue.5535:
  %ctx.field.5538 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5539 = load i32, ptr %ctx.field.5538, align 4
  %steps.next.5540 = add i32 %steps.current.5539, 1
  store i32 %steps.next.5540, ptr %ctx.field.5538, align 4
  %steps.over.5541 = icmp ugt i32 %steps.next.5540, 10000
  br i1 %steps.over.5541, label %failure.5542, label %continue.5543
failure.5542:
  %ctx.field.5544 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 568, ptr %ctx.field.5544, align 4
  %status.diagnostic.5545 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5545, align 4
  ret void
continue.5543:
  %ctx.field.5546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5547 = load i32, ptr %ctx.field.5546, align 4
  %steps.next.5548 = add i32 %steps.current.5547, 1
  store i32 %steps.next.5548, ptr %ctx.field.5546, align 4
  %steps.over.5549 = icmp ugt i32 %steps.next.5548, 10000
  br i1 %steps.over.5549, label %failure.5550, label %continue.5551
failure.5550:
  %ctx.field.5552 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 569, ptr %ctx.field.5552, align 4
  %status.diagnostic.5553 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5553, align 4
  ret void
continue.5551:
  %depth.exceeded.5554 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5554, label %failure.5555, label %continue.5556
failure.5555:
  %ctx.field.5557 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 570, ptr %ctx.field.5557, align 4
  %status.diagnostic.5558 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5558, align 4
  ret void
continue.5556:
  %workspace.slot.5559 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5529, ptr %workspace.slot.5559, align 8
  %workspace.slot.5560 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5561 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 52, ptr %outputs, i32 1, ptr %workspace.slot.5560)
  switch i32 %record.make.status.5561, label %runtime.invalid.result.5567 [ i32 0, label %runtime.success.5562 i32 1, label %runtime.invalid.request.5563 i32 2, label %runtime.invalid.reference.5564 i32 3, label %runtime.scratch.capacity.5565 i32 4, label %runtime.retained.capacity.5566 ]
runtime.invalid.request.5563:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5564:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5565:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5566:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5567:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5562:
  %record.make.handle.5568 = load i64, ptr %workspace.slot.5560, align 8
  %ctx.field.5569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5570 = load i32, ptr %ctx.field.5569, align 4
  %steps.next.5571 = add i32 %steps.current.5570, 1
  store i32 %steps.next.5571, ptr %ctx.field.5569, align 4
  %steps.over.5572 = icmp ugt i32 %steps.next.5571, 10000
  br i1 %steps.over.5572, label %failure.5573, label %continue.5574
failure.5573:
  %ctx.field.5575 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 571, ptr %ctx.field.5575, align 4
  %status.diagnostic.5576 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5576, align 4
  ret void
continue.5574:
  %ctx.field.5577 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5578 = load i32, ptr %ctx.field.5577, align 4
  %steps.next.5579 = add i32 %steps.current.5578, 1
  store i32 %steps.next.5579, ptr %ctx.field.5577, align 4
  %steps.over.5580 = icmp ugt i32 %steps.next.5579, 10000
  br i1 %steps.over.5580, label %failure.5581, label %continue.5582
failure.5581:
  %ctx.field.5583 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 572, ptr %ctx.field.5583, align 4
  %status.diagnostic.5584 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5584, align 4
  ret void
continue.5582:
  %ctx.field.5585 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5586 = load i32, ptr %ctx.field.5585, align 4
  %steps.next.5587 = add i32 %steps.current.5586, 1
  store i32 %steps.next.5587, ptr %ctx.field.5585, align 4
  %steps.over.5588 = icmp ugt i32 %steps.next.5587, 10000
  br i1 %steps.over.5588, label %failure.5589, label %continue.5590
failure.5589:
  %ctx.field.5591 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 573, ptr %ctx.field.5591, align 4
  %status.diagnostic.5592 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5592, align 4
  ret void
continue.5590:
  %depth.exceeded.5593 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5593, label %failure.5594, label %continue.5595
failure.5594:
  %ctx.field.5596 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 574, ptr %ctx.field.5596, align 4
  %status.diagnostic.5597 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5597, align 4
  ret void
continue.5595:
  %workspace.slot.5598 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5568, ptr %workspace.slot.5598, align 8
  %workspace.slot.5599 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5600 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 53, ptr %outputs, i32 1, ptr %workspace.slot.5599)
  switch i32 %record.make.status.5600, label %runtime.invalid.result.5606 [ i32 0, label %runtime.success.5601 i32 1, label %runtime.invalid.request.5602 i32 2, label %runtime.invalid.reference.5603 i32 3, label %runtime.scratch.capacity.5604 i32 4, label %runtime.retained.capacity.5605 ]
runtime.invalid.request.5602:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5603:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5604:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5605:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5606:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5601:
  %record.make.handle.5607 = load i64, ptr %workspace.slot.5599, align 8
  %ctx.field.5608 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5609 = load i32, ptr %ctx.field.5608, align 4
  %steps.next.5610 = add i32 %steps.current.5609, 1
  store i32 %steps.next.5610, ptr %ctx.field.5608, align 4
  %steps.over.5611 = icmp ugt i32 %steps.next.5610, 10000
  br i1 %steps.over.5611, label %failure.5612, label %continue.5613
failure.5612:
  %ctx.field.5614 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 575, ptr %ctx.field.5614, align 4
  %status.diagnostic.5615 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5615, align 4
  ret void
continue.5613:
  %ctx.field.5616 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5617 = load i32, ptr %ctx.field.5616, align 4
  %steps.next.5618 = add i32 %steps.current.5617, 1
  store i32 %steps.next.5618, ptr %ctx.field.5616, align 4
  %steps.over.5619 = icmp ugt i32 %steps.next.5618, 10000
  br i1 %steps.over.5619, label %failure.5620, label %continue.5621
failure.5620:
  %ctx.field.5622 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 576, ptr %ctx.field.5622, align 4
  %status.diagnostic.5623 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5623, align 4
  ret void
continue.5621:
  %ctx.field.5624 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5625 = load i32, ptr %ctx.field.5624, align 4
  %steps.next.5626 = add i32 %steps.current.5625, 1
  store i32 %steps.next.5626, ptr %ctx.field.5624, align 4
  %steps.over.5627 = icmp ugt i32 %steps.next.5626, 10000
  br i1 %steps.over.5627, label %failure.5628, label %continue.5629
failure.5628:
  %ctx.field.5630 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 577, ptr %ctx.field.5630, align 4
  %status.diagnostic.5631 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5631, align 4
  ret void
continue.5629:
  %depth.exceeded.5632 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5632, label %failure.5633, label %continue.5634
failure.5633:
  %ctx.field.5635 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 578, ptr %ctx.field.5635, align 4
  %status.diagnostic.5636 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5636, align 4
  ret void
continue.5634:
  %workspace.slot.5637 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5607, ptr %workspace.slot.5637, align 8
  %workspace.slot.5638 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5639 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 54, ptr %outputs, i32 1, ptr %workspace.slot.5638)
  switch i32 %record.make.status.5639, label %runtime.invalid.result.5645 [ i32 0, label %runtime.success.5640 i32 1, label %runtime.invalid.request.5641 i32 2, label %runtime.invalid.reference.5642 i32 3, label %runtime.scratch.capacity.5643 i32 4, label %runtime.retained.capacity.5644 ]
runtime.invalid.request.5641:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5642:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5643:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5644:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5645:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5640:
  %record.make.handle.5646 = load i64, ptr %workspace.slot.5638, align 8
  %ctx.field.5647 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5648 = load i32, ptr %ctx.field.5647, align 4
  %steps.next.5649 = add i32 %steps.current.5648, 1
  store i32 %steps.next.5649, ptr %ctx.field.5647, align 4
  %steps.over.5650 = icmp ugt i32 %steps.next.5649, 10000
  br i1 %steps.over.5650, label %failure.5651, label %continue.5652
failure.5651:
  %ctx.field.5653 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 579, ptr %ctx.field.5653, align 4
  %status.diagnostic.5654 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5654, align 4
  ret void
continue.5652:
  %ctx.field.5655 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5656 = load i32, ptr %ctx.field.5655, align 4
  %steps.next.5657 = add i32 %steps.current.5656, 1
  store i32 %steps.next.5657, ptr %ctx.field.5655, align 4
  %steps.over.5658 = icmp ugt i32 %steps.next.5657, 10000
  br i1 %steps.over.5658, label %failure.5659, label %continue.5660
failure.5659:
  %ctx.field.5661 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 580, ptr %ctx.field.5661, align 4
  %status.diagnostic.5662 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5662, align 4
  ret void
continue.5660:
  %ctx.field.5663 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5664 = load i32, ptr %ctx.field.5663, align 4
  %steps.next.5665 = add i32 %steps.current.5664, 1
  store i32 %steps.next.5665, ptr %ctx.field.5663, align 4
  %steps.over.5666 = icmp ugt i32 %steps.next.5665, 10000
  br i1 %steps.over.5666, label %failure.5667, label %continue.5668
failure.5667:
  %ctx.field.5669 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 581, ptr %ctx.field.5669, align 4
  %status.diagnostic.5670 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5670, align 4
  ret void
continue.5668:
  %depth.exceeded.5671 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5671, label %failure.5672, label %continue.5673
failure.5672:
  %ctx.field.5674 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 582, ptr %ctx.field.5674, align 4
  %status.diagnostic.5675 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5675, align 4
  ret void
continue.5673:
  %workspace.slot.5676 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5646, ptr %workspace.slot.5676, align 8
  %workspace.slot.5677 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5678 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 55, ptr %outputs, i32 1, ptr %workspace.slot.5677)
  switch i32 %record.make.status.5678, label %runtime.invalid.result.5684 [ i32 0, label %runtime.success.5679 i32 1, label %runtime.invalid.request.5680 i32 2, label %runtime.invalid.reference.5681 i32 3, label %runtime.scratch.capacity.5682 i32 4, label %runtime.retained.capacity.5683 ]
runtime.invalid.request.5680:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5681:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5682:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5683:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5684:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5679:
  %record.make.handle.5685 = load i64, ptr %workspace.slot.5677, align 8
  %ctx.field.5686 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5687 = load i32, ptr %ctx.field.5686, align 4
  %steps.next.5688 = add i32 %steps.current.5687, 1
  store i32 %steps.next.5688, ptr %ctx.field.5686, align 4
  %steps.over.5689 = icmp ugt i32 %steps.next.5688, 10000
  br i1 %steps.over.5689, label %failure.5690, label %continue.5691
failure.5690:
  %ctx.field.5692 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 583, ptr %ctx.field.5692, align 4
  %status.diagnostic.5693 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5693, align 4
  ret void
continue.5691:
  %ctx.field.5694 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5695 = load i32, ptr %ctx.field.5694, align 4
  %steps.next.5696 = add i32 %steps.current.5695, 1
  store i32 %steps.next.5696, ptr %ctx.field.5694, align 4
  %steps.over.5697 = icmp ugt i32 %steps.next.5696, 10000
  br i1 %steps.over.5697, label %failure.5698, label %continue.5699
failure.5698:
  %ctx.field.5700 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 584, ptr %ctx.field.5700, align 4
  %status.diagnostic.5701 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5701, align 4
  ret void
continue.5699:
  %ctx.field.5702 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5703 = load i32, ptr %ctx.field.5702, align 4
  %steps.next.5704 = add i32 %steps.current.5703, 1
  store i32 %steps.next.5704, ptr %ctx.field.5702, align 4
  %steps.over.5705 = icmp ugt i32 %steps.next.5704, 10000
  br i1 %steps.over.5705, label %failure.5706, label %continue.5707
failure.5706:
  %ctx.field.5708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 585, ptr %ctx.field.5708, align 4
  %status.diagnostic.5709 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5709, align 4
  ret void
continue.5707:
  %depth.exceeded.5710 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5710, label %failure.5711, label %continue.5712
failure.5711:
  %ctx.field.5713 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 586, ptr %ctx.field.5713, align 4
  %status.diagnostic.5714 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5714, align 4
  ret void
continue.5712:
  %workspace.slot.5715 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5685, ptr %workspace.slot.5715, align 8
  %workspace.slot.5716 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5717 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 56, ptr %outputs, i32 1, ptr %workspace.slot.5716)
  switch i32 %record.make.status.5717, label %runtime.invalid.result.5723 [ i32 0, label %runtime.success.5718 i32 1, label %runtime.invalid.request.5719 i32 2, label %runtime.invalid.reference.5720 i32 3, label %runtime.scratch.capacity.5721 i32 4, label %runtime.retained.capacity.5722 ]
runtime.invalid.request.5719:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5720:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5721:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5722:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5723:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5718:
  %record.make.handle.5724 = load i64, ptr %workspace.slot.5716, align 8
  %ctx.field.5725 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5726 = load i32, ptr %ctx.field.5725, align 4
  %steps.next.5727 = add i32 %steps.current.5726, 1
  store i32 %steps.next.5727, ptr %ctx.field.5725, align 4
  %steps.over.5728 = icmp ugt i32 %steps.next.5727, 10000
  br i1 %steps.over.5728, label %failure.5729, label %continue.5730
failure.5729:
  %ctx.field.5731 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 587, ptr %ctx.field.5731, align 4
  %status.diagnostic.5732 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5732, align 4
  ret void
continue.5730:
  %ctx.field.5733 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5734 = load i32, ptr %ctx.field.5733, align 4
  %steps.next.5735 = add i32 %steps.current.5734, 1
  store i32 %steps.next.5735, ptr %ctx.field.5733, align 4
  %steps.over.5736 = icmp ugt i32 %steps.next.5735, 10000
  br i1 %steps.over.5736, label %failure.5737, label %continue.5738
failure.5737:
  %ctx.field.5739 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 588, ptr %ctx.field.5739, align 4
  %status.diagnostic.5740 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5740, align 4
  ret void
continue.5738:
  %ctx.field.5741 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5742 = load i32, ptr %ctx.field.5741, align 4
  %steps.next.5743 = add i32 %steps.current.5742, 1
  store i32 %steps.next.5743, ptr %ctx.field.5741, align 4
  %steps.over.5744 = icmp ugt i32 %steps.next.5743, 10000
  br i1 %steps.over.5744, label %failure.5745, label %continue.5746
failure.5745:
  %ctx.field.5747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 589, ptr %ctx.field.5747, align 4
  %status.diagnostic.5748 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5748, align 4
  ret void
continue.5746:
  %depth.exceeded.5749 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5749, label %failure.5750, label %continue.5751
failure.5750:
  %ctx.field.5752 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 590, ptr %ctx.field.5752, align 4
  %status.diagnostic.5753 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5753, align 4
  ret void
continue.5751:
  %workspace.slot.5754 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5724, ptr %workspace.slot.5754, align 8
  %workspace.slot.5755 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5756 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 57, ptr %outputs, i32 1, ptr %workspace.slot.5755)
  switch i32 %record.make.status.5756, label %runtime.invalid.result.5762 [ i32 0, label %runtime.success.5757 i32 1, label %runtime.invalid.request.5758 i32 2, label %runtime.invalid.reference.5759 i32 3, label %runtime.scratch.capacity.5760 i32 4, label %runtime.retained.capacity.5761 ]
runtime.invalid.request.5758:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5759:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5760:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5761:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5762:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5757:
  %record.make.handle.5763 = load i64, ptr %workspace.slot.5755, align 8
  %ctx.field.5764 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5765 = load i32, ptr %ctx.field.5764, align 4
  %steps.next.5766 = add i32 %steps.current.5765, 1
  store i32 %steps.next.5766, ptr %ctx.field.5764, align 4
  %steps.over.5767 = icmp ugt i32 %steps.next.5766, 10000
  br i1 %steps.over.5767, label %failure.5768, label %continue.5769
failure.5768:
  %ctx.field.5770 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 591, ptr %ctx.field.5770, align 4
  %status.diagnostic.5771 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5771, align 4
  ret void
continue.5769:
  %ctx.field.5772 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5773 = load i32, ptr %ctx.field.5772, align 4
  %steps.next.5774 = add i32 %steps.current.5773, 1
  store i32 %steps.next.5774, ptr %ctx.field.5772, align 4
  %steps.over.5775 = icmp ugt i32 %steps.next.5774, 10000
  br i1 %steps.over.5775, label %failure.5776, label %continue.5777
failure.5776:
  %ctx.field.5778 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 592, ptr %ctx.field.5778, align 4
  %status.diagnostic.5779 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5779, align 4
  ret void
continue.5777:
  %ctx.field.5780 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5781 = load i32, ptr %ctx.field.5780, align 4
  %steps.next.5782 = add i32 %steps.current.5781, 1
  store i32 %steps.next.5782, ptr %ctx.field.5780, align 4
  %steps.over.5783 = icmp ugt i32 %steps.next.5782, 10000
  br i1 %steps.over.5783, label %failure.5784, label %continue.5785
failure.5784:
  %ctx.field.5786 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 593, ptr %ctx.field.5786, align 4
  %status.diagnostic.5787 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5787, align 4
  ret void
continue.5785:
  %depth.exceeded.5788 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5788, label %failure.5789, label %continue.5790
failure.5789:
  %ctx.field.5791 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 594, ptr %ctx.field.5791, align 4
  %status.diagnostic.5792 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5792, align 4
  ret void
continue.5790:
  %workspace.slot.5793 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5763, ptr %workspace.slot.5793, align 8
  %workspace.slot.5794 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5795 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 58, ptr %outputs, i32 1, ptr %workspace.slot.5794)
  switch i32 %record.make.status.5795, label %runtime.invalid.result.5801 [ i32 0, label %runtime.success.5796 i32 1, label %runtime.invalid.request.5797 i32 2, label %runtime.invalid.reference.5798 i32 3, label %runtime.scratch.capacity.5799 i32 4, label %runtime.retained.capacity.5800 ]
runtime.invalid.request.5797:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5798:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5799:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5800:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5801:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5796:
  %record.make.handle.5802 = load i64, ptr %workspace.slot.5794, align 8
  %ctx.field.5803 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5804 = load i32, ptr %ctx.field.5803, align 4
  %steps.next.5805 = add i32 %steps.current.5804, 1
  store i32 %steps.next.5805, ptr %ctx.field.5803, align 4
  %steps.over.5806 = icmp ugt i32 %steps.next.5805, 10000
  br i1 %steps.over.5806, label %failure.5807, label %continue.5808
failure.5807:
  %ctx.field.5809 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 595, ptr %ctx.field.5809, align 4
  %status.diagnostic.5810 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5810, align 4
  ret void
continue.5808:
  %ctx.field.5811 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5812 = load i32, ptr %ctx.field.5811, align 4
  %steps.next.5813 = add i32 %steps.current.5812, 1
  store i32 %steps.next.5813, ptr %ctx.field.5811, align 4
  %steps.over.5814 = icmp ugt i32 %steps.next.5813, 10000
  br i1 %steps.over.5814, label %failure.5815, label %continue.5816
failure.5815:
  %ctx.field.5817 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 596, ptr %ctx.field.5817, align 4
  %status.diagnostic.5818 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5818, align 4
  ret void
continue.5816:
  %ctx.field.5819 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5820 = load i32, ptr %ctx.field.5819, align 4
  %steps.next.5821 = add i32 %steps.current.5820, 1
  store i32 %steps.next.5821, ptr %ctx.field.5819, align 4
  %steps.over.5822 = icmp ugt i32 %steps.next.5821, 10000
  br i1 %steps.over.5822, label %failure.5823, label %continue.5824
failure.5823:
  %ctx.field.5825 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 597, ptr %ctx.field.5825, align 4
  %status.diagnostic.5826 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5826, align 4
  ret void
continue.5824:
  %depth.exceeded.5827 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5827, label %failure.5828, label %continue.5829
failure.5828:
  %ctx.field.5830 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 598, ptr %ctx.field.5830, align 4
  %status.diagnostic.5831 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5831, align 4
  ret void
continue.5829:
  %workspace.slot.5832 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5802, ptr %workspace.slot.5832, align 8
  %workspace.slot.5833 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5834 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 59, ptr %outputs, i32 1, ptr %workspace.slot.5833)
  switch i32 %record.make.status.5834, label %runtime.invalid.result.5840 [ i32 0, label %runtime.success.5835 i32 1, label %runtime.invalid.request.5836 i32 2, label %runtime.invalid.reference.5837 i32 3, label %runtime.scratch.capacity.5838 i32 4, label %runtime.retained.capacity.5839 ]
runtime.invalid.request.5836:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5837:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5838:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5839:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5840:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5835:
  %record.make.handle.5841 = load i64, ptr %workspace.slot.5833, align 8
  %ctx.field.5842 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5843 = load i32, ptr %ctx.field.5842, align 4
  %steps.next.5844 = add i32 %steps.current.5843, 1
  store i32 %steps.next.5844, ptr %ctx.field.5842, align 4
  %steps.over.5845 = icmp ugt i32 %steps.next.5844, 10000
  br i1 %steps.over.5845, label %failure.5846, label %continue.5847
failure.5846:
  %ctx.field.5848 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 599, ptr %ctx.field.5848, align 4
  %status.diagnostic.5849 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5849, align 4
  ret void
continue.5847:
  %ctx.field.5850 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5851 = load i32, ptr %ctx.field.5850, align 4
  %steps.next.5852 = add i32 %steps.current.5851, 1
  store i32 %steps.next.5852, ptr %ctx.field.5850, align 4
  %steps.over.5853 = icmp ugt i32 %steps.next.5852, 10000
  br i1 %steps.over.5853, label %failure.5854, label %continue.5855
failure.5854:
  %ctx.field.5856 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 600, ptr %ctx.field.5856, align 4
  %status.diagnostic.5857 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5857, align 4
  ret void
continue.5855:
  %ctx.field.5858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5859 = load i32, ptr %ctx.field.5858, align 4
  %steps.next.5860 = add i32 %steps.current.5859, 1
  store i32 %steps.next.5860, ptr %ctx.field.5858, align 4
  %steps.over.5861 = icmp ugt i32 %steps.next.5860, 10000
  br i1 %steps.over.5861, label %failure.5862, label %continue.5863
failure.5862:
  %ctx.field.5864 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 601, ptr %ctx.field.5864, align 4
  %status.diagnostic.5865 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5865, align 4
  ret void
continue.5863:
  %depth.exceeded.5866 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5866, label %failure.5867, label %continue.5868
failure.5867:
  %ctx.field.5869 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 602, ptr %ctx.field.5869, align 4
  %status.diagnostic.5870 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5870, align 4
  ret void
continue.5868:
  %workspace.slot.5871 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5841, ptr %workspace.slot.5871, align 8
  %workspace.slot.5872 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5873 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 61, ptr %outputs, i32 1, ptr %workspace.slot.5872)
  switch i32 %record.make.status.5873, label %runtime.invalid.result.5879 [ i32 0, label %runtime.success.5874 i32 1, label %runtime.invalid.request.5875 i32 2, label %runtime.invalid.reference.5876 i32 3, label %runtime.scratch.capacity.5877 i32 4, label %runtime.retained.capacity.5878 ]
runtime.invalid.request.5875:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5876:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5877:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5878:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5879:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5874:
  %record.make.handle.5880 = load i64, ptr %workspace.slot.5872, align 8
  %ctx.field.5881 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5882 = load i32, ptr %ctx.field.5881, align 4
  %steps.next.5883 = add i32 %steps.current.5882, 1
  store i32 %steps.next.5883, ptr %ctx.field.5881, align 4
  %steps.over.5884 = icmp ugt i32 %steps.next.5883, 10000
  br i1 %steps.over.5884, label %failure.5885, label %continue.5886
failure.5885:
  %ctx.field.5887 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 603, ptr %ctx.field.5887, align 4
  %status.diagnostic.5888 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5888, align 4
  ret void
continue.5886:
  %ctx.field.5889 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5890 = load i32, ptr %ctx.field.5889, align 4
  %steps.next.5891 = add i32 %steps.current.5890, 1
  store i32 %steps.next.5891, ptr %ctx.field.5889, align 4
  %steps.over.5892 = icmp ugt i32 %steps.next.5891, 10000
  br i1 %steps.over.5892, label %failure.5893, label %continue.5894
failure.5893:
  %ctx.field.5895 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 604, ptr %ctx.field.5895, align 4
  %status.diagnostic.5896 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5896, align 4
  ret void
continue.5894:
  %ctx.field.5897 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5898 = load i32, ptr %ctx.field.5897, align 4
  %steps.next.5899 = add i32 %steps.current.5898, 1
  store i32 %steps.next.5899, ptr %ctx.field.5897, align 4
  %steps.over.5900 = icmp ugt i32 %steps.next.5899, 10000
  br i1 %steps.over.5900, label %failure.5901, label %continue.5902
failure.5901:
  %ctx.field.5903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 605, ptr %ctx.field.5903, align 4
  %status.diagnostic.5904 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5904, align 4
  ret void
continue.5902:
  %depth.exceeded.5905 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5905, label %failure.5906, label %continue.5907
failure.5906:
  %ctx.field.5908 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 606, ptr %ctx.field.5908, align 4
  %status.diagnostic.5909 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5909, align 4
  ret void
continue.5907:
  %workspace.slot.5910 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5880, ptr %workspace.slot.5910, align 8
  %workspace.slot.5911 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5912 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 62, ptr %outputs, i32 1, ptr %workspace.slot.5911)
  switch i32 %record.make.status.5912, label %runtime.invalid.result.5918 [ i32 0, label %runtime.success.5913 i32 1, label %runtime.invalid.request.5914 i32 2, label %runtime.invalid.reference.5915 i32 3, label %runtime.scratch.capacity.5916 i32 4, label %runtime.retained.capacity.5917 ]
runtime.invalid.request.5914:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5915:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5916:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5917:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5918:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5913:
  %record.make.handle.5919 = load i64, ptr %workspace.slot.5911, align 8
  %ctx.field.5920 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5921 = load i32, ptr %ctx.field.5920, align 4
  %steps.next.5922 = add i32 %steps.current.5921, 1
  store i32 %steps.next.5922, ptr %ctx.field.5920, align 4
  %steps.over.5923 = icmp ugt i32 %steps.next.5922, 10000
  br i1 %steps.over.5923, label %failure.5924, label %continue.5925
failure.5924:
  %ctx.field.5926 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 607, ptr %ctx.field.5926, align 4
  %status.diagnostic.5927 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5927, align 4
  ret void
continue.5925:
  %ctx.field.5928 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5929 = load i32, ptr %ctx.field.5928, align 4
  %steps.next.5930 = add i32 %steps.current.5929, 1
  store i32 %steps.next.5930, ptr %ctx.field.5928, align 4
  %steps.over.5931 = icmp ugt i32 %steps.next.5930, 10000
  br i1 %steps.over.5931, label %failure.5932, label %continue.5933
failure.5932:
  %ctx.field.5934 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 608, ptr %ctx.field.5934, align 4
  %status.diagnostic.5935 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5935, align 4
  ret void
continue.5933:
  %ctx.field.5936 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5937 = load i32, ptr %ctx.field.5936, align 4
  %steps.next.5938 = add i32 %steps.current.5937, 1
  store i32 %steps.next.5938, ptr %ctx.field.5936, align 4
  %steps.over.5939 = icmp ugt i32 %steps.next.5938, 10000
  br i1 %steps.over.5939, label %failure.5940, label %continue.5941
failure.5940:
  %ctx.field.5942 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 609, ptr %ctx.field.5942, align 4
  %status.diagnostic.5943 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5943, align 4
  ret void
continue.5941:
  %depth.exceeded.5944 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5944, label %failure.5945, label %continue.5946
failure.5945:
  %ctx.field.5947 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 610, ptr %ctx.field.5947, align 4
  %status.diagnostic.5948 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5948, align 4
  ret void
continue.5946:
  %workspace.slot.5949 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5919, ptr %workspace.slot.5949, align 8
  %workspace.slot.5950 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5951 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 63, ptr %outputs, i32 1, ptr %workspace.slot.5950)
  switch i32 %record.make.status.5951, label %runtime.invalid.result.5957 [ i32 0, label %runtime.success.5952 i32 1, label %runtime.invalid.request.5953 i32 2, label %runtime.invalid.reference.5954 i32 3, label %runtime.scratch.capacity.5955 i32 4, label %runtime.retained.capacity.5956 ]
runtime.invalid.request.5953:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5954:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5955:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5956:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5957:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5952:
  %record.make.handle.5958 = load i64, ptr %workspace.slot.5950, align 8
  %ctx.field.5959 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5960 = load i32, ptr %ctx.field.5959, align 4
  %steps.next.5961 = add i32 %steps.current.5960, 1
  store i32 %steps.next.5961, ptr %ctx.field.5959, align 4
  %steps.over.5962 = icmp ugt i32 %steps.next.5961, 10000
  br i1 %steps.over.5962, label %failure.5963, label %continue.5964
failure.5963:
  %ctx.field.5965 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 611, ptr %ctx.field.5965, align 4
  %status.diagnostic.5966 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5966, align 4
  ret void
continue.5964:
  %ctx.field.5967 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5968 = load i32, ptr %ctx.field.5967, align 4
  %steps.next.5969 = add i32 %steps.current.5968, 1
  store i32 %steps.next.5969, ptr %ctx.field.5967, align 4
  %steps.over.5970 = icmp ugt i32 %steps.next.5969, 10000
  br i1 %steps.over.5970, label %failure.5971, label %continue.5972
failure.5971:
  %ctx.field.5973 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 612, ptr %ctx.field.5973, align 4
  %status.diagnostic.5974 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5974, align 4
  ret void
continue.5972:
  %ctx.field.5975 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5976 = load i32, ptr %ctx.field.5975, align 4
  %steps.next.5977 = add i32 %steps.current.5976, 1
  store i32 %steps.next.5977, ptr %ctx.field.5975, align 4
  %steps.over.5978 = icmp ugt i32 %steps.next.5977, 10000
  br i1 %steps.over.5978, label %failure.5979, label %continue.5980
failure.5979:
  %ctx.field.5981 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 613, ptr %ctx.field.5981, align 4
  %status.diagnostic.5982 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5982, align 4
  ret void
continue.5980:
  %depth.exceeded.5983 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5983, label %failure.5984, label %continue.5985
failure.5984:
  %ctx.field.5986 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 614, ptr %ctx.field.5986, align 4
  %status.diagnostic.5987 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5987, align 4
  ret void
continue.5985:
  %workspace.slot.5988 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5958, ptr %workspace.slot.5988, align 8
  %workspace.slot.5989 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5990 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 64, ptr %outputs, i32 1, ptr %workspace.slot.5989)
  switch i32 %record.make.status.5990, label %runtime.invalid.result.5996 [ i32 0, label %runtime.success.5991 i32 1, label %runtime.invalid.request.5992 i32 2, label %runtime.invalid.reference.5993 i32 3, label %runtime.scratch.capacity.5994 i32 4, label %runtime.retained.capacity.5995 ]
runtime.invalid.request.5992:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5993:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5994:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5995:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5996:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5991:
  %record.make.handle.5997 = load i64, ptr %workspace.slot.5989, align 8
  %ctx.field.5998 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5999 = load i32, ptr %ctx.field.5998, align 4
  %steps.next.6000 = add i32 %steps.current.5999, 1
  store i32 %steps.next.6000, ptr %ctx.field.5998, align 4
  %steps.over.6001 = icmp ugt i32 %steps.next.6000, 10000
  br i1 %steps.over.6001, label %failure.6002, label %continue.6003
failure.6002:
  %ctx.field.6004 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 615, ptr %ctx.field.6004, align 4
  %status.diagnostic.6005 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6005, align 4
  ret void
continue.6003:
  %ctx.field.6006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6007 = load i32, ptr %ctx.field.6006, align 4
  %steps.next.6008 = add i32 %steps.current.6007, 1
  store i32 %steps.next.6008, ptr %ctx.field.6006, align 4
  %steps.over.6009 = icmp ugt i32 %steps.next.6008, 10000
  br i1 %steps.over.6009, label %failure.6010, label %continue.6011
failure.6010:
  %ctx.field.6012 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 616, ptr %ctx.field.6012, align 4
  %status.diagnostic.6013 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6013, align 4
  ret void
continue.6011:
  %ctx.field.6014 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6015 = load i32, ptr %ctx.field.6014, align 4
  %steps.next.6016 = add i32 %steps.current.6015, 1
  store i32 %steps.next.6016, ptr %ctx.field.6014, align 4
  %steps.over.6017 = icmp ugt i32 %steps.next.6016, 10000
  br i1 %steps.over.6017, label %failure.6018, label %continue.6019
failure.6018:
  %ctx.field.6020 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 617, ptr %ctx.field.6020, align 4
  %status.diagnostic.6021 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6021, align 4
  ret void
continue.6019:
  %depth.exceeded.6022 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6022, label %failure.6023, label %continue.6024
failure.6023:
  %ctx.field.6025 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 618, ptr %ctx.field.6025, align 4
  %status.diagnostic.6026 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6026, align 4
  ret void
continue.6024:
  %workspace.slot.6027 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5997, ptr %workspace.slot.6027, align 8
  %workspace.slot.6028 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6029 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 65, ptr %outputs, i32 1, ptr %workspace.slot.6028)
  switch i32 %record.make.status.6029, label %runtime.invalid.result.6035 [ i32 0, label %runtime.success.6030 i32 1, label %runtime.invalid.request.6031 i32 2, label %runtime.invalid.reference.6032 i32 3, label %runtime.scratch.capacity.6033 i32 4, label %runtime.retained.capacity.6034 ]
runtime.invalid.request.6031:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6032:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6033:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6034:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6035:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6030:
  %record.make.handle.6036 = load i64, ptr %workspace.slot.6028, align 8
  %ctx.field.6037 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6038 = load i32, ptr %ctx.field.6037, align 4
  %steps.next.6039 = add i32 %steps.current.6038, 1
  store i32 %steps.next.6039, ptr %ctx.field.6037, align 4
  %steps.over.6040 = icmp ugt i32 %steps.next.6039, 10000
  br i1 %steps.over.6040, label %failure.6041, label %continue.6042
failure.6041:
  %ctx.field.6043 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 619, ptr %ctx.field.6043, align 4
  %status.diagnostic.6044 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6044, align 4
  ret void
continue.6042:
  %ctx.field.6045 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6046 = load i32, ptr %ctx.field.6045, align 4
  %steps.next.6047 = add i32 %steps.current.6046, 1
  store i32 %steps.next.6047, ptr %ctx.field.6045, align 4
  %steps.over.6048 = icmp ugt i32 %steps.next.6047, 10000
  br i1 %steps.over.6048, label %failure.6049, label %continue.6050
failure.6049:
  %ctx.field.6051 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 620, ptr %ctx.field.6051, align 4
  %status.diagnostic.6052 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6052, align 4
  ret void
continue.6050:
  %ctx.field.6053 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6054 = load i32, ptr %ctx.field.6053, align 4
  %steps.next.6055 = add i32 %steps.current.6054, 1
  store i32 %steps.next.6055, ptr %ctx.field.6053, align 4
  %steps.over.6056 = icmp ugt i32 %steps.next.6055, 10000
  br i1 %steps.over.6056, label %failure.6057, label %continue.6058
failure.6057:
  %ctx.field.6059 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 621, ptr %ctx.field.6059, align 4
  %status.diagnostic.6060 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6060, align 4
  ret void
continue.6058:
  %depth.exceeded.6061 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6061, label %failure.6062, label %continue.6063
failure.6062:
  %ctx.field.6064 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 622, ptr %ctx.field.6064, align 4
  %status.diagnostic.6065 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6065, align 4
  ret void
continue.6063:
  %workspace.slot.6066 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6036, ptr %workspace.slot.6066, align 8
  %workspace.slot.6067 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6068 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 66, ptr %outputs, i32 1, ptr %workspace.slot.6067)
  switch i32 %record.make.status.6068, label %runtime.invalid.result.6074 [ i32 0, label %runtime.success.6069 i32 1, label %runtime.invalid.request.6070 i32 2, label %runtime.invalid.reference.6071 i32 3, label %runtime.scratch.capacity.6072 i32 4, label %runtime.retained.capacity.6073 ]
runtime.invalid.request.6070:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6071:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6072:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6073:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6074:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6069:
  %record.make.handle.6075 = load i64, ptr %workspace.slot.6067, align 8
  %ctx.field.6076 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6077 = load i32, ptr %ctx.field.6076, align 4
  %steps.next.6078 = add i32 %steps.current.6077, 1
  store i32 %steps.next.6078, ptr %ctx.field.6076, align 4
  %steps.over.6079 = icmp ugt i32 %steps.next.6078, 10000
  br i1 %steps.over.6079, label %failure.6080, label %continue.6081
failure.6080:
  %ctx.field.6082 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 623, ptr %ctx.field.6082, align 4
  %status.diagnostic.6083 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6083, align 4
  ret void
continue.6081:
  %ctx.field.6084 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6085 = load i32, ptr %ctx.field.6084, align 4
  %steps.next.6086 = add i32 %steps.current.6085, 1
  store i32 %steps.next.6086, ptr %ctx.field.6084, align 4
  %steps.over.6087 = icmp ugt i32 %steps.next.6086, 10000
  br i1 %steps.over.6087, label %failure.6088, label %continue.6089
failure.6088:
  %ctx.field.6090 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 624, ptr %ctx.field.6090, align 4
  %status.diagnostic.6091 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6091, align 4
  ret void
continue.6089:
  %ctx.field.6092 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6093 = load i32, ptr %ctx.field.6092, align 4
  %steps.next.6094 = add i32 %steps.current.6093, 1
  store i32 %steps.next.6094, ptr %ctx.field.6092, align 4
  %steps.over.6095 = icmp ugt i32 %steps.next.6094, 10000
  br i1 %steps.over.6095, label %failure.6096, label %continue.6097
failure.6096:
  %ctx.field.6098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 625, ptr %ctx.field.6098, align 4
  %status.diagnostic.6099 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6099, align 4
  ret void
continue.6097:
  %depth.exceeded.6100 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6100, label %failure.6101, label %continue.6102
failure.6101:
  %ctx.field.6103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 626, ptr %ctx.field.6103, align 4
  %status.diagnostic.6104 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6104, align 4
  ret void
continue.6102:
  %workspace.slot.6105 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6075, ptr %workspace.slot.6105, align 8
  %workspace.slot.6106 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6107 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 67, ptr %outputs, i32 1, ptr %workspace.slot.6106)
  switch i32 %record.make.status.6107, label %runtime.invalid.result.6113 [ i32 0, label %runtime.success.6108 i32 1, label %runtime.invalid.request.6109 i32 2, label %runtime.invalid.reference.6110 i32 3, label %runtime.scratch.capacity.6111 i32 4, label %runtime.retained.capacity.6112 ]
runtime.invalid.request.6109:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6110:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6111:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6112:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6113:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6108:
  %record.make.handle.6114 = load i64, ptr %workspace.slot.6106, align 8
  %ctx.field.6115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6116 = load i32, ptr %ctx.field.6115, align 4
  %steps.next.6117 = add i32 %steps.current.6116, 1
  store i32 %steps.next.6117, ptr %ctx.field.6115, align 4
  %steps.over.6118 = icmp ugt i32 %steps.next.6117, 10000
  br i1 %steps.over.6118, label %failure.6119, label %continue.6120
failure.6119:
  %ctx.field.6121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 627, ptr %ctx.field.6121, align 4
  %status.diagnostic.6122 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6122, align 4
  ret void
continue.6120:
  %ctx.field.6123 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6124 = load i32, ptr %ctx.field.6123, align 4
  %steps.next.6125 = add i32 %steps.current.6124, 1
  store i32 %steps.next.6125, ptr %ctx.field.6123, align 4
  %steps.over.6126 = icmp ugt i32 %steps.next.6125, 10000
  br i1 %steps.over.6126, label %failure.6127, label %continue.6128
failure.6127:
  %ctx.field.6129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 628, ptr %ctx.field.6129, align 4
  %status.diagnostic.6130 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6130, align 4
  ret void
continue.6128:
  %ctx.field.6131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6132 = load i32, ptr %ctx.field.6131, align 4
  %steps.next.6133 = add i32 %steps.current.6132, 1
  store i32 %steps.next.6133, ptr %ctx.field.6131, align 4
  %steps.over.6134 = icmp ugt i32 %steps.next.6133, 10000
  br i1 %steps.over.6134, label %failure.6135, label %continue.6136
failure.6135:
  %ctx.field.6137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 629, ptr %ctx.field.6137, align 4
  %status.diagnostic.6138 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6138, align 4
  ret void
continue.6136:
  %depth.exceeded.6139 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6139, label %failure.6140, label %continue.6141
failure.6140:
  %ctx.field.6142 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 630, ptr %ctx.field.6142, align 4
  %status.diagnostic.6143 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6143, align 4
  ret void
continue.6141:
  %workspace.slot.6144 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6114, ptr %workspace.slot.6144, align 8
  %workspace.slot.6145 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6146 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 68, ptr %outputs, i32 1, ptr %workspace.slot.6145)
  switch i32 %record.make.status.6146, label %runtime.invalid.result.6152 [ i32 0, label %runtime.success.6147 i32 1, label %runtime.invalid.request.6148 i32 2, label %runtime.invalid.reference.6149 i32 3, label %runtime.scratch.capacity.6150 i32 4, label %runtime.retained.capacity.6151 ]
runtime.invalid.request.6148:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6149:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6150:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6151:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6152:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6147:
  %record.make.handle.6153 = load i64, ptr %workspace.slot.6145, align 8
  %ctx.field.6154 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6155 = load i32, ptr %ctx.field.6154, align 4
  %steps.next.6156 = add i32 %steps.current.6155, 1
  store i32 %steps.next.6156, ptr %ctx.field.6154, align 4
  %steps.over.6157 = icmp ugt i32 %steps.next.6156, 10000
  br i1 %steps.over.6157, label %failure.6158, label %continue.6159
failure.6158:
  %ctx.field.6160 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 631, ptr %ctx.field.6160, align 4
  %status.diagnostic.6161 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6161, align 4
  ret void
continue.6159:
  %ctx.field.6162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6163 = load i32, ptr %ctx.field.6162, align 4
  %steps.next.6164 = add i32 %steps.current.6163, 1
  store i32 %steps.next.6164, ptr %ctx.field.6162, align 4
  %steps.over.6165 = icmp ugt i32 %steps.next.6164, 10000
  br i1 %steps.over.6165, label %failure.6166, label %continue.6167
failure.6166:
  %ctx.field.6168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 632, ptr %ctx.field.6168, align 4
  %status.diagnostic.6169 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6169, align 4
  ret void
continue.6167:
  %ctx.field.6170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6171 = load i32, ptr %ctx.field.6170, align 4
  %steps.next.6172 = add i32 %steps.current.6171, 1
  store i32 %steps.next.6172, ptr %ctx.field.6170, align 4
  %steps.over.6173 = icmp ugt i32 %steps.next.6172, 10000
  br i1 %steps.over.6173, label %failure.6174, label %continue.6175
failure.6174:
  %ctx.field.6176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 633, ptr %ctx.field.6176, align 4
  %status.diagnostic.6177 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6177, align 4
  ret void
continue.6175:
  %depth.exceeded.6178 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6178, label %failure.6179, label %continue.6180
failure.6179:
  %ctx.field.6181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 634, ptr %ctx.field.6181, align 4
  %status.diagnostic.6182 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6182, align 4
  ret void
continue.6180:
  %workspace.slot.6183 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6153, ptr %workspace.slot.6183, align 8
  %workspace.slot.6184 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6185 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 69, ptr %outputs, i32 1, ptr %workspace.slot.6184)
  switch i32 %record.make.status.6185, label %runtime.invalid.result.6191 [ i32 0, label %runtime.success.6186 i32 1, label %runtime.invalid.request.6187 i32 2, label %runtime.invalid.reference.6188 i32 3, label %runtime.scratch.capacity.6189 i32 4, label %runtime.retained.capacity.6190 ]
runtime.invalid.request.6187:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6188:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6189:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6190:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6191:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6186:
  %record.make.handle.6192 = load i64, ptr %workspace.slot.6184, align 8
  %ctx.field.6193 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6194 = load i32, ptr %ctx.field.6193, align 4
  %steps.next.6195 = add i32 %steps.current.6194, 1
  store i32 %steps.next.6195, ptr %ctx.field.6193, align 4
  %steps.over.6196 = icmp ugt i32 %steps.next.6195, 10000
  br i1 %steps.over.6196, label %failure.6197, label %continue.6198
failure.6197:
  %ctx.field.6199 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 635, ptr %ctx.field.6199, align 4
  %status.diagnostic.6200 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6200, align 4
  ret void
continue.6198:
  %ctx.field.6201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6202 = load i32, ptr %ctx.field.6201, align 4
  %steps.next.6203 = add i32 %steps.current.6202, 1
  store i32 %steps.next.6203, ptr %ctx.field.6201, align 4
  %steps.over.6204 = icmp ugt i32 %steps.next.6203, 10000
  br i1 %steps.over.6204, label %failure.6205, label %continue.6206
failure.6205:
  %ctx.field.6207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 636, ptr %ctx.field.6207, align 4
  %status.diagnostic.6208 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6208, align 4
  ret void
continue.6206:
  %ctx.field.6209 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6210 = load i32, ptr %ctx.field.6209, align 4
  %steps.next.6211 = add i32 %steps.current.6210, 1
  store i32 %steps.next.6211, ptr %ctx.field.6209, align 4
  %steps.over.6212 = icmp ugt i32 %steps.next.6211, 10000
  br i1 %steps.over.6212, label %failure.6213, label %continue.6214
failure.6213:
  %ctx.field.6215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 637, ptr %ctx.field.6215, align 4
  %status.diagnostic.6216 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6216, align 4
  ret void
continue.6214:
  %depth.exceeded.6217 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6217, label %failure.6218, label %continue.6219
failure.6218:
  %ctx.field.6220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 638, ptr %ctx.field.6220, align 4
  %status.diagnostic.6221 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6221, align 4
  ret void
continue.6219:
  %workspace.slot.6222 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6192, ptr %workspace.slot.6222, align 8
  %workspace.slot.6223 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6224 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 70, ptr %outputs, i32 1, ptr %workspace.slot.6223)
  switch i32 %record.make.status.6224, label %runtime.invalid.result.6230 [ i32 0, label %runtime.success.6225 i32 1, label %runtime.invalid.request.6226 i32 2, label %runtime.invalid.reference.6227 i32 3, label %runtime.scratch.capacity.6228 i32 4, label %runtime.retained.capacity.6229 ]
runtime.invalid.request.6226:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6227:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6228:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6229:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6230:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6225:
  %record.make.handle.6231 = load i64, ptr %workspace.slot.6223, align 8
  %ctx.field.6232 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6233 = load i32, ptr %ctx.field.6232, align 4
  %steps.next.6234 = add i32 %steps.current.6233, 1
  store i32 %steps.next.6234, ptr %ctx.field.6232, align 4
  %steps.over.6235 = icmp ugt i32 %steps.next.6234, 10000
  br i1 %steps.over.6235, label %failure.6236, label %continue.6237
failure.6236:
  %ctx.field.6238 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 639, ptr %ctx.field.6238, align 4
  %status.diagnostic.6239 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6239, align 4
  ret void
continue.6237:
  %ctx.field.6240 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6241 = load i32, ptr %ctx.field.6240, align 4
  %steps.next.6242 = add i32 %steps.current.6241, 1
  store i32 %steps.next.6242, ptr %ctx.field.6240, align 4
  %steps.over.6243 = icmp ugt i32 %steps.next.6242, 10000
  br i1 %steps.over.6243, label %failure.6244, label %continue.6245
failure.6244:
  %ctx.field.6246 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 640, ptr %ctx.field.6246, align 4
  %status.diagnostic.6247 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6247, align 4
  ret void
continue.6245:
  %ctx.field.6248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6249 = load i32, ptr %ctx.field.6248, align 4
  %steps.next.6250 = add i32 %steps.current.6249, 1
  store i32 %steps.next.6250, ptr %ctx.field.6248, align 4
  %steps.over.6251 = icmp ugt i32 %steps.next.6250, 10000
  br i1 %steps.over.6251, label %failure.6252, label %continue.6253
failure.6252:
  %ctx.field.6254 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 641, ptr %ctx.field.6254, align 4
  %status.diagnostic.6255 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6255, align 4
  ret void
continue.6253:
  %depth.exceeded.6256 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6256, label %failure.6257, label %continue.6258
failure.6257:
  %ctx.field.6259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 642, ptr %ctx.field.6259, align 4
  %status.diagnostic.6260 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6260, align 4
  ret void
continue.6258:
  %workspace.slot.6261 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6231, ptr %workspace.slot.6261, align 8
  %workspace.slot.6262 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6263 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 72, ptr %outputs, i32 1, ptr %workspace.slot.6262)
  switch i32 %record.make.status.6263, label %runtime.invalid.result.6269 [ i32 0, label %runtime.success.6264 i32 1, label %runtime.invalid.request.6265 i32 2, label %runtime.invalid.reference.6266 i32 3, label %runtime.scratch.capacity.6267 i32 4, label %runtime.retained.capacity.6268 ]
runtime.invalid.request.6265:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6266:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6267:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6268:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6269:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6264:
  %record.make.handle.6270 = load i64, ptr %workspace.slot.6262, align 8
  %ctx.field.6271 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6272 = load i32, ptr %ctx.field.6271, align 4
  %steps.next.6273 = add i32 %steps.current.6272, 1
  store i32 %steps.next.6273, ptr %ctx.field.6271, align 4
  %steps.over.6274 = icmp ugt i32 %steps.next.6273, 10000
  br i1 %steps.over.6274, label %failure.6275, label %continue.6276
failure.6275:
  %ctx.field.6277 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 643, ptr %ctx.field.6277, align 4
  %status.diagnostic.6278 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6278, align 4
  ret void
continue.6276:
  %ctx.field.6279 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6280 = load i32, ptr %ctx.field.6279, align 4
  %steps.next.6281 = add i32 %steps.current.6280, 1
  store i32 %steps.next.6281, ptr %ctx.field.6279, align 4
  %steps.over.6282 = icmp ugt i32 %steps.next.6281, 10000
  br i1 %steps.over.6282, label %failure.6283, label %continue.6284
failure.6283:
  %ctx.field.6285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 644, ptr %ctx.field.6285, align 4
  %status.diagnostic.6286 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6286, align 4
  ret void
continue.6284:
  %ctx.field.6287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6288 = load i32, ptr %ctx.field.6287, align 4
  %steps.next.6289 = add i32 %steps.current.6288, 1
  store i32 %steps.next.6289, ptr %ctx.field.6287, align 4
  %steps.over.6290 = icmp ugt i32 %steps.next.6289, 10000
  br i1 %steps.over.6290, label %failure.6291, label %continue.6292
failure.6291:
  %ctx.field.6293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 645, ptr %ctx.field.6293, align 4
  %status.diagnostic.6294 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6294, align 4
  ret void
continue.6292:
  %depth.exceeded.6295 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6295, label %failure.6296, label %continue.6297
failure.6296:
  %ctx.field.6298 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 646, ptr %ctx.field.6298, align 4
  %status.diagnostic.6299 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6299, align 4
  ret void
continue.6297:
  %workspace.slot.6300 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6270, ptr %workspace.slot.6300, align 8
  %workspace.slot.6301 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6302 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 73, ptr %outputs, i32 1, ptr %workspace.slot.6301)
  switch i32 %record.make.status.6302, label %runtime.invalid.result.6308 [ i32 0, label %runtime.success.6303 i32 1, label %runtime.invalid.request.6304 i32 2, label %runtime.invalid.reference.6305 i32 3, label %runtime.scratch.capacity.6306 i32 4, label %runtime.retained.capacity.6307 ]
runtime.invalid.request.6304:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6305:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6306:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6307:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6308:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6303:
  %record.make.handle.6309 = load i64, ptr %workspace.slot.6301, align 8
  %ctx.field.6310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6311 = load i32, ptr %ctx.field.6310, align 4
  %steps.next.6312 = add i32 %steps.current.6311, 1
  store i32 %steps.next.6312, ptr %ctx.field.6310, align 4
  %steps.over.6313 = icmp ugt i32 %steps.next.6312, 10000
  br i1 %steps.over.6313, label %failure.6314, label %continue.6315
failure.6314:
  %ctx.field.6316 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 647, ptr %ctx.field.6316, align 4
  %status.diagnostic.6317 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6317, align 4
  ret void
continue.6315:
  %ctx.field.6318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6319 = load i32, ptr %ctx.field.6318, align 4
  %steps.next.6320 = add i32 %steps.current.6319, 1
  store i32 %steps.next.6320, ptr %ctx.field.6318, align 4
  %steps.over.6321 = icmp ugt i32 %steps.next.6320, 10000
  br i1 %steps.over.6321, label %failure.6322, label %continue.6323
failure.6322:
  %ctx.field.6324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 648, ptr %ctx.field.6324, align 4
  %status.diagnostic.6325 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6325, align 4
  ret void
continue.6323:
  %ctx.field.6326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6327 = load i32, ptr %ctx.field.6326, align 4
  %steps.next.6328 = add i32 %steps.current.6327, 1
  store i32 %steps.next.6328, ptr %ctx.field.6326, align 4
  %steps.over.6329 = icmp ugt i32 %steps.next.6328, 10000
  br i1 %steps.over.6329, label %failure.6330, label %continue.6331
failure.6330:
  %ctx.field.6332 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 649, ptr %ctx.field.6332, align 4
  %status.diagnostic.6333 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6333, align 4
  ret void
continue.6331:
  %depth.exceeded.6334 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6334, label %failure.6335, label %continue.6336
failure.6335:
  %ctx.field.6337 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 650, ptr %ctx.field.6337, align 4
  %status.diagnostic.6338 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6338, align 4
  ret void
continue.6336:
  %workspace.slot.6339 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6309, ptr %workspace.slot.6339, align 8
  %workspace.slot.6340 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6341 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 74, ptr %outputs, i32 1, ptr %workspace.slot.6340)
  switch i32 %record.make.status.6341, label %runtime.invalid.result.6347 [ i32 0, label %runtime.success.6342 i32 1, label %runtime.invalid.request.6343 i32 2, label %runtime.invalid.reference.6344 i32 3, label %runtime.scratch.capacity.6345 i32 4, label %runtime.retained.capacity.6346 ]
runtime.invalid.request.6343:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6344:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6345:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6346:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6347:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6342:
  %record.make.handle.6348 = load i64, ptr %workspace.slot.6340, align 8
  %ctx.field.6349 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6350 = load i32, ptr %ctx.field.6349, align 4
  %steps.next.6351 = add i32 %steps.current.6350, 1
  store i32 %steps.next.6351, ptr %ctx.field.6349, align 4
  %steps.over.6352 = icmp ugt i32 %steps.next.6351, 10000
  br i1 %steps.over.6352, label %failure.6353, label %continue.6354
failure.6353:
  %ctx.field.6355 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 651, ptr %ctx.field.6355, align 4
  %status.diagnostic.6356 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6356, align 4
  ret void
continue.6354:
  %ctx.field.6357 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6358 = load i32, ptr %ctx.field.6357, align 4
  %steps.next.6359 = add i32 %steps.current.6358, 1
  store i32 %steps.next.6359, ptr %ctx.field.6357, align 4
  %steps.over.6360 = icmp ugt i32 %steps.next.6359, 10000
  br i1 %steps.over.6360, label %failure.6361, label %continue.6362
failure.6361:
  %ctx.field.6363 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 652, ptr %ctx.field.6363, align 4
  %status.diagnostic.6364 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6364, align 4
  ret void
continue.6362:
  %ctx.field.6365 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6366 = load i32, ptr %ctx.field.6365, align 4
  %steps.next.6367 = add i32 %steps.current.6366, 1
  store i32 %steps.next.6367, ptr %ctx.field.6365, align 4
  %steps.over.6368 = icmp ugt i32 %steps.next.6367, 10000
  br i1 %steps.over.6368, label %failure.6369, label %continue.6370
failure.6369:
  %ctx.field.6371 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 653, ptr %ctx.field.6371, align 4
  %status.diagnostic.6372 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6372, align 4
  ret void
continue.6370:
  %depth.exceeded.6373 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6373, label %failure.6374, label %continue.6375
failure.6374:
  %ctx.field.6376 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 654, ptr %ctx.field.6376, align 4
  %status.diagnostic.6377 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6377, align 4
  ret void
continue.6375:
  %workspace.slot.6378 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6348, ptr %workspace.slot.6378, align 8
  %workspace.slot.6379 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6380 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 75, ptr %outputs, i32 1, ptr %workspace.slot.6379)
  switch i32 %record.make.status.6380, label %runtime.invalid.result.6386 [ i32 0, label %runtime.success.6381 i32 1, label %runtime.invalid.request.6382 i32 2, label %runtime.invalid.reference.6383 i32 3, label %runtime.scratch.capacity.6384 i32 4, label %runtime.retained.capacity.6385 ]
runtime.invalid.request.6382:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6383:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6384:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6385:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6386:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6381:
  %record.make.handle.6387 = load i64, ptr %workspace.slot.6379, align 8
  %ctx.field.6388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6389 = load i32, ptr %ctx.field.6388, align 4
  %steps.next.6390 = add i32 %steps.current.6389, 1
  store i32 %steps.next.6390, ptr %ctx.field.6388, align 4
  %steps.over.6391 = icmp ugt i32 %steps.next.6390, 10000
  br i1 %steps.over.6391, label %failure.6392, label %continue.6393
failure.6392:
  %ctx.field.6394 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 655, ptr %ctx.field.6394, align 4
  %status.diagnostic.6395 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6395, align 4
  ret void
continue.6393:
  %ctx.field.6396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6397 = load i32, ptr %ctx.field.6396, align 4
  %steps.next.6398 = add i32 %steps.current.6397, 1
  store i32 %steps.next.6398, ptr %ctx.field.6396, align 4
  %steps.over.6399 = icmp ugt i32 %steps.next.6398, 10000
  br i1 %steps.over.6399, label %failure.6400, label %continue.6401
failure.6400:
  %ctx.field.6402 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 656, ptr %ctx.field.6402, align 4
  %status.diagnostic.6403 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6403, align 4
  ret void
continue.6401:
  %ctx.field.6404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6405 = load i32, ptr %ctx.field.6404, align 4
  %steps.next.6406 = add i32 %steps.current.6405, 1
  store i32 %steps.next.6406, ptr %ctx.field.6404, align 4
  %steps.over.6407 = icmp ugt i32 %steps.next.6406, 10000
  br i1 %steps.over.6407, label %failure.6408, label %continue.6409
failure.6408:
  %ctx.field.6410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 657, ptr %ctx.field.6410, align 4
  %status.diagnostic.6411 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6411, align 4
  ret void
continue.6409:
  %depth.exceeded.6412 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6412, label %failure.6413, label %continue.6414
failure.6413:
  %ctx.field.6415 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 658, ptr %ctx.field.6415, align 4
  %status.diagnostic.6416 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6416, align 4
  ret void
continue.6414:
  %workspace.slot.6417 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6387, ptr %workspace.slot.6417, align 8
  %workspace.slot.6418 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6419 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 76, ptr %outputs, i32 1, ptr %workspace.slot.6418)
  switch i32 %record.make.status.6419, label %runtime.invalid.result.6425 [ i32 0, label %runtime.success.6420 i32 1, label %runtime.invalid.request.6421 i32 2, label %runtime.invalid.reference.6422 i32 3, label %runtime.scratch.capacity.6423 i32 4, label %runtime.retained.capacity.6424 ]
runtime.invalid.request.6421:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6422:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6423:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6424:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6425:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6420:
  %record.make.handle.6426 = load i64, ptr %workspace.slot.6418, align 8
  %ctx.field.6427 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6428 = load i32, ptr %ctx.field.6427, align 4
  %steps.next.6429 = add i32 %steps.current.6428, 1
  store i32 %steps.next.6429, ptr %ctx.field.6427, align 4
  %steps.over.6430 = icmp ugt i32 %steps.next.6429, 10000
  br i1 %steps.over.6430, label %failure.6431, label %continue.6432
failure.6431:
  %ctx.field.6433 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 659, ptr %ctx.field.6433, align 4
  %status.diagnostic.6434 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6434, align 4
  ret void
continue.6432:
  %ctx.field.6435 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6436 = load i32, ptr %ctx.field.6435, align 4
  %steps.next.6437 = add i32 %steps.current.6436, 1
  store i32 %steps.next.6437, ptr %ctx.field.6435, align 4
  %steps.over.6438 = icmp ugt i32 %steps.next.6437, 10000
  br i1 %steps.over.6438, label %failure.6439, label %continue.6440
failure.6439:
  %ctx.field.6441 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 660, ptr %ctx.field.6441, align 4
  %status.diagnostic.6442 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6442, align 4
  ret void
continue.6440:
  %ctx.field.6443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6444 = load i32, ptr %ctx.field.6443, align 4
  %steps.next.6445 = add i32 %steps.current.6444, 1
  store i32 %steps.next.6445, ptr %ctx.field.6443, align 4
  %steps.over.6446 = icmp ugt i32 %steps.next.6445, 10000
  br i1 %steps.over.6446, label %failure.6447, label %continue.6448
failure.6447:
  %ctx.field.6449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 661, ptr %ctx.field.6449, align 4
  %status.diagnostic.6450 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6450, align 4
  ret void
continue.6448:
  %depth.exceeded.6451 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6451, label %failure.6452, label %continue.6453
failure.6452:
  %ctx.field.6454 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 662, ptr %ctx.field.6454, align 4
  %status.diagnostic.6455 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6455, align 4
  ret void
continue.6453:
  %workspace.slot.6456 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6426, ptr %workspace.slot.6456, align 8
  %workspace.slot.6457 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6458 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 77, ptr %outputs, i32 1, ptr %workspace.slot.6457)
  switch i32 %record.make.status.6458, label %runtime.invalid.result.6464 [ i32 0, label %runtime.success.6459 i32 1, label %runtime.invalid.request.6460 i32 2, label %runtime.invalid.reference.6461 i32 3, label %runtime.scratch.capacity.6462 i32 4, label %runtime.retained.capacity.6463 ]
runtime.invalid.request.6460:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6461:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6462:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6463:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6464:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6459:
  %record.make.handle.6465 = load i64, ptr %workspace.slot.6457, align 8
  %ctx.field.6466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6467 = load i32, ptr %ctx.field.6466, align 4
  %steps.next.6468 = add i32 %steps.current.6467, 1
  store i32 %steps.next.6468, ptr %ctx.field.6466, align 4
  %steps.over.6469 = icmp ugt i32 %steps.next.6468, 10000
  br i1 %steps.over.6469, label %failure.6470, label %continue.6471
failure.6470:
  %ctx.field.6472 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 663, ptr %ctx.field.6472, align 4
  %status.diagnostic.6473 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6473, align 4
  ret void
continue.6471:
  %ctx.field.6474 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6475 = load i32, ptr %ctx.field.6474, align 4
  %steps.next.6476 = add i32 %steps.current.6475, 1
  store i32 %steps.next.6476, ptr %ctx.field.6474, align 4
  %steps.over.6477 = icmp ugt i32 %steps.next.6476, 10000
  br i1 %steps.over.6477, label %failure.6478, label %continue.6479
failure.6478:
  %ctx.field.6480 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 664, ptr %ctx.field.6480, align 4
  %status.diagnostic.6481 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6481, align 4
  ret void
continue.6479:
  %ctx.field.6482 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6483 = load i32, ptr %ctx.field.6482, align 4
  %steps.next.6484 = add i32 %steps.current.6483, 1
  store i32 %steps.next.6484, ptr %ctx.field.6482, align 4
  %steps.over.6485 = icmp ugt i32 %steps.next.6484, 10000
  br i1 %steps.over.6485, label %failure.6486, label %continue.6487
failure.6486:
  %ctx.field.6488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 665, ptr %ctx.field.6488, align 4
  %status.diagnostic.6489 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6489, align 4
  ret void
continue.6487:
  %depth.exceeded.6490 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6490, label %failure.6491, label %continue.6492
failure.6491:
  %ctx.field.6493 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 666, ptr %ctx.field.6493, align 4
  %status.diagnostic.6494 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6494, align 4
  ret void
continue.6492:
  %workspace.slot.6495 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6465, ptr %workspace.slot.6495, align 8
  %workspace.slot.6496 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6497 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 78, ptr %outputs, i32 1, ptr %workspace.slot.6496)
  switch i32 %record.make.status.6497, label %runtime.invalid.result.6503 [ i32 0, label %runtime.success.6498 i32 1, label %runtime.invalid.request.6499 i32 2, label %runtime.invalid.reference.6500 i32 3, label %runtime.scratch.capacity.6501 i32 4, label %runtime.retained.capacity.6502 ]
runtime.invalid.request.6499:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6500:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6501:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6502:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6503:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6498:
  %record.make.handle.6504 = load i64, ptr %workspace.slot.6496, align 8
  %ctx.field.6505 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6506 = load i32, ptr %ctx.field.6505, align 4
  %steps.next.6507 = add i32 %steps.current.6506, 1
  store i32 %steps.next.6507, ptr %ctx.field.6505, align 4
  %steps.over.6508 = icmp ugt i32 %steps.next.6507, 10000
  br i1 %steps.over.6508, label %failure.6509, label %continue.6510
failure.6509:
  %ctx.field.6511 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 667, ptr %ctx.field.6511, align 4
  %status.diagnostic.6512 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6512, align 4
  ret void
continue.6510:
  %ctx.field.6513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6514 = load i32, ptr %ctx.field.6513, align 4
  %steps.next.6515 = add i32 %steps.current.6514, 1
  store i32 %steps.next.6515, ptr %ctx.field.6513, align 4
  %steps.over.6516 = icmp ugt i32 %steps.next.6515, 10000
  br i1 %steps.over.6516, label %failure.6517, label %continue.6518
failure.6517:
  %ctx.field.6519 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 668, ptr %ctx.field.6519, align 4
  %status.diagnostic.6520 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6520, align 4
  ret void
continue.6518:
  %ctx.field.6521 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6522 = load i32, ptr %ctx.field.6521, align 4
  %steps.next.6523 = add i32 %steps.current.6522, 1
  store i32 %steps.next.6523, ptr %ctx.field.6521, align 4
  %steps.over.6524 = icmp ugt i32 %steps.next.6523, 10000
  br i1 %steps.over.6524, label %failure.6525, label %continue.6526
failure.6525:
  %ctx.field.6527 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 669, ptr %ctx.field.6527, align 4
  %status.diagnostic.6528 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6528, align 4
  ret void
continue.6526:
  %depth.exceeded.6529 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6529, label %failure.6530, label %continue.6531
failure.6530:
  %ctx.field.6532 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 670, ptr %ctx.field.6532, align 4
  %status.diagnostic.6533 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6533, align 4
  ret void
continue.6531:
  %workspace.slot.6534 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6504, ptr %workspace.slot.6534, align 8
  %workspace.slot.6535 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6536 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 79, ptr %outputs, i32 1, ptr %workspace.slot.6535)
  switch i32 %record.make.status.6536, label %runtime.invalid.result.6542 [ i32 0, label %runtime.success.6537 i32 1, label %runtime.invalid.request.6538 i32 2, label %runtime.invalid.reference.6539 i32 3, label %runtime.scratch.capacity.6540 i32 4, label %runtime.retained.capacity.6541 ]
runtime.invalid.request.6538:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6539:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6540:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6541:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6542:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6537:
  %record.make.handle.6543 = load i64, ptr %workspace.slot.6535, align 8
  %ctx.field.6544 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6545 = load i32, ptr %ctx.field.6544, align 4
  %steps.next.6546 = add i32 %steps.current.6545, 1
  store i32 %steps.next.6546, ptr %ctx.field.6544, align 4
  %steps.over.6547 = icmp ugt i32 %steps.next.6546, 10000
  br i1 %steps.over.6547, label %failure.6548, label %continue.6549
failure.6548:
  %ctx.field.6550 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 671, ptr %ctx.field.6550, align 4
  %status.diagnostic.6551 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6551, align 4
  ret void
continue.6549:
  %ctx.field.6552 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6553 = load i32, ptr %ctx.field.6552, align 4
  %steps.next.6554 = add i32 %steps.current.6553, 1
  store i32 %steps.next.6554, ptr %ctx.field.6552, align 4
  %steps.over.6555 = icmp ugt i32 %steps.next.6554, 10000
  br i1 %steps.over.6555, label %failure.6556, label %continue.6557
failure.6556:
  %ctx.field.6558 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 672, ptr %ctx.field.6558, align 4
  %status.diagnostic.6559 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6559, align 4
  ret void
continue.6557:
  %ctx.field.6560 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6561 = load i32, ptr %ctx.field.6560, align 4
  %steps.next.6562 = add i32 %steps.current.6561, 1
  store i32 %steps.next.6562, ptr %ctx.field.6560, align 4
  %steps.over.6563 = icmp ugt i32 %steps.next.6562, 10000
  br i1 %steps.over.6563, label %failure.6564, label %continue.6565
failure.6564:
  %ctx.field.6566 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 673, ptr %ctx.field.6566, align 4
  %status.diagnostic.6567 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6567, align 4
  ret void
continue.6565:
  %depth.exceeded.6568 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6568, label %failure.6569, label %continue.6570
failure.6569:
  %ctx.field.6571 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 674, ptr %ctx.field.6571, align 4
  %status.diagnostic.6572 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6572, align 4
  ret void
continue.6570:
  %workspace.slot.6573 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6543, ptr %workspace.slot.6573, align 8
  %workspace.slot.6574 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6575 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 80, ptr %outputs, i32 1, ptr %workspace.slot.6574)
  switch i32 %record.make.status.6575, label %runtime.invalid.result.6581 [ i32 0, label %runtime.success.6576 i32 1, label %runtime.invalid.request.6577 i32 2, label %runtime.invalid.reference.6578 i32 3, label %runtime.scratch.capacity.6579 i32 4, label %runtime.retained.capacity.6580 ]
runtime.invalid.request.6577:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6578:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6579:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6580:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6581:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6576:
  %record.make.handle.6582 = load i64, ptr %workspace.slot.6574, align 8
  %ctx.field.6583 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6584 = load i32, ptr %ctx.field.6583, align 4
  %steps.next.6585 = add i32 %steps.current.6584, 1
  store i32 %steps.next.6585, ptr %ctx.field.6583, align 4
  %steps.over.6586 = icmp ugt i32 %steps.next.6585, 10000
  br i1 %steps.over.6586, label %failure.6587, label %continue.6588
failure.6587:
  %ctx.field.6589 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 675, ptr %ctx.field.6589, align 4
  %status.diagnostic.6590 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6590, align 4
  ret void
continue.6588:
  %ctx.field.6591 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6592 = load i32, ptr %ctx.field.6591, align 4
  %steps.next.6593 = add i32 %steps.current.6592, 1
  store i32 %steps.next.6593, ptr %ctx.field.6591, align 4
  %steps.over.6594 = icmp ugt i32 %steps.next.6593, 10000
  br i1 %steps.over.6594, label %failure.6595, label %continue.6596
failure.6595:
  %ctx.field.6597 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 676, ptr %ctx.field.6597, align 4
  %status.diagnostic.6598 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6598, align 4
  ret void
continue.6596:
  %ctx.field.6599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6600 = load i32, ptr %ctx.field.6599, align 4
  %steps.next.6601 = add i32 %steps.current.6600, 1
  store i32 %steps.next.6601, ptr %ctx.field.6599, align 4
  %steps.over.6602 = icmp ugt i32 %steps.next.6601, 10000
  br i1 %steps.over.6602, label %failure.6603, label %continue.6604
failure.6603:
  %ctx.field.6605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 677, ptr %ctx.field.6605, align 4
  %status.diagnostic.6606 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6606, align 4
  ret void
continue.6604:
  %depth.exceeded.6607 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6607, label %failure.6608, label %continue.6609
failure.6608:
  %ctx.field.6610 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 678, ptr %ctx.field.6610, align 4
  %status.diagnostic.6611 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6611, align 4
  ret void
continue.6609:
  %workspace.slot.6612 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6582, ptr %workspace.slot.6612, align 8
  %workspace.slot.6613 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6614 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 81, ptr %outputs, i32 1, ptr %workspace.slot.6613)
  switch i32 %record.make.status.6614, label %runtime.invalid.result.6620 [ i32 0, label %runtime.success.6615 i32 1, label %runtime.invalid.request.6616 i32 2, label %runtime.invalid.reference.6617 i32 3, label %runtime.scratch.capacity.6618 i32 4, label %runtime.retained.capacity.6619 ]
runtime.invalid.request.6616:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6617:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6618:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6619:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6620:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6615:
  %record.make.handle.6621 = load i64, ptr %workspace.slot.6613, align 8
  %ctx.field.6622 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6623 = load i32, ptr %ctx.field.6622, align 4
  %steps.next.6624 = add i32 %steps.current.6623, 1
  store i32 %steps.next.6624, ptr %ctx.field.6622, align 4
  %steps.over.6625 = icmp ugt i32 %steps.next.6624, 10000
  br i1 %steps.over.6625, label %failure.6626, label %continue.6627
failure.6626:
  %ctx.field.6628 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 679, ptr %ctx.field.6628, align 4
  %status.diagnostic.6629 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6629, align 4
  ret void
continue.6627:
  %ctx.field.6630 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6631 = load i32, ptr %ctx.field.6630, align 4
  %steps.next.6632 = add i32 %steps.current.6631, 1
  store i32 %steps.next.6632, ptr %ctx.field.6630, align 4
  %steps.over.6633 = icmp ugt i32 %steps.next.6632, 10000
  br i1 %steps.over.6633, label %failure.6634, label %continue.6635
failure.6634:
  %ctx.field.6636 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 680, ptr %ctx.field.6636, align 4
  %status.diagnostic.6637 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6637, align 4
  ret void
continue.6635:
  %ctx.field.6638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6639 = load i32, ptr %ctx.field.6638, align 4
  %steps.next.6640 = add i32 %steps.current.6639, 1
  store i32 %steps.next.6640, ptr %ctx.field.6638, align 4
  %steps.over.6641 = icmp ugt i32 %steps.next.6640, 10000
  br i1 %steps.over.6641, label %failure.6642, label %continue.6643
failure.6642:
  %ctx.field.6644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 681, ptr %ctx.field.6644, align 4
  %status.diagnostic.6645 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6645, align 4
  ret void
continue.6643:
  %depth.exceeded.6646 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6646, label %failure.6647, label %continue.6648
failure.6647:
  %ctx.field.6649 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 682, ptr %ctx.field.6649, align 4
  %status.diagnostic.6650 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6650, align 4
  ret void
continue.6648:
  %workspace.slot.6651 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6621, ptr %workspace.slot.6651, align 8
  %workspace.slot.6652 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6653 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 83, ptr %outputs, i32 1, ptr %workspace.slot.6652)
  switch i32 %record.make.status.6653, label %runtime.invalid.result.6659 [ i32 0, label %runtime.success.6654 i32 1, label %runtime.invalid.request.6655 i32 2, label %runtime.invalid.reference.6656 i32 3, label %runtime.scratch.capacity.6657 i32 4, label %runtime.retained.capacity.6658 ]
runtime.invalid.request.6655:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6656:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6657:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6658:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6659:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6654:
  %record.make.handle.6660 = load i64, ptr %workspace.slot.6652, align 8
  %ctx.field.6661 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6662 = load i32, ptr %ctx.field.6661, align 4
  %steps.next.6663 = add i32 %steps.current.6662, 1
  store i32 %steps.next.6663, ptr %ctx.field.6661, align 4
  %steps.over.6664 = icmp ugt i32 %steps.next.6663, 10000
  br i1 %steps.over.6664, label %failure.6665, label %continue.6666
failure.6665:
  %ctx.field.6667 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 683, ptr %ctx.field.6667, align 4
  %status.diagnostic.6668 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6668, align 4
  ret void
continue.6666:
  %ctx.field.6669 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6670 = load i32, ptr %ctx.field.6669, align 4
  %steps.next.6671 = add i32 %steps.current.6670, 1
  store i32 %steps.next.6671, ptr %ctx.field.6669, align 4
  %steps.over.6672 = icmp ugt i32 %steps.next.6671, 10000
  br i1 %steps.over.6672, label %failure.6673, label %continue.6674
failure.6673:
  %ctx.field.6675 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 684, ptr %ctx.field.6675, align 4
  %status.diagnostic.6676 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6676, align 4
  ret void
continue.6674:
  %ctx.field.6677 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6678 = load i32, ptr %ctx.field.6677, align 4
  %steps.next.6679 = add i32 %steps.current.6678, 1
  store i32 %steps.next.6679, ptr %ctx.field.6677, align 4
  %steps.over.6680 = icmp ugt i32 %steps.next.6679, 10000
  br i1 %steps.over.6680, label %failure.6681, label %continue.6682
failure.6681:
  %ctx.field.6683 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 685, ptr %ctx.field.6683, align 4
  %status.diagnostic.6684 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6684, align 4
  ret void
continue.6682:
  %depth.exceeded.6685 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6685, label %failure.6686, label %continue.6687
failure.6686:
  %ctx.field.6688 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 686, ptr %ctx.field.6688, align 4
  %status.diagnostic.6689 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6689, align 4
  ret void
continue.6687:
  %workspace.slot.6690 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6660, ptr %workspace.slot.6690, align 8
  %workspace.slot.6691 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6692 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 84, ptr %outputs, i32 1, ptr %workspace.slot.6691)
  switch i32 %record.make.status.6692, label %runtime.invalid.result.6698 [ i32 0, label %runtime.success.6693 i32 1, label %runtime.invalid.request.6694 i32 2, label %runtime.invalid.reference.6695 i32 3, label %runtime.scratch.capacity.6696 i32 4, label %runtime.retained.capacity.6697 ]
runtime.invalid.request.6694:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6695:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6696:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6697:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6698:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6693:
  %record.make.handle.6699 = load i64, ptr %workspace.slot.6691, align 8
  %ctx.field.6700 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6701 = load i32, ptr %ctx.field.6700, align 4
  %steps.next.6702 = add i32 %steps.current.6701, 1
  store i32 %steps.next.6702, ptr %ctx.field.6700, align 4
  %steps.over.6703 = icmp ugt i32 %steps.next.6702, 10000
  br i1 %steps.over.6703, label %failure.6704, label %continue.6705
failure.6704:
  %ctx.field.6706 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 687, ptr %ctx.field.6706, align 4
  %status.diagnostic.6707 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6707, align 4
  ret void
continue.6705:
  %ctx.field.6708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6709 = load i32, ptr %ctx.field.6708, align 4
  %steps.next.6710 = add i32 %steps.current.6709, 1
  store i32 %steps.next.6710, ptr %ctx.field.6708, align 4
  %steps.over.6711 = icmp ugt i32 %steps.next.6710, 10000
  br i1 %steps.over.6711, label %failure.6712, label %continue.6713
failure.6712:
  %ctx.field.6714 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 688, ptr %ctx.field.6714, align 4
  %status.diagnostic.6715 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6715, align 4
  ret void
continue.6713:
  %ctx.field.6716 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6717 = load i32, ptr %ctx.field.6716, align 4
  %steps.next.6718 = add i32 %steps.current.6717, 1
  store i32 %steps.next.6718, ptr %ctx.field.6716, align 4
  %steps.over.6719 = icmp ugt i32 %steps.next.6718, 10000
  br i1 %steps.over.6719, label %failure.6720, label %continue.6721
failure.6720:
  %ctx.field.6722 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 689, ptr %ctx.field.6722, align 4
  %status.diagnostic.6723 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6723, align 4
  ret void
continue.6721:
  %depth.exceeded.6724 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6724, label %failure.6725, label %continue.6726
failure.6725:
  %ctx.field.6727 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 690, ptr %ctx.field.6727, align 4
  %status.diagnostic.6728 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6728, align 4
  ret void
continue.6726:
  %workspace.slot.6729 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6699, ptr %workspace.slot.6729, align 8
  %workspace.slot.6730 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6731 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 85, ptr %outputs, i32 1, ptr %workspace.slot.6730)
  switch i32 %record.make.status.6731, label %runtime.invalid.result.6737 [ i32 0, label %runtime.success.6732 i32 1, label %runtime.invalid.request.6733 i32 2, label %runtime.invalid.reference.6734 i32 3, label %runtime.scratch.capacity.6735 i32 4, label %runtime.retained.capacity.6736 ]
runtime.invalid.request.6733:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6734:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6735:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6736:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6737:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6732:
  %record.make.handle.6738 = load i64, ptr %workspace.slot.6730, align 8
  %ctx.field.6739 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6740 = load i32, ptr %ctx.field.6739, align 4
  %steps.next.6741 = add i32 %steps.current.6740, 1
  store i32 %steps.next.6741, ptr %ctx.field.6739, align 4
  %steps.over.6742 = icmp ugt i32 %steps.next.6741, 10000
  br i1 %steps.over.6742, label %failure.6743, label %continue.6744
failure.6743:
  %ctx.field.6745 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 691, ptr %ctx.field.6745, align 4
  %status.diagnostic.6746 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6746, align 4
  ret void
continue.6744:
  %ctx.field.6747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6748 = load i32, ptr %ctx.field.6747, align 4
  %steps.next.6749 = add i32 %steps.current.6748, 1
  store i32 %steps.next.6749, ptr %ctx.field.6747, align 4
  %steps.over.6750 = icmp ugt i32 %steps.next.6749, 10000
  br i1 %steps.over.6750, label %failure.6751, label %continue.6752
failure.6751:
  %ctx.field.6753 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 692, ptr %ctx.field.6753, align 4
  %status.diagnostic.6754 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6754, align 4
  ret void
continue.6752:
  %ctx.field.6755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6756 = load i32, ptr %ctx.field.6755, align 4
  %steps.next.6757 = add i32 %steps.current.6756, 1
  store i32 %steps.next.6757, ptr %ctx.field.6755, align 4
  %steps.over.6758 = icmp ugt i32 %steps.next.6757, 10000
  br i1 %steps.over.6758, label %failure.6759, label %continue.6760
failure.6759:
  %ctx.field.6761 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 693, ptr %ctx.field.6761, align 4
  %status.diagnostic.6762 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6762, align 4
  ret void
continue.6760:
  %depth.exceeded.6763 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6763, label %failure.6764, label %continue.6765
failure.6764:
  %ctx.field.6766 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 694, ptr %ctx.field.6766, align 4
  %status.diagnostic.6767 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6767, align 4
  ret void
continue.6765:
  %workspace.slot.6768 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6738, ptr %workspace.slot.6768, align 8
  %workspace.slot.6769 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6770 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 86, ptr %outputs, i32 1, ptr %workspace.slot.6769)
  switch i32 %record.make.status.6770, label %runtime.invalid.result.6776 [ i32 0, label %runtime.success.6771 i32 1, label %runtime.invalid.request.6772 i32 2, label %runtime.invalid.reference.6773 i32 3, label %runtime.scratch.capacity.6774 i32 4, label %runtime.retained.capacity.6775 ]
runtime.invalid.request.6772:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6773:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6774:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6775:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6776:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6771:
  %record.make.handle.6777 = load i64, ptr %workspace.slot.6769, align 8
  %ctx.field.6778 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6779 = load i32, ptr %ctx.field.6778, align 4
  %steps.next.6780 = add i32 %steps.current.6779, 1
  store i32 %steps.next.6780, ptr %ctx.field.6778, align 4
  %steps.over.6781 = icmp ugt i32 %steps.next.6780, 10000
  br i1 %steps.over.6781, label %failure.6782, label %continue.6783
failure.6782:
  %ctx.field.6784 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 695, ptr %ctx.field.6784, align 4
  %status.diagnostic.6785 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6785, align 4
  ret void
continue.6783:
  %ctx.field.6786 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6787 = load i32, ptr %ctx.field.6786, align 4
  %steps.next.6788 = add i32 %steps.current.6787, 1
  store i32 %steps.next.6788, ptr %ctx.field.6786, align 4
  %steps.over.6789 = icmp ugt i32 %steps.next.6788, 10000
  br i1 %steps.over.6789, label %failure.6790, label %continue.6791
failure.6790:
  %ctx.field.6792 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 696, ptr %ctx.field.6792, align 4
  %status.diagnostic.6793 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6793, align 4
  ret void
continue.6791:
  %ctx.field.6794 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6795 = load i32, ptr %ctx.field.6794, align 4
  %steps.next.6796 = add i32 %steps.current.6795, 1
  store i32 %steps.next.6796, ptr %ctx.field.6794, align 4
  %steps.over.6797 = icmp ugt i32 %steps.next.6796, 10000
  br i1 %steps.over.6797, label %failure.6798, label %continue.6799
failure.6798:
  %ctx.field.6800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 697, ptr %ctx.field.6800, align 4
  %status.diagnostic.6801 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6801, align 4
  ret void
continue.6799:
  %depth.exceeded.6802 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6802, label %failure.6803, label %continue.6804
failure.6803:
  %ctx.field.6805 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 698, ptr %ctx.field.6805, align 4
  %status.diagnostic.6806 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6806, align 4
  ret void
continue.6804:
  %workspace.slot.6807 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6777, ptr %workspace.slot.6807, align 8
  %workspace.slot.6808 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6809 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 87, ptr %outputs, i32 1, ptr %workspace.slot.6808)
  switch i32 %record.make.status.6809, label %runtime.invalid.result.6815 [ i32 0, label %runtime.success.6810 i32 1, label %runtime.invalid.request.6811 i32 2, label %runtime.invalid.reference.6812 i32 3, label %runtime.scratch.capacity.6813 i32 4, label %runtime.retained.capacity.6814 ]
runtime.invalid.request.6811:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6812:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6813:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6814:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6815:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6810:
  %record.make.handle.6816 = load i64, ptr %workspace.slot.6808, align 8
  %ctx.field.6817 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6818 = load i32, ptr %ctx.field.6817, align 4
  %steps.next.6819 = add i32 %steps.current.6818, 1
  store i32 %steps.next.6819, ptr %ctx.field.6817, align 4
  %steps.over.6820 = icmp ugt i32 %steps.next.6819, 10000
  br i1 %steps.over.6820, label %failure.6821, label %continue.6822
failure.6821:
  %ctx.field.6823 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 699, ptr %ctx.field.6823, align 4
  %status.diagnostic.6824 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6824, align 4
  ret void
continue.6822:
  %ctx.field.6825 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6826 = load i32, ptr %ctx.field.6825, align 4
  %steps.next.6827 = add i32 %steps.current.6826, 1
  store i32 %steps.next.6827, ptr %ctx.field.6825, align 4
  %steps.over.6828 = icmp ugt i32 %steps.next.6827, 10000
  br i1 %steps.over.6828, label %failure.6829, label %continue.6830
failure.6829:
  %ctx.field.6831 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 700, ptr %ctx.field.6831, align 4
  %status.diagnostic.6832 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6832, align 4
  ret void
continue.6830:
  %ctx.field.6833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6834 = load i32, ptr %ctx.field.6833, align 4
  %steps.next.6835 = add i32 %steps.current.6834, 1
  store i32 %steps.next.6835, ptr %ctx.field.6833, align 4
  %steps.over.6836 = icmp ugt i32 %steps.next.6835, 10000
  br i1 %steps.over.6836, label %failure.6837, label %continue.6838
failure.6837:
  %ctx.field.6839 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 701, ptr %ctx.field.6839, align 4
  %status.diagnostic.6840 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6840, align 4
  ret void
continue.6838:
  %depth.exceeded.6841 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6841, label %failure.6842, label %continue.6843
failure.6842:
  %ctx.field.6844 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 702, ptr %ctx.field.6844, align 4
  %status.diagnostic.6845 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6845, align 4
  ret void
continue.6843:
  %workspace.slot.6846 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6816, ptr %workspace.slot.6846, align 8
  %workspace.slot.6847 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6848 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 88, ptr %outputs, i32 1, ptr %workspace.slot.6847)
  switch i32 %record.make.status.6848, label %runtime.invalid.result.6854 [ i32 0, label %runtime.success.6849 i32 1, label %runtime.invalid.request.6850 i32 2, label %runtime.invalid.reference.6851 i32 3, label %runtime.scratch.capacity.6852 i32 4, label %runtime.retained.capacity.6853 ]
runtime.invalid.request.6850:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6851:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6852:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6853:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6854:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6849:
  %record.make.handle.6855 = load i64, ptr %workspace.slot.6847, align 8
  %ctx.field.6856 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6857 = load i32, ptr %ctx.field.6856, align 4
  %steps.next.6858 = add i32 %steps.current.6857, 1
  store i32 %steps.next.6858, ptr %ctx.field.6856, align 4
  %steps.over.6859 = icmp ugt i32 %steps.next.6858, 10000
  br i1 %steps.over.6859, label %failure.6860, label %continue.6861
failure.6860:
  %ctx.field.6862 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 703, ptr %ctx.field.6862, align 4
  %status.diagnostic.6863 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6863, align 4
  ret void
continue.6861:
  %ctx.field.6864 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6865 = load i32, ptr %ctx.field.6864, align 4
  %steps.next.6866 = add i32 %steps.current.6865, 1
  store i32 %steps.next.6866, ptr %ctx.field.6864, align 4
  %steps.over.6867 = icmp ugt i32 %steps.next.6866, 10000
  br i1 %steps.over.6867, label %failure.6868, label %continue.6869
failure.6868:
  %ctx.field.6870 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 704, ptr %ctx.field.6870, align 4
  %status.diagnostic.6871 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6871, align 4
  ret void
continue.6869:
  %ctx.field.6872 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6873 = load i32, ptr %ctx.field.6872, align 4
  %steps.next.6874 = add i32 %steps.current.6873, 1
  store i32 %steps.next.6874, ptr %ctx.field.6872, align 4
  %steps.over.6875 = icmp ugt i32 %steps.next.6874, 10000
  br i1 %steps.over.6875, label %failure.6876, label %continue.6877
failure.6876:
  %ctx.field.6878 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 705, ptr %ctx.field.6878, align 4
  %status.diagnostic.6879 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6879, align 4
  ret void
continue.6877:
  %depth.exceeded.6880 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6880, label %failure.6881, label %continue.6882
failure.6881:
  %ctx.field.6883 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 706, ptr %ctx.field.6883, align 4
  %status.diagnostic.6884 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6884, align 4
  ret void
continue.6882:
  %workspace.slot.6885 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6855, ptr %workspace.slot.6885, align 8
  %workspace.slot.6886 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6887 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 89, ptr %outputs, i32 1, ptr %workspace.slot.6886)
  switch i32 %record.make.status.6887, label %runtime.invalid.result.6893 [ i32 0, label %runtime.success.6888 i32 1, label %runtime.invalid.request.6889 i32 2, label %runtime.invalid.reference.6890 i32 3, label %runtime.scratch.capacity.6891 i32 4, label %runtime.retained.capacity.6892 ]
runtime.invalid.request.6889:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6890:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6891:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6892:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6893:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6888:
  %record.make.handle.6894 = load i64, ptr %workspace.slot.6886, align 8
  %ctx.field.6895 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6896 = load i32, ptr %ctx.field.6895, align 4
  %steps.next.6897 = add i32 %steps.current.6896, 1
  store i32 %steps.next.6897, ptr %ctx.field.6895, align 4
  %steps.over.6898 = icmp ugt i32 %steps.next.6897, 10000
  br i1 %steps.over.6898, label %failure.6899, label %continue.6900
failure.6899:
  %ctx.field.6901 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 707, ptr %ctx.field.6901, align 4
  %status.diagnostic.6902 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6902, align 4
  ret void
continue.6900:
  %ctx.field.6903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6904 = load i32, ptr %ctx.field.6903, align 4
  %steps.next.6905 = add i32 %steps.current.6904, 1
  store i32 %steps.next.6905, ptr %ctx.field.6903, align 4
  %steps.over.6906 = icmp ugt i32 %steps.next.6905, 10000
  br i1 %steps.over.6906, label %failure.6907, label %continue.6908
failure.6907:
  %ctx.field.6909 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 708, ptr %ctx.field.6909, align 4
  %status.diagnostic.6910 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6910, align 4
  ret void
continue.6908:
  %ctx.field.6911 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6912 = load i32, ptr %ctx.field.6911, align 4
  %steps.next.6913 = add i32 %steps.current.6912, 1
  store i32 %steps.next.6913, ptr %ctx.field.6911, align 4
  %steps.over.6914 = icmp ugt i32 %steps.next.6913, 10000
  br i1 %steps.over.6914, label %failure.6915, label %continue.6916
failure.6915:
  %ctx.field.6917 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 709, ptr %ctx.field.6917, align 4
  %status.diagnostic.6918 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6918, align 4
  ret void
continue.6916:
  %depth.exceeded.6919 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6919, label %failure.6920, label %continue.6921
failure.6920:
  %ctx.field.6922 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 710, ptr %ctx.field.6922, align 4
  %status.diagnostic.6923 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6923, align 4
  ret void
continue.6921:
  %workspace.slot.6924 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6894, ptr %workspace.slot.6924, align 8
  %workspace.slot.6925 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6926 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 90, ptr %outputs, i32 1, ptr %workspace.slot.6925)
  switch i32 %record.make.status.6926, label %runtime.invalid.result.6932 [ i32 0, label %runtime.success.6927 i32 1, label %runtime.invalid.request.6928 i32 2, label %runtime.invalid.reference.6929 i32 3, label %runtime.scratch.capacity.6930 i32 4, label %runtime.retained.capacity.6931 ]
runtime.invalid.request.6928:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6929:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6930:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6931:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6932:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6927:
  %record.make.handle.6933 = load i64, ptr %workspace.slot.6925, align 8
  %ctx.field.6934 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6935 = load i32, ptr %ctx.field.6934, align 4
  %steps.next.6936 = add i32 %steps.current.6935, 1
  store i32 %steps.next.6936, ptr %ctx.field.6934, align 4
  %steps.over.6937 = icmp ugt i32 %steps.next.6936, 10000
  br i1 %steps.over.6937, label %failure.6938, label %continue.6939
failure.6938:
  %ctx.field.6940 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 711, ptr %ctx.field.6940, align 4
  %status.diagnostic.6941 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6941, align 4
  ret void
continue.6939:
  %ctx.field.6942 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6943 = load i32, ptr %ctx.field.6942, align 4
  %steps.next.6944 = add i32 %steps.current.6943, 1
  store i32 %steps.next.6944, ptr %ctx.field.6942, align 4
  %steps.over.6945 = icmp ugt i32 %steps.next.6944, 10000
  br i1 %steps.over.6945, label %failure.6946, label %continue.6947
failure.6946:
  %ctx.field.6948 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 712, ptr %ctx.field.6948, align 4
  %status.diagnostic.6949 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6949, align 4
  ret void
continue.6947:
  %ctx.field.6950 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6951 = load i32, ptr %ctx.field.6950, align 4
  %steps.next.6952 = add i32 %steps.current.6951, 1
  store i32 %steps.next.6952, ptr %ctx.field.6950, align 4
  %steps.over.6953 = icmp ugt i32 %steps.next.6952, 10000
  br i1 %steps.over.6953, label %failure.6954, label %continue.6955
failure.6954:
  %ctx.field.6956 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 713, ptr %ctx.field.6956, align 4
  %status.diagnostic.6957 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6957, align 4
  ret void
continue.6955:
  %depth.exceeded.6958 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6958, label %failure.6959, label %continue.6960
failure.6959:
  %ctx.field.6961 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 714, ptr %ctx.field.6961, align 4
  %status.diagnostic.6962 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6962, align 4
  ret void
continue.6960:
  %workspace.slot.6963 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6933, ptr %workspace.slot.6963, align 8
  %workspace.slot.6964 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.6965 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 91, ptr %outputs, i32 1, ptr %workspace.slot.6964)
  switch i32 %record.make.status.6965, label %runtime.invalid.result.6971 [ i32 0, label %runtime.success.6966 i32 1, label %runtime.invalid.request.6967 i32 2, label %runtime.invalid.reference.6968 i32 3, label %runtime.scratch.capacity.6969 i32 4, label %runtime.retained.capacity.6970 ]
runtime.invalid.request.6967:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.6968:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.6969:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.6970:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.6971:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.6966:
  %record.make.handle.6972 = load i64, ptr %workspace.slot.6964, align 8
  %ctx.field.6973 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6974 = load i32, ptr %ctx.field.6973, align 4
  %steps.next.6975 = add i32 %steps.current.6974, 1
  store i32 %steps.next.6975, ptr %ctx.field.6973, align 4
  %steps.over.6976 = icmp ugt i32 %steps.next.6975, 10000
  br i1 %steps.over.6976, label %failure.6977, label %continue.6978
failure.6977:
  %ctx.field.6979 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 715, ptr %ctx.field.6979, align 4
  %status.diagnostic.6980 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6980, align 4
  ret void
continue.6978:
  %ctx.field.6981 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6982 = load i32, ptr %ctx.field.6981, align 4
  %steps.next.6983 = add i32 %steps.current.6982, 1
  store i32 %steps.next.6983, ptr %ctx.field.6981, align 4
  %steps.over.6984 = icmp ugt i32 %steps.next.6983, 10000
  br i1 %steps.over.6984, label %failure.6985, label %continue.6986
failure.6985:
  %ctx.field.6987 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 716, ptr %ctx.field.6987, align 4
  %status.diagnostic.6988 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6988, align 4
  ret void
continue.6986:
  %ctx.field.6989 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.6990 = load i32, ptr %ctx.field.6989, align 4
  %steps.next.6991 = add i32 %steps.current.6990, 1
  store i32 %steps.next.6991, ptr %ctx.field.6989, align 4
  %steps.over.6992 = icmp ugt i32 %steps.next.6991, 10000
  br i1 %steps.over.6992, label %failure.6993, label %continue.6994
failure.6993:
  %ctx.field.6995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 717, ptr %ctx.field.6995, align 4
  %status.diagnostic.6996 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.6996, align 4
  ret void
continue.6994:
  %depth.exceeded.6997 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.6997, label %failure.6998, label %continue.6999
failure.6998:
  %ctx.field.7000 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 718, ptr %ctx.field.7000, align 4
  %status.diagnostic.7001 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7001, align 4
  ret void
continue.6999:
  %workspace.slot.7002 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.6972, ptr %workspace.slot.7002, align 8
  %workspace.slot.7003 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7004 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 92, ptr %outputs, i32 1, ptr %workspace.slot.7003)
  switch i32 %record.make.status.7004, label %runtime.invalid.result.7010 [ i32 0, label %runtime.success.7005 i32 1, label %runtime.invalid.request.7006 i32 2, label %runtime.invalid.reference.7007 i32 3, label %runtime.scratch.capacity.7008 i32 4, label %runtime.retained.capacity.7009 ]
runtime.invalid.request.7006:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7007:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7008:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7009:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7010:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7005:
  %record.make.handle.7011 = load i64, ptr %workspace.slot.7003, align 8
  %ctx.field.7012 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7013 = load i32, ptr %ctx.field.7012, align 4
  %steps.next.7014 = add i32 %steps.current.7013, 1
  store i32 %steps.next.7014, ptr %ctx.field.7012, align 4
  %steps.over.7015 = icmp ugt i32 %steps.next.7014, 10000
  br i1 %steps.over.7015, label %failure.7016, label %continue.7017
failure.7016:
  %ctx.field.7018 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 719, ptr %ctx.field.7018, align 4
  %status.diagnostic.7019 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7019, align 4
  ret void
continue.7017:
  %ctx.field.7020 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7021 = load i32, ptr %ctx.field.7020, align 4
  %steps.next.7022 = add i32 %steps.current.7021, 1
  store i32 %steps.next.7022, ptr %ctx.field.7020, align 4
  %steps.over.7023 = icmp ugt i32 %steps.next.7022, 10000
  br i1 %steps.over.7023, label %failure.7024, label %continue.7025
failure.7024:
  %ctx.field.7026 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 720, ptr %ctx.field.7026, align 4
  %status.diagnostic.7027 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7027, align 4
  ret void
continue.7025:
  %ctx.field.7028 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7029 = load i32, ptr %ctx.field.7028, align 4
  %steps.next.7030 = add i32 %steps.current.7029, 1
  store i32 %steps.next.7030, ptr %ctx.field.7028, align 4
  %steps.over.7031 = icmp ugt i32 %steps.next.7030, 10000
  br i1 %steps.over.7031, label %failure.7032, label %continue.7033
failure.7032:
  %ctx.field.7034 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 721, ptr %ctx.field.7034, align 4
  %status.diagnostic.7035 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7035, align 4
  ret void
continue.7033:
  %depth.exceeded.7036 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7036, label %failure.7037, label %continue.7038
failure.7037:
  %ctx.field.7039 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 722, ptr %ctx.field.7039, align 4
  %status.diagnostic.7040 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7040, align 4
  ret void
continue.7038:
  %workspace.slot.7041 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7011, ptr %workspace.slot.7041, align 8
  %workspace.slot.7042 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7043 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 94, ptr %outputs, i32 1, ptr %workspace.slot.7042)
  switch i32 %record.make.status.7043, label %runtime.invalid.result.7049 [ i32 0, label %runtime.success.7044 i32 1, label %runtime.invalid.request.7045 i32 2, label %runtime.invalid.reference.7046 i32 3, label %runtime.scratch.capacity.7047 i32 4, label %runtime.retained.capacity.7048 ]
runtime.invalid.request.7045:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7046:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7047:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7048:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7049:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7044:
  %record.make.handle.7050 = load i64, ptr %workspace.slot.7042, align 8
  %ctx.field.7051 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7052 = load i32, ptr %ctx.field.7051, align 4
  %steps.next.7053 = add i32 %steps.current.7052, 1
  store i32 %steps.next.7053, ptr %ctx.field.7051, align 4
  %steps.over.7054 = icmp ugt i32 %steps.next.7053, 10000
  br i1 %steps.over.7054, label %failure.7055, label %continue.7056
failure.7055:
  %ctx.field.7057 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 723, ptr %ctx.field.7057, align 4
  %status.diagnostic.7058 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7058, align 4
  ret void
continue.7056:
  %ctx.field.7059 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7060 = load i32, ptr %ctx.field.7059, align 4
  %steps.next.7061 = add i32 %steps.current.7060, 1
  store i32 %steps.next.7061, ptr %ctx.field.7059, align 4
  %steps.over.7062 = icmp ugt i32 %steps.next.7061, 10000
  br i1 %steps.over.7062, label %failure.7063, label %continue.7064
failure.7063:
  %ctx.field.7065 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 724, ptr %ctx.field.7065, align 4
  %status.diagnostic.7066 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7066, align 4
  ret void
continue.7064:
  %ctx.field.7067 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7068 = load i32, ptr %ctx.field.7067, align 4
  %steps.next.7069 = add i32 %steps.current.7068, 1
  store i32 %steps.next.7069, ptr %ctx.field.7067, align 4
  %steps.over.7070 = icmp ugt i32 %steps.next.7069, 10000
  br i1 %steps.over.7070, label %failure.7071, label %continue.7072
failure.7071:
  %ctx.field.7073 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 725, ptr %ctx.field.7073, align 4
  %status.diagnostic.7074 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7074, align 4
  ret void
continue.7072:
  %depth.exceeded.7075 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7075, label %failure.7076, label %continue.7077
failure.7076:
  %ctx.field.7078 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 726, ptr %ctx.field.7078, align 4
  %status.diagnostic.7079 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7079, align 4
  ret void
continue.7077:
  %workspace.slot.7080 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7050, ptr %workspace.slot.7080, align 8
  %workspace.slot.7081 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7082 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 95, ptr %outputs, i32 1, ptr %workspace.slot.7081)
  switch i32 %record.make.status.7082, label %runtime.invalid.result.7088 [ i32 0, label %runtime.success.7083 i32 1, label %runtime.invalid.request.7084 i32 2, label %runtime.invalid.reference.7085 i32 3, label %runtime.scratch.capacity.7086 i32 4, label %runtime.retained.capacity.7087 ]
runtime.invalid.request.7084:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7085:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7086:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7087:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7088:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7083:
  %record.make.handle.7089 = load i64, ptr %workspace.slot.7081, align 8
  %ctx.field.7090 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7091 = load i32, ptr %ctx.field.7090, align 4
  %steps.next.7092 = add i32 %steps.current.7091, 1
  store i32 %steps.next.7092, ptr %ctx.field.7090, align 4
  %steps.over.7093 = icmp ugt i32 %steps.next.7092, 10000
  br i1 %steps.over.7093, label %failure.7094, label %continue.7095
failure.7094:
  %ctx.field.7096 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 727, ptr %ctx.field.7096, align 4
  %status.diagnostic.7097 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7097, align 4
  ret void
continue.7095:
  %ctx.field.7098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7099 = load i32, ptr %ctx.field.7098, align 4
  %steps.next.7100 = add i32 %steps.current.7099, 1
  store i32 %steps.next.7100, ptr %ctx.field.7098, align 4
  %steps.over.7101 = icmp ugt i32 %steps.next.7100, 10000
  br i1 %steps.over.7101, label %failure.7102, label %continue.7103
failure.7102:
  %ctx.field.7104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 728, ptr %ctx.field.7104, align 4
  %status.diagnostic.7105 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7105, align 4
  ret void
continue.7103:
  %ctx.field.7106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7107 = load i32, ptr %ctx.field.7106, align 4
  %steps.next.7108 = add i32 %steps.current.7107, 1
  store i32 %steps.next.7108, ptr %ctx.field.7106, align 4
  %steps.over.7109 = icmp ugt i32 %steps.next.7108, 10000
  br i1 %steps.over.7109, label %failure.7110, label %continue.7111
failure.7110:
  %ctx.field.7112 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 729, ptr %ctx.field.7112, align 4
  %status.diagnostic.7113 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7113, align 4
  ret void
continue.7111:
  %depth.exceeded.7114 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7114, label %failure.7115, label %continue.7116
failure.7115:
  %ctx.field.7117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 730, ptr %ctx.field.7117, align 4
  %status.diagnostic.7118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7118, align 4
  ret void
continue.7116:
  %workspace.slot.7119 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7089, ptr %workspace.slot.7119, align 8
  %workspace.slot.7120 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7121 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 96, ptr %outputs, i32 1, ptr %workspace.slot.7120)
  switch i32 %record.make.status.7121, label %runtime.invalid.result.7127 [ i32 0, label %runtime.success.7122 i32 1, label %runtime.invalid.request.7123 i32 2, label %runtime.invalid.reference.7124 i32 3, label %runtime.scratch.capacity.7125 i32 4, label %runtime.retained.capacity.7126 ]
runtime.invalid.request.7123:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7124:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7125:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7126:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7127:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7122:
  %record.make.handle.7128 = load i64, ptr %workspace.slot.7120, align 8
  %ctx.field.7129 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7130 = load i32, ptr %ctx.field.7129, align 4
  %steps.next.7131 = add i32 %steps.current.7130, 1
  store i32 %steps.next.7131, ptr %ctx.field.7129, align 4
  %steps.over.7132 = icmp ugt i32 %steps.next.7131, 10000
  br i1 %steps.over.7132, label %failure.7133, label %continue.7134
failure.7133:
  %ctx.field.7135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 731, ptr %ctx.field.7135, align 4
  %status.diagnostic.7136 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7136, align 4
  ret void
continue.7134:
  %ctx.field.7137 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7138 = load i32, ptr %ctx.field.7137, align 4
  %steps.next.7139 = add i32 %steps.current.7138, 1
  store i32 %steps.next.7139, ptr %ctx.field.7137, align 4
  %steps.over.7140 = icmp ugt i32 %steps.next.7139, 10000
  br i1 %steps.over.7140, label %failure.7141, label %continue.7142
failure.7141:
  %ctx.field.7143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 732, ptr %ctx.field.7143, align 4
  %status.diagnostic.7144 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7144, align 4
  ret void
continue.7142:
  %ctx.field.7145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7146 = load i32, ptr %ctx.field.7145, align 4
  %steps.next.7147 = add i32 %steps.current.7146, 1
  store i32 %steps.next.7147, ptr %ctx.field.7145, align 4
  %steps.over.7148 = icmp ugt i32 %steps.next.7147, 10000
  br i1 %steps.over.7148, label %failure.7149, label %continue.7150
failure.7149:
  %ctx.field.7151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 733, ptr %ctx.field.7151, align 4
  %status.diagnostic.7152 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7152, align 4
  ret void
continue.7150:
  %depth.exceeded.7153 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7153, label %failure.7154, label %continue.7155
failure.7154:
  %ctx.field.7156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 734, ptr %ctx.field.7156, align 4
  %status.diagnostic.7157 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7157, align 4
  ret void
continue.7155:
  %workspace.slot.7158 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7128, ptr %workspace.slot.7158, align 8
  %workspace.slot.7159 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7160 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 97, ptr %outputs, i32 1, ptr %workspace.slot.7159)
  switch i32 %record.make.status.7160, label %runtime.invalid.result.7166 [ i32 0, label %runtime.success.7161 i32 1, label %runtime.invalid.request.7162 i32 2, label %runtime.invalid.reference.7163 i32 3, label %runtime.scratch.capacity.7164 i32 4, label %runtime.retained.capacity.7165 ]
runtime.invalid.request.7162:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7163:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7164:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7165:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7166:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7161:
  %record.make.handle.7167 = load i64, ptr %workspace.slot.7159, align 8
  %ctx.field.7168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7169 = load i32, ptr %ctx.field.7168, align 4
  %steps.next.7170 = add i32 %steps.current.7169, 1
  store i32 %steps.next.7170, ptr %ctx.field.7168, align 4
  %steps.over.7171 = icmp ugt i32 %steps.next.7170, 10000
  br i1 %steps.over.7171, label %failure.7172, label %continue.7173
failure.7172:
  %ctx.field.7174 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 735, ptr %ctx.field.7174, align 4
  %status.diagnostic.7175 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7175, align 4
  ret void
continue.7173:
  %ctx.field.7176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7177 = load i32, ptr %ctx.field.7176, align 4
  %steps.next.7178 = add i32 %steps.current.7177, 1
  store i32 %steps.next.7178, ptr %ctx.field.7176, align 4
  %steps.over.7179 = icmp ugt i32 %steps.next.7178, 10000
  br i1 %steps.over.7179, label %failure.7180, label %continue.7181
failure.7180:
  %ctx.field.7182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 736, ptr %ctx.field.7182, align 4
  %status.diagnostic.7183 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7183, align 4
  ret void
continue.7181:
  %ctx.field.7184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7185 = load i32, ptr %ctx.field.7184, align 4
  %steps.next.7186 = add i32 %steps.current.7185, 1
  store i32 %steps.next.7186, ptr %ctx.field.7184, align 4
  %steps.over.7187 = icmp ugt i32 %steps.next.7186, 10000
  br i1 %steps.over.7187, label %failure.7188, label %continue.7189
failure.7188:
  %ctx.field.7190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 737, ptr %ctx.field.7190, align 4
  %status.diagnostic.7191 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7191, align 4
  ret void
continue.7189:
  %depth.exceeded.7192 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7192, label %failure.7193, label %continue.7194
failure.7193:
  %ctx.field.7195 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 738, ptr %ctx.field.7195, align 4
  %status.diagnostic.7196 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7196, align 4
  ret void
continue.7194:
  %workspace.slot.7197 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7167, ptr %workspace.slot.7197, align 8
  %workspace.slot.7198 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7199 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 98, ptr %outputs, i32 1, ptr %workspace.slot.7198)
  switch i32 %record.make.status.7199, label %runtime.invalid.result.7205 [ i32 0, label %runtime.success.7200 i32 1, label %runtime.invalid.request.7201 i32 2, label %runtime.invalid.reference.7202 i32 3, label %runtime.scratch.capacity.7203 i32 4, label %runtime.retained.capacity.7204 ]
runtime.invalid.request.7201:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7202:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7203:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7204:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7205:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7200:
  %record.make.handle.7206 = load i64, ptr %workspace.slot.7198, align 8
  %ctx.field.7207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7208 = load i32, ptr %ctx.field.7207, align 4
  %steps.next.7209 = add i32 %steps.current.7208, 1
  store i32 %steps.next.7209, ptr %ctx.field.7207, align 4
  %steps.over.7210 = icmp ugt i32 %steps.next.7209, 10000
  br i1 %steps.over.7210, label %failure.7211, label %continue.7212
failure.7211:
  %ctx.field.7213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 739, ptr %ctx.field.7213, align 4
  %status.diagnostic.7214 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7214, align 4
  ret void
continue.7212:
  %ctx.field.7215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7216 = load i32, ptr %ctx.field.7215, align 4
  %steps.next.7217 = add i32 %steps.current.7216, 1
  store i32 %steps.next.7217, ptr %ctx.field.7215, align 4
  %steps.over.7218 = icmp ugt i32 %steps.next.7217, 10000
  br i1 %steps.over.7218, label %failure.7219, label %continue.7220
failure.7219:
  %ctx.field.7221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 740, ptr %ctx.field.7221, align 4
  %status.diagnostic.7222 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7222, align 4
  ret void
continue.7220:
  %ctx.field.7223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7224 = load i32, ptr %ctx.field.7223, align 4
  %steps.next.7225 = add i32 %steps.current.7224, 1
  store i32 %steps.next.7225, ptr %ctx.field.7223, align 4
  %steps.over.7226 = icmp ugt i32 %steps.next.7225, 10000
  br i1 %steps.over.7226, label %failure.7227, label %continue.7228
failure.7227:
  %ctx.field.7229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 741, ptr %ctx.field.7229, align 4
  %status.diagnostic.7230 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7230, align 4
  ret void
continue.7228:
  %depth.exceeded.7231 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7231, label %failure.7232, label %continue.7233
failure.7232:
  %ctx.field.7234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 742, ptr %ctx.field.7234, align 4
  %status.diagnostic.7235 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7235, align 4
  ret void
continue.7233:
  %workspace.slot.7236 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7206, ptr %workspace.slot.7236, align 8
  %workspace.slot.7237 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7238 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 99, ptr %outputs, i32 1, ptr %workspace.slot.7237)
  switch i32 %record.make.status.7238, label %runtime.invalid.result.7244 [ i32 0, label %runtime.success.7239 i32 1, label %runtime.invalid.request.7240 i32 2, label %runtime.invalid.reference.7241 i32 3, label %runtime.scratch.capacity.7242 i32 4, label %runtime.retained.capacity.7243 ]
runtime.invalid.request.7240:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7241:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7242:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7243:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7244:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7239:
  %record.make.handle.7245 = load i64, ptr %workspace.slot.7237, align 8
  %ctx.field.7246 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7247 = load i32, ptr %ctx.field.7246, align 4
  %steps.next.7248 = add i32 %steps.current.7247, 1
  store i32 %steps.next.7248, ptr %ctx.field.7246, align 4
  %steps.over.7249 = icmp ugt i32 %steps.next.7248, 10000
  br i1 %steps.over.7249, label %failure.7250, label %continue.7251
failure.7250:
  %ctx.field.7252 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 743, ptr %ctx.field.7252, align 4
  %status.diagnostic.7253 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7253, align 4
  ret void
continue.7251:
  %ctx.field.7254 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7255 = load i32, ptr %ctx.field.7254, align 4
  %steps.next.7256 = add i32 %steps.current.7255, 1
  store i32 %steps.next.7256, ptr %ctx.field.7254, align 4
  %steps.over.7257 = icmp ugt i32 %steps.next.7256, 10000
  br i1 %steps.over.7257, label %failure.7258, label %continue.7259
failure.7258:
  %ctx.field.7260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 744, ptr %ctx.field.7260, align 4
  %status.diagnostic.7261 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7261, align 4
  ret void
continue.7259:
  %ctx.field.7262 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7263 = load i32, ptr %ctx.field.7262, align 4
  %steps.next.7264 = add i32 %steps.current.7263, 1
  store i32 %steps.next.7264, ptr %ctx.field.7262, align 4
  %steps.over.7265 = icmp ugt i32 %steps.next.7264, 10000
  br i1 %steps.over.7265, label %failure.7266, label %continue.7267
failure.7266:
  %ctx.field.7268 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 745, ptr %ctx.field.7268, align 4
  %status.diagnostic.7269 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7269, align 4
  ret void
continue.7267:
  %depth.exceeded.7270 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7270, label %failure.7271, label %continue.7272
failure.7271:
  %ctx.field.7273 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 746, ptr %ctx.field.7273, align 4
  %status.diagnostic.7274 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7274, align 4
  ret void
continue.7272:
  %workspace.slot.7275 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7245, ptr %workspace.slot.7275, align 8
  %workspace.slot.7276 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7277 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 100, ptr %outputs, i32 1, ptr %workspace.slot.7276)
  switch i32 %record.make.status.7277, label %runtime.invalid.result.7283 [ i32 0, label %runtime.success.7278 i32 1, label %runtime.invalid.request.7279 i32 2, label %runtime.invalid.reference.7280 i32 3, label %runtime.scratch.capacity.7281 i32 4, label %runtime.retained.capacity.7282 ]
runtime.invalid.request.7279:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7280:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7281:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7282:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7283:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7278:
  %record.make.handle.7284 = load i64, ptr %workspace.slot.7276, align 8
  %ctx.field.7285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7286 = load i32, ptr %ctx.field.7285, align 4
  %steps.next.7287 = add i32 %steps.current.7286, 1
  store i32 %steps.next.7287, ptr %ctx.field.7285, align 4
  %steps.over.7288 = icmp ugt i32 %steps.next.7287, 10000
  br i1 %steps.over.7288, label %failure.7289, label %continue.7290
failure.7289:
  %ctx.field.7291 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 747, ptr %ctx.field.7291, align 4
  %status.diagnostic.7292 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7292, align 4
  ret void
continue.7290:
  %ctx.field.7293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7294 = load i32, ptr %ctx.field.7293, align 4
  %steps.next.7295 = add i32 %steps.current.7294, 1
  store i32 %steps.next.7295, ptr %ctx.field.7293, align 4
  %steps.over.7296 = icmp ugt i32 %steps.next.7295, 10000
  br i1 %steps.over.7296, label %failure.7297, label %continue.7298
failure.7297:
  %ctx.field.7299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 748, ptr %ctx.field.7299, align 4
  %status.diagnostic.7300 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7300, align 4
  ret void
continue.7298:
  %ctx.field.7301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7302 = load i32, ptr %ctx.field.7301, align 4
  %steps.next.7303 = add i32 %steps.current.7302, 1
  store i32 %steps.next.7303, ptr %ctx.field.7301, align 4
  %steps.over.7304 = icmp ugt i32 %steps.next.7303, 10000
  br i1 %steps.over.7304, label %failure.7305, label %continue.7306
failure.7305:
  %ctx.field.7307 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 749, ptr %ctx.field.7307, align 4
  %status.diagnostic.7308 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7308, align 4
  ret void
continue.7306:
  %depth.exceeded.7309 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7309, label %failure.7310, label %continue.7311
failure.7310:
  %ctx.field.7312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 750, ptr %ctx.field.7312, align 4
  %status.diagnostic.7313 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7313, align 4
  ret void
continue.7311:
  %workspace.slot.7314 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7284, ptr %workspace.slot.7314, align 8
  %workspace.slot.7315 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7316 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 101, ptr %outputs, i32 1, ptr %workspace.slot.7315)
  switch i32 %record.make.status.7316, label %runtime.invalid.result.7322 [ i32 0, label %runtime.success.7317 i32 1, label %runtime.invalid.request.7318 i32 2, label %runtime.invalid.reference.7319 i32 3, label %runtime.scratch.capacity.7320 i32 4, label %runtime.retained.capacity.7321 ]
runtime.invalid.request.7318:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7319:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7320:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7321:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7322:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7317:
  %record.make.handle.7323 = load i64, ptr %workspace.slot.7315, align 8
  %ctx.field.7324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7325 = load i32, ptr %ctx.field.7324, align 4
  %steps.next.7326 = add i32 %steps.current.7325, 1
  store i32 %steps.next.7326, ptr %ctx.field.7324, align 4
  %steps.over.7327 = icmp ugt i32 %steps.next.7326, 10000
  br i1 %steps.over.7327, label %failure.7328, label %continue.7329
failure.7328:
  %ctx.field.7330 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 751, ptr %ctx.field.7330, align 4
  %status.diagnostic.7331 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7331, align 4
  ret void
continue.7329:
  %ctx.field.7332 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7333 = load i32, ptr %ctx.field.7332, align 4
  %steps.next.7334 = add i32 %steps.current.7333, 1
  store i32 %steps.next.7334, ptr %ctx.field.7332, align 4
  %steps.over.7335 = icmp ugt i32 %steps.next.7334, 10000
  br i1 %steps.over.7335, label %failure.7336, label %continue.7337
failure.7336:
  %ctx.field.7338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 752, ptr %ctx.field.7338, align 4
  %status.diagnostic.7339 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7339, align 4
  ret void
continue.7337:
  %ctx.field.7340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7341 = load i32, ptr %ctx.field.7340, align 4
  %steps.next.7342 = add i32 %steps.current.7341, 1
  store i32 %steps.next.7342, ptr %ctx.field.7340, align 4
  %steps.over.7343 = icmp ugt i32 %steps.next.7342, 10000
  br i1 %steps.over.7343, label %failure.7344, label %continue.7345
failure.7344:
  %ctx.field.7346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 753, ptr %ctx.field.7346, align 4
  %status.diagnostic.7347 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7347, align 4
  ret void
continue.7345:
  %depth.exceeded.7348 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7348, label %failure.7349, label %continue.7350
failure.7349:
  %ctx.field.7351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 754, ptr %ctx.field.7351, align 4
  %status.diagnostic.7352 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7352, align 4
  ret void
continue.7350:
  %workspace.slot.7353 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7323, ptr %workspace.slot.7353, align 8
  %workspace.slot.7354 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7355 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 102, ptr %outputs, i32 1, ptr %workspace.slot.7354)
  switch i32 %record.make.status.7355, label %runtime.invalid.result.7361 [ i32 0, label %runtime.success.7356 i32 1, label %runtime.invalid.request.7357 i32 2, label %runtime.invalid.reference.7358 i32 3, label %runtime.scratch.capacity.7359 i32 4, label %runtime.retained.capacity.7360 ]
runtime.invalid.request.7357:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7358:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7359:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7360:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7361:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7356:
  %record.make.handle.7362 = load i64, ptr %workspace.slot.7354, align 8
  %ctx.field.7363 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7364 = load i32, ptr %ctx.field.7363, align 4
  %steps.next.7365 = add i32 %steps.current.7364, 1
  store i32 %steps.next.7365, ptr %ctx.field.7363, align 4
  %steps.over.7366 = icmp ugt i32 %steps.next.7365, 10000
  br i1 %steps.over.7366, label %failure.7367, label %continue.7368
failure.7367:
  %ctx.field.7369 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 755, ptr %ctx.field.7369, align 4
  %status.diagnostic.7370 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7370, align 4
  ret void
continue.7368:
  %ctx.field.7371 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7372 = load i32, ptr %ctx.field.7371, align 4
  %steps.next.7373 = add i32 %steps.current.7372, 1
  store i32 %steps.next.7373, ptr %ctx.field.7371, align 4
  %steps.over.7374 = icmp ugt i32 %steps.next.7373, 10000
  br i1 %steps.over.7374, label %failure.7375, label %continue.7376
failure.7375:
  %ctx.field.7377 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 756, ptr %ctx.field.7377, align 4
  %status.diagnostic.7378 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7378, align 4
  ret void
continue.7376:
  %ctx.field.7379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7380 = load i32, ptr %ctx.field.7379, align 4
  %steps.next.7381 = add i32 %steps.current.7380, 1
  store i32 %steps.next.7381, ptr %ctx.field.7379, align 4
  %steps.over.7382 = icmp ugt i32 %steps.next.7381, 10000
  br i1 %steps.over.7382, label %failure.7383, label %continue.7384
failure.7383:
  %ctx.field.7385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 757, ptr %ctx.field.7385, align 4
  %status.diagnostic.7386 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7386, align 4
  ret void
continue.7384:
  %depth.exceeded.7387 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7387, label %failure.7388, label %continue.7389
failure.7388:
  %ctx.field.7390 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 758, ptr %ctx.field.7390, align 4
  %status.diagnostic.7391 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7391, align 4
  ret void
continue.7389:
  %workspace.slot.7392 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7362, ptr %workspace.slot.7392, align 8
  %workspace.slot.7393 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7394 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 103, ptr %outputs, i32 1, ptr %workspace.slot.7393)
  switch i32 %record.make.status.7394, label %runtime.invalid.result.7400 [ i32 0, label %runtime.success.7395 i32 1, label %runtime.invalid.request.7396 i32 2, label %runtime.invalid.reference.7397 i32 3, label %runtime.scratch.capacity.7398 i32 4, label %runtime.retained.capacity.7399 ]
runtime.invalid.request.7396:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7397:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7398:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7399:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7400:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7395:
  %record.make.handle.7401 = load i64, ptr %workspace.slot.7393, align 8
  %ctx.field.7402 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7403 = load i32, ptr %ctx.field.7402, align 4
  %steps.next.7404 = add i32 %steps.current.7403, 1
  store i32 %steps.next.7404, ptr %ctx.field.7402, align 4
  %steps.over.7405 = icmp ugt i32 %steps.next.7404, 10000
  br i1 %steps.over.7405, label %failure.7406, label %continue.7407
failure.7406:
  %ctx.field.7408 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 759, ptr %ctx.field.7408, align 4
  %status.diagnostic.7409 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7409, align 4
  ret void
continue.7407:
  %ctx.field.7410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7411 = load i32, ptr %ctx.field.7410, align 4
  %steps.next.7412 = add i32 %steps.current.7411, 1
  store i32 %steps.next.7412, ptr %ctx.field.7410, align 4
  %steps.over.7413 = icmp ugt i32 %steps.next.7412, 10000
  br i1 %steps.over.7413, label %failure.7414, label %continue.7415
failure.7414:
  %ctx.field.7416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 760, ptr %ctx.field.7416, align 4
  %status.diagnostic.7417 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7417, align 4
  ret void
continue.7415:
  %ctx.field.7418 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7419 = load i32, ptr %ctx.field.7418, align 4
  %steps.next.7420 = add i32 %steps.current.7419, 1
  store i32 %steps.next.7420, ptr %ctx.field.7418, align 4
  %steps.over.7421 = icmp ugt i32 %steps.next.7420, 10000
  br i1 %steps.over.7421, label %failure.7422, label %continue.7423
failure.7422:
  %ctx.field.7424 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 761, ptr %ctx.field.7424, align 4
  %status.diagnostic.7425 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7425, align 4
  ret void
continue.7423:
  %depth.exceeded.7426 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7426, label %failure.7427, label %continue.7428
failure.7427:
  %ctx.field.7429 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 762, ptr %ctx.field.7429, align 4
  %status.diagnostic.7430 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7430, align 4
  ret void
continue.7428:
  %workspace.slot.7431 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7401, ptr %workspace.slot.7431, align 8
  %workspace.slot.7432 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7433 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 105, ptr %outputs, i32 1, ptr %workspace.slot.7432)
  switch i32 %record.make.status.7433, label %runtime.invalid.result.7439 [ i32 0, label %runtime.success.7434 i32 1, label %runtime.invalid.request.7435 i32 2, label %runtime.invalid.reference.7436 i32 3, label %runtime.scratch.capacity.7437 i32 4, label %runtime.retained.capacity.7438 ]
runtime.invalid.request.7435:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7436:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7437:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7438:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7439:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7434:
  %record.make.handle.7440 = load i64, ptr %workspace.slot.7432, align 8
  %ctx.field.7441 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7442 = load i32, ptr %ctx.field.7441, align 4
  %steps.next.7443 = add i32 %steps.current.7442, 1
  store i32 %steps.next.7443, ptr %ctx.field.7441, align 4
  %steps.over.7444 = icmp ugt i32 %steps.next.7443, 10000
  br i1 %steps.over.7444, label %failure.7445, label %continue.7446
failure.7445:
  %ctx.field.7447 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 763, ptr %ctx.field.7447, align 4
  %status.diagnostic.7448 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7448, align 4
  ret void
continue.7446:
  %ctx.field.7449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7450 = load i32, ptr %ctx.field.7449, align 4
  %steps.next.7451 = add i32 %steps.current.7450, 1
  store i32 %steps.next.7451, ptr %ctx.field.7449, align 4
  %steps.over.7452 = icmp ugt i32 %steps.next.7451, 10000
  br i1 %steps.over.7452, label %failure.7453, label %continue.7454
failure.7453:
  %ctx.field.7455 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 764, ptr %ctx.field.7455, align 4
  %status.diagnostic.7456 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7456, align 4
  ret void
continue.7454:
  %ctx.field.7457 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7458 = load i32, ptr %ctx.field.7457, align 4
  %steps.next.7459 = add i32 %steps.current.7458, 1
  store i32 %steps.next.7459, ptr %ctx.field.7457, align 4
  %steps.over.7460 = icmp ugt i32 %steps.next.7459, 10000
  br i1 %steps.over.7460, label %failure.7461, label %continue.7462
failure.7461:
  %ctx.field.7463 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 765, ptr %ctx.field.7463, align 4
  %status.diagnostic.7464 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7464, align 4
  ret void
continue.7462:
  %depth.exceeded.7465 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7465, label %failure.7466, label %continue.7467
failure.7466:
  %ctx.field.7468 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 766, ptr %ctx.field.7468, align 4
  %status.diagnostic.7469 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7469, align 4
  ret void
continue.7467:
  %workspace.slot.7470 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7440, ptr %workspace.slot.7470, align 8
  %workspace.slot.7471 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7472 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 106, ptr %outputs, i32 1, ptr %workspace.slot.7471)
  switch i32 %record.make.status.7472, label %runtime.invalid.result.7478 [ i32 0, label %runtime.success.7473 i32 1, label %runtime.invalid.request.7474 i32 2, label %runtime.invalid.reference.7475 i32 3, label %runtime.scratch.capacity.7476 i32 4, label %runtime.retained.capacity.7477 ]
runtime.invalid.request.7474:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7475:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7476:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7477:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7478:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7473:
  %record.make.handle.7479 = load i64, ptr %workspace.slot.7471, align 8
  %ctx.field.7480 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7481 = load i32, ptr %ctx.field.7480, align 4
  %steps.next.7482 = add i32 %steps.current.7481, 1
  store i32 %steps.next.7482, ptr %ctx.field.7480, align 4
  %steps.over.7483 = icmp ugt i32 %steps.next.7482, 10000
  br i1 %steps.over.7483, label %failure.7484, label %continue.7485
failure.7484:
  %ctx.field.7486 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 767, ptr %ctx.field.7486, align 4
  %status.diagnostic.7487 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7487, align 4
  ret void
continue.7485:
  %ctx.field.7488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7489 = load i32, ptr %ctx.field.7488, align 4
  %steps.next.7490 = add i32 %steps.current.7489, 1
  store i32 %steps.next.7490, ptr %ctx.field.7488, align 4
  %steps.over.7491 = icmp ugt i32 %steps.next.7490, 10000
  br i1 %steps.over.7491, label %failure.7492, label %continue.7493
failure.7492:
  %ctx.field.7494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 768, ptr %ctx.field.7494, align 4
  %status.diagnostic.7495 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7495, align 4
  ret void
continue.7493:
  %ctx.field.7496 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7497 = load i32, ptr %ctx.field.7496, align 4
  %steps.next.7498 = add i32 %steps.current.7497, 1
  store i32 %steps.next.7498, ptr %ctx.field.7496, align 4
  %steps.over.7499 = icmp ugt i32 %steps.next.7498, 10000
  br i1 %steps.over.7499, label %failure.7500, label %continue.7501
failure.7500:
  %ctx.field.7502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 769, ptr %ctx.field.7502, align 4
  %status.diagnostic.7503 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7503, align 4
  ret void
continue.7501:
  %depth.exceeded.7504 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7504, label %failure.7505, label %continue.7506
failure.7505:
  %ctx.field.7507 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 770, ptr %ctx.field.7507, align 4
  %status.diagnostic.7508 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7508, align 4
  ret void
continue.7506:
  %workspace.slot.7509 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7479, ptr %workspace.slot.7509, align 8
  %workspace.slot.7510 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7511 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 107, ptr %outputs, i32 1, ptr %workspace.slot.7510)
  switch i32 %record.make.status.7511, label %runtime.invalid.result.7517 [ i32 0, label %runtime.success.7512 i32 1, label %runtime.invalid.request.7513 i32 2, label %runtime.invalid.reference.7514 i32 3, label %runtime.scratch.capacity.7515 i32 4, label %runtime.retained.capacity.7516 ]
runtime.invalid.request.7513:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7514:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7515:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7516:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7517:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7512:
  %record.make.handle.7518 = load i64, ptr %workspace.slot.7510, align 8
  %ctx.field.7519 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7520 = load i32, ptr %ctx.field.7519, align 4
  %steps.next.7521 = add i32 %steps.current.7520, 1
  store i32 %steps.next.7521, ptr %ctx.field.7519, align 4
  %steps.over.7522 = icmp ugt i32 %steps.next.7521, 10000
  br i1 %steps.over.7522, label %failure.7523, label %continue.7524
failure.7523:
  %ctx.field.7525 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 771, ptr %ctx.field.7525, align 4
  %status.diagnostic.7526 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7526, align 4
  ret void
continue.7524:
  %ctx.field.7527 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7528 = load i32, ptr %ctx.field.7527, align 4
  %steps.next.7529 = add i32 %steps.current.7528, 1
  store i32 %steps.next.7529, ptr %ctx.field.7527, align 4
  %steps.over.7530 = icmp ugt i32 %steps.next.7529, 10000
  br i1 %steps.over.7530, label %failure.7531, label %continue.7532
failure.7531:
  %ctx.field.7533 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 772, ptr %ctx.field.7533, align 4
  %status.diagnostic.7534 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7534, align 4
  ret void
continue.7532:
  %ctx.field.7535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7536 = load i32, ptr %ctx.field.7535, align 4
  %steps.next.7537 = add i32 %steps.current.7536, 1
  store i32 %steps.next.7537, ptr %ctx.field.7535, align 4
  %steps.over.7538 = icmp ugt i32 %steps.next.7537, 10000
  br i1 %steps.over.7538, label %failure.7539, label %continue.7540
failure.7539:
  %ctx.field.7541 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 773, ptr %ctx.field.7541, align 4
  %status.diagnostic.7542 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7542, align 4
  ret void
continue.7540:
  %depth.exceeded.7543 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7543, label %failure.7544, label %continue.7545
failure.7544:
  %ctx.field.7546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 774, ptr %ctx.field.7546, align 4
  %status.diagnostic.7547 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7547, align 4
  ret void
continue.7545:
  %workspace.slot.7548 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7518, ptr %workspace.slot.7548, align 8
  %workspace.slot.7549 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7550 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 108, ptr %outputs, i32 1, ptr %workspace.slot.7549)
  switch i32 %record.make.status.7550, label %runtime.invalid.result.7556 [ i32 0, label %runtime.success.7551 i32 1, label %runtime.invalid.request.7552 i32 2, label %runtime.invalid.reference.7553 i32 3, label %runtime.scratch.capacity.7554 i32 4, label %runtime.retained.capacity.7555 ]
runtime.invalid.request.7552:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7553:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7554:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7555:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7556:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7551:
  %record.make.handle.7557 = load i64, ptr %workspace.slot.7549, align 8
  %ctx.field.7558 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7559 = load i32, ptr %ctx.field.7558, align 4
  %steps.next.7560 = add i32 %steps.current.7559, 1
  store i32 %steps.next.7560, ptr %ctx.field.7558, align 4
  %steps.over.7561 = icmp ugt i32 %steps.next.7560, 10000
  br i1 %steps.over.7561, label %failure.7562, label %continue.7563
failure.7562:
  %ctx.field.7564 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 775, ptr %ctx.field.7564, align 4
  %status.diagnostic.7565 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7565, align 4
  ret void
continue.7563:
  %ctx.field.7566 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7567 = load i32, ptr %ctx.field.7566, align 4
  %steps.next.7568 = add i32 %steps.current.7567, 1
  store i32 %steps.next.7568, ptr %ctx.field.7566, align 4
  %steps.over.7569 = icmp ugt i32 %steps.next.7568, 10000
  br i1 %steps.over.7569, label %failure.7570, label %continue.7571
failure.7570:
  %ctx.field.7572 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 776, ptr %ctx.field.7572, align 4
  %status.diagnostic.7573 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7573, align 4
  ret void
continue.7571:
  %ctx.field.7574 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7575 = load i32, ptr %ctx.field.7574, align 4
  %steps.next.7576 = add i32 %steps.current.7575, 1
  store i32 %steps.next.7576, ptr %ctx.field.7574, align 4
  %steps.over.7577 = icmp ugt i32 %steps.next.7576, 10000
  br i1 %steps.over.7577, label %failure.7578, label %continue.7579
failure.7578:
  %ctx.field.7580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 777, ptr %ctx.field.7580, align 4
  %status.diagnostic.7581 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7581, align 4
  ret void
continue.7579:
  %depth.exceeded.7582 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7582, label %failure.7583, label %continue.7584
failure.7583:
  %ctx.field.7585 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 778, ptr %ctx.field.7585, align 4
  %status.diagnostic.7586 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7586, align 4
  ret void
continue.7584:
  %workspace.slot.7587 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7557, ptr %workspace.slot.7587, align 8
  %workspace.slot.7588 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7589 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 109, ptr %outputs, i32 1, ptr %workspace.slot.7588)
  switch i32 %record.make.status.7589, label %runtime.invalid.result.7595 [ i32 0, label %runtime.success.7590 i32 1, label %runtime.invalid.request.7591 i32 2, label %runtime.invalid.reference.7592 i32 3, label %runtime.scratch.capacity.7593 i32 4, label %runtime.retained.capacity.7594 ]
runtime.invalid.request.7591:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7592:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7593:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7594:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7595:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7590:
  %record.make.handle.7596 = load i64, ptr %workspace.slot.7588, align 8
  %ctx.field.7597 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7598 = load i32, ptr %ctx.field.7597, align 4
  %steps.next.7599 = add i32 %steps.current.7598, 1
  store i32 %steps.next.7599, ptr %ctx.field.7597, align 4
  %steps.over.7600 = icmp ugt i32 %steps.next.7599, 10000
  br i1 %steps.over.7600, label %failure.7601, label %continue.7602
failure.7601:
  %ctx.field.7603 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 779, ptr %ctx.field.7603, align 4
  %status.diagnostic.7604 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7604, align 4
  ret void
continue.7602:
  %ctx.field.7605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7606 = load i32, ptr %ctx.field.7605, align 4
  %steps.next.7607 = add i32 %steps.current.7606, 1
  store i32 %steps.next.7607, ptr %ctx.field.7605, align 4
  %steps.over.7608 = icmp ugt i32 %steps.next.7607, 10000
  br i1 %steps.over.7608, label %failure.7609, label %continue.7610
failure.7609:
  %ctx.field.7611 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 780, ptr %ctx.field.7611, align 4
  %status.diagnostic.7612 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7612, align 4
  ret void
continue.7610:
  %ctx.field.7613 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7614 = load i32, ptr %ctx.field.7613, align 4
  %steps.next.7615 = add i32 %steps.current.7614, 1
  store i32 %steps.next.7615, ptr %ctx.field.7613, align 4
  %steps.over.7616 = icmp ugt i32 %steps.next.7615, 10000
  br i1 %steps.over.7616, label %failure.7617, label %continue.7618
failure.7617:
  %ctx.field.7619 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 781, ptr %ctx.field.7619, align 4
  %status.diagnostic.7620 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7620, align 4
  ret void
continue.7618:
  %depth.exceeded.7621 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7621, label %failure.7622, label %continue.7623
failure.7622:
  %ctx.field.7624 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 782, ptr %ctx.field.7624, align 4
  %status.diagnostic.7625 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7625, align 4
  ret void
continue.7623:
  %workspace.slot.7626 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7596, ptr %workspace.slot.7626, align 8
  %workspace.slot.7627 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7628 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 110, ptr %outputs, i32 1, ptr %workspace.slot.7627)
  switch i32 %record.make.status.7628, label %runtime.invalid.result.7634 [ i32 0, label %runtime.success.7629 i32 1, label %runtime.invalid.request.7630 i32 2, label %runtime.invalid.reference.7631 i32 3, label %runtime.scratch.capacity.7632 i32 4, label %runtime.retained.capacity.7633 ]
runtime.invalid.request.7630:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7631:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7632:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7633:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7634:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7629:
  %record.make.handle.7635 = load i64, ptr %workspace.slot.7627, align 8
  %ctx.field.7636 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7637 = load i32, ptr %ctx.field.7636, align 4
  %steps.next.7638 = add i32 %steps.current.7637, 1
  store i32 %steps.next.7638, ptr %ctx.field.7636, align 4
  %steps.over.7639 = icmp ugt i32 %steps.next.7638, 10000
  br i1 %steps.over.7639, label %failure.7640, label %continue.7641
failure.7640:
  %ctx.field.7642 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 783, ptr %ctx.field.7642, align 4
  %status.diagnostic.7643 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7643, align 4
  ret void
continue.7641:
  %ctx.field.7644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7645 = load i32, ptr %ctx.field.7644, align 4
  %steps.next.7646 = add i32 %steps.current.7645, 1
  store i32 %steps.next.7646, ptr %ctx.field.7644, align 4
  %steps.over.7647 = icmp ugt i32 %steps.next.7646, 10000
  br i1 %steps.over.7647, label %failure.7648, label %continue.7649
failure.7648:
  %ctx.field.7650 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 784, ptr %ctx.field.7650, align 4
  %status.diagnostic.7651 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7651, align 4
  ret void
continue.7649:
  %ctx.field.7652 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7653 = load i32, ptr %ctx.field.7652, align 4
  %steps.next.7654 = add i32 %steps.current.7653, 1
  store i32 %steps.next.7654, ptr %ctx.field.7652, align 4
  %steps.over.7655 = icmp ugt i32 %steps.next.7654, 10000
  br i1 %steps.over.7655, label %failure.7656, label %continue.7657
failure.7656:
  %ctx.field.7658 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 785, ptr %ctx.field.7658, align 4
  %status.diagnostic.7659 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7659, align 4
  ret void
continue.7657:
  %depth.exceeded.7660 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7660, label %failure.7661, label %continue.7662
failure.7661:
  %ctx.field.7663 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 786, ptr %ctx.field.7663, align 4
  %status.diagnostic.7664 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7664, align 4
  ret void
continue.7662:
  %workspace.slot.7665 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7635, ptr %workspace.slot.7665, align 8
  %workspace.slot.7666 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7667 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 111, ptr %outputs, i32 1, ptr %workspace.slot.7666)
  switch i32 %record.make.status.7667, label %runtime.invalid.result.7673 [ i32 0, label %runtime.success.7668 i32 1, label %runtime.invalid.request.7669 i32 2, label %runtime.invalid.reference.7670 i32 3, label %runtime.scratch.capacity.7671 i32 4, label %runtime.retained.capacity.7672 ]
runtime.invalid.request.7669:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7670:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7671:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7672:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7673:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7668:
  %record.make.handle.7674 = load i64, ptr %workspace.slot.7666, align 8
  %ctx.field.7675 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7676 = load i32, ptr %ctx.field.7675, align 4
  %steps.next.7677 = add i32 %steps.current.7676, 1
  store i32 %steps.next.7677, ptr %ctx.field.7675, align 4
  %steps.over.7678 = icmp ugt i32 %steps.next.7677, 10000
  br i1 %steps.over.7678, label %failure.7679, label %continue.7680
failure.7679:
  %ctx.field.7681 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 787, ptr %ctx.field.7681, align 4
  %status.diagnostic.7682 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7682, align 4
  ret void
continue.7680:
  %ctx.field.7683 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7684 = load i32, ptr %ctx.field.7683, align 4
  %steps.next.7685 = add i32 %steps.current.7684, 1
  store i32 %steps.next.7685, ptr %ctx.field.7683, align 4
  %steps.over.7686 = icmp ugt i32 %steps.next.7685, 10000
  br i1 %steps.over.7686, label %failure.7687, label %continue.7688
failure.7687:
  %ctx.field.7689 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 788, ptr %ctx.field.7689, align 4
  %status.diagnostic.7690 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7690, align 4
  ret void
continue.7688:
  %ctx.field.7691 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7692 = load i32, ptr %ctx.field.7691, align 4
  %steps.next.7693 = add i32 %steps.current.7692, 1
  store i32 %steps.next.7693, ptr %ctx.field.7691, align 4
  %steps.over.7694 = icmp ugt i32 %steps.next.7693, 10000
  br i1 %steps.over.7694, label %failure.7695, label %continue.7696
failure.7695:
  %ctx.field.7697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 789, ptr %ctx.field.7697, align 4
  %status.diagnostic.7698 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7698, align 4
  ret void
continue.7696:
  %depth.exceeded.7699 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7699, label %failure.7700, label %continue.7701
failure.7700:
  %ctx.field.7702 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 790, ptr %ctx.field.7702, align 4
  %status.diagnostic.7703 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7703, align 4
  ret void
continue.7701:
  %workspace.slot.7704 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7674, ptr %workspace.slot.7704, align 8
  %workspace.slot.7705 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7706 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 112, ptr %outputs, i32 1, ptr %workspace.slot.7705)
  switch i32 %record.make.status.7706, label %runtime.invalid.result.7712 [ i32 0, label %runtime.success.7707 i32 1, label %runtime.invalid.request.7708 i32 2, label %runtime.invalid.reference.7709 i32 3, label %runtime.scratch.capacity.7710 i32 4, label %runtime.retained.capacity.7711 ]
runtime.invalid.request.7708:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7709:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7710:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7711:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7712:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7707:
  %record.make.handle.7713 = load i64, ptr %workspace.slot.7705, align 8
  %ctx.field.7714 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7715 = load i32, ptr %ctx.field.7714, align 4
  %steps.next.7716 = add i32 %steps.current.7715, 1
  store i32 %steps.next.7716, ptr %ctx.field.7714, align 4
  %steps.over.7717 = icmp ugt i32 %steps.next.7716, 10000
  br i1 %steps.over.7717, label %failure.7718, label %continue.7719
failure.7718:
  %ctx.field.7720 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 791, ptr %ctx.field.7720, align 4
  %status.diagnostic.7721 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7721, align 4
  ret void
continue.7719:
  %ctx.field.7722 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7723 = load i32, ptr %ctx.field.7722, align 4
  %steps.next.7724 = add i32 %steps.current.7723, 1
  store i32 %steps.next.7724, ptr %ctx.field.7722, align 4
  %steps.over.7725 = icmp ugt i32 %steps.next.7724, 10000
  br i1 %steps.over.7725, label %failure.7726, label %continue.7727
failure.7726:
  %ctx.field.7728 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 792, ptr %ctx.field.7728, align 4
  %status.diagnostic.7729 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7729, align 4
  ret void
continue.7727:
  %ctx.field.7730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7731 = load i32, ptr %ctx.field.7730, align 4
  %steps.next.7732 = add i32 %steps.current.7731, 1
  store i32 %steps.next.7732, ptr %ctx.field.7730, align 4
  %steps.over.7733 = icmp ugt i32 %steps.next.7732, 10000
  br i1 %steps.over.7733, label %failure.7734, label %continue.7735
failure.7734:
  %ctx.field.7736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 793, ptr %ctx.field.7736, align 4
  %status.diagnostic.7737 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7737, align 4
  ret void
continue.7735:
  %depth.exceeded.7738 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7738, label %failure.7739, label %continue.7740
failure.7739:
  %ctx.field.7741 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 794, ptr %ctx.field.7741, align 4
  %status.diagnostic.7742 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7742, align 4
  ret void
continue.7740:
  %workspace.slot.7743 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7713, ptr %workspace.slot.7743, align 8
  %workspace.slot.7744 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7745 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 113, ptr %outputs, i32 1, ptr %workspace.slot.7744)
  switch i32 %record.make.status.7745, label %runtime.invalid.result.7751 [ i32 0, label %runtime.success.7746 i32 1, label %runtime.invalid.request.7747 i32 2, label %runtime.invalid.reference.7748 i32 3, label %runtime.scratch.capacity.7749 i32 4, label %runtime.retained.capacity.7750 ]
runtime.invalid.request.7747:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7748:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7749:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7750:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7751:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7746:
  %record.make.handle.7752 = load i64, ptr %workspace.slot.7744, align 8
  %ctx.field.7753 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7754 = load i32, ptr %ctx.field.7753, align 4
  %steps.next.7755 = add i32 %steps.current.7754, 1
  store i32 %steps.next.7755, ptr %ctx.field.7753, align 4
  %steps.over.7756 = icmp ugt i32 %steps.next.7755, 10000
  br i1 %steps.over.7756, label %failure.7757, label %continue.7758
failure.7757:
  %ctx.field.7759 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 795, ptr %ctx.field.7759, align 4
  %status.diagnostic.7760 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7760, align 4
  ret void
continue.7758:
  %ctx.field.7761 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7762 = load i32, ptr %ctx.field.7761, align 4
  %steps.next.7763 = add i32 %steps.current.7762, 1
  store i32 %steps.next.7763, ptr %ctx.field.7761, align 4
  %steps.over.7764 = icmp ugt i32 %steps.next.7763, 10000
  br i1 %steps.over.7764, label %failure.7765, label %continue.7766
failure.7765:
  %ctx.field.7767 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 796, ptr %ctx.field.7767, align 4
  %status.diagnostic.7768 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7768, align 4
  ret void
continue.7766:
  %ctx.field.7769 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7770 = load i32, ptr %ctx.field.7769, align 4
  %steps.next.7771 = add i32 %steps.current.7770, 1
  store i32 %steps.next.7771, ptr %ctx.field.7769, align 4
  %steps.over.7772 = icmp ugt i32 %steps.next.7771, 10000
  br i1 %steps.over.7772, label %failure.7773, label %continue.7774
failure.7773:
  %ctx.field.7775 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 797, ptr %ctx.field.7775, align 4
  %status.diagnostic.7776 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7776, align 4
  ret void
continue.7774:
  %depth.exceeded.7777 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7777, label %failure.7778, label %continue.7779
failure.7778:
  %ctx.field.7780 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 798, ptr %ctx.field.7780, align 4
  %status.diagnostic.7781 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7781, align 4
  ret void
continue.7779:
  %workspace.slot.7782 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7752, ptr %workspace.slot.7782, align 8
  %workspace.slot.7783 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7784 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 114, ptr %outputs, i32 1, ptr %workspace.slot.7783)
  switch i32 %record.make.status.7784, label %runtime.invalid.result.7790 [ i32 0, label %runtime.success.7785 i32 1, label %runtime.invalid.request.7786 i32 2, label %runtime.invalid.reference.7787 i32 3, label %runtime.scratch.capacity.7788 i32 4, label %runtime.retained.capacity.7789 ]
runtime.invalid.request.7786:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7787:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7788:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7789:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7790:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7785:
  %record.make.handle.7791 = load i64, ptr %workspace.slot.7783, align 8
  %ctx.field.7792 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7793 = load i32, ptr %ctx.field.7792, align 4
  %steps.next.7794 = add i32 %steps.current.7793, 1
  store i32 %steps.next.7794, ptr %ctx.field.7792, align 4
  %steps.over.7795 = icmp ugt i32 %steps.next.7794, 10000
  br i1 %steps.over.7795, label %failure.7796, label %continue.7797
failure.7796:
  %ctx.field.7798 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 799, ptr %ctx.field.7798, align 4
  %status.diagnostic.7799 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7799, align 4
  ret void
continue.7797:
  %ctx.field.7800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7801 = load i32, ptr %ctx.field.7800, align 4
  %steps.next.7802 = add i32 %steps.current.7801, 1
  store i32 %steps.next.7802, ptr %ctx.field.7800, align 4
  %steps.over.7803 = icmp ugt i32 %steps.next.7802, 10000
  br i1 %steps.over.7803, label %failure.7804, label %continue.7805
failure.7804:
  %ctx.field.7806 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 800, ptr %ctx.field.7806, align 4
  %status.diagnostic.7807 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7807, align 4
  ret void
continue.7805:
  %ctx.field.7808 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7809 = load i32, ptr %ctx.field.7808, align 4
  %steps.next.7810 = add i32 %steps.current.7809, 1
  store i32 %steps.next.7810, ptr %ctx.field.7808, align 4
  %steps.over.7811 = icmp ugt i32 %steps.next.7810, 10000
  br i1 %steps.over.7811, label %failure.7812, label %continue.7813
failure.7812:
  %ctx.field.7814 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 801, ptr %ctx.field.7814, align 4
  %status.diagnostic.7815 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7815, align 4
  ret void
continue.7813:
  %depth.exceeded.7816 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7816, label %failure.7817, label %continue.7818
failure.7817:
  %ctx.field.7819 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 802, ptr %ctx.field.7819, align 4
  %status.diagnostic.7820 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7820, align 4
  ret void
continue.7818:
  %workspace.slot.7821 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7791, ptr %workspace.slot.7821, align 8
  %workspace.slot.7822 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7823 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 117, ptr %outputs, i32 1, ptr %workspace.slot.7822)
  switch i32 %record.make.status.7823, label %runtime.invalid.result.7829 [ i32 0, label %runtime.success.7824 i32 1, label %runtime.invalid.request.7825 i32 2, label %runtime.invalid.reference.7826 i32 3, label %runtime.scratch.capacity.7827 i32 4, label %runtime.retained.capacity.7828 ]
runtime.invalid.request.7825:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7826:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7827:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7828:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7829:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7824:
  %record.make.handle.7830 = load i64, ptr %workspace.slot.7822, align 8
  %ctx.field.7831 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7832 = load i32, ptr %ctx.field.7831, align 4
  %steps.next.7833 = add i32 %steps.current.7832, 1
  store i32 %steps.next.7833, ptr %ctx.field.7831, align 4
  %steps.over.7834 = icmp ugt i32 %steps.next.7833, 10000
  br i1 %steps.over.7834, label %failure.7835, label %continue.7836
failure.7835:
  %ctx.field.7837 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 803, ptr %ctx.field.7837, align 4
  %status.diagnostic.7838 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7838, align 4
  ret void
continue.7836:
  %ctx.field.7839 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7840 = load i32, ptr %ctx.field.7839, align 4
  %steps.next.7841 = add i32 %steps.current.7840, 1
  store i32 %steps.next.7841, ptr %ctx.field.7839, align 4
  %steps.over.7842 = icmp ugt i32 %steps.next.7841, 10000
  br i1 %steps.over.7842, label %failure.7843, label %continue.7844
failure.7843:
  %ctx.field.7845 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 804, ptr %ctx.field.7845, align 4
  %status.diagnostic.7846 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7846, align 4
  ret void
continue.7844:
  %ctx.field.7847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7848 = load i32, ptr %ctx.field.7847, align 4
  %steps.next.7849 = add i32 %steps.current.7848, 1
  store i32 %steps.next.7849, ptr %ctx.field.7847, align 4
  %steps.over.7850 = icmp ugt i32 %steps.next.7849, 10000
  br i1 %steps.over.7850, label %failure.7851, label %continue.7852
failure.7851:
  %ctx.field.7853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 805, ptr %ctx.field.7853, align 4
  %status.diagnostic.7854 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7854, align 4
  ret void
continue.7852:
  %depth.exceeded.7855 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7855, label %failure.7856, label %continue.7857
failure.7856:
  %ctx.field.7858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 806, ptr %ctx.field.7858, align 4
  %status.diagnostic.7859 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7859, align 4
  ret void
continue.7857:
  %workspace.slot.7860 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7830, ptr %workspace.slot.7860, align 8
  %workspace.slot.7861 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7862 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 118, ptr %outputs, i32 1, ptr %workspace.slot.7861)
  switch i32 %record.make.status.7862, label %runtime.invalid.result.7868 [ i32 0, label %runtime.success.7863 i32 1, label %runtime.invalid.request.7864 i32 2, label %runtime.invalid.reference.7865 i32 3, label %runtime.scratch.capacity.7866 i32 4, label %runtime.retained.capacity.7867 ]
runtime.invalid.request.7864:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7865:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7866:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7867:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7868:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7863:
  %record.make.handle.7869 = load i64, ptr %workspace.slot.7861, align 8
  %ctx.field.7870 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7871 = load i32, ptr %ctx.field.7870, align 4
  %steps.next.7872 = add i32 %steps.current.7871, 1
  store i32 %steps.next.7872, ptr %ctx.field.7870, align 4
  %steps.over.7873 = icmp ugt i32 %steps.next.7872, 10000
  br i1 %steps.over.7873, label %failure.7874, label %continue.7875
failure.7874:
  %ctx.field.7876 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 807, ptr %ctx.field.7876, align 4
  %status.diagnostic.7877 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7877, align 4
  ret void
continue.7875:
  %ctx.field.7878 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7879 = load i32, ptr %ctx.field.7878, align 4
  %steps.next.7880 = add i32 %steps.current.7879, 1
  store i32 %steps.next.7880, ptr %ctx.field.7878, align 4
  %steps.over.7881 = icmp ugt i32 %steps.next.7880, 10000
  br i1 %steps.over.7881, label %failure.7882, label %continue.7883
failure.7882:
  %ctx.field.7884 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 808, ptr %ctx.field.7884, align 4
  %status.diagnostic.7885 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7885, align 4
  ret void
continue.7883:
  %ctx.field.7886 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7887 = load i32, ptr %ctx.field.7886, align 4
  %steps.next.7888 = add i32 %steps.current.7887, 1
  store i32 %steps.next.7888, ptr %ctx.field.7886, align 4
  %steps.over.7889 = icmp ugt i32 %steps.next.7888, 10000
  br i1 %steps.over.7889, label %failure.7890, label %continue.7891
failure.7890:
  %ctx.field.7892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 809, ptr %ctx.field.7892, align 4
  %status.diagnostic.7893 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7893, align 4
  ret void
continue.7891:
  %depth.exceeded.7894 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7894, label %failure.7895, label %continue.7896
failure.7895:
  %ctx.field.7897 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 810, ptr %ctx.field.7897, align 4
  %status.diagnostic.7898 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7898, align 4
  ret void
continue.7896:
  %workspace.slot.7899 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7869, ptr %workspace.slot.7899, align 8
  %workspace.slot.7900 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7901 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 119, ptr %outputs, i32 1, ptr %workspace.slot.7900)
  switch i32 %record.make.status.7901, label %runtime.invalid.result.7907 [ i32 0, label %runtime.success.7902 i32 1, label %runtime.invalid.request.7903 i32 2, label %runtime.invalid.reference.7904 i32 3, label %runtime.scratch.capacity.7905 i32 4, label %runtime.retained.capacity.7906 ]
runtime.invalid.request.7903:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7904:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7905:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7906:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7907:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7902:
  %record.make.handle.7908 = load i64, ptr %workspace.slot.7900, align 8
  %ctx.field.7909 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7910 = load i32, ptr %ctx.field.7909, align 4
  %steps.next.7911 = add i32 %steps.current.7910, 1
  store i32 %steps.next.7911, ptr %ctx.field.7909, align 4
  %steps.over.7912 = icmp ugt i32 %steps.next.7911, 10000
  br i1 %steps.over.7912, label %failure.7913, label %continue.7914
failure.7913:
  %ctx.field.7915 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 811, ptr %ctx.field.7915, align 4
  %status.diagnostic.7916 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7916, align 4
  ret void
continue.7914:
  %ctx.field.7917 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7918 = load i32, ptr %ctx.field.7917, align 4
  %steps.next.7919 = add i32 %steps.current.7918, 1
  store i32 %steps.next.7919, ptr %ctx.field.7917, align 4
  %steps.over.7920 = icmp ugt i32 %steps.next.7919, 10000
  br i1 %steps.over.7920, label %failure.7921, label %continue.7922
failure.7921:
  %ctx.field.7923 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 812, ptr %ctx.field.7923, align 4
  %status.diagnostic.7924 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7924, align 4
  ret void
continue.7922:
  %ctx.field.7925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7926 = load i32, ptr %ctx.field.7925, align 4
  %steps.next.7927 = add i32 %steps.current.7926, 1
  store i32 %steps.next.7927, ptr %ctx.field.7925, align 4
  %steps.over.7928 = icmp ugt i32 %steps.next.7927, 10000
  br i1 %steps.over.7928, label %failure.7929, label %continue.7930
failure.7929:
  %ctx.field.7931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 813, ptr %ctx.field.7931, align 4
  %status.diagnostic.7932 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7932, align 4
  ret void
continue.7930:
  %depth.exceeded.7933 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7933, label %failure.7934, label %continue.7935
failure.7934:
  %ctx.field.7936 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 814, ptr %ctx.field.7936, align 4
  %status.diagnostic.7937 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7937, align 4
  ret void
continue.7935:
  %workspace.slot.7938 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7908, ptr %workspace.slot.7938, align 8
  %workspace.slot.7939 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7940 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 120, ptr %outputs, i32 1, ptr %workspace.slot.7939)
  switch i32 %record.make.status.7940, label %runtime.invalid.result.7946 [ i32 0, label %runtime.success.7941 i32 1, label %runtime.invalid.request.7942 i32 2, label %runtime.invalid.reference.7943 i32 3, label %runtime.scratch.capacity.7944 i32 4, label %runtime.retained.capacity.7945 ]
runtime.invalid.request.7942:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7943:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7944:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7945:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7946:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7941:
  %record.make.handle.7947 = load i64, ptr %workspace.slot.7939, align 8
  %ctx.field.7948 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7949 = load i32, ptr %ctx.field.7948, align 4
  %steps.next.7950 = add i32 %steps.current.7949, 1
  store i32 %steps.next.7950, ptr %ctx.field.7948, align 4
  %steps.over.7951 = icmp ugt i32 %steps.next.7950, 10000
  br i1 %steps.over.7951, label %failure.7952, label %continue.7953
failure.7952:
  %ctx.field.7954 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 815, ptr %ctx.field.7954, align 4
  %status.diagnostic.7955 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7955, align 4
  ret void
continue.7953:
  %ctx.field.7956 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7957 = load i32, ptr %ctx.field.7956, align 4
  %steps.next.7958 = add i32 %steps.current.7957, 1
  store i32 %steps.next.7958, ptr %ctx.field.7956, align 4
  %steps.over.7959 = icmp ugt i32 %steps.next.7958, 10000
  br i1 %steps.over.7959, label %failure.7960, label %continue.7961
failure.7960:
  %ctx.field.7962 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 816, ptr %ctx.field.7962, align 4
  %status.diagnostic.7963 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7963, align 4
  ret void
continue.7961:
  %ctx.field.7964 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7965 = load i32, ptr %ctx.field.7964, align 4
  %steps.next.7966 = add i32 %steps.current.7965, 1
  store i32 %steps.next.7966, ptr %ctx.field.7964, align 4
  %steps.over.7967 = icmp ugt i32 %steps.next.7966, 10000
  br i1 %steps.over.7967, label %failure.7968, label %continue.7969
failure.7968:
  %ctx.field.7970 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 817, ptr %ctx.field.7970, align 4
  %status.diagnostic.7971 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7971, align 4
  ret void
continue.7969:
  %depth.exceeded.7972 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.7972, label %failure.7973, label %continue.7974
failure.7973:
  %ctx.field.7975 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 818, ptr %ctx.field.7975, align 4
  %status.diagnostic.7976 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7976, align 4
  ret void
continue.7974:
  %workspace.slot.7977 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7947, ptr %workspace.slot.7977, align 8
  %workspace.slot.7978 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.7979 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 121, ptr %outputs, i32 1, ptr %workspace.slot.7978)
  switch i32 %record.make.status.7979, label %runtime.invalid.result.7985 [ i32 0, label %runtime.success.7980 i32 1, label %runtime.invalid.request.7981 i32 2, label %runtime.invalid.reference.7982 i32 3, label %runtime.scratch.capacity.7983 i32 4, label %runtime.retained.capacity.7984 ]
runtime.invalid.request.7981:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.7982:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.7983:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.7984:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.7985:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.7980:
  %record.make.handle.7986 = load i64, ptr %workspace.slot.7978, align 8
  %ctx.field.7987 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7988 = load i32, ptr %ctx.field.7987, align 4
  %steps.next.7989 = add i32 %steps.current.7988, 1
  store i32 %steps.next.7989, ptr %ctx.field.7987, align 4
  %steps.over.7990 = icmp ugt i32 %steps.next.7989, 10000
  br i1 %steps.over.7990, label %failure.7991, label %continue.7992
failure.7991:
  %ctx.field.7993 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 819, ptr %ctx.field.7993, align 4
  %status.diagnostic.7994 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7994, align 4
  ret void
continue.7992:
  %ctx.field.7995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.7996 = load i32, ptr %ctx.field.7995, align 4
  %steps.next.7997 = add i32 %steps.current.7996, 1
  store i32 %steps.next.7997, ptr %ctx.field.7995, align 4
  %steps.over.7998 = icmp ugt i32 %steps.next.7997, 10000
  br i1 %steps.over.7998, label %failure.7999, label %continue.8000
failure.7999:
  %ctx.field.8001 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 820, ptr %ctx.field.8001, align 4
  %status.diagnostic.8002 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8002, align 4
  ret void
continue.8000:
  %ctx.field.8003 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8004 = load i32, ptr %ctx.field.8003, align 4
  %steps.next.8005 = add i32 %steps.current.8004, 1
  store i32 %steps.next.8005, ptr %ctx.field.8003, align 4
  %steps.over.8006 = icmp ugt i32 %steps.next.8005, 10000
  br i1 %steps.over.8006, label %failure.8007, label %continue.8008
failure.8007:
  %ctx.field.8009 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 821, ptr %ctx.field.8009, align 4
  %status.diagnostic.8010 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8010, align 4
  ret void
continue.8008:
  %depth.exceeded.8011 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8011, label %failure.8012, label %continue.8013
failure.8012:
  %ctx.field.8014 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 822, ptr %ctx.field.8014, align 4
  %status.diagnostic.8015 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8015, align 4
  ret void
continue.8013:
  %workspace.slot.8016 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.7986, ptr %workspace.slot.8016, align 8
  %workspace.slot.8017 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8018 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 122, ptr %outputs, i32 1, ptr %workspace.slot.8017)
  switch i32 %record.make.status.8018, label %runtime.invalid.result.8024 [ i32 0, label %runtime.success.8019 i32 1, label %runtime.invalid.request.8020 i32 2, label %runtime.invalid.reference.8021 i32 3, label %runtime.scratch.capacity.8022 i32 4, label %runtime.retained.capacity.8023 ]
runtime.invalid.request.8020:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8021:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8022:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8023:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8024:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8019:
  %record.make.handle.8025 = load i64, ptr %workspace.slot.8017, align 8
  %ctx.field.8026 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8027 = load i32, ptr %ctx.field.8026, align 4
  %steps.next.8028 = add i32 %steps.current.8027, 1
  store i32 %steps.next.8028, ptr %ctx.field.8026, align 4
  %steps.over.8029 = icmp ugt i32 %steps.next.8028, 10000
  br i1 %steps.over.8029, label %failure.8030, label %continue.8031
failure.8030:
  %ctx.field.8032 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 823, ptr %ctx.field.8032, align 4
  %status.diagnostic.8033 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8033, align 4
  ret void
continue.8031:
  %ctx.field.8034 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8035 = load i32, ptr %ctx.field.8034, align 4
  %steps.next.8036 = add i32 %steps.current.8035, 1
  store i32 %steps.next.8036, ptr %ctx.field.8034, align 4
  %steps.over.8037 = icmp ugt i32 %steps.next.8036, 10000
  br i1 %steps.over.8037, label %failure.8038, label %continue.8039
failure.8038:
  %ctx.field.8040 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 824, ptr %ctx.field.8040, align 4
  %status.diagnostic.8041 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8041, align 4
  ret void
continue.8039:
  %ctx.field.8042 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8043 = load i32, ptr %ctx.field.8042, align 4
  %steps.next.8044 = add i32 %steps.current.8043, 1
  store i32 %steps.next.8044, ptr %ctx.field.8042, align 4
  %steps.over.8045 = icmp ugt i32 %steps.next.8044, 10000
  br i1 %steps.over.8045, label %failure.8046, label %continue.8047
failure.8046:
  %ctx.field.8048 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 825, ptr %ctx.field.8048, align 4
  %status.diagnostic.8049 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8049, align 4
  ret void
continue.8047:
  %depth.exceeded.8050 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8050, label %failure.8051, label %continue.8052
failure.8051:
  %ctx.field.8053 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 826, ptr %ctx.field.8053, align 4
  %status.diagnostic.8054 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8054, align 4
  ret void
continue.8052:
  %workspace.slot.8055 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8025, ptr %workspace.slot.8055, align 8
  %workspace.slot.8056 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8057 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 123, ptr %outputs, i32 1, ptr %workspace.slot.8056)
  switch i32 %record.make.status.8057, label %runtime.invalid.result.8063 [ i32 0, label %runtime.success.8058 i32 1, label %runtime.invalid.request.8059 i32 2, label %runtime.invalid.reference.8060 i32 3, label %runtime.scratch.capacity.8061 i32 4, label %runtime.retained.capacity.8062 ]
runtime.invalid.request.8059:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8060:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8061:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8062:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8063:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8058:
  %record.make.handle.8064 = load i64, ptr %workspace.slot.8056, align 8
  %ctx.field.8065 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8066 = load i32, ptr %ctx.field.8065, align 4
  %steps.next.8067 = add i32 %steps.current.8066, 1
  store i32 %steps.next.8067, ptr %ctx.field.8065, align 4
  %steps.over.8068 = icmp ugt i32 %steps.next.8067, 10000
  br i1 %steps.over.8068, label %failure.8069, label %continue.8070
failure.8069:
  %ctx.field.8071 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 827, ptr %ctx.field.8071, align 4
  %status.diagnostic.8072 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8072, align 4
  ret void
continue.8070:
  %ctx.field.8073 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8074 = load i32, ptr %ctx.field.8073, align 4
  %steps.next.8075 = add i32 %steps.current.8074, 1
  store i32 %steps.next.8075, ptr %ctx.field.8073, align 4
  %steps.over.8076 = icmp ugt i32 %steps.next.8075, 10000
  br i1 %steps.over.8076, label %failure.8077, label %continue.8078
failure.8077:
  %ctx.field.8079 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 828, ptr %ctx.field.8079, align 4
  %status.diagnostic.8080 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8080, align 4
  ret void
continue.8078:
  %ctx.field.8081 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8082 = load i32, ptr %ctx.field.8081, align 4
  %steps.next.8083 = add i32 %steps.current.8082, 1
  store i32 %steps.next.8083, ptr %ctx.field.8081, align 4
  %steps.over.8084 = icmp ugt i32 %steps.next.8083, 10000
  br i1 %steps.over.8084, label %failure.8085, label %continue.8086
failure.8085:
  %ctx.field.8087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 829, ptr %ctx.field.8087, align 4
  %status.diagnostic.8088 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8088, align 4
  ret void
continue.8086:
  %depth.exceeded.8089 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8089, label %failure.8090, label %continue.8091
failure.8090:
  %ctx.field.8092 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 830, ptr %ctx.field.8092, align 4
  %status.diagnostic.8093 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8093, align 4
  ret void
continue.8091:
  %workspace.slot.8094 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8064, ptr %workspace.slot.8094, align 8
  %workspace.slot.8095 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8096 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 124, ptr %outputs, i32 1, ptr %workspace.slot.8095)
  switch i32 %record.make.status.8096, label %runtime.invalid.result.8102 [ i32 0, label %runtime.success.8097 i32 1, label %runtime.invalid.request.8098 i32 2, label %runtime.invalid.reference.8099 i32 3, label %runtime.scratch.capacity.8100 i32 4, label %runtime.retained.capacity.8101 ]
runtime.invalid.request.8098:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8099:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8100:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8101:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8102:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8097:
  %record.make.handle.8103 = load i64, ptr %workspace.slot.8095, align 8
  %ctx.field.8104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8105 = load i32, ptr %ctx.field.8104, align 4
  %steps.next.8106 = add i32 %steps.current.8105, 1
  store i32 %steps.next.8106, ptr %ctx.field.8104, align 4
  %steps.over.8107 = icmp ugt i32 %steps.next.8106, 10000
  br i1 %steps.over.8107, label %failure.8108, label %continue.8109
failure.8108:
  %ctx.field.8110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 831, ptr %ctx.field.8110, align 4
  %status.diagnostic.8111 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8111, align 4
  ret void
continue.8109:
  %ctx.field.8112 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8113 = load i32, ptr %ctx.field.8112, align 4
  %steps.next.8114 = add i32 %steps.current.8113, 1
  store i32 %steps.next.8114, ptr %ctx.field.8112, align 4
  %steps.over.8115 = icmp ugt i32 %steps.next.8114, 10000
  br i1 %steps.over.8115, label %failure.8116, label %continue.8117
failure.8116:
  %ctx.field.8118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 832, ptr %ctx.field.8118, align 4
  %status.diagnostic.8119 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8119, align 4
  ret void
continue.8117:
  %ctx.field.8120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8121 = load i32, ptr %ctx.field.8120, align 4
  %steps.next.8122 = add i32 %steps.current.8121, 1
  store i32 %steps.next.8122, ptr %ctx.field.8120, align 4
  %steps.over.8123 = icmp ugt i32 %steps.next.8122, 10000
  br i1 %steps.over.8123, label %failure.8124, label %continue.8125
failure.8124:
  %ctx.field.8126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 833, ptr %ctx.field.8126, align 4
  %status.diagnostic.8127 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8127, align 4
  ret void
continue.8125:
  %depth.exceeded.8128 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8128, label %failure.8129, label %continue.8130
failure.8129:
  %ctx.field.8131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 834, ptr %ctx.field.8131, align 4
  %status.diagnostic.8132 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8132, align 4
  ret void
continue.8130:
  %workspace.slot.8133 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8103, ptr %workspace.slot.8133, align 8
  %workspace.slot.8134 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8135 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 125, ptr %outputs, i32 1, ptr %workspace.slot.8134)
  switch i32 %record.make.status.8135, label %runtime.invalid.result.8141 [ i32 0, label %runtime.success.8136 i32 1, label %runtime.invalid.request.8137 i32 2, label %runtime.invalid.reference.8138 i32 3, label %runtime.scratch.capacity.8139 i32 4, label %runtime.retained.capacity.8140 ]
runtime.invalid.request.8137:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8138:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8139:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8140:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8141:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8136:
  %record.make.handle.8142 = load i64, ptr %workspace.slot.8134, align 8
  %ctx.field.8143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8144 = load i32, ptr %ctx.field.8143, align 4
  %steps.next.8145 = add i32 %steps.current.8144, 1
  store i32 %steps.next.8145, ptr %ctx.field.8143, align 4
  %steps.over.8146 = icmp ugt i32 %steps.next.8145, 10000
  br i1 %steps.over.8146, label %failure.8147, label %continue.8148
failure.8147:
  %ctx.field.8149 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 835, ptr %ctx.field.8149, align 4
  %status.diagnostic.8150 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8150, align 4
  ret void
continue.8148:
  %ctx.field.8151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8152 = load i32, ptr %ctx.field.8151, align 4
  %steps.next.8153 = add i32 %steps.current.8152, 1
  store i32 %steps.next.8153, ptr %ctx.field.8151, align 4
  %steps.over.8154 = icmp ugt i32 %steps.next.8153, 10000
  br i1 %steps.over.8154, label %failure.8155, label %continue.8156
failure.8155:
  %ctx.field.8157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 836, ptr %ctx.field.8157, align 4
  %status.diagnostic.8158 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8158, align 4
  ret void
continue.8156:
  %ctx.field.8159 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8160 = load i32, ptr %ctx.field.8159, align 4
  %steps.next.8161 = add i32 %steps.current.8160, 1
  store i32 %steps.next.8161, ptr %ctx.field.8159, align 4
  %steps.over.8162 = icmp ugt i32 %steps.next.8161, 10000
  br i1 %steps.over.8162, label %failure.8163, label %continue.8164
failure.8163:
  %ctx.field.8165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 837, ptr %ctx.field.8165, align 4
  %status.diagnostic.8166 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8166, align 4
  ret void
continue.8164:
  %depth.exceeded.8167 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8167, label %failure.8168, label %continue.8169
failure.8168:
  %ctx.field.8170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 838, ptr %ctx.field.8170, align 4
  %status.diagnostic.8171 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8171, align 4
  ret void
continue.8169:
  %workspace.slot.8172 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8142, ptr %workspace.slot.8172, align 8
  %workspace.slot.8173 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8174 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 126, ptr %outputs, i32 1, ptr %workspace.slot.8173)
  switch i32 %record.make.status.8174, label %runtime.invalid.result.8180 [ i32 0, label %runtime.success.8175 i32 1, label %runtime.invalid.request.8176 i32 2, label %runtime.invalid.reference.8177 i32 3, label %runtime.scratch.capacity.8178 i32 4, label %runtime.retained.capacity.8179 ]
runtime.invalid.request.8176:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8177:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8178:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8179:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8180:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8175:
  %record.make.handle.8181 = load i64, ptr %workspace.slot.8173, align 8
  %ctx.field.8182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8183 = load i32, ptr %ctx.field.8182, align 4
  %steps.next.8184 = add i32 %steps.current.8183, 1
  store i32 %steps.next.8184, ptr %ctx.field.8182, align 4
  %steps.over.8185 = icmp ugt i32 %steps.next.8184, 10000
  br i1 %steps.over.8185, label %failure.8186, label %continue.8187
failure.8186:
  %ctx.field.8188 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 839, ptr %ctx.field.8188, align 4
  %status.diagnostic.8189 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8189, align 4
  ret void
continue.8187:
  %ctx.field.8190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8191 = load i32, ptr %ctx.field.8190, align 4
  %steps.next.8192 = add i32 %steps.current.8191, 1
  store i32 %steps.next.8192, ptr %ctx.field.8190, align 4
  %steps.over.8193 = icmp ugt i32 %steps.next.8192, 10000
  br i1 %steps.over.8193, label %failure.8194, label %continue.8195
failure.8194:
  %ctx.field.8196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 840, ptr %ctx.field.8196, align 4
  %status.diagnostic.8197 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8197, align 4
  ret void
continue.8195:
  %ctx.field.8198 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8199 = load i32, ptr %ctx.field.8198, align 4
  %steps.next.8200 = add i32 %steps.current.8199, 1
  store i32 %steps.next.8200, ptr %ctx.field.8198, align 4
  %steps.over.8201 = icmp ugt i32 %steps.next.8200, 10000
  br i1 %steps.over.8201, label %failure.8202, label %continue.8203
failure.8202:
  %ctx.field.8204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 841, ptr %ctx.field.8204, align 4
  %status.diagnostic.8205 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8205, align 4
  ret void
continue.8203:
  %depth.exceeded.8206 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8206, label %failure.8207, label %continue.8208
failure.8207:
  %ctx.field.8209 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 842, ptr %ctx.field.8209, align 4
  %status.diagnostic.8210 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8210, align 4
  ret void
continue.8208:
  %workspace.slot.8211 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8181, ptr %workspace.slot.8211, align 8
  %workspace.slot.8212 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8213 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 128, ptr %outputs, i32 1, ptr %workspace.slot.8212)
  switch i32 %record.make.status.8213, label %runtime.invalid.result.8219 [ i32 0, label %runtime.success.8214 i32 1, label %runtime.invalid.request.8215 i32 2, label %runtime.invalid.reference.8216 i32 3, label %runtime.scratch.capacity.8217 i32 4, label %runtime.retained.capacity.8218 ]
runtime.invalid.request.8215:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8216:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8217:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8218:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8219:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8214:
  %record.make.handle.8220 = load i64, ptr %workspace.slot.8212, align 8
  %ctx.field.8221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8222 = load i32, ptr %ctx.field.8221, align 4
  %steps.next.8223 = add i32 %steps.current.8222, 1
  store i32 %steps.next.8223, ptr %ctx.field.8221, align 4
  %steps.over.8224 = icmp ugt i32 %steps.next.8223, 10000
  br i1 %steps.over.8224, label %failure.8225, label %continue.8226
failure.8225:
  %ctx.field.8227 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 843, ptr %ctx.field.8227, align 4
  %status.diagnostic.8228 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8228, align 4
  ret void
continue.8226:
  %ctx.field.8229 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8230 = load i32, ptr %ctx.field.8229, align 4
  %steps.next.8231 = add i32 %steps.current.8230, 1
  store i32 %steps.next.8231, ptr %ctx.field.8229, align 4
  %steps.over.8232 = icmp ugt i32 %steps.next.8231, 10000
  br i1 %steps.over.8232, label %failure.8233, label %continue.8234
failure.8233:
  %ctx.field.8235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 844, ptr %ctx.field.8235, align 4
  %status.diagnostic.8236 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8236, align 4
  ret void
continue.8234:
  %ctx.field.8237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8238 = load i32, ptr %ctx.field.8237, align 4
  %steps.next.8239 = add i32 %steps.current.8238, 1
  store i32 %steps.next.8239, ptr %ctx.field.8237, align 4
  %steps.over.8240 = icmp ugt i32 %steps.next.8239, 10000
  br i1 %steps.over.8240, label %failure.8241, label %continue.8242
failure.8241:
  %ctx.field.8243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 845, ptr %ctx.field.8243, align 4
  %status.diagnostic.8244 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8244, align 4
  ret void
continue.8242:
  %depth.exceeded.8245 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8245, label %failure.8246, label %continue.8247
failure.8246:
  %ctx.field.8248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 846, ptr %ctx.field.8248, align 4
  %status.diagnostic.8249 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8249, align 4
  ret void
continue.8247:
  %workspace.slot.8250 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8220, ptr %workspace.slot.8250, align 8
  %workspace.slot.8251 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8252 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 129, ptr %outputs, i32 1, ptr %workspace.slot.8251)
  switch i32 %record.make.status.8252, label %runtime.invalid.result.8258 [ i32 0, label %runtime.success.8253 i32 1, label %runtime.invalid.request.8254 i32 2, label %runtime.invalid.reference.8255 i32 3, label %runtime.scratch.capacity.8256 i32 4, label %runtime.retained.capacity.8257 ]
runtime.invalid.request.8254:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8255:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8256:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8257:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8258:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8253:
  %record.make.handle.8259 = load i64, ptr %workspace.slot.8251, align 8
  %ctx.field.8260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8261 = load i32, ptr %ctx.field.8260, align 4
  %steps.next.8262 = add i32 %steps.current.8261, 1
  store i32 %steps.next.8262, ptr %ctx.field.8260, align 4
  %steps.over.8263 = icmp ugt i32 %steps.next.8262, 10000
  br i1 %steps.over.8263, label %failure.8264, label %continue.8265
failure.8264:
  %ctx.field.8266 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 847, ptr %ctx.field.8266, align 4
  %status.diagnostic.8267 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8267, align 4
  ret void
continue.8265:
  %ctx.field.8268 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8269 = load i32, ptr %ctx.field.8268, align 4
  %steps.next.8270 = add i32 %steps.current.8269, 1
  store i32 %steps.next.8270, ptr %ctx.field.8268, align 4
  %steps.over.8271 = icmp ugt i32 %steps.next.8270, 10000
  br i1 %steps.over.8271, label %failure.8272, label %continue.8273
failure.8272:
  %ctx.field.8274 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 848, ptr %ctx.field.8274, align 4
  %status.diagnostic.8275 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8275, align 4
  ret void
continue.8273:
  %ctx.field.8276 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8277 = load i32, ptr %ctx.field.8276, align 4
  %steps.next.8278 = add i32 %steps.current.8277, 1
  store i32 %steps.next.8278, ptr %ctx.field.8276, align 4
  %steps.over.8279 = icmp ugt i32 %steps.next.8278, 10000
  br i1 %steps.over.8279, label %failure.8280, label %continue.8281
failure.8280:
  %ctx.field.8282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 849, ptr %ctx.field.8282, align 4
  %status.diagnostic.8283 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8283, align 4
  ret void
continue.8281:
  %depth.exceeded.8284 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8284, label %failure.8285, label %continue.8286
failure.8285:
  %ctx.field.8287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 850, ptr %ctx.field.8287, align 4
  %status.diagnostic.8288 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8288, align 4
  ret void
continue.8286:
  %workspace.slot.8289 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8259, ptr %workspace.slot.8289, align 8
  %workspace.slot.8290 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8291 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 130, ptr %outputs, i32 1, ptr %workspace.slot.8290)
  switch i32 %record.make.status.8291, label %runtime.invalid.result.8297 [ i32 0, label %runtime.success.8292 i32 1, label %runtime.invalid.request.8293 i32 2, label %runtime.invalid.reference.8294 i32 3, label %runtime.scratch.capacity.8295 i32 4, label %runtime.retained.capacity.8296 ]
runtime.invalid.request.8293:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8294:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8295:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8296:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8297:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8292:
  %record.make.handle.8298 = load i64, ptr %workspace.slot.8290, align 8
  %ctx.field.8299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8300 = load i32, ptr %ctx.field.8299, align 4
  %steps.next.8301 = add i32 %steps.current.8300, 1
  store i32 %steps.next.8301, ptr %ctx.field.8299, align 4
  %steps.over.8302 = icmp ugt i32 %steps.next.8301, 10000
  br i1 %steps.over.8302, label %failure.8303, label %continue.8304
failure.8303:
  %ctx.field.8305 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 851, ptr %ctx.field.8305, align 4
  %status.diagnostic.8306 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8306, align 4
  ret void
continue.8304:
  %ctx.field.8307 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8308 = load i32, ptr %ctx.field.8307, align 4
  %steps.next.8309 = add i32 %steps.current.8308, 1
  store i32 %steps.next.8309, ptr %ctx.field.8307, align 4
  %steps.over.8310 = icmp ugt i32 %steps.next.8309, 10000
  br i1 %steps.over.8310, label %failure.8311, label %continue.8312
failure.8311:
  %ctx.field.8313 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 852, ptr %ctx.field.8313, align 4
  %status.diagnostic.8314 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8314, align 4
  ret void
continue.8312:
  %ctx.field.8315 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8316 = load i32, ptr %ctx.field.8315, align 4
  %steps.next.8317 = add i32 %steps.current.8316, 1
  store i32 %steps.next.8317, ptr %ctx.field.8315, align 4
  %steps.over.8318 = icmp ugt i32 %steps.next.8317, 10000
  br i1 %steps.over.8318, label %failure.8319, label %continue.8320
failure.8319:
  %ctx.field.8321 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 853, ptr %ctx.field.8321, align 4
  %status.diagnostic.8322 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8322, align 4
  ret void
continue.8320:
  %depth.exceeded.8323 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8323, label %failure.8324, label %continue.8325
failure.8324:
  %ctx.field.8326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 854, ptr %ctx.field.8326, align 4
  %status.diagnostic.8327 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8327, align 4
  ret void
continue.8325:
  %workspace.slot.8328 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8298, ptr %workspace.slot.8328, align 8
  %workspace.slot.8329 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8330 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 131, ptr %outputs, i32 1, ptr %workspace.slot.8329)
  switch i32 %record.make.status.8330, label %runtime.invalid.result.8336 [ i32 0, label %runtime.success.8331 i32 1, label %runtime.invalid.request.8332 i32 2, label %runtime.invalid.reference.8333 i32 3, label %runtime.scratch.capacity.8334 i32 4, label %runtime.retained.capacity.8335 ]
runtime.invalid.request.8332:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8333:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8334:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8335:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8336:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8331:
  %record.make.handle.8337 = load i64, ptr %workspace.slot.8329, align 8
  %ctx.field.8338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8339 = load i32, ptr %ctx.field.8338, align 4
  %steps.next.8340 = add i32 %steps.current.8339, 1
  store i32 %steps.next.8340, ptr %ctx.field.8338, align 4
  %steps.over.8341 = icmp ugt i32 %steps.next.8340, 10000
  br i1 %steps.over.8341, label %failure.8342, label %continue.8343
failure.8342:
  %ctx.field.8344 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 855, ptr %ctx.field.8344, align 4
  %status.diagnostic.8345 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8345, align 4
  ret void
continue.8343:
  %ctx.field.8346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8347 = load i32, ptr %ctx.field.8346, align 4
  %steps.next.8348 = add i32 %steps.current.8347, 1
  store i32 %steps.next.8348, ptr %ctx.field.8346, align 4
  %steps.over.8349 = icmp ugt i32 %steps.next.8348, 10000
  br i1 %steps.over.8349, label %failure.8350, label %continue.8351
failure.8350:
  %ctx.field.8352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 856, ptr %ctx.field.8352, align 4
  %status.diagnostic.8353 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8353, align 4
  ret void
continue.8351:
  %ctx.field.8354 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8355 = load i32, ptr %ctx.field.8354, align 4
  %steps.next.8356 = add i32 %steps.current.8355, 1
  store i32 %steps.next.8356, ptr %ctx.field.8354, align 4
  %steps.over.8357 = icmp ugt i32 %steps.next.8356, 10000
  br i1 %steps.over.8357, label %failure.8358, label %continue.8359
failure.8358:
  %ctx.field.8360 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 857, ptr %ctx.field.8360, align 4
  %status.diagnostic.8361 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8361, align 4
  ret void
continue.8359:
  %depth.exceeded.8362 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8362, label %failure.8363, label %continue.8364
failure.8363:
  %ctx.field.8365 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 858, ptr %ctx.field.8365, align 4
  %status.diagnostic.8366 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8366, align 4
  ret void
continue.8364:
  %workspace.slot.8367 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8337, ptr %workspace.slot.8367, align 8
  %workspace.slot.8368 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8369 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 132, ptr %outputs, i32 1, ptr %workspace.slot.8368)
  switch i32 %record.make.status.8369, label %runtime.invalid.result.8375 [ i32 0, label %runtime.success.8370 i32 1, label %runtime.invalid.request.8371 i32 2, label %runtime.invalid.reference.8372 i32 3, label %runtime.scratch.capacity.8373 i32 4, label %runtime.retained.capacity.8374 ]
runtime.invalid.request.8371:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8372:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8373:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8374:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8375:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8370:
  %record.make.handle.8376 = load i64, ptr %workspace.slot.8368, align 8
  %ctx.field.8377 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8378 = load i32, ptr %ctx.field.8377, align 4
  %steps.next.8379 = add i32 %steps.current.8378, 1
  store i32 %steps.next.8379, ptr %ctx.field.8377, align 4
  %steps.over.8380 = icmp ugt i32 %steps.next.8379, 10000
  br i1 %steps.over.8380, label %failure.8381, label %continue.8382
failure.8381:
  %ctx.field.8383 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 859, ptr %ctx.field.8383, align 4
  %status.diagnostic.8384 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8384, align 4
  ret void
continue.8382:
  %ctx.field.8385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8386 = load i32, ptr %ctx.field.8385, align 4
  %steps.next.8387 = add i32 %steps.current.8386, 1
  store i32 %steps.next.8387, ptr %ctx.field.8385, align 4
  %steps.over.8388 = icmp ugt i32 %steps.next.8387, 10000
  br i1 %steps.over.8388, label %failure.8389, label %continue.8390
failure.8389:
  %ctx.field.8391 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 860, ptr %ctx.field.8391, align 4
  %status.diagnostic.8392 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8392, align 4
  ret void
continue.8390:
  %ctx.field.8393 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8394 = load i32, ptr %ctx.field.8393, align 4
  %steps.next.8395 = add i32 %steps.current.8394, 1
  store i32 %steps.next.8395, ptr %ctx.field.8393, align 4
  %steps.over.8396 = icmp ugt i32 %steps.next.8395, 10000
  br i1 %steps.over.8396, label %failure.8397, label %continue.8398
failure.8397:
  %ctx.field.8399 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 861, ptr %ctx.field.8399, align 4
  %status.diagnostic.8400 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8400, align 4
  ret void
continue.8398:
  %depth.exceeded.8401 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8401, label %failure.8402, label %continue.8403
failure.8402:
  %ctx.field.8404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 862, ptr %ctx.field.8404, align 4
  %status.diagnostic.8405 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8405, align 4
  ret void
continue.8403:
  %workspace.slot.8406 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8376, ptr %workspace.slot.8406, align 8
  %workspace.slot.8407 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8408 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 133, ptr %outputs, i32 1, ptr %workspace.slot.8407)
  switch i32 %record.make.status.8408, label %runtime.invalid.result.8414 [ i32 0, label %runtime.success.8409 i32 1, label %runtime.invalid.request.8410 i32 2, label %runtime.invalid.reference.8411 i32 3, label %runtime.scratch.capacity.8412 i32 4, label %runtime.retained.capacity.8413 ]
runtime.invalid.request.8410:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8411:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8412:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8413:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8414:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8409:
  %record.make.handle.8415 = load i64, ptr %workspace.slot.8407, align 8
  %ctx.field.8416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8417 = load i32, ptr %ctx.field.8416, align 4
  %steps.next.8418 = add i32 %steps.current.8417, 1
  store i32 %steps.next.8418, ptr %ctx.field.8416, align 4
  %steps.over.8419 = icmp ugt i32 %steps.next.8418, 10000
  br i1 %steps.over.8419, label %failure.8420, label %continue.8421
failure.8420:
  %ctx.field.8422 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 863, ptr %ctx.field.8422, align 4
  %status.diagnostic.8423 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8423, align 4
  ret void
continue.8421:
  %ctx.field.8424 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8425 = load i32, ptr %ctx.field.8424, align 4
  %steps.next.8426 = add i32 %steps.current.8425, 1
  store i32 %steps.next.8426, ptr %ctx.field.8424, align 4
  %steps.over.8427 = icmp ugt i32 %steps.next.8426, 10000
  br i1 %steps.over.8427, label %failure.8428, label %continue.8429
failure.8428:
  %ctx.field.8430 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 864, ptr %ctx.field.8430, align 4
  %status.diagnostic.8431 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8431, align 4
  ret void
continue.8429:
  %ctx.field.8432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8433 = load i32, ptr %ctx.field.8432, align 4
  %steps.next.8434 = add i32 %steps.current.8433, 1
  store i32 %steps.next.8434, ptr %ctx.field.8432, align 4
  %steps.over.8435 = icmp ugt i32 %steps.next.8434, 10000
  br i1 %steps.over.8435, label %failure.8436, label %continue.8437
failure.8436:
  %ctx.field.8438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 865, ptr %ctx.field.8438, align 4
  %status.diagnostic.8439 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8439, align 4
  ret void
continue.8437:
  %depth.exceeded.8440 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8440, label %failure.8441, label %continue.8442
failure.8441:
  %ctx.field.8443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 866, ptr %ctx.field.8443, align 4
  %status.diagnostic.8444 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8444, align 4
  ret void
continue.8442:
  %workspace.slot.8445 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8415, ptr %workspace.slot.8445, align 8
  %workspace.slot.8446 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8447 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 134, ptr %outputs, i32 1, ptr %workspace.slot.8446)
  switch i32 %record.make.status.8447, label %runtime.invalid.result.8453 [ i32 0, label %runtime.success.8448 i32 1, label %runtime.invalid.request.8449 i32 2, label %runtime.invalid.reference.8450 i32 3, label %runtime.scratch.capacity.8451 i32 4, label %runtime.retained.capacity.8452 ]
runtime.invalid.request.8449:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8450:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8451:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8452:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8453:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8448:
  %record.make.handle.8454 = load i64, ptr %workspace.slot.8446, align 8
  %ctx.field.8455 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8456 = load i32, ptr %ctx.field.8455, align 4
  %steps.next.8457 = add i32 %steps.current.8456, 1
  store i32 %steps.next.8457, ptr %ctx.field.8455, align 4
  %steps.over.8458 = icmp ugt i32 %steps.next.8457, 10000
  br i1 %steps.over.8458, label %failure.8459, label %continue.8460
failure.8459:
  %ctx.field.8461 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 867, ptr %ctx.field.8461, align 4
  %status.diagnostic.8462 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8462, align 4
  ret void
continue.8460:
  %ctx.field.8463 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8464 = load i32, ptr %ctx.field.8463, align 4
  %steps.next.8465 = add i32 %steps.current.8464, 1
  store i32 %steps.next.8465, ptr %ctx.field.8463, align 4
  %steps.over.8466 = icmp ugt i32 %steps.next.8465, 10000
  br i1 %steps.over.8466, label %failure.8467, label %continue.8468
failure.8467:
  %ctx.field.8469 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 868, ptr %ctx.field.8469, align 4
  %status.diagnostic.8470 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8470, align 4
  ret void
continue.8468:
  %ctx.field.8471 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8472 = load i32, ptr %ctx.field.8471, align 4
  %steps.next.8473 = add i32 %steps.current.8472, 1
  store i32 %steps.next.8473, ptr %ctx.field.8471, align 4
  %steps.over.8474 = icmp ugt i32 %steps.next.8473, 10000
  br i1 %steps.over.8474, label %failure.8475, label %continue.8476
failure.8475:
  %ctx.field.8477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 869, ptr %ctx.field.8477, align 4
  %status.diagnostic.8478 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8478, align 4
  ret void
continue.8476:
  %depth.exceeded.8479 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8479, label %failure.8480, label %continue.8481
failure.8480:
  %ctx.field.8482 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 870, ptr %ctx.field.8482, align 4
  %status.diagnostic.8483 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8483, align 4
  ret void
continue.8481:
  %workspace.slot.8484 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8454, ptr %workspace.slot.8484, align 8
  %workspace.slot.8485 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8486 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 135, ptr %outputs, i32 1, ptr %workspace.slot.8485)
  switch i32 %record.make.status.8486, label %runtime.invalid.result.8492 [ i32 0, label %runtime.success.8487 i32 1, label %runtime.invalid.request.8488 i32 2, label %runtime.invalid.reference.8489 i32 3, label %runtime.scratch.capacity.8490 i32 4, label %runtime.retained.capacity.8491 ]
runtime.invalid.request.8488:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8489:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8490:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8491:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8492:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8487:
  %record.make.handle.8493 = load i64, ptr %workspace.slot.8485, align 8
  %ctx.field.8494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8495 = load i32, ptr %ctx.field.8494, align 4
  %steps.next.8496 = add i32 %steps.current.8495, 1
  store i32 %steps.next.8496, ptr %ctx.field.8494, align 4
  %steps.over.8497 = icmp ugt i32 %steps.next.8496, 10000
  br i1 %steps.over.8497, label %failure.8498, label %continue.8499
failure.8498:
  %ctx.field.8500 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 871, ptr %ctx.field.8500, align 4
  %status.diagnostic.8501 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8501, align 4
  ret void
continue.8499:
  %ctx.field.8502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8503 = load i32, ptr %ctx.field.8502, align 4
  %steps.next.8504 = add i32 %steps.current.8503, 1
  store i32 %steps.next.8504, ptr %ctx.field.8502, align 4
  %steps.over.8505 = icmp ugt i32 %steps.next.8504, 10000
  br i1 %steps.over.8505, label %failure.8506, label %continue.8507
failure.8506:
  %ctx.field.8508 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 872, ptr %ctx.field.8508, align 4
  %status.diagnostic.8509 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8509, align 4
  ret void
continue.8507:
  %ctx.field.8510 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8511 = load i32, ptr %ctx.field.8510, align 4
  %steps.next.8512 = add i32 %steps.current.8511, 1
  store i32 %steps.next.8512, ptr %ctx.field.8510, align 4
  %steps.over.8513 = icmp ugt i32 %steps.next.8512, 10000
  br i1 %steps.over.8513, label %failure.8514, label %continue.8515
failure.8514:
  %ctx.field.8516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 873, ptr %ctx.field.8516, align 4
  %status.diagnostic.8517 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8517, align 4
  ret void
continue.8515:
  %depth.exceeded.8518 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8518, label %failure.8519, label %continue.8520
failure.8519:
  %ctx.field.8521 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 874, ptr %ctx.field.8521, align 4
  %status.diagnostic.8522 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8522, align 4
  ret void
continue.8520:
  %workspace.slot.8523 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8493, ptr %workspace.slot.8523, align 8
  %workspace.slot.8524 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8525 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 136, ptr %outputs, i32 1, ptr %workspace.slot.8524)
  switch i32 %record.make.status.8525, label %runtime.invalid.result.8531 [ i32 0, label %runtime.success.8526 i32 1, label %runtime.invalid.request.8527 i32 2, label %runtime.invalid.reference.8528 i32 3, label %runtime.scratch.capacity.8529 i32 4, label %runtime.retained.capacity.8530 ]
runtime.invalid.request.8527:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8528:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8529:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8530:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8531:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8526:
  %record.make.handle.8532 = load i64, ptr %workspace.slot.8524, align 8
  %ctx.field.8533 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8534 = load i32, ptr %ctx.field.8533, align 4
  %steps.next.8535 = add i32 %steps.current.8534, 1
  store i32 %steps.next.8535, ptr %ctx.field.8533, align 4
  %steps.over.8536 = icmp ugt i32 %steps.next.8535, 10000
  br i1 %steps.over.8536, label %failure.8537, label %continue.8538
failure.8537:
  %ctx.field.8539 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 875, ptr %ctx.field.8539, align 4
  %status.diagnostic.8540 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8540, align 4
  ret void
continue.8538:
  %ctx.field.8541 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8542 = load i32, ptr %ctx.field.8541, align 4
  %steps.next.8543 = add i32 %steps.current.8542, 1
  store i32 %steps.next.8543, ptr %ctx.field.8541, align 4
  %steps.over.8544 = icmp ugt i32 %steps.next.8543, 10000
  br i1 %steps.over.8544, label %failure.8545, label %continue.8546
failure.8545:
  %ctx.field.8547 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 876, ptr %ctx.field.8547, align 4
  %status.diagnostic.8548 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8548, align 4
  ret void
continue.8546:
  %ctx.field.8549 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8550 = load i32, ptr %ctx.field.8549, align 4
  %steps.next.8551 = add i32 %steps.current.8550, 1
  store i32 %steps.next.8551, ptr %ctx.field.8549, align 4
  %steps.over.8552 = icmp ugt i32 %steps.next.8551, 10000
  br i1 %steps.over.8552, label %failure.8553, label %continue.8554
failure.8553:
  %ctx.field.8555 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 877, ptr %ctx.field.8555, align 4
  %status.diagnostic.8556 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8556, align 4
  ret void
continue.8554:
  %depth.exceeded.8557 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8557, label %failure.8558, label %continue.8559
failure.8558:
  %ctx.field.8560 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 878, ptr %ctx.field.8560, align 4
  %status.diagnostic.8561 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8561, align 4
  ret void
continue.8559:
  %workspace.slot.8562 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8532, ptr %workspace.slot.8562, align 8
  %workspace.slot.8563 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8564 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 137, ptr %outputs, i32 1, ptr %workspace.slot.8563)
  switch i32 %record.make.status.8564, label %runtime.invalid.result.8570 [ i32 0, label %runtime.success.8565 i32 1, label %runtime.invalid.request.8566 i32 2, label %runtime.invalid.reference.8567 i32 3, label %runtime.scratch.capacity.8568 i32 4, label %runtime.retained.capacity.8569 ]
runtime.invalid.request.8566:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8567:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8568:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8569:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8570:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8565:
  %record.make.handle.8571 = load i64, ptr %workspace.slot.8563, align 8
  %ctx.field.8572 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8573 = load i32, ptr %ctx.field.8572, align 4
  %steps.next.8574 = add i32 %steps.current.8573, 1
  store i32 %steps.next.8574, ptr %ctx.field.8572, align 4
  %steps.over.8575 = icmp ugt i32 %steps.next.8574, 10000
  br i1 %steps.over.8575, label %failure.8576, label %continue.8577
failure.8576:
  %ctx.field.8578 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 879, ptr %ctx.field.8578, align 4
  %status.diagnostic.8579 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8579, align 4
  ret void
continue.8577:
  %ctx.field.8580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8581 = load i32, ptr %ctx.field.8580, align 4
  %steps.next.8582 = add i32 %steps.current.8581, 1
  store i32 %steps.next.8582, ptr %ctx.field.8580, align 4
  %steps.over.8583 = icmp ugt i32 %steps.next.8582, 10000
  br i1 %steps.over.8583, label %failure.8584, label %continue.8585
failure.8584:
  %ctx.field.8586 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 880, ptr %ctx.field.8586, align 4
  %status.diagnostic.8587 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8587, align 4
  ret void
continue.8585:
  %ctx.field.8588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8589 = load i32, ptr %ctx.field.8588, align 4
  %steps.next.8590 = add i32 %steps.current.8589, 1
  store i32 %steps.next.8590, ptr %ctx.field.8588, align 4
  %steps.over.8591 = icmp ugt i32 %steps.next.8590, 10000
  br i1 %steps.over.8591, label %failure.8592, label %continue.8593
failure.8592:
  %ctx.field.8594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 881, ptr %ctx.field.8594, align 4
  %status.diagnostic.8595 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8595, align 4
  ret void
continue.8593:
  %depth.exceeded.8596 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8596, label %failure.8597, label %continue.8598
failure.8597:
  %ctx.field.8599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 882, ptr %ctx.field.8599, align 4
  %status.diagnostic.8600 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8600, align 4
  ret void
continue.8598:
  %workspace.slot.8601 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8571, ptr %workspace.slot.8601, align 8
  %workspace.slot.8602 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8603 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 139, ptr %outputs, i32 1, ptr %workspace.slot.8602)
  switch i32 %record.make.status.8603, label %runtime.invalid.result.8609 [ i32 0, label %runtime.success.8604 i32 1, label %runtime.invalid.request.8605 i32 2, label %runtime.invalid.reference.8606 i32 3, label %runtime.scratch.capacity.8607 i32 4, label %runtime.retained.capacity.8608 ]
runtime.invalid.request.8605:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8606:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8607:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8608:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8609:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8604:
  %record.make.handle.8610 = load i64, ptr %workspace.slot.8602, align 8
  %ctx.field.8611 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8612 = load i32, ptr %ctx.field.8611, align 4
  %steps.next.8613 = add i32 %steps.current.8612, 1
  store i32 %steps.next.8613, ptr %ctx.field.8611, align 4
  %steps.over.8614 = icmp ugt i32 %steps.next.8613, 10000
  br i1 %steps.over.8614, label %failure.8615, label %continue.8616
failure.8615:
  %ctx.field.8617 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 883, ptr %ctx.field.8617, align 4
  %status.diagnostic.8618 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8618, align 4
  ret void
continue.8616:
  %ctx.field.8619 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8620 = load i32, ptr %ctx.field.8619, align 4
  %steps.next.8621 = add i32 %steps.current.8620, 1
  store i32 %steps.next.8621, ptr %ctx.field.8619, align 4
  %steps.over.8622 = icmp ugt i32 %steps.next.8621, 10000
  br i1 %steps.over.8622, label %failure.8623, label %continue.8624
failure.8623:
  %ctx.field.8625 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 884, ptr %ctx.field.8625, align 4
  %status.diagnostic.8626 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8626, align 4
  ret void
continue.8624:
  %ctx.field.8627 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8628 = load i32, ptr %ctx.field.8627, align 4
  %steps.next.8629 = add i32 %steps.current.8628, 1
  store i32 %steps.next.8629, ptr %ctx.field.8627, align 4
  %steps.over.8630 = icmp ugt i32 %steps.next.8629, 10000
  br i1 %steps.over.8630, label %failure.8631, label %continue.8632
failure.8631:
  %ctx.field.8633 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 885, ptr %ctx.field.8633, align 4
  %status.diagnostic.8634 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8634, align 4
  ret void
continue.8632:
  %depth.exceeded.8635 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8635, label %failure.8636, label %continue.8637
failure.8636:
  %ctx.field.8638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 886, ptr %ctx.field.8638, align 4
  %status.diagnostic.8639 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8639, align 4
  ret void
continue.8637:
  %workspace.slot.8640 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8610, ptr %workspace.slot.8640, align 8
  %workspace.slot.8641 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8642 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 140, ptr %outputs, i32 1, ptr %workspace.slot.8641)
  switch i32 %record.make.status.8642, label %runtime.invalid.result.8648 [ i32 0, label %runtime.success.8643 i32 1, label %runtime.invalid.request.8644 i32 2, label %runtime.invalid.reference.8645 i32 3, label %runtime.scratch.capacity.8646 i32 4, label %runtime.retained.capacity.8647 ]
runtime.invalid.request.8644:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8645:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8646:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8647:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8648:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8643:
  %record.make.handle.8649 = load i64, ptr %workspace.slot.8641, align 8
  %ctx.field.8650 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8651 = load i32, ptr %ctx.field.8650, align 4
  %steps.next.8652 = add i32 %steps.current.8651, 1
  store i32 %steps.next.8652, ptr %ctx.field.8650, align 4
  %steps.over.8653 = icmp ugt i32 %steps.next.8652, 10000
  br i1 %steps.over.8653, label %failure.8654, label %continue.8655
failure.8654:
  %ctx.field.8656 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 887, ptr %ctx.field.8656, align 4
  %status.diagnostic.8657 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8657, align 4
  ret void
continue.8655:
  %ctx.field.8658 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8659 = load i32, ptr %ctx.field.8658, align 4
  %steps.next.8660 = add i32 %steps.current.8659, 1
  store i32 %steps.next.8660, ptr %ctx.field.8658, align 4
  %steps.over.8661 = icmp ugt i32 %steps.next.8660, 10000
  br i1 %steps.over.8661, label %failure.8662, label %continue.8663
failure.8662:
  %ctx.field.8664 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 888, ptr %ctx.field.8664, align 4
  %status.diagnostic.8665 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8665, align 4
  ret void
continue.8663:
  %ctx.field.8666 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8667 = load i32, ptr %ctx.field.8666, align 4
  %steps.next.8668 = add i32 %steps.current.8667, 1
  store i32 %steps.next.8668, ptr %ctx.field.8666, align 4
  %steps.over.8669 = icmp ugt i32 %steps.next.8668, 10000
  br i1 %steps.over.8669, label %failure.8670, label %continue.8671
failure.8670:
  %ctx.field.8672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 889, ptr %ctx.field.8672, align 4
  %status.diagnostic.8673 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8673, align 4
  ret void
continue.8671:
  %depth.exceeded.8674 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8674, label %failure.8675, label %continue.8676
failure.8675:
  %ctx.field.8677 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 890, ptr %ctx.field.8677, align 4
  %status.diagnostic.8678 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8678, align 4
  ret void
continue.8676:
  %workspace.slot.8679 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8649, ptr %workspace.slot.8679, align 8
  %workspace.slot.8680 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8681 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 141, ptr %outputs, i32 1, ptr %workspace.slot.8680)
  switch i32 %record.make.status.8681, label %runtime.invalid.result.8687 [ i32 0, label %runtime.success.8682 i32 1, label %runtime.invalid.request.8683 i32 2, label %runtime.invalid.reference.8684 i32 3, label %runtime.scratch.capacity.8685 i32 4, label %runtime.retained.capacity.8686 ]
runtime.invalid.request.8683:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8684:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8685:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8686:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8687:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8682:
  %record.make.handle.8688 = load i64, ptr %workspace.slot.8680, align 8
  %ctx.field.8689 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8690 = load i32, ptr %ctx.field.8689, align 4
  %steps.next.8691 = add i32 %steps.current.8690, 1
  store i32 %steps.next.8691, ptr %ctx.field.8689, align 4
  %steps.over.8692 = icmp ugt i32 %steps.next.8691, 10000
  br i1 %steps.over.8692, label %failure.8693, label %continue.8694
failure.8693:
  %ctx.field.8695 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 891, ptr %ctx.field.8695, align 4
  %status.diagnostic.8696 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8696, align 4
  ret void
continue.8694:
  %ctx.field.8697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8698 = load i32, ptr %ctx.field.8697, align 4
  %steps.next.8699 = add i32 %steps.current.8698, 1
  store i32 %steps.next.8699, ptr %ctx.field.8697, align 4
  %steps.over.8700 = icmp ugt i32 %steps.next.8699, 10000
  br i1 %steps.over.8700, label %failure.8701, label %continue.8702
failure.8701:
  %ctx.field.8703 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 892, ptr %ctx.field.8703, align 4
  %status.diagnostic.8704 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8704, align 4
  ret void
continue.8702:
  %ctx.field.8705 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8706 = load i32, ptr %ctx.field.8705, align 4
  %steps.next.8707 = add i32 %steps.current.8706, 1
  store i32 %steps.next.8707, ptr %ctx.field.8705, align 4
  %steps.over.8708 = icmp ugt i32 %steps.next.8707, 10000
  br i1 %steps.over.8708, label %failure.8709, label %continue.8710
failure.8709:
  %ctx.field.8711 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 893, ptr %ctx.field.8711, align 4
  %status.diagnostic.8712 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8712, align 4
  ret void
continue.8710:
  %depth.exceeded.8713 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8713, label %failure.8714, label %continue.8715
failure.8714:
  %ctx.field.8716 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 894, ptr %ctx.field.8716, align 4
  %status.diagnostic.8717 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8717, align 4
  ret void
continue.8715:
  %workspace.slot.8718 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8688, ptr %workspace.slot.8718, align 8
  %workspace.slot.8719 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8720 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 142, ptr %outputs, i32 1, ptr %workspace.slot.8719)
  switch i32 %record.make.status.8720, label %runtime.invalid.result.8726 [ i32 0, label %runtime.success.8721 i32 1, label %runtime.invalid.request.8722 i32 2, label %runtime.invalid.reference.8723 i32 3, label %runtime.scratch.capacity.8724 i32 4, label %runtime.retained.capacity.8725 ]
runtime.invalid.request.8722:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8723:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8724:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8725:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8726:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8721:
  %record.make.handle.8727 = load i64, ptr %workspace.slot.8719, align 8
  %ctx.field.8728 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8729 = load i32, ptr %ctx.field.8728, align 4
  %steps.next.8730 = add i32 %steps.current.8729, 1
  store i32 %steps.next.8730, ptr %ctx.field.8728, align 4
  %steps.over.8731 = icmp ugt i32 %steps.next.8730, 10000
  br i1 %steps.over.8731, label %failure.8732, label %continue.8733
failure.8732:
  %ctx.field.8734 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 895, ptr %ctx.field.8734, align 4
  %status.diagnostic.8735 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8735, align 4
  ret void
continue.8733:
  %ctx.field.8736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8737 = load i32, ptr %ctx.field.8736, align 4
  %steps.next.8738 = add i32 %steps.current.8737, 1
  store i32 %steps.next.8738, ptr %ctx.field.8736, align 4
  %steps.over.8739 = icmp ugt i32 %steps.next.8738, 10000
  br i1 %steps.over.8739, label %failure.8740, label %continue.8741
failure.8740:
  %ctx.field.8742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 896, ptr %ctx.field.8742, align 4
  %status.diagnostic.8743 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8743, align 4
  ret void
continue.8741:
  %ctx.field.8744 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8745 = load i32, ptr %ctx.field.8744, align 4
  %steps.next.8746 = add i32 %steps.current.8745, 1
  store i32 %steps.next.8746, ptr %ctx.field.8744, align 4
  %steps.over.8747 = icmp ugt i32 %steps.next.8746, 10000
  br i1 %steps.over.8747, label %failure.8748, label %continue.8749
failure.8748:
  %ctx.field.8750 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 897, ptr %ctx.field.8750, align 4
  %status.diagnostic.8751 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8751, align 4
  ret void
continue.8749:
  %depth.exceeded.8752 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8752, label %failure.8753, label %continue.8754
failure.8753:
  %ctx.field.8755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 898, ptr %ctx.field.8755, align 4
  %status.diagnostic.8756 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8756, align 4
  ret void
continue.8754:
  %workspace.slot.8757 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8727, ptr %workspace.slot.8757, align 8
  %workspace.slot.8758 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8759 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 143, ptr %outputs, i32 1, ptr %workspace.slot.8758)
  switch i32 %record.make.status.8759, label %runtime.invalid.result.8765 [ i32 0, label %runtime.success.8760 i32 1, label %runtime.invalid.request.8761 i32 2, label %runtime.invalid.reference.8762 i32 3, label %runtime.scratch.capacity.8763 i32 4, label %runtime.retained.capacity.8764 ]
runtime.invalid.request.8761:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8762:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8763:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8764:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8765:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8760:
  %record.make.handle.8766 = load i64, ptr %workspace.slot.8758, align 8
  %ctx.field.8767 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8768 = load i32, ptr %ctx.field.8767, align 4
  %steps.next.8769 = add i32 %steps.current.8768, 1
  store i32 %steps.next.8769, ptr %ctx.field.8767, align 4
  %steps.over.8770 = icmp ugt i32 %steps.next.8769, 10000
  br i1 %steps.over.8770, label %failure.8771, label %continue.8772
failure.8771:
  %ctx.field.8773 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 899, ptr %ctx.field.8773, align 4
  %status.diagnostic.8774 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8774, align 4
  ret void
continue.8772:
  %ctx.field.8775 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8776 = load i32, ptr %ctx.field.8775, align 4
  %steps.next.8777 = add i32 %steps.current.8776, 1
  store i32 %steps.next.8777, ptr %ctx.field.8775, align 4
  %steps.over.8778 = icmp ugt i32 %steps.next.8777, 10000
  br i1 %steps.over.8778, label %failure.8779, label %continue.8780
failure.8779:
  %ctx.field.8781 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 900, ptr %ctx.field.8781, align 4
  %status.diagnostic.8782 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8782, align 4
  ret void
continue.8780:
  %ctx.field.8783 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8784 = load i32, ptr %ctx.field.8783, align 4
  %steps.next.8785 = add i32 %steps.current.8784, 1
  store i32 %steps.next.8785, ptr %ctx.field.8783, align 4
  %steps.over.8786 = icmp ugt i32 %steps.next.8785, 10000
  br i1 %steps.over.8786, label %failure.8787, label %continue.8788
failure.8787:
  %ctx.field.8789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 901, ptr %ctx.field.8789, align 4
  %status.diagnostic.8790 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8790, align 4
  ret void
continue.8788:
  %depth.exceeded.8791 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8791, label %failure.8792, label %continue.8793
failure.8792:
  %ctx.field.8794 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 902, ptr %ctx.field.8794, align 4
  %status.diagnostic.8795 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8795, align 4
  ret void
continue.8793:
  %workspace.slot.8796 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8766, ptr %workspace.slot.8796, align 8
  %workspace.slot.8797 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8798 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 144, ptr %outputs, i32 1, ptr %workspace.slot.8797)
  switch i32 %record.make.status.8798, label %runtime.invalid.result.8804 [ i32 0, label %runtime.success.8799 i32 1, label %runtime.invalid.request.8800 i32 2, label %runtime.invalid.reference.8801 i32 3, label %runtime.scratch.capacity.8802 i32 4, label %runtime.retained.capacity.8803 ]
runtime.invalid.request.8800:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8801:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8802:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8803:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8804:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8799:
  %record.make.handle.8805 = load i64, ptr %workspace.slot.8797, align 8
  %ctx.field.8806 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8807 = load i32, ptr %ctx.field.8806, align 4
  %steps.next.8808 = add i32 %steps.current.8807, 1
  store i32 %steps.next.8808, ptr %ctx.field.8806, align 4
  %steps.over.8809 = icmp ugt i32 %steps.next.8808, 10000
  br i1 %steps.over.8809, label %failure.8810, label %continue.8811
failure.8810:
  %ctx.field.8812 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 903, ptr %ctx.field.8812, align 4
  %status.diagnostic.8813 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8813, align 4
  ret void
continue.8811:
  %ctx.field.8814 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8815 = load i32, ptr %ctx.field.8814, align 4
  %steps.next.8816 = add i32 %steps.current.8815, 1
  store i32 %steps.next.8816, ptr %ctx.field.8814, align 4
  %steps.over.8817 = icmp ugt i32 %steps.next.8816, 10000
  br i1 %steps.over.8817, label %failure.8818, label %continue.8819
failure.8818:
  %ctx.field.8820 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 904, ptr %ctx.field.8820, align 4
  %status.diagnostic.8821 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8821, align 4
  ret void
continue.8819:
  %ctx.field.8822 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8823 = load i32, ptr %ctx.field.8822, align 4
  %steps.next.8824 = add i32 %steps.current.8823, 1
  store i32 %steps.next.8824, ptr %ctx.field.8822, align 4
  %steps.over.8825 = icmp ugt i32 %steps.next.8824, 10000
  br i1 %steps.over.8825, label %failure.8826, label %continue.8827
failure.8826:
  %ctx.field.8828 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 905, ptr %ctx.field.8828, align 4
  %status.diagnostic.8829 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8829, align 4
  ret void
continue.8827:
  %depth.exceeded.8830 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8830, label %failure.8831, label %continue.8832
failure.8831:
  %ctx.field.8833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 906, ptr %ctx.field.8833, align 4
  %status.diagnostic.8834 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8834, align 4
  ret void
continue.8832:
  %workspace.slot.8835 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8805, ptr %workspace.slot.8835, align 8
  %workspace.slot.8836 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8837 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 145, ptr %outputs, i32 1, ptr %workspace.slot.8836)
  switch i32 %record.make.status.8837, label %runtime.invalid.result.8843 [ i32 0, label %runtime.success.8838 i32 1, label %runtime.invalid.request.8839 i32 2, label %runtime.invalid.reference.8840 i32 3, label %runtime.scratch.capacity.8841 i32 4, label %runtime.retained.capacity.8842 ]
runtime.invalid.request.8839:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8840:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8841:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8842:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8843:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8838:
  %record.make.handle.8844 = load i64, ptr %workspace.slot.8836, align 8
  %ctx.field.8845 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8846 = load i32, ptr %ctx.field.8845, align 4
  %steps.next.8847 = add i32 %steps.current.8846, 1
  store i32 %steps.next.8847, ptr %ctx.field.8845, align 4
  %steps.over.8848 = icmp ugt i32 %steps.next.8847, 10000
  br i1 %steps.over.8848, label %failure.8849, label %continue.8850
failure.8849:
  %ctx.field.8851 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 907, ptr %ctx.field.8851, align 4
  %status.diagnostic.8852 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8852, align 4
  ret void
continue.8850:
  %ctx.field.8853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8854 = load i32, ptr %ctx.field.8853, align 4
  %steps.next.8855 = add i32 %steps.current.8854, 1
  store i32 %steps.next.8855, ptr %ctx.field.8853, align 4
  %steps.over.8856 = icmp ugt i32 %steps.next.8855, 10000
  br i1 %steps.over.8856, label %failure.8857, label %continue.8858
failure.8857:
  %ctx.field.8859 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 908, ptr %ctx.field.8859, align 4
  %status.diagnostic.8860 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8860, align 4
  ret void
continue.8858:
  %ctx.field.8861 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8862 = load i32, ptr %ctx.field.8861, align 4
  %steps.next.8863 = add i32 %steps.current.8862, 1
  store i32 %steps.next.8863, ptr %ctx.field.8861, align 4
  %steps.over.8864 = icmp ugt i32 %steps.next.8863, 10000
  br i1 %steps.over.8864, label %failure.8865, label %continue.8866
failure.8865:
  %ctx.field.8867 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 909, ptr %ctx.field.8867, align 4
  %status.diagnostic.8868 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8868, align 4
  ret void
continue.8866:
  %depth.exceeded.8869 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8869, label %failure.8870, label %continue.8871
failure.8870:
  %ctx.field.8872 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 910, ptr %ctx.field.8872, align 4
  %status.diagnostic.8873 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8873, align 4
  ret void
continue.8871:
  %workspace.slot.8874 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8844, ptr %workspace.slot.8874, align 8
  %workspace.slot.8875 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8876 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 146, ptr %outputs, i32 1, ptr %workspace.slot.8875)
  switch i32 %record.make.status.8876, label %runtime.invalid.result.8882 [ i32 0, label %runtime.success.8877 i32 1, label %runtime.invalid.request.8878 i32 2, label %runtime.invalid.reference.8879 i32 3, label %runtime.scratch.capacity.8880 i32 4, label %runtime.retained.capacity.8881 ]
runtime.invalid.request.8878:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8879:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8880:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8881:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8882:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8877:
  %record.make.handle.8883 = load i64, ptr %workspace.slot.8875, align 8
  %ctx.field.8884 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8885 = load i32, ptr %ctx.field.8884, align 4
  %steps.next.8886 = add i32 %steps.current.8885, 1
  store i32 %steps.next.8886, ptr %ctx.field.8884, align 4
  %steps.over.8887 = icmp ugt i32 %steps.next.8886, 10000
  br i1 %steps.over.8887, label %failure.8888, label %continue.8889
failure.8888:
  %ctx.field.8890 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 911, ptr %ctx.field.8890, align 4
  %status.diagnostic.8891 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8891, align 4
  ret void
continue.8889:
  %ctx.field.8892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8893 = load i32, ptr %ctx.field.8892, align 4
  %steps.next.8894 = add i32 %steps.current.8893, 1
  store i32 %steps.next.8894, ptr %ctx.field.8892, align 4
  %steps.over.8895 = icmp ugt i32 %steps.next.8894, 10000
  br i1 %steps.over.8895, label %failure.8896, label %continue.8897
failure.8896:
  %ctx.field.8898 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 912, ptr %ctx.field.8898, align 4
  %status.diagnostic.8899 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8899, align 4
  ret void
continue.8897:
  %ctx.field.8900 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8901 = load i32, ptr %ctx.field.8900, align 4
  %steps.next.8902 = add i32 %steps.current.8901, 1
  store i32 %steps.next.8902, ptr %ctx.field.8900, align 4
  %steps.over.8903 = icmp ugt i32 %steps.next.8902, 10000
  br i1 %steps.over.8903, label %failure.8904, label %continue.8905
failure.8904:
  %ctx.field.8906 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 913, ptr %ctx.field.8906, align 4
  %status.diagnostic.8907 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8907, align 4
  ret void
continue.8905:
  %depth.exceeded.8908 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8908, label %failure.8909, label %continue.8910
failure.8909:
  %ctx.field.8911 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 914, ptr %ctx.field.8911, align 4
  %status.diagnostic.8912 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8912, align 4
  ret void
continue.8910:
  %workspace.slot.8913 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8883, ptr %workspace.slot.8913, align 8
  %workspace.slot.8914 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8915 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 147, ptr %outputs, i32 1, ptr %workspace.slot.8914)
  switch i32 %record.make.status.8915, label %runtime.invalid.result.8921 [ i32 0, label %runtime.success.8916 i32 1, label %runtime.invalid.request.8917 i32 2, label %runtime.invalid.reference.8918 i32 3, label %runtime.scratch.capacity.8919 i32 4, label %runtime.retained.capacity.8920 ]
runtime.invalid.request.8917:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8918:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8919:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8920:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8921:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8916:
  %record.make.handle.8922 = load i64, ptr %workspace.slot.8914, align 8
  %ctx.field.8923 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8924 = load i32, ptr %ctx.field.8923, align 4
  %steps.next.8925 = add i32 %steps.current.8924, 1
  store i32 %steps.next.8925, ptr %ctx.field.8923, align 4
  %steps.over.8926 = icmp ugt i32 %steps.next.8925, 10000
  br i1 %steps.over.8926, label %failure.8927, label %continue.8928
failure.8927:
  %ctx.field.8929 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 915, ptr %ctx.field.8929, align 4
  %status.diagnostic.8930 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8930, align 4
  ret void
continue.8928:
  %ctx.field.8931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8932 = load i32, ptr %ctx.field.8931, align 4
  %steps.next.8933 = add i32 %steps.current.8932, 1
  store i32 %steps.next.8933, ptr %ctx.field.8931, align 4
  %steps.over.8934 = icmp ugt i32 %steps.next.8933, 10000
  br i1 %steps.over.8934, label %failure.8935, label %continue.8936
failure.8935:
  %ctx.field.8937 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 916, ptr %ctx.field.8937, align 4
  %status.diagnostic.8938 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8938, align 4
  ret void
continue.8936:
  %ctx.field.8939 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8940 = load i32, ptr %ctx.field.8939, align 4
  %steps.next.8941 = add i32 %steps.current.8940, 1
  store i32 %steps.next.8941, ptr %ctx.field.8939, align 4
  %steps.over.8942 = icmp ugt i32 %steps.next.8941, 10000
  br i1 %steps.over.8942, label %failure.8943, label %continue.8944
failure.8943:
  %ctx.field.8945 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 917, ptr %ctx.field.8945, align 4
  %status.diagnostic.8946 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8946, align 4
  ret void
continue.8944:
  %depth.exceeded.8947 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8947, label %failure.8948, label %continue.8949
failure.8948:
  %ctx.field.8950 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 918, ptr %ctx.field.8950, align 4
  %status.diagnostic.8951 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8951, align 4
  ret void
continue.8949:
  %workspace.slot.8952 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8922, ptr %workspace.slot.8952, align 8
  %workspace.slot.8953 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8954 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 148, ptr %outputs, i32 1, ptr %workspace.slot.8953)
  switch i32 %record.make.status.8954, label %runtime.invalid.result.8960 [ i32 0, label %runtime.success.8955 i32 1, label %runtime.invalid.request.8956 i32 2, label %runtime.invalid.reference.8957 i32 3, label %runtime.scratch.capacity.8958 i32 4, label %runtime.retained.capacity.8959 ]
runtime.invalid.request.8956:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8957:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8958:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8959:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8960:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8955:
  %record.make.handle.8961 = load i64, ptr %workspace.slot.8953, align 8
  %ctx.field.8962 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8963 = load i32, ptr %ctx.field.8962, align 4
  %steps.next.8964 = add i32 %steps.current.8963, 1
  store i32 %steps.next.8964, ptr %ctx.field.8962, align 4
  %steps.over.8965 = icmp ugt i32 %steps.next.8964, 10000
  br i1 %steps.over.8965, label %failure.8966, label %continue.8967
failure.8966:
  %ctx.field.8968 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 919, ptr %ctx.field.8968, align 4
  %status.diagnostic.8969 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8969, align 4
  ret void
continue.8967:
  %ctx.field.8970 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8971 = load i32, ptr %ctx.field.8970, align 4
  %steps.next.8972 = add i32 %steps.current.8971, 1
  store i32 %steps.next.8972, ptr %ctx.field.8970, align 4
  %steps.over.8973 = icmp ugt i32 %steps.next.8972, 10000
  br i1 %steps.over.8973, label %failure.8974, label %continue.8975
failure.8974:
  %ctx.field.8976 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 920, ptr %ctx.field.8976, align 4
  %status.diagnostic.8977 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8977, align 4
  ret void
continue.8975:
  %ctx.field.8978 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.8979 = load i32, ptr %ctx.field.8978, align 4
  %steps.next.8980 = add i32 %steps.current.8979, 1
  store i32 %steps.next.8980, ptr %ctx.field.8978, align 4
  %steps.over.8981 = icmp ugt i32 %steps.next.8980, 10000
  br i1 %steps.over.8981, label %failure.8982, label %continue.8983
failure.8982:
  %ctx.field.8984 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 921, ptr %ctx.field.8984, align 4
  %status.diagnostic.8985 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8985, align 4
  ret void
continue.8983:
  %depth.exceeded.8986 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8986, label %failure.8987, label %continue.8988
failure.8987:
  %ctx.field.8989 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 922, ptr %ctx.field.8989, align 4
  %status.diagnostic.8990 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.8990, align 4
  ret void
continue.8988:
  %workspace.slot.8991 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.8961, ptr %workspace.slot.8991, align 8
  %workspace.slot.8992 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.8993 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 150, ptr %outputs, i32 1, ptr %workspace.slot.8992)
  switch i32 %record.make.status.8993, label %runtime.invalid.result.8999 [ i32 0, label %runtime.success.8994 i32 1, label %runtime.invalid.request.8995 i32 2, label %runtime.invalid.reference.8996 i32 3, label %runtime.scratch.capacity.8997 i32 4, label %runtime.retained.capacity.8998 ]
runtime.invalid.request.8995:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.8996:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.8997:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.8998:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.8999:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.8994:
  %record.make.handle.9000 = load i64, ptr %workspace.slot.8992, align 8
  %ctx.field.9001 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9002 = load i32, ptr %ctx.field.9001, align 4
  %steps.next.9003 = add i32 %steps.current.9002, 1
  store i32 %steps.next.9003, ptr %ctx.field.9001, align 4
  %steps.over.9004 = icmp ugt i32 %steps.next.9003, 10000
  br i1 %steps.over.9004, label %failure.9005, label %continue.9006
failure.9005:
  %ctx.field.9007 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 923, ptr %ctx.field.9007, align 4
  %status.diagnostic.9008 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9008, align 4
  ret void
continue.9006:
  %ctx.field.9009 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9010 = load i32, ptr %ctx.field.9009, align 4
  %steps.next.9011 = add i32 %steps.current.9010, 1
  store i32 %steps.next.9011, ptr %ctx.field.9009, align 4
  %steps.over.9012 = icmp ugt i32 %steps.next.9011, 10000
  br i1 %steps.over.9012, label %failure.9013, label %continue.9014
failure.9013:
  %ctx.field.9015 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 924, ptr %ctx.field.9015, align 4
  %status.diagnostic.9016 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9016, align 4
  ret void
continue.9014:
  %ctx.field.9017 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9018 = load i32, ptr %ctx.field.9017, align 4
  %steps.next.9019 = add i32 %steps.current.9018, 1
  store i32 %steps.next.9019, ptr %ctx.field.9017, align 4
  %steps.over.9020 = icmp ugt i32 %steps.next.9019, 10000
  br i1 %steps.over.9020, label %failure.9021, label %continue.9022
failure.9021:
  %ctx.field.9023 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 925, ptr %ctx.field.9023, align 4
  %status.diagnostic.9024 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9024, align 4
  ret void
continue.9022:
  %depth.exceeded.9025 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9025, label %failure.9026, label %continue.9027
failure.9026:
  %ctx.field.9028 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 926, ptr %ctx.field.9028, align 4
  %status.diagnostic.9029 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9029, align 4
  ret void
continue.9027:
  %workspace.slot.9030 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9000, ptr %workspace.slot.9030, align 8
  %workspace.slot.9031 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9032 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 151, ptr %outputs, i32 1, ptr %workspace.slot.9031)
  switch i32 %record.make.status.9032, label %runtime.invalid.result.9038 [ i32 0, label %runtime.success.9033 i32 1, label %runtime.invalid.request.9034 i32 2, label %runtime.invalid.reference.9035 i32 3, label %runtime.scratch.capacity.9036 i32 4, label %runtime.retained.capacity.9037 ]
runtime.invalid.request.9034:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9035:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9036:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9037:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9038:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9033:
  %record.make.handle.9039 = load i64, ptr %workspace.slot.9031, align 8
  %ctx.field.9040 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9041 = load i32, ptr %ctx.field.9040, align 4
  %steps.next.9042 = add i32 %steps.current.9041, 1
  store i32 %steps.next.9042, ptr %ctx.field.9040, align 4
  %steps.over.9043 = icmp ugt i32 %steps.next.9042, 10000
  br i1 %steps.over.9043, label %failure.9044, label %continue.9045
failure.9044:
  %ctx.field.9046 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 927, ptr %ctx.field.9046, align 4
  %status.diagnostic.9047 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9047, align 4
  ret void
continue.9045:
  %ctx.field.9048 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9049 = load i32, ptr %ctx.field.9048, align 4
  %steps.next.9050 = add i32 %steps.current.9049, 1
  store i32 %steps.next.9050, ptr %ctx.field.9048, align 4
  %steps.over.9051 = icmp ugt i32 %steps.next.9050, 10000
  br i1 %steps.over.9051, label %failure.9052, label %continue.9053
failure.9052:
  %ctx.field.9054 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 928, ptr %ctx.field.9054, align 4
  %status.diagnostic.9055 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9055, align 4
  ret void
continue.9053:
  %ctx.field.9056 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9057 = load i32, ptr %ctx.field.9056, align 4
  %steps.next.9058 = add i32 %steps.current.9057, 1
  store i32 %steps.next.9058, ptr %ctx.field.9056, align 4
  %steps.over.9059 = icmp ugt i32 %steps.next.9058, 10000
  br i1 %steps.over.9059, label %failure.9060, label %continue.9061
failure.9060:
  %ctx.field.9062 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 929, ptr %ctx.field.9062, align 4
  %status.diagnostic.9063 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9063, align 4
  ret void
continue.9061:
  %depth.exceeded.9064 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9064, label %failure.9065, label %continue.9066
failure.9065:
  %ctx.field.9067 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 930, ptr %ctx.field.9067, align 4
  %status.diagnostic.9068 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9068, align 4
  ret void
continue.9066:
  %workspace.slot.9069 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9039, ptr %workspace.slot.9069, align 8
  %workspace.slot.9070 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9071 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 152, ptr %outputs, i32 1, ptr %workspace.slot.9070)
  switch i32 %record.make.status.9071, label %runtime.invalid.result.9077 [ i32 0, label %runtime.success.9072 i32 1, label %runtime.invalid.request.9073 i32 2, label %runtime.invalid.reference.9074 i32 3, label %runtime.scratch.capacity.9075 i32 4, label %runtime.retained.capacity.9076 ]
runtime.invalid.request.9073:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9074:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9075:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9076:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9077:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9072:
  %record.make.handle.9078 = load i64, ptr %workspace.slot.9070, align 8
  %ctx.field.9079 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9080 = load i32, ptr %ctx.field.9079, align 4
  %steps.next.9081 = add i32 %steps.current.9080, 1
  store i32 %steps.next.9081, ptr %ctx.field.9079, align 4
  %steps.over.9082 = icmp ugt i32 %steps.next.9081, 10000
  br i1 %steps.over.9082, label %failure.9083, label %continue.9084
failure.9083:
  %ctx.field.9085 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 931, ptr %ctx.field.9085, align 4
  %status.diagnostic.9086 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9086, align 4
  ret void
continue.9084:
  %ctx.field.9087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9088 = load i32, ptr %ctx.field.9087, align 4
  %steps.next.9089 = add i32 %steps.current.9088, 1
  store i32 %steps.next.9089, ptr %ctx.field.9087, align 4
  %steps.over.9090 = icmp ugt i32 %steps.next.9089, 10000
  br i1 %steps.over.9090, label %failure.9091, label %continue.9092
failure.9091:
  %ctx.field.9093 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 932, ptr %ctx.field.9093, align 4
  %status.diagnostic.9094 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9094, align 4
  ret void
continue.9092:
  %ctx.field.9095 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9096 = load i32, ptr %ctx.field.9095, align 4
  %steps.next.9097 = add i32 %steps.current.9096, 1
  store i32 %steps.next.9097, ptr %ctx.field.9095, align 4
  %steps.over.9098 = icmp ugt i32 %steps.next.9097, 10000
  br i1 %steps.over.9098, label %failure.9099, label %continue.9100
failure.9099:
  %ctx.field.9101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 933, ptr %ctx.field.9101, align 4
  %status.diagnostic.9102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9102, align 4
  ret void
continue.9100:
  %depth.exceeded.9103 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9103, label %failure.9104, label %continue.9105
failure.9104:
  %ctx.field.9106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 934, ptr %ctx.field.9106, align 4
  %status.diagnostic.9107 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9107, align 4
  ret void
continue.9105:
  %workspace.slot.9108 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9078, ptr %workspace.slot.9108, align 8
  %workspace.slot.9109 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9110 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 153, ptr %outputs, i32 1, ptr %workspace.slot.9109)
  switch i32 %record.make.status.9110, label %runtime.invalid.result.9116 [ i32 0, label %runtime.success.9111 i32 1, label %runtime.invalid.request.9112 i32 2, label %runtime.invalid.reference.9113 i32 3, label %runtime.scratch.capacity.9114 i32 4, label %runtime.retained.capacity.9115 ]
runtime.invalid.request.9112:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9113:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9114:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9115:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9116:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9111:
  %record.make.handle.9117 = load i64, ptr %workspace.slot.9109, align 8
  %ctx.field.9118 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9119 = load i32, ptr %ctx.field.9118, align 4
  %steps.next.9120 = add i32 %steps.current.9119, 1
  store i32 %steps.next.9120, ptr %ctx.field.9118, align 4
  %steps.over.9121 = icmp ugt i32 %steps.next.9120, 10000
  br i1 %steps.over.9121, label %failure.9122, label %continue.9123
failure.9122:
  %ctx.field.9124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 935, ptr %ctx.field.9124, align 4
  %status.diagnostic.9125 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9125, align 4
  ret void
continue.9123:
  %ctx.field.9126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9127 = load i32, ptr %ctx.field.9126, align 4
  %steps.next.9128 = add i32 %steps.current.9127, 1
  store i32 %steps.next.9128, ptr %ctx.field.9126, align 4
  %steps.over.9129 = icmp ugt i32 %steps.next.9128, 10000
  br i1 %steps.over.9129, label %failure.9130, label %continue.9131
failure.9130:
  %ctx.field.9132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 936, ptr %ctx.field.9132, align 4
  %status.diagnostic.9133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9133, align 4
  ret void
continue.9131:
  %ctx.field.9134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9135 = load i32, ptr %ctx.field.9134, align 4
  %steps.next.9136 = add i32 %steps.current.9135, 1
  store i32 %steps.next.9136, ptr %ctx.field.9134, align 4
  %steps.over.9137 = icmp ugt i32 %steps.next.9136, 10000
  br i1 %steps.over.9137, label %failure.9138, label %continue.9139
failure.9138:
  %ctx.field.9140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 937, ptr %ctx.field.9140, align 4
  %status.diagnostic.9141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9141, align 4
  ret void
continue.9139:
  %depth.exceeded.9142 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9142, label %failure.9143, label %continue.9144
failure.9143:
  %ctx.field.9145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 938, ptr %ctx.field.9145, align 4
  %status.diagnostic.9146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9146, align 4
  ret void
continue.9144:
  %workspace.slot.9147 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9117, ptr %workspace.slot.9147, align 8
  %workspace.slot.9148 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9149 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 154, ptr %outputs, i32 1, ptr %workspace.slot.9148)
  switch i32 %record.make.status.9149, label %runtime.invalid.result.9155 [ i32 0, label %runtime.success.9150 i32 1, label %runtime.invalid.request.9151 i32 2, label %runtime.invalid.reference.9152 i32 3, label %runtime.scratch.capacity.9153 i32 4, label %runtime.retained.capacity.9154 ]
runtime.invalid.request.9151:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9152:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9153:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9154:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9155:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9150:
  %record.make.handle.9156 = load i64, ptr %workspace.slot.9148, align 8
  %ctx.field.9157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9158 = load i32, ptr %ctx.field.9157, align 4
  %steps.next.9159 = add i32 %steps.current.9158, 1
  store i32 %steps.next.9159, ptr %ctx.field.9157, align 4
  %steps.over.9160 = icmp ugt i32 %steps.next.9159, 10000
  br i1 %steps.over.9160, label %failure.9161, label %continue.9162
failure.9161:
  %ctx.field.9163 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 939, ptr %ctx.field.9163, align 4
  %status.diagnostic.9164 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9164, align 4
  ret void
continue.9162:
  %ctx.field.9165 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9166 = load i32, ptr %ctx.field.9165, align 4
  %steps.next.9167 = add i32 %steps.current.9166, 1
  store i32 %steps.next.9167, ptr %ctx.field.9165, align 4
  %steps.over.9168 = icmp ugt i32 %steps.next.9167, 10000
  br i1 %steps.over.9168, label %failure.9169, label %continue.9170
failure.9169:
  %ctx.field.9171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 940, ptr %ctx.field.9171, align 4
  %status.diagnostic.9172 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9172, align 4
  ret void
continue.9170:
  %ctx.field.9173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9174 = load i32, ptr %ctx.field.9173, align 4
  %steps.next.9175 = add i32 %steps.current.9174, 1
  store i32 %steps.next.9175, ptr %ctx.field.9173, align 4
  %steps.over.9176 = icmp ugt i32 %steps.next.9175, 10000
  br i1 %steps.over.9176, label %failure.9177, label %continue.9178
failure.9177:
  %ctx.field.9179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 941, ptr %ctx.field.9179, align 4
  %status.diagnostic.9180 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9180, align 4
  ret void
continue.9178:
  %depth.exceeded.9181 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9181, label %failure.9182, label %continue.9183
failure.9182:
  %ctx.field.9184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 942, ptr %ctx.field.9184, align 4
  %status.diagnostic.9185 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9185, align 4
  ret void
continue.9183:
  %workspace.slot.9186 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9156, ptr %workspace.slot.9186, align 8
  %workspace.slot.9187 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9188 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 155, ptr %outputs, i32 1, ptr %workspace.slot.9187)
  switch i32 %record.make.status.9188, label %runtime.invalid.result.9194 [ i32 0, label %runtime.success.9189 i32 1, label %runtime.invalid.request.9190 i32 2, label %runtime.invalid.reference.9191 i32 3, label %runtime.scratch.capacity.9192 i32 4, label %runtime.retained.capacity.9193 ]
runtime.invalid.request.9190:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9191:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9192:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9193:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9194:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9189:
  %record.make.handle.9195 = load i64, ptr %workspace.slot.9187, align 8
  %ctx.field.9196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9197 = load i32, ptr %ctx.field.9196, align 4
  %steps.next.9198 = add i32 %steps.current.9197, 1
  store i32 %steps.next.9198, ptr %ctx.field.9196, align 4
  %steps.over.9199 = icmp ugt i32 %steps.next.9198, 10000
  br i1 %steps.over.9199, label %failure.9200, label %continue.9201
failure.9200:
  %ctx.field.9202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 943, ptr %ctx.field.9202, align 4
  %status.diagnostic.9203 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9203, align 4
  ret void
continue.9201:
  %ctx.field.9204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9205 = load i32, ptr %ctx.field.9204, align 4
  %steps.next.9206 = add i32 %steps.current.9205, 1
  store i32 %steps.next.9206, ptr %ctx.field.9204, align 4
  %steps.over.9207 = icmp ugt i32 %steps.next.9206, 10000
  br i1 %steps.over.9207, label %failure.9208, label %continue.9209
failure.9208:
  %ctx.field.9210 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 944, ptr %ctx.field.9210, align 4
  %status.diagnostic.9211 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9211, align 4
  ret void
continue.9209:
  %ctx.field.9212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9213 = load i32, ptr %ctx.field.9212, align 4
  %steps.next.9214 = add i32 %steps.current.9213, 1
  store i32 %steps.next.9214, ptr %ctx.field.9212, align 4
  %steps.over.9215 = icmp ugt i32 %steps.next.9214, 10000
  br i1 %steps.over.9215, label %failure.9216, label %continue.9217
failure.9216:
  %ctx.field.9218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 945, ptr %ctx.field.9218, align 4
  %status.diagnostic.9219 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9219, align 4
  ret void
continue.9217:
  %depth.exceeded.9220 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9220, label %failure.9221, label %continue.9222
failure.9221:
  %ctx.field.9223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 946, ptr %ctx.field.9223, align 4
  %status.diagnostic.9224 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9224, align 4
  ret void
continue.9222:
  %workspace.slot.9225 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9195, ptr %workspace.slot.9225, align 8
  %workspace.slot.9226 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9227 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 156, ptr %outputs, i32 1, ptr %workspace.slot.9226)
  switch i32 %record.make.status.9227, label %runtime.invalid.result.9233 [ i32 0, label %runtime.success.9228 i32 1, label %runtime.invalid.request.9229 i32 2, label %runtime.invalid.reference.9230 i32 3, label %runtime.scratch.capacity.9231 i32 4, label %runtime.retained.capacity.9232 ]
runtime.invalid.request.9229:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9230:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9231:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9232:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9233:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9228:
  %record.make.handle.9234 = load i64, ptr %workspace.slot.9226, align 8
  %ctx.field.9235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9236 = load i32, ptr %ctx.field.9235, align 4
  %steps.next.9237 = add i32 %steps.current.9236, 1
  store i32 %steps.next.9237, ptr %ctx.field.9235, align 4
  %steps.over.9238 = icmp ugt i32 %steps.next.9237, 10000
  br i1 %steps.over.9238, label %failure.9239, label %continue.9240
failure.9239:
  %ctx.field.9241 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 947, ptr %ctx.field.9241, align 4
  %status.diagnostic.9242 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9242, align 4
  ret void
continue.9240:
  %ctx.field.9243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9244 = load i32, ptr %ctx.field.9243, align 4
  %steps.next.9245 = add i32 %steps.current.9244, 1
  store i32 %steps.next.9245, ptr %ctx.field.9243, align 4
  %steps.over.9246 = icmp ugt i32 %steps.next.9245, 10000
  br i1 %steps.over.9246, label %failure.9247, label %continue.9248
failure.9247:
  %ctx.field.9249 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 948, ptr %ctx.field.9249, align 4
  %status.diagnostic.9250 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9250, align 4
  ret void
continue.9248:
  %ctx.field.9251 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9252 = load i32, ptr %ctx.field.9251, align 4
  %steps.next.9253 = add i32 %steps.current.9252, 1
  store i32 %steps.next.9253, ptr %ctx.field.9251, align 4
  %steps.over.9254 = icmp ugt i32 %steps.next.9253, 10000
  br i1 %steps.over.9254, label %failure.9255, label %continue.9256
failure.9255:
  %ctx.field.9257 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 949, ptr %ctx.field.9257, align 4
  %status.diagnostic.9258 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9258, align 4
  ret void
continue.9256:
  %depth.exceeded.9259 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9259, label %failure.9260, label %continue.9261
failure.9260:
  %ctx.field.9262 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 950, ptr %ctx.field.9262, align 4
  %status.diagnostic.9263 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9263, align 4
  ret void
continue.9261:
  %workspace.slot.9264 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9234, ptr %workspace.slot.9264, align 8
  %workspace.slot.9265 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9266 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 157, ptr %outputs, i32 1, ptr %workspace.slot.9265)
  switch i32 %record.make.status.9266, label %runtime.invalid.result.9272 [ i32 0, label %runtime.success.9267 i32 1, label %runtime.invalid.request.9268 i32 2, label %runtime.invalid.reference.9269 i32 3, label %runtime.scratch.capacity.9270 i32 4, label %runtime.retained.capacity.9271 ]
runtime.invalid.request.9268:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9269:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9270:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9271:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9272:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9267:
  %record.make.handle.9273 = load i64, ptr %workspace.slot.9265, align 8
  %ctx.field.9274 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9275 = load i32, ptr %ctx.field.9274, align 4
  %steps.next.9276 = add i32 %steps.current.9275, 1
  store i32 %steps.next.9276, ptr %ctx.field.9274, align 4
  %steps.over.9277 = icmp ugt i32 %steps.next.9276, 10000
  br i1 %steps.over.9277, label %failure.9278, label %continue.9279
failure.9278:
  %ctx.field.9280 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 951, ptr %ctx.field.9280, align 4
  %status.diagnostic.9281 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9281, align 4
  ret void
continue.9279:
  %ctx.field.9282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9283 = load i32, ptr %ctx.field.9282, align 4
  %steps.next.9284 = add i32 %steps.current.9283, 1
  store i32 %steps.next.9284, ptr %ctx.field.9282, align 4
  %steps.over.9285 = icmp ugt i32 %steps.next.9284, 10000
  br i1 %steps.over.9285, label %failure.9286, label %continue.9287
failure.9286:
  %ctx.field.9288 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 952, ptr %ctx.field.9288, align 4
  %status.diagnostic.9289 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9289, align 4
  ret void
continue.9287:
  %ctx.field.9290 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9291 = load i32, ptr %ctx.field.9290, align 4
  %steps.next.9292 = add i32 %steps.current.9291, 1
  store i32 %steps.next.9292, ptr %ctx.field.9290, align 4
  %steps.over.9293 = icmp ugt i32 %steps.next.9292, 10000
  br i1 %steps.over.9293, label %failure.9294, label %continue.9295
failure.9294:
  %ctx.field.9296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 953, ptr %ctx.field.9296, align 4
  %status.diagnostic.9297 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9297, align 4
  ret void
continue.9295:
  %depth.exceeded.9298 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9298, label %failure.9299, label %continue.9300
failure.9299:
  %ctx.field.9301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 954, ptr %ctx.field.9301, align 4
  %status.diagnostic.9302 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9302, align 4
  ret void
continue.9300:
  %workspace.slot.9303 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9273, ptr %workspace.slot.9303, align 8
  %workspace.slot.9304 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9305 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 158, ptr %outputs, i32 1, ptr %workspace.slot.9304)
  switch i32 %record.make.status.9305, label %runtime.invalid.result.9311 [ i32 0, label %runtime.success.9306 i32 1, label %runtime.invalid.request.9307 i32 2, label %runtime.invalid.reference.9308 i32 3, label %runtime.scratch.capacity.9309 i32 4, label %runtime.retained.capacity.9310 ]
runtime.invalid.request.9307:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9308:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9309:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9310:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9311:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9306:
  %record.make.handle.9312 = load i64, ptr %workspace.slot.9304, align 8
  %ctx.field.9313 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9314 = load i32, ptr %ctx.field.9313, align 4
  %steps.next.9315 = add i32 %steps.current.9314, 1
  store i32 %steps.next.9315, ptr %ctx.field.9313, align 4
  %steps.over.9316 = icmp ugt i32 %steps.next.9315, 10000
  br i1 %steps.over.9316, label %failure.9317, label %continue.9318
failure.9317:
  %ctx.field.9319 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 955, ptr %ctx.field.9319, align 4
  %status.diagnostic.9320 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9320, align 4
  ret void
continue.9318:
  %ctx.field.9321 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9322 = load i32, ptr %ctx.field.9321, align 4
  %steps.next.9323 = add i32 %steps.current.9322, 1
  store i32 %steps.next.9323, ptr %ctx.field.9321, align 4
  %steps.over.9324 = icmp ugt i32 %steps.next.9323, 10000
  br i1 %steps.over.9324, label %failure.9325, label %continue.9326
failure.9325:
  %ctx.field.9327 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 956, ptr %ctx.field.9327, align 4
  %status.diagnostic.9328 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9328, align 4
  ret void
continue.9326:
  %ctx.field.9329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9330 = load i32, ptr %ctx.field.9329, align 4
  %steps.next.9331 = add i32 %steps.current.9330, 1
  store i32 %steps.next.9331, ptr %ctx.field.9329, align 4
  %steps.over.9332 = icmp ugt i32 %steps.next.9331, 10000
  br i1 %steps.over.9332, label %failure.9333, label %continue.9334
failure.9333:
  %ctx.field.9335 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 957, ptr %ctx.field.9335, align 4
  %status.diagnostic.9336 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9336, align 4
  ret void
continue.9334:
  %depth.exceeded.9337 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9337, label %failure.9338, label %continue.9339
failure.9338:
  %ctx.field.9340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 958, ptr %ctx.field.9340, align 4
  %status.diagnostic.9341 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9341, align 4
  ret void
continue.9339:
  %workspace.slot.9342 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9312, ptr %workspace.slot.9342, align 8
  %workspace.slot.9343 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9344 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 159, ptr %outputs, i32 1, ptr %workspace.slot.9343)
  switch i32 %record.make.status.9344, label %runtime.invalid.result.9350 [ i32 0, label %runtime.success.9345 i32 1, label %runtime.invalid.request.9346 i32 2, label %runtime.invalid.reference.9347 i32 3, label %runtime.scratch.capacity.9348 i32 4, label %runtime.retained.capacity.9349 ]
runtime.invalid.request.9346:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9347:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9348:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9349:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9350:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9345:
  %record.make.handle.9351 = load i64, ptr %workspace.slot.9343, align 8
  %ctx.field.9352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9353 = load i32, ptr %ctx.field.9352, align 4
  %steps.next.9354 = add i32 %steps.current.9353, 1
  store i32 %steps.next.9354, ptr %ctx.field.9352, align 4
  %steps.over.9355 = icmp ugt i32 %steps.next.9354, 10000
  br i1 %steps.over.9355, label %failure.9356, label %continue.9357
failure.9356:
  %ctx.field.9358 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 959, ptr %ctx.field.9358, align 4
  %status.diagnostic.9359 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9359, align 4
  ret void
continue.9357:
  %ctx.field.9360 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9361 = load i32, ptr %ctx.field.9360, align 4
  %steps.next.9362 = add i32 %steps.current.9361, 1
  store i32 %steps.next.9362, ptr %ctx.field.9360, align 4
  %steps.over.9363 = icmp ugt i32 %steps.next.9362, 10000
  br i1 %steps.over.9363, label %failure.9364, label %continue.9365
failure.9364:
  %ctx.field.9366 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 960, ptr %ctx.field.9366, align 4
  %status.diagnostic.9367 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9367, align 4
  ret void
continue.9365:
  %ctx.field.9368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9369 = load i32, ptr %ctx.field.9368, align 4
  %steps.next.9370 = add i32 %steps.current.9369, 1
  store i32 %steps.next.9370, ptr %ctx.field.9368, align 4
  %steps.over.9371 = icmp ugt i32 %steps.next.9370, 10000
  br i1 %steps.over.9371, label %failure.9372, label %continue.9373
failure.9372:
  %ctx.field.9374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 961, ptr %ctx.field.9374, align 4
  %status.diagnostic.9375 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9375, align 4
  ret void
continue.9373:
  %depth.exceeded.9376 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9376, label %failure.9377, label %continue.9378
failure.9377:
  %ctx.field.9379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 962, ptr %ctx.field.9379, align 4
  %status.diagnostic.9380 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9380, align 4
  ret void
continue.9378:
  %workspace.slot.9381 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9351, ptr %workspace.slot.9381, align 8
  %workspace.slot.9382 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9383 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 161, ptr %outputs, i32 1, ptr %workspace.slot.9382)
  switch i32 %record.make.status.9383, label %runtime.invalid.result.9389 [ i32 0, label %runtime.success.9384 i32 1, label %runtime.invalid.request.9385 i32 2, label %runtime.invalid.reference.9386 i32 3, label %runtime.scratch.capacity.9387 i32 4, label %runtime.retained.capacity.9388 ]
runtime.invalid.request.9385:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9386:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9387:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9388:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9389:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9384:
  %record.make.handle.9390 = load i64, ptr %workspace.slot.9382, align 8
  %ctx.field.9391 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9392 = load i32, ptr %ctx.field.9391, align 4
  %steps.next.9393 = add i32 %steps.current.9392, 1
  store i32 %steps.next.9393, ptr %ctx.field.9391, align 4
  %steps.over.9394 = icmp ugt i32 %steps.next.9393, 10000
  br i1 %steps.over.9394, label %failure.9395, label %continue.9396
failure.9395:
  %ctx.field.9397 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 963, ptr %ctx.field.9397, align 4
  %status.diagnostic.9398 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9398, align 4
  ret void
continue.9396:
  %ctx.field.9399 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9400 = load i32, ptr %ctx.field.9399, align 4
  %steps.next.9401 = add i32 %steps.current.9400, 1
  store i32 %steps.next.9401, ptr %ctx.field.9399, align 4
  %steps.over.9402 = icmp ugt i32 %steps.next.9401, 10000
  br i1 %steps.over.9402, label %failure.9403, label %continue.9404
failure.9403:
  %ctx.field.9405 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 964, ptr %ctx.field.9405, align 4
  %status.diagnostic.9406 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9406, align 4
  ret void
continue.9404:
  %ctx.field.9407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9408 = load i32, ptr %ctx.field.9407, align 4
  %steps.next.9409 = add i32 %steps.current.9408, 1
  store i32 %steps.next.9409, ptr %ctx.field.9407, align 4
  %steps.over.9410 = icmp ugt i32 %steps.next.9409, 10000
  br i1 %steps.over.9410, label %failure.9411, label %continue.9412
failure.9411:
  %ctx.field.9413 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 965, ptr %ctx.field.9413, align 4
  %status.diagnostic.9414 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9414, align 4
  ret void
continue.9412:
  %depth.exceeded.9415 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9415, label %failure.9416, label %continue.9417
failure.9416:
  %ctx.field.9418 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 966, ptr %ctx.field.9418, align 4
  %status.diagnostic.9419 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9419, align 4
  ret void
continue.9417:
  %workspace.slot.9420 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9390, ptr %workspace.slot.9420, align 8
  %workspace.slot.9421 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9422 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 162, ptr %outputs, i32 1, ptr %workspace.slot.9421)
  switch i32 %record.make.status.9422, label %runtime.invalid.result.9428 [ i32 0, label %runtime.success.9423 i32 1, label %runtime.invalid.request.9424 i32 2, label %runtime.invalid.reference.9425 i32 3, label %runtime.scratch.capacity.9426 i32 4, label %runtime.retained.capacity.9427 ]
runtime.invalid.request.9424:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9425:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9426:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9427:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9428:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9423:
  %record.make.handle.9429 = load i64, ptr %workspace.slot.9421, align 8
  %ctx.field.9430 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9431 = load i32, ptr %ctx.field.9430, align 4
  %steps.next.9432 = add i32 %steps.current.9431, 1
  store i32 %steps.next.9432, ptr %ctx.field.9430, align 4
  %steps.over.9433 = icmp ugt i32 %steps.next.9432, 10000
  br i1 %steps.over.9433, label %failure.9434, label %continue.9435
failure.9434:
  %ctx.field.9436 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 967, ptr %ctx.field.9436, align 4
  %status.diagnostic.9437 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9437, align 4
  ret void
continue.9435:
  %ctx.field.9438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9439 = load i32, ptr %ctx.field.9438, align 4
  %steps.next.9440 = add i32 %steps.current.9439, 1
  store i32 %steps.next.9440, ptr %ctx.field.9438, align 4
  %steps.over.9441 = icmp ugt i32 %steps.next.9440, 10000
  br i1 %steps.over.9441, label %failure.9442, label %continue.9443
failure.9442:
  %ctx.field.9444 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 968, ptr %ctx.field.9444, align 4
  %status.diagnostic.9445 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9445, align 4
  ret void
continue.9443:
  %ctx.field.9446 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9447 = load i32, ptr %ctx.field.9446, align 4
  %steps.next.9448 = add i32 %steps.current.9447, 1
  store i32 %steps.next.9448, ptr %ctx.field.9446, align 4
  %steps.over.9449 = icmp ugt i32 %steps.next.9448, 10000
  br i1 %steps.over.9449, label %failure.9450, label %continue.9451
failure.9450:
  %ctx.field.9452 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 969, ptr %ctx.field.9452, align 4
  %status.diagnostic.9453 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9453, align 4
  ret void
continue.9451:
  %depth.exceeded.9454 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9454, label %failure.9455, label %continue.9456
failure.9455:
  %ctx.field.9457 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 970, ptr %ctx.field.9457, align 4
  %status.diagnostic.9458 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9458, align 4
  ret void
continue.9456:
  %workspace.slot.9459 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9429, ptr %workspace.slot.9459, align 8
  %workspace.slot.9460 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9461 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 163, ptr %outputs, i32 1, ptr %workspace.slot.9460)
  switch i32 %record.make.status.9461, label %runtime.invalid.result.9467 [ i32 0, label %runtime.success.9462 i32 1, label %runtime.invalid.request.9463 i32 2, label %runtime.invalid.reference.9464 i32 3, label %runtime.scratch.capacity.9465 i32 4, label %runtime.retained.capacity.9466 ]
runtime.invalid.request.9463:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9464:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9465:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9466:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9467:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9462:
  %record.make.handle.9468 = load i64, ptr %workspace.slot.9460, align 8
  %ctx.field.9469 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9470 = load i32, ptr %ctx.field.9469, align 4
  %steps.next.9471 = add i32 %steps.current.9470, 1
  store i32 %steps.next.9471, ptr %ctx.field.9469, align 4
  %steps.over.9472 = icmp ugt i32 %steps.next.9471, 10000
  br i1 %steps.over.9472, label %failure.9473, label %continue.9474
failure.9473:
  %ctx.field.9475 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 971, ptr %ctx.field.9475, align 4
  %status.diagnostic.9476 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9476, align 4
  ret void
continue.9474:
  %ctx.field.9477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9478 = load i32, ptr %ctx.field.9477, align 4
  %steps.next.9479 = add i32 %steps.current.9478, 1
  store i32 %steps.next.9479, ptr %ctx.field.9477, align 4
  %steps.over.9480 = icmp ugt i32 %steps.next.9479, 10000
  br i1 %steps.over.9480, label %failure.9481, label %continue.9482
failure.9481:
  %ctx.field.9483 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 972, ptr %ctx.field.9483, align 4
  %status.diagnostic.9484 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9484, align 4
  ret void
continue.9482:
  %ctx.field.9485 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9486 = load i32, ptr %ctx.field.9485, align 4
  %steps.next.9487 = add i32 %steps.current.9486, 1
  store i32 %steps.next.9487, ptr %ctx.field.9485, align 4
  %steps.over.9488 = icmp ugt i32 %steps.next.9487, 10000
  br i1 %steps.over.9488, label %failure.9489, label %continue.9490
failure.9489:
  %ctx.field.9491 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 973, ptr %ctx.field.9491, align 4
  %status.diagnostic.9492 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9492, align 4
  ret void
continue.9490:
  %depth.exceeded.9493 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9493, label %failure.9494, label %continue.9495
failure.9494:
  %ctx.field.9496 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 974, ptr %ctx.field.9496, align 4
  %status.diagnostic.9497 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9497, align 4
  ret void
continue.9495:
  %workspace.slot.9498 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9468, ptr %workspace.slot.9498, align 8
  %workspace.slot.9499 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9500 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 164, ptr %outputs, i32 1, ptr %workspace.slot.9499)
  switch i32 %record.make.status.9500, label %runtime.invalid.result.9506 [ i32 0, label %runtime.success.9501 i32 1, label %runtime.invalid.request.9502 i32 2, label %runtime.invalid.reference.9503 i32 3, label %runtime.scratch.capacity.9504 i32 4, label %runtime.retained.capacity.9505 ]
runtime.invalid.request.9502:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9503:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9504:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9505:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9506:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9501:
  %record.make.handle.9507 = load i64, ptr %workspace.slot.9499, align 8
  %ctx.field.9508 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9509 = load i32, ptr %ctx.field.9508, align 4
  %steps.next.9510 = add i32 %steps.current.9509, 1
  store i32 %steps.next.9510, ptr %ctx.field.9508, align 4
  %steps.over.9511 = icmp ugt i32 %steps.next.9510, 10000
  br i1 %steps.over.9511, label %failure.9512, label %continue.9513
failure.9512:
  %ctx.field.9514 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 975, ptr %ctx.field.9514, align 4
  %status.diagnostic.9515 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9515, align 4
  ret void
continue.9513:
  %ctx.field.9516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9517 = load i32, ptr %ctx.field.9516, align 4
  %steps.next.9518 = add i32 %steps.current.9517, 1
  store i32 %steps.next.9518, ptr %ctx.field.9516, align 4
  %steps.over.9519 = icmp ugt i32 %steps.next.9518, 10000
  br i1 %steps.over.9519, label %failure.9520, label %continue.9521
failure.9520:
  %ctx.field.9522 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 976, ptr %ctx.field.9522, align 4
  %status.diagnostic.9523 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9523, align 4
  ret void
continue.9521:
  %ctx.field.9524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9525 = load i32, ptr %ctx.field.9524, align 4
  %steps.next.9526 = add i32 %steps.current.9525, 1
  store i32 %steps.next.9526, ptr %ctx.field.9524, align 4
  %steps.over.9527 = icmp ugt i32 %steps.next.9526, 10000
  br i1 %steps.over.9527, label %failure.9528, label %continue.9529
failure.9528:
  %ctx.field.9530 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 977, ptr %ctx.field.9530, align 4
  %status.diagnostic.9531 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9531, align 4
  ret void
continue.9529:
  %depth.exceeded.9532 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9532, label %failure.9533, label %continue.9534
failure.9533:
  %ctx.field.9535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 978, ptr %ctx.field.9535, align 4
  %status.diagnostic.9536 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9536, align 4
  ret void
continue.9534:
  %workspace.slot.9537 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9507, ptr %workspace.slot.9537, align 8
  %workspace.slot.9538 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9539 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 165, ptr %outputs, i32 1, ptr %workspace.slot.9538)
  switch i32 %record.make.status.9539, label %runtime.invalid.result.9545 [ i32 0, label %runtime.success.9540 i32 1, label %runtime.invalid.request.9541 i32 2, label %runtime.invalid.reference.9542 i32 3, label %runtime.scratch.capacity.9543 i32 4, label %runtime.retained.capacity.9544 ]
runtime.invalid.request.9541:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9542:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9543:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9544:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9545:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9540:
  %record.make.handle.9546 = load i64, ptr %workspace.slot.9538, align 8
  %ctx.field.9547 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9548 = load i32, ptr %ctx.field.9547, align 4
  %steps.next.9549 = add i32 %steps.current.9548, 1
  store i32 %steps.next.9549, ptr %ctx.field.9547, align 4
  %steps.over.9550 = icmp ugt i32 %steps.next.9549, 10000
  br i1 %steps.over.9550, label %failure.9551, label %continue.9552
failure.9551:
  %ctx.field.9553 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 979, ptr %ctx.field.9553, align 4
  %status.diagnostic.9554 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9554, align 4
  ret void
continue.9552:
  %ctx.field.9555 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9556 = load i32, ptr %ctx.field.9555, align 4
  %steps.next.9557 = add i32 %steps.current.9556, 1
  store i32 %steps.next.9557, ptr %ctx.field.9555, align 4
  %steps.over.9558 = icmp ugt i32 %steps.next.9557, 10000
  br i1 %steps.over.9558, label %failure.9559, label %continue.9560
failure.9559:
  %ctx.field.9561 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 980, ptr %ctx.field.9561, align 4
  %status.diagnostic.9562 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9562, align 4
  ret void
continue.9560:
  %ctx.field.9563 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9564 = load i32, ptr %ctx.field.9563, align 4
  %steps.next.9565 = add i32 %steps.current.9564, 1
  store i32 %steps.next.9565, ptr %ctx.field.9563, align 4
  %steps.over.9566 = icmp ugt i32 %steps.next.9565, 10000
  br i1 %steps.over.9566, label %failure.9567, label %continue.9568
failure.9567:
  %ctx.field.9569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 981, ptr %ctx.field.9569, align 4
  %status.diagnostic.9570 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9570, align 4
  ret void
continue.9568:
  %depth.exceeded.9571 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9571, label %failure.9572, label %continue.9573
failure.9572:
  %ctx.field.9574 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 982, ptr %ctx.field.9574, align 4
  %status.diagnostic.9575 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9575, align 4
  ret void
continue.9573:
  %workspace.slot.9576 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9546, ptr %workspace.slot.9576, align 8
  %workspace.slot.9577 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9578 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 166, ptr %outputs, i32 1, ptr %workspace.slot.9577)
  switch i32 %record.make.status.9578, label %runtime.invalid.result.9584 [ i32 0, label %runtime.success.9579 i32 1, label %runtime.invalid.request.9580 i32 2, label %runtime.invalid.reference.9581 i32 3, label %runtime.scratch.capacity.9582 i32 4, label %runtime.retained.capacity.9583 ]
runtime.invalid.request.9580:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9581:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9582:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9583:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9584:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9579:
  %record.make.handle.9585 = load i64, ptr %workspace.slot.9577, align 8
  %ctx.field.9586 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9587 = load i32, ptr %ctx.field.9586, align 4
  %steps.next.9588 = add i32 %steps.current.9587, 1
  store i32 %steps.next.9588, ptr %ctx.field.9586, align 4
  %steps.over.9589 = icmp ugt i32 %steps.next.9588, 10000
  br i1 %steps.over.9589, label %failure.9590, label %continue.9591
failure.9590:
  %ctx.field.9592 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 983, ptr %ctx.field.9592, align 4
  %status.diagnostic.9593 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9593, align 4
  ret void
continue.9591:
  %ctx.field.9594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9595 = load i32, ptr %ctx.field.9594, align 4
  %steps.next.9596 = add i32 %steps.current.9595, 1
  store i32 %steps.next.9596, ptr %ctx.field.9594, align 4
  %steps.over.9597 = icmp ugt i32 %steps.next.9596, 10000
  br i1 %steps.over.9597, label %failure.9598, label %continue.9599
failure.9598:
  %ctx.field.9600 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 984, ptr %ctx.field.9600, align 4
  %status.diagnostic.9601 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9601, align 4
  ret void
continue.9599:
  %ctx.field.9602 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9603 = load i32, ptr %ctx.field.9602, align 4
  %steps.next.9604 = add i32 %steps.current.9603, 1
  store i32 %steps.next.9604, ptr %ctx.field.9602, align 4
  %steps.over.9605 = icmp ugt i32 %steps.next.9604, 10000
  br i1 %steps.over.9605, label %failure.9606, label %continue.9607
failure.9606:
  %ctx.field.9608 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 985, ptr %ctx.field.9608, align 4
  %status.diagnostic.9609 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9609, align 4
  ret void
continue.9607:
  %depth.exceeded.9610 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9610, label %failure.9611, label %continue.9612
failure.9611:
  %ctx.field.9613 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 986, ptr %ctx.field.9613, align 4
  %status.diagnostic.9614 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9614, align 4
  ret void
continue.9612:
  %workspace.slot.9615 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9585, ptr %workspace.slot.9615, align 8
  %workspace.slot.9616 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9617 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 167, ptr %outputs, i32 1, ptr %workspace.slot.9616)
  switch i32 %record.make.status.9617, label %runtime.invalid.result.9623 [ i32 0, label %runtime.success.9618 i32 1, label %runtime.invalid.request.9619 i32 2, label %runtime.invalid.reference.9620 i32 3, label %runtime.scratch.capacity.9621 i32 4, label %runtime.retained.capacity.9622 ]
runtime.invalid.request.9619:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9620:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9621:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9622:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9623:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9618:
  %record.make.handle.9624 = load i64, ptr %workspace.slot.9616, align 8
  %ctx.field.9625 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9626 = load i32, ptr %ctx.field.9625, align 4
  %steps.next.9627 = add i32 %steps.current.9626, 1
  store i32 %steps.next.9627, ptr %ctx.field.9625, align 4
  %steps.over.9628 = icmp ugt i32 %steps.next.9627, 10000
  br i1 %steps.over.9628, label %failure.9629, label %continue.9630
failure.9629:
  %ctx.field.9631 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 987, ptr %ctx.field.9631, align 4
  %status.diagnostic.9632 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9632, align 4
  ret void
continue.9630:
  %ctx.field.9633 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9634 = load i32, ptr %ctx.field.9633, align 4
  %steps.next.9635 = add i32 %steps.current.9634, 1
  store i32 %steps.next.9635, ptr %ctx.field.9633, align 4
  %steps.over.9636 = icmp ugt i32 %steps.next.9635, 10000
  br i1 %steps.over.9636, label %failure.9637, label %continue.9638
failure.9637:
  %ctx.field.9639 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 988, ptr %ctx.field.9639, align 4
  %status.diagnostic.9640 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9640, align 4
  ret void
continue.9638:
  %ctx.field.9641 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9642 = load i32, ptr %ctx.field.9641, align 4
  %steps.next.9643 = add i32 %steps.current.9642, 1
  store i32 %steps.next.9643, ptr %ctx.field.9641, align 4
  %steps.over.9644 = icmp ugt i32 %steps.next.9643, 10000
  br i1 %steps.over.9644, label %failure.9645, label %continue.9646
failure.9645:
  %ctx.field.9647 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 989, ptr %ctx.field.9647, align 4
  %status.diagnostic.9648 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9648, align 4
  ret void
continue.9646:
  %depth.exceeded.9649 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9649, label %failure.9650, label %continue.9651
failure.9650:
  %ctx.field.9652 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 990, ptr %ctx.field.9652, align 4
  %status.diagnostic.9653 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9653, align 4
  ret void
continue.9651:
  %workspace.slot.9654 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9624, ptr %workspace.slot.9654, align 8
  %workspace.slot.9655 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9656 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 168, ptr %outputs, i32 1, ptr %workspace.slot.9655)
  switch i32 %record.make.status.9656, label %runtime.invalid.result.9662 [ i32 0, label %runtime.success.9657 i32 1, label %runtime.invalid.request.9658 i32 2, label %runtime.invalid.reference.9659 i32 3, label %runtime.scratch.capacity.9660 i32 4, label %runtime.retained.capacity.9661 ]
runtime.invalid.request.9658:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9659:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9660:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9661:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9662:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9657:
  %record.make.handle.9663 = load i64, ptr %workspace.slot.9655, align 8
  %ctx.field.9664 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9665 = load i32, ptr %ctx.field.9664, align 4
  %steps.next.9666 = add i32 %steps.current.9665, 1
  store i32 %steps.next.9666, ptr %ctx.field.9664, align 4
  %steps.over.9667 = icmp ugt i32 %steps.next.9666, 10000
  br i1 %steps.over.9667, label %failure.9668, label %continue.9669
failure.9668:
  %ctx.field.9670 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 991, ptr %ctx.field.9670, align 4
  %status.diagnostic.9671 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9671, align 4
  ret void
continue.9669:
  %ctx.field.9672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9673 = load i32, ptr %ctx.field.9672, align 4
  %steps.next.9674 = add i32 %steps.current.9673, 1
  store i32 %steps.next.9674, ptr %ctx.field.9672, align 4
  %steps.over.9675 = icmp ugt i32 %steps.next.9674, 10000
  br i1 %steps.over.9675, label %failure.9676, label %continue.9677
failure.9676:
  %ctx.field.9678 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 992, ptr %ctx.field.9678, align 4
  %status.diagnostic.9679 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9679, align 4
  ret void
continue.9677:
  %ctx.field.9680 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9681 = load i32, ptr %ctx.field.9680, align 4
  %steps.next.9682 = add i32 %steps.current.9681, 1
  store i32 %steps.next.9682, ptr %ctx.field.9680, align 4
  %steps.over.9683 = icmp ugt i32 %steps.next.9682, 10000
  br i1 %steps.over.9683, label %failure.9684, label %continue.9685
failure.9684:
  %ctx.field.9686 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 993, ptr %ctx.field.9686, align 4
  %status.diagnostic.9687 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9687, align 4
  ret void
continue.9685:
  %depth.exceeded.9688 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9688, label %failure.9689, label %continue.9690
failure.9689:
  %ctx.field.9691 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 994, ptr %ctx.field.9691, align 4
  %status.diagnostic.9692 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9692, align 4
  ret void
continue.9690:
  %workspace.slot.9693 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9663, ptr %workspace.slot.9693, align 8
  %workspace.slot.9694 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9695 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 169, ptr %outputs, i32 1, ptr %workspace.slot.9694)
  switch i32 %record.make.status.9695, label %runtime.invalid.result.9701 [ i32 0, label %runtime.success.9696 i32 1, label %runtime.invalid.request.9697 i32 2, label %runtime.invalid.reference.9698 i32 3, label %runtime.scratch.capacity.9699 i32 4, label %runtime.retained.capacity.9700 ]
runtime.invalid.request.9697:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9698:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9699:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9700:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9701:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9696:
  %record.make.handle.9702 = load i64, ptr %workspace.slot.9694, align 8
  %ctx.field.9703 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9704 = load i32, ptr %ctx.field.9703, align 4
  %steps.next.9705 = add i32 %steps.current.9704, 1
  store i32 %steps.next.9705, ptr %ctx.field.9703, align 4
  %steps.over.9706 = icmp ugt i32 %steps.next.9705, 10000
  br i1 %steps.over.9706, label %failure.9707, label %continue.9708
failure.9707:
  %ctx.field.9709 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 995, ptr %ctx.field.9709, align 4
  %status.diagnostic.9710 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9710, align 4
  ret void
continue.9708:
  %ctx.field.9711 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9712 = load i32, ptr %ctx.field.9711, align 4
  %steps.next.9713 = add i32 %steps.current.9712, 1
  store i32 %steps.next.9713, ptr %ctx.field.9711, align 4
  %steps.over.9714 = icmp ugt i32 %steps.next.9713, 10000
  br i1 %steps.over.9714, label %failure.9715, label %continue.9716
failure.9715:
  %ctx.field.9717 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 996, ptr %ctx.field.9717, align 4
  %status.diagnostic.9718 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9718, align 4
  ret void
continue.9716:
  %ctx.field.9719 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9720 = load i32, ptr %ctx.field.9719, align 4
  %steps.next.9721 = add i32 %steps.current.9720, 1
  store i32 %steps.next.9721, ptr %ctx.field.9719, align 4
  %steps.over.9722 = icmp ugt i32 %steps.next.9721, 10000
  br i1 %steps.over.9722, label %failure.9723, label %continue.9724
failure.9723:
  %ctx.field.9725 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 997, ptr %ctx.field.9725, align 4
  %status.diagnostic.9726 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9726, align 4
  ret void
continue.9724:
  %depth.exceeded.9727 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9727, label %failure.9728, label %continue.9729
failure.9728:
  %ctx.field.9730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 998, ptr %ctx.field.9730, align 4
  %status.diagnostic.9731 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9731, align 4
  ret void
continue.9729:
  %workspace.slot.9732 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9702, ptr %workspace.slot.9732, align 8
  %workspace.slot.9733 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9734 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 170, ptr %outputs, i32 1, ptr %workspace.slot.9733)
  switch i32 %record.make.status.9734, label %runtime.invalid.result.9740 [ i32 0, label %runtime.success.9735 i32 1, label %runtime.invalid.request.9736 i32 2, label %runtime.invalid.reference.9737 i32 3, label %runtime.scratch.capacity.9738 i32 4, label %runtime.retained.capacity.9739 ]
runtime.invalid.request.9736:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9737:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9738:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9739:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9740:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9735:
  %record.make.handle.9741 = load i64, ptr %workspace.slot.9733, align 8
  %ctx.field.9742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9743 = load i32, ptr %ctx.field.9742, align 4
  %steps.next.9744 = add i32 %steps.current.9743, 1
  store i32 %steps.next.9744, ptr %ctx.field.9742, align 4
  %steps.over.9745 = icmp ugt i32 %steps.next.9744, 10000
  br i1 %steps.over.9745, label %failure.9746, label %continue.9747
failure.9746:
  %ctx.field.9748 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 999, ptr %ctx.field.9748, align 4
  %status.diagnostic.9749 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9749, align 4
  ret void
continue.9747:
  %ctx.field.9750 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9751 = load i32, ptr %ctx.field.9750, align 4
  %steps.next.9752 = add i32 %steps.current.9751, 1
  store i32 %steps.next.9752, ptr %ctx.field.9750, align 4
  %steps.over.9753 = icmp ugt i32 %steps.next.9752, 10000
  br i1 %steps.over.9753, label %failure.9754, label %continue.9755
failure.9754:
  %ctx.field.9756 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1000, ptr %ctx.field.9756, align 4
  %status.diagnostic.9757 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9757, align 4
  ret void
continue.9755:
  %ctx.field.9758 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9759 = load i32, ptr %ctx.field.9758, align 4
  %steps.next.9760 = add i32 %steps.current.9759, 1
  store i32 %steps.next.9760, ptr %ctx.field.9758, align 4
  %steps.over.9761 = icmp ugt i32 %steps.next.9760, 10000
  br i1 %steps.over.9761, label %failure.9762, label %continue.9763
failure.9762:
  %ctx.field.9764 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1001, ptr %ctx.field.9764, align 4
  %status.diagnostic.9765 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9765, align 4
  ret void
continue.9763:
  %depth.exceeded.9766 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9766, label %failure.9767, label %continue.9768
failure.9767:
  %ctx.field.9769 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1002, ptr %ctx.field.9769, align 4
  %status.diagnostic.9770 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9770, align 4
  ret void
continue.9768:
  %workspace.slot.9771 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9741, ptr %workspace.slot.9771, align 8
  %workspace.slot.9772 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9773 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 172, ptr %outputs, i32 1, ptr %workspace.slot.9772)
  switch i32 %record.make.status.9773, label %runtime.invalid.result.9779 [ i32 0, label %runtime.success.9774 i32 1, label %runtime.invalid.request.9775 i32 2, label %runtime.invalid.reference.9776 i32 3, label %runtime.scratch.capacity.9777 i32 4, label %runtime.retained.capacity.9778 ]
runtime.invalid.request.9775:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9776:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9777:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9778:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9779:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9774:
  %record.make.handle.9780 = load i64, ptr %workspace.slot.9772, align 8
  %ctx.field.9781 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9782 = load i32, ptr %ctx.field.9781, align 4
  %steps.next.9783 = add i32 %steps.current.9782, 1
  store i32 %steps.next.9783, ptr %ctx.field.9781, align 4
  %steps.over.9784 = icmp ugt i32 %steps.next.9783, 10000
  br i1 %steps.over.9784, label %failure.9785, label %continue.9786
failure.9785:
  %ctx.field.9787 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1003, ptr %ctx.field.9787, align 4
  %status.diagnostic.9788 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9788, align 4
  ret void
continue.9786:
  %ctx.field.9789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9790 = load i32, ptr %ctx.field.9789, align 4
  %steps.next.9791 = add i32 %steps.current.9790, 1
  store i32 %steps.next.9791, ptr %ctx.field.9789, align 4
  %steps.over.9792 = icmp ugt i32 %steps.next.9791, 10000
  br i1 %steps.over.9792, label %failure.9793, label %continue.9794
failure.9793:
  %ctx.field.9795 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1004, ptr %ctx.field.9795, align 4
  %status.diagnostic.9796 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9796, align 4
  ret void
continue.9794:
  %ctx.field.9797 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9798 = load i32, ptr %ctx.field.9797, align 4
  %steps.next.9799 = add i32 %steps.current.9798, 1
  store i32 %steps.next.9799, ptr %ctx.field.9797, align 4
  %steps.over.9800 = icmp ugt i32 %steps.next.9799, 10000
  br i1 %steps.over.9800, label %failure.9801, label %continue.9802
failure.9801:
  %ctx.field.9803 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1005, ptr %ctx.field.9803, align 4
  %status.diagnostic.9804 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9804, align 4
  ret void
continue.9802:
  %depth.exceeded.9805 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9805, label %failure.9806, label %continue.9807
failure.9806:
  %ctx.field.9808 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1006, ptr %ctx.field.9808, align 4
  %status.diagnostic.9809 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9809, align 4
  ret void
continue.9807:
  %workspace.slot.9810 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9780, ptr %workspace.slot.9810, align 8
  %workspace.slot.9811 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9812 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 173, ptr %outputs, i32 1, ptr %workspace.slot.9811)
  switch i32 %record.make.status.9812, label %runtime.invalid.result.9818 [ i32 0, label %runtime.success.9813 i32 1, label %runtime.invalid.request.9814 i32 2, label %runtime.invalid.reference.9815 i32 3, label %runtime.scratch.capacity.9816 i32 4, label %runtime.retained.capacity.9817 ]
runtime.invalid.request.9814:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9815:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9816:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9817:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9818:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9813:
  %record.make.handle.9819 = load i64, ptr %workspace.slot.9811, align 8
  %ctx.field.9820 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9821 = load i32, ptr %ctx.field.9820, align 4
  %steps.next.9822 = add i32 %steps.current.9821, 1
  store i32 %steps.next.9822, ptr %ctx.field.9820, align 4
  %steps.over.9823 = icmp ugt i32 %steps.next.9822, 10000
  br i1 %steps.over.9823, label %failure.9824, label %continue.9825
failure.9824:
  %ctx.field.9826 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1007, ptr %ctx.field.9826, align 4
  %status.diagnostic.9827 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9827, align 4
  ret void
continue.9825:
  %ctx.field.9828 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9829 = load i32, ptr %ctx.field.9828, align 4
  %steps.next.9830 = add i32 %steps.current.9829, 1
  store i32 %steps.next.9830, ptr %ctx.field.9828, align 4
  %steps.over.9831 = icmp ugt i32 %steps.next.9830, 10000
  br i1 %steps.over.9831, label %failure.9832, label %continue.9833
failure.9832:
  %ctx.field.9834 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1008, ptr %ctx.field.9834, align 4
  %status.diagnostic.9835 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9835, align 4
  ret void
continue.9833:
  %ctx.field.9836 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9837 = load i32, ptr %ctx.field.9836, align 4
  %steps.next.9838 = add i32 %steps.current.9837, 1
  store i32 %steps.next.9838, ptr %ctx.field.9836, align 4
  %steps.over.9839 = icmp ugt i32 %steps.next.9838, 10000
  br i1 %steps.over.9839, label %failure.9840, label %continue.9841
failure.9840:
  %ctx.field.9842 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1009, ptr %ctx.field.9842, align 4
  %status.diagnostic.9843 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9843, align 4
  ret void
continue.9841:
  %depth.exceeded.9844 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9844, label %failure.9845, label %continue.9846
failure.9845:
  %ctx.field.9847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1010, ptr %ctx.field.9847, align 4
  %status.diagnostic.9848 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9848, align 4
  ret void
continue.9846:
  %workspace.slot.9849 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9819, ptr %workspace.slot.9849, align 8
  %workspace.slot.9850 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9851 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 174, ptr %outputs, i32 1, ptr %workspace.slot.9850)
  switch i32 %record.make.status.9851, label %runtime.invalid.result.9857 [ i32 0, label %runtime.success.9852 i32 1, label %runtime.invalid.request.9853 i32 2, label %runtime.invalid.reference.9854 i32 3, label %runtime.scratch.capacity.9855 i32 4, label %runtime.retained.capacity.9856 ]
runtime.invalid.request.9853:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9854:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9855:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9856:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9857:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9852:
  %record.make.handle.9858 = load i64, ptr %workspace.slot.9850, align 8
  %ctx.field.9859 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9860 = load i32, ptr %ctx.field.9859, align 4
  %steps.next.9861 = add i32 %steps.current.9860, 1
  store i32 %steps.next.9861, ptr %ctx.field.9859, align 4
  %steps.over.9862 = icmp ugt i32 %steps.next.9861, 10000
  br i1 %steps.over.9862, label %failure.9863, label %continue.9864
failure.9863:
  %ctx.field.9865 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1011, ptr %ctx.field.9865, align 4
  %status.diagnostic.9866 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9866, align 4
  ret void
continue.9864:
  %ctx.field.9867 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9868 = load i32, ptr %ctx.field.9867, align 4
  %steps.next.9869 = add i32 %steps.current.9868, 1
  store i32 %steps.next.9869, ptr %ctx.field.9867, align 4
  %steps.over.9870 = icmp ugt i32 %steps.next.9869, 10000
  br i1 %steps.over.9870, label %failure.9871, label %continue.9872
failure.9871:
  %ctx.field.9873 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1012, ptr %ctx.field.9873, align 4
  %status.diagnostic.9874 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9874, align 4
  ret void
continue.9872:
  %ctx.field.9875 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9876 = load i32, ptr %ctx.field.9875, align 4
  %steps.next.9877 = add i32 %steps.current.9876, 1
  store i32 %steps.next.9877, ptr %ctx.field.9875, align 4
  %steps.over.9878 = icmp ugt i32 %steps.next.9877, 10000
  br i1 %steps.over.9878, label %failure.9879, label %continue.9880
failure.9879:
  %ctx.field.9881 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1013, ptr %ctx.field.9881, align 4
  %status.diagnostic.9882 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9882, align 4
  ret void
continue.9880:
  %depth.exceeded.9883 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9883, label %failure.9884, label %continue.9885
failure.9884:
  %ctx.field.9886 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1014, ptr %ctx.field.9886, align 4
  %status.diagnostic.9887 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9887, align 4
  ret void
continue.9885:
  %workspace.slot.9888 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9858, ptr %workspace.slot.9888, align 8
  %workspace.slot.9889 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9890 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 175, ptr %outputs, i32 1, ptr %workspace.slot.9889)
  switch i32 %record.make.status.9890, label %runtime.invalid.result.9896 [ i32 0, label %runtime.success.9891 i32 1, label %runtime.invalid.request.9892 i32 2, label %runtime.invalid.reference.9893 i32 3, label %runtime.scratch.capacity.9894 i32 4, label %runtime.retained.capacity.9895 ]
runtime.invalid.request.9892:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9893:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9894:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9895:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9896:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9891:
  %record.make.handle.9897 = load i64, ptr %workspace.slot.9889, align 8
  %ctx.field.9898 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9899 = load i32, ptr %ctx.field.9898, align 4
  %steps.next.9900 = add i32 %steps.current.9899, 1
  store i32 %steps.next.9900, ptr %ctx.field.9898, align 4
  %steps.over.9901 = icmp ugt i32 %steps.next.9900, 10000
  br i1 %steps.over.9901, label %failure.9902, label %continue.9903
failure.9902:
  %ctx.field.9904 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1015, ptr %ctx.field.9904, align 4
  %status.diagnostic.9905 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9905, align 4
  ret void
continue.9903:
  %ctx.field.9906 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9907 = load i32, ptr %ctx.field.9906, align 4
  %steps.next.9908 = add i32 %steps.current.9907, 1
  store i32 %steps.next.9908, ptr %ctx.field.9906, align 4
  %steps.over.9909 = icmp ugt i32 %steps.next.9908, 10000
  br i1 %steps.over.9909, label %failure.9910, label %continue.9911
failure.9910:
  %ctx.field.9912 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1016, ptr %ctx.field.9912, align 4
  %status.diagnostic.9913 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9913, align 4
  ret void
continue.9911:
  %ctx.field.9914 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9915 = load i32, ptr %ctx.field.9914, align 4
  %steps.next.9916 = add i32 %steps.current.9915, 1
  store i32 %steps.next.9916, ptr %ctx.field.9914, align 4
  %steps.over.9917 = icmp ugt i32 %steps.next.9916, 10000
  br i1 %steps.over.9917, label %failure.9918, label %continue.9919
failure.9918:
  %ctx.field.9920 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1017, ptr %ctx.field.9920, align 4
  %status.diagnostic.9921 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9921, align 4
  ret void
continue.9919:
  %depth.exceeded.9922 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9922, label %failure.9923, label %continue.9924
failure.9923:
  %ctx.field.9925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1018, ptr %ctx.field.9925, align 4
  %status.diagnostic.9926 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9926, align 4
  ret void
continue.9924:
  %workspace.slot.9927 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9897, ptr %workspace.slot.9927, align 8
  %workspace.slot.9928 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9929 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 176, ptr %outputs, i32 1, ptr %workspace.slot.9928)
  switch i32 %record.make.status.9929, label %runtime.invalid.result.9935 [ i32 0, label %runtime.success.9930 i32 1, label %runtime.invalid.request.9931 i32 2, label %runtime.invalid.reference.9932 i32 3, label %runtime.scratch.capacity.9933 i32 4, label %runtime.retained.capacity.9934 ]
runtime.invalid.request.9931:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9932:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9933:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9934:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9935:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9930:
  %record.make.handle.9936 = load i64, ptr %workspace.slot.9928, align 8
  %ctx.field.9937 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9938 = load i32, ptr %ctx.field.9937, align 4
  %steps.next.9939 = add i32 %steps.current.9938, 1
  store i32 %steps.next.9939, ptr %ctx.field.9937, align 4
  %steps.over.9940 = icmp ugt i32 %steps.next.9939, 10000
  br i1 %steps.over.9940, label %failure.9941, label %continue.9942
failure.9941:
  %ctx.field.9943 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1019, ptr %ctx.field.9943, align 4
  %status.diagnostic.9944 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9944, align 4
  ret void
continue.9942:
  %ctx.field.9945 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9946 = load i32, ptr %ctx.field.9945, align 4
  %steps.next.9947 = add i32 %steps.current.9946, 1
  store i32 %steps.next.9947, ptr %ctx.field.9945, align 4
  %steps.over.9948 = icmp ugt i32 %steps.next.9947, 10000
  br i1 %steps.over.9948, label %failure.9949, label %continue.9950
failure.9949:
  %ctx.field.9951 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1020, ptr %ctx.field.9951, align 4
  %status.diagnostic.9952 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9952, align 4
  ret void
continue.9950:
  %ctx.field.9953 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9954 = load i32, ptr %ctx.field.9953, align 4
  %steps.next.9955 = add i32 %steps.current.9954, 1
  store i32 %steps.next.9955, ptr %ctx.field.9953, align 4
  %steps.over.9956 = icmp ugt i32 %steps.next.9955, 10000
  br i1 %steps.over.9956, label %failure.9957, label %continue.9958
failure.9957:
  %ctx.field.9959 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1021, ptr %ctx.field.9959, align 4
  %status.diagnostic.9960 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9960, align 4
  ret void
continue.9958:
  %depth.exceeded.9961 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.9961, label %failure.9962, label %continue.9963
failure.9962:
  %ctx.field.9964 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1022, ptr %ctx.field.9964, align 4
  %status.diagnostic.9965 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9965, align 4
  ret void
continue.9963:
  %workspace.slot.9966 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.9936, ptr %workspace.slot.9966, align 8
  %workspace.slot.9967 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.9968 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 177, ptr %outputs, i32 1, ptr %workspace.slot.9967)
  switch i32 %record.make.status.9968, label %runtime.invalid.result.9974 [ i32 0, label %runtime.success.9969 i32 1, label %runtime.invalid.request.9970 i32 2, label %runtime.invalid.reference.9971 i32 3, label %runtime.scratch.capacity.9972 i32 4, label %runtime.retained.capacity.9973 ]
runtime.invalid.request.9970:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.9971:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.9972:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.9973:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.9974:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.9969:
  %record.make.handle.9975 = load i64, ptr %workspace.slot.9967, align 8
  br label %value.limit.failure.9976
value.limit.failure.9976:
  %ctx.field.9978 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1023, ptr %ctx.field.9978, align 4
  %status.diagnostic.9979 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9979, align 4
  ret void
value.limit.continue.9977:
  %ctx.field.9980 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9981 = load i32, ptr %ctx.field.9980, align 4
  %steps.next.9982 = add i32 %steps.current.9981, 1
  store i32 %steps.next.9982, ptr %ctx.field.9980, align 4
  %steps.over.9983 = icmp ugt i32 %steps.next.9982, 10000
  br i1 %steps.over.9983, label %failure.9984, label %continue.9985
failure.9984:
  %ctx.field.9986 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1024, ptr %ctx.field.9986, align 4
  %status.diagnostic.9987 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9987, align 4
  ret void
continue.9985:
  br label %value.limit.failure.9988
value.limit.failure.9988:
  %ctx.field.9990 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1025, ptr %ctx.field.9990, align 4
  %status.diagnostic.9991 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.9991, align 4
  ret void
value.limit.continue.9989:
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 2 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 0, i32 %capacity, ptr %status, i32 2)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr null, i32 0)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 0, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

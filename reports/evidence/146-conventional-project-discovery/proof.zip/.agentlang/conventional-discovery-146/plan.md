# Conventional broker discovery

Objective: address report145's broker argument/path guessing before another efficacy comparison.

- Add inspect with no arguments as a deterministic project overview. Preserve inspect(path).
- Return canonical operation schemas, configured validation target and bounded allowed-source file paths; no source bodies or hashing during overview.
- Keep six operation names. Share search's deterministic traversal, generated-directory exclusions, reparse rejection, entry/depth bounds. Inventory observes file/result limits and explicit truncation.
- Preserve strict mutation fields, fresh hashes, exact anchors and path rejection. Preserve CLI's existing nested args compatibility while documenting canonical top-level fields.
- Files: Conventional Dispatcher.fs; conventional dispatcher and CLI executable test programs; docs/CONVENTIONAL.md. Root owns report146, roadmap and archived validation.
- Acceptance: empty inspect discovers paths + all operation argument forms; inspect(path) remains compatible; malformed inspect fields fail; traversal limits and symlinks remain guarded; JSONL read/hash/patch workflow discoverable; no historical trial files changed.
- Validation: fresh serial Release builds of both test projects with NuGetAudit=false, execute each test DLL; fresh conventional CLI build and bounded broker smoke if needed to verify integration.
- Do not claim reduced agent errors without a later independent trial.

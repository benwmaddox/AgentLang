[<EntryPoint>]
let main _ =
    printfn "PASS smoke"
    0

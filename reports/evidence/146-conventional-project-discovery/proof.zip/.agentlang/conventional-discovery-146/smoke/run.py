from pathlib import Path
import subprocess,json,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parents[1]
CLI=ROOT/'root-artifacts/bin/AgentLang.Conventional.Cli/release/AgentLang.Conventional.Cli.dll'
PROJECT=ROOT/'smoke/project'
for label,budget in [('overview',20000),('budget-denial',1)]:
    out=ROOT/'smoke'/label
    out.mkdir(exist_ok=False)
    trace=out/'trace.jsonl'
    command=['pwsh','-NoProfile','-File',str(REPO/'scripts/Start-SubagentTrialHostV2.ps1'),'-CliDll',str(CLI),'-ProjectPath',str(PROJECT),'-TracePath',str(trace),'-AllowedOperations','inspect','-Profile','conventional','-AdditionalCliArgumentsJson',json.dumps(['--validation-project','Demo.fsproj']),'-MaxInspectionResponseBytes',str(budget),'-MaxExchanges','3']
    requests='{"op":"inspect"}\n{"op":"host.close"}\n'
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    (out/'requests.jsonl').write_text(requests,encoding='utf-8')
    r=subprocess.run(command,input=requests,text=True,encoding='utf-8',capture_output=True,cwd=REPO)
    (out/'stdout.txt').write_text(r.stdout,encoding='utf-8');(out/'stderr.txt').write_text(r.stderr,encoding='utf-8')
    (out/'exit.txt').write_text(str(r.returncode)+'\n',encoding='utf-8')
    assert r.returncode==0,(label,r.stderr)
    rows=[json.loads(l) for l in trace.read_text(encoding='utf-8').splitlines()]
    exchange=next(x for x in rows if x.get('event')=='exchange')
    assert exchange['operation']=='inspect'
    assert exchange['inspectionBudget']['operationClass']=='inspection'
    if label=='overview':
        response=json.loads(exchange['response']['rawLine'])
        assert response['ok'],response
        assert exchange['inspectionBudget']['decision']=='admitted'
    else:
        assert exchange['inspectionBudget']['decision']=='withheld-after-response'
    audit=['pwsh','-NoProfile','-File',str(REPO/'scripts/Audit-SubagentTrialTerminationV2.ps1'),'-TracePath',str(trace)]
    a=subprocess.run(audit,text=True,encoding='utf-8',capture_output=True,cwd=REPO)
    (out/'audit.txt').write_text(a.stdout+a.stderr,encoding='utf-8')
    assert a.returncode==0,a.stderr
    print(label,'passed')

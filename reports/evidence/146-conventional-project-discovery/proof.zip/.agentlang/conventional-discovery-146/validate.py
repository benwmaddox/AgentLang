from pathlib import Path
import subprocess,os,json,hashlib
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OUT=ROOT/'root-validation'
OUT.mkdir(exist_ok=False)
artifacts=ROOT/'root-artifacts'
env=os.environ.copy();env['NuGetAudit']='false'
temp=ROOT/'root-tmp';temp.mkdir(exist_ok=True)
env['TMP']=str(temp);env['TEMP']=str(temp)
commands=[]
for name in ['AgentLang.Conventional.Tests','AgentLang.Conventional.Cli.Tests']:
    commands.append((name+'.build',['dotnet','build',str(REPO/'tests'/name/(name+'.fsproj')),'-c','Release','-m:1','-p:NuGetAudit=false','--artifacts-path',str(artifacts)]))
    commands.append((name+'.run',['dotnet',str(artifacts/'bin'/name/'release'/(name+'.dll'))]))
for label,cmd in commands:
    (OUT/(label+'.command.json')).write_text(json.dumps({'command':cmd,'cwd':str(REPO),'environmentOverrides':{k:env[k] for k in ['TMP','TEMP','NuGetAudit']}},indent=2)+'\n',encoding='utf-8')
    r=subprocess.run(cmd,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    (OUT/(label+'.stdout.txt')).write_text(r.stdout,encoding='utf-8');(OUT/(label+'.stderr.txt')).write_text(r.stderr,encoding='utf-8');(OUT/(label+'.exit.txt')).write_text(str(r.returncode)+'\n',encoding='utf-8')
    print(label,r.returncode,r.stdout[-500:],flush=True)
    if r.returncode:raise SystemExit(r.returncode)

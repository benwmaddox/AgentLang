# Root verification

Fresh CLI build after implementation completed:
`dotnet build experiments/AgentLang.Conventional.Cli/AgentLang.Conventional.Cli.fsproj -c Release -m:1 -p:NuGetAudit=false --artifacts-path .agentlang/conventional-discovery-146/root-artifacts`
Exit 0, 0 warnings, 0 errors. Tool execution recorded 4.76 seconds build time.

`python .agentlang/conventional-discovery-146/smoke/run.py` used the newly built CLI.
Both overview and budget-denial runs passed; existing termination auditor passed
both. Returned overview has Demo.fsproj/Program.fs, all six operation schemas,
correct configured validation target and truncated=false. The admitted response
was 993 UTF-8 payload bytes; cap 1 withheld the response after execution.

Reviewed worker clean Release builds/runs: 216 conventional assertions;
8 CLI groups/339 assertions. Worker used process-local workspace TMP/TEMP and
NuGetAudit=false for fixture-spawned validation. Initial test-syntax and OS-temp
sandbox failures are recorded separately, not counted as final passes.

Independent read-only review /root/conventional_discovery_plan found no material
defects in shared traversal/schema. It confirmed file/result stop points,
large-file scan accounting, deterministic ordering, reparse/error handling and
cross-directory entry-cap regression. It did not claim to execute tests.

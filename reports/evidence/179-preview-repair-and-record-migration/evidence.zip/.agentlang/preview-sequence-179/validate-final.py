"""Validate final study receipts; does not re-execute participant projects."""
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('preservation', HERE / 'audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
config = read(HERE / 'actors.json')
metrics = read(HERE / 'metrics.json')['stages']
assert len(metrics) == 12
projections = 0
library_stages = 0
fsharp_stages = 0
notes = {}
for actor in config['actors']:
    for stage in (1, 2):
        name = actor['name']
        capture = read(HERE / f'capture-{name}-stage{stage}.json')
        measured = next(row for row in metrics if row['actor'] == name and row['stage'] == stage)
        assert measured['normalFinalization']
        assert measured['traceSha256'] == capture['traceSha256'] == sha(HERE / f'trace-{name}-stage{stage}.jsonl')
        score = read(HERE / f"oracle/a{actor['order']}s{stage}.json")
        assert score['candidateUnchanged'] and not score['exceptions']
        fields = score['results'].get('fields', score['results'])
        for field in ('original',) if stage == 1 else ('original', 'proposed'):
            result = fields[field].get('score', fields[field])
            assert result['executedCaseCount'] == result['passedCaseCount'] == 37
            assert not result.get('setupFailure') and not result.get('setupFailureCaseIds')
            projections += 1
        assert not read(HERE / f'audit-{name}-stage{stage}.json')['automaticIssues']
        note = HERE / f'result-{name}-stage{stage}.md'
        assert note.is_file()
        notes[note.name] = sha(note)
        if actor['arm'] == 'fsharp':
            assert measured['validations'][-1]['exitCode'] == 0
            fsharp_stages += 1
        else:
            manifest, store = audit.manifest(HERE / f'snapshots/{name}-stage{stage}')
            assert audit.active(manifest)['subscription.preview-replacement']['maturity'] == 'library'
            assert any(item['ok'] for item in measured['publications'])
            assert measured['validations'][-1]['passed'] == measured['validations'][-1]['total']
            assert measured['taskCommits'][-1]['ok'] and measured['taskCommits'][-1]['active'] is False
            library_stages += 1
assert projections == 18 and library_stages == 8 and fsharp_stages == 4
verification = read(HERE / 'oracle/verify-a1s1.json')
assert verification['candidateUnchanged'] and verification['results']['original']['passedCaseCount'] == 37
output = HERE / 'validation-summary.json'
assert not output.exists()
output.write_text(json.dumps({
    'status': 'pass', 'participants': 6, 'stages': 12, 'projections': 18,
    'casesPerProjection': 37, 'allProjectionsPass': True,
    'automaticPreservationAuditsPass': 12,
    'manualSourceReviewNoteSha256': notes,
    'agentLangLibraryPublicationStages': library_stages,
    'fsharpSuccessfulValidationStages': fsharp_stages,
    'normalTerminalFinalizations': 12,
    'supplementalVerification': 'same first captured candidate; 37/37; not an additional participant outcome',
    'validatorSha256': sha(Path(__file__)),
}, indent=2) + '\n', encoding='utf-8')
print(output)

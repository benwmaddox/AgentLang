"""Freeze a terminal participant candidate before advancing its next stage."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('actor');parser.add_argument('--stage',type=int,choices=[1,2],required=True)
args=parser.parse_args()
config=json.loads((HERE/'actors.json').read_text())
actor=next(a for a in config['actors'] if a['name']==args.actor)
prompt=next(p for p in actor['prompts'] if p['stage']==args.stage)
assert sha(REPO/prompt['path'])==prompt['sha256']
assert sha(REPO/actor['cli'])==actor['cliSha256']
trace_path=REPO/prompt['trace']
trace=[json.loads(line) for line in trace_path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
end=trace[-1]
assert end['event']=='session-end',end
assert end['hostExitCode'] is not None and end['runtimeExitCode'] is not None,end
destination=HERE/'snapshots'/f'{args.actor}-stage{args.stage}'
assert not destination.exists(),destination
shutil.copytree(REPO/actor['project'],destination,ignore=shutil.ignore_patterns('bin','obj','WRITE.lock','__pycache__'))
pins=[{'path':p.relative_to(destination).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(destination.rglob('*')) if p.is_file()]
normal=end['terminationKind']=='host-close' and end['hostExitCode']==0 and end['runtimeExitCode']==0
record={'actor':args.actor,'arm':actor['arm'],'stage':args.stage,'project':str(destination.relative_to(REPO)),'terminal':end,'normalBrokerFinalization':normal,'terminalPolicy':'Failed terminal candidates may be captured for evidence; finalization assessed separately. Live candidates cannot be captured.','traceSha256':sha(trace_path),'promptSha256':prompt['sha256'],'cliSha256':actor['cliSha256'],'candidatePins':pins,'behaviorScored':False,'preservationReviewed':False}
(HERE/f'capture-{args.actor}-stage{args.stage}.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'actor':args.actor,'stage':args.stage,'snapshot':str(destination),'terminal':end}))

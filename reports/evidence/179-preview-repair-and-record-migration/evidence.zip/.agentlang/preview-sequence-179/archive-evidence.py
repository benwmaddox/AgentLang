"""Create a deterministic, integrity-checked evidence archive for study 179.

Run only after study 179 results are complete. The archive contains the study
tree (minus build/cache/credential material), its tracked study README, and the
external scorer/model sources pinned by the study's scoring scripts.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DEST = REPO / "reports/evidence/179-preview-repair-and-record-migration"
ARCHIVE = DEST / "evidence.zip"
INDEX = DEST / "archive.json"

STUDY_README = Path("experiments/AgentLang.SubagentTrials/preview-sequence-179/README.md")
PINNED_SOURCES = (
    # The 178 scorer builds its frozen 37 cases from the 161 model and cases.
    Path("experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py"),
    Path("experiments/AgentLang.SubagentTrials/preview-repair-178/cases.json"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/cases.json"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py"),
    # Flow and F# adapters directly loaded by score.py and phase2 scripts.
    Path(".agentlang/preview-retention-171/drafts/score_adapter.py"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/score_conventional.py"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/Scorer.fs"),
    Path("experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/Handoff.fs"),
    # The F# qualification script compares against this coordinator-prepared foundation.
    Path(".agentlang/efficacy-maintenance-178/conventional-preparation/Reference/Business.fs"),
    Path("experiments/AgentLang.Business/Business.fs"),
    Path("experiments/AgentLang.Business/AgentLang.Business.fsproj"),
)

EXCLUDED_COMPONENTS = {
    "build",
    "bin",
    "obj",
    "temp",
    "temp-owned",
    "tmp",
    "dotnet-home",
    "dotnet-cli-home",
    "nuget-packages",
    ".nuget",
    "nuget",
    "packages",
    "cache",
    "caches",
    ".cache",
    ".git",
    "__pycache__",
}
EXCLUDED_SUFFIXES = {".dll", ".exe", ".pdb", ".zip"}
EXCLUDED_SECRET_NAMES = {
    "credentials",
    "credentials.json",
    "token",
    "token.json",
    "access_token",
    "refresh_token",
    "secrets",
    "secrets.json",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def relative_name(path: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(REPO.resolve()).as_posix()
    except ValueError as error:
        raise ValueError(f"Archive input escapes the repository: {path}") from error


def is_included(path: Path) -> bool:
    """Filter by name before reading bytes; never follow links or inspect secrets."""
    if path.is_symlink() or not path.is_file():
        return False

    relative = path.relative_to(REPO)
    parts = tuple(part.casefold() for part in relative.parts)
    if any(part in EXCLUDED_COMPONENTS or part.startswith(".dotnet") for part in parts):
        return False

    name = path.name.casefold()
    if name == "write.lock" or name in EXCLUDED_SECRET_NAMES or name.startswith(".env"):
        return False
    if path.suffix.casefold() in EXCLUDED_SUFFIXES:
        return False
    if path.suffix.casefold() in {".pem", ".key", ".p12", ".pfx"}:
        return False
    return True


def source_revision() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=REPO, text=True, encoding="utf-8"
    ).strip()


def archive_evidence() -> dict:
    DEST.mkdir(parents=True, exist_ok=True)
    if ARCHIVE.exists() or INDEX.exists():
        raise FileExistsError(f"Refusing to overwrite final evidence outputs in {DEST}")

    inputs: dict[str, Path] = {}
    for path in ROOT.rglob("*"):
        if is_included(path):
            inputs[relative_name(path)] = path

    for relative in (STUDY_README, *PINNED_SOURCES):
        path = REPO / relative
        if not path.is_file():
            raise FileNotFoundError(f"Required study evidence source is missing: {relative}")
        if not is_included(path):
            raise RuntimeError(f"Required study evidence source is excluded: {relative}")
        inputs[relative.as_posix()] = path

    # Read each selected repository file once. Only paths inside the repository
    # are eligible, and the filter above removes build products, caches, and
    # credential-shaped files before this read.
    content = {name: path.read_bytes() for name, path in sorted(inputs.items())}
    entries = [
        {"path": name, "bytes": len(data), "sha256": sha256(data)}
        for name, data in content.items()
    ]
    revision = source_revision()
    archive_created = False
    try:
        with zipfile.ZipFile(
            ARCHIVE,
            mode="x",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as output:
            archive_created = True
            for name, data in content.items():
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.extra = b""
                info.comment = b""
                output.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

        with zipfile.ZipFile(ARCHIVE, mode="r") as check:
            if check.testzip() is not None:
                raise RuntimeError("ZIP CRC validation failed")
            if check.namelist() != list(content):
                raise RuntimeError("ZIP entries differ from the sorted evidence inventory")
            for row in entries:
                data = check.read(row["path"])
                if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                    raise RuntimeError(f"Extracted entry verification failed: {row['path']}")

        pin_index = [
            {"path": relative.as_posix(), "bytes": len(content[relative.as_posix()]),
             "sha256": sha256(content[relative.as_posix()])}
            for relative in PINNED_SOURCES
        ]
        index = {
            "schemaVersion": 1,
            "sourceRevision": revision,
            "archive": ARCHIVE.name,
            "bytes": ARCHIVE.stat().st_size,
            "sha256": sha256(ARCHIVE.read_bytes()),
            "entryCount": len(entries),
            "entries": entries,
            "pinnedSources": pin_index,
            "verification": {
                "zipCrc": "passed",
                "extractedEntryHashes": "passed",
                "zipTimestamp": "fixed to 1980-01-01 UTC for reproducible entries",
            },
            "exclusions": {
                "pathComponents": sorted(EXCLUDED_COMPONENTS),
                "dotnetComponentsPrefix": ".dotnet",
                "fileNames": ["WRITE.lock", "credential/token/secret names", ".env*"],
                "suffixes": sorted(EXCLUDED_SUFFIXES | {".pem", ".key", ".p12", ".pfx"}),
            },
        }
        with INDEX.open("x", encoding="utf-8", newline="\n") as output:
            output.write(json.dumps(index, indent=2, ensure_ascii=False) + "\n")
        return {"entries": len(entries), "bytes": index["bytes"], "sha256": index["sha256"]}
    except Exception:
        if archive_created and ARCHIVE.exists() and not INDEX.exists():
            ARCHIVE.unlink()
        raise


if __name__ == "__main__":
    print(json.dumps(archive_evidence(), sort_keys=True))

"""Preservation evidence. Changed permitted assertions require human source review."""
import argparse
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(project):
    store=project/'.agentlang/store'
    current=json.loads((store/'CURRENT').read_text())
    return json.loads((store/'manifests'/f"{current['manifestHash']}.json").read_text()),store
def active(m):
    return {w['currentName']:next(r for r in m['revisions'] if r['wordId']==w['wordId'] and r['revision']==w['currentRevision']) for w in m['words']}
def source(store,ref):
    p=store/'objects'/f"{ref['hash']}.agent"
    assert sha(p)==ref['hash'],p
    return p.read_text(encoding='utf-8-sig')
def tests(store,rev):
    result={}
    for ref in rev['tests']:
        text=source(store,ref)
        name=re.search(r'\btest\s+[^\s{]+/([^\s{]+)',text).group(1)
        result[name]=(ref,text)
    return result
def flow(before,after,stage):
    b,bs=manifest(before);a,ats=manifest(after)
    bw=active(b);aw=active(a)
    issues=[];review=[]
    target='subscription.preview-replacement'
    for name,old in bw.items():
        new=aw.get(name)
        if new is None:
            issues.append(f'missing word {name}');continue
        if name!=target:
            for key in ('wordId','name','definition','tests','examples','maturity','sourceFormat','deprecated','callBindings'):
                if old.get(key)!=new.get(key):issues.append(f'unrelated word changed {name}:{key}')
        else:
            for key in ('wordId','name','examples','maturity','deprecated'):
                if old.get(key)!=new.get(key):issues.append(f'target identity/metadata changed:{key}')
            ot=tests(bs,old);nt=tests(ats,new)
            for case,(ref,text) in ot.items():
                if case not in nt:issues.append(f'missing target case {case}');continue
                newref,newtext=nt[case]
                if ref==newref:continue
                if stage==1 and case!='zero-period-no-op':issues.append(f'inherited test changed {case}')
                elif stage==2:
                    normalized=newtext.replace('Result<ReplacementPreview, BusinessError>','Result<Store, BusinessError>').replace('Result<ReplacementPreview,BusinessError>','Result<Store,BusinessError>').replace('result.error<ReplacementPreview, BusinessError>','result.error<Store, BusinessError>').replace('result.error<ReplacementPreview,BusinessError>','result.error<Store,BusinessError>')
                    if normalized!=text:review.append({'case':case,'before':text,'after':newtext})
                else:review.append({'case':case,'before':text,'after':newtext})
    at={t['name']:t for t in a['types']}
    for t in b['types']:
        if at.get(t['name'])!=t:issues.append(f'inherited type changed {t["name"]}')
    addedtypes=sorted(set(at)-{t['name'] for t in b['types']})
    if stage==1 and addedtypes:issues.append('unrequested added types')
    if stage==2 and addedtypes!=['ReplacementPreview']:issues.append(f'expected exact added type, got {addedtypes}')
    return {'automaticIssues':issues,'permittedChangesNeedingSourceReview':review,'newWords':sorted(set(aw)-set(bw)),'newTypes':addedtypes,'targetBefore':bw[target]['definition'],'targetAfter':aw[target]['definition'],'sourceReviewRequired':True}
def fsharp(before,after,stage):
    ignored={'bin','obj','temp','dotnet-home','.git'}
    files=lambda p:{f.relative_to(p).as_posix():f for f in p.rglob('*') if f.is_file() and not(set(f.relative_to(p).parts)&ignored)}
    bf=files(before);af=files(after)
    issues=[]
    for name,path in bf.items():
        if name not in af:issues.append(f'missing file {name}')
        elif name not in ('Operations.fs','SelfTests.fs') and sha(path)!=sha(af[name]):issues.append(f'frozen file changed {name}')
    for name in set(af)-set(bf):issues.append(f'unrequested file added {name}')
    changed={name:{'before':bf[name].read_text(encoding='utf-8-sig'),'after':af[name].read_text(encoding='utf-8-sig')} for name in ('Operations.fs','SelfTests.fs')}
    return {'automaticIssues':issues,'sourceReviewRequired':True,'allowedFilesForAssertionAndSignatureReview':changed}
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--arm',choices=['retained','reset','fsharp'],required=True);parser.add_argument('--before',type=Path,required=True);parser.add_argument('--after',type=Path,required=True);parser.add_argument('--stage',type=int,choices=[1,2],required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists(),args.output
    result=(fsharp if args.arm=='fsharp' else flow)(args.before,args.after,args.stage)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'automaticIssues':result['automaticIssues'],'sourceReviewRequired':True}))

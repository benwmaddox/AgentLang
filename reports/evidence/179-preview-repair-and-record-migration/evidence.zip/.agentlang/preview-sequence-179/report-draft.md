# 179 — Preview repair and record migration sequence

**Status: partial snapshot, 2026-10-10.** Six of 12 planned participant-stage outcomes have complete saved
scores and reviews. Six other stage outcomes are pending. This draft makes no comparative efficacy claim.

Study question: can participants repair the preview defect, then migrate its success result to explicit
original/proposed state while preserving tests and unrelated state, compared with the F# workflow reference?

## Design and task

Six fresh external Luna/max participants were assigned two each to retained AgentLang, reset-rich AgentLang,
and conventional F#. Each participant keeps the same project and conversation across two stages. Dispatch
order was frozen as retained-1, reset-1, F#-1, F#-2, reset-2, retained-2. The retained/reset contrast covers
the whole checkpoint-171 project package, including tests, history and documentation. F# is a workflow
reference seeded from a coordinator-prepared checkpoint-178 handoff/preview project derived from report 166;
its provenance and suites differ. This is not a matched language-only comparison.
[Protocol](../../experiments/AgentLang.SubagentTrials/preview-sequence-179/README.md), [frozen actor/prompt
inventory](actors.json)

Stage one repairs the zero-duration replacement shortcut: preview must validate cancellation before
replacement creation and return the complete unchanged input Store on success. The one deliberately
incorrect `zero-period-no-op` expectation may be corrected; unrelated inherited evidence must remain intact.
Stage two changes success to a `ReplacementPreview` with exactly `original` and `proposed` Store fields
(`Original` and `Proposed` in F#). The original is the unchanged input; proposed is the complete validated
cancellation/replacement state. Existing errors, precedence and unrelated definitions remain in scope for
preservation review. [Frozen tasks and acceptance
rules](../../experiments/AgentLang.SubagentTrials/preview-sequence-179/README.md)

Independent behavioral scoring uses the same 37 pinned checkpoint-178 cases. Stage one checks the complete
original-Store result and error codes; stage two scores both projections independently. All recorded scores
have zero setup failures. The corpus has 30 common valid-reference cases and seven orphan-reference
robustness cases; it reuses 33 historical fixtures and adds four zero-duration combinations. It is not an
entirely unseen corpus, and error message text is not exhaustively scored. [Case and protocol
definition](../../experiments/AgentLang.SubagentTrials/preview-sequence-179/README.md), [checkpoint
178](../../reports/178-preview-defect-control-calibration.md)

## Calibration and controls

Before participant dispatch, the checkpoint-178 calibration passed all three correct-language controls at
37/37; the injected zero-duration shortcut scored 29/37 in each language, with the same eight mismatches. It
also showed why saved test/library coverage cannot stand in for independent acceptance: inherited tests
rejected the faulty branch, but a deliberately wrong assertion could make that branch pass the language
gate. This was a coordinator control, not an agent outcome. [Report
178](../../reports/178-preview-defect-control-calibration.md)

The stage-two shape calibration passed all four Flow projections (retained and reset, original and proposed)
at 37/37, and the F# correct control passed both fields at 37/37. The negative swapped-field control and
proposed-equals-original control each scored 27/37 (10 mismatches), as required. The successful scored
controls used the same frozen 37-case file. The gate was marked passed while `participantsDispatched` was
false; the freeze review separately recorded six actors, 12 checked prompts, matching seed/runtime/source
pins, and three broker smoke profiles. [Calibration summary](phase2/evidence/calibration-summary.json),
[gate](gate.json), [freeze review](freeze-review.json)

Failed preparation/scoring attempts were retained, not counted as participant outcomes: initial Flow
retained preparation rejected generic Result typing; initial reset preparation failed library coverage
because a nested match exposed an unexercisable `Ok` branch; the first disposable F# scorer build omitted
the handoff dependency; and a combined Flow score hit the Windows path-length limit on its final negative
projection, which was rerun under a shorter evidence path. The corrected runs passed and raw attempts were
not overwritten. [Calibration attempt ledger](phase2/evidence/calibration-summary.json)

## Participant results saved so far

Each stage-one cell is one 37-case score. Each stage-two cell lists the separate 37-case original and
proposed projection scores.

| Participant | Stage one behavior | Stage two behavior |
| --- | --- | --- |
| retained-1 | 37/37; zero setup failures ([score](oracle/a1s1.json)) | original 37/37; proposed 37/37; zero setup failures ([score](oracle/a1s2.json)) |
| retained-2 | pending | pending |
| reset-1 | 37/37; zero setup failures ([score](oracle/a2s1.json)) | original 37/37; proposed 37/37; zero setup failures ([score](oracle/a2s2.json)) |
| reset-2 | pending | pending |
| F#-1 | 37/37; zero setup failures ([score](oracle/a3s1.json)) | original 37/37; proposed 37/37; zero setup failures ([score](oracle/a3s2.json)) |
| F#-2 | pending | pending |

The six result notes and six oracle records cover retained-1, reset-1 and F#-1 at both stages. The six
remaining actor-stage cells have no saved result. For the two completed AgentLang sequences, task commit and
normal terminal exit are recorded separately from their scores and preservation review. No participant
feedback about independent scores or preservation findings was supplied between stages. [Result
notes](result-retained-1-stage1.md), [stage two](result-retained-1-stage2.md), [reset stage
one](result-reset-1-stage1.md), [reset stage two](result-reset-1-stage2.md), [F# stage
one](result-fsharp-1-stage1.md), [F# stage two](result-fsharp-1-stage2.md); [machine scores](oracle/)

The three completed sequences used 52 broker exchanges for retained-1 (22 + 30), 51 for reset-1 (19 + 32),
and 23 for F#-1 (14 + 9). These are protocol counts; full-study exchange/byte aggregation awaits the
remaining stages.

## Separate evidence endpoints

Saved suite totals and the behavioral oracle are different measures. The result notes report retained-1
target/project totals of 4/4 and 146/146 at stage one, then 5/5 and 147/147 at stage two. Reset-1 reports
5/5 and 142/142, then 6/6 and 143/143. F#-1's stage-one participant validation exited successfully, but its
note gives no comparable suite count. Do not convert these test totals or 37/37 behavioral scores into a
cross-arm library-qualification rate. The saved notes do not uniformly state a standalone qualification
decision for every arm; reconcile that endpoint from the final qualification evidence before completing the
report. F# does not use the AgentLang library gate.

Preservation was reviewed separately from scores and suite totals. Retained-1's stage-one change is limited
to the wrong zero-period expectation; its stage-two success assertion compares `original` with the same
expected Store, and its new test checks the complete proposed Store with unrelated state intact. Reset-1
also changes only the stage-one zero-period assertion, but it accepts any error rather than checking the
exact expiry code; the independent oracle checks the expected code and precedence. Its stage-two error
assertions and repaired zero-duration case remain intact, with a complete proposed-state assertion. F#-1's
stage-one source review found only the equality-shortcut removal and an exact expiry-error assertion, with
other files and assertions preserved. Its stage-two review reports a two-field record, unchanged inputs,
forwarded errors, the original success assertion adapted to `.Original`, and a full proposed-state
assertion; the proposed test compares against the existing handoff, so the independent oracle remains the
separate check against expected state. The retained-1 stage-one launch allowlist was shortened to a subset
of allowed operations; the participant disclosed rejected queries and a rejected revision before a
successful retry. Preserve this as a workflow deviation. Later saved stages report no departure. [Per-stage
reviews](result-retained-1-stage1.md), [retained stage two](result-retained-1-stage2.md), [reset stage
one](result-reset-1-stage1.md), [reset stage two](result-reset-1-stage2.md), [F# stage
one](result-fsharp-1-stage1.md)

## Provenance, limits and safety boundary

An independent review found the first scorer lacked mandatory snapshot-to-capture linkage. The amendment
added snapshot/capture equality plus capture/trace hashes; it did not change the semantic oracle or public
prompts, and retained the first stage score and trace. A scoped guard re-review found no material issue.
Treat hash audits as supporting evidence: source-level review still determines whether an adapted assertion
kept its meaning. [Amendment](integration-amendment.json), [guard review](guard-review.json)

These six participants form two fixed-order sequences per condition, which do not estimate population
reliability. The retained/reset condition also changes the whole project package; F# has unequal seed
provenance and suites. Results cannot establish a causal language advantage. Provider token counts and
effective context limits are unavailable; exchange and byte counts describe protocol volume. [Study
protocol](../../experiments/AgentLang.SubagentTrials/preview-sequence-179/README.md), [report
177](../../reports/177-reliability-and-vocabulary-checkpoint.md)

Trials use isolated local projects and the existing restricted JSONL broker, with virtual effects and no
application network/mail effects. No product API, native ABI, allocator or effect capability is changed.
This is not a cybersecurity certification; AI agents are external developers of the language.

### To complete after remaining results

Replace pending cells only from saved score and review artifacts; reconcile library qualification,
preservation, permitted test adaptation and finalization for every participant-stage independently. Recheck
the counts and limits above before removing this draft status. Do not add an efficacy claim unless the full
predeclared sequence supports it.

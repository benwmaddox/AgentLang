# fsharp-2 stage 1 review

Independent original-state score 37/37, zero setup failures; fresh scorer build/run exit 0 and unchanged candidate. Broker normal host/runtime exit 0 after 18 exchanges; participant validation exit 0.

Source diff: only removes early equality shortcut in preview; same six inputs and Store result, handoff errors forwarded unchanged. Only the deliberately wrong zero-period assertion is replaced, requiring exact SubscriptionExpiryMustFollowStart. Other files/functions/assertions unchanged. One malformed 65-character SHA patch request rejected; participant reread authoritative file and corrected the hash. No shell/protocol scope departure reported. Scores withheld between stages.

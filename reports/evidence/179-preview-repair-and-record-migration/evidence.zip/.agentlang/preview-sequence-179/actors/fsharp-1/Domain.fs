namespace AgentLang.SubscriptionHandoff

open System

type Instant = DateTimeOffset
type CustomerId = AgentLang.Business.Domain.CustomerId
type ProductId = AgentLang.Business.Domain.ProductId
type SubscriptionId = AgentLang.Business.Domain.SubscriptionId
type Store = AgentLang.Business.Domain.Store
type SubscriptionRecord = AgentLang.Business.Domain.Subscription
type DomainError = AgentLang.Business.Domain.DomainError

module Store =
    let empty: Store = AgentLang.Business.Domain.Store.empty
    let summary = AgentLang.Business.Domain.Store.summary
    let customer = AgentLang.Business.Domain.Store.customer
    let product = AgentLang.Business.Domain.Store.product
    let subscription = AgentLang.Business.Domain.Store.subscription
    let addCustomer = AgentLang.Business.Domain.Store.addCustomer
    let addProduct = AgentLang.Business.Domain.Store.addProduct

namespace AgentLang.SubscriptionHandoff

open System

module Program =
    [<EntryPoint>]
    let main _ =
        try
            SelfTests.run ()
            SelfTests.runPreviewBasics ()
            SelfTests.runZeroPeriodControl ()
            0
        with error ->
            Console.Error.WriteLine(error.Message)
            1

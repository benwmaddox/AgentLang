namespace AgentLang.SubscriptionHandoff.Control

open System

module ParticipantProgram =
    [<EntryPoint>]
    let main args =
        try
            if args.Length <> 2 then failwith "Expected field and case file"
            let field = args.[0]
            if field <> "original" && field <> "proposed" then failwith "Unknown field"
            let choose store oldId replacementId term at expiry _dryRun =
                Subscription.previewReplacement store oldId replacementId term at expiry
                |> Result.map (fun preview -> if field = "original" then preview.Original else preview.Proposed)
            Scorer.runFileWith choose (field = "original") args.[1]
            0
        with error ->
            Console.Error.WriteLine(error.ToString())
            2

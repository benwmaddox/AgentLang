"""Score only the required Flow result fields against the frozen 37 cases."""
from __future__ import annotations

from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PHASE2 = HERE.parent
REPO = PHASE2.parents[2]
EVIDENCE = PHASE2 / "evidence" / "flow-score"
PREVIEW = REPO / "experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py"
OLD_ADAPTER = REPO / ".agentlang/preview-retention-171/drafts/score_adapter.py"
CONTROLS = {
    "flow-retained-correct": (PHASE2 / "controls/flow-retained-correct", ("original", "proposed")),
    "flow-reset-correct": (PHASE2 / "controls/flow-reset-correct-retry1", ("original", "proposed")),
    "flow-retained-swapped": (PHASE2 / "controls/flow-retained-swapped", ("original",)),
    "flow-reset-proposed-original": (PHASE2 / "controls/flow-reset-proposed-original", ("proposed",)),
}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", help="Optional exact control:field pair for a required follow-up projection")
    parser.add_argument("--evidence-root", type=Path, default=EVIDENCE)
    args = parser.parse_args()
    evidence_root = args.evidence_root if args.evidence_root.is_absolute() else (REPO / args.evidence_root).resolve()
    evidence_root.mkdir(parents=True, exist_ok=True)
    selected = CONTROLS
    if args.only:
        if ":" not in args.only:
            parser.error("--only must be CONTROL:field")
        control_name, requested_field = args.only.split(":", 1)
        if control_name not in CONTROLS or requested_field not in CONTROLS[control_name][1]:
            parser.error("--only must select an available control field")
        project, _ = CONTROLS[control_name]
        selected = {control_name: (project, (requested_field,))}
    preview = load_module("phase2_preview_178", PREVIEW)
    rows = preview.cases()
    if len(rows) != 37:
        raise ValueError(f"Expected 37 frozen acceptance cases, got {len(rows)}")
    adapter = load_module("phase2_preview_retention_adapter", OLD_ADAPTER)
    adapter.EVIDENCE_ROOT = evidence_root
    adapter.load_cases = lambda: deepcopy(rows)
    outcomes = []
    for name, (project, fields) in selected.items():
        if not project.is_dir():
            raise FileNotFoundError(project)
        for field in fields:
            # Replace the old Store result observation with a projection of one
            # actual field from the result record; errors pass through unchanged.
            adapter.OBSERVER_SOURCE = r'''// frontend: flow/2

record PreviewReplacementScoringObservation {
    field input: Store
    field outcome: Result<Store, BusinessError>
}

fn preview-retention.scoring-observe(input: Store, old-id: SubscriptionId, replacement-id: SubscriptionId, term: String, handoff-at: Instant, expires-at: Instant) -> PreviewReplacementScoringObservation {
    match subscription.preview-replacement(input, old-id, replacement-id, term, handoff-at, expires-at) {
        ok preview => previewReplacementScoringObservation.new(input = input, outcome = result.ok<Store, BusinessError>(preview.FIELD))
        error failure => previewReplacementScoringObservation.new(input = input, outcome = result.error<Store, BusinessError>(failure))
    }
}
'''.replace("preview.FIELD", f"preview.{field}")

            def expected_projection(item: dict, selected=field) -> dict:
                model = item["expected"]
                expected_input = adapter.OLD.normalized_projection({"store": item["store"]})
                if model["tag"] == "error":
                    return {"tag": "error", "code": model["code"], "input": expected_input}
                source_store = item["store"] if selected == "original" else model["store"]
                return {"tag": "ok", "store": adapter.OLD.normalized_projection({"store": source_store}),
                        "input": expected_input}

            adapter.expected_projection = expected_projection
            label = ("rpo-proposed" if name == "flow-reset-proposed-original" and field == "proposed"
                     else f"{name}-{field}")
            report = adapter.score_actor(project, REPO / ".agentlang/efficacy-maintenance-178/build/bin/AgentLang.Cli/release/AgentLang.Cli.dll",
                                         "control", label)
            report["field"] = field
            report["controlSourceSha256"] = sha(project / "dictionary.agent")
            report["caseSourceSha256"] = sha(REPO / "experiments/AgentLang.SubagentTrials/preview-repair-178/cases.json")
            report["scoreScriptSha256"] = sha(Path(__file__))
            report["adapterSha256"] = sha(OLD_ADAPTER)
            report["caseCount"] = len(rows)
            report["executedCaseCount"] = report.get("executedCaseCount", 0)
            negative = "swapped" in name or "proposed-original" in name
            report["controlExpected"] = "behavioral-mismatch" if negative else "passed"
            report["controlExpectationMet"] = (
                report.get("executedCaseCount") == 37 and report.get("setupErrorCount") == 0
                and (bool(report.get("failingCaseIds")) if negative else report.get("status") == "passed")
            )
            outcomes.append(report)
            if not report["controlExpectationMet"]:
                raise RuntimeError(f"Flow field score failed its calibration expectation: {label}; inspect {report}")
    summary = {"caseCount": len(rows), "controls": outcomes,
               "allExpectationsMet": all(row["controlExpectationMet"] for row in outcomes)}
    out = evidence_root / "summary.json"
    if out.exists():
        out = evidence_root / f"summary-{len(outcomes)}-fields.json"
    out.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps([{"label": row["label"], "field": row["field"], "status": row["status"],
                       "executedCaseCount": row["executedCaseCount"], "passedCaseCount": row["passedCaseCount"],
                       "failingCaseIds": row["failingCaseIds"], "setupErrorCount": row["setupErrorCount"]}
                      for row in outcomes], indent=2))


if __name__ == "__main__":
    main()

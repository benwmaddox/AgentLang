"""Build a disposable F# wrapper and score Original/Proposed on all 37 cases."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PHASE2 = HERE.parent
REPO = PHASE2.parents[2]
SOURCE = PHASE2 / "controls/fsharp-correct/source"
SEED = REPO / ".agentlang/efficacy-maintenance-178/conventional-preparation"
PREVIEW = REPO / "experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py"
SCORER = REPO / "experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/Scorer.fs"
HANDOFF = REPO / "experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/Handoff.fs"
ADAPTER_PATH = REPO / "experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/conventional/score_conventional.py"
PROJECT_TEXT = """<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net9.0</TargetFramework>
    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
    <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="Domain.fs" />
    <Compile Include="Operations.fs" />
    <Compile Include="Handoff.fs" />
    <Compile Include="Scorer.fs" />
    <Compile Include="ParticipantProgram.fs" />
  </ItemGroup>
  <ItemGroup>
    <Reference Include="AgentLang.Business">
      <HintPath>lib\\AgentLang.Business.dll</HintPath>
      <Private>true</Private>
    </Reference>
  </ItemGroup>
</Project>
"""
RUNNER_TEXT = """namespace AgentLang.SubscriptionHandoff.Control

open System
open AgentLang.SubscriptionHandoff

module ParticipantProgram =
    [<EntryPoint>]
    let main args =
        try
            if args.Length <> 2 then failwith "Expected field and case file"
            let field = args.[0]
            if field <> "original" && field <> "proposed" then failwith "Unknown field"
            let choose store oldId replacementId term at expiry _dryRun =
                Subscription.previewReplacement store oldId replacementId term at expiry
                |> Result.map (fun preview -> if field = "original" then preview.Original else preview.Proposed)
            Scorer.runFileWith choose (field = "original") args.[1]
            0
        with error ->
            Console.Error.WriteLine(error.ToString())
            2
"""


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    preview = load_module("phase2_preview_for_fsharp", PREVIEW)
    adapter = load_module("phase2_conventional_scorer", ADAPTER_PATH)
    rows = preview.cases()
    if len(rows) != 37:
        raise ValueError(f"Expected 37 fixtures, got {len(rows)}")
    root = PHASE2 / "evidence" / "fsharp-score"
    run = adapter.next_run_directory(root)
    project = run / "project"
    project.mkdir()
    (project / "lib").mkdir()
    shutil.copy2(SOURCE / "Domain.fs", project / "Domain.fs")
    shutil.copy2(SOURCE / "Operations.fs", project / "Operations.fs")
    shutil.copy2(HANDOFF, project / "Handoff.fs")
    shutil.copy2(SCORER, project / "Scorer.fs")
    shutil.copy2(SOURCE / "lib/AgentLang.Business.dll", project / "lib/AgentLang.Business.dll")
    (project / "ParticipantProgram.fs").write_text(RUNNER_TEXT, encoding="utf-8", newline="\n")
    (project / "ParticipantControl.fsproj").write_text(PROJECT_TEXT, encoding="utf-8", newline="\n")
    cases_path = run / "cases.json"
    write_json(cases_path, rows)
    temp = run / "temp-owned"
    temp.mkdir()
    environment = os.environ.copy()
    environment.update({"TEMP": str(temp), "TMP": str(temp), "DOTNET_CLI_HOME": str(temp),
                        "DOTNET_NOLOGO": "1", "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1"})
    build_command = ["dotnet", "build", str(project / "ParticipantControl.fsproj"), "--configuration", "Release",
                     "--verbosity", "minimal", "-m:1", "-p:NuGetAudit=false", "-p:RestoreIgnoreFailedSources=true"]
    build = subprocess.run(build_command, cwd=REPO, env=environment, capture_output=True,
                           text=True, encoding="utf-8", errors="replace", timeout=600)
    (run / "build.stdout.txt").write_text(build.stdout, encoding="utf-8")
    (run / "build.stderr.txt").write_text(build.stderr, encoding="utf-8")
    dll = project / "bin/Release/net9.0/ParticipantControl.dll"
    manifest = {
        "participantSource": str(SOURCE.relative_to(REPO)),
        "participantOperationsSha256": sha(SOURCE / "Operations.fs"),
        "baselineOperationsSha256": sha(SEED / "Operations.fs"),
        "domainSha256": sha(SOURCE / "Domain.fs"),
        "businessDllSha256": sha(SOURCE / "lib/AgentLang.Business.dll"),
        "businessDllBaselineSha256": sha(SEED / "lib/AgentLang.Business.dll"),
        "scorerSource": str(SCORER.relative_to(REPO)),
        "scorerSha256": sha(SCORER),
        "scorerAdapterSha256": sha(ADAPTER_PATH),
        "scoreScriptSha256": sha(Path(__file__)),
        "caseSource": str(PREVIEW.relative_to(REPO)),
        "caseSourceSha256": sha(PREVIEW),
        "caseCount": len(rows),
        "caseIds": [row["id"] for row in rows],
        "fixturePopulations": adapter.fixture_populations(rows),
        "project": str(project.relative_to(REPO)),
        "projectFileSha256": sha(project / "ParticipantControl.fsproj"),
        "runnerSha256": sha(project / "ParticipantProgram.fs"),
        "selfTestsIncluded": False,
        "compileInputs": {name: sha(project / name) for name in ("Domain.fs", "Operations.fs", "Handoff.fs", "Scorer.fs", "ParticipantProgram.fs")},
        "copiedBusinessSourcesMatchSaved": (
            sha(project / "Operations.fs") == sha(SOURCE / "Operations.fs")
            and sha(project / "Domain.fs") == sha(SOURCE / "Domain.fs")
        ),
        "copiedOperationsSha256": sha(project / "Operations.fs"),
        "copiedDomainSha256": sha(project / "Domain.fs"),
        "buildCommand": build_command,
        "buildExitCode": build.returncode,
        "tempRoot": str(temp.relative_to(REPO)),
        "fieldScores": {},
    }
    if build.returncode != 0:
        manifest["setupFailure"] = "Fresh disposable scorer build failed"
    else:
        for field, dry_run in (("original", True), ("proposed", False)):
            label = f"fsharp-{field}"
            command = ["dotnet", str(dll), field, str(cases_path)]
            process = subprocess.run(command, cwd=project, env=environment, capture_output=True,
                                     text=True, encoding="utf-8", errors="replace", timeout=600)
            report = adapter.score_rows(label, rows, process, dry_run, run, command)
            emitted, parse_error = adapter.parse_rows(process.stdout)
            expected_ids = [row["id"] for row in rows]
            actual_ids = [row.get("id") for row in emitted]
            ordered = not parse_error and actual_ids == expected_ids
            report["selectedField"] = field
            report["sourceFunction"] = "AgentLang.SubscriptionHandoff.Subscription.previewReplacement"
            report["dryRunExpectedProjection"] = dry_run
            report["emittedCaseIdsMatchFrozenOrder"] = ordered
            report["emittedCaseCount"] = len(emitted)
            report["idParseError"] = parse_error
            if not ordered:
                report["status"] = "setup-failure"
                report["setupFailure"] = "Scorer output IDs did not match all 37 frozen IDs in order"
            manifest["fieldScores"][field] = report
    summary_path = run / "result.json"
    write_json(summary_path, manifest)
    print(json.dumps({"status": "setup-failure" if build.returncode else
                      "pass" if all(row["status"] == "pass" and row["passedCaseCount"] == 37
                                    and row["executedCaseCount"] == 37 and not row["setupFailureCaseIds"]
                                    and row["emittedCaseIdsMatchFrozenOrder"]
                                    for row in manifest["fieldScores"].values()) else "score-failure",
                      "run": str(run.relative_to(REPO)), "buildExitCode": build.returncode,
                      "fieldScores": {field: {"status": row["status"], "executed": row["executedCaseCount"],
                                               "passed": row["passedCaseCount"], "setupFailure": row["setupFailure"]}
                                      for field, row in manifest["fieldScores"].items()}}, indent=2))
    if build.returncode != 0 or not manifest["copiedBusinessSourcesMatchSaved"] or any(row["status"] != "pass" or row["passedCaseCount"] != 37
                                   or row["executedCaseCount"] != 37 or row["setupFailureCaseIds"]
                                   or not row["emittedCaseIdsMatchFrozenOrder"]
                                   for row in manifest["fieldScores"].values()):
        raise RuntimeError(f"F# score did not calibrate; inspect {summary_path}")


if __name__ == "__main__":
    main()

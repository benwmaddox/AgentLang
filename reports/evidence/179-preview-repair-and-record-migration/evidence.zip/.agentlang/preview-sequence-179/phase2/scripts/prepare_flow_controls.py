"""Prepare and qualify four isolated Flow replacement controls through the CLI."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
PHASE2 = HERE.parent
REPO = PHASE2.parents[2]
CLI = REPO / ".agentlang/efficacy-maintenance-178/build/bin/AgentLang.Cli/release/AgentLang.Cli.dll"
TARGET = "subscription.preview-replacement"
VARIANTS = {
    "flow-retained-correct": ("retained", "correct", "flow-retained-correct"),
    "flow-reset-correct": ("reset", "correct", "flow-reset-correct-retry1"),
    "flow-retained-swapped": ("retained", "swapped", "flow-retained-swapped"),
    "flow-reset-proposed-original": ("reset", "proposed-original", "flow-reset-proposed-original"),
}
TYPE_SOURCE = "record ReplacementPreview {\n    field original: Store\n    field proposed: Store\n}\n"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(project: Path) -> dict:
    store = project / ".agentlang/store"
    current = json.loads((store / "CURRENT").read_text(encoding="utf-8-sig"))
    manifest = json.loads((store / "manifests" / f"{current['manifestHash']}.json").read_text(encoding="utf-8-sig"))
    word = next(row for row in manifest["words"] if row["currentName"] == TARGET)
    revision = next(row for row in manifest["revisions"]
                    if row["wordId"] == word["wordId"] and row["revision"] == word["currentRevision"])
    return {"wordId": word["wordId"], "name": TARGET, "revision": word["currentRevision"],
            "maturity": revision["maturity"], "definitionHash": revision["definition"]["hash"],
            "manifestHash": current["manifestHash"]}


def original_definition(arm: str, project: Path) -> tuple[str, list[dict]]:
    saved = REPO / f".agentlang/efficacy-maintenance-178/reload/{arm}.responses.jsonl"
    responses = [json.loads(line) for line in saved.read_text(encoding="utf-8").splitlines() if line.strip()]
    source = next(row["data"] for row in responses if row.get("kind") == "source")
    cases = next(row["data"] for row in responses if row.get("kind") == "tests")
    if not source.startswith(f"fn {TARGET}("):
        raise ValueError(f"Unexpected saved {arm} source")
    return source, cases


def construct_target(source: str, arm: str, variant: str) -> str:
    signature = "-> Result<Store, BusinessError>"
    replacement_signature = "-> Result<ReplacementPreview, BusinessError>"
    if source.count(signature) != 1:
        raise ValueError("Expected one original Store result signature")
    result = source.replace(signature, replacement_signature, 1)
    if arm == "retained":
        old = "ok _ => result.ok<Store, BusinessError>(store)"
        if result.count(old) != 1:
            raise ValueError("Could not identify the retained success projection")
        result = result.replace(
            old,
            "ok proposed => result.ok<ReplacementPreview, BusinessError>(replacementPreview.new(original = store, proposed = proposed))",
            1,
        )
    else:
        old = "ok replacement-store => result.ok<Store, BusinessError>(store)"
        if result.count(old) != 1:
            raise ValueError("Could not identify the reset success projection")
        result = result.replace(
            old,
            "ok replacement-store => result.ok<ReplacementPreview, BusinessError>(replacementPreview.new(original = store, proposed = replacement-store))",
            1,
        )
        old = "none => .subscription.cancel(store, oldId, handoffAt)"
        new = "none => result.error<ReplacementPreview, BusinessError>(businessError.new(code = \"SUBSCRIPTION_NOT_FOUND\", message = \"The subscription does not exist.\"))"
        if result.count(old) != 1:
            raise ValueError("Could not identify the reset missing-old branch")
        result = result.replace(old, new, 1)

    if variant == "swapped":
        result = result.replace("original = store, proposed = proposed", "original = proposed, proposed = store")
    elif variant == "proposed-original":
        result = result.replace("proposed = replacement-store", "proposed = store")
    result = result.replace("result.error<Store, BusinessError>", "result.error<ReplacementPreview, BusinessError>")
    return result


def adapted_tests(cases: list[dict], variant: str) -> list[str]:
    outputs = []
    for item in cases:
        source = item["source"]
        name = item["name"]
        if name.startswith("success-"):
            if source.count(".equals(returned, store)") == 1:
                field = "proposed" if variant == "swapped" else "original"
                source = source.replace(".equals(returned, store)", f".equals(returned.{field}, store)")
            elif source.count("equals(preview, initial)") == 1:
                field = "proposed" if variant == "swapped" else "original"
                source = source.replace("equals(preview, initial)", f"equals(preview.{field}, initial)")
            else:
                raise ValueError(f"Unknown successful preview assertion: {name}")
        outputs.append(source)
    return outputs


def run_one(name: str, arm: str, variant: str, project_name: str) -> dict:
    project = PHASE2 / "controls" / project_name
    if not project.is_dir():
        raise FileNotFoundError(project)
    evidence = PHASE2 / "evidence" / "flow-prepare-pass2" / name
    evidence.mkdir(parents=True, exist_ok=False)
    temp = evidence / "temp"
    temp.mkdir()
    before = identity(project)
    original, saved_tests = original_definition(arm, project)
    target = construct_target(original, arm, variant)
    tests = adapted_tests(saved_tests, variant)
    request_rows = [
        {"op": "define", "frontend": "flow", "syntaxVersion": 2, "source": TYPE_SOURCE},
        {"op": "define", "frontend": "flow", "syntaxVersion": 2, "replace": True,
         "expectedRevision": before["revision"], "source": target, "tests": tests},
        {"op": "test", "word": TARGET},
        {"op": "replace-word", "word": TARGET, "library": True},
        {"op": "test-all"},
        {"op": "describe", "word": TARGET},
        {"op": "tests", "word": TARGET, "includeSource": True},
    ]
    request_text = "\n".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) for row in request_rows) + "\n"
    (evidence / "source.flow").write_text(target, encoding="utf-8", newline="\n")
    (evidence / "type.flow").write_text(TYPE_SOURCE, encoding="utf-8", newline="\n")
    (evidence / "requests.jsonl").write_text(request_text, encoding="utf-8", newline="\n")
    (evidence / "requests.sha256").write_text(hashlib.sha256(request_text.encode()).hexdigest() + "  requests.jsonl\n", encoding="ascii")
    env = os.environ.copy()
    env["TEMP"] = str(temp.resolve())
    env["TMP"] = str(temp.resolve())
    result = {"control": name, "arm": arm, "variant": variant, "before": before,
              "cli": str(CLI.relative_to(REPO)), "cliSha256": sha(CLI),
              "sourceSha256": hashlib.sha256(target.encode()).hexdigest(),
              "testSourceHashesBefore": {item["name"]: item["sourceHash"] for item in saved_tests},
              "typeSourceSha256": hashlib.sha256(TYPE_SOURCE.encode()).hexdigest(),
              "requestSha256": hashlib.sha256(request_text.encode()).hexdigest()}
    try:
        process = subprocess.run(["dotnet", str(CLI), "--project", str(project), "--filesystem", "virtual", "--jsonl"],
                                 cwd=REPO, input=request_text, capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=300, env=env)
        (evidence / "responses.jsonl").write_text(process.stdout, encoding="utf-8", newline="\n")
        (evidence / "stderr.txt").write_text(process.stderr, encoding="utf-8", newline="\n")
        responses = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
        result["cliExitCode"] = process.returncode
        result["responseCount"] = len(responses)
        result["responsesOk"] = [bool(row.get("ok")) for row in responses]
        result["testSummary"] = responses[2].get("text") if len(responses) > 2 else None
        result["libraryCommit"] = responses[3] if len(responses) > 3 else None
        result["testAllSummary"] = responses[4].get("text") if len(responses) > 4 else None
        result["after"] = identity(project)
        result["wordIdPreserved"] = result["after"]["wordId"] == before["wordId"]
        result["revisionAdvanced"] = result["after"]["revision"] == before["revision"] + 1
        result["qualified"] = (process.returncode == 0 and len(responses) == len(request_rows)
                                and all(row.get("ok") for row in responses)
                                and result["wordIdPreserved"] and result["revisionAdvanced"]
                                and result["after"]["maturity"] == "library")
        if len(responses) == len(request_rows) and responses[-1].get("ok"):
            saved_after = responses[-1].get("data", [])
            result["testNamesAfter"] = sorted(row.get("name") for row in saved_after)
        else:
            result["testNamesAfter"] = []
    except Exception as error:
        result["exception"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        # Evidence and failed attempts are retained; TEMP/TMP remain owned by this run.
        (evidence / "temp-owned.json").write_text(json.dumps({"TEMP": str(temp), "TMP": str(temp)}), encoding="utf-8")
    (evidence / "result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not result.get("qualified"):
        raise RuntimeError(f"Control did not qualify; inspect {evidence}")
    return result


def main() -> None:
    if not CLI.is_file() or sha(CLI) != "f43cac5e162ea1a104e158c279e00ca2cdac8c7fa670ac0b3a825951fdc66006":
        raise RuntimeError("Fresh pinned Flow CLI is missing or its hash changed")
    results = [run_one(name, arm, variant, project_name)
               for name, (arm, variant, project_name) in VARIANTS.items() if name != "flow-retained-correct"]
    aggregate = {"controls": results, "allQualified": all(row["qualified"] for row in results)}
    out = PHASE2 / "evidence" / "flow-prepare-summary.json"
    if out.exists():
        raise FileExistsError(out)
    out.write_text(json.dumps(aggregate, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps([{"control": row["control"], "qualified": row["qualified"],
                       "testSummary": row["testSummary"], "testAllSummary": row["testAllSummary"],
                       "target": row["after"]} for row in results], indent=2))


if __name__ == "__main__":
    main()

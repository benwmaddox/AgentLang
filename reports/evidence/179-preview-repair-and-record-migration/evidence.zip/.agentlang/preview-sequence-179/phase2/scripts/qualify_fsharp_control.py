"""Fresh build and run the isolated F# control's existing self-test program."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
PHASE2 = HERE.parent
REPO = PHASE2.parents[2]
SOURCE = PHASE2 / "controls/fsharp-correct/source"
BASELINE = REPO / ".agentlang/efficacy-maintenance-178/conventional-preparation"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    evidence = PHASE2 / "evidence" / "fsharp-qualify"
    evidence.mkdir(parents=True, exist_ok=False)
    temp = evidence / "temp-owned"
    temp.mkdir()
    project = evidence / "project"
    shutil.copytree(SOURCE, project, ignore=shutil.ignore_patterns("bin", "obj", "temp", "__pycache__"))
    env = os.environ.copy()
    env.update({"TEMP": str(temp), "TMP": str(temp), "DOTNET_CLI_HOME": str(temp),
                "DOTNET_NOLOGO": "1", "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1"})
    relative_files = sorted(path.relative_to(SOURCE).as_posix() for path in SOURCE.rglob("*")
                            if path.is_file() and not any(part in ("bin", "obj") for part in path.relative_to(SOURCE).parts))
    changed = []
    for relative in relative_files:
        source_file = SOURCE / Path(relative)
        baseline_file = BASELINE / Path(relative)
        if not baseline_file.is_file() or sha(source_file) != sha(baseline_file):
            changed.append(relative)
    if set(changed) != {"Operations.fs", "SelfTests.fs"}:
        raise RuntimeError(f"Unexpected F# source edits: {changed}")
    build_command = ["dotnet", "build", str(project / "SubscriptionHandoff.Conventional.fsproj"),
                     "--configuration", "Release", "--verbosity", "minimal", "-m:1",
                     "-p:NuGetAudit=false", "-p:RestoreIgnoreFailedSources=true"]
    build = subprocess.run(build_command, cwd=REPO, env=env, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
    (evidence / "build.stdout.txt").write_text(build.stdout, encoding="utf-8")
    (evidence / "build.stderr.txt").write_text(build.stderr, encoding="utf-8")
    run_command = ["dotnet", str(project / "bin/Release/net9.0/SubscriptionHandoff.Conventional.dll")]
    run = None
    if build.returncode == 0:
        run = subprocess.run(run_command, cwd=REPO, env=env, capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=300)
        (evidence / "tests.stdout.txt").write_text(run.stdout, encoding="utf-8")
        (evidence / "tests.stderr.txt").write_text(run.stderr, encoding="utf-8")
    result = {
        "sourceDirectory": str(SOURCE.relative_to(REPO)),
        "disposableProject": str(project.relative_to(REPO)),
        "changedSourceFiles": changed,
        "operationsSha256": sha(SOURCE / "Operations.fs"),
        "selfTestsSha256": sha(SOURCE / "SelfTests.fs"),
        "programSha256MatchesBaseline": sha(SOURCE / "Program.fs") == sha(BASELINE / "Program.fs"),
        "businessDllSha256": sha(SOURCE / "lib/AgentLang.Business.dll"),
        "businessDllBaselineSha256": sha(BASELINE / "lib/AgentLang.Business.dll"),
        "buildCommand": build_command,
        "buildExitCode": build.returncode,
        "runCommand": run_command,
        "runExitCode": run.returncode if run else None,
        "runStdout": run.stdout if run else None,
        "runStderr": run.stderr if run else None,
        "tempRoot": str(temp.relative_to(REPO)),
        "passed": build.returncode == 0 and run is not None and run.returncode == 0,
    }
    (evidence / "result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("buildExitCode", "runExitCode", "changedSourceFiles",
                                                   "programSha256MatchesBaseline", "passed", "runStdout")}, indent=2))
    if not result["passed"]:
        raise RuntimeError(f"F# target self-test qualification failed; inspect {evidence}")


if __name__ == "__main__":
    main()

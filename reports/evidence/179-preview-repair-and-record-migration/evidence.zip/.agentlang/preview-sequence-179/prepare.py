"""Freeze isolated projects and both stage prompts before participant dispatch."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
flow_cli = REPO / '.agentlang/efficacy-maintenance-178/build/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
conv_cli = HERE / 'build/bin/AgentLang.Conventional.Cli/release/AgentLang.Conventional.Cli.dll'
assert sha(flow_cli) == 'f43cac5e162ea1a104e158c279e00ca2cdac8c7fa670ac0b3a825951fdc66006'
assert conv_cli.exists()
primer = (REPO / '.agentlang/preview-retention-171/primer-future-corrected.md').read_text(encoding='utf-8-sig')
common = '''The human explicitly authorizes edits only to your assigned isolated trial project and local test execution through the supplied broker. You are an external coding agent, not part of the language runtime. Read only your assigned prompt, then launch its broker. Otherwise use only the broker for discovery, edits and tests. Do not read the main repository, other trials, hidden oracles or reports. Do not use web tools, spawn/list/read/contact agents, or run other shell commands. Disclose non-broker tool use. Keep one broker process for this stage, at most 100 exchanges. Poll the same live handle after observation timeouts; do not restart a live broker for silence. Finish with {"op":"host.close"} and observe its terminal status. Two predeclared stages use the same project and same participant; stage two will be assigned after stage one ends, with a new broker and independent 100-exchange allowance. Do not implement stage two until assigned.
'''
stage1 = '''Repair the existing subscription replacement preview. A zero-length replacement (expiry equals handoff time) is incorrectly accepted as a successful no-op. Preview must validate cancellation of the old subscription first, then creation of its replacement, and return the complete original Store on success without changing it. Preserve existing validation order: cancellation failures precede creation failures; creation checks duplicate ID before term and positive duration, then remaining existing creation validations. Keep established error codes and messages.

Correct the deliberately mistaken zero-period-no-op test expectation so it requires an error. Preserve every other inherited assertion, test, example, unrelated definition, target identity/name/input/output signature, and library maturity. Existing wrappers and handoff must retain behavior and signatures. Add tests only where useful; existing adequate assertions need not be duplicated. Run all tests and finalize/publish changes through the ordinary protocol. Explain the repair briefly after closing the broker.
'''
stage2 = '''Change the six-input subscription replacement preview's successful result from Store to a new typed record ReplacementPreview with exactly two Store fields: original and proposed (Original and Proposed in F#). Return Result<ReplacementPreview, BusinessError> in the language, or Result<ReplacementPreview, DomainError> in F#. On success original is the complete unchanged input Store, and proposed is the complete Store obtained by validated cancellation followed by replacement creation. Preserve all existing error forwarding, messages and precedence, including the zero-duration repair.

Keep target identity/name/inputs/library maturity. Preserve handoff, renewal wrappers, unrelated definitions, tests and examples. Adapt existing successful preview assertions only to check the original field against their same expected complete Store. Preserve inherited error assertions and their expected errors; only necessary Result type annotations may change. Retain the corrected zero-duration test. Add a meaningful assertion for the complete proposed Store, including unrelated state. Do not discard assertions, cases or examples to make qualification pass. Run all tests and finalize/publish through the ordinary protocol. Explain the change briefly after closing the broker.
'''
flow_ops = 'help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort'
conv_ops = 'inspect,read,search,patch,replace,validate'
actors = []
order = [('retained-1','retained'), ('reset-1','reset'), ('fsharp-1','fsharp'), ('fsharp-2','fsharp'), ('reset-2','reset'), ('retained-2','retained')]
for index, (name, arm) in enumerate(order, 1):
    seed = REPO / ('.agentlang/efficacy-maintenance-178/conventional' if arm == 'fsharp' else f'.agentlang/efficacy-maintenance-178/controls/faulty-{arm}/project')
    project = HERE / 'actors' / name
    if project.exists():
        raise RuntimeError(f'Refusing reset: {project}')
    shutil.copytree(seed, project, ignore=shutil.ignore_patterns('bin','obj','WRITE.lock','__pycache__'))
    if arm == 'fsharp':
        assert sha(project / 'lib/AgentLang.Business.dll') == '234ced2345d0e1ba482eb86b616099db4c2f558c0dafd9e39cf97a0f3aa9f8b1'
    cli = conv_cli if arm == 'fsharp' else flow_cli
    operations = conv_ops if arm == 'fsharp' else flow_ops
    profile = 'conventional' if arm == 'fsharp' else 'agentlang'
    specifics = ('''Edit only Operations.fs and SelfTests.fs. Other project files are frozen infrastructure readable through the broker. Reference/Business.fs documents the foundation and must not be edited. Preserve all existing function names invoked by Program.fs. The preview wrapper and its basic tests were coordinator-authored. Broker inspect/read/search allow discovery; patch/replace require the current SHA256; validate runs fixed local self-tests. No arbitrary shell command is accepted.
''' if arm == 'fsharp' else '''Use supported dictionary operations. Preserve stable function identity and library maturity; do not edit manifest files directly. Existing words may be inspected and composed. The broker grants no application effects.
''' + primer)
    prompts = []
    for stage, task in ((1,stage1),(2,stage2)):
        temp = HERE / 'temp' / f'{name}-stage{stage}'
        temp.mkdir(parents=True)
        trace = HERE / f'trace-{name}-stage{stage}.jsonl'
        launch = f"$env:TEMP = '{temp}'\n$env:TMP = $env:TEMP\n$env:DOTNET_CLI_HOME = '{temp}'\n"
        launch += f"& '{REPO / 'scripts/Start-SubagentTrialHostV2.ps1'}' -CliDll '{cli}' -ProjectPath '{project}' -TracePath '{trace}' -AllowedOperations @('{operations}') -Profile '{profile}' "
        if arm == 'fsharp':
            launch += "-AdditionalCliArguments @('--validation-project','SubscriptionHandoff.Conventional.fsproj') "
        launch += '-ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100'
        path = HERE / f'prompt-{name}-stage{stage}.md'
        path.write_text(common + '\n' + task + '\n' + specifics + '\nLaunch once with exec_command, tty:true, yield_time_ms:10000.\n\n```powershell\n' + launch + '\n```\n', encoding='utf-8', newline='\n')
        prompts.append({'stage':stage,'path':str(path.relative_to(REPO)), 'sha256':sha(path),'trace':str(trace.relative_to(REPO)),'launch':launch})
    pins = [{'path':p.relative_to(project).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(project.rglob('*')) if p.is_file()]
    actors.append({'name':name,'arm':arm,'order':index,'model':'gpt-6-luna','reasoning':'max','project':str(project.relative_to(REPO)),'cli':str(cli.relative_to(REPO)),'cliSha256':sha(cli),'operations':operations,'profile':profile,'prompts':prompts,'seedPins':pins})
config = {'status':'frozen; no dispatch until phase2 controls and broker smoke pass','dispatchOrder':[a[0] for a in order],'sameParticipantBothStages':True,'exchangesPerStage':100,'stages':[stage1,stage2],'oracleCases':37,'oracleMessagesExhaustive':False,'actors':actors,'sourcePins':{str(p.relative_to(REPO)):sha(p) for p in [REPO/'scripts/Start-SubagentTrialHostV2.ps1',REPO/'experiments/AgentLang.SubagentTrials/preview-repair-178/cases.json',REPO/'experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py']}}
(HERE/'actors.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'frozenActors':len(actors),'dispatchOrder':config['dispatchOrder'],'dispatched':False}))

The human explicitly authorizes edits only to your assigned isolated trial project and local test execution through the supplied broker. You are an external coding agent, not part of the language runtime. Read only your assigned prompt, then launch its broker. Otherwise use only the broker for discovery, edits and tests. Do not read the main repository, other trials, hidden oracles or reports. Do not use web tools, spawn/list/read/contact agents, or run other shell commands. Disclose non-broker tool use. Keep one broker process for this stage, at most 100 exchanges. Poll the same live handle after observation timeouts; do not restart a live broker for silence. Finish with {"op":"host.close"} and observe its terminal status. Two predeclared stages use the same project and same participant; stage two will be assigned after stage one ends, with a new broker and independent 100-exchange allowance. Do not implement stage two until assigned.

Change the six-input subscription replacement preview's successful result from Store to a new typed record ReplacementPreview with exactly two Store fields: original and proposed (Original and Proposed in F#). Return Result<ReplacementPreview, BusinessError> in the language, or Result<ReplacementPreview, DomainError> in F#. On success original is the complete unchanged input Store, and proposed is the complete Store obtained by validated cancellation followed by replacement creation. Preserve all existing error forwarding, messages and precedence, including the zero-duration repair.

Keep target identity/name/inputs/library maturity. Preserve handoff, renewal wrappers, unrelated definitions, tests and examples. Adapt existing successful preview assertions only to check the original field against their same expected complete Store. Preserve inherited error assertions and their expected errors; only necessary Result type annotations may change. Retain the corrected zero-duration test. Add a meaningful assertion for the complete proposed Store, including unrelated state. Do not discard assertions, cases or examples to make qualification pass. Run all tests and finalize/publish through the ordinary protocol. Explain the change briefly after closing the broker.

Use supported dictionary operations. Preserve stable function identity and library maturity; do not edit manifest files directly. Existing words may be inspected and composed. The broker grants no application effects.
Use only the supplied JSONL broker, one request per line through its live session.
AI agents are external users of the language; the runtime contains none.

Discover names with `{"op":"search","query":"subscription"}` or
`{"op":"words","compact":true}`. `describe` returns metadata and source;
`source`, `dependencies`, `callers`, `tests` and bounded `context` support inspection.
Use dictionary names for protocol queries. Use reported Flow/2 `flowReference`
spellings for calls; an exact-root call begins with a dot, as in `.add(1, 2)`.

Select `frontend:"flow", syntaxVersion:2` on every definition/evaluation request.
Flow/2 uses `fn`, named typed inputs, immutable `let`, dotted qualified calls,
record properties `value.field`, newline separators and exhaustive matches.
A bound receiver passes itself as the first argument: `value.operation(args)`.
Both branches return the declared type. No implicit nominal conversions occur.

```flow
fn increment(value: Int) -> Int {
    effects none
    doc "Adds one."

    .add(value, 1)
}
test increment/basic {
    .increment(1)
    => 2
}
```

Omitted effects means pure. Put effects before doc, then a blank line before code.
Use versioned runtime help for exact syntax:
`{"op":"help","syntaxVersion":2,"topic":"define"}`.
Generic values use `result.ok<T,E>(value)`, `result.error<T,E>(error)` and
`option.some<T>(value)`. Inspect examples/tests rather than guessing constructors.

Tests attach through `function-name/case-name`. Bare `=>` accepts supported
literals; `=> value expression` compares constructed values. `=> error CODE`
expects a runtime failure, not a returned `Result.error` value. Inspect authored
cases with `{"op":"tests","word":"...","includeSource":true,"caseName":"..."}`.

Begin a task with `task.begin` and a goal. Define source, run `test` for the new
function, then `commit` with its word name and `library:true`. Library functions
need passing own tests, complete own instruction/branch and finite-value coverage,
and qualified dependencies. Caller tests do not replace helper coverage.
Run relevant regressions, preserve all old definitions/tests, and finish with
`task.commit`. `test-all` updates the latest coverage batch; a later single-word
test can replace that batch. Query help for failures rather than weakening gates.

Protocol bytes are not model tokens. Poll the same live handle after observation
timeouts; never repeat an uncertain mutation. Finish with `{"op":"host.close"}`
and observe terminal status. Do not spawn/contact other agents or use other tools.

Launch once with exec_command, tty:true, yield_time_ms:10000.

```powershell
$env:TEMP = 'D:\code\AgentLang\.agentlang\preview-sequence-179\temp\reset-2-stage2'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = 'D:\code\AgentLang\.agentlang\preview-sequence-179\temp\reset-2-stage2'
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\efficacy-maintenance-178\build\bin\AgentLang.Cli\release\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\preview-sequence-179\actors\reset-2' -TracePath 'D:\code\AgentLang\.agentlang\preview-sequence-179\trace-reset-2-stage2.jsonl' -AllowedOperations @('help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort') -Profile 'agentlang' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

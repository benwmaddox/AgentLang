"""Check frozen seeds through disposable broker sessions; never touch actors."""
import json
import os
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
config = json.loads((HERE/'actors.json').read_text())
output = HERE/'smoke-001'
output.mkdir(exist_ok=False)
results = []
for arm in ('retained','reset','fsharp'):
    actor = next(a for a in config['actors'] if a['arm']==arm)
    project = output/arm
    shutil.copytree(REPO/actor['project'],project)
    temp = output/f'{arm}-temp'
    temp.mkdir()
    env = os.environ.copy()
    env.update(TEMP=str(temp),TMP=str(temp),DOTNET_CLI_HOME=str(temp))
    command = ['pwsh','-NoProfile','-File',str(REPO/'scripts/Start-SubagentTrialHostV2.ps1'),'-CliDll',str(REPO/actor['cli']),'-ProjectPath',str(project),'-TracePath',str(output/f'trace-{arm}.jsonl'),'-AllowedOperations','inspect,validate' if arm=='fsharp' else 'help,test-all','-Profile',actor['profile'],'-ExchangeTimeoutMilliseconds','120000','-MaxExchanges','100']
    if arm=='fsharp':
        command += ['-AdditionalCliArgumentsJson',json.dumps(['--validation-project','SubscriptionHandoff.Conventional.fsproj'])]
    requests = ([{'op':'inspect'},{'op':'validate'}] if arm=='fsharp' else [{'op':'help','syntaxVersion':2,'topic':'define'},{'op':'test-all'}])+[{'op':'host.close'}]
    data = ''.join(json.dumps(r)+'\n' for r in requests)
    (output/f'{arm}-requests.jsonl').write_text(data)
    run = subprocess.run(command,input=data,text=True,encoding='utf-8',errors='replace',capture_output=True,env=env,cwd=REPO)
    (output/f'{arm}-stdout.jsonl').write_text(run.stdout,encoding='utf-8')
    (output/f'{arm}-stderr.txt').write_text(run.stderr,encoding='utf-8')
    rows = [json.loads(line) for line in run.stdout.splitlines() if line.strip()]
    trace = [json.loads(line) for line in (output/f'trace-{arm}.jsonl').read_text().splitlines()]
    ending = trace[-1]
    assert run.returncode==0 and len(rows)==2 and all(r.get('ok') for r in rows),(arm,run.returncode,rows)
    assert ending['event']=='session-end' and ending['terminationKind']=='host-close' and ending['hostExitCode']==0 and ending['runtimeExitCode']==0,ending
    if arm=='fsharp':
        assert rows[1]['data']['exitCode']==0,rows[1]
    else:
        expected = '146/146 test(s) passed.' if arm=='retained' else '142/142 test(s) passed.'
        assert rows[1]['text']==expected,rows[1]
    results.append({'arm':arm,'exitCode':run.returncode,'validation':rows[1]})
(output/'summary.json').write_text(json.dumps({'status':'pass','results':results,'participantsDispatched':False},indent=2)+'\n')
print(json.dumps({'status':'pass','profiles':len(results),'participantsDispatched':False}))

# Supplemental first-score verification

The initial retained-1 stage1 result used the pre-amendment wrapper (SHA68c102ffa09365102f5234c1a1dfeff74b8d920cd65e419a5cc706ab0bb8d3ce). Its old wrapper bytes were not retained, although original hash receipt/result and captured candidate remain. Root created verify-first-score.py from the corrected score.py, changing only the output label to verify-a1s1; all capture/trace guards and frozen semantic adapters remain intact. Independent verification of the same captured snapshot again passes37/37, setup0, candidate unchanged. It is supplemental validation, not another participant or added trial outcome; no participant feedback provided.

An initial shell command to create the verification script had a quoting error and did not create or run a scorer. Corrected creation via Python stdin succeeded; the saved script and oracle/verify-a1s1.json preserve the executed verification.

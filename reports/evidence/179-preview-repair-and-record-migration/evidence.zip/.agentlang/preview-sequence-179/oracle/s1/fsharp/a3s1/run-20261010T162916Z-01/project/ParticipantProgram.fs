namespace AgentLang.SubscriptionHandoff.Control

module ParticipantProgram =
    [<EntryPoint>]
    let main args =
        try
            let observe store oldId newId term at expiry _ =
                AgentLang.SubscriptionHandoff.Subscription.previewReplacement store oldId newId term at expiry
            Scorer.runFileWith observe true args.[0]
            0
        with error ->
            System.Console.Error.WriteLine(error.Message)
            2

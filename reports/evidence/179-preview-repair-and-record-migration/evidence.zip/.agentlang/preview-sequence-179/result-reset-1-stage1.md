Independent score 37/37, zero setup errors; candidate unchanged and linked to
captured snapshot/trace. Automatic collateral audit has no issues/new words/new
types. Same stable library identity, six inputs, Store Result output; source
removes shortcut and preserves cancellation-first lower-level composition.

Only zero-period-no-op changes: same fixture/call now requires any returned
error rather than success. This satisfies the frozen correction requirement but
is weaker than checking its exact expiry code. All other inherited assertions,
examples, definitions/types and bindings remain exact. Independent oracle checks
the correct error code, including precedence fixtures.

Trace has 19 exchanges, normal host/runtime exit 0 and task.commit. Participant
reports target 5/5 with coverage and whole project 142/142. Three unsupported help
topics rejected; no reported protocol departure or non-broker use beyond prompt
read/launch. Scores and preservation feedback withheld from stage two.

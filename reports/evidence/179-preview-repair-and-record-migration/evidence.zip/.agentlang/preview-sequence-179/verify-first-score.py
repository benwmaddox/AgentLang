"""Thin sequence scorer using the calibrated existing fixture encoders."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import argparse

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def inventory(project):
    return {p.relative_to(project).as_posix():sha(p) for p in sorted(project.rglob('*')) if p.is_file() and not (set(p.relative_to(project).parts)&{'bin','obj','temp','__pycache__'})}
parser=argparse.ArgumentParser();parser.add_argument('actor');parser.add_argument('--stage',type=int,choices=[1,2],required=True)
args=parser.parse_args()
actor=next(a for a in json.loads((HERE/'actors.json').read_text())['actors'] if a['name']==args.actor)
project=HERE/'snapshots'/f'{args.actor}-stage{args.stage}'
assert project.is_dir(),project
label="verify-a1s1"
output=HERE/'oracle'/f'{label}.json'
assert not output.exists(),output
capture_path=HERE/f'capture-{args.actor}-stage{args.stage}.json'
capture=json.loads(capture_path.read_text())
assert capture['actor']==args.actor and capture['stage']==args.stage
before=inventory(project);ownhash=sha(Path(__file__))
assert before=={r['path']:r['sha256'] for r in capture['candidatePins']},'Snapshot differs from captured candidate'
trace_path=REPO/next(p['trace'] for p in actor['prompts'] if p['stage']==args.stage)
assert sha(trace_path)==capture['traceSha256'],'Captured trace changed'
preview=module('sequence_preview178',REPO/'experiments/AgentLang.SubagentTrials/preview-repair-178/score_preview.py')
rows=preview.cases();assert len(rows)==37
results={};exceptions=[]
if args.stage==1:
    preview.EVIDENCE=HERE/'oracle'/'s1'
    result=(preview.fsharp_score(project,label,rows) if actor['arm']=='fsharp' else preview.flow_score(project,REPO/actor['cli'],label,rows))
    results['original']=result
elif actor['arm']=='fsharp':
    scorer=module('sequence_fsharp2',HERE/'phase2/scripts/score_fsharp_control.py')
    scorer.SOURCE=project;scorer.PHASE2=HERE/'oracle'/label
    scorer.PHASE2.mkdir(parents=True,exist_ok=False)
    try:scorer.main()
    except Exception as e:exceptions.append(f'{type(e).__name__}: {e}')
    summaries=list((scorer.PHASE2/'evidence/fsharp-score').glob('*/result.json'))
    assert len(summaries)==1,summaries
    record=json.loads(summaries[0].read_text());results=record.get('fieldScores',{})
    run=summaries[0].parent
    assert record['participantOperationsSha256']==sha(project/'Operations.fs')==record['compileInputs']['Operations.fs']
    assert record['domainSha256']==sha(project/'Domain.fs')==record['compileInputs']['Domain.fs']
    for field,result in results.items():
        # The original fixture decoder zips rows; separately enforce IDs/order.
        emitted,error=scorer.load_module('sequence_decoder_check',scorer.ADAPTER_PATH).parse_rows((run/f'fsharp-{field}-stdout.txt').read_text())
        assert not error and [r.get('id') for r in emitted]==[r['id'] for r in rows],field
    results={'fields':results,'scoringManifest':record}
else:
    adapter=module('sequence_flow2',REPO/'.agentlang/preview-retention-171/drafts/score_adapter.py')
    adapter.EVIDENCE_ROOT=HERE/'oracle'/'s2';adapter.load_cases=lambda:deepcopy(rows)
    for field in ('original','proposed'):
        adapter.OBSERVER_SOURCE='''// frontend: flow/2
record PreviewReplacementScoringObservation {
    field input: Store
    field outcome: Result<Store, BusinessError>
}
fn preview-retention.scoring-observe(input: Store, old-id: SubscriptionId, replacement-id: SubscriptionId, term: String, handoff-at: Instant, expires-at: Instant) -> PreviewReplacementScoringObservation {
    match subscription.preview-replacement(input, old-id, replacement-id, term, handoff-at, expires-at) {
        ok preview => previewReplacementScoringObservation.new(input = input, outcome = result.ok<Store, BusinessError>(preview.FIELD))
        error failure => previewReplacementScoringObservation.new(input = input, outcome = result.error<Store, BusinessError>(failure))
    }
}
'''.replace('preview.FIELD',f'preview.{field}')
        def expected(item,selected=field):
            model=item['expected'];input_value=adapter.OLD.normalized_projection({'store':item['store']})
            if model['tag']=='error':return {'tag':'error','code':model['code'],'input':input_value}
            value=item['store'] if selected=='original' else model['store']
            return {'tag':'ok','store':adapter.OLD.normalized_projection({'store':value}),'input':input_value}
        adapter.expected_projection=expected
        try:results[field]=adapter.score_actor(project,REPO/actor['cli'],'participant',f'{label}{field[0]}')
        except Exception as e:exceptions.append(f'{field}: {type(e).__name__}: {e}')
result={'actor':args.actor,'arm':actor['arm'],'stage':args.stage,'caseCount':37,'caseSha256':sha(REPO/'experiments/AgentLang.SubagentTrials/preview-repair-178/cases.json'),'scoreScriptSha256':ownhash,'captureSha256':sha(capture_path),'traceSha256':capture['traceSha256'],'candidateBefore':before,'candidateUnchanged':before==inventory(project),'results':results,'exceptions':exceptions,'preservationSeparate':True}
assert sha(Path(__file__))==ownhash
output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert result['candidateUnchanged']
print(json.dumps({'saved':str(output),'actor':args.actor,'stage':args.stage,'exceptions':exceptions,'candidateUnchanged':True}))

Independent original/proposed projections each pass 37/37 with zero setup errors;
candidate/capture/trace linkage and input inventory match. Normal terminal exit
0, 32 exchanges; target 6/6 and project 143/143, replacement/task commit succeed.

Automatic collateral audit no issues/new authored functions; exact new record
type and six typed inputs/stable library identity. Only old successful assertion
uses preview.original with its original expected Store. Inherited errors and
corrected zero-duration test remain byte-identical. Target preserves lower-level
cancel/start composition. Missing-old path now explicitly creates the same
SUBSCRIPTION_NOT_FOUND code and exact message as unchanged subscription.cancel;
manual comparison confirms message preservation for that rewritten path.

New proposed assertion constructs explicit cancellation/replacement states and
keeps an unrelated subscription, comparing the entire expected Store and original
Store. Initial definition was rejected with FLOW_MATCH_BRANCH_TYPE; corrected
definition passed. Type-name describe rejected NAME_UNKNOWN_WORD, then source
inspection worked. No protocol departures reported.

"""Terminal broker measurements, not provider token/context measurements."""
import collections
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
config = json.loads((HERE / 'actors.json').read_text(encoding='utf-8-sig'))
rows = []
for actor in config['actors']:
    for prompt in actor['prompts']:
        stage = prompt['stage']
        trace = HERE / f"trace-{actor['name']}-stage{stage}.jsonl"
        capture = json.loads((HERE / f"capture-{actor['name']}-stage{stage}.json").read_text(encoding='utf-8-sig'))
        trace_hash = hashlib.sha256(trace.read_bytes()).hexdigest()
        assert capture['traceSha256'] == trace_hash, 'Measured trace differs from captured trace'
        events = [json.loads(line) for line in trace.read_text(encoding='utf-8-sig').splitlines()]
        start = events[0]
        end = events[-1]
        assert start['event'] == 'session-start' and end['event'] == 'session-end'
        exchanges = [event for event in events if event['event'] == 'exchange']
        assert len(exchanges) == end['exchangeCount']
        failures = []
        publications = []
        validations = []
        task_commits = []
        for event in exchanges:
            response = event.get('response') or {}
            raw = response.get('canonical')
            body = json.loads(raw) if raw else {}
            if event['operation'] in ('replace-word', 'commit'):
                publications.append({'index': event['index'], 'operation': event['operation'],
                                     'ok': body.get('ok'), 'text': body.get('text')})
            if event['operation'] == 'test-all':
                results = (body.get('data') or {}).get('results', [])
                validations.append({'index': event['index'], 'ok': body.get('ok'), 'total': len(results),
                                    'passed': sum(result.get('passed') is True for result in results)})
            if event['operation'] == 'validate':
                data = body.get('data') or {}
                validations.append({'index': event['index'], 'ok': body.get('ok'), 'exitCode': data.get('exitCode')})
            if event['operation'] == 'task.commit':
                task_commits.append({'index': event['index'], 'ok': body.get('ok'),
                                     'active': (body.get('data') or {}).get('active')})
            if body.get('ok') is False or event.get('errorCode'):
                failures.append({'index': event['index'], 'operation': event['operation'],
                                 'hostError': event.get('errorCode'), 'runtimeError': body.get('error')})
        expected_ops = set(actor['operations'].split(','))
        actual_ops = set(start['allowedOperations'])
        rows.append({
            'actor': actor['name'], 'arm': actor['arm'], 'stage': stage,
            'exchanges': len(exchanges),
            'operations': dict(collections.Counter(event['operation'] for event in exchanges)),
            'requestPayloadBytes': sum((event.get('request') or {}).get('payloadUtf8Bytes', 0) for event in exchanges),
            'responsePayloadBytes': sum((event.get('response') or {}).get('payloadUtf8Bytes', 0) for event in exchanges),
            'brokerSeconds': (datetime.datetime.fromisoformat(end['finishedUtc']) - datetime.datetime.fromisoformat(start['startedUtc'])).total_seconds(),
            'normalFinalization': end['terminationKind'] == 'host-close' and end['hostExitCode'] == 0 and end['runtimeExitCode'] == 0,
            'allowlistMissing': sorted(expected_ops - actual_ops),
            'allowlistExtra': sorted(actual_ops - expected_ops),
            'failedResponses': failures,
            'publications': publications,
            'validations': validations,
            'taskCommits': task_commits,
            'traceSha256': trace_hash,
        })
out = HERE / 'metrics.json'
assert not out.exists(), 'Refuse overwriting saved measurements'
out.write_text(json.dumps({'limits': 'Protocol payload bytes and broker duration only; no authoritative LLM token usage, effective context or total agent wall time.', 'stages': rows}, indent=2) + '\n', encoding='utf-8')
print(out)

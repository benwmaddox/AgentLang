from pathlib import Path
p = Path(r"D:\code\AgentLang\tests\AgentLang.Campfire.NativeRoomRead.Tests\native\room_read_standalone_smoke.c")
s = p.read_text(encoding="utf-8")
i = s.index("/* Rails' CSRF tokens are randomly masked per form (report 271): compare the")
j = s.index("static void reset_runtime_context(", i)
s = s[:i] + '''/* Pages carry no CSRF tokens since report 283, so the output must match the
 * expected bytes exactly. */
static int bytes_equal(const uint8_t *left, const uint8_t *right, uint32_t length) {
  uint32_t index;
  for (index = 0u; index < length; ++index) {
    if (left[index] != right[index])
      return 0;
  }
  return 1;
}

''' + s[j:]
a = "if (!bytes_equal_masking_csrf(retained_storage, room_read_expected, written_bytes)) {"
assert s.count(a) == 1
s = s.replace(a, "if (!bytes_equal(retained_storage, room_read_expected, written_bytes)) {")
p.write_text(s, encoding="utf-8", newline="")
print("ok")

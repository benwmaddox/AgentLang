from pathlib import Path
p = Path(r"D:\code\AgentLang\tests\AgentLang.Campfire.NativeRoomRead.Tests\NativeRoomReadTests.fs")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:70], s.count(a))
    s = s.replace(a, b)


rep('''    /// A fixed, valid session CSRF secret (32 bytes, urlsafe Base64) for these synthetic requests.
    let private csrfSecret''', '''    /// A fixed, valid session CSRF secret (32 bytes, urlsafe Base64), as a Rails-written session
    /// carries. Since report 283 pages carry no tokens, so the secret must not reach the body.
    let private csrfSecret''')
i = s.index("    /// Rails' CSRF tokens are randomly masked per form, so pages compare with")
j = s.index("    let private withRequestMethod request methodName =", i)
s = s[:i] + '''    /// Report 283: pages carry no CSRF tokens, so native and interpreter values compare exactly.
    let private sameValue (actual: Value list) (expected: Value) = actual = [ expected ]

    /// True when the body has no CSRF markup and none of the session secret.
    let private noCsrfMarkup (body: string) =
        not (body.Contains("csrf", StringComparison.Ordinal))
        && not (body.Contains("authenticity_token", StringComparison.Ordinal))
        && not (body.Contains(csrfSecret, StringComparison.Ordinal))

''' + s[j:]
rep('''                            let valid, found = csrfTokensValid body
                            check assertions $"{optimizationName}/{testCase.Name}: every CSRF token unmasks to its HMAC" (found = 8 * expectedCount + 1 && valid = found)''',
    '''                            check assertions $"{optimizationName}/{testCase.Name}: no CSRF tokens in the page" (noCsrfMarkup body)
                            let boostForms = body.Split("/boosts\\" accept-charset=\\"UTF-8\\" method=\\"post\\">\\n            <input type=\\"hidden\\" name=\\"boost[content]\\"", StringSplitOptions.None).Length - 1
                            check assertions $"{optimizationName}/{testCase.Name}: eight token-free boost forms per message" (boostForms = 8 * expectedCount)''')
rep("(maskCsrf expectedHead = maskCsrf expectedGet)", "(expectedHead = expectedGet)")
s = s.replace("sameMasked ", "sameValue ")
assert "maskCsrf" not in s and "csrfTokensValid" not in s and "sameMasked" not in s
p.write_text(s, encoding="utf-8", newline="")
print("ok", s.count("sameValue "))

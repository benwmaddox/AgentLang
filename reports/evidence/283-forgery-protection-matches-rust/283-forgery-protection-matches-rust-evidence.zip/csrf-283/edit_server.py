from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:80], s.count(a))
    s = s.replace(a, b)


i = s.index("fn campfire.server.tokened-message(")
j = s.index("// ------------------------------------------------------- fragment cache", i)
s = s[:i] + s[j:]
rep("""// cache version, and nothing about the viewer, the creator or the room. On a
// hit Rails evaluates none of the partial, so the eight quick-boost forms keep
// the authenticity tokens of the request that first rendered the fragment
// (valid for that session only; Rails behaves the same). Editing a message or""",
    """// cache version, and nothing about the viewer, the creator or the room. On a
// hit Rails evaluates none of the partial. The fragments carry no authenticity
// tokens (forgery protection is by Origin and Sec-Fetch-Site, as in the Rust
// reference), so a cached fragment equals a fresh render. Editing a message or""")
rep('"views/messages/_message:flow-1"', '"views/messages/_message:flow-2"')
rep('== "views/messages/_message:flow-1/messages/3-1772465460123/presentation-v3"',
    '== "views/messages/_message:flow-2/messages/3-1772465460123/presentation-v3"')
rep("""record FragmentContext {
    page: MessageContext
    secret: String
}

fn campfire.server.message-fragment(context: FragmentContext, message: MessageWithCreator) -> String {
    effects cache.read, cache.write, random.read
    doc "The markup of messages/_message for one message through the fragment cache: the cached fragment, else the rendered partial (with this request's boost tokens, from the session's CSRF secret), stored for later requests."
""", """fn campfire.server.message-fragment(context: MessageContext, message: MessageWithCreator) -> String {
    effects cache.read, cache.write
    doc "The markup of messages/_message for one message through the fragment cache: the cached fragment, else the rendered partial, stored for later requests."
""")
rep("campfire.views.text(campfire.views.rails-message(context.page, campfire.server.tokened-message(context.secret, message)))",
    "campfire.views.text(campfire.views.rails-message(context, message))")
rep('''    let first = campfire.server.message-fragment(fragmentContext.new(page = page, secret = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"), message)
    let again = campfire.server.message-fragment(fragmentContext.new(page = page, secret = "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"), message)
    let edited = campfire.server.message-fragment(fragmentContext.new(page = page, secret = "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"), messageWithCreator.new(''',
    '''    let first = campfire.server.message-fragment(page, message)
    let again = campfire.server.message-fragment(page, message)
    let edited = campfire.server.message-fragment(page, messageWithCreator.new(''')
rep('''    expect first == again
    expect string.contains(edited''', '''    expect first == again
    expect first == campfire.views.text(campfire.views.rails-message(page, message))
    expect string.contains(edited''')
rep("""fn campfire.server.cached-room-page(chrome: PageChrome, secret: String, messages: List<MessageWithCreator>) -> String {
    effects cache.read, cache.write, random.read""", """fn campfire.server.cached-room-page(chrome: PageChrome, messages: List<MessageWithCreator>) -> String {
    effects cache.read, cache.write""")
rep("    let context = fragmentContext.new(page = messageContext.new(room-id = chrome.room-id, room-name = chrome.room-name, base-url = chrome.base-url), secret = secret)",
    "    let context = messageContext.new(room-id = chrome.room-id, room-name = chrome.room-name, base-url = chrome.base-url)")
rep('''    let first = campfire.server.cached-room-page(chrome, "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", [message])
    let second = campfire.server.cached-room-page(chrome, "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB", [message])
    expect first == second''', '''    let first = campfire.server.cached-room-page(chrome, [message])
    let second = campfire.server.cached-room-page(chrome, [message])
    expect first == second
    expect first == campfire.views.creator-room-page(chrome, [message])''')
rep('''            let secret = campfire.csrf.session-secret(request.csrf-token)
            let room-id = int.to-string(RoomId.value(room.id))
            let meta-token = campfire.csrf.form-token(secret.value, "!real_csrf_token")
            let composer-token = campfire.csrf.form-token(secret.value, string.concat(string.concat("/rooms/", room-id), "/messages#post"))
            let secret-value = secret.value
            let new-csrf-token = if secret.fresh {
                option.some<String>(secret.value)
            } else {
                option.none<String>()
            }
''', "")
rep('''                new-csrf-token = new-csrf-token,
                body = campfire.server.cached-room-page(campfire.views.room-chrome(room, user, request.base-url), secret-value, messages))''',
    '''                new-csrf-token = option.none<String>(),
                body = campfire.server.cached-room-page(campfire.views.room-chrome(room, user, request.base-url), messages))''')
rep("    expect shown.new-csrf-token != option.none<String>()\n",
    '    expect shown.new-csrf-token == option.none<String>()\n    expect bool.not(string.contains(shown.body, "authenticity_token"))\n')
rep("    let csrf-ok = response.new-csrf-token == option.none<String>() || response.view == HttpView.room()\n",
    "    let csrf-ok = response.new-csrf-token == option.none<String>()\n")
rep('''    let mutation = response.remember-return-to || alert != option.none<String>() || response.new-csrf-token != option.none<String>()
    var headers = option.some<List<HttpHeader>>(list.empty<HttpHeader>())
    if mutation {
        let session = match built.session { none => "{}"; some text => text }
        headers = match campfire.server.mutate-session(session, return-url, alert, response.new-csrf-token) {''',
    '''    let mutation = response.remember-return-to || alert != option.none<String>()
    var headers = option.some<List<HttpHeader>>(list.empty<HttpHeader>())
    if mutation {
        let decrypted = match built.session-cookie {
            none => option.none<String>()
            some raw => campfire.server.decrypt-session(context.encryption-key, raw, now)
        }
        let session = match decrypted { none => "{}"; some text => text }
        headers = match campfire.server.mutate-session(session, return-url, alert) {''')
rep("_campfire_session (return-to, flash alert, new CSRF secret; HttpOnly, session lifetime)",
    "_campfire_session (return-to, flash alert; decrypted only then; HttpOnly, session lifetime)")
rep("session = option.none<String>())", "session-cookie = option.none<String>())", 2)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

cd /home/ben/linuxbench/private
for r in s1-rust-off-r1 s1-flow-off-r1 s1-rails-off-r1; do
  f=$r/body1.html; echo "== $r $(stat -c %s $f) bytes"
  echo "csrf-meta=$(grep -c 'name="csrf-token"' $f) csrf-param=$(grep -c 'name="csrf-param"' $f) token-inputs=$(grep -o 'name="authenticity_token"' $f | wc -l) forms=$(grep -o '<form' $f | wc -l) data-token=$(grep -o 'authenticity' $f | wc -l)"
  grep -o '<meta name="csrf[^>]*>' $f | sed -E 's/content="[^"]*"/content="..."/'
  grep -o '<form[^>]*>' $f | head -2
done

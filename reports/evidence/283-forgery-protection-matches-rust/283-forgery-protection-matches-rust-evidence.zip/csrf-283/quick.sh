D=/mnt/d/code/AgentLang/.agentlang/linux-sweep-282
export FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-283/flow_http_server
for cfg in rust:off flow:off rust:on flow:on flow:off rust:off flow:on rust:on; do
  app=${cfg%%:*}; c=${cfg##*:}; n=$(ls -d $D/runs/q283-$app-$c-* 2>/dev/null | wc -l); run=q283-$app-$c-$((n+1))
  bash $D/sweep-lifetime.sh $app $run $c 16,64 > /dev/null 2>&1; echo "$run exit=$?"
done

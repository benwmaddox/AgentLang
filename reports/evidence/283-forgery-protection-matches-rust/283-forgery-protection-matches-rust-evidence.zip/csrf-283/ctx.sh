cd /home/ben/linuxbench/private
for r in s1-rust-off-r1 s1-flow-off-r1; do f=$r/body1.html; echo "=== $r"
python3 - "$f" <<'PY'
import sys,re
s=open(sys.argv[1],encoding='utf-8').read()
i=s.index('apple-mobile-web-app-capable'); print(repr(s[i:i+220]))
i=s.index('<form id="composer"'); j=s.index('>',s.index('method="post"',i)); print(repr(s[j-20:j+80]))
i=s.index('/boosts" accept-charset'); print(repr(s[i:i+200]))
PY
done

from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\views-tests.flow")
s = p.read_text(encoding="utf-8")
for tail in ("            <input", "        <fieldset"):
    a = 'method=\\"post\\">\n' + tail
    assert s.count(a) == 1, tail
    s = s.replace(a, 'method=\\"post\\">\\n' + tail)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

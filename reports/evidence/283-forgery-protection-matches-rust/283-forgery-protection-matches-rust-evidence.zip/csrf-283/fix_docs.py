from pathlib import Path
p = Path(r"D:\code\AgentLang\docs\PENDING-REVIEW.md")
s = p.read_text(encoding="utf-8")
lines = s.split("\n")
idx = next(i for i, l in enumerate(lines) if l.startswith("| CSRF parity with Rust (282) |"))
del lines[idx]
s = "\n".join(lines)
a = "## Scheduled removals\n\n| Item | Action | Deadline |\n| --- | --- | --- |\n"
assert a in s
s = s.replace(a, a + "| CSRF record fields (283) | `CampfireHttpRequest.csrf-token` and `CampfireHttpResponse.new-csrf-token` are always none since Flow matches Rust's header-only forgery protection (user, 2026-10-15). They stay only because the Windows native host (`request_encoder.c`, `campfire_http_renderer.c`, the `_csrf_token` writer in `cookie_response_codec.c`) and the .NET hosts encode those layouts. Remove the fields and that code when those hosts are deleted. | With stdlib step 5 |\n")
a = "## Deferred usability work (user, 2026-10-13)"
assert a in s
s = s.replace(a, """## Decided: forgery protection matches Rust (user, 2026-10-15)

Flow Campfire uses header-only forgery protection, like the Rust reference
(Rails main's `protect_from_forgery using: :header_only`): writes are checked by
`Origin` and `Sec-Fetch-Site` (`campfire.request.forgery-check-passed?`, which
was already the only check: no request path ever verified a token). Pages
carry no CSRF meta tags or `authenticity_token` fields, so a room page is the
same bytes on every request, and the server decrypts `_campfire_session` only
when a response changes it. Rails keeps its token scheme in the benchmark and is
labeled as the one server doing token work (report 283).

""" + a)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

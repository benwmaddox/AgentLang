from pathlib import Path
p = Path(r"D:\code\AgentLang\tests\AgentLang.Campfire.Http.Tests\Program.fs")
s = p.read_text(encoding="utf-8")
i = s.index("        // Report 271: Rails' CSRF model. A session without _csrf_token gets one,")
j = s.index('        currentCheck <- "unauthenticated room redirect preserves encrypted existing state and return URL"', i)
new = '''        // Report 283: forgery protection by Origin and Sec-Fetch-Site only, as the Rust reference
        // (Rails main's `protect_from_forgery using: :header_only`). Pages carry no CSRF tokens, the
        // session is not rewritten for a CSRF secret, and the same request renders the same bytes.
        currentCheck <- "room page carries no CSRF tokens and does not rewrite the session"
        check (not (room.Body.Contains("csrf", StringComparison.Ordinal))) "no csrf-param or csrf-token meta tags"
        check (not (room.Body.Contains("authenticity_token", StringComparison.Ordinal))) "no authenticity_token form fields"
        equal 320 (Regex.Matches(room.Body, "action=\\"/messages/\\d+/boosts\\" accept-charset=\\"UTF-8\\" method=\\"post\\">\\n            <input type=\\"hidden\\" name=\\"boost\\[content\\]\\"").Count) "forty messages render eight quick-boost forms each, without tokens"
        check (getCookie room "_campfire_session" |> Option.isNone) "a session without a CSRF secret is not given one"
        let again =
            send client
                { (baseSpec "GET" "/rooms/1") with
                    Cookies = [ "session_token", token "fresh-token"; "last_room", "1" ]
                    Accept = Some "text/html"
                    FetchSite = Some "same-origin" }
        expectStatus 200 again
        equal room.Body again.Body "the same room renders byte-identical pages across requests"
        check (getCookie again "_campfire_session" |> Option.isNone) "a steady-state room GET writes no session cookie"

'''
s = s[:i] + new + s[j:]
p.write_text(s, encoding="utf-8", newline="")
print("ok")

#!/usr/bin/env python3
"""Mechanical source rewrites for 283 (Flow matches Rust: no CSRF tokens in pages)."""
import re, sys
from pathlib import Path

def close(s, i):
    """Index just past the parenthesis group opening at s[i] == '(' (strings respected)."""
    depth, j, q = 0, i, False
    while j < len(s):
        c = s[j]
        if q:
            if c == '\\': j += 1
            elif c == '"': q = False
        elif c == '"': q = True
        elif c == '(': depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0: return j + 1
        j += 1
    raise ValueError("unbalanced")

def args(s, i):
    """Top-level argument spans of the call whose '(' is at s[i]."""
    end = close(s, i); out, depth, q, start = [], 0, False, i + 1
    for j in range(i + 1, end - 1):
        c = s[j]
        if q:
            if c == '\\' and False: pass
            if c == '"' and s[j - 1] != '\\': q = False
            continue
        if c == '"': q = True
        elif c in '([{<': depth += 1 if c != '<' else 0
        elif c in ')]}': depth -= 1
        elif c == ',' and depth == 0: out.append((start, j)); start = j + 1
    out.append((start, end - 1)); return out, end

def unwrap_tokened(s):
    key = 'tokenedMessage.new('
    while (i := s.find(key)) >= 0:
        p = i + len(key) - 1; spans, end = args(s, p)
        inner = s[spans[0][0]:spans[0][1]].strip()
        assert inner.startswith('message = '), inner[:40]
        s = s[:i] + inner[len('message = '):] + s[end:]
    return s

def drop_chrome_tokens(s):
    key = 'campfire.views.room-chrome('
    pos = 0
    while (i := s.find(key, pos)) >= 0:
        p = i + len(key) - 1; spans, end = args(s, p)
        if s[p - len('fn ') - len(key) + 1:p].startswith('fn '):  # definition
            pos = end; continue
        if len(spans) == 5:
            s = s[:spans[2][1]] + ')' + s[end:]
        pos = i + 1
    return s

for path in map(Path, sys.argv[1:]):
    s = path.read_text(encoding='utf-8'); t = drop_chrome_tokens(unwrap_tokened(s))
    t = t.replace('List<TokenedMessage>', 'List<MessageWithCreator>').replace('list.empty<TokenedMessage>', 'list.empty<MessageWithCreator>')
    if t != s:
        path.write_text(t, encoding='utf-8', newline='')
        print('rewrote', path)

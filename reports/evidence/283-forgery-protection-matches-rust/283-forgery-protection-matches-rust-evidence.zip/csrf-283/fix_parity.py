from pathlib import Path
p = Path(r"D:\code\AgentLang\scripts\Test-CampfireFlowServerParity.ps1")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''Bodies are compared with masked CSRF tokens replaced by a marker; the tokens
themselves are checked by unmasking them with the session's CSRF secret.''',
    '''Bodies are compared byte for byte: since report 283 pages carry no CSRF tokens
(forgery protection is by Origin and Sec-Fetch-Site, as in the Rust reference), so
the script also checks that no token markup or session secret appears and that
repeated requests render identical pages.''')
rep('''    [string] $CsrfOracle = '',
''', '')
rep('''    # The Flow server's --cache-mb (0 = no cache). With the cache on, message
    # fragments (and their boost-form tokens) are reused from the first render,
    # as Rails' `cache [ message, "presentation-v3" ]` does; bodies still match
    # the uncached native host modulo token masks, and every token still verifies.''',
    '''    # The Flow server's --cache-mb (0 = no cache). With the cache on, message
    # fragments are reused from the first render, as Rails'
    # `cache [ message, "presentation-v3" ]` does; bodies still match the
    # uncached native host byte for byte.''')
rep('''    $masked = [regex]::Replace($body, '(name="authenticity_token" value="|<meta name="csrf-token" content=")[A-Za-z0-9_-]+', '$1<token>')
    return [ordered]@{ status = $status; headers = (@($headers | Sort-Object) -join "`n"); cookies = ($cookies -join "`n"); body = $masked; bodyBytes = $body.Length }''',
    '''    return [ordered]@{ status = $status; headers = (@($headers | Sort-Object) -join "`n"); cookies = ($cookies -join "`n"); body = $body; bodyBytes = $body.Length }''')
i = s.index("# CSRF: each masked token is pad || (pad XOR HMAC-SHA256(secret, identifier)),")
j = s.index("$flowServerLog = Join-Path $out 'flow/server.stderr.log'", i)
new = '''# CSRF (report 283): no csrf meta tags, no authenticity_token fields and none of
# the session's _csrf_token (a Rails-written session still carries one).
$csrfSecret = $null
$sessionPart = $cookie.Split(';') | ForEach-Object { $_.Trim() } | Where-Object { $_.StartsWith('_campfire_session=') } | Select-Object -First 1
if ($sessionPart) {
    $pieces = [Uri]::UnescapeDataString($sessionPart.Substring(18)).Split('--'); $data = [Convert]::FromBase64String($pieces[0]); $plain = [byte[]]::new($data.Length)
    [Security.Cryptography.AesGcm]::new($encryptionKey, 16).Decrypt([Convert]::FromBase64String($pieces[1]), $data, [Convert]::FromBase64String($pieces[2]), $plain)
    $session = (Open-Envelope ([Text.Encoding]::UTF8.GetString($plain))).message | ConvertFrom-Json -AsHashtable
    if ($session.ContainsKey('_csrf_token')) { $csrfSecret = $session['_csrf_token'] }
}
function Test-NoCsrf([string] $Body) {
    return -not $Body.Contains('csrf') -and -not $Body.Contains('authenticity_token') -and ($null -eq $csrfSecret -or -not $Body.Contains($csrfSecret))
}
foreach ($kind in @('native', 'flow')) {
    $steady = [IO.File]::ReadAllText((Join-Path $out "$kind/room-steady.body.html"))
    $first = [IO.File]::ReadAllText((Join-Path $out "$kind/room-first.body.html"))
    $noCsrf = Test-NoCsrf $steady
    # No per-request tokens: the first and the steady room page are the same bytes,
    # with the fragment cache on or off.
    $repeat = $first -ceq $steady
    $allSame = $allSame -and $noCsrf -and $repeat
    "{0,-7} csrf: no-token-markup={1} session-secret-present={2} first==steady={3} (flow --cache-mb {4})" -f $kind, $noCsrf, ($null -ne $csrfSecret), $repeat, $CacheMb
    "{0,-7} loadgen --validate 2 s: ok={1} invalid={2} errors={3}" -f $kind, $results[$kind].ok, $results[$kind].invalid, $results[$kind].errors
}
'''
s = s[:i] + new + s[j:]
rep('''"loadgen bodies identical modulo tokens: {0}" -f (([regex]::Replace([IO.File]::ReadAllText((Join-Path $out 'native/loadgen-body.html')), '(name="authenticity_token" value="|<meta name="csrf-token" content=")[A-Za-z0-9_-]+', '$1<token>')) -ceq ([regex]::Replace([IO.File]::ReadAllText((Join-Path $out 'flow/loadgen-body.html')), '(name="authenticity_token" value="|<meta name="csrf-token" content=")[A-Za-z0-9_-]+', '$1<token>')))''',
    '''$loadgenSame = [IO.File]::ReadAllText((Join-Path $out 'native/loadgen-body.html')) -ceq [IO.File]::ReadAllText((Join-Path $out 'flow/loadgen-body.html'))
$allSame = $allSame -and $loadgenSame
"loadgen bodies identical: {0}" -f $loadgenSame''')
assert "CsrfOracle" not in s
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")
a = '''    let sent = campfire.server.handle(request, context)
    expect sent.status == 200
    expect campfire.server.header-count(sent.headers, "Set-Cookie") == 2
    expect string.contains(sent.body, "first message")
}'''
b = '''    let sent = campfire.server.handle(request, context)
    expect sent.status == 200
    // Only last_room: no CSRF secret means no _campfire_session rewrite (as the Rust reference).
    expect campfire.server.header-count(sent.headers, "Set-Cookie") == 1
    expect match campfire.server.header-last(sent.headers, "set-cookie") { none => false; some value => string.starts-with(value, "last_room=1;") }
    expect string.contains(sent.body, "first message")
    expect bool.not(string.contains(sent.body, "authenticity_token"))
    expect bool.not(string.contains(sent.body, "csrf"))
    // No per-request tokens: the same request renders the same bytes.
    expect campfire.server.handle(request, context).body == sent.body
}'''
assert s.count(a) == 1
p.write_text(s.replace(a, b), encoding="utf-8", newline="")
print("ok")

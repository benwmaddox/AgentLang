from pathlib import Path
p = Path(r"D:\code\AgentLang\docs\WORKER-STORE-PLAN.md")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)


rep('''  - `store.hash(text: String) -> Int`: a 64-bit FNV-1a hash of the bytes, so
    Flow can index keys without a byte loop.''', '''  - `store.hash(text: String) -> Int`: a 64-bit FNV-1a hash of the bytes, so
    Flow can index keys without a byte loop.
  - `store.matches(offset: Int, text: String) -> Bool`: an in-place compare,
    so checking a key copies and validates nothing.
  - `store.ints(offset: Int, count: Int) -> Option<List<Int>>`: reads one
    index slot or one entry header in a single call.
- **Measure first:** before the cache is written, a trusted-O2 micro-benchmark
  of a `store.int` loop sets the per-call cost. With up to about 8 calls per
  lookup and 40 lookups per page, the cache must stay well under the C cache
  it replaces. If host calls are too dear, the coarse reads above carry the
  probe.''')
rep('''- **Body assembly:** the final body is everything written, followed by
  `HttpResponse.body`, so existing apps that write nothing are unchanged. The
  host sets `Content-Length` from the total.''', '''- **Opt-in body assembly:** streamed bytes are used only when the response asks
  for them. `HttpResponse` gains `streamed: Bool`:
  - when it is true, the body is everything written followed by
    `HttpResponse.body`;
  - when it is false (an error, a redirect, a bare 500 from a failed contract
    check), the written bytes are discarded.

  The host sets `Content-Length` from the total, and HEAD sends no body either
  way. `response.discard()` also drops what was written so far. Existing apps
  that never write and never set `streamed` are unchanged.
- **Tests:** `http.streamed-body(response) -> String`, interpreter only, gives
  attached tests the assembled body (written bytes plus `body`), so tests
  assert on the whole page.''')
rep('''- **Header**, fixed at offset 0:
  - `head`, the next write offset in the ring;
  - `tail`, the oldest live entry;''', '''- **Header**, fixed at offset 0:
  - `head`, the next write offset in the ring;
  - `tail`, the oldest live entry;
  - `wrap`, the end of the written span before the last wrap, so `tail` knows
    where to jump to the ring start;
  - `live-bytes` and `live-entries`, so `head == tail` is never ambiguous
    between an empty and a full ring;''')
rep('''  - If `head + n` passes the ring's end, wrap `head` to the ring start. The
    space skipped at the end becomes a dead gap that the tail passes over.''', '''  - If `head + n` passes the ring's end, record `wrap = head` and continue at
    the ring start. The space from `wrap` to the ring's end is a dead gap:
    when `tail` reaches `wrap` it jumps to the ring start.''')
rep('''    sequence number, write the key and value, write the header, then write the
    sequence number last. Then claim an index slot: a free one, else one whose
    entry is stale, else the oldest in the probe window.''', '''    sequence number, write the key and value, write the header, then write the
    sequence number last. Only then advance `head` and the live counts. Then
    claim an index slot: a free one, else one whose entry is stale, else the
    oldest in the probe window.''')
rep('''- **Fetch only what the frame needs first, like the Rust reference**''', '''- **Do not regress the uncached column.** With the store off
  (`store.capacity() == 0`), the room page keeps today's single joined query.
  The narrow-then-load path below runs only with a store. Its misses are loaded
  in one batched query (a JSON list of ids through `json_each`), not one query
  per message. Acceptance: uncached CPU per request is no worse than the 283
  build's.
- **Fetch only what the frame needs first, like the Rust reference**''')
rep('''- `--cache-mb` and `flow_http_cache.c` stay in the tree for now, unused by
  Campfire. They are deleted when nothing else uses them.''', '''- `--cache-mb` and `flow_http_cache.c` stay in the tree for now, unused by
  Campfire. They are deleted when nothing else uses them.
- **Scope:** only the portable Flow server (`applications/campfire/server/`)
  uses the store. The HTTP.sys and .NET hosts have no store operations; their
  shared room path is unchanged.
- `store.read`, `store.write` and `response.write` join the closed effect
  vocabulary.
- Splitting the layout must leave `campfire.views.page` byte-identical; a test
  checks that the page equals head ++ fragments ++ tail.''')
rep('''- **Campfire parity:**''', '''- **Harness:** the parity script's `-CacheMb` and the sweep's `FLOW_CACHE_MB`
  become `--store-mb`. Each lifetime records the per-worker store size in
  `cache-env.txt`, and a store-off run must show zero store traffic in the
  shutdown stats.
- **Campfire parity:**''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

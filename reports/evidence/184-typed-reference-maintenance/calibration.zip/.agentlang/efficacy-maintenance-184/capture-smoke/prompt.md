Coordinator-only help/close smoke; no AI participant, edits or task acceptance.

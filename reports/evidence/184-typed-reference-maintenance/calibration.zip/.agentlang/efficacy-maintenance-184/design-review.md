# Study 184 design review

Review snapshot: 2026-10-10 21:02 UTC. Read-only review; no participant trials,
runtime edits, tests, or network calls were made.

## Finding

The comparison has a sound core: the retained, reset-rich, and F# seeds all use
a nominal `ShipmentId`, matching shipment/store/input/error semantics, and the
same public ingestion contract. Reset-rich shares the common AgentLang seed and
differs by not having the reusable wrapper; it does not lose the nominal ID.
The plan accurately limits this to one held-out task and explicitly says it is
not evidence of vocabulary accumulation across agents. Keep that limitation.

The draft is **not ready to freeze or dispatch**. Minimum remaining work:

1. **Match the prompts and the helper acceptance rule.** The two Flow prompts
   are byte-identical, but F# alone is explicitly asked to add focused tests
   for replay, cross-shipment independence, validation precedence, and batch
   order. Flow additionally names preservation of inherited tests and
   documented error rules, which the F# prompt omits. Give every arm the same
   focused-test and inherited-evidence requirements. The scorer recognizes
   only `shipment.find-scan` / `shipment.scan-lookup-step` in Flow and
   `Shipment.findScan` in F#; the prompts only say to use existing vocabulary
   “where it fits.” Either require each arm to retain and retype its seeded
   lookup helper by its existing name, or make acceptance name-agnostic. Keep
   caller wiring (`ingest` and batch to the typed helper) as separate source
   review evidence; the scorer correctly says signature discovery alone does
   not prove wiring.

2. **Turn preservation, finalization, and recovery labels into evidence.** The
   scorer's `participantSourceUnchanged` compares the candidate before and
   after scoring, so it does not demonstrate participant preservation against
   the seed. The seed preparation manifest currently hashes only the shared
   Flow source and retained helper. Capture a baseline inventory for each
   arm's authored sources, tests, examples, and docs, then attach a reviewed
   seed-to-candidate diff that checks assertion meaning, not just counts. The
   terminal capture script checks `session-end` and exit codes but does not
   require an explicit durable `task.commit` receipt. The scorer's four
   `separateEndpoints` values are descriptive placeholders, and recovery has
   no distinct evidence procedure. Capture commit evidence and define what
   failure/recovery trace plus final snapshot qualifies; otherwise report
   those endpoints as unmeasured.

3. **Complete runtime calibration and freeze a complete input manifest.** The
   four control projects have setup artifacts. I found scorer smoke projects
   for baseline seeds, but no scored mutant-control receipts in the control
   directories; the draft report also says calibration is pending. Before
   launch, record correct control = 18/18; always-append fails replay;
   global dedup fails the
   cross-shipment case; and wrong-self-test global dedup passes its own
   qualification while the independent oracle rejects it. Record setup
   failures rather than dropping controls. Freeze hashes for the model,
   vectors, scorer, task contract, prompts, seed sources, allowlist, and fresh
   CLI together; each score receipt currently includes the vector and scorer
   hashes but not the model hash.

The independent behavior oracle is appropriately separate from participant
tests and compares complete Store/error observations. Type evidence is also
labeled honestly: Flow uses type metadata and `eval` rejection diagnostics,
not a separate compiler; F# uses reflection for metadata plus positive and
negative compile controls. Do not promote either into a claim about caller
wiring without the source review described above.

The report discloses inherited suite sizes (retained 21, reset-rich 18, F# 8
assertions). These are not matched counts; treat preservation relative to each
arm's own baseline and avoid comparing raw test counts as an outcome. They are
a documented setup difference, not evidence that the semantic contracts differ.
The six-actor pilot and exclusions of token, throughput, security, and general
vocabulary-growth claims are appropriately bounded.

## Pins at review time

Tracked `HEAD` is `49a7f30dae4738d0f3ecb0ccee65e3ed96809227`; tracked status was
clean. Study 184 and retention004 files were untracked, so they are draft
inputs, not accepted baseline evidence. Preserve all unrelated untracked
retention004 files.

SHA-256 pins (draft snapshot):

| Input | SHA-256 |
|---|---|
| `study-plan.md` | `01F228979638F8421660A4FE147D9F84E060744FF6D7C99ABE9EC55E18DB2FF2` |
| `task-contract.md` | `FA1DD8D496F0D4F8C2B623BF0A63F614A6AF986647D5AF3CF7D1C965C9A37593` |
| both Flow prompts (identical) | `248BDF0BB97E171C54C029A83F43D6BFDAE7ED3755F6F27C6B7FB6297D80E464` |
| F# prompt | `D93C3B39331E54BC41E11FD80FCA33617EA3EDBA5F4F3A0D647A5DF56A669897` |
| oracle `model.py` | `CE7F674AC361139476C1B21C7EC9A32158BABAC32B385EFEB26C1A552CBA61A8` |
| oracle `cases.json` | `1FF64EFDFF553279D835137CDFF7CEAA6E27C3D4D74FF7F1621DC6F02BEB5E22` |
| oracle `score_reference.py` | `4D444C87FBDCC6968AC6A1EC5406B4E1AD7207E8C88CACDED64816CC63A6FF02` |
| common AgentLang seed | `AD79222EBCAB30F301E6B5062298D177A342C845DBD3781CE2995E38AB41E4B4` |
| retained helper seed | `F393F24071C0D3FE6563E44ADF0CC22445EF8DEC8442FE7705035EABA497513F` |
| F# `Business.fs` seed | `B66B6B2E19D1268E3C36CFAF88EE9C85FB7BB298396E928B6F59644EBBEE3EA8` |

## Delta review

Checked the previous findings again at 2026-10-10 21:06 UTC. The hashes above
are the original 21:02 draft snapshot, not current freeze pins.

The prompt/helper blocker is closed in the current drafts: all three prompts
require the same focused behavior tests and inherited evidence preservation,
and each names the seeded lookup helper to keep and retype. The task contract
also says to preserve seeded helper names while allowing new helpers. The
endpoint-procedure blocker is closed at the plan level: it now requires a
per-candidate baseline-to-final evidence review, observed AgentLang
`task.commit` plus reload verification, distinct F# validation reporting, and
trace-linked recovery records. No changes to those files are needed for this
review.

The coordinator terminal-capture smoke passed with one exchange and host/runtime
exit codes 0/0. It validates the capture/termination path only; it is not a
participant result or evidence that candidate preservation, commit, or recovery
has already been audited.

**The remaining freeze/dispatch blocker is unfinished runtime oracle scoring and
input freezing.** The parent reports four clean control setups with successful
setup responses, while control scoring remains in progress. Do not treat setup
success as calibration: preserve receipts showing the correct control passes
all 18 vectors, each mutant is rejected on its discriminating case, and the
wrong-self-test mutant qualifies locally but is rejected by the independent
oracle. The report discloses the deleted failed setup attempt; do not attempt to
reconstruct it. After scoring, produce and verify one current freeze manifest
covering model, vectors, scorer, contract, all prompts, seeds, allowlist, and
fresh CLI. The prior pin table must not serve as that manifest.

The source-level baseline match and the one-stage vocabulary-growth limitation
remain as assessed above. No tests, participant runs, or other runtime trials
were performed for this delta review.

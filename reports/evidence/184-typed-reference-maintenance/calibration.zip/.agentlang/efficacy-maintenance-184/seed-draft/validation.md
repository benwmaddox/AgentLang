# Seed draft validation

Draft only. Do not freeze or dispatch until milestone 183 is accepted and the
independent oracle controls are calibrated.

## Flow CLI

Command:

```powershell
dotnet build src/AgentLang.Cli/AgentLang.Cli.fsproj -c Release --artifacts-path .agentlang/efficacy-maintenance-184/seed-draft/build -m:1 -p:NuGetAudit=false
```

Exit: `0`; build succeeded with 0 warnings and 0 errors. Temporary files were
directed to `seed-draft/tmp`.

## AgentLang seed projects

Command:

```powershell
pwsh -NoProfile -File experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/prepare_seeds.ps1 -FlowCliDll .agentlang/efficacy-maintenance-184/seed-draft/build/bin/AgentLang.Cli/release/AgentLang.Cli.dll -DraftId draft-008
```

Exit: `0`. The run produced
`projects/draft-008/seed-draft-manifest.json`, which records setup history and
full test/example responses. Retained AgentLang passed 21/21 tests; reset-rich
AgentLang passed 18/18. Each public entry example passed in each arm, as did
the retained lookup example. History lookup returned one durable revision for
`shipment.ingest` in both projects.

## F# seed

Command:

```powershell
dotnet build experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/seeds/fsharp/project/tests/AgentLang.TypedReference.Tests.fsproj -c Release --artifacts-path .agentlang/efficacy-maintenance-184/seed-draft/fsharp-build -m:1 -p:NuGetAudit=false
dotnet .agentlang/efficacy-maintenance-184/seed-draft/fsharp-build/bin/AgentLang.TypedReference.Tests/release/AgentLang.TypedReference.Tests.dll
```

Exit: `0` for both commands. Build succeeded with 0 warnings and 0 errors;
the test harness reported `Shipment baseline: 8 assertions`.

## Accepted-183 oracle controls

Using the fresh accepted-revision CLI at
`.agentlang/efficacy-maintenance-184/accepted-build/bin/AgentLang.Cli/release/AgentLang.Cli.dll`:

```powershell
python experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/seeds/controls/prepare_controls.py --cli .agentlang/efficacy-maintenance-184/accepted-build/bin/AgentLang.Cli/release/AgentLang.Cli.dll
```

Exit: `0`. The four isolated project setup sessions each exited `0`, had no
failed CLI responses, passed their attached test suites, and completed
`task.commit`. Detailed JSONL transcripts, responses, per-project source
inventories, and hashes are in
`.agentlang/efficacy-maintenance-184/seed-draft/controls/control-manifest.json`.

| Control | Project | Attached tests |
| --- | --- | ---: |
| Correct per-shipment idempotence | `controls/correct/project` | 25/25 |
| Always append (matching incorrect replay test) | `controls/always-append/project` | 22/22 |
| Store-wide deduplication | `controls/global-dedup/project` | 25/25 |
| Store-wide deduplication (matching incorrect cross-shipment test) | `controls/global-dedup-wrong-selftests/project` | 26/26 |

The independent oracle scorer must still reject the three mutants on their
designed vectors; these setup and self-test receipts alone are not calibration.

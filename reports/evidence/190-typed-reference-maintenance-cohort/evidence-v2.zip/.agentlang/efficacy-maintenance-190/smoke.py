import hashlib, json, shutil, subprocess
from pathlib import Path
repo = Path('D:/code/AgentLang')
base = repo / '.agentlang/efficacy-maintenance-190/smoke-002'
assert not base.exists(), 'Refuse overwriting smoke evidence'
gate = json.loads((repo / '.agentlang/efficacy-maintenance-184/dispatch-gate.json').read_text())
rows = []
for arm in ['retained', 'reset-rich', 'fsharp']:
    source = repo / gate['seeds'][arm]
    destination = base / arm
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns('bin', 'obj', '__pycache__', 'WRITE.lock'))
    if arm == 'fsharp':
        cli = repo / '.agentlang/efficacy-maintenance-190/conventional-build/bin/AgentLang.Conventional.Cli/release/AgentLang.Conventional.Cli.dll'
        arguments = ['dotnet', str(cli), '--project', str(destination), '--validation-project', 'tests/AgentLang.TypedReference.Tests.fsproj', '--jsonl']
        request = {'op': 'validate'}
    else:
        cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
        arguments = ['dotnet', str(cli), '--project', str(destination), '--jsonl', '--clock', '2000-01-01T00:00:00Z']
        request = {'op': 'test-all'}
    process = subprocess.run(arguments, input=json.dumps(request)+'\n', text=True, encoding='utf-8', capture_output=True, cwd=repo, timeout=150)
    (destination.parent / (arm+'.stdout.txt')).write_text(process.stdout, encoding='utf-8')
    (destination.parent / (arm+'.stderr.txt')).write_text(process.stderr, encoding='utf-8')
    responses = [json.loads(line) for line in process.stdout.splitlines() if line.strip()]
    assert process.returncode == 0 and len(responses) == 1 and responses[0]['ok'], (arm, process.returncode, process.stderr, responses)
    response = responses[0]
    if arm != 'fsharp':
        tests = response['data']['results']
        expected_count = 21 if arm == 'retained' else 18
        assert len(tests) == expected_count and all(row['passed'] for row in tests), (arm, tests)
    rows.append({'arm': arm, 'command': arguments, 'exitCode': process.returncode, 'response': response, 'cliSha256': hashlib.sha256(cli.read_bytes()).hexdigest()})
(base/'receipt.json').write_text(json.dumps({'status':'passed', 'checks':rows}, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status':'passed', 'arms':[row['arm'] for row in rows]}))

from pathlib import Path
R = Path(r"D:\code\AgentLang\scripts")
p = R / "Test-CampfireFlowServerParity.ps1"
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


i = s.index("    # The Flow server's --cache-mb (0 = no cache).")
j = s.index("    [int] $CacheMb = 32", i)
s = s[:i] + '''    # The Flow server's --store-mb total (0 = no worker store, split between its
    # 4 workers). With a store the room page is streamed through the worker
    # cache (docs/WORKER-STORE-PLAN.md); bodies still match the native host
    # byte for byte. The process-wide --cache-mb cache stays off.
    [int] $StoreMb = 32''' + s[j + len("    [int] $CacheMb = 32"):]
rep(''''--allow-control', '--cache-mb', "$CacheMb")''', ''''--allow-control', '--cache-mb', '0', '--store-mb', "$StoreMb")''')
rep('''(Split-Path -Leaf $out), "$CacheMb")''', '''(Split-Path -Leaf $out), "$StoreMb")''')
rep('''first==steady={3} (flow --cache-mb {4})" -f $kind, $noCsrf, ($null -ne $csrfSecret), $repeat, $CacheMb''',
    '''first==steady={3} (flow --store-mb {4})" -f $kind, $noCsrf, ($null -ne $csrfSecret), $repeat, $StoreMb''')
k = s.index('''if (Test-Path $flowServerLog) {''')
end = s.index("\n", k)
s = s[:k] + '''if (Test-Path $flowServerLog) {
    "flow    {0}" -f ((Select-String -LiteralPath $flowServerLog -Pattern 'STOPPED' | Select-Object -Last 1).Line -replace '^.*(cache-mb=.*)$', '$1')
    foreach ($line in (Select-String -LiteralPath $flowServerLog -Pattern '^worker \\d+: ')) { "flow    {0}" -f ($line.Line -replace '^(worker \\d+): .*(store-bytes=\\d+ store-pages-used=\\d+).*$', '$1 $2') }
}''' + s[end:]
p.write_text(s, encoding="utf-8", newline="")

p = R / "campfire-flow-parity-linux.sh"
s = p.read_text(encoding="utf-8")
a = 'RUN=${10}; CACHE_MB=${11:-32}'
assert a in s
s = s.replace(a, 'RUN=${10}; STORE_MB=${11:-32}')
a = '--allow-control --cache-mb "$CACHE_MB"'
assert a in s
s = s.replace(a, '--allow-control --cache-mb 0 --store-mb "$STORE_MB"')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
p = Path(r"D:\code\AgentLang\src\AgentLang.Llvm\native\http_host\flow_http_host.c")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep("  if (worker->stream == 0 || (options->store_bytes > 0u && worker->store == 0)) return -1;\n",
    "  if (worker->stream == 0 || (options->store_bytes > 0u && worker->store == 0)) { worker->state = -1; goto done; }\n")
rep('''  if (!fh_load_config(&options)) return 2;''', '''  /* The store total is split evenly between workers, in whole 16 KB pages. */
  options.store_bytes = (((uint64_t)options.store_mb << 20) / (uint64_t)options.workers) & ~(uint64_t)16383u;
  if (!fh_load_config(&options)) return 2;''')
rep('''"       [--arena-mb N] [--retained-mb N] [--max-body-kb N] [--cache-mb N] [--allow-control]\\n"''',
    '''"       [--arena-mb N] [--retained-mb N] [--max-body-kb N] [--cache-mb N] [--store-mb N] [--allow-control]\\n"''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")
a = '''        if bool.not(worker-cache.write-to-response(cache, cache-key)) {
            match campfire.server.find-message(loaded, key.id) {
                none => {
                    written = false
                }
                some message => {
                    let text = campfire.views.text(campfire.views.rails-message(context, message))
                    written = written && response.write(text)
                    rendered = list.append(rendered, text)
                    rendered-keys = list.append(rendered-keys, cache-key)
                }
            }
        }'''
b = '''        if bool.not(worker-cache.write-to-response(cache, cache-key)) {
            let found = campfire.server.find-message(loaded, key.id)
            if found == option.none<MessageWithCreator>() {
                written = false
            } else {
                let text = match found {
                    none => ""
                    some message => campfire.views.text(campfire.views.rails-message(context, message))
                }
                written = written && response.write(text)
                rendered = list.append(rendered, text)
                rendered-keys = list.append(rendered-keys, cache-key)
            }
        }'''
assert s.count(a) == 1
p.write_text(s.replace(a, b), encoding="utf-8", newline="")
print("ok")

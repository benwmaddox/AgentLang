from pathlib import Path
p = Path(r"D:\code\AgentLang\src\stdlib\worker-cache.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''            var place = -1
            var sound = true
            for step in 0..live + 3 {''', '''            var place = -1
            var sound = true
            let steps = live + 3
            for step in 0..steps {''')
rep('''    let small = "0123456789012345678901234567890123456789"
    var i = 0
    for n in 0..60 {
        expect worker-cache.put(cache, string.concat("s", int.to-string(n)), small)
    }
    let before''', '''    let small = "0123456789012345678901234567890123456789"
    var stored = 0
    for n in 0..60 {
        if worker-cache.put(cache, string.concat("s", int.to-string(n)), small) {
            stored = stored + 1
        }
    }
    expect stored == 60
    let before''')
rep('''fn worker-cache.not-ready(base: Int) -> WorkerCache {
''', '''fn worker-cache.not-ready(base: Int) -> WorkerCache {
    doc "A cache that every operation treats as absent."
''')
s += '''
test worker-cache.magic/nonzero {
    expect worker-cache.magic() != 0
}

test worker-cache.not-ready/absent {
    let cache = worker-cache.not-ready(0)
    expect bool.not(cache.ready)
    expect worker-cache.find(cache, "k") == option.none<CacheEntry>()
    expect bool.not(worker-cache.put(cache, "k", "v"))
}

test worker-cache.slot-of/wraps-negative-hashes {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.slot-of(cache, -1, 0) == cache.index + 63 * 24
    expect worker-cache.slot-of(cache, 5, 60) == cache.index + 1 * 24
}

test worker-cache.find/miss-on-empty {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.find(cache, "nothing") == option.none<CacheEntry>()
}

test worker-cache.write-to-response/hit-writes-value {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.put(cache, "k", "<b>v</b>")
    expect worker-cache.write-to-response(cache, "k")
    expect response.written(0) == "<b>v</b>"
}

test worker-cache.text/hit {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.put(cache, "k", "v")
    expect worker-cache.text(cache, "k") == option.some<String>("v")
}

test worker-cache.bytes/hit {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.put(cache, "k", "v")
    expect worker-cache.bytes(cache, "k") == option.some<Bytes>(bytes.from-utf8("v"))
}

test worker-cache.unindex/frees-slot {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.put(cache, "k", "v")
    expect worker-cache.unindex(cache, cache.ring-start, 1, store.hash("k"))
    expect worker-cache.find(cache, "k") == option.none<CacheEntry>()
}

test worker-cache.claim-slot/free-first {
    let cache = worker-cache.open(0, 16384)
    expect worker-cache.claim-slot(cache, 7) == worker-cache.slot-of(cache, 7, 0)
    expect worker-cache.put(cache, "k", "v")
    expect worker-cache.claim-slot(cache, store.hash("k")) == worker-cache.slot-of(cache, store.hash("k"), 1)
}

test worker-cache.stats/empty {
    let stats = worker-cache.stats(worker-cache.open(0, 16384))
    expect stats.entries == 0 && stats.bytes == 0 && stats.capacity == 16384 - 1664 && stats.pages-in-use == 1
}
'''
p.write_text(s, encoding="utf-8", newline="")

p = Path(r"D:\code\AgentLang\src\stdlib\store.flow")
s = p.read_text(encoding="utf-8")
s += '''
test store.size/test-store {
    expect store.size() == 262144
}

test response.write-html/appends {
    expect response.write-html(html"<i>x</i>")
    expect response.written(0) == "<i>x</i>"
}
'''
p.write_text(s, encoding="utf-8", newline="")
print("ok")

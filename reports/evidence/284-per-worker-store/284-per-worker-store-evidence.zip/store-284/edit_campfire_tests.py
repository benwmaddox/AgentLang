from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


USER = 'authUser.new(id = UserId.new(1), name = "Ann", role = Role.member(), status = AuthUserStatus.active())'
ROOM = 'roomRow.new(id = RoomId.new(1), name = option.some<String>("Lobby"), kind = RoomKind.open(), creator-id = UserId.new(1), created-at = "2026-01-01 00:00:00", updated-at = "2026-01-01 00:00:00")'

rep('''    let shown = campfire.server.show-room(campfire.server.test-request(option.none<String>()), user, room, option.none<SessionToken>(), campfire.server.test-context())
    expect shown.status == 200
    expect shown.last-room == option.some<RoomId>(RoomId.new(1))
    expect shown.new-csrf-token == option.none<String>()
    expect bool.not(string.contains(shown.body, "authenticity_token"))
    expect string.contains(shown.body, "second message")
}''', '''    let shown = campfire.server.show-room(campfire.server.test-request(option.none<String>()), user, room, option.none<SessionToken>(), campfire.server.test-context())
    expect shown.status == 200
    expect shown.last-room == option.some<RoomId>(RoomId.new(1))
    expect shown.new-csrf-token == option.none<String>()
    // Attached tests have a worker store, so the page went to the response stream.
    expect shown.body == ""
    let page = response.written(0)
    expect bool.not(string.contains(page, "authenticity_token"))
    expect string.contains(page, "second message")
    // Byte-identical to the one-piece page, cold and then from the worker cache.
    let whole = match campfire.server.page-for-member(user.id, room.id, campfire.server.test-context()) {
        error failure => ""
        ok messages => campfire.views.creator-room-page(campfire.views.room-chrome(room, user, "http://127.0.0.1:13773"), messages)
    }
    expect page == whole
    expect response.discard(0) == string.byte-length(whole)
    expect campfire.server.show-room(campfire.server.test-request(option.none<String>()), user, room, option.none<SessionToken>(), campfire.server.test-context()).body == ""
    expect response.written(0) == whole
    expect worker-cache.stats(campfire.server.worker-cache()).entries == 2
}

test campfire.server.worker-cache/ready-in-tests {
    expect campfire.server.worker-cache().ready
}

test campfire.server.missing-ids/only-uncached {
    let cache = campfire.server.worker-cache()
    let keys = [pageKey.new(id = 1, updated-at-ms = 5), pageKey.new(id = 2, updated-at-ms = 6)]
    expect campfire.server.missing-ids(cache, keys) == [1, 2]
    expect worker-cache.put(cache, campfire.server.fragment-key(1, 5), "<one>")
    expect campfire.server.missing-ids(cache, keys) == [2]
}

test campfire.server.write-messages/hits-and-misses-in-order {
    let cache = campfire.server.worker-cache()
    expect worker-cache.put(cache, campfire.server.fragment-key(1, 5), "<one>")
    let message = messageWithCreator.new(id = MessageId.new(2), room-id = RoomId.new(1), creator-id = UserId.new(1), created-at-ms = 0, updated-at-ms = 6, client-message-id = "c2", created-at = "2026-01-01 00:00:00", creator-name = "Ann", creator-bio = "", creator-updated-at = "2026-01-01 00:00:00", creator-avatar-token = "t", body = option.some<String>("two"))
    let context = messageContext.new(room-id = "1", room-name = "Lobby", base-url = "http://x")
    let page = campfire.server.write-messages(cache, context, [pageKey.new(id = 1, updated-at-ms = 5), pageKey.new(id = 2, updated-at-ms = 6)], [message])
    expect page.written
    expect page.rendered-keys == [campfire.server.fragment-key(2, 6)]
    expect response.written(0) == string.concat("<one>", campfire.views.text(campfire.views.rails-message(context, message)))
    let missing = campfire.server.write-messages(cache, context, [pageKey.new(id = 3, updated-at-ms = 1)], list.empty<MessageWithCreator>())
    expect bool.not(missing.written)
}

test campfire.server.store-fragments/stores-rendered {
    let cache = campfire.server.worker-cache()
    let page = streamedPage.new(written = true, rendered = ["<a>", "<b>"], rendered-keys = ["ka", "kb"])
    expect campfire.server.store-fragments(cache, page) == 2
    expect worker-cache.text(cache, "kb") == option.some<String>("<b>")
}

test campfire.server.stream-room-page/fixture {
    expect campfire.server.test-fixture() == 0
    let cache = campfire.server.worker-cache()
    let chrome = campfire.views.room-chrome(''' + ROOM + ''', ''' + USER + ''', "http://x")
    let keys = match campfire.server.page-keys-query(RoomId.new(1)) { error failure => list.empty<PageKey>(); ok found => found }
    expect campfire.server.stream-room-page(chrome, keys, cache, campfire.server.test-context().avatar-key) == result.ok<Int, DbError>(2)
    expect string.contains(response.written(0), "first message")
    expect response.discard(0) > 0
    expect campfire.server.stream-room-page(chrome, keys, cache, campfire.server.test-context().avatar-key) == result.ok<Int, DbError>(0)
}

test campfire.server.streamed-page-for-member/membership {
    expect campfire.server.test-fixture() == 0
    let cache = campfire.server.worker-cache()
    let chrome = campfire.views.room-chrome(''' + ROOM + ''', ''' + USER + ''', "http://x")
    expect campfire.server.streamed-page-for-member(UserId.new(1), chrome, RoomId.new(1), cache, campfire.server.test-context()) == result.ok<Int, RoomMessageError>(2)
    expect campfire.server.streamed-page-for-member(UserId.new(2), chrome, RoomId.new(1), cache, campfire.server.test-context()) == result.error<Int, RoomMessageError>(RoomMessageError.access-denied())
}''')

rep('''    let sent = campfire.server.handle(request, context)
    expect sent.status == 200
    // Only last_room: no CSRF secret means no _campfire_session rewrite (as the Rust reference).
    expect campfire.server.header-count(sent.headers, "Set-Cookie") == 1
    expect match campfire.server.header-last(sent.headers, "Set-Cookie") { none => false; some value => string.starts-with(value, "last_room=1;") }
    expect string.contains(sent.body, "first message")
    expect bool.not(string.contains(sent.body, "authenticity_token"))
    expect bool.not(string.contains(sent.body, "csrf"))
    // No per-request tokens: the same request renders the same bytes.
    expect campfire.server.handle(request, context).body == sent.body
}''', '''    let sent = campfire.server.handle(request, context)
    expect sent.status == 200
    // Only last_room: no CSRF secret means no _campfire_session rewrite (as the Rust reference).
    expect campfire.server.header-count(sent.headers, "Set-Cookie") == 1
    expect match campfire.server.header-last(sent.headers, "Set-Cookie") { none => false; some value => string.starts-with(value, "last_room=1;") }
    // The page went to the response stream (attached tests have a worker store).
    expect sent.streamed && sent.body == ""
    let page = response.written(0)
    expect string.contains(page, "first message")
    expect bool.not(string.contains(page, "authenticity_token"))
    expect bool.not(string.contains(page, "csrf"))
    // No per-request tokens: the same request renders the same bytes, now from the worker cache.
    expect response.discard(0) == string.byte-length(page)
    expect campfire.server.handle(request, context).streamed
    expect response.written(0) == page
}''')
p.write_text(s, encoding="utf-8", newline="")

p = Path(r"D:\code\AgentLang\applications\campfire\server\server-db-tests.flow")
t = p.read_text(encoding="utf-8")
t += '''
test campfire.server.page-keys-query/fixture {
    expect campfire.server.test-fixture() == 0
    expect campfire.server.page-keys-query(RoomId.new(1)) == result.ok<List<PageKey>, DbError>([pageKey.new(id = 1, updated-at-ms = 1791972000250), pageKey.new(id = 2, updated-at-ms = 1791972300000)])
    expect campfire.server.page-keys-query(RoomId.new(9)) == result.error<List<PageKey>, DbError>(DbError.not-found())
}

test campfire.server.messages-by-id/only-requested {
    expect campfire.server.test-fixture() == 0
    let loaded = campfire.server.messages-by-id([2], bytes.from-utf8("key"))
    expect match loaded { error failure => -1; ok messages => list.count(messages) } == 1
    expect match loaded { error failure => ""; ok messages => match list.get(messages, 0) { none => ""; some message => match message.body { none => ""; some text => text } } } == "second message"
    expect campfire.server.messages-by-id(list.empty<Int>(), bytes.from-utf8("key")) == result.ok<List<MessageWithCreator>, DbError>(list.empty<MessageWithCreator>())
}
'''
p.write_text(t, encoding="utf-8", newline="")
print("ok")

import re
from pathlib import Path
R = Path(r"D:\code\AgentLang")


def rw(rel, f):
    p = R / rel
    s = p.read_text(encoding="utf-8")
    t = f(s)
    assert t != s, rel
    p.write_text(t, encoding="utf-8", newline="")


def http(s):
    a = """record HttpResponse {
    status: Int
    headers: List<HttpHeader>
    body: String
}"""
    assert a in s
    s = s.replace(a, """// streamed: the body is this request's response stream (response.write,
// response.write-store; src/stdlib/store.flow) followed by `body`. When false
// the stream is discarded, so an error or redirect built after partial writes
// never carries them.
record HttpResponse {
    status: Int
    headers: List<HttpHeader>
    body: String
    streamed: Bool
}""")
    a = '''    httpResponse.new(status = status, headers = [httpHeader.new(name = "content-type", value = content-type)], body = body)
}'''
    assert a in s
    s = s.replace(a, '''    httpResponse.new(status = status, headers = [httpHeader.new(name = "content-type", value = content-type)], body = body, streamed = false)
}

fn http.streamed(status: Int, headers: List<HttpHeader>, tail: String) -> HttpResponse {
    doc "A response whose body is the response stream written so far, then tail."
    httpResponse.new(status = status, headers = headers, body = tail, streamed = true)
}''')
    return s


rw("src/stdlib/http.flow", http)


def add_streamed_false(s):
    # Every httpResponse.new(...) call: append `, streamed = false` before its closing parenthesis.
    out, i, key = [], 0, "httpResponse.new("
    while (j := s.find(key, i)) >= 0:
        k = j + len(key) - 1
        depth, q, m = 0, False, k
        while True:
            c = s[m]
            if q:
                if c == "\\": m += 1
                elif c == '"': q = False
            elif c == '"': q = True
            elif c == "(": depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0: break
            m += 1
        inner = s[k + 1:m]
        if "streamed =" not in inner:
            trail = inner.rstrip()
            ws = inner[len(trail):]
            inner = trail + ", streamed = false" + ws
        out.append(s[i:k + 1] + inner)
        i = m
    out.append(s[i:])
    return "".join(out)


for rel in ("applications/campfire/server/server-request.flow", "applications/campfire/server/server.flow", "tests/AgentLang.FlowHttp.Tests/app/counter.flow"):
    rw(rel, add_streamed_false)
print("ok")

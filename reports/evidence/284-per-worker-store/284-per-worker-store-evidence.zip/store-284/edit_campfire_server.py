from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


# Key from (id, updated_at) so the narrow page can build it.
rep('''fn campfire.server.message-cache-key(message: MessageWithCreator) -> String {
    doc "The Rails key of `cache [ message, presentation-v3 ]` with the record's cache version folded in (the cache keeps the first value per key): <template version>/messages/<id>-<updated_at ms>/presentation-v3."
    let record = string.concat(string.concat(string.concat("messages/", int.to-string(MessageId.value(message.id))), "-"), int.to-string(message.updated-at-ms))
    cache.key([campfire.server.message-template-version(), record, "presentation-v3"])
}''', '''fn campfire.server.message-cache-key(message: MessageWithCreator) -> String {
    doc "The Rails key of `cache [ message, presentation-v3 ]` with the record's cache version folded in (the cache keeps the first value per key): <template version>/messages/<id>-<updated_at ms>/presentation-v3."
    campfire.server.fragment-key(MessageId.value(message.id), message.updated-at-ms)
}

fn campfire.server.fragment-key(id: Int, updated-at-ms: Int) -> String {
    doc "campfire.server.message-cache-key from a message id and its updated_at (ms)."
    let record = string.concat(string.concat(string.concat("messages/", int.to-string(id)), "-"), int.to-string(updated-at-ms))
    cache.key([campfire.server.message-template-version(), record, "presentation-v3"])
}

test campfire.server.fragment-key/same-as-message-key {
    expect campfire.server.fragment-key(3, 9) == "views/messages/_message:flow-2/messages/3-9/presentation-v3"
}''')

stream_code = '''
// ------------------------------------------------------ worker-store page
//
// With a worker store (--store-mb), the room page is written in order to the
// response stream: the layout head, each message's fragment, the layout tail.
// Fragments live in the worker cache (src/stdlib/worker-cache.flow) under the
// same Rails key as above. As in the Rust reference (Message::last_page, then
// presenter.message() only on a miss), the page first reads just the forty
// ids and updated_at values; creators, bodies and avatar tokens are loaded,
// in one query, only for the messages whose fragment is missing. A hit is
// copied from the store straight to the output. New fragments are stored
// after the page is written, so no put can evict a hit before it is sent.

fn campfire.server.worker-cache() -> WorkerCache {
    effects store.read, store.write
    doc "The worker cache over the whole worker store; not ready when the host gives no store."
    worker-cache.open(0, store.size())
}

fn campfire.server.find-message(messages: List<MessageWithCreator>, id: Int) -> Option<MessageWithCreator> {
    doc "The message with this id, if loaded."
    var found = option.none<MessageWithCreator>()
    for message in messages {
        if MessageId.value(message.id) == id {
            found = option.some<MessageWithCreator>(message)
            break
        }
    }
    found
}

test campfire.server.find-message/by-id {
    let message = messageWithCreator.new(id = MessageId.new(7), room-id = RoomId.new(1), creator-id = UserId.new(1), created-at-ms = 0, updated-at-ms = 0, client-message-id = "c", created-at = "", creator-name = "", creator-bio = "", creator-updated-at = "", creator-avatar-token = "", body = option.none<String>())
    expect campfire.server.find-message([message], 7) == option.some<MessageWithCreator>(message)
    expect campfire.server.find-message([message], 8) == option.none<MessageWithCreator>()
}

fn campfire.server.missing-ids(cache: WorkerCache, keys: List<PageKey>) -> List<Int> {
    effects store.read
    doc "The page's message ids whose fragment is not in the worker cache."
    var missing = list.empty<Int>()
    for key in keys {
        if worker-cache.find(cache, campfire.server.fragment-key(key.id, key.updated-at-ms)) == option.none<CacheEntry>() {
            missing = list.append(missing, key.id)
        }
    }
    missing
}

record StreamedPage {
    written: Bool
    rendered: List<String>
    rendered-keys: List<String>
}

fn campfire.server.write-messages(cache: WorkerCache, context: MessageContext, keys: List<PageKey>, loaded: List<MessageWithCreator>) -> StreamedPage {
    effects store.read, response.write
    doc "Writes each message's fragment to the response stream in page order: a hit straight from the store, a miss rendered from the loaded rows. Returns the rendered fragments and their keys for storing afterwards; written is false when a fragment could not be written."
    var written = true
    var rendered = list.empty<String>()
    var rendered-keys = list.empty<String>()
    for key in keys {
        let cache-key = campfire.server.fragment-key(key.id, key.updated-at-ms)
        if bool.not(worker-cache.write-to-response(cache, cache-key)) {
            match campfire.server.find-message(loaded, key.id) {
                none => {
                    written = false
                }
                some message => {
                    let text = campfire.views.text(campfire.views.rails-message(context, message))
                    written = written && response.write(text)
                    rendered = list.append(rendered, text)
                    rendered-keys = list.append(rendered-keys, cache-key)
                }
            }
        }
    }
    streamedPage.new(written = written, rendered = rendered, rendered-keys = rendered-keys)
}

fn campfire.server.store-fragments(cache: WorkerCache, page: StreamedPage) -> Int {
    effects store.read, store.write
    doc "Stores the fragments a page rendered; returns how many were stored."
    var stored = 0
    for key, index in page.rendered-keys {
        let text = match list.get(page.rendered, index) { none => ""; some value => value }
        if worker-cache.put(cache, key, text) {
            stored = stored + 1
        }
    }
    stored
}

fn campfire.server.stream-room-page(chrome: PageChrome, keys: List<PageKey>, cache: WorkerCache, avatar-key: Bytes) -> Result<Int, DbError> {
    effects db.read, store.read, store.write, response.write
    doc "Writes the whole room page to the response stream (head, fragments, tail) and stores the fragments it rendered. Ok holds how many were stored; an error leaves a partial stream that the caller's non-streamed error response drops."

    let missing = campfire.server.missing-ids(cache, keys)
    match campfire.server.messages-by-id(missing, avatar-key) {
        error failure => result.error<Int, DbError>(failure)
        ok loaded => {
            let context = messageContext.new(room-id = chrome.room-id, room-name = chrome.room-name, base-url = chrome.base-url)
            let head = response.write-html(campfire.views.page-head(chrome))
            let page = campfire.server.write-messages(cache, context, keys, loaded)
            let tail = response.write-html(campfire.views.page-tail(chrome))
            if head && page.written && tail {
                result.ok<Int, DbError>(campfire.server.store-fragments(cache, page))
            } else {
                result.error<Int, DbError>(DbError.unavailable())
            }
        }
    }
}

fn campfire.server.streamed-page-for-member(user-id: UserId, chrome: PageChrome, room-id: RoomId, cache: WorkerCache, context: CampfireServerContext) -> Result<Int, RoomMessageError> {
    effects db.read, db.write, store.read, store.write, response.write
    doc "campfire.server.page-for-member for the worker-store page: membership, then the narrow page and its misses in one deferred transaction, written to the response stream."

    match campfire.membership.exists?(membershipKey.new(user-id = user-id, room-id = room-id)) {
        error failure => result.error<Int, RoomMessageError>(campfire.server.room-message-error(failure))
        ok is-member => {
            if bool.not(is-member) {
                result.error<Int, RoomMessageError>(RoomMessageError.access-denied())
            } else {
                match db.execute("BEGIN DEFERRED", list.empty<DbValue>()) {
                    error failure => result.error<Int, RoomMessageError>(campfire.server.room-message-error(campfire.server.db-error(failure)))
                    ok begun => {
                        let written = match campfire.server.page-keys-query(room-id) {
                            error failure => result.error<Int, DbError>(failure)
                            ok keys => campfire.server.stream-room-page(chrome, keys, cache, context.avatar-key)
                        }
                        match written {
                            error failure => {
                                campfire.server.rollback()
                                result.error<Int, RoomMessageError>(campfire.server.room-message-error(failure))
                            }
                            ok stored => match db.execute("COMMIT", list.empty<DbValue>()) {
                                error failure => {
                                    campfire.server.rollback()
                                    result.error<Int, RoomMessageError>(campfire.server.room-message-error(campfire.server.db-error(failure)))
                                }
                                ok committed => result.ok<Int, RoomMessageError>(stored)
                            }
                        }
                    }
                }
            }
        }
    }
}

fn campfire.server.show-room('''
rep('''
fn campfire.server.show-room(''', stream_code)

# show-room: use the streamed path when the worker cache is ready.
rep('''    match campfire.server.page-for-member(user.id, room.id, context) {
        error failure => campfire.server.response(500, HttpView.empty(), "", refresh)
        ok messages => {''', '''    let cache = campfire.server.worker-cache()
    let remember-room = match request.last-room {
        none => option.some<RoomId>(room.id)
        some prior => {
            if prior == int.to-string(RoomId.value(room.id)) {
                option.none<RoomId>()
            } else {
                option.some<RoomId>(room.id)
            }
        }
    }
    if cache.ready {
        // The page goes to the response stream; an empty room body marks it streamed.
        match campfire.server.streamed-page-for-member(user.id, campfire.views.room-chrome(room, user, request.base-url), room.id, cache, context) {
            error failure => campfire.server.response(500, HttpView.empty(), "", refresh)
            ok stored => campfireHttpResponse.new(
                status = 200,
                view = HttpView.room(),
                text = "",
                room = option.some<RoomRow>(room),
                message = option.none<MessageRow>(),
                refresh-session-token = refresh,
                remember-return-to = false,
                last-room = remember-room,
                new-csrf-token = option.none<String>(),
                body = "")
        }
    } else {
    match campfire.server.page-for-member(user.id, room.id, context) {
        error failure => campfire.server.response(500, HttpView.empty(), "", refresh)
        ok messages => {''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

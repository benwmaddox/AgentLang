import re
from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:70], s.count(a))
    s = s.replace(a, b)


rep('''    } else {
    match campfire.server.page-for-member(user.id, room.id, context) {
        error failure => campfire.server.response(500, HttpView.empty(), "", refresh)
        ok messages => {
            let remember-room = match request.last-room {
                none => option.some<RoomId>(room.id)
                some prior => {
                    if prior == int.to-string(RoomId.value(room.id)) {
                        option.none<RoomId>()
                    } else {
                        option.some<RoomId>(room.id)
                    }
                }
            }
            campfireHttpResponse.new(''', '''    } else {
        match campfire.server.page-for-member(user.id, room.id, context) {
            error failure => campfire.server.response(500, HttpView.empty(), "", refresh)
            ok messages => campfireHttpResponse.new(''')
rep('''                new-csrf-token = option.none<String>(),
                body = campfire.server.cached-room-page(campfire.views.room-chrome(room, user, request.base-url), messages))
        }
    }
}''', '''                new-csrf-token = option.none<String>(),
                body = campfire.views.creator-room-page(campfire.views.room-chrome(room, user, request.base-url), messages))
        }
    }
}''')
rep('''fn campfire.server.show-room(request: CampfireHttpRequest, user: AuthUser, room: RoomRow, refresh: Option<SessionToken>, context: CampfireServerContext) -> CampfireHttpResponse {
    effects db.read, db.write, cache.read, cache.write
    doc "campfire.http.show-room: the newest forty messages; last_room is set only when the cookie differs."''',
    '''fn campfire.server.show-room(request: CampfireHttpRequest, user: AuthUser, room: RoomRow, refresh: Option<SessionToken>, context: CampfireServerContext) -> CampfireHttpResponse {
    effects db.read, db.write, store.read, store.write, response.write
    doc "campfire.http.show-room: the newest forty messages; last_room is set only when the cookie differs. With a worker store the page is written to the response stream through the worker cache (the response body is then empty); without one it is rendered in one piece."''')

# Remove the process-wide-cache page (fragment cache through cache.get/put): unused now.
start = s.index("fn campfire.server.message-fragment(")
end = s.index("// ------------------------------------------------------ worker-store page")
s = s[:start] + s[end:]

# Effects up the room chain.
s = s.replace("effects db.read, db.write, cache.read, cache.write\n    doc \"campfire.http.room-read-route", "effects db.read, db.write, store.read, store.write, response.write\n    doc \"campfire.http.room-read-route")
s = s.replace("effects db.read, db.write, cache.read, cache.write\n    doc \"campfire.http.room-read for", "effects db.read, db.write, store.read, store.write, response.write\n    doc \"campfire.http.room-read for")
rep('''    effects db.read, db.write, cache.read, cache.write, random.read
    doc "GET/HEAD /rooms/<id>: transport checks, the room-read chain, then the rendered response with its cookies."''',
    '''    effects db.read, db.write, store.read, store.write, response.write, random.read
    doc "GET/HEAD /rooms/<id>: transport checks, the room-read chain, then the rendered response with its cookies."''')

# http-response: a room response with an empty body was written to the stream.
rep('''                httpResponse.new(status = response.status, headers = list.concat(located, cookies), body = response.body, streamed = false)''',
    '''                // campfire.server.show-room leaves a room body empty when it wrote the page to the response stream.
                httpResponse.new(status = response.status, headers = list.concat(located, cookies), body = response.body, streamed = response.view == HttpView.room() && response.body == "")''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")
for m in re.finditer(r"effects [^\n]*cache\.(read|write)[^\n]*", s):
    print("left:", m.group(0))
print("message-fragment" in s, "cached-room-page" in s, "messages-slot" in s)

from pathlib import Path
D = Path(r"D:\code\AgentLang\src\AgentLang.Llvm\native\http_host")


def rw(name, pairs):
    p = D / name
    s = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (name, a[:70], s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8", newline="")


rw("flow_http.h", [
    ('''/* The provider context the generated module passes to the adapter: the
 * worker's database connection and its index (the cache epoch slot). */
typedef struct fh_provider {
  fh_db *db;
  uint32_t worker;
} fh_provider;''', '''/* The provider context the generated module passes to the adapter: the
 * worker's database connection, its index (the cache epoch slot), its store
 * (docs/WORKER-STORE-PLAN.md: a fixed, zero-filled region owned by this
 * worker alone) and its response stream (emptied before every request). */
typedef struct fh_provider {
  fh_db *db;
  uint32_t worker;
  uint8_t *store;
  uint64_t store_bytes;
  uint8_t *stream;
  uint32_t stream_capacity;
  uint32_t stream_used;
} fh_provider;'''),
])

store_code = r'''
/* ------------------------------------------------------------ worker store
 * Host operations of src/AgentLang.FlowHttp/Store.fs (tags 5-17) over the
 * worker's own store and response stream. Every offset is bounds-checked and
 * Int accesses must be 8-byte aligned; a failed check is none/false. */
#define FH_STORE_CAPACITY 5u
#define FH_STORE_INT 6u
#define FH_STORE_INTS 7u
#define FH_STORE_SET_INT 8u
#define FH_STORE_WRITE 9u
#define FH_STORE_BYTES 10u
#define FH_STORE_TEXT 11u
#define FH_STORE_MATCHES 12u
#define FH_STORE_HASH 13u
#define FH_RESPONSE_WRITE 14u
#define FH_RESPONSE_WRITE_STORE 15u
#define FH_RESPONSE_WRITTEN 16u
#define FH_RESPONSE_DISCARD 17u

static int fh_input_i64(const fh_host_input *input, int64_t *value) {
  if (input->extent_bytes < 8u) return 0;
  memcpy(value, input->data, 8);
  return 1;
}

static const uint8_t *fh_input_bytes(const fh_host_input *input, uint32_t *length) {
  fh_reader r;
  const uint8_t *data;
  r.data = input->data; r.extent = input->extent_bytes; r.at = 0u; r.failed = 0;
  data = fh_get_bytes(&r, length);
  return r.failed ? 0 : data;
}

static int fh_store_range(const fh_provider *p, int64_t offset, int64_t length) {
  return offset >= 0 && length >= 0 && (uint64_t)offset <= p->store_bytes &&
         (uint64_t)length <= p->store_bytes - (uint64_t)offset;
}

static int fh_store_aligned(const fh_provider *p, int64_t offset) {
  return (offset & 7) == 0 && fh_store_range(p, offset, 8);
}

static int fh_stream_append(fh_provider *p, const uint8_t *data, uint32_t length) {
  if (length > p->stream_capacity - p->stream_used) return 0;
  if (length > 0u) memcpy(p->stream + p->stream_used, data, length);
  p->stream_used += length;
  return 1;
}

static int32_t fh_store_host(fh_provider *p, uint32_t operation, const fh_host_input *inputs,
                             uint32_t input_count, fh_writer *w) {
  int64_t a = 0, b = 0;
  const uint8_t *text;
  uint32_t text_length = 0u;
  if (inputs == 0 || input_count == 0u || input_count > 2u) return 1;
  switch (operation) {
    case FH_STORE_CAPACITY:
      fh_put_i64(w, (int64_t)p->store_bytes);
      return 0;
    case FH_STORE_INT:
      if (!fh_input_i64(&inputs[0], &a)) return 1;
      if (fh_store_aligned(p, a)) { int64_t v; memcpy(&v, p->store + a, 8); fh_put_i64(w, 0); fh_put_i64(w, v); }
      else fh_put_i64(w, 1);
      return 0;
    case FH_STORE_INTS:
      if (input_count != 2u || !fh_input_i64(&inputs[0], &a) || !fh_input_i64(&inputs[1], &b)) return 1;
      if (b >= 0 && b <= 64 && (a & 7) == 0 && fh_store_range(p, a, b * 8)) {
        int64_t i;
        fh_put_i64(w, 0);
        fh_put_list_header(w, (uint32_t)b);
        for (i = 0; i < b; ++i) { int64_t v; memcpy(&v, p->store + a + i * 8, 8); fh_put_i64(w, v); }
      } else {
        fh_put_i64(w, 1);
      }
      return 0;
    case FH_STORE_SET_INT:
      if (input_count != 2u || !fh_input_i64(&inputs[0], &a) || !fh_input_i64(&inputs[1], &b)) return 1;
      if (fh_store_aligned(p, a)) { memcpy(p->store + a, &b, 8); fh_put_i64(w, 1); }
      else fh_put_i64(w, 0);
      return 0;
    case FH_STORE_WRITE:
    case FH_STORE_MATCHES:
      if (input_count != 2u || !fh_input_i64(&inputs[0], &a) || (text = fh_input_bytes(&inputs[1], &text_length)) == 0) return 1;
      if (!fh_store_range(p, a, text_length)) { fh_put_i64(w, 0); return 0; }
      if (operation == FH_STORE_WRITE) {
        if (text_length > 0u) memcpy(p->store + a, text, text_length);
        fh_put_i64(w, 1);
      } else {
        fh_put_i64(w, text_length == 0u || memcmp(p->store + a, text, text_length) == 0 ? 1 : 0);
      }
      return 0;
    case FH_STORE_BYTES:
    case FH_STORE_TEXT:
      if (input_count != 2u || !fh_input_i64(&inputs[0], &a) || !fh_input_i64(&inputs[1], &b)) return 1;
      /* Text is validated by the runtime when it commits the host output. */
      if (fh_store_range(p, a, b) && b <= 0x7fffffff) { fh_put_i64(w, 0); fh_put_bytes(w, p->store + a, (uint32_t)b); }
      else fh_put_i64(w, 1);
      return 0;
    case FH_STORE_HASH: {
      uint64_t hash = 14695981039346656037ull;
      uint32_t i;
      if ((text = fh_input_bytes(&inputs[0], &text_length)) == 0) return 1;
      for (i = 0u; i < text_length; ++i) hash = (hash ^ text[i]) * 1099511628211ull;
      fh_put_i64(w, (int64_t)hash);
      return 0;
    }
    case FH_RESPONSE_WRITE:
      if ((text = fh_input_bytes(&inputs[0], &text_length)) == 0) return 1;
      fh_put_i64(w, fh_stream_append(p, text, text_length) ? 1 : 0);
      return 0;
    case FH_RESPONSE_WRITE_STORE:
      if (input_count != 2u || !fh_input_i64(&inputs[0], &a) || !fh_input_i64(&inputs[1], &b)) return 1;
      fh_put_i64(w, fh_store_range(p, a, b) && b <= 0x7fffffff && fh_stream_append(p, p->store + a, (uint32_t)b) ? 1 : 0);
      return 0;
    case FH_RESPONSE_WRITTEN:
      fh_put_bytes(w, p->stream, p->stream_used);
      return 0;
    case FH_RESPONSE_DISCARD:
      fh_put_i64(w, (int64_t)p->stream_used);
      p->stream_used = 0u;
      return 0;
    default:
      return 1;
  }
}

int32_t al_host_flow_http_v1('''

rw("flow_http_db.c", [
    ("\nint32_t al_host_flow_http_v1(", store_code),
    ('''  const fh_provider *provider = (const fh_provider *)provider_context;''', '''  fh_provider *provider = (fh_provider *)provider_context;'''),
    ('''  if (provider != 0 && output != 0 && (operation == FH_CACHE_GET || operation == FH_CACHE_PUT)) {''',
     '''  if (provider != 0 && output != 0 && operation >= FH_STORE_CAPACITY && operation <= FH_RESPONSE_DISCARD) {
    w.data = output; w.capacity = output_capacity_bytes; w.used = 0u; w.failed = 0;
    status = fh_store_host(provider, operation, inputs, input_count, &w);
    if (status != 0 || w.failed) return 1;
    *output_extent_bytes = w.used;
    return 0;
  }
  if (provider != 0 && output != 0 && (operation == FH_CACHE_GET || operation == FH_CACHE_PUT)) {'''),
])

rw("flow_http_host.c", [
    ('''  uint8_t *retained;
  uint32_t context_bytes;''', '''  uint8_t *retained;
  uint8_t *store;  /* this worker's store (--store-mb total / workers), or NULL */
  uint8_t *stream; /* this worker's response stream, retained_bytes long */
  uint32_t context_bytes;'''),
    ('''  uint32_t retained_bytes;''', '''  uint32_t retained_bytes;
  uint64_t store_bytes;   /* per worker, a multiple of 16 KB; 0 = no store */
  uint32_t store_mb;      /* the --store-mb total, split between workers */'''),
    ('''  fh_context_reset(worker, &ctx);
  /* The cache epoch covers the whole handle call: cache.get copies a hit into
   * the arena inside it; the response is then in the worker's own buffer. */''', '''  fh_context_reset(worker, &ctx);
  worker->provider.stream_used = 0u; /* every request starts with an empty response stream */
  /* The cache epoch covers the whole handle call: cache.get copies a hit into
   * the arena inside it; the response is then in the worker's own buffer. */'''),
    ('''      !fh_write_response(c, worker->retained, (uint32_t)ctx.retained_copy_bytes,''',
     '''      !fh_write_response(c, worker->retained, (uint32_t)ctx.retained_copy_bytes,
                         worker->stream, worker->provider.stream_used,'''),
    ('''static int fh_write_response(fh_connection *c, const uint8_t *value, uint32_t extent, int head_only, int close) {''',
     '''/* HttpResponse is status, headers, body, streamed. A streamed response's body
 * is the request's response stream followed by `body`; otherwise the stream
 * is dropped. */
static int fh_write_response(fh_connection *c, const uint8_t *value, uint32_t extent,
                             const uint8_t *stream, uint32_t stream_used, int head_only, int close) {'''),
    ('''  body = fh_get_bytes(&r, &body_length);
  if (r.failed) { c->out_used = mark; return 0; }
  n = snprintf(line, sizeof(line), "content-length: %u\\r\\n%s\\r\\n", body_length, close ? "connection: close\\r\\n" : "");
  fh_out_append(c, line, (uint32_t)n);
  if (!head_only) fh_out_body(c, body, body_length);
  return 1;''', '''  body = fh_get_bytes(&r, &body_length);
  streamed = fh_get_i64(&r);
  if (r.failed || (streamed != 0 && streamed != 1) || (streamed && body_length > 0xffffffffu - stream_used)) {
    c->out_used = mark;
    return 0;
  }
  if (!streamed) stream_used = 0u;
  n = snprintf(line, sizeof(line), "content-length: %u\\r\\n%s\\r\\n", stream_used + body_length, close ? "connection: close\\r\\n" : "");
  fh_out_append(c, line, (uint32_t)n);
  if (!head_only) {
    if (stream_used > 0u) fh_out_body(c, stream, stream_used);
    fh_out_body(c, body, body_length);
  }
  return 1;'''),
    ('''  const uint8_t *body;
  char line[128];
  int n;
  uint32_t mark = c->out_used;''', '''  const uint8_t *body;
  int64_t streamed;
  char line[128];
  int n;
  uint32_t mark = c->out_used;'''),
    ('''  worker->retained = (uint8_t *)fh_alloc(options->retained_bytes);''', '''  worker->retained = (uint8_t *)fh_alloc(options->retained_bytes);
  worker->stream = (uint8_t *)fh_alloc(options->retained_bytes);
  worker->store = options->store_bytes > 0u ? (uint8_t *)fh_alloc((size_t)options->store_bytes) : 0;
  if (worker->stream == 0 || (options->store_bytes > 0u && worker->store == 0)) return -1;
  worker->provider.store = worker->store;
  worker->provider.store_bytes = worker->store == 0 ? 0u : options->store_bytes;
  worker->provider.stream = worker->stream;
  worker->provider.stream_capacity = options->retained_bytes;
  worker->provider.stream_used = 0u;'''),
    ('''    fh_free(workers[i].retained, options.retained_bytes);''', '''    fh_free(workers[i].retained, options.retained_bytes);
    fh_free(workers[i].stream, options.retained_bytes);
    if (workers[i].store != 0) fh_free(workers[i].store, (size_t)options.store_bytes);'''),
    ('''    else if (strcmp(a, "--cache-mb") == 0 && v) { options.cache_mb = (uint32_t)atoi(v); ++i; }''',
     '''    else if (strcmp(a, "--cache-mb") == 0 && v) { options.cache_mb = (uint32_t)atoi(v); ++i; }
    else if (strcmp(a, "--store-mb") == 0 && v) { options.store_mb = (uint32_t)atoi(v); ++i; }'''),
    ('''  options.cache_mb = 0u; /* off unless asked for: a no-cache run never caches silently */''',
     '''  options.cache_mb = 0u; /* off unless asked for: a no-cache run never caches silently */
  options.store_mb = 0u; /* no worker store unless asked for */'''),
    ('''         "  --cache-mb N  byte budget of the process-wide cache.get/cache.put cache (default 0 = disabled)\\n");''',
     '''         "  --cache-mb N  byte budget of the process-wide cache.get/cache.put cache (default 0 = disabled)\\n"
         "  --store-mb N  total worker-store size, split evenly between workers (default 0 = no store)\\n");'''),
    ('''options.cache_mb > (1u << 16)) {''', '''options.cache_mb > (1u << 16) || options.store_mb > (1u << 16)) {'''),
])
print("ok")

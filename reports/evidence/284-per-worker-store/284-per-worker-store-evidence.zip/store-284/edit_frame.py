from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\server\server.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''fn campfire.server.worker-cache() -> WorkerCache {''', '''record PageFrame {
    head: String
    tail: String
}

fn campfire.server.page-frame(chrome: PageChrome) -> PageFrame {
    doc "campfire.views.page with no messages, split where the messages go: just after the opening tag of the messages container (the first '\\">' after its data-messages-target attribute; attribute values are escaped, so page text cannot end it early). head ++ messages ++ tail is the page. The layout stays one compile-time-checked template."

    let empty = campfire.views.text(campfire.views.page(chrome, list.empty<Html>()))
    let split = match string.index-of(empty, "data-messages-target=\\"messages\\"", 0) {
        none => -1
        some at => match string.index-of(empty, "\\">", at) {
            none => -1
            some end => end + 2
        }
    }
    if split < 0 {
        pageFrame.new(head = empty, tail = "")
    } else {
        pageFrame.new(
            head = match string.slice(empty, 0, split) { none => ""; some text => text },
            tail = match string.slice(empty, split, string.byte-length(empty) - split) { none => ""; some text => text })
    }
}

test campfire.server.page-frame/joins-to-page {
    let chrome = campfire.views.room-chrome(roomRow.new(id = RoomId.new(1), name = option.some<String>("Lo\\">bby"), kind = RoomKind.open(), creator-id = UserId.new(1), created-at = "", updated-at = ""), authUser.new(id = UserId.new(1), name = "Ann", role = Role.member(), status = AuthUserStatus.active()), "http://x")
    let frame = campfire.server.page-frame(chrome)
    expect string.ends-with(frame.head, "/rooms/1/refresh\\">")
    expect string.starts-with(frame.tail, "</div>")
    expect string.concat(frame.head, string.concat("<p>m</p>", frame.tail)) == campfire.views.text(campfire.views.page(chrome, [html"<p>m</p>"]))
}

fn campfire.server.worker-cache() -> WorkerCache {''')
rep('''            let head = response.write-html(campfire.views.page-head(chrome))
            let page = campfire.server.write-messages(cache, context, keys, loaded)
            let tail = response.write-html(campfire.views.page-tail(chrome))''', '''            let frame = campfire.server.page-frame(chrome)
            let head = response.write(frame.head)
            let page = campfire.server.write-messages(cache, context, keys, loaded)
            let tail = response.write(frame.tail)''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

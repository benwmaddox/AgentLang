from pathlib import Path
R = Path(r"D:\code\AgentLang")


def rw(rel, pairs):
    p = R / rel
    s = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert s.count(a) == 1, (rel, a[:60], s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8", newline="")


rw("src/AgentLang.Core/TypedIR.fs", [
    ("    | CacheRead\n    | CacheWrite\n", "    | CacheRead\n    | CacheWrite\n    | StoreRead\n    | StoreWrite\n    | ResponseWrite\n"),
    ('        | IrEffect.CacheWrite -> "cache.write"\n', '        | IrEffect.CacheWrite -> "cache.write"\n        | IrEffect.StoreRead -> "store.read"\n        | IrEffect.StoreWrite -> "store.write"\n        | IrEffect.ResponseWrite -> "response.write"\n'),
    ('        | "cache.write" -> Some IrEffect.CacheWrite\n', '        | "cache.write" -> Some IrEffect.CacheWrite\n        | "store.read" -> Some IrEffect.StoreRead\n        | "store.write" -> Some IrEffect.StoreWrite\n        | "response.write" -> Some IrEffect.ResponseWrite\n'),
])
rw("src/AgentLang.Core/Core.fs", [
    ('let observableEffects = set [ "cache.read"; "cache.write"; "clock.read"; "console.write"; "db.read"; "db.write"; "fs.read"; "fs.write"; "random.read" ]',
     'let observableEffects = set [ "cache.read"; "cache.write"; "clock.read"; "console.write"; "db.read"; "db.write"; "fs.read"; "fs.write"; "random.read"; "response.write"; "store.read"; "store.write" ]'),
])
rw("src/AgentLang.Core/Parser.fs", [
    ('"console.write"; "cache.read"; "cache.write" ]', '"console.write"; "cache.read"; "cache.write"; "store.read"; "store.write"; "response.write" ]'),
])
rw("src/AgentLang.FlowHttp/FlowApp.fs", [
    ('let capabilities = Set.ofList [ "db.read"; "db.write"; "cache.read"; "cache.write"; "clock.read"; "random.read" ]',
     'let capabilities = Set.ofList [ "db.read"; "db.write"; "cache.read"; "cache.write"; "clock.read"; "random.read"; "store.read"; "store.write"; "response.write" ]'),
])
print("ok")

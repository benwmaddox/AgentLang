from pathlib import Path
p = Path(r"D:\code\AgentLang\tests\AgentLang.FlowHttp.Tests\app\counter.flow")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''// Example Flow HTTP app for the portable host tests: echo, a db-backed item
// list, the process-wide cache, and a per-worker context derived once in
// worker-init.''', '''// Example Flow HTTP app for the portable host tests: echo, a db-backed item
// list, the process-wide cache, the per-worker store with its worker cache and
// response stream, and a per-worker context derived once in worker-init.''')
rep('''fn counter.handle(request: HttpRequest, context: CounterContext) -> HttpResponse {
    effects db.read, db.write, cache.read, cache.write''', '''fn counter.store(request: HttpRequest) -> HttpResponse {
    effects store.read, store.write, response.write
    doc "The worker cache over the whole store. GET /store?<key>: streamed \\"store:<value>;hit\\" (the value copied from the store to the output) or \\"store:none;miss\\". POST /store?<key> with the value as body: stored or refused. GET /store-text?<key>: the value through the data stack, or absent."
    let key = http.query(request.target)
    let cache = worker-cache.open(0, store.size())
    let path = http.path(request.target)
    if request.method == "POST" {
        let value = match bytes.to-utf8(request.body) {
            none => ""
            some text => text
        }
        if worker-cache.put(cache, key, value) {
            counter.text(201, "stored")
        } else {
            counter.text(200, "refused")
        }
    } else if path == "/store-text" {
        match worker-cache.text(cache, key) {
            none => counter.text(404, "absent")
            some value => counter.text(200, string.concat("text:", value))
        }
    } else {
        let opened = response.write("store:")
        if worker-cache.write-to-response(cache, key) {
            http.streamed(200, [httpHeader.new(name = "content-type", value = "text/plain; charset=utf-8")], ";hit")
        } else {
            let wrote = response.write("none")
            http.streamed(404, [httpHeader.new(name = "content-type", value = "text/plain; charset=utf-8")], ";miss")
        }
    }
}

test counter.store/miss-put-hit {
    expect response.discard(0) == 0
    expect counter.store(counter.test-request("GET", "/store?k", "")).status == 404
    expect response.written(0) == "store:none"
    expect response.discard(0) == 10
    expect counter.store(counter.test-request("POST", "/store?k", "<b>é</b>")).body == "stored"
    let hit = counter.store(counter.test-request("GET", "/store?k", ""))
    expect hit.status == 200 && hit.streamed && hit.body == ";hit"
    expect response.written(0) == "store:<b>é</b>"
    expect counter.store(counter.test-request("GET", "/store-text?k", "")).body == "text:<b>é</b>"
}

fn counter.store-unstreamed(request: HttpRequest) -> HttpResponse {
    effects response.write
    doc "Writes to the response stream, then returns an ordinary response: the written bytes must not be sent. /store-discard empties the stream first; /store-error does not."
    let wrote = response.write("junk")
    if http.path(request.target) == "/store-discard" {
        let dropped = response.discard(0)
        counter.text(200, string.concat("clean:", int.to-string(dropped)))
    } else {
        counter.text(500, "error after partial writes")
    }
}

test counter.store-unstreamed/drops {
    expect counter.store-unstreamed(counter.test-request("GET", "/store-discard", "")).body == "clean:4"
    let failed = counter.store-unstreamed(counter.test-request("GET", "/store-error", ""))
    expect failed.status == 500 && bool.not(failed.streamed)
}

fn counter.handle(request: HttpRequest, context: CounterContext) -> HttpResponse {
    effects db.read, db.write, cache.read, cache.write, store.read, store.write, response.write''')
rep('''    } else if path == "/cache" {
        counter.cache(request)''', '''    } else if path == "/cache" {
        counter.cache(request)
    } else if path == "/store" || path == "/store-text" {
        counter.store(request)
    } else if path == "/store-discard" || path == "/store-error" {
        counter.store-unstreamed(request)''')
p.write_text(s, encoding="utf-8", newline="")

p = Path(r"D:\code\AgentLang\tests\AgentLang.FlowHttp.Tests\Program.fs")
s = p.read_text(encoding="utf-8")
rep('''      case "GET" "/cache?k1" [] ""                        // first value
      case "GET" "/nope" [] "" ]''', '''      case "GET" "/cache?k1" [] ""                        // first value
      case "GET" "/store?s1" [] ""                        // worker store: streamed miss,
      case "POST" "/store?s1" [] "<b>\u00e9 one</b>"           // put,
      case "GET" "/store?s1" [] ""                        // hit copied from the store to the output,
      case "GET" "/store-text?s1" [] ""                   // the same value through the data stack,
      case "GET" "/store-text?s2" [] ""                   // absent,
      case "GET" "/store-discard" [] ""                   // stream emptied by the app,
      case "GET" "/store-error" [] ""                     // a non-streamed response drops partial writes,
      case "GET" "/store?s1" [] ""                        // still a hit
      case "GET" "/nope" [] "" ]''')
rep('''    use app = FlowApp.load (Path.Combine(root, "engine")) "counter" [ appSource ] database''',
    '''    // One worker store of 1 MB, as each of the native servers' 3 workers gets from --store-mb 3.
    use app = FlowApp.loadWithStore (Path.Combine(root, "engine")) "counter" [ appSource ] database 1048576''')
s = s.replace('--workers 3 --allow-control --arena-mb 8 --cache-mb 8', '--workers 3 --allow-control --arena-mb 8 --cache-mb 8 --store-mb 3')
rep('''    check $"{server.Label}: config values are never logged" (not (errors.Contains "s3cret") && not (server.Output.ToString().Contains "s3cret"))''',
    '''    check $"{server.Label}: config values are never logged" (not (errors.Contains "s3cret") && not (server.Output.ToString().Contains "s3cret"))
    check $"{server.Label}: store size per worker is logged" (errors.Contains "store-bytes=")''')
rep('''                client.Send(encodeRequest (case "GET" "/cache?k" [] ""))
                check "cache-off: get misses" (client.Read(false) |> Option.exists (fun r -> r.Status = 404 && r.Body = "miss"))''',
    '''                client.Send(encodeRequest (case "GET" "/cache?k" [] ""))
                check "cache-off: get misses" (client.Read(false) |> Option.exists (fun r -> r.Status = 404 && r.Body = "miss"))
                // No --store-mb: the store has size 0, so the worker cache is never ready.
                client.Send(encodeRequest (case "POST" "/store?k" [] "v"))
                check "store-off: put refused" (client.Read(false) |> Option.exists (fun r -> r.Body = "refused"))
                client.Send(encodeRequest (case "GET" "/store?k" [] ""))
                check "store-off: get misses" (client.Read(false) |> Option.exists (fun r -> r.Status = 404 && r.Body = "store:none;miss"))''')
# HEAD of a streamed response keeps the streamed content length.
rep('''     client.Send(encodeRequest (case "GET" "/hello" [] ""))
     check $"{label}: keep-alive after HEAD" (client.Read(false) |> Option.exists (fun r -> r.Body = "hello world"))''',
    '''     client.Send(encodeRequest (case "GET" "/hello" [] ""))
     check $"{label}: keep-alive after HEAD" (client.Read(false) |> Option.exists (fun r -> r.Body = "hello world"))
     client.Send(encodeRequest (case "HEAD" "/store?none" [] ""))
     let streamedHead = client.Read(true)
     check $"{label}: HEAD of a streamed response has its content length" (streamedHead |> Option.exists (fun r -> r.Status = 404 && r.Headers |> List.contains ("content-length", "15")))
     client.Send(encodeRequest (case "GET" "/hello" [] ""))
     check $"{label}: keep-alive after streamed HEAD" (client.Read(false) |> Option.exists (fun r -> r.Body = "hello world"))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
R = Path(r"D:\code\AgentLang\docs")
p = R / "WORKER-STORE-PLAN.md"
s = p.read_text(encoding="utf-8")
s += '''
## As built (284)

- **Host** (`native/http_host/flow_http_host.c`, adapter `flow_http_db.c`):
  - `--store-mb N` is the total. Each worker gets `N MB / workers`, rounded
    down to whole 16 KB pages, as a lazy zero-filled reservation. There is also
    a per-worker response stream of `--retained-mb`.
  - Tags 5-17 implement the operations in `src/AgentLang.FlowHttp/Store.fs`,
    and the interpreter shares the same table.
  - `HttpResponse.streamed` decides whether the stream is sent before `body`.
    HEAD keeps the streamed `Content-Length`.
  - At shutdown each worker logs `store-bytes` and `store-pages-used` (16 KB
    pages holding any non-zero byte).
- **Operations that take no argument** (`store.capacity`, `response.written`,
  `response.discard`) carry an ignored Int input, because host operations need
  at least one input today. `store.size()` wraps `store.capacity(0)`.
- **Stdlib:** `store.flow` and `worker-cache.flow` call host operations, so
  `FlowApp` defines them on the engine that binds them (`hostStdlibFiles`),
  after the type-only stdlib.
- **The page frame is split at run time.** Splitting `layout.flow` into head
  and tail templates fails the compile-time markup check (a head leaves
  `<html>`, `<body>` and the messages `<div>` open). Instead,
  `campfire.server.page-frame` renders the page with no messages (about 33 KB)
  and splits it just after the messages container's opening tag. A test checks
  that head ++ messages ++ tail equals the page. A template form that may leave
  elements open is listed in PENDING-REVIEW.
- **Campfire:**
  - With a store, the server streams the page through the worker cache:
    narrow query, one batched miss query, in-order writes, then puts.
  - Without a store, it renders the page in one piece with the single joined
    query (`campfire.views.creator-room-page`). The process-wide
    `cache.get`/`cache.put` cache is no longer used by Campfire.
  - A room response with an empty body is the streamed one.
- **Measured (Linux, 4 pinned vCPUs, 16 connections):**
  - store on: 0.74 ms CPU per request;
  - uncached, interleaved against 283: 1.17 against 1.31 ms (no regression);
  - each worker uses 30 pages (about 480 KB) for the 40 fragments and the index.

  Report 284 has the full interleaved sweep against Rust.
'''
p.write_text(s, encoding="utf-8", newline="")

p = R / "PENDING-REVIEW.md"
s = p.read_text(encoding="utf-8")
a = "## Deferred usability work (user, 2026-10-13)"
assert a in s
s = s.replace(a, '''## Language and stdlib follow-ups from the worker store (284)

- **Html into the stdlib (user, 2026-10-15).** `Html` is still built into the
  compiler (`HtmlMarkup.fs`, `Compiler.fs`). Move the type and its words into
  `src/stdlib/html.flow` as a refined type over String. The compiler keeps
  only the validation: literal and template checks at compile time, and the
  proof that lets `html.raw` skip the runtime check.
- **Templates that leave elements open.** A layout can't be split into
  head/tail templates, because each half fails `FLOW_TEMPLATE_MARKUP`.
  Campfire splits the rendered page at run time instead
  (`campfire.server.page-frame`). Possible language support: a template form
  checked as a pair (head opens exactly what tail closes), or a streaming hole
  that names where the stream continues.
- **Host operations with no inputs.** `store.capacity`, `response.written` and
  `response.discard` take an ignored Int. Allow zero-input host operations.

''' + a)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

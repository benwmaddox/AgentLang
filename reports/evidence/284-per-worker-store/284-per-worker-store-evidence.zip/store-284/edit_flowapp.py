from pathlib import Path
p = Path(r"D:\code\AgentLang\src\AgentLang.FlowHttp\FlowApp.fs")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:70]
    s = s.replace(a, b)


rep('''      ContextType: string
      Provider: HostOperationProvider }''', '''      ContextType: string
      Provider: HostOperationProvider
      /// The interpreter "worker": its store and response stream.
      Worker: Store.WorkerState }''')
rep('let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow" ]', 'let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow"; "store.flow"; "worker-cache.flow" ]')
rep('''    let load (projectDirectory: string) (app: string) (sourcePaths: string list) (databasePath: string) =''',
    '''    let loadWithStore (projectDirectory: string) (app: string) (sourcePaths: string list) (databasePath: string) (storeBytes: int) =''')
rep('''        let provider = Cache.combine [ Db.createProvider databasePath; Cache.createProvider (Some Cache.processStore) ]
        let environment =
            { Manifest = Map.fold (fun acc key value -> Map.add key value acc) Db.manifest Cache.manifest
              ProductionProvider = provider
              CreateTestProvider = fun () -> Ok(Cache.combine [ Db.createProvider ":memory:"; Cache.createProvider (Some(Collections.Concurrent.ConcurrentDictionary<string, string>(StringComparer.Ordinal))) ]) }''',
    '''        // store: this worker's region (storeBytes, 0 = no store); tests get a fresh one each.
        let worker = Store.WorkerState(storeBytes, Store.streamCapacity)
        let provider = Cache.combine [ Db.createProvider databasePath; Cache.createProvider (Some Cache.processStore); Store.createProvider worker ]
        let merge (maps: Map<HostOperationId, HostOperationDefinition> list) = maps |> List.reduce (fun acc next -> Map.fold (fun a k v -> Map.add k v a) acc next)
        let environment =
            { Manifest = merge [ Db.manifest; Cache.manifest; Store.manifest ]
              ProductionProvider = provider
              CreateTestProvider =
                fun () ->
                    Ok(Cache.combine
                        [ Db.createProvider ":memory:"
                          Cache.createProvider (Some(Collections.Concurrent.ConcurrentDictionary<string, string>(StringComparer.Ordinal)))
                          Store.createProvider (Store.WorkerState(Store.testCapacity, Store.streamCapacity)) ]) }''')
rep('''        { Engine = engine; App = app; ContextType = contextType; Provider = provider }''',
    '''        { Engine = engine; App = app; ContextType = contextType; Provider = provider; Worker = worker }

    /// load with no worker store (store.capacity is 0).
    let load projectDirectory app sourcePaths databasePath = loadWithStore projectDirectory app sourcePaths databasePath 0''')
rep('''    let handle (app: FlowApp) (request: Value) (context: Value) =
        invoke app $"{app.App}.handle" (handleSignature app) [ request; context ]''',
    '''    /// One request, as the native host runs it: the response stream starts
    /// empty, and a `streamed` response's body is the stream followed by `body`.
    let handle (app: FlowApp) (request: Value) (context: Value) =
        app.Worker.ResetStream()
        match invoke app $"{app.App}.handle" (handleSignature app) [ request; context ] with
        | RecordValue("HttpResponse", fields) when fields.TryFind "streamed" = Some(BoolValue true) ->
            let tail = match fields.TryFind "body" with Some(StringValue text) -> text | _ -> ""
            let streamed = Encoding.UTF8.GetString(app.Worker.Stream.ToArray())
            RecordValue("HttpResponse", fields.Add("body", StringValue(streamed + tail)))
        | response -> response''')
rep('''            Db.nativeOperations @ Cache.nativeOperations''', '''            Db.nativeOperations @ Cache.nativeOperations @ Store.nativeOperations''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

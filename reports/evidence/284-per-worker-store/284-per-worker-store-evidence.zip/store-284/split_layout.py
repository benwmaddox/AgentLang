from pathlib import Path
p = Path(r"D:\code\AgentLang\applications\campfire\layout.flow")
s = p.read_text(encoding="utf-8")
start_marker = '''fn campfire.views.page(chrome: PageChrome, messages: List<Html>) -> Html {
    effects none
    doc "The Rails room page layout (layouts/application and rooms/show chrome), generated from Campfire's markup with every request, user, room and account value as a hole."

    html"""'''
i = s.index(start_marker)
body_start = i + len(start_marker)
end = s.index('\n"""\n}', body_start)
template = s[body_start:end]
assert template.count("{messages}") == 1
head, tail = template.split("{messages}")
new = '''fn campfire.views.page(chrome: PageChrome, messages: List<Html>) -> Html {
    effects none
    doc "The Rails room page layout (layouts/application and rooms/show chrome), generated from Campfire's markup with every request, user, room and account value as a hole: page-head, the messages, page-tail."

    let head = campfire.views.page-head(chrome)
    let tail = campfire.views.page-tail(chrome)
    html"{head}{messages}{tail}"
}

fn campfire.views.page-head(chrome: PageChrome) -> Html {
    effects none
    doc "The room page up to the messages container's content (campfire.views.page before its messages)."

    html"""''' + head + '''"""
}

fn campfire.views.page-tail(chrome: PageChrome) -> Html {
    effects none
    doc "The room page after the messages (campfire.views.page after its messages)."

    html"""''' + tail + '''
"""
}'''
s = s[:i] + new + s[end + len('\n"""\n}'):]
p.write_text(s, encoding="utf-8", newline="")
print("ok", len(head), len(tail))

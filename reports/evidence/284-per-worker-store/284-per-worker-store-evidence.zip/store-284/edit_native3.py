from pathlib import Path
p = Path(r"D:\code\AgentLang\src\AgentLang.Llvm\native\http_host\flow_http_host.c")
s = p.read_text(encoding="utf-8")
a = '''    if (workers[i].requests > 0u) {
      char line[200];
      snprintf(line, sizeof(line), "worker %d: requests=%llu peak-arena-bytes=%u peak-response-bytes=%u peak-input-bytes=%u context-bytes=%u\\n",
               i, (unsigned long long)workers[i].requests, workers[i].peak_arena, workers[i].peak_response,
               workers[i].peak_input, workers[i].context_bytes);
      fh_log(line);
    }'''
b = '''    if (workers[i].requests > 0u) {
      char line[260];
      uint64_t pages = 0u, page, at;
      /* Store pages holding any non-zero byte (the store starts zero-filled). */
      for (page = 0u; workers[i].store != 0 && page < options.store_bytes / 16384u; ++page)
        for (at = 0u; at < 16384u; at += 8u) {
          uint64_t word;
          memcpy(&word, workers[i].store + page * 16384u + at, 8);
          if (word != 0u) { ++pages; break; }
        }
      snprintf(line, sizeof(line), "worker %d: requests=%llu peak-arena-bytes=%u peak-response-bytes=%u peak-input-bytes=%u context-bytes=%u store-bytes=%llu store-pages-used=%llu\\n",
               i, (unsigned long long)workers[i].requests, workers[i].peak_arena, workers[i].peak_response,
               workers[i].peak_input, workers[i].context_bytes, (unsigned long long)options.store_bytes, (unsigned long long)pages);
      fh_log(line);
    }'''
assert s.count(a) == 1
s = s.replace(a, b)
p.write_text(s, encoding="utf-8", newline="")
print("ok")

from pathlib import Path
p = Path(r"D:\code\AgentLang\src\stdlib\worker-cache.flow")
s = p.read_text(encoding="utf-8")
i = s.index("test worker-cache.put/large-put-evicts-several-and-quarter-limit {")
j = s.index("\n}\n", i) + 3
s = s[:i] + '''test worker-cache.put/large-put-evicts-several-and-quarter-limit {
    let cache = worker-cache.open(0, 16384)
    let small = "0123456789012345678901234567890123456789"
    var stored = 0
    for n in 0..140 {
        if worker-cache.put(cache, string.concat("s", int.to-string(n)), small) {
            stored = stored + 1
        }
    }
    expect stored == 140
    let before = worker-cache.stats(cache)
    expect before.evictions == 0
    var large = ""
    for n in 0..75 {
        large = string.concat(large, small)
    }
    expect string.byte-length(large) == 3000
    expect worker-cache.put(cache, "large", large)
    let after = worker-cache.stats(cache)
    expect after.evictions >= 20
    expect worker-cache.text(cache, "large") == option.some<String>(large)
    expect worker-cache.text(cache, "s0") == option.none<String>()
    expect worker-cache.text(cache, "s139") == option.some<String>(small)
    let huge = string.concat(large, large)
    expect bool.not(worker-cache.put(cache, "huge", huge))
    expect worker-cache.stats(cache).refused == 1
}
''' + s[j:]
p.write_text(s, encoding="utf-8", newline="")
print("ok")

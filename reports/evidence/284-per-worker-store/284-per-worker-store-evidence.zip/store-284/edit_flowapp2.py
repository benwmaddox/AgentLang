from pathlib import Path
p = Path(r"D:\code\AgentLang\src\AgentLang.FlowHttp\FlowApp.fs")
s = p.read_text(encoding="utf-8")
a = '    let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow"; "store.flow"; "worker-cache.flow" ]'
assert a in s
s = s.replace(a, '''    /// Defined first, on a bootstrap engine: types the host manifest names, and words that call no host operation.
    let stdlibFiles = [ "http.flow"; "db.flow"; "cache.flow" ]
    /// Defined with the app, once the host operations are bound (their words call them).
    let hostStdlibFiles = [ "store.flow"; "worker-cache.flow" ]''')
a = '        define engine (String.concat "\\n\\n" appSources)'
assert a in s, "define"
s = s.replace(a, '''        let hostStdlibSources = hostStdlibFiles |> List.map (fun name -> File.ReadAllText(Path.Combine(stdlib, name)))
        define engine (String.concat "\\n\\n" (hostStdlibSources @ appSources))''')
p.write_text(s, encoding="utf-8", newline="")
print("ok")

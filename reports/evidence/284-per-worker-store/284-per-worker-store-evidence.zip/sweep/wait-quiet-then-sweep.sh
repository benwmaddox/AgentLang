# Waits until the WSL VM is quiet (1-min loadavg < 0.5 on three checks 20 s apart),
# then runs the pre-registered sweep. Root: bash .../wait-quiet-then-sweep.sh <tag>
D=/mnt/d/code/AgentLang/.agentlang/linux-sweep-284
quiet=0
while [ $quiet -lt 3 ]; do
  load=$(cut -d' ' -f1 /proc/loadavg)
  if awk -v l="$load" 'BEGIN { exit !(l < 0.5) }'; then quiet=$((quiet + 1)); else quiet=0; fi
  echo "$(date -u +%FT%TZ) load=$load quiet=$quiet" >> "$D/wait-$1.log"
  sleep 20
done
echo "$(date -u +%FT%TZ) quiet; starting sweep $1" >> "$D/wait-$1.log"
bash "$D/run-sweep.sh" "$1"

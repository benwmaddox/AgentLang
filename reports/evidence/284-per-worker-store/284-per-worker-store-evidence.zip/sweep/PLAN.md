# 284 Linux concurrency sweep — pre-registered (written 2026-10-15, before any run)

Protocol: docs/LINUX-SERVER-PLAN.md "Benchmark protocol (Linux)", including the saturation check.

## Servers and configurations

- Rails (native Ruby 3.4.10 + YJIT + jemalloc, puma 3x5, redis), Rust (native, 6dae2fd), Flow
  (Campfire on the portable Flow host with the per-worker store, built from the 284 working tree, trusted profile, O2, no `-Profile`; sha256 in each cache-env.txt).
- off: no cache anywhere. Rails: no-cache initializer (perform_caching=false). Rust:
  CAMPFIRE_RESPONSE_CACHE_MB=0, CAMPFIRE_FRAGMENT_CACHE_MB=0. Flow: no worker store (--store-mb 0, --cache-mb 0): the page is rendered in one piece.
- on: message-fragment caches only. Rails: redis_cache_store (as configured). Rust:
  CAMPFIRE_FRAGMENT_CACHE_MB=32, CAMPFIRE_RESPONSE_CACHE_MB=0 (the 273 rust-cache-1 run used the
  64 MB response cache too, which the plan excludes). Flow: --store-mb 32 total, split into 8 MB
  per worker (4 workers), --cache-mb 0: the page is streamed through the worker cache. Each server's live
  configuration is recorded in cache-env.txt.
- No User-Agent header, for all three (as every earlier run).
- Server on vCPUs 8-11 (4), load generator on vCPUs 12-19 (8). vCPUs, not physical cores.
- Same room (watercooler, 40-message window), every response validated against the canonical
  room_show contract.

## Run order

3 reps; each rep runs the 6 configs, rotated by 2 per rep and reversed on rep 2 (run-sweep.sh).
Each lifetime measures 16, 32, 64 and 128 connections; the order rotates through four
permutations across lifetimes. Each cell: warm-up at the same connection count (Rails 10 s, others
3 s), then a measured window (Rails 30 s, others 10 s).

## Per-cell measures and labels

- req/s, p50/p99, n (ok), invalid, CPU ms per request (cgroup usage_usec delta / ok), PSS after the
  cell.
- server utilization = cgroup usage delta / (secs x 4 vCPUs).
- client utilization = loadgen (user + sys) / (secs x 8 vCPUs).
- label: saturated if server >= 0.90 and client < 0.70; client-bound if client >= 0.70; otherwise
  wait-bound.
- A server's peak = the highest-req/s cell labeled saturated (median over reps). If no cell is
  saturated, report the best cell with its label; no fairness claim from it.
- Report median and range over the 3 reps per cell; CPU per request next to throughput.

## Contamination screen

- Before starting: no gate run, build, Codex session or other agent writing in the checkout; WSL
  loadavg recorded per lifetime with the top 3 CPU processes (sweep-*.log).
- A lifetime is excluded (and rerun under a new name, the original kept) if: invalid responses > 0,
  a non-200 status, the cache configuration in cache-env.txt differs from this plan, or a foreign
  process shows >= 20% CPU in the start line.

## Changes from 282

- Flow pages carry no CSRF tokens since 283 (as Rust's); Rails still masks ~322 tokens per page.
- Flow's cached column is the per-worker store (docs/WORKER-STORE-PLAN.md), not the process-wide
  cache. Its 32 MB is a per-process total split between workers (Rust: one 32 MB store).
- Same scripts otherwise (sweep-lifetime.sh copied from 282 with the Flow flags changed).

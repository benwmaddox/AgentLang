S284=/mnt/d/code/AgentLang/.agentlang/linux-sweep-284/sweep-lifetime.sh
S282=/mnt/d/code/AgentLang/.agentlang/linux-sweep-282/sweep-lifetime.sh
for rep in 1 2 3; do
  if [ $rep = 2 ]; then order="283 284"; else order="284 283"; fi
  for v in $order; do
    if [ $v = 284 ]; then bash $S284 flow ab284-off-$rep off 16,64 > /dev/null 2>&1; echo "284 rep$rep exit=$?"
    else FLOWBIN=/home/ben/linuxbench/flowhttp/campfire-283/flow_http_server bash $S282 flow ab283-off-$rep off 64,16 > /dev/null 2>&1; echo "283 rep$rep exit=$?"; fi
  done
done

namespace AgentLang

open System

/// Runtime-independent identity for a source word. IDs are never resolved by name.
[<Struct>]
type WordId = WordId of string

/// A nominal type key is scoped to one immutable compiled program snapshot.
[<Struct>]
type ProgramTypeKey = ProgramTypeKey of int

/// Stable identity of a source expression within its owner (or standalone body).
[<Struct>]
type SourceSiteId = SourceSiteId of WordId option * int

/// Compiler-assigned slot for a named source local.
[<Struct>]
type LocalSlot = LocalSlot of int

/// A standard primitive identity is independent of its per-call type instantiation.
[<Struct>]
type PrimitiveId = PrimitiveId of string

/// Closed, source-independent effect vocabulary used by executable IR.
[<RequireQualifiedAccess>]
type IrEffect =
    | FileRead
    | FileWrite
    | DatabaseRead
    | DatabaseWrite
    | NetworkRead
    | NetworkWrite
    | ProcessExecute
    | ClockRead
    | RandomRead
    | ConsoleWrite
    | CacheRead
    | CacheWrite
    | StoreRead
    | StoreWrite
    | ResponseWrite

module IrEffects =
    let format = function
        | IrEffect.FileRead -> "fs.read"
        | IrEffect.FileWrite -> "fs.write"
        | IrEffect.DatabaseRead -> "db.read"
        | IrEffect.DatabaseWrite -> "db.write"
        | IrEffect.NetworkRead -> "network.read"
        | IrEffect.NetworkWrite -> "network.write"
        | IrEffect.ProcessExecute -> "process.execute"
        | IrEffect.ClockRead -> "clock.read"
        | IrEffect.RandomRead -> "random.read"
        | IrEffect.ConsoleWrite -> "console.write"
        | IrEffect.CacheRead -> "cache.read"
        | IrEffect.CacheWrite -> "cache.write"
        | IrEffect.StoreRead -> "store.read"
        | IrEffect.StoreWrite -> "store.write"
        | IrEffect.ResponseWrite -> "response.write"

    let ofName = function
        | "fs.read" -> Some IrEffect.FileRead
        | "fs.write" -> Some IrEffect.FileWrite
        | "db.read" -> Some IrEffect.DatabaseRead
        | "db.write" -> Some IrEffect.DatabaseWrite
        | "network.read" -> Some IrEffect.NetworkRead
        | "network.write" -> Some IrEffect.NetworkWrite
        | "process.execute" -> Some IrEffect.ProcessExecute
        | "clock.read" -> Some IrEffect.ClockRead
        | "random.read" -> Some IrEffect.RandomRead
        | "console.write" -> Some IrEffect.ConsoleWrite
        | "cache.read" -> Some IrEffect.CacheRead
        | "cache.write" -> Some IrEffect.CacheWrite
        | "store.read" -> Some IrEffect.StoreRead
        | "store.write" -> Some IrEffect.StoreWrite
        | "response.write" -> Some IrEffect.ResponseWrite
        | _ -> None

    let names effects = effects |> Set.toList |> List.map format |> List.sort

/// Closed executable types. Source type names and inference variables are absent.
type IrType =
    | IrInt
    | IrFloat
    | IrBool
    | IrString
    | IrBytes
    | IrJson
    | IrUnit
    | IrList of IrType
    | IrOption of IrType
    | IrResult of IrType * IrType
    | IrNominal of ProgramTypeKey

type IrCallTarget =
    | UserWordTarget of WordId * int
    | PrimitiveTarget of PrimitiveId
    | HostOperationTarget of HostOperationId
    | GeneratedWordTarget of WordId * int

/// A call-site specialization. In particular, multiple calls to one polymorphic
/// primitive carry independent concrete signatures here.
type IrResolvedCall =
    { ResolvedTarget: IrCallTarget
      ResolvedName: string
      InputTypes: IrType list
      OutputTypes: IrType list
      ResolvedDeclaredEffects: Set<IrEffect>
      ResolvedEffects: Set<IrEffect> }

type IrGeneratedOperation =
    | MakeRecordOperation of ProgramTypeKey
    | GetRecordFieldOperation of ProgramTypeKey * int
    | WrapScalarOperation of ProgramTypeKey
    | UnwrapScalarOperation of ProgramTypeKey
    | MakeEnumCaseOperation of ProgramTypeKey * int

type IrRecordField =
    { FieldIndex: int
      FieldName: string
      FieldType: IrType }

type IrRecordDefinitionData =
    { TypeKey: ProgramTypeKey
      TypeName: string
      RecordFields: IrRecordField list
      ValidatorCall: IrResolvedCall option }

type IrScalarDefinitionData =
    { TypeKey: ProgramTypeKey
      TypeName: string
      BaseType: IrType
      ValidatorCall: IrResolvedCall option }

type IrEnumDefinitionData =
    { TypeKey: ProgramTypeKey
      TypeName: string
      Cases: string list }

type IrNominalDefinition =
    | IrRecordDefinition of IrRecordDefinitionData
    | IrScalarDefinition of IrScalarDefinitionData
    | IrEnumDefinition of IrEnumDefinitionData

type IrGeneratedTarget =
    { TargetId: WordId
      TargetRevision: int
      TargetName: string
      Operation: IrGeneratedOperation
      InputTypes: IrType list
      OutputTypes: IrType list
      TargetDeclaredEffects: Set<IrEffect>
      TargetEffects: Set<IrEffect>
      SourceSite: SourceSiteId option }

type IrShape =
    { StackTypes: IrType list
      LocalTypes: Map<LocalSlot, IrType> }

module IrHtml =
    /// The built-in markup validator that html templates satisfy by construction.
    let validatorPrimitive = "string.html-fragment?"

    let isHtmlValidator (validator: IrResolvedCall option) =
        match validator with
        | Some call -> call.ResolvedTarget = PrimitiveTarget(PrimitiveId validatorPrimitive)
        | None -> false

    /// Reserved call name the parser gives an html"…" template.
    let templateCallName = "%html-template"

[<RequireQualifiedAccess>]
type IrOperation =
    | Constant of Literal * IrType
    | Call of IrResolvedCall
    | ListEmpty of IrType
    | ListSingleton of IrType
    | ListOf of IrType * count: int
    | OptionNone of IrType
    | OptionSome of IrType
    | ResultOk of IrType * IrType
    | ResultError of IrType * IrType
    | ListMap of IrResolvedCall * IrType * IrType
    | ListFilter of IrResolvedCall * IrType
    | ListEach of IrResolvedCall * IrType
    /// Strict left fold. The input stack suffix is List<Item> then Accumulator;
    /// the callback receives Accumulator then Item and returns Accumulator.
    | ListFold of IrResolvedCall * ItemType: IrType * AccumulatorType: IrType
    /// Map with a borrowed context. The input stack suffix is List<Item> then
    /// Context; the callback receives Context then Item and returns Output.
    | ListMapWithContext of IrResolvedCall * ContextType: IrType * ItemType: IrType * OutputType: IrType
    | StoreLocal of LocalSlot
    | LoadLocal of LocalSlot
    | Scope of IrBlock
    /// Like Scope, but the block must push exactly one value; the owning AOT
    /// backend moves that value to the block's arena mark and rewinds past it.
    | Compact of IrBlock
    | If of IrBlock * IrBlock
    | MatchOption of SomeLocal: LocalSlot * SomeBlock: IrBlock * NoneBlock: IrBlock
    | MatchResult of OkLocal: LocalSlot * ErrorLocal: LocalSlot * OkBlock: IrBlock * ErrorBlock: IrBlock
    | MatchEnum of TypeKey: ProgramTypeKey * Cases: (int * IrBlock) list
    | MakeRecord of IrResolvedCall * ProgramTypeKey * IrResolvedCall option
    | GetRecordField of IrResolvedCall * ProgramTypeKey * int
    | WrapScalar of IrResolvedCall * ProgramTypeKey * IrResolvedCall option
    | UnwrapScalar of IrResolvedCall * ProgramTypeKey
    | MakeEnumCase of IrResolvedCall * ProgramTypeKey * int
    /// html"…" template: pops one value per hole (String holes are escaped like
    /// string.html-escape, Html holes are inserted as-is) and pushes the joined
    /// markup as the Html type. The verifier re-checks the literal skeleton, so
    /// the result satisfies `string.html-fragment?` by construction and no
    /// backend runs the validator.
    | HtmlTemplate of HtmlKey: ProgramTypeKey * Parts: HtmlTemplatePart list
    /// Pops one value and overwrites an existing local of exactly that type
    /// (a Flow `var`). Unlike StoreLocal it never introduces a slot.
    | AssignLocal of LocalSlot
    /// Counted loop: pops start then end (Int). The body runs for each index in
    /// [start, end) with IndexLocal bound; its stack and outer locals are
    /// loop-invariant. Every iteration charges the loop step budget.
    | ForRange of IndexLocal: LocalSlot * Body: IrBlock
    /// List loop: pops List<ItemType>; the body runs once per item in order with
    /// ItemLocal (and the optional Int IndexLocal) bound.
    | ForList of ItemType: IrType * ItemLocal: LocalSlot * IndexLocal: LocalSlot option * Body: IrBlock
    /// Leaves the innermost enclosing loop. Must end its block.
    | Break
    /// Starts the innermost enclosing loop's next iteration. Must end its block.
    | Continue

and IrInstruction =
    { Site: SourceSiteId
      Operation: IrOperation }

and IrBlock =
    { EntryShape: IrShape
      ExitShape: IrShape
      Code: IrInstruction list }

module IrLoops =
    /// Per-invocation loop iteration budget shared by the interpreter and the
    /// native owning backend. Exceeding it fails with RUNTIME_LOOP_BUDGET_EXCEEDED.
    [<Literal>]
    let DefaultIterationBudget = 10_000_000

    let budgetExceededCode = "RUNTIME_LOOP_BUDGET_EXCEEDED"

    /// Outer local slots that a block (including nested blocks) reassigns.
    let rec assignedSlots (block: IrBlock) : Set<LocalSlot> =
        block.Code
        |> List.fold (fun found instruction ->
            match instruction.Operation with
            | IrOperation.AssignLocal slot -> Set.add slot found
            | IrOperation.If(left, right) -> Set.unionMany [ found; assignedSlots left; assignedSlots right ]
            | IrOperation.Scope inner | IrOperation.Compact inner
            | IrOperation.ForRange(_, inner) | IrOperation.ForList(_, _, _, inner) -> Set.union found (assignedSlots inner)
            | IrOperation.MatchOption(_, left, right) | IrOperation.MatchResult(_, _, left, right) -> Set.unionMany [ found; assignedSlots left; assignedSlots right ]
            | IrOperation.MatchEnum(_, cases) -> cases |> List.fold (fun acc (_, caseBlock) -> Set.union acc (assignedSlots caseBlock)) found
            | _ -> found) Set.empty

type IrSourceSite =
    { SiteOwner: WordId option
      SiteSpan: SourceSpan
      SourceKind: string }

type IrCoverageObligations =
    { CoveredSites: Set<SourceSiteId>
      BranchOutcomes: Map<SourceSiteId, string list> }

type IrFunction =
    { FunctionId: WordId
      FunctionRevision: int
      FunctionName: string
      InputTypes: IrType list
      OutputTypes: IrType list
      FunctionDeclaredEffects: Set<IrEffect>
      FunctionInferredEffects: Set<IrEffect>
      LocalNames: Map<LocalSlot, string>
      FunctionBody: IrBlock
      /// `inline fn` (report 280): a backend hint; interpretation ignores it.
      FunctionInline: bool }

type IrProgram =
    { NominalTypesByKey: Map<ProgramTypeKey, IrNominalDefinition>
      FunctionsById: Map<WordId, IrFunction>
      GeneratedTargetsById: Map<WordId, IrGeneratedTarget>
      SourceMap: Map<SourceSiteId, IrSourceSite>
      CoverageByWord: Map<WordId, IrCoverageObligations> }

/// A standalone executable body (eval, test, or example) is verified against
/// one complete program snapshot but is not inserted into its word dictionary.
type IrExecutableBody =
    { BodyName: string
      BodyInputTypes: IrType list
      BodyOutputTypes: IrType list
      BodyDeclaredEffects: Set<IrEffect>
      BodyInferredEffects: Set<IrEffect>
      BodyLocalNames: Map<LocalSlot, string>
      BodyBlock: IrBlock
      BodySourceMap: Map<SourceSiteId, IrSourceSite>
      BodyCoverage: IrCoverageObligations }

type private IrCallGraphNode =
    | IrFunctionNode of WordId
    | IrGeneratedNode of WordId

/// Generic patterns belong to the compiler's primitive catalog, never to an
/// executable program or a concrete call site.
type IrTypePattern =
    | PatternInt
    | PatternFloat
    | PatternBool
    | PatternString
    | PatternBytes
    | PatternJson
    | PatternUnit
    | PatternList of IrTypePattern
    | PatternOption of IrTypePattern
    | PatternResult of IrTypePattern * IrTypePattern
    | PatternVariable of int

type IrPrimitiveContract =
    { Primitive: PrimitiveId
      InputPatterns: IrTypePattern list
      OutputPatterns: IrTypePattern list
      PrimitiveEffects: Set<IrEffect> }

type IrPrimitiveCatalog = Map<PrimitiveId, IrPrimitiveContract>

/// Exact, nominally resolved contract retained only on compiler-minted program
/// handles. A raw IrProgram cannot carry executable host authority.
type IrHostOperationContract =
    { OperationId: HostOperationId
      OperationName: string
      InputTypes: IrType list
      OutputTypes: IrType list
      OperationEffects: Set<IrEffect> }

type IrHostOperationCatalog = Map<HostOperationId, IrHostOperationContract>

/// Immutable verified-program handle. The constructor is assembly-internal so
/// host backends outside AgentLang.Core cannot forge an executable snapshot.
/// Backends accept only instances minted by Compiler lowering and must match
/// the retained catalog against their canonical host registry.
[<Sealed>]
type VerifiedIrProgram internal (program: IrProgram, catalog: IrPrimitiveCatalog, hostCatalog: IrHostOperationCatalog, backendExecutable: bool, compilerSnapshotFingerprint: string option) =
    member internal _.Program = program
    member internal _.Catalog = catalog
    member internal _.HostCatalog = hostCatalog
    member internal _.BackendExecutable = backendExecutable
    member internal _.CompilerSnapshotFingerprint = compilerSnapshotFingerprint

module VerifiedIrProgram =
    /// Read-only inspection does not grant execution authority; backends must
    /// still accept a VerifiedIrProgram rather than a raw IrProgram.
    let inspect (verified: VerifiedIrProgram) = verified.Program

    /// Whether the compiler's trusted lowering path verified this snapshot.
    /// This flag alone does not grant host access; backends must also compare
    /// the retained catalog with their canonical registry.
    let isBackendExecutable (verified: VerifiedIrProgram) = verified.BackendExecutable

    /// Read-only host contracts do not grant provider access; Runtime separately
    /// compares them to its exact Engine manifest before dispatch.
    let hostOperationContracts (verified: VerifiedIrProgram) = verified.HostCatalog

    /// Native backends have no host-operation dispatch path and reject the
    /// feature explicitly instead of falling through to another executor.
    let requireNoHostOperations (verified: VerifiedIrProgram) =
        if not (Map.isEmpty verified.HostCatalog) then
            Diagnostics.raiseError "IR_NATIVE_HOST_OPERATION_UNSUPPORTED" "Native backends do not execute host operations; use the interpreter with its registered provider." None None
                [ "program without host operations" ] (verified.HostCatalog |> Map.toList |> List.map (fun (id, _) -> sprintf "%A" id))

    let requireBackendRegistry (canonicalCatalog: IrPrimitiveCatalog) (verified: VerifiedIrProgram) =
        if not verified.BackendExecutable then
            Diagnostics.raiseError "IR_BACKEND_UNTRUSTED_PROGRAM" "A model-only verifier result cannot be executed by a backend." None None [ "compiler-lowered verified snapshot" ] [ "verifier-only snapshot" ]
        if verified.Catalog <> canonicalCatalog then
            Diagnostics.raiseError "IR_BACKEND_CATALOG_MISMATCH" "Verified primitive contracts do not match the backend's canonical host registry." None None [ "canonical primitive catalog" ] [ "different primitive catalog" ]

[<Sealed>]
type VerifiedIrBody internal (program: VerifiedIrProgram, body: IrExecutableBody) =
    member internal _.Program = program
    member internal _.Body = body

module VerifiedIrBody =
    /// Read-only body and program inspection does not create backend authority.
    let inspect (verified: VerifiedIrBody) = verified.Body
    let program (verified: VerifiedIrBody) = verified.Program

module IrTypes =
    let rec format = function
        | IrInt -> "Int"
        | IrFloat -> "Float"
        | IrBool -> "Bool"
        | IrString -> "String"
        | IrBytes -> "Bytes"
        | IrJson -> "Json"
        | IrUnit -> "Unit"
        | IrList item -> $"List<{format item}>"
        | IrOption item -> $"Option<{format item}>"
        | IrResult(ok, error) -> $"Result<{format ok}, {format error}>"
        | IrNominal(ProgramTypeKey key) -> $"@type{key}"

    let rec hasNominal key = function
        | IrNominal candidate -> candidate = key
        | IrList item | IrOption item -> hasNominal key item
        | IrResult(ok, error) -> hasNominal key ok || hasNominal key error
        | _ -> false

module IrVerifier =
    let private failure code message expected actual =
        Diagnostics.raiseError code message None None expected actual

    let private valueType = function
        | LInt _ -> IrInt
        | LFloat _ -> IrFloat
        | LBool _ -> IrBool
        | LString _ -> IrString
        | LUnit -> IrUnit

    let private sourceSpan (program: IrProgram) site =
        program.SourceMap
        |> Map.tryFind site
        |> Option.map (fun source -> Some source.SiteSpan)
        |> Option.defaultValue None

    let private verifyIrType (program: IrProgram) owner site ty =
        let rec verifyType = function
            | IrInt | IrFloat | IrBool | IrString | IrBytes | IrJson | IrUnit -> ()
            | IrList item | IrOption item -> verifyType item
            | IrResult(ok, error) -> verifyType ok; verifyType error
            | IrNominal key when program.NominalTypesByKey.ContainsKey key -> ()
            | IrNominal(ProgramTypeKey key) ->
                Diagnostics.raiseError "IR_UNKNOWN_TYPE_KEY" "Executable IR contains a nominal key absent from its snapshot type table." owner (site |> Option.bind (sourceSpan program)) [ "known ProgramTypeKey" ] [ string key ]
        verifyType ty

    let private verifyCatalog (catalog: IrPrimitiveCatalog) =
        let rec patternVariables pattern =
            match pattern with
            | PatternVariable variable -> Set.singleton variable
            | PatternList item | PatternOption item -> patternVariables item
            | PatternResult(ok, error) -> Set.union (patternVariables ok) (patternVariables error)
            | _ -> Set.empty
        for KeyValue(id, contract) in catalog do
            if id <> contract.Primitive then
                failure "IR_PRIMITIVE_ID_MISMATCH" "Primitive catalog key differs from its contract identity." [ sprintf "%A" id ] [ sprintf "%A" contract.Primitive ]
            let inputVariables = contract.InputPatterns |> List.map patternVariables |> Set.unionMany
            let outputVariables = contract.OutputPatterns |> List.map patternVariables |> Set.unionMany
            if outputVariables |> Set.exists (fun variable -> variable < 0 || not (inputVariables.Contains variable)) then
                failure "IR_PRIMITIVE_CONTRACT_VARIABLE" "Primitive output type variables must be nonnegative and constrained by an input." (inputVariables |> Set.toList |> List.map string) (outputVariables |> Set.toList |> List.map string)
            if inputVariables |> Set.exists (fun variable -> variable < 0) then
                failure "IR_PRIMITIVE_CONTRACT_VARIABLE" "Primitive type variables must be nonnegative." [] (inputVariables |> Set.toList |> List.map string)

    let private verifyPattern (contract: IrPrimitiveContract) (call: IrResolvedCall) =
        let substitutions = System.Collections.Generic.Dictionary<int, IrType>()
        let rec unify pattern actual =
            match pattern, actual with
            | PatternInt, IrInt | PatternFloat, IrFloat | PatternBool, IrBool
            | PatternBytes, IrBytes -> true
            | PatternJson, IrJson -> true
            | PatternString, IrString | PatternUnit, IrUnit -> true
            | PatternVariable variable, actual ->
                match substitutions.TryGetValue variable with
                | true, previous -> previous = actual
                | _ -> substitutions[variable] <- actual; true
            | PatternList pattern, IrList actual
            | PatternOption pattern, IrOption actual -> unify pattern actual
            | PatternResult(patternOk, patternError), IrResult(actualOk, actualError) ->
                unify patternOk actualOk && unify patternError actualError
            | _ -> false
        contract.InputPatterns.Length = call.InputTypes.Length
        && contract.OutputPatterns.Length = call.OutputTypes.Length
        && (List.zip contract.InputPatterns call.InputTypes |> List.forall (fun (pattern, actual) -> unify pattern actual))
        && (List.zip contract.OutputPatterns call.OutputTypes |> List.forall (fun (pattern, actual) -> unify pattern actual))

    let private verifyCall (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) sourceOwner site (call: IrResolvedCall) =
        let failCall code expected actual =
            Diagnostics.raiseError code $"Resolved call '{call.ResolvedName}' is inconsistent with its target." (Some sourceOwner) (sourceSpan program site) expected actual
        if String.IsNullOrWhiteSpace call.ResolvedName then
            failCall "IR_CALL_NAME_MISSING" [ "nonempty display name" ] [ call.ResolvedName ]
        call.InputTypes @ call.OutputTypes |> List.iter (verifyIrType program (Some sourceOwner) (Some site))
        if call.ResolvedDeclaredEffects <> call.ResolvedEffects then
            failCall "IR_CALL_EFFECT_MISMATCH" (IrEffects.names call.ResolvedDeclaredEffects) (IrEffects.names call.ResolvedEffects)
        match call.ResolvedTarget with
        | UserWordTarget(id, revision) ->
            match program.FunctionsById.TryFind id with
            | None -> failCall "IR_UNKNOWN_WORD_ID" [ "known user WordId" ] [ sprintf "%A" id ]
            | Some target ->
                if target.FunctionRevision <> revision then failCall "IR_WORD_REVISION_MISMATCH" [ string target.FunctionRevision ] [ string revision ]
                if target.InputTypes <> call.InputTypes || target.OutputTypes <> call.OutputTypes then
                    failCall "IR_CALL_SIGNATURE_MISMATCH" (target.InputTypes |> List.map IrTypes.format) (call.InputTypes |> List.map IrTypes.format)
                if target.FunctionDeclaredEffects <> call.ResolvedDeclaredEffects || target.FunctionDeclaredEffects <> call.ResolvedEffects then
                    failCall "IR_CALL_EFFECT_MISMATCH" (IrEffects.names target.FunctionDeclaredEffects) (IrEffects.names call.ResolvedEffects)
        | PrimitiveTarget id ->
            match catalog.TryFind id with
            | None -> failCall "IR_UNKNOWN_PRIMITIVE_ID" [ "catalog primitive" ] [ sprintf "%A" id ]
            | Some contract ->
                if not (verifyPattern contract call) then
                    failCall "IR_CALL_SIGNATURE_MISMATCH" [ "valid concrete primitive instantiation" ] (call.InputTypes |> List.map IrTypes.format)
                if contract.PrimitiveEffects <> call.ResolvedDeclaredEffects || contract.PrimitiveEffects <> call.ResolvedEffects then
                    failCall "IR_CALL_EFFECT_MISMATCH" (IrEffects.names contract.PrimitiveEffects) (IrEffects.names call.ResolvedEffects)
        | HostOperationTarget id ->
            match hostCatalog.TryFind id with
            | None -> failCall "IR_UNKNOWN_HOST_OPERATION_ID" [ "verified host-operation contract" ] [ sprintf "%A" id ]
            | Some contract ->
                if contract.OperationId <> id then
                    failCall "IR_HOST_OPERATION_ID_MISMATCH" [ sprintf "%A" id ] [ sprintf "%A" contract.OperationId ]
                if call.ResolvedName <> contract.OperationName then
                    failCall "IR_HOST_OPERATION_NAME_MISMATCH" [ contract.OperationName ] [ call.ResolvedName ]
                if contract.InputTypes <> call.InputTypes || contract.OutputTypes <> call.OutputTypes then
                    failCall "IR_HOST_OPERATION_SIGNATURE_MISMATCH"
                        ((contract.InputTypes |> List.map IrTypes.format) @ [ "->" ] @ (contract.OutputTypes |> List.map IrTypes.format))
                        ((call.InputTypes |> List.map IrTypes.format) @ [ "->" ] @ (call.OutputTypes |> List.map IrTypes.format))
                if contract.OperationEffects <> call.ResolvedDeclaredEffects || contract.OperationEffects <> call.ResolvedEffects then
                    failCall "IR_HOST_OPERATION_EFFECT_MISMATCH" (IrEffects.names contract.OperationEffects) (IrEffects.names call.ResolvedEffects)
        | GeneratedWordTarget(id, revision) ->
            match program.GeneratedTargetsById.TryFind id with
            | None -> failCall "IR_UNKNOWN_GENERATED_ID" [ "known generated WordId" ] [ sprintf "%A" id ]
            | Some target ->
                if target.TargetRevision <> revision then failCall "IR_WORD_REVISION_MISMATCH" [ string target.TargetRevision ] [ string revision ]
                if target.InputTypes <> call.InputTypes || target.OutputTypes <> call.OutputTypes then
                    failCall "IR_CALL_SIGNATURE_MISMATCH" (target.InputTypes |> List.map IrTypes.format) (call.InputTypes |> List.map IrTypes.format)
                if target.TargetDeclaredEffects <> call.ResolvedDeclaredEffects || target.TargetEffects <> call.ResolvedEffects then
                    failCall "IR_CALL_EFFECT_MISMATCH" (IrEffects.names target.TargetEffects) (IrEffects.names call.ResolvedEffects)

    let private verifyNominalTypes (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) =
        let names = ResizeArray<string>()
        for KeyValue(key, definition) in program.NominalTypesByKey do
            match definition with
            | IrRecordDefinition record ->
                if record.TypeKey <> key then failure "IR_TYPE_KEY_MISMATCH" "Record type table key does not match its definition." [ string (let (ProgramTypeKey value) = key in value) ] [ string (let (ProgramTypeKey value) = record.TypeKey in value) ]
                if key < ProgramTypeKey 0 then failure "IR_TYPE_KEY_INVALID" "ProgramTypeKey must be nonnegative." [ "nonnegative key" ] [ sprintf "%A" key ]
                if String.IsNullOrWhiteSpace record.TypeName then failure "IR_TYPE_NAME_MISSING" "Record type name must be nonempty." [ "nonempty type name" ] [ record.TypeName ]
                names.Add record.TypeName
                let indexes = record.RecordFields |> List.map (fun field -> field.FieldIndex)
                if indexes <> [ 0 .. record.RecordFields.Length - 1 ] then failure "IR_RECORD_FIELD_LAYOUT" $"Record '{record.TypeName}' has a noncanonical field layout." [ "contiguous declared field indexes" ] (indexes |> List.map string)
                let fieldNames = record.RecordFields |> List.map (fun field -> field.FieldName)
                if fieldNames |> List.exists String.IsNullOrWhiteSpace || (Set.ofList fieldNames).Count <> fieldNames.Length then
                    failure "IR_RECORD_FIELD_NAMES" $"Record '{record.TypeName}' has an empty or duplicate field name." [ "unique nonempty field names" ] fieldNames
                for field in record.RecordFields do verifyIrType program (Some record.TypeName) None field.FieldType
                match record.ValidatorCall with
                | Some validator ->
                    match validator.ResolvedTarget with
                    | HostOperationTarget _ -> failure "IR_TYPE_VALIDATOR_HOST_OPERATION" "Nominal type validators cannot call registered host operations." [ "pure authored function" ] [ validator.ResolvedName ]
                    | _ -> ()
                    if validator.InputTypes <> [ IrNominal key ] || validator.OutputTypes <> [ IrBool ] then
                        failure "IR_RECORD_VALIDATOR_SIGNATURE" $"Record '{record.TypeName}' validator has a malformed resolved signature." [ IrTypes.format (IrNominal key) + " -> Bool" ] [ String.concat " " (validator.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (validator.OutputTypes |> List.map IrTypes.format) ]
                    if not (Set.isEmpty validator.ResolvedEffects) then
                        failure "IR_RECORD_VALIDATOR_EFFECT" $"Record '{record.TypeName}' validator must be pure." [] (IrEffects.names validator.ResolvedEffects)
                    verifyCall program catalog hostCatalog record.TypeName (SourceSiteId(None, 0)) validator
                | None -> ()
            | IrScalarDefinition scalar ->
                if scalar.TypeKey <> key then failure "IR_TYPE_KEY_MISMATCH" "Scalar type table key does not match its definition." [] []
                if key < ProgramTypeKey 0 then failure "IR_TYPE_KEY_INVALID" "ProgramTypeKey must be nonnegative." [ "nonnegative key" ] [ sprintf "%A" key ]
                if String.IsNullOrWhiteSpace scalar.TypeName then failure "IR_TYPE_NAME_MISSING" "Scalar type name must be nonempty." [ "nonempty type name" ] [ scalar.TypeName ]
                names.Add scalar.TypeName
                if IrTypes.hasNominal key scalar.BaseType then
                    failure "IR_SCALAR_CYCLE" $"Scalar '{scalar.TypeName}' cannot use itself as its base type." [ "base type independent of this scalar" ] [ IrTypes.format scalar.BaseType ]
                match scalar.BaseType with
                | IrInt | IrFloat | IrBool | IrString -> ()
                | _ -> failure "IR_SCALAR_BASE_UNSUPPORTED" $"Scalar '{scalar.TypeName}' has a base type unsupported by source validation." [ "Int | Float | Bool | String" ] [ IrTypes.format scalar.BaseType ]
                verifyIrType program (Some scalar.TypeName) None scalar.BaseType
                match scalar.ValidatorCall with
                | Some validator ->
                    match validator.ResolvedTarget with
                    | HostOperationTarget _ -> failure "IR_TYPE_VALIDATOR_HOST_OPERATION" "Nominal type validators cannot call registered host operations." [ "pure authored function" ] [ validator.ResolvedName ]
                    | _ -> ()
                    if validator.InputTypes <> [ scalar.BaseType ] || validator.OutputTypes <> [ IrBool ] then
                        failure "IR_SCALAR_VALIDATOR_SIGNATURE" $"Scalar '{scalar.TypeName}' validator has a malformed resolved signature." [ IrTypes.format scalar.BaseType + " -> Bool" ] [ String.concat " " (validator.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (validator.OutputTypes |> List.map IrTypes.format) ]
                    if not (Set.isEmpty validator.ResolvedEffects) then
                        failure "IR_SCALAR_VALIDATOR_EFFECT" $"Scalar '{scalar.TypeName}' validator must be pure." [] (IrEffects.names validator.ResolvedEffects)
                    verifyCall program catalog hostCatalog scalar.TypeName (SourceSiteId(None, 0)) validator
                | None -> ()
            | IrEnumDefinition enumDefinition ->
                if enumDefinition.TypeKey <> key then failure "IR_TYPE_KEY_MISMATCH" "Enum type table key does not match its definition." [] []
                if key < ProgramTypeKey 0 then failure "IR_TYPE_KEY_INVALID" "ProgramTypeKey must be nonnegative." [ "nonnegative key" ] [ sprintf "%A" key ]
                if String.IsNullOrWhiteSpace enumDefinition.TypeName then failure "IR_TYPE_NAME_MISSING" "Enum type name must be nonempty." [ "nonempty type name" ] [ enumDefinition.TypeName ]
                names.Add enumDefinition.TypeName
                if List.isEmpty enumDefinition.Cases then failure "IR_ENUM_EMPTY" $"Enum '{enumDefinition.TypeName}' must contain at least one case." [ "one or more cases" ] []
                let validCaseName (name: string) =
                    not (String.IsNullOrWhiteSpace name)
                    && (Char.IsLetter name[0] || name[0] = '_')
                    && (name |> Seq.skip 1 |> Seq.forall (fun value -> Char.IsLetterOrDigit value || value = '_' || value = '-' || value = '?' || value = '!'))
                let invalid = enumDefinition.Cases |> List.filter (validCaseName >> not)
                let duplicates = enumDefinition.Cases |> List.groupBy id |> List.choose (fun (name, values) -> if values.Length > 1 then Some name else None)
                let reserved = enumDefinition.Cases |> List.filter (fun name -> name = "some" || name = "none" || name = "ok" || name = "error")
                if not invalid.IsEmpty || not duplicates.IsEmpty || not reserved.IsEmpty then
                    failure "IR_ENUM_CASE_LAYOUT" $"Enum '{enumDefinition.TypeName}' has invalid, duplicate, or reserved case names." [ "unique valid non-reserved case names" ] (invalid @ duplicates @ reserved)
        if (Set.ofSeq names).Count <> names.Count then
            failure "IR_TYPE_NAME_COLLISION" "Nominal type names must be unique within one executable snapshot." [ "unique record, scalar, and enum names" ] (List.ofSeq names)

    let private verifyGeneratedTarget (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) (id: WordId) (target: IrGeneratedTarget) =
        if target.TargetId <> id then failure "IR_GENERATED_ID_MISMATCH" "Generated target map key differs from its identity." [ sprintf "%A" target.TargetId ] [ sprintf "%A" id ]
        let (WordId idText) = id
        if String.IsNullOrWhiteSpace idText || String.IsNullOrWhiteSpace target.TargetName then
            failure "IR_GENERATED_ID_INVALID" "Generated target identity and display name must be nonempty." [ "nonempty identity and name" ] [ idText; target.TargetName ]
        if target.TargetRevision < 0 then failure "IR_INVALID_REVISION" "Generated target revision cannot be negative." [ "nonnegative revision" ] [ string target.TargetRevision ]
        let sourceSite =
            match target.SourceSite with
            | None -> failure "IR_GENERATED_SOURCE_SITE_MISSING" "Generated operations must retain the type or field declaration source site." [ "mapped declaration source site" ] [ target.TargetName ]
            | Some site -> site
        match program.SourceMap.TryFind sourceSite with
        | Some source when source.SiteOwner = Some id -> ()
        | Some source -> Diagnostics.raiseError "IR_SOURCE_OWNER_MISMATCH" "Generated operation source map belongs to a different identity." (Some target.TargetName) (Some source.SiteSpan) [ sprintf "%A" id ] [ sprintf "%A" source.SiteOwner ]
        | None -> failure "IR_SOURCE_SITE_MISSING" "Generated operation source site is absent from the program source map." [ sprintf "%A" sourceSite ] []
        match target.Operation with
        | MakeRecordOperation key ->
            match program.NominalTypesByKey.TryFind key with
            | Some(IrRecordDefinition record) when target.InputTypes = (record.RecordFields |> List.map (fun field -> field.FieldType)) && target.OutputTypes = [ IrNominal key ] ->
                match record.ValidatorCall with
                | Some validator when validator.ResolvedEffects <> target.TargetEffects -> failure "IR_GENERATED_EFFECT_MISMATCH" "Record constructor effects do not include its validator effects." (IrEffects.names validator.ResolvedEffects) (IrEffects.names target.TargetEffects)
                | _ -> ()
            | _ -> failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated record constructor '{target.TargetName}' disagrees with its type layout." [ "record fields -> record" ] (target.InputTypes |> List.map IrTypes.format)
        | GetRecordFieldOperation(key, fieldIndex) ->
            match program.NominalTypesByKey.TryFind key with
            | Some(IrRecordDefinition record) when fieldIndex >= 0 && fieldIndex < record.RecordFields.Length && target.InputTypes = [ IrNominal key ] && target.OutputTypes = [ record.RecordFields[fieldIndex].FieldType ] -> ()
            | _ -> failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated record accessor '{target.TargetName}' disagrees with its field layout." [ "record -> field type" ] (target.OutputTypes |> List.map IrTypes.format)
        | WrapScalarOperation key ->
            match program.NominalTypesByKey.TryFind key with
            | Some(IrScalarDefinition scalar) when target.InputTypes = [ scalar.BaseType ] && target.OutputTypes = [ IrNominal key ] ->
                match scalar.ValidatorCall with
                | Some validator when validator.ResolvedEffects <> target.TargetEffects -> failure "IR_GENERATED_EFFECT_MISMATCH" "Scalar constructor effects do not include its validator effects." (IrEffects.names validator.ResolvedEffects) (IrEffects.names target.TargetEffects)
                | _ -> ()
            | _ -> failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated scalar constructor '{target.TargetName}' disagrees with its base type." [ "base type -> nominal type" ] (target.InputTypes |> List.map IrTypes.format)
        | UnwrapScalarOperation key ->
            match program.NominalTypesByKey.TryFind key with
            | Some(IrScalarDefinition scalar) when target.InputTypes = [ IrNominal key ] && target.OutputTypes = [ scalar.BaseType ] -> ()
            | _ -> failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated scalar accessor '{target.TargetName}' disagrees with its base type." [ "nominal type -> base type" ] (target.OutputTypes |> List.map IrTypes.format)
        | MakeEnumCaseOperation(key, caseIndex) ->
            match program.NominalTypesByKey.TryFind key with
            | Some(IrEnumDefinition enumDefinition) when caseIndex >= 0 && caseIndex < enumDefinition.Cases.Length ->
                let expectedName = enumDefinition.TypeName + "." + enumDefinition.Cases[caseIndex]
                if target.TargetName <> expectedName || target.InputTypes <> [] || target.OutputTypes <> [ IrNominal key ] then
                    failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated enum constructor '{target.TargetName}' disagrees with its frozen case table." [ expectedName + ": () -> enum" ] [ target.TargetName; target.InputTypes |> List.map IrTypes.format |> String.concat " "; target.OutputTypes |> List.map IrTypes.format |> String.concat " " ]
            | _ -> failure "IR_GENERATED_SIGNATURE_MISMATCH" $"Generated enum constructor '{target.TargetName}' refers to a missing enum case." [ "known enum case index" ] [ string caseIndex ]
        let call =
            { ResolvedTarget = GeneratedWordTarget(id, target.TargetRevision)
              ResolvedName = target.TargetName
              InputTypes = target.InputTypes
              OutputTypes = target.OutputTypes
              ResolvedDeclaredEffects = target.TargetDeclaredEffects
              ResolvedEffects = target.TargetEffects }
        verifyCall program catalog hostCatalog target.TargetName sourceSite call

    let private verifyBlock (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) (owner: IrFunction) (sourceOwnerId: WordId option) (block: IrBlock) =
        let verifyShape site shape =
            shape.StackTypes |> List.iter (verifyIrType program (Some owner.FunctionName) (Some site))
            for KeyValue(slot, ty) in shape.LocalTypes do
                verifyIrType program (Some owner.FunctionName) (Some site) ty
                if not (owner.LocalNames.ContainsKey slot) then
                    Diagnostics.raiseError "IR_UNKNOWN_LOCAL_SLOT" "Block shape contains a local slot absent from the function layout." (Some owner.FunctionName) (sourceSpan program site) [] [ sprintf "%A" slot ]
        // Enclosing loop contexts: Some loop-invariant stack for a loop body, None
        // for a compact block (loop control may not cross a relocation boundary).
        let loopContexts = System.Collections.Generic.Stack<IrType list option>()
        let rec verifyNested (instructions: IrInstruction list) (shape: IrShape) =
            let mutable currentShape = shape
            let mutable accumulatedEffects = Set.empty<IrEffect>
            let mutable terminated = false
            // Flat blocks can contain thousands of operations. Walk the list
            // iteratively so valid generated IR cannot exhaust the host stack;
            // structured branches still recurse through verifyBlockNested.
            for instruction in instructions do
                if terminated then
                    Diagnostics.raiseError "IR_LOOP_CONTROL_NOT_TERMINAL" "break/continue must be the last instruction of its block." (Some owner.FunctionName) (sourceSpan program instruction.Site) [] [ sprintf "%A" instruction.Operation ]
                verifyShape instruction.Site currentShape
                let shape = currentShape
                let sourceOwner = Some owner.FunctionName
                match program.SourceMap.TryFind instruction.Site with
                | None -> Diagnostics.raiseError "IR_SOURCE_SITE_MISSING" "IR instruction has no source-map entry." sourceOwner None [ sprintf "%A" instruction.Site ] []
                | Some source when source.SiteOwner <> sourceOwnerId ->
                    Diagnostics.raiseError "IR_SOURCE_OWNER_MISMATCH" "IR instruction source map belongs to a different word." sourceOwner (Some source.SiteSpan) [ sprintf "%A" owner.FunctionId ] [ sprintf "%A" source.SiteOwner ]
                | _ -> ()
                let at = sourceSpan program instruction.Site
                let operationError code message expected actual = Diagnostics.raiseError code message sourceOwner at expected actual
                let sourceKind = program.SourceMap[instruction.Site].SourceKind
                match sourceKind, instruction.Operation with
                | "synthetic-scope", IrOperation.Scope _ -> ()
                | "synthetic-store-local", IrOperation.StoreLocal _ -> ()
                | "synthetic-load-local", IrOperation.LoadLocal _ -> ()
                | kind, _ when kind.StartsWith("synthetic", StringComparison.Ordinal) ->
                    operationError "IR_SYNTHETIC_SOURCE_KIND_INVALID" "Synthetic source classifications are closed and must match their internal opcode." [ "synthetic-scope/Scope | synthetic-store-local/StoreLocal | synthetic-load-local/LoadLocal" ] [ kind; sprintf "%A" instruction.Operation ]
                | _ -> ()
                let pop count =
                    if shape.StackTypes.Length < count then operationError "IR_STACK_UNDERFLOW" "IR operation input shape underflows its block stack." [ string count ] [ string shape.StackTypes.Length ]
                    shape.StackTypes |> List.take (shape.StackTypes.Length - count), shape.StackTypes |> List.skip (shape.StackTypes.Length - count)
                let requireGeneratedOperation expected call =
                    match call.ResolvedTarget with
                    | GeneratedWordTarget(id, revision) ->
                        match program.GeneratedTargetsById.TryFind id with
                        | Some target when target.TargetRevision = revision && target.Operation = expected -> ()
                        | _ -> operationError "IR_GENERATED_OPERATION_MISMATCH" "Explicit generated operation does not match its linked generated target." [ sprintf "%A" expected ] [ call.ResolvedName ]
                    | _ -> operationError "IR_GENERATED_TARGET_REQUIRED" "Record and scalar operations must resolve to a generated target." [ sprintf "%A" expected ] [ call.ResolvedName ]
                let nextShape, effects =
                    match instruction.Operation with
                    | IrOperation.Constant(literal, ty) ->
                        verifyIrType program sourceOwner (Some instruction.Site) ty
                        match literal with
                        | LFloat value when not (Double.IsFinite value) -> operationError "IR_CONSTANT_LITERAL_INVALID" "IR floating constants must be finite, matching source literal validation." [ "finite Float" ] [ FloatText.format value ]
                        | LString value when isNull value -> operationError "IR_CONSTANT_LITERAL_INVALID" "IR string constants cannot be null." [ "non-null String" ] [ "null" ]
                        | _ -> ()
                        if valueType literal <> ty then operationError "IR_CONSTANT_TYPE_MISMATCH" "Constant type does not match its literal." [ IrTypes.format (valueType literal) ] [ IrTypes.format ty ]
                        { shape with StackTypes = shape.StackTypes @ [ ty ] }, Set.empty
                    | IrOperation.Call call ->
                        match call.ResolvedTarget with
                        | GeneratedWordTarget _ -> operationError "IR_GENERATED_OPERATION_REQUIRED" "Generated word calls must lower to their explicit semantic operation." [] [ call.ResolvedName ]
                        | _ -> ()
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        let prefix, actuals = pop call.InputTypes.Length
                        if actuals <> call.InputTypes then operationError "IR_CALL_STACK_MISMATCH" "Resolved call signature does not match its actual stack inputs." (call.InputTypes |> List.map IrTypes.format) (actuals |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ call.OutputTypes }, call.ResolvedEffects
                    | IrOperation.ListEmpty item ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        { shape with StackTypes = shape.StackTypes @ [ IrList item ] }, Set.empty
                    | IrOperation.ListSingleton item ->
                        let prefix, actual = pop 1
                        if actual <> [ item ] then operationError "IR_CONTAINER_PAYLOAD" "List singleton payload type does not match its closed element type." [ IrTypes.format item ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrList item ] }, Set.empty
                    | IrOperation.ListOf(item, count) ->
                        if count < 1 then operationError "IR_CONTAINER_PAYLOAD" "List literal must have at least one element." [ "count >= 1" ] [ string count ]
                        let prefix, actual = pop count
                        if actual <> List.replicate count item then operationError "IR_CONTAINER_PAYLOAD" "List literal element types do not match its closed element type." [ IrTypes.format item ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrList item ] }, Set.empty
                    | IrOperation.OptionNone item ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        { shape with StackTypes = shape.StackTypes @ [ IrOption item ] }, Set.empty
                    | IrOperation.OptionSome item ->
                        let prefix, actual = pop 1
                        if actual <> [ item ] then operationError "IR_CONTAINER_PAYLOAD" "Option Some payload type does not match its closed element type." [ IrTypes.format item ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrOption item ] }, Set.empty
                    | IrOperation.ResultOk(ok, error) ->
                        verifyIrType program sourceOwner (Some instruction.Site) ok
                        verifyIrType program sourceOwner (Some instruction.Site) error
                        let prefix, actual = pop 1
                        if actual <> [ ok ] then operationError "IR_CONTAINER_PAYLOAD" "Result Ok payload type does not match its explicit success type." [ IrTypes.format ok ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrResult(ok, error) ] }, Set.empty
                    | IrOperation.ResultError(ok, error) ->
                        verifyIrType program sourceOwner (Some instruction.Site) ok
                        verifyIrType program sourceOwner (Some instruction.Site) error
                        let prefix, actual = pop 1
                        if actual <> [ error ] then operationError "IR_CONTAINER_PAYLOAD" "Result Error payload type does not match its explicit error type." [ IrTypes.format error ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrResult(ok, error) ] }, Set.empty
                    | IrOperation.ListMap(callback, item, output) ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        verifyIrType program sourceOwner (Some instruction.Site) output
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site callback
                        if callback.InputTypes <> [ item ] || callback.OutputTypes <> [ output ] then operationError "IR_CALLBACK_SIGNATURE_MISMATCH" "Map callback must have concrete signature T -> U." [ IrTypes.format item + " -> " + IrTypes.format output ] [ String.concat " " (callback.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (callback.OutputTypes |> List.map IrTypes.format) ]
                        let prefix, actual = pop 1
                        if actual <> [ IrList item ] then operationError "IR_LIST_STACK_MISMATCH" "Map input stack must end in List<T>." [ IrTypes.format (IrList item) ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrList output ] }, callback.ResolvedEffects
                    | IrOperation.ListFilter(callback, item) ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site callback
                        if callback.InputTypes <> [ item ] || callback.OutputTypes <> [ IrBool ] then operationError "IR_CALLBACK_SIGNATURE_MISMATCH" "Filter callback must have concrete signature T -> Bool." [ IrTypes.format item + " -> Bool" ] [ String.concat " " (callback.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (callback.OutputTypes |> List.map IrTypes.format) ]
                        let prefix, actual = pop 1
                        if actual <> [ IrList item ] then operationError "IR_LIST_STACK_MISMATCH" "Filter input stack must end in List<T>." [ IrTypes.format (IrList item) ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrList item ] }, callback.ResolvedEffects
                    | IrOperation.ListEach(callback, item) ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site callback
                        if callback.InputTypes <> [ item ] || callback.OutputTypes <> [ IrUnit ] then operationError "IR_CALLBACK_SIGNATURE_MISMATCH" "Each callback must have concrete signature T -> Unit." [ IrTypes.format item + " -> Unit" ] [ String.concat " " (callback.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (callback.OutputTypes |> List.map IrTypes.format) ]
                        let prefix, actual = pop 1
                        if actual <> [ IrList item ] then operationError "IR_LIST_STACK_MISMATCH" "Each input stack must end in List<T>." [ IrTypes.format (IrList item) ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrUnit ] }, callback.ResolvedEffects
                    | IrOperation.ListFold(callback, item, accumulator) ->
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        verifyIrType program sourceOwner (Some instruction.Site) accumulator
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site callback
                        if callback.InputTypes <> [ accumulator; item ] || callback.OutputTypes <> [ accumulator ] then
                            operationError "IR_CALLBACK_SIGNATURE_MISMATCH" "Fold callback must have concrete signature Accumulator Item -> Accumulator."
                                [ $"{IrTypes.format accumulator} {IrTypes.format item} -> {IrTypes.format accumulator}" ]
                                [ String.concat " " (callback.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (callback.OutputTypes |> List.map IrTypes.format) ]
                        let prefix, actual = pop 2
                        if actual <> [ IrList item; accumulator ] then
                            operationError "IR_LIST_STACK_MISMATCH" "Fold input stack must end in List<T> followed by its initial accumulator."
                                [ IrTypes.format (IrList item); IrTypes.format accumulator ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ accumulator ] }, callback.ResolvedEffects
                    | IrOperation.ListMapWithContext(callback, context, item, output) ->
                        verifyIrType program sourceOwner (Some instruction.Site) context
                        verifyIrType program sourceOwner (Some instruction.Site) item
                        verifyIrType program sourceOwner (Some instruction.Site) output
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site callback
                        if callback.InputTypes <> [ context; item ] || callback.OutputTypes <> [ output ] then
                            operationError "IR_CALLBACK_SIGNATURE_MISMATCH" "Map-with-context callback must have concrete signature Context Item -> Output."
                                [ $"{IrTypes.format context} {IrTypes.format item} -> {IrTypes.format output}" ]
                                [ String.concat " " (callback.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (callback.OutputTypes |> List.map IrTypes.format) ]
                        let prefix, actual = pop 2
                        if actual <> [ IrList item; context ] then
                            operationError "IR_LIST_STACK_MISMATCH" "Map-with-context input stack must end in List<T> followed by its context."
                                [ IrTypes.format (IrList item); IrTypes.format context ] (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrList output ] }, callback.ResolvedEffects
                    | IrOperation.StoreLocal slot ->
                        if not (owner.LocalNames.ContainsKey slot) then operationError "IR_UNKNOWN_LOCAL_SLOT" "IR local store references a slot absent from the function layout." [] [ sprintf "%A" slot ]
                        let prefix, actual = pop 1
                        let locals = Map.add slot actual.Head shape.LocalTypes
                        { StackTypes = prefix; LocalTypes = locals }, Set.empty
                    | IrOperation.LoadLocal slot ->
                        if not (owner.LocalNames.ContainsKey slot) then operationError "IR_UNKNOWN_LOCAL_SLOT" "IR local load references a slot absent from the function layout." [] [ sprintf "%A" slot ]
                        match shape.LocalTypes.TryFind slot with
                        | None -> operationError "IR_UNKNOWN_LOCAL_SLOT" "IR local load references a slot absent from this block shape." [] [ sprintf "%A" slot ]
                        | Some ty -> { shape with StackTypes = shape.StackTypes @ [ ty ] }, Set.empty
                    | IrOperation.If(thenBlock, elseBlock) ->
                        let prefix, condition = pop 1
                        if condition <> [ IrBool ] then operationError "IR_IF_CONDITION_TYPE" "IR if requires Bool on top of stack." [ "Bool" ] (condition |> List.map IrTypes.format)
                        let expectedEntry = { shape with StackTypes = prefix }
                        let thenShape, thenEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site expectedEntry thenBlock
                        let elseShape, elseEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site expectedEntry elseBlock
                        if thenShape <> elseShape then operationError "IR_BRANCH_JOIN_MISMATCH" "IR if arms do not have the same output stack and local shape." (thenShape.StackTypes |> List.map IrTypes.format) (elseShape.StackTypes |> List.map IrTypes.format)
                        thenShape, Set.union thenEffects elseEffects
                    | IrOperation.Scope innerBlock ->
                        let innerShape, innerEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site shape innerBlock
                        { StackTypes = innerShape.StackTypes; LocalTypes = shape.LocalTypes }, innerEffects
                    | IrOperation.AssignLocal slot ->
                        let prefix, actual = pop 1
                        match shape.LocalTypes.TryFind slot with
                        | None -> operationError "IR_ASSIGN_UNKNOWN_LOCAL" "IR local assignment targets a slot that is not bound in this block shape." [] [ sprintf "%A" slot ]
                        | Some declared when [ declared ] <> actual ->
                            operationError "IR_ASSIGN_TYPE" "IR local assignment must keep the local's exact type." [ IrTypes.format declared ] (actual |> List.map IrTypes.format)
                        | Some _ -> { shape with StackTypes = prefix }, Set.empty
                    | IrOperation.Break
                    | IrOperation.Continue ->
                        match (if loopContexts.Count = 0 then None else loopContexts.Peek()) with
                        | None -> operationError "IR_LOOP_CONTROL_OUTSIDE_LOOP" "break/continue must be inside a loop body (and not inside a compact block within it)." [ "enclosing loop" ] []
                        | Some loopStack when loopStack <> shape.StackTypes ->
                            operationError "IR_LOOP_CONTROL_STACK" "break/continue requires the loop body's entry stack." (loopStack |> List.map IrTypes.format) (shape.StackTypes |> List.map IrTypes.format)
                        | Some _ ->
                            terminated <- true
                            shape, Set.empty
                    | IrOperation.ForRange(indexLocal, body) ->
                        let prefix, bounds = pop 2
                        if bounds <> [ IrInt; IrInt ] then operationError "IR_LOOP_RANGE_TYPE" "A range loop requires Int start and end on top of the stack." [ "Int"; "Int" ] (bounds |> List.map IrTypes.format)
                        let bound = [ indexLocal, IrInt ]
                        verifyLoop instruction.Site shape prefix bound body
                    | IrOperation.ForList(itemType, itemLocal, indexLocal, body) ->
                        let prefix, input = pop 1
                        if input <> [ IrList itemType ] then operationError "IR_LOOP_LIST_TYPE" "A list loop requires its List<T> on top of the stack." [ IrTypes.format (IrList itemType) ] (input |> List.map IrTypes.format)
                        let bound = (itemLocal, itemType) :: (indexLocal |> Option.map (fun slot -> slot, IrInt) |> Option.toList)
                        if indexLocal = Some itemLocal then operationError "IR_LOOP_LOCAL_SHADOW" "A list loop's item and index slots must differ." [] [ sprintf "%A" itemLocal ]
                        verifyLoop instruction.Site shape prefix bound body
                    | IrOperation.Compact innerBlock ->
                        loopContexts.Push None
                        let innerShape, innerEffects =
                            try verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site shape innerBlock
                            finally loopContexts.Pop() |> ignore
                        let unchangedPrefix =
                            innerShape.StackTypes.Length = shape.StackTypes.Length + 1
                            && List.take shape.StackTypes.Length innerShape.StackTypes = shape.StackTypes
                        if not unchangedPrefix then
                            operationError "IR_COMPACT_SHAPE" "A compact block must leave the outer stack unchanged and produce exactly one value."
                                ((shape.StackTypes |> List.map IrTypes.format) @ [ "one value" ])
                                (innerShape.StackTypes |> List.map IrTypes.format)
                        { StackTypes = innerShape.StackTypes; LocalTypes = shape.LocalTypes }, innerEffects
                    | IrOperation.MatchOption(someLocal, someBlock, noneBlock) ->
                        if not (owner.LocalNames.ContainsKey someLocal) then operationError "IR_UNKNOWN_LOCAL_SLOT" "Option case local is absent from the function layout." [] [ sprintf "%A" someLocal ]
                        let prefix, input = pop 1
                        let item = match input with | [ IrOption value ] -> value | _ -> operationError "IR_OPTION_MATCH_TYPE" "Option match requires Option<T>." [ "Option<T>" ] (input |> List.map IrTypes.format)
                        if shape.LocalTypes.ContainsKey someLocal then operationError "IR_CASE_LOCAL_SHADOW" "Option match payload slot shadows an outer local." [] [ sprintf "%A" someLocal ]
                        let someEntry = { StackTypes = prefix; LocalTypes = Map.add someLocal item shape.LocalTypes }
                        let noneEntry = { StackTypes = prefix; LocalTypes = shape.LocalTypes }
                        let someShape, someEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site someEntry someBlock
                        let noneShape, noneEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site noneEntry noneBlock
                        if noneShape.LocalTypes.ContainsKey someLocal then operationError "IR_CASE_LOCAL_ESCAPE" "Option payload slot escaped into the None arm." [] [ sprintf "%A" someLocal ]
                        let someJoin = { someShape with LocalTypes = Map.remove someLocal someShape.LocalTypes }
                        if someJoin <> noneShape then operationError "IR_BRANCH_JOIN_MISMATCH" "Option match arms do not have the same output stack and outer-local shape." (someJoin.StackTypes |> List.map IrTypes.format) (noneShape.StackTypes |> List.map IrTypes.format)
                        someJoin, Set.union someEffects noneEffects
                    | IrOperation.MatchResult(okLocal, errorLocal, okBlock, errorBlock) ->
                        if not (owner.LocalNames.ContainsKey okLocal && owner.LocalNames.ContainsKey errorLocal) then operationError "IR_UNKNOWN_LOCAL_SLOT" "Result case local is absent from the function layout." [] [ sprintf "%A" (okLocal, errorLocal) ]
                        let prefix, input = pop 1
                        let okType, errorType = match input with | [ IrResult(ok, error) ] -> ok, error | _ -> operationError "IR_RESULT_MATCH_TYPE" "Result match requires Result<T, E>." [ "Result<T, E>" ] (input |> List.map IrTypes.format)
                        if shape.LocalTypes.ContainsKey okLocal || shape.LocalTypes.ContainsKey errorLocal then operationError "IR_CASE_LOCAL_SHADOW" "Result match payload slot shadows an outer local." [] [ sprintf "%A" (okLocal, errorLocal) ]
                        let okEntry = { StackTypes = prefix; LocalTypes = Map.add okLocal okType shape.LocalTypes }
                        let errorEntry = { StackTypes = prefix; LocalTypes = Map.add errorLocal errorType shape.LocalTypes }
                        let okShape, okEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site okEntry okBlock
                        let errorShape, errorEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site errorEntry errorBlock
                        if okShape.LocalTypes.ContainsKey errorLocal || errorShape.LocalTypes.ContainsKey okLocal then operationError "IR_CASE_LOCAL_ESCAPE" "Result case payload escaped into the other case arm." [] [ sprintf "%A" (okLocal, errorLocal) ]
                        let okJoin = { okShape with LocalTypes = Map.remove okLocal okShape.LocalTypes }
                        let errorJoin = { errorShape with LocalTypes = Map.remove errorLocal errorShape.LocalTypes }
                        if okJoin <> errorJoin then operationError "IR_BRANCH_JOIN_MISMATCH" "Result match arms do not have the same output stack and outer-local shape." (okJoin.StackTypes |> List.map IrTypes.format) (errorJoin.StackTypes |> List.map IrTypes.format)
                        okJoin, Set.union okEffects errorEffects
                    | IrOperation.MatchEnum(typeKey, caseBlocks) ->
                        let prefix, input = pop 1
                        let enumDefinition =
                            match program.NominalTypesByKey.TryFind typeKey with
                            | Some(IrEnumDefinition definition) -> definition
                            | Some _ -> operationError "IR_ENUM_MATCH_TYPE" "Enum match type key refers to a non-enum nominal definition." [ "enum definition" ] [ sprintf "%A" typeKey ]
                            | None -> operationError "IR_ENUM_MATCH_TYPE" "Enum match type key is absent from the frozen nominal table." [ "known enum key" ] [ sprintf "%A" typeKey ]
                        if input <> [ IrNominal typeKey ] then operationError "IR_ENUM_MATCH_TYPE" "Enum match scrutinee must have the exact nominal type named by the match operation." [ IrTypes.format (IrNominal typeKey) ] (input |> List.map IrTypes.format)
                        let indexes = caseBlocks |> List.map fst
                        let expectedIndexes = [ 0 .. enumDefinition.Cases.Length - 1 ]
                        if indexes.Length <> expectedIndexes.Length || (indexes |> List.sort) <> expectedIndexes then
                            operationError "IR_ENUM_MATCH_CASE_SET" "Enum match must contain every frozen case exactly once and no other case index." (expectedIndexes |> List.map string) (indexes |> List.map string)
                        let expectedEntry = { shape with StackTypes = prefix }
                        let mutable joinShape = None
                        let mutable branchEffects = Set.empty
                        for caseIndex, caseBlock in caseBlocks do
                            if caseIndex < 0 || caseIndex >= enumDefinition.Cases.Length then
                                operationError "IR_ENUM_MATCH_CASE_SET" "Enum match contains a case index outside its frozen case table." (expectedIndexes |> List.map string) [ string caseIndex ]
                            let caseShape, caseEffects = verifyBlockNested program catalog hostCatalog owner sourceOwnerId instruction.Site expectedEntry caseBlock
                            match joinShape with
                            | None -> joinShape <- Some caseShape
                            | Some previous when previous <> caseShape ->
                                operationError "IR_BRANCH_JOIN_MISMATCH" "Enum match arms do not have the same output stack and outer-local shape." (previous.StackTypes |> List.map IrTypes.format) (caseShape.StackTypes |> List.map IrTypes.format)
                            | Some _ -> ()
                            branchEffects <- Set.union branchEffects caseEffects
                        joinShape |> Option.defaultWith (fun () -> operationError "IR_ENUM_MATCH_CASE_SET" "Enum match has no case blocks." (expectedIndexes |> List.map string) []) |> fun result -> result, branchEffects
                    | IrOperation.MakeEnumCase(call, key, caseIndex) ->
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        requireGeneratedOperation (MakeEnumCaseOperation(key, caseIndex)) call
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrEnumDefinition enumDefinition) when caseIndex >= 0 && caseIndex < enumDefinition.Cases.Length && call.InputTypes = [] && call.OutputTypes = [ IrNominal key ] -> ()
                        | _ -> operationError "IR_ENUM_CONSTRUCTION_TYPE" "Enum case construction must target a valid frozen case with a zero-input signature." [ "() -> enum case" ] [ call.ResolvedName ]
                        { shape with StackTypes = shape.StackTypes @ call.OutputTypes }, call.ResolvedEffects
                    | IrOperation.HtmlTemplate(key, parts) ->
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrScalarDefinition scalar) when scalar.BaseType = IrString && IrHtml.isHtmlValidator scalar.ValidatorCall -> ()
                        | _ -> operationError "IR_HTML_TEMPLATE_TYPE" "An html template must produce a String-based type validated by string.html-fragment?." [ "type Html : String { validate string.html-fragment? }" ] []
                        match HtmlMarkup.check parts with
                        | Ok() -> ()
                        | Error(_, message) -> operationError "IR_HTML_TEMPLATE_MARKUP" ("html template markup is not a well-formed fragment: " + message) [] []
                        let holeTypes =
                            parts
                            |> List.choose (function
                                | HtmlTemplatePart.StringHole -> Some IrString
                                | HtmlTemplatePart.HtmlHole -> Some(IrNominal key)
                                | HtmlTemplatePart.HtmlListHole -> Some(IrList(IrNominal key))
                                | HtmlTemplatePart.Text _ -> None)
                        let prefix, actual = pop holeTypes.Length
                        if actual <> holeTypes then operationError "IR_CALL_STACK_MISMATCH" "html template holes do not match the stack." (holeTypes |> List.map IrTypes.format) (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ [ IrNominal key ] }, Set.empty
                    | IrOperation.MakeRecord(call, key, validator) ->
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        requireGeneratedOperation (MakeRecordOperation key) call
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrRecordDefinition record) when call.InputTypes = (record.RecordFields |> List.map (fun field -> field.FieldType)) && call.OutputTypes = [ IrNominal key ] ->
                            if validator <> record.ValidatorCall then operationError "IR_RECORD_VALIDATOR_MISMATCH" "Record construction validator differs from the immutable type table." [] []
                            match validator with
                            | Some checkedCall ->
                                verifyCall program catalog hostCatalog owner.FunctionName instruction.Site checkedCall
                                if checkedCall.InputTypes <> [ IrNominal key ] || checkedCall.OutputTypes <> [ IrBool ] || not (Set.isEmpty checkedCall.ResolvedEffects) then
                                    operationError "IR_RECORD_VALIDATOR_INVALID" "Record validator must be pure and have signature Record -> Bool." [ IrTypes.format (IrNominal key) + " -> Bool" ] [ String.concat " " (checkedCall.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (checkedCall.OutputTypes |> List.map IrTypes.format) ]
                            | None -> ()
                        | _ -> operationError "IR_RECORD_CONSTRUCTION_TYPE" "Record construction does not match the snapshot type layout." [ "record fields -> nominal record" ] (call.OutputTypes |> List.map IrTypes.format)
                        let prefix, actual = pop call.InputTypes.Length
                        if actual <> call.InputTypes then operationError "IR_CALL_STACK_MISMATCH" "Record constructor inputs do not match the stack." (call.InputTypes |> List.map IrTypes.format) (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ call.OutputTypes }, Set.union call.ResolvedEffects (validator |> Option.map (fun value -> value.ResolvedEffects) |> Option.defaultValue Set.empty)
                    | IrOperation.GetRecordField(call, key, index) ->
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        requireGeneratedOperation (GetRecordFieldOperation(key, index)) call
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrRecordDefinition record) when index >= 0 && index < record.RecordFields.Length && call.InputTypes = [ IrNominal key ] && call.OutputTypes = [ record.RecordFields[index].FieldType ] -> ()
                        | _ -> operationError "IR_RECORD_ACCESS_TYPE" "Record accessor does not match its snapshot type or field index." [ "record -> selected field" ] (call.OutputTypes |> List.map IrTypes.format)
                        let prefix, actual = pop 1
                        if actual <> call.InputTypes then operationError "IR_CALL_STACK_MISMATCH" "Record accessor input does not match the stack." (call.InputTypes |> List.map IrTypes.format) (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ call.OutputTypes }, call.ResolvedEffects
                    | IrOperation.WrapScalar(call, key, validator) ->
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        requireGeneratedOperation (WrapScalarOperation key) call
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrScalarDefinition scalar) when call.InputTypes = [ scalar.BaseType ] && call.OutputTypes = [ IrNominal key ] ->
                            if validator <> scalar.ValidatorCall then operationError "IR_SCALAR_VALIDATOR_MISMATCH" "Scalar wrapping validator differs from the immutable type table." [] []
                            match validator with
                            | Some checkedCall ->
                                verifyCall program catalog hostCatalog owner.FunctionName instruction.Site checkedCall
                                if checkedCall.InputTypes <> [ scalar.BaseType ] || checkedCall.OutputTypes <> [ IrBool ] || not (Set.isEmpty checkedCall.ResolvedEffects) then
                                    operationError "IR_SCALAR_VALIDATOR_INVALID" "Scalar validator must be pure and have signature BaseType -> Bool." [ IrTypes.format scalar.BaseType + " -> Bool" ] [ String.concat " " (checkedCall.InputTypes |> List.map IrTypes.format) + " -> " + String.concat " " (checkedCall.OutputTypes |> List.map IrTypes.format) ]
                            | None -> ()
                        | _ -> operationError "IR_SCALAR_WRAP_TYPE" "Scalar wrapping does not match its base and nominal types." [ "base -> nominal" ] (call.OutputTypes |> List.map IrTypes.format)
                        let prefix, actual = pop 1
                        if actual <> call.InputTypes then operationError "IR_CALL_STACK_MISMATCH" "Scalar constructor input does not match the stack." (call.InputTypes |> List.map IrTypes.format) (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ call.OutputTypes }, Set.union call.ResolvedEffects (validator |> Option.map (fun value -> value.ResolvedEffects) |> Option.defaultValue Set.empty)
                    | IrOperation.UnwrapScalar(call, key) ->
                        verifyCall program catalog hostCatalog owner.FunctionName instruction.Site call
                        requireGeneratedOperation (UnwrapScalarOperation key) call
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrScalarDefinition scalar) when call.InputTypes = [ IrNominal key ] && call.OutputTypes = [ scalar.BaseType ] -> ()
                        | _ -> operationError "IR_SCALAR_UNWRAP_TYPE" "Scalar unwrapping does not match its nominal and base types." [ "nominal -> base" ] (call.OutputTypes |> List.map IrTypes.format)
                        let prefix, actual = pop 1
                        if actual <> call.InputTypes then operationError "IR_CALL_STACK_MISMATCH" "Scalar accessor input does not match the stack." (call.InputTypes |> List.map IrTypes.format) (actual |> List.map IrTypes.format)
                        { shape with StackTypes = prefix @ call.OutputTypes }, call.ResolvedEffects
                currentShape <- nextShape
                accumulatedEffects <- Set.union accumulatedEffects effects
            currentShape, accumulatedEffects
        and verifyBlockNested (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) (owner: IrFunction) (sourceOwnerId: WordId option) (parentSite: SourceSiteId) expectedEntry (block: IrBlock) =
            if block.EntryShape <> expectedEntry then
                Diagnostics.raiseError "IR_BLOCK_ENTRY_MISMATCH" "Structured IR block entry shape does not match its control-flow edge." (Some owner.FunctionName) (sourceSpan program parentSite) (expectedEntry.StackTypes |> List.map IrTypes.format) (block.EntryShape.StackTypes |> List.map IrTypes.format)
            let actualExit, effects = verifyNested block.Code block.EntryShape
            if actualExit <> block.ExitShape then
                Diagnostics.raiseError "IR_BLOCK_EXIT_MISMATCH" "IR block exit annotation disagrees with its verified instructions." (Some owner.FunctionName) (sourceSpan program parentSite) (actualExit.StackTypes |> List.map IrTypes.format) (block.ExitShape.StackTypes |> List.map IrTypes.format)
            actualExit, effects
        and verifyLoop (site: SourceSiteId) (shape: IrShape) (prefix: IrType list) (bound: (LocalSlot * IrType) list) (body: IrBlock) =
            let at = sourceSpan program site
            for slot, _ in bound do
                if not (owner.LocalNames.ContainsKey slot) then
                    Diagnostics.raiseError "IR_UNKNOWN_LOCAL_SLOT" "Loop local is absent from the function layout." (Some owner.FunctionName) at [] [ sprintf "%A" slot ]
                if shape.LocalTypes.ContainsKey slot then
                    Diagnostics.raiseError "IR_LOOP_LOCAL_SHADOW" "A loop's item or index slot shadows an outer local." (Some owner.FunctionName) at [] [ sprintf "%A" slot ]
            let entry = { StackTypes = prefix; LocalTypes = bound |> List.fold (fun locals (slot, ty) -> Map.add slot ty locals) shape.LocalTypes }
            loopContexts.Push(Some prefix)
            let bodyExit, bodyEffects =
                try verifyBlockNested program catalog hostCatalog owner sourceOwnerId site entry body
                finally loopContexts.Pop() |> ignore
            let invariant =
                bodyExit.StackTypes = prefix
                && (shape.LocalTypes |> Map.forall (fun slot ty -> bodyExit.LocalTypes.TryFind slot = Some ty))
            if not invariant then
                Diagnostics.raiseError "IR_LOOP_SHAPE_NOT_INVARIANT" "A loop body must leave its entry stack and every outer local's type unchanged." (Some owner.FunctionName) at
                    (prefix |> List.map IrTypes.format) (bodyExit.StackTypes |> List.map IrTypes.format)
            { StackTypes = prefix; LocalTypes = shape.LocalTypes }, bodyEffects
        let actualExit, effects = verifyNested block.Code block.EntryShape
        if actualExit <> block.ExitShape then
            Diagnostics.raiseError "IR_BLOCK_EXIT_MISMATCH" "Function block exit annotation disagrees with its verified instructions." (Some owner.FunctionName) None (block.ExitShape.StackTypes |> List.map IrTypes.format) (actualExit.StackTypes |> List.map IrTypes.format)
        if effects <> owner.FunctionInferredEffects then
            Diagnostics.raiseError "IR_FUNCTION_EFFECT_MISMATCH" $"Function '{owner.FunctionName}' inferred effects disagree with its body." (Some owner.FunctionName) None (IrEffects.names owner.FunctionInferredEffects) (IrEffects.names effects)
        if not (Set.isSubset effects owner.FunctionDeclaredEffects) then
            Diagnostics.raiseError "IR_UNDECLARED_EFFECT" $"Function '{owner.FunctionName}' uses effects absent from its declaration." (Some owner.FunctionName) None (IrEffects.names owner.FunctionDeclaredEffects) (IrEffects.names effects)

    let private expectedCoverage (nominalTypes: Map<ProgramTypeKey, IrNominalDefinition>) (sourceMap: Map<SourceSiteId, IrSourceSite>) (block: IrBlock) =
        let isAuthoredSite site =
            match sourceMap.TryFind site with
            | Some source ->
                not (
                    source.SourceKind = "synthetic-scope"
                    || source.SourceKind = "synthetic-store-local"
                    || source.SourceKind = "synthetic-load-local")
            | None -> true
        let rec collectBlock (instructions: IrInstruction list) (sites: Set<SourceSiteId>) (branches: Map<SourceSiteId, string list>) =
            instructions
            |> List.fold (fun (sites, branches) instruction ->
                let sites = if isAuthoredSite instruction.Site then Set.add instruction.Site sites else sites
                match instruction.Operation with
                | IrOperation.If(thenBlock, elseBlock) ->
                    let branches = Map.add instruction.Site [ "true"; "false" ] branches
                    let leftSites, leftBranches = collectBlock thenBlock.Code sites branches
                    collectBlock elseBlock.Code leftSites leftBranches
                | IrOperation.Scope innerBlock
                | IrOperation.Compact innerBlock
                | IrOperation.ForRange(_, innerBlock)
                | IrOperation.ForList(_, _, _, innerBlock) -> collectBlock innerBlock.Code sites branches
                | IrOperation.MatchOption(_, someBlock, noneBlock) ->
                    let branches = Map.add instruction.Site [ "some"; "none" ] branches
                    let leftSites, leftBranches = collectBlock someBlock.Code sites branches
                    collectBlock noneBlock.Code leftSites leftBranches
                | IrOperation.MatchResult(_, _, okBlock, errorBlock) ->
                    let branches = Map.add instruction.Site [ "ok"; "error" ] branches
                    let leftSites, leftBranches = collectBlock okBlock.Code sites branches
                    collectBlock errorBlock.Code leftSites leftBranches
                | IrOperation.MatchEnum(typeKey, caseBlocks) ->
                    let labels =
                        match nominalTypes.TryFind typeKey with
                        | Some(IrEnumDefinition enumDefinition) -> enumDefinition.Cases
                        | _ -> caseBlocks |> List.map (fun (caseIndex, _) -> "case" + string caseIndex)
                    let branches = Map.add instruction.Site labels branches
                    caseBlocks |> List.fold (fun (nestedSites, nestedBranches) (_, caseBlock) -> collectBlock caseBlock.Code nestedSites nestedBranches) (sites, branches)
                | IrOperation.ListMap _ | IrOperation.ListEach _ -> Map.add instruction.Site [ "empty"; "nonempty" ] branches |> fun branches -> sites, branches
                | IrOperation.ListFilter _ -> Map.add instruction.Site [ "empty"; "nonempty"; "keep"; "drop" ] branches |> fun branches -> sites, branches
                | IrOperation.ListFold _ -> Map.add instruction.Site [ "empty"; "nonempty" ] branches |> fun branches -> sites, branches
                | IrOperation.ListMapWithContext _ -> Map.add instruction.Site [ "empty"; "nonempty" ] branches |> fun branches -> sites, branches
                | _ -> sites, branches) (sites, branches)
        collectBlock block.Code Set.empty Map.empty

    let private instructionsInBlock (block: IrBlock) =
        let rec collect instructions =
            instructions
            |> List.collect (fun instruction ->
                let nested =
                    match instruction.Operation with
                    | IrOperation.If(thenBlock, elseBlock) -> collect thenBlock.Code @ collect elseBlock.Code
                    | IrOperation.Scope innerBlock
                    | IrOperation.Compact innerBlock
                    | IrOperation.ForRange(_, innerBlock)
                    | IrOperation.ForList(_, _, _, innerBlock) -> collect innerBlock.Code
                    | IrOperation.MatchOption(_, someBlock, noneBlock) -> collect someBlock.Code @ collect noneBlock.Code
                    | IrOperation.MatchResult(_, _, okBlock, errorBlock) -> collect okBlock.Code @ collect errorBlock.Code
                    | IrOperation.MatchEnum(_, caseBlocks) -> caseBlocks |> List.collect (snd >> fun caseBlock -> collect caseBlock.Code)
                    | _ -> []
                instruction :: nested)
        collect block.Code

    let private callTargetsInBlock (block: IrBlock) =
        let rec collect instructions =
            instructions
            |> List.collect (fun instruction ->
                let direct =
                    match instruction.Operation with
                    | IrOperation.Call call -> [ call.ResolvedTarget ]
                    | IrOperation.ListMap(call, _, _) | IrOperation.ListFilter(call, _) | IrOperation.ListEach(call, _) | IrOperation.ListFold(call, _, _) | IrOperation.ListMapWithContext(call, _, _, _) -> [ call.ResolvedTarget ]
                    | IrOperation.GetRecordField(call, _, _) | IrOperation.UnwrapScalar(call, _)
                    | IrOperation.MakeEnumCase(call, _, _) -> [ call.ResolvedTarget ]
                    | IrOperation.MakeRecord(call, _, validator) -> call.ResolvedTarget :: (validator |> Option.map (fun value -> value.ResolvedTarget) |> Option.toList)
                    | IrOperation.WrapScalar(call, _, validator) -> call.ResolvedTarget :: (validator |> Option.map (fun value -> value.ResolvedTarget) |> Option.toList)
                    | _ -> []
                let nested =
                    match instruction.Operation with
                    | IrOperation.If(thenBlock, elseBlock) -> collect thenBlock.Code @ collect elseBlock.Code
                    | IrOperation.Scope innerBlock
                    | IrOperation.Compact innerBlock
                    | IrOperation.ForRange(_, innerBlock)
                    | IrOperation.ForList(_, _, _, innerBlock) -> collect innerBlock.Code
                    | IrOperation.MatchOption(_, someBlock, noneBlock) -> collect someBlock.Code @ collect noneBlock.Code
                    | IrOperation.MatchResult(_, _, okBlock, errorBlock) -> collect okBlock.Code @ collect errorBlock.Code
                    | IrOperation.MatchEnum(_, caseBlocks) -> caseBlocks |> List.collect (snd >> fun caseBlock -> collect caseBlock.Code)
                    | _ -> []
                direct @ nested)
        collect block.Code

    let private targetNode = function
        | UserWordTarget(id, _) -> Some(IrFunctionNode id)
        | GeneratedWordTarget(id, _) -> Some(IrGeneratedNode id)
        | PrimitiveTarget _
        | HostOperationTarget _ -> None

    let private verifyAcyclicCallGraph (program: IrProgram) =
        let functionEdges =
            program.FunctionsById
            |> Map.toList
            |> List.map (fun (id, fn) ->
                IrFunctionNode id,
                (callTargetsInBlock fn.FunctionBody |> List.choose targetNode |> Set.ofList))
        let generatedEdges =
            program.GeneratedTargetsById
            |> Map.toList
            |> List.map (fun (id, target) ->
                let validatorTarget =
                    match target.Operation with
                    | MakeRecordOperation key ->
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrRecordDefinition record) -> record.ValidatorCall |> Option.bind (fun validator -> targetNode validator.ResolvedTarget) |> Option.toList
                        | _ -> []
                    | WrapScalarOperation key ->
                        match program.NominalTypesByKey.TryFind key with
                        | Some(IrScalarDefinition scalar) -> scalar.ValidatorCall |> Option.bind (fun validator -> targetNode validator.ResolvedTarget) |> Option.toList
                        | _ -> []
                    | _ -> []
                IrGeneratedNode id, (validatorTarget |> Set.ofList))
        let graph = Map.ofList (functionEdges @ generatedEdges)
        let colors = System.Collections.Generic.Dictionary<IrCallGraphNode, int>()
        let path = ResizeArray<IrCallGraphNode>()
        let label = function
            | IrFunctionNode(WordId id) -> "word:" + id
            | IrGeneratedNode(WordId id) -> "generated:" + id
        let rec visit node =
            match colors.TryGetValue node with
            | true, 2 -> ()
            | true, 1 ->
                let currentPath = path |> Seq.map label |> String.concat " -> "
                failure "IR_RECURSIVE_CALL_GRAPH" "Executable user and generated-word references must be acyclic." [ "acyclic call graph" ] [ currentPath + " -> " + label node ]
            | _ ->
                colors[node] <- 1
                path.Add node
                for dependency in (graph.TryFind node |> Option.defaultValue Set.empty) do visit dependency
                path.RemoveAt(path.Count - 1)
                colors[node] <- 2
        for node in graph |> Map.toSeq |> Seq.map fst do visit node

    let private verifyFunction (program: IrProgram) (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) (id: WordId) (fn: IrFunction) =
        if fn.FunctionId <> id then failure "IR_WORD_ID_MISMATCH" "Function map key differs from its stable identity." [ sprintf "%A" fn.FunctionId ] [ sprintf "%A" id ]
        let (WordId idText) = id
        if String.IsNullOrWhiteSpace idText || String.IsNullOrWhiteSpace fn.FunctionName then
            failure "IR_WORD_ID_INVALID" "Function identity and display name must be nonempty." [ "nonempty identity and name" ] [ idText; fn.FunctionName ]
        if fn.FunctionRevision < 0 then failure "IR_INVALID_REVISION" "Function revision cannot be negative." [ "nonnegative revision" ] [ string fn.FunctionRevision ]
        fn.InputTypes @ fn.OutputTypes |> List.iter (verifyIrType program (Some fn.FunctionName) None)
        for KeyValue(slot, name) in fn.LocalNames do
            let (LocalSlot value) = slot
            if value < 0 || String.IsNullOrWhiteSpace name then
                failure "IR_LOCAL_LAYOUT_INVALID" "Function local slots must be nonnegative and have nonempty names." [ "valid local slot/name" ] [ sprintf "%A=%s" slot name ]
        if not (Map.isEmpty fn.FunctionBody.EntryShape.LocalTypes) then
            failure "IR_FUNCTION_ENTRY_LOCALS" $"Function '{fn.FunctionName}' must begin with no initialized locals." [] (fn.FunctionBody.EntryShape.LocalTypes |> Map.toList |> List.map (fun (slot, _) -> sprintf "%A" slot))
        if fn.FunctionBody.EntryShape.StackTypes <> fn.InputTypes || fn.FunctionBody.ExitShape.StackTypes <> fn.OutputTypes then
            failure "IR_FUNCTION_SIGNATURE_MISMATCH" $"Function '{fn.FunctionName}' body stack shape differs from its signature." (fn.InputTypes |> List.map IrTypes.format) (fn.FunctionBody.ExitShape.StackTypes |> List.map IrTypes.format)
        let sites, branches = expectedCoverage program.NominalTypesByKey program.SourceMap fn.FunctionBody
        let coverage = program.CoverageByWord.TryFind id |> Option.defaultValue { CoveredSites = Set.empty; BranchOutcomes = Map.empty }
        if coverage.CoveredSites <> sites || coverage.BranchOutcomes <> branches then
            failure "IR_COVERAGE_MAP_MISMATCH" $"Function '{fn.FunctionName}' coverage obligations do not match its source operations." [ string sites.Count; string branches.Count ] [ string coverage.CoveredSites.Count; string coverage.BranchOutcomes.Count ]
        verifyBlock program catalog hostCatalog fn (Some id) fn.FunctionBody

    let private verifyHostCatalog (hostCatalog: IrHostOperationCatalog) =
        let names = ResizeArray<string>()
        for KeyValue(id, contract) in hostCatalog do
            let (HostOperationId idText) = id
            if String.IsNullOrWhiteSpace idText then
                failure "IR_HOST_OPERATION_ID_INVALID" "Host-operation identities must be nonempty." [ "nonempty operation ID" ] [ idText ]
            if contract.OperationId <> id then
                failure "IR_HOST_OPERATION_ID_MISMATCH" "Host-operation catalog key differs from the retained contract identity." [ sprintf "%A" id ] [ sprintf "%A" contract.OperationId ]
            if String.IsNullOrWhiteSpace contract.OperationName then
                failure "IR_HOST_OPERATION_NAME_MISSING" "Host-operation display names must be nonempty." [ "nonempty operation name" ] [ contract.OperationName ]
            names.Add contract.OperationName
        if (Set.ofSeq names).Count <> names.Count then
            failure "IR_HOST_OPERATION_NAME_COLLISION" "Host-operation catalog names must be unique." [ "unique operation names" ] (List.ofSeq names)

    let private verifyProgram (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) (program: IrProgram) =
        verifyCatalog catalog
        verifyHostCatalog hostCatalog
        verifyNominalTypes program catalog hostCatalog
        let duplicateIds = Set.intersect (program.FunctionsById |> Map.toSeq |> Seq.map fst |> Set.ofSeq) (program.GeneratedTargetsById |> Map.toSeq |> Seq.map fst |> Set.ofSeq)
        if not (Set.isEmpty duplicateIds) then
            failure "IR_WORD_ID_COLLISION" "User and generated targets share stable WordIds." [] (duplicateIds |> Set.toList |> List.map (sprintf "%A"))
        for KeyValue(id, target) in program.GeneratedTargetsById do verifyGeneratedTarget program catalog hostCatalog id target
        for KeyValue(id, fn) in program.FunctionsById do verifyFunction program catalog hostCatalog id fn
        let functionIds = program.FunctionsById |> Map.toSeq |> Seq.map fst |> Set.ofSeq
        let coverageIds = program.CoverageByWord |> Map.toSeq |> Seq.map fst |> Set.ofSeq
        if functionIds <> coverageIds then
            failure "IR_COVERAGE_OWNER_MISMATCH" "Coverage metadata must contain exactly one entry for each user function." (functionIds |> Set.toList |> List.map (sprintf "%A")) (coverageIds |> Set.toList |> List.map (sprintf "%A"))
        let duplicateSites =
            program.FunctionsById
            |> Map.toList
            |> List.collect (fun (_, fn) -> instructionsInBlock fn.FunctionBody |> List.map (fun instruction -> instruction.Site))
            |> List.countBy id
            |> List.choose (fun (site, count) -> if count > 1 then Some(site, count) else None)
        if not (List.isEmpty duplicateSites) then
            failure "IR_DUPLICATE_SOURCE_SITE" "Each source expression must have one executable instruction identity across all nested blocks." [ "unique source-site ID per executable instruction" ] (duplicateSites |> List.map (fun (site, count) -> sprintf "%A (%d instructions)" site count))
        for KeyValue(site, source) in program.SourceMap do
            let (SourceSiteId(siteOwner, ordinal)) = site
            if ordinal < 0 then failure "IR_SOURCE_SITE_INVALID" "Source-site ordinals must be nonnegative." [ "nonnegative ordinal" ] [ string ordinal ]
            if String.IsNullOrWhiteSpace source.SourceKind then
                failure "IR_SOURCE_KIND_MISSING" "Source-map entries must identify their source construct." [ "nonempty source kind" ] [ source.SourceKind ]
            if String.IsNullOrWhiteSpace source.SiteSpan.File || source.SiteSpan.Line < 1 || source.SiteSpan.Column < 1 || source.SiteSpan.Length < 0 then
                failure "IR_SOURCE_SPAN_INVALID" "Source-map spans must have a file, positive line/column, and nonnegative length." [ "valid SourceSpan" ] [ sprintf "%A" source.SiteSpan ]
            if siteOwner <> source.SiteOwner then
                failure "IR_SOURCE_SITE_OWNER_MISMATCH" "Source-site ID owner does not match its source-map entry." [ sprintf "%A" siteOwner ] [ sprintf "%A" source.SiteOwner ]
            match source.SiteOwner with
            | Some owner when not (program.FunctionsById.ContainsKey owner || program.GeneratedTargetsById.ContainsKey owner) ->
                failure "IR_SOURCE_OWNER_UNKNOWN" "Source map refers to an unknown owner identity." [] [ sprintf "%A" owner ]
            | None -> failure "IR_SOURCE_OWNER_UNKNOWN" "A complete executable program cannot contain standalone source-map entries." [ "word or generated owner" ] []
            | _ -> ()
        verifyAcyclicCallGraph program

    /// Verify manually supplied IR for conformance tests and structural tooling.
    /// The result deliberately cannot be executed by a host backend.
    let verify (catalog: IrPrimitiveCatalog) (program: IrProgram) =
        verifyProgram catalog Map.empty program
        VerifiedIrProgram(program, catalog, Map.empty, false, None)

    /// The compiler alone uses this path after lowering with its fixed host
    /// primitive registry. Public raw-IR verification remains non-executable.
    let internal verifyCompilerProgram (catalog: IrPrimitiveCatalog) (hostCatalog: IrHostOperationCatalog) snapshotFingerprint (program: IrProgram) =
        verifyProgram catalog hostCatalog program
        VerifiedIrProgram(program, catalog, hostCatalog, true, Some snapshotFingerprint)

    let coverageObligations (block: IrBlock) =
        let coveredSites, branchOutcomes = expectedCoverage Map.empty Map.empty block
        { CoveredSites = coveredSites; BranchOutcomes = branchOutcomes }

    let coverageObligationsWithSourceMap sourceMap (block: IrBlock) =
        let coveredSites, branchOutcomes = expectedCoverage Map.empty sourceMap block
        { CoveredSites = coveredSites; BranchOutcomes = branchOutcomes }

    let coverageObligationsWithTypes nominalTypes sourceMap (block: IrBlock) =
        let coveredSites, branchOutcomes = expectedCoverage nominalTypes sourceMap block
        { CoveredSites = coveredSites; BranchOutcomes = branchOutcomes }

    let verifyBody (verifiedProgram: VerifiedIrProgram) (body: IrExecutableBody) =
        if String.IsNullOrWhiteSpace body.BodyName then
            failure "IR_BODY_NAME_MISSING" "A detached executable body must have a display name." [ "nonempty body name" ] [ body.BodyName ]
        let sourceMap =
            Map.fold (fun merged site source ->
                if Map.containsKey site merged then
                    Diagnostics.raiseError "IR_SOURCE_SITE_COLLISION" "Detached body source sites collide with the compiled program snapshot." (Some body.BodyName) (Some source.SiteSpan) [] [ sprintf "%A" site ]
                Map.add site source merged) verifiedProgram.Program.SourceMap body.BodySourceMap
        if body.BodySourceMap |> Map.toList |> List.exists (fun (_, source) -> source.SiteOwner.IsSome) then
            failure "IR_BODY_SOURCE_OWNER" "Detached body source sites must use the standalone owner." [ "SiteOwner=None" ] (body.BodySourceMap |> Map.toList |> List.map (fun (site, source) -> sprintf "%A=%A" site source.SiteOwner))
        let program = { verifiedProgram.Program with SourceMap = sourceMap }
        let sites, branches = expectedCoverage verifiedProgram.Program.NominalTypesByKey sourceMap body.BodyBlock
        let obligations = { CoveredSites = sites; BranchOutcomes = branches }
        if body.BodyCoverage <> obligations then
            failure "IR_BODY_COVERAGE_MISMATCH" "Detached body coverage metadata does not match its executable structure." [ string obligations.CoveredSites.Count; string obligations.BranchOutcomes.Count ] [ string body.BodyCoverage.CoveredSites.Count; string body.BodyCoverage.BranchOutcomes.Count ]
        let instructionSites = instructionsInBlock body.BodyBlock |> List.map (fun instruction -> instruction.Site)
        let duplicateSites = instructionSites |> List.countBy id |> List.filter (fun (_, count) -> count > 1)
        if not duplicateSites.IsEmpty then
            failure "IR_DUPLICATE_SOURCE_SITE" "Each detached source expression must have one executable instruction identity across all nested blocks." [ "unique source-site ID per executable instruction" ] (duplicateSites |> List.map (fun (site, count) -> sprintf "%A (%d instructions)" site count))
        let bodySites = instructionSites |> Set.ofList
        if body.BodySourceMap |> Map.toSeq |> Seq.map fst |> Set.ofSeq <> bodySites then
            failure "IR_BODY_SOURCE_MAP_MISMATCH" "Detached body source map must contain every operation site, including synthetic implementation details." (bodySites |> Set.toList |> List.map (sprintf "%A")) (body.BodySourceMap |> Map.toList |> List.map (fun (site, _) -> sprintf "%A" site))
        let pseudoOwner =
            { FunctionId = WordId("detached:" + body.BodyName)
              FunctionRevision = 0
              FunctionName = body.BodyName
              InputTypes = body.BodyInputTypes
              OutputTypes = body.BodyOutputTypes
              FunctionDeclaredEffects = body.BodyDeclaredEffects
              FunctionInferredEffects = body.BodyInferredEffects
              LocalNames = body.BodyLocalNames
              FunctionBody = body.BodyBlock
              FunctionInline = false }
        body.BodyInputTypes @ body.BodyOutputTypes |> List.iter (verifyIrType program (Some body.BodyName) None)
        for KeyValue(slot, name) in body.BodyLocalNames do
            let (LocalSlot value) = slot
            if value < 0 || String.IsNullOrWhiteSpace name then
                failure "IR_LOCAL_LAYOUT_INVALID" "Detached body local slots must be nonnegative and have nonempty names." [ "valid local slot/name" ] [ sprintf "%A=%s" slot name ]
        if body.BodyBlock.EntryShape.StackTypes <> body.BodyInputTypes || body.BodyBlock.ExitShape.StackTypes <> body.BodyOutputTypes then
            failure "IR_BODY_SIGNATURE_MISMATCH" "Detached body block stack shape differs from its signature." (body.BodyInputTypes |> List.map IrTypes.format) (body.BodyBlock.ExitShape.StackTypes |> List.map IrTypes.format)
        if body.BodyBlock.EntryShape.LocalTypes |> Map.exists (fun _ _ -> true) then
            failure "IR_BODY_ENTRY_LOCALS" "Detached execution bodies must begin with no initialized locals." [] []
        for KeyValue(site, source) in body.BodySourceMap do
            let (SourceSiteId(siteOwner, ordinal)) = site
            if ordinal < 0 then failure "IR_SOURCE_SITE_INVALID" "Source-site ordinals must be nonnegative." [ "nonnegative ordinal" ] [ string ordinal ]
            if siteOwner.IsSome || source.SiteOwner.IsSome then
                failure "IR_BODY_SOURCE_OWNER" "Detached body source sites must use the standalone owner." [ "SiteOwner=None" ] [ sprintf "%A=%A" site source.SiteOwner ]
            if String.IsNullOrWhiteSpace source.SourceKind || String.IsNullOrWhiteSpace source.SiteSpan.File || source.SiteSpan.Line < 1 || source.SiteSpan.Column < 1 || source.SiteSpan.Length < 0 then
                failure "IR_SOURCE_SPAN_INVALID" "Detached body source map must contain a valid source kind and span." [ "valid SourceSpan and source kind" ] [ sprintf "%A" source.SiteSpan ]
        verifyBlock program verifiedProgram.Catalog verifiedProgram.HostCatalog pseudoOwner None body.BodyBlock
        VerifiedIrBody(verifiedProgram, body)

# Git boundary 204 source review

**Outcome: scoped approval.** The final source pins in `implementation/source-pins-final.json` match the reviewed `FileSystem.fs` and CLI test sources.

`FileSystem.resolve` canonicalizes the project root and requested path, enforces containment, then checks the relative path's first segment in `isReservedProjectPath`. The new `.git` comparison uses `StringComparison.OrdinalIgnoreCase` on every platform, so the canonical root `.git` entry and its subtree are reserved after path normalization, including `./.git` and `ordinary/../.git`. The exact segment comparison leaves `.git-data` available. The Windows alias guard is unchanged; its existing invalid-path behavior still takes precedence for ambiguous spellings.

The reserved-path failure retains `EFFECT_FILE_PATH_RESERVED` and now describes host-managed project metadata, which also fits Git metadata. The change is confined to the real filesystem resolver. `Runtime.fs` still routes virtual reads, writes, and existence checks through its in-memory map, without calling this resolver.

The CLI tests use `withProject`, which creates a disposable project under the system temporary directory. They create a synthetic `.git` directory with config and hook bytes, plus a separate synthetic `.git` pointer file. Read, write, and exists requests cover normalized and uppercase spellings; the tests check that the synthetic bytes remain unchanged. They also verify that `.git-data` remains usable and that a fresh CLI process reloads the committed library after the reserved-path requests. The hooks are fixture bytes only; the test code launches the AgentLang CLI and does not invoke Git, initialize a repository, create a worktree, or execute hooks.

The implementation receipt records a passing Release build, CLI tests (13 groups, 305 assertions), and `git diff --check`; this source-only review did not run those commands. Coverage is limited to the canonical project-root `.git` entry. Nested repositories, hardlinks, and hostile concurrent filesystem changes remain outside scope; this change is not an OS sandbox or a security certification.

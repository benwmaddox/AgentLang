"""Non-executable synthetic Git metadata probe; never touches checkout metadata."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

repo = Path(__file__).resolve().parents[2]
root = Path(__file__).resolve().parent
project = root / 'baseline-project-corrected'
runtime = root / 'baseline-runtime'
if project.exists():
    raise SystemExit('Refusing to reuse probe paths')
if not runtime.exists():
    shutil.copytree(repo / 'src/AgentLang.Cli/bin/Release/net9.0', runtime)
hook = project / '.git/hooks/pre-commit'
hook.parent.mkdir(parents=True)
hook.write_bytes(b'# inert fixture; never executed\n')
requests = [{'op': 'eval', 'syntaxVersion': 2,
             'code': 'file.write(".git/hooks/pre-commit", "changed inert fixture")'}]
before = hook.read_bytes()
run = subprocess.run(['dotnet', str(runtime / 'AgentLang.Cli.dll'), '--project', str(project),
                      '--allow', 'fs.write', '--jsonl'], input=json.dumps(requests[0]) + '\n',
                     text=True, capture_output=True, timeout=30)
(root / 'baseline-corrected.requests.jsonl').write_text(json.dumps(requests[0]) + '\n', encoding='utf-8')
(root / 'baseline-corrected.stdout.jsonl').write_text(run.stdout, encoding='utf-8')
(root / 'baseline-corrected.stderr.log').write_text(run.stderr, encoding='utf-8')
after = hook.read_bytes()
receipt = {'exitCode': run.returncode, 'syntheticHookChanged': before != after,
           'before': before.decode(), 'after': after.decode(),
           'hooksExecuted': False, 'runtimePins': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in runtime.glob('*') if p.suffix in {'.dll', '.json'}}}
(root / 'baseline-corrected-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
if run.returncode != 0 or not json.loads(run.stdout)['ok'] or not receipt['syntheticHookChanged']:
    raise SystemExit('Baseline did not reproduce metadata write')
print('Confirmed synthetic Git-hook metadata overwrite; no hook executed.')

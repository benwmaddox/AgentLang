$ErrorActionPreference = 'Stop'
$repo = (Get-Location).Path
$evidence = Join-Path $repo '.agentlang/native-float-format-224/runtime'
$currentDir = Join-Path $repo 'src/AgentLang.Llvm/native'
$baselineDir = Join-Path $evidence 'baseline'
$clang = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\x64\bin\clang.exe'
$nm = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\x64\bin\llvm-nm.exe'
$env:TEMP = $evidence
$env:TMP = $evidence
$commands = [Collections.Generic.List[string]]::new()
$results = [Collections.Generic.List[string]]::new()
foreach ($optimization in @('O0', 'O2')) {
    foreach ($variant in @('current', 'baseline')) {
        $sourceDir = if ($variant -eq 'current') { $currentDir } else { $baselineDir }
        $source = Join-Path $sourceDir 'owning_stack_runtime.c'
        $object = Join-Path $evidence "runtime-$variant-$optimization.obj"
        $args = @('--target=x86_64-pc-windows-msvc', '-std=c11', '-Wall', '-Wextra', '-Werror', '-ffreestanding', '-fno-builtin', "-$optimization", "-I$sourceDir", '-c', $source, '-o', $object)
        $commands.Add("$clang $($args -join ' ')")
        & $clang @args *> (Join-Path $evidence "runtime-$variant-$optimization-build.log")
        $buildExit = $LASTEXITCODE
        if ($buildExit -ne 0) { throw "Runtime object build failed: $variant $optimization exit=$buildExit" }
        $symbolOutput = & $nm '-u' $object
        $nmExit = $LASTEXITCODE
        if ($nmExit -ne 0) { throw "llvm-nm failed: $variant $optimization exit=$nmExit" }
        $symbolOutput | Set-Content -LiteralPath (Join-Path $evidence "symbols-$variant-$optimization.txt") -Encoding ascii
        $results.Add("$variant $optimization buildExit=$buildExit nmExit=$nmExit undefined=$((($symbolOutput | ForEach-Object { $_.Trim() }) -join ','))")
    }
    $current = @((Get-Content -LiteralPath (Join-Path $evidence "symbols-current-$optimization.txt")) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    $baseline = @((Get-Content -LiteralPath (Join-Path $evidence "symbols-baseline-$optimization.txt")) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    $added = @(Compare-Object -ReferenceObject $baseline -DifferenceObject $current | Where-Object SideIndicator -eq '=>' | ForEach-Object InputObject)
    $memoryImports = @($current | Where-Object { $_ -match '(?i)memcpy|memmove|memset' })
    $baseChkstk = @($baseline | Where-Object { $_ -match '(?i)chkstk' }).Count
    $currentChkstk = @($current | Where-Object { $_ -match '(?i)chkstk' }).Count
    if ($added.Count -ne 0 -or $memoryImports.Count -ne 0 -or $baseChkstk -ne $currentChkstk) {
        throw "Undefined symbol audit differs at $optimization"
    }
    $results.Add("comparison $optimization addedUndefined=none memoryImports=none chkstkCurrent=$currentChkstk chkstkBaseline=$baseChkstk")
}
$commands | Set-Content -LiteralPath (Join-Path $evidence 'symbol-audit-commands.txt') -Encoding utf8
$results | Set-Content -LiteralPath (Join-Path $evidence 'symbol-audit-results.txt') -Encoding utf8

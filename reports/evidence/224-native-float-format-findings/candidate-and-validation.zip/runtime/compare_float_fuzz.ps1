param([Parameter(Mandatory=$true)][string]$NativePath,[Parameter(Mandatory=$true)][string]$OutputDirectory)
$invariant = [Globalization.CultureInfo]::InvariantCulture
$nativeLines = [IO.File]::ReadAllLines($NativePath)
$bitsLines = [Collections.Generic.List[string]]::new()
$oracleLines = [Collections.Generic.List[string]]::new()
$checked = 0
foreach ($line in $nativeLines) {
    $parts = $line.Split("`t", 2)
    if ($parts.Length -ne 2) { throw "Malformed native output line $checked" }
    $bits = [UInt64]::Parse($parts[0], [Globalization.NumberStyles]::HexNumber, $invariant)
    [byte[]]$bytes = 0,0,0,0,0,0,0,0
    for ($i = 0; $i -lt 8; $i++) { $bytes[$i] = [byte](($bits -shr (8 * $i)) -band [UInt64]255) }
    $expected = [BitConverter]::ToDouble($bytes, 0).ToString('G', $invariant)
    if ($parts[1] -cne $expected) { throw ('Mismatch {0}: native={1} dotnet={2}' -f $parts[0], $parts[1], $expected) }
    $bitsLines.Add($parts[0])
    $oracleLines.Add($parts[0] + "`t" + $expected)
    $checked++
}
[IO.File]::WriteAllLines((Join-Path $OutputDirectory 'float-format-10000-bits.txt'), $bitsLines, [Text.Encoding]::ASCII)
[IO.File]::WriteAllLines((Join-Path $OutputDirectory 'dotnet-float-format-10000.tsv'), $oracleLines, [Text.Encoding]::ASCII)
"cases=$checked`nmethod=xorshift64 state=0x9e3779b97f4a7c15, shifts=13/7/17, exponent=state%2047; compare raw-bit .NET G invariant output`nstatus=pass"

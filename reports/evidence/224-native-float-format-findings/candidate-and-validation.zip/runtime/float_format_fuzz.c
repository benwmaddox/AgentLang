#include "owning_stack_runtime.h"
#include <stdint.h>
#include <stdio.h>

int main(void) {
  al_owning_stack_context context = {0};
  uint64_t state = UINT64_C(0x9e3779b97f4a7c15);
  uint32_t index;
  for (index = 0u; index < 10000u; ++index) {
    uint8_t ascii[AL_OWNING_FLOAT_ASCII_CAPACITY];
    uint32_t length = 0u;
    uint64_t bits;
    uint32_t exponent;
    state ^= state << 13u;
    state ^= state >> 7u;
    state ^= state << 17u;
    exponent = (uint32_t)(state % 2047u);
    bits = (state & UINT64_C(0x800fffffffffffff)) |
           ((uint64_t)exponent << 52u);
    if (al_owning_float_format(&context, bits, ascii, &length, 1u) != 0)
      return 2;
    (void)printf("%016llx\t", (unsigned long long)bits);
    (void)fwrite(ascii, 1u, length, stdout);
    (void)putchar('\n');
  }
  return 0;
}

# Native binary64 format verification evidence

This directory records focused validation for the formatter in `src/AgentLang.Llvm/native/float_format.h` and its runtime wrappers. The compiled test executables and temporary runner are kept here so the repository's native source directory contains no build artifacts.

## Algorithm bounds reviewed

The implementation decodes each finite binary64 as `m * 2^e`. It stores the exact center and interval margins as integer ratios scaled by four. For `e < 0`, the center is `(4m) / (4 * 2^-e)` and each margin is an integer over the same denominator. For `e >= 0`, the center is `(4m * 2^e) / 4` and margins are shifted by `e`. A normal power of two with exponent field greater than one uses a one-unit lower margin and a two-unit upper margin; all other values use two units on both sides. The smallest normal therefore keeps equal margins. Both midpoint endpoints are included only when the binary significand is even.

The largest denominator is `4 * 2^1074 = 2^1076` bits by value; the largest exact center for a finite normal is below `2^1026`. Decimal normalization multiplies a center and both margins, or the denominator, by ten for at most 324 iterations. Its largest scaled component remains below 1140 bits. Four fixed 40-limb values occupy 640 bytes; one 40-limb temporary uses another 160 bytes. Digit generation stops within 17 significant digits. Every shift, multiply, subtract, digit append, normalization step, and output write has a bound check; a violated bound maps to an internal runtime failure. Runtime code uses integer arithmetic and no formatter, parser, allocation, or floating-point operation.

After the shortest prefix is inside its interval, the implementation chooses the nearest decimal candidate; an exact decimal tie uses even final decimal digit. Carry is applied before trailing zero removal. Fixed notation is used for decimal exponents -4 through 16 inclusive; other values use uppercase `E`, an explicit exponent sign, and at least two exponent digits. Signed zero is emitted as `0` or `-0`.

## Native unit results

`native-test-commands.txt` and `native-test-results.txt` record O0, O2, and UBSan trap build and run commands/results. Each run passed with 56 cases and 792 checks (40 dynamic cases / 603 checks). The six boundary vectors add six checks to the earlier 56-case / 786-check run; ABI and byte-category metrics remain unchanged.

## Supplemental random .NET 10 oracle

`float_format_fuzz.c` uses a deterministic xorshift64 state seeded with `0x9e3779b97f4a7c15`; each round applies shifts 13, 7, and 17, chooses exponent field `state % 2047`, and retains the sign and fraction bits. This gives 10,000 finite raw binary64 values. `native-float-format-10000.tsv` contains the raw bits and native result. `compare_float_fuzz.ps1` reconstructs each bit pattern, calls `.NET double.ToString("G", InvariantCulture)`, compares ordinally, and writes `float-format-10000-bits.txt` and `dotnet-float-format-10000.tsv`. `random-oracle-comparison.log` records a 10,000-case pass on PowerShell 7.6.5 / .NET 10.0.11, as recorded in `oracle-environment.txt`. This is supplemental; the focused .NET 9 oracle corpus is authoritative.

`pow2-probe-comparison.log` records a separate .NET 10.0.11 probe of 12,276 signed exact powers of two and immediate neighbors. It found two distinct positive power-of-two values whose `G` output parses to the predecessor; `dotnet-g-fallback-bug-repro-net10.log` records the relevant bit patterns and the .NET 9 focused-corpus failure artifact hash. The formatter regression tests keep the exact round-trip strings at the reported boundary and its neighbors.

## Undefined-symbol audit

`audit_symbols.ps1` compiles both the current runtime and the `HEAD` baseline saved under `baseline/`, with `-ffreestanding -fno-builtin`, at O0 and O2. It runs `llvm-nm -u` and compares outputs. `symbol-audit-results.txt` shows the same pre-existing `U __chkstk` symbol at both optimization levels for current and baseline; there are no new undefined symbols and no `memcpy`, `memmove`, or `memset` imports. Command, symbol, and build logs are stored beside this file.

`clang-version.log`, `hashes.sha256`, `diff-check.log`, command files, and the named object/executable artifacts make the runs reproducible and inspectable.

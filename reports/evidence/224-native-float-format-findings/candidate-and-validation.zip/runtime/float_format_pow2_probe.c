#include "owning_stack_runtime.h"
#include <stdint.h>
#include <stdio.h>
int main(void) {
  al_owning_stack_context context = {0};
  uint32_t exponent;
  for (exponent = 1u; exponent < 0x7ffu; ++exponent) {
    int32_t offset;
    for (offset = -1; offset <= 1; ++offset) {
      uint64_t base = (uint64_t)exponent << 52u;
      uint64_t bits = offset < 0 ? base - 1u : (offset > 0 ? base + 1u : base);
      uint32_t sign;
      for (sign = 0u; sign < 2u; ++sign) {
        uint8_t ascii[AL_OWNING_FLOAT_ASCII_CAPACITY];
        uint32_t length = 0u;
        uint64_t signed_bits = bits | ((uint64_t)sign << 63u);
        if (al_owning_float_format(&context, signed_bits, ascii, &length, 1u) != 0)
          return 2;
        (void)printf("%016llx\t", (unsigned long long)signed_bits);
        (void)fwrite(ascii, 1u, length, stdout);
        (void)putchar('\n');
      }
    }
  }
  return 0;
}

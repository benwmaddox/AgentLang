$ErrorActionPreference = 'Stop'
$ev = Split-Path -Parent $MyInvocation.MyCommand.Path
$lines = Get-Content -LiteralPath (Join-Path $ev 'pow2-probe-native.tsv')
$culture = [Globalization.CultureInfo]::InvariantCulture
$diffs = [System.Collections.Generic.List[string]]::new()
$powerDiffs = [System.Collections.Generic.List[string]]::new()
$roundtripFailures = [System.Collections.Generic.List[string]]::new()
foreach ($line in $lines) {
  $parts = $line.Split("`t")
  $bits = [Convert]::ToUInt64($parts[0], 16)
  $raw = [BitConverter]::ToInt64([BitConverter]::GetBytes($bits), 0)
  $value = [BitConverter]::Int64BitsToDouble($raw)
  $expected = $value.ToString('G', $culture)
  if (-not [string]::Equals($expected, $parts[1], [StringComparison]::Ordinal)) {
    $m = '{0} expected={1} native={2}' -f $parts[0], $expected, $parts[1]
    $diffs.Add($m)
    if (($bits -band 0x000fffffffffffff) -eq 0) { $powerDiffs.Add($m) }
    $parsed = [double]::Parse($expected, $culture)
    $parsedBits = [BitConverter]::ToUInt64([BitConverter]::GetBytes($parsed), 0)
    if ($parsedBits -ne $bits) { $roundtripFailures.Add(('{0} parsesAs={1:X16} expected={2}' -f $parts[0],$parsedBits,$expected)) }
  }
}
$report = [System.Collections.Generic.List[string]]::new()
$report.Add('framework=' + [Runtime.InteropServices.RuntimeInformation]::FrameworkDescription)
$report.Add('inputCount=' + $lines.Count)
$report.Add('mismatchCount=' + $diffs.Count)
$report.Add('powerOfTwoMismatchCount=' + $powerDiffs.Count)
$report.Add('nonRoundtripMismatchCount=' + $roundtripFailures.Count)
$report.Add('mismatches:')
foreach ($item in $diffs) { $report.Add($item) }
$report.Add('oracleNonRoundtrip:')
foreach ($item in $roundtripFailures) { $report.Add($item) }
$report | Set-Content -LiteralPath (Join-Path $ev 'pow2-probe-comparison.log')

using System;
using System.Globalization;
using System.Runtime.InteropServices;

Console.WriteLine("FrameworkDescription=" + RuntimeInformation.FrameworkDescription);
Console.WriteLine("Environment.Version=" + Environment.Version);
Console.WriteLine("CoreLib=" + typeof(double).Assembly.Location);
Console.WriteLine("RequestedTargetFramework=net9.0");
ulong bits = 0x0410000000000000UL;
double value = BitConverter.UInt64BitsToDouble(bits);
Console.WriteLine("InputBits=" + bits.ToString("X16"));
foreach (string format in new[] { "G", "R", "G17" })
{
    string text = value.ToString(format, CultureInfo.InvariantCulture);
    ulong parsedBits = BitConverter.DoubleToUInt64Bits(double.Parse(text, CultureInfo.InvariantCulture));
    Console.WriteLine($"Format={format}; Text={text}; ParsedBits={parsedBits:X16}; SameBits={parsedBits == bits}");
}
string nativeCandidate = "4.1045368012983762E-289";
ulong candidateBits = BitConverter.DoubleToUInt64Bits(double.Parse(nativeCandidate, CultureInfo.InvariantCulture));
Console.WriteLine($"NativeCandidate={nativeCandidate}; ParsedBits={candidateBits:X16}; SameBits={candidateBits == bits}");
Console.WriteLine($"Dragon4UintShift52={1U << 52}; DoubleImplicitMantissa={1UL << 52}; Equal={(1UL << 52) == (1U << 52)}");
foreach (ulong neighborBits in new[] { bits - 1, bits, bits + 1 })
{
    string text = BitConverter.UInt64BitsToDouble(neighborBits).ToString("G", CultureInfo.InvariantCulture);
    Console.WriteLine($"NeighborBits={neighborBits:X16}; G={text}");
}

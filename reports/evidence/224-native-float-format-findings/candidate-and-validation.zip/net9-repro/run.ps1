$ErrorActionPreference = 'Stop'
$projectPath = Join-Path $PSScriptRoot 'net9-repro.csproj'
$outputPath = Join-Path $PSScriptRoot 'output.txt'
& dotnet run --project $projectPath -c Release -p:NuGetAudit=false 2>&1 | Tee-Object -FilePath $outputPath
if ($LASTEXITCODE -ne 0) { throw "net9 repro failed with exit code $LASTEXITCODE" }

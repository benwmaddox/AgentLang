# .NET 9 formatting mismatch reproduction

Run from the repository root:

```powershell
& ./.agentlang/native-float-format-224/net9-repro/run.ps1
```

The script runs `dotnet run --project <this directory>/net9-repro.csproj -c Release -p:NuGetAudit=false` and preserves its raw output in `output.txt`. The recorded run completed with exit code 0 and explicitly identifies .NET 9.0.11, its CoreLib path, and `Environment.Version`.

The input `0x0410000000000000` produces identical `G` and `R` text, `4.104536801298376E-289`, which invariant parsing maps to predecessor bits `0x040FFFFFFFFFFFFF`. Explicit `G17` and the native formatter candidate, `4.1045368012983762E-289`, both parse to the original bits.

Primary-source investigation:

- https://raw.githubusercontent.com/dotnet/runtime/v9.0.10/src/libraries/System.Private.CoreLib/src/System/Number.Dragon4.cs — line 25 uses `mantissa == (1U << TNumber.DenormalMantissaBits)`. For binary64, a 32-bit shift by 52 is masked to 20. The program records this value and the unequal comparison. This causes Dragon4 to use symmetric margins for normal binary64 powers of two.
- https://raw.githubusercontent.com/dotnet/runtime/v9.0.10/src/libraries/System.Private.CoreLib/src/System/Number.DiyFp.cs — lines 94–115 build Grisu3 boundaries using `1UL`, so its power-of-two detection differs from Dragon4.
- https://raw.githubusercontent.com/dotnet/runtime/v9.0.10/src/libraries/System.Private.CoreLib/src/System/Number.Grisu3.cs — lines 315–345 describe success/failure of the Grisu3 conversion; the formatting path falls back to Dragon4 on failure.
- https://raw.githubusercontent.com/dotnet/runtime/v9.0.0/src/libraries/System.Private.CoreLib/src/System/Number.Formatting.cs — lines 547–550 call Dragon4 if Grisu3 fails.

The source explanation is an inference consistent with the exact local reproduction; this project does not instrument internal Grisu3 execution. It does not establish a complete discriminator for all affected values. Replacing native lower margins globally with symmetric margins would therefore be unjustified. The preserved candidate is not a proof of interpreter byte parity or authorization to change interpreter semantics.

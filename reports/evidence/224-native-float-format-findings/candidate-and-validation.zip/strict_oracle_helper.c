#include "owning_stack_runtime.h"
#include "float_format.h"
__declspec(dllexport) int format_bits(uint64_t bits, uint8_t *ascii, uint32_t *length) {
  return al_owning_float_format_ascii(bits, ascii, length);
}

# 224 — Native Float formatting

Status: validation in progress.

The owning AOT backend now lowers `float.to-string` to a bounded original integer formatter. Its contract stays the interpreter's finite binary64 `ToString("G", InvariantCulture)`: shortest round-trip digits, nearest/ties-even choice, signed zero, and invariant fixed/scientific rendering. No interpreter or typed semantic IR behavior changes.

The helper uses five 40-limb integer workspaces (800 bytes) plus small bounded text buffers. Normalization stops within 324 decimal shifts and digit generation within 17 digits. Bound failures produce structured errors; there is no approximation fallback. The generated frame accounts for its 32-byte ASCII buffer and four-byte length; transient C helper scratch is separate from that generated-frame metadata. Results use the existing owning UTF-16 String representation and allocation trace.

The implementation adds no external-effect grant, arbitrary .NET invocation, runtime allocation dependency, locale formatter, or managed callback. The native ABI still relies on trusted host pointers. Owning stack ABI 2, layout/schema 4, mailbox module ABI 2, and the 176-byte context remain unchanged. Native verifier source pins now include the helper header; touched fresh-build verifiers enable NuGet auditing.

Validation results will be filled from final stable-source receipts. Early failures are retained separately: test compilation referenced a nonexistent metrics field; the raw fuel fixture initially exhausted its 4 KB arena before reaching the instruction limit; O2 copy-loop optimization introduced memcpy/memmove imports. These were harness/implementation defects to correct, not reasons to relax parity or failure checks. Some first-attempt output was not saved; retrospective notes must distinguish that from raw logs.

This is native semantic conformance, not a throughput, memory-policy, or agent-efficacy result. The fresh reliability comparison in report 222 still establishes no AgentLang advantage. The interpreter remains authoritative; legacy shared-graph Float, general native release coverage and JIT remain later work.

import ctypes, json, math, platform, struct
from decimal import Decimal
from pathlib import Path
root = Path(__file__).resolve().parent
lib = ctypes.CDLL(str(root / 'strict_oracle_helper.dll'))
fn = lib.format_bits
fn.argtypes = [ctypes.c_uint64, ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint32)]
fn.restype = ctypes.c_int
cases = set()
mask = (1 << 52) - 1
for exponent in range(2047):
    for mantissa in [0, 1, 2, 1 << 51, mask - 1, mask]:
        for sign in [0, 1 << 63]:
            cases.add(sign | exponent << 52 | mantissa)
for line in (root / 'runtime/native-float-format-10000.tsv').read_text().splitlines():
    cases.add(int(line.split('\t')[0], 16))
for exponent in range(-323, 309):
    value = float('1e' + str(exponent))
    if math.isfinite(value) and value > 0:
        for near in [math.nextafter(value, 0), value, math.nextafter(value, math.inf)]:
            if math.isfinite(near):
                bits = int.from_bytes(struct.pack('>d', near), 'big')
                cases.add(bits)
                cases.add(bits | (1 << 63))
def oracle(value, bits):
    sign = '-' if bits >> 63 else ''
    if value == 0:
        return sign + '0'
    digits_tuple = Decimal(repr(abs(value))).as_tuple()
    digits = ''.join(str(d) for d in digits_tuple.digits)
    exponent = len(digits) + digits_tuple.exponent - 1
    digits = digits.rstrip('0')
    if -4 <= exponent <= 16:
        point = exponent + 1
        if point <= 0:
            text = '0.' + '0' * -point + digits
        elif point >= len(digits):
            text = digits + '0' * (point - len(digits))
        else:
            text = digits[:point] + '.' + digits[point:]
    else:
        text = digits[0] + ('.' + digits[1:] if len(digits) > 1 else '')
        text += 'E' + ('-' if exponent < 0 else '+') + str(abs(exponent)).zfill(2)
    return sign + text
mismatches, bad_roundtrips = [], []
with (root / 'strict-python-oracle.tsv').open('w', newline='\n') as output:
    for bits in sorted(cases):
        raw = bits.to_bytes(8, 'big')
        value = struct.unpack('>d', raw)[0]
        expected = oracle(value, bits)
        buffer = (ctypes.c_uint8 * 32)()
        length = ctypes.c_uint32(0)
        status = fn(bits, buffer, ctypes.byref(length))
        actual = bytes(buffer)[:length.value].decode('ascii') if status == 1 else '<failure>'
        output.write(f'{bits:016X}\t{expected}\t{actual}\n')
        if actual != expected:
            mismatches.append({'bits': f'{bits:016X}', 'expected': expected, 'actual': actual})
        if status != 1 or struct.pack('>d', float(actual)) != raw:
            bad_roundtrips.append(f'{bits:016X}')
summary = {'python': platform.python_version(), 'nativeOptimization': 'O2', 'cases': len(cases), 'mismatchCount': len(mismatches), 'roundtripFailureCount': len(bad_roundtrips), 'firstMismatches': mismatches[:20], 'status': 'pass' if not mismatches and not bad_roundtrips else 'fail', 'contract': 'CPython repr shortest digits rendered with invariant exponent thresholds -4 through16; independent of .NET G'}
(root / 'strict-python-oracle-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
raise SystemExit(0 if summary['status'] == 'pass' else 1)

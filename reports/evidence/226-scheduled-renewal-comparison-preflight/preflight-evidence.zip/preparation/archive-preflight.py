#!/usr/bin/env python3
"""Package only the scheduled-batch-226 pre-dispatch preparation evidence."""

from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path
from typing import Any


REPO = Path(__file__).resolve().parents[2]
STUDY = ".agentlang/scheduled-batch-226"
OUT = REPO / "reports/evidence/226-scheduled-renewal-comparison-preflight"
ARCHIVE = OUT / "preflight-evidence.zip"
SIDECAR = OUT / "preflight-evidence.manifest.json"
INNER_MANIFEST = "MANIFEST.json"

EXCLUDED_PARTS = {
    "bin", "obj", "scratch", "temp", "tmp", "project-copy", "scoring-copy", "artifacts",
}
EXCLUDED_NAMES = {"dispatch.jsonl"}

items: dict[str, tuple[Path | None, bytes | None, str]] = {}
excluded: dict[str, int] = {}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def add_bytes(member: str, data: bytes, group: str) -> None:
    name = member.replace("\\", "/")
    if name in items or name == INNER_MANIFEST:
        raise ValueError(f"duplicate archive member: {name}")
    items[name] = (None, data, group)


def add_file(path: Path, group: str, member: str | None = None) -> None:
    if not path.is_file():
        raise FileNotFoundError(path)
    name = (member or path.relative_to(REPO).as_posix()).replace("\\", "/")
    if name in items or name == INNER_MANIFEST:
        raise ValueError(f"duplicate archive member: {name}")
    items[name] = (path, None, group)


def excluded_file(path: Path, extra_parts: set[str] | None = None) -> str | None:
    parts = set(path.parts)
    blocked = EXCLUDED_PARTS | (extra_parts or set())
    hit = next((p for p in path.parts if p.lower() in blocked), None)
    if hit:
        return f"directory:{hit}"
    if path.name.lower() in EXCLUDED_NAMES:
        return f"file:{path.name}"
    return None


def add_tree(rel: str, group: str, *, extra_exclusions: set[str] | None = None) -> None:
    root = REPO / rel
    if not root.is_dir():
        raise FileNotFoundError(root)
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        reason = excluded_file(path, extra_exclusions)
        if reason:
            excluded[reason] = excluded.get(reason, 0) + 1
            continue
        add_file(path, group)


def add_selected_tree_files(rel: str, group: str, predicate) -> None:
    root = REPO / rel
    if not root.is_dir():
        raise FileNotFoundError(root)
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        reason = excluded_file(path)
        if reason:
            excluded[reason] = excluded.get(reason, 0) + 1
            continue
        if predicate(path):
            add_file(path, group)
        else:
            excluded["scope-filter:" + rel] = excluded.get("scope-filter:" + rel, 0) + 1


def add_fixed(rel: str, group: str) -> None:
    add_file(REPO / rel, group)


def make_runtime_inventory() -> bytes:
    root = REPO / STUDY
    setup = json.loads((root / "setup.json").read_text(encoding="utf-8"))
    candidate = json.loads((root / "freeze-candidate.json").read_text(encoding="utf-8"))
    inventory: dict[str, Any] = {
        "study": "scheduled-batch-226",
        "source": "setup.json and freeze-candidate.json pin records",
        "binaryPayloadsIncluded": False,
        "runtimes": {},
    }
    pins = candidate["privateRuntimes"]
    for arm, details in sorted(pins.items()):
        prep = setup["freshRuntimes"][arm]
        inventory["runtimes"][arm] = {
            "path": details["path"],
            "treeSha256": details.get("treeSha256"),
            "preparationSource": prep.get("source"),
            "files": [],
        }
        for row in sorted(details["files"], key=lambda x: x["path"]):
            filename = row["path"]
            binary = Path(filename).suffix.lower() in {".dll", ".exe", ".pdb", ".so", ".dylib"}
            inventory["runtimes"][arm]["files"].append({
                "path": filename,
                "bytes": row["bytes"],
                "sha256": row["sha256"],
                "binaryOmitted": binary,
                "includedAsMetadata": not binary,
            })
            if not binary:
                add_fixed(f"{details['path']}/{filename}", "pinned-runtime-metadata")
    return (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode("utf-8")


def read_member(path: Path | None, data: bytes | None) -> bytes:
    if path is not None:
        return path.read_bytes()
    assert data is not None
    return data


def record_for(name: str, value: tuple[Path | None, bytes | None, str]) -> dict[str, Any]:
    path, data, group = value
    raw = read_member(path, data)
    return {
        "path": name,
        "group": group,
        "bytes": len(raw),
        "sha256": sha256(raw),
        "source": str(path.relative_to(REPO).as_posix()) if path is not None else "generated",
    }


def select_inputs() -> None:
    # Stable study inputs and source packets.
    for rel in ("setup.json", "freeze-candidate.json", "freeze-supplement.json", "freeze.json"):
        add_fixed(f"{STUDY}/{rel}", "candidate-supplement-freeze")
    add_tree(f"{STUDY}/packets", "participant-packets")
    add_tree(f"{STUDY}/review", "preflight-review")
    add_tree(f"{STUDY}/launchers", "pinned-launchers")

    # One baseline source copy for each arm; preflight clones are excluded.
    add_tree(f"{STUDY}/baselines/retained", "baseline-retained")
    add_tree(f"{STUDY}/baselines/fsharp", "baseline-fsharp")

    # Fresh build and broker receipts, plus raw non-trace preflight attempts.
    add_tree(f"{STUDY}/root-builds", "fresh-build-and-broker-logs")
    add_fixed(f"{STUDY}/root/preflight.json", "preflight-receipts")
    for rel in ("root/preflight", "root/preflight-attempt-01", "root/preflight-attempt-02"):
        add_tree(f"{STUDY}/{rel}", "preflight-attempt-logs", extra_exclusions={"project"})
    add_tree(f"{STUDY}/root/control-attempts", "fsharp-control-attempt-sources")

    # Final actual controls only, each retained once with its canonical store.
    agentlang_controls = (
        "controls/agentlang-candidate09/correct",
        "controls/agentlang-candidate10/shared-instant",
        "controls/agentlang-candidate10/sort-by-at",
        "controls/agentlang-candidate12/last-error",
        "controls/agentlang-candidate14/partial-success",
    )
    for rel in agentlang_controls:
        add_tree(f"{STUDY}/{rel}", "final-agentlang-control-root")
    add_tree(f"{STUDY}/controls/fsharp-calibrated", "final-fsharp-control-sources")

    # Preserve all AgentLang control producer attempts and raw authored exchanges.
    add_tree(f"{STUDY}/controls/agentlang-buildlogs", "agentlang-control-producer-logs")

    # Raw F# runs, including failed early calibration attempts; omit build artifacts.
    for rel in (
        "oracle-work/fsharp/runs",
        "oracle-work/fsharp-controls",
        "oracle-work/fsharp-calibrated-scores",
        "oracle-work/fsharp-calibrated-final",
    ):
        add_tree(f"{STUDY}/{rel}", "fsharp-calibration-runs")

    # Final AgentLang calibration and the preserved incomplete-control receipt.
    for rel in ("oracle-work/language/c", "oracle-work/language/correct-final"):
        add_tree(f"{STUDY}/{rel}", "agentlang-calibration-and-typegate-raw")

    # Independent root type-gate probes and their complete raw exchanges.
    add_tree(f"{STUDY}/root-type-gates", "root-typegate-probes")

    # Tracked experiment sources and evaluator/model files.
    add_tree("experiments/AgentLang.SubagentTrials/scheduled-batch-226", "tracked-experiment-source")

    # Runtime pins are retained as metadata, while executable payloads stay out.
    add_bytes("preparation/runtime-inventory.json", make_runtime_inventory(), "pinned-runtime-inventory")
    add_file(Path(__file__).resolve(), "archive-packager", "preparation/archive-preflight.py")

    notes = """# Scheduled renewal comparison preflight evidence

This archive contains preparation evidence only. It has no participant actor
source, actor outputs, dispatch records, or active traces. The final freeze is
included with its clear preflight review; participants were not dispatched at
the time that freeze was created.

Included material covers both baseline source arms; fresh CLI/business/broker
build and preflight receipts; pinned runtime metadata; final AgentLang and F#
control roots and the producer/run logs; actual type-gate probes; the finalized
candidate, supplement, freeze and review; failed/superseded preflight and
control attempts; and the tracked 226 experiment source.

The five final AgentLang control roots each appear once with their manifest and
object store. Scoring `project-copy` trees, preflight baseline clones, and
compiled scorer artifacts are omitted. Runtime binaries are omitted; their
sizes and SHA-256 pins are recorded in the freeze/setup inputs and the generated
`preparation/runtime-inventory.json`. The `.deps.json` and `.runtimeconfig.json`
metadata files are included.

Exclusions: `.agentlang/scheduled-batch-226/actors/**` was not traversed or
read; the active `.agentlang/scheduled-batch-226/traces/**` directory and
`dispatch.jsonl` were excluded. Completed preparation `trace.jsonl` receipts
under root preflight attempts are included. `bin/`,
`obj/`, scratch/temp trees, `project-copy/`, `scoring-copy/`, and compiled
`artifacts/` were omitted; intermediate built control roots were omitted while
all available AgentLang producer logs and failed run receipts were retained.

One combined scorer attempt was stopped by Windows `WinError 3` while copying
to a 281-character destination path before case execution. Its completed type
gate probes are preserved in the successful shorter-path run; the successful
combined calibration is recorded in `oracle-work/language/c/`.
"""
    add_bytes("preparation/README.md", notes.encode("utf-8"), "archive-scope-and-exclusions")


def main() -> int:
    select_inputs()
    records = [record_for(name, items[name]) for name in sorted(items)]
    freeze = json.loads((REPO / STUDY / "freeze.json").read_text(encoding="utf-8"))
    inner = {
        "format": "scheduled-batch-226-preflight-evidence-v1",
        "freezeStatus": freeze.get("status"),
        "freezeFinalizedAtUtc": freeze.get("finalizedAtUtc"),
        "members": records,
        "exclusions": {
            "notTraversed": [
                f"{STUDY}/actors/** (not read)",
                f"{STUDY}/traces/**",
                f"{STUDY}/dispatch.jsonl",
            ],
            "filteredCounts": dict(sorted(excluded.items())),
            "policy": "See preparation/README.md for categorized scope and omitted artifacts.",
        },
    }
    inner_bytes = (json.dumps(inner, indent=2, sort_keys=True) + "\n").encode("utf-8")
    all_items = dict(items)
    all_items[INNER_MANIFEST] = (None, inner_bytes, "archive-member-manifest")
    all_records = [record_for(name, all_items[name]) for name in sorted(all_items)]

    OUT.mkdir(parents=True, exist_ok=True)
    tmp_archive = ARCHIVE.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp_archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for name in sorted(all_items):
            path, data, _ = all_items[name]
            raw = read_member(path, data)
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            zf.writestr(info, raw)
    os.replace(tmp_archive, ARCHIVE)

    with zipfile.ZipFile(ARCHIVE, "r") as zf:
        names = zf.namelist()
        if len(names) != len(set(names)) or set(names) != set(all_items):
            raise RuntimeError("archive member set differs from the planned selection")
        for row in all_records:
            raw = zf.read(row["path"])
            if len(raw) != row["bytes"] or sha256(raw) != row["sha256"]:
                raise RuntimeError(f"archive member verification failed: {row['path']}")
        if json.loads(zf.read(INNER_MANIFEST)) != inner:
            raise RuntimeError("embedded member manifest does not match the generated inventory")

    # Recheck every source after packaging to detect concurrent edits.
    changed: list[str] = []
    for row in records:
        path, data, _ = items[row["path"]]
        current = read_member(path, data)
        if len(current) != row["bytes"] or sha256(current) != row["sha256"]:
            changed.append(row["path"])
    if changed:
        raise RuntimeError("source changed during packaging: " + ", ".join(changed[:10]))

    sidecar = {
        **inner,
        "archive": {
            "path": ARCHIVE.relative_to(REPO).as_posix(),
            "bytes": ARCHIVE.stat().st_size,
            "sha256": sha256(ARCHIVE.read_bytes()),
        },
        "archiveMemberCount": len(all_records),
        "verified": True,
        "sourceRecheck": "unchanged",
        "members": all_records,
    }
    SIDECAR.write_text(json.dumps(sidecar, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    # Final sidecar-to-archive cross-check.
    with zipfile.ZipFile(ARCHIVE, "r") as zf:
        if set(zf.namelist()) != {row["path"] for row in all_records}:
            raise RuntimeError("sidecar member set mismatch")
        for row in sidecar["members"]:
            raw = zf.read(row["path"])
            if len(raw) != row["bytes"] or sha256(raw) != row["sha256"]:
                raise RuntimeError(f"sidecar verification failed: {row['path']}")
    print(json.dumps({
        "archive": str(ARCHIVE),
        "manifest": str(SIDECAR),
        "sha256": sidecar["archive"]["sha256"],
        "members": len(all_records),
        "bytes": sidecar["archive"]["bytes"],
        "verified": sidecar["verified"],
        "excludedCounts": sidecar["exclusions"]["filteredCounts"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Scheduled renewal comparison preflight evidence

This archive contains preparation evidence only. It has no participant actor
source, actor outputs, dispatch records, or active traces. The final freeze is
included with its clear preflight review; participants were not dispatched at
the time that freeze was created.

Included material covers both baseline source arms; fresh CLI/business/broker
build and preflight receipts; pinned runtime metadata; final AgentLang and F#
control roots and the producer/run logs; actual type-gate probes; the finalized
candidate, supplement, freeze and review; failed/superseded preflight and
control attempts; and the tracked 226 experiment source.

The five final AgentLang control roots each appear once with their manifest and
object store. Scoring `project-copy` trees, preflight baseline clones, and
compiled scorer artifacts are omitted. Runtime binaries are omitted; their
sizes and SHA-256 pins are recorded in the freeze/setup inputs and the generated
`preparation/runtime-inventory.json`. The `.deps.json` and `.runtimeconfig.json`
metadata files are included.

Exclusions: `.agentlang/scheduled-batch-226/actors/**` was not traversed or
read; the active `.agentlang/scheduled-batch-226/traces/**` directory and
`dispatch.jsonl` were excluded. Completed preparation `trace.jsonl` receipts
under root preflight attempts are included. `bin/`,
`obj/`, scratch/temp trees, `project-copy/`, `scoring-copy/`, and compiled
`artifacts/` were omitted; intermediate built control roots were omitted while
all available AgentLang producer logs and failed run receipts were retained.

One combined scorer attempt was stopped by Windows `WinError 3` while copying
to a 281-character destination path before case execution. Its completed type
gate probes are preserved in the successful shorter-path run; the successful
combined calibration is recorded in `oracle-work/language/c/`.

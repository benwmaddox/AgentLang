#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$repositoryRoot = 'D:\code\AgentLang'
$hostScriptPath = Join-Path $repositoryRoot 'scripts/Start-SubagentTrialHostV2.ps1'
$cliDll = Join-Path $repositoryRoot '.agentlang/scheduled-batch-226/runtime/conventional/AgentLang.Conventional.Cli.dll'
$projectPath = 'D:\code\AgentLang\.agentlang\scheduled-batch-226\actors\fsharp'
$tracePath = 'D:\code\AgentLang\.agentlang\scheduled-batch-226\root\preflight\fsharp\trace.jsonl'
$tempPath = Join-Path 'D:\code\AgentLang\.agentlang\scheduled-batch-226\root\scratch' 'temp'
$tmpPath = Join-Path 'D:\code\AgentLang\.agentlang\scheduled-batch-226\root\scratch' 'tmp'
[IO.Directory]::CreateDirectory($tempPath) | Out-Null
[IO.Directory]::CreateDirectory($tmpPath) | Out-Null
$env:MSBuildEnableWorkloadResolver = 'false'
$env:TEMP = $tempPath
$env:TMP = $tmpPath
$hostArguments = @{
    CliDll = $cliDll
    ProjectPath = $projectPath
    TracePath = $tracePath
    AllowedOperations = @('inspect', 'read', 'search', 'patch', 'replace', 'validate')
    Profile = 'conventional'
    Capabilities = @()
    ClockValue = '2000-01-01T00:00:00Z'
    MaxRequestBytes = 262144
    MaxResponseBytes = 524288
    ExchangeTimeoutMilliseconds = 120000
    MaxExchanges = 100
}
$hostArguments.Add('AdditionalCliArguments', @('--validation-project', 'SubscriptionBatch.Conventional.fsproj', '--max-requests', '100'))
& $hostScriptPath @hostArguments

# Launch details

From the repository root, run: pwsh -NoProfile -ExecutionPolicy Bypass -File .agentlang/scheduled-batch-226/launchers/retained.ps1

Assigned project path: .agentlang/scheduled-batch-226/actors/retained

# Common participant bootstrap

The human authorizes edits only to your assigned isolated trial project and
local validation through the supplied broker. Read only your assigned packet
and project. Launch the exact command in that packet once; keep its operation
list, limits, and project path unchanged. Use only that broker for project
discovery, edits, and validation. Do not inspect sibling projects, reports,
controls, graders, or other agents. Do not use web tools or other agents. Run
one session, at most 100 exchanges.

Poll the same live handle after an observation timeout. Do not restart for
silence, repeat an uncertain mutation, or kill the process to finish. When
finished, send `{"op":"host.close"}` and observe terminal status. This is a
host transport command outside the runtime operation list. If closure fails,
report the failure and preserve the session and trace. In your final response,
report changes, validation, and unresolved failures.

# AgentLang interface

Allowed operations:
`help,words,source,tests,define,test,test-all,commit,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort`.

Use Flow/2 and include `frontend:"flow"` and `syntaxVersion:2` on `define` and
`eval`. Keep new definitions library-qualified. Record changes must be staged
and published with their tests in the same live session. Do not edit runtime
storage files directly. No external effects are granted.

Use only this assigned project through the AgentLang broker. Do not edit runtime storage files directly.

# Scheduled renewal batch

Add one new API to the assigned project:

- AgentLang: define `ScheduledSubscriptionRenewal` with `renewal:
  SubscriptionRenewal` and `at: Instant`, then add
  `subscription.renew-scheduled-batch(Store, List<ScheduledSubscriptionRenewal>)`.
- F#: define the corresponding record with `Renewal: SubscriptionRenewal` and
  `At: Instant`, then add `Subscription.renewScheduledBatch`.

The result is a complete `Store` on success or the exact existing business
error on failure. Process items in the order supplied. Use each item's `at` for
that item's renewal. Stop at the first error. Do not return partial Store state
as success. An empty list succeeds with the entire input Store. Preserve
complete Store contents, unrelated entities and state, and the caller's input.

Keep every existing definition, test, example, fixture, and expected result
unchanged. Make additive changes only. In F#, edit only `Operations.fs` and
`SelfTests.fs`; add regression tests for per-item instants, input ordering,
first-error behavior, failure after a successful prefix, complete Store
preservation, and empty input. Keep the model pure: do not add I/O, packages,
providers, mutable global state, or project changes.

#!/usr/bin/env python3
"""Seal report-257 markup-parity evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
A = REPO / ".agentlang"
P256 = A / "campfire-native-profile-256"
HERE = A / "campfire-native-markup-257"
OUT = REPO / "reports" / "evidence" / "257-native-campfire-message-markup"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|config\.json$|secret|private-request|private-measure|\.env$)")
COOKIE = re.compile(rb"(?im)(_campfire_session|session_token)=[A-Za-z0-9%+/=_-]{16,}|^\s*cookie\s*:")
BUILDS = ["build-trusted-generated-20261013T104437427Z-e7617fb18f1f4da88b1891babfd76d20",
          "build-trusted-generated-20261013T104256913Z-e51cccb9aae24ee09cec770bea70942a"]
GATE = A / "campfire-native-room-read-252" / "test-runs" / "20261013T104002202Z-3c2a57d523dc461a9a93d6cd09d842da"
HTTP_TESTS = A / "campfire-logout-245" / "http-tests" / "runs" / "20261013T103451550Z-dc74c0f0e3b24de0b0c655c0cc484c5e"
SOURCES = ["applications/campfire/Http/ResponseRenderer.fs", "applications/campfire/Native/http/campfire_http_renderer.c",
           "tests/AgentLang.Campfire.Http.Tests/Program.fs", "scripts/Build-CampfireNativeHttp.ps1"]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect() -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    for d in sorted((HERE / "validation").iterdir()):
        for f in sorted(d.iterdir()):
            items.append((f, f"validation/{d.name}/{f.name}"))
    for d in sorted((P256 / "runs").glob("markup257-*")):
        for f in sorted(p for p in d.iterdir() if p.is_file()):
            items.append((f, f"runs/{d.name}/{f.name}"))
    for d in sorted((P256 / "http-validation").glob("markup257-*")):
        for f in sorted(d.iterdir()):
            items.append((f, f"http-validation/{d.name}/{f.name}"))
    for b in BUILDS:
        root = P256 / "http-host" / b
        for rel in ("http_host_pins.h", "source-pins.json", "O0/build-receipt.json", "O2/build-receipt.json",
                    "O0/native-imports.txt", "O2/native-imports.txt"):
            items.append((root / rel, f"builds/{b}/{rel}"))
    for name in ("test-receipt.json", "test-source-freeze.json", "test-run.log"):
        items.append((GATE / name, f"room-read-gate/{name}"))
    items.append((HTTP_TESTS / "receipt.json", "http-tests/receipt.json"))
    items.append((HERE / "reference-build.log", "reference/reference-build.log"))
    for name in ("Validate-Markup.ps1", "seal_257.py"):
        items.append((HERE / name, f"tools/{name}"))
    for rel in SOURCES:
        items.append((REPO / rel, f"sources/{rel}"))
    return items


def main() -> int:
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries = []
    blobs = {}
    for path, arc in collect():
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) or BANNED.search(arc):
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        if COOKIE.search(data):
            raise SystemExit(f"refused possible credential content: {arc}")
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "campfire-native-markup-evidence-v1", "report": "257", "entries": entries,
                            "excluded": ["fixture databases and WAL/SHM", "secrets and cookies", "request configs"]}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "257-native-campfire-message-markup-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
        if names != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

#requires -Version 7.0
# Report-257 markup parity: one native host (13773) + rebuilt interpreted reference (13774).
# Native starts first (its pre-run refresh updates both fixture DBs); the reference starts after.
param(
  [Parameter(Mandatory)][ValidateSet('O0','O2')][string]$Optimization,
  [Parameter(Mandatory)][string]$BuildRoot,
  [ValidatePattern('^[a-z0-9]{1,8}$')][string]$Attempt = 'a'
)
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
$p256 = Join-Path $repo '.agentlang/campfire-native-profile-256'
$root = Join-Path $repo '.agentlang/campfire-native-markup-257'
$fixture = Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke'
$runName = "markup257-off-$($Optimization.ToLowerInvariant())-$Attempt"
$out = Join-Path $root "validation/$runName"
if (Test-Path -LiteralPath $out) { throw 'Validation roots are immutable.' }
$null = New-Item -ItemType Directory -Path $out -Force
function Note([string]$t) { "$([DateTime]::UtcNow.ToString('O')) $t" | Add-Content -LiteralPath (Join-Path $out 'driver.log') -Encoding utf8NoBOM; Write-Output $t }

$busy = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 13773, 13774
$httpSys = netsh http show servicestate view=requestq | Select-String '127\.0\.0\.1:1377[34]'
if ($busy -or $httpSys) { throw 'A listener already owns 13773/13774.' }

$pwsh = (Get-Process -Id $PID).Path
$native = Start-Process -FilePath $pwsh -PassThru -NoNewWindow -RedirectStandardOutput (Join-Path $out 'run-host.out.log') -RedirectStandardError (Join-Path $out 'run-host.err.log') -ArgumentList @(
  '-NoProfile', '-File', (Join-Path $p256 'Run-Host.ps1'), '-BuildDirectory', (Join-Path $BuildRoot $Optimization),
  '-RunName', $runName, '-ExecutionProfile', 'Off', '-Optimization', $Optimization, '-Workers', '4')
$null = $native.Handle
$runRoot = Join-Path $p256 "runs/$runName"
$deadline = [DateTime]::UtcNow.AddSeconds(90)
while ([DateTime]::UtcNow -lt $deadline -and -not $native.HasExited) {
  $log = Join-Path $runRoot 'native-host.log'
  if ((Test-Path $log) -and (Select-String -LiteralPath $log -Pattern '^READY ' -Quiet)) { break }
  Start-Sleep -Milliseconds 250
}
$reference = $null
$referenceStopName = 'Local\CampfireNative257ReferenceStop'
try {
  if (-not (Select-String -LiteralPath (Join-Path $runRoot 'native-host.log') -Pattern '^READY ' -Quiet)) { throw 'Native host not READY.' }
  Note 'native ready'
  $refDll = Join-Path $root 'reference-artifacts/bin/ReferenceHost/release/ReferenceHost.dll'
  $reference = Start-Process -FilePath 'dotnet' -PassThru -NoNewWindow -RedirectStandardOutput (Join-Path $out 'reference.out.log') -RedirectStandardError (Join-Path $out 'reference.err.log') -ArgumentList @(
    $refDll, '--db', (Join-Path $fixture 'reference.sqlite'), '--secret-file', (Join-Path $fixture 'synthetic-secret.txt'),
    '--project', (Join-Path $p256 'reference-project'), '--source', (Join-Path $repo 'applications/campfire'),
    '--port', '13774', '--stop-event', $referenceStopName)
  $null = $reference.Handle
  $deadline = [DateTime]::UtcNow.AddSeconds(90)
  while ([DateTime]::UtcNow -lt $deadline -and -not $reference.HasExited) {
    if (Select-String -LiteralPath (Join-Path $out 'reference.out.log') -Pattern '"status":"READY"' -Quiet) { break }
    Start-Sleep -Milliseconds 250
  }
  if (-not (Select-String -LiteralPath (Join-Path $out 'reference.out.log') -Pattern '"status":"READY"' -Quiet)) { throw 'Reference host not READY.' }
  Note 'reference ready'

  # Byte-for-byte room body parity, hashed without storing the body or cookie.
  $request = Get-Content -LiteralPath (Join-Path $fixture 'private-request.json') -Raw | ConvertFrom-Json
  $client = [Net.Http.HttpClient]::new()
  $hashes = @{}
  foreach ($port in 13773, 13774) {
    $message = [Net.Http.HttpRequestMessage]::new('GET', ($request.Uri -replace ':13773/', ":$port/"))
    [void]$message.Headers.TryAddWithoutValidation('Cookie', $request.Cookie)
    [void]$message.Headers.TryAddWithoutValidation('User-Agent', $request.UserAgent)
    $response = $client.Send($message)
    $bytes = $response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
    $text = [Text.Encoding]::UTF8.GetString($bytes)
    $hashes[$port] = [ordered]@{
      status = [int]$response.StatusCode; bytes = $bytes.Length
      sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
      dataMessageIds = ([regex]::Matches($text, '<div\b[^>]*\sdata-message-id="(\d+)"[^>]*>')).Count
      presentations = ([regex]::Matches($text, '<div id="presentation_message_\d+"')).Count
    }
  }
  $client.Dispose()
  $parity = [ordered]@{ native = $hashes[13773]; reference = $hashes[13774]; identical = ($hashes[13773].sha256 -eq $hashes[13774].sha256) }
  $parity | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $out 'room-body-parity.json') -Encoding utf8NoBOM
  if (-not $parity.identical -or $hashes[13773].status -ne 200 -or $hashes[13773].dataMessageIds -ne 40 -or $hashes[13773].presentations -ne 40) { throw 'Room body parity failed.' }
  Note "room body identical sha=$($hashes[13773].sha256) bytes=$($hashes[13773].bytes)"

  & $pwsh -NoProfile -File (Join-Path $p256 'Validate-Http.ps1') -RunName $runName -ExecutionProfile Off -Optimization $Optimization
  if ($LASTEXITCODE -ne 0) { throw 'Validate-Http failed.' }
  Note 'validate-http passed'
} finally {
  foreach ($name in 'Local\CampfireNative256Stop', $referenceStopName) {
    try { $e = [Threading.EventWaitHandle]::OpenExisting($name); [void]$e.Set(); $e.Dispose(); Note "signalled $name" } catch { Note "no event $name" }
  }
  if ($reference -and -not $reference.WaitForExit(60000)) { Note 'reference did not exit' } elseif ($reference) { $reference.WaitForExit(); Note "reference exit=$($reference.ExitCode)" }
  if (-not $native.WaitForExit(120000)) { Note 'native Run-Host did not exit' } else { $native.WaitForExit(); Note "run-host exit=$($native.ExitCode)" }
}
Get-Content -LiteralPath (Join-Path $out 'run-host.out.log') | Select-Object -Last 2

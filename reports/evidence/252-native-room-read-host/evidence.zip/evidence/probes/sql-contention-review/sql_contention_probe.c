#define main pure_vectors_profile_main
#include "../cookie-fix/pure-vectors-actual-profile.c"
#undef main

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "room_read_adapter.h"
#include "room_read_sqlite_subset.h"

static const uint8_t probe_database_path[] =
    ".agentlang\\campfire-native-room-read-252\\sql-contention-review\\"
    "native.sqlite";
static const char session_token[] = "native-room-read-session-token";

static al_campfire_room_read_context_v1 provider_context;
static uint8_t refresh_value[40u];

static int execute_transaction_sql(sqlite3 *database, const char *sql) {
  sqlite3_stmt *statement = NULL;
  const char *tail = NULL;
  int rc = sqlite3_prepare_v2(database, sql, -1, &statement, &tail);
  int step_rc;
  int finalize_rc;
  if (rc != SQLITE_OK || statement == NULL || tail == NULL || *tail != '\0') {
    if (statement != NULL)
      (void)sqlite3_finalize(statement);
    return 0;
  }
  step_rc = sqlite3_step(statement);
  finalize_rc = sqlite3_finalize(statement);
  return step_rc == SQLITE_DONE && finalize_rc == SQLITE_OK;
}

static int call_session_find(uint8_t output[8192u], uint32_t *out_extent) {
  const uint32_t string_extent = pack_string(first_string, session_token);
  inputs[0] =
      (al_campfire_room_read_input){first_string, string_extent, 33u};
  memset(output, 0xa5, 8192u);
  return al_host_campfire_room_read_v1(
             &provider_context, AL_CAMPFIRE_SESSION_FIND, &test_layout, inputs,
             1u, 54u, output, 8192u, out_extent) == 0;
}

static void prepare_refresh_input(void) {
  memset(refresh_value, 0, sizeof(refresh_value));
  pack_i64(refresh_value, 70);
  pack_i64(refresh_value + 8u, INT64_C(1767268800000000));
  pack_i64(refresh_value + 16u, INT64_C(1767269700123456));
  /* Both optional strings are None, each encoded as an eight-byte tag. */
  pack_i64(refresh_value + 24u, 1);
  pack_i64(refresh_value + 32u, 1);
  inputs[0] = (al_campfire_room_read_input){refresh_value, 40u, 28u};
}

static int call_refresh(uint8_t output[8192u], uint32_t *out_extent) {
  prepare_refresh_input();
  memset(output, 0xa5, 8192u);
  return al_host_campfire_room_read_v1(
             &provider_context, AL_CAMPFIRE_SESSION_REFRESH, &test_layout,
             inputs, 1u, 56u, output, 8192u, out_extent) == 0;
}

static int verify_updated_timestamp(sqlite3 *database) {
  static const uint16_t expected[] = {
      '2', '0', '2', '6', '-', '0', '1', '-', '0', '1', ' ', '1', '2',
      ':', '1', '5', ':', '0', '0', '.', '1', '2', '3', '4', '5', '6'};
  sqlite3_stmt *statement = NULL;
  const char *tail = NULL;
  const uint16_t *actual;
  int rc;
  int bytes;
  uint32_t index;
  rc = sqlite3_prepare_v2(
      database, "SELECT last_active_at FROM sessions WHERE id = 70", -1,
      &statement, &tail);
  if (rc != SQLITE_OK || statement == NULL || tail == NULL || *tail != '\0') {
    if (statement != NULL)
      (void)sqlite3_finalize(statement);
    return 0;
  }
  rc = sqlite3_step(statement);
  actual = (const uint16_t *)sqlite3_column_text16(statement, 0);
  bytes = sqlite3_column_bytes16(statement, 0);
  if (rc != SQLITE_ROW || actual == NULL ||
      bytes != (int)sizeof(expected)) {
    (void)sqlite3_finalize(statement);
    return 0;
  }
  for (index = 0u; index < sizeof(expected) / sizeof(expected[0]); ++index) {
    if (actual[index] != expected[index]) {
      (void)sqlite3_finalize(statement);
      return 0;
    }
  }
  rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    (void)sqlite3_finalize(statement);
    return 0;
  }
  return sqlite3_finalize(statement) == SQLITE_OK;
}

int main(void) {
  sqlite3 *writer = NULL;
  uint8_t output[8192u];
  uint32_t output_extent = UINT32_MAX;
  uint32_t db_error_tag = UINT32_MAX;
  uint32_t path_bytes = (uint32_t)(sizeof(probe_database_path) - 1u);
  uint64_t started_ms;
  uint64_t blocked_ms = 0u;
  int lookup_during_lock_ok = 0;
  int busy_error_ok = 0;
  int callback_reuse_ok = 0;
  int rollback_ok = 0;
  int retry_ok = 0;
  int verify_timestamp_ok = 0;
  int provider_initialized = 0;
  int final_status = 1;

  if (sqlite3_libversion_number() != 3053003 || test_layout.type_count != 60u ||
      test_layout.field_count != 123u ||
      al_campfire_room_read_provision_wal_v1(
          probe_database_path, path_bytes, &db_error_tag) != 0) {
    puts("probe setup failed: profile or WAL provisioning");
    return 1;
  }
  memset(&provider_context, 0, sizeof(provider_context));
  if (al_campfire_room_read_context_init_v1(
          &provider_context, probe_database_path, path_bytes, NULL,
          &db_error_tag) != 0) {
    printf("probe setup failed: provider init tag=%u\n", db_error_tag);
    return 1;
  }
  provider_initialized = 1;
  if (sqlite3_open_v2((const char *)probe_database_path, &writer,
                      SQLITE_OPEN_READWRITE | SQLITE_OPEN_NOMUTEX |
                          SQLITE_OPEN_PRIVATECACHE,
                      NULL) != SQLITE_OK ||
      writer == NULL) {
    puts("probe setup failed: second connection open");
    goto cleanup;
  }
  if (!execute_transaction_sql(writer, "BEGIN IMMEDIATE") ||
      sqlite3_get_autocommit(writer) != 0) {
    puts("probe setup failed: second connection did not acquire writer lock");
    goto cleanup;
  }

  output_extent = UINT32_MAX;
  lookup_during_lock_ok =
      call_session_find(output, &output_extent) && output_extent > 16u &&
      read_u64(output) == 0u && read_u64(output + 8u) == 0u &&
      read_u64(output + 16u) == 70u && provider_context.active == 0u &&
      sqlite3_get_autocommit((sqlite3 *)provider_context.opaque_db) == 1;

  started_ms = GetTickCount64();
  output_extent = UINT32_MAX;
  busy_error_ok = call_refresh(output, &output_extent) &&
                  output_extent == 16u && read_u64(output) == 1u &&
                  read_u64(output + 8u) ==
                      AL_CAMPFIRE_DB_ERROR_UNAVAILABLE &&
                  provider_context.active == 0u &&
                  sqlite3_get_autocommit(
                      (sqlite3 *)provider_context.opaque_db) == 1;
  blocked_ms = GetTickCount64() - started_ms;

  output_extent = UINT32_MAX;
  callback_reuse_ok =
      call_session_find(output, &output_extent) && output_extent > 16u &&
      read_u64(output) == 0u && read_u64(output + 8u) == 0u &&
      read_u64(output + 16u) == 70u && provider_context.active == 0u &&
      sqlite3_get_autocommit((sqlite3 *)provider_context.opaque_db) == 1;

  rollback_ok = execute_transaction_sql(writer, "ROLLBACK") &&
                sqlite3_get_autocommit(writer) == 1;
  output_extent = UINT32_MAX;
  retry_ok = rollback_ok && call_refresh(output, &output_extent) &&
             output_extent > 16u && read_u64(output) == 0u &&
             read_u64(output + 8u) == 70u && provider_context.active == 0u &&
             sqlite3_get_autocommit(
                 (sqlite3 *)provider_context.opaque_db) == 1;
  verify_timestamp_ok = retry_ok && verify_updated_timestamp(writer);

  printf("sqlite=%d lock_lookup=%s busy_error=%s blocked_ms=%llu "
         "callback_reuse=%s external_rollback=%s refresh_retry=%s "
         "timestamp=%s\n",
         sqlite3_libversion_number(), lookup_during_lock_ok ? "passed" : "failed",
         busy_error_ok ? "typed-unavailable" : "failed",
         (unsigned long long)blocked_ms,
         callback_reuse_ok ? "passed" : "failed",
         rollback_ok ? "passed" : "failed", retry_ok ? "passed" : "failed",
         verify_timestamp_ok ? "passed" : "failed");
  final_status = lookup_during_lock_ok && busy_error_ok &&
                         blocked_ms >= 4500u && blocked_ms <= 15000u &&
                         callback_reuse_ok && rollback_ok && retry_ok &&
                         verify_timestamp_ok
                     ? 0
                     : 1;

cleanup:
  if (writer != NULL) {
    if (sqlite3_get_autocommit(writer) == 0)
      (void)execute_transaction_sql(writer, "ROLLBACK");
    (void)sqlite3_close(writer);
  }
  if (provider_initialized &&
      al_campfire_room_read_context_destroy_v1(&provider_context) != 0)
    final_status = 1;
  return final_status;
}

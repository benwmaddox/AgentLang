# Campfire SQL contention and reuse probe

Run date: 2026-10-12. Working directory: `D:\code\AgentLang`.

This standalone probe calls `al_host_campfire_room_read_v1` directly with the current provider sources and the retained compiler profile. A separate SQLite connection holds `BEGIN IMMEDIATE`; token lookup remains available in WAL mode, refresh returns a typed `Unavailable` after the provider's busy timeout, and the same provider context works after rollback. The retry updates `sessions.id=70` to `2026-01-01 12:15:00.123456`.

## Pins

- SQLite runtime: `sqlite3_libversion_number() == 3053003` (3.53.3). Runtime DLL SHA-256: `B7385D722C83FB52142A00477A726723745916D22A555711EE89834C1111FB2E`; import library SHA-256: `36E52C6B1A8A80554CA6053115E6E8F4AC8985D999EF5E69BB94F06324241C9A`.
- Provider source `room_read_adapter.c`: `42F88CDA5B944C3CC1F990B6C74587797C52C20ACF97DC234939AE6706D42F2E`; header: `16406F85B511CAA13AA61D35446AE83B7B822FC981669864C3FEE6ADD5EAFC97`.
- Pure source/header: `0C7482253A2A27E8F58BFA6E17D5F7BFC63BB1E375478CCB04C2577CA1A092CE` / `2A1FDB4D8AE84045FC4EFC629F456F95F5EA8001041A843F528E5B1B9F350879`.
- SQL ABI header: `3DE0D23119786BACDFB0FD7D9754EEFA2E555790B273257001871D45C753BFEC`; SQLite subset header: `38DC810EE2974C82880164F7540294CDAE05782B09C48DB8D0876CCBDC459091`.
- Owning runtime source/header: `ED50BDB3B5C9D6892370FA22631EA15F50C743A840BB86E616D47AC1813E4BB2` / `853ED9692E46DA0624FFD414272774BA3CDA239920A03473F98CC0453B3DC2C0`.
- Compiler layout source `cookie-fix/pure-vectors-actual-profile.c`: `6E974AEE3C6DB80CA11C9AE26049383440125E3670D6187836CB5D625ECFF110`; profile: 60 types, 123 fields.
- Fixture source `test-runs/20261012T204759973Z-eed70b04ffc744be9c277176a258b39b/test-fixture/native.sqlite`: `5F8CF2561FD18BD74C89C2853F7E74FA04C3195FA04708AD36A53564B19AA3C5`. The private copy was reset from this source immediately before the recorded run.
- Probe source `sql_contention_probe.c`: `618EF4D6E05643A5845CA5DD4FEAEC968CA2A3059AFE4D44197CFCD4D31D1C1D`.

## Commands

The probe was built with clang-cl 19.1.5 for `x86_64-pc-windows-msvc`, using the retained O0 SQLite import library and its matching runtime DLL:

```powershell
$clangcl = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang-cl.exe'
$probeDir = (Resolve-Path '.agentlang/campfire-native-room-read-252/sql-contention-review').Path
$deps = (Resolve-Path '.agentlang/campfire-native-room-read-252/test-runs/20261012T204759973Z-eed70b04ffc744be9c277176a258b39b/test-artifacts/O0/native-dependencies').Path
$dll = (Resolve-Path '.agentlang/campfire-native-room-read-252/test-runs/20261012T204759973Z-eed70b04ffc744be9c277176a258b39b/test-artifacts/O0/e_sqlite3.dll').Path
& $clangcl /nologo /TC /std:c11 /W4 /Od --target=x86_64-pc-windows-msvc /I src/AgentLang.Llvm/native /I applications/campfire/Native /I .agentlang/campfire-native-room-read-252/sql-contention-review /Fo:$probeDir\ /Fe:$probeDir\sql_contention_probe.exe .agentlang/campfire-native-room-read-252/sql-contention-review/sql_contention_probe.c applications/campfire/Native/room_read_adapter.c applications/campfire/Native/room_read_pure.c src/AgentLang.Llvm/native/owning_stack_runtime.c /link /LIBPATH:$deps bcrypt.lib e_sqlite3.lib kernel32.lib
Copy-Item -LiteralPath $dll -Destination $probeDir -Force
Copy-Item -LiteralPath '.agentlang/campfire-native-room-read-252/test-runs/20261012T204759973Z-eed70b04ffc744be9c277176a258b39b/test-fixture/native.sqlite' -Destination (Join-Path $probeDir 'native.sqlite') -Force
& (Join-Path $probeDir 'sql_contention_probe.exe')
```

Strict syntax check:

```powershell
& $clangcl /nologo /TC /std:c11 /W4 --target=x86_64-pc-windows-msvc /clang:-fsyntax-only /I src/AgentLang.Llvm/native /I applications/campfire/Native .agentlang/campfire-native-room-read-252/sql-contention-review/sql_contention_probe.c
```

Recorded output (`probe-run.log`):

```text
sqlite=3053003 lock_lookup=passed busy_error=typed-unavailable blocked_ms=5547 callback_reuse=passed external_rollback=passed refresh_retry=passed timestamp=passed
```

The callback probe covers the direct provider SQL path. It does not exercise the host's cross-module SQLite-handle settings/provisioning path, so it does not rule on the separately identified native-settings handle defect or explain the full verifier failure.
# Run4 compiler ABI and stack review

## Scope

Read-only review of test-runs/20261012T204759973Z-eed70b04ffc744be9c277176a258b39b. No production sources or generated artifacts were changed.

## Pins and replay evidence

- O0 native DLL: test-artifacts/O0/owning-stack-native-host.dll
- DLL SHA-256: 8d254588d6ab9caa85f135f6e423b8052feccfa78bf169dc0bc832f9b6c5d357
- LLVM IR SHA-256: 5f4b40b1e8abe93919f47e8e4aa59b0bfddb937527f60a41e94f6a8aa07318d7
- Source freeze: test-source-freeze.json says stable=true; compiler source pin is efa520eec75d369d9b5e07cc90506d80e61b9aeab64b17126a8b5d9fe0d8c6c0.
- The same O0 DLL was loaded by test-diagnostics/run4-o0-direct-replay/test-direct-replay.exe. Its replay-receipt.json reports stage 6, entryStatus=0, contextStatus=0, retainedCopyBytes=72, 123 trace events, and output prefix 2e010000 (302). This is a saved missing-cookie request; it establishes one standalone entry/replay path and does not exercise the contended refresh branch.

## Callback ABI inspection

owning-stack-native-host.ll call sites include the provider context, operation tag, layout, input descriptor pointer/count, output type index, output pointer/capacity, and output extent pointer (nine ABI parameters). For example, LLVM line 30149 calls tag 3 (campfire.sessions.refresh-before) with all nine arguments.

The forced native-runtime/campfire_room_read_host_abi.h prototype and adapter definition in native-runtime/campfire_room_read_host_adapter.c match that call shape. The header has compile-time checks that al_campfire_room_read_input is 16 bytes with extent_bytes at offset 8 and type_index at offset 12. The adapter and LLVM objects compiled and linked in the retained run. This bounds callback arity and input-structure layout as suspects; it does not prove every runtime pointer belongs to the correct SQLite module instance.

## Stack inspection

Relevant generated rows are in test-artifacts/O0/agentlang-native.su; all are static. The largest generated frame is agentlang_word_0000 at 17,400 bytes. The reachable generated call graph has 19 functions and no cycles in this IR. Its largest direct export-to-generated path is:

agentlang_owning_execute_with_host_context (328) -> agentlang_entry_frame (200) -> agentlang_word_0007 (7,272) -> agentlang_word_0006 (1,736) -> agentlang_word_0000 (17,400) -> agentlang_word_0015 (600) = 27,536 bytes.

The adapter .su rows top out at messages_last_page (984 bytes), and the arena-runtime rows top out at al_owning_validate_type_graph (8,280 bytes). The compiler's native stack screen caps each static frame at 64 KiB and rejects dynamic rows. Its source explicitly says it does not bound cumulative call-chain stack. These measurements rule out an oversized generated frame and bound the generated known call chain; they do not bound SQLite's internal stack or all cumulative paths through external DLL code.

Commands used to inspect pins and stack rows:

Get-FileHash <run>\test-artifacts\O0\owning-stack-native-host.dll,<run>\test-artifacts\O0\owning-stack-native-host.ll
Get-Content <run>\test-artifacts\O0\agentlang-native.su
Get-Content <run>\test-artifacts\O0\agentlang-native-host-adapter.su
Get-Content <run>\test-artifacts\O0\agentlang-arena-runtime.su
rg -n 'call i32 @al_host_campfire_room_read_v1' <run>\test-artifacts\O0\owning-stack-native-host.ll

## Current limit of the conclusion

This review found no compiler callback-arity/layout mismatch or oversized generated stack frame in the pinned O0 artifact. It does not establish the exact cause of 0xC0000409. Root's separate module-instance review found the native import bound to the package SQLite instance while the test settings helper loads the copied artifact SQLite module and passes it the native context's database pointer; that is a confirmed cross-module ownership mismatch in the settings probe and is more concrete than the compiler ABI/stack leads. The SQL agent's standalone contention/recovery probe passed token lookup under BEGIN IMMEDIATE, typed busy error, autocommit cleanup, callback reuse, rollback, and retry. A fresh phase-marked integration run is still needed to tie the fail-fast to a precise test phase.
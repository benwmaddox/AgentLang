#define main pure_vectors_profile_main
#include "../cookie-fix/pure-vectors-actual-profile.c"
#undef main

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "room_read_adapter.h"
#include "room_read_sqlite_subset.h"

#include <stdio.h>
#include <string.h>

#define SQLITE_OK 0
#define SQLITE_DENY 1
#define SQLITE_TRANSACTION 22

typedef int (*sqlite3_exec_callback)(void *, int, char **, char **);
typedef int (*sqlite3_authorizer_callback)(void *, int, const char *,
                                           const char *, const char *,
                                           const char *);

__declspec(dllimport) int sqlite3_exec(sqlite3 *database, const char *sql,
                                       sqlite3_exec_callback callback,
                                       void *callback_context,
                                       char **error_message);
__declspec(dllimport) int sqlite3_set_authorizer(
    sqlite3 *database, sqlite3_authorizer_callback callback,
    void *callback_context);

static const uint8_t probe_database_path[] =
    ".agentlang\\campfire-native-room-read-252\\sqlite-cleanup-probe\\"
    "fixture\\native.sqlite";

__declspec(align(64)) static uint8_t cleanup_probe_pure_context[32768u];
static al_campfire_room_read_context_v1 poison_context;
static al_campfire_room_read_context_v1 reusable_context;
typedef struct cleanup_probe_authorizer_state {
  uint32_t rollback_denials;
} cleanup_probe_authorizer_state;
static cleanup_probe_authorizer_state authorizer_state;
static uint32_t poisoned_active_after_call;
static int poisoned_autocommit_after_call;

static int record_and_deny_rollback(void *opaque, int action,
                                    const char *argument1,
                                    const char *argument2,
                                    const char *database_name,
                                    const char *trigger_name) {
  (void)argument2;
  (void)database_name;
  (void)trigger_name;
  if (action == SQLITE_TRANSACTION && argument1 != NULL &&
      strcmp(argument1, "ROLLBACK") == 0) {
    cleanup_probe_authorizer_state *state =
        (cleanup_probe_authorizer_state *)opaque;
    ++state->rollback_denials;
    return SQLITE_DENY;
  }
  return SQLITE_OK;
}

static void prepare_browser_call(void) {
  const uint32_t first_extent = pack_string(first_string, "3.10.1");
  const uint32_t second_extent = pack_string(second_string, "3.10.1beta");
  inputs[0] = (al_campfire_room_read_input){first_string, first_extent,
                                             STRING_TYPE};
  inputs[1] = (al_campfire_room_read_input){second_string, second_extent,
                                             STRING_TYPE};
}

static int initialize_context(al_campfire_room_read_context_v1 *context,
                              uint32_t path_bytes) {
  uint32_t error_tag = UINT32_MAX;
  memset(context, 0, sizeof(*context));
  return al_campfire_room_read_context_init_v1(
             context, probe_database_path, path_bytes,
             cleanup_probe_pure_context, &error_tag) == 0;
}

static int run_poisoning_path(uint32_t path_bytes) {
  uint32_t output_extent = UINT32_MAX;
  uint32_t rejected_extent = UINT32_MAX;
  uint32_t denials_after_first;
  int first_status;
  int rejected_status;
  int destroy_status = 1;
  int assertions_passed = 0;
  sqlite3 *database;

  if (!initialize_context(&poison_context, path_bytes))
    return 0;
  database = (sqlite3 *)poison_context.opaque_db;
  if (sqlite3_exec(database, "BEGIN IMMEDIATE", NULL, NULL, NULL) != SQLITE_OK ||
      sqlite3_get_autocommit(database) != 0)
    goto cleanup;
  authorizer_state.rollback_denials = 0u;
  if (sqlite3_set_authorizer(database, record_and_deny_rollback,
                             &authorizer_state) != SQLITE_OK)
    goto cleanup;

  prepare_browser_call();
  memset(output_value, 0xa5, sizeof(output_value));
  first_status = al_host_campfire_room_read_v1(
      &poison_context, AL_CAMPFIRE_BROWSER_VERSION, &test_layout, inputs, 2u,
      BOOL_TYPE, output_value, sizeof(output_value), &output_extent);
  denials_after_first = authorizer_state.rollback_denials;
  poisoned_active_after_call = poison_context.active;
  poisoned_autocommit_after_call = sqlite3_get_autocommit(database);
  rejected_status = al_host_campfire_room_read_v1(
      &poison_context, AL_CAMPFIRE_BROWSER_VERSION, &test_layout, inputs, 2u,
      BOOL_TYPE, output_value, sizeof(output_value), &rejected_extent);
  assertions_passed =
      first_status != 0 && output_extent == 0u && poison_context.active == 2u &&
      denials_after_first != 0u && rejected_status != 0 &&
      rejected_extent == 0u && authorizer_state.rollback_denials ==
                                    denials_after_first &&
      poisoned_autocommit_after_call == 0 &&
      sqlite3_get_autocommit(database) == 0;

cleanup:
  if (database != NULL)
    (void)sqlite3_set_authorizer(database, NULL, NULL);
  destroy_status = al_campfire_room_read_context_destroy_v1(&poison_context);
  return assertions_passed && destroy_status == 0;
}

static int run_reuse_path(uint32_t path_bytes) {
  uint32_t first_extent = UINT32_MAX;
  uint32_t second_extent = UINT32_MAX;
  int first_status;
  int second_status;
  int destroy_status = 1;
  int assertions_passed = 0;
  sqlite3 *database;

  if (!initialize_context(&reusable_context, path_bytes))
    return 0;
  database = (sqlite3 *)reusable_context.opaque_db;
  if (sqlite3_exec(database, "BEGIN IMMEDIATE", NULL, NULL, NULL) != SQLITE_OK ||
      sqlite3_get_autocommit(database) != 0)
    goto cleanup;

  prepare_browser_call();
  memset(output_value, 0xa5, sizeof(output_value));
  first_status = al_host_campfire_room_read_v1(
      &reusable_context, AL_CAMPFIRE_BROWSER_VERSION, &test_layout, inputs, 2u,
      BOOL_TYPE, output_value, sizeof(output_value), &first_extent);
  if (first_status == 0 || first_extent != 0u || reusable_context.active != 0u ||
      sqlite3_get_autocommit(database) != 1)
    goto cleanup;

  second_status = al_host_campfire_room_read_v1(
      &reusable_context, AL_CAMPFIRE_BROWSER_VERSION, &test_layout, inputs, 2u,
      BOOL_TYPE, output_value, sizeof(output_value), &second_extent);
  assertions_passed =
      second_status == 0 && second_extent == 8u &&
      read_u64(output_value) == 1u && reusable_context.active == 0u &&
      sqlite3_get_autocommit(database) == 1;

cleanup:
  destroy_status = al_campfire_room_read_context_destroy_v1(&reusable_context);
  return assertions_passed && destroy_status == 0;
}

int main(void) {
  const uint32_t path_bytes = (uint32_t)(sizeof(probe_database_path) - 1u);
  const int sqlite_version = sqlite3_libversion_number();
  uint32_t error_tag = UINT32_MAX;
  int poison_ok;
  int reuse_ok;

  if (sqlite_version != 3053003 || test_layout.type_count != 60u ||
      test_layout.field_count != 123u) {
    printf("setup=failed sqlite=%d types=%u fields=%u\n", sqlite_version,
           test_layout.type_count, test_layout.field_count);
    return 1;
  }
  if (al_campfire_room_read_provision_wal_v1(
          probe_database_path, path_bytes, &error_tag) != 0) {
    puts("fixture=failed");
    return 1;
  }
  if (al_campfire_pure_context_init_v1(
          cleanup_probe_pure_context, sizeof(cleanup_probe_pure_context),
          fixture_secret, (uint32_t)(sizeof(fixture_secret) - 1u)) != 0) {
    puts("pure_context=failed");
    return 1;
  }
  poison_ok = run_poisoning_path(path_bytes);
  reuse_ok = run_reuse_path(path_bytes);
  al_campfire_pure_context_destroy_v1(cleanup_probe_pure_context);

  printf("sqlite_version=%d rollback_denials=%u poisoned_active=%u "
         "poisoned_autocommit=%d poison_path=%s reuse_path=%s\n",
         sqlite_version, authorizer_state.rollback_denials,
         poisoned_active_after_call, poisoned_autocommit_after_call,
         poison_ok ? "passed" : "failed", reuse_ok ? "passed" : "failed");
  return poison_ok && reuse_ok ? 0 : 1;
}

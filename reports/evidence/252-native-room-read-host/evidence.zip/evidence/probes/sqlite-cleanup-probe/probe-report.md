# Native SQLite cleanup probe

This private probe exercises the real room-read adapter against the retained
60-type/123-field profile and SQLite 3.53.3. It uses a copy of the retained
`native.sqlite` fixture under this directory; that copy was made before
provisioning or opening it. The retained source fixture remains unchanged.

The probe calls `sqlite3_exec("BEGIN IMMEDIATE")` directly through
`native_context.opaque_db`, then calls the real browser-version operation. A
private-only authorizer denies `SQLITE_TRANSACTION` / `ROLLBACK` and otherwise
permits every action. The callback only increments a denial counter and
returns `SQLITE_DENY`; it does not modify SQLite state. Setting the authorizer
after context initialization expires the precompiled rollback statement, so
the measured denial occurs while SQLite reparses it in `sqlite3_step`.

## Results

The retained runtime output is:

```text
sqlite_version=3053003 rollback_denials=1 poisoned_active=2 poisoned_autocommit=0 poison_path=passed reuse_path=passed
exit_code=0
```

The poisoned path verifies that the adapter returns failure with output extent
zero, leaves `active` at 2 and autocommit disabled, and rejects a second call
without another authorizer denial. Removing the authorizer lets owner-thread
context destruction finish successfully.

The healthy path begins a transaction without an authorizer. Its first adapter
call returns failure with extent zero after cleanup restores autocommit and
releases `active` to zero. A second valid browser-version call then succeeds
with an 8-byte `true` result, and context destruction succeeds.

No application bootstrap or general SQL callback was used. The fixture copy
was provisioned for WAL and used only for `BEGIN IMMEDIATE` plus rollback; no
SQL, cookie, or database contents were printed.

## Build and checks

Compiler: Clang 19.1.5, `x86_64-pc-windows-msvc`; MSVC headers 14.44.35207;
Windows SDK 10.0.26100.0. The strict syntax check compiled the probe, adapter,
and pure provider with `-std=c11 -ffreestanding -fno-builtin -Wall -Wextra
-Werror -fsyntax-only`; it exited 0. The same flags compiled all three objects
separately, each with exit code 0, then Clang/LLD linked the private executable
with the pinned SQLite import library and a private import library containing
only `sqlite3_exec` and `sqlite3_set_authorizer`.

The executable imports `e_sqlite3.dll`, `bcrypt.dll`, and `KERNEL32.dll`.
Runtime version check requires `sqlite3_libversion_number() == 3053003`.
`sqlite_cleanup_imports.lib` exposes the two private-only SQLite imports.

## Source hashes

| File | SHA-256 |
| --- | --- |
| `applications/campfire/Native/room_read_adapter.c` | `42F88CDA5B944C3CC1F990B6C74587797C52C20ACF97DC234939AE6706D42F2E` |
| `applications/campfire/Native/room_read_pure.c` | `0C7482253A2A27E8F58BFA6E17D5F7BFC63BB1E375478CCB04C2577CA1A092CE` |
| `sqlite_cleanup_probe.c` | `DA454ECA9BCA031EAE09CB4E1299D0458455E7C766BB00AE5B124ED0FF57B141` |
| `e_sqlite3.dll` | `B7385D722C83FB52142A00477A726723745916D22A555711EE89834C1111FB2E` |
| retained fixture before copy | `7D918D99EC26A69AAFC60D0B1D7720BA0EDAB51D9C82B4BC957A7B7BEE286030` |
| private fixture copy before probe | `7D918D99EC26A69AAFC60D0B1D7720BA0EDAB51D9C82B4BC957A7B7BEE286030` |

The command logs are `strict-syntax.log`, `compile-objects.log`, `link.log`,
and `run.log`. All files created for this probe are confined to this private
directory.

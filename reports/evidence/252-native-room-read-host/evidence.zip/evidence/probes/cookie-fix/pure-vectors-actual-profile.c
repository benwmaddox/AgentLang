#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "room_read_pure.h"

static const uint8_t fixture_secret[] =
    "native-room-read-test-secret-not-production";
static const uint8_t cookie_service_fixture_secret[] =
    "5335c3b1ad35b4ad170c3413bd651ef3b6ed64e257261871a6de3f978cf3868ee417a927040935fb30b0f7debdedb34a2a403e9f34b16cf594c917c2ecd4a995";

static const char valid_cookie[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNWhkR2wyWlMxelpYTnphVzl1TFRReUlnPT0iLCJleHAiOiIyMDMwLTAxLTAxVDAwOjAwOjAwLjAwMFoiLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiJ9fQ==--65a1ad9fa46212b76594fd46b6dfee9b21a607b6";
static const char wrong_purpose_cookie[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNWhkR2wyWlMxelpYTnphVzl1TFRReUlnPT0iLCJleHAiOiIyMDMwLTAxLTAxVDAwOjAwOjAwLjAwMFoiLCJwdXIiOiJjb29raWUub3RoZXIifX0=--924bc9782cced19938f35a3455038bf6071003c1";
static const char expired_cookie[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNWhkR2wyWlMxelpYTnphVzl1TFRReUlnPT0iLCJleHAiOiIyMDIwLTAxLTAxVDAwOjAwOjAwLjAwMFoiLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiJ9fQ==--d5db2e2431a55152c47bc473d955184286714d99";
static const char offset_future_cookie[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNWhkR2wyWlMxelpYTnphVzl1TFRReUlnPT0iLCJleHAiOiIyMDIzLTExLTE1VDAwOjEzOjIwLjAwMDAwMSswMjowMCIsInB1ciI6ImNvb2tpZS5zZXNzaW9uX3Rva2VuIn19--2be53bfa65744ce447d306c43160e2b3753d50fa";
static const char equal_expiry_cookie[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNWhkR2wyWlMxelpYTnphVzl1TFRReUlnPT0iLCJleHAiOiIyMDIzLTExLTE0VDIyOjEzOjIwLjAwMDAwMFoiLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiJ9fQ==--adbec748ffedbff7d57e3b3e3b6652de4118fd7f";
static const char direct_cookie[] =
    "ImRpcmVjdC1sZWdhY3ktdG9rZW4i--38e32a9f859a634ea34b9a80f691d9782eef964f";
static const char cookie_service_golden[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltaGxiR3h2SUhkdmNteGtJZz09IiwiZXhwIjoiMjA0Ni0wMS0wMVQxMjowMDowMC4wMDBaIiwicHVyIjoiY29va2llLnNlc3Npb25fdG9rZW4ifX0=--39bc3535e5f45a95eb9b0e682f896d448c372571";
static const char cookie_service_no_purpose_null[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNXZjSFZ5Y0c5elpTST0iLCJleHAiOiIyMDI2LTAxLTAyVDEyOjAwOjAwLjAwMFoiLCJwdXIiOm51bGx9fQ==--ce674c4e2eae4763923a1a05d72f6b9fdcdf14fc";
static const char cookie_service_no_purpose_expired[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltNXZjSFZ5Y0c5elpTST0iLCJleHAiOiIyMDI1LTEyLTMxVDEyOjAwOjAwLjAwMFoiLCJwdXIiOm51bGx9fQ==--991b52e0442af6ca5302f80e6fd90b38060f536e";
static const char cookie_service_empty_purpose[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltZHZiR1F0Wlcxd2RIa3RjSFZ5Y0c5elpTST0iLCJleHAiOm51bGwsInB1ciI6IiJ9fQ==--f860052ef91b09abbf26e240ed8ef40b35037cd7";
static const char cookie_service_missing_purpose[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltZHZiR1F0YldsemMybHVaeTF3ZFhKd2IzTmxJZz09IiwiZXhwIjpudWxsfX0=--abf90f49a7234fe8a68e8a94246ddccd93b48faa";
static const char cookie_service_duplicate_purpose_valid[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltZHZiR1F0WkhWd2JHbGpZWFJsTFhaaGJHbGtJZz09IiwiZXhwIjpudWxsLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiIsInB1ciI6ImNvb2tpZS5vdGhlciIsInB1ciI6ImNvb2tpZS5zZXNzaW9uX3Rva2VuIn19--a64f055fd47cf91f75d078045cb89260c780008e";
static const char cookie_service_duplicate_purpose_invalid[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltZHZiR1F0WkhWd2JHbGpZWFJsTFdsdWRtRnNhV1FpIiwiZXhwIjpudWxsLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiIsInB1ciI6ImNvb2tpZS5zZXNzaW9uX3Rva2VuIiwicHVyIjoiY29va2llLm90aGVyIn19--0110ff665ee2be4a240e07fd939861aea61f68e7";
static const char cookie_service_trailing_json[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltZHZiR1F0ZEhKaGFXeHBibWNpIiwiZXhwIjpudWxsLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiJ9fSBnYXJiYWdl--cfe126bf7a3f7e0b842aedbe5e41279c875e5167";
static const char cookie_service_invalid_utf8[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkluVjBaamdpIiwiZXhwIjpudWxsLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiIsIngiOiL/In19--86ee956b8d9acb39b25d79bf6f11db5ff6f8d32c";
static const char cookie_service_invalid_escape[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltVnpZMkZ3WlNJPSIsImV4cCI6bnVsbCwicHVyIjoiY29va2llLnNlc3Npb25fdG9rZW4iLCJ4IjoiXHVaWlpaIn19--cd858f73e137f060100c5cffde7fa8ee813270c1";
static const char cookie_service_overdeep_json[] =
    "eyJfcmFpbHMiOnsibWVzc2FnZSI6IkltUmxaWEFpIiwiZXhwIjpudWxsLCJwdXIiOiJjb29raWUuc2Vzc2lvbl90b2tlbiJ9LCJkZWVwIjpbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbbnVsbF1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV1dXV19--820baca20e58de6edef668e10a89b8468e721cc3";

enum { STRING_TYPE = 33u, I64_TYPE = 32u, COOKIE_OPTION_TYPE = 45u, BOOL_TYPE = 1u };

static const al_owning_type_descriptor test_types[60u] = {
    {1u, 1u, 0u, 0u, 8u, 8u, 8u, 8u, 0u},
    {2u, 2u, 0u, 0u, 8u, 8u, 8u, 8u, 0u},
    {4u, 4u, 0u, 4u, 4294967295u, 4294967295u, 32u, 32u, 0u},
    {6u, 5u, 4u, 0u, 8u, 8u, 8u, 8u, 3u},
    {5u, 6u, 4u, 0u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {6u, 7u, 4u, 0u, 8u, 8u, 8u, 8u, 6u},
    {4u, 8u, 4u, 3u, 4294967295u, 4294967295u, 24u, 24u, 0u},
    {4u, 9u, 7u, 20u, 4294967295u, 4294967295u, 200u, 200u, 0u},
    {4u, 10u, 27u, 9u, 4294967295u, 4294967295u, 72u, 72u, 0u},
    {6u, 11u, 36u, 0u, 8u, 8u, 8u, 8u, 4u},
    {6u, 13u, 36u, 0u, 8u, 8u, 8u, 8u, 4u},
    {4u, 14u, 36u, 2u, 4294967295u, 4294967295u, 16u, 16u, 0u},
    {4u, 15u, 38u, 1u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {4u, 16u, 39u, 2u, 4294967295u, 4294967295u, 16u, 16u, 0u},
    {6u, 17u, 41u, 0u, 8u, 8u, 8u, 8u, 5u},
    {6u, 18u, 41u, 0u, 8u, 8u, 8u, 8u, 11u},
    {4u, 19u, 41u, 2u, 16u, 16u, 16u, 16u, 0u},
    {1u, 20u, 43u, 0u, 8u, 8u, 8u, 8u, 0u},
    {4u, 21u, 43u, 7u, 4294967295u, 4294967295u, 56u, 56u, 0u},
    {5u, 23u, 50u, 0u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {6u, 24u, 50u, 0u, 8u, 8u, 8u, 8u, 3u},
    {4u, 25u, 50u, 3u, 4294967295u, 4294967295u, 80u, 80u, 0u},
    {6u, 26u, 53u, 0u, 8u, 8u, 8u, 8u, 3u},
    {1u, 27u, 53u, 0u, 8u, 8u, 8u, 8u, 0u},
    {6u, 28u, 53u, 0u, 8u, 8u, 8u, 8u, 3u},
    {6u, 29u, 53u, 0u, 8u, 8u, 8u, 8u, 5u},
    {4u, 30u, 53u, 6u, 4294967295u, 4294967295u, 48u, 48u, 0u},
    {1u, 31u, 59u, 0u, 8u, 8u, 8u, 8u, 0u},
    {4u, 32u, 59u, 5u, 4294967295u, 4294967295u, 40u, 40u, 0u},
    {4u, 33u, 64u, 8u, 4294967295u, 4294967295u, 64u, 64u, 0u},
    {5u, 35u, 72u, 0u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {1u, 37u, 72u, 0u, 8u, 8u, 8u, 8u, 0u},
    {1u, 38u, 72u, 0u, 8u, 8u, 8u, 8u, 0u},
    {5u, 39u, 72u, 0u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {7u, 41u, 72u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 42u, 74u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 43u, 76u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {7u, 44u, 78u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 45u, 80u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {7u, 46u, 82u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 47u, 84u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {7u, 48u, 86u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 49u, 88u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {10u, 50u, 90u, 1u, 4294967295u, 4294967295u, 8u, 8u, 0u},
    {7u, 51u, 91u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 52u, 93u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 53u, 95u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 54u, 97u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {7u, 55u, 99u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 56u, 101u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {7u, 57u, 103u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 58u, 105u, 2u, 4294967295u, 4294967295u, 40u, 40u, 2u},
    {8u, 59u, 107u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {8u, 60u, 109u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {8u, 61u, 111u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {7u, 62u, 113u, 2u, 4294967295u, 4294967295u, 8u, 8u, 2u},
    {8u, 63u, 115u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {8u, 64u, 117u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
    {8u, 65u, 119u, 2u, 16u, 16u, 16u, 16u, 2u},
    {8u, 66u, 121u, 2u, 4294967295u, 4294967295u, 16u, 16u, 2u},
};

static const al_owning_field_descriptor test_fields[123u] = {
    {31u, 0u, 0u, 0u},
    {33u, 8u, 0u, 0u},
    {22u, 4294967295u, 0u, 0u},
    {3u, 4294967295u, 0u, 0u},
    {5u, 0u, 0u, 0u},
    {34u, 8u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {14u, 0u, 0u, 0u},
    {20u, 8u, 0u, 0u},
    {23u, 16u, 0u, 0u},
    {32u, 24u, 0u, 0u},
    {19u, 32u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {33u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {35u, 4294967295u, 0u, 0u},
    {36u, 4294967295u, 0u, 0u},
    {38u, 4294967295u, 0u, 0u},
    {40u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {6u, 4294967295u, 0u, 0u},
    {0u, 0u, 0u, 0u},
    {15u, 8u, 0u, 0u},
    {33u, 16u, 0u, 0u},
    {42u, 4294967295u, 0u, 0u},
    {43u, 4294967295u, 0u, 0u},
    {44u, 4294967295u, 0u, 0u},
    {45u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {46u, 4294967295u, 0u, 0u},
    {34u, 0u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {34u, 0u, 0u, 0u},
    {34u, 0u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {31u, 0u, 0u, 0u},
    {23u, 8u, 0u, 0u},
    {17u, 0u, 0u, 0u},
    {23u, 8u, 0u, 0u},
    {31u, 16u, 0u, 0u},
    {33u, 24u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {33u, 4294967295u, 0u, 0u},
    {33u, 4294967295u, 0u, 0u},
    {49u, 0u, 0u, 0u},
    {29u, 4294967295u, 0u, 0u},
    {1u, 4294967295u, 0u, 0u},
    {23u, 0u, 0u, 0u},
    {34u, 8u, 0u, 0u},
    {24u, 4294967295u, 0u, 0u},
    {31u, 4294967295u, 0u, 0u},
    {33u, 4294967295u, 0u, 0u},
    {33u, 4294967295u, 0u, 0u},
    {27u, 0u, 0u, 0u},
    {32u, 8u, 0u, 0u},
    {32u, 16u, 0u, 0u},
    {50u, 24u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {27u, 0u, 0u, 0u},
    {31u, 8u, 0u, 0u},
    {30u, 16u, 0u, 0u},
    {50u, 4294967295u, 0u, 0u},
    {34u, 4294967295u, 0u, 0u},
    {32u, 4294967295u, 0u, 0u},
    {32u, 4294967295u, 0u, 0u},
    {32u, 4294967295u, 0u, 0u},
    {33u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {4u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {37u, 8u, 0u, 0u},
    {10u, 8u, 0u, 0u},
    {13u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {39u, 8u, 0u, 0u},
    {10u, 8u, 0u, 0u},
    {11u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {41u, 8u, 0u, 0u},
    {10u, 8u, 0u, 0u},
    {12u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {26u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {18u, 8u, 0u, 0u},
    {18u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {30u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {23u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {48u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {21u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {2u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {19u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {2u, 8u, 0u, 0u},
    {8u, 8u, 0u, 0u},
    {42u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {49u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {55u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {29u, 8u, 0u, 0u},
    {4294967295u, 8u, 0u, 0u},
    {29u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {43u, 8u, 0u, 0u},
    {25u, 8u, 0u, 0u},
    {1u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
    {43u, 8u, 0u, 0u},
    {9u, 8u, 0u, 0u},
};

static const al_owning_layout test_layout = {
    AL_OWNING_LAYOUT_ABI_VERSION, test_types, 60u, test_fields, 123u};
static __declspec(align(16)) uint8_t pure_context_storage[32768u];
static uint8_t first_string[8192u];
static uint8_t second_string[8192u];
static uint8_t instant_value[8u];
static uint8_t output_value[8192u];
static al_campfire_room_read_input inputs[2u];
static uint32_t checks;

static uint32_t pack_string(uint8_t *destination, const char *text) {
  const uint32_t length = (uint32_t)strlen(text);
  const uint32_t payload = 8u + length * 2u;
  const uint32_t extent = (payload + 7u) & ~7u;
  uint32_t index;
  memset(destination, 0, extent);
  destination[0] = (uint8_t)length;
  destination[1] = (uint8_t)(length >> 8u);
  destination[2] = (uint8_t)(length >> 16u);
  destination[3] = (uint8_t)(length >> 24u);
  for (index = 0u; index < length; ++index) {
    destination[8u + index * 2u] = (uint8_t)text[index];
    destination[9u + index * 2u] = 0u;
  }
  return extent;
}

static void pack_i64(uint8_t *destination, int64_t value) {
  uint32_t index;
  const uint64_t bits = (uint64_t)value;
  for (index = 0u; index < 8u; ++index)
    destination[index] = (uint8_t)(bits >> (index * 8u));
}

static uint64_t read_u64(const uint8_t *source) {
  uint64_t value = 0u;
  uint32_t index;
  for (index = 0u; index < 8u; ++index)
    value |= (uint64_t)source[index] << (index * 8u);
  return value;
}

static uint32_t read_u32(const uint8_t *source) {
  return (uint32_t)source[0] | ((uint32_t)source[1] << 8u) |
         ((uint32_t)source[2] << 16u) | ((uint32_t)source[3] << 24u);
}

static int check_cookie(void *context, const char *raw, int64_t now,
                        const char *expected_token) {
  uint32_t extent;
  uint32_t output_extent = 0u;
  uint32_t index;
  const uint32_t raw_extent = pack_string(first_string, raw);
  ++checks;
  pack_i64(instant_value, now);
  inputs[0] = (al_campfire_room_read_input){first_string, raw_extent,
                                             STRING_TYPE};
  inputs[1] = (al_campfire_room_read_input){instant_value, 8u, I64_TYPE};
  memset(output_value, 0xa5, sizeof(output_value));
  if (al_campfire_verify_cookie_v1(
          context, &test_layout, inputs, 2u, COOKIE_OPTION_TYPE, output_value,
          sizeof(output_value), &output_extent) != 0)
    return 0;
  if (expected_token == NULL)
    return output_extent == 8u && read_u64(output_value) == 1u;
  if (output_extent < 16u || read_u64(output_value) != 0u)
    return 0;
  extent = read_u32(output_value + 8u);
  if (extent != (uint32_t)strlen(expected_token) ||
      output_extent != 8u + ((8u + extent * 2u + 7u) & ~7u))
    return 0;
  for (index = 0u; index < extent; ++index) {
    if (output_value[16u + index * 2u] != (uint8_t)expected_token[index] ||
        output_value[17u + index * 2u] != 0u)
      return 0;
  }
  return 1;
}

static int check_browser(const char *version, const char *minimum,
                         int expected) {
  uint32_t output_extent = 0u;
  const uint32_t first_extent = pack_string(first_string, version);
  const uint32_t second_extent = pack_string(second_string, minimum);
  ++checks;
  inputs[0] = (al_campfire_room_read_input){first_string, first_extent,
                                             STRING_TYPE};
  inputs[1] = (al_campfire_room_read_input){second_string, second_extent,
                                             STRING_TYPE};
  memset(output_value, 0xa5, sizeof(output_value));
  return al_campfire_browser_version_v1(
             NULL, &test_layout, inputs, 2u, BOOL_TYPE, output_value,
             sizeof(output_value), &output_extent) == 0 &&
         output_extent == 8u && read_u64(output_value) == (uint64_t)expected;
}

int main(void) {
  static const int64_t test_now = INT64_C(1700000000000000);
  const uint32_t context_size = al_campfire_pure_context_size_v1();
  const uint32_t context_alignment = al_campfire_pure_context_alignment_v1();
  int ok = 1;
  if (context_size > sizeof(pure_context_storage) ||
      context_alignment == 0u ||
      ((uintptr_t)pure_context_storage % context_alignment) != 0u ||
      al_campfire_pure_context_init_v1(
          pure_context_storage, sizeof(pure_context_storage), fixture_secret,
          (uint32_t)(sizeof(fixture_secret) - 1u)) != 0) {
    fputs("pure context init failed\n", stderr);
    return 1;
  }
  ok &= check_cookie((void *)pure_context_storage, valid_cookie, test_now,
                     "native-session-42");
  ok &= check_cookie((void *)pure_context_storage, wrong_purpose_cookie,
                     test_now, NULL);
  ok &= check_cookie((void *)pure_context_storage, expired_cookie, test_now,
                     NULL);
  ok &= check_cookie((void *)pure_context_storage, offset_future_cookie,
                     test_now, "native-session-42");
  ok &= check_cookie((void *)pure_context_storage, equal_expiry_cookie,
                     test_now, NULL);
  ok &= check_cookie((void *)pure_context_storage, direct_cookie, test_now,
                     "direct-legacy-token");
  ok &= check_cookie((void *)pure_context_storage, "not-a-cookie", test_now,
                     NULL);
  ok &= check_browser("3.10.1", "3.10.1beta", 1);
  ok &= check_browser("3.10.1beta", "3.10.1", 0);
  ok &= check_browser("v12.0", "v12.0", 1);
  ok &= check_browser("v12.0", "v13.0", 0);
  ok &= check_browser("1.2.3.4.5.6", "1.2.3.4.5.6.7", 1);
  al_campfire_pure_context_destroy_v1((void *)pure_context_storage);
  if (al_campfire_pure_context_init_v1(
          pure_context_storage, sizeof(pure_context_storage),
          cookie_service_fixture_secret,
          (uint32_t)(sizeof(cookie_service_fixture_secret) - 1u)) != 0) {
    fputs("CookieService fixture context init failed\n", stderr);
    return 1;
  }
  ok &= check_cookie((void *)pure_context_storage, cookie_service_golden,
                     INT64_C(1767268800000000), "hello world");
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_no_purpose_null,
                     INT64_C(1767268800000000), "nopurpose");
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_no_purpose_expired,
                     INT64_C(1767268800000000), NULL);
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_empty_purpose,
                     INT64_C(1767268800000000), "gold-empty-purpose");
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_missing_purpose,
                     INT64_C(1767268800000000), "gold-missing-purpose");
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_duplicate_purpose_valid,
                     INT64_C(1767268800000000), "gold-duplicate-valid");
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_duplicate_purpose_invalid,
                     INT64_C(1767268800000000), NULL);
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_trailing_json,
                     INT64_C(1767268800000000), NULL);
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_invalid_utf8,
                     INT64_C(1767268800000000), NULL);
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_invalid_escape,
                     INT64_C(1767268800000000), NULL);
  ok &= check_cookie((void *)pure_context_storage,
                     cookie_service_overdeep_json,
                     INT64_C(1767268800000000), NULL);
  al_campfire_pure_context_destroy_v1((void *)pure_context_storage);
  if (!ok) {
    fputs("pure provider vector failed\n", stderr);
    return 1;
  }
  printf("pure provider vectors passed (%u checks)\n", checks);
  return 0;
}


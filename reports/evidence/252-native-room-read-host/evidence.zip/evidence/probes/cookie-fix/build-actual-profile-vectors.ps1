$ErrorActionPreference = 'Stop'
$repo = (Get-Location).Path
$runRoot = Join-Path $repo '.agentlang/campfire-native-room-read-252/test-runs/20261012T200452671Z-006611170c3b41adbe0c6dffbfcf9373'
$llvmPath = Join-Path $runRoot 'test-artifacts/O0/owning-stack-native-host.ll'
$sourcePath = Join-Path $repo '.agentlang/campfire-native-room-read-252/pure-vectors.c'
$outputPath = Join-Path $repo '.agentlang/campfire-native-room-read-252/cookie-fix/pure-vectors-actual-profile.c'
$llvm = Get-Content -LiteralPath $llvmPath -Raw
$source = Get-Content -LiteralPath $sourcePath -Raw
$typeArray = [regex]::Match($llvm, '(?s)@al_owning_types = private constant \[\d+ x %AlOwningTypeDescriptor\] \[(.*?)\], align 4')
$fieldArray = [regex]::Match($llvm, '(?s)@al_owning_fields = private constant \[\d+ x %AlOwningFieldDescriptor\] \[(.*?)\], align 4')
if (-not $typeArray.Success -or -not $fieldArray.Success) { throw 'Frozen LLVM layout arrays were not found.' }
$typeEntries = [regex]::Matches($typeArray.Groups[1].Value, '%AlOwningTypeDescriptor \{ ([^}]*) \}')
$fieldEntries = [regex]::Matches($fieldArray.Groups[1].Value, '%AlOwningFieldDescriptor \{ ([^}]*) \}')
if ($typeEntries.Count -ne 60 -or $fieldEntries.Count -ne 123) { throw "Unexpected frozen layout dimensions: $($typeEntries.Count) types, $($fieldEntries.Count) fields." }
$typeLines = foreach ($entry in $typeEntries) {
    $values = [regex]::Matches($entry.Groups[1].Value, 'i32 (\d+)') | ForEach-Object { "$($_.Groups[1].Value)u" }
    '    {' + ($values -join ', ') + '},'
}
$fieldLines = foreach ($entry in $fieldEntries) {
    $values = [regex]::Matches($entry.Groups[1].Value, 'i32 (\d+)') | ForEach-Object { "$($_.Groups[1].Value)u" }
    '    {' + ($values -join ', ') + '},'
}
$replacement = @"
enum { STRING_TYPE = 33u, I64_TYPE = 32u, COOKIE_OPTION_TYPE = 45u, BOOL_TYPE = 1u };

static const al_owning_type_descriptor test_types[60u] = {
$($typeLines -join "`n")
};

static const al_owning_field_descriptor test_fields[123u] = {
$($fieldLines -join "`n")
};

static const al_owning_layout test_layout = {
    AL_OWNING_LAYOUT_ABI_VERSION, test_types, 60u, test_fields, 123u};

"@
$fixtureBlock = [regex]::Match($source, '(?s)enum \{\s*STRING_TYPE = 0,.*?(?=static __declspec\(align\(16\)\))')
if (-not $fixtureBlock.Success) { throw 'Private vector layout block was not found.' }
$source = $source.Substring(0, $fixtureBlock.Index) + $replacement + $source.Substring($fixtureBlock.Index + $fixtureBlock.Length)
$source = $source.Replace('return output_extent == 8u && read_u64(output_value) == 0u;', 'return output_extent == 8u && read_u64(output_value) == 1u;')
$source = $source.Replace('if (output_extent < 16u || read_u64(output_value) != 1u)', 'if (output_extent < 16u || read_u64(output_value) != 0u)')
Set-Content -LiteralPath $outputPath -Value $source -Encoding Ascii
Write-Output "Generated disposable vector harness with $($typeEntries.Count) frozen types and $($fieldEntries.Count) frozen fields."

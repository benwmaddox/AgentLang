# Native cookie boundary fix

The retained O0 manifest identifies output type index 45 as `Option<SessionToken>`, with `Some` tag 0 and `None` tag 1. Its child `SessionToken` is type index 30, `String`; callback inputs are type 33 (`String`) and 32 (`UtcInstant`). The generated IR at line 111423 calls the room-read host with operation 1 and output type 45. The callback had written None as tag 0 and Some as tag 1. A malformed cookie therefore produced tag 0 with only the 8-byte option header; the owning-stack validator correctly interpreted this as Some and rejected the missing string payload.

`applications/campfire/Native/room_read_pure.c` now writes None tag 1 and Some tag 0. The existing output type, field, capacity, and extent checks remain unchanged. No adapter, compiler, or test source was edited.

## Validation

A disposable copy of the private 23-vector harness was generated at `pure-vectors-actual-profile.c` using the frozen LLVM module's complete 60 type descriptors and 123 field descriptors. The copy uses the compiled profile's Option tags. It exercises direct native callback calls for valid Some cookies and malformed/invalid None cookies, including the exact 8-byte None result. All 23 checks passed:

```text
pure provider vectors passed (23 checks)
```

The harness build and run used clang-cl on the x64 Windows target with `/W4 /WX`; the command and generated copy are in this directory.

The strict GNU-style Clang syntax gate also passed with zero warning exclusions. It compiled the combined adapter and pure-provider translation unit through the private preflight source:

```powershell
$native = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe'
& $native --target=x86_64-pc-windows-msvc -std=c11 -ffreestanding -fno-builtin -Wall -Wextra -Werror -fsyntax-only -Isrc/AgentLang.Llvm/native -Iapplications/campfire/Native .agentlang/campfire-native-room-read-252/adapter-preflight.c
```

The zero-exit log is `root-combined-strict-syntax.log`. `git diff --check` passed for the untracked C source. C source SHA-256: `0C7482253A2A27E8F58BFA6E17D5F7BFC63BB1E375478CCB04C2577CA1A092CE`.

#ifndef TEST_DIRECT_REPLAY_CONFIG_H
#define TEST_DIRECT_REPLAY_CONFIG_H
#define REPLAY_DLL_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-runs\\final-integrated-6\\test-artifacts\\O0\\owning-stack-native-host.dll"
#define REPLAY_INPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\final6-raw-capture\\diagnostic-input.bin"
#define REPLAY_DATABASE_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\final6-raw-capture\\test-fixture\\native.sqlite"
#define REPLAY_OUTPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\replay-original\\replay-receipt.json"
#endif

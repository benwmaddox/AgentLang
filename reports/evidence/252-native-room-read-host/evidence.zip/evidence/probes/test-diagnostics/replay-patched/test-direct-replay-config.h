#ifndef TEST_DIRECT_REPLAY_CONFIG_H
#define TEST_DIRECT_REPLAY_CONFIG_H
#define REPLAY_DLL_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\validator-call-repair-probe\\diagnostic-only-repaired.dll"
#define REPLAY_INPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\final6-raw-capture\\diagnostic-input.bin"
#define REPLAY_DATABASE_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\final6-raw-capture\\test-fixture\\native.sqlite"
#define REPLAY_OUTPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\replay-patched\\replay-receipt.json"
#endif

#ifndef TEST_DIRECT_REPLAY_CONFIG_H
#define TEST_DIRECT_REPLAY_CONFIG_H
#define REPLAY_DLL_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-runs\\20261012T204759973Z-eed70b04ffc744be9c277176a258b39b\\test-artifacts\\O0\\owning-stack-native-host.dll"
#define REPLAY_INPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\final6-raw-capture\\diagnostic-input.bin"
#define REPLAY_DATABASE_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-runs\\20261012T204759973Z-eed70b04ffc744be9c277176a258b39b\\test-fixture\\native.sqlite"
#define REPLAY_OUTPUT_PATH "D:\\code\\AgentLang\\.agentlang\\campfire-native-room-read-252\\test-diagnostics\\run4-o0-direct-replay\\replay-receipt.json"
#endif

$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ModuleProbe252 {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)]
 public static extern uint GetModuleFileNameW(IntPtr module, System.Text.StringBuilder path, uint size);
 [DllImport("kernel32.dll")]
 public static extern bool GetModuleHandleExW(uint flags, IntPtr address, out IntPtr module);
}
'@
$package = 'C:\Users\Ben\.nuget\packages\sqlitepclraw.lib.e_sqlite3\2.1.12\runtimes\win-x64\native\e_sqlite3.dll'
$artifact = 'D:\code\AgentLang\.agentlang\campfire-native-room-read-252\test-runs\20261012T204759973Z-eed70b04ffc744be9c277176a258b39b\test-artifacts\O0'
$packageHandle = [System.Runtime.InteropServices.NativeLibrary]::Load($package)
$nativeHandle = [System.Runtime.InteropServices.NativeLibrary]::Load((Join-Path $artifact 'owning-stack-native-host.dll'))
$copiedHandle = [System.Runtime.InteropServices.NativeLibrary]::Load((Join-Path $artifact 'e_sqlite3.dll'))
$marshal = [System.Runtime.InteropServices.Marshal]
$peOffset = $marshal::ReadInt32($nativeHandle, 60)
$optionalOffset = $peOffset + 24
if ($marshal::ReadInt16($nativeHandle, $optionalOffset) -ne 0x20b) { throw 'Expected PE32+.' }
$importRva = $marshal::ReadInt32($nativeHandle, $optionalOffset + 120)
$descriptor = [IntPtr]::Add($nativeHandle, $importRva)
$found = $false
for ($i=0; $i -lt 32; $i++) {
 $nameRva = $marshal::ReadInt32($descriptor, 12)
 if ($nameRva -eq 0) { break }
 $name = $marshal::PtrToStringAnsi([IntPtr]::Add($nativeHandle, $nameRva))
 if ($name -eq 'e_sqlite3.dll') {
  $iatRva = $marshal::ReadInt32($descriptor, 16)
  $functionPointer = $marshal::ReadIntPtr([IntPtr]::Add($nativeHandle, $iatRva))
  $boundModule = [IntPtr]::Zero
  if (-not [ModuleProbe252]::GetModuleHandleExW(6, $functionPointer, [ref]$boundModule)) { throw 'Cannot resolve IAT module.' }
  $path = [System.Text.StringBuilder]::new(32768)
  if ([ModuleProbe252]::GetModuleFileNameW($boundModule, $path, 32768) -eq 0) { throw 'Cannot resolve module path.' }
  [ordered]@{ packageHandle=$packageHandle.ToString('x'); copiedHandle=$copiedHandle.ToString('x'); boundModule=$boundModule.ToString('x'); boundPath=$path.ToString(); copiedEqualsBound=($copiedHandle -eq $boundModule); packageEqualsBound=($packageHandle -eq $boundModule) } | ConvertTo-Json
  $found = $true
  break
 }
 $descriptor = [IntPtr]::Add($descriptor, 20)
}
if (-not $found) { throw 'No SQLite import found.' }
[System.Runtime.InteropServices.NativeLibrary]::Free($copiedHandle)
[System.Runtime.InteropServices.NativeLibrary]::Free($nativeHandle)
[System.Runtime.InteropServices.NativeLibrary]::Free($packageHandle)

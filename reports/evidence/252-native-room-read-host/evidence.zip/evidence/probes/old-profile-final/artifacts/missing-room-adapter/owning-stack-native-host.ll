%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [10 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 6, i32 4, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 4 }, %AlOwningTypeDescriptor { i32 1, i32 5, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 6, i32 6, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 3 }, %AlOwningTypeDescriptor { i32 4, i32 7, i32 0, i32 6, i32 4294967295, i32 4294967295, i32 48, i32 48, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 8, i32 6, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 9, i32 6, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 8, i32 11, i32 6, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }, %AlOwningTypeDescriptor { i32 7, i32 12, i32 8, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 7, i32 13, i32 10, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [12 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 9, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 5, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 8, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 5, ptr @al_owning_types, i32 10, ptr @al_owning_fields, i32 12 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_commit_host_output(ptr, ptr, i32, i32, i32, i32, i32, i32, ptr)
declare i32 @al_host_campfire_rooms_find_for_user_v1(ptr, i64, i64, ptr, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_ascii_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare i32 @al_owning_int_format(ptr, i64, ptr, ptr, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.78 = alloca [2 x %AlOwningDescriptor], align 4
  %call.results.99 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 8
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %argument.type.invalid.26
argument.type.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.25:
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %stack.sub.31 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.29 = icmp ule i32 %descriptor.value.23, %context.value.28
  %descriptor.offset.inside.30 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.32 = icmp ule i32 %descriptor.value.19, %stack.sub.31
  %descriptor.payload.inside.33 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.34 = and i1 %descriptor.owner.inside.29, %descriptor.offset.inside.30
  %descriptor.range.inside.36 = and i1 %descriptor.owner.offset.valid.34, %descriptor.extent.inside.32
  %descriptor.range.valid.35 = and i1 %descriptor.range.inside.36, %descriptor.payload.inside.33
  %descriptor.type.valid.37 = icmp eq i32 8, 8
  %descriptor.valid.38 = and i1 %descriptor.range.valid.35, %descriptor.type.valid.37
  br i1 %descriptor.valid.38, label %descriptor.valid.39, label %descriptor.invalid.40
descriptor.invalid.40:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.39:
  %descriptor.initialized.status.41 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.42 = icmp eq i32 %descriptor.initialized.status.41, 0
  br i1 %helper.ok.42, label %helper.continue.43, label %frame.failure.0
helper.continue.43:
  %descriptor.element.44 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.45 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.44, i32 0, i32 0
  %descriptor.value.46 = load i32, ptr %descriptor.field.45, align 4
  %descriptor.field.47 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.44, i32 0, i32 1
  %descriptor.value.48 = load i32, ptr %descriptor.field.47, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.44, i32 0, i32 2
  %descriptor.value.50 = load i32, ptr %descriptor.field.49, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.44, i32 0, i32 3
  %descriptor.value.52 = load i32, ptr %descriptor.field.51, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.44, i32 0, i32 4
  %descriptor.value.54 = load i32, ptr %descriptor.field.53, align 4
  %argument.type.valid.55 = icmp eq i32 %descriptor.value.46, 5
  br i1 %argument.type.valid.55, label %argument.type.ok.56, label %argument.type.invalid.57
argument.type.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.56:
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %stack.sub.62 = sub i32 %descriptor.value.54, %descriptor.value.48
  %descriptor.owner.inside.60 = icmp ule i32 %descriptor.value.54, %context.value.59
  %descriptor.offset.inside.61 = icmp ule i32 %descriptor.value.48, %descriptor.value.54
  %descriptor.extent.inside.63 = icmp ule i32 %descriptor.value.50, %stack.sub.62
  %descriptor.payload.inside.64 = icmp ule i32 %descriptor.value.52, %descriptor.value.50
  %descriptor.owner.offset.valid.65 = and i1 %descriptor.owner.inside.60, %descriptor.offset.inside.61
  %descriptor.range.inside.67 = and i1 %descriptor.owner.offset.valid.65, %descriptor.extent.inside.63
  %descriptor.range.valid.66 = and i1 %descriptor.range.inside.67, %descriptor.payload.inside.64
  %descriptor.type.valid.68 = icmp eq i32 5, 5
  %descriptor.valid.69 = and i1 %descriptor.range.valid.66, %descriptor.type.valid.68
  br i1 %descriptor.valid.69, label %descriptor.valid.70, label %descriptor.invalid.71
descriptor.invalid.71:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.70:
  %descriptor.initialized.status.72 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.48, i32 %descriptor.value.50)
  %helper.ok.73 = icmp eq i32 %descriptor.initialized.status.72, 0
  br i1 %helper.ok.73, label %helper.continue.74, label %frame.failure.0
helper.continue.74:
  %step.status.75 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.76 = icmp eq i32 %step.status.75, 0
  br i1 %helper.ok.76, label %helper.continue.77, label %frame.failure.0
helper.continue.77:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.78, i32 0
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  store i32 8, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.82, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.84, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %runtime.ok.87 = icmp eq i32 %context.value.86, 0
  br i1 %runtime.ok.87, label %runtime.continue.88, label %frame.failure.0
runtime.continue.88:
  %descriptor.element.89 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.78, i32 1
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.89, i32 0, i32 0
  store i32 5, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.89, i32 0, i32 1
  store i32 %descriptor.value.48, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.89, i32 0, i32 2
  store i32 %descriptor.value.50, ptr %descriptor.field.92, align 4
  %descriptor.field.93 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.89, i32 0, i32 3
  store i32 %descriptor.value.52, ptr %descriptor.field.93, align 4
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.89, i32 0, i32 4
  store i32 %descriptor.value.54, ptr %descriptor.field.94, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.48, i32 20, i32 %descriptor.value.52, i32 %descriptor.value.54, i32 %descriptor.value.50)
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %runtime.ok.97 = icmp eq i32 %context.value.96, 0
  br i1 %runtime.ok.97, label %runtime.continue.98, label %frame.failure.0
runtime.continue.98:
  %callee.status.100 = call i32 @agentlang_word_0000(ptr %ctx, ptr %provider.context, ptr %call.arguments.78, ptr %call.results.99, i32 2)
  %helper.ok.101 = icmp eq i32 %callee.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %descriptor.element.103 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.99, i32 0
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 0
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 1
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 2
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 3
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 4
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %callee.result.type.valid.114 = icmp eq i32 %descriptor.value.105, 11
  br i1 %callee.result.type.valid.114, label %callee.result.type.ok.115, label %frame.failure.0
callee.result.type.ok.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.113, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.109, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 11, 11
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %runtime.ok.135 = icmp eq i32 %context.value.134, 0
  br i1 %runtime.ok.135, label %runtime.continue.136, label %frame.failure.0
runtime.continue.136:
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %stack.sub.141 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.139 = icmp ule i32 %descriptor.value.113, %context.value.138
  %descriptor.offset.inside.140 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.142 = icmp ule i32 %descriptor.value.109, %stack.sub.141
  %descriptor.payload.inside.143 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.144 = and i1 %descriptor.owner.inside.139, %descriptor.offset.inside.140
  %descriptor.range.inside.146 = and i1 %descriptor.owner.offset.valid.144, %descriptor.extent.inside.142
  %descriptor.range.valid.145 = and i1 %descriptor.range.inside.146, %descriptor.payload.inside.143
  %descriptor.type.valid.147 = icmp eq i32 11, 11
  %descriptor.valid.148 = and i1 %descriptor.range.valid.145, %descriptor.type.valid.147
  br i1 %descriptor.valid.148, label %descriptor.valid.149, label %descriptor.invalid.150
descriptor.invalid.150:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.149:
  %descriptor.initialized.status.151 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.152 = icmp eq i32 %descriptor.initialized.status.151, 0
  br i1 %helper.ok.152, label %helper.continue.153, label %frame.failure.0
helper.continue.153:
  %descriptor.element.154 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 0
  store i32 11, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 1
  store i32 %descriptor.value.107, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 2
  store i32 %descriptor.value.109, ptr %descriptor.field.157, align 4
  %descriptor.field.158 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 3
  store i32 %descriptor.value.111, ptr %descriptor.field.158, align 4
  %descriptor.field.159 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.154, i32 0, i32 4
  store i32 %descriptor.value.113, ptr %descriptor.field.159, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %stack.offset.170 = add i32 %context.value.5, %context.value.7
  %stack.offset.171 = add i32 %context.value.165, %context.value.167
  %stack.sub.172 = sub i32 %stack.offset.170, %stack.offset.171
  %stack.sub.173 = sub i32 %context.value.7, %context.value.167
  %stack.sub.174 = sub i32 %context.value.169, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.172, i32 %stack.sub.173)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.174)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %call.arguments.412 = alloca [2 x %AlOwningDescriptor], align 4
  %call.results.433 = alloca [1 x %AlOwningDescriptor], align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 8
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %argument.type.invalid.38
argument.type.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.37:
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %stack.sub.43 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.41 = icmp ule i32 %descriptor.value.35, %context.value.40
  %descriptor.offset.inside.42 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.44 = icmp ule i32 %descriptor.value.31, %stack.sub.43
  %descriptor.payload.inside.45 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.46 = and i1 %descriptor.owner.inside.41, %descriptor.offset.inside.42
  %descriptor.range.inside.48 = and i1 %descriptor.owner.offset.valid.46, %descriptor.extent.inside.44
  %descriptor.range.valid.47 = and i1 %descriptor.range.inside.48, %descriptor.payload.inside.45
  %descriptor.type.valid.49 = icmp eq i32 8, 8
  %descriptor.valid.50 = and i1 %descriptor.range.valid.47, %descriptor.type.valid.49
  br i1 %descriptor.valid.50, label %descriptor.valid.51, label %descriptor.invalid.52
descriptor.invalid.52:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.51:
  %descriptor.initialized.status.53 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.54 = icmp eq i32 %descriptor.initialized.status.53, 0
  br i1 %helper.ok.54, label %helper.continue.55, label %frame.failure.0
helper.continue.55:
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %argument.type.valid.67 = icmp eq i32 %descriptor.value.58, 5
  br i1 %argument.type.valid.67, label %argument.type.ok.68, label %argument.type.invalid.69
argument.type.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.68:
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %descriptor.value.66, %descriptor.value.60
  %descriptor.owner.inside.72 = icmp ule i32 %descriptor.value.66, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %descriptor.value.60, %descriptor.value.66
  %descriptor.extent.inside.75 = icmp ule i32 %descriptor.value.62, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %descriptor.value.64, %descriptor.value.62
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  %descriptor.type.valid.80 = icmp eq i32 5, 5
  %descriptor.valid.81 = and i1 %descriptor.range.valid.78, %descriptor.type.valid.80
  br i1 %descriptor.valid.81, label %descriptor.valid.82, label %descriptor.invalid.83
descriptor.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.82:
  %descriptor.initialized.status.84 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.60, i32 %descriptor.value.62)
  %helper.ok.85 = icmp eq i32 %descriptor.initialized.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %step.status.87 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.88 = icmp eq i32 %step.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.60, ptr %local.offset.3, align 4
  store i32 %descriptor.value.62, ptr %local.extent.4, align 4
  store i32 %descriptor.value.64, ptr %local.payload.5, align 4
  store i32 %descriptor.value.66, ptr %local.owner.end.6, align 4
  store i32 5, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.60, i32 20, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 %descriptor.value.62)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %stack.sub.98 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.96 = icmp ule i32 %descriptor.value.35, %context.value.95
  %descriptor.offset.inside.97 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.99 = icmp ule i32 %descriptor.value.31, %stack.sub.98
  %descriptor.payload.inside.100 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.101 = and i1 %descriptor.owner.inside.96, %descriptor.offset.inside.97
  %descriptor.range.inside.103 = and i1 %descriptor.owner.offset.valid.101, %descriptor.extent.inside.99
  %descriptor.range.valid.102 = and i1 %descriptor.range.inside.103, %descriptor.payload.inside.100
  %descriptor.type.valid.104 = icmp eq i32 8, 8
  %descriptor.valid.105 = and i1 %descriptor.range.valid.102, %descriptor.type.valid.104
  br i1 %descriptor.valid.105, label %descriptor.valid.106, label %descriptor.invalid.107
descriptor.invalid.107:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.106:
  %descriptor.initialized.status.108 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.109 = icmp eq i32 %descriptor.initialized.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %local.is.active.111 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.111, label %local.descriptor.active.112, label %local.descriptor.inactive.113
local.descriptor.active.112:
  %local.check.offset.115 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.116 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.117 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.118 = load i32, ptr %local.owner.end.6, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %local.check.owner.end.118, %local.check.offset.115
  %descriptor.owner.inside.121 = icmp ule i32 %local.check.owner.end.118, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %local.check.offset.115, %local.check.owner.end.118
  %descriptor.extent.inside.124 = icmp ule i32 %local.check.extent.116, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %local.check.payload.117, %local.check.extent.116
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  br i1 %descriptor.range.valid.127, label %descriptor.valid.129, label %descriptor.invalid.130
descriptor.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.129:
  %descriptor.initialized.status.131 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.115, i32 %local.check.extent.116)
  %helper.ok.132 = icmp eq i32 %descriptor.initialized.status.131, 0
  br i1 %helper.ok.132, label %helper.continue.133, label %frame.failure.0
helper.continue.133:
  br label %local.descriptor.checked.114
local.descriptor.inactive.113:
  br label %local.descriptor.checked.114
local.descriptor.checked.114:
  %local.is.active.134 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.134, label %local.descriptor.active.135, label %local.descriptor.inactive.136
local.descriptor.active.135:
  %local.check.offset.138 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.139 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.140 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.141 = load i32, ptr %local.owner.end.12, align 4
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %stack.sub.146 = sub i32 %local.check.owner.end.141, %local.check.offset.138
  %descriptor.owner.inside.144 = icmp ule i32 %local.check.owner.end.141, %context.value.143
  %descriptor.offset.inside.145 = icmp ule i32 %local.check.offset.138, %local.check.owner.end.141
  %descriptor.extent.inside.147 = icmp ule i32 %local.check.extent.139, %stack.sub.146
  %descriptor.payload.inside.148 = icmp ule i32 %local.check.payload.140, %local.check.extent.139
  %descriptor.owner.offset.valid.149 = and i1 %descriptor.owner.inside.144, %descriptor.offset.inside.145
  %descriptor.range.inside.151 = and i1 %descriptor.owner.offset.valid.149, %descriptor.extent.inside.147
  %descriptor.range.valid.150 = and i1 %descriptor.range.inside.151, %descriptor.payload.inside.148
  br i1 %descriptor.range.valid.150, label %descriptor.valid.152, label %descriptor.invalid.153
descriptor.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.152:
  %descriptor.initialized.status.154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.138, i32 %local.check.extent.139)
  %helper.ok.155 = icmp eq i32 %descriptor.initialized.status.154, 0
  br i1 %helper.ok.155, label %helper.continue.156, label %frame.failure.0
helper.continue.156:
  br label %local.descriptor.checked.137
local.descriptor.inactive.136:
  br label %local.descriptor.checked.137
local.descriptor.checked.137:
  %step.status.157 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.158 = icmp eq i32 %step.status.157, 0
  br i1 %helper.ok.158, label %helper.continue.159, label %frame.failure.0
helper.continue.159:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.29, ptr %local.offset.9, align 4
  store i32 %descriptor.value.31, ptr %local.extent.10, align 4
  store i32 %descriptor.value.33, ptr %local.payload.11, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.12, align 4
  store i32 8, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  %local.is.active.164 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.164, label %local.descriptor.active.165, label %local.descriptor.inactive.166
local.descriptor.active.165:
  %local.check.offset.168 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.169 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.170 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.171 = load i32, ptr %local.owner.end.6, align 4
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.sub.176 = sub i32 %local.check.owner.end.171, %local.check.offset.168
  %descriptor.owner.inside.174 = icmp ule i32 %local.check.owner.end.171, %context.value.173
  %descriptor.offset.inside.175 = icmp ule i32 %local.check.offset.168, %local.check.owner.end.171
  %descriptor.extent.inside.177 = icmp ule i32 %local.check.extent.169, %stack.sub.176
  %descriptor.payload.inside.178 = icmp ule i32 %local.check.payload.170, %local.check.extent.169
  %descriptor.owner.offset.valid.179 = and i1 %descriptor.owner.inside.174, %descriptor.offset.inside.175
  %descriptor.range.inside.181 = and i1 %descriptor.owner.offset.valid.179, %descriptor.extent.inside.177
  %descriptor.range.valid.180 = and i1 %descriptor.range.inside.181, %descriptor.payload.inside.178
  br i1 %descriptor.range.valid.180, label %descriptor.valid.182, label %descriptor.invalid.183
descriptor.invalid.183:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.182:
  %descriptor.initialized.status.184 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.168, i32 %local.check.extent.169)
  %helper.ok.185 = icmp eq i32 %descriptor.initialized.status.184, 0
  br i1 %helper.ok.185, label %helper.continue.186, label %frame.failure.0
helper.continue.186:
  br label %local.descriptor.checked.167
local.descriptor.inactive.166:
  br label %local.descriptor.checked.167
local.descriptor.checked.167:
  %local.is.active.187 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.187, label %local.descriptor.active.188, label %local.descriptor.inactive.189
local.descriptor.active.188:
  %local.check.offset.191 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.192 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.193 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.194 = load i32, ptr %local.owner.end.12, align 4
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %stack.sub.199 = sub i32 %local.check.owner.end.194, %local.check.offset.191
  %descriptor.owner.inside.197 = icmp ule i32 %local.check.owner.end.194, %context.value.196
  %descriptor.offset.inside.198 = icmp ule i32 %local.check.offset.191, %local.check.owner.end.194
  %descriptor.extent.inside.200 = icmp ule i32 %local.check.extent.192, %stack.sub.199
  %descriptor.payload.inside.201 = icmp ule i32 %local.check.payload.193, %local.check.extent.192
  %descriptor.owner.offset.valid.202 = and i1 %descriptor.owner.inside.197, %descriptor.offset.inside.198
  %descriptor.range.inside.204 = and i1 %descriptor.owner.offset.valid.202, %descriptor.extent.inside.200
  %descriptor.range.valid.203 = and i1 %descriptor.range.inside.204, %descriptor.payload.inside.201
  br i1 %descriptor.range.valid.203, label %descriptor.valid.205, label %descriptor.invalid.206
descriptor.invalid.206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.205:
  %descriptor.initialized.status.207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.191, i32 %local.check.extent.192)
  %helper.ok.208 = icmp eq i32 %descriptor.initialized.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  br label %local.descriptor.checked.190
local.descriptor.inactive.189:
  br label %local.descriptor.checked.190
local.descriptor.checked.190:
  %step.status.210 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.211 = icmp eq i32 %step.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %local.resolved.offset.213 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.214 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.215 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.216 = load i32, ptr %local.owner.end.12, align 4
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %stack.sub.221 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.219 = icmp ule i32 %local.resolved.owner.end.216, %context.value.218
  %descriptor.offset.inside.220 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.222 = icmp ule i32 %local.resolved.extent.214, %stack.sub.221
  %descriptor.payload.inside.223 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.224 = and i1 %descriptor.owner.inside.219, %descriptor.offset.inside.220
  %descriptor.range.inside.226 = and i1 %descriptor.owner.offset.valid.224, %descriptor.extent.inside.222
  %descriptor.range.valid.225 = and i1 %descriptor.range.inside.226, %descriptor.payload.inside.223
  %descriptor.type.valid.227 = icmp eq i32 8, 8
  %descriptor.valid.228 = and i1 %descriptor.range.valid.225, %descriptor.type.valid.227
  br i1 %descriptor.valid.228, label %descriptor.valid.229, label %descriptor.invalid.230
descriptor.invalid.230:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.229:
  %descriptor.initialized.status.231 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.232 = icmp eq i32 %descriptor.initialized.status.231, 0
  br i1 %helper.ok.232, label %helper.continue.233, label %frame.failure.0
helper.continue.233:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.213, i32 20, i32 %local.resolved.payload.215, i32 %local.resolved.owner.end.216, i32 %local.resolved.extent.214)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %context.field.238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.239 = load i32, ptr %context.field.238, align 4
  %stack.sub.242 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.240 = icmp ule i32 %local.resolved.owner.end.216, %context.value.239
  %descriptor.offset.inside.241 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.243 = icmp ule i32 %local.resolved.extent.214, %stack.sub.242
  %descriptor.payload.inside.244 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.245 = and i1 %descriptor.owner.inside.240, %descriptor.offset.inside.241
  %descriptor.range.inside.247 = and i1 %descriptor.owner.offset.valid.245, %descriptor.extent.inside.243
  %descriptor.range.valid.246 = and i1 %descriptor.range.inside.247, %descriptor.payload.inside.244
  %descriptor.type.valid.248 = icmp eq i32 8, 8
  %descriptor.valid.249 = and i1 %descriptor.range.valid.246, %descriptor.type.valid.248
  br i1 %descriptor.valid.249, label %descriptor.valid.250, label %descriptor.invalid.251
descriptor.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.250:
  %descriptor.initialized.status.252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.253 = icmp eq i32 %descriptor.initialized.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  %local.is.active.255 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.255, label %local.descriptor.active.256, label %local.descriptor.inactive.257
local.descriptor.active.256:
  %local.check.offset.259 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.260 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.261 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.262 = load i32, ptr %local.owner.end.6, align 4
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %stack.sub.267 = sub i32 %local.check.owner.end.262, %local.check.offset.259
  %descriptor.owner.inside.265 = icmp ule i32 %local.check.owner.end.262, %context.value.264
  %descriptor.offset.inside.266 = icmp ule i32 %local.check.offset.259, %local.check.owner.end.262
  %descriptor.extent.inside.268 = icmp ule i32 %local.check.extent.260, %stack.sub.267
  %descriptor.payload.inside.269 = icmp ule i32 %local.check.payload.261, %local.check.extent.260
  %descriptor.owner.offset.valid.270 = and i1 %descriptor.owner.inside.265, %descriptor.offset.inside.266
  %descriptor.range.inside.272 = and i1 %descriptor.owner.offset.valid.270, %descriptor.extent.inside.268
  %descriptor.range.valid.271 = and i1 %descriptor.range.inside.272, %descriptor.payload.inside.269
  br i1 %descriptor.range.valid.271, label %descriptor.valid.273, label %descriptor.invalid.274
descriptor.invalid.274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.273:
  %descriptor.initialized.status.275 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.259, i32 %local.check.extent.260)
  %helper.ok.276 = icmp eq i32 %descriptor.initialized.status.275, 0
  br i1 %helper.ok.276, label %helper.continue.277, label %frame.failure.0
helper.continue.277:
  br label %local.descriptor.checked.258
local.descriptor.inactive.257:
  br label %local.descriptor.checked.258
local.descriptor.checked.258:
  %local.is.active.278 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.12, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %step.status.301 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.302 = icmp eq i32 %step.status.301, 0
  br i1 %helper.ok.302, label %helper.continue.303, label %frame.failure.0
helper.continue.303:
  %local.resolved.offset.304 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.305 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.306 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.307 = load i32, ptr %local.owner.end.6, align 4
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %stack.sub.312 = sub i32 %local.resolved.owner.end.307, %local.resolved.offset.304
  %descriptor.owner.inside.310 = icmp ule i32 %local.resolved.owner.end.307, %context.value.309
  %descriptor.offset.inside.311 = icmp ule i32 %local.resolved.offset.304, %local.resolved.owner.end.307
  %descriptor.extent.inside.313 = icmp ule i32 %local.resolved.extent.305, %stack.sub.312
  %descriptor.payload.inside.314 = icmp ule i32 %local.resolved.payload.306, %local.resolved.extent.305
  %descriptor.owner.offset.valid.315 = and i1 %descriptor.owner.inside.310, %descriptor.offset.inside.311
  %descriptor.range.inside.317 = and i1 %descriptor.owner.offset.valid.315, %descriptor.extent.inside.313
  %descriptor.range.valid.316 = and i1 %descriptor.range.inside.317, %descriptor.payload.inside.314
  %descriptor.type.valid.318 = icmp eq i32 5, 5
  %descriptor.valid.319 = and i1 %descriptor.range.valid.316, %descriptor.type.valid.318
  br i1 %descriptor.valid.319, label %descriptor.valid.320, label %descriptor.invalid.321
descriptor.invalid.321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.320:
  %descriptor.initialized.status.322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.304, i32 %local.resolved.extent.305)
  %helper.ok.323 = icmp eq i32 %descriptor.initialized.status.322, 0
  br i1 %helper.ok.323, label %helper.continue.324, label %frame.failure.0
helper.continue.324:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.304, i32 20, i32 %local.resolved.payload.306, i32 %local.resolved.owner.end.307, i32 %local.resolved.extent.305)
  %context.field.325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.326 = load i32, ptr %context.field.325, align 4
  %runtime.ok.327 = icmp eq i32 %context.value.326, 0
  br i1 %runtime.ok.327, label %runtime.continue.328, label %frame.failure.0
runtime.continue.328:
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %stack.sub.333 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.331 = icmp ule i32 %local.resolved.owner.end.216, %context.value.330
  %descriptor.offset.inside.332 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.334 = icmp ule i32 %local.resolved.extent.214, %stack.sub.333
  %descriptor.payload.inside.335 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.336 = and i1 %descriptor.owner.inside.331, %descriptor.offset.inside.332
  %descriptor.range.inside.338 = and i1 %descriptor.owner.offset.valid.336, %descriptor.extent.inside.334
  %descriptor.range.valid.337 = and i1 %descriptor.range.inside.338, %descriptor.payload.inside.335
  %descriptor.type.valid.339 = icmp eq i32 8, 8
  %descriptor.valid.340 = and i1 %descriptor.range.valid.337, %descriptor.type.valid.339
  br i1 %descriptor.valid.340, label %descriptor.valid.341, label %descriptor.invalid.342
descriptor.invalid.342:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.341:
  %descriptor.initialized.status.343 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.344 = icmp eq i32 %descriptor.initialized.status.343, 0
  br i1 %helper.ok.344, label %helper.continue.345, label %frame.failure.0
helper.continue.345:
  %context.field.346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.347 = load i32, ptr %context.field.346, align 4
  %stack.sub.350 = sub i32 %local.resolved.owner.end.307, %local.resolved.offset.304
  %descriptor.owner.inside.348 = icmp ule i32 %local.resolved.owner.end.307, %context.value.347
  %descriptor.offset.inside.349 = icmp ule i32 %local.resolved.offset.304, %local.resolved.owner.end.307
  %descriptor.extent.inside.351 = icmp ule i32 %local.resolved.extent.305, %stack.sub.350
  %descriptor.payload.inside.352 = icmp ule i32 %local.resolved.payload.306, %local.resolved.extent.305
  %descriptor.owner.offset.valid.353 = and i1 %descriptor.owner.inside.348, %descriptor.offset.inside.349
  %descriptor.range.inside.355 = and i1 %descriptor.owner.offset.valid.353, %descriptor.extent.inside.351
  %descriptor.range.valid.354 = and i1 %descriptor.range.inside.355, %descriptor.payload.inside.352
  %descriptor.type.valid.356 = icmp eq i32 5, 5
  %descriptor.valid.357 = and i1 %descriptor.range.valid.354, %descriptor.type.valid.356
  br i1 %descriptor.valid.357, label %descriptor.valid.358, label %descriptor.invalid.359
descriptor.invalid.359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.358:
  %descriptor.initialized.status.360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.304, i32 %local.resolved.extent.305)
  %helper.ok.361 = icmp eq i32 %descriptor.initialized.status.360, 0
  br i1 %helper.ok.361, label %helper.continue.362, label %frame.failure.0
helper.continue.362:
  %local.is.active.363 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.363, label %local.descriptor.active.364, label %local.descriptor.inactive.365
local.descriptor.active.364:
  %local.check.offset.367 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.368 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.369 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.370 = load i32, ptr %local.owner.end.6, align 4
  %context.field.371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.372 = load i32, ptr %context.field.371, align 4
  %stack.sub.375 = sub i32 %local.check.owner.end.370, %local.check.offset.367
  %descriptor.owner.inside.373 = icmp ule i32 %local.check.owner.end.370, %context.value.372
  %descriptor.offset.inside.374 = icmp ule i32 %local.check.offset.367, %local.check.owner.end.370
  %descriptor.extent.inside.376 = icmp ule i32 %local.check.extent.368, %stack.sub.375
  %descriptor.payload.inside.377 = icmp ule i32 %local.check.payload.369, %local.check.extent.368
  %descriptor.owner.offset.valid.378 = and i1 %descriptor.owner.inside.373, %descriptor.offset.inside.374
  %descriptor.range.inside.380 = and i1 %descriptor.owner.offset.valid.378, %descriptor.extent.inside.376
  %descriptor.range.valid.379 = and i1 %descriptor.range.inside.380, %descriptor.payload.inside.377
  br i1 %descriptor.range.valid.379, label %descriptor.valid.381, label %descriptor.invalid.382
descriptor.invalid.382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.381:
  %descriptor.initialized.status.383 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.367, i32 %local.check.extent.368)
  %helper.ok.384 = icmp eq i32 %descriptor.initialized.status.383, 0
  br i1 %helper.ok.384, label %helper.continue.385, label %frame.failure.0
helper.continue.385:
  br label %local.descriptor.checked.366
local.descriptor.inactive.365:
  br label %local.descriptor.checked.366
local.descriptor.checked.366:
  %local.is.active.386 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.386, label %local.descriptor.active.387, label %local.descriptor.inactive.388
local.descriptor.active.387:
  %local.check.offset.390 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.391 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.392 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.393 = load i32, ptr %local.owner.end.12, align 4
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %stack.sub.398 = sub i32 %local.check.owner.end.393, %local.check.offset.390
  %descriptor.owner.inside.396 = icmp ule i32 %local.check.owner.end.393, %context.value.395
  %descriptor.offset.inside.397 = icmp ule i32 %local.check.offset.390, %local.check.owner.end.393
  %descriptor.extent.inside.399 = icmp ule i32 %local.check.extent.391, %stack.sub.398
  %descriptor.payload.inside.400 = icmp ule i32 %local.check.payload.392, %local.check.extent.391
  %descriptor.owner.offset.valid.401 = and i1 %descriptor.owner.inside.396, %descriptor.offset.inside.397
  %descriptor.range.inside.403 = and i1 %descriptor.owner.offset.valid.401, %descriptor.extent.inside.399
  %descriptor.range.valid.402 = and i1 %descriptor.range.inside.403, %descriptor.payload.inside.400
  br i1 %descriptor.range.valid.402, label %descriptor.valid.404, label %descriptor.invalid.405
descriptor.invalid.405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.404:
  %descriptor.initialized.status.406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.390, i32 %local.check.extent.391)
  %helper.ok.407 = icmp eq i32 %descriptor.initialized.status.406, 0
  br i1 %helper.ok.407, label %helper.continue.408, label %frame.failure.0
helper.continue.408:
  br label %local.descriptor.checked.389
local.descriptor.inactive.388:
  br label %local.descriptor.checked.389
local.descriptor.checked.389:
  %step.status.409 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.410 = icmp eq i32 %step.status.409, 0
  br i1 %helper.ok.410, label %helper.continue.411, label %frame.failure.0
helper.continue.411:
  %descriptor.element.413 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.412, i32 0
  %descriptor.field.414 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.413, i32 0, i32 0
  store i32 8, ptr %descriptor.field.414, align 4
  %descriptor.field.415 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.413, i32 0, i32 1
  store i32 %local.resolved.offset.213, ptr %descriptor.field.415, align 4
  %descriptor.field.416 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.413, i32 0, i32 2
  store i32 %local.resolved.extent.214, ptr %descriptor.field.416, align 4
  %descriptor.field.417 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.413, i32 0, i32 3
  store i32 %local.resolved.payload.215, ptr %descriptor.field.417, align 4
  %descriptor.field.418 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.413, i32 0, i32 4
  store i32 %local.resolved.owner.end.216, ptr %descriptor.field.418, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.213, i32 20, i32 %local.resolved.payload.215, i32 %local.resolved.owner.end.216, i32 %local.resolved.extent.214)
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.420 = load i32, ptr %context.field.419, align 4
  %runtime.ok.421 = icmp eq i32 %context.value.420, 0
  br i1 %runtime.ok.421, label %runtime.continue.422, label %frame.failure.0
runtime.continue.422:
  %descriptor.element.423 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.412, i32 1
  %descriptor.field.424 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.423, i32 0, i32 0
  store i32 5, ptr %descriptor.field.424, align 4
  %descriptor.field.425 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.423, i32 0, i32 1
  store i32 %local.resolved.offset.304, ptr %descriptor.field.425, align 4
  %descriptor.field.426 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.423, i32 0, i32 2
  store i32 %local.resolved.extent.305, ptr %descriptor.field.426, align 4
  %descriptor.field.427 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.423, i32 0, i32 3
  store i32 %local.resolved.payload.306, ptr %descriptor.field.427, align 4
  %descriptor.field.428 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.423, i32 0, i32 4
  store i32 %local.resolved.owner.end.307, ptr %descriptor.field.428, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.304, i32 20, i32 %local.resolved.payload.306, i32 %local.resolved.owner.end.307, i32 %local.resolved.extent.305)
  %context.field.429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.430 = load i32, ptr %context.field.429, align 4
  %runtime.ok.431 = icmp eq i32 %context.value.430, 0
  br i1 %runtime.ok.431, label %runtime.continue.432, label %frame.failure.0
runtime.continue.432:
  %callee.status.434 = call i32 @agentlang_word_0001(ptr %ctx, ptr %provider.context, ptr %call.arguments.412, ptr %call.results.433, i32 8)
  %helper.ok.435 = icmp eq i32 %callee.status.434, 0
  br i1 %helper.ok.435, label %helper.continue.436, label %frame.failure.0
helper.continue.436:
  %descriptor.element.437 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.433, i32 0
  %descriptor.field.438 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.437, i32 0, i32 0
  %descriptor.value.439 = load i32, ptr %descriptor.field.438, align 4
  %descriptor.field.440 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.437, i32 0, i32 1
  %descriptor.value.441 = load i32, ptr %descriptor.field.440, align 4
  %descriptor.field.442 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.437, i32 0, i32 2
  %descriptor.value.443 = load i32, ptr %descriptor.field.442, align 4
  %descriptor.field.444 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.437, i32 0, i32 3
  %descriptor.value.445 = load i32, ptr %descriptor.field.444, align 4
  %descriptor.field.446 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.437, i32 0, i32 4
  %descriptor.value.447 = load i32, ptr %descriptor.field.446, align 4
  %callee.result.type.valid.448 = icmp eq i32 %descriptor.value.439, 11
  br i1 %callee.result.type.valid.448, label %callee.result.type.ok.449, label %frame.failure.0
callee.result.type.ok.449:
  %context.field.450 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.451 = load i32, ptr %context.field.450, align 4
  %stack.sub.454 = sub i32 %descriptor.value.447, %descriptor.value.441
  %descriptor.owner.inside.452 = icmp ule i32 %descriptor.value.447, %context.value.451
  %descriptor.offset.inside.453 = icmp ule i32 %descriptor.value.441, %descriptor.value.447
  %descriptor.extent.inside.455 = icmp ule i32 %descriptor.value.443, %stack.sub.454
  %descriptor.payload.inside.456 = icmp ule i32 %descriptor.value.445, %descriptor.value.443
  %descriptor.owner.offset.valid.457 = and i1 %descriptor.owner.inside.452, %descriptor.offset.inside.453
  %descriptor.range.inside.459 = and i1 %descriptor.owner.offset.valid.457, %descriptor.extent.inside.455
  %descriptor.range.valid.458 = and i1 %descriptor.range.inside.459, %descriptor.payload.inside.456
  %descriptor.type.valid.460 = icmp eq i32 11, 11
  %descriptor.valid.461 = and i1 %descriptor.range.valid.458, %descriptor.type.valid.460
  br i1 %descriptor.valid.461, label %descriptor.valid.462, label %descriptor.invalid.463
descriptor.invalid.463:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.462:
  %descriptor.initialized.status.464 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.441, i32 %descriptor.value.443)
  %helper.ok.465 = icmp eq i32 %descriptor.initialized.status.464, 0
  br i1 %helper.ok.465, label %helper.continue.466, label %frame.failure.0
helper.continue.466:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.441, i32 20, i32 %descriptor.value.445, i32 %descriptor.value.447, i32 %descriptor.value.443)
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %runtime.ok.469 = icmp eq i32 %context.value.468, 0
  br i1 %runtime.ok.469, label %runtime.continue.470, label %frame.failure.0
runtime.continue.470:
  %context.field.471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.472 = load i32, ptr %context.field.471, align 4
  %stack.sub.475 = sub i32 %descriptor.value.447, %descriptor.value.441
  %descriptor.owner.inside.473 = icmp ule i32 %descriptor.value.447, %context.value.472
  %descriptor.offset.inside.474 = icmp ule i32 %descriptor.value.441, %descriptor.value.447
  %descriptor.extent.inside.476 = icmp ule i32 %descriptor.value.443, %stack.sub.475
  %descriptor.payload.inside.477 = icmp ule i32 %descriptor.value.445, %descriptor.value.443
  %descriptor.owner.offset.valid.478 = and i1 %descriptor.owner.inside.473, %descriptor.offset.inside.474
  %descriptor.range.inside.480 = and i1 %descriptor.owner.offset.valid.478, %descriptor.extent.inside.476
  %descriptor.range.valid.479 = and i1 %descriptor.range.inside.480, %descriptor.payload.inside.477
  %descriptor.type.valid.481 = icmp eq i32 11, 11
  %descriptor.valid.482 = and i1 %descriptor.range.valid.479, %descriptor.type.valid.481
  br i1 %descriptor.valid.482, label %descriptor.valid.483, label %descriptor.invalid.484
descriptor.invalid.484:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.483:
  %descriptor.initialized.status.485 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.441, i32 %descriptor.value.443)
  %helper.ok.486 = icmp eq i32 %descriptor.initialized.status.485, 0
  br i1 %helper.ok.486, label %helper.continue.487, label %frame.failure.0
helper.continue.487:
  %local.is.active.488 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.488, label %local.descriptor.active.489, label %local.descriptor.inactive.490
local.descriptor.active.489:
  %local.check.offset.492 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.493 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.494 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.495 = load i32, ptr %local.owner.end.6, align 4
  %context.field.496 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.497 = load i32, ptr %context.field.496, align 4
  %stack.sub.500 = sub i32 %local.check.owner.end.495, %local.check.offset.492
  %descriptor.owner.inside.498 = icmp ule i32 %local.check.owner.end.495, %context.value.497
  %descriptor.offset.inside.499 = icmp ule i32 %local.check.offset.492, %local.check.owner.end.495
  %descriptor.extent.inside.501 = icmp ule i32 %local.check.extent.493, %stack.sub.500
  %descriptor.payload.inside.502 = icmp ule i32 %local.check.payload.494, %local.check.extent.493
  %descriptor.owner.offset.valid.503 = and i1 %descriptor.owner.inside.498, %descriptor.offset.inside.499
  %descriptor.range.inside.505 = and i1 %descriptor.owner.offset.valid.503, %descriptor.extent.inside.501
  %descriptor.range.valid.504 = and i1 %descriptor.range.inside.505, %descriptor.payload.inside.502
  br i1 %descriptor.range.valid.504, label %descriptor.valid.506, label %descriptor.invalid.507
descriptor.invalid.507:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.506:
  %descriptor.initialized.status.508 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.492, i32 %local.check.extent.493)
  %helper.ok.509 = icmp eq i32 %descriptor.initialized.status.508, 0
  br i1 %helper.ok.509, label %helper.continue.510, label %frame.failure.0
helper.continue.510:
  br label %local.descriptor.checked.491
local.descriptor.inactive.490:
  br label %local.descriptor.checked.491
local.descriptor.checked.491:
  %local.is.active.511 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.511, label %local.descriptor.active.512, label %local.descriptor.inactive.513
local.descriptor.active.512:
  %local.check.offset.515 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.516 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.517 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.518 = load i32, ptr %local.owner.end.12, align 4
  %context.field.519 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.520 = load i32, ptr %context.field.519, align 4
  %stack.sub.523 = sub i32 %local.check.owner.end.518, %local.check.offset.515
  %descriptor.owner.inside.521 = icmp ule i32 %local.check.owner.end.518, %context.value.520
  %descriptor.offset.inside.522 = icmp ule i32 %local.check.offset.515, %local.check.owner.end.518
  %descriptor.extent.inside.524 = icmp ule i32 %local.check.extent.516, %stack.sub.523
  %descriptor.payload.inside.525 = icmp ule i32 %local.check.payload.517, %local.check.extent.516
  %descriptor.owner.offset.valid.526 = and i1 %descriptor.owner.inside.521, %descriptor.offset.inside.522
  %descriptor.range.inside.528 = and i1 %descriptor.owner.offset.valid.526, %descriptor.extent.inside.524
  %descriptor.range.valid.527 = and i1 %descriptor.range.inside.528, %descriptor.payload.inside.525
  br i1 %descriptor.range.valid.527, label %descriptor.valid.529, label %descriptor.invalid.530
descriptor.invalid.530:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.529:
  %descriptor.initialized.status.531 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.515, i32 %local.check.extent.516)
  %helper.ok.532 = icmp eq i32 %descriptor.initialized.status.531, 0
  br i1 %helper.ok.532, label %helper.continue.533, label %frame.failure.0
helper.continue.533:
  br label %local.descriptor.checked.514
local.descriptor.inactive.513:
  br label %local.descriptor.checked.514
local.descriptor.checked.514:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.534 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.535 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.534, i32 0, i32 0
  store i32 11, ptr %descriptor.field.535, align 4
  %descriptor.field.536 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.534, i32 0, i32 1
  store i32 %descriptor.value.441, ptr %descriptor.field.536, align 4
  %descriptor.field.537 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.534, i32 0, i32 2
  store i32 %descriptor.value.443, ptr %descriptor.field.537, align 4
  %descriptor.field.538 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.534, i32 0, i32 3
  store i32 %descriptor.value.445, ptr %descriptor.field.538, align 4
  %descriptor.field.539 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.534, i32 0, i32 4
  store i32 %descriptor.value.447, ptr %descriptor.field.539, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.441, i32 20, i32 %descriptor.value.445, i32 %descriptor.value.447, i32 %descriptor.value.443)
  %context.field.540 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.541 = load i32, ptr %context.field.540, align 4
  %runtime.ok.542 = icmp eq i32 %context.value.541, 0
  br i1 %runtime.ok.542, label %runtime.continue.543, label %frame.failure.0
runtime.continue.543:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.545 = load i32, ptr %context.field.544, align 4
  %context.field.546 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.547 = load i32, ptr %context.field.546, align 4
  %context.field.548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.549 = load i32, ptr %context.field.548, align 4
  %stack.offset.550 = add i32 %context.value.17, %context.value.19
  %stack.offset.551 = add i32 %context.value.545, %context.value.547
  %stack.sub.552 = sub i32 %stack.offset.550, %stack.offset.551
  %stack.sub.553 = sub i32 %context.value.19, %context.value.547
  %stack.sub.554 = sub i32 %context.value.549, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.552, i32 %stack.sub.553)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.554)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %host.output.extent.pointer.451 = alloca i32, align 4
  %host.output.payload.pointer.454 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 8
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %argument.type.invalid.38
argument.type.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.37:
  %context.field.39 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.40 = load i32, ptr %context.field.39, align 4
  %stack.sub.43 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.41 = icmp ule i32 %descriptor.value.35, %context.value.40
  %descriptor.offset.inside.42 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.44 = icmp ule i32 %descriptor.value.31, %stack.sub.43
  %descriptor.payload.inside.45 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.46 = and i1 %descriptor.owner.inside.41, %descriptor.offset.inside.42
  %descriptor.range.inside.48 = and i1 %descriptor.owner.offset.valid.46, %descriptor.extent.inside.44
  %descriptor.range.valid.47 = and i1 %descriptor.range.inside.48, %descriptor.payload.inside.45
  %descriptor.type.valid.49 = icmp eq i32 8, 8
  %descriptor.valid.50 = and i1 %descriptor.range.valid.47, %descriptor.type.valid.49
  br i1 %descriptor.valid.50, label %descriptor.valid.51, label %descriptor.invalid.52
descriptor.invalid.52:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.51:
  %descriptor.initialized.status.53 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.54 = icmp eq i32 %descriptor.initialized.status.53, 0
  br i1 %helper.ok.54, label %helper.continue.55, label %frame.failure.0
helper.continue.55:
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %argument.type.valid.67 = icmp eq i32 %descriptor.value.58, 5
  br i1 %argument.type.valid.67, label %argument.type.ok.68, label %argument.type.invalid.69
argument.type.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
argument.type.ok.68:
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %descriptor.value.66, %descriptor.value.60
  %descriptor.owner.inside.72 = icmp ule i32 %descriptor.value.66, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %descriptor.value.60, %descriptor.value.66
  %descriptor.extent.inside.75 = icmp ule i32 %descriptor.value.62, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %descriptor.value.64, %descriptor.value.62
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  %descriptor.type.valid.80 = icmp eq i32 5, 5
  %descriptor.valid.81 = and i1 %descriptor.range.valid.78, %descriptor.type.valid.80
  br i1 %descriptor.valid.81, label %descriptor.valid.82, label %descriptor.invalid.83
descriptor.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.82:
  %descriptor.initialized.status.84 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.60, i32 %descriptor.value.62)
  %helper.ok.85 = icmp eq i32 %descriptor.initialized.status.84, 0
  br i1 %helper.ok.85, label %helper.continue.86, label %frame.failure.0
helper.continue.86:
  %step.status.87 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.88 = icmp eq i32 %step.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.60, ptr %local.offset.3, align 4
  store i32 %descriptor.value.62, ptr %local.extent.4, align 4
  store i32 %descriptor.value.64, ptr %local.payload.5, align 4
  store i32 %descriptor.value.66, ptr %local.owner.end.6, align 4
  store i32 5, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.60, i32 20, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 %descriptor.value.62)
  %context.field.90 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.91 = load i32, ptr %context.field.90, align 4
  %runtime.ok.92 = icmp eq i32 %context.value.91, 0
  br i1 %runtime.ok.92, label %runtime.continue.93, label %frame.failure.0
runtime.continue.93:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %stack.sub.98 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.96 = icmp ule i32 %descriptor.value.35, %context.value.95
  %descriptor.offset.inside.97 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.99 = icmp ule i32 %descriptor.value.31, %stack.sub.98
  %descriptor.payload.inside.100 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.101 = and i1 %descriptor.owner.inside.96, %descriptor.offset.inside.97
  %descriptor.range.inside.103 = and i1 %descriptor.owner.offset.valid.101, %descriptor.extent.inside.99
  %descriptor.range.valid.102 = and i1 %descriptor.range.inside.103, %descriptor.payload.inside.100
  %descriptor.type.valid.104 = icmp eq i32 8, 8
  %descriptor.valid.105 = and i1 %descriptor.range.valid.102, %descriptor.type.valid.104
  br i1 %descriptor.valid.105, label %descriptor.valid.106, label %descriptor.invalid.107
descriptor.invalid.107:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.106:
  %descriptor.initialized.status.108 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.109 = icmp eq i32 %descriptor.initialized.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %local.is.active.111 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.111, label %local.descriptor.active.112, label %local.descriptor.inactive.113
local.descriptor.active.112:
  %local.check.offset.115 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.116 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.117 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.118 = load i32, ptr %local.owner.end.6, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %local.check.owner.end.118, %local.check.offset.115
  %descriptor.owner.inside.121 = icmp ule i32 %local.check.owner.end.118, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %local.check.offset.115, %local.check.owner.end.118
  %descriptor.extent.inside.124 = icmp ule i32 %local.check.extent.116, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %local.check.payload.117, %local.check.extent.116
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  br i1 %descriptor.range.valid.127, label %descriptor.valid.129, label %descriptor.invalid.130
descriptor.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.129:
  %descriptor.initialized.status.131 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.115, i32 %local.check.extent.116)
  %helper.ok.132 = icmp eq i32 %descriptor.initialized.status.131, 0
  br i1 %helper.ok.132, label %helper.continue.133, label %frame.failure.0
helper.continue.133:
  br label %local.descriptor.checked.114
local.descriptor.inactive.113:
  br label %local.descriptor.checked.114
local.descriptor.checked.114:
  %local.is.active.134 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.134, label %local.descriptor.active.135, label %local.descriptor.inactive.136
local.descriptor.active.135:
  %local.check.offset.138 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.139 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.140 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.141 = load i32, ptr %local.owner.end.12, align 4
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %stack.sub.146 = sub i32 %local.check.owner.end.141, %local.check.offset.138
  %descriptor.owner.inside.144 = icmp ule i32 %local.check.owner.end.141, %context.value.143
  %descriptor.offset.inside.145 = icmp ule i32 %local.check.offset.138, %local.check.owner.end.141
  %descriptor.extent.inside.147 = icmp ule i32 %local.check.extent.139, %stack.sub.146
  %descriptor.payload.inside.148 = icmp ule i32 %local.check.payload.140, %local.check.extent.139
  %descriptor.owner.offset.valid.149 = and i1 %descriptor.owner.inside.144, %descriptor.offset.inside.145
  %descriptor.range.inside.151 = and i1 %descriptor.owner.offset.valid.149, %descriptor.extent.inside.147
  %descriptor.range.valid.150 = and i1 %descriptor.range.inside.151, %descriptor.payload.inside.148
  br i1 %descriptor.range.valid.150, label %descriptor.valid.152, label %descriptor.invalid.153
descriptor.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.152:
  %descriptor.initialized.status.154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.138, i32 %local.check.extent.139)
  %helper.ok.155 = icmp eq i32 %descriptor.initialized.status.154, 0
  br i1 %helper.ok.155, label %helper.continue.156, label %frame.failure.0
helper.continue.156:
  br label %local.descriptor.checked.137
local.descriptor.inactive.136:
  br label %local.descriptor.checked.137
local.descriptor.checked.137:
  %step.status.157 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.158 = icmp eq i32 %step.status.157, 0
  br i1 %helper.ok.158, label %helper.continue.159, label %frame.failure.0
helper.continue.159:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.29, ptr %local.offset.9, align 4
  store i32 %descriptor.value.31, ptr %local.extent.10, align 4
  store i32 %descriptor.value.33, ptr %local.payload.11, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.12, align 4
  store i32 8, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  %local.is.active.164 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.164, label %local.descriptor.active.165, label %local.descriptor.inactive.166
local.descriptor.active.165:
  %local.check.offset.168 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.169 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.170 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.171 = load i32, ptr %local.owner.end.6, align 4
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %stack.sub.176 = sub i32 %local.check.owner.end.171, %local.check.offset.168
  %descriptor.owner.inside.174 = icmp ule i32 %local.check.owner.end.171, %context.value.173
  %descriptor.offset.inside.175 = icmp ule i32 %local.check.offset.168, %local.check.owner.end.171
  %descriptor.extent.inside.177 = icmp ule i32 %local.check.extent.169, %stack.sub.176
  %descriptor.payload.inside.178 = icmp ule i32 %local.check.payload.170, %local.check.extent.169
  %descriptor.owner.offset.valid.179 = and i1 %descriptor.owner.inside.174, %descriptor.offset.inside.175
  %descriptor.range.inside.181 = and i1 %descriptor.owner.offset.valid.179, %descriptor.extent.inside.177
  %descriptor.range.valid.180 = and i1 %descriptor.range.inside.181, %descriptor.payload.inside.178
  br i1 %descriptor.range.valid.180, label %descriptor.valid.182, label %descriptor.invalid.183
descriptor.invalid.183:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.182:
  %descriptor.initialized.status.184 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.168, i32 %local.check.extent.169)
  %helper.ok.185 = icmp eq i32 %descriptor.initialized.status.184, 0
  br i1 %helper.ok.185, label %helper.continue.186, label %frame.failure.0
helper.continue.186:
  br label %local.descriptor.checked.167
local.descriptor.inactive.166:
  br label %local.descriptor.checked.167
local.descriptor.checked.167:
  %local.is.active.187 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.187, label %local.descriptor.active.188, label %local.descriptor.inactive.189
local.descriptor.active.188:
  %local.check.offset.191 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.192 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.193 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.194 = load i32, ptr %local.owner.end.12, align 4
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %stack.sub.199 = sub i32 %local.check.owner.end.194, %local.check.offset.191
  %descriptor.owner.inside.197 = icmp ule i32 %local.check.owner.end.194, %context.value.196
  %descriptor.offset.inside.198 = icmp ule i32 %local.check.offset.191, %local.check.owner.end.194
  %descriptor.extent.inside.200 = icmp ule i32 %local.check.extent.192, %stack.sub.199
  %descriptor.payload.inside.201 = icmp ule i32 %local.check.payload.193, %local.check.extent.192
  %descriptor.owner.offset.valid.202 = and i1 %descriptor.owner.inside.197, %descriptor.offset.inside.198
  %descriptor.range.inside.204 = and i1 %descriptor.owner.offset.valid.202, %descriptor.extent.inside.200
  %descriptor.range.valid.203 = and i1 %descriptor.range.inside.204, %descriptor.payload.inside.201
  br i1 %descriptor.range.valid.203, label %descriptor.valid.205, label %descriptor.invalid.206
descriptor.invalid.206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.205:
  %descriptor.initialized.status.207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.191, i32 %local.check.extent.192)
  %helper.ok.208 = icmp eq i32 %descriptor.initialized.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  br label %local.descriptor.checked.190
local.descriptor.inactive.189:
  br label %local.descriptor.checked.190
local.descriptor.checked.190:
  %step.status.210 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.211 = icmp eq i32 %step.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  %local.resolved.offset.213 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.214 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.215 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.216 = load i32, ptr %local.owner.end.12, align 4
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %stack.sub.221 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.219 = icmp ule i32 %local.resolved.owner.end.216, %context.value.218
  %descriptor.offset.inside.220 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.222 = icmp ule i32 %local.resolved.extent.214, %stack.sub.221
  %descriptor.payload.inside.223 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.224 = and i1 %descriptor.owner.inside.219, %descriptor.offset.inside.220
  %descriptor.range.inside.226 = and i1 %descriptor.owner.offset.valid.224, %descriptor.extent.inside.222
  %descriptor.range.valid.225 = and i1 %descriptor.range.inside.226, %descriptor.payload.inside.223
  %descriptor.type.valid.227 = icmp eq i32 8, 8
  %descriptor.valid.228 = and i1 %descriptor.range.valid.225, %descriptor.type.valid.227
  br i1 %descriptor.valid.228, label %descriptor.valid.229, label %descriptor.invalid.230
descriptor.invalid.230:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.229:
  %descriptor.initialized.status.231 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.232 = icmp eq i32 %descriptor.initialized.status.231, 0
  br i1 %helper.ok.232, label %helper.continue.233, label %frame.failure.0
helper.continue.233:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.213, i32 20, i32 %local.resolved.payload.215, i32 %local.resolved.owner.end.216, i32 %local.resolved.extent.214)
  %context.field.234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.235 = load i32, ptr %context.field.234, align 4
  %runtime.ok.236 = icmp eq i32 %context.value.235, 0
  br i1 %runtime.ok.236, label %runtime.continue.237, label %frame.failure.0
runtime.continue.237:
  %context.field.238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.239 = load i32, ptr %context.field.238, align 4
  %stack.sub.242 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.240 = icmp ule i32 %local.resolved.owner.end.216, %context.value.239
  %descriptor.offset.inside.241 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.243 = icmp ule i32 %local.resolved.extent.214, %stack.sub.242
  %descriptor.payload.inside.244 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.245 = and i1 %descriptor.owner.inside.240, %descriptor.offset.inside.241
  %descriptor.range.inside.247 = and i1 %descriptor.owner.offset.valid.245, %descriptor.extent.inside.243
  %descriptor.range.valid.246 = and i1 %descriptor.range.inside.247, %descriptor.payload.inside.244
  %descriptor.type.valid.248 = icmp eq i32 8, 8
  %descriptor.valid.249 = and i1 %descriptor.range.valid.246, %descriptor.type.valid.248
  br i1 %descriptor.valid.249, label %descriptor.valid.250, label %descriptor.invalid.251
descriptor.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.250:
  %descriptor.initialized.status.252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.253 = icmp eq i32 %descriptor.initialized.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  %local.is.active.255 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.255, label %local.descriptor.active.256, label %local.descriptor.inactive.257
local.descriptor.active.256:
  %local.check.offset.259 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.260 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.261 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.262 = load i32, ptr %local.owner.end.6, align 4
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %stack.sub.267 = sub i32 %local.check.owner.end.262, %local.check.offset.259
  %descriptor.owner.inside.265 = icmp ule i32 %local.check.owner.end.262, %context.value.264
  %descriptor.offset.inside.266 = icmp ule i32 %local.check.offset.259, %local.check.owner.end.262
  %descriptor.extent.inside.268 = icmp ule i32 %local.check.extent.260, %stack.sub.267
  %descriptor.payload.inside.269 = icmp ule i32 %local.check.payload.261, %local.check.extent.260
  %descriptor.owner.offset.valid.270 = and i1 %descriptor.owner.inside.265, %descriptor.offset.inside.266
  %descriptor.range.inside.272 = and i1 %descriptor.owner.offset.valid.270, %descriptor.extent.inside.268
  %descriptor.range.valid.271 = and i1 %descriptor.range.inside.272, %descriptor.payload.inside.269
  br i1 %descriptor.range.valid.271, label %descriptor.valid.273, label %descriptor.invalid.274
descriptor.invalid.274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.273:
  %descriptor.initialized.status.275 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.259, i32 %local.check.extent.260)
  %helper.ok.276 = icmp eq i32 %descriptor.initialized.status.275, 0
  br i1 %helper.ok.276, label %helper.continue.277, label %frame.failure.0
helper.continue.277:
  br label %local.descriptor.checked.258
local.descriptor.inactive.257:
  br label %local.descriptor.checked.258
local.descriptor.checked.258:
  %local.is.active.278 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.12, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %step.status.301 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.302 = icmp eq i32 %step.status.301, 0
  br i1 %helper.ok.302, label %helper.continue.303, label %frame.failure.0
helper.continue.303:
  %local.resolved.offset.304 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.305 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.306 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.307 = load i32, ptr %local.owner.end.6, align 4
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %stack.sub.312 = sub i32 %local.resolved.owner.end.307, %local.resolved.offset.304
  %descriptor.owner.inside.310 = icmp ule i32 %local.resolved.owner.end.307, %context.value.309
  %descriptor.offset.inside.311 = icmp ule i32 %local.resolved.offset.304, %local.resolved.owner.end.307
  %descriptor.extent.inside.313 = icmp ule i32 %local.resolved.extent.305, %stack.sub.312
  %descriptor.payload.inside.314 = icmp ule i32 %local.resolved.payload.306, %local.resolved.extent.305
  %descriptor.owner.offset.valid.315 = and i1 %descriptor.owner.inside.310, %descriptor.offset.inside.311
  %descriptor.range.inside.317 = and i1 %descriptor.owner.offset.valid.315, %descriptor.extent.inside.313
  %descriptor.range.valid.316 = and i1 %descriptor.range.inside.317, %descriptor.payload.inside.314
  %descriptor.type.valid.318 = icmp eq i32 5, 5
  %descriptor.valid.319 = and i1 %descriptor.range.valid.316, %descriptor.type.valid.318
  br i1 %descriptor.valid.319, label %descriptor.valid.320, label %descriptor.invalid.321
descriptor.invalid.321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.320:
  %descriptor.initialized.status.322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.304, i32 %local.resolved.extent.305)
  %helper.ok.323 = icmp eq i32 %descriptor.initialized.status.322, 0
  br i1 %helper.ok.323, label %helper.continue.324, label %frame.failure.0
helper.continue.324:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.304, i32 20, i32 %local.resolved.payload.306, i32 %local.resolved.owner.end.307, i32 %local.resolved.extent.305)
  %context.field.325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.326 = load i32, ptr %context.field.325, align 4
  %runtime.ok.327 = icmp eq i32 %context.value.326, 0
  br i1 %runtime.ok.327, label %runtime.continue.328, label %frame.failure.0
runtime.continue.328:
  %context.field.329 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.330 = load i32, ptr %context.field.329, align 4
  %stack.sub.333 = sub i32 %local.resolved.owner.end.216, %local.resolved.offset.213
  %descriptor.owner.inside.331 = icmp ule i32 %local.resolved.owner.end.216, %context.value.330
  %descriptor.offset.inside.332 = icmp ule i32 %local.resolved.offset.213, %local.resolved.owner.end.216
  %descriptor.extent.inside.334 = icmp ule i32 %local.resolved.extent.214, %stack.sub.333
  %descriptor.payload.inside.335 = icmp ule i32 %local.resolved.payload.215, %local.resolved.extent.214
  %descriptor.owner.offset.valid.336 = and i1 %descriptor.owner.inside.331, %descriptor.offset.inside.332
  %descriptor.range.inside.338 = and i1 %descriptor.owner.offset.valid.336, %descriptor.extent.inside.334
  %descriptor.range.valid.337 = and i1 %descriptor.range.inside.338, %descriptor.payload.inside.335
  %descriptor.type.valid.339 = icmp eq i32 8, 8
  %descriptor.valid.340 = and i1 %descriptor.range.valid.337, %descriptor.type.valid.339
  br i1 %descriptor.valid.340, label %descriptor.valid.341, label %descriptor.invalid.342
descriptor.invalid.342:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.341:
  %descriptor.initialized.status.343 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214)
  %helper.ok.344 = icmp eq i32 %descriptor.initialized.status.343, 0
  br i1 %helper.ok.344, label %helper.continue.345, label %frame.failure.0
helper.continue.345:
  %context.field.346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.347 = load i32, ptr %context.field.346, align 4
  %stack.sub.350 = sub i32 %local.resolved.owner.end.307, %local.resolved.offset.304
  %descriptor.owner.inside.348 = icmp ule i32 %local.resolved.owner.end.307, %context.value.347
  %descriptor.offset.inside.349 = icmp ule i32 %local.resolved.offset.304, %local.resolved.owner.end.307
  %descriptor.extent.inside.351 = icmp ule i32 %local.resolved.extent.305, %stack.sub.350
  %descriptor.payload.inside.352 = icmp ule i32 %local.resolved.payload.306, %local.resolved.extent.305
  %descriptor.owner.offset.valid.353 = and i1 %descriptor.owner.inside.348, %descriptor.offset.inside.349
  %descriptor.range.inside.355 = and i1 %descriptor.owner.offset.valid.353, %descriptor.extent.inside.351
  %descriptor.range.valid.354 = and i1 %descriptor.range.inside.355, %descriptor.payload.inside.352
  %descriptor.type.valid.356 = icmp eq i32 5, 5
  %descriptor.valid.357 = and i1 %descriptor.range.valid.354, %descriptor.type.valid.356
  br i1 %descriptor.valid.357, label %descriptor.valid.358, label %descriptor.invalid.359
descriptor.invalid.359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.358:
  %descriptor.initialized.status.360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.304, i32 %local.resolved.extent.305)
  %helper.ok.361 = icmp eq i32 %descriptor.initialized.status.360, 0
  br i1 %helper.ok.361, label %helper.continue.362, label %frame.failure.0
helper.continue.362:
  %local.is.active.363 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.363, label %local.descriptor.active.364, label %local.descriptor.inactive.365
local.descriptor.active.364:
  %local.check.offset.367 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.368 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.369 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.370 = load i32, ptr %local.owner.end.6, align 4
  %context.field.371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.372 = load i32, ptr %context.field.371, align 4
  %stack.sub.375 = sub i32 %local.check.owner.end.370, %local.check.offset.367
  %descriptor.owner.inside.373 = icmp ule i32 %local.check.owner.end.370, %context.value.372
  %descriptor.offset.inside.374 = icmp ule i32 %local.check.offset.367, %local.check.owner.end.370
  %descriptor.extent.inside.376 = icmp ule i32 %local.check.extent.368, %stack.sub.375
  %descriptor.payload.inside.377 = icmp ule i32 %local.check.payload.369, %local.check.extent.368
  %descriptor.owner.offset.valid.378 = and i1 %descriptor.owner.inside.373, %descriptor.offset.inside.374
  %descriptor.range.inside.380 = and i1 %descriptor.owner.offset.valid.378, %descriptor.extent.inside.376
  %descriptor.range.valid.379 = and i1 %descriptor.range.inside.380, %descriptor.payload.inside.377
  br i1 %descriptor.range.valid.379, label %descriptor.valid.381, label %descriptor.invalid.382
descriptor.invalid.382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.381:
  %descriptor.initialized.status.383 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.367, i32 %local.check.extent.368)
  %helper.ok.384 = icmp eq i32 %descriptor.initialized.status.383, 0
  br i1 %helper.ok.384, label %helper.continue.385, label %frame.failure.0
helper.continue.385:
  br label %local.descriptor.checked.366
local.descriptor.inactive.365:
  br label %local.descriptor.checked.366
local.descriptor.checked.366:
  %local.is.active.386 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.386, label %local.descriptor.active.387, label %local.descriptor.inactive.388
local.descriptor.active.387:
  %local.check.offset.390 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.391 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.392 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.393 = load i32, ptr %local.owner.end.12, align 4
  %context.field.394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.395 = load i32, ptr %context.field.394, align 4
  %stack.sub.398 = sub i32 %local.check.owner.end.393, %local.check.offset.390
  %descriptor.owner.inside.396 = icmp ule i32 %local.check.owner.end.393, %context.value.395
  %descriptor.offset.inside.397 = icmp ule i32 %local.check.offset.390, %local.check.owner.end.393
  %descriptor.extent.inside.399 = icmp ule i32 %local.check.extent.391, %stack.sub.398
  %descriptor.payload.inside.400 = icmp ule i32 %local.check.payload.392, %local.check.extent.391
  %descriptor.owner.offset.valid.401 = and i1 %descriptor.owner.inside.396, %descriptor.offset.inside.397
  %descriptor.range.inside.403 = and i1 %descriptor.owner.offset.valid.401, %descriptor.extent.inside.399
  %descriptor.range.valid.402 = and i1 %descriptor.range.inside.403, %descriptor.payload.inside.400
  br i1 %descriptor.range.valid.402, label %descriptor.valid.404, label %descriptor.invalid.405
descriptor.invalid.405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.404:
  %descriptor.initialized.status.406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.390, i32 %local.check.extent.391)
  %helper.ok.407 = icmp eq i32 %descriptor.initialized.status.406, 0
  br i1 %helper.ok.407, label %helper.continue.408, label %frame.failure.0
helper.continue.408:
  br label %local.descriptor.checked.389
local.descriptor.inactive.388:
  br label %local.descriptor.checked.389
local.descriptor.checked.389:
  %step.status.409 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.410 = icmp eq i32 %step.status.409, 0
  br i1 %helper.ok.410, label %helper.continue.411, label %frame.failure.0
helper.continue.411:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %local.resolved.offset.304, i32 %local.resolved.extent.305, i32 %local.resolved.payload.306, i32 0, i32 0)
  %context.field.412 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.413 = load i32, ptr %context.field.412, align 4
  %runtime.ok.414 = icmp eq i32 %context.value.413, 0
  br i1 %runtime.ok.414, label %runtime.continue.415, label %frame.failure.0
runtime.continue.415:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %local.resolved.offset.213, i32 %local.resolved.extent.214, i32 %local.resolved.payload.215, i32 0, i32 0)
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %runtime.ok.418 = icmp eq i32 %context.value.417, 0
  br i1 %runtime.ok.418, label %runtime.continue.419, label %frame.failure.0
runtime.continue.419:
  %host.user.id.420 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.213)
  %context.field.422 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.423 = load i32, ptr %context.field.422, align 4
  %runtime.ok.424 = icmp eq i32 %context.value.423, 0
  br i1 %runtime.ok.424, label %runtime.continue.425, label %frame.failure.0
runtime.continue.425:
  %host.room.id.421 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.304)
  %context.field.426 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.427 = load i32, ptr %context.field.426, align 4
  %runtime.ok.428 = icmp eq i32 %context.value.427, 0
  br i1 %runtime.ok.428, label %runtime.continue.429, label %frame.failure.0
runtime.continue.429:
  %context.field.430 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.431 = load i32, ptr %context.field.430, align 4
  %context.field.432 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 1
  %context.value.433 = load i32, ptr %context.field.432, align 4
  %stack.sub.434 = sub i32 %context.value.433, %context.value.431
  %host.output.below.limit.435 = icmp ult i32 %stack.sub.434, 65536
  %host.output.capacity.436 = select i1 %host.output.below.limit.435, i32 %stack.sub.434, i32 65536
  %host.output.minimum.fits.437 = icmp uge i32 %host.output.capacity.436, 16
  br i1 %host.output.minimum.fits.437, label %host.output.minimum.fits.438, label %host.output.minimum.too.small.439
host.output.minimum.too.small.439:
  %stack.offset.440 = add i32 %context.value.431, 16
  %reserve.status.441 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.440, i32 14)
  %reserve.ok.442 = icmp eq i32 %reserve.status.441, 0
  br i1 %reserve.ok.442, label %reserve.continue.443, label %frame.failure.0
reserve.continue.443:
  br label %frame.failure.0
host.output.minimum.fits.438:
  %stack.offset.444 = add i32 %context.value.431, %host.output.capacity.436
  %reserve.status.445 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.444, i32 15)
  %reserve.ok.446 = icmp eq i32 %reserve.status.445, 0
  br i1 %reserve.ok.446, label %reserve.continue.447, label %frame.failure.0
reserve.continue.447:
  %host.stack.data.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 25
  %host.stack.data.449 = load ptr, ptr %host.stack.data.field.448, align 8
  %host.output.pointer.450 = getelementptr inbounds i8, ptr %host.stack.data.449, i32 %context.value.431
  store i32 0, ptr %host.output.extent.pointer.451, align 4
  %host.call.status.452 = call i32 @al_host_campfire_rooms_find_for_user_v1(ptr %provider.context, i64 %host.user.id.420, i64 %host.room.id.421, ptr %host.output.pointer.450, i32 %host.output.capacity.436, ptr %host.output.extent.pointer.451)
  %host.output.extent.453 = load i32, ptr %host.output.extent.pointer.451, align 4
  store i32 0, ptr %host.output.payload.pointer.454, align 4
  %host.output.commit.status.456 = call i32 @al_owning_commit_host_output(ptr %ctx, ptr @al_owning_layout, i32 7, i32 %context.value.431, i32 %stack.offset.444, i32 %host.output.extent.453, i32 %host.call.status.452, i32 16, ptr %host.output.payload.pointer.454)
  %helper.ok.457 = icmp eq i32 %host.output.commit.status.456, 0
  br i1 %helper.ok.457, label %helper.continue.458, label %frame.failure.0
helper.continue.458:
  %host.output.payload.455 = load i32, ptr %host.output.payload.pointer.454, align 4
  %stack.offset.459 = add i32 %context.value.431, %host.output.extent.453
  %context.field.460 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.461 = load i32, ptr %context.field.460, align 4
  %stack.sub.464 = sub i32 %stack.offset.459, %context.value.431
  %descriptor.owner.inside.462 = icmp ule i32 %stack.offset.459, %context.value.461
  %descriptor.offset.inside.463 = icmp ule i32 %context.value.431, %stack.offset.459
  %descriptor.extent.inside.465 = icmp ule i32 %host.output.extent.453, %stack.sub.464
  %descriptor.payload.inside.466 = icmp ule i32 %host.output.payload.455, %host.output.extent.453
  %descriptor.owner.offset.valid.467 = and i1 %descriptor.owner.inside.462, %descriptor.offset.inside.463
  %descriptor.range.inside.469 = and i1 %descriptor.owner.offset.valid.467, %descriptor.extent.inside.465
  %descriptor.range.valid.468 = and i1 %descriptor.range.inside.469, %descriptor.payload.inside.466
  %descriptor.type.valid.470 = icmp eq i32 11, 11
  %descriptor.valid.471 = and i1 %descriptor.range.valid.468, %descriptor.type.valid.470
  br i1 %descriptor.valid.471, label %descriptor.valid.472, label %descriptor.invalid.473
descriptor.invalid.473:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.472:
  %descriptor.initialized.status.474 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.431, i32 %host.output.extent.453)
  %helper.ok.475 = icmp eq i32 %descriptor.initialized.status.474, 0
  br i1 %helper.ok.475, label %helper.continue.476, label %frame.failure.0
helper.continue.476:
  %local.is.active.477 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.477, label %local.descriptor.active.478, label %local.descriptor.inactive.479
local.descriptor.active.478:
  %local.check.offset.481 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.482 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.483 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.484 = load i32, ptr %local.owner.end.6, align 4
  %context.field.485 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.486 = load i32, ptr %context.field.485, align 4
  %stack.sub.489 = sub i32 %local.check.owner.end.484, %local.check.offset.481
  %descriptor.owner.inside.487 = icmp ule i32 %local.check.owner.end.484, %context.value.486
  %descriptor.offset.inside.488 = icmp ule i32 %local.check.offset.481, %local.check.owner.end.484
  %descriptor.extent.inside.490 = icmp ule i32 %local.check.extent.482, %stack.sub.489
  %descriptor.payload.inside.491 = icmp ule i32 %local.check.payload.483, %local.check.extent.482
  %descriptor.owner.offset.valid.492 = and i1 %descriptor.owner.inside.487, %descriptor.offset.inside.488
  %descriptor.range.inside.494 = and i1 %descriptor.owner.offset.valid.492, %descriptor.extent.inside.490
  %descriptor.range.valid.493 = and i1 %descriptor.range.inside.494, %descriptor.payload.inside.491
  br i1 %descriptor.range.valid.493, label %descriptor.valid.495, label %descriptor.invalid.496
descriptor.invalid.496:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.495:
  %descriptor.initialized.status.497 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.481, i32 %local.check.extent.482)
  %helper.ok.498 = icmp eq i32 %descriptor.initialized.status.497, 0
  br i1 %helper.ok.498, label %helper.continue.499, label %frame.failure.0
helper.continue.499:
  br label %local.descriptor.checked.480
local.descriptor.inactive.479:
  br label %local.descriptor.checked.480
local.descriptor.checked.480:
  %local.is.active.500 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.500, label %local.descriptor.active.501, label %local.descriptor.inactive.502
local.descriptor.active.501:
  %local.check.offset.504 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.505 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.506 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.507 = load i32, ptr %local.owner.end.12, align 4
  %context.field.508 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.509 = load i32, ptr %context.field.508, align 4
  %stack.sub.512 = sub i32 %local.check.owner.end.507, %local.check.offset.504
  %descriptor.owner.inside.510 = icmp ule i32 %local.check.owner.end.507, %context.value.509
  %descriptor.offset.inside.511 = icmp ule i32 %local.check.offset.504, %local.check.owner.end.507
  %descriptor.extent.inside.513 = icmp ule i32 %local.check.extent.505, %stack.sub.512
  %descriptor.payload.inside.514 = icmp ule i32 %local.check.payload.506, %local.check.extent.505
  %descriptor.owner.offset.valid.515 = and i1 %descriptor.owner.inside.510, %descriptor.offset.inside.511
  %descriptor.range.inside.517 = and i1 %descriptor.owner.offset.valid.515, %descriptor.extent.inside.513
  %descriptor.range.valid.516 = and i1 %descriptor.range.inside.517, %descriptor.payload.inside.514
  br i1 %descriptor.range.valid.516, label %descriptor.valid.518, label %descriptor.invalid.519
descriptor.invalid.519:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.518:
  %descriptor.initialized.status.520 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.504, i32 %local.check.extent.505)
  %helper.ok.521 = icmp eq i32 %descriptor.initialized.status.520, 0
  br i1 %helper.ok.521, label %helper.continue.522, label %frame.failure.0
helper.continue.522:
  br label %local.descriptor.checked.503
local.descriptor.inactive.502:
  br label %local.descriptor.checked.503
local.descriptor.checked.503:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.523 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.524 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.523, i32 0, i32 0
  store i32 11, ptr %descriptor.field.524, align 4
  %descriptor.field.525 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.523, i32 0, i32 1
  store i32 %context.value.431, ptr %descriptor.field.525, align 4
  %descriptor.field.526 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.523, i32 0, i32 2
  store i32 %host.output.extent.453, ptr %descriptor.field.526, align 4
  %descriptor.field.527 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.523, i32 0, i32 3
  store i32 %host.output.payload.455, ptr %descriptor.field.527, align 4
  %descriptor.field.528 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.523, i32 0, i32 4
  store i32 %stack.offset.459, ptr %descriptor.field.528, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %context.value.431, i32 20, i32 %host.output.payload.455, i32 %stack.offset.459, i32 %host.output.extent.453)
  %context.field.529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.530 = load i32, ptr %context.field.529, align 4
  %runtime.ok.531 = icmp eq i32 %context.value.530, 0
  br i1 %runtime.ok.531, label %runtime.continue.532, label %frame.failure.0
runtime.continue.532:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.533 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.534 = load i32, ptr %context.field.533, align 4
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %context.field.537 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.538 = load i32, ptr %context.field.537, align 4
  %stack.offset.539 = add i32 %context.value.17, %context.value.19
  %stack.offset.540 = add i32 %context.value.534, %context.value.536
  %stack.sub.541 = sub i32 %stack.offset.539, %stack.offset.540
  %stack.sub.542 = sub i32 %context.value.19, %context.value.536
  %stack.sub.543 = sub i32 %context.value.538, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.541, i32 %stack.sub.542)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.543)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute_with_host_context(ptr %ctx, ptr %provider.context, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.18 = alloca [2 x %AlOwningDescriptor], align 4
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.payload.pointer.48 = alloca i32, align 4
  %input.measured.extent.pointer.49 = alloca i32, align 4
  %entry.output.descriptors.95 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.host.context.present.7 = icmp ne ptr %provider.context, null
  br i1 %entry.host.context.present.7, label %entry.host.context.ok.8, label %entry.host.context.missing.9
entry.host.context.missing.9:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %entry.failure.0
entry.host.context.ok.8:
  %entry.input.count.ok.10 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.10, label %entry.input.counted.11, label %entry.input.count.failure.12
entry.input.count.failure.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.11:
  %entry.input.extents.present.13 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.14 = icmp ne ptr %input, null
  %entry.input.pointers.present.15 = and i1 %entry.input.extents.present.13, %entry.input.bytes.present.14
  br i1 %entry.input.pointers.present.15, label %entry.input.pointers.ok.16, label %entry.input.pointers.invalid.17
entry.input.pointers.invalid.17:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.16:
  %input.extent.pointer.19 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.20 = load i32, ptr %input.extent.pointer.19, align 4
  %stack.sub.21 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.22 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.23 = icmp ule i32 %input.host.extent.20, %stack.sub.21
  %input.slice.within.bytes.24 = and i1 %input.offset.within.bytes.22, %input.extent.within.bytes.23
  br i1 %input.slice.within.bytes.24, label %input.slice.ready.25, label %input.slice.invalid.26
input.slice.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.25:
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.27, i32 %input.host.extent.20, i32 0, i32 18, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.20
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 %input.measured.extent.34, i32 %input.host.extent.20)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 0, %input.host.extent.20
  %input.extent.pointer.39 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.40 = load i32, ptr %input.extent.pointer.39, align 4
  %stack.sub.41 = sub i32 %input.bytes, %stack.offset.38
  %input.offset.within.bytes.42 = icmp ule i32 %stack.offset.38, %input.bytes
  %input.extent.within.bytes.43 = icmp ule i32 %input.host.extent.40, %stack.sub.41
  %input.slice.within.bytes.44 = and i1 %input.offset.within.bytes.42, %input.extent.within.bytes.43
  br i1 %input.slice.within.bytes.44, label %input.slice.ready.45, label %input.slice.invalid.46
input.slice.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 19, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.45:
  %host.pointer.47 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.measure.status.50 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.47, i32 %input.host.extent.40, i32 0, i32 19, ptr %input.payload.pointer.48, ptr %input.measured.extent.pointer.49)
  %helper.ok.51 = icmp eq i32 %input.measure.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %entry.failure.0
helper.continue.52:
  %input.measured.payload.53 = load i32, ptr %input.payload.pointer.48, align 4
  %input.measured.extent.54 = load i32, ptr %input.measured.extent.pointer.49, align 4
  %input.extent.exact.55 = icmp eq i32 %input.measured.extent.54, %input.host.extent.40
  br i1 %input.extent.exact.55, label %input.extent.exact.56, label %input.extent.invalid.57
input.extent.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 19, i32 %input.measured.extent.54, i32 %input.host.extent.40)
  br label %entry.failure.0
input.extent.exact.56:
  %stack.offset.58 = add i32 %stack.offset.38, %input.host.extent.40
  %input.total.exact.59 = icmp eq i32 %stack.offset.58, %input.bytes
  br i1 %input.total.exact.59, label %input.valid.60, label %input.invalid.61
input.invalid.61:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.58, i32 %input.bytes)
  br label %entry.failure.0
input.valid.60:
  %reserve.status.62 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.58, i32 20)
  %reserve.ok.63 = icmp eq i32 %reserve.status.62, 0
  br i1 %reserve.ok.63, label %reserve.continue.64, label %entry.failure.0
reserve.continue.64:
  %host.pointer.65 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.65, i32 %input.host.extent.20, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.20, i32 8, i32 21)
  %helper.ok.67 = icmp eq i32 %input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %entry.failure.0
helper.continue.68:
  %stack.offset.69 = add i32 0, %input.host.extent.20
  %descriptor.element.70 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.18, i32 0
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 0
  store i32 8, ptr %descriptor.field.71, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 1
  store i32 0, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 2
  store i32 %input.host.extent.20, ptr %descriptor.field.73, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 4
  store i32 %stack.offset.69, ptr %descriptor.field.75, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.69, i32 %input.host.extent.20)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %entry.failure.0
runtime.continue.79:
  %host.pointer.80 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.copy.status.81 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.38, ptr %host.pointer.80, i32 %input.host.extent.40, i32 0, i32 %input.measured.payload.53, i32 %input.host.extent.40, i32 5, i32 22)
  %helper.ok.82 = icmp eq i32 %input.copy.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %entry.failure.0
helper.continue.83:
  %stack.offset.84 = add i32 %stack.offset.38, %input.host.extent.40
  %descriptor.element.85 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.18, i32 1
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 0
  store i32 5, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 1
  store i32 %stack.offset.38, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 2
  store i32 %input.host.extent.40, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 3
  store i32 %input.measured.payload.53, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 4
  store i32 %stack.offset.84, ptr %descriptor.field.90, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.38, i32 20, i32 %input.measured.payload.53, i32 %stack.offset.84, i32 %input.host.extent.40)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %entry.body.status.96 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %provider.context, ptr %entry.input.descriptors.18, ptr %entry.output.descriptors.95, i32 23)
  %entry.body.ok.97 = icmp eq i32 %entry.body.status.96, 0
  br i1 %entry.body.ok.97, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.98 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.95, i32 0
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 0
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 1
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 2
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 3
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %descriptor.field.107 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 4
  %descriptor.value.108 = load i32, ptr %descriptor.field.107, align 4
  %entry.output.type.valid.109 = icmp eq i32 %descriptor.value.100, 11
  br i1 %entry.output.type.valid.109, label %entry.output.type.ok.110, label %entry.output.type.invalid.111
entry.output.type.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.110:
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %descriptor.value.108, %descriptor.value.102
  %descriptor.owner.inside.114 = icmp ule i32 %descriptor.value.108, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %descriptor.value.102, %descriptor.value.108
  %descriptor.extent.inside.117 = icmp ule i32 %descriptor.value.104, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %descriptor.value.106, %descriptor.value.104
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 11, 11
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.102, i32 %descriptor.value.104)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %entry.failure.0
helper.continue.128:
  %entry.output.size.i64.129 = zext i32 %descriptor.value.104 to i64
  %entry.output.total.i64.130 = add i64 0, %entry.output.size.i64.129
  %entry.retained.capacity.i64.131 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.132 = icmp ule i64 %entry.output.total.i64.130, 4294967295
  %entry.retained.required.truncated.133 = trunc i64 %entry.output.total.i64.130 to i32
  %entry.retained.required.134 = select i1 %entry.retained.required.fits.u32.132, i32 %entry.retained.required.truncated.133, i32 4294967295
  %entry.retained.capacity.ok.135 = icmp ule i64 %entry.output.total.i64.130, %entry.retained.capacity.i64.131
  br i1 %entry.retained.capacity.ok.135, label %entry.retained.capacity.ready.136, label %entry.retained.capacity.failure.137
entry.retained.capacity.failure.137:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.134, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.136:
  %host.pointer.138 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.139 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.138, i32 %stack.sub.139, i32 %descriptor.value.102, i32 %descriptor.value.104, i32 11)
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %runtime.ok.142 = icmp eq i32 %context.value.141, 0
  br i1 %runtime.ok.142, label %runtime.continue.143, label %entry.failure.0
runtime.continue.143:
  %stack.offset.144 = add i32 0, %descriptor.value.104
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %stack.sub.149 = sub i32 0, %context.value.146
  %stack.sub.150 = sub i32 0, %context.value.148
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.149, i32 %stack.sub.150)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %entry.failure.0
runtime.continue.154:
  br label %entry.return.status
entry.failure.0:
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %stack.offset.161 = add i32 %context.value.156, %context.value.158
  %stack.sub.162 = sub i32 0, %stack.offset.161
  %stack.sub.163 = sub i32 0, %context.value.158
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.162, i32 %stack.sub.163)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.160)
  br label %entry.return.status
entry.return.status:
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  ret i32 %context.value.165
}


#include "D:/code/AgentLang/applications/campfire/Native/room_read_adapter.c"
#include "D:/code/AgentLang/applications/campfire/Native/room_read_pure.c"

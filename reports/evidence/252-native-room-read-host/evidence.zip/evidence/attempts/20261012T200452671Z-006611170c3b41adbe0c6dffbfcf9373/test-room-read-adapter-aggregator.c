#line 1 "room_read_adapter.c"
#include "room_read_adapter.h"
#include "room_read_pure.h"
#include "room_read_sqlite_subset.h"

#include <limits.h>
#include <stddef.h>

#if !defined(_WIN32)
#error "The Campfire native room-read adapter currently requires Windows x64."
#endif

#define SQLITE_BUSY_TIMEOUT_MS 5000
#define SQLITE_MINIMUM_VERSION_NUMBER 3051003
#define SQLITE_SYNCHRONOUS_FULL 2
#define SQLITE_SYNCHRONOUS_EXTRA 3
#define WAL_AUTO_CHECKPOINT_PAGES 1000
#define SQLITE_OPEN_FLAGS \
  (SQLITE_OPEN_READWRITE | SQLITE_OPEN_NOMUTEX | SQLITE_OPEN_PRIVATECACHE)
#define ROOM_READ_CONTEXT_COOKIE UINT64_C(0x4346525245414431)
#define HOST_BOUNDARY_FAILURE 1
#define MAX_LAYOUT_DEPTH 64u
#define MAX_LAST_PAGE_ROWS 40u
#define UNIX_MICROS_PER_SECOND INT64_C(1000000)
#define UNIX_MICROS_PER_MINUTE (INT64_C(60) * UNIX_MICROS_PER_SECOND)
#define UNIX_MICROS_PER_DAY (INT64_C(86400) * UNIX_MICROS_PER_SECOND)
#define UNIX_EPOCH_TICKS INT64_C(621355968000000000)
#define DATETIME_MAX_TICKS INT64_C(3155378975999999999)
#define UtcInstant_MIN_MICROS INT64_C(-62135596800000000)
#define UtcInstant_MAX_MICROS INT64_C(253402300799999999)
#define ROOM_READ_CONTEXT_STATE_ACTIVE 1u
#define ROOM_READ_CONTEXT_STATE_POISONED 2u

extern __declspec(dllimport) unsigned long __stdcall GetCurrentThreadId(void);

static const char *const room_read_queries[AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT] = {
    "SELECT id, user_id, token, ip_address, user_agent, last_active_at, "
    "created_at, updated_at FROM sessions WHERE token = $token LIMIT 1",
    "SELECT id, user_id, token, ip_address, user_agent, last_active_at, "
    "created_at, updated_at FROM sessions WHERE id = $sessionId LIMIT 1",
    "UPDATE sessions SET ip_address = $ipAddress, user_agent = $userAgent, "
    "last_active_at = $now, updated_at = $now "
    "WHERE id = $sessionId AND last_active_at = $observedLastActiveAt",
    "SELECT id, name, role, status FROM users WHERE id = $userId LIMIT 1",
    "SELECT id, name, role, status FROM users "
    "WHERE status = 0 AND role = 2 AND id = $id AND bot_token = $token LIMIT 1",
    "SELECT rooms.id, rooms.name, rooms.type, rooms.creator_id, "
    "rooms.created_at, rooms.updated_at "
    "FROM rooms INNER JOIN memberships ON rooms.id = memberships.room_id "
    "WHERE memberships.user_id = $userId AND rooms.id = $roomId LIMIT 1",
    "SELECT EXISTS (SELECT 1 FROM \"memberships\" "
    "WHERE \"user_id\" = $userId AND \"room_id\" = $roomId)",
    "SELECT EXISTS (SELECT 1 FROM \"rooms\" WHERE \"id\" = $roomId)",
    "SELECT messages.id, messages.room_id, messages.creator_id, "
    "messages.client_message_id, rich_text.body, messages.created_at, "
    "messages.updated_at FROM messages LEFT JOIN action_text_rich_texts "
    "AS rich_text ON rich_text.record_id = messages.id AND "
    "rich_text.record_type = 'Message' AND rich_text.name = 'body' "
    "WHERE messages.room_id = $roomId "
    "ORDER BY messages.created_at DESC LIMIT 40",
    "BEGIN DEFERRED",
    "BEGIN IMMEDIATE",
    "COMMIT",
    "ROLLBACK"};

typedef struct al_room_read_text {
  const uint8_t *bytes;
  uint32_t code_units;
} al_room_read_text;

typedef struct al_room_read_session_row {
  int64_t id;
  int64_t user_id;
  al_room_read_text token;
  int ip_state;
  al_room_read_text ip_address;
  int agent_state;
  al_room_read_text user_agent;
  al_room_read_text last_active_at_text;
  al_room_read_text created_at_text;
  al_room_read_text updated_at_text;
  int64_t last_active_at_micros;
  int64_t created_at_micros;
  int64_t updated_at_micros;
  const uint16_t *observed_last_active_at;
  int observed_last_active_bytes;
} al_room_read_session_row;

typedef struct al_room_read_user_row {
  int64_t id;
  al_room_read_text name;
  uint32_t role;
  uint32_t status;
} al_room_read_user_row;

typedef struct al_room_read_room_row {
  int64_t id;
  int name_state;
  al_room_read_text name;
  uint32_t kind;
  int64_t creator_id;
  al_room_read_text created_at;
  al_room_read_text updated_at;
} al_room_read_room_row;

typedef struct al_room_read_message_row {
  int64_t id;
  int64_t room_id;
  int64_t creator_id;
  al_room_read_text client_message_id;
  int body_state;
  al_room_read_text body;
  al_room_read_text created_at;
  al_room_read_text updated_at;
} al_room_read_message_row;

typedef struct al_room_read_refresh_input {
  int64_t session_id;
  int64_t cutoff;
  int64_t now;
  const uint8_t *ip_option;
  uint32_t ip_option_extent;
  const uint8_t *agent_option;
  uint32_t agent_option_extent;
} al_room_read_refresh_input;

typedef struct al_room_read_message_extent {
  uint32_t extent;
  uint32_t output_offset;
  int64_t message_id;
} al_room_read_message_extent;

static void clear_bytes(void *memory, size_t count) {
  volatile uint8_t *bytes = (volatile uint8_t *)memory;
  size_t index;
  for (index = 0u; index < count; ++index)
    bytes[index] = 0u;
}

static uint64_t load_u64_le(const uint8_t *bytes) {
  uint64_t value = 0u;
  uint32_t index;
  for (index = 0u; index < 8u; ++index)
    value |= (uint64_t)bytes[index] << (index * 8u);
  return value;
}

static uint16_t load_u16_le(const uint8_t *bytes) {
  return (uint16_t)((uint16_t)bytes[0] | ((uint16_t)bytes[1] << 8u));
}

static void store_u64_le(uint8_t *output, uint32_t offset, uint64_t value) {
  uint32_t index;
  for (index = 0u; index < 8u; ++index)
    output[offset + index] = (uint8_t)(value >> (index * 8u));
}

static uint32_t padded_string_extent(uint32_t code_units) {
  uint64_t raw = UINT64_C(8) + (uint64_t)code_units * UINT64_C(2);
  uint64_t padded = (raw + UINT64_C(7)) & ~UINT64_C(7);
  if (padded > UINT32_MAX)
    return 0u;
  return (uint32_t)padded;
}

static int measure_value(const al_owning_layout *layout, uint32_t type_index,
                         const uint8_t *data, uint32_t available,
                         uint32_t *out_extent, uint32_t depth);

static int valid_layout(const al_owning_layout *layout) {
  return layout != NULL &&
         layout->abi_version == AL_OWNING_LAYOUT_ABI_VERSION &&
         layout->type_count != 0u &&
         layout->type_count <= AL_OWNING_LAYOUT_MAX_TYPES &&
         layout->types != NULL &&
         layout->field_count <= AL_OWNING_LAYOUT_MAX_FIELDS &&
         (layout->field_count == 0u || layout->fields != NULL);
}

static int get_type(const al_owning_layout *layout, uint32_t type_index,
                    const al_owning_type_descriptor **out_type) {
  if (!valid_layout(layout) || type_index >= layout->type_count)
    return 0;
  *out_type = &layout->types[type_index];
  return 1;
}

static int get_field(const al_owning_layout *layout,
                     const al_owning_type_descriptor *type,
                     uint32_t field_index,
                     const al_owning_field_descriptor **out_field) {
  uint64_t index = (uint64_t)type->first_field + field_index;
  if (field_index >= type->field_count || index >= layout->field_count)
    return 0;
  *out_field = &layout->fields[(uint32_t)index];
  return 1;
}

static int measure_value(const al_owning_layout *layout, uint32_t type_index,
                         const uint8_t *data, uint32_t available,
                         uint32_t *out_extent, uint32_t depth) {
  const al_owning_type_descriptor *type;
  uint32_t extent = 0u;
  uint32_t index;
  if (data == NULL || out_extent == NULL || depth >= MAX_LAYOUT_DEPTH ||
      !get_type(layout, type_index, &type))
    return 0;

  switch (type->kind) {
  case AL_OWNING_TYPE_I64:
  case AL_OWNING_TYPE_BOOL:
  case AL_OWNING_TYPE_UNIT:
  case AL_OWNING_TYPE_F64:
    if (type->fixed_extent_bytes != 8u || available < 8u)
      return 0;
    if (type->kind == AL_OWNING_TYPE_BOOL && load_u64_le(data) > 1u)
      return 0;
    extent = 8u;
    break;
  case AL_OWNING_TYPE_ENUM:
    if (type->fixed_extent_bytes != 8u || type->case_count == 0u ||
        type->case_count > 64u || available < 8u ||
        load_u64_le(data) >= type->case_count)
      return 0;
    extent = 8u;
    break;
  case AL_OWNING_TYPE_STRING: {
    uint64_t code_units;
    uint64_t raw;
    uint64_t padded;
    uint32_t pad_index;
    if (available < 8u)
      return 0;
    code_units = load_u64_le(data);
    if (code_units > (UINT32_MAX - 16u) / 2u)
      return 0;
    raw = UINT64_C(8) + code_units * UINT64_C(2);
    padded = (raw + UINT64_C(7)) & ~UINT64_C(7);
    if (padded > available || padded > UINT32_MAX)
      return 0;
    for (pad_index = (uint32_t)raw; pad_index < (uint32_t)padded;
         ++pad_index) {
      if (data[pad_index] != 0u)
        return 0;
    }
    extent = (uint32_t)padded;
    break;
  }
  case AL_OWNING_TYPE_RECORD: {
    uint32_t offset = 0u;
    if (type->field_count == 0u) {
      if (type->fixed_extent_bytes != 8u || available < 8u)
        return 0;
      extent = 8u;
      break;
    }
    for (index = 0u; index < type->field_count; ++index) {
      const al_owning_field_descriptor *field;
      uint32_t child_extent;
      if (!get_field(layout, type, index, &field) ||
          field->reserved != 0u ||
          (field->flags & ~AL_OWNING_FIELD_ZERO_WIDTH) != 0u ||
          (field->fixed_offset_bytes != AL_OWNING_LAYOUT_DYNAMIC_U32 &&
           field->fixed_offset_bytes != offset))
        return 0;
      if (field->flags & AL_OWNING_FIELD_ZERO_WIDTH) {
        if (field->child_type_index >= layout->type_count)
          return 0;
        continue;
      }
      if (field->child_type_index >= layout->type_count || offset > available ||
          !measure_value(layout, field->child_type_index, data + offset,
                         available - offset, &child_extent, depth + 1u) ||
          child_extent > UINT32_MAX - offset)
        return 0;
      offset += child_extent;
    }
    if (offset == 0u)
      offset = 8u;
    if (available < offset)
      return 0;
    if (type->fixed_extent_bytes != AL_OWNING_LAYOUT_DYNAMIC_U32 &&
        type->fixed_extent_bytes != offset)
      return 0;
    extent = offset;
    break;
  }
  case AL_OWNING_TYPE_OPTION:
  case AL_OWNING_TYPE_RESULT: {
    uint64_t tag;
    const al_owning_field_descriptor *field;
    uint32_t child_extent;
    if (available < 8u || type->case_count == 0u ||
        type->case_count != type->field_count || type->case_count > 64u)
      return 0;
    tag = load_u64_le(data);
    if (tag >= type->case_count ||
        !get_field(layout, type, (uint32_t)tag, &field) ||
        field->fixed_offset_bytes != 8u || field->reserved != 0u ||
        field->flags != 0u)
      return 0;
    if (field->child_type_index == AL_OWNING_LAYOUT_DYNAMIC_U32) {
      if (type->kind != AL_OWNING_TYPE_OPTION || tag != 1u)
        return 0;
      extent = 8u;
    } else {
      if (field->child_type_index >= layout->type_count ||
          !measure_value(layout, field->child_type_index, data + 8u,
                         available - 8u, &child_extent, depth + 1u) ||
          child_extent > UINT32_MAX - 8u)
        return 0;
      extent = 8u + child_extent;
    }
    if (type->fixed_extent_bytes != AL_OWNING_LAYOUT_DYNAMIC_U32 &&
        type->fixed_extent_bytes != extent)
      return 0;
    break;
  }
  case AL_OWNING_TYPE_LIST: {
    const al_owning_field_descriptor *field;
    uint64_t count;
    uint32_t cursor = 8u;
    if (available < 8u || type->field_count != 1u || type->case_count != 0u ||
        !get_field(layout, type, 0u, &field) ||
        field->fixed_offset_bytes != 8u || field->flags != 0u ||
        field->reserved != 0u ||
        field->child_type_index >= layout->type_count)
      return 0;
    count = load_u64_le(data);
    if (count > (available - 8u) / 8u)
      return 0;
    for (index = 0u; index < (uint32_t)count; ++index) {
      uint32_t child_extent;
      if (cursor > available ||
          !measure_value(layout, field->child_type_index, data + cursor,
                         available - cursor, &child_extent, depth + 1u) ||
          child_extent > UINT32_MAX - cursor)
        return 0;
      cursor += child_extent;
    }
    extent = cursor;
    if (type->fixed_extent_bytes != AL_OWNING_LAYOUT_DYNAMIC_U32 &&
        type->fixed_extent_bytes != extent)
      return 0;
    break;
  }
  default:
    return 0;
  }

  *out_extent = extent;
  return 1;
}

static int input_matches(const al_owning_layout *layout,
                         const al_campfire_room_read_input *input,
                         uint32_t expected_kind) {
  const al_owning_type_descriptor *type;
  uint32_t extent;
  return input != NULL && input->data != NULL &&
         get_type(layout, input->type_index, &type) &&
         type->kind == expected_kind &&
         measure_value(layout, input->type_index, input->data,
                       input->extent_bytes, &extent, 0u) &&
         extent == input->extent_bytes;
}

static int record_field_location(const al_owning_layout *layout,
                                 uint32_t record_type_index,
                                 const uint8_t *record_data,
                                 uint32_t record_extent,
                                 uint32_t field_index, uint32_t *out_offset,
                                 uint32_t *out_child_type_index) {
  const al_owning_type_descriptor *record_type;
  uint32_t offset = 0u;
  uint32_t index;
  if (!get_type(layout, record_type_index, &record_type) ||
      record_type->kind != AL_OWNING_TYPE_RECORD ||
      field_index >= record_type->field_count)
    return 0;
  for (index = 0u; index <= field_index; ++index) {
    const al_owning_field_descriptor *field;
    uint32_t child_extent;
    if (!get_field(layout, record_type, index, &field) ||
        field->reserved != 0u ||
        field->flags != 0u ||
        (field->fixed_offset_bytes != AL_OWNING_LAYOUT_DYNAMIC_U32 &&
         field->fixed_offset_bytes != offset))
      return 0;
    if (index == field_index) {
      *out_offset = offset;
      *out_child_type_index = field->child_type_index;
      return 1;
    }
    if (field->flags & AL_OWNING_FIELD_ZERO_WIDTH)
      continue;
    if (field->child_type_index >= layout->type_count || offset > record_extent ||
        !measure_value(layout, field->child_type_index,
                       record_data + offset, record_extent - offset,
                       &child_extent, 0u) ||
        child_extent > UINT32_MAX - offset)
      return 0;
    offset += child_extent;
  }
  return 0;
}

static int record_field_type(const al_owning_layout *layout,
                             uint32_t record_type_index,
                             uint32_t field_index,
                             uint32_t *out_child_type_index) {
  const al_owning_type_descriptor *record_type;
  const al_owning_field_descriptor *field;
  if (!get_type(layout, record_type_index, &record_type) ||
      record_type->kind != AL_OWNING_TYPE_RECORD ||
      !get_field(layout, record_type, field_index, &field) ||
      field->reserved != 0u ||
      field->flags != 0u ||
      field->child_type_index >= layout->type_count)
    return 0;
  *out_child_type_index = field->child_type_index;
  return 1;
}

static int type_has_kind(const al_owning_layout *layout, uint32_t type_index,
                         uint32_t kind) {
  const al_owning_type_descriptor *type;
  return get_type(layout, type_index, &type) && type->kind == kind;
}

static int enum_has_cases(const al_owning_layout *layout, uint32_t type_index,
                          uint32_t case_count) {
  const al_owning_type_descriptor *type;
  return get_type(layout, type_index, &type) &&
         type->kind == AL_OWNING_TYPE_ENUM && type->field_count == 0u &&
         type->case_count == case_count && type->fixed_extent_bytes == 8u;
}

static int option_payload_type(const al_owning_layout *layout,
                               uint32_t option_type_index,
                               uint32_t expected_payload_kind,
                               uint32_t *out_payload_type) {
  const al_owning_type_descriptor *type;
  const al_owning_field_descriptor *some_field;
  const al_owning_field_descriptor *none_field;
  if (!get_type(layout, option_type_index, &type) ||
      type->kind != AL_OWNING_TYPE_OPTION || type->field_count != 2u ||
      type->case_count != 2u ||
      !get_field(layout, type, 0u, &some_field) ||
      !get_field(layout, type, 1u, &none_field) ||
      some_field->flags != 0u || none_field->flags != 0u ||
      some_field->reserved != 0u || none_field->reserved != 0u ||
      some_field->fixed_offset_bytes != 8u ||
      none_field->fixed_offset_bytes != 8u ||
      some_field->child_type_index >= layout->type_count ||
      none_field->child_type_index != AL_OWNING_LAYOUT_DYNAMIC_U32 ||
      !type_has_kind(layout, some_field->child_type_index,
                     expected_payload_kind))
    return 0;
  *out_payload_type = some_field->child_type_index;
  return 1;
}

static int record_has_kinds(const al_owning_layout *layout,
                            uint32_t record_type_index,
                            const uint32_t *expected_kinds,
                            uint32_t field_count) {
  const al_owning_type_descriptor *record_type;
  uint32_t index;
  if (!get_type(layout, record_type_index, &record_type) ||
      record_type->kind != AL_OWNING_TYPE_RECORD ||
      record_type->field_count != field_count)
    return 0;
  for (index = 0u; index < field_count; ++index) {
    uint32_t child_type;
    if (!record_field_type(layout, record_type_index, index, &child_type))
      return 0;
    if (expected_kinds[index] == AL_OWNING_TYPE_OPTION) {
      uint32_t option_payload;
      if (!option_payload_type(layout, child_type, AL_OWNING_TYPE_STRING,
                               &option_payload))
        return 0;
    } else if (expected_kinds[index] == (uint32_t)-1) {
      const al_owning_type_descriptor *enum_type;
      if (!get_type(layout, child_type, &enum_type) ||
          enum_type->kind != AL_OWNING_TYPE_ENUM ||
          enum_type->fixed_extent_bytes != 8u || enum_type->case_count != 3u)
        return 0;
    } else if (!type_has_kind(layout, child_type, expected_kinds[index])) {
      return 0;
    }
  }
  return 1;
}

static int result_success_type(const al_owning_layout *layout,
                               uint32_t result_type_index,
                               uint32_t expected_success_kind,
                               uint32_t *out_success_type) {
  const al_owning_type_descriptor *result_type;
  const al_owning_field_descriptor *ok_field;
  const al_owning_field_descriptor *error_field;
  if (!get_type(layout, result_type_index, &result_type) ||
      result_type->kind != AL_OWNING_TYPE_RESULT ||
      result_type->field_count != 2u || result_type->case_count != 2u ||
      !get_field(layout, result_type, 0u, &ok_field) ||
      !get_field(layout, result_type, 1u, &error_field) ||
      ok_field->flags != 0u || error_field->flags != 0u ||
      ok_field->reserved != 0u || error_field->reserved != 0u ||
      ok_field->fixed_offset_bytes != 8u ||
      error_field->fixed_offset_bytes != 8u ||
      ok_field->child_type_index >= layout->type_count ||
      error_field->child_type_index >= layout->type_count ||
      !enum_has_cases(layout, error_field->child_type_index, 4u) ||
      !type_has_kind(layout, ok_field->child_type_index,
                     expected_success_kind))
    return 0;
  *out_success_type = ok_field->child_type_index;
  return 1;
}

static int validate_sql_output_type(const al_owning_layout *layout,
                                    uint32_t operation,
                                    uint32_t output_type_index) {
  uint32_t success_index;
  uint32_t payload_index;
  static const uint32_t session_fields[] = {
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_I64, AL_OWNING_TYPE_STRING,
      AL_OWNING_TYPE_OPTION, AL_OWNING_TYPE_OPTION, AL_OWNING_TYPE_I64,
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_I64};
  static const uint32_t user_fields[] = {
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_STRING, (uint32_t)-1, (uint32_t)-1};
  static const uint32_t room_fields[] = {
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_OPTION, (uint32_t)-1,
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_STRING, AL_OWNING_TYPE_STRING};
  static const uint32_t message_fields[] = {
      AL_OWNING_TYPE_I64, AL_OWNING_TYPE_I64, AL_OWNING_TYPE_I64,
      AL_OWNING_TYPE_STRING, AL_OWNING_TYPE_OPTION,
      AL_OWNING_TYPE_STRING, AL_OWNING_TYPE_STRING};
  uint32_t option_payload;

  if (operation == AL_CAMPFIRE_MEMBERSHIP_EXISTS)
    return result_success_type(layout, output_type_index, AL_OWNING_TYPE_BOOL,
                                &success_index);
  if (operation == AL_CAMPFIRE_MESSAGES_LAST_PAGE) {
    const al_owning_type_descriptor *list_type;
    const al_owning_field_descriptor *element_field;
    if (!result_success_type(layout, output_type_index, AL_OWNING_TYPE_LIST,
                             &success_index) ||
        !get_type(layout, success_index, &list_type) ||
        list_type->field_count != 1u ||
        !get_field(layout, list_type, 0u, &element_field) ||
        element_field->fixed_offset_bytes != 8u ||
        element_field->child_type_index >= layout->type_count ||
        !record_has_kinds(layout, element_field->child_type_index,
                          message_fields, 7u))
      return 0;
    return 1;
  }
  if (operation == AL_CAMPFIRE_SESSION_REFRESH) {
    return result_success_type(layout, output_type_index,
                               AL_OWNING_TYPE_RECORD, &success_index) &&
           record_has_kinds(layout, success_index, session_fields, 8u);
  }
  if (operation == AL_CAMPFIRE_SESSION_FIND ||
      operation == AL_CAMPFIRE_USER_FIND ||
      operation == AL_CAMPFIRE_USER_BOT_KEY ||
      operation == AL_CAMPFIRE_ROOM_FIND) {
    if (!result_success_type(layout, output_type_index,
                             AL_OWNING_TYPE_OPTION, &success_index) ||
        !option_payload_type(layout, success_index, AL_OWNING_TYPE_RECORD,
                             &payload_index))
      return 0;
    switch (operation) {
    case AL_CAMPFIRE_SESSION_FIND:
      return record_has_kinds(layout, payload_index, session_fields, 8u);
    case AL_CAMPFIRE_USER_FIND:
    case AL_CAMPFIRE_USER_BOT_KEY:
      return record_has_kinds(layout, payload_index, user_fields, 4u);
    case AL_CAMPFIRE_ROOM_FIND:
      if (!record_has_kinds(layout, payload_index, room_fields, 6u) ||
          !record_field_type(layout, payload_index, 1u, &payload_index))
        return 0;
      return option_payload_type(layout, payload_index,
                                 AL_OWNING_TYPE_STRING, &option_payload);
    default:
      return 0;
    }
  }
  return 0;
}

static int valid_utf8_path(const uint8_t *path, uint32_t byte_count) {
  uint32_t offset = 0u;
  int only_whitespace = 1;
  if (path == NULL || byte_count == 0u ||
      byte_count > AL_CAMPFIRE_ROOM_READ_PATH_LIMIT_BYTES ||
      path[byte_count] != 0u ||
      (byte_count == 8u && path[0] == ':' && path[1] == 'm' &&
       path[2] == 'e' && path[3] == 'm' && path[4] == 'o' &&
       path[5] == 'r' && path[6] == 'y' && path[7] == ':') ||
      (byte_count >= 5u && path[0] == 'f' && path[1] == 'i' &&
       path[2] == 'l' && path[3] == 'e' && path[4] == ':'))
    return 0;
  while (offset < byte_count) {
    uint32_t codepoint;
    uint8_t first = path[offset++];
    uint32_t count;
    uint32_t minimum;
    uint32_t part;
    if (first == 0u)
      return 0;
    if (first < 0x80u) {
      codepoint = first;
      count = 0u;
      minimum = 0u;
    } else if (first >= 0xc2u && first <= 0xdfu) {
      codepoint = first & 0x1fu;
      count = 1u;
      minimum = 0x80u;
    } else if (first >= 0xe0u && first <= 0xefu) {
      codepoint = first & 0x0fu;
      count = 2u;
      minimum = 0x800u;
    } else if (first >= 0xf0u && first <= 0xf4u) {
      codepoint = first & 0x07u;
      count = 3u;
      minimum = 0x10000u;
    } else {
      return 0;
    }
    for (part = 0u; part < count; ++part) {
      uint8_t next;
      if (offset >= byte_count)
        return 0;
      next = path[offset++];
      if ((next & 0xc0u) != 0x80u)
        return 0;
      codepoint = (codepoint << 6u) | (uint32_t)(next & 0x3fu);
    }
    if ((count != 0u && codepoint < minimum) || codepoint > 0x10ffffu ||
        (codepoint >= 0xd800u && codepoint <= 0xdfffu))
      return 0;
    if (!((codepoint >= 0x0009u && codepoint <= 0x000du) ||
          codepoint == 0x0020u || codepoint == 0x0085u ||
          codepoint == 0x00a0u || codepoint == 0x1680u ||
          (codepoint >= 0x2000u && codepoint <= 0x200au) ||
          codepoint == 0x2028u || codepoint == 0x2029u ||
          codepoint == 0x202fu || codepoint == 0x205fu ||
          codepoint == 0x3000u))
      only_whitespace = 0;
  }
  return !only_whitespace;
}

static uint32_t sqlite_error_tag(sqlite3 *database) {
  int extended = database == NULL ? SQLITE_ERROR
                                  : sqlite3_extended_errcode(database);
  if (extended == 1811)
    return AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  if (extended == 1555 || extended == 2067)
    return AL_CAMPFIRE_DB_ERROR_CONSTRAINT_CONFLICT;
  if (extended == 787)
    return AL_CAMPFIRE_DB_ERROR_NOT_FOUND;
  if ((extended & 0xff) == SQLITE_CONSTRAINT)
    return AL_CAMPFIRE_DB_ERROR_INVALID_INPUT;
  return AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
}

static int read_column_text16(sqlite3 *database, sqlite3_stmt *statement,
                              int column, int allow_null,
                              al_room_read_text *out_text) {
  const void *value;
  int byte_count;
  int type = sqlite3_column_type(statement, column);
  if (type == SQLITE_NULL)
    return allow_null ? 0 : -1;
  value = sqlite3_column_text16(statement, column);
  byte_count = sqlite3_column_bytes16(statement, column);
  if (value == NULL || byte_count < 0 || (byte_count & 1) != 0 ||
      sqlite3_errcode(database) == SQLITE_NOMEM)
    return -1;
  out_text->bytes = (const uint8_t *)value;
  out_text->code_units = (uint32_t)byte_count / 2u;
  return 1;
}

static int read_column_int64(sqlite3_stmt *statement, int column,
                             int64_t *out_value) {
  if (sqlite3_column_type(statement, column) == SQLITE_NULL)
    return 0;
  *out_value = (int64_t)sqlite3_column_int64(statement, column);
  return 1;
}

static int text_equal_ascii(const al_room_read_text *text,
                            const char *ascii, uint32_t length) {
  uint32_t index;
  if (text->code_units != length)
    return 0;
  for (index = 0u; index < length; ++index) {
    if (load_u16_le(text->bytes + index * 2u) != (uint16_t)ascii[index])
      return 0;
  }
  return 1;
}

static int is_ascii_digit(uint16_t value) {
  return value >= (uint16_t)'0' && value <= (uint16_t)'9';
}

static int read_digits(const al_room_read_text *text, uint32_t start,
                       uint32_t count, uint32_t *out_value) {
  uint32_t index;
  uint32_t result = 0u;
  for (index = 0u; index < count; ++index) {
    uint16_t character = load_u16_le(text->bytes + (start + index) * 2u);
    if (!is_ascii_digit(character))
      return 0;
    result = result * 10u + (uint32_t)(character - (uint16_t)'0');
  }
  *out_value = result;
  return 1;
}

static int is_unicode_whitespace(uint32_t value) {
  return ((value >= 0x0009u && value <= 0x000du) || value == 0x0020u ||
          value == 0x0085u || value == 0x00a0u || value == 0x1680u ||
          (value >= 0x2000u && value <= 0x200au) || value == 0x2028u ||
          value == 0x2029u || value == 0x202fu || value == 0x205fu ||
          value == 0x3000u);
}

static int is_leap_year(uint32_t year) {
  return (year % 4u == 0u && year % 100u != 0u) || year % 400u == 0u;
}

/* This matches Authentication.Persistence.SqliteDetails.tryParseTimestamp:
 * trim Unicode whitespace, accept Rails/ISO date-time text and explicit UTC
 * offsets, retain only the first six fractional digits, and normalize to UTC. */
static int try_parse_timestamp(const al_room_read_text *text,
                               int64_t *out_unix_micros) {
  static const uint32_t month_days[] = {31u, 28u, 31u, 30u, 31u, 30u,
                                        31u, 31u, 30u, 31u, 30u, 31u};
  uint32_t start = 0u;
  uint32_t end = text->code_units;
  uint32_t year, month, day, hour, minute, second;
  uint32_t fraction_microseconds = 0u;
  uint32_t offset_hours = 0u;
  uint32_t offset_minutes = 0u;
  int offset_sign = 1;
  uint32_t suffix;
  uint32_t month_day_limit;
  int64_t days;
  int64_t local_ticks;
  int64_t utc_ticks;
  uint32_t index;

  if (text->bytes == NULL)
    return 0;
  while (start < end && is_unicode_whitespace(
                             load_u16_le(text->bytes + start * 2u)))
    ++start;
  while (end > start && is_unicode_whitespace(
                             load_u16_le(text->bytes + (end - 1u) * 2u)))
    --end;
  if (end - start < 19u)
    return 0;
  if (load_u16_le(text->bytes + (start + 4u) * 2u) != (uint16_t)'-' ||
      load_u16_le(text->bytes + (start + 7u) * 2u) != (uint16_t)'-' ||
      (load_u16_le(text->bytes + (start + 10u) * 2u) != (uint16_t)' ' &&
       load_u16_le(text->bytes + (start + 10u) * 2u) != (uint16_t)'T') ||
      load_u16_le(text->bytes + (start + 13u) * 2u) != (uint16_t)':' ||
      load_u16_le(text->bytes + (start + 16u) * 2u) != (uint16_t)':')
    return 0;
  if (!read_digits(text, start, 4u, &year) ||
      !read_digits(text, start + 5u, 2u, &month) ||
      !read_digits(text, start + 8u, 2u, &day) ||
      !read_digits(text, start + 11u, 2u, &hour) ||
      !read_digits(text, start + 14u, 2u, &minute) ||
      !read_digits(text, start + 17u, 2u, &second))
    return 0;
  if (year == 0u || month == 0u || month > 12u || hour > 23u ||
      minute > 59u || second > 59u)
    return 0;
  month_day_limit = month_days[month - 1u];
  if (month == 2u && is_leap_year(year))
    month_day_limit = 29u;
  if (day == 0u || day > month_day_limit)
    return 0;

  suffix = start + 19u;
  if (suffix < end &&
      load_u16_le(text->bytes + suffix * 2u) == (uint16_t)'.') {
    uint32_t first_digit;
    uint32_t digit_count;
    ++suffix;
    first_digit = suffix;
    while (suffix < end && is_ascii_digit(
                               load_u16_le(text->bytes + suffix * 2u)))
      ++suffix;
    digit_count = suffix - first_digit;
    if (digit_count == 0u)
      return 0;
    for (index = 0u; index < digit_count && index < 6u; ++index) {
      fraction_microseconds = fraction_microseconds * 10u +
          (uint32_t)(load_u16_le(text->bytes + (first_digit + index) * 2u) -
                     (uint16_t)'0');
    }
    for (; index < 6u; ++index)
      fraction_microseconds *= 10u;
  }

  if (suffix == end) {
    offset_sign = 1;
  } else if (end - suffix == 1u &&
             load_u16_le(text->bytes + suffix * 2u) == (uint16_t)'Z') {
    offset_sign = 1;
  } else if (end - suffix == 4u &&
             load_u16_le(text->bytes + suffix * 2u) == (uint16_t)' ' &&
             load_u16_le(text->bytes + (suffix + 1u) * 2u) == (uint16_t)'U' &&
             load_u16_le(text->bytes + (suffix + 2u) * 2u) == (uint16_t)'T' &&
             load_u16_le(text->bytes + (suffix + 3u) * 2u) == (uint16_t)'C') {
    offset_sign = 1;
  } else if (end - suffix == 6u &&
             (load_u16_le(text->bytes + suffix * 2u) == (uint16_t)'+' ||
              load_u16_le(text->bytes + suffix * 2u) == (uint16_t)'-') &&
             load_u16_le(text->bytes + (suffix + 3u) * 2u) == (uint16_t)':') {
    offset_sign =
        load_u16_le(text->bytes + suffix * 2u) == (uint16_t)'-' ? -1 : 1;
    if (!read_digits(text, suffix + 1u, 2u, &offset_hours) ||
        !read_digits(text, suffix + 4u, 2u, &offset_minutes) ||
        offset_hours > 14u || offset_minutes > 59u ||
        (offset_hours == 14u && offset_minutes != 0u))
      return 0;
  } else {
    return 0;
  }

  days = (int64_t)(year - 1u) * 365 + (int64_t)((year - 1u) / 4u) -
         (int64_t)((year - 1u) / 100u) +
         (int64_t)((year - 1u) / 400u);
  for (index = 1u; index < month; ++index) {
    days += (int64_t)month_days[index - 1u];
    if (index == 2u && is_leap_year(year))
      ++days;
  }
  days += (int64_t)day - 1;
  local_ticks = days * INT64_C(864000000000) +
      (int64_t)hour * 3600 * INT64_C(10000000) +
      (int64_t)minute * 60 * INT64_C(10000000) +
      (int64_t)second * INT64_C(10000000) +
      (int64_t)fraction_microseconds * 10;
  utc_ticks = local_ticks -
      (int64_t)(offset_sign * (int)(offset_hours * 60u + offset_minutes)) *
          INT64_C(600000000);
  if (utc_ticks < 0 || utc_ticks > DATETIME_MAX_TICKS)
    return 0;
  *out_unix_micros = (utc_ticks - UNIX_EPOCH_TICKS) / 10;
  return 1;
}

static void write_string(uint8_t *output, uint32_t offset,
                         const al_room_read_text *text) {
  uint32_t extent = padded_string_extent(text->code_units);
  uint32_t raw_extent = 8u + text->code_units * 2u;
  uint32_t index;
  store_u64_le(output, offset, text->code_units);
  for (index = 0u; index < text->code_units; ++index) {
    uint16_t unit = load_u16_le(text->bytes + index * 2u);
    output[offset + 8u + index * 2u] = (uint8_t)(unit & 0xffu);
    output[offset + 9u + index * 2u] = (uint8_t)(unit >> 8u);
  }
  for (index = raw_extent; index < extent; ++index)
    output[offset + index] = 0u;
}

static int write_result_error(uint8_t *output, uint32_t capacity,
                              uint32_t error_tag,
                              uint32_t *out_extent_bytes) {
  if (output == NULL || out_extent_bytes == NULL || capacity < 16u)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 1u); /* Result.Error */
  store_u64_le(output, 8u, error_tag);
  *out_extent_bytes = 16u;
  return 0;
}

static int write_result_option_none(uint8_t *output, uint32_t capacity,
                                    uint32_t *out_extent_bytes) {
  if (output == NULL || out_extent_bytes == NULL || capacity < 16u)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u); /* Result.Ok */
  store_u64_le(output, 8u, 1u); /* Option.None */
  *out_extent_bytes = 16u;
  return 0;
}

static int write_result_bool(uint8_t *output, uint32_t capacity, int value,
                             uint32_t *out_extent_bytes) {
  if (output == NULL || out_extent_bytes == NULL || capacity < 16u)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u); /* Result.Ok */
  store_u64_le(output, 8u, value ? 1u : 0u);
  *out_extent_bytes = 16u;
  return 0;
}

static int text_output_extent(const al_room_read_text *text,
                              uint32_t *out_extent) {
  uint32_t extent = padded_string_extent(text->code_units);
  if (extent == 0u)
    return 0;
  *out_extent = extent;
  return 1;
}

static int option_text_output_extent(int state,
                                     const al_room_read_text *text,
                                     uint32_t *out_extent) {
  uint32_t string_extent = 0u;
  if (state < 0 || state > 1 ||
      (state == 1 && !text_output_extent(text, &string_extent)))
    return 0;
  *out_extent = 8u + string_extent;
  return 1;
}

static int load_session_row(sqlite3 *database, sqlite3_stmt *statement,
                            al_room_read_session_row *row) {
  int token_state;
  int ip_state;
  int agent_state;
  int active_state;
  int created_state;
  int updated_state;
  if (!read_column_int64(statement, 0, &row->id) ||
      !read_column_int64(statement, 1, &row->user_id))
    return 0;
  token_state = read_column_text16(database, statement, 2, 0, &row->token);
  ip_state = read_column_text16(database, statement, 3, 1, &row->ip_address);
  agent_state =
      read_column_text16(database, statement, 4, 1, &row->user_agent);
  active_state = read_column_text16(database, statement, 5, 0,
                                    &row->last_active_at_text);
  created_state =
      read_column_text16(database, statement, 6, 0, &row->created_at_text);
  updated_state =
      read_column_text16(database, statement, 7, 0, &row->updated_at_text);
  if (token_state != 1 || ip_state < 0 || agent_state < 0 ||
      active_state != 1 || created_state != 1 || updated_state != 1 ||
      !try_parse_timestamp(&row->last_active_at_text,
                           &row->last_active_at_micros) ||
      !try_parse_timestamp(&row->created_at_text, &row->created_at_micros) ||
      !try_parse_timestamp(&row->updated_at_text, &row->updated_at_micros))
    return 0;
  row->observed_last_active_at =
      (const uint16_t *)row->last_active_at_text.bytes;
  row->observed_last_active_bytes =
      (int)(row->last_active_at_text.code_units * 2u);
  row->ip_state = ip_state;
  row->agent_state = agent_state;
  return 1;
}

static int session_output_extent(const al_room_read_session_row *row,
                                 uint32_t *out_extent) {
  uint32_t token_extent;
  uint32_t ip_extent;
  uint32_t agent_extent;
  uint64_t total;
  if (!text_output_extent(&row->token, &token_extent) ||
      !option_text_output_extent(row->ip_state, &row->ip_address,
                                 &ip_extent) ||
      !option_text_output_extent(row->agent_state, &row->user_agent,
                                 &agent_extent))
    return 0;
  total = UINT64_C(16) + token_extent + ip_extent + agent_extent +
          UINT64_C(24);
  if (total > UINT32_MAX)
    return 0;
  *out_extent = (uint32_t)total;
  return 1;
}

static void write_session_row(uint8_t *output, uint32_t offset,
                              const al_room_read_session_row *row) {
  uint32_t token_extent = padded_string_extent(row->token.code_units);
  uint32_t option_extent;
  store_u64_le(output, offset, (uint64_t)row->id);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->user_id);
  offset += 8u;
  write_string(output, offset, &row->token);
  offset += token_extent;
  store_u64_le(output, offset, row->ip_state == 1 ? 0u : 1u);
  offset += 8u;
  if (row->ip_state == 1) {
    option_extent = padded_string_extent(row->ip_address.code_units);
    write_string(output, offset, &row->ip_address);
    offset += option_extent;
  }
  store_u64_le(output, offset, row->agent_state == 1 ? 0u : 1u);
  offset += 8u;
  if (row->agent_state == 1) {
    option_extent = padded_string_extent(row->user_agent.code_units);
    write_string(output, offset, &row->user_agent);
    offset += option_extent;
  }
  store_u64_le(output, offset, (uint64_t)row->last_active_at_micros);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->created_at_micros);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->updated_at_micros);
}

static int reset_statement(sqlite3_stmt *statement) {
  int reset_status;
  int clear_status;
  if (statement == NULL)
    return SQLITE_OK;
  reset_status = sqlite3_reset(statement);
  clear_status = sqlite3_clear_bindings(statement);
  return clear_status != SQLITE_OK ? clear_status :
         (reset_status == SQLITE_OK ? SQLITE_OK : reset_status);
}

static void cleanup_statements(al_campfire_room_read_context_v1 *ctx) {
  uint32_t index;
  for (index = 0u; index < AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT;
       ++index)
    (void)reset_statement((sqlite3_stmt *)ctx->opaque_statements[index]);
}

static void poison_context(al_campfire_room_read_context_v1 *ctx) {
  uint32_t state = __atomic_load_n(&ctx->active, __ATOMIC_RELAXED);
  __atomic_store_n(&ctx->active,
                   state | ROOM_READ_CONTEXT_STATE_POISONED,
                   __ATOMIC_RELEASE);
}

static void release_context_call(al_campfire_room_read_context_v1 *ctx) {
  uint32_t state = __atomic_load_n(&ctx->active, __ATOMIC_RELAXED);
  __atomic_store_n(&ctx->active,
                   state & ROOM_READ_CONTEXT_STATE_POISONED,
                   __ATOMIC_RELEASE);
}

static int bind_int64(sqlite3_stmt *statement, int index, int64_t value) {
  return sqlite3_bind_int64(statement, index, (sqlite3_int64)value);
}

static int bind_text(sqlite3_stmt *statement, int index,
                     const uint8_t *bytes, uint32_t code_units) {
  uint64_t byte_count = (uint64_t)code_units * 2u;
  if (byte_count > INT_MAX)
    return SQLITE_ERROR;
  return sqlite3_bind_text16(statement, index, bytes, (int)byte_count,
                             SQLITE_TRANSIENT);
}

static int bind_option_text(sqlite3_stmt *statement, int index,
                            const uint8_t *option, uint32_t option_extent) {
  uint64_t tag;
  uint32_t string_extent;
  uint64_t code_units;
  if (option == NULL || option_extent < 8u)
    return SQLITE_ERROR;
  tag = load_u64_le(option);
  if (tag == 1u)
    return sqlite3_bind_null(statement, index);
  if (tag != 0u || option_extent < 16u)
    return SQLITE_ERROR;
  code_units = load_u64_le(option + 8u);
  if (code_units > UINT32_MAX ||
      (string_extent = padded_string_extent((uint32_t)code_units)) == 0u ||
      string_extent + 8u != option_extent)
    return SQLITE_ERROR;
  return bind_text(statement, index, option + 16u, (uint32_t)code_units);
}

static void write_text_option(uint8_t *output, uint32_t offset, int state,
                              const al_room_read_text *text) {
  store_u64_le(output, offset, state == 1 ? 0u : 1u);
  if (state == 1)
    write_string(output, offset + 8u, text);
}

static int load_user_row(sqlite3 *database, sqlite3_stmt *statement,
                         al_room_read_user_row *row) {
  int name_state;
  int64_t raw_role;
  int64_t raw_status;
  if (!read_column_int64(statement, 0, &row->id))
    return 0;
  name_state = read_column_text16(database, statement, 1, 0, &row->name);
  if (name_state != 1 || !read_column_int64(statement, 2, &raw_role) ||
      !read_column_int64(statement, 3, &raw_status) || raw_role < 0 ||
      raw_role > 2 || raw_status < 0 || raw_status > 2)
    return 0;
  row->role = (uint32_t)raw_role;
  row->status = (uint32_t)raw_status;
  return 1;
}

static int user_output_extent(const al_room_read_user_row *row,
                              uint32_t *out_extent) {
  uint32_t name_extent;
  if (!text_output_extent(&row->name, &name_extent))
    return 0;
  *out_extent = 24u + name_extent;
  return 1;
}

static void write_user_row(uint8_t *output, uint32_t offset,
                           const al_room_read_user_row *row) {
  store_u64_le(output, offset, (uint64_t)row->id);
  write_string(output, offset + 8u, &row->name);
  store_u64_le(output, offset + 8u + padded_string_extent(row->name.code_units),
               row->role);
  store_u64_le(output,
               offset + 16u + padded_string_extent(row->name.code_units),
               row->status);
}

static int room_kind_tag(const al_room_read_text *text, uint32_t *out_tag) {
  if (text_equal_ascii(text, "Rooms::Open", 11u)) {
    *out_tag = 0u;
    return 1;
  }
  if (text_equal_ascii(text, "Rooms::Closed", 13u)) {
    *out_tag = 1u;
    return 1;
  }
  if (text_equal_ascii(text, "Rooms::Direct", 13u)) {
    *out_tag = 2u;
    return 1;
  }
  return 0;
}

static int load_room_row(sqlite3 *database, sqlite3_stmt *statement,
                         al_room_read_room_row *row) {
  al_room_read_text kind_text;
  int kind_state;
  int created_state;
  int updated_state;
  int64_t parsed_ticks;
  if (!read_column_int64(statement, 0, &row->id))
    return 0;
  row->name_state =
      read_column_text16(database, statement, 1, 1, &row->name);
  kind_state = read_column_text16(database, statement, 2, 0, &kind_text);
  if (kind_state != 1 ||
      !room_kind_tag(&kind_text, &row->kind) ||
      !read_column_int64(statement, 3, &row->creator_id))
    return 0;
  created_state = read_column_text16(database, statement, 4, 0,
                                     &row->created_at);
  updated_state = read_column_text16(database, statement, 5, 0,
                                     &row->updated_at);
  return row->name_state >= 0 && created_state == 1 && updated_state == 1 &&
         try_parse_timestamp(&row->created_at, &parsed_ticks) &&
         try_parse_timestamp(&row->updated_at, &parsed_ticks);
}

static int room_output_extent(const al_room_read_room_row *row,
                              uint32_t *out_extent) {
  uint32_t name_extent;
  uint32_t created_extent;
  uint32_t updated_extent;
  uint64_t total;
  if (!option_text_output_extent(row->name_state, &row->name, &name_extent) ||
      !text_output_extent(&row->created_at, &created_extent) ||
      !text_output_extent(&row->updated_at, &updated_extent))
    return 0;
  total = UINT64_C(32) + name_extent + created_extent +
          updated_extent;
  if (total > UINT32_MAX)
    return 0;
  *out_extent = (uint32_t)total;
  return 1;
}

static void write_room_row(uint8_t *output, uint32_t offset,
                           const al_room_read_room_row *row) {
  uint32_t name_extent;
  store_u64_le(output, offset, (uint64_t)row->id);
  offset += 8u;
  name_extent = row->name_state == 1
                    ? padded_string_extent(row->name.code_units)
                    : 0u;
  write_text_option(output, offset, row->name_state, &row->name);
  offset += 8u + name_extent;
  store_u64_le(output, offset, row->kind);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->creator_id);
  offset += 8u;
  write_string(output, offset, &row->created_at);
  offset += padded_string_extent(row->created_at.code_units);
  write_string(output, offset, &row->updated_at);
}

static int load_message_row(sqlite3 *database, sqlite3_stmt *statement,
                            al_room_read_message_row *row) {
  int client_state;
  int body_state;
  int created_state;
  int updated_state;
  if (!read_column_int64(statement, 0, &row->id) ||
      !read_column_int64(statement, 1, &row->room_id) ||
      !read_column_int64(statement, 2, &row->creator_id))
    return 0;
  client_state =
      read_column_text16(database, statement, 3, 0, &row->client_message_id);
  body_state = read_column_text16(database, statement, 4, 1, &row->body);
  created_state =
      read_column_text16(database, statement, 5, 0, &row->created_at);
  updated_state =
      read_column_text16(database, statement, 6, 0, &row->updated_at);
  if (client_state != 1 || body_state < 0 || created_state != 1 ||
      updated_state != 1)
    return 0;
  row->body_state = body_state;
  return 1;
}

static int message_output_extent(const al_room_read_message_row *row,
                                 uint32_t *out_extent) {
  uint32_t client_extent;
  uint32_t body_extent;
  uint32_t created_extent;
  uint32_t updated_extent;
  uint64_t total;
  if (!text_output_extent(&row->client_message_id, &client_extent) ||
      !option_text_output_extent(row->body_state, &row->body, &body_extent) ||
      !text_output_extent(&row->created_at, &created_extent) ||
      !text_output_extent(&row->updated_at, &updated_extent))
    return 0;
  total = UINT64_C(24) + client_extent + body_extent + created_extent +
          updated_extent;
  if (total > UINT32_MAX)
    return 0;
  *out_extent = (uint32_t)total;
  return 1;
}

static void write_message_row(uint8_t *output, uint32_t offset,
                              const al_room_read_message_row *row) {
  uint32_t client_extent =
      padded_string_extent(row->client_message_id.code_units);
  uint32_t body_extent = row->body_state == 1
                             ? padded_string_extent(row->body.code_units)
                             : 0u;
  store_u64_le(output, offset, (uint64_t)row->id);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->room_id);
  offset += 8u;
  store_u64_le(output, offset, (uint64_t)row->creator_id);
  offset += 8u;
  write_string(output, offset, &row->client_message_id);
  offset += client_extent;
  write_text_option(output, offset, row->body_state, &row->body);
  offset += 8u + body_extent;
  write_string(output, offset, &row->created_at);
  offset += padded_string_extent(row->created_at.code_units);
  write_string(output, offset, &row->updated_at);
}

static void format_timestamp(int64_t unix_micros, uint16_t output[26],
                             uint32_t *out_code_units) {
  int64_t days = unix_micros / UNIX_MICROS_PER_DAY;
  int64_t day_micros = unix_micros % UNIX_MICROS_PER_DAY;
  int64_t z;
  int64_t era;
  int64_t doe;
  int64_t yoe;
  int64_t year;
  int64_t doy;
  int64_t mp;
  int64_t day;
  int64_t month;
  int64_t hour;
  int64_t minute;
  int64_t second;
  int64_t micros;
  uint32_t length = 19u;
  uint32_t index;

  if (day_micros < 0) {
    day_micros += UNIX_MICROS_PER_DAY;
    --days;
  }
  z = days + INT64_C(719468);
  era = z / INT64_C(146097);
  doe = z - era * INT64_C(146097);
  yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  year = yoe + era * 400;
  doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
  mp = (5 * doy + 2) / 153;
  day = doy - (153 * mp + 2) / 5 + 1;
  month = mp + (mp < 10 ? 3 : -9);
  year += month <= 2;
  hour = day_micros / (3600 * UNIX_MICROS_PER_SECOND);
  day_micros %= 3600 * UNIX_MICROS_PER_SECOND;
  minute = day_micros / (60 * UNIX_MICROS_PER_SECOND);
  day_micros %= 60 * UNIX_MICROS_PER_SECOND;
  second = day_micros / UNIX_MICROS_PER_SECOND;
  micros = day_micros % UNIX_MICROS_PER_SECOND;

  for (index = 0u; index < 26u; ++index)
    output[index] = 0u;
#define PUT_DIGIT(position, digit) \
  output[(position)] = (uint16_t)('0' + (digit))
  PUT_DIGIT(0u, (year / 1000) % 10);
  PUT_DIGIT(1u, (year / 100) % 10);
  PUT_DIGIT(2u, (year / 10) % 10);
  PUT_DIGIT(3u, year % 10);
  output[4] = (uint16_t)'-';
  PUT_DIGIT(5u, month / 10);
  PUT_DIGIT(6u, month % 10);
  output[7] = (uint16_t)'-';
  PUT_DIGIT(8u, day / 10);
  PUT_DIGIT(9u, day % 10);
  output[10] = (uint16_t)' ';
  PUT_DIGIT(11u, hour / 10);
  PUT_DIGIT(12u, hour % 10);
  output[13] = (uint16_t)':';
  PUT_DIGIT(14u, minute / 10);
  PUT_DIGIT(15u, minute % 10);
  output[16] = (uint16_t)':';
  PUT_DIGIT(17u, second / 10);
  PUT_DIGIT(18u, second % 10);
  if (micros != 0) {
    output[19] = (uint16_t)'.';
    PUT_DIGIT(20u, micros / 100000);
    PUT_DIGIT(21u, (micros / 10000) % 10);
    PUT_DIGIT(22u, (micros / 1000) % 10);
    PUT_DIGIT(23u, (micros / 100) % 10);
    PUT_DIGIT(24u, (micros / 10) % 10);
    PUT_DIGIT(25u, micros % 10);
    length = 26u;
  }
#undef PUT_DIGIT
  *out_code_units = length;
}

static int begin_transaction(al_campfire_room_read_context_v1 *ctx,
                             uint32_t statement_index,
                             uint32_t *out_error_tag) {
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      statement_index];
  int rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    *out_error_tag = sqlite_error_tag((sqlite3 *)ctx->opaque_db);
    return 0;
  }
  return 1;
}

static int end_transaction(al_campfire_room_read_context_v1 *ctx,
                           uint32_t statement_index,
                           uint32_t *out_error_tag) {
  sqlite3_stmt *statement =
      (sqlite3_stmt *)ctx->opaque_statements[statement_index];
  int rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    *out_error_tag = sqlite_error_tag((sqlite3 *)ctx->opaque_db);
    return 0;
  }
  return 1;
}

static int rollback_transaction(al_campfire_room_read_context_v1 *ctx) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_ROLLBACK];
  int rc;
  int reset_rc;
  /* Draining/resetting active readers can itself end a transaction after a
   * SQLite error, so inspect autocommit only after this cleanup. */
  cleanup_statements(ctx);
  if (database == NULL) {
    poison_context(ctx);
    return 0;
  }
  if (sqlite3_get_autocommit(database) != 0)
    return 1;
  if (statement == NULL) {
    poison_context(ctx);
    return 0;
  }
  rc = sqlite3_step(statement);
  reset_rc = reset_statement(statement);
  if (rc != SQLITE_DONE || reset_rc != SQLITE_OK ||
      sqlite3_get_autocommit(database) == 0) {
    poison_context(ctx);
    return 0;
  }
  return 1;
}

static int require_autocommit(al_campfire_room_read_context_v1 *ctx) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  if (database != NULL && sqlite3_get_autocommit(database) != 0)
    return 1;
  (void)rollback_transaction(ctx);
  return 0;
}

static int session_find_by_token(al_campfire_room_read_context_v1 *ctx,
                                 const al_campfire_room_read_input *inputs,
                                 uint8_t *output, uint32_t capacity,
                                 uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_SESSION_FIND_TOKEN];
  al_room_read_session_row row;
  uint32_t row_extent;
  int rc;
  uint64_t code_units = load_u64_le(inputs[0].data);
  if (code_units > UINT32_MAX ||
      bind_text(statement, 1, inputs[0].data + 8u, (uint32_t)code_units) !=
          SQLITE_OK)
    return write_result_error(output, capacity,
                              sqlite_error_tag(database), out_extent);
  rc = sqlite3_step(statement);
  if (rc == SQLITE_DONE)
    return write_result_option_none(output, capacity, out_extent);
  if (rc != SQLITE_ROW)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  if (!load_session_row(database, statement, &row))
    return write_result_error(output, capacity,
                              AL_CAMPFIRE_DB_ERROR_UNAVAILABLE, out_extent);
  if (!session_output_extent(&row, &row_extent) ||
      (uint64_t)row_extent + 16u > capacity)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u); /* Result.Ok */
  store_u64_le(output, 8u, 0u); /* Option.Some */
  write_session_row(output, 16u, &row);
  *out_extent = row_extent + 16u;
  return 0;
}

static int parse_session_refresh_input(const al_owning_layout *layout,
                                       const al_campfire_room_read_input *input,
                                       al_room_read_refresh_input *refresh) {
  const al_owning_type_descriptor *record_type;
  uint32_t offsets[5];
  uint32_t child_types[5];
  uint32_t index;
  uint32_t option_extent;
  if (!get_type(layout, input->type_index, &record_type) ||
      record_type->kind != AL_OWNING_TYPE_RECORD ||
      record_type->field_count != 5u)
    return 0;
  for (index = 0u; index < 5u; ++index) {
    if (!record_field_location(layout, input->type_index, input->data,
                               input->extent_bytes, index, &offsets[index],
                               &child_types[index]))
      return 0;
  }
  if (!type_has_kind(layout, child_types[0], AL_OWNING_TYPE_I64) ||
      !type_has_kind(layout, child_types[1], AL_OWNING_TYPE_I64) ||
      !type_has_kind(layout, child_types[2], AL_OWNING_TYPE_I64) ||
      !option_payload_type(layout, child_types[3], AL_OWNING_TYPE_STRING,
                           &index) ||
      !option_payload_type(layout, child_types[4], AL_OWNING_TYPE_STRING,
                           &index))
    return 0;
  refresh->session_id = (int64_t)load_u64_le(input->data + offsets[0]);
  refresh->cutoff = (int64_t)load_u64_le(input->data + offsets[1]);
  refresh->now = (int64_t)load_u64_le(input->data + offsets[2]);
  refresh->ip_option = input->data + offsets[3];
  if (!measure_value(layout, child_types[3], refresh->ip_option,
                     input->extent_bytes - offsets[3], &option_extent, 0u))
    return 0;
  refresh->ip_option_extent = option_extent;
  refresh->agent_option = input->data + offsets[4];
  if (!measure_value(layout, child_types[4], refresh->agent_option,
                     input->extent_bytes - offsets[4], &option_extent, 0u))
    return 0;
  refresh->agent_option_extent = option_extent;
  return 1;
}

static int refresh_read_row(al_campfire_room_read_context_v1 *ctx,
                            int64_t session_id,
                            al_room_read_session_row *row,
                            uint32_t *out_error_tag, int *out_found) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_SESSION_FIND_ID];
  int rc;
  if (bind_int64(statement, 1, session_id) != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  rc = sqlite3_step(statement);
  if (rc == SQLITE_DONE) {
    *out_found = 0;
    return 1;
  }
  if (rc != SQLITE_ROW) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  if (!load_session_row(database, statement, row)) {
    *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    return 0;
  }
  *out_found = 1;
  return 1;
}

static int session_refresh_before(al_campfire_room_read_context_v1 *ctx,
                                  const al_owning_layout *layout,
                                  const al_campfire_room_read_input *inputs,
                                  uint8_t *output, uint32_t capacity,
                                  uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *update_statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_SESSION_REFRESH_UPDATE];
  al_room_read_refresh_input refresh;
  uint16_t now_utf16[26];
  uint32_t now_code_units;
  uint32_t error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  uint32_t attempts;
  int transaction_open = 0;
  int result = HOST_BOUNDARY_FAILURE;

  if (!parse_session_refresh_input(layout, &inputs[0], &refresh))
    return HOST_BOUNDARY_FAILURE;
  if (refresh.cutoff < UtcInstant_MIN_MICROS ||
      refresh.cutoff > UtcInstant_MAX_MICROS ||
      refresh.now < UtcInstant_MIN_MICROS ||
      refresh.now > UtcInstant_MAX_MICROS || refresh.cutoff > refresh.now)
    return write_result_error(output, capacity,
                              AL_CAMPFIRE_DB_ERROR_INVALID_INPUT, out_extent);
  format_timestamp(refresh.now, now_utf16, &now_code_units);
  if (!begin_transaction(ctx, AL_CAMPFIRE_READ_STMT_BEGIN_IMMEDIATE,
                         &error_tag))
    return write_result_error(output, capacity, error_tag, out_extent);
  transaction_open = 1;

  for (attempts = 0u; attempts <= 2u; ++attempts) {
    al_room_read_session_row current;
    uint32_t row_extent;
    int found = 0;
    if (!refresh_read_row(ctx, refresh.session_id, &current, &error_tag,
                          &found))
      goto refresh_error;
    if (!found) {
      error_tag = AL_CAMPFIRE_DB_ERROR_NOT_FOUND;
      goto refresh_error;
    }

    if (current.last_active_at_micros < refresh.cutoff) {
      int rc;
      if (bind_option_text(update_statement, 1, refresh.ip_option,
                           refresh.ip_option_extent) != SQLITE_OK ||
          bind_option_text(update_statement, 2, refresh.agent_option,
                           refresh.agent_option_extent) != SQLITE_OK ||
          bind_text(update_statement, 3, (const uint8_t *)now_utf16,
                    now_code_units) != SQLITE_OK ||
          bind_int64(update_statement, 4, refresh.session_id) != SQLITE_OK ||
          current.observed_last_active_at == NULL ||
          current.observed_last_active_bytes < 0 ||
          sqlite3_bind_text16(update_statement, 5,
                              current.observed_last_active_at,
                              current.observed_last_active_bytes,
                              SQLITE_TRANSIENT) != SQLITE_OK) {
        error_tag = sqlite_error_tag(database);
        goto refresh_error;
      }
      /* SQLite owns a copy of the timestamp binding before the read is reset. */
      (void)reset_statement((sqlite3_stmt *)ctx->opaque_statements[
          AL_CAMPFIRE_READ_STMT_SESSION_FIND_ID]);
      rc = sqlite3_step(update_statement);
      if (rc != SQLITE_DONE) {
        error_tag = sqlite_error_tag(database);
        goto refresh_error;
      }
      if (sqlite3_changes(database) == 0) {
        (void)reset_statement(update_statement);
        if (attempts < 2u)
          continue;
        error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
        goto refresh_error;
      }
      (void)reset_statement(update_statement);
      if (!refresh_read_row(ctx, refresh.session_id, &current, &error_tag,
                            &found))
        goto refresh_error;
      if (!found) {
        error_tag = AL_CAMPFIRE_DB_ERROR_NOT_FOUND;
        goto refresh_error;
      }
    }

    if (!session_output_extent(&current, &row_extent) ||
        (uint64_t)row_extent + 8u > capacity)
      goto refresh_boundary;
    store_u64_le(output, 0u, 0u); /* Result.Ok */
    write_session_row(output, 8u, &current);
    /* Drain/reset the read statement before COMMIT. Output is still borrowed;
     * a commit failure replaces it with a complete typed Error value. */
    {
      sqlite3_stmt *read_statement = (sqlite3_stmt *)ctx->opaque_statements[
          AL_CAMPFIRE_READ_STMT_SESSION_FIND_ID];
      int rc = sqlite3_step(read_statement);
      if (rc != SQLITE_DONE) {
        error_tag = sqlite_error_tag(database);
        goto refresh_error;
      }
      (void)reset_statement(read_statement);
    }
    if (!end_transaction(ctx, AL_CAMPFIRE_READ_STMT_COMMIT, &error_tag))
      goto refresh_error;
    transaction_open = 0;
    *out_extent = row_extent + 8u;
    return 0;
  }

refresh_boundary:
  if (transaction_open)
    rollback_transaction(ctx);
  return HOST_BOUNDARY_FAILURE;

refresh_error:
  if (transaction_open)
    rollback_transaction(ctx);
  result = write_result_error(output, capacity, error_tag, out_extent);
  return result;
}

static int user_find_by_id(al_campfire_room_read_context_v1 *ctx,
                           int64_t user_id, uint8_t *output,
                           uint32_t capacity, uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_USER_FIND_ID];
  al_room_read_user_row row;
  uint32_t row_extent;
  int rc;
  if (bind_int64(statement, 1, user_id) != SQLITE_OK)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  rc = sqlite3_step(statement);
  if (rc == SQLITE_DONE)
    return write_result_option_none(output, capacity, out_extent);
  if (rc != SQLITE_ROW)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  if (!load_user_row(database, statement, &row))
    return write_result_error(output, capacity,
                              AL_CAMPFIRE_DB_ERROR_UNAVAILABLE, out_extent);
  if (!user_output_extent(&row, &row_extent) ||
      (uint64_t)row_extent + 16u > capacity)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u);
  store_u64_le(output, 8u, 0u);
  write_user_row(output, 16u, &row);
  *out_extent = row_extent + 16u;
  return 0;
}

static int split_bot_key(const al_room_read_text *key,
                         al_room_read_text *id,
                         al_room_read_text *token) {
  uint32_t index;
  uint32_t dash = UINT32_MAX;
  uint32_t second_dash = UINT32_MAX;
  for (index = 0u; index < key->code_units; ++index) {
    if (load_u16_le(key->bytes + index * 2u) == (uint16_t)'-') {
      if (dash == UINT32_MAX)
        dash = index;
      else {
        second_dash = index;
        break;
      }
    }
  }
  if (dash == UINT32_MAX)
    return 0;
  id->bytes = key->bytes;
  id->code_units = dash;
  token->bytes = key->bytes + (dash + 1u) * 2u;
  token->code_units = (second_dash == UINT32_MAX ? key->code_units
                                                 : second_dash) - dash - 1u;
  return 1;
}

static int user_authenticate_bot_key(al_campfire_room_read_context_v1 *ctx,
                                    const al_campfire_room_read_input *input,
                                    uint8_t *output, uint32_t capacity,
                                    uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_USER_BOT_KEY];
  al_room_read_text key;
  al_room_read_text id;
  al_room_read_text token;
  al_room_read_user_row row;
  uint32_t row_extent;
  uint64_t key_units = load_u64_le(input->data);
  int rc;
  key.bytes = input->data + 8u;
  key.code_units = (uint32_t)key_units;
  if (!split_bot_key(&key, &id, &token))
    return write_result_option_none(output, capacity, out_extent);
  if (bind_text(statement, 1, id.bytes, id.code_units) != SQLITE_OK ||
      bind_text(statement, 2, token.bytes, token.code_units) != SQLITE_OK)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  rc = sqlite3_step(statement);
  if (rc == SQLITE_DONE)
    return write_result_option_none(output, capacity, out_extent);
  if (rc != SQLITE_ROW)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  if (!load_user_row(database, statement, &row))
    return write_result_error(output, capacity,
                              AL_CAMPFIRE_DB_ERROR_UNAVAILABLE, out_extent);
  if (!user_output_extent(&row, &row_extent) ||
      (uint64_t)row_extent + 16u > capacity)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u);
  store_u64_le(output, 8u, 0u);
  write_user_row(output, 16u, &row);
  *out_extent = row_extent + 16u;
  return 0;
}

static int room_find_for_user(al_campfire_room_read_context_v1 *ctx,
                              int64_t user_id, int64_t room_id,
                              uint8_t *output, uint32_t capacity,
                              uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_ROOM_FIND_FOR_USER];
  al_room_read_room_row row;
  uint32_t row_extent;
  int rc;
  if (bind_int64(statement, 1, user_id) != SQLITE_OK ||
      bind_int64(statement, 2, room_id) != SQLITE_OK)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  rc = sqlite3_step(statement);
  if (rc == SQLITE_DONE)
    return write_result_option_none(output, capacity, out_extent);
  if (rc != SQLITE_ROW)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  if (!load_room_row(database, statement, &row))
    return write_result_error(output, capacity,
                              AL_CAMPFIRE_DB_ERROR_UNAVAILABLE, out_extent);
  if (!room_output_extent(&row, &row_extent) ||
      (uint64_t)row_extent + 16u > capacity)
    return HOST_BOUNDARY_FAILURE;
  store_u64_le(output, 0u, 0u);
  store_u64_le(output, 8u, 0u);
  write_room_row(output, 16u, &row);
  *out_extent = row_extent + 16u;
  return 0;
}

static int membership_exists(al_campfire_room_read_context_v1 *ctx,
                             int64_t user_id, int64_t room_id,
                             uint8_t *output, uint32_t capacity,
                             uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_MEMBERSHIP_EXISTS];
  int rc;
  if (bind_int64(statement, 1, user_id) != SQLITE_OK ||
      bind_int64(statement, 2, room_id) != SQLITE_OK)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  rc = sqlite3_step(statement);
  if (rc != SQLITE_ROW)
    return write_result_error(output, capacity, sqlite_error_tag(database),
                              out_extent);
  return write_result_bool(output, capacity,
                           sqlite3_column_int64(statement, 0) != 0,
                           out_extent);
}

static int room_exists(al_campfire_room_read_context_v1 *ctx, int64_t room_id,
                       int *out_exists, uint32_t *out_error_tag) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_ROOM_EXISTS];
  int rc;
  if (bind_int64(statement, 1, room_id) != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  rc = sqlite3_step(statement);
  if (rc != SQLITE_ROW) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  *out_exists = sqlite3_column_int64(statement, 0) != 0;
  (void)reset_statement(statement);
  return 1;
}

static int parse_membership_input(const al_owning_layout *layout,
                                  const al_campfire_room_read_input *input,
                                  int64_t *out_user_id,
                                  int64_t *out_room_id) {
  const al_owning_type_descriptor *record_type;
  uint32_t user_offset;
  uint32_t room_offset;
  uint32_t user_type;
  uint32_t room_type;
  if (!get_type(layout, input->type_index, &record_type) ||
      record_type->kind != AL_OWNING_TYPE_RECORD ||
      record_type->field_count != 2u ||
      !record_field_location(layout, input->type_index, input->data,
                             input->extent_bytes, 0u, &user_offset,
                             &user_type) ||
      !record_field_location(layout, input->type_index, input->data,
                             input->extent_bytes, 1u, &room_offset,
                             &room_type) ||
      !type_has_kind(layout, user_type, AL_OWNING_TYPE_I64) ||
      !type_has_kind(layout, room_type, AL_OWNING_TYPE_I64))
    return 0;
  *out_user_id = (int64_t)load_u64_le(input->data + user_offset);
  *out_room_id = (int64_t)load_u64_le(input->data + room_offset);
  return 1;
}

static int messages_last_page(al_campfire_room_read_context_v1 *ctx,
                              int64_t room_id, uint8_t *output,
                              uint32_t capacity, uint32_t *out_extent) {
  sqlite3 *database = (sqlite3 *)ctx->opaque_db;
  sqlite3_stmt *statement = (sqlite3_stmt *)ctx->opaque_statements[
      AL_CAMPFIRE_READ_STMT_MESSAGES_LAST_PAGE];
  al_room_read_message_extent rows[MAX_LAST_PAGE_ROWS];
  uint32_t count = 0u;
  uint32_t total_extent = 16u;
  uint32_t error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  int exists = 0;
  int transaction_open = 0;
  int rc;
  uint32_t index;

  if (!begin_transaction(ctx, AL_CAMPFIRE_READ_STMT_BEGIN_DEFERRED,
                         &error_tag))
    return write_result_error(output, capacity, error_tag, out_extent);
  transaction_open = 1;
  if (!room_exists(ctx, room_id, &exists, &error_tag))
    goto last_page_error;
  if (!exists) {
    error_tag = AL_CAMPFIRE_DB_ERROR_NOT_FOUND;
    goto last_page_error;
  }
  if (bind_int64(statement, 1, room_id) != SQLITE_OK) {
    error_tag = sqlite_error_tag(database);
    goto last_page_error;
  }
  for (;;) {
    al_room_read_message_row row;
    uint32_t row_extent;
    rc = sqlite3_step(statement);
    if (rc == SQLITE_DONE)
      break;
    if (rc != SQLITE_ROW) {
      error_tag = sqlite_error_tag(database);
      goto last_page_error;
    }
    if (count >= MAX_LAST_PAGE_ROWS || !load_message_row(database, statement,
                                                         &row) ||
        !message_output_extent(&row, &row_extent)) {
      error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
      goto last_page_error;
    }
    if ((uint64_t)total_extent + row_extent > AL_CAMPFIRE_ROOM_READ_OUTPUT_LIMIT) {
      transaction_open = 1;
      (void)reset_statement(statement);
      rollback_transaction(ctx);
      return HOST_BOUNDARY_FAILURE;
    }
    rows[count].extent = row_extent;
    rows[count].output_offset = 0u;
    rows[count].message_id = row.id;
    total_extent += row_extent;
    ++count;
  }
  if (total_extent > capacity)
    goto last_page_boundary;
  {
    uint32_t cursor = 16u;
    for (index = count; index > 0u; --index) {
      uint32_t descending_index = index - 1u;
      rows[descending_index].output_offset = cursor;
      cursor += rows[descending_index].extent;
    }
  }
  (void)reset_statement(statement);
  if (bind_int64(statement, 1, room_id) != SQLITE_OK) {
    error_tag = sqlite_error_tag(database);
    goto last_page_error;
  }
  store_u64_le(output, 0u, 0u); /* Result.Ok */
  store_u64_le(output, 8u, count);
  for (index = 0u; index < count; ++index) {
    al_room_read_message_row row;
    uint32_t row_extent;
    rc = sqlite3_step(statement);
    if (rc != SQLITE_ROW) {
      error_tag = sqlite_error_tag(database);
      goto last_page_error;
    }
    if (!load_message_row(database, statement, &row) ||
        !message_output_extent(&row, &row_extent) ||
        row_extent != rows[index].extent ||
        row.id != rows[index].message_id ||
        rows[index].output_offset > capacity ||
        row_extent > capacity - rows[index].output_offset) {
      error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
      goto last_page_error;
    }
    write_message_row(output, rows[index].output_offset, &row);
  }
  rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    error_tag = sqlite_error_tag(database);
    goto last_page_error;
  }
  (void)reset_statement(statement);
  if (!end_transaction(ctx, AL_CAMPFIRE_READ_STMT_COMMIT, &error_tag))
    goto last_page_error;
  transaction_open = 0;
  *out_extent = total_extent;
  return 0;

last_page_boundary:
  if (transaction_open)
    rollback_transaction(ctx);
  return HOST_BOUNDARY_FAILURE;

last_page_error:
  if (transaction_open)
    rollback_transaction(ctx);
  return write_result_error(output, capacity, error_tag, out_extent);
}

static int32_t prepare_query(sqlite3 *database, uint32_t index,
                             sqlite3_stmt **out_statement) {
  const char *tail = NULL;
  int rc = sqlite3_prepare_v2(database, room_read_queries[index], -1,
                              out_statement, &tail);
  if (rc != SQLITE_OK || *out_statement == NULL || tail == NULL ||
      *tail != '\0')
    return HOST_BOUNDARY_FAILURE;
  return 0;
}

static int prepare_fixed_pragma(sqlite3 *database, const char *sql,
                                sqlite3_stmt **out_statement,
                                uint32_t *out_error_tag) {
  const char *tail = NULL;
  int rc = sqlite3_prepare_v2(database, sql, -1, out_statement, &tail);
  if (rc != SQLITE_OK || *out_statement == NULL || tail == NULL ||
      *tail != '\0') {
    *out_error_tag = sqlite_error_tag(database);
    if (*out_statement != NULL) {
      (void)sqlite3_finalize(*out_statement);
      *out_statement = NULL;
    }
    return 0;
  }
  return 1;
}

static int execute_fixed_pragma(sqlite3 *database, const char *sql,
                                uint32_t *out_error_tag) {
  sqlite3_stmt *statement = NULL;
  int rc;
  if (!prepare_fixed_pragma(database, sql, &statement, out_error_tag))
    return 0;
  do {
    rc = sqlite3_step(statement);
  } while (rc == SQLITE_ROW);
  if (rc != SQLITE_DONE) {
    *out_error_tag = sqlite_error_tag(database);
    (void)sqlite3_finalize(statement);
    return 0;
  }
  rc = sqlite3_finalize(statement);
  if (rc != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  return 1;
}

static int pragma_text_equals(sqlite3 *database, const char *sql,
                              const char *expected,
                              uint32_t expected_code_units,
                              uint32_t *out_error_tag) {
  sqlite3_stmt *statement = NULL;
  const uint16_t *value;
  int byte_count;
  uint32_t index;
  int rc;
  if (!prepare_fixed_pragma(database, sql, &statement, out_error_tag))
    return 0;
  rc = sqlite3_step(statement);
  if (rc != SQLITE_ROW ||
      sqlite3_column_type(statement, 0) != SQLITE_TEXT) {
    *out_error_tag = sqlite_error_tag(database);
    (void)sqlite3_finalize(statement);
    return 0;
  }
  value = (const uint16_t *)sqlite3_column_text16(statement, 0);
  byte_count = sqlite3_column_bytes16(statement, 0);
  if (value == NULL || byte_count < 0 || (byte_count & 1) != 0 ||
      (uint32_t)byte_count / 2u != expected_code_units) {
    *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    (void)sqlite3_finalize(statement);
    return 0;
  }
  for (index = 0u; index < expected_code_units; ++index) {
    uint16_t actual = load_u16_le((const uint8_t *)value + index * 2u);
    uint16_t wanted = (uint16_t)expected[index];
    if (actual >= (uint16_t)'A' && actual <= (uint16_t)'Z')
      actual = (uint16_t)(actual + ((uint16_t)'a' - (uint16_t)'A'));
    if (wanted >= (uint16_t)'A' && wanted <= (uint16_t)'Z')
      wanted = (uint16_t)(wanted + ((uint16_t)'a' - (uint16_t)'A'));
    if (actual != wanted) {
      *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
      (void)sqlite3_finalize(statement);
      return 0;
    }
  }
  rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    *out_error_tag = sqlite_error_tag(database);
    (void)sqlite3_finalize(statement);
    return 0;
  }
  rc = sqlite3_finalize(statement);
  if (rc != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  return 1;
}

static int pragma_integer_equals(sqlite3 *database, const char *sql,
                                 int64_t expected,
                                 uint32_t *out_error_tag) {
  sqlite3_stmt *statement = NULL;
  int64_t actual;
  int rc;
  if (!prepare_fixed_pragma(database, sql, &statement, out_error_tag))
    return 0;
  rc = sqlite3_step(statement);
  if (rc != SQLITE_ROW ||
      sqlite3_column_type(statement, 0) != SQLITE_INTEGER) {
    *out_error_tag = sqlite_error_tag(database);
    (void)sqlite3_finalize(statement);
    return 0;
  }
  actual = (int64_t)sqlite3_column_int64(statement, 0);
  if (actual != expected) {
    *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    (void)sqlite3_finalize(statement);
    return 0;
  }
  rc = sqlite3_step(statement);
  if (rc != SQLITE_DONE) {
    *out_error_tag = sqlite_error_tag(database);
    (void)sqlite3_finalize(statement);
    return 0;
  }
  rc = sqlite3_finalize(statement);
  if (rc != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  return 1;
}

static int configure_connection_base(sqlite3 *database,
                                     uint32_t *out_error_tag) {
  int foreign_keys_enabled = 0;
  if (sqlite3_extended_result_codes(database, 1) != SQLITE_OK ||
      sqlite3_busy_timeout(database, SQLITE_BUSY_TIMEOUT_MS) != SQLITE_OK) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  if (sqlite3_db_config(database, SQLITE_DBCONFIG_ENABLE_FKEY, 1,
                        &foreign_keys_enabled) != SQLITE_OK ||
      foreign_keys_enabled != 1) {
    *out_error_tag = sqlite_error_tag(database);
    return 0;
  }
  if (!pragma_integer_equals(database, "PRAGMA foreign_keys", 1,
                             out_error_tag) ||
      !execute_fixed_pragma(database, "PRAGMA read_uncommitted=0",
                            out_error_tag) ||
      !pragma_integer_equals(database, "PRAGMA read_uncommitted", 0,
                             out_error_tag))
    return 0;
  return 1;
}

static int verify_connection_pragmas(sqlite3 *database,
                                     uint32_t *out_error_tag) {
  if (!pragma_text_equals(database, "PRAGMA journal_mode", "wal", 3u,
                          out_error_tag) ||
      !pragma_integer_equals(database, "PRAGMA synchronous",
                             SQLITE_SYNCHRONOUS_FULL, out_error_tag) ||
      !pragma_integer_equals(database, "PRAGMA read_uncommitted", 0,
                             out_error_tag) ||
      !pragma_integer_equals(database, "PRAGMA wal_autocheckpoint",
                             WAL_AUTO_CHECKPOINT_PAGES, out_error_tag))
    return 0;
  if (sqlite3_get_autocommit(database) == 0) {
    *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    return 0;
  }
  return 1;
}

static int configure_worker_connection(sqlite3 *database,
                                       uint32_t *out_error_tag) {
  if (sqlite3_libversion_number() < SQLITE_MINIMUM_VERSION_NUMBER) {
    *out_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    return 0;
  }
  if (!configure_connection_base(database, out_error_tag) ||
      !pragma_text_equals(database, "PRAGMA journal_mode", "wal", 3u,
                          out_error_tag) ||
      !execute_fixed_pragma(database, "PRAGMA synchronous=FULL",
                            out_error_tag) ||
      !verify_connection_pragmas(database, out_error_tag))
    return 0;
  return 1;
}

AL_CAMPFIRE_EXPORT int32_t al_campfire_room_read_provision_wal_v1(
    const uint8_t *canonical_db_path_utf8, uint32_t path_bytes,
    uint32_t *out_db_error_tag) {
  sqlite3 *database = NULL;
  uint32_t error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  int result = HOST_BOUNDARY_FAILURE;
  int rc;
  if (out_db_error_tag == NULL)
    return HOST_BOUNDARY_FAILURE;
  *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  if (!valid_utf8_path(canonical_db_path_utf8, path_bytes)) {
    *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_INVALID_INPUT;
    return HOST_BOUNDARY_FAILURE;
  }
  if (sqlite3_libversion_number() < SQLITE_MINIMUM_VERSION_NUMBER) {
    *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    return HOST_BOUNDARY_FAILURE;
  }
  rc = sqlite3_open_v2((const char *)canonical_db_path_utf8, &database,
                       SQLITE_OPEN_FLAGS, NULL);
  if (rc != SQLITE_OK) {
    error_tag = sqlite_error_tag(database);
    goto provision_failed;
  }
  if (!configure_connection_base(database, &error_tag) ||
      !execute_fixed_pragma(database, "PRAGMA synchronous=EXTRA",
                            &error_tag) ||
      !pragma_integer_equals(database, "PRAGMA synchronous",
                             SQLITE_SYNCHRONOUS_EXTRA, &error_tag) ||
      !pragma_text_equals(database, "PRAGMA journal_mode=WAL", "wal", 3u,
                          &error_tag) ||
      !execute_fixed_pragma(database, "PRAGMA synchronous=FULL",
                            &error_tag) ||
      !verify_connection_pragmas(database, &error_tag))
    goto provision_failed;
  rc = sqlite3_close(database);
  if (rc != SQLITE_OK) {
    error_tag = sqlite_error_tag(database);
    goto provision_failed;
  }
  database = NULL;
  *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  return 0;

provision_failed:
  if (database != NULL)
    (void)sqlite3_close(database);
  *out_db_error_tag = error_tag;
  return result;
}

AL_CAMPFIRE_EXPORT int32_t al_campfire_room_read_context_init_v1(
    al_campfire_room_read_context_v1 *ctx,
    const uint8_t *canonical_db_path_utf8, uint32_t path_bytes,
    void *pure_context, uint32_t *out_db_error_tag) {
  sqlite3 *database = NULL;
  sqlite3_stmt *statements[AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT] = {0};
  int rc;
  uint32_t index;
  uint32_t error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  if (out_db_error_tag == NULL)
    return HOST_BOUNDARY_FAILURE;
  *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  if (ctx == NULL)
    return HOST_BOUNDARY_FAILURE;
  if (ctx->cookie == ROOM_READ_CONTEXT_COOKIE) {
    *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_INVALID_INPUT;
    return HOST_BOUNDARY_FAILURE;
  }
  clear_bytes(ctx, sizeof(*ctx));
  if (!valid_utf8_path(canonical_db_path_utf8, path_bytes)) {
    *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_INVALID_INPUT;
    return HOST_BOUNDARY_FAILURE;
  }
  rc = sqlite3_open_v2((const char *)canonical_db_path_utf8, &database,
                       SQLITE_OPEN_FLAGS, NULL);
  if (rc != SQLITE_OK) {
    error_tag = sqlite_error_tag(database);
    goto failed;
  }
  if (!configure_worker_connection(database, &error_tag))
    goto failed;
  for (index = 0u; index < AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT;
       ++index) {
    if (prepare_query(database, index, &statements[index]) != 0) {
      error_tag = sqlite_error_tag(database);
      goto failed;
    }
  }
  if (sqlite3_get_autocommit(database) == 0) {
    error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
    goto failed;
  }
  ctx->opaque_db = database;
  for (index = 0u; index < AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT;
       ++index)
    ctx->opaque_statements[index] = statements[index];
  ctx->pure_context = pure_context;
  ctx->cookie = ROOM_READ_CONTEXT_COOKIE;
  ctx->owner_thread_id = GetCurrentThreadId();
  ctx->active = 0u;
  *out_db_error_tag = AL_CAMPFIRE_DB_ERROR_UNAVAILABLE;
  return 0;

failed:
  for (index = 0u; index < AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT;
       ++index) {
    if (statements[index] != NULL)
      (void)sqlite3_finalize(statements[index]);
  }
  if (database != NULL)
    (void)sqlite3_close(database);
  clear_bytes(ctx, sizeof(*ctx));
  *out_db_error_tag = error_tag;
  return HOST_BOUNDARY_FAILURE;
}

AL_CAMPFIRE_EXPORT int32_t al_campfire_room_read_context_destroy_v1(
    al_campfire_room_read_context_v1 *ctx) {
  sqlite3 *database;
  uint32_t state;
  uint32_t index;
  int rc;
  if (ctx == NULL)
    return HOST_BOUNDARY_FAILURE;
  if (ctx->cookie == 0u && ctx->opaque_db == NULL && ctx->pure_context == NULL &&
      ctx->owner_thread_id == 0u && ctx->active == 0u)
    return 0;
  state = __atomic_load_n(&ctx->active, __ATOMIC_ACQUIRE);
  if (ctx->cookie != ROOM_READ_CONTEXT_COOKIE ||
      ctx->owner_thread_id != GetCurrentThreadId() ||
      (state & ROOM_READ_CONTEXT_STATE_ACTIVE) != 0u)
    return HOST_BOUNDARY_FAILURE;
  database = (sqlite3 *)ctx->opaque_db;
  if (database != NULL && sqlite3_get_autocommit(database) == 0) {
    cleanup_statements(ctx);
    (void)rollback_transaction(ctx);
  }
  for (index = 0u; index < AL_CAMPFIRE_ROOM_READ_SQLITE_STATEMENT_COUNT;
       ++index) {
    sqlite3_stmt *statement =
        (sqlite3_stmt *)ctx->opaque_statements[index];
    if (statement != NULL) {
      (void)sqlite3_finalize(statement);
      ctx->opaque_statements[index] = NULL;
    }
  }
  rc = database == NULL ? SQLITE_OK : sqlite3_close(database);
  if (rc != SQLITE_OK)
    return HOST_BOUNDARY_FAILURE;
  clear_bytes(ctx, sizeof(*ctx));
  return 0;
}

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdll-attribute-on-redeclaration"
AL_CAMPFIRE_EXPORT int32_t al_host_campfire_room_read_v1(
    void *provider_context, uint32_t operation,
    const al_owning_layout *layout,
    const al_campfire_room_read_input *inputs, uint32_t input_count,
    uint32_t output_type_index, uint8_t *output,
    uint32_t output_capacity_bytes, uint32_t *output_extent_bytes) {
  al_campfire_room_read_context_v1 *ctx =
      (al_campfire_room_read_context_v1 *)provider_context;
  uint32_t effective_capacity;
  uint32_t minimum_output_extent;
  uint32_t expected_count;
  uint32_t expected_input_kind = AL_OWNING_TYPE_I64;
  uint32_t expected_active = 0u;
  int64_t membership_user_id = 0;
  int64_t membership_room_id = 0;
  al_room_read_refresh_input refresh_validation;
  int32_t result;

  if (output_extent_bytes == NULL)
    return HOST_BOUNDARY_FAILURE;
  *output_extent_bytes = 0u;
  if (ctx == NULL || ctx->cookie != ROOM_READ_CONTEXT_COOKIE ||
      ctx->opaque_db == NULL ||
      ctx->owner_thread_id != GetCurrentThreadId())
    return HOST_BOUNDARY_FAILURE;
  if (!__atomic_compare_exchange_n(&ctx->active, &expected_active, 1u, 0,
                                   __ATOMIC_ACQUIRE, __ATOMIC_RELAXED))
    return HOST_BOUNDARY_FAILURE;
  if (!require_autocommit(ctx)) {
    release_context_call(ctx);
    return HOST_BOUNDARY_FAILURE;
  }
  if (output == NULL || !valid_layout(layout) ||
      output_type_index >= layout->type_count ||
      (input_count != 0u && inputs == NULL)) {
    result = HOST_BOUNDARY_FAILURE;
    goto callback_complete;
  }
  minimum_output_extent = layout->types[output_type_index].minimum_extent_bytes;
  if (minimum_output_extent < 8u ||
      minimum_output_extent > AL_CAMPFIRE_ROOM_READ_OUTPUT_LIMIT) {
    result = HOST_BOUNDARY_FAILURE;
    goto callback_complete;
  }
  effective_capacity = output_capacity_bytes;
  if (effective_capacity > AL_CAMPFIRE_ROOM_READ_OUTPUT_LIMIT)
    effective_capacity = AL_CAMPFIRE_ROOM_READ_OUTPUT_LIMIT;
  if (effective_capacity < minimum_output_extent) {
    result = HOST_BOUNDARY_FAILURE;
    goto callback_complete;
  }

  if (operation == AL_CAMPFIRE_COOKIE_VERIFY ||
      operation == AL_CAMPFIRE_BROWSER_VERSION) {
    result = operation == AL_CAMPFIRE_COOKIE_VERIFY
                 ? al_campfire_verify_cookie_v1(
                       ctx->pure_context, layout, inputs, input_count,
                       output_type_index, output, effective_capacity,
                       output_extent_bytes)
                 : al_campfire_browser_version_v1(
                       ctx->pure_context, layout, inputs, input_count,
                       output_type_index, output, effective_capacity,
                       output_extent_bytes);
    goto callback_complete;
  }

  switch (operation) {
  case AL_CAMPFIRE_SESSION_FIND:
  case AL_CAMPFIRE_USER_BOT_KEY:
    expected_count = 1u;
    expected_input_kind = AL_OWNING_TYPE_STRING;
    break;
  case AL_CAMPFIRE_SESSION_REFRESH:
    expected_count = 1u;
    expected_input_kind = AL_OWNING_TYPE_RECORD;
    break;
  case AL_CAMPFIRE_USER_FIND:
    expected_count = 1u;
    break;
  case AL_CAMPFIRE_ROOM_FIND:
    expected_count = 2u;
    break;
  case AL_CAMPFIRE_MEMBERSHIP_EXISTS:
    expected_count = 1u;
    expected_input_kind = AL_OWNING_TYPE_RECORD;
    break;
  case AL_CAMPFIRE_MESSAGES_LAST_PAGE:
    expected_count = 1u;
    break;
  default:
    result = HOST_BOUNDARY_FAILURE;
    goto callback_complete;
  }
  if (input_count != expected_count ||
      !validate_sql_output_type(layout, operation, output_type_index)) {
    result = HOST_BOUNDARY_FAILURE;
    goto callback_complete;
  }

  if (operation == AL_CAMPFIRE_SESSION_FIND ||
      operation == AL_CAMPFIRE_USER_BOT_KEY) {
    if (!input_matches(layout, &inputs[0], expected_input_kind)) {
      result = HOST_BOUNDARY_FAILURE;
      goto callback_complete;
    }
  } else if (operation == AL_CAMPFIRE_SESSION_REFRESH) {
    if (!input_matches(layout, &inputs[0], AL_OWNING_TYPE_RECORD) ||
        !parse_session_refresh_input(layout, &inputs[0],
                                     &refresh_validation)) {
      result = HOST_BOUNDARY_FAILURE;
      goto callback_complete;
    }
  } else if (operation == AL_CAMPFIRE_ROOM_FIND) {
    if (!input_matches(layout, &inputs[0], AL_OWNING_TYPE_I64) ||
        !input_matches(layout, &inputs[1], AL_OWNING_TYPE_I64)) {
      result = HOST_BOUNDARY_FAILURE;
      goto callback_complete;
    }
  } else if (operation == AL_CAMPFIRE_MEMBERSHIP_EXISTS) {
    if (!input_matches(layout, &inputs[0], AL_OWNING_TYPE_RECORD) ||
        !parse_membership_input(layout, &inputs[0], &membership_user_id,
                                &membership_room_id)) {
      result = HOST_BOUNDARY_FAILURE;
      goto callback_complete;
    }
  } else if (operation == AL_CAMPFIRE_USER_FIND ||
             operation == AL_CAMPFIRE_MESSAGES_LAST_PAGE) {
    if (!input_matches(layout, &inputs[0], AL_OWNING_TYPE_I64)) {
      result = HOST_BOUNDARY_FAILURE;
      goto callback_complete;
    }
  }
  switch (operation) {
  case AL_CAMPFIRE_SESSION_FIND:
    result = session_find_by_token(ctx, inputs, output,
                                   effective_capacity, output_extent_bytes);
    break;
  case AL_CAMPFIRE_SESSION_REFRESH:
    result = session_refresh_before(ctx, layout, inputs, output,
                                    effective_capacity, output_extent_bytes);
    break;
  case AL_CAMPFIRE_USER_FIND:
    result = user_find_by_id(ctx, (int64_t)load_u64_le(inputs[0].data), output,
                             effective_capacity, output_extent_bytes);
    break;
  case AL_CAMPFIRE_USER_BOT_KEY:
    result = user_authenticate_bot_key(ctx, &inputs[0], output,
                                      effective_capacity, output_extent_bytes);
    break;
  case AL_CAMPFIRE_ROOM_FIND:
    result = room_find_for_user(
        ctx, (int64_t)load_u64_le(inputs[0].data),
        (int64_t)load_u64_le(inputs[1].data), output, effective_capacity,
        output_extent_bytes);
    break;
  case AL_CAMPFIRE_MEMBERSHIP_EXISTS:
    result = membership_exists(ctx, membership_user_id, membership_room_id,
                                output, effective_capacity,
                                output_extent_bytes);
    break;
  case AL_CAMPFIRE_MESSAGES_LAST_PAGE:
    result = messages_last_page(ctx, (int64_t)load_u64_le(inputs[0].data),
                                output, effective_capacity,
                                output_extent_bytes);
    break;
  default:
    result = HOST_BOUNDARY_FAILURE;
    break;
  }
callback_complete:
  cleanup_statements(ctx);
  if (sqlite3_get_autocommit((sqlite3 *)ctx->opaque_db) == 0) {
    (void)rollback_transaction(ctx);
    result = HOST_BOUNDARY_FAILURE;
  }
  if (result == 0 &&
      (*output_extent_bytes < minimum_output_extent ||
       *output_extent_bytes > effective_capacity))
    result = HOST_BOUNDARY_FAILURE;
  if ((__atomic_load_n(&ctx->active, __ATOMIC_ACQUIRE) &
       ROOM_READ_CONTEXT_STATE_POISONED) != 0u)
    result = HOST_BOUNDARY_FAILURE;
  release_context_call(ctx);
  if (result != 0)
    *output_extent_bytes = 0u;
  return result;
}
#pragma clang diagnostic pop

#line 1 "room_read_pure.c"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bcrypt.h>

#include <stdint.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>

#include "room_read_pure.h"

#pragma comment(lib, "bcrypt.lib")

#define AL_CAMPFIRE_PURE_CONTEXT_MAGIC UINT32_C(0x43505231)
#define AL_CAMPFIRE_COOKIE_MAX_BYTES 4096u
#define AL_CAMPFIRE_COOKIE_NAME_BYTES 13u
#define AL_CAMPFIRE_SCRATCH_BYTES 4096u
#define AL_CAMPFIRE_TOKEN_UNITS 4096u
#define AL_CAMPFIRE_SIGNING_KEY_BYTES 64u
#define AL_CAMPFIRE_SHA1_BYTES 20u
#define AL_CAMPFIRE_HEX_SHA1_BYTES 40u
#define AL_CAMPFIRE_HMAC_OBJECT_CAPACITY 512u
#define AL_CAMPFIRE_JSON_MAX_DEPTH 32u

typedef struct al_campfire_pure_context {
  uint32_t magic;
  SRWLOCK lock;
  BCRYPT_ALG_HANDLE hmac_sha1_algorithm;
  ULONG hmac_object_bytes;
  uint8_t signing_key[AL_CAMPFIRE_SIGNING_KEY_BYTES];
  uint8_t hmac_object[AL_CAMPFIRE_HMAC_OBJECT_CAPACITY];
  uint8_t raw_ascii[AL_CAMPFIRE_SCRATCH_BYTES];
  uint8_t payload[AL_CAMPFIRE_SCRATCH_BYTES];
  uint8_t message[AL_CAMPFIRE_SCRATCH_BYTES];
  uint8_t inner_json[AL_CAMPFIRE_SCRATCH_BYTES];
  uint16_t token[AL_CAMPFIRE_TOKEN_UNITS];
} al_campfire_pure_context;

typedef struct al_campfire_string_view {
  const uint8_t *data;
  uint32_t code_units;
  uint32_t extent_bytes;
} al_campfire_string_view;

typedef struct al_campfire_json_parser {
  const uint8_t *bytes;
  uint32_t length;
  uint32_t index;
} al_campfire_json_parser;

typedef struct al_campfire_rails_fields {
  uint8_t message_is_string;
  uint8_t message_is_ascii;
  uint32_t message_length;
  uint8_t purpose_matches;
  uint8_t expiry_present;
  uint8_t expiry_valid;
  int64_t expiry_utc_ticks;
} al_campfire_rails_fields;

typedef enum al_campfire_segment_kind {
  AL_CAMPFIRE_SEGMENT_INTEGER = 1,
  AL_CAMPFIRE_SEGMENT_TEXT = 2
} al_campfire_segment_kind;

typedef struct al_campfire_version_segment {
  al_campfire_segment_kind kind;
  const al_campfire_string_view *owner;
  uint32_t start_unit;
  uint32_t length_units;
  uint8_t is_zero_literal;
} al_campfire_version_segment;

static uint32_t al_campfire_read_u32_le(const uint8_t *bytes) {
  return (uint32_t)bytes[0] | ((uint32_t)bytes[1] << 8u) |
         ((uint32_t)bytes[2] << 16u) | ((uint32_t)bytes[3] << 24u);
}

static uint64_t al_campfire_read_u64_le(const uint8_t *bytes) {
  uint64_t value = 0u;
  uint32_t index;
  for (index = 0u; index < 8u; ++index)
    value |= (uint64_t)bytes[index] << (index * 8u);
  return value;
}

static void al_campfire_write_u32_le(uint8_t *bytes, uint32_t value) {
  uint32_t index;
  for (index = 0u; index < 4u; ++index)
    bytes[index] = (uint8_t)(value >> (index * 8u));
}

static void al_campfire_write_u64_le(uint8_t *bytes, uint64_t value) {
  uint32_t index;
  for (index = 0u; index < 8u; ++index)
    bytes[index] = (uint8_t)(value >> (index * 8u));
}

static uint16_t al_campfire_read_u16_le(const uint8_t *bytes) {
  return (uint16_t)((uint16_t)bytes[0] | ((uint16_t)bytes[1] << 8u));
}

static void al_campfire_write_u16_le(uint8_t *bytes, uint16_t value) {
  bytes[0] = (uint8_t)value;
  bytes[1] = (uint8_t)(value >> 8u);
}

static int32_t al_campfire_layout_valid(const al_owning_layout *layout) {
  return layout != NULL &&
         layout->abi_version == AL_OWNING_LAYOUT_ABI_VERSION &&
         layout->types != NULL && layout->type_count > 0u &&
         layout->type_count <= AL_OWNING_LAYOUT_MAX_TYPES &&
         (layout->field_count == 0u || layout->fields != NULL) &&
         layout->field_count <= AL_OWNING_LAYOUT_MAX_FIELDS;
}

static int32_t al_campfire_read_input_string(
    const al_owning_layout *layout,
    const al_campfire_room_read_input *input,
    al_campfire_string_view *out_view) {
  const al_owning_type_descriptor *type;
  uint32_t code_units;
  uint64_t payload;
  uint64_t extent;
  uint32_t index;
  if (layout == NULL || input == NULL || out_view == NULL ||
      input->data == NULL || input->type_index >= layout->type_count)
    return 0;
  type = &layout->types[input->type_index];
  if (type->kind != AL_OWNING_TYPE_STRING || input->extent_bytes < 8u)
    return 0;
  code_units = al_campfire_read_u32_le(input->data);
  if (input->data[4] != 0u || input->data[5] != 0u ||
      input->data[6] != 0u || input->data[7] != 0u)
    return 0;
  payload = 8u + (uint64_t)code_units * 2u;
  extent = (payload + 7u) & ~UINT64_C(7);
  if (extent > UINT32_MAX || extent != input->extent_bytes)
    return 0;
  for (index = (uint32_t)payload; index < input->extent_bytes; ++index) {
    if (input->data[index] != 0u)
      return 0;
  }
  out_view->data = input->data + 8u;
  out_view->code_units = code_units;
  out_view->extent_bytes = input->extent_bytes;
  return 1;
}

static int32_t al_campfire_read_input_i64(
    const al_owning_layout *layout,
    const al_campfire_room_read_input *input, int64_t *out_value) {
  if (layout == NULL || input == NULL || out_value == NULL ||
      input->data == NULL || input->type_index >= layout->type_count ||
      input->extent_bytes != 8u ||
      layout->types[input->type_index].kind != AL_OWNING_TYPE_I64)
    return 0;
  *out_value = (int64_t)al_campfire_read_u64_le(input->data);
  return 1;
}

static uint16_t al_campfire_string_unit(const al_campfire_string_view *view,
                                       uint32_t index) {
  return al_campfire_read_u16_le(view->data + ((size_t)index * 2u));
}

static int32_t al_campfire_string_is_ascii(
    const al_campfire_string_view *view) {
  uint32_t index;
  for (index = 0u; index < view->code_units; ++index) {
    if (al_campfire_string_unit(view, index) > 0x7fu)
      return 0;
  }
  return 1;
}

static void al_campfire_clear_scratch(al_campfire_pure_context *context) {
  SecureZeroMemory(context->hmac_object, sizeof(context->hmac_object));
  SecureZeroMemory(context->raw_ascii, sizeof(context->raw_ascii));
  SecureZeroMemory(context->payload, sizeof(context->payload));
  SecureZeroMemory(context->message, sizeof(context->message));
  SecureZeroMemory(context->inner_json, sizeof(context->inner_json));
  SecureZeroMemory(context->token, sizeof(context->token));
}

static int32_t al_campfire_utf8_byte_count(
    const al_campfire_string_view *view, uint32_t maximum,
    uint32_t *out_bytes) {
  uint64_t total = 0u;
  uint32_t index = 0u;
  if (view == NULL || out_bytes == NULL)
    return 0;
  while (index < view->code_units) {
    const uint16_t first = al_campfire_string_unit(view, index);
    if (first <= 0x7fu) {
      total += 1u;
      ++index;
    } else if (first <= 0x7ffu) {
      total += 2u;
      ++index;
    } else if (first >= 0xd800u && first <= 0xdbffu &&
               index + 1u < view->code_units) {
      const uint16_t second = al_campfire_string_unit(view, index + 1u);
      if (second >= 0xdc00u && second <= 0xdfffu) {
        total += 4u;
        index += 2u;
      } else {
        /* Encoding.UTF8's default replacement for an unpaired surrogate. */
        total += 3u;
        ++index;
      }
    } else {
      /* Includes isolated low surrogates, which also become U+FFFD. */
      total += 3u;
      ++index;
    }
    if (total > maximum)
      return 0;
  }
  *out_bytes = (uint32_t)total;
  return 1;
}

static int32_t al_campfire_base64_value(uint8_t value) {
  if (value >= (uint8_t)'A' && value <= (uint8_t)'Z')
    return (int32_t)(value - (uint8_t)'A');
  if (value >= (uint8_t)'a' && value <= (uint8_t)'z')
    return 26 + (int32_t)(value - (uint8_t)'a');
  if (value >= (uint8_t)'0' && value <= (uint8_t)'9')
    return 52 + (int32_t)(value - (uint8_t)'0');
  if (value == (uint8_t)'+' || value == (uint8_t)'-')
    return 62;
  if (value == (uint8_t)'/' || value == (uint8_t)'_')
    return 63;
  return -1;
}

/* Matches RailsCookieFormat.urlSafeBase64Decode, including canonical pad bits. */
static int32_t al_campfire_decode_base64_urlsafe(
    const uint8_t *encoded, uint32_t encoded_length, uint8_t *decoded,
    uint32_t decoded_capacity, uint32_t *out_decoded_length) {
  uint32_t first_padding = encoded_length;
  uint32_t padding_count = 0u;
  uint32_t normalized_length;
  uint32_t input_index;
  uint32_t output_index = 0u;
  if (encoded == NULL || decoded == NULL || out_decoded_length == NULL ||
      encoded_length == 0u)
    return 0;
  for (input_index = 0u; input_index < encoded_length; ++input_index) {
    const uint8_t value = encoded[input_index];
    if (value == (uint8_t)'=') {
      if (first_padding == encoded_length)
        first_padding = input_index;
      ++padding_count;
    } else if (al_campfire_base64_value(value) < 0 ||
               first_padding != encoded_length) {
      return 0;
    }
  }
  if (padding_count > 2u ||
      (padding_count > 0u &&
       (encoded_length < 2u || first_padding < encoded_length - 2u ||
        encoded_length % 4u != 0u)))
    return 0;
  if (padding_count == 0u && encoded_length % 4u == 1u)
    return 0;
  normalized_length = encoded_length;
  if (padding_count == 0u)
    normalized_length += (4u - (normalized_length % 4u)) % 4u;
  if (normalized_length == 0u || normalized_length % 4u != 0u)
    return 0;
  if ((uint64_t)(normalized_length / 4u) * 3u < padding_count)
    return 0;
  if (((uint64_t)(normalized_length / 4u) * 3u) - padding_count >
      decoded_capacity)
    return 0;

  for (input_index = 0u; input_index < normalized_length; input_index += 4u) {
    int32_t values[4];
    uint32_t local;
    uint32_t actual_padding = 0u;
    for (local = 0u; local < 4u; ++local) {
      const uint32_t position = input_index + local;
      const uint8_t value = position < encoded_length ? encoded[position]
                                                       : (uint8_t)'=';
      if (value == (uint8_t)'=') {
        values[local] = 0;
        ++actual_padding;
      } else {
        values[local] = al_campfire_base64_value(value);
        if (values[local] < 0)
          return 0;
      }
    }
    if (actual_padding > 0u && input_index + 4u != normalized_length)
      return 0;
    if (actual_padding > 2u ||
        (actual_padding == 2u &&
         (input_index + 4u != normalized_length ||
          (input_index + 2u < encoded_length &&
           encoded[input_index + 2u] != (uint8_t)'='))) ||
        (actual_padding == 1u &&
         (input_index + 4u != normalized_length ||
          (input_index + 3u < encoded_length &&
           encoded[input_index + 3u] != (uint8_t)'='))))
      return 0;
    if ((actual_padding == 2u && (values[1] & 0x0f) != 0) ||
        (actual_padding == 1u && (values[2] & 0x03) != 0))
      return 0;
    decoded[output_index++] =
        (uint8_t)((values[0] << 2) | ((values[1] >> 4) & 0x03));
    if (actual_padding < 2u)
      decoded[output_index++] =
          (uint8_t)(((values[1] & 0x0f) << 4) | ((values[2] >> 2) & 0x0f));
    if (actual_padding == 0u)
      decoded[output_index++] =
          (uint8_t)(((values[2] & 0x03) << 6) | values[3]);
  }
  if (output_index != (uint32_t)(((uint64_t)(normalized_length / 4u) * 3u) -
                                 padding_count))
    return 0;
  *out_decoded_length = output_index;
  return 1;
}

static int32_t al_campfire_is_json_whitespace(uint8_t value) {
  return value == (uint8_t)' ' || value == (uint8_t)'\t' ||
         value == (uint8_t)'\r' || value == (uint8_t)'\n';
}

static void al_campfire_json_skip_whitespace(al_campfire_json_parser *parser) {
  while (parser->index < parser->length &&
         al_campfire_is_json_whitespace(parser->bytes[parser->index]))
    ++parser->index;
}

static int32_t al_campfire_hex_value(uint8_t value) {
  if (value >= (uint8_t)'0' && value <= (uint8_t)'9')
    return (int32_t)(value - (uint8_t)'0');
  if (value >= (uint8_t)'a' && value <= (uint8_t)'f')
    return 10 + (int32_t)(value - (uint8_t)'a');
  if (value >= (uint8_t)'A' && value <= (uint8_t)'F')
    return 10 + (int32_t)(value - (uint8_t)'A');
  return -1;
}

static int32_t al_campfire_read_utf8_scalar(
    const uint8_t *bytes, uint32_t length, uint32_t *index,
    uint32_t *out_scalar) {
  const uint8_t first = bytes[*index];
  uint32_t scalar;
  uint32_t count;
  uint32_t local;
  if (first <= 0x7fu) {
    *out_scalar = first;
    ++*index;
    return 1;
  }
  if (first >= 0xc2u && first <= 0xdfu) {
    scalar = (uint32_t)(first & 0x1fu);
    count = 1u;
  } else if (first >= 0xe0u && first <= 0xefu) {
    scalar = (uint32_t)(first & 0x0fu);
    count = 2u;
  } else if (first >= 0xf0u && first <= 0xf4u) {
    scalar = (uint32_t)(first & 0x07u);
    count = 3u;
  } else {
    return 0;
  }
  if (count > length - *index - 1u)
    return 0;
  for (local = 1u; local <= count; ++local) {
    const uint8_t next = bytes[*index + local];
    if ((next & 0xc0u) != 0x80u)
      return 0;
    scalar = (scalar << 6u) | (uint32_t)(next & 0x3fu);
  }
  if ((count == 1u && scalar < 0x80u) ||
      (count == 2u && scalar < 0x800u) ||
      (count == 3u && scalar < 0x10000u) || scalar > 0x10ffffu ||
      (scalar >= 0xd800u && scalar <= 0xdfffu))
    return 0;
  *index += count + 1u;
  *out_scalar = scalar;
  return 1;
}

static int32_t al_campfire_json_read_u_escape(
    al_campfire_json_parser *parser, uint16_t *out_unit) {
  uint32_t index;
  uint32_t value = 0u;
  if (parser->length - parser->index < 4u)
    return 0;
  for (index = 0u; index < 4u; ++index) {
    const int32_t digit =
        al_campfire_hex_value(parser->bytes[parser->index + index]);
    if (digit < 0)
      return 0;
    value = (value << 4u) | (uint32_t)digit;
  }
  parser->index += 4u;
  *out_unit = (uint16_t)value;
  return 1;
}

/* Parse a JSON string while optionally collecting UTF-16, ASCII, or comparing
 * its decoded contents with an ASCII property/value. System.Text.Json accepts
 * escaped unpaired surrogates; preserve those for token strings and make them
 * non-matching/non-base64 for cookie metadata. */
static int32_t al_campfire_json_parse_string(
    al_campfire_json_parser *parser, uint16_t *utf16_output,
    uint32_t utf16_capacity, uint32_t *out_utf16_units,
    uint8_t *ascii_output, uint32_t ascii_capacity,
    uint32_t *out_ascii_length, int32_t *out_all_ascii,
    const uint8_t *ascii_match, uint32_t ascii_match_length,
    int32_t *out_matches) {
  uint32_t utf16_length = 0u;
  uint32_t ascii_length = 0u;
  uint32_t match_index = 0u;
  int32_t all_ascii = 1;
  int32_t matches = ascii_match != NULL;
  if (parser == NULL || parser->index >= parser->length ||
      parser->bytes[parser->index] != (uint8_t)'"')
    return 0;
  ++parser->index;
  while (parser->index < parser->length) {
    uint32_t scalar;
    uint32_t units_to_emit = 1u;
    uint16_t first_unit;
    uint16_t second_unit = 0u;
    const uint8_t value = parser->bytes[parser->index];
    if (value == (uint8_t)'"') {
      ++parser->index;
      if (utf16_output != NULL && out_utf16_units != NULL)
        *out_utf16_units = utf16_length;
      if (ascii_output != NULL && out_ascii_length != NULL)
        *out_ascii_length = ascii_length;
      if (out_all_ascii != NULL)
        *out_all_ascii = all_ascii;
      if (out_matches != NULL)
        *out_matches = matches && match_index == ascii_match_length;
      return 1;
    }
    if (value < 0x20u)
      return 0;
    if (value == (uint8_t)'\\') {
      uint8_t escaped;
      ++parser->index;
      if (parser->index >= parser->length)
        return 0;
      escaped = parser->bytes[parser->index++];
      if (escaped == (uint8_t)'"' || escaped == (uint8_t)'\\' ||
          escaped == (uint8_t)'/') {
        scalar = escaped;
      } else if (escaped == (uint8_t)'b') {
        scalar = 0x08u;
      } else if (escaped == (uint8_t)'f') {
        scalar = 0x0cu;
      } else if (escaped == (uint8_t)'n') {
        scalar = 0x0au;
      } else if (escaped == (uint8_t)'r') {
        scalar = 0x0du;
      } else if (escaped == (uint8_t)'t') {
        scalar = 0x09u;
      } else if (escaped == (uint8_t)'u') {
        uint16_t escaped_unit;
        if (!al_campfire_json_read_u_escape(parser, &escaped_unit))
          return 0;
        scalar = escaped_unit;
        if (escaped_unit >= 0xd800u && escaped_unit <= 0xdbffu &&
            parser->length - parser->index >= 6u &&
            parser->bytes[parser->index] == (uint8_t)'\\' &&
            parser->bytes[parser->index + 1u] == (uint8_t)'u') {
          uint32_t saved_index = parser->index;
          uint16_t low_unit;
          parser->index += 2u;
          if (!al_campfire_json_read_u_escape(parser, &low_unit))
            return 0;
          if (low_unit >= 0xdc00u && low_unit <= 0xdfffu) {
            scalar = 0x10000u +
                     ((((uint32_t)escaped_unit - 0xd800u) << 10u) |
                      ((uint32_t)low_unit - 0xdc00u));
          } else {
            parser->index = saved_index;
          }
        }
      } else {
        return 0;
      }
    } else {
      if (!al_campfire_read_utf8_scalar(parser->bytes, parser->length,
                                        &parser->index, &scalar))
        return 0;
    }

    if (scalar <= 0xffffu) {
      first_unit = (uint16_t)scalar;
    } else {
      const uint32_t adjusted = scalar - 0x10000u;
      first_unit = (uint16_t)(0xd800u + (adjusted >> 10u));
      second_unit = (uint16_t)(0xdc00u + (adjusted & 0x3ffu));
      units_to_emit = 2u;
    }
    if (utf16_length > UINT32_MAX - units_to_emit ||
        (utf16_output != NULL &&
         units_to_emit > utf16_capacity - utf16_length))
      return 0;
    if (utf16_output != NULL) {
      utf16_output[utf16_length] = first_unit;
      if (units_to_emit == 2u)
        utf16_output[utf16_length + 1u] = second_unit;
    }
    utf16_length += units_to_emit;

    if (scalar <= 0x7fu) {
      const uint8_t ascii_value = (uint8_t)scalar;
      if (ascii_output != NULL) {
        if (ascii_length >= ascii_capacity)
          return 0;
        ascii_output[ascii_length] = ascii_value;
      }
      if (ascii_match != NULL) {
        if (match_index >= ascii_match_length ||
            ascii_match[match_index] != ascii_value)
          matches = 0;
      }
      ++ascii_length;
      ++match_index;
    } else {
      all_ascii = 0;
      matches = 0;
      if (scalar <= 0x7ffu)
        ascii_length += 2u;
      else if (scalar <= 0xffffu)
        ascii_length += 3u;
      else
        ascii_length += 4u;
      match_index += scalar <= 0x7ffu ? 2u : scalar <= 0xffffu ? 3u : 4u;
      if (ascii_output != NULL && ascii_length > ascii_capacity)
        return 0;
    }
  }
  return 0;
}

static int32_t al_campfire_json_parse_number(al_campfire_json_parser *parser) {
  uint32_t index = parser->index;
  if (index < parser->length && parser->bytes[index] == (uint8_t)'-')
    ++index;
  if (index >= parser->length)
    return 0;
  if (parser->bytes[index] == (uint8_t)'0') {
    ++index;
    if (index < parser->length && parser->bytes[index] >= (uint8_t)'0' &&
        parser->bytes[index] <= (uint8_t)'9')
      return 0;
  } else if (parser->bytes[index] >= (uint8_t)'1' &&
             parser->bytes[index] <= (uint8_t)'9') {
    do {
      ++index;
    } while (index < parser->length &&
             parser->bytes[index] >= (uint8_t)'0' &&
             parser->bytes[index] <= (uint8_t)'9');
  } else {
    return 0;
  }
  if (index < parser->length && parser->bytes[index] == (uint8_t)'.') {
    ++index;
    if (index >= parser->length || parser->bytes[index] < (uint8_t)'0' ||
        parser->bytes[index] > (uint8_t)'9')
      return 0;
    do {
      ++index;
    } while (index < parser->length &&
             parser->bytes[index] >= (uint8_t)'0' &&
             parser->bytes[index] <= (uint8_t)'9');
  }
  if (index < parser->length &&
      (parser->bytes[index] == (uint8_t)'e' ||
       parser->bytes[index] == (uint8_t)'E')) {
    ++index;
    if (index < parser->length &&
        (parser->bytes[index] == (uint8_t)'+' ||
         parser->bytes[index] == (uint8_t)'-'))
      ++index;
    if (index >= parser->length || parser->bytes[index] < (uint8_t)'0' ||
        parser->bytes[index] > (uint8_t)'9')
      return 0;
    do {
      ++index;
    } while (index < parser->length &&
             parser->bytes[index] >= (uint8_t)'0' &&
             parser->bytes[index] <= (uint8_t)'9');
  }
  parser->index = index;
  return 1;
}

static int32_t al_campfire_json_parse_value(al_campfire_json_parser *parser,
                                             uint32_t depth);

static int32_t al_campfire_json_parse_object(al_campfire_json_parser *parser,
                                              uint32_t depth) {
  if (depth >= AL_CAMPFIRE_JSON_MAX_DEPTH ||
      parser->bytes[parser->index] != (uint8_t)'{')
    return 0;
  ++parser->index;
  al_campfire_json_skip_whitespace(parser);
  if (parser->index < parser->length &&
      parser->bytes[parser->index] == (uint8_t)'}') {
    ++parser->index;
    return 1;
  }
  while (parser->index < parser->length) {
    if (!al_campfire_json_parse_string(parser, NULL, 0u, NULL, NULL, 0u,
                                       NULL, NULL, NULL, 0u, NULL))
      return 0;
    al_campfire_json_skip_whitespace(parser);
    if (parser->index >= parser->length ||
        parser->bytes[parser->index] != (uint8_t)':')
      return 0;
    ++parser->index;
    al_campfire_json_skip_whitespace(parser);
    if (!al_campfire_json_parse_value(parser, depth + 1u))
      return 0;
    al_campfire_json_skip_whitespace(parser);
    if (parser->index < parser->length &&
        parser->bytes[parser->index] == (uint8_t)'}') {
      ++parser->index;
      return 1;
    }
    if (parser->index >= parser->length ||
        parser->bytes[parser->index] != (uint8_t)',')
      return 0;
    ++parser->index;
    al_campfire_json_skip_whitespace(parser);
  }
  return 0;
}

static int32_t al_campfire_json_parse_array(al_campfire_json_parser *parser,
                                             uint32_t depth) {
  if (depth >= AL_CAMPFIRE_JSON_MAX_DEPTH ||
      parser->bytes[parser->index] != (uint8_t)'[')
    return 0;
  ++parser->index;
  al_campfire_json_skip_whitespace(parser);
  if (parser->index < parser->length &&
      parser->bytes[parser->index] == (uint8_t)']') {
    ++parser->index;
    return 1;
  }
  while (parser->index < parser->length) {
    if (!al_campfire_json_parse_value(parser, depth + 1u))
      return 0;
    al_campfire_json_skip_whitespace(parser);
    if (parser->index < parser->length &&
        parser->bytes[parser->index] == (uint8_t)']') {
      ++parser->index;
      return 1;
    }
    if (parser->index >= parser->length ||
        parser->bytes[parser->index] != (uint8_t)',')
      return 0;
    ++parser->index;
    al_campfire_json_skip_whitespace(parser);
  }
  return 0;
}

static int32_t al_campfire_json_parse_value(al_campfire_json_parser *parser,
                                             uint32_t depth) {
  if (parser == NULL || parser->index >= parser->length)
    return 0;
  switch (parser->bytes[parser->index]) {
  case (uint8_t)'"':
    return al_campfire_json_parse_string(parser, NULL, 0u, NULL, NULL, 0u,
                                         NULL, NULL, NULL, 0u, NULL);
  case (uint8_t)'{':
    return al_campfire_json_parse_object(parser, depth);
  case (uint8_t)'[':
    return al_campfire_json_parse_array(parser, depth);
  case (uint8_t)'t':
    if (parser->length - parser->index < 4u ||
        parser->bytes[parser->index + 1u] != (uint8_t)'r' ||
        parser->bytes[parser->index + 2u] != (uint8_t)'u' ||
        parser->bytes[parser->index + 3u] != (uint8_t)'e')
      return 0;
    parser->index += 4u;
    return 1;
  case (uint8_t)'f':
    if (parser->length - parser->index < 5u ||
        parser->bytes[parser->index + 1u] != (uint8_t)'a' ||
        parser->bytes[parser->index + 2u] != (uint8_t)'l' ||
        parser->bytes[parser->index + 3u] != (uint8_t)'s' ||
        parser->bytes[parser->index + 4u] != (uint8_t)'e')
      return 0;
    parser->index += 5u;
    return 1;
  case (uint8_t)'n':
    if (parser->length - parser->index < 4u ||
        parser->bytes[parser->index + 1u] != (uint8_t)'u' ||
        parser->bytes[parser->index + 2u] != (uint8_t)'l' ||
        parser->bytes[parser->index + 3u] != (uint8_t)'l')
      return 0;
    parser->index += 4u;
    return 1;
  default:
    return al_campfire_json_parse_number(parser);
  }
}

static int32_t al_campfire_json_parse_null(al_campfire_json_parser *parser) {
  if (parser->length - parser->index < 4u ||
      parser->bytes[parser->index] != (uint8_t)'n' ||
      parser->bytes[parser->index + 1u] != (uint8_t)'u' ||
      parser->bytes[parser->index + 2u] != (uint8_t)'l' ||
      parser->bytes[parser->index + 3u] != (uint8_t)'l')
    return 0;
  parser->index += 4u;
  return 1;
}

static int32_t al_campfire_is_ascii_digit(uint8_t value) {
  return value >= (uint8_t)'0' && value <= (uint8_t)'9';
}

static uint32_t al_campfire_decimal2(const uint8_t *bytes) {
  return (uint32_t)(bytes[0] - (uint8_t)'0') * 10u +
         (uint32_t)(bytes[1] - (uint8_t)'0');
}

static uint32_t al_campfire_decimal4(const uint8_t *bytes) {
  return (uint32_t)(bytes[0] - (uint8_t)'0') * 1000u +
         (uint32_t)(bytes[1] - (uint8_t)'0') * 100u +
         (uint32_t)(bytes[2] - (uint8_t)'0') * 10u +
         (uint32_t)(bytes[3] - (uint8_t)'0');
}

static int32_t al_campfire_is_leap_year(uint32_t year) {
  return year % 4u == 0u && (year % 100u != 0u || year % 400u == 0u);
}

static uint32_t al_campfire_days_before_year(uint32_t year) {
  const uint64_t prior = (uint64_t)year - 1u;
  return (uint32_t)(prior * 365u + prior / 4u - prior / 100u + prior / 400u);
}

static int32_t al_campfire_parse_rails_expiry(
    const uint8_t *text, uint32_t length, int64_t *out_utc_ticks) {
  static const uint8_t days_in_month[12] = {31u, 28u, 31u, 30u, 31u, 30u,
                                            31u, 31u, 30u, 31u, 30u, 31u};
  uint32_t zone_index = UINT32_MAX;
  uint32_t date_time_length;
  uint32_t fractional_digits = 0u;
  uint32_t fractional_ticks = 0u;
  uint32_t year;
  uint32_t month;
  uint32_t day;
  uint32_t hour;
  uint32_t minute;
  uint32_t second;
  uint32_t days = 0u;
  uint32_t month_index;
  int32_t offset_sign = 0;
  uint32_t offset_minutes = 0u;
  uint64_t local_ticks;
  int64_t utc_ticks;
  uint32_t index;
  if (text == NULL || out_utc_ticks == NULL || length < 20u)
    return 0;
  if (text[length - 1u] == (uint8_t)'Z' ||
      text[length - 1u] == (uint8_t)'z') {
    zone_index = length - 1u;
    date_time_length = zone_index;
  } else {
    uint32_t last_plus = UINT32_MAX;
    uint32_t last_minus = UINT32_MAX;
    for (index = 0u; index < length; ++index) {
      if (text[index] == (uint8_t)'+')
        last_plus = index;
      else if (text[index] == (uint8_t)'-')
        last_minus = index;
    }
    if (last_plus == UINT32_MAX && last_minus == UINT32_MAX)
      return 0;
    if (last_plus == UINT32_MAX)
      zone_index = last_minus;
    else if (last_minus == UINT32_MAX)
      zone_index = last_plus;
    else
      zone_index = last_plus > last_minus ? last_plus : last_minus;
    if (zone_index < 19u || length - zone_index != 6u ||
        text[zone_index + 3u] != (uint8_t)':')
      return 0;
    offset_sign = text[zone_index] == (uint8_t)'+' ? 1 : -1;
    if (!al_campfire_is_ascii_digit(text[zone_index + 1u]) ||
        !al_campfire_is_ascii_digit(text[zone_index + 2u]) ||
        !al_campfire_is_ascii_digit(text[zone_index + 4u]) ||
        !al_campfire_is_ascii_digit(text[zone_index + 5u]))
      return 0;
    offset_minutes = al_campfire_decimal2(text + zone_index + 1u) * 60u +
                     al_campfire_decimal2(text + zone_index + 4u);
    if (al_campfire_decimal2(text + zone_index + 4u) > 59u ||
        al_campfire_decimal2(text + zone_index + 1u) > 14u ||
        (al_campfire_decimal2(text + zone_index + 1u) == 14u &&
         al_campfire_decimal2(text + zone_index + 4u) != 0u))
      return 0;
    date_time_length = zone_index;
  }
  if (zone_index == UINT32_MAX || date_time_length < 19u ||
      text[4] != (uint8_t)'-' || text[7] != (uint8_t)'-' ||
      (text[10] != (uint8_t)'T' && text[10] != (uint8_t)'t') ||
      text[13] != (uint8_t)':' || text[16] != (uint8_t)':')
    return 0;
  for (index = 0u; index < 4u; ++index) {
    if (!al_campfire_is_ascii_digit(text[index]))
      return 0;
  }
  if (!al_campfire_is_ascii_digit(text[5]) ||
      !al_campfire_is_ascii_digit(text[6]) ||
      !al_campfire_is_ascii_digit(text[8]) ||
      !al_campfire_is_ascii_digit(text[9]) ||
      !al_campfire_is_ascii_digit(text[11]) ||
      !al_campfire_is_ascii_digit(text[12]) ||
      !al_campfire_is_ascii_digit(text[14]) ||
      !al_campfire_is_ascii_digit(text[15]) ||
      !al_campfire_is_ascii_digit(text[17]) ||
      !al_campfire_is_ascii_digit(text[18]))
    return 0;
  if (date_time_length == 19u) {
    fractional_digits = 0u;
  } else {
    if (text[19] != (uint8_t)'.' || date_time_length < 21u ||
        date_time_length > 27u)
      return 0;
    fractional_digits = date_time_length - 20u;
    for (index = 0u; index < fractional_digits; ++index) {
      if (!al_campfire_is_ascii_digit(text[20u + index]))
        return 0;
      fractional_ticks = fractional_ticks * 10u +
                         (uint32_t)(text[20u + index] - (uint8_t)'0');
    }
    for (; fractional_digits < 7u; ++fractional_digits)
      fractional_ticks *= 10u;
  }
  year = al_campfire_decimal4(text);
  month = al_campfire_decimal2(text + 5u);
  day = al_campfire_decimal2(text + 8u);
  hour = al_campfire_decimal2(text + 11u);
  minute = al_campfire_decimal2(text + 14u);
  second = al_campfire_decimal2(text + 17u);
  if (year == 0u || month == 0u || month > 12u || hour > 23u ||
      minute > 59u || second > 59u)
    return 0;
  for (month_index = 1u; month_index < month; ++month_index) {
    uint32_t month_days = days_in_month[month_index - 1u];
    if (month_index == 2u && al_campfire_is_leap_year(year))
      ++month_days;
    days += month_days;
  }
  if (month == 2u && al_campfire_is_leap_year(year)) {
    if (day > 29u)
      return 0;
  } else if (day > days_in_month[month - 1u]) {
    return 0;
  }
  if (day == 0u)
    return 0;
  days += day - 1u;
  days += al_campfire_days_before_year(year);
  local_ticks = (uint64_t)days * UINT64_C(864000000000) +
                ((uint64_t)hour * 3600u + (uint64_t)minute * 60u + second) *
                    UINT64_C(10000000) +
                fractional_ticks;
  utc_ticks = (int64_t)local_ticks -
              (int64_t)offset_sign * (int64_t)offset_minutes *
                  INT64_C(600000000);
  if (utc_ticks < 0 || utc_ticks > INT64_C(3155378975999999999))
    return 0;
  *out_utc_ticks = utc_ticks;
  return 1;
}

static void al_campfire_rails_fields_init(al_campfire_rails_fields *fields) {
  SecureZeroMemory(fields, sizeof(*fields));
  fields->expiry_valid = 1u;
  /* CookieService retries a failed purpose-specific parse with no expected
   * purpose, where absent, null, and empty string all coerce to "". */
  fields->purpose_matches = 1u;
}

static int32_t al_campfire_json_parse_rails_object(
    al_campfire_json_parser *parser, al_campfire_pure_context *context,
    al_campfire_rails_fields *fields) {
  static const uint8_t rails_message_key[] = "message";
  static const uint8_t rails_purpose_key[] = "pur";
  static const uint8_t rails_expiry_key[] = "exp";
  static const uint8_t expected_purpose[] = "cookie.session_token";
  if (parser->index >= parser->length ||
      parser->bytes[parser->index] != (uint8_t)'{') {
    fields->expiry_valid = 0u;
    return al_campfire_json_parse_value(parser, 1u);
  }
  al_campfire_rails_fields_init(fields);
  ++parser->index;
  al_campfire_json_skip_whitespace(parser);
  if (parser->index < parser->length &&
      parser->bytes[parser->index] == (uint8_t)'}') {
    ++parser->index;
    return 1;
  }
  while (parser->index < parser->length) {
    uint32_t key_length = 0u;
    int32_t key_is_ascii = 0;
    int32_t message_key_matches;
    int32_t purpose_key_matches;
    int32_t expiry_key_matches;
    if (!al_campfire_json_parse_string(
            parser, NULL, 0u, NULL, context->raw_ascii,
            AL_CAMPFIRE_SCRATCH_BYTES, &key_length, &key_is_ascii, NULL, 0u,
            NULL))
      return 0;
    message_key_matches =
        key_is_ascii && key_length == sizeof(rails_message_key) - 1u &&
        memcmp(context->raw_ascii, rails_message_key,
               sizeof(rails_message_key) - 1u) == 0;
    purpose_key_matches =
        key_is_ascii && key_length == sizeof(rails_purpose_key) - 1u &&
        memcmp(context->raw_ascii, rails_purpose_key,
               sizeof(rails_purpose_key) - 1u) == 0;
    expiry_key_matches =
        key_is_ascii && key_length == sizeof(rails_expiry_key) - 1u &&
        memcmp(context->raw_ascii, rails_expiry_key,
               sizeof(rails_expiry_key) - 1u) == 0;
    al_campfire_json_skip_whitespace(parser);
    if (parser->index >= parser->length ||
        parser->bytes[parser->index] != (uint8_t)':')
      return 0;
    ++parser->index;
    al_campfire_json_skip_whitespace(parser);
    if (message_key_matches) {
      fields->message_is_string = 0u;
      fields->message_is_ascii = 0u;
      fields->message_length = 0u;
      if (parser->index < parser->length &&
          parser->bytes[parser->index] == (uint8_t)'"') {
        int32_t is_ascii = 0;
        fields->message_is_string = 1u;
        if (!al_campfire_json_parse_string(
                parser, NULL, 0u, NULL, context->message,
                AL_CAMPFIRE_SCRATCH_BYTES, &fields->message_length,
                &is_ascii, NULL, 0u, NULL))
          return 0;
        fields->message_is_ascii = (uint8_t)(is_ascii != 0);
      } else if (!al_campfire_json_parse_value(parser, 2u)) {
        return 0;
      }
    } else if (purpose_key_matches) {
      fields->purpose_matches = 0u;
      if (parser->index < parser->length &&
          parser->bytes[parser->index] == (uint8_t)'"') {
        uint32_t purpose_length = 0u;
        int32_t purpose_is_ascii = 0;
        if (!al_campfire_json_parse_string(
                parser, NULL, 0u, NULL, context->raw_ascii,
                AL_CAMPFIRE_SCRATCH_BYTES, &purpose_length,
                &purpose_is_ascii, NULL, 0u, NULL))
          return 0;
        fields->purpose_matches =
            (uint8_t)(purpose_is_ascii &&
                      (purpose_length == 0u ||
                       (purpose_length == sizeof(expected_purpose) - 1u &&
                        memcmp(context->raw_ascii, expected_purpose,
                               sizeof(expected_purpose) - 1u) == 0)));
      } else if (al_campfire_json_parse_null(parser)) {
        fields->purpose_matches = 1u;
      } else {
        if (!al_campfire_json_parse_value(parser, 2u))
          return 0;
        fields->purpose_matches = 0u;
      }
    } else if (expiry_key_matches) {
      fields->expiry_present = 1u;
      fields->expiry_valid = 0u;
      if (al_campfire_json_parse_null(parser)) {
        fields->expiry_present = 0u;
        fields->expiry_valid = 1u;
      } else if (parser->index < parser->length &&
                 parser->bytes[parser->index] == (uint8_t)'"') {
        uint32_t expiry_length = 0u;
        int32_t expiry_is_ascii = 0;
        if (!al_campfire_json_parse_string(
                parser, NULL, 0u, NULL, context->raw_ascii,
                AL_CAMPFIRE_SCRATCH_BYTES, &expiry_length,
                &expiry_is_ascii, NULL, 0u, NULL))
          return 0;
        if (expiry_is_ascii &&
            al_campfire_parse_rails_expiry(context->raw_ascii, expiry_length,
                                           &fields->expiry_utc_ticks))
          fields->expiry_valid = 1u;
      } else if (!al_campfire_json_parse_value(parser, 2u)) {
        return 0;
      }
    } else if (!al_campfire_json_parse_value(parser, 2u)) {
      return 0;
    }
    al_campfire_json_skip_whitespace(parser);
    if (parser->index < parser->length &&
        parser->bytes[parser->index] == (uint8_t)'}') {
      ++parser->index;
      return 1;
    }
    if (parser->index >= parser->length ||
        parser->bytes[parser->index] != (uint8_t)',')
      return 0;
    ++parser->index;
    al_campfire_json_skip_whitespace(parser);
  }
  return 0;
}

static int32_t al_campfire_json_parse_rails_envelope(
    const uint8_t *bytes, uint32_t length,
    al_campfire_pure_context *context,
    al_campfire_rails_fields *out_fields) {
  static const uint8_t rails_key[] = "_rails";
  al_campfire_json_parser parser;
  al_campfire_rails_fields last_rails;
  uint8_t rails_seen = 0u;
  if (bytes == NULL || context == NULL || out_fields == NULL ||
      length == 0u || length > 16384u)
    return 0;
  parser.bytes = bytes;
  parser.length = length;
  parser.index = 0u;
  al_campfire_json_skip_whitespace(&parser);
  if (parser.index >= parser.length ||
      parser.bytes[parser.index] != (uint8_t)'{')
    return 0;
  ++parser.index;
  al_campfire_json_skip_whitespace(&parser);
  if (parser.index < parser.length &&
      parser.bytes[parser.index] == (uint8_t)'}')
    return 0;
  while (parser.index < parser.length) {
    uint32_t key_length = 0u;
    int32_t key_is_ascii = 0;
    int32_t is_rails = 0;
    if (!al_campfire_json_parse_string(
            &parser, NULL, 0u, NULL, context->raw_ascii,
            AL_CAMPFIRE_SCRATCH_BYTES, &key_length, &key_is_ascii, NULL, 0u,
            NULL))
      return 0;
    is_rails = key_is_ascii && key_length == sizeof(rails_key) - 1u &&
               memcmp(context->raw_ascii, rails_key,
                      sizeof(rails_key) - 1u) == 0;
    al_campfire_json_skip_whitespace(&parser);
    if (parser.index >= parser.length ||
        parser.bytes[parser.index] != (uint8_t)':')
      return 0;
    ++parser.index;
    al_campfire_json_skip_whitespace(&parser);
    if (is_rails) {
      al_campfire_rails_fields current;
      al_campfire_rails_fields_init(&current);
      if (!al_campfire_json_parse_rails_object(&parser, context, &current))
        return 0;
      last_rails = current;
      rails_seen = 1u;
    } else if (!al_campfire_json_parse_value(&parser, 1u)) {
      return 0;
    }
    al_campfire_json_skip_whitespace(&parser);
    if (parser.index < parser.length &&
        parser.bytes[parser.index] == (uint8_t)'}') {
      ++parser.index;
      al_campfire_json_skip_whitespace(&parser);
      if (parser.index != parser.length || !rails_seen)
        return 0;
      *out_fields = last_rails;
      return 1;
    }
    if (parser.index >= parser.length ||
        parser.bytes[parser.index] != (uint8_t)',')
      return 0;
    ++parser.index;
    al_campfire_json_skip_whitespace(&parser);
  }
  return 0;
}

static int32_t al_campfire_json_root_string(
    const uint8_t *bytes, uint32_t length, uint16_t *out_token,
    uint32_t token_capacity, uint32_t *out_token_units) {
  al_campfire_json_parser parser;
  int32_t is_string = 0;
  if (bytes == NULL || out_token == NULL || out_token_units == NULL ||
      length == 0u || length > 16384u)
    return 0;
  parser.bytes = bytes;
  parser.length = length;
  parser.index = 0u;
  al_campfire_json_skip_whitespace(&parser);
  if (parser.index >= parser.length)
    return 0;
  if (parser.bytes[parser.index] == (uint8_t)'"') {
    is_string = 1;
    if (!al_campfire_json_parse_string(
            &parser, out_token, token_capacity, out_token_units, NULL, 0u,
            NULL, NULL, NULL, 0u, NULL))
      return 0;
  } else if (!al_campfire_json_parse_value(&parser, 0u)) {
    return 0;
  }
  al_campfire_json_skip_whitespace(&parser);
  return is_string && parser.index == parser.length;
}

/* Returns -1 for a CNG boundary failure, 0 for a bad digest, and 1 for a
 * constant-time digest match. */
static int32_t al_campfire_verify_digest(
    al_campfire_pure_context *context, const uint8_t *encoded,
    uint32_t encoded_length, const uint8_t *actual_hex) {
  static const uint8_t hex[] = "0123456789abcdef";
  BCRYPT_HASH_HANDLE hash = NULL;
  uint8_t digest[AL_CAMPFIRE_SHA1_BYTES];
  uint8_t expected_hex[AL_CAMPFIRE_HEX_SHA1_BYTES];
  uint32_t index;
  uint32_t difference = 0u;
  NTSTATUS status;
  SecureZeroMemory(digest, sizeof(digest));
  SecureZeroMemory(expected_hex, sizeof(expected_hex));
  status = BCryptCreateHash(context->hmac_sha1_algorithm, &hash,
                            context->hmac_object, context->hmac_object_bytes,
                            context->signing_key,
                            AL_CAMPFIRE_SIGNING_KEY_BYTES, 0u);
  if (!BCRYPT_SUCCESS(status))
    goto crypto_failure;
  status = BCryptHashData(hash, (PUCHAR)encoded, encoded_length, 0u);
  if (!BCRYPT_SUCCESS(status))
    goto crypto_failure;
  status = BCryptFinishHash(hash, digest, sizeof(digest), 0u);
  if (!BCRYPT_SUCCESS(status))
    goto crypto_failure;
  for (index = 0u; index < AL_CAMPFIRE_SHA1_BYTES; ++index) {
    expected_hex[index * 2u] = hex[digest[index] >> 4u];
    expected_hex[index * 2u + 1u] = hex[digest[index] & 0x0fu];
  }
  for (index = 0u; index < AL_CAMPFIRE_HEX_SHA1_BYTES; ++index)
    difference |= (uint32_t)(expected_hex[index] ^ actual_hex[index]);
  BCryptDestroyHash(hash);
  SecureZeroMemory(context->hmac_object, context->hmac_object_bytes);
  SecureZeroMemory(digest, sizeof(digest));
  SecureZeroMemory(expected_hex, sizeof(expected_hex));
  return difference == 0u ? 1 : 0;

crypto_failure:
  if (hash != NULL)
    BCryptDestroyHash(hash);
  SecureZeroMemory(context->hmac_object, context->hmac_object_bytes);
  SecureZeroMemory(digest, sizeof(digest));
  SecureZeroMemory(expected_hex, sizeof(expected_hex));
  return -1;
}

static int32_t al_campfire_parse_verified_cookie(
    al_campfire_pure_context *context,
    const al_campfire_string_view *raw_view, int64_t now_microseconds,
    uint32_t *out_token_units) {
  static const uint8_t envelope_prefix[] =
      "{\"_rails\":{\"message\":\"";
  uint32_t raw_utf8_bytes = 0u;
  uint32_t raw_units;
  uint32_t encoded_length;
  uint32_t payload_length = 0u;
  uint32_t inner_length = 0u;
  uint32_t index;
  int32_t digest_result;
  int64_t now_ticks;
  if (context == NULL || raw_view == NULL || out_token_units == NULL ||
      !al_campfire_utf8_byte_count(
          raw_view, AL_CAMPFIRE_COOKIE_MAX_BYTES -
                        AL_CAMPFIRE_COOKIE_NAME_BYTES,
          &raw_utf8_bytes) ||
      raw_utf8_bytes + AL_CAMPFIRE_COOKIE_NAME_BYTES >
          AL_CAMPFIRE_COOKIE_MAX_BYTES ||
      !al_campfire_string_is_ascii(raw_view))
    return 0;
  raw_units = raw_view->code_units;
  if (raw_units < 42u || raw_units >= AL_CAMPFIRE_SCRATCH_BYTES)
    return 0;
  for (index = 0u; index < raw_units; ++index)
    context->raw_ascii[index] = (uint8_t)al_campfire_string_unit(raw_view, index);
  encoded_length = raw_units - 42u;
  if (encoded_length == 0u ||
      context->raw_ascii[encoded_length] != (uint8_t)'-' ||
      context->raw_ascii[encoded_length + 1u] != (uint8_t)'-')
    return 0;
  for (index = 0u; index < AL_CAMPFIRE_HEX_SHA1_BYTES; ++index) {
    const uint8_t digit = context->raw_ascii[encoded_length + 2u + index];
    if (!((digit >= (uint8_t)'0' && digit <= (uint8_t)'9') ||
          (digit >= (uint8_t)'a' && digit <= (uint8_t)'f')))
      return 0;
  }
  digest_result = al_campfire_verify_digest(
      context, context->raw_ascii, encoded_length,
      context->raw_ascii + encoded_length + 2u);
  if (digest_result <= 0)
    return digest_result;
  if (!al_campfire_decode_base64_urlsafe(
          context->raw_ascii, encoded_length, context->payload,
          sizeof(context->payload), &payload_length))
    return 0;

  if (payload_length >= sizeof(envelope_prefix) - 1u &&
      memcmp(context->payload, envelope_prefix,
             sizeof(envelope_prefix) - 1u) == 0) {
    al_campfire_rails_fields fields;
    int64_t expiry_utc_ticks;
    if (!al_campfire_json_parse_rails_envelope(
            context->payload, payload_length, context, &fields) ||
        !fields.message_is_string || !fields.message_is_ascii ||
        !fields.purpose_matches || !fields.expiry_valid)
      return 0;
    if (fields.expiry_present) {
      expiry_utc_ticks = fields.expiry_utc_ticks;
      now_ticks = INT64_C(621355968000000000) +
                  now_microseconds * INT64_C(10);
      if (now_ticks >= expiry_utc_ticks)
        return 0;
    }
    if (!al_campfire_decode_base64_urlsafe(
            context->message, fields.message_length, context->inner_json,
            sizeof(context->inner_json), &inner_length))
      return 0;
    if (!al_campfire_json_root_string(
            context->inner_json, inner_length, context->token,
            AL_CAMPFIRE_TOKEN_UNITS, out_token_units))
      return 0;
    return 1;
  }

  if (!al_campfire_json_root_string(context->payload, payload_length,
                                    context->token,
                                    AL_CAMPFIRE_TOKEN_UNITS,
                                    out_token_units))
    return 0;
  return 1;
}

static int32_t al_campfire_cookie_output_valid(
    const al_owning_layout *layout, uint32_t output_type_index) {
  const al_owning_type_descriptor *option;
  const al_owning_field_descriptor *some_field;
  const al_owning_field_descriptor *none_field;
  if (!al_campfire_layout_valid(layout) ||
      output_type_index >= layout->type_count)
    return 0;
  option = &layout->types[output_type_index];
  if (option->kind != AL_OWNING_TYPE_OPTION || option->case_count != 2u ||
      option->field_count != 2u ||
      option->first_field > layout->field_count ||
      option->field_count > layout->field_count - option->first_field)
    return 0;
  some_field = &layout->fields[option->first_field];
  none_field = &layout->fields[option->first_field + 1u];
  if (some_field->child_type_index >= layout->type_count ||
      layout->types[some_field->child_type_index].kind != AL_OWNING_TYPE_STRING ||
      some_field->fixed_offset_bytes != 8u || some_field->flags != 0u ||
      some_field->reserved != 0u ||
      none_field->child_type_index != AL_OWNING_LAYOUT_DYNAMIC_U32 ||
      none_field->fixed_offset_bytes != 8u || none_field->flags != 0u ||
      none_field->reserved != 0u)
    return 0;
  return 1;
}

static int32_t al_campfire_write_cookie_none(
    uint8_t *output, uint32_t output_capacity_bytes,
    uint32_t *output_extent_bytes) {
  if (output == NULL || output_extent_bytes == NULL ||
      output_capacity_bytes < 8u)
    return 1;
  al_campfire_write_u64_le(output, 0u);
  *output_extent_bytes = 8u;
  return 0;
}

static int32_t al_campfire_write_cookie_some(
    const al_owning_layout *layout, uint32_t output_type_index,
    const uint16_t *token, uint32_t token_units, uint8_t *output,
    uint32_t output_capacity_bytes, uint32_t *output_extent_bytes) {
  const uint64_t string_payload = 8u + (uint64_t)token_units * 2u;
  const uint64_t string_extent = (string_payload + 7u) & ~UINT64_C(7);
  const uint64_t total_extent = 8u + string_extent;
  uint32_t index;
  if (output == NULL || token == NULL || output_extent_bytes == NULL ||
      !al_campfire_cookie_output_valid(layout, output_type_index) ||
      total_extent > UINT32_MAX || total_extent > output_capacity_bytes)
    return 1;
  SecureZeroMemory(output, (size_t)total_extent);
  al_campfire_write_u64_le(output, 1u);
  al_campfire_write_u32_le(output + 8u, token_units);
  for (index = 0u; index < token_units; ++index)
    al_campfire_write_u16_le(output + 16u + index * 2u, token[index]);
  *output_extent_bytes = (uint32_t)total_extent;
  return 0;
}

uint32_t al_campfire_pure_context_size_v1(void) {
  return (uint32_t)sizeof(al_campfire_pure_context);
}

uint32_t al_campfire_pure_context_alignment_v1(void) {
  return (uint32_t)__alignof(al_campfire_pure_context);
}

int32_t al_campfire_pure_context_init_v1(void *storage,
                                        uint32_t storage_bytes,
                                        const uint8_t *secret_utf8,
                                        uint32_t secret_length) {
  static const uint8_t signed_cookie_salt[] = "signed cookie";
  al_campfire_pure_context *context;
  BCRYPT_ALG_HANDLE sha256_algorithm = NULL;
  ULONG result_bytes = 0u;
  ULONG object_bytes = 0u;
  NTSTATUS status;
  if (storage == NULL || storage_bytes < sizeof(al_campfire_pure_context) ||
      ((uintptr_t)storage % __alignof(al_campfire_pure_context)) != 0u ||
      secret_utf8 == NULL || secret_length < 30u)
    return 1;
  context = (al_campfire_pure_context *)storage;
  SecureZeroMemory(context, sizeof(*context));
  InitializeSRWLock(&context->lock);
  status = BCryptOpenAlgorithmProvider(&sha256_algorithm,
                                       BCRYPT_SHA256_ALGORITHM, NULL,
                                       BCRYPT_ALG_HANDLE_HMAC_FLAG);
  if (!BCRYPT_SUCCESS(status))
    goto initialization_failure;
  status = BCryptDeriveKeyPBKDF2(
      sha256_algorithm, (PUCHAR)secret_utf8, secret_length,
      (PUCHAR)signed_cookie_salt,
      (ULONG)(sizeof(signed_cookie_salt) - 1u), 1000u,
      context->signing_key, AL_CAMPFIRE_SIGNING_KEY_BYTES, 0u);
  if (!BCRYPT_SUCCESS(status))
    goto initialization_failure;
  status = BCryptOpenAlgorithmProvider(
      &context->hmac_sha1_algorithm, BCRYPT_SHA1_ALGORITHM, NULL,
      BCRYPT_ALG_HANDLE_HMAC_FLAG);
  if (!BCRYPT_SUCCESS(status))
    goto initialization_failure;
  status = BCryptGetProperty(context->hmac_sha1_algorithm, BCRYPT_OBJECT_LENGTH,
                             (PUCHAR)&object_bytes, sizeof(object_bytes),
                             &result_bytes, 0u);
  if (!BCRYPT_SUCCESS(status) || result_bytes != sizeof(object_bytes) ||
      object_bytes == 0u || object_bytes > sizeof(context->hmac_object))
    goto initialization_failure;
  context->hmac_object_bytes = object_bytes;
  context->magic = AL_CAMPFIRE_PURE_CONTEXT_MAGIC;
  BCryptCloseAlgorithmProvider(sha256_algorithm, 0u);
  return 0;

initialization_failure:
  if (sha256_algorithm != NULL)
    BCryptCloseAlgorithmProvider(sha256_algorithm, 0u);
  if (context->hmac_sha1_algorithm != NULL) {
    BCryptCloseAlgorithmProvider(context->hmac_sha1_algorithm, 0u);
    context->hmac_sha1_algorithm = NULL;
  }
  SecureZeroMemory(context, sizeof(*context));
  return 1;
}

void al_campfire_pure_context_destroy_v1(void *pure_context) {
  al_campfire_pure_context *context =
      (al_campfire_pure_context *)pure_context;
  if (context == NULL || context->magic != AL_CAMPFIRE_PURE_CONTEXT_MAGIC)
    return;
  AcquireSRWLockExclusive(&context->lock);
  context->magic = 0u;
  if (context->hmac_sha1_algorithm != NULL) {
    BCryptCloseAlgorithmProvider(context->hmac_sha1_algorithm, 0u);
    context->hmac_sha1_algorithm = NULL;
  }
  al_campfire_clear_scratch(context);
  SecureZeroMemory(context->signing_key, sizeof(context->signing_key));
  ReleaseSRWLockExclusive(&context->lock);
  SecureZeroMemory(context, sizeof(*context));
}

int32_t al_campfire_verify_cookie_v1(
    void *pure_context, const al_owning_layout *layout,
    const al_campfire_room_read_input *inputs, uint32_t input_count,
    uint32_t output_type_index, uint8_t *output,
    uint32_t output_capacity_bytes, uint32_t *output_extent_bytes) {
  al_campfire_pure_context *context =
      (al_campfire_pure_context *)pure_context;
  al_campfire_string_view raw_cookie;
  int64_t now_microseconds = 0;
  uint32_t token_units = 0u;
  int32_t token_valid = 0;
  int32_t status = 1;
  if (output_extent_bytes != NULL)
    *output_extent_bytes = 0u;
  if (context == NULL || context->magic != AL_CAMPFIRE_PURE_CONTEXT_MAGIC ||
      !al_campfire_layout_valid(layout) || inputs == NULL || input_count != 2u ||
      output == NULL || output_extent_bytes == NULL ||
      !al_campfire_cookie_output_valid(layout, output_type_index) ||
      !al_campfire_read_input_string(layout, &inputs[0], &raw_cookie) ||
      !al_campfire_read_input_i64(layout, &inputs[1], &now_microseconds) ||
      now_microseconds < INT64_C(-62135596800000000) ||
      now_microseconds > INT64_C(253402300799999999))
    return 1;
  AcquireSRWLockExclusive(&context->lock);
  if (context->magic != AL_CAMPFIRE_PURE_CONTEXT_MAGIC)
    goto cleanup;
  al_campfire_clear_scratch(context);
  token_valid = al_campfire_parse_verified_cookie(
      context, &raw_cookie, now_microseconds, &token_units);
  if (token_valid < 0)
    goto cleanup;
  if (token_valid != 0) {
    status = al_campfire_write_cookie_some(
        layout, output_type_index, context->token, token_units, output,
        output_capacity_bytes, output_extent_bytes);
  } else {
    status = al_campfire_write_cookie_none(
        output, output_capacity_bytes, output_extent_bytes);
  }

cleanup:
  al_campfire_clear_scratch(context);
  ReleaseSRWLockExclusive(&context->lock);
  return status;
}

static int32_t al_campfire_is_ascii_digit_unit(
    const al_campfire_string_view *view, uint32_t index) {
  const uint16_t value = al_campfire_string_unit(view, index);
  return value >= (uint16_t)'0' && value <= (uint16_t)'9';
}

static int32_t al_campfire_is_ascii_letter_unit(
    const al_campfire_string_view *view, uint32_t index) {
  const uint16_t value = al_campfire_string_unit(view, index);
  return (value >= (uint16_t)'A' && value <= (uint16_t)'Z') ||
         (value >= (uint16_t)'a' && value <= (uint16_t)'z');
}

static int32_t al_campfire_is_ruby_space(uint16_t value) {
  return value == (uint16_t)' ' || value == (uint16_t)'\t' ||
         value == (uint16_t)'\n' || value == 0x000bu ||
         value == 0x000cu || value == (uint16_t)'\r';
}

static int32_t al_campfire_string_is_blank(
    const al_campfire_string_view *view) {
  uint32_t index;
  for (index = 0u; index < view->code_units; ++index) {
    if (!al_campfire_is_ruby_space(al_campfire_string_unit(view, index)))
      return 0;
  }
  return 1;
}

static uint32_t al_campfire_initial_digit_count(
    const al_campfire_string_view *view) {
  uint32_t index = 0u;
  while (index < view->code_units &&
         al_campfire_is_ascii_digit_unit(view, index))
    ++index;
  return index;
}

static int32_t al_campfire_version_is_comparable(
    const al_campfire_string_view *view) {
  const uint32_t digits = al_campfire_initial_digit_count(view);
  return !al_campfire_string_is_blank(view) && digits > 0u &&
         (digits == view->code_units ||
          al_campfire_string_unit(view, digits) == (uint16_t)'.');
}

static int32_t al_campfire_next_version_segment(
    const al_campfire_string_view *view, uint32_t *cursor,
    al_campfire_version_segment *out_segment) {
  uint32_t index = *cursor;
  while (index < view->code_units) {
    if (al_campfire_is_ascii_digit_unit(view, index)) {
      const uint32_t start = index;
      uint32_t normalized_start;
      while (index < view->code_units &&
             al_campfire_is_ascii_digit_unit(view, index))
        ++index;
      normalized_start = start;
      while (normalized_start < index &&
             al_campfire_string_unit(view, normalized_start) ==
                 (uint16_t)'0')
        ++normalized_start;
      out_segment->kind = AL_CAMPFIRE_SEGMENT_INTEGER;
      out_segment->owner = view;
      out_segment->is_zero_literal = normalized_start == index;
      out_segment->start_unit = out_segment->is_zero_literal ? index - 1u
                                                              : normalized_start;
      out_segment->length_units = out_segment->is_zero_literal
                                      ? 1u
                                      : index - normalized_start;
      *cursor = index;
      return 1;
    }
    if (al_campfire_is_ascii_letter_unit(view, index)) {
      const uint32_t start = index;
      uint32_t finish = index + 1u;
      while (finish < view->code_units &&
             (al_campfire_is_ascii_letter_unit(view, finish) ||
              al_campfire_is_ascii_digit_unit(view, finish) ||
              al_campfire_string_unit(view, finish) == (uint16_t)'-'))
        ++finish;
      if (finish == view->code_units) {
        out_segment->kind = AL_CAMPFIRE_SEGMENT_TEXT;
        out_segment->owner = view;
        out_segment->start_unit = start;
        out_segment->length_units = finish - start;
        out_segment->is_zero_literal = 0u;
        *cursor = finish;
        return 1;
      }
      index = start + 1u;
    } else {
      ++index;
    }
  }
  *cursor = view->code_units;
  return 0;
}

static int32_t al_campfire_get_segment(
    const al_campfire_string_view *view, int32_t comparable, int32_t blank,
    uint32_t *cursor, uint32_t index,
    al_campfire_version_segment *out_segment) {
  if (blank)
    return 0;
  if (!comparable) {
    if (index != 0u)
      return 0;
    out_segment->kind = AL_CAMPFIRE_SEGMENT_TEXT;
    out_segment->owner = view;
    out_segment->start_unit = 0u;
    out_segment->length_units = view->code_units;
    out_segment->is_zero_literal = 0u;
    return 1;
  }
  return al_campfire_next_version_segment(view, cursor, out_segment);
}

typedef struct al_campfire_utf8_iterator {
  const al_campfire_string_view *view;
  uint32_t index;
  uint32_t end;
  uint8_t pending[4];
  uint32_t pending_index;
  uint32_t pending_length;
} al_campfire_utf8_iterator;

static int32_t al_campfire_utf8_next(al_campfire_utf8_iterator *iterator,
                                     uint8_t *out_byte) {
  if (iterator->pending_index < iterator->pending_length) {
    *out_byte = iterator->pending[iterator->pending_index++];
    return 1;
  }
  if (iterator->index >= iterator->end)
    return 0;
  {
    uint32_t scalar;
    const uint16_t first =
        al_campfire_string_unit(iterator->view, iterator->index++);
    iterator->pending_index = 0u;
    if (first >= 0xd800u && first <= 0xdbffu &&
        iterator->index < iterator->end) {
      const uint16_t second =
          al_campfire_string_unit(iterator->view, iterator->index);
      if (second >= 0xdc00u && second <= 0xdfffu) {
        ++iterator->index;
        scalar = 0x10000u +
                 ((((uint32_t)first - 0xd800u) << 10u) |
                  ((uint32_t)second - 0xdc00u));
      } else {
        scalar = 0xfffdu;
      }
    } else if (first >= 0xd800u && first <= 0xdfffu) {
      scalar = 0xfffdu;
    } else {
      scalar = first;
    }
    if (scalar <= 0x7fu) {
      iterator->pending[0] = (uint8_t)scalar;
      iterator->pending_length = 1u;
    } else if (scalar <= 0x7ffu) {
      iterator->pending[0] = (uint8_t)(0xc0u | (scalar >> 6u));
      iterator->pending[1] = (uint8_t)(0x80u | (scalar & 0x3fu));
      iterator->pending_length = 2u;
    } else if (scalar <= 0xffffu) {
      iterator->pending[0] = (uint8_t)(0xe0u | (scalar >> 12u));
      iterator->pending[1] = (uint8_t)(0x80u | ((scalar >> 6u) & 0x3fu));
      iterator->pending[2] = (uint8_t)(0x80u | (scalar & 0x3fu));
      iterator->pending_length = 3u;
    } else {
      iterator->pending[0] = (uint8_t)(0xf0u | (scalar >> 18u));
      iterator->pending[1] = (uint8_t)(0x80u | ((scalar >> 12u) & 0x3fu));
      iterator->pending[2] = (uint8_t)(0x80u | ((scalar >> 6u) & 0x3fu));
      iterator->pending[3] = (uint8_t)(0x80u | (scalar & 0x3fu));
      iterator->pending_length = 4u;
    }
  }
  *out_byte = iterator->pending[iterator->pending_index++];
  return 1;
}

static int32_t al_campfire_compare_utf8_segments(
    const al_campfire_version_segment *left,
    const al_campfire_version_segment *right) {
  al_campfire_utf8_iterator left_iterator;
  al_campfire_utf8_iterator right_iterator;
  uint8_t left_byte;
  uint8_t right_byte;
  left_iterator.view = left->owner;
  left_iterator.index = left->start_unit;
  left_iterator.end = left->start_unit + left->length_units;
  left_iterator.pending_index = 0u;
  left_iterator.pending_length = 0u;
  right_iterator.view = right->owner;
  right_iterator.index = right->start_unit;
  right_iterator.end = right->start_unit + right->length_units;
  right_iterator.pending_index = 0u;
  right_iterator.pending_length = 0u;
  for (;;) {
    const int32_t has_left = al_campfire_utf8_next(&left_iterator, &left_byte);
    const int32_t has_right =
        al_campfire_utf8_next(&right_iterator, &right_byte);
    if (!has_left || !has_right) {
      if (has_left)
        return 1;
      if (has_right)
        return -1;
      return 0;
    }
    if (left_byte != right_byte)
      return left_byte < right_byte ? -1 : 1;
  }
}

static int32_t al_campfire_compare_segments(
    const al_campfire_version_segment *left,
    const al_campfire_version_segment *right) {
  if (left->kind == AL_CAMPFIRE_SEGMENT_INTEGER &&
      right->kind == AL_CAMPFIRE_SEGMENT_INTEGER) {
    uint32_t index;
    if (left->length_units != right->length_units)
      return left->length_units < right->length_units ? -1 : 1;
    for (index = 0u; index < left->length_units; ++index) {
      const uint16_t left_value = left->is_zero_literal
                                      ? (uint16_t)'0'
                                      : al_campfire_string_unit(
                                            left->owner,
                                            left->start_unit + index);
      const uint16_t right_value = right->is_zero_literal
                                       ? (uint16_t)'0'
                                       : al_campfire_string_unit(
                                             right->owner,
                                             right->start_unit + index);
      if (left_value != right_value)
        return left_value < right_value ? -1 : 1;
    }
    return 0;
  }
  if (left->kind == AL_CAMPFIRE_SEGMENT_TEXT &&
      right->kind == AL_CAMPFIRE_SEGMENT_INTEGER)
    return -1;
  if (left->kind == AL_CAMPFIRE_SEGMENT_INTEGER &&
      right->kind == AL_CAMPFIRE_SEGMENT_TEXT)
    return 1;
  return al_campfire_compare_utf8_segments(left, right);
}

static int32_t al_campfire_compare_versions(
    const al_campfire_string_view *left,
    const al_campfire_string_view *right) {
  uint32_t left_cursor = 0u;
  uint32_t right_cursor = 0u;
  uint32_t index;
  const int32_t left_comparable = al_campfire_version_is_comparable(left);
  const int32_t right_comparable = al_campfire_version_is_comparable(right);
  const int32_t left_blank = al_campfire_string_is_blank(left);
  const int32_t right_blank = al_campfire_string_is_blank(right);
  if (!left_comparable) {
    uint32_t unit;
    if (left->code_units == right->code_units) {
      for (unit = 0u; unit < left->code_units; ++unit) {
        if (al_campfire_string_unit(left, unit) !=
            al_campfire_string_unit(right, unit))
          return -1;
      }
      return 0;
    }
    return -1;
  }
  for (index = 0u; index < 6u; ++index) {
    al_campfire_version_segment left_segment;
    al_campfire_version_segment right_segment;
    const int32_t has_left = al_campfire_get_segment(
        left, left_comparable, left_blank, &left_cursor, index, &left_segment);
    const int32_t has_right = al_campfire_get_segment(
        right, right_comparable, right_blank, &right_cursor, index,
        &right_segment);
    int32_t result;
    if (!has_left) {
      left_segment.kind = AL_CAMPFIRE_SEGMENT_INTEGER;
      left_segment.owner = NULL;
      left_segment.start_unit = 0u;
      left_segment.length_units = 1u;
      left_segment.is_zero_literal = 1u;
    }
    if (!has_right) {
      right_segment.kind = AL_CAMPFIRE_SEGMENT_INTEGER;
      right_segment.owner = NULL;
      right_segment.start_unit = 0u;
      right_segment.length_units = 1u;
      right_segment.is_zero_literal = 1u;
    }
    result = al_campfire_compare_segments(&left_segment, &right_segment);
    if (result != 0)
      return result;
  }
  return 0;
}

int32_t al_campfire_browser_version_v1(
    void *pure_context, const al_owning_layout *layout,
    const al_campfire_room_read_input *inputs, uint32_t input_count,
    uint32_t output_type_index, uint8_t *output,
    uint32_t output_capacity_bytes, uint32_t *output_extent_bytes) {
  al_campfire_string_view version;
  al_campfire_string_view minimum;
  uint64_t result;
  (void)pure_context;
  if (output_extent_bytes != NULL)
    *output_extent_bytes = 0u;
  if (!al_campfire_layout_valid(layout) || inputs == NULL || input_count != 2u ||
      output == NULL || output_extent_bytes == NULL || output_capacity_bytes < 8u ||
      output_type_index >= layout->type_count ||
      layout->types[output_type_index].kind != AL_OWNING_TYPE_BOOL ||
      !al_campfire_read_input_string(layout, &inputs[0], &version) ||
      !al_campfire_read_input_string(layout, &inputs[1], &minimum))
    return 1;
  result = al_campfire_compare_versions(&version, &minimum) >= 0 ? 1u : 0u;
  al_campfire_write_u64_le(output, result);
  *output_extent_bytes = 8u;
  return 0;
}


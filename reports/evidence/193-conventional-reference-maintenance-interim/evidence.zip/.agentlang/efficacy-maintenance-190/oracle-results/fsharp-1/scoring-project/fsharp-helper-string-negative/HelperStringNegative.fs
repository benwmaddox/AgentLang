namespace AgentLang.TypedReferenceMaintenance.Oracle184

open AgentLang.TypedReferenceMaintenance.Domain

module HelperStringNegative =
    let private subject : Shipment =
        { Id = ShipmentId.create "ship-a"; Label = "probe"; Scans = [] }

    let invalid : Scan option = Shipment.findScan subject "raw-string"

namespace AgentLang.TypedReferenceMaintenance.Oracle184

open AgentLang.TypedReferenceMaintenance.Domain

module Negative =
    let invalid : ScanInput =
        { ShipmentId = ShipmentId.create "ship-a"; Reference = ShipmentId.create "raw-id"; Status = "received" }

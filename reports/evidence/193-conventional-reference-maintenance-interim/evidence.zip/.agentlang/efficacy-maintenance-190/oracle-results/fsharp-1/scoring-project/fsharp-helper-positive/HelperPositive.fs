namespace AgentLang.TypedReferenceMaintenance.Oracle184

open AgentLang.TypedReferenceMaintenance.Domain

module HelperSignatureProbe =
    let private subject : Shipment =
        { Id = ShipmentId.create "ship-a"; Label = "probe"; Scans = [] }

    let private typedReference : TrackingReference = unbox<TrackingReference> null

    let positive : Scan option = Shipment.findScan subject typedReference

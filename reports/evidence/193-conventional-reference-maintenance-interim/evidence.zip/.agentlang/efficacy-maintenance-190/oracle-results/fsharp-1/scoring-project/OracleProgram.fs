namespace AgentLang.TypedReferenceMaintenance.Oracle184

open System
open System.Text.Json
open System.Text.Json.Nodes
open Microsoft.FSharp.Reflection
open AgentLang.TypedReferenceMaintenance.Domain

module Program =
    let private makeReference<'T> (raw: string) : 'T =
        let referenceType = typeof<'T>
        if referenceType = typeof<string> then unbox<'T> (box raw)
        elif FSharpType.IsUnion(referenceType, allowAccessToPrivateRepresentation = true) then
            let cases = FSharpType.GetUnionCases(referenceType, allowAccessToPrivateRepresentation = true)
            if cases.Length <> 1 then failwithf "Reference wrapper %s is not a single-case union" referenceType.FullName
            let fields = cases[0].GetFields()
            if fields.Length <> 1 || fields[0].PropertyType <> typeof<string> then
                failwithf "Reference wrapper %s does not contain one String" referenceType.FullName
            FSharpValue.MakeUnion(cases[0], [| box raw |], allowAccessToPrivateRepresentation = true) :?> 'T
        elif FSharpType.IsRecord(referenceType, allowAccessToPrivateRepresentation = true) then
            let fields = FSharpType.GetRecordFields(referenceType, allowAccessToPrivateRepresentation = true)
            if fields.Length <> 1 || fields[0].PropertyType <> typeof<string> then
                failwithf "Reference wrapper %s does not contain one String" referenceType.FullName
            FSharpValue.MakeRecord(referenceType, [| box raw |], allowAccessToPrivateRepresentation = true) :?> 'T
        else
            failwithf "Reference wrapper %s is neither a single-case union nor a one-field record" referenceType.FullName

    let private referenceValue<'T> (value: 'T) : string =
        let referenceType = typeof<'T>
        if referenceType = typeof<string> then unbox<string> (box value)
        elif FSharpType.IsUnion(referenceType, allowAccessToPrivateRepresentation = true) then
            let _, fields = FSharpValue.GetUnionFields(box value, referenceType, allowAccessToPrivateRepresentation = true)
            unbox<string> fields.[0]
        elif FSharpType.IsRecord(referenceType, allowAccessToPrivateRepresentation = true) then
            let fields = FSharpValue.GetRecordFields(box value, allowAccessToPrivateRepresentation = true)
            unbox<string> fields.[0]
        else
            failwithf "Reference wrapper %s is neither a single-case union nor a one-field record" referenceType.FullName

    let private mkScan (reference: string) (status: string) : Scan =
        { Reference = makeReference reference; Status = status }

    let private mkShipment (id: string) (label: string) (scans: Scan list) : Shipment =
        { Id = ShipmentId.create id; Label = label; Scans = scans }

    let private mkStore (shipments: Shipment list) (audit: string) (generation: int) : Store =
        { Shipments = shipments; Audit = audit; Generation = generation }

    let private mkInput (shipmentId: string) (reference: string) (status: string) : ScanInput =
        { ShipmentId = ShipmentId.create shipmentId; Reference = makeReference reference; Status = status }

    let private storeJson (value: Store) : JsonObject =
        let shipments = JsonArray()
        for shipment in value.Shipments do
            let scans = JsonArray()
            for scan in shipment.Scans do
                let scanNode = JsonObject()
                scanNode["reference"] <- JsonValue.Create(referenceValue scan.Reference)
                scanNode["status"] <- JsonValue.Create(scan.Status)
                scans.Add(scanNode)
            let shipmentNode = JsonObject()
            shipmentNode["id"] <- JsonValue.Create(ShipmentId.value shipment.Id)
            shipmentNode["label"] <- JsonValue.Create(shipment.Label)
            shipmentNode["scans"] <- scans
            shipments.Add(shipmentNode)
        let node = JsonObject()
        node["shipments"] <- shipments
        node["audit"] <- JsonValue.Create(value.Audit)
        node["generation"] <- JsonValue.Create(value.Generation)
        node

    let private observationJson (input: Store) (outcome: Result<Store, ScanError>) : JsonObject =
        let node = JsonObject()
        match outcome with
        | Ok result ->
            node["tag"] <- JsonValue.Create("ok")
            node["store"] <- storeJson result
            node["input"] <- storeJson input
        | Error UnknownShipment ->
            node["tag"] <- JsonValue.Create("error")
            node["code"] <- JsonValue.Create("UNKNOWN_SHIPMENT")
            node["input"] <- storeJson input
        | Error InvalidStatus ->
            node["tag"] <- JsonValue.Create("error")
            node["code"] <- JsonValue.Create("INVALID_STATUS")
            node["input"] <- storeJson input
        node

    let private vectors: (string * Store * ScanInput list * bool) list =
        [
        ("first-scan", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "ship-a" "scan-001" "received" ], false);
        ("append-after-existing", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "scan-old" "received" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "scan-new" "in-transit" ], false);
        ("same-shipment-replay-same-status", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "scan-dup" "delivered" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "scan-dup" "delivered" ], false);
        ("same-shipment-replay-keeps-first-status", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "scan-dup" "received" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "scan-dup" "delivered" ], false);
        ("same-reference-on-another-shipment", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "shared-ref" "received" ]; mkShipment "ship-b" "Beta" [  ] ] "audit-sentinel" 73, [ mkInput "ship-b" "shared-ref" "delivered" ], false);
        ("reference-text-equals-shipment-id", mkStore [ mkShipment "same-text" "Text collision" [  ] ] "audit-sentinel" 73, [ mkInput "same-text" "same-text" "received" ], false);
        ("empty-batch-is-identity", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "keep" "in-transit" ]; mkShipment "ship-b" "Beta" [  ] ] "audit-sentinel" 73, [  ], true);
        ("replay-within-batch-keeps-first", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "ship-a" "batch-dup" "received"; mkInput "ship-a" "batch-dup" "delivered" ], true);
        ("batch-replay-of-existing-reference-is-identity", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "existing" "in-transit" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "existing" "delivered" ], true);
        ("batch-appends-fresh-references-in-order", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "before" "received" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "new-1" "in-transit"; mkInput "ship-a" "new-2" "delivered" ], true);
        ("interleaved-batch-preserves-shipments-and-unrelated-fields", mkStore [ mkShipment "ship-b" "Beta" [ mkScan "b-old" "received" ]; mkShipment "ship-a" "Alpha" [ mkScan "a-old" "in-transit" ]; mkShipment "ship-c" "Gamma" [ mkScan "c-old" "delivered" ] ] "audit: keep exact" 9001, [ mkInput "ship-a" "a-new" "delivered"; mkInput "ship-b" "b-new" "in-transit"; mkInput "ship-a" "a-newer" "received" ], true);
        ("unknown-shipment", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "missing" "scan-unknown" "received" ], false);
        ("invalid-status-for-known-shipment", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "ship-a" "scan-invalid" "pending" ], false);
        ("unknown-shipment-precedes-invalid-status", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "missing" "scan-unknown" "pending" ], false);
        ("invalid-status-precedes-replay-deduplication", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "replayed" "received" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "replayed" "pending" ], false);
        ("batch-stops-at-first-error", mkStore [ mkShipment "ship-a" "Alpha" [ mkScan "initial" "received" ] ] "audit-sentinel" 73, [ mkInput "ship-a" "valid-before-error" "in-transit"; mkInput "ship-a" "bad-status" "pending"; mkInput "missing" "later-unknown" "received" ], true);
        ("empty-reference-is-valid-and-deduplicates-exactly", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "ship-a" "" "received"; mkInput "ship-a" "" "delivered" ], true);
        ("whitespace-and-case-are-distinct", mkStore [ mkShipment "ship-a" "Alpha" [  ] ] "audit-sentinel" 73, [ mkInput "ship-a" "Ref" "received"; mkInput "ship-a" " ref" "in-transit"; mkInput "ship-a" "ref" "delivered"; mkInput "ship-a" "Ref " "received" ], true)
        ]

    [<EntryPoint>]
    let main _ =
        for caseId, input, events, isBatch in vectors do
            let outcome =
                if isBatch then Shipment.ingestBatch input events
                else
                    match events with
                    | [ event ] -> Shipment.ingest input event
                    | _ -> failwithf "single vector %s does not have exactly one event" caseId
            let row = JsonObject()
            row["id"] <- JsonValue.Create(caseId)
            row["actual"] <- observationJson input outcome
            row["scanReferenceType"] <- JsonValue.Create(typeof<Scan>.GetProperty("Reference").PropertyType.FullName)
            row["scanInputReferenceType"] <- JsonValue.Create(typeof<ScanInput>.GetProperty("Reference").PropertyType.FullName)
            Console.Out.WriteLine(row.ToJsonString())
        0

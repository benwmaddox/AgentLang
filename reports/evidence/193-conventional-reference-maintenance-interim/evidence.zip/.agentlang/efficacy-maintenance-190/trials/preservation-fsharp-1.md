# F# fsharp-1 preservation receipt

This is a read-only audit of the captured F# snapshot. All four captured files match the capture pins. The four source files match the F# seed pins in both actors.json sourcePins and the fsharp-1 initialPins. The seed has eight console assertions; the snapshot keeps all eight and adds five focused assertions. Source review supports the requested behavior; the captured validation pass is reported as execution evidence, not as behavioral acceptance.

The draft-009 manifest still carries its historical status text, “draft; do not freeze or dispatch before milestone 183 acceptance and oracle calibration.” The later 184 dispatch gate is marked passed. The authoritative 190 amended index records an amended pre-dispatch freeze with zero participants dispatched, and its actorManifestSha256 matches the current actors.json hash. The 184 F# baseline calibration records 18 passed cases and no failures.

| File | F# seed SHA-256 | Captured snapshot SHA-256 | Result |
|---|---|---|---|
| business/Business.fs | b66b6b2e19d1268e3c36cfaf88ee9c85fb7bb298396e928b6f59644ebbee3ea8 | 49359a7c2ad814705e581db34241f4cf9db99e1fec4f88a3b3e20f24247b31ac | changed for requested type and replay behavior |
| tests/Program.fs | cab2d077a2b2bc00274b530e9e2817d99eb812f15831b852376b2aafdeba8e5a | d04274b57a056263a6468183cb3649864fca4f35a44a76d67af0161677d67367 | typed fixture adaptation plus five new assertions |
| business/AgentLang.TypedReference.Business.fsproj | b195fa6a90fd4b20d13fffb8f6aca5a13a0f24fe2207f5cfa2adb991a1c91449 | b195fa6a90fd4b20d13fffb8f6aca5a13a0f24fe2207f5cfa2adb991a1c91449 | byte-identical |
| tests/AgentLang.TypedReference.Tests.fsproj | 4faa0540778fd5fc36dad2105a1ef065396a0b41e76139d7735ce43bbf2de7c9 | 4faa0540778fd5fc36dad2105a1ef065396a0b41e76139d7735ce43bbf2de7c9 | byte-identical |

The 184 retained AgentLang project used as the conventional behavior anchor is generation 10, manifest f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f, with 21 inherited tests and three examples. The F# participant has its own pinned source seed and console assertions, so those AgentLang-only library/test protocol counts are not assigned to the F# snapshot.

## Inherited assertions

| Assertion | Preservation finding |
|---|---|
| Reference lookup returns the first matching scan | Same first-match expectation; stored references and lookup argument wrap the same raw text in TrackingReference.create. |
| Reference lookup returns none when absent | Same None expectation and same raw lookup text after nominal wrapping. |
| First scan appends and preserves all Store fields | Same successful append, order, label, audit, generation, and status expectation; expected Scan value is now nominally typed. |
| Unknown shipment precedes invalid status | Test-function source is byte-identical; UnknownShipment remains expected. |
| Known shipment reports invalid status | Test-function source is byte-identical; InvalidStatus remains expected. |
| Empty batch is identity | Same Ok current expectation. |
| Batch applies input order and preserves shipment order | Same event order and expected shipments/statuses; expected references are nominally wrapped. |
| Batch returns first error | Same InvalidStatus result before a later unknown-shipment event. |

There are no removed, weakened, or unknown inherited F# assertions. Six reference-bearing cases are same-value nominal adaptations. The two error-precedence assertions remain in a byte-identical test function. Exact test-function hashes are recorded per case in the JSON receipt.

## Added assertions and implementation

Five focused assertions cover same-shipment replay and full Store preservation; same raw reference on a different shipment; invalid status on replay; batch replay, first status, and order; and exact equality for empty, whitespace, lowercase, and uppercase references.

TrackingReference is a string-backed single-case struct union. Its constructor only wraps the raw string. Scan.Reference, ScanInput.Reference, Shipment.findScan, and the shared ingestion path use the nominal type. Shipment.findScan keeps its name and first exact-match behavior. Shipment.ingestRule validates exactly received, in-transit, and delivered before checking for a replay; a valid replay returns the existing Shipment. Shipment.ingest checks shipment existence first and returns the original Store for an unchanged Shipment. Shipment.ingestBatch folds events in order through Shipment.ingest, stops at the first Error, and returns Ok current for an empty list.

The two project files are byte-identical to their seed versions. There are no new packages or providers. The domain code has no IO or global mutable state; the existing console harness uses a local assertion counter. AgentLang library qualification and task.commit are not applicable to this F# broker flow.

The seeded README places its usage example in the console test project; the inherited single-event and batch calls remain in the F# test functions. The README is not part of the four-file snapshot. The inherited Business.fs summary still says ingestRule appends one scan after status validation and does not describe duplicate no-op behavior. Existing error rules remain in code and assertions, but that comment does not document the new replay behavior.

## Captured run and request recovery

The capture reports normal broker finalization at exchange 26 by host-close, host and runtime exit codes 0/0, and zero runtime stderr. A malformed request at index 1 was not sent or executed; inspect at index 2 succeeded. Validation at index 20 failed on FS0058 indentation diagnostics. Searches at 21-22, patch 23, and validation 24 show the recovery; validation 24 exited 0 and printed “Shipment baseline: 13 assertions” with empty stderr. No trace failures remain unresolved.

Capture and metrics both say normal finalization. The capture says behaviorScored=false, so this receipt makes no behavioral acceptance claim from the passing validation output.


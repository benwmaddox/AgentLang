namespace AgentLang.TypedReferenceMaintenance.Tests

open AgentLang.TypedReferenceMaintenance.Domain

module Program =
    let private id value = ShipmentId.create value
    let private trackingReference value = TrackingReference.create value

    let private shipment key label scans = {
        Id = id key
        Label = label
        Scans = scans
    }

    let private input shipmentId reference status = {
        ShipmentId = id shipmentId
        Reference = trackingReference reference
        Status = status
    }

    let private store shipments = {
        Shipments = shipments
        Audit = "sentinel-audit"
        Generation = 19
    }

    let private testScanLookup equal =
        let first = { Reference = trackingReference "scan-1"; Status = "received" }
        let later = { Reference = trackingReference "scan-1"; Status = "delivered" }
        let target = shipment "shipment-1" "Box" [ first; later ]
        equal "reference lookup returns the first matching scan" (Some first) (Shipment.findScan target (trackingReference "scan-1"))
        equal "reference lookup returns none when absent" None (Shipment.findScan target (trackingReference "missing"))

    let private testSingleScan equal =
        let first = shipment "shipment-1" "Box" []
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        let expected = store [ { first with Scans = [ { Reference = trackingReference "scan-1"; Status = "received" } ] }; second ]
        equal "first scan appends and preserves all Store fields" (Ok expected) (Shipment.ingest current (input "shipment-1" "scan-1" "received"))

    let private testErrorPrecedence equal =
        let empty = store []
        equal "unknown shipment precedes invalid status" (Error UnknownShipment) (Shipment.ingest empty (input "missing" "scan-1" "invalid"))

        let known = store [ shipment "shipment-1" "Box" [] ]
        equal "known shipment reports invalid status" (Error InvalidStatus) (Shipment.ingest known (input "shipment-1" "scan-1" "invalid"))

        let knownWithScan =
            store [ shipment "shipment-1" "Box" [ { Reference = trackingReference "scan-1"; Status = "received" } ] ]
        equal "invalid status on a replay still reports InvalidStatus" (Error InvalidStatus) (Shipment.ingest knownWithScan (input "shipment-1" "scan-1" "invalid"))

    let private testSameShipmentReplay equal =
        let first = { Reference = trackingReference "repeat"; Status = "received" }
        let later = { Reference = trackingReference "repeat"; Status = "delivered" }
        let unrelated = { Reference = trackingReference "unrelated"; Status = "in-transit" }
        let target = shipment "shipment-1" "Box" [ first; later; unrelated ]
        let other = shipment "shipment-2" "Envelope" [ { Reference = trackingReference "other"; Status = "delivered" } ]
        let current = store [ target; other ]

        equal "same-shipment replay preserves the complete Store and first scan" (Ok current) (Shipment.ingest current (input "shipment-1" "repeat" "delivered"))

    let private testCrossShipmentIndependence equal =
        let shared = { Reference = trackingReference "shared"; Status = "received" }
        let first = shipment "shipment-1" "Box" [ shared ]
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        let expected = store [ first; { second with Scans = [ { Reference = trackingReference "shared"; Status = "delivered" } ] } ]

        equal "the same reference is independent across shipments" (Ok expected) (Shipment.ingest current (input "shipment-2" "shared" "delivered"))

    let private testBatch equal =
        let first = shipment "shipment-1" "Box" []
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        equal "empty batch is identity" (Ok current) (Shipment.ingestBatch current [])

        let ordered = [ input "shipment-2" "scan-b" "received"; input "shipment-1" "scan-a" "delivered" ]
        let expected = store [ { first with Scans = [ { Reference = trackingReference "scan-a"; Status = "delivered" } ] }; { second with Scans = [ { Reference = trackingReference "scan-b"; Status = "received" } ] } ]
        equal "batch applies input order and preserves shipment order" (Ok expected) (Shipment.ingestBatch current ordered)

        let failing = [ input "shipment-2" "scan-b" "received"; input "shipment-1" "scan-bad" "invalid"; input "missing" "later" "received" ]
        equal "batch returns first error" (Error InvalidStatus) (Shipment.ingestBatch current failing)

    let private testBatchReplayAndOrdering equal =
        let existing = { Reference = trackingReference "repeat"; Status = "received" }
        let unrelated = { Reference = trackingReference "unrelated"; Status = "in-transit" }
        let first = shipment "shipment-1" "Box" [ existing; unrelated ]
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]

        let events = [
            input "shipment-1" "repeat" "delivered"
            input "shipment-2" "repeat" "received"
            input "shipment-1" "scan-a" "delivered"
            input "shipment-1" "scan-b" "in-transit"
            input "shipment-1" "scan-a" "received"
        ]
        let expected = store [
            { first with Scans = [ existing; unrelated; { Reference = trackingReference "scan-a"; Status = "delivered" }; { Reference = trackingReference "scan-b"; Status = "in-transit" } ] }
            { second with Scans = [ { Reference = trackingReference "repeat"; Status = "received" } ] }
        ]
        equal "batch replay keeps first scans and appends new scans in input order" (Ok expected) (Shipment.ingestBatch current events)

    let private testExactReferenceSemantics equal =
        let first = shipment "shipment-1" "Box" []
        let current = store [ first ]
        let emptyReference = { Reference = trackingReference ""; Status = "received" }
        let whitespaceReference = { Reference = trackingReference " "; Status = "in-transit" }
        let lowercaseReference = { Reference = trackingReference "scan-a"; Status = "delivered" }
        let uppercaseReference = { Reference = trackingReference "Scan-a"; Status = "received" }
        let expectedShipment = { first with Scans = [ emptyReference; whitespaceReference; lowercaseReference; uppercaseReference ] }
        let expected = store [ expectedShipment ]
        let events = [
            input "shipment-1" "" "received"
            input "shipment-1" " " "in-transit"
            input "shipment-1" "scan-a" "delivered"
            input "shipment-1" "Scan-a" "received"
            input "shipment-1" "" "delivered"
            input "shipment-1" " " "received"
        ]

        equal "empty, whitespace, and case-distinct references remain exact" (Ok expected) (Shipment.ingestBatch current events)

    let private testExactReferenceLookups equal =
        let target = shipment "shipment-1" "Box" [
            { Reference = trackingReference ""; Status = "received" }
            { Reference = trackingReference " "; Status = "in-transit" }
            { Reference = trackingReference "scan-a"; Status = "delivered" }
            { Reference = trackingReference "Scan-a"; Status = "received" }
        ]
        let emptyReference = { Reference = trackingReference ""; Status = "received" }
        let whitespaceReference = { Reference = trackingReference " "; Status = "in-transit" }
        let lowercaseReference = { Reference = trackingReference "scan-a"; Status = "delivered" }
        let uppercaseReference = { Reference = trackingReference "Scan-a"; Status = "received" }

        equal "empty reference lookup is exact" (Some emptyReference) (Shipment.findScan target (trackingReference ""))
        equal "whitespace reference lookup is exact" (Some whitespaceReference) (Shipment.findScan target (trackingReference " "))
        equal "reference lookup preserves case" (Some lowercaseReference) (Shipment.findScan target (trackingReference "scan-a"))
        equal "case-distinct reference lookup remains distinct" (Some uppercaseReference) (Shipment.findScan target (trackingReference "Scan-a"))

    [<EntryPoint>]
    let main _ =
        let mutable assertions = 0
        let equal label expected actual =
            assertions <- assertions + 1
            if expected <> actual then failwith $"FAIL: {label}"
        try
            testScanLookup equal
            testSingleScan equal
            testErrorPrecedence equal
            testSameShipmentReplay equal
            testCrossShipmentIndependence equal
            testBatch equal
            testBatchReplayAndOrdering equal
            testExactReferenceSemantics equal
            testExactReferenceLookups equal
            printfn "Shipment baseline: %d assertions" assertions
            0
        with error ->
            eprintfn "FAIL after %d assertions: %s" assertions error.Message
            1

namespace AgentLang.TypedReferenceMaintenance.Tests

open AgentLang.TypedReferenceMaintenance.Domain

module Program =
    let private id value = ShipmentId.create value
    let private trackingRef value = TrackingReference.create value

    let private shipment key label scans = {
        Id = id key
        Label = label
        Scans = scans
    }

    let private input shipmentId reference status = {
        ShipmentId = id shipmentId
        Reference = trackingRef reference
        Status = status
    }

    let private store shipments = {
        Shipments = shipments
        Audit = "sentinel-audit"
        Generation = 19
    }

    let private testScanLookup equal =
        let first = { Reference = trackingRef "scan-1"; Status = "received" }
        let later = { Reference = trackingRef "scan-1"; Status = "delivered" }
        let target = shipment "shipment-1" "Box" [ first; later ]
        equal "reference lookup returns the first matching scan" (Some first) (Shipment.findScan target (trackingRef "scan-1"))
        equal "reference lookup returns none when absent" None (Shipment.findScan target (trackingRef "missing"))

    let private testSingleScan equal =
        let first = shipment "shipment-1" "Box" []
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        let expected = store [ { first with Scans = [ { Reference = trackingRef "scan-1"; Status = "received" } ] }; second ]
        equal "first scan appends and preserves all Store fields" (Ok expected) (Shipment.ingest current (input "shipment-1" "scan-1" "received"))

    let private testErrorPrecedence equal =
        let empty = store []
        equal "unknown shipment precedes invalid status" (Error UnknownShipment) (Shipment.ingest empty (input "missing" "scan-1" "invalid"))

        let known = store [ shipment "shipment-1" "Box" [] ]
        equal "known shipment reports invalid status" (Error InvalidStatus) (Shipment.ingest known (input "shipment-1" "scan-1" "invalid"))

    let private testBatch equal =
        let first = shipment "shipment-1" "Box" []
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        equal "empty batch is identity" (Ok current) (Shipment.ingestBatch current [])

        let ordered = [ input "shipment-2" "scan-b" "received"; input "shipment-1" "scan-a" "delivered" ]
        let expected = store [ { first with Scans = [ { Reference = trackingRef "scan-a"; Status = "delivered" } ] }; { second with Scans = [ { Reference = trackingRef "scan-b"; Status = "received" } ] } ]
        equal "batch applies input order and preserves shipment order" (Ok expected) (Shipment.ingestBatch current ordered)

        let failing = [ input "shipment-2" "scan-b" "received"; input "shipment-1" "scan-bad" "invalid"; input "missing" "later" "received" ]
        equal "batch returns first error" (Error InvalidStatus) (Shipment.ingestBatch current failing)

    let private testReplayPreservesStore equal =
        let firstScan = { Reference = trackingRef "scan-1"; Status = "delivered" }
        let unrelated = { Reference = trackingRef "unrelated"; Status = "received" }
        let first = shipment "shipment-1" "Box" [ firstScan; unrelated ]
        let second = shipment "shipment-2" "Envelope" [
            { Reference = trackingRef "other-scan"; Status = "in-transit" }
        ]
        let current = store [ first; second ]

        equal
            "same-shipment replay preserves the first scan and complete Store"
            (Ok current)
            (Shipment.ingest current (input "shipment-1" "scan-1" "received"))

    let private testCrossShipmentReference equal =
        let firstScan = { Reference = trackingRef "shared"; Status = "received" }
        let first = shipment "shipment-1" "Box" [ firstScan ]
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        let expected =
            store [
                first
                { second with Scans = [ { Reference = trackingRef "shared"; Status = "delivered" } ] }
            ]

        equal
            "the same raw reference is independent on another shipment"
            (Ok expected)
            (Shipment.ingest current (input "shipment-2" "shared" "delivered"))

    let private testInvalidStatusOnReplay equal =
        let existing = { Reference = trackingRef "scan-1"; Status = "received" }
        let current = store [ shipment "shipment-1" "Box" [ existing ] ]

        equal
            "invalid status is reported for a known-shipment replay"
            (Error InvalidStatus)
            (Shipment.ingest current (input "shipment-1" "scan-1" "invalid"))

    let private testBatchReplayAndOrder equal =
        let first = shipment "shipment-1" "Box" []
        let second = shipment "shipment-2" "Envelope" []
        let current = store [ first; second ]
        let events = [
            input "shipment-1" "scan-a" "received"
            input "shipment-1" "scan-a" "delivered"
            input "shipment-2" "scan-a" "in-transit"
            input "shipment-1" "scan-b" "delivered"
        ]
        let firstScan = { Reference = trackingRef "scan-a"; Status = "received" }
        let laterScan = { Reference = trackingRef "scan-b"; Status = "delivered" }
        let secondShipmentScan = { Reference = trackingRef "scan-a"; Status = "in-transit" }
        let expected =
            store [
                { first with Scans = [ firstScan; laterScan ] }
                { second with Scans = [ secondShipmentScan ] }
            ]

        equal
            "batch replay keeps first status and folds later scans in input order"
            (Ok expected)
            (Shipment.ingestBatch current events)

    let private testExactReferenceEquality equal =
        let current = store [ shipment "shipment-1" "Box" [] ]
        let events = [
            input "shipment-1" "" "received"
            input "shipment-1" "" "delivered"
            input "shipment-1" " " "in-transit"
            input "shipment-1" "x" "received"
            input "shipment-1" "X" "delivered"
        ]
        let expected =
            store [
                shipment "shipment-1" "Box" [
                    { Reference = trackingRef ""; Status = "received" }
                    { Reference = trackingRef " "; Status = "in-transit" }
                    { Reference = trackingRef "x"; Status = "received" }
                    { Reference = trackingRef "X"; Status = "delivered" }
                ]
            ]

        equal
            "empty, whitespace, and case-distinct references use exact string equality"
            (Ok expected)
            (Shipment.ingestBatch current events)

    [<EntryPoint>]
    let main _ =
        let mutable assertions = 0
        let equal label expected actual =
            assertions <- assertions + 1
            if expected <> actual then failwith $"FAIL: {label}"
        try
            testScanLookup equal
            testSingleScan equal
            testErrorPrecedence equal
            testBatch equal
            testReplayPreservesStore equal
            testCrossShipmentReference equal
            testInvalidStatusOnReplay equal
            testBatchReplayAndOrder equal
            testExactReferenceEquality equal
            printfn "Shipment baseline: %d assertions" assertions
            0
        with error ->
            eprintfn "FAIL after %d assertions: %s" assertions error.Message
            1

The human authorizes edits only to your assigned isolated trial project and local test execution through this broker. You are an external coding agent. Read only this prompt, then launch the exact broker command once, without changing its allowlist or limits. Use only the broker for discovery, edits and tests. Do not read repository files, other trials, oracles or reports; do not use web tools or other agents. Disclose any non-broker tool use. One session, at most 100 exchanges. Poll the same live handle after timeouts; do not restart for silence or repeat uncertain mutations. Finish with {"op":"host.close"} and observe terminal status.

Implement the requested maintenance change in the F# shipment-tracking project supplied for this task.

Add idempotence to scan ingestion. Introduce a nominal `TrackingReference` over `string` with no predicate or normalization, and use it for both `Scan.Reference` and `ScanInput.Reference`. Thread that type through the shared `Shipment.ingestRule` and the single-event and batch entry points.

For a valid scan, a reference already present on the same shipment leaves the complete Store unchanged and keeps the first scan and status. The same raw reference on another shipment is independent. Check that the shipment exists before validating status; a known shipment with an invalid status still returns `InvalidStatus`, including when the reference is already present. Accepted statuses remain exactly `received`, `in-transit`, and `delivered`.

Batch ingestion processes events in input order, stops at its first error, and returns the error without exposing a partial Store. Successful batches are the ordered fold of single-event ingestion; an empty batch returns the original Store. Preserve shipment order, labels, unrelated scans, audit text, and generation. Reference equality is exact string equality: empty text is valid, and whitespace or case differences are distinct.

Inspect and use the existing project vocabulary where it fits. Preserve all inherited behavioral assertions, tests, usage examples, and documented error rules; do not weaken or replace inherited evidence. Add focused tests for same-shipment replay with first-scan and full-Store preservation, cross-shipment independence, invalid status on replay, batch replay and ordering, and exact empty/whitespace/case behavior. Keep the seeded reusable helper name `Shipment.findScan` so the calibration can discover it; retype its reference parameter to `TrackingReference`. The requested migration is expected to retype `Scan.Reference`, `ScanInput.Reference`, and any lookup or ingestion-rule parameter that carries a reference to `TrackingReference`. Update affected signatures, constructors, fixtures, and expected typed representations as needed while keeping public entry behavior and semantic expectations unchanged. Keep the model pure: no IO, providers, mutable global state, or new packages. Run the existing tests and finish with a concise result report.

Edit only business/Business.fs and tests/Program.fs; project files are frozen. Validate uses the fixed local test project.
Launch with exec_command, tty:true, yield_time_ms:10000.

~~~powershell
$env:TEMP = 'D:\code\AgentLang\.agentlang\efficacy-maintenance-190\trials\temp\fsharp-1'
$env:TMP = $env:TEMP
$env:DOTNET_CLI_HOME = 'D:\code\AgentLang\.agentlang\efficacy-maintenance-190\trials\temp\fsharp-1'
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\efficacy-maintenance-190\conventional-build\bin\AgentLang.Conventional.Cli\release\AgentLang.Conventional.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\efficacy-maintenance-190\trials\actors\fsharp-1' -TracePath 'D:\code\AgentLang\.agentlang\efficacy-maintenance-190\trials\traces\fsharp-1.jsonl' -AllowedOperations 'inspect,read,search,patch,replace,validate' -Profile 'conventional' -Capabilities @() -ClockValue '2000-01-01T00:00:00Z' -MaxRequestBytes 262144 -MaxResponseBytes 524288 -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100 -AdditionalCliArguments @('--validation-project','tests/AgentLang.TypedReference.Tests.fsproj')
~~~

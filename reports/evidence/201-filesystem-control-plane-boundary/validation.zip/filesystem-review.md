# Filesystem boundary review

This was a read-only review of the real language `file.read`, `file.exists?`, and `file.write` providers, their capability preflight, and the static project-storage path layout. I did not inspect `.agentlang` participant or experiment data, and I did not run a build or tests.

## Finding: language file writes can overwrite AgentLang’s authoritative store pointer

With `fs.write` granted, a program can call `file.write(".agentlang/store/CURRENT", "not-json")` in a committed project. `Runtime.Engine` uses the configured project directory for both `Storage.create` and the real file provider (`Runtime.fs:343`, `FileSystem.fs:104`). The common path resolver rejects rooted paths and paths outside the project, but it has no reserved-path rule for `.agentlang`; `writeText` then calls `File.WriteAllBytes` (`FileSystem.fs:158`). The storage module places its authoritative pointer at `<project>/.agentlang/store/CURRENT` (`Storage.fs:211`, `Storage.fs:1197`, `Storage.fs:1201`). On the next project load, that file is parsed as the current authority, and invalid JSON is a storage error; Storage documents that a corrupt existing pointer fails closed rather than falling back to `dictionary.agent` (`Storage.fs:1451`, `docs/STORAGE.md`, “Commit boundary”).

This is not an effect-name bypass: the invocation still requires the host to grant `fs.write`. It is a resource-scope gap: that grant covers host-managed durable runtime state as well as ordinary project files, despite the PRD describing project commits and task management as host control-plane writes (`docs/PRD.md`, “Trusted capability boundary”). The same unreserved path is readable and queryable with `fs.read`.

The smallest likely fix is a shared reserved-path rejection in `FileSystem.resolve` for the root-relative `.agentlang` subtree, which protects read, write, and exists together. Keep Storage’s direct host access unchanged. Add the regression to the existing CLI filesystem-boundary group and verify that an ordinary project file remains accessible while the pointer remains unchanged.

## Checks and limits

For ordinary lexical paths, no escape was found in the reviewed code. `Path.IsPathRooted` rejects absolute input; `Path.GetFullPath` canonicalizes the combined path; containment uses the canonical root plus a directory separator, so `..` escapes and sibling names sharing the root prefix do not pass. Reparse-point checks inspect each existing descendant component and reject entries with `ReparsePoint` or a `LinkTarget` (`FileSystem.fs:77`). The configured root itself is not checked as a descendant; a symlink or junction selected by the host as the project root is treated as the root. The source comment explicitly says the component check is not race-proof against concurrent changes (`FileSystem.fs:22`).

The check is path-based. A pre-existing hard link inside the project can refer to the same file object as a file outside it; hard links are not reparse points and have no `LinkTarget`, so this code does not detect that setup. This needs an externally provisioned hard link and is not something the language’s current filesystem primitives create.

The existing CLI filesystem tests cover real reads/writes, exists/missing behavior, virtual mode, capability denial, and one `../escaped.txt` write rejection (`tests/AgentLang.Cli.Tests/Program.fs:573`, `tests/AgentLang.Cli.Tests/Program.fs:663`). I found no language-provider regression for reserved `.agentlang` paths, rooted paths, sibling-prefix escapes, or symlink/junction rejection. Storage tests exercise Storage’s own tamper/path rules, but do not show that the language provider cannot reach those paths.

Focused validation after adding the reserved-path regression: `dotnet run --project tests/AgentLang.Cli.Tests/AgentLang.Cli.Tests.fsproj -c Release`. I did not run it for this review.

## Runtime path summary

The compiler maps `file.read` and `file.exists?` to `fs.read`, and `file.write` to `fs.write` (`Compiler.fs:109`). Runtime preflights inferred effects against the host grant before invoking a provider (`Runtime.fs:2060`); real mode then routes each operation through `FileSystem`, while virtual mode uses trace-local in-memory state (`Runtime.fs:2082`). CLI documentation says real filesystem mode is the default and confines normal operations to the configured project directory (`README.md:355`). The current policy is effect-wide, with no per-path allowlist, which is why the reserved storage namespace remains reachable after a valid `fs.write` grant.

## Review of the proposed bounded fix

Reserving the root `.agentlang` subtree and root `dictionary.agent` in the shared real-provider resolver is a suitable narrow fix for the confirmed gap. Keep the reserved-name decision based on the canonical root-relative path after `GetFullPath`; otherwise an input such as `sub/../dictionary.agent` can evade a check that only examines the original segments. Use exact path-component comparisons, with Windows case-insensitive comparison, so `.agentlanguage` is not confused with `.agentlang`.

For Windows, rejecting segments with trailing dots or spaces, any colon, and `~` followed by a digit is a conservative way to close common Win32 aliases for those reserved names without adding filesystem interop. Apply the ambiguous-segment rule to path segments before normalization as well as the surviving canonical segments, since a segment that normalizes away could otherwise conceal an ambiguous lookup during path traversal. Treat exact `.` and `..` as structural navigation tokens for `GetFullPath` and the existing containment check; reject variants such as `.. ` or `name.`. Reject the ambiguous input rather than trying to resolve its OS-specific meaning.

The listed aliases cover the likely lexical bypasses for these two names in a normal workspace: case variation, trailing-dot/space aliases, alternate data streams, and DOS short-name aliases. This does not close the already documented check/open race or hard-link limitation; retain those as explicit host-filesystem limits and do not describe this fix as a hostile-host sandbox. A separate DOS device-name policy is not required to protect these reserved paths, but should be reviewed independently if file operations are later claimed to exclude device I/O effects.

Regression cases should include the direct protected names and normalized aliases such as `sub/../.agentlang/store/CURRENT` and `sub/../dictionary.agent`, under all three operations. Keep a positive case for an ordinary root-relative file, and preserve the existing virtual-provider expectations.

## Final source-only review of the frozen implementation

Reviewed `src/AgentLang.Core/FileSystem.fs` at SHA-256 `d03ad16df8607ec3c351734ed28273bef4afc0710e721bd972ac9de1eb991833` and `tests/AgentLang.Cli.Tests/Program.fs` at SHA-256 `f7d89e563c22f041998f0ab73e1b279e0e57c69c56b00c52397eb1861ac84a5d`; both match the requested frozen versions. I found no concrete bypass of the `.agentlang` and root `dictionary.agent` reservation within the declared normal-workspace boundary.

The implementation checks Windows-ambiguous raw segments before path resolution, then checks the canonical root-relative segments after containment. That covers navigation-normalized reserved paths, case variants, trailing-dot/space spellings, ADS colons, and short-name segments containing `~` plus digits. The reservation is shared by all three real operations. The tests exercise read/write/exists against direct, case-variant, and `..`-normalized protected paths; check Windows spellings on Windows; verify adjacent ordinary names still work; and verify persisted pointer/export bytes and a fresh load afterward. No tests were run during this review.

One test detail is weaker than its label suggests: the test seeds `dictionary.agent` when absent, then records `legacyExportExisted`, so that value is always true. It verifies the seeded or committed export bytes remain unchanged through the protected-path attempts, but it does not verify that an initially absent export stays absent. This does not expose a source bypass; the provider rejects the operation before touching the file. The check/open race and pre-existing hard-link caveat above remain the explicit filesystem limits.

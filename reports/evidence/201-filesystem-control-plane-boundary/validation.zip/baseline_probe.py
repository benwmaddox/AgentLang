import hashlib
import json
import os
import subprocess
from pathlib import Path

repo = Path.cwd()
root = repo / '.agentlang/security-boundary-201'
out = root / 'baseline-probe'
out.mkdir(exist_ok=False)
project = out / 'project'
project.mkdir()
tmp = root / 'tmp'
tmp.mkdir(exist_ok=True)
env = dict(os.environ, TEMP=str(tmp), TMP=str(tmp))
cli = repo / '.agentlang/organic-reuse-200/runtime/AgentLang.Cli.dll'

def invoke(name, requests):
    wire = ''.join(json.dumps(q) + '\n' for q in requests)
    command = ['dotnet', str(cli), '--project', str(project), '--allow', 'fs.write', '--jsonl']
    result = subprocess.run(command, input=wire, text=True, capture_output=True, env=env, timeout=60)
    (out / (name + '-requests.jsonl')).write_text(wire, encoding='utf-8')
    (out / (name + '-responses.jsonl')).write_text(result.stdout, encoding='utf-8')
    (out / (name + '-stderr.txt')).write_text(result.stderr, encoding='utf-8')
    return result, [json.loads(line) for line in result.stdout.splitlines()]

setup, responses = invoke('setup', [
    {'op': 'define', 'syntaxVersion': 2, 'source': 'fn sentinel(value: Int) -> Int {\n doc "Storage boundary sentinel."\n\n value\n}\ntest sentinel/basic {\n sentinel(1)\n => 1\n}'},
    {'op': 'commit', 'word': 'sentinel', 'library': True}
])
assert setup.returncode == 0 and len(responses) == 2 and all(row['ok'] for row in responses)
pointer = project / '.agentlang/store/CURRENT'
original = pointer.read_bytes()
(out / 'CURRENT-before').write_bytes(original)
write, responses = invoke('write', [{'op': 'eval', 'syntaxVersion': 2, 'code': 'file.write(".agentlang/store/CURRENT", "not-json")'}])
assert write.returncode == 0 and len(responses) == 1 and responses[0]['ok']
assert pointer.read_bytes() == b'not-json'
reload, reload_responses = invoke('reload', [{'op': 'eval', 'syntaxVersion': 2, 'code': 'sentinel(7)'}])
receipt = {
    'status': 'confirmed vulnerable baseline in disposable project only',
    'runtime': str(cli.relative_to(repo)),
    'cliSha256': hashlib.sha256(cli.read_bytes()).hexdigest(),
    'setupExit': setup.returncode,
    'writeExit': write.returncode,
    'writeSucceeded': True,
    'pointerBeforeSha256': hashlib.sha256(original).hexdigest(),
    'pointerAfter': pointer.read_text(),
    'reloadExit': reload.returncode,
    'reloadResponses': reload_responses,
    'scope': 'Fresh root-owned disposable project; no participant or real project storage altered.'
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))

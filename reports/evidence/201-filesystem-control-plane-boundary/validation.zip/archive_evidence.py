"""Archive the completed local gate; never overwrite a sealed archive."""
import hashlib
import json
from pathlib import Path
import zipfile

repo = Path(__file__).resolve().parents[2]
evidence = repo / '.agentlang/security-boundary-201'
gate = json.loads((evidence / 'full-validation.json').read_text(encoding='utf-8-sig'))
if not gate.get('passed'):
    raise SystemExit('Refusing to archive an unaccepted full gate')
target = repo / 'reports/evidence/201-filesystem-control-plane-boundary'
target.mkdir(parents=True, exist_ok=True)
archive = target / 'validation.zip'
index = target / 'validation.index.json'
if archive.exists() or index.exists():
    raise SystemExit('Refusing to overwrite sealed evidence')
files = [p for p in evidence.rglob('*') if p.is_file()
         and not any(part in {'tmp', 'bin', 'obj', '__pycache__'} for part in p.relative_to(evidence).parts)
         and p.suffix.lower() not in {'.dll', '.exe', '.pdb'}]
sources = ['src/AgentLang.Core/FileSystem.fs', 'tests/AgentLang.Cli.Tests/Program.fs',
           'scripts/Validate.ps1']
entries = [(p.relative_to(evidence).as_posix(), p) for p in files]
entries += [('accepted-source/' + name, repo / name) for name in sources]
members = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(entries):
        data = p.read_bytes()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert sorted(z.namelist()) == sorted(m['path'] for m in members)
    for m in members:
        data = z.read(m['path'])
        assert len(data) == m['bytes'] and hashlib.sha256(data).hexdigest() == m['sha256']
receipt = {'archive': archive.name, 'bytes': archive.stat().st_size,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'members': members, 'memberVerification': 'all lengths and SHA-256 hashes verified after reopening'}
index.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))
print('Verified members:', len(members))

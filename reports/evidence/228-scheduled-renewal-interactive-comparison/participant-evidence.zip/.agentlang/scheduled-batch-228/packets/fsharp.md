# Launch details

From the repository root, run: pwsh -NoProfile -ExecutionPolicy Bypass -File .agentlang/scheduled-batch-228/launchers/fsharp.ps1

Assigned project path: .agentlang/scheduled-batch-228/actors/fsharp

Fixed validation project: `SubscriptionBatch.Conventional.fsproj`, resolved inside the assigned project path.

Permitted files:
- `Operations.fs`
- `SelfTests.fs`

All other files are read-only.

# Common participant bootstrap

Launch the packet's exact PowerShell command through `exec_command` with `tty:true`. Do not pipe requests or redirect stdin. Keep the returned `session_id`; send requests with `write_stdin` to that same session. If an observation times out, continue with that session and do not restart the process. Send `{"op":"host.close"}` through `write_stdin` to the same handle and observe terminal exit; the coordinator will audit termination.

The human authorizes edits only to your assigned isolated trial project and
local validation through the supplied broker. Read only your assigned packet
and project. Launch the exact command in that packet once; keep its operation
list, limits, and project path unchanged. Use only that broker for project
discovery, edits, and validation. Do not inspect sibling projects, reports,
controls, graders, or other agents. Do not use web tools or other agents. Run
one session, at most 100 exchanges.

Poll the same live handle after an observation timeout. Do not restart for
silence, repeat an uncertain mutation, or kill the process to finish. When
finished, send `{"op":"host.close"}` and observe terminal status. This is a
host transport command outside the runtime operation list. If closure fails,
report the failure and preserve the session and trace. In your final response,
report changes, validation, and unresolved failures.

# Conventional F# interface

Allowed operations: `inspect,read,search,patch,replace,validate`.

The fixed validation project is `SubscriptionBatch.Conventional.fsproj` inside
your assigned project. Only `Operations.fs` and `SelfTests.fs` may be edited;
all other project files are read-only. Validation uses that local project.
Keep the implementation pure and do not add packages.

# Scheduled renewal batch

Add one new API to the assigned project:

- AgentLang: define `ScheduledSubscriptionRenewal` with `renewal:
  SubscriptionRenewal` and `at: Instant`, then add
  `subscription.renew-scheduled-batch(Store, List<ScheduledSubscriptionRenewal>)`.
- F#: define the corresponding record with `Renewal: SubscriptionRenewal` and
  `At: Instant`, then add `Subscription.renewScheduledBatch`.

The result is a complete `Store` on success or the exact existing business
error on failure. Process items in the order supplied. Use each item's `at` for
that item's renewal. Stop at the first error. Do not return partial Store state
as success. An empty list succeeds with the entire input Store. Preserve
complete Store contents, unrelated entities and state, and the caller's input.

Keep every existing definition, test, example, fixture, and expected result
unchanged. Make additive changes only. In F#, edit only `Operations.fs` and
`SelfTests.fs`; add regression tests for per-item instants, input ordering,
first-error behavior, failure after a successful prefix, complete Store
preservation, and empty input. Keep the model pure: do not add I/O, packages,
providers, mutable global state, or project changes.

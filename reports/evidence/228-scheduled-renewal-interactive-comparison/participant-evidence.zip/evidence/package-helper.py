#!/usr/bin/env python3
"""Package the completed scheduled-batch-228 evidence without build copies."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import zipfile
from pathlib import Path
from typing import Any


REPO = Path(__file__).resolve().parents[3]
STUDY = ".agentlang/scheduled-batch-228"
OLD_SCORE = ".agentlang/scheduled-batch-226/oracle-work/language"
PREP_ARCHIVE = "reports/evidence/226-scheduled-renewal-comparison-preflight/preflight-evidence.zip"
PREP_MANIFEST = "reports/evidence/226-scheduled-renewal-comparison-preflight/preflight-evidence.manifest.json"
REPORT = "reports/228-scheduled-renewal-interactive-comparison.md"
METRICS = f"{STUDY}/participant-metrics.json"
OUT = Path("reports/evidence/228-scheduled-renewal-interactive-comparison")
ARCHIVE = OUT / "participant-evidence.zip"
SIDECAR = OUT / "participant-evidence.manifest.json"
INNER = "MANIFEST.json"
EXCLUDED_PARTS = {"bin", "obj", "artifacts", "project-copy", "scoring-copy", "scratch", "tmp", "temp"}

ITEMS: dict[str, tuple[Path | None, bytes | None, str]] = {}
FILTERED: dict[str, int] = {}


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def add_bytes(member: str, raw: bytes, group: str) -> None:
    name = member.replace("\\", "/")
    if name in ITEMS or name == INNER:
        raise ValueError(f"duplicate archive member: {name}")
    ITEMS[name] = (None, raw, group)


def add_file(path: Path, group: str, member: str | None = None) -> None:
    path = path if path.is_absolute() else REPO / path
    if not path.is_file():
        raise FileNotFoundError(path)
    name = (member or path.relative_to(REPO).as_posix()).replace("\\", "/")
    if name in ITEMS or name == INNER:
        raise ValueError(f"duplicate archive member: {name}")
    ITEMS[name] = (path, None, group)


def add_tree(rel: str | Path, group: str) -> None:
    root = Path(rel)
    root = root if root.is_absolute() else REPO / root
    if not root.is_dir():
        raise FileNotFoundError(root)
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        blocked = next((part.lower() for part in path.parts if part.lower() in EXCLUDED_PARTS), None)
        if blocked:
            key = f"directory:{blocked}"
            FILTERED[key] = FILTERED.get(key, 0) + 1
            continue
        if path.suffix.lower() in {".dll", ".exe", ".pdb", ".so", ".dylib"}:
            FILTERED["binary-extension"] = FILTERED.get("binary-extension", 0) + 1
            continue
        add_file(path, group)


def source_bytes(source: Path | None, embedded: bytes | None) -> bytes:
    if source is not None:
        return source.read_bytes()
    assert embedded is not None
    return embedded


def entry(name: str, value: tuple[Path | None, bytes | None, str]) -> dict[str, Any]:
    source, embedded, group = value
    raw = source_bytes(source, embedded)
    return {
        "path": name,
        "group": group,
        "bytes": len(raw),
        "sha256": digest(raw),
        "source": source.relative_to(REPO).as_posix() if source is not None else "generated",
    }


def add_study_inputs() -> None:
    for name, group in (
        ("setup.json", "study-setup"),
        ("freeze.json", "frozen-public-inputs"),
        ("dispatch.json", "dispatch-record"),
        ("fsharp-score.log", "fsharp-score-output"),
        ("fsharp-termination-audit.txt", "termination-audits"),
        ("retained-score.log", "retained-score-failure-attempt"),
        ("retained-score-short-path.log", "retained-final-score-output"),
        ("retained-termination-audit.txt", "termination-audits"),
        ("participant-finals.json", "participant-final-reports"),
        ("participant-metrics.json", "participant-metrics"),
    ):
        add_file(Path(STUDY) / name, group)

    # The input and baseline copies are captured once; no scoring project copies.
    for name in ("baselines/retained", "baselines/fsharp", "packets", "launchers", "preflight", "review"):
        group = {
            "baselines/retained": "baseline-retained-once",
            "baselines/fsharp": "baseline-fsharp-once",
            "packets": "public-participant-packets",
            "launchers": "frozen-launchers",
            "preflight": "preflight-receipts-and-logs",
            "review": "independent-reviews",
        }[name]
        add_tree(Path(STUDY) / name, group)

    # Read-only terminal material: the full retained endpoint, but F# source only.
    add_tree(Path(STUDY) / "actors/retained", "retained-terminal-project-and-durable-store")
    for name in (
        "Domain.fs", "Fixtures.fs", "Operations.fs", "Program.fs", "SelfTests.fs",
        "SubscriptionBatch.Conventional.fsproj",
    ):
        add_file(Path(STUDY) / "actors/fsharp" / name, "fsharp-terminal-source-only")
    add_tree(Path(STUDY) / "traces", "completed-terminal-traces")

    # F# run logs and both retained scoring attempts, preserving the path-length failure.
    add_tree(Path(STUDY) / "fsharp-score", "fsharp-independent-score-raw")
    for name in ("p228", "z"):
        add_tree(Path(OLD_SCORE) / name, "retained-independent-score-raw")

    # Human-readable report is snapshotted only after its metrics are finalized.
    add_file(Path(REPORT), "report-snapshot")
    for name in ("228-scheduled-renewal-interactive-comparison.md",):
        report_path = Path("reports/evidence") / name
        if report_path.is_file():
            add_file(report_path, "report-evidence-copy")

    add_file(Path(__file__).resolve(), "archive-helper", "evidence/package-helper.py")


def make_readme(prep_hash: str) -> bytes:
    content = f"""# Scheduled renewal interactive comparison evidence

This archive snapshots the completed 228 study inputs, final report and metrics,
both terminal participant endpoints, trace/audit receipts, and the independent
raw grading evidence. The retained endpoint includes its complete durable
project store. The F# endpoint is represented by its six source/project files
only; F# bin/obj and runtime binaries are excluded. Baseline source is included
once per arm.

The two retained scorer trees include the original failed long-path attempt
(`p228`) and the final short-path retry (`z`). Their raw scores and logs are
included while disposable project-copy/scoring-copy trees and build artifacts
are omitted. The F# raw score remains separate; its reported disposition is
preserved verbatim and this archive makes no additional functional claim.

Prior calibration is referenced by the verified 226 preflight archive SHA-256:
`{prep_hash}`. The exact archive path and manifest hash are recorded in
`evidence/preparation-archive-reference.json`.
"""
    return content.encode("utf-8")


def package() -> dict[str, Any]:
    if not (REPO / REPORT).is_file():
        raise FileNotFoundError(f"final report snapshot not ready: {REPORT}")
    if not (REPO / METRICS).is_file():
        raise FileNotFoundError(f"participant metrics not ready: {METRICS}")

    prep_path = REPO / PREP_ARCHIVE
    prep_manifest_path = REPO / PREP_MANIFEST
    prep_manifest = json.loads(prep_manifest_path.read_text(encoding="utf-8"))
    prep_hash = digest(prep_path.read_bytes())
    if prep_hash != prep_manifest.get("archive", {}).get("sha256"):
        raise ValueError("226 preparation archive bytes do not match its manifest")

    add_study_inputs()
    reference = {
        "study": "scheduled-batch-228",
        "priorCalibrationArchive": PREP_ARCHIVE,
        "priorCalibrationArchiveSha256": prep_hash,
        "priorCalibrationManifest": PREP_MANIFEST,
        "priorCalibrationManifestSha256": digest(prep_manifest_path.read_bytes()),
    }
    add_bytes("evidence/preparation-archive-reference.json",
              (json.dumps(reference, indent=2, sort_keys=True) + "\n").encode("utf-8"),
              "prior-calibration-cross-reference")
    add_bytes("evidence/README.md", make_readme(prep_hash), "archive-scope-and-exclusions")

    records = [entry(name, ITEMS[name]) for name in sorted(ITEMS)]
    freeze = json.loads((REPO / STUDY / "freeze.json").read_text(encoding="utf-8"))
    manifest = {
        "format": "scheduled-batch-228-participant-evidence-v1",
        "freezeStatus": freeze.get("status"),
        "reportSnapshot": REPORT,
        "priorCalibrationArchiveSha256": prep_hash,
        "members": records,
        "exclusions": {
            "notTraversed": [
                f"{STUDY}/actors/fsharp/bin/**",
                f"{STUDY}/actors/fsharp/obj/**",
                f"{STUDY}/runtime/**",
            ],
            "filteredCounts": dict(sorted(FILTERED.items())),
            "policy": "No unrelated actor paths or runtime binaries; omit score project-copies, artifacts, bin/obj, and scratch/temp files.",
        },
    }
    inner_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
    all_items = dict(ITEMS)
    all_items[INNER] = (None, inner_bytes, "archive-member-manifest")
    all_rows = [entry(name, all_items[name]) for name in sorted(all_items)]

    OUT_ABS = REPO / OUT
    OUT_ABS.mkdir(parents=True, exist_ok=True)
    archive_abs = REPO / ARCHIVE
    sidecar_abs = REPO / SIDECAR
    temporary = archive_abs.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in sorted(all_items):
            source, embedded, _ = all_items[name]
            raw = source_bytes(source, embedded)
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, raw)
    os.replace(temporary, archive_abs)

    with zipfile.ZipFile(archive_abs, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != {row["path"] for row in all_rows}:
            raise RuntimeError("archive membership mismatch")
        for row in all_rows:
            raw = archive.read(row["path"])
            if len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
                raise RuntimeError(f"member hash mismatch: {row['path']}")
        if json.loads(archive.read(INNER)) != manifest:
            raise RuntimeError("embedded manifest mismatch")

    changed = []
    for row in records:
        source, embedded, _ = ITEMS[row["path"]]
        raw = source_bytes(source, embedded)
        if len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
            changed.append(row["path"])
    if changed:
        raise RuntimeError("input changed during packaging: " + ", ".join(changed[:10]))

    sidecar = {
        **manifest,
        "archive": {
            "path": ARCHIVE.as_posix(),
            "bytes": archive_abs.stat().st_size,
            "sha256": digest(archive_abs.read_bytes()),
        },
        "archiveMemberCount": len(all_rows),
        "verified": True,
        "sourceRecheck": "unchanged",
        "members": all_rows,
    }
    sidecar_abs.write_text(json.dumps(sidecar, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with zipfile.ZipFile(archive_abs, "r") as archive:
        if set(archive.namelist()) != {row["path"] for row in sidecar["members"]}:
            raise RuntimeError("sidecar membership mismatch")
        for row in sidecar["members"]:
            raw = archive.read(row["path"])
            if len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
                raise RuntimeError(f"sidecar verification failed: {row['path']}")
    return {
        "archive": ARCHIVE.as_posix(),
        "manifest": SIDECAR.as_posix(),
        "sha256": sidecar["archive"]["sha256"],
        "members": len(all_rows),
        "bytes": sidecar["archive"]["bytes"],
        "verified": True,
        "filteredCounts": sidecar["exclusions"]["filteredCounts"],
        "priorCalibrationArchiveSha256": prep_hash,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal", action="store_true", help="write the package after report and metrics are finalized")
    args = parser.parse_args()
    if not args.seal:
        parser.error("pass --seal only after the coordinator confirms report and metrics readiness")
    print(json.dumps(package(), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

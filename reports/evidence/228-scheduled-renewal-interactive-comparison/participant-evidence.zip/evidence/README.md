# Scheduled renewal interactive comparison evidence

This archive snapshots the completed 228 study inputs, final report and metrics,
both terminal participant endpoints, trace/audit receipts, and the independent
raw grading evidence. The retained endpoint includes its complete durable
project store. The F# endpoint is represented by its six source/project files
only; F# bin/obj and runtime binaries are excluded. Baseline source is included
once per arm.

The two retained scorer trees include the original failed long-path attempt
(`p228`) and the final short-path retry (`z`). Their raw scores and logs are
included while disposable project-copy/scoring-copy trees and build artifacts
are omitted. The F# raw score remains separate; its reported disposition is
preserved verbatim and this archive makes no additional functional claim.

Prior calibration is referenced by the verified 226 preflight archive SHA-256:
`25ebe493842b7745a0284281f265511aad8a0aafe44c2ddc6e9a5e273c837b6d`. The exact archive path and manifest hash are recorded in
`evidence/preparation-archive-reference.json`.

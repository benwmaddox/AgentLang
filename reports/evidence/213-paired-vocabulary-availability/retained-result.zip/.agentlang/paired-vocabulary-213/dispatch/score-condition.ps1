param([Parameter(Mandatory=$true)][ValidateSet('reset','retained')][string]$Condition)
$trialRoot = 'D:\code\AgentLang\.agentlang\paired-vocabulary-213'
& pwsh -NoProfile -File scripts/Audit-SubagentTrialTerminationV2.ps1 `
    -TracePath "$trialRoot\traces\$Condition.jsonl" `
    *> "$trialRoot\dispatch\$Condition-terminal-audit.txt"
$auditCode = $LASTEXITCODE
& python -B experiments/AgentLang.SubagentTrials/paired-vocabulary-213/oracle/score_batch.py `
    --cli "$trialRoot\runtime\AgentLang.Cli.dll" `
    --actor-project "$trialRoot\actors\$Condition" `
    --condition $Condition `
    --seed-project "$trialRoot\baselines\reset" `
    --baseline-project "$trialRoot\baselines\$Condition" `
    --trace "$trialRoot\traces\$Condition.jsonl" `
    --evidence-root "$trialRoot\s" `
    > "$trialRoot\dispatch\$Condition-score.json"
$scoreCode = $LASTEXITCODE
@{ condition = $Condition; auditExitCode = $auditCode; scoreExitCode = $scoreCode } |
    ConvertTo-Json | Set-Content "$trialRoot\dispatch\$Condition-scoring-receipt.json"
Write-Output "Audit exit $auditCode; scorer exit $scoreCode"

import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root=Path(__file__).resolve().parents[3]
study=root/'.agentlang/paired-vocabulary-213'
condition=sys.argv[1]
assert condition in ['reset','retained']
score=json.loads((study/'dispatch'/(condition+'-score.json')).read_text())
receipt=json.loads((study/'dispatch'/(condition+'-scoring-receipt.json')).read_text())
out=root/'reports/evidence/213-paired-vocabulary-availability'
archive=out/(condition+'-result.zip')
index=out/(condition+'-result.index.json')
assert not archive.exists() and not index.exists(), 'Do not overwrite sealed result'
paths={study/'traces'/(condition+'.jsonl')}
for directory in [study/'actors'/condition,Path(score['evidenceDirectory'])]:
    paths.update(p for p in directory.rglob('*') if p.is_file())
paths.update(p for p in (study/'dispatch').glob(condition+'-*') if p.is_file())
paths.update(p for p in (study/'dispatch').glob('*dispatch.json') if p.is_file())
paths.update(study/name for name in ['source-pin.json','accepted-runtime-pin.json','frozen-inputs.json'])
paths.update(study/'dispatch'/name for name in ['score-condition.ps1','package-condition.py','lifecycle-observation.json'] if (study/'dispatch'/name).is_file())
members=[]
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(paths):
        assert root in p.resolve().parents and p.suffix.lower() not in {'.dll','.exe','.pdb','.pyc'}
        data=p.read_bytes(); name=p.relative_to(root).as_posix()
        z.writestr(name,data)
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist())==len(members)
    for r in members:
        data=z.read(r['path'])
        assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
result={'status':'sealed terminal participant result','condition':condition,'scoreStatus':score['status'],'auditExitCode':receipt['auditExitCode'],'scoreExitCode':receipt['scoreExitCode'],'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'memberCount':len(members),'members':members,'interpretationLimit':'One arm observation; no paired result until both fresh participants close and independent scores are accepted.'}
index.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'}))

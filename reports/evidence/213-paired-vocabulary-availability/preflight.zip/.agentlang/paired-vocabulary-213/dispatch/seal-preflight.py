import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys

root=Path(__file__).resolve().parents[3]
study=root/'.agentlang/paired-vocabulary-213'
sys.path.insert(0,str(root/'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle'))
import score_organic_reuse as scorer
source=json.loads((study/'source-pin.json').read_text())
runtime=json.loads((study/'accepted-runtime-pin.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in source['files']:
    assert sha(root/row['path'])==row['sha256']
for row in runtime['runtimeFiles']:
    assert sha(study/'runtime'/row['name'])==row['sha256']
prep=json.loads((study/'preflight/preparation.json').read_text())
for c in ['reset','retained']:
    assert scorer.project_fingerprint(study/'baselines'/c)==prep['baselines'][c]
    assert scorer.project_fingerprint(study/'actors'/c)==prep['baselines'][c]
    calibrated=json.loads((study/'preflight'/('adapter-'+c+'.json')).read_text())
    assert calibrated['status']=='passed' and calibrated['behavior']['passedCaseCount']==9
    assert calibrated['suite']['commonSeedTestCount']==137 and calibrated['actorProjectUnchangedDuringScore']
controls=json.loads((study/'c/a/20261011T095620Z-01/control-preflight-summary.json').read_text())
assert controls['status']=='preflight-passed'
assert all(r['status']=='preflight-passed' and r['behavior']['executedCaseCount']==9 for rows in controls['conditions'].values() for r in rows)
out=root/'reports/evidence/213-paired-vocabulary-availability'
out.mkdir(parents=True,exist_ok=True)
archive=out/'preflight.zip'
index=out/'preflight.index.json'
assert not archive.exists() and not index.exists()
paths=set()
for directory in [study/'baselines',study/'actors',study/'dispatch',study/'preflight',study/'c',study/'v',root/'experiments/AgentLang.SubagentTrials/paired-vocabulary-213',root/'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle']:
    for p in directory.rglob('*'):
        if p.is_file() and not {'seed-project','project-copy','__pycache__'} & set(p.parts):
            paths.add(p)
paths.update(root/row['path'] for row in source['files'])
paths.update([study/'source-pin.json',study/'accepted-runtime-pin.json'])
paths.update(root/name for name in [
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/score_agentlang.py',
    'reports/evidence/211-public-vocabulary-reuse/developer-result.index.json',
    'reports/evidence/213-paired-vocabulary-availability/review.md'])
pins=[]
for p in sorted(paths):
    assert root in p.resolve().parents and p.suffix.lower() not in {'.dll','.exe','.zip','.pdb','.pyc'}
    pins.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
frozen=study/'frozen-inputs.json'
assert not frozen.exists()
frozen.write_text(json.dumps({'status':'accepted pre-dispatch inputs; no participant output','files':pins,'launchOrder':prep['launchOrder'],'externalCapabilities':[],'model':'gpt-6-luna','reasoning':'max','maxExchanges':100},indent=2)+'\n')
paths.add(frozen)
members=[]
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(paths):
        data=p.read_bytes()
        name=p.relative_to(root).as_posix()
        z.writestr(name,data)
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist())==len(members)
    for row in members:
        data=z.read(row['path'])
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'status':'accepted pre-dispatch evidence; no participant result','archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'memberCount':len(members),'verification':'every member reopened; length and SHA256 verified','omissions':'compiled runtime and saved control/scoring copies; exact baselines, actor copies, requests/responses and pins retained','members':members}
index.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))

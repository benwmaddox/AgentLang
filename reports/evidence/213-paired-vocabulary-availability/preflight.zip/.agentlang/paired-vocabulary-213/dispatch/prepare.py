import hashlib
import json
from pathlib import Path
import secrets
import shutil
import sys

root=Path(__file__).resolve().parents[3]
study=root/'.agentlang/paired-vocabulary-213'
prior=root/'.agentlang/public-vocabulary-reuse-211'
sys.path.insert(0,str(root/'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle'))
import score_organic_reuse as scorer
source=json.loads((prior/'source-pin.json').read_text())
runtime=json.loads((prior/'accepted-runtime-pin.json').read_text())
for row in source['files']:
    data=(root/row['path']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
for row in runtime['runtimeFiles']:
    data=(prior/'runtime'/row['name']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
reset=root/'.agentlang/subscription-handoff-161/seeds/agentlang-project'
retained=prior/'accepted/creator/project'
inventory,_=scorer.validate_seed_inventory(reset)
assert scorer.project_fingerprint(retained)=='390c0ebc697b735a21e5f12efe508b5e192f3d04c1a8947d9174f1835f62edd2'
for condition,baseline in [('reset',reset),('retained',retained)]:
    shutil.copytree(baseline,study/'baselines'/condition)
    shutil.copytree(baseline,study/'actors'/condition)
    assert scorer.project_fingerprint(baseline)==scorer.project_fingerprint(study/'actors'/condition)
shutil.copytree(prior/'runtime',study/'runtime')
for name in ['source-pin.json','accepted-runtime-pin.json']:
    shutil.copy2(prior/name,study/name)
for folder in ['tmp','traces','preflight']:
    (study/folder).mkdir(exist_ok=True)
order=['reset','retained']
if secrets.randbelow(2):
    order.reverse()
receipt={'status':'prepared; controls and adapter review pending','sourceFilesVerified':len(source['files']),'runtimeFilesVerified':len(runtime['runtimeFiles']),'runtimeOrigin':'accepted freshly built 210 binary; all build/host inputs unchanged','seedManifestHash':inventory['manifestHash'],'baselines':{c:scorer.project_fingerprint(study/'baselines'/c) for c in order},'launchOrder':order,'orderMethod':'one random draw before either dispatch; sequential execution','externalCapabilities':[],'filesystemMode':'virtual'}
(study/'preflight/preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))

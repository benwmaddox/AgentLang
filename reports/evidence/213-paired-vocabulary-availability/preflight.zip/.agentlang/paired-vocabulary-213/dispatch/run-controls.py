import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parents[3]
study=root/'.agentlang/paired-vocabulary-213'
sys.path.insert(0,str(root/'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle'))
import score_organic_reuse as scorer
import control_preflight as controls
import run_preflight_controls as runner

scorer.STUDY_ROOT=study
cli=study/'runtime/AgentLang.Cli.dll'
pin=runner.validate_runtime_pin(cli)
original=controls.creator_source
attempt=scorer.create_run_directory(study/'c','a')
reports={}
for condition in ['reset','retained']:
    project=study/'baselines'/condition
    before=scorer.project_fingerprint(project)
    if condition=='reset':
        scorer.validate_seed_inventory(project)
        controls.creator_source=original
    else:
        assert before=='390c0ebc697b735a21e5f12efe508b5e192f3d04c1a8947d9174f1835f62edd2'
        controls.creator_source=lambda mutant='correct':''
    reports[condition]=[runner.run_variant(v,cli,project,attempt/condition[0],pin) for v in controls.SUCCESSOR_VARIANTS]
    assert before==scorer.project_fingerprint(project)
summary={'status':'preflight-passed' if all(r['status']=='preflight-passed' for rows in reports.values() for r in rows) else 'preflight-failed','scope':'six batch behavior controls; not participant or library qualification','conditions':reports,'baselinesUnchanged':True,'runtimeInvocation':{'filesystemMode':'virtual','capabilities':[],'testCapabilities':[]}}
(attempt/'control-preflight-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'summary':str(attempt/'control-preflight-summary.json')},indent=2))
raise SystemExit(0 if summary['status']=='preflight-passed' else 1)

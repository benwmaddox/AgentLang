from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
repo=root.parents[1]
source=repo/'experiments/AgentLang.Business/Business.fs'
inventory=root/'setup/inventory.json'
backup=root/'setup/inventory-before-reference.json'
if backup.exists(): raise RuntimeError('Refusing repeat seed augmentation')
shutil.copy2(inventory,backup)
for directory in [root/'seeds/conventional',root/'actors/conventional']:
    target=directory/'Reference/Business.fs'
    if target.exists(): raise RuntimeError('Reference already present')
    target.parent.mkdir()
    shutil.copy2(source,target)
record=json.loads(inventory.read_text())
record['files'].append({'path':'seeds\\conventional\\Reference\\Business.fs','sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
record['referenceSource']='Frozen broker-readable host source, not compiled or editable by the participant.'
inventory.write_text(json.dumps(record,indent=2))
print('Added matching read-only conventional implementation source to seed and actor.')

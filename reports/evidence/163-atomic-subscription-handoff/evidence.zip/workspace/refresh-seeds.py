from pathlib import Path
import hashlib, json, shutil, subprocess, os

repo = Path(__file__).resolve().parents[2]
root = repo / '.agentlang/subscription-handoff-163'
source = repo / '.agentlang/subscription-handoff-161/seeds'
setup = root / 'setup'
setup.mkdir(parents=True, exist_ok=True)
seeds = root / 'seeds'
if seeds.exists():
    raise RuntimeError('Refusing to overwrite existing seeds')
shutil.copytree(source / 'agentlang-project', seeds / 'agentlang-project')
shutil.copytree(source / 'conventional', seeds / 'conventional', ignore=shutil.ignore_patterns('bin','obj'))
shutil.copy2(repo / 'experiments/AgentLang.Business/bin/Release/net9.0/AgentLang.Business.dll', seeds / 'conventional/lib/AgentLang.Business.dll')
tmp = root / 'tmp'
tmp.mkdir(exist_ok=True)
env = dict(os.environ, TEMP=str(tmp), TMP=str(tmp))
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
requests = '\n'.join(json.dumps({'op': op}) for op in ['words','test-all'])+'\n'
(setup / 'language-requests.jsonl').write_text(requests)
p = subprocess.run(['dotnet',str(cli),'--project',str(seeds/'agentlang-project'),'--filesystem','virtual','--jsonl'],input=requests,text=True,capture_output=True,env=env)
(setup / 'language-responses.jsonl').write_text(p.stdout)
(setup / 'language-stderr.txt').write_text(p.stderr)
assert p.returncode == 0, p.stderr
responses = [json.loads(line) for line in p.stdout.splitlines()]
assert len(responses)==2 and all(r['ok'] for r in responses)
assert len(responses[0]['data']['words'])==214
assert all(w['maturity']=='library' for w in responses[0]['data']['words'])
assert not any(w['name']=='subscription.handoff' for w in responses[0]['data']['words'])
assert len(responses[1]['data']['results'])==137 and all(t['passed'] for t in responses[1]['data']['results'])
project = seeds / 'conventional/SubscriptionHandoff.Conventional.fsproj'
command=['dotnet','build',str(project),'-c','Release','-m:1','-p:NuGetAudit=false','--nologo']
p=subprocess.run(command,text=True,capture_output=True,env=env)
(setup/'conventional-build.log').write_text(p.stdout+p.stderr)
assert p.returncode==0
p=subprocess.run(['dotnet',str(project.parent/'bin/Release/net9.0/SubscriptionHandoff.Conventional.dll')],text=True,capture_output=True,env=env)
(setup/'conventional-baseline.log').write_text(p.stdout+p.stderr)
assert p.returncode==0 and 'Baseline checks passed: 6' in p.stdout
inventory={ 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(), 'languageWords':214,'languageTests':137,'conventionalBaselineGroups':6,'files':[] }
for path in sorted(seeds.rglob('*')):
    if path.is_file() and not any(part in ('bin','obj') for part in path.relative_to(seeds).parts):
        inventory['files'].append({'path':str(path.relative_to(root)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
for path in [cli,repo/'experiments/AgentLang.Conventional.Cli/bin/Release/net9.0/AgentLang.Conventional.Cli.dll']:
    inventory.setdefault('runtime',[]).append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(setup/'inventory.json').write_text(json.dumps(inventory,indent=2))
print('Current runtime seeds verified: 214 library words, 137 tests; conventional 6 baseline groups.')

from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
seed=root/'seeds/conventional'
actor=root/'actors/conventional'
inventory=json.loads((root/'setup/inventory.json').read_text())
prefix='seeds\\conventional\\'
unchanged=[]
for row in inventory['files']:
    if row['path'].startswith(prefix):
        relative=row['path'][len(prefix):]
        if relative not in ['Operations.fs','SelfTests.fs']:
            assert hashlib.sha256((actor/relative).read_bytes()).hexdigest()==row['sha256'],relative
            unchanged.append(relative)
original=(seed/'Operations.fs').read_text()
edited=(actor/'Operations.fs').read_text()
assert edited.startswith(original)
assert edited[len(original):].count('let handoff ')==1
original_tests=(seed/'SelfTests.fs').read_text()
original_body=original_tests.rsplit('        printfn "Baseline checks passed: 6"',1)[0]
edited_tests=(actor/'SelfTests.fs').read_text()
assert edited_tests.startswith(original_body)
result={'status':'pass','unchangedInfrastructureFiles':unchanged,
 'existingOperationsSourcePreserved':True,'existingTestBodyPreserved':True,
 'newFunction':'Subscription.handoff',
 'newTargetCallsInSelfTests':edited_tests[len(original_body):].count('Subscription.handoff')}
(root/'preservation-conventional.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

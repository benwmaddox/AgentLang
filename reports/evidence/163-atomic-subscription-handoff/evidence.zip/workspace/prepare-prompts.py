from pathlib import Path

root=Path(__file__).resolve().parent
common='''You are a fresh external experimental coding agent. The human explicitly authorizes edits ONLY to your isolated trial project and local test execution through the supplied broker. Read this assigned prompt and launch the specified broker; otherwise use only that broker for discovery, edits and tests. Do not read main repository source, other trials, hidden oracles, reports or snapshots. Do not use web tools, spawn agents, list/read/contact other agents or run other shell commands. Disclose any non-broker tool use. Use one broker process, at most 100 exchanges. Poll the same handle after observation timeouts. Finish with {"op":"host.close"} and observe terminal status.

Public task: add one pure atomic subscription handoff operation. Given a Store, old subscription ID, replacement ID, replacement term, handoff instant and replacement expiry, end the old subscription at the handoff instant and create an active replacement for the same customer and product beginning at that exact instant. Preserve existing cancellation rules and their error precedence. Only after those succeed, apply existing creation rules and their error precedence. On success return the final Store. Preserve every unrelated entity and all old subscription fields except status and cancellation timestamp. Trim the new term. On failure return the existing error code; do not report the intermediate cancelled Store as a successful handoff. The caller's input remains unchanged. Discover existing project capabilities, document the new function, add meaningful regression tests and retain all prior behavior/tests. Reuse useful existing functionality where appropriate.

'''
flow='''Implement subscription.handoff(store: Store, oldId: SubscriptionId, replacementId: SubscriptionId, term: String, handoffAt: Instant, expiresAt: Instant) -> Result<Store, BusinessError>. Commit as library, persist attached tests and finish the task session. Existing definitions must keep library status. Add only new function(s) and attached tests. All requests that author/evaluate Flow must specify frontend: "flow", syntaxVersion: 2.

Compact primer: fn name(parameter: Type) -> Type { ... }. Qualified calls use dots. Local receiver calls value.operation(args) pass value first; record properties use value.field. Bind with let name = expression. Newlines separate statements, final expression is result. Put effects before doc, blank line before body; omitted effects means pure. Enum values are zero-argument constructor calls. Use help with syntaxVersion:2 for exact syntax and testing, including Result expectations.
Useful operations: search, describe, source, tests, dependencies, callers, help, define, test, test-all, commit, task.begin, task.status, task.commit. Example: {"op":"commit","word":"subscription.handoff","library":true}.
'''
conventional='''Implement Subscription.handoff(store, oldId, replacementId, term, handoffAt, expiresAt) returning Result<Store, DomainError> by adding a function to Operations.fs. Preserve existing functions. Add meaningful tests to SelfTests.fs and run validate. Edit only Operations.fs and SelfTests.fs; all other files are frozen infrastructure readable through the broker. Reference/Business.fs is frozen implementation documentation and must not be edited.

Broker JSONL operations: {"op":"inspect"} lists files; {"op":"read","path":"Operations.fs"} returns source/SHA256. replace requires path, expectedSha256 and content. patch requires path, expectedSha256, oldText and newText. search uses query. validate executes the fixed local self-test executable. No arbitrary shell commands.
'''
for arm,primer,dll,ops,extra in [
 ('flow',flow,'flow/AgentLang.Cli.dll','help,words,source,tests,define,test,test-all,commit,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort',"-Profile 'agentlang'"),
 ('conventional',conventional,'conventional/AgentLang.Conventional.Cli.dll','inspect,read,search,patch,replace,validate',"-Profile 'conventional' -AdditionalCliArguments @('--validation-project','SubscriptionHandoff.Conventional.fsproj')")]:
    command=f'''\nLaunch once using exec_command with tty:true and yield_time_ms:10000. If sandbox rejects this authorized launch, the same command may use require_escalated without broadening scope.

```powershell
$env:TEMP = '{root / 'tmp'}'
$env:TMP = $env:TEMP
& 'D:\\code\\AgentLang\\scripts\\Start-SubagentTrialHostV2.ps1' -CliDll '{root / 'runtime' / dll}' -ProjectPath '{root / 'actors' / arm}' -TracePath '{root / ('trace-'+arm+'.jsonl')}' -AllowedOperations @('{ops}') {extra} -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```
'''
    (root/f'prompt-{arm}.md').write_text(common+primer+command,encoding='utf-8')
print('Draft matched prompts created; do not dispatch until actual controls pass and pins freeze.')

from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
repo=root.parents[1]
manifest=json.loads((root/'freeze/manifest.json').read_text())
archive=root/'freeze/inputs.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archiveSha256']
checked=[]
for row in manifest['files']:
    name=row['path']
    path=None
    if name.startswith('protocol/'):
        path=repo/'experiments/AgentLang.SubagentTrials/subscription-handoff-161'/name[len('protocol/'):]
    elif name.startswith('broker/'):
        path=repo/'scripts'/name[len('broker/'):]
    elif name.startswith('workspace/runtime/') or name.startswith('workspace/seeds/'):
        path=root/name[len('workspace/'):]
    elif name.startswith('workspace/prompt-'):
        path=root/name[len('workspace/'):]
    elif name.startswith('workspace/control/') and Path(name).suffix in ['.fs','.fsproj','.py','.agent']:
        path=root/name[len('workspace/'):]
    if path is not None:
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],str(path)
        checked.append(name)
result={'status':'pass','preDispatchArchiveSha256':manifest['archiveSha256'],
 'staticInputFilesChecked':len(checked),'files':checked,
 'scope':'Runtime, seed files, prompts, original protocol/oracle files, broker, control/scorer source. Actor working files and generated grading outputs may change.'}
(root/'frozen-input-audit.json').write_text(json.dumps(result,indent=2))
print(f'Frozen input archive and {len(checked)} static files unchanged.')

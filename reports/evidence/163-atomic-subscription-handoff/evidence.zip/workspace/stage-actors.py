from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
inventory=json.loads((root/'setup/inventory.json').read_text())
for arm,seed in [('flow','agentlang-project'),('conventional','conventional')]:
    actor=root/'actors'/arm
    if actor.exists(): raise RuntimeError(f'Refusing to overwrite actor {arm}')
    shutil.copytree(root/'seeds'/seed,actor,ignore=shutil.ignore_patterns('bin','obj'))
    count=0
    prefix=f'seeds\\{seed}\\'
    for item in inventory['files']:
        if item['path'].startswith(prefix):
            path=actor/item['path'][len(prefix):]
            assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],str(path)
            count+=1
    print(f'{arm}: {count} inventoried seed files match staged actor')
(root/'setup/actors-staged.json').write_text(json.dumps({'status':'staged, dispatch pending controls/review/freeze','arms':['flow','conventional']},indent=2))

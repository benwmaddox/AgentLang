"""Run only after root verifies actual controls and prompt review.

Preserves the complete pre-dispatch inputs, including initial actor copies, as
an immutable archive. Actor files may change only after this freeze.
"""
from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path(__file__).resolve().parent
repo=root.parents[1]
out=root/'freeze'
if out.exists(): raise RuntimeError('Refusing to replace a frozen trial')
approval=root/'setup/dispatch-readiness.json'
readiness=json.loads(approval.read_text())
assert readiness['actualControlsPassed'] and readiness['promptReviewResolved']
assert readiness['participantsDispatched'] is False
for proof in readiness['proofs']:
    assert hashlib.sha256((root/proof['path']).read_bytes()).hexdigest()==proof['sha256'],proof['path']
staged=json.loads((root/'setup/staged-runtime.json').read_text())
for item in staged['files']:
    path=Path(item['path'])
    if not path.is_absolute(): path=root/path
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],str(path)
inventory=json.loads((root/'setup/inventory.json').read_text())
for item in inventory['files']:
    path=root/item['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],str(path)
    for seed,arm in [('agentlang-project','flow'),('conventional','conventional')]:
        prefix=f'seeds\\{seed}\\'
        if item['path'].startswith(prefix):
            actor=root/'actors'/arm/item['path'][len(prefix):]
            assert hashlib.sha256(actor.read_bytes()).hexdigest()==item['sha256'],str(actor)
inputs=[]
for directory in ['seeds','actors','runtime','control','setup']:
    for path in (root/directory).rglob('*'):
        if path.is_file() and not any(p in ('bin','obj') for p in path.relative_to(root/directory).parts):
            if directory=='setup' and any(p.endswith('-project') for p in path.relative_to(root/directory).parts): continue
            inputs.append((f'workspace/{path.relative_to(root).as_posix()}',path))
for path in root.glob('*.py'): inputs.append((f'workspace/{path.name}',path))
for path in root.glob('prompt-*.md'): inputs.append((f'workspace/{path.name}',path))
trial=repo/'experiments/AgentLang.SubagentTrials/subscription-handoff-161'
for path in trial.rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts:
        inputs.append((f'protocol/{path.relative_to(trial).as_posix()}',path))
broker=repo/'scripts/Start-SubagentTrialHostV2.ps1'
inputs.append(('broker/Start-SubagentTrialHostV2.ps1',broker))
out.mkdir()
rows=[]
archive=out/'inputs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in sorted(inputs):
        data=path.read_bytes()
        rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    for row in rows: assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
manifest={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'status':'pre-dispatch freeze','readiness':readiness,'files':rows,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(f'Frozen and verified {len(rows)} inputs; {manifest["archiveSha256"]}')

namespace AgentLang.SubscriptionHandoff

open AgentLang.Business.Domain
open System

module Subscription =
    let id = AgentLang.Business.Domain.Subscription.id
    let customerId = AgentLang.Business.Domain.Subscription.customerId
    let productId = AgentLang.Business.Domain.Subscription.productId
    let term = AgentLang.Business.Domain.Subscription.term
    let startedAt = AgentLang.Business.Domain.Subscription.startedAt
    let expiresAt = AgentLang.Business.Domain.Subscription.expiresAt
    let status = AgentLang.Business.Domain.Subscription.status
    let cancelledAt = AgentLang.Business.Domain.Subscription.cancelledAt
    let occupiedPeriod = AgentLang.Business.Domain.Subscription.occupiedPeriod
    let start = AgentLang.Business.Domain.Subscription.start
    let cancel = AgentLang.Business.Domain.Subscription.cancel

    let handoff (store: Store) (oldId: SubscriptionId) (replacementId: SubscriptionId)
                (term: string) (handoffAt: DateTimeOffset) (expiresAt: DateTimeOffset) : Result<Store, DomainError> =
        if Store.subscription replacementId store |> Option.isSome then
            Error(DuplicateSubscription replacementId)
        else
            match cancel store oldId handoffAt with
            | Error error -> Error error
            | Ok (cancelledStore, oldSubscription) ->
                start cancelledStore replacementId (customerId oldSubscription) (productId oldSubscription)
                    term handoffAt expiresAt
                |> Result.map fst

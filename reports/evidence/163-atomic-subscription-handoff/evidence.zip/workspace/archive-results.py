from pathlib import Path
import hashlib,json,zipfile,subprocess,datetime
root=Path(__file__).resolve().parent
repo=root.parents[1]
out=repo/'reports/evidence/163-atomic-subscription-handoff'
if out.exists(): raise RuntimeError('Refusing to overwrite durable evidence')
out.mkdir(parents=True)
inputs=[]
for name,base in [('workspace',root),('protocol',repo/'experiments/AgentLang.SubagentTrials/subscription-handoff-161')]:
    for path in base.rglob('*'):
        if path.is_file() and not any(part in ('bin','obj','__pycache__') for part in path.relative_to(base).parts):
            inputs.append((f'{name}/{path.relative_to(base).as_posix()}',path))
for relative in ['scripts/Start-SubagentTrialHostV2.ps1','scripts/Audit-SubagentTrialTerminationV2.ps1','README.md','docs/ROADMAP.md']:
    inputs.append((f'repository/{relative}',repo/relative))
rows=[]
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in sorted(inputs):
        data=path.read_bytes()
        rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(rows)
    for row in rows:
        assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],row['path']
manifest={'sourceBaseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'entryCount':len(rows),'archiveBytes':archive.stat().st_size,
 'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'exclusions':['bin','obj','__pycache__','referencing report'],
 'scope':'Pre-dispatch frozen archive (including staged runtimes), retained setup/control evidence, final actor projects, traces, acceptance and preservation audits, scorer/model/source, report input documents.',
 'files':rows}
(out/'archive.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))

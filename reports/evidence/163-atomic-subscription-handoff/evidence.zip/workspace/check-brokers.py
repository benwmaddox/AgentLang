from pathlib import Path
import json,shutil,subprocess,os,sys
root=Path(__file__).resolve().parent
repo=root.parents[1]
env=dict(os.environ,TEMP=str(root/'tmp'),TMP=str(root/'tmp'))
attempt=sys.argv[1] if len(sys.argv)>1 else '002'
for arm,seed,dll,op,extra in [('flow','agentlang-project','AgentLang.Cli.dll','test-all',[]),('conventional','conventional','AgentLang.Conventional.Cli.dll','validate',['-AdditionalCliArgumentsJson','["--validation-project","SubscriptionHandoff.Conventional.fsproj"]'])]:
    prefix=f'broker-{arm}-{attempt}'
    project=root/'setup'/f'{prefix}-project'
    if project.exists(): raise RuntimeError('Refusing overwrite')
    shutil.copytree(root/'seeds'/seed,project,ignore=shutil.ignore_patterns('bin','obj'))
    script=repo/'scripts/Start-SubagentTrialHostV2.ps1'
    trace=root/'setup'/f'{prefix}-trace.jsonl'
    allowed=op if arm=='flow' else op+',read'
    command=['pwsh','-NoProfile','-File',str(script),'-CliDll',str(root/'runtime'/arm/dll),'-ProjectPath',str(project),'-TracePath',str(trace),'-AllowedOperations',allowed,'-Profile','agentlang' if arm=='flow' else 'conventional','-ExchangeTimeoutMilliseconds','120000','-MaxExchanges','100']+extra
    operations=[{'op':op}]
    if arm=='conventional': operations.append({'op':'read','path':'Reference/Business.fs'})
    requests='\n'.join(json.dumps(r) for r in operations+[{'op':'host.close'}])+'\n'
    (root/'setup'/f'{prefix}-requests.jsonl').write_text(requests)
    result=subprocess.run(command,input=requests,text=True,capture_output=True,env=env,timeout=300)
    (root/'setup'/f'{prefix}-stdout.txt').write_text(result.stdout)
    (root/'setup'/f'{prefix}-stderr.txt').write_text(result.stderr)
    assert result.returncode==0,(arm,result.stderr)
    rows=[json.loads(line) for line in result.stdout.splitlines() if line.strip().startswith('{')]
    assert len(rows)==len(operations) and all(row['ok'] for row in rows),(arm,'baseline/reference response failed')
    events=[json.loads(line) for line in trace.read_text().splitlines()]
    terminal=events[-1]
    assert terminal['event']=='session-end' and terminal['terminationKind']=='host-close'
    assert terminal['hostExitCode']==0 and terminal['runtimeExitCode']==0
    print(f'{arm}: baseline broker exchange and clean close passed')

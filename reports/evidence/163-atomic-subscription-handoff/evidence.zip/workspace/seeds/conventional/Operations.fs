namespace AgentLang.SubscriptionHandoff

module Subscription =
    let id = AgentLang.Business.Domain.Subscription.id
    let customerId = AgentLang.Business.Domain.Subscription.customerId
    let productId = AgentLang.Business.Domain.Subscription.productId
    let term = AgentLang.Business.Domain.Subscription.term
    let startedAt = AgentLang.Business.Domain.Subscription.startedAt
    let expiresAt = AgentLang.Business.Domain.Subscription.expiresAt
    let status = AgentLang.Business.Domain.Subscription.status
    let cancelledAt = AgentLang.Business.Domain.Subscription.cancelledAt
    let occupiedPeriod = AgentLang.Business.Domain.Subscription.occupiedPeriod
    let start = AgentLang.Business.Domain.Subscription.start
    let cancel = AgentLang.Business.Domain.Subscription.cancel

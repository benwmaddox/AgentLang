namespace AgentLang.SubscriptionHandoff

open AgentLang.Business.Domain

module SelfTests =
    let private assertEqual label expected actual =
        if actual <> expected then
            failwithf "%s: expected %A but received %A" label expected actual

    let private subscriptionId value =
        SubscriptionId.parse value
        |> Result.defaultWith (fun error -> failwithf "fixture subscription id: %s" (DomainError.message error))

    let run () =
        let seed = Fixtures.create ()
        let summary = Store.summary seed.Store
        assertEqual "seed customer count" 1 summary.Customers
        assertEqual "seed product count" 1 summary.Products
        assertEqual "seed includes one active subscription" 1 summary.Subscriptions
        let original =
            Store.subscription seed.OldSubscriptionId seed.Store
            |> Option.defaultWith (fun () -> failwith "seed subscription is missing")
        assertEqual "seed subscription is active" Active (Subscription.status original)
        assertEqual "seed subscription starts at the canonical time" (Fixtures.instant 2026 1 2) (Subscription.startedAt original)
        assertEqual "seed subscription expires at the canonical time" (Fixtures.instant 2026 2 1) (Subscription.expiresAt original)

        let adjacentId = subscriptionId "30000000-0000-0000-0000-000000000002"
        let started =
            match Subscription.start seed.Store adjacentId seed.CustomerId seed.ProductId "monthly"
                    (Fixtures.instant 2026 2 1) (Fixtures.instant 2026 3 1) with
            | Ok (updated, subscription) ->
                assertEqual "start returns the requested identifier" adjacentId (Subscription.id subscription)
                assertEqual "start creates an active subscription" Active (Subscription.status subscription)
                updated
            | Error error -> failwithf "valid adjacent subscription start failed: %s" (DomainError.message error)

        assertEqual "start leaves the input store unchanged" 1 (Store.summary seed.Store).Subscriptions
        assertEqual "start returns a new store" 2 (Store.summary started).Subscriptions

        let overlappingId = subscriptionId "30000000-0000-0000-0000-000000000003"
        match Subscription.start seed.Store overlappingId seed.CustomerId seed.ProductId "monthly"
                (Fixtures.instant 2026 1 15) (Fixtures.instant 2026 2 15) with
        | Error SubscriptionOverlap -> ()
        | Error error -> failwithf "overlap returned the wrong error: %s" (DomainError.message error)
        | Ok _ -> failwith "overlapping subscription was accepted"

        let blankTermId = subscriptionId "30000000-0000-0000-0000-000000000004"
        match Subscription.start seed.Store blankTermId seed.CustomerId seed.ProductId "  "
                (Fixtures.instant 2026 1 2) (Fixtures.instant 2026 2 1) with
        | Error InvalidSubscriptionTerm -> ()
        | Error error -> failwithf "blank term returned the wrong error: %s" (DomainError.message error)
        | Ok _ -> failwith "blank subscription term was accepted"

        let cancellationTime = Fixtures.instant 2026 1 15
        let cancelled =
            match Subscription.cancel seed.Store seed.OldSubscriptionId cancellationTime with
            | Ok (updated, subscription) ->
                assertEqual "cancel returns a cancelled subscription" Cancelled (Subscription.status subscription)
                assertEqual "cancel records the requested time" (Some cancellationTime) (Subscription.cancelledAt subscription)
                updated
            | Error error -> failwithf "valid subscription cancel failed: %s" (DomainError.message error)

        assertEqual "cancel leaves its input store unchanged" Active (Store.subscription seed.OldSubscriptionId seed.Store |> Option.map Subscription.status |> Option.defaultValue Cancelled)
        assertEqual "cancel returns an updated store" Cancelled (Store.subscription seed.OldSubscriptionId cancelled |> Option.map Subscription.status |> Option.defaultValue Active)

        match Subscription.cancel seed.Store seed.OldSubscriptionId (Fixtures.instant 2026 1 1) with
        | Error (CancelBeforeSubscriptionStart _) -> ()
        | Error error -> failwithf "early cancellation returned the wrong error: %s" (DomainError.message error)
        | Ok _ -> failwith "cancellation before start was accepted"

        printfn "Baseline checks passed: 6"
